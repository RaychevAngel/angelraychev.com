import HPFiniteA3B2Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
namespace THalfPlaneFinite
open CrossUnits PolyominoFormal

theorem hp3_2_node1373 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1373 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1373 ((5 : Int),(1 : Int)) hp3_2_branches1373 hp3_2_evidence1373 hp3_2_check1373 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1373,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1372 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1372 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1372 ((5 : Int),(1 : Int)) hp3_2_branches1372 hp3_2_evidence1372 hp3_2_check1372 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1372,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1371 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1371 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1371 ((5 : Int),(1 : Int)) hp3_2_branches1371 hp3_2_evidence1371 hp3_2_check1371 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1371,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1370 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1370 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1370 ((6 : Int),(1 : Int)) hp3_2_branches1370 hp3_2_evidence1370 hp3_2_check1370 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1370,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1369 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1369 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1369 ((6 : Int),(1 : Int)) hp3_2_branches1369 hp3_2_evidence1369 hp3_2_check1369 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1369,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1368 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1368 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1368 ((5 : Int),(1 : Int)) hp3_2_branches1368 hp3_2_evidence1368 hp3_2_check1368 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1368,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1369 T childKnown
  · exact hp3_2_node1370 T childKnown
theorem hp3_2_node1367 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1367 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1367 ((5 : Int),(1 : Int)) hp3_2_branches1367 hp3_2_evidence1367 hp3_2_check1367 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1367,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1366 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1366 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1366 ((4 : Int),(1 : Int)) hp3_2_branches1366 hp3_2_evidence1366 hp3_2_check1366 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1366,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1367 T childKnown
  · exact hp3_2_node1368 T childKnown
  · exact hp3_2_node1371 T childKnown
  · exact hp3_2_node1372 T childKnown
  · exact hp3_2_node1373 T childKnown
theorem hp3_2_node1365 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1365 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1365 ((5 : Int),(1 : Int)) hp3_2_branches1365 hp3_2_evidence1365 hp3_2_check1365 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1365,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1364 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1364 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1364 ((5 : Int),(1 : Int)) hp3_2_branches1364 hp3_2_evidence1364 hp3_2_check1364 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1364,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1363 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1363 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1363 ((0 : Int),(2 : Int)) hp3_2_branches1363 hp3_2_evidence1363 hp3_2_check1363 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1363,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1362 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1362 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1362 ((1 : Int),(1 : Int)) hp3_2_branches1362 hp3_2_evidence1362 hp3_2_check1362 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1362,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1363 T childKnown
theorem hp3_2_node1361 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1361 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1361 ((2 : Int),(2 : Int)) hp3_2_branches1361 hp3_2_evidence1361 hp3_2_check1361 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1361,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1360 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1360 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1360 ((2 : Int),(2 : Int)) hp3_2_branches1360 hp3_2_evidence1360 hp3_2_check1360 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1360,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1359 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1359 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1359 ((2 : Int),(1 : Int)) hp3_2_branches1359 hp3_2_evidence1359 hp3_2_check1359 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1359,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1360 T childKnown
  · exact hp3_2_node1361 T childKnown
  · exact hp3_2_node1362 T childKnown
theorem hp3_2_node1358 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1358 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1358 ((5 : Int),(1 : Int)) hp3_2_branches1358 hp3_2_evidence1358 hp3_2_check1358 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1358,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1359 T childKnown
theorem hp3_2_node1357 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1357 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1357 ((5 : Int),(1 : Int)) hp3_2_branches1357 hp3_2_evidence1357 hp3_2_check1357 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1357,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1356 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1356 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1356 ((4 : Int),(1 : Int)) hp3_2_branches1356 hp3_2_evidence1356 hp3_2_check1356 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1356,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1357 T childKnown
  · exact hp3_2_node1358 T childKnown
  · exact hp3_2_node1364 T childKnown
  · exact hp3_2_node1365 T childKnown
theorem hp3_2_node1355 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1355 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1355 ((6 : Int),(1 : Int)) hp3_2_branches1355 hp3_2_evidence1355 hp3_2_check1355 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1355,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1354 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1354 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1354 ((6 : Int),(1 : Int)) hp3_2_branches1354 hp3_2_evidence1354 hp3_2_check1354 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1354,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1353 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1353 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1353 ((6 : Int),(0 : Int)) hp3_2_branches1353 hp3_2_evidence1353 hp3_2_check1353 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1353,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1354 T childKnown
  · exact hp3_2_node1355 T childKnown
theorem hp3_2_node1352 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1352 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1352 ((4 : Int),(1 : Int)) hp3_2_branches1352 hp3_2_evidence1352 hp3_2_check1352 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1352,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1353 T childKnown
theorem hp3_2_node1351 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1351 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1351 ((0 : Int),(2 : Int)) hp3_2_branches1351 hp3_2_evidence1351 hp3_2_check1351 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1351,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1350 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1350 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1350 ((1 : Int),(1 : Int)) hp3_2_branches1350 hp3_2_evidence1350 hp3_2_check1350 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1350,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1351 T childKnown
theorem hp3_2_node1349 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1349 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1349 ((2 : Int),(2 : Int)) hp3_2_branches1349 hp3_2_evidence1349 hp3_2_check1349 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1349,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1348 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1348 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1348 ((2 : Int),(2 : Int)) hp3_2_branches1348 hp3_2_evidence1348 hp3_2_check1348 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1348,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1347 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1347 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1347 ((2 : Int),(1 : Int)) hp3_2_branches1347 hp3_2_evidence1347 hp3_2_check1347 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1347,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1348 T childKnown
  · exact hp3_2_node1349 T childKnown
  · exact hp3_2_node1350 T childKnown
theorem hp3_2_node1346 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1346 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1346 ((6 : Int),(0 : Int)) hp3_2_branches1346 hp3_2_evidence1346 hp3_2_check1346 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1346,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1347 T childKnown
theorem hp3_2_node1345 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1345 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1345 ((4 : Int),(1 : Int)) hp3_2_branches1345 hp3_2_evidence1345 hp3_2_check1345 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1345,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1346 T childKnown
theorem hp3_2_node1344 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1344 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1344 ((4 : Int),(1 : Int)) hp3_2_branches1344 hp3_2_evidence1344 hp3_2_check1344 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1344,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1343 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1343 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1343 ((4 : Int),(1 : Int)) hp3_2_branches1343 hp3_2_evidence1343 hp3_2_check1343 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1343,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1342 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1342 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1342 ((5 : Int),(0 : Int)) hp3_2_branches1342 hp3_2_evidence1342 hp3_2_check1342 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1342,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1343 T childKnown
  · exact hp3_2_node1344 T childKnown
  · exact hp3_2_node1345 T childKnown
  · exact hp3_2_node1352 T childKnown
  · exact hp3_2_node1356 T childKnown
  · exact hp3_2_node1366 T childKnown
theorem hp3_2_node1341 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1341 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1341 ((2 : Int),(2 : Int)) hp3_2_branches1341 hp3_2_evidence1341 hp3_2_check1341 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1341,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1340 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1340 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1340 ((4 : Int),(2 : Int)) hp3_2_branches1340 hp3_2_evidence1340 hp3_2_check1340 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1340,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1341 T childKnown
theorem hp3_2_node1339 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1339 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1339 ((6 : Int),(2 : Int)) hp3_2_branches1339 hp3_2_evidence1339 hp3_2_check1339 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1339,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1340 T childKnown
theorem hp3_2_node1338 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1338 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1338 ((6 : Int),(2 : Int)) hp3_2_branches1338 hp3_2_evidence1338 hp3_2_check1338 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1338,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1337 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1337 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1337 ((6 : Int),(2 : Int)) hp3_2_branches1337 hp3_2_evidence1337 hp3_2_check1337 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1337,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1336 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1336 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1336 ((7 : Int),(1 : Int)) hp3_2_branches1336 hp3_2_evidence1336 hp3_2_check1336 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1336,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1337 T childKnown
  · exact hp3_2_node1338 T childKnown
  · exact hp3_2_node1339 T childKnown
theorem hp3_2_node1335 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1335 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1335 ((5 : Int),(0 : Int)) hp3_2_branches1335 hp3_2_evidence1335 hp3_2_check1335 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1335,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1336 T childKnown
theorem hp3_2_node1334 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1334 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1334 ((5 : Int),(2 : Int)) hp3_2_branches1334 hp3_2_evidence1334 hp3_2_check1334 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1334,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1333 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1333 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1333 ((4 : Int),(2 : Int)) hp3_2_branches1333 hp3_2_evidence1333 hp3_2_check1333 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1333,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1334 T childKnown
theorem hp3_2_node1332 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1332 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1332 ((4 : Int),(2 : Int)) hp3_2_branches1332 hp3_2_evidence1332 hp3_2_check1332 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1332,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1331 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1331 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1331 ((0 : Int),(2 : Int)) hp3_2_branches1331 hp3_2_evidence1331 hp3_2_check1331 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1331,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1330 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1330 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1330 ((10 : Int),(0 : Int)) hp3_2_branches1330 hp3_2_evidence1330 hp3_2_check1330 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1330,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1329 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1329 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1329 ((10 : Int),(0 : Int)) hp3_2_branches1329 hp3_2_evidence1329 hp3_2_check1329 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1329,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1328 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1328 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1328 ((10 : Int),(0 : Int)) hp3_2_branches1328 hp3_2_evidence1328 hp3_2_check1328 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1328,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1327 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1327 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1327 ((10 : Int),(1 : Int)) hp3_2_branches1327 hp3_2_evidence1327 hp3_2_check1327 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1326 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1326 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1326 ((10 : Int),(1 : Int)) hp3_2_branches1326 hp3_2_evidence1326 hp3_2_check1326 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1326,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1325 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1325 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1325 ((10 : Int),(0 : Int)) hp3_2_branches1325 hp3_2_evidence1325 hp3_2_check1325 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1325,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1326 T childKnown
  · exact hp3_2_node1327 T childKnown
theorem hp3_2_node1324 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1324 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1324 ((10 : Int),(1 : Int)) hp3_2_branches1324 hp3_2_evidence1324 hp3_2_check1324 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1324,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1323 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1323 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1323 ((10 : Int),(0 : Int)) hp3_2_branches1323 hp3_2_evidence1323 hp3_2_check1323 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1323,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1324 T childKnown
theorem hp3_2_node1322 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1322 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1322 ((10 : Int),(0 : Int)) hp3_2_branches1322 hp3_2_evidence1322 hp3_2_check1322 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1321 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1321 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1321 ((10 : Int),(1 : Int)) hp3_2_branches1321 hp3_2_evidence1321 hp3_2_check1321 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1321,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1322 T childKnown
theorem hp3_2_node1320 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1320 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1320 ((9 : Int),(1 : Int)) hp3_2_branches1320 hp3_2_evidence1320 hp3_2_check1320 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1320,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1321 T childKnown
  · exact hp3_2_node1323 T childKnown
  · exact hp3_2_node1325 T childKnown
  · exact hp3_2_node1328 T childKnown
  · exact hp3_2_node1329 T childKnown
  · exact hp3_2_node1330 T childKnown
theorem hp3_2_node1319 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1319 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1319 ((10 : Int),(0 : Int)) hp3_2_branches1319 hp3_2_evidence1319 hp3_2_check1319 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1319,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1318 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1318 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1318 ((10 : Int),(0 : Int)) hp3_2_branches1318 hp3_2_evidence1318 hp3_2_check1318 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1318,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1317 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1317 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1317 ((10 : Int),(0 : Int)) hp3_2_branches1317 hp3_2_evidence1317 hp3_2_check1317 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1317,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1316 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1316 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1316 ((10 : Int),(1 : Int)) hp3_2_branches1316 hp3_2_evidence1316 hp3_2_check1316 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1316,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1315 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1315 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1315 ((10 : Int),(1 : Int)) hp3_2_branches1315 hp3_2_evidence1315 hp3_2_check1315 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1315,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1314 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1314 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1314 ((10 : Int),(0 : Int)) hp3_2_branches1314 hp3_2_evidence1314 hp3_2_check1314 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1314,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1315 T childKnown
  · exact hp3_2_node1316 T childKnown
theorem hp3_2_node1313 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1313 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1313 ((10 : Int),(1 : Int)) hp3_2_branches1313 hp3_2_evidence1313 hp3_2_check1313 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1313,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1312 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1312 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1312 ((10 : Int),(0 : Int)) hp3_2_branches1312 hp3_2_evidence1312 hp3_2_check1312 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1312,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1313 T childKnown
theorem hp3_2_node1311 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1311 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1311 ((10 : Int),(0 : Int)) hp3_2_branches1311 hp3_2_evidence1311 hp3_2_check1311 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1311,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1310 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1310 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1310 ((10 : Int),(1 : Int)) hp3_2_branches1310 hp3_2_evidence1310 hp3_2_check1310 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1310,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1311 T childKnown
theorem hp3_2_node1309 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1309 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1309 ((9 : Int),(1 : Int)) hp3_2_branches1309 hp3_2_evidence1309 hp3_2_check1309 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1309,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1310 T childKnown
  · exact hp3_2_node1312 T childKnown
  · exact hp3_2_node1314 T childKnown
  · exact hp3_2_node1317 T childKnown
  · exact hp3_2_node1318 T childKnown
  · exact hp3_2_node1319 T childKnown
theorem hp3_2_node1308 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1308 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1308 ((0 : Int),(2 : Int)) hp3_2_branches1308 hp3_2_evidence1308 hp3_2_check1308 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1308,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1309 T childKnown
theorem hp3_2_node1307 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1307 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1307 ((10 : Int),(0 : Int)) hp3_2_branches1307 hp3_2_evidence1307 hp3_2_check1307 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1307,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1306 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1306 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1306 ((10 : Int),(0 : Int)) hp3_2_branches1306 hp3_2_evidence1306 hp3_2_check1306 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1306,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1305 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1305 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1305 ((10 : Int),(0 : Int)) hp3_2_branches1305 hp3_2_evidence1305 hp3_2_check1305 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1305,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1304 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1304 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1304 ((10 : Int),(1 : Int)) hp3_2_branches1304 hp3_2_evidence1304 hp3_2_check1304 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1304,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1303 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1303 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1303 ((10 : Int),(1 : Int)) hp3_2_branches1303 hp3_2_evidence1303 hp3_2_check1303 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1303,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1302 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1302 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1302 ((10 : Int),(0 : Int)) hp3_2_branches1302 hp3_2_evidence1302 hp3_2_check1302 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1302,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1303 T childKnown
  · exact hp3_2_node1304 T childKnown
theorem hp3_2_node1301 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1301 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1301 ((10 : Int),(1 : Int)) hp3_2_branches1301 hp3_2_evidence1301 hp3_2_check1301 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1301,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1300 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1300 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1300 ((10 : Int),(0 : Int)) hp3_2_branches1300 hp3_2_evidence1300 hp3_2_check1300 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1300,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1301 T childKnown
theorem hp3_2_node1299 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1299 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1299 ((10 : Int),(0 : Int)) hp3_2_branches1299 hp3_2_evidence1299 hp3_2_check1299 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1299,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1298 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1298 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1298 ((10 : Int),(1 : Int)) hp3_2_branches1298 hp3_2_evidence1298 hp3_2_check1298 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1298,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1299 T childKnown
theorem hp3_2_node1297 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1297 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1297 ((9 : Int),(1 : Int)) hp3_2_branches1297 hp3_2_evidence1297 hp3_2_check1297 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1297,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1298 T childKnown
  · exact hp3_2_node1300 T childKnown
  · exact hp3_2_node1302 T childKnown
  · exact hp3_2_node1305 T childKnown
  · exact hp3_2_node1306 T childKnown
  · exact hp3_2_node1307 T childKnown
theorem hp3_2_node1296 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1296 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1296 ((0 : Int),(2 : Int)) hp3_2_branches1296 hp3_2_evidence1296 hp3_2_check1296 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1296,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1297 T childKnown
theorem hp3_2_node1295 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1295 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1295 ((0 : Int),(1 : Int)) hp3_2_branches1295 hp3_2_evidence1295 hp3_2_check1295 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1295,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1296 T childKnown
  · exact hp3_2_node1308 T childKnown
  · exact hp3_2_node1320 T childKnown
  · exact hp3_2_node1331 T childKnown
theorem hp3_2_node1294 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1294 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1294 ((5 : Int),(2 : Int)) hp3_2_branches1294 hp3_2_evidence1294 hp3_2_check1294 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1295 T childKnown
theorem hp3_2_node1293 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1293 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1293 ((0 : Int),(2 : Int)) hp3_2_branches1293 hp3_2_evidence1293 hp3_2_check1293 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1293,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1292 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1292 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1292 ((10 : Int),(0 : Int)) hp3_2_branches1292 hp3_2_evidence1292 hp3_2_check1292 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1292,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1291 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1291 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1291 ((10 : Int),(0 : Int)) hp3_2_branches1291 hp3_2_evidence1291 hp3_2_check1291 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1291,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1290 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1290 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1290 ((10 : Int),(0 : Int)) hp3_2_branches1290 hp3_2_evidence1290 hp3_2_check1290 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1290,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1289 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1289 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1289 ((10 : Int),(1 : Int)) hp3_2_branches1289 hp3_2_evidence1289 hp3_2_check1289 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1289,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1288 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1288 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1288 ((10 : Int),(1 : Int)) hp3_2_branches1288 hp3_2_evidence1288 hp3_2_check1288 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1288,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1287 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1287 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1287 ((10 : Int),(0 : Int)) hp3_2_branches1287 hp3_2_evidence1287 hp3_2_check1287 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1287,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1288 T childKnown
  · exact hp3_2_node1289 T childKnown
theorem hp3_2_node1286 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1286 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1286 ((10 : Int),(1 : Int)) hp3_2_branches1286 hp3_2_evidence1286 hp3_2_check1286 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1285 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1285 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1285 ((10 : Int),(0 : Int)) hp3_2_branches1285 hp3_2_evidence1285 hp3_2_check1285 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1285,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1286 T childKnown
theorem hp3_2_node1284 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1284 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1284 ((10 : Int),(0 : Int)) hp3_2_branches1284 hp3_2_evidence1284 hp3_2_check1284 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1284,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1283 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1283 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1283 ((10 : Int),(1 : Int)) hp3_2_branches1283 hp3_2_evidence1283 hp3_2_check1283 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1283,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1284 T childKnown
theorem hp3_2_node1282 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1282 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1282 ((9 : Int),(1 : Int)) hp3_2_branches1282 hp3_2_evidence1282 hp3_2_check1282 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1282,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1283 T childKnown
  · exact hp3_2_node1285 T childKnown
  · exact hp3_2_node1287 T childKnown
  · exact hp3_2_node1290 T childKnown
  · exact hp3_2_node1291 T childKnown
  · exact hp3_2_node1292 T childKnown
theorem hp3_2_node1281 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1281 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1281 ((10 : Int),(0 : Int)) hp3_2_branches1281 hp3_2_evidence1281 hp3_2_check1281 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1281,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1280 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1280 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1280 ((10 : Int),(0 : Int)) hp3_2_branches1280 hp3_2_evidence1280 hp3_2_check1280 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1280,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1279 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1279 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1279 ((10 : Int),(0 : Int)) hp3_2_branches1279 hp3_2_evidence1279 hp3_2_check1279 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1279,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1278 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1278 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1278 ((10 : Int),(1 : Int)) hp3_2_branches1278 hp3_2_evidence1278 hp3_2_check1278 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1278,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1277 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1277 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1277 ((10 : Int),(1 : Int)) hp3_2_branches1277 hp3_2_evidence1277 hp3_2_check1277 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1277,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1276 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1276 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1276 ((10 : Int),(0 : Int)) hp3_2_branches1276 hp3_2_evidence1276 hp3_2_check1276 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1276,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1277 T childKnown
  · exact hp3_2_node1278 T childKnown
theorem hp3_2_node1275 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1275 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1275 ((10 : Int),(1 : Int)) hp3_2_branches1275 hp3_2_evidence1275 hp3_2_check1275 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1274 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1274 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1274 ((10 : Int),(0 : Int)) hp3_2_branches1274 hp3_2_evidence1274 hp3_2_check1274 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1274,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1275 T childKnown
theorem hp3_2_node1273 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1273 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1273 ((10 : Int),(0 : Int)) hp3_2_branches1273 hp3_2_evidence1273 hp3_2_check1273 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1273,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1272 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1272 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1272 ((10 : Int),(1 : Int)) hp3_2_branches1272 hp3_2_evidence1272 hp3_2_check1272 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1272,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1273 T childKnown
theorem hp3_2_node1271 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1271 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1271 ((9 : Int),(1 : Int)) hp3_2_branches1271 hp3_2_evidence1271 hp3_2_check1271 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1272 T childKnown
  · exact hp3_2_node1274 T childKnown
  · exact hp3_2_node1276 T childKnown
  · exact hp3_2_node1279 T childKnown
  · exact hp3_2_node1280 T childKnown
  · exact hp3_2_node1281 T childKnown
theorem hp3_2_node1270 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1270 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1270 ((0 : Int),(2 : Int)) hp3_2_branches1270 hp3_2_evidence1270 hp3_2_check1270 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1270,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1271 T childKnown
theorem hp3_2_node1269 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1269 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1269 ((10 : Int),(0 : Int)) hp3_2_branches1269 hp3_2_evidence1269 hp3_2_check1269 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1269,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1268 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1268 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1268 ((10 : Int),(0 : Int)) hp3_2_branches1268 hp3_2_evidence1268 hp3_2_check1268 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1268,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1267 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1267 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1267 ((10 : Int),(0 : Int)) hp3_2_branches1267 hp3_2_evidence1267 hp3_2_check1267 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1267,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1266 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1266 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1266 ((10 : Int),(1 : Int)) hp3_2_branches1266 hp3_2_evidence1266 hp3_2_check1266 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1265 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1265 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1265 ((10 : Int),(1 : Int)) hp3_2_branches1265 hp3_2_evidence1265 hp3_2_check1265 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1264 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1264 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1264 ((10 : Int),(0 : Int)) hp3_2_branches1264 hp3_2_evidence1264 hp3_2_check1264 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1264,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1265 T childKnown
  · exact hp3_2_node1266 T childKnown
theorem hp3_2_node1263 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1263 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1263 ((10 : Int),(1 : Int)) hp3_2_branches1263 hp3_2_evidence1263 hp3_2_check1263 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1263,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1262 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1262 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1262 ((10 : Int),(0 : Int)) hp3_2_branches1262 hp3_2_evidence1262 hp3_2_check1262 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1262,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1263 T childKnown
theorem hp3_2_node1261 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1261 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1261 ((10 : Int),(0 : Int)) hp3_2_branches1261 hp3_2_evidence1261 hp3_2_check1261 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1261,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1260 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1260 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1260 ((10 : Int),(1 : Int)) hp3_2_branches1260 hp3_2_evidence1260 hp3_2_check1260 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1260,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1261 T childKnown
theorem hp3_2_node1259 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1259 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1259 ((9 : Int),(1 : Int)) hp3_2_branches1259 hp3_2_evidence1259 hp3_2_check1259 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1259,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1260 T childKnown
  · exact hp3_2_node1262 T childKnown
  · exact hp3_2_node1264 T childKnown
  · exact hp3_2_node1267 T childKnown
  · exact hp3_2_node1268 T childKnown
  · exact hp3_2_node1269 T childKnown
theorem hp3_2_node1258 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1258 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1258 ((0 : Int),(2 : Int)) hp3_2_branches1258 hp3_2_evidence1258 hp3_2_check1258 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1258,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1259 T childKnown
theorem hp3_2_node1257 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1257 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1257 ((0 : Int),(1 : Int)) hp3_2_branches1257 hp3_2_evidence1257 hp3_2_check1257 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1257,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1258 T childKnown
  · exact hp3_2_node1270 T childKnown
  · exact hp3_2_node1282 T childKnown
  · exact hp3_2_node1293 T childKnown
theorem hp3_2_node1256 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1256 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1256 ((5 : Int),(2 : Int)) hp3_2_branches1256 hp3_2_evidence1256 hp3_2_check1256 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1256,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1257 T childKnown
theorem hp3_2_node1255 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1255 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1255 ((5 : Int),(2 : Int)) hp3_2_branches1255 hp3_2_evidence1255 hp3_2_check1255 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1255,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1254 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1254 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1254 ((4 : Int),(2 : Int)) hp3_2_branches1254 hp3_2_evidence1254 hp3_2_check1254 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1254,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1255 T childKnown
  · exact hp3_2_node1256 T childKnown
  · exact hp3_2_node1294 T childKnown
theorem hp3_2_node1253 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1253 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1253 ((0 : Int),(2 : Int)) hp3_2_branches1253 hp3_2_evidence1253 hp3_2_check1253 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1253,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1252 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1252 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1252 ((0 : Int),(2 : Int)) hp3_2_branches1252 hp3_2_evidence1252 hp3_2_check1252 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1252,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1251 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1251 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1251 ((0 : Int),(2 : Int)) hp3_2_branches1251 hp3_2_evidence1251 hp3_2_check1251 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1251,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1250 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1250 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1250 ((0 : Int),(1 : Int)) hp3_2_branches1250 hp3_2_evidence1250 hp3_2_check1250 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1251 T childKnown
  · exact hp3_2_node1252 T childKnown
  · exact hp3_2_node1253 T childKnown
theorem hp3_2_node1249 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1249 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1249 ((0 : Int),(2 : Int)) hp3_2_branches1249 hp3_2_evidence1249 hp3_2_check1249 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1249,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1248 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1248 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1248 ((10 : Int),(0 : Int)) hp3_2_branches1248 hp3_2_evidence1248 hp3_2_check1248 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1248,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1247 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1247 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1247 ((10 : Int),(0 : Int)) hp3_2_branches1247 hp3_2_evidence1247 hp3_2_check1247 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1247,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1246 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1246 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1246 ((10 : Int),(0 : Int)) hp3_2_branches1246 hp3_2_evidence1246 hp3_2_check1246 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1246,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1245 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1245 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1245 ((10 : Int),(1 : Int)) hp3_2_branches1245 hp3_2_evidence1245 hp3_2_check1245 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1244 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1244 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1244 ((10 : Int),(1 : Int)) hp3_2_branches1244 hp3_2_evidence1244 hp3_2_check1244 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1243 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1243 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1243 ((10 : Int),(0 : Int)) hp3_2_branches1243 hp3_2_evidence1243 hp3_2_check1243 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1243,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1244 T childKnown
  · exact hp3_2_node1245 T childKnown
theorem hp3_2_node1242 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1242 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1242 ((10 : Int),(1 : Int)) hp3_2_branches1242 hp3_2_evidence1242 hp3_2_check1242 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1241 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1241 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1241 ((10 : Int),(0 : Int)) hp3_2_branches1241 hp3_2_evidence1241 hp3_2_check1241 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1241,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1242 T childKnown
theorem hp3_2_node1240 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1240 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1240 ((10 : Int),(0 : Int)) hp3_2_branches1240 hp3_2_evidence1240 hp3_2_check1240 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1240,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1239 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1239 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1239 ((10 : Int),(1 : Int)) hp3_2_branches1239 hp3_2_evidence1239 hp3_2_check1239 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1239,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1240 T childKnown
theorem hp3_2_node1238 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1238 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1238 ((9 : Int),(1 : Int)) hp3_2_branches1238 hp3_2_evidence1238 hp3_2_check1238 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1238,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1239 T childKnown
  · exact hp3_2_node1241 T childKnown
  · exact hp3_2_node1243 T childKnown
  · exact hp3_2_node1246 T childKnown
  · exact hp3_2_node1247 T childKnown
  · exact hp3_2_node1248 T childKnown
theorem hp3_2_node1237 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1237 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1237 ((0 : Int),(2 : Int)) hp3_2_branches1237 hp3_2_evidence1237 hp3_2_check1237 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1236 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1236 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1236 ((0 : Int),(2 : Int)) hp3_2_branches1236 hp3_2_evidence1236 hp3_2_check1236 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1236,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1235 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1235 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1235 ((0 : Int),(1 : Int)) hp3_2_branches1235 hp3_2_evidence1235 hp3_2_check1235 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1235,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1236 T childKnown
  · exact hp3_2_node1237 T childKnown
  · exact hp3_2_node1238 T childKnown
  · exact hp3_2_node1249 T childKnown
theorem hp3_2_node1234 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1234 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1234 ((5 : Int),(2 : Int)) hp3_2_branches1234 hp3_2_evidence1234 hp3_2_check1234 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1234,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1235 T childKnown
theorem hp3_2_node1233 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1233 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1233 ((0 : Int),(2 : Int)) hp3_2_branches1233 hp3_2_evidence1233 hp3_2_check1233 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1233,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1232 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1232 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1232 ((10 : Int),(0 : Int)) hp3_2_branches1232 hp3_2_evidence1232 hp3_2_check1232 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1232,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1231 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1231 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1231 ((10 : Int),(0 : Int)) hp3_2_branches1231 hp3_2_evidence1231 hp3_2_check1231 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1231,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1230 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1230 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1230 ((10 : Int),(0 : Int)) hp3_2_branches1230 hp3_2_evidence1230 hp3_2_check1230 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1230,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1229 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1229 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1229 ((10 : Int),(1 : Int)) hp3_2_branches1229 hp3_2_evidence1229 hp3_2_check1229 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1229,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1228 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1228 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1228 ((10 : Int),(1 : Int)) hp3_2_branches1228 hp3_2_evidence1228 hp3_2_check1228 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1228,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1227 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1227 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1227 ((10 : Int),(0 : Int)) hp3_2_branches1227 hp3_2_evidence1227 hp3_2_check1227 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1227,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1228 T childKnown
  · exact hp3_2_node1229 T childKnown
theorem hp3_2_node1226 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1226 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1226 ((10 : Int),(1 : Int)) hp3_2_branches1226 hp3_2_evidence1226 hp3_2_check1226 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1226,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1225 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1225 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1225 ((10 : Int),(0 : Int)) hp3_2_branches1225 hp3_2_evidence1225 hp3_2_check1225 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1225,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1226 T childKnown
theorem hp3_2_node1224 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1224 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1224 ((10 : Int),(0 : Int)) hp3_2_branches1224 hp3_2_evidence1224 hp3_2_check1224 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1224,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1223 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1223 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1223 ((10 : Int),(1 : Int)) hp3_2_branches1223 hp3_2_evidence1223 hp3_2_check1223 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1223,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1224 T childKnown
theorem hp3_2_node1222 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1222 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1222 ((9 : Int),(1 : Int)) hp3_2_branches1222 hp3_2_evidence1222 hp3_2_check1222 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1222,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1223 T childKnown
  · exact hp3_2_node1225 T childKnown
  · exact hp3_2_node1227 T childKnown
  · exact hp3_2_node1230 T childKnown
  · exact hp3_2_node1231 T childKnown
  · exact hp3_2_node1232 T childKnown
theorem hp3_2_node1221 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1221 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1221 ((0 : Int),(2 : Int)) hp3_2_branches1221 hp3_2_evidence1221 hp3_2_check1221 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1221,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1220 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1220 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1220 ((0 : Int),(2 : Int)) hp3_2_branches1220 hp3_2_evidence1220 hp3_2_check1220 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1219 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1219 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1219 ((0 : Int),(1 : Int)) hp3_2_branches1219 hp3_2_evidence1219 hp3_2_check1219 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1219,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1220 T childKnown
  · exact hp3_2_node1221 T childKnown
  · exact hp3_2_node1222 T childKnown
  · exact hp3_2_node1233 T childKnown
theorem hp3_2_node1218 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1218 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1218 ((5 : Int),(2 : Int)) hp3_2_branches1218 hp3_2_evidence1218 hp3_2_check1218 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1218,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1219 T childKnown
theorem hp3_2_node1217 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1217 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1217 ((0 : Int),(2 : Int)) hp3_2_branches1217 hp3_2_evidence1217 hp3_2_check1217 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1217,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1216 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1216 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1216 ((10 : Int),(0 : Int)) hp3_2_branches1216 hp3_2_evidence1216 hp3_2_check1216 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1216,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1215 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1215 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1215 ((10 : Int),(0 : Int)) hp3_2_branches1215 hp3_2_evidence1215 hp3_2_check1215 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1215,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1214 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1214 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1214 ((10 : Int),(0 : Int)) hp3_2_branches1214 hp3_2_evidence1214 hp3_2_check1214 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1214,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1213 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1213 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1213 ((10 : Int),(1 : Int)) hp3_2_branches1213 hp3_2_evidence1213 hp3_2_check1213 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1213,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1212 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1212 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1212 ((10 : Int),(1 : Int)) hp3_2_branches1212 hp3_2_evidence1212 hp3_2_check1212 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1212,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1211 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1211 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1211 ((10 : Int),(0 : Int)) hp3_2_branches1211 hp3_2_evidence1211 hp3_2_check1211 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1211,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1212 T childKnown
  · exact hp3_2_node1213 T childKnown
theorem hp3_2_node1210 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1210 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1210 ((10 : Int),(1 : Int)) hp3_2_branches1210 hp3_2_evidence1210 hp3_2_check1210 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1210,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1209 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1209 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1209 ((10 : Int),(0 : Int)) hp3_2_branches1209 hp3_2_evidence1209 hp3_2_check1209 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1209,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1210 T childKnown
theorem hp3_2_node1208 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1208 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1208 ((10 : Int),(0 : Int)) hp3_2_branches1208 hp3_2_evidence1208 hp3_2_check1208 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1208,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1207 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1207 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1207 ((10 : Int),(1 : Int)) hp3_2_branches1207 hp3_2_evidence1207 hp3_2_check1207 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1207,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1208 T childKnown
theorem hp3_2_node1206 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1206 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1206 ((9 : Int),(1 : Int)) hp3_2_branches1206 hp3_2_evidence1206 hp3_2_check1206 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1206,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1207 T childKnown
  · exact hp3_2_node1209 T childKnown
  · exact hp3_2_node1211 T childKnown
  · exact hp3_2_node1214 T childKnown
  · exact hp3_2_node1215 T childKnown
  · exact hp3_2_node1216 T childKnown
theorem hp3_2_node1205 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1205 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1205 ((0 : Int),(2 : Int)) hp3_2_branches1205 hp3_2_evidence1205 hp3_2_check1205 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1205,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1204 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1204 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1204 ((0 : Int),(2 : Int)) hp3_2_branches1204 hp3_2_evidence1204 hp3_2_check1204 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1204,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1203 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1203 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1203 ((0 : Int),(1 : Int)) hp3_2_branches1203 hp3_2_evidence1203 hp3_2_check1203 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1203,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1204 T childKnown
  · exact hp3_2_node1205 T childKnown
  · exact hp3_2_node1206 T childKnown
  · exact hp3_2_node1217 T childKnown
theorem hp3_2_node1202 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1202 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1202 ((6 : Int),(2 : Int)) hp3_2_branches1202 hp3_2_evidence1202 hp3_2_check1202 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1202,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1201 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1201 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1201 ((6 : Int),(2 : Int)) hp3_2_branches1201 hp3_2_evidence1201 hp3_2_check1201 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1201,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1200 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1200 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1200 ((5 : Int),(2 : Int)) hp3_2_branches1200 hp3_2_evidence1200 hp3_2_check1200 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1200,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1201 T childKnown
  · exact hp3_2_node1202 T childKnown
  · exact hp3_2_node1203 T childKnown
theorem hp3_2_node1199 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1199 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1199 ((4 : Int),(2 : Int)) hp3_2_branches1199 hp3_2_evidence1199 hp3_2_check1199 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1199,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1200 T childKnown
  · exact hp3_2_node1218 T childKnown
  · exact hp3_2_node1234 T childKnown
theorem hp3_2_node1198 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1198 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1198 ((2 : Int),(2 : Int)) hp3_2_branches1198 hp3_2_evidence1198 hp3_2_check1198 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1198,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1199 T childKnown
  · exact hp3_2_node1250 T childKnown
  · exact hp3_2_node1254 T childKnown
  · exact hp3_2_node1332 T childKnown
  · exact hp3_2_node1333 T childKnown
theorem hp3_2_node1197 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1197 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1197 ((5 : Int),(0 : Int)) hp3_2_branches1197 hp3_2_evidence1197 hp3_2_check1197 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1197,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1198 T childKnown
theorem hp3_2_node1196 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1196 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1196 ((3 : Int),(2 : Int)) hp3_2_branches1196 hp3_2_evidence1196 hp3_2_check1196 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1196,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1195 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1195 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1195 ((3 : Int),(2 : Int)) hp3_2_branches1195 hp3_2_evidence1195 hp3_2_check1195 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1195,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1194 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1194 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1194 ((3 : Int),(2 : Int)) hp3_2_branches1194 hp3_2_evidence1194 hp3_2_check1194 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1193 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1193 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1193 ((3 : Int),(1 : Int)) hp3_2_branches1193 hp3_2_evidence1193 hp3_2_check1193 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1193,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1194 T childKnown
  · exact hp3_2_node1195 T childKnown
  · exact hp3_2_node1196 T childKnown
theorem hp3_2_node1192 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1192 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1192 ((10 : Int),(1 : Int)) hp3_2_branches1192 hp3_2_evidence1192 hp3_2_check1192 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1191 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1191 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1191 ((9 : Int),(1 : Int)) hp3_2_branches1191 hp3_2_evidence1191 hp3_2_check1191 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1191,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1192 T childKnown
theorem hp3_2_node1190 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1190 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1190 ((10 : Int),(1 : Int)) hp3_2_branches1190 hp3_2_evidence1190 hp3_2_check1190 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1190,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1189 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1189 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1189 ((9 : Int),(1 : Int)) hp3_2_branches1189 hp3_2_evidence1189 hp3_2_check1189 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1189,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1190 T childKnown
theorem hp3_2_node1188 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1188 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1188 ((9 : Int),(1 : Int)) hp3_2_branches1188 hp3_2_evidence1188 hp3_2_check1188 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1188,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1187 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1187 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1187 ((10 : Int),(0 : Int)) hp3_2_branches1187 hp3_2_evidence1187 hp3_2_check1187 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1187,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1188 T childKnown
  · exact hp3_2_node1189 T childKnown
  · exact hp3_2_node1191 T childKnown
theorem hp3_2_node1186 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1186 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1186 ((7 : Int),(2 : Int)) hp3_2_branches1186 hp3_2_evidence1186 hp3_2_check1186 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1186,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1187 T childKnown
theorem hp3_2_node1185 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1185 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1185 ((7 : Int),(2 : Int)) hp3_2_branches1185 hp3_2_evidence1185 hp3_2_check1185 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1185,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1184 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1184 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1184 ((10 : Int),(0 : Int)) hp3_2_branches1184 hp3_2_evidence1184 hp3_2_check1184 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1184,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1183 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1183 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1183 ((9 : Int),(2 : Int)) hp3_2_branches1183 hp3_2_evidence1183 hp3_2_check1183 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1183,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1182 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1182 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1182 ((10 : Int),(0 : Int)) hp3_2_branches1182 hp3_2_evidence1182 hp3_2_check1182 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1182,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1181 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1181 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1181 ((10 : Int),(0 : Int)) hp3_2_branches1181 hp3_2_evidence1181 hp3_2_check1181 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1181,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1180 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1180 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1180 ((10 : Int),(1 : Int)) hp3_2_branches1180 hp3_2_evidence1180 hp3_2_check1180 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1180,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1181 T childKnown
theorem hp3_2_node1179 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1179 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1179 ((9 : Int),(1 : Int)) hp3_2_branches1179 hp3_2_evidence1179 hp3_2_check1179 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1179,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1180 T childKnown
  · exact hp3_2_node1182 T childKnown
  · exact hp3_2_node1183 T childKnown
  · exact hp3_2_node1184 T childKnown
theorem hp3_2_node1178 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1178 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1178 ((9 : Int),(2 : Int)) hp3_2_branches1178 hp3_2_evidence1178 hp3_2_check1178 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1178,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1177 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1177 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1177 ((9 : Int),(2 : Int)) hp3_2_branches1177 hp3_2_evidence1177 hp3_2_check1177 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1177,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1176 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1176 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1176 ((9 : Int),(2 : Int)) hp3_2_branches1176 hp3_2_evidence1176 hp3_2_check1176 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1176,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1175 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1175 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1175 ((9 : Int),(1 : Int)) hp3_2_branches1175 hp3_2_evidence1175 hp3_2_check1175 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1175,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1176 T childKnown
  · exact hp3_2_node1177 T childKnown
  · exact hp3_2_node1178 T childKnown
theorem hp3_2_node1174 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1174 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1174 ((10 : Int),(1 : Int)) hp3_2_branches1174 hp3_2_evidence1174 hp3_2_check1174 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1174,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1173 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1173 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1173 ((9 : Int),(1 : Int)) hp3_2_branches1173 hp3_2_evidence1173 hp3_2_check1173 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1173,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1174 T childKnown
theorem hp3_2_node1172 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1172 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1172 ((10 : Int),(1 : Int)) hp3_2_branches1172 hp3_2_evidence1172 hp3_2_check1172 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1172,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1171 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1171 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1171 ((9 : Int),(1 : Int)) hp3_2_branches1171 hp3_2_evidence1171 hp3_2_check1171 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1171,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1172 T childKnown
theorem hp3_2_node1170 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1170 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1170 ((9 : Int),(1 : Int)) hp3_2_branches1170 hp3_2_evidence1170 hp3_2_check1170 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1169 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1169 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1169 ((10 : Int),(0 : Int)) hp3_2_branches1169 hp3_2_evidence1169 hp3_2_check1169 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1169,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1170 T childKnown
  · exact hp3_2_node1171 T childKnown
  · exact hp3_2_node1173 T childKnown
theorem hp3_2_node1168 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1168 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1168 ((7 : Int),(2 : Int)) hp3_2_branches1168 hp3_2_evidence1168 hp3_2_check1168 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1168,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1169 T childKnown
  · exact hp3_2_node1175 T childKnown
  · exact hp3_2_node1179 T childKnown
theorem hp3_2_node1167 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1167 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1167 ((10 : Int),(0 : Int)) hp3_2_branches1167 hp3_2_evidence1167 hp3_2_check1167 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1167,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1166 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1166 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1166 ((9 : Int),(2 : Int)) hp3_2_branches1166 hp3_2_evidence1166 hp3_2_check1166 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1166,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1165 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1165 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1165 ((10 : Int),(0 : Int)) hp3_2_branches1165 hp3_2_evidence1165 hp3_2_check1165 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1165,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1164 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1164 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1164 ((10 : Int),(0 : Int)) hp3_2_branches1164 hp3_2_evidence1164 hp3_2_check1164 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1164,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1163 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1163 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1163 ((10 : Int),(1 : Int)) hp3_2_branches1163 hp3_2_evidence1163 hp3_2_check1163 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1163,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1164 T childKnown
theorem hp3_2_node1162 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1162 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1162 ((9 : Int),(1 : Int)) hp3_2_branches1162 hp3_2_evidence1162 hp3_2_check1162 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1162,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1163 T childKnown
  · exact hp3_2_node1165 T childKnown
  · exact hp3_2_node1166 T childKnown
  · exact hp3_2_node1167 T childKnown
theorem hp3_2_node1161 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1161 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1161 ((9 : Int),(2 : Int)) hp3_2_branches1161 hp3_2_evidence1161 hp3_2_check1161 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1161,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1160 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1160 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1160 ((9 : Int),(2 : Int)) hp3_2_branches1160 hp3_2_evidence1160 hp3_2_check1160 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1160,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1159 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1159 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1159 ((9 : Int),(2 : Int)) hp3_2_branches1159 hp3_2_evidence1159 hp3_2_check1159 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1159,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1158 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1158 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1158 ((9 : Int),(1 : Int)) hp3_2_branches1158 hp3_2_evidence1158 hp3_2_check1158 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1158,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1159 T childKnown
  · exact hp3_2_node1160 T childKnown
  · exact hp3_2_node1161 T childKnown
theorem hp3_2_node1157 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1157 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1157 ((10 : Int),(1 : Int)) hp3_2_branches1157 hp3_2_evidence1157 hp3_2_check1157 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1157,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1156 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1156 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1156 ((9 : Int),(1 : Int)) hp3_2_branches1156 hp3_2_evidence1156 hp3_2_check1156 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1156,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1157 T childKnown
theorem hp3_2_node1155 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1155 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1155 ((10 : Int),(1 : Int)) hp3_2_branches1155 hp3_2_evidence1155 hp3_2_check1155 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1154 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1154 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1154 ((9 : Int),(1 : Int)) hp3_2_branches1154 hp3_2_evidence1154 hp3_2_check1154 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1154,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1155 T childKnown
theorem hp3_2_node1153 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1153 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1153 ((9 : Int),(1 : Int)) hp3_2_branches1153 hp3_2_evidence1153 hp3_2_check1153 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1153,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1152 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1152 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1152 ((10 : Int),(0 : Int)) hp3_2_branches1152 hp3_2_evidence1152 hp3_2_check1152 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1152,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1153 T childKnown
  · exact hp3_2_node1154 T childKnown
  · exact hp3_2_node1156 T childKnown
theorem hp3_2_node1151 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1151 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1151 ((7 : Int),(2 : Int)) hp3_2_branches1151 hp3_2_evidence1151 hp3_2_check1151 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1151,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1152 T childKnown
  · exact hp3_2_node1158 T childKnown
  · exact hp3_2_node1162 T childKnown
theorem hp3_2_node1150 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1150 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1150 ((5 : Int),(2 : Int)) hp3_2_branches1150 hp3_2_evidence1150 hp3_2_check1150 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1150,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1151 T childKnown
  · exact hp3_2_node1168 T childKnown
  · exact hp3_2_node1185 T childKnown
  · exact hp3_2_node1186 T childKnown
theorem hp3_2_node1149 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1149 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1149 ((5 : Int),(0 : Int)) hp3_2_branches1149 hp3_2_evidence1149 hp3_2_check1149 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1149,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1150 T childKnown
theorem hp3_2_node1148 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1148 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1148 ((7 : Int),(1 : Int)) hp3_2_branches1148 hp3_2_evidence1148 hp3_2_check1148 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1148,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1147 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1147 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1147 ((7 : Int),(1 : Int)) hp3_2_branches1147 hp3_2_evidence1147 hp3_2_check1147 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1147,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1146 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1146 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1146 ((6 : Int),(1 : Int)) hp3_2_branches1146 hp3_2_evidence1146 hp3_2_check1146 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1146,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1147 T childKnown
  · exact hp3_2_node1148 T childKnown
theorem hp3_2_node1145 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1145 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1145 ((8 : Int),(2 : Int)) hp3_2_branches1145 hp3_2_evidence1145 hp3_2_check1145 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1145,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1144 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1144 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1144 ((8 : Int),(2 : Int)) hp3_2_branches1144 hp3_2_evidence1144 hp3_2_check1144 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1144,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1143 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1143 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1143 ((9 : Int),(2 : Int)) hp3_2_branches1143 hp3_2_evidence1143 hp3_2_check1143 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1142 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1142 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1142 ((9 : Int),(1 : Int)) hp3_2_branches1142 hp3_2_evidence1142 hp3_2_check1142 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1142,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1143 T childKnown
theorem hp3_2_node1141 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1141 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1141 ((8 : Int),(1 : Int)) hp3_2_branches1141 hp3_2_evidence1141 hp3_2_check1141 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1141,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1142 T childKnown
  · exact hp3_2_node1144 T childKnown
  · exact hp3_2_node1145 T childKnown
theorem hp3_2_node1140 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1140 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1140 ((6 : Int),(1 : Int)) hp3_2_branches1140 hp3_2_evidence1140 hp3_2_check1140 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1140,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1141 T childKnown
theorem hp3_2_node1139 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1139 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1139 ((7 : Int),(1 : Int)) hp3_2_branches1139 hp3_2_evidence1139 hp3_2_check1139 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1139,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1138 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1138 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1138 ((7 : Int),(1 : Int)) hp3_2_branches1138 hp3_2_evidence1138 hp3_2_check1138 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1138,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1137 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1137 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1137 ((7 : Int),(0 : Int)) hp3_2_branches1137 hp3_2_evidence1137 hp3_2_check1137 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1137,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1138 T childKnown
  · exact hp3_2_node1139 T childKnown
theorem hp3_2_node1136 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1136 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1136 ((12 : Int),(0 : Int)) hp3_2_branches1136 hp3_2_evidence1136 hp3_2_check1136 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1136,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1135 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1135 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1135 ((12 : Int),(0 : Int)) hp3_2_branches1135 hp3_2_evidence1135 hp3_2_check1135 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1135,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1134 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1134 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1134 ((12 : Int),(0 : Int)) hp3_2_branches1134 hp3_2_evidence1134 hp3_2_check1134 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1133 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1133 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1133 ((12 : Int),(1 : Int)) hp3_2_branches1133 hp3_2_evidence1133 hp3_2_check1133 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1133,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1132 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1132 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1132 ((12 : Int),(1 : Int)) hp3_2_branches1132 hp3_2_evidence1132 hp3_2_check1132 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1132,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1131 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1131 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1131 ((12 : Int),(0 : Int)) hp3_2_branches1131 hp3_2_evidence1131 hp3_2_check1131 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1131,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1132 T childKnown
  · exact hp3_2_node1133 T childKnown
theorem hp3_2_node1130 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1130 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1130 ((12 : Int),(1 : Int)) hp3_2_branches1130 hp3_2_evidence1130 hp3_2_check1130 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1130,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1129 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1129 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1129 ((12 : Int),(0 : Int)) hp3_2_branches1129 hp3_2_evidence1129 hp3_2_check1129 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1129,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1130 T childKnown
theorem hp3_2_node1128 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1128 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1128 ((12 : Int),(0 : Int)) hp3_2_branches1128 hp3_2_evidence1128 hp3_2_check1128 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1128,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1127 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1127 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1127 ((12 : Int),(1 : Int)) hp3_2_branches1127 hp3_2_evidence1127 hp3_2_check1127 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1127,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1128 T childKnown
theorem hp3_2_node1126 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1126 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1126 ((11 : Int),(1 : Int)) hp3_2_branches1126 hp3_2_evidence1126 hp3_2_check1126 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1126,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1127 T childKnown
  · exact hp3_2_node1129 T childKnown
  · exact hp3_2_node1131 T childKnown
  · exact hp3_2_node1134 T childKnown
  · exact hp3_2_node1135 T childKnown
  · exact hp3_2_node1136 T childKnown
theorem hp3_2_node1125 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1125 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1125 ((12 : Int),(0 : Int)) hp3_2_branches1125 hp3_2_evidence1125 hp3_2_check1125 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1125,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1124 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1124 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1124 ((12 : Int),(0 : Int)) hp3_2_branches1124 hp3_2_evidence1124 hp3_2_check1124 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1124,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1123 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1123 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1123 ((12 : Int),(0 : Int)) hp3_2_branches1123 hp3_2_evidence1123 hp3_2_check1123 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1123,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1122 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1122 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1122 ((12 : Int),(1 : Int)) hp3_2_branches1122 hp3_2_evidence1122 hp3_2_check1122 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1122,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1121 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1121 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1121 ((12 : Int),(1 : Int)) hp3_2_branches1121 hp3_2_evidence1121 hp3_2_check1121 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1120 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1120 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1120 ((12 : Int),(0 : Int)) hp3_2_branches1120 hp3_2_evidence1120 hp3_2_check1120 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1121 T childKnown
  · exact hp3_2_node1122 T childKnown
theorem hp3_2_node1119 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1119 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1119 ((12 : Int),(1 : Int)) hp3_2_branches1119 hp3_2_evidence1119 hp3_2_check1119 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1118 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1118 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1118 ((12 : Int),(0 : Int)) hp3_2_branches1118 hp3_2_evidence1118 hp3_2_check1118 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1118,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1119 T childKnown
theorem hp3_2_node1117 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1117 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1117 ((12 : Int),(0 : Int)) hp3_2_branches1117 hp3_2_evidence1117 hp3_2_check1117 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1116 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1116 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1116 ((12 : Int),(1 : Int)) hp3_2_branches1116 hp3_2_evidence1116 hp3_2_check1116 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1116,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1117 T childKnown
theorem hp3_2_node1115 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1115 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1115 ((11 : Int),(1 : Int)) hp3_2_branches1115 hp3_2_evidence1115 hp3_2_check1115 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1115,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1116 T childKnown
  · exact hp3_2_node1118 T childKnown
  · exact hp3_2_node1120 T childKnown
  · exact hp3_2_node1123 T childKnown
  · exact hp3_2_node1124 T childKnown
  · exact hp3_2_node1125 T childKnown
theorem hp3_2_node1114 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1114 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1114 ((12 : Int),(0 : Int)) hp3_2_branches1114 hp3_2_evidence1114 hp3_2_check1114 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1113 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1113 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1113 ((12 : Int),(0 : Int)) hp3_2_branches1113 hp3_2_evidence1113 hp3_2_check1113 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1113,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1112 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1112 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1112 ((12 : Int),(0 : Int)) hp3_2_branches1112 hp3_2_evidence1112 hp3_2_check1112 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1112,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1111 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1111 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1111 ((12 : Int),(1 : Int)) hp3_2_branches1111 hp3_2_evidence1111 hp3_2_check1111 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1111,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1110 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1110 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1110 ((12 : Int),(1 : Int)) hp3_2_branches1110 hp3_2_evidence1110 hp3_2_check1110 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1110,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1109 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1109 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1109 ((12 : Int),(0 : Int)) hp3_2_branches1109 hp3_2_evidence1109 hp3_2_check1109 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1109,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1110 T childKnown
  · exact hp3_2_node1111 T childKnown
theorem hp3_2_node1108 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1108 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1108 ((12 : Int),(1 : Int)) hp3_2_branches1108 hp3_2_evidence1108 hp3_2_check1108 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1108,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1107 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1107 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1107 ((12 : Int),(0 : Int)) hp3_2_branches1107 hp3_2_evidence1107 hp3_2_check1107 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1107,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1108 T childKnown
theorem hp3_2_node1106 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1106 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1106 ((12 : Int),(0 : Int)) hp3_2_branches1106 hp3_2_evidence1106 hp3_2_check1106 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1106,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1105 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1105 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1105 ((12 : Int),(1 : Int)) hp3_2_branches1105 hp3_2_evidence1105 hp3_2_check1105 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1105,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1106 T childKnown
theorem hp3_2_node1104 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1104 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1104 ((11 : Int),(1 : Int)) hp3_2_branches1104 hp3_2_evidence1104 hp3_2_check1104 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1104,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1105 T childKnown
  · exact hp3_2_node1107 T childKnown
  · exact hp3_2_node1109 T childKnown
  · exact hp3_2_node1112 T childKnown
  · exact hp3_2_node1113 T childKnown
  · exact hp3_2_node1114 T childKnown
theorem hp3_2_node1103 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1103 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1103 ((0 : Int),(2 : Int)) hp3_2_branches1103 hp3_2_evidence1103 hp3_2_check1103 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1103,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1104 T childKnown
theorem hp3_2_node1102 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1102 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1102 ((12 : Int),(0 : Int)) hp3_2_branches1102 hp3_2_evidence1102 hp3_2_check1102 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1101 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1101 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1101 ((12 : Int),(0 : Int)) hp3_2_branches1101 hp3_2_evidence1101 hp3_2_check1101 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1100 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1100 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1100 ((12 : Int),(0 : Int)) hp3_2_branches1100 hp3_2_evidence1100 hp3_2_check1100 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1100,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1099 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1099 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1099 ((12 : Int),(1 : Int)) hp3_2_branches1099 hp3_2_evidence1099 hp3_2_check1099 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1099,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1098 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1098 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1098 ((12 : Int),(1 : Int)) hp3_2_branches1098 hp3_2_evidence1098 hp3_2_check1098 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1098,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1097 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1097 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1097 ((12 : Int),(0 : Int)) hp3_2_branches1097 hp3_2_evidence1097 hp3_2_check1097 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1097,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1098 T childKnown
  · exact hp3_2_node1099 T childKnown
theorem hp3_2_node1096 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1096 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1096 ((12 : Int),(1 : Int)) hp3_2_branches1096 hp3_2_evidence1096 hp3_2_check1096 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1096,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1095 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1095 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1095 ((12 : Int),(0 : Int)) hp3_2_branches1095 hp3_2_evidence1095 hp3_2_check1095 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1095,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1096 T childKnown
theorem hp3_2_node1094 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1094 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1094 ((12 : Int),(0 : Int)) hp3_2_branches1094 hp3_2_evidence1094 hp3_2_check1094 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1094,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1093 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1093 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1093 ((12 : Int),(1 : Int)) hp3_2_branches1093 hp3_2_evidence1093 hp3_2_check1093 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1093,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1094 T childKnown
theorem hp3_2_node1092 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1092 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1092 ((11 : Int),(1 : Int)) hp3_2_branches1092 hp3_2_evidence1092 hp3_2_check1092 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1092,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1093 T childKnown
  · exact hp3_2_node1095 T childKnown
  · exact hp3_2_node1097 T childKnown
  · exact hp3_2_node1100 T childKnown
  · exact hp3_2_node1101 T childKnown
  · exact hp3_2_node1102 T childKnown
theorem hp3_2_node1091 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1091 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1091 ((12 : Int),(0 : Int)) hp3_2_branches1091 hp3_2_evidence1091 hp3_2_check1091 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1091,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1090 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1090 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1090 ((12 : Int),(0 : Int)) hp3_2_branches1090 hp3_2_evidence1090 hp3_2_check1090 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1090,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1089 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1089 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1089 ((12 : Int),(0 : Int)) hp3_2_branches1089 hp3_2_evidence1089 hp3_2_check1089 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1089,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1088 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1088 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1088 ((12 : Int),(1 : Int)) hp3_2_branches1088 hp3_2_evidence1088 hp3_2_check1088 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1088,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1087 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1087 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1087 ((12 : Int),(1 : Int)) hp3_2_branches1087 hp3_2_evidence1087 hp3_2_check1087 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1087,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1086 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1086 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1086 ((12 : Int),(0 : Int)) hp3_2_branches1086 hp3_2_evidence1086 hp3_2_check1086 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1086,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1087 T childKnown
  · exact hp3_2_node1088 T childKnown
theorem hp3_2_node1085 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1085 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1085 ((12 : Int),(1 : Int)) hp3_2_branches1085 hp3_2_evidence1085 hp3_2_check1085 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1085,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1084 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1084 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1084 ((12 : Int),(0 : Int)) hp3_2_branches1084 hp3_2_evidence1084 hp3_2_check1084 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1084,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1085 T childKnown
theorem hp3_2_node1083 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1083 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1083 ((12 : Int),(0 : Int)) hp3_2_branches1083 hp3_2_evidence1083 hp3_2_check1083 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1083,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1082 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1082 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1082 ((12 : Int),(1 : Int)) hp3_2_branches1082 hp3_2_evidence1082 hp3_2_check1082 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1082,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1083 T childKnown
theorem hp3_2_node1081 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1081 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1081 ((11 : Int),(1 : Int)) hp3_2_branches1081 hp3_2_evidence1081 hp3_2_check1081 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1081,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1082 T childKnown
  · exact hp3_2_node1084 T childKnown
  · exact hp3_2_node1086 T childKnown
  · exact hp3_2_node1089 T childKnown
  · exact hp3_2_node1090 T childKnown
  · exact hp3_2_node1091 T childKnown
theorem hp3_2_node1080 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1080 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1080 ((12 : Int),(0 : Int)) hp3_2_branches1080 hp3_2_evidence1080 hp3_2_check1080 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1080,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1079 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1079 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1079 ((12 : Int),(0 : Int)) hp3_2_branches1079 hp3_2_evidence1079 hp3_2_check1079 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1079,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1078 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1078 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1078 ((12 : Int),(0 : Int)) hp3_2_branches1078 hp3_2_evidence1078 hp3_2_check1078 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1078,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1077 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1077 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1077 ((12 : Int),(1 : Int)) hp3_2_branches1077 hp3_2_evidence1077 hp3_2_check1077 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1077,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1076 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1076 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1076 ((12 : Int),(1 : Int)) hp3_2_branches1076 hp3_2_evidence1076 hp3_2_check1076 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1076,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1075 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1075 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1075 ((12 : Int),(0 : Int)) hp3_2_branches1075 hp3_2_evidence1075 hp3_2_check1075 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1075,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1076 T childKnown
  · exact hp3_2_node1077 T childKnown
theorem hp3_2_node1074 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1074 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1074 ((12 : Int),(1 : Int)) hp3_2_branches1074 hp3_2_evidence1074 hp3_2_check1074 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1074,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1073 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1073 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1073 ((12 : Int),(0 : Int)) hp3_2_branches1073 hp3_2_evidence1073 hp3_2_check1073 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1073,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1074 T childKnown
theorem hp3_2_node1072 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1072 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1072 ((12 : Int),(0 : Int)) hp3_2_branches1072 hp3_2_evidence1072 hp3_2_check1072 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1072,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1071 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1071 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1071 ((12 : Int),(1 : Int)) hp3_2_branches1071 hp3_2_evidence1071 hp3_2_check1071 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1071,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1072 T childKnown
theorem hp3_2_node1070 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1070 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1070 ((11 : Int),(1 : Int)) hp3_2_branches1070 hp3_2_evidence1070 hp3_2_check1070 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1070,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1071 T childKnown
  · exact hp3_2_node1073 T childKnown
  · exact hp3_2_node1075 T childKnown
  · exact hp3_2_node1078 T childKnown
  · exact hp3_2_node1079 T childKnown
  · exact hp3_2_node1080 T childKnown
theorem hp3_2_node1069 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1069 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1069 ((0 : Int),(2 : Int)) hp3_2_branches1069 hp3_2_evidence1069 hp3_2_check1069 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1069,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1070 T childKnown
  · exact hp3_2_node1081 T childKnown
theorem hp3_2_node1068 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1068 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1068 ((12 : Int),(0 : Int)) hp3_2_branches1068 hp3_2_evidence1068 hp3_2_check1068 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1068,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1067 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1067 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1067 ((12 : Int),(0 : Int)) hp3_2_branches1067 hp3_2_evidence1067 hp3_2_check1067 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1067,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1066 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1066 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1066 ((12 : Int),(0 : Int)) hp3_2_branches1066 hp3_2_evidence1066 hp3_2_check1066 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1066,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1065 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1065 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1065 ((12 : Int),(1 : Int)) hp3_2_branches1065 hp3_2_evidence1065 hp3_2_check1065 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1065,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1064 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1064 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1064 ((12 : Int),(1 : Int)) hp3_2_branches1064 hp3_2_evidence1064 hp3_2_check1064 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1064,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1063 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1063 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1063 ((12 : Int),(0 : Int)) hp3_2_branches1063 hp3_2_evidence1063 hp3_2_check1063 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1063,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1064 T childKnown
  · exact hp3_2_node1065 T childKnown
theorem hp3_2_node1062 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1062 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1062 ((12 : Int),(1 : Int)) hp3_2_branches1062 hp3_2_evidence1062 hp3_2_check1062 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1062,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1061 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1061 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1061 ((12 : Int),(0 : Int)) hp3_2_branches1061 hp3_2_evidence1061 hp3_2_check1061 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1061,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1062 T childKnown
theorem hp3_2_node1060 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1060 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1060 ((12 : Int),(0 : Int)) hp3_2_branches1060 hp3_2_evidence1060 hp3_2_check1060 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1060,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1059 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1059 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1059 ((12 : Int),(1 : Int)) hp3_2_branches1059 hp3_2_evidence1059 hp3_2_check1059 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1059,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1060 T childKnown
theorem hp3_2_node1058 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1058 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1058 ((11 : Int),(1 : Int)) hp3_2_branches1058 hp3_2_evidence1058 hp3_2_check1058 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1058,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1059 T childKnown
  · exact hp3_2_node1061 T childKnown
  · exact hp3_2_node1063 T childKnown
  · exact hp3_2_node1066 T childKnown
  · exact hp3_2_node1067 T childKnown
  · exact hp3_2_node1068 T childKnown
theorem hp3_2_node1057 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1057 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1057 ((12 : Int),(0 : Int)) hp3_2_branches1057 hp3_2_evidence1057 hp3_2_check1057 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1057,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1056 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1056 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1056 ((12 : Int),(0 : Int)) hp3_2_branches1056 hp3_2_evidence1056 hp3_2_check1056 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1056,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1055 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1055 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1055 ((12 : Int),(0 : Int)) hp3_2_branches1055 hp3_2_evidence1055 hp3_2_check1055 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1055,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1054 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1054 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1054 ((12 : Int),(1 : Int)) hp3_2_branches1054 hp3_2_evidence1054 hp3_2_check1054 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1054,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1053 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1053 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1053 ((12 : Int),(1 : Int)) hp3_2_branches1053 hp3_2_evidence1053 hp3_2_check1053 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1053,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1052 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1052 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1052 ((12 : Int),(0 : Int)) hp3_2_branches1052 hp3_2_evidence1052 hp3_2_check1052 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1052,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1053 T childKnown
  · exact hp3_2_node1054 T childKnown
theorem hp3_2_node1051 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1051 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1051 ((12 : Int),(1 : Int)) hp3_2_branches1051 hp3_2_evidence1051 hp3_2_check1051 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1051,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1050 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1050 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1050 ((12 : Int),(0 : Int)) hp3_2_branches1050 hp3_2_evidence1050 hp3_2_check1050 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1050,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1051 T childKnown
theorem hp3_2_node1049 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1049 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1049 ((12 : Int),(0 : Int)) hp3_2_branches1049 hp3_2_evidence1049 hp3_2_check1049 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1049,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1048 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1048 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1048 ((12 : Int),(1 : Int)) hp3_2_branches1048 hp3_2_evidence1048 hp3_2_check1048 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1048,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1049 T childKnown
theorem hp3_2_node1047 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1047 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1047 ((11 : Int),(1 : Int)) hp3_2_branches1047 hp3_2_evidence1047 hp3_2_check1047 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1047,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1048 T childKnown
  · exact hp3_2_node1050 T childKnown
  · exact hp3_2_node1052 T childKnown
  · exact hp3_2_node1055 T childKnown
  · exact hp3_2_node1056 T childKnown
  · exact hp3_2_node1057 T childKnown
theorem hp3_2_node1046 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1046 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1046 ((12 : Int),(0 : Int)) hp3_2_branches1046 hp3_2_evidence1046 hp3_2_check1046 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1046,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1045 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1045 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1045 ((12 : Int),(0 : Int)) hp3_2_branches1045 hp3_2_evidence1045 hp3_2_check1045 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1045,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1044 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1044 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1044 ((12 : Int),(0 : Int)) hp3_2_branches1044 hp3_2_evidence1044 hp3_2_check1044 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1044,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1043 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1043 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1043 ((12 : Int),(1 : Int)) hp3_2_branches1043 hp3_2_evidence1043 hp3_2_check1043 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1043,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1042 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1042 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1042 ((12 : Int),(1 : Int)) hp3_2_branches1042 hp3_2_evidence1042 hp3_2_check1042 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1042,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1041 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1041 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1041 ((12 : Int),(0 : Int)) hp3_2_branches1041 hp3_2_evidence1041 hp3_2_check1041 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1041,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1042 T childKnown
  · exact hp3_2_node1043 T childKnown
theorem hp3_2_node1040 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1040 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1040 ((12 : Int),(1 : Int)) hp3_2_branches1040 hp3_2_evidence1040 hp3_2_check1040 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1040,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1039 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1039 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1039 ((12 : Int),(0 : Int)) hp3_2_branches1039 hp3_2_evidence1039 hp3_2_check1039 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1039,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1040 T childKnown
theorem hp3_2_node1038 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1038 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1038 ((12 : Int),(0 : Int)) hp3_2_branches1038 hp3_2_evidence1038 hp3_2_check1038 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1038,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1037 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1037 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1037 ((12 : Int),(1 : Int)) hp3_2_branches1037 hp3_2_evidence1037 hp3_2_check1037 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1037,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1038 T childKnown
theorem hp3_2_node1036 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1036 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1036 ((11 : Int),(1 : Int)) hp3_2_branches1036 hp3_2_evidence1036 hp3_2_check1036 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1036,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1037 T childKnown
  · exact hp3_2_node1039 T childKnown
  · exact hp3_2_node1041 T childKnown
  · exact hp3_2_node1044 T childKnown
  · exact hp3_2_node1045 T childKnown
  · exact hp3_2_node1046 T childKnown
theorem hp3_2_node1035 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1035 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1035 ((0 : Int),(2 : Int)) hp3_2_branches1035 hp3_2_evidence1035 hp3_2_check1035 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1035,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1036 T childKnown
  · exact hp3_2_node1047 T childKnown
  · exact hp3_2_node1058 T childKnown
theorem hp3_2_node1034 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1034 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1034 ((0 : Int),(1 : Int)) hp3_2_branches1034 hp3_2_evidence1034 hp3_2_check1034 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1034,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1035 T childKnown
  · exact hp3_2_node1069 T childKnown
  · exact hp3_2_node1092 T childKnown
  · exact hp3_2_node1103 T childKnown
  · exact hp3_2_node1115 T childKnown
  · exact hp3_2_node1126 T childKnown
theorem hp3_2_node1033 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1033 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1033 ((8 : Int),(2 : Int)) hp3_2_branches1033 hp3_2_evidence1033 hp3_2_check1033 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1033,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1032 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1032 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1032 ((8 : Int),(2 : Int)) hp3_2_branches1032 hp3_2_evidence1032 hp3_2_check1032 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1032,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1031 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1031 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1031 ((9 : Int),(1 : Int)) hp3_2_branches1031 hp3_2_evidence1031 hp3_2_check1031 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1031,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1030 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1030 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1030 ((9 : Int),(1 : Int)) hp3_2_branches1030 hp3_2_evidence1030 hp3_2_check1030 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1030,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1029 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1029 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1029 ((8 : Int),(2 : Int)) hp3_2_branches1029 hp3_2_evidence1029 hp3_2_check1029 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1029,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1030 T childKnown
  · exact hp3_2_node1031 T childKnown
theorem hp3_2_node1028 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1028 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1028 ((7 : Int),(2 : Int)) hp3_2_branches1028 hp3_2_evidence1028 hp3_2_check1028 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1028,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1029 T childKnown
  · exact hp3_2_node1032 T childKnown
  · exact hp3_2_node1033 T childKnown
  · exact hp3_2_node1034 T childKnown
theorem hp3_2_node1027 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1027 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1027 ((7 : Int),(0 : Int)) hp3_2_branches1027 hp3_2_evidence1027 hp3_2_check1027 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1027,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1028 T childKnown
theorem hp3_2_node1026 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1026 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1026 ((6 : Int),(0 : Int)) hp3_2_branches1026 hp3_2_evidence1026 hp3_2_check1026 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1026,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1027 T childKnown
  · exact hp3_2_node1137 T childKnown
  · exact hp3_2_node1140 T childKnown
  · exact hp3_2_node1146 T childKnown
theorem hp3_2_node1025 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1025 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1025 ((3 : Int),(1 : Int)) hp3_2_branches1025 hp3_2_evidence1025 hp3_2_check1025 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1025,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1026 T childKnown
  · exact hp3_2_node1149 T childKnown
theorem hp3_2_node1024 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1024 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1024 ((3 : Int),(2 : Int)) hp3_2_branches1024 hp3_2_evidence1024 hp3_2_check1024 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1024,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1023 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1023 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1023 ((3 : Int),(1 : Int)) hp3_2_branches1023 hp3_2_evidence1023 hp3_2_check1023 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1023,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1024 T childKnown
theorem hp3_2_node1022 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1022 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1022 ((0 : Int),(2 : Int)) hp3_2_branches1022 hp3_2_evidence1022 hp3_2_check1022 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1022,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1021 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1021 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1021 ((4 : Int),(2 : Int)) hp3_2_branches1021 hp3_2_evidence1021 hp3_2_check1021 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1021,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1020 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1020 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1020 ((4 : Int),(2 : Int)) hp3_2_branches1020 hp3_2_evidence1020 hp3_2_check1020 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1020,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1019 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1019 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1019 ((3 : Int),(2 : Int)) hp3_2_branches1019 hp3_2_evidence1019 hp3_2_check1019 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1019,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1020 T childKnown
  · exact hp3_2_node1021 T childKnown
theorem hp3_2_node1018 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1018 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1018 ((5 : Int),(0 : Int)) hp3_2_branches1018 hp3_2_evidence1018 hp3_2_check1018 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1018,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1019 T childKnown
theorem hp3_2_node1017 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1017 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1017 ((4 : Int),(2 : Int)) hp3_2_branches1017 hp3_2_evidence1017 hp3_2_check1017 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1017,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1016 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1016 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1016 ((3 : Int),(2 : Int)) hp3_2_branches1016 hp3_2_evidence1016 hp3_2_check1016 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1016,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1017 T childKnown
theorem hp3_2_node1015 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1015 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1015 ((6 : Int),(2 : Int)) hp3_2_branches1015 hp3_2_evidence1015 hp3_2_check1015 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1015,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1014 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1014 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1014 ((5 : Int),(2 : Int)) hp3_2_branches1014 hp3_2_evidence1014 hp3_2_check1014 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1014,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1015 T childKnown
theorem hp3_2_node1013 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1013 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1013 ((5 : Int),(0 : Int)) hp3_2_branches1013 hp3_2_evidence1013 hp3_2_check1013 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1013,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1014 T childKnown
theorem hp3_2_node1012 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1012 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1012 ((3 : Int),(2 : Int)) hp3_2_branches1012 hp3_2_evidence1012 hp3_2_check1012 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1012,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node1013 T childKnown
theorem hp3_2_node1011 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1011 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1011 ((4 : Int),(2 : Int)) hp3_2_branches1011 hp3_2_evidence1011 hp3_2_check1011 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1011,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1010 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1010 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1010 ((4 : Int),(2 : Int)) hp3_2_branches1010 hp3_2_evidence1010 hp3_2_check1010 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1010,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1009 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1009 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1009 ((4 : Int),(2 : Int)) hp3_2_branches1009 hp3_2_evidence1009 hp3_2_check1009 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1009,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1008 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1008 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1008 ((4 : Int),(1 : Int)) hp3_2_branches1008 hp3_2_evidence1008 hp3_2_check1008 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1008,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node1009 T childKnown
  · exact hp3_2_node1010 T childKnown
  · exact hp3_2_node1011 T childKnown
theorem hp3_2_node1007 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1007 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1007 ((5 : Int),(0 : Int)) hp3_2_branches1007 hp3_2_evidence1007 hp3_2_check1007 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1007,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1006 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1006 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1006 ((5 : Int),(0 : Int)) hp3_2_branches1006 hp3_2_evidence1006 hp3_2_check1006 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1006,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1005 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1005 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1005 ((4 : Int),(1 : Int)) hp3_2_branches1005 hp3_2_evidence1005 hp3_2_check1005 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1005,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node1006 T childKnown
  · exact hp3_2_node1007 T childKnown
theorem hp3_2_node1004 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1004 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1004 ((3 : Int),(1 : Int)) hp3_2_branches1004 hp3_2_evidence1004 hp3_2_check1004 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1004,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1005 T childKnown
  · exact hp3_2_node1008 T childKnown
  · exact hp3_2_node1012 T childKnown
  · exact hp3_2_node1016 T childKnown
  · exact hp3_2_node1018 T childKnown
theorem hp3_2_node1003 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1003 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1003 ((0 : Int),(2 : Int)) hp3_2_branches1003 hp3_2_evidence1003 hp3_2_check1003 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1003,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1002 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1002 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1002 ((0 : Int),(2 : Int)) hp3_2_branches1002 hp3_2_evidence1002 hp3_2_check1002 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1002,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1001 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1001 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1001 ((0 : Int),(1 : Int)) hp3_2_branches1001 hp3_2_evidence1001 hp3_2_check1001 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1001,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node1002 T childKnown
  · exact hp3_2_node1003 T childKnown
  · exact hp3_2_node1004 T childKnown
  · exact hp3_2_node1022 T childKnown
theorem hp3_2_node1000 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1000 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1000 ((0 : Int),(2 : Int)) hp3_2_branches1000 hp3_2_evidence1000 hp3_2_check1000 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1000,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node999 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected999 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected999 ((0 : Int),(2 : Int)) hp3_2_branches999 hp3_2_evidence999 hp3_2_check999 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches999,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node998 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected998 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected998 ((0 : Int),(1 : Int)) hp3_2_branches998 hp3_2_evidence998 hp3_2_check998 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches998,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node999 T childKnown
  · exact hp3_2_node1000 T childKnown
theorem hp3_2_node997 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected997 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected997 ((2 : Int),(1 : Int)) hp3_2_branches997 hp3_2_evidence997 hp3_2_check997 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches997,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node998 T childKnown
  · exact hp3_2_node1001 T childKnown
  · exact hp3_2_node1023 T childKnown
  · exact hp3_2_node1025 T childKnown
  · exact hp3_2_node1193 T childKnown
  · exact hp3_2_node1197 T childKnown
  · exact hp3_2_node1335 T childKnown
theorem hp3_2_node996 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected996 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected996 ((1 : Int),(1 : Int)) hp3_2_branches996 hp3_2_evidence996 hp3_2_check996 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches996,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node995 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected995 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected995 ((1 : Int),(1 : Int)) hp3_2_branches995 hp3_2_evidence995 hp3_2_check995 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches995,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node994 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected994 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected994 ((1 : Int),(0 : Int)) hp3_2_branches994 hp3_2_evidence994 hp3_2_check994 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches994,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node995 T childKnown
  · exact hp3_2_node996 T childKnown
theorem hp3_2_node993 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected993 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected993 ((6 : Int),(0 : Int)) hp3_2_branches993 hp3_2_evidence993 hp3_2_check993 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches993,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node992 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected992 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected992 ((6 : Int),(0 : Int)) hp3_2_branches992 hp3_2_evidence992 hp3_2_check992 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches992,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node991 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected991 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected991 ((6 : Int),(0 : Int)) hp3_2_branches991 hp3_2_evidence991 hp3_2_check991 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches991,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node990 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected990 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected990 ((6 : Int),(1 : Int)) hp3_2_branches990 hp3_2_evidence990 hp3_2_check990 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches990,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node989 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected989 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected989 ((6 : Int),(1 : Int)) hp3_2_branches989 hp3_2_evidence989 hp3_2_check989 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches989,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node988 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected988 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected988 ((6 : Int),(0 : Int)) hp3_2_branches988 hp3_2_evidence988 hp3_2_check988 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches988,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node989 T childKnown
  · exact hp3_2_node990 T childKnown
theorem hp3_2_node987 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected987 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected987 ((6 : Int),(1 : Int)) hp3_2_branches987 hp3_2_evidence987 hp3_2_check987 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches987,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node986 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected986 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected986 ((6 : Int),(0 : Int)) hp3_2_branches986 hp3_2_evidence986 hp3_2_check986 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches986,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node987 T childKnown
theorem hp3_2_node985 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected985 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected985 ((6 : Int),(0 : Int)) hp3_2_branches985 hp3_2_evidence985 hp3_2_check985 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches985,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node984 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected984 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected984 ((6 : Int),(1 : Int)) hp3_2_branches984 hp3_2_evidence984 hp3_2_check984 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches984,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node985 T childKnown
theorem hp3_2_node983 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected983 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected983 ((5 : Int),(1 : Int)) hp3_2_branches983 hp3_2_evidence983 hp3_2_check983 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches983,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node984 T childKnown
  · exact hp3_2_node986 T childKnown
  · exact hp3_2_node988 T childKnown
  · exact hp3_2_node991 T childKnown
  · exact hp3_2_node992 T childKnown
  · exact hp3_2_node993 T childKnown
theorem hp3_2_node982 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected982 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected982 ((2 : Int),(2 : Int)) hp3_2_branches982 hp3_2_evidence982 hp3_2_check982 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches982,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node981 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected981 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected981 ((2 : Int),(2 : Int)) hp3_2_branches981 hp3_2_evidence981 hp3_2_check981 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches981,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node980 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected980 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected980 ((3 : Int),(1 : Int)) hp3_2_branches980 hp3_2_evidence980 hp3_2_check980 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches980,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node979 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected979 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected979 ((3 : Int),(1 : Int)) hp3_2_branches979 hp3_2_evidence979 hp3_2_check979 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches979,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node978 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected978 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected978 ((2 : Int),(2 : Int)) hp3_2_branches978 hp3_2_evidence978 hp3_2_check978 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches978,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node979 T childKnown
  · exact hp3_2_node980 T childKnown
theorem hp3_2_node977 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected977 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected977 ((1 : Int),(2 : Int)) hp3_2_branches977 hp3_2_evidence977 hp3_2_check977 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches977,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node978 T childKnown
  · exact hp3_2_node981 T childKnown
  · exact hp3_2_node982 T childKnown
  · exact hp3_2_node983 T childKnown
theorem hp3_2_node976 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected976 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected976 ((1 : Int),(0 : Int)) hp3_2_branches976 hp3_2_evidence976 hp3_2_check976 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches976,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node977 T childKnown
theorem hp3_2_node975 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected975 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected975 ((1 : Int),(1 : Int)) hp3_2_branches975 hp3_2_evidence975 hp3_2_check975 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches975,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node974 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected974 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected974 ((1 : Int),(0 : Int)) hp3_2_branches974 hp3_2_evidence974 hp3_2_check974 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches974,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node975 T childKnown
theorem hp3_2_node973 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected973 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected973 ((4 : Int),(1 : Int)) hp3_2_branches973 hp3_2_evidence973 hp3_2_check973 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches973,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node972 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected972 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected972 ((4 : Int),(1 : Int)) hp3_2_branches972 hp3_2_evidence972 hp3_2_check972 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches972,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node971 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected971 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected971 ((4 : Int),(1 : Int)) hp3_2_branches971 hp3_2_evidence971 hp3_2_check971 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches971,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node970 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected970 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected970 ((5 : Int),(1 : Int)) hp3_2_branches970 hp3_2_evidence970 hp3_2_check970 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches970,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node969 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected969 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected969 ((5 : Int),(1 : Int)) hp3_2_branches969 hp3_2_evidence969 hp3_2_check969 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches969,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node968 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected968 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected968 ((4 : Int),(1 : Int)) hp3_2_branches968 hp3_2_evidence968 hp3_2_check968 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches968,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node969 T childKnown
  · exact hp3_2_node970 T childKnown
theorem hp3_2_node967 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected967 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected967 ((4 : Int),(1 : Int)) hp3_2_branches967 hp3_2_evidence967 hp3_2_check967 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches967,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node966 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected966 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected966 ((3 : Int),(1 : Int)) hp3_2_branches966 hp3_2_evidence966 hp3_2_check966 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches966,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node967 T childKnown
  · exact hp3_2_node968 T childKnown
  · exact hp3_2_node971 T childKnown
  · exact hp3_2_node972 T childKnown
  · exact hp3_2_node973 T childKnown
theorem hp3_2_node965 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected965 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected965 ((4 : Int),(1 : Int)) hp3_2_branches965 hp3_2_evidence965 hp3_2_check965 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches965,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node964 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected964 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected964 ((4 : Int),(1 : Int)) hp3_2_branches964 hp3_2_evidence964 hp3_2_check964 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches964,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node963 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected963 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected963 ((0 : Int),(2 : Int)) hp3_2_branches963 hp3_2_evidence963 hp3_2_check963 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches963,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node962 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected962 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected962 ((0 : Int),(1 : Int)) hp3_2_branches962 hp3_2_evidence962 hp3_2_check962 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches962,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node963 T childKnown
theorem hp3_2_node961 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected961 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected961 ((1 : Int),(2 : Int)) hp3_2_branches961 hp3_2_evidence961 hp3_2_check961 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches961,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node960 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected960 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected960 ((1 : Int),(2 : Int)) hp3_2_branches960 hp3_2_evidence960 hp3_2_check960 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches960,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node959 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected959 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected959 ((1 : Int),(1 : Int)) hp3_2_branches959 hp3_2_evidence959 hp3_2_check959 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches959,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node960 T childKnown
  · exact hp3_2_node961 T childKnown
  · exact hp3_2_node962 T childKnown
theorem hp3_2_node958 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected958 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected958 ((4 : Int),(1 : Int)) hp3_2_branches958 hp3_2_evidence958 hp3_2_check958 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches958,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node959 T childKnown
theorem hp3_2_node957 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected957 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected957 ((4 : Int),(1 : Int)) hp3_2_branches957 hp3_2_evidence957 hp3_2_check957 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches957,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node956 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected956 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected956 ((3 : Int),(1 : Int)) hp3_2_branches956 hp3_2_evidence956 hp3_2_check956 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches956,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node957 T childKnown
  · exact hp3_2_node958 T childKnown
  · exact hp3_2_node964 T childKnown
  · exact hp3_2_node965 T childKnown
theorem hp3_2_node955 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected955 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected955 ((5 : Int),(1 : Int)) hp3_2_branches955 hp3_2_evidence955 hp3_2_check955 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches955,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node954 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected954 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected954 ((5 : Int),(1 : Int)) hp3_2_branches954 hp3_2_evidence954 hp3_2_check954 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches954,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node953 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected953 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected953 ((5 : Int),(0 : Int)) hp3_2_branches953 hp3_2_evidence953 hp3_2_check953 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches953,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node954 T childKnown
  · exact hp3_2_node955 T childKnown
theorem hp3_2_node952 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected952 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected952 ((3 : Int),(1 : Int)) hp3_2_branches952 hp3_2_evidence952 hp3_2_check952 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches952,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node953 T childKnown
theorem hp3_2_node951 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected951 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected951 ((0 : Int),(2 : Int)) hp3_2_branches951 hp3_2_evidence951 hp3_2_check951 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches951,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node950 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected950 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected950 ((0 : Int),(1 : Int)) hp3_2_branches950 hp3_2_evidence950 hp3_2_check950 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches950,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node951 T childKnown
theorem hp3_2_node949 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected949 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected949 ((1 : Int),(2 : Int)) hp3_2_branches949 hp3_2_evidence949 hp3_2_check949 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches949,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node948 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected948 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected948 ((1 : Int),(2 : Int)) hp3_2_branches948 hp3_2_evidence948 hp3_2_check948 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches948,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node947 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected947 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected947 ((1 : Int),(1 : Int)) hp3_2_branches947 hp3_2_evidence947 hp3_2_check947 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches947,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node948 T childKnown
  · exact hp3_2_node949 T childKnown
  · exact hp3_2_node950 T childKnown
theorem hp3_2_node946 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected946 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected946 ((5 : Int),(0 : Int)) hp3_2_branches946 hp3_2_evidence946 hp3_2_check946 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches946,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node947 T childKnown
theorem hp3_2_node945 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected945 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected945 ((3 : Int),(1 : Int)) hp3_2_branches945 hp3_2_evidence945 hp3_2_check945 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches945,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node946 T childKnown
theorem hp3_2_node944 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected944 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected944 ((3 : Int),(1 : Int)) hp3_2_branches944 hp3_2_evidence944 hp3_2_check944 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches944,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node943 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected943 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected943 ((3 : Int),(1 : Int)) hp3_2_branches943 hp3_2_evidence943 hp3_2_check943 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches943,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node942 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected942 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected942 ((4 : Int),(0 : Int)) hp3_2_branches942 hp3_2_evidence942 hp3_2_check942 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches942,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node943 T childKnown
  · exact hp3_2_node944 T childKnown
  · exact hp3_2_node945 T childKnown
  · exact hp3_2_node952 T childKnown
  · exact hp3_2_node956 T childKnown
  · exact hp3_2_node966 T childKnown
theorem hp3_2_node941 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected941 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected941 ((1 : Int),(2 : Int)) hp3_2_branches941 hp3_2_evidence941 hp3_2_check941 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches941,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node940 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected940 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected940 ((3 : Int),(2 : Int)) hp3_2_branches940 hp3_2_evidence940 hp3_2_check940 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches940,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node941 T childKnown
theorem hp3_2_node939 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected939 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected939 ((5 : Int),(2 : Int)) hp3_2_branches939 hp3_2_evidence939 hp3_2_check939 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches939,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node940 T childKnown
theorem hp3_2_node938 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected938 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected938 ((5 : Int),(2 : Int)) hp3_2_branches938 hp3_2_evidence938 hp3_2_check938 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches938,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node937 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected937 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected937 ((5 : Int),(2 : Int)) hp3_2_branches937 hp3_2_evidence937 hp3_2_check937 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches937,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node936 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected936 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected936 ((6 : Int),(1 : Int)) hp3_2_branches936 hp3_2_evidence936 hp3_2_check936 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches936,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node937 T childKnown
  · exact hp3_2_node938 T childKnown
  · exact hp3_2_node939 T childKnown
theorem hp3_2_node935 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected935 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected935 ((4 : Int),(0 : Int)) hp3_2_branches935 hp3_2_evidence935 hp3_2_check935 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches935,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node936 T childKnown
theorem hp3_2_node934 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected934 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected934 ((4 : Int),(2 : Int)) hp3_2_branches934 hp3_2_evidence934 hp3_2_check934 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches934,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node933 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected933 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected933 ((3 : Int),(2 : Int)) hp3_2_branches933 hp3_2_evidence933 hp3_2_check933 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches933,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node934 T childKnown
theorem hp3_2_node932 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected932 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected932 ((3 : Int),(2 : Int)) hp3_2_branches932 hp3_2_evidence932 hp3_2_check932 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches932,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node931 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected931 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected931 ((9 : Int),(0 : Int)) hp3_2_branches931 hp3_2_evidence931 hp3_2_check931 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches931,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node930 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected930 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected930 ((9 : Int),(0 : Int)) hp3_2_branches930 hp3_2_evidence930 hp3_2_check930 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches930,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node929 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected929 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected929 ((9 : Int),(0 : Int)) hp3_2_branches929 hp3_2_evidence929 hp3_2_check929 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches929,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node928 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected928 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected928 ((9 : Int),(1 : Int)) hp3_2_branches928 hp3_2_evidence928 hp3_2_check928 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches928,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node927 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected927 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected927 ((9 : Int),(1 : Int)) hp3_2_branches927 hp3_2_evidence927 hp3_2_check927 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches927,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node926 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected926 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected926 ((9 : Int),(0 : Int)) hp3_2_branches926 hp3_2_evidence926 hp3_2_check926 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches926,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node927 T childKnown
  · exact hp3_2_node928 T childKnown
theorem hp3_2_node925 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected925 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected925 ((9 : Int),(1 : Int)) hp3_2_branches925 hp3_2_evidence925 hp3_2_check925 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches925,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node924 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected924 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected924 ((9 : Int),(0 : Int)) hp3_2_branches924 hp3_2_evidence924 hp3_2_check924 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches924,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node925 T childKnown
theorem hp3_2_node923 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected923 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected923 ((9 : Int),(0 : Int)) hp3_2_branches923 hp3_2_evidence923 hp3_2_check923 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches923,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node922 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected922 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected922 ((9 : Int),(1 : Int)) hp3_2_branches922 hp3_2_evidence922 hp3_2_check922 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches922,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node923 T childKnown
theorem hp3_2_node921 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected921 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected921 ((8 : Int),(1 : Int)) hp3_2_branches921 hp3_2_evidence921 hp3_2_check921 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches921,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node922 T childKnown
  · exact hp3_2_node924 T childKnown
  · exact hp3_2_node926 T childKnown
  · exact hp3_2_node929 T childKnown
  · exact hp3_2_node930 T childKnown
  · exact hp3_2_node931 T childKnown
theorem hp3_2_node920 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected920 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected920 ((4 : Int),(2 : Int)) hp3_2_branches920 hp3_2_evidence920 hp3_2_check920 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches920,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node921 T childKnown
theorem hp3_2_node919 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected919 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected919 ((9 : Int),(0 : Int)) hp3_2_branches919 hp3_2_evidence919 hp3_2_check919 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches919,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node918 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected918 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected918 ((9 : Int),(0 : Int)) hp3_2_branches918 hp3_2_evidence918 hp3_2_check918 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches918,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node917 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected917 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected917 ((9 : Int),(0 : Int)) hp3_2_branches917 hp3_2_evidence917 hp3_2_check917 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches917,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node916 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected916 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected916 ((9 : Int),(1 : Int)) hp3_2_branches916 hp3_2_evidence916 hp3_2_check916 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches916,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node915 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected915 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected915 ((9 : Int),(1 : Int)) hp3_2_branches915 hp3_2_evidence915 hp3_2_check915 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches915,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node914 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected914 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected914 ((9 : Int),(0 : Int)) hp3_2_branches914 hp3_2_evidence914 hp3_2_check914 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches914,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node915 T childKnown
  · exact hp3_2_node916 T childKnown
theorem hp3_2_node913 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected913 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected913 ((9 : Int),(1 : Int)) hp3_2_branches913 hp3_2_evidence913 hp3_2_check913 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches913,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node912 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected912 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected912 ((9 : Int),(0 : Int)) hp3_2_branches912 hp3_2_evidence912 hp3_2_check912 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches912,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node913 T childKnown
theorem hp3_2_node911 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected911 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected911 ((9 : Int),(0 : Int)) hp3_2_branches911 hp3_2_evidence911 hp3_2_check911 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches911,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node910 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected910 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected910 ((9 : Int),(1 : Int)) hp3_2_branches910 hp3_2_evidence910 hp3_2_check910 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches910,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node911 T childKnown
theorem hp3_2_node909 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected909 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected909 ((8 : Int),(1 : Int)) hp3_2_branches909 hp3_2_evidence909 hp3_2_check909 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches909,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node910 T childKnown
  · exact hp3_2_node912 T childKnown
  · exact hp3_2_node914 T childKnown
  · exact hp3_2_node917 T childKnown
  · exact hp3_2_node918 T childKnown
  · exact hp3_2_node919 T childKnown
theorem hp3_2_node908 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected908 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected908 ((4 : Int),(2 : Int)) hp3_2_branches908 hp3_2_evidence908 hp3_2_check908 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches908,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node909 T childKnown
theorem hp3_2_node907 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected907 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected907 ((4 : Int),(2 : Int)) hp3_2_branches907 hp3_2_evidence907 hp3_2_check907 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches907,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node906 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected906 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected906 ((3 : Int),(2 : Int)) hp3_2_branches906 hp3_2_evidence906 hp3_2_check906 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches906,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node907 T childKnown
  · exact hp3_2_node908 T childKnown
  · exact hp3_2_node920 T childKnown
theorem hp3_2_node905 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected905 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected905 ((9 : Int),(0 : Int)) hp3_2_branches905 hp3_2_evidence905 hp3_2_check905 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches905,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node904 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected904 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected904 ((9 : Int),(0 : Int)) hp3_2_branches904 hp3_2_evidence904 hp3_2_check904 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches904,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node903 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected903 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected903 ((9 : Int),(0 : Int)) hp3_2_branches903 hp3_2_evidence903 hp3_2_check903 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches903,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node902 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected902 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected902 ((9 : Int),(1 : Int)) hp3_2_branches902 hp3_2_evidence902 hp3_2_check902 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches902,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node901 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected901 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected901 ((9 : Int),(1 : Int)) hp3_2_branches901 hp3_2_evidence901 hp3_2_check901 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches901,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node900 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected900 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected900 ((9 : Int),(0 : Int)) hp3_2_branches900 hp3_2_evidence900 hp3_2_check900 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches900,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node901 T childKnown
  · exact hp3_2_node902 T childKnown
theorem hp3_2_node899 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected899 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected899 ((9 : Int),(1 : Int)) hp3_2_branches899 hp3_2_evidence899 hp3_2_check899 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches899,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node898 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected898 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected898 ((9 : Int),(0 : Int)) hp3_2_branches898 hp3_2_evidence898 hp3_2_check898 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches898,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node899 T childKnown
theorem hp3_2_node897 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected897 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected897 ((9 : Int),(0 : Int)) hp3_2_branches897 hp3_2_evidence897 hp3_2_check897 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches897,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node896 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected896 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected896 ((9 : Int),(1 : Int)) hp3_2_branches896 hp3_2_evidence896 hp3_2_check896 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches896,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node897 T childKnown
theorem hp3_2_node895 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected895 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected895 ((8 : Int),(1 : Int)) hp3_2_branches895 hp3_2_evidence895 hp3_2_check895 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches895,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node896 T childKnown
  · exact hp3_2_node898 T childKnown
  · exact hp3_2_node900 T childKnown
  · exact hp3_2_node903 T childKnown
  · exact hp3_2_node904 T childKnown
  · exact hp3_2_node905 T childKnown
theorem hp3_2_node894 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected894 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected894 ((4 : Int),(2 : Int)) hp3_2_branches894 hp3_2_evidence894 hp3_2_check894 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches894,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node895 T childKnown
theorem hp3_2_node893 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected893 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected893 ((9 : Int),(0 : Int)) hp3_2_branches893 hp3_2_evidence893 hp3_2_check893 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches893,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node892 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected892 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected892 ((9 : Int),(0 : Int)) hp3_2_branches892 hp3_2_evidence892 hp3_2_check892 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches892,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node891 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected891 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected891 ((9 : Int),(0 : Int)) hp3_2_branches891 hp3_2_evidence891 hp3_2_check891 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches891,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node890 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected890 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected890 ((9 : Int),(1 : Int)) hp3_2_branches890 hp3_2_evidence890 hp3_2_check890 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches890,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node889 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected889 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected889 ((9 : Int),(1 : Int)) hp3_2_branches889 hp3_2_evidence889 hp3_2_check889 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches889,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node888 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected888 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected888 ((9 : Int),(0 : Int)) hp3_2_branches888 hp3_2_evidence888 hp3_2_check888 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches888,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node889 T childKnown
  · exact hp3_2_node890 T childKnown
theorem hp3_2_node887 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected887 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected887 ((9 : Int),(1 : Int)) hp3_2_branches887 hp3_2_evidence887 hp3_2_check887 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches887,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node886 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected886 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected886 ((9 : Int),(0 : Int)) hp3_2_branches886 hp3_2_evidence886 hp3_2_check886 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches886,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node887 T childKnown
theorem hp3_2_node885 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected885 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected885 ((9 : Int),(0 : Int)) hp3_2_branches885 hp3_2_evidence885 hp3_2_check885 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches885,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node884 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected884 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected884 ((9 : Int),(1 : Int)) hp3_2_branches884 hp3_2_evidence884 hp3_2_check884 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches884,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node885 T childKnown
theorem hp3_2_node883 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected883 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected883 ((8 : Int),(1 : Int)) hp3_2_branches883 hp3_2_evidence883 hp3_2_check883 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches883,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node884 T childKnown
  · exact hp3_2_node886 T childKnown
  · exact hp3_2_node888 T childKnown
  · exact hp3_2_node891 T childKnown
  · exact hp3_2_node892 T childKnown
  · exact hp3_2_node893 T childKnown
theorem hp3_2_node882 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected882 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected882 ((4 : Int),(2 : Int)) hp3_2_branches882 hp3_2_evidence882 hp3_2_check882 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches882,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node883 T childKnown
theorem hp3_2_node881 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected881 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected881 ((4 : Int),(2 : Int)) hp3_2_branches881 hp3_2_evidence881 hp3_2_check881 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches881,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node880 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected880 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected880 ((3 : Int),(2 : Int)) hp3_2_branches880 hp3_2_evidence880 hp3_2_check880 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches880,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node881 T childKnown
  · exact hp3_2_node882 T childKnown
  · exact hp3_2_node894 T childKnown
theorem hp3_2_node879 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected879 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected879 ((9 : Int),(0 : Int)) hp3_2_branches879 hp3_2_evidence879 hp3_2_check879 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches879,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node878 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected878 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected878 ((9 : Int),(0 : Int)) hp3_2_branches878 hp3_2_evidence878 hp3_2_check878 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches878,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node877 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected877 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected877 ((9 : Int),(0 : Int)) hp3_2_branches877 hp3_2_evidence877 hp3_2_check877 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches877,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node876 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected876 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected876 ((9 : Int),(1 : Int)) hp3_2_branches876 hp3_2_evidence876 hp3_2_check876 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches876,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node875 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected875 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected875 ((9 : Int),(1 : Int)) hp3_2_branches875 hp3_2_evidence875 hp3_2_check875 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches875,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node874 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected874 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected874 ((9 : Int),(0 : Int)) hp3_2_branches874 hp3_2_evidence874 hp3_2_check874 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches874,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node875 T childKnown
  · exact hp3_2_node876 T childKnown
theorem hp3_2_node873 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected873 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected873 ((9 : Int),(1 : Int)) hp3_2_branches873 hp3_2_evidence873 hp3_2_check873 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches873,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node872 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected872 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected872 ((9 : Int),(0 : Int)) hp3_2_branches872 hp3_2_evidence872 hp3_2_check872 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches872,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node873 T childKnown
theorem hp3_2_node871 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected871 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected871 ((9 : Int),(0 : Int)) hp3_2_branches871 hp3_2_evidence871 hp3_2_check871 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches871,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node870 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected870 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected870 ((9 : Int),(1 : Int)) hp3_2_branches870 hp3_2_evidence870 hp3_2_check870 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches870,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node871 T childKnown
theorem hp3_2_node869 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected869 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected869 ((8 : Int),(1 : Int)) hp3_2_branches869 hp3_2_evidence869 hp3_2_check869 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches869,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node870 T childKnown
  · exact hp3_2_node872 T childKnown
  · exact hp3_2_node874 T childKnown
  · exact hp3_2_node877 T childKnown
  · exact hp3_2_node878 T childKnown
  · exact hp3_2_node879 T childKnown
theorem hp3_2_node868 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected868 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected868 ((4 : Int),(2 : Int)) hp3_2_branches868 hp3_2_evidence868 hp3_2_check868 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches868,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node869 T childKnown
theorem hp3_2_node867 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected867 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected867 ((9 : Int),(0 : Int)) hp3_2_branches867 hp3_2_evidence867 hp3_2_check867 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches867,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node866 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected866 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected866 ((9 : Int),(0 : Int)) hp3_2_branches866 hp3_2_evidence866 hp3_2_check866 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches866,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node865 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected865 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected865 ((9 : Int),(0 : Int)) hp3_2_branches865 hp3_2_evidence865 hp3_2_check865 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches865,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node864 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected864 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected864 ((9 : Int),(1 : Int)) hp3_2_branches864 hp3_2_evidence864 hp3_2_check864 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches864,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node863 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected863 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected863 ((9 : Int),(1 : Int)) hp3_2_branches863 hp3_2_evidence863 hp3_2_check863 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches863,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node862 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected862 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected862 ((9 : Int),(0 : Int)) hp3_2_branches862 hp3_2_evidence862 hp3_2_check862 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches862,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node863 T childKnown
  · exact hp3_2_node864 T childKnown
theorem hp3_2_node861 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected861 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected861 ((9 : Int),(1 : Int)) hp3_2_branches861 hp3_2_evidence861 hp3_2_check861 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches861,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node860 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected860 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected860 ((9 : Int),(0 : Int)) hp3_2_branches860 hp3_2_evidence860 hp3_2_check860 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches860,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node861 T childKnown
theorem hp3_2_node859 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected859 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected859 ((9 : Int),(0 : Int)) hp3_2_branches859 hp3_2_evidence859 hp3_2_check859 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches859,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node858 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected858 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected858 ((9 : Int),(1 : Int)) hp3_2_branches858 hp3_2_evidence858 hp3_2_check858 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches858,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node859 T childKnown
theorem hp3_2_node857 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected857 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected857 ((8 : Int),(1 : Int)) hp3_2_branches857 hp3_2_evidence857 hp3_2_check857 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches857,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node858 T childKnown
  · exact hp3_2_node860 T childKnown
  · exact hp3_2_node862 T childKnown
  · exact hp3_2_node865 T childKnown
  · exact hp3_2_node866 T childKnown
  · exact hp3_2_node867 T childKnown
theorem hp3_2_node856 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected856 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected856 ((4 : Int),(2 : Int)) hp3_2_branches856 hp3_2_evidence856 hp3_2_check856 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches856,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node857 T childKnown
theorem hp3_2_node855 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected855 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected855 ((9 : Int),(0 : Int)) hp3_2_branches855 hp3_2_evidence855 hp3_2_check855 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches855,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node854 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected854 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected854 ((9 : Int),(0 : Int)) hp3_2_branches854 hp3_2_evidence854 hp3_2_check854 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches854,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node853 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected853 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected853 ((9 : Int),(0 : Int)) hp3_2_branches853 hp3_2_evidence853 hp3_2_check853 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches853,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node852 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected852 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected852 ((9 : Int),(1 : Int)) hp3_2_branches852 hp3_2_evidence852 hp3_2_check852 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches852,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node851 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected851 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected851 ((9 : Int),(1 : Int)) hp3_2_branches851 hp3_2_evidence851 hp3_2_check851 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches851,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node850 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected850 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected850 ((9 : Int),(0 : Int)) hp3_2_branches850 hp3_2_evidence850 hp3_2_check850 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches850,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node851 T childKnown
  · exact hp3_2_node852 T childKnown
theorem hp3_2_node849 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected849 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected849 ((9 : Int),(1 : Int)) hp3_2_branches849 hp3_2_evidence849 hp3_2_check849 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches849,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node848 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected848 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected848 ((9 : Int),(0 : Int)) hp3_2_branches848 hp3_2_evidence848 hp3_2_check848 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches848,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node849 T childKnown
theorem hp3_2_node847 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected847 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected847 ((9 : Int),(0 : Int)) hp3_2_branches847 hp3_2_evidence847 hp3_2_check847 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches847,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node846 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected846 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected846 ((9 : Int),(1 : Int)) hp3_2_branches846 hp3_2_evidence846 hp3_2_check846 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches846,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node847 T childKnown
theorem hp3_2_node845 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected845 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected845 ((8 : Int),(1 : Int)) hp3_2_branches845 hp3_2_evidence845 hp3_2_check845 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches845,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node846 T childKnown
  · exact hp3_2_node848 T childKnown
  · exact hp3_2_node850 T childKnown
  · exact hp3_2_node853 T childKnown
  · exact hp3_2_node854 T childKnown
  · exact hp3_2_node855 T childKnown
theorem hp3_2_node844 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected844 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected844 ((5 : Int),(2 : Int)) hp3_2_branches844 hp3_2_evidence844 hp3_2_check844 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches844,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node843 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected843 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected843 ((5 : Int),(2 : Int)) hp3_2_branches843 hp3_2_evidence843 hp3_2_check843 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches843,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node842 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected842 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected842 ((4 : Int),(2 : Int)) hp3_2_branches842 hp3_2_evidence842 hp3_2_check842 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches842,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node843 T childKnown
  · exact hp3_2_node844 T childKnown
  · exact hp3_2_node845 T childKnown
theorem hp3_2_node841 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected841 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected841 ((3 : Int),(2 : Int)) hp3_2_branches841 hp3_2_evidence841 hp3_2_check841 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches841,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node842 T childKnown
  · exact hp3_2_node856 T childKnown
  · exact hp3_2_node868 T childKnown
theorem hp3_2_node840 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected840 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected840 ((1 : Int),(2 : Int)) hp3_2_branches840 hp3_2_evidence840 hp3_2_check840 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches840,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node841 T childKnown
  · exact hp3_2_node880 T childKnown
  · exact hp3_2_node906 T childKnown
  · exact hp3_2_node932 T childKnown
  · exact hp3_2_node933 T childKnown
theorem hp3_2_node839 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected839 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected839 ((4 : Int),(0 : Int)) hp3_2_branches839 hp3_2_evidence839 hp3_2_check839 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches839,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node840 T childKnown
theorem hp3_2_node838 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected838 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected838 ((2 : Int),(2 : Int)) hp3_2_branches838 hp3_2_evidence838 hp3_2_check838 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches838,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node837 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected837 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected837 ((2 : Int),(2 : Int)) hp3_2_branches837 hp3_2_evidence837 hp3_2_check837 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches837,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node836 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected836 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected836 ((2 : Int),(2 : Int)) hp3_2_branches836 hp3_2_evidence836 hp3_2_check836 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches836,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node835 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected835 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected835 ((2 : Int),(1 : Int)) hp3_2_branches835 hp3_2_evidence835 hp3_2_check835 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches835,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node836 T childKnown
  · exact hp3_2_node837 T childKnown
  · exact hp3_2_node838 T childKnown
theorem hp3_2_node834 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected834 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected834 ((9 : Int),(1 : Int)) hp3_2_branches834 hp3_2_evidence834 hp3_2_check834 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches834,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node833 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected833 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected833 ((8 : Int),(1 : Int)) hp3_2_branches833 hp3_2_evidence833 hp3_2_check833 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches833,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node834 T childKnown
theorem hp3_2_node832 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected832 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected832 ((9 : Int),(1 : Int)) hp3_2_branches832 hp3_2_evidence832 hp3_2_check832 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches832,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node831 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected831 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected831 ((8 : Int),(1 : Int)) hp3_2_branches831 hp3_2_evidence831 hp3_2_check831 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches831,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node832 T childKnown
theorem hp3_2_node830 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected830 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected830 ((8 : Int),(1 : Int)) hp3_2_branches830 hp3_2_evidence830 hp3_2_check830 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches830,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node829 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected829 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected829 ((9 : Int),(0 : Int)) hp3_2_branches829 hp3_2_evidence829 hp3_2_check829 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches829,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node830 T childKnown
  · exact hp3_2_node831 T childKnown
  · exact hp3_2_node833 T childKnown
theorem hp3_2_node828 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected828 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected828 ((6 : Int),(2 : Int)) hp3_2_branches828 hp3_2_evidence828 hp3_2_check828 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches828,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node829 T childKnown
theorem hp3_2_node827 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected827 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected827 ((6 : Int),(2 : Int)) hp3_2_branches827 hp3_2_evidence827 hp3_2_check827 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches827,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node826 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected826 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected826 ((9 : Int),(0 : Int)) hp3_2_branches826 hp3_2_evidence826 hp3_2_check826 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches826,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node825 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected825 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected825 ((8 : Int),(2 : Int)) hp3_2_branches825 hp3_2_evidence825 hp3_2_check825 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches825,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node824 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected824 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected824 ((9 : Int),(0 : Int)) hp3_2_branches824 hp3_2_evidence824 hp3_2_check824 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches824,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node823 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected823 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected823 ((9 : Int),(0 : Int)) hp3_2_branches823 hp3_2_evidence823 hp3_2_check823 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches823,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node822 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected822 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected822 ((9 : Int),(1 : Int)) hp3_2_branches822 hp3_2_evidence822 hp3_2_check822 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches822,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node823 T childKnown
theorem hp3_2_node821 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected821 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected821 ((8 : Int),(1 : Int)) hp3_2_branches821 hp3_2_evidence821 hp3_2_check821 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches821,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node822 T childKnown
  · exact hp3_2_node824 T childKnown
  · exact hp3_2_node825 T childKnown
  · exact hp3_2_node826 T childKnown
theorem hp3_2_node820 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected820 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected820 ((8 : Int),(2 : Int)) hp3_2_branches820 hp3_2_evidence820 hp3_2_check820 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches820,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node819 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected819 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected819 ((8 : Int),(2 : Int)) hp3_2_branches819 hp3_2_evidence819 hp3_2_check819 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches819,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node818 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected818 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected818 ((8 : Int),(2 : Int)) hp3_2_branches818 hp3_2_evidence818 hp3_2_check818 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches818,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node817 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected817 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected817 ((8 : Int),(1 : Int)) hp3_2_branches817 hp3_2_evidence817 hp3_2_check817 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches817,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node818 T childKnown
  · exact hp3_2_node819 T childKnown
  · exact hp3_2_node820 T childKnown
theorem hp3_2_node816 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected816 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected816 ((9 : Int),(1 : Int)) hp3_2_branches816 hp3_2_evidence816 hp3_2_check816 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches816,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node815 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected815 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected815 ((8 : Int),(1 : Int)) hp3_2_branches815 hp3_2_evidence815 hp3_2_check815 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches815,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node816 T childKnown
theorem hp3_2_node814 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected814 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected814 ((9 : Int),(1 : Int)) hp3_2_branches814 hp3_2_evidence814 hp3_2_check814 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches814,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node813 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected813 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected813 ((8 : Int),(1 : Int)) hp3_2_branches813 hp3_2_evidence813 hp3_2_check813 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches813,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node814 T childKnown
theorem hp3_2_node812 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected812 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected812 ((8 : Int),(1 : Int)) hp3_2_branches812 hp3_2_evidence812 hp3_2_check812 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches812,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node811 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected811 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected811 ((9 : Int),(0 : Int)) hp3_2_branches811 hp3_2_evidence811 hp3_2_check811 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches811,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node812 T childKnown
  · exact hp3_2_node813 T childKnown
  · exact hp3_2_node815 T childKnown
theorem hp3_2_node810 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected810 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected810 ((6 : Int),(2 : Int)) hp3_2_branches810 hp3_2_evidence810 hp3_2_check810 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches810,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node811 T childKnown
  · exact hp3_2_node817 T childKnown
  · exact hp3_2_node821 T childKnown
theorem hp3_2_node809 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected809 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected809 ((9 : Int),(0 : Int)) hp3_2_branches809 hp3_2_evidence809 hp3_2_check809 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches809,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node808 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected808 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected808 ((8 : Int),(2 : Int)) hp3_2_branches808 hp3_2_evidence808 hp3_2_check808 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches808,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node807 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected807 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected807 ((9 : Int),(0 : Int)) hp3_2_branches807 hp3_2_evidence807 hp3_2_check807 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches807,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node806 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected806 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected806 ((9 : Int),(0 : Int)) hp3_2_branches806 hp3_2_evidence806 hp3_2_check806 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches806,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node805 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected805 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected805 ((9 : Int),(1 : Int)) hp3_2_branches805 hp3_2_evidence805 hp3_2_check805 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches805,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node806 T childKnown
theorem hp3_2_node804 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected804 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected804 ((8 : Int),(1 : Int)) hp3_2_branches804 hp3_2_evidence804 hp3_2_check804 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches804,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node805 T childKnown
  · exact hp3_2_node807 T childKnown
  · exact hp3_2_node808 T childKnown
  · exact hp3_2_node809 T childKnown
theorem hp3_2_node803 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected803 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected803 ((8 : Int),(2 : Int)) hp3_2_branches803 hp3_2_evidence803 hp3_2_check803 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches803,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node802 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected802 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected802 ((8 : Int),(2 : Int)) hp3_2_branches802 hp3_2_evidence802 hp3_2_check802 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches802,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node801 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected801 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected801 ((8 : Int),(2 : Int)) hp3_2_branches801 hp3_2_evidence801 hp3_2_check801 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches801,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node800 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected800 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected800 ((8 : Int),(1 : Int)) hp3_2_branches800 hp3_2_evidence800 hp3_2_check800 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches800,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node801 T childKnown
  · exact hp3_2_node802 T childKnown
  · exact hp3_2_node803 T childKnown
theorem hp3_2_node799 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected799 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected799 ((9 : Int),(1 : Int)) hp3_2_branches799 hp3_2_evidence799 hp3_2_check799 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches799,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node798 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected798 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected798 ((8 : Int),(1 : Int)) hp3_2_branches798 hp3_2_evidence798 hp3_2_check798 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches798,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node799 T childKnown
theorem hp3_2_node797 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected797 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected797 ((9 : Int),(1 : Int)) hp3_2_branches797 hp3_2_evidence797 hp3_2_check797 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches797,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node796 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected796 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected796 ((8 : Int),(1 : Int)) hp3_2_branches796 hp3_2_evidence796 hp3_2_check796 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches796,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node797 T childKnown
theorem hp3_2_node795 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected795 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected795 ((8 : Int),(1 : Int)) hp3_2_branches795 hp3_2_evidence795 hp3_2_check795 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches795,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node794 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected794 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected794 ((9 : Int),(0 : Int)) hp3_2_branches794 hp3_2_evidence794 hp3_2_check794 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches794,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node795 T childKnown
  · exact hp3_2_node796 T childKnown
  · exact hp3_2_node798 T childKnown
theorem hp3_2_node793 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected793 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected793 ((6 : Int),(2 : Int)) hp3_2_branches793 hp3_2_evidence793 hp3_2_check793 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches793,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node794 T childKnown
  · exact hp3_2_node800 T childKnown
  · exact hp3_2_node804 T childKnown
theorem hp3_2_node792 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected792 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected792 ((4 : Int),(2 : Int)) hp3_2_branches792 hp3_2_evidence792 hp3_2_check792 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches792,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node793 T childKnown
  · exact hp3_2_node810 T childKnown
  · exact hp3_2_node827 T childKnown
  · exact hp3_2_node828 T childKnown
theorem hp3_2_node791 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected791 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected791 ((4 : Int),(0 : Int)) hp3_2_branches791 hp3_2_evidence791 hp3_2_check791 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches791,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node792 T childKnown
theorem hp3_2_node790 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected790 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected790 ((6 : Int),(1 : Int)) hp3_2_branches790 hp3_2_evidence790 hp3_2_check790 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches790,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node789 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected789 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected789 ((6 : Int),(1 : Int)) hp3_2_branches789 hp3_2_evidence789 hp3_2_check789 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches789,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node788 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected788 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected788 ((5 : Int),(1 : Int)) hp3_2_branches788 hp3_2_evidence788 hp3_2_check788 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches788,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node789 T childKnown
  · exact hp3_2_node790 T childKnown
theorem hp3_2_node787 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected787 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected787 ((7 : Int),(2 : Int)) hp3_2_branches787 hp3_2_evidence787 hp3_2_check787 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches787,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node786 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected786 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected786 ((7 : Int),(2 : Int)) hp3_2_branches786 hp3_2_evidence786 hp3_2_check786 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches786,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node785 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected785 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected785 ((8 : Int),(2 : Int)) hp3_2_branches785 hp3_2_evidence785 hp3_2_check785 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches785,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node784 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected784 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected784 ((8 : Int),(1 : Int)) hp3_2_branches784 hp3_2_evidence784 hp3_2_check784 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches784,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node785 T childKnown
theorem hp3_2_node783 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected783 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected783 ((7 : Int),(1 : Int)) hp3_2_branches783 hp3_2_evidence783 hp3_2_check783 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches783,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node784 T childKnown
  · exact hp3_2_node786 T childKnown
  · exact hp3_2_node787 T childKnown
theorem hp3_2_node782 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected782 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected782 ((5 : Int),(1 : Int)) hp3_2_branches782 hp3_2_evidence782 hp3_2_check782 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches782,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node783 T childKnown
theorem hp3_2_node781 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected781 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected781 ((6 : Int),(1 : Int)) hp3_2_branches781 hp3_2_evidence781 hp3_2_check781 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches781,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node780 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected780 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected780 ((6 : Int),(1 : Int)) hp3_2_branches780 hp3_2_evidence780 hp3_2_check780 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches780,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node779 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected779 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected779 ((6 : Int),(0 : Int)) hp3_2_branches779 hp3_2_evidence779 hp3_2_check779 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches779,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node780 T childKnown
  · exact hp3_2_node781 T childKnown
theorem hp3_2_node778 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected778 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected778 ((11 : Int),(0 : Int)) hp3_2_branches778 hp3_2_evidence778 hp3_2_check778 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches778,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node777 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected777 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected777 ((11 : Int),(0 : Int)) hp3_2_branches777 hp3_2_evidence777 hp3_2_check777 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches777,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node776 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected776 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected776 ((11 : Int),(0 : Int)) hp3_2_branches776 hp3_2_evidence776 hp3_2_check776 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches776,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node775 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected775 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected775 ((11 : Int),(1 : Int)) hp3_2_branches775 hp3_2_evidence775 hp3_2_check775 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches775,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node774 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected774 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected774 ((11 : Int),(1 : Int)) hp3_2_branches774 hp3_2_evidence774 hp3_2_check774 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches774,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node773 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected773 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected773 ((11 : Int),(0 : Int)) hp3_2_branches773 hp3_2_evidence773 hp3_2_check773 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches773,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node774 T childKnown
  · exact hp3_2_node775 T childKnown
theorem hp3_2_node772 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected772 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected772 ((11 : Int),(1 : Int)) hp3_2_branches772 hp3_2_evidence772 hp3_2_check772 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches772,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node771 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected771 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected771 ((11 : Int),(0 : Int)) hp3_2_branches771 hp3_2_evidence771 hp3_2_check771 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches771,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node772 T childKnown
theorem hp3_2_node770 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected770 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected770 ((11 : Int),(0 : Int)) hp3_2_branches770 hp3_2_evidence770 hp3_2_check770 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches770,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node769 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected769 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected769 ((11 : Int),(1 : Int)) hp3_2_branches769 hp3_2_evidence769 hp3_2_check769 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches769,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node770 T childKnown
theorem hp3_2_node768 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected768 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected768 ((10 : Int),(1 : Int)) hp3_2_branches768 hp3_2_evidence768 hp3_2_check768 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches768,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node769 T childKnown
  · exact hp3_2_node771 T childKnown
  · exact hp3_2_node773 T childKnown
  · exact hp3_2_node776 T childKnown
  · exact hp3_2_node777 T childKnown
  · exact hp3_2_node778 T childKnown
theorem hp3_2_node767 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected767 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected767 ((7 : Int),(2 : Int)) hp3_2_branches767 hp3_2_evidence767 hp3_2_check767 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches767,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node766 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected766 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected766 ((7 : Int),(2 : Int)) hp3_2_branches766 hp3_2_evidence766 hp3_2_check766 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches766,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node765 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected765 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected765 ((8 : Int),(1 : Int)) hp3_2_branches765 hp3_2_evidence765 hp3_2_check765 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches765,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node764 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected764 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected764 ((8 : Int),(1 : Int)) hp3_2_branches764 hp3_2_evidence764 hp3_2_check764 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches764,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node763 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected763 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected763 ((7 : Int),(2 : Int)) hp3_2_branches763 hp3_2_evidence763 hp3_2_check763 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches763,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node764 T childKnown
  · exact hp3_2_node765 T childKnown
theorem hp3_2_node762 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected762 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected762 ((6 : Int),(2 : Int)) hp3_2_branches762 hp3_2_evidence762 hp3_2_check762 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches762,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node763 T childKnown
  · exact hp3_2_node766 T childKnown
  · exact hp3_2_node767 T childKnown
  · exact hp3_2_node768 T childKnown
theorem hp3_2_node761 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected761 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected761 ((6 : Int),(0 : Int)) hp3_2_branches761 hp3_2_evidence761 hp3_2_check761 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches761,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node762 T childKnown
theorem hp3_2_node760 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected760 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected760 ((5 : Int),(0 : Int)) hp3_2_branches760 hp3_2_evidence760 hp3_2_check760 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches760,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node761 T childKnown
  · exact hp3_2_node779 T childKnown
  · exact hp3_2_node782 T childKnown
  · exact hp3_2_node788 T childKnown
theorem hp3_2_node759 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected759 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected759 ((2 : Int),(1 : Int)) hp3_2_branches759 hp3_2_evidence759 hp3_2_check759 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches759,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node760 T childKnown
  · exact hp3_2_node791 T childKnown
theorem hp3_2_node758 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected758 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected758 ((2 : Int),(2 : Int)) hp3_2_branches758 hp3_2_evidence758 hp3_2_check758 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches758,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node757 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected757 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected757 ((2 : Int),(1 : Int)) hp3_2_branches757 hp3_2_evidence757 hp3_2_check757 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches757,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node758 T childKnown
theorem hp3_2_node756 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected756 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected756 ((3 : Int),(2 : Int)) hp3_2_branches756 hp3_2_evidence756 hp3_2_check756 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches756,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node755 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected755 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected755 ((3 : Int),(2 : Int)) hp3_2_branches755 hp3_2_evidence755 hp3_2_check755 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches755,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node754 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected754 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected754 ((2 : Int),(2 : Int)) hp3_2_branches754 hp3_2_evidence754 hp3_2_check754 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches754,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node755 T childKnown
  · exact hp3_2_node756 T childKnown
theorem hp3_2_node753 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected753 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected753 ((4 : Int),(0 : Int)) hp3_2_branches753 hp3_2_evidence753 hp3_2_check753 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches753,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node754 T childKnown
theorem hp3_2_node752 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected752 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected752 ((3 : Int),(2 : Int)) hp3_2_branches752 hp3_2_evidence752 hp3_2_check752 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches752,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node751 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected751 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected751 ((2 : Int),(2 : Int)) hp3_2_branches751 hp3_2_evidence751 hp3_2_check751 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches751,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node752 T childKnown
theorem hp3_2_node750 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected750 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected750 ((5 : Int),(2 : Int)) hp3_2_branches750 hp3_2_evidence750 hp3_2_check750 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches750,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node749 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected749 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected749 ((4 : Int),(2 : Int)) hp3_2_branches749 hp3_2_evidence749 hp3_2_check749 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches749,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node750 T childKnown
theorem hp3_2_node748 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected748 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected748 ((4 : Int),(0 : Int)) hp3_2_branches748 hp3_2_evidence748 hp3_2_check748 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches748,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node749 T childKnown
theorem hp3_2_node747 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected747 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected747 ((2 : Int),(2 : Int)) hp3_2_branches747 hp3_2_evidence747 hp3_2_check747 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches747,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node748 T childKnown
theorem hp3_2_node746 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected746 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected746 ((3 : Int),(2 : Int)) hp3_2_branches746 hp3_2_evidence746 hp3_2_check746 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches746,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node745 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected745 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected745 ((3 : Int),(2 : Int)) hp3_2_branches745 hp3_2_evidence745 hp3_2_check745 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches745,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node744 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected744 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected744 ((3 : Int),(2 : Int)) hp3_2_branches744 hp3_2_evidence744 hp3_2_check744 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches744,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node743 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected743 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected743 ((3 : Int),(1 : Int)) hp3_2_branches743 hp3_2_evidence743 hp3_2_check743 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches743,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node744 T childKnown
  · exact hp3_2_node745 T childKnown
  · exact hp3_2_node746 T childKnown
theorem hp3_2_node742 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected742 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected742 ((4 : Int),(0 : Int)) hp3_2_branches742 hp3_2_evidence742 hp3_2_check742 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches742,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node741 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected741 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected741 ((4 : Int),(0 : Int)) hp3_2_branches741 hp3_2_evidence741 hp3_2_check741 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches741,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node740 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected740 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected740 ((3 : Int),(1 : Int)) hp3_2_branches740 hp3_2_evidence740 hp3_2_check740 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches740,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node741 T childKnown
  · exact hp3_2_node742 T childKnown
theorem hp3_2_node739 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected739 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected739 ((2 : Int),(1 : Int)) hp3_2_branches739 hp3_2_evidence739 hp3_2_check739 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches739,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node740 T childKnown
  · exact hp3_2_node743 T childKnown
  · exact hp3_2_node747 T childKnown
  · exact hp3_2_node751 T childKnown
  · exact hp3_2_node753 T childKnown
theorem hp3_2_node738 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected738 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected738 ((2 : Int),(2 : Int)) hp3_2_branches738 hp3_2_evidence738 hp3_2_check738 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches738,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node737 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected737 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected737 ((2 : Int),(2 : Int)) hp3_2_branches737 hp3_2_evidence737 hp3_2_check737 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches737,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node736 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected736 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected736 ((2 : Int),(2 : Int)) hp3_2_branches736 hp3_2_evidence736 hp3_2_check736 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches736,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node735 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected735 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected735 ((2 : Int),(1 : Int)) hp3_2_branches735 hp3_2_evidence735 hp3_2_check735 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches735,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node736 T childKnown
  · exact hp3_2_node737 T childKnown
  · exact hp3_2_node738 T childKnown
theorem hp3_2_node734 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected734 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected734 ((1 : Int),(1 : Int)) hp3_2_branches734 hp3_2_evidence734 hp3_2_check734 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches734,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node735 T childKnown
  · exact hp3_2_node739 T childKnown
  · exact hp3_2_node757 T childKnown
  · exact hp3_2_node759 T childKnown
  · exact hp3_2_node835 T childKnown
  · exact hp3_2_node839 T childKnown
  · exact hp3_2_node935 T childKnown
theorem hp3_2_node733 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected733 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected733 ((2 : Int),(1 : Int)) hp3_2_branches733 hp3_2_evidence733 hp3_2_check733 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches733,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node732 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected732 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected732 ((2 : Int),(1 : Int)) hp3_2_branches732 hp3_2_evidence732 hp3_2_check732 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches732,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node731 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected731 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected731 ((1 : Int),(1 : Int)) hp3_2_branches731 hp3_2_evidence731 hp3_2_check731 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches731,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node732 T childKnown
  · exact hp3_2_node733 T childKnown
theorem hp3_2_node730 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected730 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected730 ((3 : Int),(2 : Int)) hp3_2_branches730 hp3_2_evidence730 hp3_2_check730 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches730,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node729 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected729 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected729 ((3 : Int),(2 : Int)) hp3_2_branches729 hp3_2_evidence729 hp3_2_check729 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches729,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node728 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected728 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected728 ((4 : Int),(2 : Int)) hp3_2_branches728 hp3_2_evidence728 hp3_2_check728 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches728,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node727 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected727 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected727 ((4 : Int),(1 : Int)) hp3_2_branches727 hp3_2_evidence727 hp3_2_check727 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches727,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node728 T childKnown
theorem hp3_2_node726 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected726 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected726 ((3 : Int),(1 : Int)) hp3_2_branches726 hp3_2_evidence726 hp3_2_check726 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches726,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node727 T childKnown
  · exact hp3_2_node729 T childKnown
  · exact hp3_2_node730 T childKnown
theorem hp3_2_node725 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected725 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected725 ((1 : Int),(1 : Int)) hp3_2_branches725 hp3_2_evidence725 hp3_2_check725 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches725,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node726 T childKnown
theorem hp3_2_node724 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected724 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected724 ((2 : Int),(1 : Int)) hp3_2_branches724 hp3_2_evidence724 hp3_2_check724 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches724,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node723 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected723 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected723 ((2 : Int),(1 : Int)) hp3_2_branches723 hp3_2_evidence723 hp3_2_check723 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches723,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node722 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected722 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected722 ((2 : Int),(0 : Int)) hp3_2_branches722 hp3_2_evidence722 hp3_2_check722 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches722,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node723 T childKnown
  · exact hp3_2_node724 T childKnown
theorem hp3_2_node721 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected721 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected721 ((7 : Int),(0 : Int)) hp3_2_branches721 hp3_2_evidence721 hp3_2_check721 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches721,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node720 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected720 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected720 ((7 : Int),(0 : Int)) hp3_2_branches720 hp3_2_evidence720 hp3_2_check720 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches720,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node719 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected719 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected719 ((7 : Int),(0 : Int)) hp3_2_branches719 hp3_2_evidence719 hp3_2_check719 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches719,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node718 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected718 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected718 ((7 : Int),(1 : Int)) hp3_2_branches718 hp3_2_evidence718 hp3_2_check718 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches718,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node717 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected717 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected717 ((7 : Int),(1 : Int)) hp3_2_branches717 hp3_2_evidence717 hp3_2_check717 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches717,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node716 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected716 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected716 ((7 : Int),(0 : Int)) hp3_2_branches716 hp3_2_evidence716 hp3_2_check716 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches716,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node717 T childKnown
  · exact hp3_2_node718 T childKnown
theorem hp3_2_node715 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected715 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected715 ((7 : Int),(1 : Int)) hp3_2_branches715 hp3_2_evidence715 hp3_2_check715 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches715,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node714 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected714 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected714 ((7 : Int),(0 : Int)) hp3_2_branches714 hp3_2_evidence714 hp3_2_check714 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches714,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node715 T childKnown
theorem hp3_2_node713 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected713 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected713 ((7 : Int),(0 : Int)) hp3_2_branches713 hp3_2_evidence713 hp3_2_check713 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches713,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node712 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected712 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected712 ((7 : Int),(1 : Int)) hp3_2_branches712 hp3_2_evidence712 hp3_2_check712 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches712,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node713 T childKnown
theorem hp3_2_node711 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected711 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected711 ((6 : Int),(1 : Int)) hp3_2_branches711 hp3_2_evidence711 hp3_2_check711 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches711,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node712 T childKnown
  · exact hp3_2_node714 T childKnown
  · exact hp3_2_node716 T childKnown
  · exact hp3_2_node719 T childKnown
  · exact hp3_2_node720 T childKnown
  · exact hp3_2_node721 T childKnown
theorem hp3_2_node710 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected710 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected710 ((3 : Int),(2 : Int)) hp3_2_branches710 hp3_2_evidence710 hp3_2_check710 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches710,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node709 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected709 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected709 ((3 : Int),(2 : Int)) hp3_2_branches709 hp3_2_evidence709 hp3_2_check709 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches709,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node708 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected708 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected708 ((4 : Int),(1 : Int)) hp3_2_branches708 hp3_2_evidence708 hp3_2_check708 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches708,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node707 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected707 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected707 ((4 : Int),(1 : Int)) hp3_2_branches707 hp3_2_evidence707 hp3_2_check707 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches707,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node706 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected706 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected706 ((3 : Int),(2 : Int)) hp3_2_branches706 hp3_2_evidence706 hp3_2_check706 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches706,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node707 T childKnown
  · exact hp3_2_node708 T childKnown
theorem hp3_2_node705 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected705 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected705 ((2 : Int),(2 : Int)) hp3_2_branches705 hp3_2_evidence705 hp3_2_check705 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches705,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node706 T childKnown
  · exact hp3_2_node709 T childKnown
  · exact hp3_2_node710 T childKnown
  · exact hp3_2_node711 T childKnown
theorem hp3_2_node704 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected704 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected704 ((2 : Int),(0 : Int)) hp3_2_branches704 hp3_2_evidence704 hp3_2_check704 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches704,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node705 T childKnown
theorem hp3_2_node703 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected703 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected703 ((1 : Int),(0 : Int)) hp3_2_branches703 hp3_2_evidence703 hp3_2_check703 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches703,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node704 T childKnown
  · exact hp3_2_node722 T childKnown
  · exact hp3_2_node725 T childKnown
  · exact hp3_2_node731 T childKnown
theorem hp3_2_node702 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected702 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected702 ((2 : Int),(1 : Int)) hp3_2_branches702 hp3_2_evidence702 hp3_2_check702 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches702,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node701 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected701 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected701 ((2 : Int),(1 : Int)) hp3_2_branches701 hp3_2_evidence701 hp3_2_check701 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches701,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node700 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected700 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected700 ((1 : Int),(1 : Int)) hp3_2_branches700 hp3_2_evidence700 hp3_2_check700 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches700,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node701 T childKnown
  · exact hp3_2_node702 T childKnown
theorem hp3_2_node699 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected699 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected699 ((3 : Int),(2 : Int)) hp3_2_branches699 hp3_2_evidence699 hp3_2_check699 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches699,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node698 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected698 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected698 ((3 : Int),(2 : Int)) hp3_2_branches698 hp3_2_evidence698 hp3_2_check698 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches698,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node697 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected697 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected697 ((4 : Int),(2 : Int)) hp3_2_branches697 hp3_2_evidence697 hp3_2_check697 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches697,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node696 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected696 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected696 ((4 : Int),(1 : Int)) hp3_2_branches696 hp3_2_evidence696 hp3_2_check696 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches696,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node697 T childKnown
theorem hp3_2_node695 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected695 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected695 ((3 : Int),(1 : Int)) hp3_2_branches695 hp3_2_evidence695 hp3_2_check695 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches695,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node696 T childKnown
  · exact hp3_2_node698 T childKnown
  · exact hp3_2_node699 T childKnown
theorem hp3_2_node694 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected694 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected694 ((1 : Int),(1 : Int)) hp3_2_branches694 hp3_2_evidence694 hp3_2_check694 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches694,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node695 T childKnown
theorem hp3_2_node693 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected693 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected693 ((2 : Int),(1 : Int)) hp3_2_branches693 hp3_2_evidence693 hp3_2_check693 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches693,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node692 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected692 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected692 ((2 : Int),(1 : Int)) hp3_2_branches692 hp3_2_evidence692 hp3_2_check692 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches692,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node691 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected691 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected691 ((2 : Int),(0 : Int)) hp3_2_branches691 hp3_2_evidence691 hp3_2_check691 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches691,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node692 T childKnown
  · exact hp3_2_node693 T childKnown
theorem hp3_2_node690 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected690 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected690 ((7 : Int),(0 : Int)) hp3_2_branches690 hp3_2_evidence690 hp3_2_check690 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches690,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node689 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected689 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected689 ((7 : Int),(0 : Int)) hp3_2_branches689 hp3_2_evidence689 hp3_2_check689 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches689,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node688 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected688 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected688 ((7 : Int),(0 : Int)) hp3_2_branches688 hp3_2_evidence688 hp3_2_check688 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches688,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node687 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected687 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected687 ((7 : Int),(1 : Int)) hp3_2_branches687 hp3_2_evidence687 hp3_2_check687 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches687,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node686 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected686 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected686 ((7 : Int),(1 : Int)) hp3_2_branches686 hp3_2_evidence686 hp3_2_check686 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches686,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node685 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected685 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected685 ((7 : Int),(0 : Int)) hp3_2_branches685 hp3_2_evidence685 hp3_2_check685 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches685,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node686 T childKnown
  · exact hp3_2_node687 T childKnown
theorem hp3_2_node684 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected684 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected684 ((7 : Int),(1 : Int)) hp3_2_branches684 hp3_2_evidence684 hp3_2_check684 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches684,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node683 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected683 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected683 ((7 : Int),(0 : Int)) hp3_2_branches683 hp3_2_evidence683 hp3_2_check683 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches683,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node684 T childKnown
theorem hp3_2_node682 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected682 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected682 ((7 : Int),(0 : Int)) hp3_2_branches682 hp3_2_evidence682 hp3_2_check682 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches682,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node681 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected681 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected681 ((7 : Int),(1 : Int)) hp3_2_branches681 hp3_2_evidence681 hp3_2_check681 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches681,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node682 T childKnown
theorem hp3_2_node680 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected680 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected680 ((6 : Int),(1 : Int)) hp3_2_branches680 hp3_2_evidence680 hp3_2_check680 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches680,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node681 T childKnown
  · exact hp3_2_node683 T childKnown
  · exact hp3_2_node685 T childKnown
  · exact hp3_2_node688 T childKnown
  · exact hp3_2_node689 T childKnown
  · exact hp3_2_node690 T childKnown
theorem hp3_2_node679 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected679 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected679 ((3 : Int),(2 : Int)) hp3_2_branches679 hp3_2_evidence679 hp3_2_check679 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches679,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node678 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected678 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected678 ((3 : Int),(2 : Int)) hp3_2_branches678 hp3_2_evidence678 hp3_2_check678 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches678,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node677 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected677 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected677 ((4 : Int),(1 : Int)) hp3_2_branches677 hp3_2_evidence677 hp3_2_check677 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches677,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node676 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected676 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected676 ((4 : Int),(1 : Int)) hp3_2_branches676 hp3_2_evidence676 hp3_2_check676 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches676,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node675 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected675 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected675 ((3 : Int),(2 : Int)) hp3_2_branches675 hp3_2_evidence675 hp3_2_check675 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches675,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node676 T childKnown
  · exact hp3_2_node677 T childKnown
theorem hp3_2_node674 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected674 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected674 ((2 : Int),(2 : Int)) hp3_2_branches674 hp3_2_evidence674 hp3_2_check674 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches674,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node675 T childKnown
  · exact hp3_2_node678 T childKnown
  · exact hp3_2_node679 T childKnown
  · exact hp3_2_node680 T childKnown
theorem hp3_2_node673 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected673 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected673 ((2 : Int),(0 : Int)) hp3_2_branches673 hp3_2_evidence673 hp3_2_check673 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches673,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node674 T childKnown
theorem hp3_2_node672 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected672 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected672 ((1 : Int),(0 : Int)) hp3_2_branches672 hp3_2_evidence672 hp3_2_check672 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches672,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node673 T childKnown
  · exact hp3_2_node691 T childKnown
  · exact hp3_2_node694 T childKnown
  · exact hp3_2_node700 T childKnown
theorem hp3_2_node671 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected671 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected671 ((3 : Int),(1 : Int)) hp3_2_branches671 hp3_2_evidence671 hp3_2_check671 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches671,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node670 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected670 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected670 ((3 : Int),(1 : Int)) hp3_2_branches670 hp3_2_evidence670 hp3_2_check670 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches670,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node669 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected669 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected669 ((3 : Int),(1 : Int)) hp3_2_branches669 hp3_2_evidence669 hp3_2_check669 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches669,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node668 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected668 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected668 ((4 : Int),(1 : Int)) hp3_2_branches668 hp3_2_evidence668 hp3_2_check668 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches668,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node667 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected667 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected667 ((4 : Int),(1 : Int)) hp3_2_branches667 hp3_2_evidence667 hp3_2_check667 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches667,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node666 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected666 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected666 ((3 : Int),(1 : Int)) hp3_2_branches666 hp3_2_evidence666 hp3_2_check666 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches666,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node667 T childKnown
  · exact hp3_2_node668 T childKnown
theorem hp3_2_node665 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected665 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected665 ((3 : Int),(1 : Int)) hp3_2_branches665 hp3_2_evidence665 hp3_2_check665 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches665,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node664 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected664 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected664 ((2 : Int),(1 : Int)) hp3_2_branches664 hp3_2_evidence664 hp3_2_check664 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches664,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node665 T childKnown
  · exact hp3_2_node666 T childKnown
  · exact hp3_2_node669 T childKnown
  · exact hp3_2_node670 T childKnown
  · exact hp3_2_node671 T childKnown
theorem hp3_2_node663 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected663 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected663 ((3 : Int),(1 : Int)) hp3_2_branches663 hp3_2_evidence663 hp3_2_check663 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches663,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node662 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected662 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected662 ((3 : Int),(1 : Int)) hp3_2_branches662 hp3_2_evidence662 hp3_2_check662 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches662,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node661 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected661 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected661 ((5 : Int),(2 : Int)) hp3_2_branches661 hp3_2_evidence661 hp3_2_check661 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches661,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node660 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected660 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected660 ((5 : Int),(2 : Int)) hp3_2_branches660 hp3_2_evidence660 hp3_2_check660 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches660,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node659 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected659 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected659 ((6 : Int),(2 : Int)) hp3_2_branches659 hp3_2_evidence659 hp3_2_check659 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches659,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node658 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected658 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected658 ((6 : Int),(1 : Int)) hp3_2_branches658 hp3_2_evidence658 hp3_2_check658 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches658,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node659 T childKnown
theorem hp3_2_node657 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected657 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected657 ((5 : Int),(1 : Int)) hp3_2_branches657 hp3_2_evidence657 hp3_2_check657 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches657,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node658 T childKnown
  · exact hp3_2_node660 T childKnown
  · exact hp3_2_node661 T childKnown
theorem hp3_2_node656 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected656 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected656 ((0 : Int),(2 : Int)) hp3_2_branches656 hp3_2_evidence656 hp3_2_check656 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches656,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node655 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected655 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected655 ((0 : Int),(2 : Int)) hp3_2_branches655 hp3_2_evidence655 hp3_2_check655 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches655,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node654 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected654 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected654 ((0 : Int),(1 : Int)) hp3_2_branches654 hp3_2_evidence654 hp3_2_check654 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches654,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node655 T childKnown
  · exact hp3_2_node656 T childKnown
  · exact hp3_2_node657 T childKnown
theorem hp3_2_node653 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected653 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected653 ((3 : Int),(1 : Int)) hp3_2_branches653 hp3_2_evidence653 hp3_2_check653 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches653,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node654 T childKnown
theorem hp3_2_node652 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected652 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected652 ((3 : Int),(1 : Int)) hp3_2_branches652 hp3_2_evidence652 hp3_2_check652 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches652,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node651 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected651 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected651 ((2 : Int),(1 : Int)) hp3_2_branches651 hp3_2_evidence651 hp3_2_check651 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches651,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node652 T childKnown
  · exact hp3_2_node653 T childKnown
  · exact hp3_2_node662 T childKnown
  · exact hp3_2_node663 T childKnown
theorem hp3_2_node650 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected650 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected650 ((4 : Int),(1 : Int)) hp3_2_branches650 hp3_2_evidence650 hp3_2_check650 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches650,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node649 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected649 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected649 ((4 : Int),(1 : Int)) hp3_2_branches649 hp3_2_evidence649 hp3_2_check649 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches649,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node648 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected648 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected648 ((4 : Int),(0 : Int)) hp3_2_branches648 hp3_2_evidence648 hp3_2_check648 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches648,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node649 T childKnown
  · exact hp3_2_node650 T childKnown
theorem hp3_2_node647 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected647 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected647 ((2 : Int),(1 : Int)) hp3_2_branches647 hp3_2_evidence647 hp3_2_check647 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches647,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node648 T childKnown
theorem hp3_2_node646 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected646 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected646 ((9 : Int),(0 : Int)) hp3_2_branches646 hp3_2_evidence646 hp3_2_check646 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches646,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node645 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected645 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected645 ((9 : Int),(0 : Int)) hp3_2_branches645 hp3_2_evidence645 hp3_2_check645 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches645,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node644 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected644 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected644 ((9 : Int),(0 : Int)) hp3_2_branches644 hp3_2_evidence644 hp3_2_check644 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches644,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node643 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected643 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected643 ((9 : Int),(1 : Int)) hp3_2_branches643 hp3_2_evidence643 hp3_2_check643 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches643,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node642 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected642 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected642 ((9 : Int),(1 : Int)) hp3_2_branches642 hp3_2_evidence642 hp3_2_check642 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches642,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node641 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected641 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected641 ((9 : Int),(0 : Int)) hp3_2_branches641 hp3_2_evidence641 hp3_2_check641 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches641,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node642 T childKnown
  · exact hp3_2_node643 T childKnown
theorem hp3_2_node640 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected640 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected640 ((9 : Int),(1 : Int)) hp3_2_branches640 hp3_2_evidence640 hp3_2_check640 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches640,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node639 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected639 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected639 ((9 : Int),(0 : Int)) hp3_2_branches639 hp3_2_evidence639 hp3_2_check639 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches639,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node640 T childKnown
theorem hp3_2_node638 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected638 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected638 ((9 : Int),(0 : Int)) hp3_2_branches638 hp3_2_evidence638 hp3_2_check638 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches638,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node637 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected637 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected637 ((9 : Int),(1 : Int)) hp3_2_branches637 hp3_2_evidence637 hp3_2_check637 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches637,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node638 T childKnown
theorem hp3_2_node636 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected636 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected636 ((8 : Int),(1 : Int)) hp3_2_branches636 hp3_2_evidence636 hp3_2_check636 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches636,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node637 T childKnown
  · exact hp3_2_node639 T childKnown
  · exact hp3_2_node641 T childKnown
  · exact hp3_2_node644 T childKnown
  · exact hp3_2_node645 T childKnown
  · exact hp3_2_node646 T childKnown
theorem hp3_2_node635 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected635 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected635 ((5 : Int),(2 : Int)) hp3_2_branches635 hp3_2_evidence635 hp3_2_check635 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches635,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node634 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected634 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected634 ((5 : Int),(2 : Int)) hp3_2_branches634 hp3_2_evidence634 hp3_2_check634 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches634,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node633 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected633 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected633 ((4 : Int),(2 : Int)) hp3_2_branches633 hp3_2_evidence633 hp3_2_check633 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches633,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node634 T childKnown
  · exact hp3_2_node635 T childKnown
  · exact hp3_2_node636 T childKnown
theorem hp3_2_node632 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected632 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected632 ((0 : Int),(2 : Int)) hp3_2_branches632 hp3_2_evidence632 hp3_2_check632 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches632,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node631 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected631 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected631 ((0 : Int),(2 : Int)) hp3_2_branches631 hp3_2_evidence631 hp3_2_check631 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches631,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node630 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected630 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected630 ((0 : Int),(1 : Int)) hp3_2_branches630 hp3_2_evidence630 hp3_2_check630 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches630,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node631 T childKnown
  · exact hp3_2_node632 T childKnown
  · exact hp3_2_node633 T childKnown
theorem hp3_2_node629 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected629 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected629 ((4 : Int),(0 : Int)) hp3_2_branches629 hp3_2_evidence629 hp3_2_check629 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches629,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node630 T childKnown
theorem hp3_2_node628 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected628 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected628 ((2 : Int),(1 : Int)) hp3_2_branches628 hp3_2_evidence628 hp3_2_check628 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches628,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node629 T childKnown
theorem hp3_2_node627 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected627 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected627 ((2 : Int),(1 : Int)) hp3_2_branches627 hp3_2_evidence627 hp3_2_check627 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches627,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node626 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected626 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected626 ((2 : Int),(1 : Int)) hp3_2_branches626 hp3_2_evidence626 hp3_2_check626 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches626,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node625 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected625 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected625 ((3 : Int),(0 : Int)) hp3_2_branches625 hp3_2_evidence625 hp3_2_check625 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches625,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node626 T childKnown
  · exact hp3_2_node627 T childKnown
  · exact hp3_2_node628 T childKnown
  · exact hp3_2_node647 T childKnown
  · exact hp3_2_node651 T childKnown
  · exact hp3_2_node664 T childKnown
theorem hp3_2_node624 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected624 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected624 ((0 : Int),(2 : Int)) hp3_2_branches624 hp3_2_evidence624 hp3_2_check624 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches624,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node623 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected623 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected623 ((2 : Int),(2 : Int)) hp3_2_branches623 hp3_2_evidence623 hp3_2_check623 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches623,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node624 T childKnown
theorem hp3_2_node622 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected622 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected622 ((4 : Int),(2 : Int)) hp3_2_branches622 hp3_2_evidence622 hp3_2_check622 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches622,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node623 T childKnown
theorem hp3_2_node621 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected621 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected621 ((4 : Int),(2 : Int)) hp3_2_branches621 hp3_2_evidence621 hp3_2_check621 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches621,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node620 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected620 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected620 ((4 : Int),(2 : Int)) hp3_2_branches620 hp3_2_evidence620 hp3_2_check620 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches620,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node619 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected619 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected619 ((5 : Int),(1 : Int)) hp3_2_branches619 hp3_2_evidence619 hp3_2_check619 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches619,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node620 T childKnown
  · exact hp3_2_node621 T childKnown
  · exact hp3_2_node622 T childKnown
theorem hp3_2_node618 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected618 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected618 ((3 : Int),(0 : Int)) hp3_2_branches618 hp3_2_evidence618 hp3_2_check618 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches618,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node619 T childKnown
theorem hp3_2_node617 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected617 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected617 ((3 : Int),(2 : Int)) hp3_2_branches617 hp3_2_evidence617 hp3_2_check617 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches617,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node616 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected616 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected616 ((2 : Int),(2 : Int)) hp3_2_branches616 hp3_2_evidence616 hp3_2_check616 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches616,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node617 T childKnown
theorem hp3_2_node615 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected615 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected615 ((2 : Int),(2 : Int)) hp3_2_branches615 hp3_2_evidence615 hp3_2_check615 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches615,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node614 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected614 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected614 ((8 : Int),(0 : Int)) hp3_2_branches614 hp3_2_evidence614 hp3_2_check614 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches614,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node613 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected613 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected613 ((8 : Int),(0 : Int)) hp3_2_branches613 hp3_2_evidence613 hp3_2_check613 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches613,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node612 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected612 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected612 ((8 : Int),(0 : Int)) hp3_2_branches612 hp3_2_evidence612 hp3_2_check612 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches612,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node611 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected611 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected611 ((8 : Int),(1 : Int)) hp3_2_branches611 hp3_2_evidence611 hp3_2_check611 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches611,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node610 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected610 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected610 ((8 : Int),(1 : Int)) hp3_2_branches610 hp3_2_evidence610 hp3_2_check610 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches610,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node609 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected609 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected609 ((8 : Int),(0 : Int)) hp3_2_branches609 hp3_2_evidence609 hp3_2_check609 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches609,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node610 T childKnown
  · exact hp3_2_node611 T childKnown
theorem hp3_2_node608 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected608 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected608 ((8 : Int),(1 : Int)) hp3_2_branches608 hp3_2_evidence608 hp3_2_check608 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches608,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node607 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected607 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected607 ((8 : Int),(0 : Int)) hp3_2_branches607 hp3_2_evidence607 hp3_2_check607 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches607,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node608 T childKnown
theorem hp3_2_node606 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected606 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected606 ((8 : Int),(0 : Int)) hp3_2_branches606 hp3_2_evidence606 hp3_2_check606 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches606,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node605 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected605 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected605 ((8 : Int),(1 : Int)) hp3_2_branches605 hp3_2_evidence605 hp3_2_check605 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches605,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node606 T childKnown
theorem hp3_2_node604 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected604 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected604 ((7 : Int),(1 : Int)) hp3_2_branches604 hp3_2_evidence604 hp3_2_check604 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches604,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node605 T childKnown
  · exact hp3_2_node607 T childKnown
  · exact hp3_2_node609 T childKnown
  · exact hp3_2_node612 T childKnown
  · exact hp3_2_node613 T childKnown
  · exact hp3_2_node614 T childKnown
theorem hp3_2_node603 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected603 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected603 ((3 : Int),(2 : Int)) hp3_2_branches603 hp3_2_evidence603 hp3_2_check603 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches603,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node604 T childKnown
theorem hp3_2_node602 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected602 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected602 ((8 : Int),(0 : Int)) hp3_2_branches602 hp3_2_evidence602 hp3_2_check602 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches602,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node601 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected601 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected601 ((8 : Int),(0 : Int)) hp3_2_branches601 hp3_2_evidence601 hp3_2_check601 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches601,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node600 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected600 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected600 ((8 : Int),(0 : Int)) hp3_2_branches600 hp3_2_evidence600 hp3_2_check600 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches600,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node599 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected599 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected599 ((8 : Int),(1 : Int)) hp3_2_branches599 hp3_2_evidence599 hp3_2_check599 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches599,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node598 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected598 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected598 ((8 : Int),(1 : Int)) hp3_2_branches598 hp3_2_evidence598 hp3_2_check598 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches598,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node597 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected597 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected597 ((8 : Int),(0 : Int)) hp3_2_branches597 hp3_2_evidence597 hp3_2_check597 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches597,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node598 T childKnown
  · exact hp3_2_node599 T childKnown
theorem hp3_2_node596 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected596 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected596 ((8 : Int),(1 : Int)) hp3_2_branches596 hp3_2_evidence596 hp3_2_check596 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches596,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node595 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected595 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected595 ((8 : Int),(0 : Int)) hp3_2_branches595 hp3_2_evidence595 hp3_2_check595 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches595,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node596 T childKnown
theorem hp3_2_node594 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected594 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected594 ((8 : Int),(0 : Int)) hp3_2_branches594 hp3_2_evidence594 hp3_2_check594 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches594,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node593 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected593 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected593 ((8 : Int),(1 : Int)) hp3_2_branches593 hp3_2_evidence593 hp3_2_check593 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches593,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node594 T childKnown
theorem hp3_2_node592 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected592 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected592 ((7 : Int),(1 : Int)) hp3_2_branches592 hp3_2_evidence592 hp3_2_check592 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches592,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node593 T childKnown
  · exact hp3_2_node595 T childKnown
  · exact hp3_2_node597 T childKnown
  · exact hp3_2_node600 T childKnown
  · exact hp3_2_node601 T childKnown
  · exact hp3_2_node602 T childKnown
theorem hp3_2_node591 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected591 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected591 ((3 : Int),(2 : Int)) hp3_2_branches591 hp3_2_evidence591 hp3_2_check591 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches591,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node592 T childKnown
theorem hp3_2_node590 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected590 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected590 ((3 : Int),(2 : Int)) hp3_2_branches590 hp3_2_evidence590 hp3_2_check590 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches590,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node589 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected589 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected589 ((2 : Int),(2 : Int)) hp3_2_branches589 hp3_2_evidence589 hp3_2_check589 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches589,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node590 T childKnown
  · exact hp3_2_node591 T childKnown
  · exact hp3_2_node603 T childKnown
theorem hp3_2_node588 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected588 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected588 ((8 : Int),(0 : Int)) hp3_2_branches588 hp3_2_evidence588 hp3_2_check588 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches588,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node587 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected587 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected587 ((8 : Int),(0 : Int)) hp3_2_branches587 hp3_2_evidence587 hp3_2_check587 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node586 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected586 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected586 ((8 : Int),(0 : Int)) hp3_2_branches586 hp3_2_evidence586 hp3_2_check586 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches586,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node585 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected585 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected585 ((8 : Int),(1 : Int)) hp3_2_branches585 hp3_2_evidence585 hp3_2_check585 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches585,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node584 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected584 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected584 ((8 : Int),(1 : Int)) hp3_2_branches584 hp3_2_evidence584 hp3_2_check584 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches584,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node583 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected583 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected583 ((8 : Int),(0 : Int)) hp3_2_branches583 hp3_2_evidence583 hp3_2_check583 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches583,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node584 T childKnown
  · exact hp3_2_node585 T childKnown
theorem hp3_2_node582 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected582 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected582 ((8 : Int),(1 : Int)) hp3_2_branches582 hp3_2_evidence582 hp3_2_check582 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches582,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node581 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected581 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected581 ((8 : Int),(0 : Int)) hp3_2_branches581 hp3_2_evidence581 hp3_2_check581 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches581,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node582 T childKnown
theorem hp3_2_node580 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected580 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected580 ((8 : Int),(0 : Int)) hp3_2_branches580 hp3_2_evidence580 hp3_2_check580 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches580,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node579 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected579 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected579 ((8 : Int),(1 : Int)) hp3_2_branches579 hp3_2_evidence579 hp3_2_check579 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches579,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node580 T childKnown
theorem hp3_2_node578 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected578 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected578 ((7 : Int),(1 : Int)) hp3_2_branches578 hp3_2_evidence578 hp3_2_check578 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches578,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node579 T childKnown
  · exact hp3_2_node581 T childKnown
  · exact hp3_2_node583 T childKnown
  · exact hp3_2_node586 T childKnown
  · exact hp3_2_node587 T childKnown
  · exact hp3_2_node588 T childKnown
theorem hp3_2_node577 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected577 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected577 ((3 : Int),(2 : Int)) hp3_2_branches577 hp3_2_evidence577 hp3_2_check577 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches577,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node578 T childKnown
theorem hp3_2_node576 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected576 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected576 ((8 : Int),(0 : Int)) hp3_2_branches576 hp3_2_evidence576 hp3_2_check576 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches576,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node575 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected575 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected575 ((8 : Int),(0 : Int)) hp3_2_branches575 hp3_2_evidence575 hp3_2_check575 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node574 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected574 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected574 ((8 : Int),(0 : Int)) hp3_2_branches574 hp3_2_evidence574 hp3_2_check574 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches574,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node573 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected573 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected573 ((8 : Int),(1 : Int)) hp3_2_branches573 hp3_2_evidence573 hp3_2_check573 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches573,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node572 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected572 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected572 ((8 : Int),(1 : Int)) hp3_2_branches572 hp3_2_evidence572 hp3_2_check572 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches572,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node571 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected571 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected571 ((8 : Int),(0 : Int)) hp3_2_branches571 hp3_2_evidence571 hp3_2_check571 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches571,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node572 T childKnown
  · exact hp3_2_node573 T childKnown
theorem hp3_2_node570 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected570 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected570 ((8 : Int),(1 : Int)) hp3_2_branches570 hp3_2_evidence570 hp3_2_check570 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches570,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node569 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected569 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected569 ((8 : Int),(0 : Int)) hp3_2_branches569 hp3_2_evidence569 hp3_2_check569 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches569,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node570 T childKnown
theorem hp3_2_node568 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected568 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected568 ((8 : Int),(0 : Int)) hp3_2_branches568 hp3_2_evidence568 hp3_2_check568 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches568,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node567 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected567 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected567 ((8 : Int),(1 : Int)) hp3_2_branches567 hp3_2_evidence567 hp3_2_check567 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches567,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node568 T childKnown
theorem hp3_2_node566 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected566 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected566 ((7 : Int),(1 : Int)) hp3_2_branches566 hp3_2_evidence566 hp3_2_check566 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches566,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node567 T childKnown
  · exact hp3_2_node569 T childKnown
  · exact hp3_2_node571 T childKnown
  · exact hp3_2_node574 T childKnown
  · exact hp3_2_node575 T childKnown
  · exact hp3_2_node576 T childKnown
theorem hp3_2_node565 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected565 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected565 ((3 : Int),(2 : Int)) hp3_2_branches565 hp3_2_evidence565 hp3_2_check565 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches565,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node566 T childKnown
theorem hp3_2_node564 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected564 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected564 ((3 : Int),(2 : Int)) hp3_2_branches564 hp3_2_evidence564 hp3_2_check564 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches564,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node563 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected563 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected563 ((2 : Int),(2 : Int)) hp3_2_branches563 hp3_2_evidence563 hp3_2_check563 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches563,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node564 T childKnown
  · exact hp3_2_node565 T childKnown
  · exact hp3_2_node577 T childKnown
theorem hp3_2_node562 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected562 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected562 ((8 : Int),(0 : Int)) hp3_2_branches562 hp3_2_evidence562 hp3_2_check562 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches562,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node561 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected561 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected561 ((8 : Int),(0 : Int)) hp3_2_branches561 hp3_2_evidence561 hp3_2_check561 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches561,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node560 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected560 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected560 ((8 : Int),(0 : Int)) hp3_2_branches560 hp3_2_evidence560 hp3_2_check560 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches560,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node559 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected559 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected559 ((8 : Int),(1 : Int)) hp3_2_branches559 hp3_2_evidence559 hp3_2_check559 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches559,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node558 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected558 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected558 ((8 : Int),(1 : Int)) hp3_2_branches558 hp3_2_evidence558 hp3_2_check558 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches558,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node557 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected557 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected557 ((8 : Int),(0 : Int)) hp3_2_branches557 hp3_2_evidence557 hp3_2_check557 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches557,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node558 T childKnown
  · exact hp3_2_node559 T childKnown
theorem hp3_2_node556 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected556 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected556 ((8 : Int),(1 : Int)) hp3_2_branches556 hp3_2_evidence556 hp3_2_check556 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches556,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node555 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected555 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected555 ((8 : Int),(0 : Int)) hp3_2_branches555 hp3_2_evidence555 hp3_2_check555 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches555,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node556 T childKnown
theorem hp3_2_node554 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected554 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected554 ((8 : Int),(0 : Int)) hp3_2_branches554 hp3_2_evidence554 hp3_2_check554 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches554,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node553 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected553 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected553 ((8 : Int),(1 : Int)) hp3_2_branches553 hp3_2_evidence553 hp3_2_check553 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches553,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node554 T childKnown
theorem hp3_2_node552 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected552 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected552 ((7 : Int),(1 : Int)) hp3_2_branches552 hp3_2_evidence552 hp3_2_check552 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches552,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node553 T childKnown
  · exact hp3_2_node555 T childKnown
  · exact hp3_2_node557 T childKnown
  · exact hp3_2_node560 T childKnown
  · exact hp3_2_node561 T childKnown
  · exact hp3_2_node562 T childKnown
theorem hp3_2_node551 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected551 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected551 ((3 : Int),(2 : Int)) hp3_2_branches551 hp3_2_evidence551 hp3_2_check551 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches551,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node552 T childKnown
theorem hp3_2_node550 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected550 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected550 ((8 : Int),(0 : Int)) hp3_2_branches550 hp3_2_evidence550 hp3_2_check550 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches550,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node549 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected549 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected549 ((8 : Int),(0 : Int)) hp3_2_branches549 hp3_2_evidence549 hp3_2_check549 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches549,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node548 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected548 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected548 ((8 : Int),(0 : Int)) hp3_2_branches548 hp3_2_evidence548 hp3_2_check548 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches548,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node547 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected547 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected547 ((8 : Int),(1 : Int)) hp3_2_branches547 hp3_2_evidence547 hp3_2_check547 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches547,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node546 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected546 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected546 ((8 : Int),(1 : Int)) hp3_2_branches546 hp3_2_evidence546 hp3_2_check546 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches546,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node545 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected545 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected545 ((8 : Int),(0 : Int)) hp3_2_branches545 hp3_2_evidence545 hp3_2_check545 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches545,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node546 T childKnown
  · exact hp3_2_node547 T childKnown
theorem hp3_2_node544 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected544 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected544 ((8 : Int),(1 : Int)) hp3_2_branches544 hp3_2_evidence544 hp3_2_check544 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches544,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node543 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected543 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected543 ((8 : Int),(0 : Int)) hp3_2_branches543 hp3_2_evidence543 hp3_2_check543 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches543,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node544 T childKnown
theorem hp3_2_node542 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected542 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected542 ((8 : Int),(0 : Int)) hp3_2_branches542 hp3_2_evidence542 hp3_2_check542 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches542,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node541 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected541 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected541 ((8 : Int),(1 : Int)) hp3_2_branches541 hp3_2_evidence541 hp3_2_check541 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches541,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node542 T childKnown
theorem hp3_2_node540 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected540 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected540 ((7 : Int),(1 : Int)) hp3_2_branches540 hp3_2_evidence540 hp3_2_check540 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches540,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node541 T childKnown
  · exact hp3_2_node543 T childKnown
  · exact hp3_2_node545 T childKnown
  · exact hp3_2_node548 T childKnown
  · exact hp3_2_node549 T childKnown
  · exact hp3_2_node550 T childKnown
theorem hp3_2_node539 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected539 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected539 ((3 : Int),(2 : Int)) hp3_2_branches539 hp3_2_evidence539 hp3_2_check539 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches539,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node540 T childKnown
theorem hp3_2_node538 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected538 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected538 ((8 : Int),(0 : Int)) hp3_2_branches538 hp3_2_evidence538 hp3_2_check538 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches538,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node537 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected537 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected537 ((8 : Int),(0 : Int)) hp3_2_branches537 hp3_2_evidence537 hp3_2_check537 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches537,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node536 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected536 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected536 ((8 : Int),(0 : Int)) hp3_2_branches536 hp3_2_evidence536 hp3_2_check536 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches536,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node535 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected535 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected535 ((8 : Int),(1 : Int)) hp3_2_branches535 hp3_2_evidence535 hp3_2_check535 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches535,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node534 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected534 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected534 ((8 : Int),(1 : Int)) hp3_2_branches534 hp3_2_evidence534 hp3_2_check534 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches534,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node533 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected533 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected533 ((8 : Int),(0 : Int)) hp3_2_branches533 hp3_2_evidence533 hp3_2_check533 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches533,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node534 T childKnown
  · exact hp3_2_node535 T childKnown
theorem hp3_2_node532 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected532 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected532 ((8 : Int),(1 : Int)) hp3_2_branches532 hp3_2_evidence532 hp3_2_check532 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches532,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node531 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected531 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected531 ((8 : Int),(0 : Int)) hp3_2_branches531 hp3_2_evidence531 hp3_2_check531 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches531,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node532 T childKnown
theorem hp3_2_node530 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected530 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected530 ((8 : Int),(0 : Int)) hp3_2_branches530 hp3_2_evidence530 hp3_2_check530 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches530,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node529 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected529 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected529 ((8 : Int),(1 : Int)) hp3_2_branches529 hp3_2_evidence529 hp3_2_check529 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches529,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node530 T childKnown
theorem hp3_2_node528 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected528 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected528 ((7 : Int),(1 : Int)) hp3_2_branches528 hp3_2_evidence528 hp3_2_check528 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches528,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node529 T childKnown
  · exact hp3_2_node531 T childKnown
  · exact hp3_2_node533 T childKnown
  · exact hp3_2_node536 T childKnown
  · exact hp3_2_node537 T childKnown
  · exact hp3_2_node538 T childKnown
theorem hp3_2_node527 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected527 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected527 ((4 : Int),(2 : Int)) hp3_2_branches527 hp3_2_evidence527 hp3_2_check527 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches527,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node526 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected526 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected526 ((4 : Int),(2 : Int)) hp3_2_branches526 hp3_2_evidence526 hp3_2_check526 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches526,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node525 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected525 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected525 ((3 : Int),(2 : Int)) hp3_2_branches525 hp3_2_evidence525 hp3_2_check525 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches525,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node526 T childKnown
  · exact hp3_2_node527 T childKnown
  · exact hp3_2_node528 T childKnown
theorem hp3_2_node524 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected524 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected524 ((2 : Int),(2 : Int)) hp3_2_branches524 hp3_2_evidence524 hp3_2_check524 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches524,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node525 T childKnown
  · exact hp3_2_node539 T childKnown
  · exact hp3_2_node551 T childKnown
theorem hp3_2_node523 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected523 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected523 ((0 : Int),(2 : Int)) hp3_2_branches523 hp3_2_evidence523 hp3_2_check523 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches523,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node524 T childKnown
  · exact hp3_2_node563 T childKnown
  · exact hp3_2_node589 T childKnown
  · exact hp3_2_node615 T childKnown
  · exact hp3_2_node616 T childKnown
theorem hp3_2_node522 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected522 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected522 ((3 : Int),(0 : Int)) hp3_2_branches522 hp3_2_evidence522 hp3_2_check522 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches522,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node523 T childKnown
theorem hp3_2_node521 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected521 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected521 ((1 : Int),(2 : Int)) hp3_2_branches521 hp3_2_evidence521 hp3_2_check521 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches521,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node520 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected520 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected520 ((1 : Int),(2 : Int)) hp3_2_branches520 hp3_2_evidence520 hp3_2_check520 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches520,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node519 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected519 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected519 ((1 : Int),(2 : Int)) hp3_2_branches519 hp3_2_evidence519 hp3_2_check519 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches519,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node518 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected518 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected518 ((1 : Int),(1 : Int)) hp3_2_branches518 hp3_2_evidence518 hp3_2_check518 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches518,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node519 T childKnown
  · exact hp3_2_node520 T childKnown
  · exact hp3_2_node521 T childKnown
theorem hp3_2_node517 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected517 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected517 ((8 : Int),(1 : Int)) hp3_2_branches517 hp3_2_evidence517 hp3_2_check517 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches517,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node516 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected516 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected516 ((7 : Int),(1 : Int)) hp3_2_branches516 hp3_2_evidence516 hp3_2_check516 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches516,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node517 T childKnown
theorem hp3_2_node515 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected515 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected515 ((8 : Int),(1 : Int)) hp3_2_branches515 hp3_2_evidence515 hp3_2_check515 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches515,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node514 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected514 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected514 ((7 : Int),(1 : Int)) hp3_2_branches514 hp3_2_evidence514 hp3_2_check514 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches514,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node515 T childKnown
theorem hp3_2_node513 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected513 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected513 ((7 : Int),(1 : Int)) hp3_2_branches513 hp3_2_evidence513 hp3_2_check513 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches513,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node512 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected512 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected512 ((8 : Int),(0 : Int)) hp3_2_branches512 hp3_2_evidence512 hp3_2_check512 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches512,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node513 T childKnown
  · exact hp3_2_node514 T childKnown
  · exact hp3_2_node516 T childKnown
theorem hp3_2_node511 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected511 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected511 ((5 : Int),(2 : Int)) hp3_2_branches511 hp3_2_evidence511 hp3_2_check511 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches511,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node512 T childKnown
theorem hp3_2_node510 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected510 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected510 ((5 : Int),(2 : Int)) hp3_2_branches510 hp3_2_evidence510 hp3_2_check510 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches510,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node509 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected509 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected509 ((8 : Int),(0 : Int)) hp3_2_branches509 hp3_2_evidence509 hp3_2_check509 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches509,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node508 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected508 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected508 ((7 : Int),(2 : Int)) hp3_2_branches508 hp3_2_evidence508 hp3_2_check508 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches508,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node507 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected507 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected507 ((8 : Int),(0 : Int)) hp3_2_branches507 hp3_2_evidence507 hp3_2_check507 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches507,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node506 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected506 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected506 ((8 : Int),(0 : Int)) hp3_2_branches506 hp3_2_evidence506 hp3_2_check506 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches506,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node505 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected505 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected505 ((8 : Int),(1 : Int)) hp3_2_branches505 hp3_2_evidence505 hp3_2_check505 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches505,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node506 T childKnown
theorem hp3_2_node504 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected504 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected504 ((7 : Int),(1 : Int)) hp3_2_branches504 hp3_2_evidence504 hp3_2_check504 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches504,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node505 T childKnown
  · exact hp3_2_node507 T childKnown
  · exact hp3_2_node508 T childKnown
  · exact hp3_2_node509 T childKnown
theorem hp3_2_node503 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected503 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected503 ((7 : Int),(2 : Int)) hp3_2_branches503 hp3_2_evidence503 hp3_2_check503 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches503,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node502 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected502 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected502 ((7 : Int),(2 : Int)) hp3_2_branches502 hp3_2_evidence502 hp3_2_check502 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches502,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node501 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected501 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected501 ((7 : Int),(2 : Int)) hp3_2_branches501 hp3_2_evidence501 hp3_2_check501 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches501,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node500 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected500 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected500 ((7 : Int),(1 : Int)) hp3_2_branches500 hp3_2_evidence500 hp3_2_check500 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches500,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node501 T childKnown
  · exact hp3_2_node502 T childKnown
  · exact hp3_2_node503 T childKnown
theorem hp3_2_node499 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected499 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected499 ((8 : Int),(1 : Int)) hp3_2_branches499 hp3_2_evidence499 hp3_2_check499 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches499,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node498 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected498 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected498 ((7 : Int),(1 : Int)) hp3_2_branches498 hp3_2_evidence498 hp3_2_check498 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches498,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node499 T childKnown
theorem hp3_2_node497 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected497 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected497 ((8 : Int),(1 : Int)) hp3_2_branches497 hp3_2_evidence497 hp3_2_check497 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches497,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node496 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected496 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected496 ((7 : Int),(1 : Int)) hp3_2_branches496 hp3_2_evidence496 hp3_2_check496 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches496,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node497 T childKnown
theorem hp3_2_node495 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected495 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected495 ((7 : Int),(1 : Int)) hp3_2_branches495 hp3_2_evidence495 hp3_2_check495 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches495,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node494 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected494 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected494 ((8 : Int),(0 : Int)) hp3_2_branches494 hp3_2_evidence494 hp3_2_check494 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches494,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node495 T childKnown
  · exact hp3_2_node496 T childKnown
  · exact hp3_2_node498 T childKnown
theorem hp3_2_node493 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected493 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected493 ((5 : Int),(2 : Int)) hp3_2_branches493 hp3_2_evidence493 hp3_2_check493 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches493,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node494 T childKnown
  · exact hp3_2_node500 T childKnown
  · exact hp3_2_node504 T childKnown
theorem hp3_2_node492 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected492 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected492 ((8 : Int),(0 : Int)) hp3_2_branches492 hp3_2_evidence492 hp3_2_check492 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches492,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node491 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected491 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected491 ((7 : Int),(2 : Int)) hp3_2_branches491 hp3_2_evidence491 hp3_2_check491 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches491,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node490 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected490 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected490 ((8 : Int),(0 : Int)) hp3_2_branches490 hp3_2_evidence490 hp3_2_check490 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches490,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node489 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected489 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected489 ((8 : Int),(0 : Int)) hp3_2_branches489 hp3_2_evidence489 hp3_2_check489 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches489,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node488 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected488 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected488 ((8 : Int),(1 : Int)) hp3_2_branches488 hp3_2_evidence488 hp3_2_check488 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches488,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node489 T childKnown
theorem hp3_2_node487 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected487 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected487 ((7 : Int),(1 : Int)) hp3_2_branches487 hp3_2_evidence487 hp3_2_check487 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches487,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node488 T childKnown
  · exact hp3_2_node490 T childKnown
  · exact hp3_2_node491 T childKnown
  · exact hp3_2_node492 T childKnown
theorem hp3_2_node486 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected486 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected486 ((7 : Int),(2 : Int)) hp3_2_branches486 hp3_2_evidence486 hp3_2_check486 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches486,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node485 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected485 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected485 ((7 : Int),(2 : Int)) hp3_2_branches485 hp3_2_evidence485 hp3_2_check485 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches485,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node484 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected484 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected484 ((7 : Int),(2 : Int)) hp3_2_branches484 hp3_2_evidence484 hp3_2_check484 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches484,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node483 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected483 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected483 ((7 : Int),(1 : Int)) hp3_2_branches483 hp3_2_evidence483 hp3_2_check483 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches483,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node484 T childKnown
  · exact hp3_2_node485 T childKnown
  · exact hp3_2_node486 T childKnown
theorem hp3_2_node482 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected482 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected482 ((8 : Int),(1 : Int)) hp3_2_branches482 hp3_2_evidence482 hp3_2_check482 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node481 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected481 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected481 ((7 : Int),(1 : Int)) hp3_2_branches481 hp3_2_evidence481 hp3_2_check481 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches481,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node482 T childKnown
theorem hp3_2_node480 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected480 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected480 ((8 : Int),(1 : Int)) hp3_2_branches480 hp3_2_evidence480 hp3_2_check480 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches480,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node479 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected479 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected479 ((7 : Int),(1 : Int)) hp3_2_branches479 hp3_2_evidence479 hp3_2_check479 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches479,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node480 T childKnown
theorem hp3_2_node478 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected478 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected478 ((7 : Int),(1 : Int)) hp3_2_branches478 hp3_2_evidence478 hp3_2_check478 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches478,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node477 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected477 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected477 ((8 : Int),(0 : Int)) hp3_2_branches477 hp3_2_evidence477 hp3_2_check477 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches477,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node478 T childKnown
  · exact hp3_2_node479 T childKnown
  · exact hp3_2_node481 T childKnown
theorem hp3_2_node476 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected476 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected476 ((5 : Int),(2 : Int)) hp3_2_branches476 hp3_2_evidence476 hp3_2_check476 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches476,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node477 T childKnown
  · exact hp3_2_node483 T childKnown
  · exact hp3_2_node487 T childKnown
theorem hp3_2_node475 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected475 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected475 ((3 : Int),(2 : Int)) hp3_2_branches475 hp3_2_evidence475 hp3_2_check475 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches475,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node476 T childKnown
  · exact hp3_2_node493 T childKnown
  · exact hp3_2_node510 T childKnown
  · exact hp3_2_node511 T childKnown
theorem hp3_2_node474 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected474 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected474 ((3 : Int),(0 : Int)) hp3_2_branches474 hp3_2_evidence474 hp3_2_check474 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches474,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node475 T childKnown
theorem hp3_2_node473 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected473 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected473 ((5 : Int),(1 : Int)) hp3_2_branches473 hp3_2_evidence473 hp3_2_check473 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches473,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node472 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected472 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected472 ((5 : Int),(1 : Int)) hp3_2_branches472 hp3_2_evidence472 hp3_2_check472 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches472,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node471 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected471 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected471 ((4 : Int),(1 : Int)) hp3_2_branches471 hp3_2_evidence471 hp3_2_check471 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches471,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node472 T childKnown
  · exact hp3_2_node473 T childKnown
theorem hp3_2_node470 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected470 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected470 ((6 : Int),(2 : Int)) hp3_2_branches470 hp3_2_evidence470 hp3_2_check470 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches470,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node469 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected469 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected469 ((6 : Int),(2 : Int)) hp3_2_branches469 hp3_2_evidence469 hp3_2_check469 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches469,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node468 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected468 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected468 ((7 : Int),(2 : Int)) hp3_2_branches468 hp3_2_evidence468 hp3_2_check468 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches468,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node467 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected467 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected467 ((7 : Int),(1 : Int)) hp3_2_branches467 hp3_2_evidence467 hp3_2_check467 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches467,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node468 T childKnown
theorem hp3_2_node466 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected466 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected466 ((6 : Int),(1 : Int)) hp3_2_branches466 hp3_2_evidence466 hp3_2_check466 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node467 T childKnown
  · exact hp3_2_node469 T childKnown
  · exact hp3_2_node470 T childKnown
theorem hp3_2_node465 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected465 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected465 ((4 : Int),(1 : Int)) hp3_2_branches465 hp3_2_evidence465 hp3_2_check465 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches465,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node466 T childKnown
theorem hp3_2_node464 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected464 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected464 ((5 : Int),(1 : Int)) hp3_2_branches464 hp3_2_evidence464 hp3_2_check464 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches464,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node463 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected463 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected463 ((5 : Int),(1 : Int)) hp3_2_branches463 hp3_2_evidence463 hp3_2_check463 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches463,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node462 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected462 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected462 ((5 : Int),(0 : Int)) hp3_2_branches462 hp3_2_evidence462 hp3_2_check462 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches462,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node463 T childKnown
  · exact hp3_2_node464 T childKnown
theorem hp3_2_node461 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected461 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected461 ((10 : Int),(0 : Int)) hp3_2_branches461 hp3_2_evidence461 hp3_2_check461 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node460 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected460 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected460 ((10 : Int),(0 : Int)) hp3_2_branches460 hp3_2_evidence460 hp3_2_check460 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches460,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node459 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected459 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected459 ((10 : Int),(0 : Int)) hp3_2_branches459 hp3_2_evidence459 hp3_2_check459 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches459,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node458 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected458 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected458 ((10 : Int),(1 : Int)) hp3_2_branches458 hp3_2_evidence458 hp3_2_check458 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches458,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node457 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected457 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected457 ((10 : Int),(1 : Int)) hp3_2_branches457 hp3_2_evidence457 hp3_2_check457 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches457,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node456 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected456 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected456 ((10 : Int),(0 : Int)) hp3_2_branches456 hp3_2_evidence456 hp3_2_check456 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches456,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node457 T childKnown
  · exact hp3_2_node458 T childKnown
theorem hp3_2_node455 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected455 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected455 ((10 : Int),(1 : Int)) hp3_2_branches455 hp3_2_evidence455 hp3_2_check455 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches455,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node454 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected454 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected454 ((10 : Int),(0 : Int)) hp3_2_branches454 hp3_2_evidence454 hp3_2_check454 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches454,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node455 T childKnown
theorem hp3_2_node453 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected453 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected453 ((10 : Int),(0 : Int)) hp3_2_branches453 hp3_2_evidence453 hp3_2_check453 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches453,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node452 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected452 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected452 ((10 : Int),(1 : Int)) hp3_2_branches452 hp3_2_evidence452 hp3_2_check452 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches452,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node453 T childKnown
theorem hp3_2_node451 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected451 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected451 ((9 : Int),(1 : Int)) hp3_2_branches451 hp3_2_evidence451 hp3_2_check451 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches451,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node452 T childKnown
  · exact hp3_2_node454 T childKnown
  · exact hp3_2_node456 T childKnown
  · exact hp3_2_node459 T childKnown
  · exact hp3_2_node460 T childKnown
  · exact hp3_2_node461 T childKnown
theorem hp3_2_node450 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected450 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected450 ((6 : Int),(2 : Int)) hp3_2_branches450 hp3_2_evidence450 hp3_2_check450 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches450,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node449 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected449 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected449 ((6 : Int),(2 : Int)) hp3_2_branches449 hp3_2_evidence449 hp3_2_check449 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches449,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node448 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected448 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected448 ((7 : Int),(1 : Int)) hp3_2_branches448 hp3_2_evidence448 hp3_2_check448 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches448,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node447 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected447 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected447 ((7 : Int),(1 : Int)) hp3_2_branches447 hp3_2_evidence447 hp3_2_check447 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches447,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node446 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected446 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected446 ((6 : Int),(2 : Int)) hp3_2_branches446 hp3_2_evidence446 hp3_2_check446 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches446,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node447 T childKnown
  · exact hp3_2_node448 T childKnown
theorem hp3_2_node445 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected445 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected445 ((5 : Int),(2 : Int)) hp3_2_branches445 hp3_2_evidence445 hp3_2_check445 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches445,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node446 T childKnown
  · exact hp3_2_node449 T childKnown
  · exact hp3_2_node450 T childKnown
  · exact hp3_2_node451 T childKnown
theorem hp3_2_node444 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected444 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected444 ((5 : Int),(0 : Int)) hp3_2_branches444 hp3_2_evidence444 hp3_2_check444 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches444,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node445 T childKnown
theorem hp3_2_node443 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected443 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected443 ((4 : Int),(0 : Int)) hp3_2_branches443 hp3_2_evidence443 hp3_2_check443 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches443,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node444 T childKnown
  · exact hp3_2_node462 T childKnown
  · exact hp3_2_node465 T childKnown
  · exact hp3_2_node471 T childKnown
theorem hp3_2_node442 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected442 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected442 ((1 : Int),(1 : Int)) hp3_2_branches442 hp3_2_evidence442 hp3_2_check442 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches442,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node443 T childKnown
  · exact hp3_2_node474 T childKnown
theorem hp3_2_node441 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected441 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected441 ((1 : Int),(2 : Int)) hp3_2_branches441 hp3_2_evidence441 hp3_2_check441 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches441,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node440 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected440 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected440 ((1 : Int),(1 : Int)) hp3_2_branches440 hp3_2_evidence440 hp3_2_check440 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches440,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node441 T childKnown
theorem hp3_2_node439 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected439 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected439 ((2 : Int),(2 : Int)) hp3_2_branches439 hp3_2_evidence439 hp3_2_check439 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches439,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node438 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected438 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected438 ((2 : Int),(2 : Int)) hp3_2_branches438 hp3_2_evidence438 hp3_2_check438 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches438,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node437 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected437 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected437 ((1 : Int),(2 : Int)) hp3_2_branches437 hp3_2_evidence437 hp3_2_check437 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches437,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node438 T childKnown
  · exact hp3_2_node439 T childKnown
theorem hp3_2_node436 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected436 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected436 ((3 : Int),(0 : Int)) hp3_2_branches436 hp3_2_evidence436 hp3_2_check436 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches436,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node437 T childKnown
theorem hp3_2_node435 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected435 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected435 ((2 : Int),(2 : Int)) hp3_2_branches435 hp3_2_evidence435 hp3_2_check435 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches435,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node434 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected434 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected434 ((1 : Int),(2 : Int)) hp3_2_branches434 hp3_2_evidence434 hp3_2_check434 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches434,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node435 T childKnown
theorem hp3_2_node433 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected433 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected433 ((4 : Int),(2 : Int)) hp3_2_branches433 hp3_2_evidence433 hp3_2_check433 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches433,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node432 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected432 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected432 ((3 : Int),(2 : Int)) hp3_2_branches432 hp3_2_evidence432 hp3_2_check432 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches432,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node433 T childKnown
theorem hp3_2_node431 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected431 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected431 ((3 : Int),(0 : Int)) hp3_2_branches431 hp3_2_evidence431 hp3_2_check431 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches431,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node432 T childKnown
theorem hp3_2_node430 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected430 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected430 ((1 : Int),(2 : Int)) hp3_2_branches430 hp3_2_evidence430 hp3_2_check430 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches430,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node431 T childKnown
theorem hp3_2_node429 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected429 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected429 ((2 : Int),(2 : Int)) hp3_2_branches429 hp3_2_evidence429 hp3_2_check429 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches429,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node428 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected428 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected428 ((2 : Int),(2 : Int)) hp3_2_branches428 hp3_2_evidence428 hp3_2_check428 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches428,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node427 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected427 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected427 ((2 : Int),(2 : Int)) hp3_2_branches427 hp3_2_evidence427 hp3_2_check427 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches427,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node426 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected426 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected426 ((2 : Int),(1 : Int)) hp3_2_branches426 hp3_2_evidence426 hp3_2_check426 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches426,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node427 T childKnown
  · exact hp3_2_node428 T childKnown
  · exact hp3_2_node429 T childKnown
theorem hp3_2_node425 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected425 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected425 ((3 : Int),(0 : Int)) hp3_2_branches425 hp3_2_evidence425 hp3_2_check425 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches425,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node424 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected424 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected424 ((3 : Int),(0 : Int)) hp3_2_branches424 hp3_2_evidence424 hp3_2_check424 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches424,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node423 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected423 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected423 ((2 : Int),(1 : Int)) hp3_2_branches423 hp3_2_evidence423 hp3_2_check423 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches423,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node424 T childKnown
  · exact hp3_2_node425 T childKnown
theorem hp3_2_node422 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected422 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected422 ((1 : Int),(1 : Int)) hp3_2_branches422 hp3_2_evidence422 hp3_2_check422 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches422,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node423 T childKnown
  · exact hp3_2_node426 T childKnown
  · exact hp3_2_node430 T childKnown
  · exact hp3_2_node434 T childKnown
  · exact hp3_2_node436 T childKnown
theorem hp3_2_node421 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected421 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected421 ((1 : Int),(2 : Int)) hp3_2_branches421 hp3_2_evidence421 hp3_2_check421 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches421,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node420 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected420 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected420 ((1 : Int),(2 : Int)) hp3_2_branches420 hp3_2_evidence420 hp3_2_check420 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches420,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node419 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected419 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected419 ((1 : Int),(2 : Int)) hp3_2_branches419 hp3_2_evidence419 hp3_2_check419 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches419,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node418 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected418 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected418 ((1 : Int),(1 : Int)) hp3_2_branches418 hp3_2_evidence418 hp3_2_check418 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches418,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node419 T childKnown
  · exact hp3_2_node420 T childKnown
  · exact hp3_2_node421 T childKnown
theorem hp3_2_node417 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected417 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected417 ((0 : Int),(1 : Int)) hp3_2_branches417 hp3_2_evidence417 hp3_2_check417 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches417,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node418 T childKnown
  · exact hp3_2_node422 T childKnown
  · exact hp3_2_node440 T childKnown
  · exact hp3_2_node442 T childKnown
  · exact hp3_2_node518 T childKnown
  · exact hp3_2_node522 T childKnown
  · exact hp3_2_node618 T childKnown
theorem hp3_2_node416 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected416 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected416 ((1 : Int),(1 : Int)) hp3_2_branches416 hp3_2_evidence416 hp3_2_check416 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches416,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node415 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected415 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected415 ((1 : Int),(1 : Int)) hp3_2_branches415 hp3_2_evidence415 hp3_2_check415 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches415,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node414 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected414 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected414 ((1 : Int),(0 : Int)) hp3_2_branches414 hp3_2_evidence414 hp3_2_check414 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches414,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node415 T childKnown
  · exact hp3_2_node416 T childKnown
theorem hp3_2_node413 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected413 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected413 ((2 : Int),(1 : Int)) hp3_2_branches413 hp3_2_evidence413 hp3_2_check413 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches413,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node412 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected412 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected412 ((2 : Int),(1 : Int)) hp3_2_branches412 hp3_2_evidence412 hp3_2_check412 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches412,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node411 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected411 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected411 ((2 : Int),(1 : Int)) hp3_2_branches411 hp3_2_evidence411 hp3_2_check411 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches411,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node410 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected410 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected410 ((3 : Int),(1 : Int)) hp3_2_branches410 hp3_2_evidence410 hp3_2_check410 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches410,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node409 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected409 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected409 ((3 : Int),(1 : Int)) hp3_2_branches409 hp3_2_evidence409 hp3_2_check409 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches409,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node408 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected408 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected408 ((2 : Int),(1 : Int)) hp3_2_branches408 hp3_2_evidence408 hp3_2_check408 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches408,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node409 T childKnown
  · exact hp3_2_node410 T childKnown
theorem hp3_2_node407 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected407 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected407 ((2 : Int),(1 : Int)) hp3_2_branches407 hp3_2_evidence407 hp3_2_check407 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches407,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node406 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected406 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected406 ((1 : Int),(1 : Int)) hp3_2_branches406 hp3_2_evidence406 hp3_2_check406 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches406,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node407 T childKnown
  · exact hp3_2_node408 T childKnown
  · exact hp3_2_node411 T childKnown
  · exact hp3_2_node412 T childKnown
  · exact hp3_2_node413 T childKnown
theorem hp3_2_node405 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected405 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected405 ((2 : Int),(1 : Int)) hp3_2_branches405 hp3_2_evidence405 hp3_2_check405 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches405,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node404 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected404 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected404 ((2 : Int),(1 : Int)) hp3_2_branches404 hp3_2_evidence404 hp3_2_check404 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches404,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node403 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected403 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected403 ((4 : Int),(2 : Int)) hp3_2_branches403 hp3_2_evidence403 hp3_2_check403 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches403,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node402 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected402 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected402 ((4 : Int),(2 : Int)) hp3_2_branches402 hp3_2_evidence402 hp3_2_check402 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches402,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node401 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected401 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected401 ((5 : Int),(2 : Int)) hp3_2_branches401 hp3_2_evidence401 hp3_2_check401 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches401,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node400 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected400 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected400 ((5 : Int),(1 : Int)) hp3_2_branches400 hp3_2_evidence400 hp3_2_check400 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches400,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node401 T childKnown
theorem hp3_2_node399 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected399 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected399 ((4 : Int),(1 : Int)) hp3_2_branches399 hp3_2_evidence399 hp3_2_check399 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches399,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node400 T childKnown
  · exact hp3_2_node402 T childKnown
  · exact hp3_2_node403 T childKnown
theorem hp3_2_node398 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected398 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected398 ((2 : Int),(1 : Int)) hp3_2_branches398 hp3_2_evidence398 hp3_2_check398 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches398,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node399 T childKnown
theorem hp3_2_node397 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected397 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected397 ((2 : Int),(1 : Int)) hp3_2_branches397 hp3_2_evidence397 hp3_2_check397 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches397,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node396 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected396 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected396 ((1 : Int),(1 : Int)) hp3_2_branches396 hp3_2_evidence396 hp3_2_check396 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches396,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node397 T childKnown
  · exact hp3_2_node398 T childKnown
  · exact hp3_2_node404 T childKnown
  · exact hp3_2_node405 T childKnown
theorem hp3_2_node395 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected395 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected395 ((3 : Int),(1 : Int)) hp3_2_branches395 hp3_2_evidence395 hp3_2_check395 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches395,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node394 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected394 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected394 ((3 : Int),(1 : Int)) hp3_2_branches394 hp3_2_evidence394 hp3_2_check394 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches394,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node393 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected393 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected393 ((3 : Int),(0 : Int)) hp3_2_branches393 hp3_2_evidence393 hp3_2_check393 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches393,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node394 T childKnown
  · exact hp3_2_node395 T childKnown
theorem hp3_2_node392 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected392 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected392 ((1 : Int),(1 : Int)) hp3_2_branches392 hp3_2_evidence392 hp3_2_check392 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches392,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node393 T childKnown
theorem hp3_2_node391 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected391 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected391 ((8 : Int),(0 : Int)) hp3_2_branches391 hp3_2_evidence391 hp3_2_check391 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches391,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node390 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected390 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected390 ((8 : Int),(0 : Int)) hp3_2_branches390 hp3_2_evidence390 hp3_2_check390 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches390,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node389 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected389 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected389 ((8 : Int),(0 : Int)) hp3_2_branches389 hp3_2_evidence389 hp3_2_check389 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches389,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node388 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected388 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected388 ((8 : Int),(1 : Int)) hp3_2_branches388 hp3_2_evidence388 hp3_2_check388 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches388,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node387 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected387 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected387 ((8 : Int),(1 : Int)) hp3_2_branches387 hp3_2_evidence387 hp3_2_check387 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches387,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node386 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected386 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected386 ((8 : Int),(0 : Int)) hp3_2_branches386 hp3_2_evidence386 hp3_2_check386 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches386,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node387 T childKnown
  · exact hp3_2_node388 T childKnown
theorem hp3_2_node385 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected385 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected385 ((8 : Int),(1 : Int)) hp3_2_branches385 hp3_2_evidence385 hp3_2_check385 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches385,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node384 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected384 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected384 ((8 : Int),(0 : Int)) hp3_2_branches384 hp3_2_evidence384 hp3_2_check384 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches384,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node385 T childKnown
theorem hp3_2_node383 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected383 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected383 ((8 : Int),(0 : Int)) hp3_2_branches383 hp3_2_evidence383 hp3_2_check383 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches383,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node382 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected382 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected382 ((8 : Int),(1 : Int)) hp3_2_branches382 hp3_2_evidence382 hp3_2_check382 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches382,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node383 T childKnown
theorem hp3_2_node381 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected381 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected381 ((7 : Int),(1 : Int)) hp3_2_branches381 hp3_2_evidence381 hp3_2_check381 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches381,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node382 T childKnown
  · exact hp3_2_node384 T childKnown
  · exact hp3_2_node386 T childKnown
  · exact hp3_2_node389 T childKnown
  · exact hp3_2_node390 T childKnown
  · exact hp3_2_node391 T childKnown
theorem hp3_2_node380 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected380 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected380 ((4 : Int),(2 : Int)) hp3_2_branches380 hp3_2_evidence380 hp3_2_check380 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches380,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node379 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected379 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected379 ((4 : Int),(2 : Int)) hp3_2_branches379 hp3_2_evidence379 hp3_2_check379 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches379,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node378 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected378 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected378 ((3 : Int),(2 : Int)) hp3_2_branches378 hp3_2_evidence378 hp3_2_check378 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches378,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node379 T childKnown
  · exact hp3_2_node380 T childKnown
  · exact hp3_2_node381 T childKnown
theorem hp3_2_node377 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected377 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected377 ((3 : Int),(0 : Int)) hp3_2_branches377 hp3_2_evidence377 hp3_2_check377 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches377,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node378 T childKnown
theorem hp3_2_node376 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected376 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected376 ((1 : Int),(1 : Int)) hp3_2_branches376 hp3_2_evidence376 hp3_2_check376 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches376,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node377 T childKnown
theorem hp3_2_node375 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected375 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected375 ((1 : Int),(1 : Int)) hp3_2_branches375 hp3_2_evidence375 hp3_2_check375 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches375,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node374 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected374 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected374 ((1 : Int),(1 : Int)) hp3_2_branches374 hp3_2_evidence374 hp3_2_check374 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches374,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node373 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected373 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected373 ((2 : Int),(0 : Int)) hp3_2_branches373 hp3_2_evidence373 hp3_2_check373 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node374 T childKnown
  · exact hp3_2_node375 T childKnown
  · exact hp3_2_node376 T childKnown
  · exact hp3_2_node392 T childKnown
  · exact hp3_2_node396 T childKnown
  · exact hp3_2_node406 T childKnown
theorem hp3_2_node372 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected372 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected372 ((7 : Int),(1 : Int)) hp3_2_branches372 hp3_2_evidence372 hp3_2_check372 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches372,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node371 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected371 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected371 ((7 : Int),(1 : Int)) hp3_2_branches371 hp3_2_evidence371 hp3_2_check371 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches371,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node370 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected370 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected370 ((7 : Int),(1 : Int)) hp3_2_branches370 hp3_2_evidence370 hp3_2_check370 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches370,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node369 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected369 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected369 ((8 : Int),(1 : Int)) hp3_2_branches369 hp3_2_evidence369 hp3_2_check369 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches369,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node368 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected368 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected368 ((8 : Int),(1 : Int)) hp3_2_branches368 hp3_2_evidence368 hp3_2_check368 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches368,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node367 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected367 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected367 ((7 : Int),(1 : Int)) hp3_2_branches367 hp3_2_evidence367 hp3_2_check367 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches367,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node368 T childKnown
  · exact hp3_2_node369 T childKnown
theorem hp3_2_node366 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected366 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected366 ((7 : Int),(1 : Int)) hp3_2_branches366 hp3_2_evidence366 hp3_2_check366 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches366,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node365 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected365 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected365 ((6 : Int),(1 : Int)) hp3_2_branches365 hp3_2_evidence365 hp3_2_check365 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches365,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node366 T childKnown
  · exact hp3_2_node367 T childKnown
  · exact hp3_2_node370 T childKnown
  · exact hp3_2_node371 T childKnown
  · exact hp3_2_node372 T childKnown
theorem hp3_2_node364 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected364 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected364 ((7 : Int),(1 : Int)) hp3_2_branches364 hp3_2_evidence364 hp3_2_check364 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches364,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node363 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected363 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected363 ((7 : Int),(1 : Int)) hp3_2_branches363 hp3_2_evidence363 hp3_2_check363 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches363,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node362 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected362 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected362 ((1 : Int),(2 : Int)) hp3_2_branches362 hp3_2_evidence362 hp3_2_check362 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches362,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node361 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected361 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected361 ((1 : Int),(1 : Int)) hp3_2_branches361 hp3_2_evidence361 hp3_2_check361 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches361,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node362 T childKnown
theorem hp3_2_node360 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected360 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected360 ((4 : Int),(2 : Int)) hp3_2_branches360 hp3_2_evidence360 hp3_2_check360 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches360,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node359 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected359 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected359 ((4 : Int),(2 : Int)) hp3_2_branches359 hp3_2_evidence359 hp3_2_check359 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches359,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node358 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected358 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected358 ((4 : Int),(1 : Int)) hp3_2_branches358 hp3_2_evidence358 hp3_2_check358 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches358,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node359 T childKnown
  · exact hp3_2_node360 T childKnown
  · exact hp3_2_node361 T childKnown
theorem hp3_2_node357 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected357 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected357 ((7 : Int),(1 : Int)) hp3_2_branches357 hp3_2_evidence357 hp3_2_check357 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches357,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node358 T childKnown
theorem hp3_2_node356 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected356 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected356 ((7 : Int),(1 : Int)) hp3_2_branches356 hp3_2_evidence356 hp3_2_check356 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches356,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node355 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected355 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected355 ((6 : Int),(1 : Int)) hp3_2_branches355 hp3_2_evidence355 hp3_2_check355 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches355,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node356 T childKnown
  · exact hp3_2_node357 T childKnown
  · exact hp3_2_node363 T childKnown
  · exact hp3_2_node364 T childKnown
theorem hp3_2_node354 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected354 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected354 ((8 : Int),(1 : Int)) hp3_2_branches354 hp3_2_evidence354 hp3_2_check354 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches354,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node353 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected353 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected353 ((8 : Int),(1 : Int)) hp3_2_branches353 hp3_2_evidence353 hp3_2_check353 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches353,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node352 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected352 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected352 ((8 : Int),(0 : Int)) hp3_2_branches352 hp3_2_evidence352 hp3_2_check352 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches352,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node353 T childKnown
  · exact hp3_2_node354 T childKnown
theorem hp3_2_node351 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected351 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected351 ((6 : Int),(1 : Int)) hp3_2_branches351 hp3_2_evidence351 hp3_2_check351 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches351,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node352 T childKnown
theorem hp3_2_node350 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected350 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected350 ((1 : Int),(2 : Int)) hp3_2_branches350 hp3_2_evidence350 hp3_2_check350 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches350,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node349 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected349 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected349 ((1 : Int),(1 : Int)) hp3_2_branches349 hp3_2_evidence349 hp3_2_check349 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches349,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node350 T childKnown
theorem hp3_2_node348 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected348 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected348 ((4 : Int),(2 : Int)) hp3_2_branches348 hp3_2_evidence348 hp3_2_check348 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches348,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node347 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected347 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected347 ((4 : Int),(2 : Int)) hp3_2_branches347 hp3_2_evidence347 hp3_2_check347 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches347,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node346 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected346 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected346 ((4 : Int),(1 : Int)) hp3_2_branches346 hp3_2_evidence346 hp3_2_check346 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches346,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node347 T childKnown
  · exact hp3_2_node348 T childKnown
  · exact hp3_2_node349 T childKnown
theorem hp3_2_node345 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected345 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected345 ((8 : Int),(0 : Int)) hp3_2_branches345 hp3_2_evidence345 hp3_2_check345 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches345,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node346 T childKnown
theorem hp3_2_node344 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected344 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected344 ((6 : Int),(1 : Int)) hp3_2_branches344 hp3_2_evidence344 hp3_2_check344 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches344,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node345 T childKnown
theorem hp3_2_node343 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected343 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected343 ((6 : Int),(1 : Int)) hp3_2_branches343 hp3_2_evidence343 hp3_2_check343 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches343,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node342 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected342 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected342 ((6 : Int),(1 : Int)) hp3_2_branches342 hp3_2_evidence342 hp3_2_check342 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches342,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node341 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected341 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected341 ((7 : Int),(0 : Int)) hp3_2_branches341 hp3_2_evidence341 hp3_2_check341 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches341,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node342 T childKnown
  · exact hp3_2_node343 T childKnown
  · exact hp3_2_node344 T childKnown
  · exact hp3_2_node351 T childKnown
  · exact hp3_2_node355 T childKnown
  · exact hp3_2_node365 T childKnown
theorem hp3_2_node340 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected340 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected340 ((1 : Int),(1 : Int)) hp3_2_branches340 hp3_2_evidence340 hp3_2_check340 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches340,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node339 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected339 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected339 ((1 : Int),(1 : Int)) hp3_2_branches339 hp3_2_evidence339 hp3_2_check339 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node338 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected338 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected338 ((1 : Int),(1 : Int)) hp3_2_branches338 hp3_2_evidence338 hp3_2_check338 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches338,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node337 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected337 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected337 ((2 : Int),(1 : Int)) hp3_2_branches337 hp3_2_evidence337 hp3_2_check337 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches337,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node336 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected336 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected336 ((1 : Int),(1 : Int)) hp3_2_branches336 hp3_2_evidence336 hp3_2_check336 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches336,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node337 T childKnown
theorem hp3_2_node335 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected335 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected335 ((1 : Int),(1 : Int)) hp3_2_branches335 hp3_2_evidence335 hp3_2_check335 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches335,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node334 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected334 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected334 ((0 : Int),(1 : Int)) hp3_2_branches334 hp3_2_evidence334 hp3_2_check334 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches334,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node335 T childKnown
  · exact hp3_2_node336 T childKnown
  · exact hp3_2_node338 T childKnown
  · exact hp3_2_node339 T childKnown
  · exact hp3_2_node340 T childKnown
theorem hp3_2_node333 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected333 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected333 ((1 : Int),(1 : Int)) hp3_2_branches333 hp3_2_evidence333 hp3_2_check333 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches333,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node332 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected332 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected332 ((1 : Int),(1 : Int)) hp3_2_branches332 hp3_2_evidence332 hp3_2_check332 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches332,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node331 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected331 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected331 ((0 : Int),(1 : Int)) hp3_2_branches331 hp3_2_evidence331 hp3_2_check331 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches331,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node332 T childKnown
  · exact hp3_2_node333 T childKnown
theorem hp3_2_node330 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected330 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected330 ((1 : Int),(1 : Int)) hp3_2_branches330 hp3_2_evidence330 hp3_2_check330 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches330,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node329 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected329 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected329 ((1 : Int),(1 : Int)) hp3_2_branches329 hp3_2_evidence329 hp3_2_check329 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches329,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node328 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected328 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected328 ((0 : Int),(1 : Int)) hp3_2_branches328 hp3_2_evidence328 hp3_2_check328 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches328,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node329 T childKnown
  · exact hp3_2_node330 T childKnown
theorem hp3_2_node327 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected327 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected327 ((3 : Int),(0 : Int)) hp3_2_branches327 hp3_2_evidence327 hp3_2_check327 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches327,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node328 T childKnown
theorem hp3_2_node326 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected326 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected326 ((1 : Int),(1 : Int)) hp3_2_branches326 hp3_2_evidence326 hp3_2_check326 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches326,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node325 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected325 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected325 ((0 : Int),(1 : Int)) hp3_2_branches325 hp3_2_evidence325 hp3_2_check325 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches325,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node324 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected324 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected324 ((3 : Int),(1 : Int)) hp3_2_branches324 hp3_2_evidence324 hp3_2_check324 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches324,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node323 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected323 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected323 ((3 : Int),(1 : Int)) hp3_2_branches323 hp3_2_evidence323 hp3_2_check323 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches323,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node322 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected322 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected322 ((4 : Int),(1 : Int)) hp3_2_branches322 hp3_2_evidence322 hp3_2_check322 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node321 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected321 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected321 ((4 : Int),(1 : Int)) hp3_2_branches321 hp3_2_evidence321 hp3_2_check321 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches321,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node320 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected320 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected320 ((4 : Int),(0 : Int)) hp3_2_branches320 hp3_2_evidence320 hp3_2_check320 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches320,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node321 T childKnown
  · exact hp3_2_node322 T childKnown
theorem hp3_2_node319 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected319 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected319 ((9 : Int),(0 : Int)) hp3_2_branches319 hp3_2_evidence319 hp3_2_check319 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches319,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node318 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected318 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected318 ((9 : Int),(0 : Int)) hp3_2_branches318 hp3_2_evidence318 hp3_2_check318 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches318,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node317 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected317 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected317 ((9 : Int),(0 : Int)) hp3_2_branches317 hp3_2_evidence317 hp3_2_check317 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches317,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node316 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected316 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected316 ((9 : Int),(1 : Int)) hp3_2_branches316 hp3_2_evidence316 hp3_2_check316 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches316,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node315 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected315 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected315 ((9 : Int),(1 : Int)) hp3_2_branches315 hp3_2_evidence315 hp3_2_check315 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches315,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node314 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected314 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected314 ((9 : Int),(0 : Int)) hp3_2_branches314 hp3_2_evidence314 hp3_2_check314 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches314,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node315 T childKnown
  · exact hp3_2_node316 T childKnown
theorem hp3_2_node313 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected313 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected313 ((9 : Int),(1 : Int)) hp3_2_branches313 hp3_2_evidence313 hp3_2_check313 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches313,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node312 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected312 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected312 ((9 : Int),(0 : Int)) hp3_2_branches312 hp3_2_evidence312 hp3_2_check312 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches312,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node313 T childKnown
theorem hp3_2_node311 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected311 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected311 ((9 : Int),(0 : Int)) hp3_2_branches311 hp3_2_evidence311 hp3_2_check311 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches311,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node310 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected310 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected310 ((9 : Int),(1 : Int)) hp3_2_branches310 hp3_2_evidence310 hp3_2_check310 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches310,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node311 T childKnown
theorem hp3_2_node309 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected309 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected309 ((8 : Int),(1 : Int)) hp3_2_branches309 hp3_2_evidence309 hp3_2_check309 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches309,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node310 T childKnown
  · exact hp3_2_node312 T childKnown
  · exact hp3_2_node314 T childKnown
  · exact hp3_2_node317 T childKnown
  · exact hp3_2_node318 T childKnown
  · exact hp3_2_node319 T childKnown
theorem hp3_2_node308 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected308 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected308 ((5 : Int),(2 : Int)) hp3_2_branches308 hp3_2_evidence308 hp3_2_check308 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches308,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node307 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected307 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected307 ((5 : Int),(2 : Int)) hp3_2_branches307 hp3_2_evidence307 hp3_2_check307 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches307,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node306 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected306 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected306 ((4 : Int),(2 : Int)) hp3_2_branches306 hp3_2_evidence306 hp3_2_check306 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches306,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node307 T childKnown
  · exact hp3_2_node308 T childKnown
  · exact hp3_2_node309 T childKnown
theorem hp3_2_node305 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected305 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected305 ((4 : Int),(0 : Int)) hp3_2_branches305 hp3_2_evidence305 hp3_2_check305 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches305,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node306 T childKnown
theorem hp3_2_node304 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected304 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected304 ((3 : Int),(0 : Int)) hp3_2_branches304 hp3_2_evidence304 hp3_2_check304 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches304,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node305 T childKnown
  · exact hp3_2_node320 T childKnown
  · exact hp3_2_node323 T childKnown
  · exact hp3_2_node324 T childKnown
theorem hp3_2_node303 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected303 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected303 ((3 : Int),(1 : Int)) hp3_2_branches303 hp3_2_evidence303 hp3_2_check303 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches303,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node302 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected302 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected302 ((3 : Int),(1 : Int)) hp3_2_branches302 hp3_2_evidence302 hp3_2_check302 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches302,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node301 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected301 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected301 ((4 : Int),(1 : Int)) hp3_2_branches301 hp3_2_evidence301 hp3_2_check301 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches301,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node300 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected300 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected300 ((4 : Int),(1 : Int)) hp3_2_branches300 hp3_2_evidence300 hp3_2_check300 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches300,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node299 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected299 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected299 ((4 : Int),(0 : Int)) hp3_2_branches299 hp3_2_evidence299 hp3_2_check299 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches299,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node300 T childKnown
  · exact hp3_2_node301 T childKnown
theorem hp3_2_node298 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected298 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected298 ((9 : Int),(0 : Int)) hp3_2_branches298 hp3_2_evidence298 hp3_2_check298 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches298,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node297 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected297 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected297 ((9 : Int),(0 : Int)) hp3_2_branches297 hp3_2_evidence297 hp3_2_check297 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches297,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node296 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected296 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected296 ((9 : Int),(0 : Int)) hp3_2_branches296 hp3_2_evidence296 hp3_2_check296 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches296,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node295 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected295 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected295 ((9 : Int),(1 : Int)) hp3_2_branches295 hp3_2_evidence295 hp3_2_check295 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches295,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node294 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected294 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected294 ((9 : Int),(1 : Int)) hp3_2_branches294 hp3_2_evidence294 hp3_2_check294 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches294,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node293 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected293 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected293 ((9 : Int),(0 : Int)) hp3_2_branches293 hp3_2_evidence293 hp3_2_check293 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches293,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node294 T childKnown
  · exact hp3_2_node295 T childKnown
theorem hp3_2_node292 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected292 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected292 ((9 : Int),(1 : Int)) hp3_2_branches292 hp3_2_evidence292 hp3_2_check292 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches292,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node291 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected291 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected291 ((9 : Int),(0 : Int)) hp3_2_branches291 hp3_2_evidence291 hp3_2_check291 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches291,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node292 T childKnown
theorem hp3_2_node290 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected290 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected290 ((9 : Int),(0 : Int)) hp3_2_branches290 hp3_2_evidence290 hp3_2_check290 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches290,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node289 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected289 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected289 ((9 : Int),(1 : Int)) hp3_2_branches289 hp3_2_evidence289 hp3_2_check289 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches289,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node290 T childKnown
theorem hp3_2_node288 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected288 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected288 ((8 : Int),(1 : Int)) hp3_2_branches288 hp3_2_evidence288 hp3_2_check288 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches288,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node289 T childKnown
  · exact hp3_2_node291 T childKnown
  · exact hp3_2_node293 T childKnown
  · exact hp3_2_node296 T childKnown
  · exact hp3_2_node297 T childKnown
  · exact hp3_2_node298 T childKnown
theorem hp3_2_node287 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected287 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected287 ((5 : Int),(2 : Int)) hp3_2_branches287 hp3_2_evidence287 hp3_2_check287 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches287,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node286 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected286 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected286 ((5 : Int),(2 : Int)) hp3_2_branches286 hp3_2_evidence286 hp3_2_check286 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node285 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected285 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected285 ((4 : Int),(2 : Int)) hp3_2_branches285 hp3_2_evidence285 hp3_2_check285 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches285,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node286 T childKnown
  · exact hp3_2_node287 T childKnown
  · exact hp3_2_node288 T childKnown
theorem hp3_2_node284 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected284 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected284 ((4 : Int),(0 : Int)) hp3_2_branches284 hp3_2_evidence284 hp3_2_check284 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches284,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node285 T childKnown
theorem hp3_2_node283 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected283 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected283 ((3 : Int),(0 : Int)) hp3_2_branches283 hp3_2_evidence283 hp3_2_check283 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches283,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node284 T childKnown
  · exact hp3_2_node299 T childKnown
  · exact hp3_2_node302 T childKnown
  · exact hp3_2_node303 T childKnown
theorem hp3_2_node282 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected282 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected282 ((0 : Int),(2 : Int)) hp3_2_branches282 hp3_2_evidence282 hp3_2_check282 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches282,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node283 T childKnown
  · exact hp3_2_node304 T childKnown
theorem hp3_2_node281 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected281 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected281 ((0 : Int),(2 : Int)) hp3_2_branches281 hp3_2_evidence281 hp3_2_check281 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches281,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node280 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected280 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected280 ((0 : Int),(2 : Int)) hp3_2_branches280 hp3_2_evidence280 hp3_2_check280 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches280,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node279 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected279 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected279 ((4 : Int),(1 : Int)) hp3_2_branches279 hp3_2_evidence279 hp3_2_check279 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches279,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node278 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected278 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected278 ((4 : Int),(1 : Int)) hp3_2_branches278 hp3_2_evidence278 hp3_2_check278 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches278,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node277 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected277 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected277 ((3 : Int),(1 : Int)) hp3_2_branches277 hp3_2_evidence277 hp3_2_check277 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches277,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node278 T childKnown
  · exact hp3_2_node279 T childKnown
theorem hp3_2_node276 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected276 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected276 ((5 : Int),(2 : Int)) hp3_2_branches276 hp3_2_evidence276 hp3_2_check276 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches276,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node275 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected275 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected275 ((5 : Int),(2 : Int)) hp3_2_branches275 hp3_2_evidence275 hp3_2_check275 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node274 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected274 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected274 ((6 : Int),(2 : Int)) hp3_2_branches274 hp3_2_evidence274 hp3_2_check274 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node273 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected273 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected273 ((6 : Int),(1 : Int)) hp3_2_branches273 hp3_2_evidence273 hp3_2_check273 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches273,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node274 T childKnown
theorem hp3_2_node272 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected272 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected272 ((5 : Int),(1 : Int)) hp3_2_branches272 hp3_2_evidence272 hp3_2_check272 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches272,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node273 T childKnown
  · exact hp3_2_node275 T childKnown
  · exact hp3_2_node276 T childKnown
theorem hp3_2_node271 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected271 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected271 ((3 : Int),(1 : Int)) hp3_2_branches271 hp3_2_evidence271 hp3_2_check271 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches271,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node272 T childKnown
theorem hp3_2_node270 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected270 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected270 ((4 : Int),(1 : Int)) hp3_2_branches270 hp3_2_evidence270 hp3_2_check270 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches270,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node269 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected269 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected269 ((4 : Int),(1 : Int)) hp3_2_branches269 hp3_2_evidence269 hp3_2_check269 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches269,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node268 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected268 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected268 ((4 : Int),(0 : Int)) hp3_2_branches268 hp3_2_evidence268 hp3_2_check268 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches268,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node269 T childKnown
  · exact hp3_2_node270 T childKnown
theorem hp3_2_node267 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected267 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected267 ((9 : Int),(0 : Int)) hp3_2_branches267 hp3_2_evidence267 hp3_2_check267 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches267,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node266 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected266 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected266 ((9 : Int),(0 : Int)) hp3_2_branches266 hp3_2_evidence266 hp3_2_check266 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node265 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected265 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected265 ((9 : Int),(0 : Int)) hp3_2_branches265 hp3_2_evidence265 hp3_2_check265 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node264 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected264 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected264 ((9 : Int),(1 : Int)) hp3_2_branches264 hp3_2_evidence264 hp3_2_check264 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches264,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node263 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected263 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected263 ((9 : Int),(1 : Int)) hp3_2_branches263 hp3_2_evidence263 hp3_2_check263 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches263,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node262 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected262 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected262 ((9 : Int),(0 : Int)) hp3_2_branches262 hp3_2_evidence262 hp3_2_check262 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches262,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node263 T childKnown
  · exact hp3_2_node264 T childKnown
theorem hp3_2_node261 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected261 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected261 ((9 : Int),(1 : Int)) hp3_2_branches261 hp3_2_evidence261 hp3_2_check261 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches261,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node260 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected260 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected260 ((9 : Int),(0 : Int)) hp3_2_branches260 hp3_2_evidence260 hp3_2_check260 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches260,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node261 T childKnown
theorem hp3_2_node259 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected259 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected259 ((9 : Int),(0 : Int)) hp3_2_branches259 hp3_2_evidence259 hp3_2_check259 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches259,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node258 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected258 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected258 ((9 : Int),(1 : Int)) hp3_2_branches258 hp3_2_evidence258 hp3_2_check258 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches258,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node259 T childKnown
theorem hp3_2_node257 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected257 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected257 ((8 : Int),(1 : Int)) hp3_2_branches257 hp3_2_evidence257 hp3_2_check257 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches257,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node258 T childKnown
  · exact hp3_2_node260 T childKnown
  · exact hp3_2_node262 T childKnown
  · exact hp3_2_node265 T childKnown
  · exact hp3_2_node266 T childKnown
  · exact hp3_2_node267 T childKnown
theorem hp3_2_node256 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected256 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected256 ((5 : Int),(2 : Int)) hp3_2_branches256 hp3_2_evidence256 hp3_2_check256 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches256,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node255 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected255 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected255 ((5 : Int),(2 : Int)) hp3_2_branches255 hp3_2_evidence255 hp3_2_check255 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches255,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node254 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected254 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected254 ((6 : Int),(1 : Int)) hp3_2_branches254 hp3_2_evidence254 hp3_2_check254 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches254,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node253 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected253 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected253 ((6 : Int),(1 : Int)) hp3_2_branches253 hp3_2_evidence253 hp3_2_check253 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches253,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node252 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected252 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected252 ((5 : Int),(2 : Int)) hp3_2_branches252 hp3_2_evidence252 hp3_2_check252 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches252,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node253 T childKnown
  · exact hp3_2_node254 T childKnown
theorem hp3_2_node251 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected251 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected251 ((4 : Int),(2 : Int)) hp3_2_branches251 hp3_2_evidence251 hp3_2_check251 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches251,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node252 T childKnown
  · exact hp3_2_node255 T childKnown
  · exact hp3_2_node256 T childKnown
  · exact hp3_2_node257 T childKnown
theorem hp3_2_node250 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected250 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected250 ((4 : Int),(0 : Int)) hp3_2_branches250 hp3_2_evidence250 hp3_2_check250 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node251 T childKnown
theorem hp3_2_node249 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected249 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected249 ((3 : Int),(0 : Int)) hp3_2_branches249 hp3_2_evidence249 hp3_2_check249 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches249,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node250 T childKnown
  · exact hp3_2_node268 T childKnown
  · exact hp3_2_node271 T childKnown
  · exact hp3_2_node277 T childKnown
theorem hp3_2_node248 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected248 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected248 ((1 : Int),(2 : Int)) hp3_2_branches248 hp3_2_evidence248 hp3_2_check248 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches248,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node249 T childKnown
  · exact hp3_2_node280 T childKnown
  · exact hp3_2_node281 T childKnown
  · exact hp3_2_node282 T childKnown
theorem hp3_2_node247 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected247 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected247 ((0 : Int),(1 : Int)) hp3_2_branches247 hp3_2_evidence247 hp3_2_check247 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches247,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node246 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected246 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected246 ((2 : Int),(0 : Int)) hp3_2_branches246 hp3_2_evidence246 hp3_2_check246 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches246,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node247 T childKnown
  · exact hp3_2_node248 T childKnown
  · exact hp3_2_node325 T childKnown
  · exact hp3_2_node326 T childKnown
  · exact hp3_2_node327 T childKnown
  · exact hp3_2_node331 T childKnown
  · exact hp3_2_node334 T childKnown
  · exact hp3_2_node341 T childKnown
theorem hp3_2_node245 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected245 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected245 ((1 : Int),(1 : Int)) hp3_2_branches245 hp3_2_evidence245 hp3_2_check245 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node244 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected244 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected244 ((1 : Int),(1 : Int)) hp3_2_branches244 hp3_2_evidence244 hp3_2_check244 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node243 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected243 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected243 ((1 : Int),(1 : Int)) hp3_2_branches243 hp3_2_evidence243 hp3_2_check243 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches243,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node242 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected242 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected242 ((2 : Int),(1 : Int)) hp3_2_branches242 hp3_2_evidence242 hp3_2_check242 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node241 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected241 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected241 ((2 : Int),(1 : Int)) hp3_2_branches241 hp3_2_evidence241 hp3_2_check241 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches241,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node240 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected240 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected240 ((1 : Int),(1 : Int)) hp3_2_branches240 hp3_2_evidence240 hp3_2_check240 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches240,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node241 T childKnown
  · exact hp3_2_node242 T childKnown
theorem hp3_2_node239 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected239 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected239 ((1 : Int),(1 : Int)) hp3_2_branches239 hp3_2_evidence239 hp3_2_check239 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches239,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node238 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected238 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected238 ((0 : Int),(1 : Int)) hp3_2_branches238 hp3_2_evidence238 hp3_2_check238 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches238,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node239 T childKnown
  · exact hp3_2_node240 T childKnown
  · exact hp3_2_node243 T childKnown
  · exact hp3_2_node244 T childKnown
  · exact hp3_2_node245 T childKnown
theorem hp3_2_node237 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected237 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected237 ((1 : Int),(1 : Int)) hp3_2_branches237 hp3_2_evidence237 hp3_2_check237 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node236 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected236 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected236 ((1 : Int),(1 : Int)) hp3_2_branches236 hp3_2_evidence236 hp3_2_check236 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches236,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node235 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected235 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected235 ((3 : Int),(2 : Int)) hp3_2_branches235 hp3_2_evidence235 hp3_2_check235 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches235,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node234 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected234 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected234 ((3 : Int),(2 : Int)) hp3_2_branches234 hp3_2_evidence234 hp3_2_check234 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches234,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node233 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected233 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected233 ((4 : Int),(2 : Int)) hp3_2_branches233 hp3_2_evidence233 hp3_2_check233 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches233,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node232 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected232 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected232 ((4 : Int),(1 : Int)) hp3_2_branches232 hp3_2_evidence232 hp3_2_check232 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches232,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node233 T childKnown
theorem hp3_2_node231 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected231 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected231 ((3 : Int),(1 : Int)) hp3_2_branches231 hp3_2_evidence231 hp3_2_check231 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches231,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node232 T childKnown
  · exact hp3_2_node234 T childKnown
  · exact hp3_2_node235 T childKnown
theorem hp3_2_node230 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected230 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected230 ((1 : Int),(1 : Int)) hp3_2_branches230 hp3_2_evidence230 hp3_2_check230 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches230,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node231 T childKnown
theorem hp3_2_node229 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected229 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected229 ((1 : Int),(1 : Int)) hp3_2_branches229 hp3_2_evidence229 hp3_2_check229 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches229,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node228 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected228 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected228 ((0 : Int),(1 : Int)) hp3_2_branches228 hp3_2_evidence228 hp3_2_check228 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches228,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node229 T childKnown
  · exact hp3_2_node230 T childKnown
  · exact hp3_2_node236 T childKnown
  · exact hp3_2_node237 T childKnown
theorem hp3_2_node227 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected227 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected227 ((2 : Int),(1 : Int)) hp3_2_branches227 hp3_2_evidence227 hp3_2_check227 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches227,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node226 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected226 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected226 ((2 : Int),(1 : Int)) hp3_2_branches226 hp3_2_evidence226 hp3_2_check226 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches226,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node225 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected225 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected225 ((2 : Int),(0 : Int)) hp3_2_branches225 hp3_2_evidence225 hp3_2_check225 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches225,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node226 T childKnown
  · exact hp3_2_node227 T childKnown
theorem hp3_2_node224 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected224 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected224 ((0 : Int),(1 : Int)) hp3_2_branches224 hp3_2_evidence224 hp3_2_check224 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches224,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node225 T childKnown
theorem hp3_2_node223 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected223 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected223 ((7 : Int),(0 : Int)) hp3_2_branches223 hp3_2_evidence223 hp3_2_check223 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches223,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node222 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected222 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected222 ((7 : Int),(0 : Int)) hp3_2_branches222 hp3_2_evidence222 hp3_2_check222 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches222,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node221 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected221 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected221 ((7 : Int),(0 : Int)) hp3_2_branches221 hp3_2_evidence221 hp3_2_check221 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches221,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node220 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected220 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected220 ((7 : Int),(1 : Int)) hp3_2_branches220 hp3_2_evidence220 hp3_2_check220 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node219 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected219 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected219 ((7 : Int),(1 : Int)) hp3_2_branches219 hp3_2_evidence219 hp3_2_check219 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches219,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node218 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected218 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected218 ((7 : Int),(0 : Int)) hp3_2_branches218 hp3_2_evidence218 hp3_2_check218 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches218,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node219 T childKnown
  · exact hp3_2_node220 T childKnown
theorem hp3_2_node217 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected217 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected217 ((7 : Int),(1 : Int)) hp3_2_branches217 hp3_2_evidence217 hp3_2_check217 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches217,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node216 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected216 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected216 ((7 : Int),(0 : Int)) hp3_2_branches216 hp3_2_evidence216 hp3_2_check216 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches216,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node217 T childKnown
theorem hp3_2_node215 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected215 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected215 ((7 : Int),(0 : Int)) hp3_2_branches215 hp3_2_evidence215 hp3_2_check215 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches215,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node214 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected214 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected214 ((7 : Int),(1 : Int)) hp3_2_branches214 hp3_2_evidence214 hp3_2_check214 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches214,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node215 T childKnown
theorem hp3_2_node213 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected213 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected213 ((6 : Int),(1 : Int)) hp3_2_branches213 hp3_2_evidence213 hp3_2_check213 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches213,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node214 T childKnown
  · exact hp3_2_node216 T childKnown
  · exact hp3_2_node218 T childKnown
  · exact hp3_2_node221 T childKnown
  · exact hp3_2_node222 T childKnown
  · exact hp3_2_node223 T childKnown
theorem hp3_2_node212 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected212 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected212 ((3 : Int),(2 : Int)) hp3_2_branches212 hp3_2_evidence212 hp3_2_check212 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches212,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node211 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected211 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected211 ((3 : Int),(2 : Int)) hp3_2_branches211 hp3_2_evidence211 hp3_2_check211 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches211,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node210 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected210 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected210 ((2 : Int),(2 : Int)) hp3_2_branches210 hp3_2_evidence210 hp3_2_check210 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches210,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node211 T childKnown
  · exact hp3_2_node212 T childKnown
  · exact hp3_2_node213 T childKnown
theorem hp3_2_node209 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected209 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected209 ((2 : Int),(0 : Int)) hp3_2_branches209 hp3_2_evidence209 hp3_2_check209 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches209,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node210 T childKnown
theorem hp3_2_node208 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected208 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected208 ((0 : Int),(1 : Int)) hp3_2_branches208 hp3_2_evidence208 hp3_2_check208 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches208,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node209 T childKnown
theorem hp3_2_node207 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected207 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected207 ((0 : Int),(1 : Int)) hp3_2_branches207 hp3_2_evidence207 hp3_2_check207 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches207,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node206 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected206 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected206 ((0 : Int),(1 : Int)) hp3_2_branches206 hp3_2_evidence206 hp3_2_check206 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches206,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node205 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected205 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected205 ((1 : Int),(0 : Int)) hp3_2_branches205 hp3_2_evidence205 hp3_2_check205 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches205,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node206 T childKnown
  · exact hp3_2_node207 T childKnown
  · exact hp3_2_node208 T childKnown
  · exact hp3_2_node224 T childKnown
  · exact hp3_2_node228 T childKnown
  · exact hp3_2_node238 T childKnown
theorem hp3_2_node204 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected204 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected204 ((6 : Int),(1 : Int)) hp3_2_branches204 hp3_2_evidence204 hp3_2_check204 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches204,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node203 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected203 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected203 ((6 : Int),(1 : Int)) hp3_2_branches203 hp3_2_evidence203 hp3_2_check203 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node202 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected202 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected202 ((6 : Int),(1 : Int)) hp3_2_branches202 hp3_2_evidence202 hp3_2_check202 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches202,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node201 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected201 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected201 ((7 : Int),(1 : Int)) hp3_2_branches201 hp3_2_evidence201 hp3_2_check201 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches201,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node200 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected200 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected200 ((7 : Int),(1 : Int)) hp3_2_branches200 hp3_2_evidence200 hp3_2_check200 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches200,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node199 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected199 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected199 ((6 : Int),(1 : Int)) hp3_2_branches199 hp3_2_evidence199 hp3_2_check199 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches199,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node200 T childKnown
  · exact hp3_2_node201 T childKnown
theorem hp3_2_node198 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected198 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected198 ((6 : Int),(1 : Int)) hp3_2_branches198 hp3_2_evidence198 hp3_2_check198 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches198,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node197 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected197 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected197 ((5 : Int),(1 : Int)) hp3_2_branches197 hp3_2_evidence197 hp3_2_check197 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches197,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node198 T childKnown
  · exact hp3_2_node199 T childKnown
  · exact hp3_2_node202 T childKnown
  · exact hp3_2_node203 T childKnown
  · exact hp3_2_node204 T childKnown
theorem hp3_2_node196 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected196 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected196 ((6 : Int),(1 : Int)) hp3_2_branches196 hp3_2_evidence196 hp3_2_check196 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches196,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node195 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected195 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected195 ((6 : Int),(1 : Int)) hp3_2_branches195 hp3_2_evidence195 hp3_2_check195 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches195,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node194 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected194 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected194 ((0 : Int),(2 : Int)) hp3_2_branches194 hp3_2_evidence194 hp3_2_check194 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node193 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected193 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected193 ((0 : Int),(1 : Int)) hp3_2_branches193 hp3_2_evidence193 hp3_2_check193 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches193,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node194 T childKnown
theorem hp3_2_node192 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected192 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected192 ((3 : Int),(2 : Int)) hp3_2_branches192 hp3_2_evidence192 hp3_2_check192 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node191 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected191 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected191 ((3 : Int),(2 : Int)) hp3_2_branches191 hp3_2_evidence191 hp3_2_check191 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches191,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node190 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected190 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected190 ((3 : Int),(1 : Int)) hp3_2_branches190 hp3_2_evidence190 hp3_2_check190 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node191 T childKnown
  · exact hp3_2_node192 T childKnown
  · exact hp3_2_node193 T childKnown
theorem hp3_2_node189 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected189 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected189 ((6 : Int),(1 : Int)) hp3_2_branches189 hp3_2_evidence189 hp3_2_check189 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches189,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node190 T childKnown
theorem hp3_2_node188 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected188 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected188 ((6 : Int),(1 : Int)) hp3_2_branches188 hp3_2_evidence188 hp3_2_check188 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches188,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node187 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected187 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected187 ((5 : Int),(1 : Int)) hp3_2_branches187 hp3_2_evidence187 hp3_2_check187 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches187,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node188 T childKnown
  · exact hp3_2_node189 T childKnown
  · exact hp3_2_node195 T childKnown
  · exact hp3_2_node196 T childKnown
theorem hp3_2_node186 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected186 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected186 ((7 : Int),(1 : Int)) hp3_2_branches186 hp3_2_evidence186 hp3_2_check186 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node185 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected185 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected185 ((7 : Int),(1 : Int)) hp3_2_branches185 hp3_2_evidence185 hp3_2_check185 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node184 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected184 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected184 ((7 : Int),(0 : Int)) hp3_2_branches184 hp3_2_evidence184 hp3_2_check184 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node185 T childKnown
  · exact hp3_2_node186 T childKnown
theorem hp3_2_node183 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected183 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected183 ((5 : Int),(1 : Int)) hp3_2_branches183 hp3_2_evidence183 hp3_2_check183 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node184 T childKnown
theorem hp3_2_node182 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected182 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected182 ((0 : Int),(2 : Int)) hp3_2_branches182 hp3_2_evidence182 hp3_2_check182 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node181 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected181 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected181 ((0 : Int),(1 : Int)) hp3_2_branches181 hp3_2_evidence181 hp3_2_check181 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node182 T childKnown
theorem hp3_2_node180 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected180 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected180 ((3 : Int),(2 : Int)) hp3_2_branches180 hp3_2_evidence180 hp3_2_check180 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node179 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected179 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected179 ((3 : Int),(2 : Int)) hp3_2_branches179 hp3_2_evidence179 hp3_2_check179 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node178 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected178 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected178 ((3 : Int),(1 : Int)) hp3_2_branches178 hp3_2_evidence178 hp3_2_check178 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node179 T childKnown
  · exact hp3_2_node180 T childKnown
  · exact hp3_2_node181 T childKnown
theorem hp3_2_node177 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected177 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected177 ((7 : Int),(0 : Int)) hp3_2_branches177 hp3_2_evidence177 hp3_2_check177 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node178 T childKnown
theorem hp3_2_node176 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected176 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected176 ((5 : Int),(1 : Int)) hp3_2_branches176 hp3_2_evidence176 hp3_2_check176 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node177 T childKnown
theorem hp3_2_node175 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected175 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected175 ((5 : Int),(1 : Int)) hp3_2_branches175 hp3_2_evidence175 hp3_2_check175 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node174 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected174 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected174 ((5 : Int),(1 : Int)) hp3_2_branches174 hp3_2_evidence174 hp3_2_check174 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node173 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected173 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected173 ((6 : Int),(0 : Int)) hp3_2_branches173 hp3_2_evidence173 hp3_2_check173 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node174 T childKnown
  · exact hp3_2_node175 T childKnown
  · exact hp3_2_node176 T childKnown
  · exact hp3_2_node183 T childKnown
  · exact hp3_2_node187 T childKnown
  · exact hp3_2_node197 T childKnown
theorem hp3_2_node172 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected172 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected172 ((1 : Int),(1 : Int)) hp3_2_branches172 hp3_2_evidence172 hp3_2_check172 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node171 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected171 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected171 ((1 : Int),(1 : Int)) hp3_2_branches171 hp3_2_evidence171 hp3_2_check171 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node170 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected170 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected170 ((3 : Int),(2 : Int)) hp3_2_branches170 hp3_2_evidence170 hp3_2_check170 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node169 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected169 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected169 ((3 : Int),(2 : Int)) hp3_2_branches169 hp3_2_evidence169 hp3_2_check169 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node168 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected168 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected168 ((4 : Int),(2 : Int)) hp3_2_branches168 hp3_2_evidence168 hp3_2_check168 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node167 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected167 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected167 ((4 : Int),(1 : Int)) hp3_2_branches167 hp3_2_evidence167 hp3_2_check167 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node168 T childKnown
theorem hp3_2_node166 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected166 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected166 ((3 : Int),(1 : Int)) hp3_2_branches166 hp3_2_evidence166 hp3_2_check166 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node167 T childKnown
  · exact hp3_2_node169 T childKnown
  · exact hp3_2_node170 T childKnown
theorem hp3_2_node165 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected165 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected165 ((1 : Int),(1 : Int)) hp3_2_branches165 hp3_2_evidence165 hp3_2_check165 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node166 T childKnown
theorem hp3_2_node164 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected164 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected164 ((3 : Int),(2 : Int)) hp3_2_branches164 hp3_2_evidence164 hp3_2_check164 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node163 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected163 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected163 ((3 : Int),(2 : Int)) hp3_2_branches163 hp3_2_evidence163 hp3_2_check163 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node162 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected162 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected162 ((4 : Int),(2 : Int)) hp3_2_branches162 hp3_2_evidence162 hp3_2_check162 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node161 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected161 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected161 ((4 : Int),(1 : Int)) hp3_2_branches161 hp3_2_evidence161 hp3_2_check161 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node162 T childKnown
theorem hp3_2_node160 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected160 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected160 ((3 : Int),(1 : Int)) hp3_2_branches160 hp3_2_evidence160 hp3_2_check160 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node161 T childKnown
  · exact hp3_2_node163 T childKnown
  · exact hp3_2_node164 T childKnown
theorem hp3_2_node159 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected159 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected159 ((1 : Int),(1 : Int)) hp3_2_branches159 hp3_2_evidence159 hp3_2_check159 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node160 T childKnown
theorem hp3_2_node158 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected158 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected158 ((1 : Int),(1 : Int)) hp3_2_branches158 hp3_2_evidence158 hp3_2_check158 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node157 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected157 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected157 ((0 : Int),(1 : Int)) hp3_2_branches157 hp3_2_evidence157 hp3_2_check157 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node158 T childKnown
  · exact hp3_2_node159 T childKnown
  · exact hp3_2_node165 T childKnown
  · exact hp3_2_node171 T childKnown
  · exact hp3_2_node172 T childKnown
theorem hp3_2_node156 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected156 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected156 ((2 : Int),(1 : Int)) hp3_2_branches156 hp3_2_evidence156 hp3_2_check156 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node155 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected155 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected155 ((2 : Int),(1 : Int)) hp3_2_branches155 hp3_2_evidence155 hp3_2_check155 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node154 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected154 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected154 ((2 : Int),(0 : Int)) hp3_2_branches154 hp3_2_evidence154 hp3_2_check154 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node155 T childKnown
  · exact hp3_2_node156 T childKnown
theorem hp3_2_node153 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected153 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected153 ((2 : Int),(1 : Int)) hp3_2_branches153 hp3_2_evidence153 hp3_2_check153 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node152 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected152 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected152 ((2 : Int),(1 : Int)) hp3_2_branches152 hp3_2_evidence152 hp3_2_check152 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node151 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected151 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected151 ((2 : Int),(0 : Int)) hp3_2_branches151 hp3_2_evidence151 hp3_2_check151 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node152 T childKnown
  · exact hp3_2_node153 T childKnown
theorem hp3_2_node150 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected150 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected150 ((0 : Int),(1 : Int)) hp3_2_branches150 hp3_2_evidence150 hp3_2_check150 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node151 T childKnown
  · exact hp3_2_node154 T childKnown
theorem hp3_2_node149 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected149 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected149 ((7 : Int),(0 : Int)) hp3_2_branches149 hp3_2_evidence149 hp3_2_check149 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node148 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected148 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected148 ((7 : Int),(0 : Int)) hp3_2_branches148 hp3_2_evidence148 hp3_2_check148 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node147 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected147 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected147 ((7 : Int),(0 : Int)) hp3_2_branches147 hp3_2_evidence147 hp3_2_check147 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node146 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected146 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected146 ((7 : Int),(1 : Int)) hp3_2_branches146 hp3_2_evidence146 hp3_2_check146 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node145 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected145 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected145 ((7 : Int),(1 : Int)) hp3_2_branches145 hp3_2_evidence145 hp3_2_check145 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node144 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected144 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected144 ((7 : Int),(0 : Int)) hp3_2_branches144 hp3_2_evidence144 hp3_2_check144 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node145 T childKnown
  · exact hp3_2_node146 T childKnown
theorem hp3_2_node143 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected143 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected143 ((7 : Int),(1 : Int)) hp3_2_branches143 hp3_2_evidence143 hp3_2_check143 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node142 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected142 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected142 ((7 : Int),(0 : Int)) hp3_2_branches142 hp3_2_evidence142 hp3_2_check142 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node143 T childKnown
theorem hp3_2_node141 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected141 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected141 ((7 : Int),(0 : Int)) hp3_2_branches141 hp3_2_evidence141 hp3_2_check141 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node140 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected140 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected140 ((7 : Int),(1 : Int)) hp3_2_branches140 hp3_2_evidence140 hp3_2_check140 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node141 T childKnown
theorem hp3_2_node139 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected139 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected139 ((6 : Int),(1 : Int)) hp3_2_branches139 hp3_2_evidence139 hp3_2_check139 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node140 T childKnown
  · exact hp3_2_node142 T childKnown
  · exact hp3_2_node144 T childKnown
  · exact hp3_2_node147 T childKnown
  · exact hp3_2_node148 T childKnown
  · exact hp3_2_node149 T childKnown
theorem hp3_2_node138 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected138 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected138 ((3 : Int),(2 : Int)) hp3_2_branches138 hp3_2_evidence138 hp3_2_check138 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node137 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected137 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected137 ((3 : Int),(2 : Int)) hp3_2_branches137 hp3_2_evidence137 hp3_2_check137 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node136 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected136 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected136 ((2 : Int),(2 : Int)) hp3_2_branches136 hp3_2_evidence136 hp3_2_check136 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node137 T childKnown
  · exact hp3_2_node138 T childKnown
  · exact hp3_2_node139 T childKnown
theorem hp3_2_node135 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected135 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected135 ((7 : Int),(0 : Int)) hp3_2_branches135 hp3_2_evidence135 hp3_2_check135 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node134 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected134 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected134 ((7 : Int),(0 : Int)) hp3_2_branches134 hp3_2_evidence134 hp3_2_check134 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node133 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected133 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected133 ((7 : Int),(0 : Int)) hp3_2_branches133 hp3_2_evidence133 hp3_2_check133 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node132 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected132 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected132 ((7 : Int),(1 : Int)) hp3_2_branches132 hp3_2_evidence132 hp3_2_check132 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node131 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected131 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected131 ((7 : Int),(1 : Int)) hp3_2_branches131 hp3_2_evidence131 hp3_2_check131 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node130 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected130 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected130 ((7 : Int),(0 : Int)) hp3_2_branches130 hp3_2_evidence130 hp3_2_check130 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node131 T childKnown
  · exact hp3_2_node132 T childKnown
theorem hp3_2_node129 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected129 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected129 ((7 : Int),(1 : Int)) hp3_2_branches129 hp3_2_evidence129 hp3_2_check129 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node128 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected128 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected128 ((7 : Int),(0 : Int)) hp3_2_branches128 hp3_2_evidence128 hp3_2_check128 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node129 T childKnown
theorem hp3_2_node127 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected127 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected127 ((7 : Int),(0 : Int)) hp3_2_branches127 hp3_2_evidence127 hp3_2_check127 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node126 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected126 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected126 ((7 : Int),(1 : Int)) hp3_2_branches126 hp3_2_evidence126 hp3_2_check126 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node127 T childKnown
theorem hp3_2_node125 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected125 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected125 ((6 : Int),(1 : Int)) hp3_2_branches125 hp3_2_evidence125 hp3_2_check125 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node126 T childKnown
  · exact hp3_2_node128 T childKnown
  · exact hp3_2_node130 T childKnown
  · exact hp3_2_node133 T childKnown
  · exact hp3_2_node134 T childKnown
  · exact hp3_2_node135 T childKnown
theorem hp3_2_node124 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected124 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected124 ((3 : Int),(2 : Int)) hp3_2_branches124 hp3_2_evidence124 hp3_2_check124 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node123 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected123 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected123 ((3 : Int),(2 : Int)) hp3_2_branches123 hp3_2_evidence123 hp3_2_check123 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node122 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected122 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected122 ((2 : Int),(2 : Int)) hp3_2_branches122 hp3_2_evidence122 hp3_2_check122 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node123 T childKnown
  · exact hp3_2_node124 T childKnown
  · exact hp3_2_node125 T childKnown
theorem hp3_2_node121 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected121 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected121 ((0 : Int),(1 : Int)) hp3_2_branches121 hp3_2_evidence121 hp3_2_check121 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node122 T childKnown
  · exact hp3_2_node136 T childKnown
theorem hp3_2_node120 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected120 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected120 ((2 : Int),(0 : Int)) hp3_2_branches120 hp3_2_evidence120 hp3_2_check120 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node121 T childKnown
theorem hp3_2_node119 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected119 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected119 ((0 : Int),(1 : Int)) hp3_2_branches119 hp3_2_evidence119 hp3_2_check119 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node118 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected118 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected118 ((0 : Int),(1 : Int)) hp3_2_branches118 hp3_2_evidence118 hp3_2_check118 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node117 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected117 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected117 ((2 : Int),(1 : Int)) hp3_2_branches117 hp3_2_evidence117 hp3_2_check117 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node116 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected116 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected116 ((2 : Int),(1 : Int)) hp3_2_branches116 hp3_2_evidence116 hp3_2_check116 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node115 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected115 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected115 ((3 : Int),(1 : Int)) hp3_2_branches115 hp3_2_evidence115 hp3_2_check115 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node114 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected114 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected114 ((3 : Int),(1 : Int)) hp3_2_branches114 hp3_2_evidence114 hp3_2_check114 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node113 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected113 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected113 ((3 : Int),(0 : Int)) hp3_2_branches113 hp3_2_evidence113 hp3_2_check113 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node114 T childKnown
  · exact hp3_2_node115 T childKnown
theorem hp3_2_node112 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected112 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected112 ((8 : Int),(0 : Int)) hp3_2_branches112 hp3_2_evidence112 hp3_2_check112 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node111 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected111 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected111 ((8 : Int),(0 : Int)) hp3_2_branches111 hp3_2_evidence111 hp3_2_check111 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node110 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected110 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected110 ((8 : Int),(0 : Int)) hp3_2_branches110 hp3_2_evidence110 hp3_2_check110 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node109 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected109 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected109 ((8 : Int),(1 : Int)) hp3_2_branches109 hp3_2_evidence109 hp3_2_check109 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node108 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected108 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected108 ((8 : Int),(1 : Int)) hp3_2_branches108 hp3_2_evidence108 hp3_2_check108 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node107 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected107 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected107 ((8 : Int),(0 : Int)) hp3_2_branches107 hp3_2_evidence107 hp3_2_check107 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node108 T childKnown
  · exact hp3_2_node109 T childKnown
theorem hp3_2_node106 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected106 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected106 ((8 : Int),(1 : Int)) hp3_2_branches106 hp3_2_evidence106 hp3_2_check106 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node105 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected105 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected105 ((8 : Int),(0 : Int)) hp3_2_branches105 hp3_2_evidence105 hp3_2_check105 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node106 T childKnown
theorem hp3_2_node104 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected104 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected104 ((8 : Int),(0 : Int)) hp3_2_branches104 hp3_2_evidence104 hp3_2_check104 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node103 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected103 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected103 ((8 : Int),(1 : Int)) hp3_2_branches103 hp3_2_evidence103 hp3_2_check103 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node104 T childKnown
theorem hp3_2_node102 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected102 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected102 ((7 : Int),(1 : Int)) hp3_2_branches102 hp3_2_evidence102 hp3_2_check102 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node103 T childKnown
  · exact hp3_2_node105 T childKnown
  · exact hp3_2_node107 T childKnown
  · exact hp3_2_node110 T childKnown
  · exact hp3_2_node111 T childKnown
  · exact hp3_2_node112 T childKnown
theorem hp3_2_node101 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected101 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected101 ((4 : Int),(2 : Int)) hp3_2_branches101 hp3_2_evidence101 hp3_2_check101 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node100 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected100 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected100 ((4 : Int),(2 : Int)) hp3_2_branches100 hp3_2_evidence100 hp3_2_check100 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node99 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected99 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected99 ((3 : Int),(2 : Int)) hp3_2_branches99 hp3_2_evidence99 hp3_2_check99 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches99,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node100 T childKnown
  · exact hp3_2_node101 T childKnown
  · exact hp3_2_node102 T childKnown
theorem hp3_2_node98 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected98 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected98 ((3 : Int),(0 : Int)) hp3_2_branches98 hp3_2_evidence98 hp3_2_check98 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches98,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node99 T childKnown
theorem hp3_2_node97 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected97 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected97 ((2 : Int),(0 : Int)) hp3_2_branches97 hp3_2_evidence97 hp3_2_check97 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches97,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node98 T childKnown
  · exact hp3_2_node113 T childKnown
  · exact hp3_2_node116 T childKnown
  · exact hp3_2_node117 T childKnown
theorem hp3_2_node96 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected96 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected96 ((3 : Int),(1 : Int)) hp3_2_branches96 hp3_2_evidence96 hp3_2_check96 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches96,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node95 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected95 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected95 ((3 : Int),(1 : Int)) hp3_2_branches95 hp3_2_evidence95 hp3_2_check95 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches95,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node94 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected94 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected94 ((2 : Int),(1 : Int)) hp3_2_branches94 hp3_2_evidence94 hp3_2_check94 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches94,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node95 T childKnown
  · exact hp3_2_node96 T childKnown
theorem hp3_2_node93 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected93 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected93 ((4 : Int),(2 : Int)) hp3_2_branches93 hp3_2_evidence93 hp3_2_check93 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches93,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node92 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected92 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected92 ((4 : Int),(2 : Int)) hp3_2_branches92 hp3_2_evidence92 hp3_2_check92 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches92,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node91 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected91 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected91 ((5 : Int),(2 : Int)) hp3_2_branches91 hp3_2_evidence91 hp3_2_check91 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches91,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node90 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected90 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected90 ((5 : Int),(1 : Int)) hp3_2_branches90 hp3_2_evidence90 hp3_2_check90 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches90,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node91 T childKnown
theorem hp3_2_node89 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected89 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected89 ((4 : Int),(1 : Int)) hp3_2_branches89 hp3_2_evidence89 hp3_2_check89 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches89,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node90 T childKnown
  · exact hp3_2_node92 T childKnown
  · exact hp3_2_node93 T childKnown
theorem hp3_2_node88 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected88 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected88 ((2 : Int),(1 : Int)) hp3_2_branches88 hp3_2_evidence88 hp3_2_check88 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches88,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node89 T childKnown
theorem hp3_2_node87 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected87 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected87 ((3 : Int),(1 : Int)) hp3_2_branches87 hp3_2_evidence87 hp3_2_check87 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches87,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node86 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected86 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected86 ((3 : Int),(1 : Int)) hp3_2_branches86 hp3_2_evidence86 hp3_2_check86 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches86,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node85 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected85 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected85 ((3 : Int),(0 : Int)) hp3_2_branches85 hp3_2_evidence85 hp3_2_check85 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches85,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node86 T childKnown
  · exact hp3_2_node87 T childKnown
theorem hp3_2_node84 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected84 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected84 ((8 : Int),(0 : Int)) hp3_2_branches84 hp3_2_evidence84 hp3_2_check84 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches84,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node83 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected83 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected83 ((8 : Int),(0 : Int)) hp3_2_branches83 hp3_2_evidence83 hp3_2_check83 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches83,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node82 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected82 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected82 ((8 : Int),(0 : Int)) hp3_2_branches82 hp3_2_evidence82 hp3_2_check82 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches82,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node81 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected81 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected81 ((8 : Int),(1 : Int)) hp3_2_branches81 hp3_2_evidence81 hp3_2_check81 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches81,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node80 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected80 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected80 ((8 : Int),(1 : Int)) hp3_2_branches80 hp3_2_evidence80 hp3_2_check80 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches80,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node79 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected79 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected79 ((8 : Int),(0 : Int)) hp3_2_branches79 hp3_2_evidence79 hp3_2_check79 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches79,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node80 T childKnown
  · exact hp3_2_node81 T childKnown
theorem hp3_2_node78 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected78 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected78 ((8 : Int),(1 : Int)) hp3_2_branches78 hp3_2_evidence78 hp3_2_check78 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches78,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node77 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected77 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected77 ((8 : Int),(0 : Int)) hp3_2_branches77 hp3_2_evidence77 hp3_2_check77 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches77,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node78 T childKnown
theorem hp3_2_node76 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected76 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected76 ((8 : Int),(0 : Int)) hp3_2_branches76 hp3_2_evidence76 hp3_2_check76 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches76,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node75 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected75 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected75 ((8 : Int),(1 : Int)) hp3_2_branches75 hp3_2_evidence75 hp3_2_check75 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches75,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node76 T childKnown
theorem hp3_2_node74 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected74 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected74 ((7 : Int),(1 : Int)) hp3_2_branches74 hp3_2_evidence74 hp3_2_check74 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches74,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node75 T childKnown
  · exact hp3_2_node77 T childKnown
  · exact hp3_2_node79 T childKnown
  · exact hp3_2_node82 T childKnown
  · exact hp3_2_node83 T childKnown
  · exact hp3_2_node84 T childKnown
theorem hp3_2_node73 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected73 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected73 ((4 : Int),(2 : Int)) hp3_2_branches73 hp3_2_evidence73 hp3_2_check73 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches73,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node72 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected72 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected72 ((4 : Int),(2 : Int)) hp3_2_branches72 hp3_2_evidence72 hp3_2_check72 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches72,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node71 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected71 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected71 ((5 : Int),(1 : Int)) hp3_2_branches71 hp3_2_evidence71 hp3_2_check71 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches71,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node70 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected70 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected70 ((5 : Int),(1 : Int)) hp3_2_branches70 hp3_2_evidence70 hp3_2_check70 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches70,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node69 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected69 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected69 ((4 : Int),(2 : Int)) hp3_2_branches69 hp3_2_evidence69 hp3_2_check69 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches69,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node70 T childKnown
  · exact hp3_2_node71 T childKnown
theorem hp3_2_node68 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected68 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected68 ((3 : Int),(2 : Int)) hp3_2_branches68 hp3_2_evidence68 hp3_2_check68 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches68,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node69 T childKnown
  · exact hp3_2_node72 T childKnown
  · exact hp3_2_node73 T childKnown
  · exact hp3_2_node74 T childKnown
theorem hp3_2_node67 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected67 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected67 ((3 : Int),(0 : Int)) hp3_2_branches67 hp3_2_evidence67 hp3_2_check67 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches67,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node68 T childKnown
theorem hp3_2_node66 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected66 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected66 ((2 : Int),(0 : Int)) hp3_2_branches66 hp3_2_evidence66 hp3_2_check66 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches66,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node67 T childKnown
  · exact hp3_2_node85 T childKnown
  · exact hp3_2_node88 T childKnown
  · exact hp3_2_node94 T childKnown
theorem hp3_2_node65 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected65 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected65 ((3 : Int),(1 : Int)) hp3_2_branches65 hp3_2_evidence65 hp3_2_check65 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches65,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node64 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected64 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected64 ((3 : Int),(1 : Int)) hp3_2_branches64 hp3_2_evidence64 hp3_2_check64 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches64,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node63 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected63 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected63 ((2 : Int),(1 : Int)) hp3_2_branches63 hp3_2_evidence63 hp3_2_check63 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches63,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node64 T childKnown
  · exact hp3_2_node65 T childKnown
theorem hp3_2_node62 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected62 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected62 ((4 : Int),(2 : Int)) hp3_2_branches62 hp3_2_evidence62 hp3_2_check62 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches62,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node61 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected61 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected61 ((4 : Int),(2 : Int)) hp3_2_branches61 hp3_2_evidence61 hp3_2_check61 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches61,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node60 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected60 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected60 ((5 : Int),(2 : Int)) hp3_2_branches60 hp3_2_evidence60 hp3_2_check60 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches60,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node59 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected59 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected59 ((5 : Int),(1 : Int)) hp3_2_branches59 hp3_2_evidence59 hp3_2_check59 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches59,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node60 T childKnown
theorem hp3_2_node58 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected58 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected58 ((4 : Int),(1 : Int)) hp3_2_branches58 hp3_2_evidence58 hp3_2_check58 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches58,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node59 T childKnown
  · exact hp3_2_node61 T childKnown
  · exact hp3_2_node62 T childKnown
theorem hp3_2_node57 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected57 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected57 ((2 : Int),(1 : Int)) hp3_2_branches57 hp3_2_evidence57 hp3_2_check57 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches57,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node58 T childKnown
theorem hp3_2_node56 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected56 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected56 ((3 : Int),(1 : Int)) hp3_2_branches56 hp3_2_evidence56 hp3_2_check56 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches56,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node55 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected55 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected55 ((3 : Int),(1 : Int)) hp3_2_branches55 hp3_2_evidence55 hp3_2_check55 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches55,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node54 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected54 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected54 ((3 : Int),(0 : Int)) hp3_2_branches54 hp3_2_evidence54 hp3_2_check54 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches54,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node55 T childKnown
  · exact hp3_2_node56 T childKnown
theorem hp3_2_node53 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected53 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected53 ((8 : Int),(0 : Int)) hp3_2_branches53 hp3_2_evidence53 hp3_2_check53 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches53,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node52 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected52 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected52 ((8 : Int),(0 : Int)) hp3_2_branches52 hp3_2_evidence52 hp3_2_check52 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches52,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node51 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected51 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected51 ((8 : Int),(0 : Int)) hp3_2_branches51 hp3_2_evidence51 hp3_2_check51 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches51,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node50 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected50 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected50 ((8 : Int),(1 : Int)) hp3_2_branches50 hp3_2_evidence50 hp3_2_check50 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches50,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node49 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected49 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected49 ((8 : Int),(1 : Int)) hp3_2_branches49 hp3_2_evidence49 hp3_2_check49 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches49,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node48 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected48 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected48 ((8 : Int),(0 : Int)) hp3_2_branches48 hp3_2_evidence48 hp3_2_check48 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches48,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node49 T childKnown
  · exact hp3_2_node50 T childKnown
theorem hp3_2_node47 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected47 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected47 ((8 : Int),(1 : Int)) hp3_2_branches47 hp3_2_evidence47 hp3_2_check47 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches47,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node46 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected46 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected46 ((8 : Int),(0 : Int)) hp3_2_branches46 hp3_2_evidence46 hp3_2_check46 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches46,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node47 T childKnown
theorem hp3_2_node45 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected45 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected45 ((8 : Int),(0 : Int)) hp3_2_branches45 hp3_2_evidence45 hp3_2_check45 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches45,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node44 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected44 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected44 ((8 : Int),(1 : Int)) hp3_2_branches44 hp3_2_evidence44 hp3_2_check44 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches44,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node45 T childKnown
theorem hp3_2_node43 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected43 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected43 ((7 : Int),(1 : Int)) hp3_2_branches43 hp3_2_evidence43 hp3_2_check43 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches43,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node44 T childKnown
  · exact hp3_2_node46 T childKnown
  · exact hp3_2_node48 T childKnown
  · exact hp3_2_node51 T childKnown
  · exact hp3_2_node52 T childKnown
  · exact hp3_2_node53 T childKnown
theorem hp3_2_node42 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected42 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected42 ((4 : Int),(2 : Int)) hp3_2_branches42 hp3_2_evidence42 hp3_2_check42 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches42,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node41 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected41 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected41 ((4 : Int),(2 : Int)) hp3_2_branches41 hp3_2_evidence41 hp3_2_check41 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches41,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node40 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected40 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected40 ((5 : Int),(1 : Int)) hp3_2_branches40 hp3_2_evidence40 hp3_2_check40 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches40,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node39 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected39 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected39 ((5 : Int),(1 : Int)) hp3_2_branches39 hp3_2_evidence39 hp3_2_check39 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches39,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node38 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected38 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected38 ((4 : Int),(2 : Int)) hp3_2_branches38 hp3_2_evidence38 hp3_2_check38 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches38,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node39 T childKnown
  · exact hp3_2_node40 T childKnown
theorem hp3_2_node37 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected37 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected37 ((3 : Int),(2 : Int)) hp3_2_branches37 hp3_2_evidence37 hp3_2_check37 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches37,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node38 T childKnown
  · exact hp3_2_node41 T childKnown
  · exact hp3_2_node42 T childKnown
  · exact hp3_2_node43 T childKnown
theorem hp3_2_node36 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected36 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected36 ((3 : Int),(0 : Int)) hp3_2_branches36 hp3_2_evidence36 hp3_2_check36 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches36,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node37 T childKnown
theorem hp3_2_node35 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected35 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected35 ((2 : Int),(0 : Int)) hp3_2_branches35 hp3_2_evidence35 hp3_2_check35 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches35,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node36 T childKnown
  · exact hp3_2_node54 T childKnown
  · exact hp3_2_node57 T childKnown
  · exact hp3_2_node63 T childKnown
theorem hp3_2_node34 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected34 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected34 ((3 : Int),(1 : Int)) hp3_2_branches34 hp3_2_evidence34 hp3_2_check34 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches34,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node33 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected33 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected33 ((3 : Int),(1 : Int)) hp3_2_branches33 hp3_2_evidence33 hp3_2_check33 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches33,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node32 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected32 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected32 ((2 : Int),(1 : Int)) hp3_2_branches32 hp3_2_evidence32 hp3_2_check32 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches32,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node33 T childKnown
  · exact hp3_2_node34 T childKnown
theorem hp3_2_node31 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected31 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected31 ((4 : Int),(2 : Int)) hp3_2_branches31 hp3_2_evidence31 hp3_2_check31 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches31,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node30 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected30 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected30 ((4 : Int),(2 : Int)) hp3_2_branches30 hp3_2_evidence30 hp3_2_check30 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches30,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node29 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected29 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected29 ((5 : Int),(2 : Int)) hp3_2_branches29 hp3_2_evidence29 hp3_2_check29 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches29,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node28 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected28 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected28 ((5 : Int),(1 : Int)) hp3_2_branches28 hp3_2_evidence28 hp3_2_check28 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches28,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node29 T childKnown
theorem hp3_2_node27 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected27 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected27 ((4 : Int),(1 : Int)) hp3_2_branches27 hp3_2_evidence27 hp3_2_check27 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches27,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp3_2_node28 T childKnown
  · exact hp3_2_node30 T childKnown
  · exact hp3_2_node31 T childKnown
theorem hp3_2_node26 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected26 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected26 ((2 : Int),(1 : Int)) hp3_2_branches26 hp3_2_evidence26 hp3_2_check26 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches26,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node27 T childKnown
theorem hp3_2_node25 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected25 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected25 ((3 : Int),(1 : Int)) hp3_2_branches25 hp3_2_evidence25 hp3_2_check25 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches25,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node24 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected24 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected24 ((3 : Int),(1 : Int)) hp3_2_branches24 hp3_2_evidence24 hp3_2_check24 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches24,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node23 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected23 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected23 ((3 : Int),(0 : Int)) hp3_2_branches23 hp3_2_evidence23 hp3_2_check23 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches23,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node24 T childKnown
  · exact hp3_2_node25 T childKnown
theorem hp3_2_node22 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected22 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected22 ((8 : Int),(0 : Int)) hp3_2_branches22 hp3_2_evidence22 hp3_2_check22 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches22,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node21 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected21 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected21 ((8 : Int),(0 : Int)) hp3_2_branches21 hp3_2_evidence21 hp3_2_check21 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches21,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node20 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected20 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected20 ((8 : Int),(0 : Int)) hp3_2_branches20 hp3_2_evidence20 hp3_2_check20 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches20,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node19 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected19 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected19 ((8 : Int),(1 : Int)) hp3_2_branches19 hp3_2_evidence19 hp3_2_check19 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches19,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node18 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected18 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected18 ((8 : Int),(1 : Int)) hp3_2_branches18 hp3_2_evidence18 hp3_2_check18 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches18,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node17 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected17 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected17 ((8 : Int),(0 : Int)) hp3_2_branches17 hp3_2_evidence17 hp3_2_check17 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches17,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node18 T childKnown
  · exact hp3_2_node19 T childKnown
theorem hp3_2_node16 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected16 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected16 ((8 : Int),(1 : Int)) hp3_2_branches16 hp3_2_evidence16 hp3_2_check16 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches16,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node15 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected15 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected15 ((8 : Int),(0 : Int)) hp3_2_branches15 hp3_2_evidence15 hp3_2_check15 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches15,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node16 T childKnown
theorem hp3_2_node14 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected14 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected14 ((8 : Int),(0 : Int)) hp3_2_branches14 hp3_2_evidence14 hp3_2_check14 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches14,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node13 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected13 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected13 ((8 : Int),(1 : Int)) hp3_2_branches13 hp3_2_evidence13 hp3_2_check13 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches13,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node14 T childKnown
theorem hp3_2_node12 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected12 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected12 ((7 : Int),(1 : Int)) hp3_2_branches12 hp3_2_evidence12 hp3_2_check12 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches12,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node13 T childKnown
  · exact hp3_2_node15 T childKnown
  · exact hp3_2_node17 T childKnown
  · exact hp3_2_node20 T childKnown
  · exact hp3_2_node21 T childKnown
  · exact hp3_2_node22 T childKnown
theorem hp3_2_node11 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected11 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected11 ((4 : Int),(2 : Int)) hp3_2_branches11 hp3_2_evidence11 hp3_2_check11 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches11,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node10 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected10 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected10 ((4 : Int),(2 : Int)) hp3_2_branches10 hp3_2_evidence10 hp3_2_check10 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches10,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node9 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected9 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected9 ((5 : Int),(1 : Int)) hp3_2_branches9 hp3_2_evidence9 hp3_2_check9 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches9,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node8 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected8 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected8 ((5 : Int),(1 : Int)) hp3_2_branches8 hp3_2_evidence8 hp3_2_check8 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches8,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node7 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected7 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected7 ((4 : Int),(2 : Int)) hp3_2_branches7 hp3_2_evidence7 hp3_2_check7 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches7,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp3_2_node8 T childKnown
  · exact hp3_2_node9 T childKnown
theorem hp3_2_node6 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected6 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected6 ((3 : Int),(2 : Int)) hp3_2_branches6 hp3_2_evidence6 hp3_2_check6 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches6,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node7 T childKnown
  · exact hp3_2_node10 T childKnown
  · exact hp3_2_node11 T childKnown
  · exact hp3_2_node12 T childKnown
theorem hp3_2_node5 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected5 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected5 ((3 : Int),(0 : Int)) hp3_2_branches5 hp3_2_evidence5 hp3_2_check5 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches5,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp3_2_node6 T childKnown
theorem hp3_2_node4 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected4 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected4 ((2 : Int),(0 : Int)) hp3_2_branches4 hp3_2_evidence4 hp3_2_check4 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches4,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node5 T childKnown
  · exact hp3_2_node23 T childKnown
  · exact hp3_2_node26 T childKnown
  · exact hp3_2_node32 T childKnown
theorem hp3_2_node3 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected3 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected3 ((0 : Int),(2 : Int)) hp3_2_branches3 hp3_2_evidence3 hp3_2_check3 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches3,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp3_2_node4 T childKnown
  · exact hp3_2_node35 T childKnown
  · exact hp3_2_node66 T childKnown
  · exact hp3_2_node97 T childKnown
theorem hp3_2_node2 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected2 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected2 ((0 : Int),(1 : Int)) hp3_2_branches2 hp3_2_evidence2 hp3_2_check2 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches2,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp3_2_node1 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected1 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected1 ((1 : Int),(0 : Int)) hp3_2_branches1 hp3_2_evidence1 hp3_2_check1 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches1,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node2 T childKnown
  · exact hp3_2_node3 T childKnown
  · exact hp3_2_node118 T childKnown
  · exact hp3_2_node119 T childKnown
  · exact hp3_2_node120 T childKnown
  · exact hp3_2_node150 T childKnown
  · exact hp3_2_node157 T childKnown
  · exact hp3_2_node173 T childKnown
theorem hp3_2_node0 (T : Tiling (3 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp3_2_selected0 → T.world s) : False := by
  apply replay_step (3 : Int) (2 : Int) (by decide) (by decide) T hp3_2_selected0 ((0 : Int),(0 : Int)) hp3_2_branches0 hp3_2_evidence0 hp3_2_check0 ?_ known
  intro t member childKnown
  simp only [hp3_2_branches0,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp3_2_node1 T childKnown
  · exact hp3_2_node205 T childKnown
  · exact hp3_2_node246 T childKnown
  · exact hp3_2_node373 T childKnown
  · exact hp3_2_node414 T childKnown
  · exact hp3_2_node417 T childKnown
  · exact hp3_2_node625 T childKnown
  · exact hp3_2_node672 T childKnown
  · exact hp3_2_node703 T childKnown
  · exact hp3_2_node734 T childKnown
  · exact hp3_2_node942 T childKnown
  · exact hp3_2_node974 T childKnown
  · exact hp3_2_node976 T childKnown
  · exact hp3_2_node994 T childKnown
  · exact hp3_2_node997 T childKnown
  · exact hp3_2_node1342 T childKnown

theorem hp3_2_no_half_plane : ¬Tiles (3 : Int) (2 : Int) 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact hp3_2_node0 T (by simp [hp3_2_selected0])
#print axioms hp3_2_no_half_plane

end THalfPlaneFinite

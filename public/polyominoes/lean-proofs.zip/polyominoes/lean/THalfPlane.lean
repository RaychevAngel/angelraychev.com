import TBoundary
import THalfPlaneArithmetic
import THalfPlaneStarters
import THalfPlaneGaps
import THalfPlaneDeepGaps
set_option maxHeartbeats 100000
set_option maxRecDepth 100000
namespace PolyominoFormal.THalfPlane
open CrossUnits TBoundary

theorem hp_bound {a b c : Int} (ha : 0≤a) (hb : 0≤b) (hc : 0≤c)
    (T : Tiling a b c 0 HalfPlane) {t : Cross} (ht : T.world t) : 0≤t.y-t.south := by
  have nn := TPlane.copy_nonnegative ha hb hc (by omega) (T.copies t ht)
  exact T.inside t ht t.x (t.y-t.south) (by
    unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)

theorem right_v_neighbor_long {a b c p r : Int} (ha : c≤a) (hc : 1≤c) (hb : a<b)
    (hr : r=a ∨ r=c) {t : Cross} (copy : Copy a b c 0 t)
    (bound : 0≤t.y-t.south) (hit : Contains t (p+1) 0)
    (sep : Apart t ⟨p,r,b,a+c-r,0,r⟩) : False := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound hit sep
  all_goals subst e; subst n; subst w; subst s
  all_goals simp only [Contains] at hit
  all_goals simp only [Apart] at sep
  all_goals omega

theorem no_right_v_long {a b c p r : Int} (ha : c≤a) (hc : 1≤c) (hb : a<b)
    (hr : r=a ∨ r=c) (T : Tiling a b c 0 HalfPlane)
    (anchor : T.world ⟨p,r,b,a+c-r,0,r⟩) : False := by
  obtain ⟨t,ht,hit⟩ := T.cover (p+1) 0 (by unfold HalfPlane; omega)
  have ap := separate (by omega) (by omega) (by omega) T ht anchor hit
    (by simp only [Contains]; omega)
  exact right_v_neighbor_long ha hc hb hr (T.copies t ht)
    (hp_bound (by omega) (by omega) (by omega) T ht) hit ap

theorem no_left_v_long {a b c p r : Int} (ha : c≤a) (hc : 1≤c) (hb : a<b)
    (hr : r=a ∨ r=c) (T : Tiling a b c 0 HalfPlane)
    (anchor : T.world ⟨p,r,0,a+c-r,b,r⟩) : False := by
  let U : Tiling a b c 0 HalfPlane := T.mirrorX.congr (by intro x y; rfl)
  have hu : U.world ⟨-p,r,b,a+c-r,0,r⟩ := ⟨_,anchor,rfl⟩
  exact no_right_v_long ha hc hb hr U hu

/-- The tile immediately beside a downward stem is forced to be a
horizontal crossbar, unless a very tall vertical crossbar is present. -/
theorem beside_s_forms {a b c p : Int} (ha : c≤a) (hc : 1≤c) (hb : 2≤b)
    {t : Cross} (copy : Copy a b c 0 t) (bound : 0≤t.y-t.south)
    (hit : Contains t (p+1) 0) (sep : Apart t ⟨p,b,a,0,c,b⟩) :
    t=⟨p+a+1,0,c,b,a,0⟩ ∨
    (a+c<b ∧ (t=⟨p+1,a,b,c,0,a⟩ ∨ t=⟨p+1,c,b,a,0,c⟩ ∨
      t=⟨p+1,a,0,c,b,a⟩ ∨ t=⟨p+1,c,0,a,b,c⟩)) := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound hit sep
  all_goals subst e; subst n; subst w; subst s
  all_goals apply Classical.byContradiction
  all_goals intro hnot
  · apply THalfPlaneArithmetic.beside_o0 a b c p x y
    refine ⟨ha,hc,hb,bound,hit,sep,?_⟩
    simpa only [Cross.mk.injEq] using hnot
  · apply THalfPlaneArithmetic.beside_o1 a b c p x y
    refine ⟨ha,hc,hb,bound,hit,sep,?_⟩
    simpa only [Cross.mk.injEq] using hnot
  · apply THalfPlaneArithmetic.beside_o2 a b c p x y
    refine ⟨ha,hc,hb,bound,hit,sep,?_⟩
    simpa only [Cross.mk.injEq] using hnot
  · apply THalfPlaneArithmetic.beside_o3 a b c p x y
    refine ⟨ha,hc,hb,bound,hit,sep,?_⟩
    simpa only [Cross.mk.injEq] using hnot
  · apply THalfPlaneArithmetic.beside_o4 a b c p x y
    refine ⟨ha,hc,hb,bound,hit,sep,?_⟩
    simpa only [Cross.mk.injEq] using hnot
  · apply THalfPlaneArithmetic.beside_o5 a b c p x y
    refine ⟨ha,hc,hb,bound,hit,sep,?_⟩
    simpa only [Cross.mk.injEq] using hnot
  · apply THalfPlaneArithmetic.beside_o6 a b c p x y
    refine ⟨ha,hc,hb,bound,hit,sep,?_⟩
    simpa only [Cross.mk.injEq] using hnot
  · apply THalfPlaneArithmetic.beside_o7 a b c p x y
    refine ⟨ha,hc,hb,bound,hit,sep,?_⟩
    simpa only [Cross.mk.injEq] using hnot

theorem enclosed_s_gap {a b c p : Int} (ha : c≤a) (hc : 1≤c) (hb : 2≤b)
    {t : Cross} (copy : Copy a b c 0 t) (bound : 0≤t.y-t.south)
    (hit : Contains t (p+1) 1) (sep : Apart t ⟨p,b,a,0,c,b⟩)
    (sep2 : Apart t ⟨p+a+1,0,c,b,a,0⟩) : False := by
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound hit sep sep2
  all_goals subst e; subst n; subst w; subst s
  · exact THalfPlaneArithmetic.enclosed_o0 a b c p x y ⟨ha,hc,hb,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.enclosed_o1 a b c p x y ⟨ha,hc,hb,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.enclosed_o2 a b c p x y ⟨ha,hc,hb,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.enclosed_o3 a b c p x y ⟨ha,hc,hb,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.enclosed_o4 a b c p x y ⟨ha,hc,hb,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.enclosed_o5 a b c p x y ⟨ha,hc,hb,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.enclosed_o6 a b c p x y ⟨ha,hc,hb,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.enclosed_o7 a b c p x y ⟨ha,hc,hb,bound,hit,sep,sep2⟩

theorem no_s_right {a b c p : Int} (ha : c≤a) (hc : 1≤c) (hb : 2≤b)
    (T : Tiling a b c 0 HalfPlane) (anchor : T.world ⟨p,b,a,0,c,b⟩) : False := by
  obtain ⟨u,hu,hitu⟩ := T.cover (p+1) 0 (by unfold HalfPlane; omega)
  have apu := separate (by omega) (by omega) (by omega) T hu anchor hitu
    (by simp only [Contains]; omega)
  have forms := beside_s_forms ha hc hb (T.copies u hu)
    (hp_bound (by omega) (by omega) (by omega) T hu) hitu apu
  have forced : u=⟨p+a+1,0,c,b,a,0⟩ := by
    rcases forms with h | ⟨long, h | h | h | h⟩
    · exact h
    · subst u
      exact False.elim (no_right_v_long ha hc (by omega) (Or.inl rfl) T
        (by simpa only [show a+c-a=c by omega] using hu))
    · subst u
      exact False.elim (no_right_v_long ha hc (by omega) (Or.inr rfl) T
        (by simpa only [show a+c-c=a by omega] using hu))
    · subst u
      exact False.elim (no_left_v_long ha hc (by omega) (Or.inl rfl) T
        (by simpa only [show a+c-a=c by omega] using hu))
    · subst u
      exact False.elim (no_left_v_long ha hc (by omega) (Or.inr rfl) T
        (by simpa only [show a+c-c=a by omega] using hu))
  subst u
  obtain ⟨v,hv,hitv⟩ := T.cover (p+1) 1 (by unfold HalfPlane; omega)
  have sep1 := separate (by omega) (by omega) (by omega) T hv anchor hitv
    (by simp only [Contains]; omega)
  have sep2 := separate (by omega) (by omega) (by omega) T hv hu hitv
    (by simp only [Contains]; omega)
  exact enclosed_s_gap ha hc hb (T.copies v hv)
    (hp_bound (by omega) (by omega) (by omega) T hv) hitv sep1 sep2

theorem no_s_left {a b c p : Int} (ha : c≤a) (hc : 1≤c) (hb : 2≤b)
    (T : Tiling a b c 0 HalfPlane) (anchor : T.world ⟨p,b,c,0,a,b⟩) : False := by
  let U : Tiling a b c 0 HalfPlane := T.mirrorX.congr (by intro x y; rfl)
  have hu : U.world ⟨-p,b,a,0,c,b⟩ := ⟨_,anchor,rfl⟩
  exact no_s_right ha hc hb U hu

/-- The first boundary cell in the direction of a vertical crossbar's stem
belongs to a horizontal bar beginning exactly at that cell. -/
theorem right_v_neighbor_horizontal {a b c p r : Int}
    (ha : c≤a) (hc : 1≤c) (hb : 2≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 HalfPlane)
    (anchor : T.world ⟨p,r,b,a+c-r,0,r⟩) :
    ∃ s, (s=a ∨ s=c) ∧ T.world ⟨p+1+s,0,a+c-s,b,s,0⟩ := by
  obtain ⟨u,hu,hit⟩ := T.cover (p+1) 0 (by unfold HalfPlane; omega)
  have sep := separate (by omega) (by omega) (by omega) T hu anchor hit
    (by simp only [Contains]; omega)
  have forms := THalfPlaneStarters.boundary_forms (by omega) (by omega) hc
    (T.copies u hu) (hp_bound (by omega) (by omega) (by omega) T hu) hit
  rcases forms with ⟨x,rfl,h0,h1⟩ | ⟨x,rfl,h0,h1⟩ | st
  · have hx : x=p+1+c := by dsimp [Apart] at sep; omega
    subst x
    exact ⟨c,Or.inr rfl,by simpa only [show a+c-c=a by omega] using hu⟩
  · have hx : x=p+1+a := by dsimp [Apart] at sep; omega
    subst x
    exact ⟨a,Or.inl rfl,by simpa only [show a+c-a=c by omega] using hu⟩
  · rcases st with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals exfalso
    · have eq := T.disjoint _ _ (p+1) r hu anchor
        (by right; dsimp; omega) (by left; dsimp; omega)
      have h := congrArg Cross.x eq; dsimp at h; omega
    · have eq := T.disjoint _ _ (p+1) r hu anchor
        (by right; dsimp; omega) (by left; dsimp; omega)
      have h := congrArg Cross.x eq; dsimp at h; omega
    · have eq := T.disjoint _ _ (p+1) r hu anchor
        (by right; dsimp; omega) (by left; dsimp; omega)
      have h := congrArg Cross.x eq; dsimp at h; omega
    · have eq := T.disjoint _ _ (p+1) r hu anchor
        (by right; dsimp; omega) (by left; dsimp; omega)
      have h := congrArg Cross.x eq; dsimp at h; omega
    · exact no_s_right ha hc hb T (by simpa using hu)
    · exact no_s_left ha hc hb T (by simpa using hu)

/-- The cell one unit above the forced H's left end is impossible when
its neighboring V has a long lower arm, or both bar arms are at least two. -/
theorem right_v_gap {a b c p r s : Int}
    (ha : c≤a) (hc : 1≤c) (hb : 2≤b) (short : b≤a)
    (hr : r=a ∨ (r=c ∧ 2≤c)) (hs : s=a ∨ s=c)
    {t : Cross} (copy : Copy a b c 0 t) (bound : 0≤t.y-t.south)
    (hit : Contains t (p+1) 1)
    (sep : Apart t ⟨p,r,b,a+c-r,0,r⟩)
    (sep2 : Apart t ⟨p+1+s,0,a+c-s,b,s,0⟩) : False := by
  rcases hr with hr | ⟨hr,hc2⟩
  all_goals subst r
  all_goals rcases hs with hs | hs
  all_goals subst s
  all_goals rcases t with ⟨x,y,e,n,w,z⟩
  all_goals rcases copy with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hz⟩
  all_goals dsimp only at he hn hw hz bound hit sep sep2
  all_goals subst e; subst n; subst w; subst z
  · exact THalfPlaneArithmetic.v_gap_r0_s0_o0 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s0_o1 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s0_o2 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s0_o3 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s0_o4 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s0_o5 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s0_o6 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s0_o7 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s1_o0 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s1_o1 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s1_o2 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s1_o3 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s1_o4 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s1_o5 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s1_o6 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r0_s1_o7 a b c p x y ⟨ha,hc,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s0_o0 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s0_o1 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s0_o2 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s0_o3 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s0_o4 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s0_o5 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s0_o6 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s0_o7 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s1_o0 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s1_o1 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s1_o2 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s1_o3 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s1_o4 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s1_o5 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s1_o6 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩
  · exact THalfPlaneArithmetic.v_gap_r1_s1_o7 a b c p x y ⟨ha,hc2,hb,short,bound,hit,sep,sep2⟩

theorem no_right_v_short_lower {a b c p r : Int}
    (ha : c≤a) (hc : 1≤c) (hb : 2≤b) (short : b≤a)
    (hr : r=a ∨ (r=c ∧ 2≤c))
    (T : Tiling a b c 0 HalfPlane)
    (anchor : T.world ⟨p,r,b,a+c-r,0,r⟩) : False := by
  have hr' : r=a ∨ r=c := by rcases hr with h | ⟨h,_⟩ <;> omega
  have rpos : 2≤r := by rcases hr with h | ⟨h,hc2⟩ <;> omega
  obtain ⟨s,hs,neighbor⟩ := right_v_neighbor_horizontal ha hc hb hr' T anchor
  obtain ⟨t,ht,hit⟩ := T.cover (p+1) 1 (by unfold HalfPlane; omega)
  have sep := separate (by omega) (by omega) (by omega) T ht anchor hit
    (by simp only [Contains]; omega)
  have sep2 := separate (by omega) (by omega) (by omega) T ht neighbor hit
    (by simp only [Contains]; omega)
  exact right_v_gap ha hc hb short hr hs (T.copies t ht)
    (hp_bound (by omega) (by omega) (by omega) T ht) hit sep sep2

theorem no_right_v_two {a b c p r : Int}
    (ha : c≤a) (hc : 2≤c) (hb : 2≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 HalfPlane)
    (anchor : T.world ⟨p,r,b,a+c-r,0,r⟩) : False := by
  by_cases long : a<b
  · exact no_right_v_long ha (by omega) long hr T anchor
  · exact no_right_v_short_lower ha (by omega) hb (by omega)
      (by rcases hr with h | h; exact Or.inl h; exact Or.inr ⟨h,hc⟩) T anchor

theorem no_left_v_two {a b c p r : Int}
    (ha : c≤a) (hc : 2≤c) (hb : 2≤b) (hr : r=a ∨ r=c)
    (T : Tiling a b c 0 HalfPlane)
    (anchor : T.world ⟨p,r,0,a+c-r,b,r⟩) : False := by
  let U : Tiling a b c 0 HalfPlane := T.mirrorX.congr (by intro x y; rfl)
  have hu : U.world ⟨-p,r,b,a+c-r,0,r⟩ := ⟨_,anchor,rfl⟩
  exact no_right_v_two ha hc hb hr U hu

theorem horizontal_cover_two {a b c : Int}
    (ha : c≤a) (hc : 2≤c) (hb : 2≤b)
    (T : Tiling a b c 0 HalfPlane) : THalfPlaneGaps.HorizontalCover T := by
  intro z
  obtain ⟨t,ht,hit⟩ := T.cover z 0 (by unfold HalfPlane; omega)
  have forms := THalfPlaneStarters.boundary_forms (by omega) (by omega) (by omega)
    (T.copies t ht) (hp_bound (by omega) (by omega) (by omega) T ht) hit
  rcases forms with ⟨x,rfl,h0,h1⟩ | ⟨x,rfl,h0,h1⟩ | st
  · refine ⟨x-c,c,Or.inr rfl,?_,h0,by omega⟩
    simpa only [Int.sub_add_cancel,show a+c-c=a by omega] using ht
  · refine ⟨x-a,a,Or.inl rfl,?_,h0,by omega⟩
    simpa only [Int.sub_add_cancel,show a+c-a=c by omega] using ht
  · rcases st with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals exfalso
    · exact no_right_v_two ha hc hb (Or.inl rfl) T
        (by simpa only [Int.zero_add,show a+c-a=c by omega] using ht)
    · exact no_right_v_two ha hc hb (Or.inr rfl) T
        (by simpa only [Int.zero_add,show a+c-c=a by omega] using ht)
    · exact no_left_v_two ha hc hb (Or.inl rfl) T
        (by simpa only [Int.zero_add,show a+c-a=c by omega] using ht)
    · exact no_left_v_two ha hc hb (Or.inr rfl) T
        (by simpa only [Int.zero_add,show a+c-c=a by omega] using ht)
    · exact no_s_right ha (by omega) hb T (by simpa only [Int.zero_add] using ht)
    · exact no_s_left ha (by omega) hb T (by simpa only [Int.zero_add] using ht)

theorem no_halfplane_two_short {a b c : Int}
    (ha : c≤a) (hc : 2≤c) (hb : 2≤b) (short : b≤a+c) :
    ¬Tiles a b c 0 HalfPlane := by
  rintro ⟨T⟩
  exact THalfPlaneGaps.all_horizontal_short_impossible ha hc (by omega) short T
    (horizontal_cover_two ha hc hb T)

/-- Complete half-plane obstruction when both crossbar arms have length at
least two; all stem lengths b>=2 are covered. -/
theorem no_halfplane_two {a b c : Int}
    (ha : c≤a) (hc : 2≤c) (hb : 2≤b) : ¬Tiles a b c 0 HalfPlane := by
  by_cases short : b≤a+c
  · exact no_halfplane_two_short ha hc hb short
  · rintro ⟨T⟩
    exact THalfPlaneDeepGaps.all_horizontal_long_impossible ha (by omega) (by omega) T
      (horizontal_cover_two ha hc hb T)

theorem horizontal_cover_long {a b c : Int}
    (ha : c≤a) (hc : 1≤c) (long : a<b)
    (T : Tiling a b c 0 HalfPlane) : THalfPlaneGaps.HorizontalCover T := by
  intro z
  obtain ⟨t,ht,hit⟩ := T.cover z 0 (by unfold HalfPlane; omega)
  have forms := THalfPlaneStarters.boundary_forms (by omega) (by omega) (by omega)
    (T.copies t ht) (hp_bound (by omega) (by omega) (by omega) T ht) hit
  rcases forms with ⟨x,rfl,h0,h1⟩ | ⟨x,rfl,h0,h1⟩ | st
  · refine ⟨x-c,c,Or.inr rfl,?_,h0,by omega⟩
    simpa only [Int.sub_add_cancel,show a+c-c=a by omega] using ht
  · refine ⟨x-a,a,Or.inl rfl,?_,h0,by omega⟩
    simpa only [Int.sub_add_cancel,show a+c-a=c by omega] using ht
  · rcases st with rfl | rfl | rfl | rfl | rfl | rfl
    all_goals exfalso
    · exact no_right_v_long ha hc long (Or.inl rfl) T
        (by simpa only [Int.zero_add,show a+c-a=c by omega] using ht)
    · exact no_right_v_long ha hc long (Or.inr rfl) T
        (by simpa only [Int.zero_add,show a+c-c=a by omega] using ht)
    · exact no_left_v_long ha hc long (Or.inl rfl) T
        (by simpa only [Int.zero_add,show a+c-a=c by omega] using ht)
    · exact no_left_v_long ha hc long (Or.inr rfl) T
        (by simpa only [Int.zero_add,show a+c-c=a by omega] using ht)
    · exact no_s_right ha hc (by omega) T (by simpa only [Int.zero_add] using ht)
    · exact no_s_left ha hc (by omega) T (by simpa only [Int.zero_add] using ht)

theorem no_halfplane_unit_long {a b : Int} (ha : 1≤a) (hb : a<b) :
    ¬Tiles a b 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact THalfPlaneDeepGaps.all_horizontal_long_impossible ha (by omega) (by omega) T
    (horizontal_cover_long ha (by omega) hb T)

#print axioms no_s_right
#print axioms right_v_neighbor_horizontal
#print axioms no_right_v_two
#print axioms no_halfplane_two_short
#print axioms no_halfplane_two
#print axioms no_halfplane_unit_long
end PolyominoFormal.THalfPlane

import LHalfPlaneAlternating
namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits THalfPlaneStarters THalfPlaneGaps LRegion
set_option maxHeartbeats 200000
set_option maxRecDepth 10000

theorem no_short_starter_shifted {a b p q : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : q+1≤p ∧ p≤q+2*a) (T : Tiling a b 0 0 HalfPlane)
    (h0 : T.world ⟨q-1,0,0,b,a,0⟩) (h1 : T.world ⟨q,0,a,b,0,0⟩)
    (h2 : T.world ⟨q+2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨q+2*a+2,0,a,b,0,0⟩)
    {t : Cross} (ht : T.world t) (st : LHalfPlaneLocal.Tip a b p 1 t) : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-q) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  have member : U.world (shift (-q) 0 t) := ⟨t,ht,rfl⟩
  refine no_short_starter (p:=p-q) ha hb hab (by omega) U ?_ ?_ ?_ ?_ member ?_
  · refine ⟨_,h0,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h1,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h2,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · refine ⟨_,h3,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  · rcases st with rfl|rfl
    · left; apply same_eq; dsimp [Same,shift]; omega
    · right; apply same_eq; dsimp [Same,shift]; omega

theorem no_short_starter_three_pockets {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : -2*a-1≤p ∧ p≤4*a+2) (T : Tiling a b 0 0 HalfPlane)
    (hL0 : T.world ⟨-2*a-3,0,0,b,a,0⟩) (hL1 : T.world ⟨-2*a-2,0,a,b,0,0⟩)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (hR0 : T.world ⟨4*a+3,0,0,b,a,0⟩) (hR1 : T.world ⟨4*a+4,0,a,b,0,0⟩)
    {t : Cross} (ht : T.world t) (st : LHalfPlaneLocal.Tip a b p 1 t) : False := by
  by_cases left : p≤-2
  · apply no_short_starter_shifted (q:=-2*a-2) ha hb hab (by omega) T _ hL1 _ _ ht st
    · simpa only [show -2*a-2-1=-2*a-3 by omega] using hL0
    · simpa only [show -2*a-2+2*a+1=-1 by omega] using h0
    · simpa only [show -2*a-2+2*a+2=0 by omega] using h1
  by_cases center : 1≤p ∧ p≤2*a
  · exact no_short_starter ha hb hab center T h0 h1 h2 h3 ht st
  by_cases right : 2*a+3≤p
  · apply no_short_starter_shifted (q:=2*a+2) ha hb hab (by omega) T _ h3 _ _ ht st
    · simpa only [show 2*a+2-1=2*a+1 by omega] using h2
    · simpa only [show 2*a+2+2*a+1=4*a+3 by omega] using hR0
    · simpa only [show 2*a+2+2*a+2=4*a+4 by omega] using hR1
  have base : Base a b p 1 := by dsimp [Base,Contains]; omega
  have hit : Contains t p 1 := LHalfPlaneLocal.tip_base (by omega) (by omega) st
  rcases base with (base|base)|(base|base)
  · have eq := T.disjoint _ _ p 1 ht h0 hit base
    have y := congrArg Cross.y eq
    rcases st with rfl|rfl <;> dsimp at y <;> omega
  · have eq := T.disjoint _ _ p 1 ht h1 hit base
    have y := congrArg Cross.y eq
    rcases st with rfl|rfl <;> dsimp at y <;> omega
  · have eq := T.disjoint _ _ p 1 ht h2 hit base
    have y := congrArg Cross.y eq
    rcases st with rfl|rfl <;> dsimp at y <;> omega
  · have eq := T.disjoint _ _ p 1 ht h3 hit base
    have y := congrArg Cross.y eq
    rcases st with rfl|rfl <;> dsimp at y <;> omega

#print axioms no_short_starter_three_pockets

theorem no_right_long_starter_eight {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 1≤p ∧ p≤2*a-3) (T : Tiling a b 0 0 HalfPlane)
    (hL0 : T.world ⟨-2*a-3,0,0,b,a,0⟩) (hL1 : T.world ⟨-2*a-2,0,a,b,0,0⟩)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (hR0 : T.world ⟨4*a+3,0,0,b,a,0⟩) (hR1 : T.world ⟨4*a+4,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,a+1,b,0,0,a⟩) : False := by
  let V := T.translate (-p) (-1)
  let W : Cross → Prop := fun t =>
    V.world t ∧ 0≤t.y-t.south ∧ ¬LRegion.ForbiddenShortTip a b t
  have copy : ∀t,W t→Copy a b 0 0 t := fun t ht => V.copies t ht.1
  have separate : ∀t u,W t→W u→t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
        (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copy t ht))
        (TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copy u hu))
      intro x y h h'
      exact eq (V.disjoint t u x y ht.1 hu.1 h h')
  have coverage : ∀x y,(1≤x ∧ x≤3 ∧ ((0≤y ∧ y≤3) ∨ y=b+1 ∨ y=b+2)) →
      ∃t,W t ∧ Contains t x y := by
    intro x y query
    obtain ⟨t,ht,hit⟩ := T.cover (x+p) (y+1) (by unfold HalfPlane; omega)
    have above := gap_tile_above_floor (by omega) (by omega) (by omega)
      (by omega : 1≤x+p ∧ x+p≤2*a) (by omega : 1≤y+1) T h0 h1 h2 h3 ht hit
    refine ⟨shift (-p) (-1) t,⟨⟨t,ht,rfl⟩,?_,?_⟩,?_⟩
    · dsimp [shift]; omega
    · intro forbidden
      rcases t with ⟨tx,ty,e,n,w,s⟩
      rcases forbidden with ⟨jy,hn,hs,arms⟩
      dsimp only [shift] at jy hn hs arms
      have ty' : ty=b+1 := by omega
      subst ty; subst n; subst s
      rcases arms with ⟨he,hw⟩ | ⟨he,hw⟩
      · subst e; subst w
        have reach : x+p-a≤tx ∧ tx≤x+p+a := by unfold Contains at hit; dsimp only at hit; omega
        apply no_short_starter_three_pockets (p:=tx) ha hb hab (by omega) T hL0 hL1 h0 h1 h2 h3 hR0 hR1 ht
        left; apply same_eq; dsimp [Same]; omega
      · subst e; subst w
        have reach : x+p-a≤tx ∧ tx≤x+p+a := by unfold Contains at hit; dsimp only at hit; omega
        apply no_short_starter_three_pockets (p:=tx) ha hb hab (by omega) T hL0 hL1 h0 h1 h2 h3 hR0 hR1 ht
        right; apply same_eq; dsimp [Same]; omega
    · apply (contains_shift _ _ _ _ _).2
      have xx : x - -p = x+p := by omega
      have yy : y - -1 = y+1 := by omega
      simpa only [xx,yy] using hit
  have initial : W ⟨0,a,b,0,0,a⟩ := by
    refine ⟨⟨_,anchor,?_⟩,by dsimp; omega,?_⟩
    · apply same_eq; dsimp [Same,shift]; omega
    · intro bad; have h := bad.1; dsimp at h; omega
  exact local_long_tip_node000 a b (by omega) (by omega) hab ha W copy
    (fun _ ht => ht.2.1) coverage separate (fun _ ht => ht.2.2) initial

#print axioms no_right_long_starter_eight

theorem no_left_long_starter_eight {a b p : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (hp : 4≤p ∧ p≤2*a) (T : Tiling a b 0 0 HalfPlane)
    (hL0 : T.world ⟨-2*a-3,0,0,b,a,0⟩) (hL1 : T.world ⟨-2*a-2,0,a,b,0,0⟩)
    (h0 : T.world ⟨-1,0,0,b,a,0⟩) (h1 : T.world ⟨0,0,a,b,0,0⟩)
    (h2 : T.world ⟨2*a+1,0,0,b,a,0⟩) (h3 : T.world ⟨2*a+2,0,a,b,0,0⟩)
    (hR0 : T.world ⟨4*a+3,0,0,b,a,0⟩) (hR1 : T.world ⟨4*a+4,0,a,b,0,0⟩)
    (anchor : T.world ⟨p,a+1,0,0,b,a⟩) : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.mirrorX.translate (2*a+1) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  have member (t : Cross) (ht : T.world t) :
      U.world ⟨2*a+1-t.x,t.y,t.west,t.north,t.east,t.south⟩ := by
    refine ⟨mirrorX t,⟨t,ht,rfl⟩,?_⟩
    apply same_eq; dsimp [Same,shift,mirrorX]; omega
  apply no_right_long_starter_eight ha hb hab (p:=2*a+1-p) (by omega) U
  · have h := member _ hR1
    have e : 2*a+1-(4*a+4) = -2*a-3 := by omega
    simpa only [e] using h
  · have h := member _ hR0
    have e : 2*a+1-(4*a+3) = -2*a-2 := by omega
    simpa only [e] using h
  · have h := member _ h3
    have e : 2*a+1-(2*a+2) = -1 := by omega
    simpa only [e] using h
  · have h := member _ h2
    have e : 2*a+1-(2*a+1) = 0 := by omega
    simpa only [e] using h
  · have h := member _ h1
    have e : 2*a+1-0 = 2*a+1 := by omega
    simpa only [e] using h
  · have h := member _ h0
    have e : 2*a+1-(-1) = 2*a+2 := by omega
    simpa only [e] using h
  · have h := member _ hL1
    have e : 2*a+1-(-2*a-2) = 4*a+3 := by omega
    simpa only [e] using h
  · have h := member _ hL0
    have e : 2*a+1-(-2*a-3) = 4*a+4 := by omega
    simpa only [e] using h
  · exact member _ anchor

#print axioms no_left_long_starter_eight
end PolyominoFormal.LHalfPlaneAlternating

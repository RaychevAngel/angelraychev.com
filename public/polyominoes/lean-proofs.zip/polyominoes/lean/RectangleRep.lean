import CoreBoundaryObstructions

namespace PolyominoFormal
open CrossUnits

def Dilate (R : Region) (k : Int) : Region := fun x y => R (x/k) (y/k)

theorem grid_div (x w h : Int) (hw : 0<w) (hh : 0<h) :
    x/(w*h)=(x/w)/h := (Int.ediv_ediv_of_nonneg (by omega)).symm

/-- Every rectangle tiling induces a tiling of the cellwise dilation of
    any region, because its boundary is aligned with the rectangle grid. -/
def Tiling.dilateAnyRegion {a b c d w h : Int} (hw : 0<w) (hh : 0<h)
    (T : Tiling a b c d (Rectangle w h)) (R : Region) :
    Tiling a b c d (Dilate R (w*h)) where
  world t := ∃ i j u, R (i/h) (j/w) ∧ T.world u ∧ shift (i*w) (j*h) u=t
  copies := by
    rintro t ⟨i,j,u,hr,hu,rfl⟩
    exact (copy_shift _ _ _ _ _ _ _).2 (T.copies u hu)
  inside := by
    rintro t ⟨i,j,u,hr,hu,rfl⟩ x y hit
    have inside := T.inside u hu _ _ ((contains_shift _ _ _ _ _).1 hit)
    have qx : x/w=i := (Int.ediv_eq_iff_of_pos hw).2 (by unfold Rectangle at inside; omega)
    have qy : y/h=j := (Int.ediv_eq_iff_of_pos hh).2 (by unfold Rectangle at inside; omega)
    unfold Dilate
    have dx : x/(w*h)=i/h := by rw [grid_div x w h hw hh,qx]
    have dy : y/(w*h)=j/w := by rw [Int.mul_comm w h,grid_div y h w hh hw,qy]
    simpa only [dx,dy] using hr
  cover := by
    intro x y hit
    have rx0 := Int.emod_nonneg x (by omega : w≠0)
    have rxw := Int.emod_lt_of_pos x hw
    have ry0 := Int.emod_nonneg y (by omega : h≠0)
    have ryh := Int.emod_lt_of_pos y hh
    obtain ⟨u,hu,hc⟩ := T.cover (x%w) (y%h) ⟨rx0,rxw,ry0,ryh⟩
    have dx : x/(w*h)=(x/w)/h := grid_div x w h hw hh
    have dy : y/(w*h)=(y/h)/w := by rw [Int.mul_comm w h]; exact grid_div y h w hh hw
    have selected : R ((x/w)/h) ((y/h)/w) := by
      unfold Dilate at hit
      simpa only [dx,dy] using hit
    refine ⟨shift ((x/w)*w) ((y/h)*h) u,⟨x/w,y/h,u,selected,hu,rfl⟩,?_⟩
    rw [contains_shift]
    have hx : x-x/w*w=x%w := by have := Int.emod_add_ediv_mul x w; omega
    have hy : y-y/h*h=y%h := by have := Int.emod_add_ediv_mul y h; omega
    simpa only [hx,hy] using hc
  disjoint := by
    rintro t u x y ⟨i,j,v,hr,hv,rfl⟩ ⟨i',j',v',hr',hv',rfl⟩ hc hd
    have cv := (contains_shift _ _ _ _ _).1 hc
    have cv' := (contains_shift _ _ _ _ _).1 hd
    have inside := T.inside v hv _ _ cv
    have inside' := T.inside v' hv' _ _ cv'
    have qx : x/w=i := (Int.ediv_eq_iff_of_pos hw).2 (by unfold Rectangle at inside; omega)
    have qx' : x/w=i' := (Int.ediv_eq_iff_of_pos hw).2 (by unfold Rectangle at inside'; omega)
    have qy : y/h=j := (Int.ediv_eq_iff_of_pos hh).2 (by unfold Rectangle at inside; omega)
    have qy' : y/h=j' := (Int.ediv_eq_iff_of_pos hh).2 (by unfold Rectangle at inside'; omega)
    have hi : i=i' := by omega
    have hj : j=j' := by omega
    have sameTile := T.disjoint v v' _ _ hv hv' cv
      (by simpa only [←hi,←hj] using cv')
    rw [←hi,←hj,sameTile]

theorem dilation_is_scaled_cross (a b c d k : Int) (hk : 0<k) (x y : Int) :
    Dilate (Contains ⟨0,0,a,b,c,d⟩) k x y ↔
      CoreBoundaryObstructions.ScaledCross a b c d k x y := by
  unfold Dilate Contains CoreBoundaryObstructions.ScaledCross
  simp only [Int.zero_sub]
  rw [Int.le_ediv_iff_mul_le hk,Int.ediv_le_iff_le_mul hk,
    Int.le_ediv_iff_mul_le hk,Int.ediv_le_iff_le_mul hk,
    Int.le_ediv_iff_mul_le hk,Int.ediv_le_iff_le_mul hk,
    Int.le_ediv_iff_mul_le hk,Int.ediv_le_iff_le_mul hk]
  simp only [Int.zero_mul,Int.zero_add,Int.add_mul,Int.one_mul]

def RepTileable (a b c d : Int) : Prop :=
  ∃ k : Nat, 2≤k ∧ Tiles a b c d (CoreBoundaryObstructions.ScaledCross a b c d k)

def Tiling.doubleRectangle {a b c d w h : Int} (hw : 0<w)
    (T : Tiling a b c d (Rectangle w h)) : Tiling a b c d (Rectangle (w+w) h) :=
  (T.union (T.translate w 0) (by
    intro x y hl hr
    unfold Rectangle at hl hr
    omega)).congr (by intro x y; unfold Rectangle; omega)

theorem rectangle_implies_rep {a b c d : Int} (tiled : RectangleTileable a b c d) :
    RepTileable a b c d := by
  obtain ⟨w,h,hw,hh,⟨T⟩⟩ := tiled
  have hW : 0<w+w := by omega
  let U := T.doubleRectangle hw
  let k := (w+w)*h
  have kPositive : 0<k := Int.mul_pos hW hh
  have lower := Int.mul_le_mul_of_nonneg_left (by omega : 1≤h) (by omega : 0≤w+w)
  have kTwo : 2≤k := by dsimp [k]; simp only [Int.mul_one] at lower; omega
  have tiling := (U.dilateAnyRegion hW hh (Contains ⟨0,0,a,b,c,d⟩)).congr
    (dilation_is_scaled_cross a b c d k kPositive)
  refine ⟨k.toNat,by omega,?_⟩
  have hk : (k.toNat : Int)=k := by omega
  rw [hk]
  exact ⟨tiling⟩

#print axioms rectangle_implies_rep
end PolyominoFormal

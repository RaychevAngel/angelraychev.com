import Std.Tactic
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_equal_tip_long_n000_point (a b : Int)
    (h0 : (¬ (((1 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (((-1 : Int) + a) ≥ (0 : Int)) ∧ ((1 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (((-1 : Int) + a) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_empty (a b : Int)
    (h0 : (((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)) ∧ (a ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ a)) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((a - a) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (a + (0 : Int)))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_o0 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + b) < a) ∨ (a < (jy - (0 : Int)))))
    (h1 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (a - a)) ∨ ((a + (0 : Int)) < jy)))
    (h2 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (jy + b)))))
    (h3 : (a = b))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < a) ∨ (a < (jy - a))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (jy + (0 : Int))))))
    (h1 : (a = b))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < a) ∨ (a < (jy - b))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (jy + a)))))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < (a - a)) ∨ ((a + (0 : Int)) < jy)))
    (h3 : (¬ (((jx = ((1 : Int) + b)) ∧ (jy = ((-1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((1 : Int) + a)) ∧ (jy = ((-1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = b) ∧ (b = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (jy + (0 : Int))))))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < a) ∨ (a < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_o5 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (jy + b)))))
    (h1 : (a = b))
    (h2 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + b) < a) ∨ (a < (jy - (0 : Int)))))
    (h3 : (¬ (((jx = ((1 : Int) + b)) ∧ (jy = ((-1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = a) ∧ (a = b) ∧ ((0 : Int) = (0 : Int))) ∨ ((jx = ((1 : Int) + a)) ∧ (jy = ((-1 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_o6 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (jy + a)))))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (a - a)) ∨ ((a + (0 : Int)) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + a) < a) ∨ (a < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n000_o7 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-1 : Int) + a)) ∧ (((-1 : Int) + a) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (a = b))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < a) ∨ (a < (jy - b))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (((-2 : Int) + a) ≥ (0 : Int)) ∧ ((1 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (((-2 : Int) + a) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_empty (a b : Int)
    (h0 : (((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)) ∧ (a ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ a)) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((a - a) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (a + (0 : Int))))) ∨ ((((1 : Int) ≥ (((1 : Int) + b) - b)) ∧ ((1 : Int) ≤ (((1 : Int) + b) + (0 : Int))) ∧ (((-1 : Int) + a) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ ((-1 : Int) + a))) ∨ (((1 : Int) ≥ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((1 : Int) + b)) ∧ ((((-1 : Int) + a) - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (((-1 : Int) + a) + a))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_o0 (a b jx jy : Int)
    (h0 : (a = b))
    (h1 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + b)))))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (a - a)) ∨ ((a + (0 : Int)) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jx) ∨ ((jy + b) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_o1 (a b jx jy : Int)
    (h0 : (((jx + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < (jx - (0 : Int))) ∨ (jy < (((-1 : Int) + a) - (0 : Int))) ∨ ((((-1 : Int) + a) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_o2 (a b jx jy : Int)
    (h0 : ((jx < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - b))))
    (h1 : (a = b))
    (h2 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jx) ∨ ((jy + a) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + a)))))
    (h3 : (b ≥ (3 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - a))))
    (h2 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + (0 : Int))))))
    (h3 : ((jy - a) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_o5 (a b jx jy : Int)
    (h0 : ((jx < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jx) ∨ ((jy + b) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - (0 : Int)))))
    (h1 : (a = b))
    (h2 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + b)))))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (a - a)) ∨ ((a + (0 : Int)) < jy)))
    (h1 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + a)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jx) ∨ ((jy + a) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n001_o7 (a b jx jy : Int)
    (h0 : ((jx < (((1 : Int) + b) - b)) ∨ ((((1 : Int) + b) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - b))))
    (h1 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + (0 : Int))))))
    (h2 : (a = b))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((1 : Int) ≥ (-((2 : Int) * ((a + b) + (1 : Int))))) ∧ (((-2 : Int) + a) ≥ (0 : Int)) ∧ ((1 : Int) ≤ ((2 : Int) * ((a + b) + (1 : Int)))) ∧ (((-2 : Int) + a) ≤ ((2 : Int) * ((a + b) + (1 : Int)))))))
    (h2 : (a ≥ b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_empty (a b : Int)
    (h0 : (((((1 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((1 : Int) ≤ ((0 : Int) + b)) ∧ (a ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ a)) ∨ (((0 : Int) ≤ (1 : Int)) ∧ ((1 : Int) ≤ (0 : Int)) ∧ ((a - a) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (a + (0 : Int))))) ∨ ((((1 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((1 : Int) ≤ (((1 : Int) + a) + (0 : Int))) ∧ (((-1 : Int) + a) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ ((-1 : Int) + a))) ∨ (((1 : Int) ≥ ((1 : Int) + a)) ∧ ((1 : Int) ≤ ((1 : Int) + a)) ∧ ((((-1 : Int) + a) - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (((-1 : Int) + a) + b))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_o0 (a b jx jy : Int)
    (h0 : (a = b))
    (h1 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + b)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (a - a)) ∨ ((a + (0 : Int)) < jy)))
    (h4 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + b) < a) ∨ (a < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_o1 (a b jx jy : Int)
    (h0 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < a) ∨ (a < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + (0 : Int))))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_o2 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - b))))
    (h2 : (a = b))
    (h3 : ((jy - b) ≥ (0 : Int)))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_o3 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jx) ∨ ((jy + a) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (a ≥ b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_o4 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - b)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - a) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < a) ∨ (a < (jy - a))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((jx < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jx) ∨ ((jy + b) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((((1 : Int) ≥ (jx - a)) ∧ ((1 : Int) ≤ (jx + (0 : Int))) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + b)))))
    (h3 : (a = b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_o6 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + b)) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - (0 : Int)) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + a)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < (a - a)) ∨ ((a + (0 : Int)) < jy)))
    (h3 : ((jx < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jx) ∨ ((jy + a) < ((-1 : Int) + a)) ∨ (((-1 : Int) + a) < (jy - (0 : Int)))))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

theorem HP_equal_tip_long_n002_o7 (a b jx jy : Int)
    (h0 : ((((1 : Int) ≥ (jx - (0 : Int))) ∧ ((1 : Int) ≤ (jx + a)) ∧ (jy ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ jy)) ∨ (((1 : Int) ≥ jx) ∧ ((1 : Int) ≤ jx) ∧ ((jy - b) ≤ ((-2 : Int) + a)) ∧ (((-2 : Int) + a) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < a) ∨ (a < (jy - b))))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (a = b))
    : False := by
  try simp only [or_true, true_or, and_true, true_and] at *
  all_goals omega

end LRegionArithmetic

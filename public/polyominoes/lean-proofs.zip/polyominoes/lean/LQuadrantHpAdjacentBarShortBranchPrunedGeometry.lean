import LQuadrantHpAdjacentBarShortBranchPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
import LHalfPlaneBoundaryPairPruning
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_adjacent_bar_short_branch_pruned_M (a b : Int) : Int := 4*(a+b+1)
def HP_adjacent_bar_short_branch_pruned_Box (a b x y : Int) : Prop := -HP_adjacent_bar_short_branch_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_adjacent_bar_short_branch_pruned_M a b ∧ y≤HP_adjacent_bar_short_branch_pruned_M a b
def HP_adjacent_bar_short_branch_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_adjacent_bar_short_branch_pruned_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_empty a b (ap2_3).2.2.1 ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_o0 a b jx jy (hb) (hlong) (insideT) (hit) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_o1 a b jx jy (sep3).2.2.1 (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_o2 a b jx jy (hit) (insideT) (hlong) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_o3 a b jx jy (sep3).2.2.1 (insideT) (hlong) (hit) (hadjacent) (sep2).2.1 (sep1).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_o4 a b jx jy (hlong) (hit) (sep3).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_o5 a b jx jy (insideT) (hadjacent) (sep1).1 (hlong) (sep3).2.2.1 (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_o6 a b jx jy (insideT) (hlong) (hstrict) (sep3).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n002_o7 a b jx jy (sep3).2.2.1 (hb) (hlong) (hit) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node005 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_point a b (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_empty a b ((by simpa only [Contains] using occupied)) (ap4_5).2.2.1 (hlong)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_o0 a b jx jy (hit) (insideT) (hlong) (hb) (sep1).2.2.1 (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_o1 a b jx jy (insideT) (sep5).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_o2 a b jx jy (insideT) (sep5).2.1 (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_o3 a b jx jy (insideT) (sep1).1 (hit) (hstrict) (sep2).2.1 (sep5).2.2.1 (hb) (ap4_5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_o4 a b jx jy (hb) (hit) (hstrict) (sep5).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_o5 a b jx jy (insideT) (sep2).2.1 (hit) (sep5).2.2.1 (sep1).1 (hb) (hstrict) (ap4_5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_o6 a b jx jy (sep5).2.2.1 (hit) (insideT) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n005_o7 a b jx jy (insideT) (sep5).2.2.1 (hit) (hstrict) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node006 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_o0 a b jx jy (hit) (hadjacent) (sep3).2.2.1 (sep3).2.1 (hb) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_o1 a b jx jy (sep3).2.2.1 (hit) (insideT) (sep1).2.2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_o2 a b jx jy (sep3).2.1 (hstrict) (hit) (insideT) (ap4_5).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_o3 a b jx jy (sep5).2.2.1 (hlong) (sep5).2.2.2 (sep3).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_o4 a b jx jy (sep3).2.2.1 (insideT) (hit) (sep1).2.2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_o5 a b jx jy (sep0).2.1 (insideT) (hit) (sep5).2.1 (sep3).2.2.1 (hadjacent) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_o6 a b jx jy (hb) (sep5).2.2.1 (sep3).2.1 (hlong) (sep5).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n006_o7 a b jx jy (insideT) (hit) (sep5).2.1 (hb) (ap4_5).2.1 (hstrict)

theorem HP_adjacent_bar_short_branch_pruned_node007 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_empty a b ((by simpa only [Contains] using occupied)) (ap4_5).2.2.1 (hstrict)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_o0 a b jx jy (hit) (insideT) (sep5).2.2.1 (hb) (hlong) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_o1 a b jx jy (sep5).2.2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_o2 a b jx jy (insideT) (sep5).2.2.1 (hit) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_o3 a b jx jy (hb) (sep2).2.1 (ap4_5).2.2.1 (sep0).1 (hit) (sep1).1 (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_o4 a b jx jy (insideT) (sep5).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_o5 a b jx jy (hit) (sep1).1 (ap4_5).2.2.1 (sep5).2.2.1 (insideT) (hstrict) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_o6 a b jx jy (insideT) (hlong) (sep1).1 (hit) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n007_o7 a b jx jy (hb) (sep5).2.1 (hit) (hstrict) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node009 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht6 : world (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_6 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_6 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_6 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_6 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_6 : Apart (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap5_6 : Apart (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have in6 := inside (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have allowed6 := avoid (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht6
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht5
  have pairAllowed0_6 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht6
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht5
  have pairAllowed1_6 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht6
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht5
  have pairAllowed2_6 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht6
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht5
  have pairAllowed3_6 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht6
  have pairAllowed4_5 := avoidPair (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht5
  have pairAllowed4_6 := avoidPair (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht6
  have pairAllowed5_6 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5 ht6
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hstrict) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5
  have pairAllowed6 := avoidPair t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht6
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit)))))))
    · exact ap
  have sep6 : Apart t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht6 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit)))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_o0 a b jx jy (sep1).2.2.1 (hit) (hstrict) (hb) (sep5).2.1 (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_o1 a b jx jy (hit) (insideT) (allowed) (sep5).2.2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_o2 a b jx jy (hit) (sep3).2.1 (hstrict) (ap4_6).2.2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_o3 a b jx jy (sep6).2.2.1 (hit) (sep5).2.2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_o4 a b jx jy (allowed) (hit) (hb) (hstrict) (insideT) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_o5 a b jx jy (sep6).2.2.1 (hb) (hstrict) (sep6).2.2.2 (sep5).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_o6 a b jx jy (sep3).2.1 (hb) (hit) (sep5).2.2.1 (hstrict) (sep6).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n009_o7 a b jx jy (hb) (hstrict) (sep5).2.2.1 (insideT) (hit) (sep1).2.2.1 (ap4_6).2.2.1

theorem HP_adjacent_bar_short_branch_pruned_node008 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_o0 a b jx jy (sep5).2.2.1 (hit) (sep1).2.2.1 (hb) (sep5).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_o1 a b jx jy (insideT) (sep5).2.2.1 (hb) (hstrict) (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_o2 a b jx jy (hb) (sep5).2.1 (hstrict) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_o3 a b jx jy (insideT) (sep5).2.2.1 (hit) (sep0).2.1 (ap4_5).2.2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_o4 a b jx jy (hit) (sep3).2.1 (insideT) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_o5 a b jx jy (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (hit) (hstrict) (sep5).2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4 sep5
    exact HP_adjacent_bar_short_branch_pruned_node009 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht5 ht ap0_1 ap0_2 ap0_3 ap0_4 ap0_5 (apart_sym sep0) ap1_2 ap1_3 ap1_4 ap1_5 (apart_sym sep1) ap2_3 ap2_4 ap2_5 (apart_sym sep2) ap3_4 ap3_5 (apart_sym sep3) ap4_5 (apart_sym sep4) (apart_sym sep5)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_o6 a b jx jy (hit) (sep3).2.1 (sep1).2.2.1 (sep5).2.2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n008_o7 a b jx jy (hit) (hb) (insideT) (sep5).2.2.1 (hstrict) (sep1).2.2.1

theorem HP_adjacent_bar_short_branch_pruned_node004 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_o0 a b jx jy (sep3).2.1 (sep1).2.2.1 (hlong) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node005 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_o1 a b jx jy (sep3).1 (sep1).2.2.1 (hit) (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_o2 a b jx jy (hlong) (insideT) (sep3).2.2.1 (hit) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_o3 a b jx jy (hb) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1 (hlong) (sep3).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node006 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_o4 a b jx jy (insideT) (sep3).2.1 (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_o5 a b jx jy (hlong) (hit) (sep3).2.1 (insideT) (sep0).2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node007 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_o6 a b jx jy (hb) (hit) (hlong) (sep3).2.1 (sep3).2.2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n004_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hb) (insideT) (hlong) (sep1).2.2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node008 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)

theorem HP_adjacent_bar_short_branch_pruned_node010 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (ha)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_empty a b (hadjacent) (ap3_4).2.2.1 ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_o0 a b jx jy (hadjacent) (sep1).2.2.1 (insideT) (hit) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_o1 a b jx jy (sep4).2.2.1 (hb) (hit) (insideT) (hstrict) (ap3_4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_o2 a b jx jy (hb) (hit) (insideT) (ap3_4).2.2.1 (allowed) (hstrict) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_o3 a b jx jy (insideT) (hit) (hstrict) (sep2).2.1 (sep4).2.2.1 (sep1).1 (ap3_4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_o4 a b jx jy (hit) (ap3_4).2.2.1 (sep4).2.2.1 (insideT) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_o5 a b jx jy (sep2).1 (hit) (insideT) (sep4).2.2.1 (ap3_4).2.2.1 (sep4).2.1 (hb) (ha)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_o6 a b jx jy (sep2).2.1 (insideT) (hit) (sep1).2.2.1 (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n010_o7 a b jx jy (sep4).1 (ap3_4).2.2.1 (allowed) (hit) (hb) (insideT) (ha)

theorem HP_adjacent_bar_short_branch_pruned_node012 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht5 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have in5 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed5 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_o0 a b jx jy (hit) (sep3).2.1 (sep3).2.2.1 (sep5).2.2.1 (hadjacent) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_o1 a b jx jy (hb) (allowed) (sep3).2.2.1 (hit) (hstrict) (sep4).1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_o2 a b jx jy (hit) (hb) (insideT) (ap4_5).2.2.1 (sep3).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_o3 a b jx jy (hit) (insideT) (hlong) (sep4).2.2.1 (sep0).2.1 (hb) (ap4_5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_o4 a b jx jy (sep3).2.1 (hit) (hstrict) (hb) (insideT) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_o5 a b jx jy (hadjacent) (insideT) (sep4).2.1 (hit) (sep4).2.2.1 (sep0).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_o6 a b jx jy (hb) (sep3).2.2.1 (sep5).2.2.1 (hit) (sep5).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n012_o7 a b jx jy (ap4_5).2.2.1 (hit) (insideT) (hadjacent) (hb) (sep3).2.2.1 (sep5).2.2.1

theorem HP_adjacent_bar_short_branch_pruned_node011 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_o0 a b jx jy (hlong) (sep1).2.2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node012 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_o1 a b jx jy (insideT) (sep1).2.2.1 (hit) (hb) (sep3).1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_o2 a b jx jy (hit) (sep3).2.1 (sep3).2.2.1 (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_o3 a b jx jy (hlong) (hit) (hb) (ap3_4).2.2.1 (sep0).2.1 (sep4).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_o4 a b jx jy (hit) (sep3).2.1 (hlong) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_o5 a b jx jy (sep4).2.2.1 (hit) (sep0).2.1 (hadjacent) (insideT) (sep4).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_o6 a b jx jy (sep1).2.2.1 (hlong) (sep3).2.2.1 (hit) (sep3).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n011_o7 a b jx jy (sep1).2.2.1 (sep4).1 (insideT) (hit) (hadjacent) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node003 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((-1 : Int) + ((2 : Int) * b)) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_point a b (hb) (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((-1 : Int) + ((2 : Int) * b)) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((-1 : Int) + ((2 : Int) * b)) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((-1 : Int) + ((2 : Int) * b)) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((-1 : Int) + ((2 : Int) * b)) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_empty a b (hadjacent) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((-1 : Int) + ((2 : Int) * b)) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_o0 a b jx jy (sep2).2.1 (sep1).2.2.1 (hb) (hit) (insideT) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_o1 a b jx jy (allowed) (hit) (insideT) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node004 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_o2 a b jx jy (allowed) (hit) (hb) ((by simpa only [Same,eq_comm] using absent)) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node010 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_o3 a b jx jy (sep2).1 (hadjacent) (insideT) (hit) (sep1).1 (hlong) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_o4 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node011 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_o5 a b jx jy (hit) (sep2).2.1 (hstrict) (sep1).1 (insideT) (sep0).1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_o6 a b jx jy (hadjacent) (sep2).2.1 (insideT) (hlong) (sep1).1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n003_o7 a b jx jy (sep2).2.1 (insideT) (hb) (hstrict) (hit)

theorem HP_adjacent_bar_short_branch_pruned_node014 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((4 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ((4 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_empty a b ((by simpa only [Contains] using occupied)) (hlong) (ap0_3).2.2.1 (hb)
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_o0 a b jx jy (hit) (sep2).2.1 (sep4).2.1 (hstrict) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_o1 a b jx jy (hit) (sep4).2.2.1 (allowed) (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_o2 a b jx jy (hit) (insideT) (hstrict) (hb) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_o3 a b jx jy (sep4).2.1 (sep2).2.1 (sep2).1 (insideT) (hb) (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_o4 a b jx jy (hb) (hit) (insideT) (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_o5 a b jx jy (hit) (hstrict) (sep0).1 (sep4).2.1 (insideT) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_o6 a b jx jy (sep2).2.1 (hb) (insideT) (hit) (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n014_o7 a b jx jy (hstrict) (hit) (sep2).2.1 (insideT) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node015 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_point a b (hb) (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_o0 a b jx jy (sep1).2.2.1 (sep3).2.1 (hb) (hit) (sep4).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_o1 a b jx jy (hit) (hlong) (insideT) (allowed) (sep4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_o2 a b jx jy (hit) (sep3).2.1 (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_o3 a b jx jy (sep0).2.1 (insideT) (hlong) (hit) (hb) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_o4 a b jx jy (allowed) (hlong) (sep4).2.2.1 (insideT) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_o5 a b jx jy (sep4).2.1 (sep3).2.1 (hstrict) (sep1).2.2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_o6 a b jx jy (sep1).2.2.1 (sep3).2.1 (hit) (hb) (sep4).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n015_o7 a b jx jy (sep4).2.1 (insideT) (hb) (hit) (hstrict)

theorem HP_adjacent_bar_short_branch_pruned_node013 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_empty a b ((by simpa only [Contains] using occupied)) (ap0_3).2.2.1 (hb)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_o0 a b jx jy (ap0_3).2.2.1 (hstrict) (sep2).2.1 (hit) (sep1).2.2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_o1 a b jx jy (insideT) (allowed) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node014 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_o2 a b jx jy (insideT) (sep3).2.1 (hit) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_o3 a b jx jy (sep2).2.1 (sep2).1 (insideT) (sep1).1 (hstrict) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_o4 a b jx jy (hit) (insideT) (allowed) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node015 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_o5 a b jx jy (sep1).1 (sep2).2.2.1 (sep2).2.1 (hb) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_o6 a b jx jy (sep1).2.2.1 (hit) (insideT) (sep2).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n013_o7 a b jx jy (hstrict) (sep2).2.1 (hit) (insideT) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node017 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((4 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ((4 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_empty a b (ap1_4).2.1 ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_o0 a b jx jy (sep4).2.1 (hb) (hit) (sep2).2.1 (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_o1 a b jx jy (sep4).2.2.1 (hit) (hlong) (insideT) (hb) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_o2 a b jx jy (hb) (insideT) (sep3).2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_o3 a b jx jy (hit) (sep4).2.1 (hb) (insideT) (sep2).1 (sep2).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_o4 a b jx jy (sep4).2.1 (hb) (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_o5 a b jx jy (sep2).2.2.1 (hit) (sep2).2.1 (hb) (sep1).1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_o6 a b jx jy (hlong) (hb) (hit) (sep2).2.1 (sep3).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n017_o7 a b jx jy (insideT) (hit) (hstrict) (sep2).2.1 (hb)

theorem HP_adjacent_bar_short_branch_pruned_node016 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_empty a b ((by simpa only [Contains] using occupied)) (hadjacent) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_o0 a b jx jy (sep2).2.1 (hit) (hadjacent) (insideT) (hlong) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_o1 a b jx jy (hit) (hlong) (allowed) ((by simpa only [Same,eq_comm] using absent)) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node017 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_o2 a b jx jy (hit) (insideT) (sep3).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_o3 a b jx jy (sep2).1 (sep1).1 (hadjacent) (insideT) (hlong) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_o4 a b jx jy (hadjacent) (hit) (insideT) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_o5 a b jx jy (sep2).2.1 (hstrict) (hit) (insideT) (sep2).1 (hb) (sep1).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_o6 a b jx jy (insideT) (sep3).2.2.1 (hlong) (hit) (sep2).2.1 (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n016_o7 a b jx jy (hit) (sep2).2.1 (insideT) (hadjacent) (hlong)

theorem HP_adjacent_bar_short_branch_pruned_node019 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_empty a b ((by simpa only [Contains] using occupied)) (hlong) (ap2_4).2.2.1
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_o0 a b jx jy (sep4).2.2.1 (insideT) (sep3).2.2.2 (hb) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_o1 a b jx jy (hlong) (hit) (insideT) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_o2 a b jx jy (insideT) (hit) (hlong) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_o3 a b jx jy (sep2).2.1 (ap2_4).2.2.1 (sep4).2.2.1 (sep1).1 (insideT) (hlong) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_o4 a b jx jy (insideT) (sep4).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_o5 a b jx jy (hit) (sep1).1 (ap2_4).2.2.1 (sep4).2.2.1 (hstrict) (insideT) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_o6 a b jx jy (hit) (hstrict) (sep4).2.2.1 (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n019_o7 a b jx jy (sep4).2.2.1 (hb) (hit) (hlong) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node021 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_point a b (hb) (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_o0 a b jx jy (sep1).2.2.1 (sep4).2.1 (sep5).2.1 (hit) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_o1 a b jx jy (sep5).2.1 (sep4).2.2.1 (insideT) (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_o2 a b jx jy (hit) (hstrict) (hb) (sep3).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_o3 a b jx jy (sep4).2.1 (ap1_5).2.1 (hit) (insideT) (sep5).2.1 (sep0).2.1 (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_o4 a b jx jy (hlong) (hit) (insideT) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_o5 a b jx jy (sep5).2.1 (sep4).2.1 (hstrict) (sep1).2.2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_o6 a b jx jy (sep4).2.1 (sep0).1 (ap1_5).2.1 (sep5).2.1 (insideT) (hlong) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n021_o7 a b jx jy (sep5).2.1 (hit) (hstrict) (insideT) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node020 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_empty a b (hb) ((by simpa only [Contains] using occupied)) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_o0 a b jx jy (sep1).2.2.1 (hit) (sep2).2.1 (hb) (hadjacent) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_o1 a b jx jy (allowed) (insideT) (hlong) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node021 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_o2 a b jx jy (insideT) (hit) (hb) (hstrict) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_o3 a b jx jy (hadjacent) (sep1).1 (hit) (sep2).2.1 (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_o4 a b jx jy (sep4).2.1 (hlong) (hadjacent) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_o5 a b jx jy (hit) (sep1).1 (sep2).2.1 (hadjacent) (hlong) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_o6 a b jx jy (sep2).2.1 (hit) (sep1).2.2.1 (insideT) (hadjacent) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n020_o7 a b jx jy (insideT) (sep2).2.1 (hit) (hadjacent) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node022 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_empty a b (hadjacent) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_o0 a b jx jy (hit) (sep1).2.2.1 (hadjacent) (insideT) (sep4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_o1 a b jx jy (hit) (insideT) (hlong) (hadjacent) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_o2 a b jx jy (insideT) (sep4).2.2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_o3 a b jx jy (hlong) (sep4).2.2.1 (sep1).1 (hit) (hadjacent) (insideT) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_o4 a b jx jy (hit) (sep4).2.2.1 (insideT) (hadjacent) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_o5 a b jx jy (sep2).1 (sep2).2.1 (insideT) (sep1).1 (hit) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_o6 a b jx jy (hadjacent) (insideT) (sep4).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n022_o7 a b jx jy (insideT) (hlong) (hadjacent) (sep4).2.2.1 (hit)

theorem HP_adjacent_bar_short_branch_pruned_node023 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_point a b (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_empty a b ((by simpa only [Contains] using occupied)) (ap2_4).2.2.1 (hlong)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_o0 a b jx jy (hit) (sep1).2.2.1 (insideT) (hb) (hlong) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_o1 a b jx jy (insideT) (sep4).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_o2 a b jx jy (hb) (hlong) (sep4).2.2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_o3 a b jx jy (insideT) (sep2).2.1 (hadjacent) (hit) (hlong) (sep1).1 (sep0).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_o4 a b jx jy (insideT) (sep4).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_o5 a b jx jy (hit) (sep4).2.2.1 (insideT) (sep2).2.1 (sep1).1 (hadjacent) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_o6 a b jx jy (hstrict) (hit) (sep4).2.2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n023_o7 a b jx jy (hit) (insideT) (hlong) (hb) (sep4).2.1

theorem HP_adjacent_bar_short_branch_pruned_node024 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_empty a b (hb) ((by simpa only [Contains] using occupied)) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_o0 a b jx jy (insideT) (hadjacent) (sep1).2.2.1 (sep4).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_o1 a b jx jy (hadjacent) (hit) (insideT) (sep4).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_o2 a b jx jy (sep4).2.2.1 (hit) (hlong) (hadjacent) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_o3 a b jx jy (sep1).1 (hit) (insideT) (hlong) (sep4).2.2.1 (hadjacent) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_o4 a b jx jy (hlong) (hit) (sep4).2.1 (insideT) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_o5 a b jx jy (sep1).1 (hstrict) (sep4).2.2.1 (hit) (insideT) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_o6 a b jx jy (hit) (sep4).2.2.1 (hlong) (hadjacent) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n024_o7 a b jx jy (hit) (hb) (sep4).2.2.1 (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node026 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht5 : world (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have in5 := inside (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed5 := avoid (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_o0 a b jx jy (hlong) (sep4).2.2.1 (sep1).2.2.1 (hit) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_o1 a b jx jy (insideT) (allowed) (sep4).2.2.1 (hstrict) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_o2 a b jx jy (insideT) (hit) (ap2_5).2.2.1 (hb) (sep3).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_o3 a b jx jy (sep0).2.1 (hstrict) (sep4).2.2.1 (hit) (hlong) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_o4 a b jx jy (insideT) (hit) (sep4).2.2.1 (hstrict) (allowed) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_o5 a b jx jy (hit) (sep5).2.2.2 (sep4).2.1 (hb) (hstrict) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_o6 a b jx jy (hstrict) (sep4).2.2.1 (hb) (sep5).2.2.1 (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n026_o7 a b jx jy (ap2_5).2.2.1 (sep4).2.2.1 (sep1).2.2.1 (insideT) (hb) (hit) (hstrict)

theorem HP_adjacent_bar_short_branch_pruned_node025 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_o0 a b jx jy (sep3).2.1 (sep4).2.2.1 (hadjacent) (sep1).2.2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_o1 a b jx jy (allowed) (hit) (sep4).2.2.1 (hlong) (hadjacent) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_o2 a b jx jy (hit) (hlong) (hb) (insideT) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_o3 a b jx jy (hit) (sep4).2.2.1 (sep1).2.2.1 (hadjacent) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_o4 a b jx jy (insideT) (sep3).2.1 (hadjacent) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1 (hit) (sep4).2.1 (hb) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node026 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_o6 a b jx jy (sep4).2.2.1 (hit) (hadjacent) (hlong) (sep1).2.2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n025_o7 a b jx jy (insideT) (sep4).1 (hb) (sep1).2.2.1 (hlong) (hit)

theorem HP_adjacent_bar_short_branch_pruned_node018 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_o0 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1 (hit) (sep3).2.1 (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node019 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (sep1).2.2.1 (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node020 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_o2 a b jx jy (hit) (insideT) (sep3).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_o3 a b jx jy (sep3).2.1 (sep0).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hadjacent) (hit) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node022 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_o4 a b jx jy (sep3).2.1 (hadjacent) (insideT) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1 (hit) (hlong) (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node023 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_o6 a b jx jy (sep1).2.2.1 (hit) (sep3).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node024 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n018_o7 a b jx jy (hb) (insideT) (hlong) (hit) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node025 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_adjacent_bar_short_branch_pruned_node027 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_point a b (hb) (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_empty a b (hlong) ((by simpa only [Contains] using occupied)) (ap2_3).2.2.1
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_o0 a b jx jy (insideT) (hb) (hit) (hlong) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_o1 a b jx jy (sep3).2.2.1 (hlong) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_o2 a b jx jy (hlong) (insideT) (hit) (hb) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_o3 a b jx jy (sep2).2.1 (hadjacent) (hlong) (hit) (sep1).1 (sep3).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_o4 a b jx jy (hit) (sep3).2.2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_o5 a b jx jy (sep3).2.2.1 (sep1).1 (sep2).2.1 (hstrict) (insideT) (hb) (hit) (ap2_3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_o6 a b jx jy (hlong) (hit) (insideT) (hstrict) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n027_o7 a b jx jy (sep3).2.1 (hb) (insideT) (hlong) (hit)

theorem HP_adjacent_bar_short_branch_pruned_node029 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((4 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_point a b (hb) (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ((4 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_empty a b (hlong) (ap1_4).2.1 (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_o0 a b jx jy (hit) (sep2).2.1 (ap1_4).2.1 (hb) (insideT) (hstrict) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_o1 a b jx jy (insideT) (hit) (sep4).2.2.1 (allowed) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_o2 a b jx jy (sep4).2.1 (hstrict) (hb) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_o3 a b jx jy (sep2).2.1 (insideT) (sep4).2.1 (sep2).1 (hstrict) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_o4 a b jx jy (hb) (sep4).2.1 (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_o5 a b jx jy (sep2).2.1 (sep2).2.2.1 (sep4).2.1 (hstrict) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_o6 a b jx jy (hit) (sep3).2.2.1 (sep2).2.1 (hb) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n029_o7 a b jx jy (sep2).2.1 (hit) (hb) (hstrict) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node030 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_o0 a b jx jy (hb) (sep4).2.1 (hit) (sep3).2.1 (sep3).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_o1 a b jx jy (allowed) (hlong) (hb) (hit) (insideT) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_o2 a b jx jy (sep3).2.1 (hb) (ap1_4).2.1 (insideT) (hlong) (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_o3 a b jx jy (sep4).2.2.1 (insideT) (hb) (hlong) (hit) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_o4 a b jx jy (allowed) (hit) (sep4).2.2.1 (insideT) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_o5 a b jx jy (sep4).2.2.1 (sep4).2.1 (hb) (insideT) (sep0).2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_o6 a b jx jy (sep4).2.1 (sep3).2.2.1 (sep3).2.1 (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n030_o7 a b jx jy (hb) (insideT) (hlong) (sep4).2.2.1 (sep4).2.1 (hit) (ap1_4).2.1

theorem HP_adjacent_bar_short_branch_pruned_node028 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_empty a b (hadjacent) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_o0 a b jx jy (sep2).2.1 (hadjacent) (sep1).2.2.1 (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_o1 a b jx jy (insideT) (hit) (allowed) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node029 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_o2 a b jx jy (hit) (hb) (insideT) (hstrict) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_o3 a b jx jy (sep2).2.1 (insideT) (sep2).1 (hadjacent) (hlong) (sep1).1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_o4 a b jx jy (allowed) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node030 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_o5 a b jx jy (sep2).2.1 (sep2).2.2.1 (hstrict) (sep1).1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_o6 a b jx jy (insideT) (hlong) (sep2).2.1 (hit) (hadjacent) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n028_o7 a b jx jy (insideT) (sep2).2.1 (hb) (hadjacent) (hit)

theorem HP_adjacent_bar_short_branch_pruned_node033 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hstrict) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_o0 a b jx jy (hit) (sep3).2.2.1 (hb) (sep1).2.1 (hlong) (sep5).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_o1 a b jx jy (sep3).2.2.1 (insideT) (hit) (allowed) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_o2 a b jx jy (sep3).2.2.1 (sep5).2.2.1 (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_o3 a b jx jy (sep0).2.1 (insideT) (sep3).2.2.1 (hstrict) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_o4 a b jx jy (sep3).2.2.1 (hit) (allowed) (insideT) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_o5 a b jx jy (insideT) (sep5).2.2.2 (sep3).2.1 (sep0).2.1 (hit) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_o6 a b jx jy (hb) (sep3).2.2.1 (hit) (hstrict) (sep5).2.2.1 (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n033_o7 a b jx jy (sep1).2.2.1 (sep3).2.2.1 (hb) (insideT) (hit) (ap4_5).2.2.1 (hstrict)

theorem HP_adjacent_bar_short_branch_pruned_node032 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hstrict)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_o0 a b jx jy (sep1).2.2.1 (sep3).2.2.1 (hb) (sep1).2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_o1 a b jx jy (sep3).2.2.1 (insideT) (allowed) (hb) (hit) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_o2 a b jx jy (hb) (hstrict) (hit) (insideT) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_o3 a b jx jy (sep0).2.1 (insideT) (hit) (sep3).2.2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_o4 a b jx jy (hb) (allowed) (sep3).2.2.1 (hit) (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (hb) (insideT) (hstrict) (sep0).2.1 (sep3).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node033 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_o6 a b jx jy (hit) (sep1).2.2.1 (sep3).2.1 (hstrict) (hb) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n032_o7 a b jx jy (sep3).2.2.1 (hb) (sep1).2.2.1 (hit) (hstrict) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node034 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed4 := avoid (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_point a b (hstrict) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_o0 a b jx jy (hit) (sep1).2.2.1 (sep3).2.2.1 (sep3).2.1 (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_o1 a b jx jy (allowed) (insideT) (sep3).2.2.1 (hit) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_o2 a b jx jy (sep3).2.1 (hit) (hstrict) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_o3 a b jx jy (sep0).2.1 (insideT) (sep3).2.2.1 (hit) (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_o4 a b jx jy (sep3).2.2.1 (hit) (allowed) (hb) (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_o5 a b jx jy (ap3_4).2.2.1 (hit) (sep0).1 (sep3).2.1 (hb) (insideT) (hstrict) (sep4).2.2.1 (sep1).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_o6 a b jx jy (hit) (sep1).2.2.1 (sep1).2.1 (sep3).2.2.1 (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n034_o7 a b jx jy (insideT) (hstrict) (sep3).1 (allowed) (hb) (hit) (sep4).1

theorem HP_adjacent_bar_short_branch_pruned_node031 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((-1 : Int) + ((2 : Int) * b)) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((-1 : Int) + ((2 : Int) * b)) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((-1 : Int) + ((2 : Int) * b)) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ((-1 : Int) + ((2 : Int) * b)) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ((-1 : Int) + ((2 : Int) * b)) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_empty a b (hadjacent) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover ((-1 : Int) + ((2 : Int) * b)) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_o0 a b jx jy (hit) (insideT) (sep1).2.2.1 (hadjacent) (hlong) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_o1 a b jx jy (insideT) (hit) (hlong) (allowed) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node032 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((2 : Int) * b)) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_o2 a b jx jy (allowed) (hit) (insideT) (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node034 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_o3 a b jx jy (insideT) (hadjacent) (sep0).1 (hit) (hlong) (sep1).1 (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_o4 a b jx jy (hlong) (insideT) (sep3).1 (hadjacent) (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_o5 a b jx jy (sep1).1 (hit) (sep2).1 (insideT) (hadjacent) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_o6 a b jx jy (sep2).2.1 (insideT) (hlong) (hadjacent) (hit) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n031_o7 a b jx jy (sep2).2.1 (hit) (insideT) (hstrict) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht1 ht2
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_point a b (hb) (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_o0 a b jx jy (sep1).2.2.1 (sep1).2.1 (hlong) (hb) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node002 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_o1 a b jx jy (sep1).2.2.1 (insideT) (hit) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node003 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_o2 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep1).2.1 (hlong) (hit) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node013 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_o3 a b jx jy (hit) (hadjacent) (hlong) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1 (insideT) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node016 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_o4 a b jx jy (hit) (insideT) (hlong) (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node018 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_o5 a b jx jy (sep1).2.1 (hlong) (insideT) (hadjacent) ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node027 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_o6 a b jx jy (sep1).2.2.1 (sep1).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node028 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n001_o7 a b jx jy (hit) (hlong) (insideT) (hb) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node031 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_adjacent_bar_short_branch_pruned_node036 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_o0 a b jx jy (insideT) (hit) (sep3).2.2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_o1 a b jx jy (sep3).2.2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_o2 a b jx jy (hb) (insideT) (hlong) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_o3 a b jx jy (sep1).1 (sep2).2.1 (hit) (insideT) (hlong) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_o4 a b jx jy (sep3).2.2.1 (insideT) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_o5 a b jx jy (sep2).2.1 (insideT) (hit) (hb) (sep1).1 (sep3).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_o6 a b jx jy (sep3).2.2.1 (hstrict) (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n036_o7 a b jx jy (hlong) (sep3).2.2.1 (hb) (hit) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node038 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_o0 a b jx jy (sep4).2.1 (hit) (sep3).2.1 (hstrict) (sep1).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_o1 a b jx jy (hlong) (sep3).2.2.1 (insideT) (sep4).2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_o2 a b jx jy (sep3).2.1 (hstrict) (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_o3 a b jx jy (hit) (sep0).2.1 (sep4).2.2.2 (hlong) (insideT) (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_o4 a b jx jy (insideT) (hit) (sep3).2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_o5 a b jx jy (sep3).2.1 (sep0).2.1 (insideT) (hit) (hstrict) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_o6 a b jx jy (sep4).2.1 (hit) (sep1).2.2.1 (hb) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n038_o7 a b jx jy (sep4).2.1 (hit) (hstrict) (insideT) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node039 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_point a b (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_empty a b ((by simpa only [Contains] using occupied)) (hb) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_o0 a b jx jy (sep3).2.1 (hb) (hlong) (sep1).2.2.1 (hit) (sep4).2.2.1 (ap1_4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_o1 a b jx jy (insideT) (allowed) (hit) (hlong) (hb) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_o2 a b jx jy (hstrict) (hb) (insideT) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_o3 a b jx jy (sep1).2.2.1 (hit) (sep4).2.2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_o4 a b jx jy (insideT) (hlong) (sep3).2.1 (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_o5 a b jx jy (sep0).2.1 (sep4).2.2.1 (sep4).2.1 (hb) (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_o6 a b jx jy (hit) (sep3).2.1 (sep3).2.2.1 (hb) (sep1).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n039_o7 a b jx jy (insideT) (hb) (sep4).2.1 (hit) (hstrict)

theorem HP_adjacent_bar_short_branch_pruned_node040 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((4 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ((4 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_empty a b (hb) (ap1_4).2.1 (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_o0 a b jx jy (insideT) (hit) (sep4).2.1 (sep2).1 (hstrict) (sep4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_o1 a b jx jy (hit) (sep4).2.2.1 (hstrict) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_o2 a b jx jy (sep4).2.1 (insideT) (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_o3 a b jx jy (hstrict) (sep4).2.2.1 (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_o4 a b jx jy (hb) (hit) (insideT) (sep4).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_o5 a b jx jy (sep2).2.1 (hit) (insideT) (sep1).1 (pairAllowed4) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_o6 a b jx jy (sep2).2.1 (hlong) (hit) (ap1_4).2.1 (sep4).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n040_o7 a b jx jy (allowed) (sep4).1 (hb) (hlong) (insideT) (hit)

theorem HP_adjacent_bar_short_branch_pruned_node037 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_empty a b ((by simpa only [Contains] using occupied)) (hadjacent) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_o0 a b jx jy (insideT) (sep1).2.2.1 (hadjacent) (sep2).2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_o1 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit) (allowed)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node038 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_o2 a b jx jy (hit) (hadjacent) (sep3).2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_o3 a b jx jy (sep2).1 (hlong) (sep2).2.1 (hadjacent) (hit) (insideT) (sep1).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_o4 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (allowed) (hit) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node039 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_o5 a b jx jy (insideT) (sep2).2.1 (hit) (sep2).1 (hstrict) (sep1).1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_o6 a b jx jy (hit) (hadjacent) (sep1).2.2.1 (hlong) (sep2).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n037_o7 a b jx jy (hit) (allowed) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node040 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_adjacent_bar_short_branch_pruned_node042 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (b + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_point a b (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (b + a) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (b + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (b + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_o0 a b jx jy (hb) (sep4).2.1 (sep2).2.1 (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_o1 a b jx jy (ap0_3).2.2.1 (hb) (insideT) (sep4).2.2.1 (allowed) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_o2 a b jx jy (hb) (insideT) (sep4).2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_o3 a b jx jy (sep2).2.1 (sep2).2.2.1 (sep1).1 (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_o4 a b jx jy (sep4).1 (hit) (allowed) (hlong) (insideT) (ap0_3).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_o5 a b jx jy (sep2).2.1 (hb) (hit) (hstrict) (insideT) (sep0).1 (sep1).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_o6 a b jx jy (hit) (hlong) (sep2).2.1 (sep1).2.2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n042_o7 a b jx jy (allowed) (insideT) (pairAllowed2) (hit) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node043 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_empty a b (hb) ((by simpa only [Contains] using occupied)) (hlong)
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_o0 a b jx jy (sep4).2.1 (sep1).2.2.1 (sep3).2.1 (hstrict) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_o1 a b jx jy (hlong) (hit) (insideT) (allowed) (sep4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_o2 a b jx jy (hb) (hlong) (insideT) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_o3 a b jx jy (sep0).2.1 (hit) (sep4).2.2.1 (hlong) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_o4 a b jx jy (hlong) (hit) (sep4).2.2.1 (insideT) (hb) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_o5 a b jx jy (hb) (sep0).2.1 (hit) (sep4).2.1 (insideT) (hlong) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_o6 a b jx jy (hb) (hit) (sep1).2.2.1 (sep3).2.1 (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n043_o7 a b jx jy (insideT) (sep4).2.1 (hb) (hit) (hstrict)

theorem HP_adjacent_bar_short_branch_pruned_node044 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((4 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ((4 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_empty a b (hlong) (ap0_3).2.2.1 (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_o0 a b jx jy (hit) (sep4).2.1 (hlong) (sep2).2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_o1 a b jx jy (insideT) (hit) (sep4).2.2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_o2 a b jx jy (sep4).2.1 (insideT) (hb) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_o3 a b jx jy (insideT) (sep4).2.2.1 (hstrict) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_o4 a b jx jy (hit) (insideT) (hb) (hstrict) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_o5 a b jx jy (sep2).2.1 (sep4).2.1 (hlong) (sep2).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_o6 a b jx jy (hit) (sep1).2.2.1 (sep4).2.2.1 (hb) (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n044_o7 a b jx jy (sep4).2.2.1 (hlong) (allowed) (hit) (insideT) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node041 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_empty a b (hlong) ((by simpa only [Contains] using occupied)) (ap0_3).2.2.1 (hb)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_o0 a b jx jy (sep1).1 (insideT) (hstrict) (hb) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_o1 a b jx jy (insideT) (hit) ((by simpa only [Same,eq_comm] using absent)) (allowed) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node042 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_o2 a b jx jy (sep3).2.1 (insideT) (hb) (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_o3 a b jx jy (sep2).1 (hit) (sep1).1 (insideT) (sep2).2.1 (hb) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_o4 a b jx jy (allowed) (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node043 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_o5 a b jx jy (sep1).1 (sep2).2.1 (sep2).1 (hstrict) (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_o6 a b jx jy (insideT) (hit) (sep1).2.2.1 (sep2).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n041_o7 a b jx jy (insideT) (hit) (allowed) (hb) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node044 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_adjacent_bar_short_branch_pruned_node046 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ht4 : world (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have in4 := inside (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_empty a b ((by simpa only [Contains] using occupied)) (hadjacent) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_o0 a b jx jy (sep3).2.2.1 (hit) (insideT) (hadjacent) (hb) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_o1 a b jx jy (allowed) (sep4).1 (insideT) (hadjacent) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_o2 a b jx jy (hit) (hstrict) (insideT) (hb) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_o3 a b jx jy (hadjacent) (sep2).2.2.1 (sep2).2.1 (hit) (sep1).1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_o4 a b jx jy (insideT) (hadjacent) (hlong) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_o5 a b jx jy (sep2).2.1 (hit) (hlong) (sep1).1 (sep2).1 (hadjacent) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_o6 a b jx jy (sep2).2.1 (insideT) (hadjacent) (sep3).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n046_o7 a b jx jy (hb) (hit) (hstrict) (insideT) (sep4).2.1

theorem HP_adjacent_bar_short_branch_pruned_node045 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (b + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) (b + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (b + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_o0 a b jx jy (sep2).2.1 (sep3).2.2.1 (hadjacent) (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (b + a) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_o1 a b jx jy (allowed) (hlong) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node046 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_o2 a b jx jy (sep3).2.1 (hstrict) (hit) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_o3 a b jx jy (hlong) (sep2).1 (hit) (sep2).2.1 (hadjacent) (insideT) (sep1).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_o4 a b jx jy (hit) (hadjacent) (hlong) (sep3).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_o5 a b jx jy (sep1).1 (sep0).1 (hit) (hlong) (sep2).2.1 (hadjacent) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_o6 a b jx jy (sep2).2.1 (insideT) (hadjacent) (hlong) (sep1).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n045_o7 a b jx jy (hb) (insideT) (hit) (pairAllowed2) (allowed)

theorem HP_adjacent_bar_short_branch_pruned_node048 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_o0 a b jx jy (hit) (insideT) (sep1).2.2.1 (sep4).2.2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_o1 a b jx jy (sep4).2.2.1 (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_o2 a b jx jy (hit) (sep4).2.1 (hlong) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_o3 a b jx jy (sep1).1 (sep2).2.1 (hit) (sep4).2.2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_o4 a b jx jy (sep4).2.2.1 (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_o5 a b jx jy (sep4).2.2.1 (sep1).1 (hlong) (hit) (insideT) (hadjacent) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_o6 a b jx jy (hlong) (insideT) (hstrict) (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n048_o7 a b jx jy (hit) (insideT) (hb) (hlong) (sep4).2.2.1

theorem HP_adjacent_bar_short_branch_pruned_node050 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_o0 a b jx jy (sep4).2.1 (hb) (sep1).2.2.1 (hit) (sep5).2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_o1 a b jx jy (sep5).2.1 (sep4).2.2.1 (hlong) (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_o2 a b jx jy (sep3).2.1 (insideT) (hstrict) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_o3 a b jx jy (sep0).2.1 (sep3).2.1 (ap1_5).2.1 (hit) (insideT) (hlong) (sep5).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_o4 a b jx jy (sep4).2.1 (hit) (insideT) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_o5 a b jx jy (sep5).2.1 (hstrict) (sep0).2.1 (sep4).2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_o6 a b jx jy (hb) (sep0).2.2.1 (sep4).2.1 (hit) (sep5).2.1 (hlong) (ap1_5).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n050_o7 a b jx jy (insideT) (sep5).2.1 (hstrict) (hit) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node051 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ht5 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have in5 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed5 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((4 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ((4 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_empty a b (ap1_5).2.1 (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_o0 a b jx jy (sep2).1 (sep5).2.1 (sep5).2.2.1 (insideT) (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_o1 a b jx jy (hit) (sep5).2.2.1 (insideT) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_o2 a b jx jy (insideT) (sep5).2.1 (hit) (hb) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_o3 a b jx jy (sep5).2.2.1 (hit) (insideT) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_o4 a b jx jy (hit) (sep5).2.2.1 (hstrict) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_o5 a b jx jy (insideT) (sep2).2.1 (hlong) (hit) (pairAllowed5) (sep5).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_o6 a b jx jy (hb) (insideT) (hit) (sep2).2.1 (sep1).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n051_o7 a b jx jy (allowed) (insideT) (hit) (hlong) (hb) (sep5).1

theorem HP_adjacent_bar_short_branch_pruned_node049 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_empty a b ((by simpa only [Contains] using occupied)) (hb) (hadjacent)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_o0 a b jx jy (insideT) (hadjacent) (sep2).2.1 (hlong) (sep1).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_o1 a b jx jy (allowed) (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node050 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_o2 a b jx jy (hit) (sep3).2.1 (insideT) (hadjacent) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_o3 a b jx jy (sep2).2.1 (sep2).1 (hit) (insideT) (sep1).1 (hlong) (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_o4 a b jx jy (sep4).2.1 (hit) (hadjacent) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_o5 a b jx jy (sep1).1 (hit) (sep2).2.1 (hadjacent) (insideT) (hlong) (sep2).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_o6 a b jx jy (hit) (sep2).2.1 (sep1).2.2.1 (hlong) (hadjacent) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n049_o7 a b jx jy (hit) (insideT) ((by simpa only [Same,eq_comm] using absent)) (allowed) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node051 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)

theorem HP_adjacent_bar_short_branch_pruned_node052 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_empty a b (hlong) (hadjacent) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_o0 a b jx jy (hadjacent) (insideT) (hit) (sep4).2.2.1 (sep3).2.2.2 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_o1 a b jx jy (hit) (hadjacent) (insideT) (hlong) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_o2 a b jx jy (sep4).2.2.1 (insideT) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_o3 a b jx jy (sep4).2.2.1 (hadjacent) (sep1).1 (sep2).2.1 (hlong) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_o4 a b jx jy (sep4).2.2.1 (insideT) (hadjacent) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_o5 a b jx jy (hit) (insideT) (sep4).2.2.2 (hadjacent) (sep1).1 (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_o6 a b jx jy (hit) (hadjacent) (sep4).2.2.1 (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n052_o7 a b jx jy (sep4).2.2.1 (insideT) (hlong) (hadjacent) (hit)

theorem HP_adjacent_bar_short_branch_pruned_node053 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_o0 a b jx jy (sep1).2.2.1 (insideT) (sep4).2.2.1 (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_o1 a b jx jy (insideT) (hit) (sep4).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_o2 a b jx jy (hit) (hlong) (sep4).2.2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_o3 a b jx jy (hlong) (insideT) (sep2).2.1 (sep1).1 (sep4).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_o4 a b jx jy (hit) (insideT) (hlong) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_o5 a b jx jy (sep2).2.1 (insideT) (sep4).2.2.1 (hit) (sep1).1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_o6 a b jx jy (insideT) (sep4).2.2.1 (hlong) (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n053_o7 a b jx jy (hit) (insideT) (hlong) (sep4).2.1 (hb)

theorem HP_adjacent_bar_short_branch_pruned_node054 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_empty a b (hadjacent) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_o0 a b jx jy (sep4).2.2.1 (sep1).2.2.1 (hadjacent) (hit) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_o1 a b jx jy (insideT) (hadjacent) (hlong) (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_o2 a b jx jy (hit) (sep4).2.2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_o3 a b jx jy (insideT) (sep4).2.2.1 (hit) (sep2).2.1 (hadjacent) (hlong) (sep1).1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_o4 a b jx jy (insideT) (sep4).2.1 (hadjacent) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_o5 a b jx jy (hit) (sep4).2.2.1 (sep2).2.1 (sep1).1 (insideT) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_o6 a b jx jy (insideT) (hadjacent) (hlong) (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n054_o7 a b jx jy (insideT) (hb) (hit) (sep4).2.2.1

theorem HP_adjacent_bar_short_branch_pruned_node056 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht5 : world (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_5 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_5 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_5 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_5 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap4_5 : Apart (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have in5 := inside (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed5 := avoid (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht5
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed0_5 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht5
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed1_5 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht5
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed2_5 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht5
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht4
  have pairAllowed3_5 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht5
  have pairAllowed4_5 := avoidPair (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4 ht5
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (3 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (3 : Int) ∨ Contains (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4
  have pairAllowed5 := avoidPair t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl hit))))))
    · exact ap
  have sep5 : Apart t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht5 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr hit))))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_o0 a b jx jy (hb) (sep4).2.2.1 (sep4).2.1 (sep1).2.2.1 (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_o1 a b jx jy (hstrict) (hit) (insideT) (sep5).2.2.1 (sep4).2.2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_o2 a b jx jy (hb) (sep5).2.2.1 (hit) (sep4).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_o3 a b jx jy (sep4).2.2.1 (hit) (hlong) (sep5).2.2.1 (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_o4 a b jx jy (insideT) (sep1).2.1 (sep4).2.2.1 (hlong) (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_o5 a b jx jy (hit) (sep5).2.2.2 (sep5).2.2.1 (hlong) (hb) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_o6 a b jx jy (sep3).2.1 (hit) (hb) (sep5).2.2.1 (sep4).2.2.1 (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n056_o7 a b jx jy (ap2_5).2.2.2 (hit) (sep4).2.2.1 (hlong) (insideT) (sep1).2.2.1 (hb)

theorem HP_adjacent_bar_short_branch_pruned_node055 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ht4 : world (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have in4 := inside (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed4 := avoid (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (4 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (4 : Int) (2 : Int) ∨ Contains (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (4 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_empty a b ((by simpa only [Contains] using occupied)) (hlong) (hb)
  obtain ⟨t,ht,hit⟩ := cover (4 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_o0 a b jx jy (sep4).2.1 (sep4).2.2.1 (hit) (sep1).2.2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_o1 a b jx jy (sep4).2.2.1 (hit) (hadjacent) (hlong) (insideT) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_o2 a b jx jy (sep4).2.1 (insideT) (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_o3 a b jx jy (hlong) (sep4).2.2.1 (hit) (insideT) (hadjacent) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_o4 a b jx jy (hadjacent) (hit) (hlong) (sep3).2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((4 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1 (sep4).2.1 (hit) (hlong) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3 sep4
    exact HP_adjacent_bar_short_branch_pruned_node056 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht4 ht ap0_1 ap0_2 ap0_3 ap0_4 (apart_sym sep0) ap1_2 ap1_3 ap1_4 (apart_sym sep1) ap2_3 ap2_4 (apart_sym sep2) ap3_4 (apart_sym sep3) (apart_sym sep4)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_o6 a b jx jy (sep3).2.1 (hlong) (sep1).2.2.1 (hadjacent) (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n055_o7 a b jx jy (hlong) (sep1).2.2.1 (hit) (sep4).1 (hb) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node047 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_o0 a b jx jy (sep3).2.1 ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1 (hit) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node048 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (3 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_o1 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT) (hlong) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node049 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_o2 a b jx jy (hit) (insideT) (sep3).2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((3 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_o3 a b jx jy (hadjacent) (sep0).2.1 (sep3).2.1 (hlong) ((by simpa only [Same,eq_comm] using absent)) (hit) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node052 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_o4 a b jx jy (hadjacent) (hit) (insideT) (hlong) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (sep3).2.1 (hit) (sep1).2.2.1 (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node053 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (3 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hit) (sep1).2.2.1 (sep3).2.1 (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node054 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (3 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n047_o7 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (hit) (hlong) (hb) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node055 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_adjacent_bar_short_branch_pruned_node057 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((2 : Int) + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_point a b (hb) (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int) ∨ Contains (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ((2 : Int) + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_empty a b (hlong) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((2 : Int) + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_o0 a b jx jy (sep3).2.2.1 (insideT) (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_o1 a b jx jy (sep3).2.2.1 (insideT) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_o2 a b jx jy (hb) (sep3).2.2.1 (hit) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_o3 a b jx jy (hit) (sep1).1 (sep2).2.1 (insideT) (sep3).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_o4 a b jx jy (hit) (hlong) (sep3).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_o5 a b jx jy (sep3).2.2.1 (sep1).1 (hit) (sep2).2.1 (insideT) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_o6 a b jx jy (insideT) (hstrict) (sep3).2.2.1 (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n057_o7 a b jx jy (insideT) (hit) (sep3).2.1 (hlong) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node059 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (b + a) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (b + a) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) (b + a) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (b + a) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_o0 a b jx jy (sep2).2.1 (insideT) (hit) (hb) (sep3).2.2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_o1 a b jx jy (hb) (insideT) (hlong) (hit) (ap1_4).2.1 (allowed) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_o2 a b jx jy (insideT) (sep4).2.1 (hb) (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_o3 a b jx jy (sep2).1 (hit) (sep1).1 (sep2).2.1 (hlong) (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_o4 a b jx jy (hit) (allowed) (insideT) (sep4).1 (hlong) (hb) (ap1_4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_o5 a b jx jy (hit) (sep2).2.2.1 (hlong) (sep2).2.1 (hb) (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_o6 a b jx jy (hit) (hlong) (sep1).2.2.1 (sep2).2.1 (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n059_o7 a b jx jy (pairAllowed2) (allowed) (hb) (hit) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node060 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_point a b (hlong) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_empty a b ((by simpa only [Contains] using occupied)) (hlong) (ap1_4).2.1
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_o0 a b jx jy (hstrict) (hb) (sep3).2.1 (hit) (sep0).2.2.1 (sep4).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_o1 a b jx jy (hit) (insideT) (allowed) (sep4).2.2.1 (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_o2 a b jx jy (ap1_4).2.1 (hit) (insideT) (sep3).2.1 (hlong) (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_o3 a b jx jy (hit) (sep4).2.2.1 (hlong) (hb) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_o4 a b jx jy (insideT) (allowed) (sep4).2.2.1 (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_o5 a b jx jy (sep4).2.1 (hlong) (insideT) (hit) (sep0).2.1 (hb) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_o6 a b jx jy (hit) (sep3).2.1 (sep3).2.2.1 (hlong) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n060_o7 a b jx jy (sep4).2.2.1 (hit) (ap1_4).2.1 (insideT) (sep4).2.1 (hlong) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node061 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap3_4 : Apart (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((4 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_point a b ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent)) (hlong) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((4 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ((4 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_empty a b (hlong) (ap1_4).2.1 ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((4 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_o0 a b jx jy (insideT) (sep4).2.1 (hlong) (hit) (sep2).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_o1 a b jx jy (sep4).2.2.1 (insideT) (hstrict) (hb) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_o2 a b jx jy (insideT) (hit) (hlong) (sep4).2.1 (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_o3 a b jx jy (insideT) (hstrict) (sep4).2.2.1 (hit) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_o4 a b jx jy (insideT) (hit) (hstrict) (hb) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_o5 a b jx jy (hit) (sep2).1 (sep2).2.1 (hb) (insideT) (sep1).1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_o6 a b jx jy (sep4).2.2.1 (hb) (sep3).2.2.1 (hstrict) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n061_o7 a b jx jy (hit) (sep4).1 (hlong) (hb) (allowed) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_node058 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((3 : Int) + b) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ((3 : Int) + b) (1 : Int) ∨ Contains (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ((3 : Int) + b) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_empty a b (hadjacent) ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover ((3 : Int) + b) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_o0 a b jx jy (hadjacent) (sep2).2.1 (insideT) (hb) (sep3).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_o1 a b jx jy (allowed) ((by simpa only [Same,eq_comm] using absent)) (insideT) (hit) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node059 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_o2 a b jx jy (insideT) (hb) (hit) (hadjacent) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_o3 a b jx jy (insideT) (hlong) (hit) (sep1).1 (sep2).2.1 (sep2).1 (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk ((3 : Int) + b) ((1 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_o4 a b jx jy (insideT) (hlong) (allowed) ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node060 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_o5 a b jx jy (hit) (sep1).1 (sep2).1 (sep2).2.1 (hadjacent) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_o6 a b jx jy (sep2).2.1 (sep3).2.2.1 (insideT) (hlong) (hadjacent) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + b) ((1 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n058_o7 a b jx jy (insideT) ((by simpa only [Same,eq_comm] using absent)) (allowed) (hb) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node061 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)

theorem HP_adjacent_bar_short_branch_pruned_node063 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ht4 : world (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_4 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_4 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    (ap3_4 : Apart (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have in4 := inside (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed4 := avoid (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht3 ht4
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (3 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (3 : Int) ∨ Contains (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (3 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_empty a b (hlong) (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (3 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_o0 a b jx jy (sep3).2.2.1 (sep1).2.1 (sep4).2.2.1 (hit) (hlong) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_o1 a b jx jy (sep3).2.2.1 (hit) (hlong) (hadjacent) (allowed) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_o2 a b jx jy (hit) (sep4).2.2.1 (hb) (hadjacent) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_o3 a b jx jy (sep3).2.2.1 (hlong) (hadjacent) (sep0).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_o4 a b jx jy (hadjacent) (sep3).2.2.1 (hit) (allowed) (insideT) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_o5 a b jx jy (sep4).2.2.2 (hadjacent) (insideT) (hit) (hlong) (sep3).2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_o6 a b jx jy (hit) (sep3).2.2.1 (sep4).2.2.1 (sep3).2.1 (hadjacent) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n063_o7 a b jx jy (insideT) (sep1).2.2.1 (hit) (allowed) (sep3).2.2.1 (hlong) (hb)

theorem HP_adjacent_bar_short_branch_pruned_node062 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    (ap2_3 : Apart (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht2 ht3
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (3 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (3 : Int) (2 : Int) ∨ Contains (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) (3 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_empty a b (hb) (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (3 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
    rcases separate t (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_o0 a b jx jy (hit) (sep1).2.1 (hb) (hlong) (sep3).2.2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_o1 a b jx jy (allowed) (hit) (sep3).2.2.1 (hadjacent) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_o2 a b jx jy (hb) (hit) (insideT) (sep3).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_o3 a b jx jy (sep3).2.2.1 (insideT) (hlong) (hadjacent) (sep0).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_o4 a b jx jy (insideT) (sep3).2.2.1 (allowed) (hadjacent) (hit) (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((3 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_o5 a b jx jy (hit) (sep1).2.1 (sep3).2.1 (sep0).2.2.1 (hlong) ((by simpa only [Same,eq_comm] using absent)) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_adjacent_bar_short_branch_pruned_node063 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_o6 a b jx jy (sep1).2.2.1 (sep3).2.2.1 (hlong) (hit) (sep1).2.1 (hadjacent)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n062_o7 a b jx jy (hb) (sep1).2.2.1 (sep3).1 (hlong) (insideT) (hit)

theorem HP_adjacent_bar_short_branch_pruned_node035 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ht2 : world (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have in2 := inside (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed2 := avoid (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have support : HP_adjacent_bar_short_branch_pruned_Box a b (2 : Int) (2 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) (2 : Int) (2 : Int) ∨ Contains (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) (2 : Int) (2 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_empty a b (hlong) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (2 : Int) (2 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_o0 a b jx jy (sep1).2.2.1 (hit) ((by simpa only [Same,eq_comm] using absent)) (hadjacent) (sep1).2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node036 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b (0 : Int) (0 : Int) a) (Cross.mk (2 : Int) ((2 : Int) + a) b (0 : Int) (0 : Int) a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_o1 a b jx jy (hlong) (hit) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep1).2.2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node037 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) a b) (Cross.mk (2 : Int) ((2 : Int) + b) (0 : Int) (0 : Int) a b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_o2 a b jx jy (insideT) (sep1).2.1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hit) (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node041 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((2 : Int) + b) (2 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_o3 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (hlong) (sep1).2.1 (hit) (hadjacent) (sep0).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node045 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) (0 : Int) b a) (Cross.mk (2 : Int) ((2 : Int) + a) (0 : Int) (0 : Int) b a) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_o4 a b jx jy (hit) ((by simpa only [Same,eq_comm] using absent)) (sep1).2.2.1 (insideT) (hlong)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node047 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((2 : Int) + a) (2 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_o5 a b jx jy (hadjacent) (sep0).2.1 (hlong) ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep1).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node057 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk (2 : Int) (2 : Int) b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_o6 a b jx jy (hit) (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (sep1).2.1
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node058 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a (0 : Int) (0 : Int) b) (Cross.mk (2 : Int) ((2 : Int) + b) a (0 : Int) (0 : Int) b) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n035_o7 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (hlong) (hit) (sep1).2.2.1 (hb)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_adjacent_bar_short_branch_pruned_node062 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)

theorem HP_adjacent_bar_short_branch_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht1
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht0 ht1
  have support : HP_adjacent_bar_short_branch_pruned_Box a b ((1 : Int) + b) (0 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_point a b (hlong) (hb) ((by simpa only [HP_adjacent_bar_short_branch_pruned_Box,HP_adjacent_bar_short_branch_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ((1 : Int) + b) (0 : Int) ∨ Contains (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ((1 : Int) + b) (0 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_empty a b (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover ((1 : Int) + b) (0 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_o0 a b jx jy (sep1).2.2.1 (hb) (hit) (sep0).1 (hadjacent) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_o1 a b jx jy (hlong) (insideT) (hit) (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_o2 a b jx jy (hit) (allowed) (insideT) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) a b (0 : Int)) (Cross.mk ((1 : Int) + ((2 : Int) * b)) (0 : Int) (0 : Int) a b (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_o3 a b jx jy (sep0).1 ((by simpa only [Same,eq_comm] using absent)) (hlong) (hadjacent) (insideT) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_adjacent_bar_short_branch_pruned_node001 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_o4 a b jx jy (allowed) (insideT) (hlong) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk ((1 : Int) + b + a) (0 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_o5 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (hadjacent) (sep0).1 (hit) (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_adjacent_bar_short_branch_pruned_node035 a b ha hb hstrict hlong hadjacent world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_o6 a b jx jy (insideT) (hlong) (hadjacent) (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_adjacent_bar_short_branch_pruned_n000_o7 a b jx jy (hb) (hit) (allowed) (insideT)

theorem HP_adjacent_bar_short_branch_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_adjacent_bar_short_branch_pruned_Inside t)
    (cover : ∀ x y, HP_adjacent_bar_short_branch_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenBoundaryPairs a b t u)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)) (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_adjacent_bar_short_branch_pruned_node000 a b ha hb hstrict hlong hadjacent world copies inside cover sep avoid avoidPair anchor0 anchor1 rootap0_1

theorem HP_adjacent_bar_short_branch_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int)))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair := avoid_boundary_pairs a b (by omega) (by omega) (by omega) T
  apply HP_adjacent_bar_short_branch_pruned_bounded_obstruction a b ha hb hstrict hlong hadjacent T.world T.copies ?_ ?_ T.disjoint avoid avoidPair anchor0 anchor1
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_adjacent_bar_short_branch_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (hadjacent : (a = (b + (1 : Int))))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) b a (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (1 : Int) (1 : Int) a b (0 : Int) (0 : Int))))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_adjacent_bar_short_branch_pruned_anchored_obstruction a b ha hb hstrict hlong hadjacent U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_adjacent_bar_short_branch_pruned_no_shifted_anchor
#print axioms HP_adjacent_bar_short_branch_pruned_bounded_obstruction
end PolyominoFormal.LRegion

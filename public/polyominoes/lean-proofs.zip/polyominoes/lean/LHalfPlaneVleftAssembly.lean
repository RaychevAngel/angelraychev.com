import LHalfPlaneShortbarAssembly
import LHalfPlaneShortbarPairs

set_option maxHeartbeats 1000000
namespace PolyominoFormal.LHalfPlaneShortbarAssembly
open CrossUnits TBoundary LRegion

def LongNeighborObstruction (a b : Int) (u : Cross) : Prop :=
  ∀T:Tiling a b 0 0 HalfPlane,
    T.world ⟨0,0,b,a,0,0⟩ → T.world ⟨1,a+1,0,0,b,a⟩ → T.world u → False

theorem force_long_tip_left {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (uprightLong : PairObstruction a b ⟨1,1,a,b,0,0⟩)
    (longTipRight : PairObstruction a b ⟨1,a+1,b,0,0,a⟩)
    (uprightShortLeft : PairObstruction a b ⟨b+1,1,0,a,b,0⟩)
    (uprightLongLeft : PairObstruction a b ⟨a+1,1,0,b,a,0⟩)
    (uprightShort : PairObstruction a b ⟨1,1,b,a,0,0⟩)
    (shortTipRight : PairObstruction a b ⟨1,b+1,a,0,0,b⟩)
    (T : Tiling a b 0 0 HalfPlane) (anchor : T.world ⟨0,0,b,a,0,0⟩) :
    T.world ⟨1,a+1,0,0,b,a⟩ := by
  obtain ⟨t,ht,hit⟩ := T.cover 1 1 (by unfold HalfPlane; omega)
  rcases inner_forms ha hb hab T anchor ht hit with eq | eq | eq | eq | eq | eq | eq
  · subst t; exact False.elim (uprightLong T anchor ht)
  · subst t; exact False.elim (longTipRight T anchor ht)
  · subst t; exact False.elim (uprightShortLeft T anchor ht)
  · simpa only [eq] using ht
  · subst t; exact False.elim (uprightLongLeft T anchor ht)
  · subst t; exact False.elim (uprightShort T anchor ht)
  · subst t; exact False.elim (shortTipRight T anchor ht)

/-- All four bar orientations adjacent to the anchored short bar are retained.
Boundary tips are excluded by the independently compiled global tip lemma. -/
theorem left_neighbor_forms {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) (anchor : T.world ⟨0,0,b,a,0,0⟩)
    {t : Cross} (ht : T.world t) (hit : Contains t (-1) 0) :
    t=⟨-a-1,0,a,b,0,0⟩ ∨ t=⟨-1,0,0,b,a,0⟩ ∨
    t=⟨-b-1,0,b,a,0,0⟩ ∨ t=⟨-1,0,0,a,b,0⟩ := by
  have bound := THalfPlane.hp_bound (by omega) (by omega) (by omega) T ht
  have ap := separate (by omega) (by omega) (by omega) T ht anchor hit
    (by dsimp [Contains]; omega)
  have hh := ap.1
  clear ap
  have cp := T.copies _ ht
  rcases t with ⟨x,y,e,n,w,s⟩
  rcases cp with cp | cp | cp | cp | cp | cp | cp | cp
  all_goals rcases cp with ⟨he,hn,hw,hs⟩
  all_goals dsimp only at he hn hw hs bound
  all_goals subst e; subst n; subst w; subst s
  all_goals dsimp [Contains] at hit
  all_goals dsimp only at hh
  · left; apply same_eq; dsimp [Same]; omega
  · have hy : y=a := by omega
    subst y; exact False.elim (unequal_no_right_long_tip a b x hb hab ha T ht)
  · have hy : y=b := by omega
    subst y; exact False.elim (unequal_no_left_short_tip a b x hb hab ha T ht)
  · right; right; right; apply same_eq; dsimp [Same]; omega
  · have hy : y=a := by omega
    subst y; exact False.elim (unequal_no_left_long_tip a b x hb hab ha T ht)
  · right; left; apply same_eq; dsimp [Same]; omega
  · right; right; left; apply same_eq; dsimp [Same]; omega
  · have hy : y=b := by omega
    subst y; exact False.elim (unequal_no_right_short_tip a b x hb hab ha T ht)

/-- It suffices to exclude the other six inner forms and the two possible long
left neighbors. The west-facing short neighbor forces an overlapping reflected
copy; the east-facing short neighbor is a forbidden equally directed pair. -/
theorem no_shortbar_from_six_and_neighbors {a b : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (uprightLong : PairObstruction a b ⟨1,1,a,b,0,0⟩)
    (longTipRight : PairObstruction a b ⟨1,a+1,b,0,0,a⟩)
    (uprightShortLeft : PairObstruction a b ⟨b+1,1,0,a,b,0⟩)
    (uprightLongLeft : PairObstruction a b ⟨a+1,1,0,b,a,0⟩)
    (uprightShort : PairObstruction a b ⟨1,1,b,a,0,0⟩)
    (shortTipRight : PairObstruction a b ⟨1,b+1,a,0,0,b⟩)
    (eastNeighbor : LongNeighborObstruction a b ⟨-a-1,0,a,b,0,0⟩)
    (westNeighbor : LongNeighborObstruction a b ⟨-1,0,0,b,a,0⟩) :
    LHalfPlaneAssembly.NoShortBars a b := by
  have force := force_long_tip_left ha hb hab uprightLong longTipRight
    uprightShortLeft uprightLongLeft uprightShort shortTipRight
  intro T p anchor
  let U : Tiling a b 0 0 HalfPlane := (T.translate (-p) 0).congr (by
    intro x y; simp only [HalfPlane,Int.sub_zero])
  have hO : U.world ⟨0,0,b,a,0,0⟩ := by
    refine ⟨_,anchor,?_⟩; apply same_eq; dsimp [Same,shift]; omega
  have hV := force U hO
  obtain ⟨t,ht,hit⟩ := U.cover (-1) 0 (by unfold HalfPlane; omega)
  rcases left_neighbor_forms ha hb hab U hO ht hit with eq | eq | eq | eq
  · subst t; exact eastNeighbor U hO hV ht
  · subst t; exact westNeighbor U hO hV ht
  · subst t
    apply same_short_bars_right_impossible a b (-b-1) 0 hb hab U ht
    simpa only [show -b-1+b+1=0 by omega] using hO
  · subst t
    let W : Tiling a b 0 0 HalfPlane := (U.mirrorX.translate (-1) 0).congr (by
      intro x y; simp only [HalfPlane,Int.sub_zero])
    have hW : W.world ⟨0,0,b,a,0,0⟩ := by
      refine ⟨_,⟨_,ht,rfl⟩,?_⟩
      apply same_eq; dsimp [Same,shift,mirrorX]; omega
    have reflected := force W hW
    obtain ⟨u,⟨v,hv,eq1⟩,eq2⟩ := reflected
    subst u
    have hx := congrArg Cross.x eq2
    have hy := congrArg Cross.y eq2
    have he := congrArg Cross.east eq2
    have hn := congrArg Cross.north eq2
    have hw := congrArg Cross.west eq2
    have hs := congrArg Cross.south eq2
    have veq : v=⟨-2,a+1,b,0,0,a⟩ := by
      apply same_eq; dsimp [Same]
      dsimp [shift,mirrorX] at hx hy he hn hw hs
      omega
    subst v
    have eq := U.disjoint ⟨1,a+1,0,0,b,a⟩ ⟨-2,a+1,b,0,0,a⟩ (-1) (a+1)
      hV hv (by left; dsimp; omega) (by left; dsimp; omega)
    have hx := congrArg Cross.x eq
    dsimp only at hx
    omega

#print axioms left_neighbor_forms
#print axioms no_shortbar_from_six_and_neighbors
end PolyominoFormal.LHalfPlaneShortbarAssembly

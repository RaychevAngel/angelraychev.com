import HPFiniteA2B2Data

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option linter.unusedSimpArgs false
namespace THalfPlaneFinite
open CrossUnits PolyominoFormal

theorem hp2_2_node692 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected692 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected692 ((5 : Int),(1 : Int)) hp2_2_branches692 hp2_2_evidence692 hp2_2_check692 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches692,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node691 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected691 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected691 ((3 : Int),(1 : Int)) hp2_2_branches691 hp2_2_evidence691 hp2_2_check691 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches691,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node690 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected690 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected690 ((3 : Int),(1 : Int)) hp2_2_branches690 hp2_2_evidence690 hp2_2_check690 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches690,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node689 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected689 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected689 ((3 : Int),(1 : Int)) hp2_2_branches689 hp2_2_evidence689 hp2_2_check689 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches689,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node688 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected688 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected688 ((4 : Int),(1 : Int)) hp2_2_branches688 hp2_2_evidence688 hp2_2_check688 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches688,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node689 T childKnown
  · exact hp2_2_node690 T childKnown
  · exact hp2_2_node691 T childKnown
  · exact hp2_2_node692 T childKnown
theorem hp2_2_node687 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected687 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected687 ((4 : Int),(1 : Int)) hp2_2_branches687 hp2_2_evidence687 hp2_2_check687 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches687,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node686 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected686 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected686 ((4 : Int),(1 : Int)) hp2_2_branches686 hp2_2_evidence686 hp2_2_check686 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches686,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node685 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected685 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected685 ((4 : Int),(1 : Int)) hp2_2_branches685 hp2_2_evidence685 hp2_2_check685 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches685,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node684 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected684 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected684 ((1 : Int),(2 : Int)) hp2_2_branches684 hp2_2_evidence684 hp2_2_check684 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches684,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node683 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected683 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected683 ((1 : Int),(2 : Int)) hp2_2_branches683 hp2_2_evidence683 hp2_2_check683 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches683,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node682 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected682 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected682 ((1 : Int),(2 : Int)) hp2_2_branches682 hp2_2_evidence682 hp2_2_check682 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches682,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node681 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected681 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected681 ((1 : Int),(1 : Int)) hp2_2_branches681 hp2_2_evidence681 hp2_2_check681 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches681,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node682 T childKnown
  · exact hp2_2_node683 T childKnown
  · exact hp2_2_node684 T childKnown
theorem hp2_2_node680 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected680 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected680 ((4 : Int),(1 : Int)) hp2_2_branches680 hp2_2_evidence680 hp2_2_check680 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches680,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node681 T childKnown
theorem hp2_2_node679 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected679 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected679 ((3 : Int),(1 : Int)) hp2_2_branches679 hp2_2_evidence679 hp2_2_check679 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches679,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node680 T childKnown
  · exact hp2_2_node685 T childKnown
  · exact hp2_2_node686 T childKnown
  · exact hp2_2_node687 T childKnown
theorem hp2_2_node678 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected678 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected678 ((5 : Int),(1 : Int)) hp2_2_branches678 hp2_2_evidence678 hp2_2_check678 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches678,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node677 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected677 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected677 ((5 : Int),(0 : Int)) hp2_2_branches677 hp2_2_evidence677 hp2_2_check677 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches677,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node678 T childKnown
theorem hp2_2_node676 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected676 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected676 ((3 : Int),(1 : Int)) hp2_2_branches676 hp2_2_evidence676 hp2_2_check676 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches676,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node677 T childKnown
theorem hp2_2_node675 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected675 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected675 ((1 : Int),(2 : Int)) hp2_2_branches675 hp2_2_evidence675 hp2_2_check675 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches675,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node674 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected674 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected674 ((1 : Int),(2 : Int)) hp2_2_branches674 hp2_2_evidence674 hp2_2_check674 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches674,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node673 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected673 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected673 ((1 : Int),(2 : Int)) hp2_2_branches673 hp2_2_evidence673 hp2_2_check673 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches673,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node672 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected672 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected672 ((1 : Int),(1 : Int)) hp2_2_branches672 hp2_2_evidence672 hp2_2_check672 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches672,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node673 T childKnown
  · exact hp2_2_node674 T childKnown
  · exact hp2_2_node675 T childKnown
theorem hp2_2_node671 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected671 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected671 ((5 : Int),(0 : Int)) hp2_2_branches671 hp2_2_evidence671 hp2_2_check671 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches671,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node672 T childKnown
theorem hp2_2_node670 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected670 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected670 ((3 : Int),(1 : Int)) hp2_2_branches670 hp2_2_evidence670 hp2_2_check670 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches670,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node671 T childKnown
theorem hp2_2_node669 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected669 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected669 ((3 : Int),(1 : Int)) hp2_2_branches669 hp2_2_evidence669 hp2_2_check669 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches669,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node668 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected668 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected668 ((4 : Int),(0 : Int)) hp2_2_branches668 hp2_2_evidence668 hp2_2_check668 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches668,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node669 T childKnown
  · exact hp2_2_node670 T childKnown
  · exact hp2_2_node676 T childKnown
  · exact hp2_2_node679 T childKnown
  · exact hp2_2_node688 T childKnown
theorem hp2_2_node667 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected667 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected667 ((2 : Int),(2 : Int)) hp2_2_branches667 hp2_2_evidence667 hp2_2_check667 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches667,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node666 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected666 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected666 ((2 : Int),(2 : Int)) hp2_2_branches666 hp2_2_evidence666 hp2_2_check666 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches666,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node665 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected665 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected665 ((2 : Int),(2 : Int)) hp2_2_branches665 hp2_2_evidence665 hp2_2_check665 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches665,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node664 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected664 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected664 ((2 : Int),(1 : Int)) hp2_2_branches664 hp2_2_evidence664 hp2_2_check664 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches664,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node665 T childKnown
  · exact hp2_2_node666 T childKnown
  · exact hp2_2_node667 T childKnown
theorem hp2_2_node663 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected663 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected663 ((2 : Int),(2 : Int)) hp2_2_branches663 hp2_2_evidence663 hp2_2_check663 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches663,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node662 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected662 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected662 ((2 : Int),(2 : Int)) hp2_2_branches662 hp2_2_evidence662 hp2_2_check662 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches662,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node661 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected661 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected661 ((2 : Int),(2 : Int)) hp2_2_branches661 hp2_2_evidence661 hp2_2_check661 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches661,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node660 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected660 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected660 ((2 : Int),(1 : Int)) hp2_2_branches660 hp2_2_evidence660 hp2_2_check660 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches660,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node661 T childKnown
  · exact hp2_2_node662 T childKnown
  · exact hp2_2_node663 T childKnown
theorem hp2_2_node659 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected659 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected659 ((3 : Int),(2 : Int)) hp2_2_branches659 hp2_2_evidence659 hp2_2_check659 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches659,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node658 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected658 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected658 ((3 : Int),(2 : Int)) hp2_2_branches658 hp2_2_evidence658 hp2_2_check658 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches658,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node657 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected657 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected657 ((3 : Int),(2 : Int)) hp2_2_branches657 hp2_2_evidence657 hp2_2_check657 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches657,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node656 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected656 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected656 ((5 : Int),(2 : Int)) hp2_2_branches656 hp2_2_evidence656 hp2_2_check656 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches656,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node655 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected655 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected655 ((3 : Int),(2 : Int)) hp2_2_branches655 hp2_2_evidence655 hp2_2_check655 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches655,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node656 T childKnown
theorem hp2_2_node654 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected654 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected654 ((2 : Int),(2 : Int)) hp2_2_branches654 hp2_2_evidence654 hp2_2_check654 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches654,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node655 T childKnown
  · exact hp2_2_node657 T childKnown
  · exact hp2_2_node658 T childKnown
  · exact hp2_2_node659 T childKnown
theorem hp2_2_node653 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected653 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected653 ((4 : Int),(0 : Int)) hp2_2_branches653 hp2_2_evidence653 hp2_2_check653 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches653,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node654 T childKnown
theorem hp2_2_node652 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected652 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected652 ((3 : Int),(2 : Int)) hp2_2_branches652 hp2_2_evidence652 hp2_2_check652 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches652,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node651 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected651 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected651 ((3 : Int),(2 : Int)) hp2_2_branches651 hp2_2_evidence651 hp2_2_check651 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches651,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node650 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected650 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected650 ((3 : Int),(2 : Int)) hp2_2_branches650 hp2_2_evidence650 hp2_2_check650 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches650,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node649 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected649 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected649 ((5 : Int),(1 : Int)) hp2_2_branches649 hp2_2_evidence649 hp2_2_check649 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches649,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node648 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected648 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected648 ((5 : Int),(1 : Int)) hp2_2_branches648 hp2_2_evidence648 hp2_2_check648 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches648,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node647 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected647 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected647 ((6 : Int),(1 : Int)) hp2_2_branches647 hp2_2_evidence647 hp2_2_check647 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches647,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node646 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected646 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected646 ((6 : Int),(0 : Int)) hp2_2_branches646 hp2_2_evidence646 hp2_2_check646 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches646,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node647 T childKnown
theorem hp2_2_node645 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected645 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected645 ((7 : Int),(2 : Int)) hp2_2_branches645 hp2_2_evidence645 hp2_2_check645 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches645,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node644 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected644 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected644 ((7 : Int),(2 : Int)) hp2_2_branches644 hp2_2_evidence644 hp2_2_check644 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches644,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node643 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected643 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected643 ((6 : Int),(2 : Int)) hp2_2_branches643 hp2_2_evidence643 hp2_2_check643 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches643,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node644 T childKnown
  · exact hp2_2_node645 T childKnown
theorem hp2_2_node642 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected642 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected642 ((6 : Int),(0 : Int)) hp2_2_branches642 hp2_2_evidence642 hp2_2_check642 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches642,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node643 T childKnown
theorem hp2_2_node641 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected641 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected641 ((5 : Int),(0 : Int)) hp2_2_branches641 hp2_2_evidence641 hp2_2_check641 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches641,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node642 T childKnown
  · exact hp2_2_node646 T childKnown
  · exact hp2_2_node648 T childKnown
  · exact hp2_2_node649 T childKnown
theorem hp2_2_node640 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected640 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected640 ((3 : Int),(2 : Int)) hp2_2_branches640 hp2_2_evidence640 hp2_2_check640 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches640,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node641 T childKnown
theorem hp2_2_node639 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected639 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected639 ((2 : Int),(2 : Int)) hp2_2_branches639 hp2_2_evidence639 hp2_2_check639 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches639,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node640 T childKnown
  · exact hp2_2_node650 T childKnown
  · exact hp2_2_node651 T childKnown
  · exact hp2_2_node652 T childKnown
theorem hp2_2_node638 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected638 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected638 ((4 : Int),(2 : Int)) hp2_2_branches638 hp2_2_evidence638 hp2_2_check638 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches638,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node637 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected637 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected637 ((4 : Int),(2 : Int)) hp2_2_branches637 hp2_2_evidence637 hp2_2_check637 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches637,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node636 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected636 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected636 ((5 : Int),(2 : Int)) hp2_2_branches636 hp2_2_evidence636 hp2_2_check636 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches636,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node635 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected635 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected635 ((5 : Int),(2 : Int)) hp2_2_branches635 hp2_2_evidence635 hp2_2_check635 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches635,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node634 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected634 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected634 ((4 : Int),(2 : Int)) hp2_2_branches634 hp2_2_evidence634 hp2_2_check634 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches634,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node635 T childKnown
  · exact hp2_2_node636 T childKnown
theorem hp2_2_node633 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected633 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected633 ((5 : Int),(2 : Int)) hp2_2_branches633 hp2_2_evidence633 hp2_2_check633 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches633,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node632 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected632 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected632 ((5 : Int),(2 : Int)) hp2_2_branches632 hp2_2_evidence632 hp2_2_check632 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches632,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node631 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected631 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected631 ((5 : Int),(2 : Int)) hp2_2_branches631 hp2_2_evidence631 hp2_2_check631 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches631,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node630 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected630 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected630 ((4 : Int),(2 : Int)) hp2_2_branches630 hp2_2_evidence630 hp2_2_check630 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches630,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node631 T childKnown
  · exact hp2_2_node632 T childKnown
  · exact hp2_2_node633 T childKnown
theorem hp2_2_node629 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected629 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected629 ((2 : Int),(2 : Int)) hp2_2_branches629 hp2_2_evidence629 hp2_2_check629 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches629,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node630 T childKnown
  · exact hp2_2_node634 T childKnown
  · exact hp2_2_node637 T childKnown
  · exact hp2_2_node638 T childKnown
theorem hp2_2_node628 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected628 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected628 ((4 : Int),(0 : Int)) hp2_2_branches628 hp2_2_evidence628 hp2_2_check628 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches628,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node629 T childKnown
theorem hp2_2_node627 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected627 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected627 ((3 : Int),(2 : Int)) hp2_2_branches627 hp2_2_evidence627 hp2_2_check627 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches627,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node626 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected626 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected626 ((3 : Int),(2 : Int)) hp2_2_branches626 hp2_2_evidence626 hp2_2_check626 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches626,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node625 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected625 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected625 ((3 : Int),(1 : Int)) hp2_2_branches625 hp2_2_evidence625 hp2_2_check625 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches625,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node626 T childKnown
  · exact hp2_2_node627 T childKnown
theorem hp2_2_node624 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected624 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected624 ((4 : Int),(0 : Int)) hp2_2_branches624 hp2_2_evidence624 hp2_2_check624 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches624,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node623 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected623 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected623 ((4 : Int),(0 : Int)) hp2_2_branches623 hp2_2_evidence623 hp2_2_check623 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches623,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node622 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected622 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected622 ((3 : Int),(1 : Int)) hp2_2_branches622 hp2_2_evidence622 hp2_2_check622 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches622,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node623 T childKnown
  · exact hp2_2_node624 T childKnown
theorem hp2_2_node621 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected621 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected621 ((2 : Int),(1 : Int)) hp2_2_branches621 hp2_2_evidence621 hp2_2_check621 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches621,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node622 T childKnown
  · exact hp2_2_node625 T childKnown
  · exact hp2_2_node628 T childKnown
  · exact hp2_2_node639 T childKnown
  · exact hp2_2_node653 T childKnown
theorem hp2_2_node620 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected620 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected620 ((3 : Int),(2 : Int)) hp2_2_branches620 hp2_2_evidence620 hp2_2_check620 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches620,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node619 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected619 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected619 ((3 : Int),(2 : Int)) hp2_2_branches619 hp2_2_evidence619 hp2_2_check619 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches619,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node618 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected618 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected618 ((2 : Int),(2 : Int)) hp2_2_branches618 hp2_2_evidence618 hp2_2_check618 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches618,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node619 T childKnown
  · exact hp2_2_node620 T childKnown
theorem hp2_2_node617 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected617 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected617 ((4 : Int),(0 : Int)) hp2_2_branches617 hp2_2_evidence617 hp2_2_check617 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches617,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node618 T childKnown
theorem hp2_2_node616 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected616 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected616 ((3 : Int),(2 : Int)) hp2_2_branches616 hp2_2_evidence616 hp2_2_check616 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches616,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node615 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected615 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected615 ((3 : Int),(2 : Int)) hp2_2_branches615 hp2_2_evidence615 hp2_2_check615 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches615,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node614 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected614 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected614 ((2 : Int),(2 : Int)) hp2_2_branches614 hp2_2_evidence614 hp2_2_check614 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches614,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node615 T childKnown
  · exact hp2_2_node616 T childKnown
theorem hp2_2_node613 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected613 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected613 ((4 : Int),(2 : Int)) hp2_2_branches613 hp2_2_evidence613 hp2_2_check613 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches613,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node612 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected612 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected612 ((4 : Int),(2 : Int)) hp2_2_branches612 hp2_2_evidence612 hp2_2_check612 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches612,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node611 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected611 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected611 ((2 : Int),(2 : Int)) hp2_2_branches611 hp2_2_evidence611 hp2_2_check611 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches611,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node612 T childKnown
  · exact hp2_2_node613 T childKnown
theorem hp2_2_node610 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected610 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected610 ((4 : Int),(0 : Int)) hp2_2_branches610 hp2_2_evidence610 hp2_2_check610 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches610,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node611 T childKnown
theorem hp2_2_node609 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected609 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected609 ((3 : Int),(2 : Int)) hp2_2_branches609 hp2_2_evidence609 hp2_2_check609 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches609,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node608 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected608 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected608 ((3 : Int),(2 : Int)) hp2_2_branches608 hp2_2_evidence608 hp2_2_check608 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches608,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node607 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected607 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected607 ((3 : Int),(1 : Int)) hp2_2_branches607 hp2_2_evidence607 hp2_2_check607 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches607,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node608 T childKnown
  · exact hp2_2_node609 T childKnown
theorem hp2_2_node606 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected606 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected606 ((4 : Int),(0 : Int)) hp2_2_branches606 hp2_2_evidence606 hp2_2_check606 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches606,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node605 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected605 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected605 ((4 : Int),(0 : Int)) hp2_2_branches605 hp2_2_evidence605 hp2_2_check605 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches605,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node604 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected604 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected604 ((3 : Int),(1 : Int)) hp2_2_branches604 hp2_2_evidence604 hp2_2_check604 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches604,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node605 T childKnown
  · exact hp2_2_node606 T childKnown
theorem hp2_2_node603 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected603 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected603 ((3 : Int),(2 : Int)) hp2_2_branches603 hp2_2_evidence603 hp2_2_check603 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches603,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node602 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected602 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected602 ((3 : Int),(2 : Int)) hp2_2_branches602 hp2_2_evidence602 hp2_2_check602 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches602,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node601 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected601 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected601 ((3 : Int),(1 : Int)) hp2_2_branches601 hp2_2_evidence601 hp2_2_check601 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches601,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node602 T childKnown
  · exact hp2_2_node603 T childKnown
theorem hp2_2_node600 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected600 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected600 ((2 : Int),(1 : Int)) hp2_2_branches600 hp2_2_evidence600 hp2_2_check600 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches600,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node601 T childKnown
  · exact hp2_2_node604 T childKnown
  · exact hp2_2_node607 T childKnown
  · exact hp2_2_node610 T childKnown
  · exact hp2_2_node614 T childKnown
  · exact hp2_2_node617 T childKnown
theorem hp2_2_node599 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected599 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected599 ((3 : Int),(2 : Int)) hp2_2_branches599 hp2_2_evidence599 hp2_2_check599 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches599,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node598 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected598 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected598 ((3 : Int),(2 : Int)) hp2_2_branches598 hp2_2_evidence598 hp2_2_check598 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches598,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node597 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected597 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected597 ((2 : Int),(2 : Int)) hp2_2_branches597 hp2_2_evidence597 hp2_2_check597 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches597,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node598 T childKnown
  · exact hp2_2_node599 T childKnown
theorem hp2_2_node596 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected596 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected596 ((4 : Int),(0 : Int)) hp2_2_branches596 hp2_2_evidence596 hp2_2_check596 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches596,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node597 T childKnown
theorem hp2_2_node595 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected595 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected595 ((3 : Int),(2 : Int)) hp2_2_branches595 hp2_2_evidence595 hp2_2_check595 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches595,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node594 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected594 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected594 ((3 : Int),(2 : Int)) hp2_2_branches594 hp2_2_evidence594 hp2_2_check594 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches594,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node593 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected593 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected593 ((2 : Int),(2 : Int)) hp2_2_branches593 hp2_2_evidence593 hp2_2_check593 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches593,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node594 T childKnown
  · exact hp2_2_node595 T childKnown
theorem hp2_2_node592 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected592 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected592 ((4 : Int),(2 : Int)) hp2_2_branches592 hp2_2_evidence592 hp2_2_check592 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches592,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node591 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected591 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected591 ((4 : Int),(2 : Int)) hp2_2_branches591 hp2_2_evidence591 hp2_2_check591 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches591,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node590 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected590 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected590 ((2 : Int),(2 : Int)) hp2_2_branches590 hp2_2_evidence590 hp2_2_check590 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches590,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node591 T childKnown
  · exact hp2_2_node592 T childKnown
theorem hp2_2_node589 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected589 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected589 ((4 : Int),(0 : Int)) hp2_2_branches589 hp2_2_evidence589 hp2_2_check589 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches589,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node590 T childKnown
theorem hp2_2_node588 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected588 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected588 ((3 : Int),(2 : Int)) hp2_2_branches588 hp2_2_evidence588 hp2_2_check588 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches588,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node587 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected587 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected587 ((3 : Int),(2 : Int)) hp2_2_branches587 hp2_2_evidence587 hp2_2_check587 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches587,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node586 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected586 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected586 ((3 : Int),(1 : Int)) hp2_2_branches586 hp2_2_evidence586 hp2_2_check586 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches586,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node587 T childKnown
  · exact hp2_2_node588 T childKnown
theorem hp2_2_node585 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected585 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected585 ((4 : Int),(0 : Int)) hp2_2_branches585 hp2_2_evidence585 hp2_2_check585 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches585,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node584 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected584 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected584 ((4 : Int),(0 : Int)) hp2_2_branches584 hp2_2_evidence584 hp2_2_check584 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches584,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node583 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected583 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected583 ((3 : Int),(1 : Int)) hp2_2_branches583 hp2_2_evidence583 hp2_2_check583 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches583,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node584 T childKnown
  · exact hp2_2_node585 T childKnown
theorem hp2_2_node582 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected582 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected582 ((3 : Int),(2 : Int)) hp2_2_branches582 hp2_2_evidence582 hp2_2_check582 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches582,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node581 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected581 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected581 ((3 : Int),(2 : Int)) hp2_2_branches581 hp2_2_evidence581 hp2_2_check581 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches581,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node580 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected580 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected580 ((3 : Int),(1 : Int)) hp2_2_branches580 hp2_2_evidence580 hp2_2_check580 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches580,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node581 T childKnown
  · exact hp2_2_node582 T childKnown
theorem hp2_2_node579 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected579 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected579 ((2 : Int),(1 : Int)) hp2_2_branches579 hp2_2_evidence579 hp2_2_check579 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches579,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node580 T childKnown
  · exact hp2_2_node583 T childKnown
  · exact hp2_2_node586 T childKnown
  · exact hp2_2_node589 T childKnown
  · exact hp2_2_node593 T childKnown
  · exact hp2_2_node596 T childKnown
theorem hp2_2_node578 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected578 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected578 ((2 : Int),(2 : Int)) hp2_2_branches578 hp2_2_evidence578 hp2_2_check578 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches578,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node577 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected577 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected577 ((2 : Int),(2 : Int)) hp2_2_branches577 hp2_2_evidence577 hp2_2_check577 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches577,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node576 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected576 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected576 ((2 : Int),(2 : Int)) hp2_2_branches576 hp2_2_evidence576 hp2_2_check576 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches576,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node575 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected575 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected575 ((3 : Int),(2 : Int)) hp2_2_branches575 hp2_2_evidence575 hp2_2_check575 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches575,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node574 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected574 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected574 ((3 : Int),(2 : Int)) hp2_2_branches574 hp2_2_evidence574 hp2_2_check574 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches574,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node573 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected573 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected573 ((3 : Int),(1 : Int)) hp2_2_branches573 hp2_2_evidence573 hp2_2_check573 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches573,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node574 T childKnown
  · exact hp2_2_node575 T childKnown
theorem hp2_2_node572 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected572 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected572 ((2 : Int),(1 : Int)) hp2_2_branches572 hp2_2_evidence572 hp2_2_check572 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches572,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node573 T childKnown
  · exact hp2_2_node576 T childKnown
  · exact hp2_2_node577 T childKnown
  · exact hp2_2_node578 T childKnown
theorem hp2_2_node571 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected571 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected571 ((2 : Int),(2 : Int)) hp2_2_branches571 hp2_2_evidence571 hp2_2_check571 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches571,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node570 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected570 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected570 ((2 : Int),(2 : Int)) hp2_2_branches570 hp2_2_evidence570 hp2_2_check570 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches570,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node569 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected569 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected569 ((2 : Int),(2 : Int)) hp2_2_branches569 hp2_2_evidence569 hp2_2_check569 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches569,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node568 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected568 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected568 ((2 : Int),(1 : Int)) hp2_2_branches568 hp2_2_evidence568 hp2_2_check568 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches568,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node569 T childKnown
  · exact hp2_2_node570 T childKnown
  · exact hp2_2_node571 T childKnown
theorem hp2_2_node567 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected567 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected567 ((2 : Int),(2 : Int)) hp2_2_branches567 hp2_2_evidence567 hp2_2_check567 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches567,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node566 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected566 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected566 ((2 : Int),(2 : Int)) hp2_2_branches566 hp2_2_evidence566 hp2_2_check566 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches566,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node565 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected565 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected565 ((2 : Int),(2 : Int)) hp2_2_branches565 hp2_2_evidence565 hp2_2_check565 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches565,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node564 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected564 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected564 ((3 : Int),(2 : Int)) hp2_2_branches564 hp2_2_evidence564 hp2_2_check564 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches564,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node563 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected563 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected563 ((3 : Int),(2 : Int)) hp2_2_branches563 hp2_2_evidence563 hp2_2_check563 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches563,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node562 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected562 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected562 ((3 : Int),(1 : Int)) hp2_2_branches562 hp2_2_evidence562 hp2_2_check562 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches562,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node563 T childKnown
  · exact hp2_2_node564 T childKnown
theorem hp2_2_node561 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected561 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected561 ((2 : Int),(1 : Int)) hp2_2_branches561 hp2_2_evidence561 hp2_2_check561 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches561,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node562 T childKnown
  · exact hp2_2_node565 T childKnown
  · exact hp2_2_node566 T childKnown
  · exact hp2_2_node567 T childKnown
theorem hp2_2_node560 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected560 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected560 ((3 : Int),(2 : Int)) hp2_2_branches560 hp2_2_evidence560 hp2_2_check560 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches560,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node559 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected559 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected559 ((2 : Int),(2 : Int)) hp2_2_branches559 hp2_2_evidence559 hp2_2_check559 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches559,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node560 T childKnown
theorem hp2_2_node558 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected558 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected558 ((3 : Int),(2 : Int)) hp2_2_branches558 hp2_2_evidence558 hp2_2_check558 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches558,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node557 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected557 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected557 ((2 : Int),(2 : Int)) hp2_2_branches557 hp2_2_evidence557 hp2_2_check557 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches557,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node558 T childKnown
theorem hp2_2_node556 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected556 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected556 ((4 : Int),(2 : Int)) hp2_2_branches556 hp2_2_evidence556 hp2_2_check556 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches556,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node555 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected555 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected555 ((4 : Int),(0 : Int)) hp2_2_branches555 hp2_2_evidence555 hp2_2_check555 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches555,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node556 T childKnown
theorem hp2_2_node554 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected554 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected554 ((2 : Int),(2 : Int)) hp2_2_branches554 hp2_2_evidence554 hp2_2_check554 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches554,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node555 T childKnown
theorem hp2_2_node553 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected553 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected553 ((3 : Int),(2 : Int)) hp2_2_branches553 hp2_2_evidence553 hp2_2_check553 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches553,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node552 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected552 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected552 ((3 : Int),(2 : Int)) hp2_2_branches552 hp2_2_evidence552 hp2_2_check552 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches552,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node551 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected551 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected551 ((3 : Int),(1 : Int)) hp2_2_branches551 hp2_2_evidence551 hp2_2_check551 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches551,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node552 T childKnown
  · exact hp2_2_node553 T childKnown
theorem hp2_2_node550 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected550 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected550 ((4 : Int),(0 : Int)) hp2_2_branches550 hp2_2_evidence550 hp2_2_check550 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches550,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node549 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected549 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected549 ((4 : Int),(0 : Int)) hp2_2_branches549 hp2_2_evidence549 hp2_2_check549 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches549,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node548 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected548 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected548 ((3 : Int),(1 : Int)) hp2_2_branches548 hp2_2_evidence548 hp2_2_check548 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches548,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node549 T childKnown
  · exact hp2_2_node550 T childKnown
theorem hp2_2_node547 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected547 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected547 ((3 : Int),(2 : Int)) hp2_2_branches547 hp2_2_evidence547 hp2_2_check547 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches547,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node546 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected546 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected546 ((3 : Int),(2 : Int)) hp2_2_branches546 hp2_2_evidence546 hp2_2_check546 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches546,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node545 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected545 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected545 ((3 : Int),(1 : Int)) hp2_2_branches545 hp2_2_evidence545 hp2_2_check545 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches545,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node546 T childKnown
  · exact hp2_2_node547 T childKnown
theorem hp2_2_node544 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected544 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected544 ((2 : Int),(1 : Int)) hp2_2_branches544 hp2_2_evidence544 hp2_2_check544 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches544,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node545 T childKnown
  · exact hp2_2_node548 T childKnown
  · exact hp2_2_node551 T childKnown
  · exact hp2_2_node554 T childKnown
  · exact hp2_2_node557 T childKnown
  · exact hp2_2_node559 T childKnown
theorem hp2_2_node543 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected543 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected543 ((3 : Int),(2 : Int)) hp2_2_branches543 hp2_2_evidence543 hp2_2_check543 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches543,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node542 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected542 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected542 ((3 : Int),(2 : Int)) hp2_2_branches542 hp2_2_evidence542 hp2_2_check542 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches542,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node541 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected541 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected541 ((2 : Int),(2 : Int)) hp2_2_branches541 hp2_2_evidence541 hp2_2_check541 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches541,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node542 T childKnown
  · exact hp2_2_node543 T childKnown
theorem hp2_2_node540 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected540 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected540 ((4 : Int),(0 : Int)) hp2_2_branches540 hp2_2_evidence540 hp2_2_check540 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches540,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node541 T childKnown
theorem hp2_2_node539 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected539 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected539 ((3 : Int),(2 : Int)) hp2_2_branches539 hp2_2_evidence539 hp2_2_check539 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches539,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node538 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected538 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected538 ((3 : Int),(2 : Int)) hp2_2_branches538 hp2_2_evidence538 hp2_2_check538 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches538,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node537 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected537 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected537 ((2 : Int),(2 : Int)) hp2_2_branches537 hp2_2_evidence537 hp2_2_check537 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches537,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node538 T childKnown
  · exact hp2_2_node539 T childKnown
theorem hp2_2_node536 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected536 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected536 ((4 : Int),(2 : Int)) hp2_2_branches536 hp2_2_evidence536 hp2_2_check536 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches536,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node535 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected535 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected535 ((4 : Int),(2 : Int)) hp2_2_branches535 hp2_2_evidence535 hp2_2_check535 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches535,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node534 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected534 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected534 ((2 : Int),(2 : Int)) hp2_2_branches534 hp2_2_evidence534 hp2_2_check534 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches534,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node535 T childKnown
  · exact hp2_2_node536 T childKnown
theorem hp2_2_node533 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected533 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected533 ((4 : Int),(0 : Int)) hp2_2_branches533 hp2_2_evidence533 hp2_2_check533 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches533,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node534 T childKnown
theorem hp2_2_node532 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected532 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected532 ((3 : Int),(2 : Int)) hp2_2_branches532 hp2_2_evidence532 hp2_2_check532 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches532,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node531 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected531 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected531 ((3 : Int),(2 : Int)) hp2_2_branches531 hp2_2_evidence531 hp2_2_check531 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches531,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node530 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected530 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected530 ((3 : Int),(1 : Int)) hp2_2_branches530 hp2_2_evidence530 hp2_2_check530 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches530,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node531 T childKnown
  · exact hp2_2_node532 T childKnown
theorem hp2_2_node529 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected529 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected529 ((4 : Int),(0 : Int)) hp2_2_branches529 hp2_2_evidence529 hp2_2_check529 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches529,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node528 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected528 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected528 ((4 : Int),(0 : Int)) hp2_2_branches528 hp2_2_evidence528 hp2_2_check528 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches528,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node527 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected527 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected527 ((3 : Int),(1 : Int)) hp2_2_branches527 hp2_2_evidence527 hp2_2_check527 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches527,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node528 T childKnown
  · exact hp2_2_node529 T childKnown
theorem hp2_2_node526 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected526 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected526 ((3 : Int),(2 : Int)) hp2_2_branches526 hp2_2_evidence526 hp2_2_check526 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches526,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node525 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected525 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected525 ((3 : Int),(2 : Int)) hp2_2_branches525 hp2_2_evidence525 hp2_2_check525 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches525,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node524 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected524 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected524 ((3 : Int),(1 : Int)) hp2_2_branches524 hp2_2_evidence524 hp2_2_check524 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches524,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node525 T childKnown
  · exact hp2_2_node526 T childKnown
theorem hp2_2_node523 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected523 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected523 ((2 : Int),(1 : Int)) hp2_2_branches523 hp2_2_evidence523 hp2_2_check523 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches523,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node524 T childKnown
  · exact hp2_2_node527 T childKnown
  · exact hp2_2_node530 T childKnown
  · exact hp2_2_node533 T childKnown
  · exact hp2_2_node537 T childKnown
  · exact hp2_2_node540 T childKnown
theorem hp2_2_node522 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected522 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected522 ((0 : Int),(2 : Int)) hp2_2_branches522 hp2_2_evidence522 hp2_2_check522 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches522,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node523 T childKnown
  · exact hp2_2_node544 T childKnown
  · exact hp2_2_node561 T childKnown
  · exact hp2_2_node568 T childKnown
  · exact hp2_2_node572 T childKnown
theorem hp2_2_node521 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected521 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected521 ((2 : Int),(2 : Int)) hp2_2_branches521 hp2_2_evidence521 hp2_2_check521 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches521,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node520 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected520 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected520 ((2 : Int),(2 : Int)) hp2_2_branches520 hp2_2_evidence520 hp2_2_check520 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches520,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node519 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected519 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected519 ((2 : Int),(2 : Int)) hp2_2_branches519 hp2_2_evidence519 hp2_2_check519 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches519,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node518 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected518 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected518 ((3 : Int),(2 : Int)) hp2_2_branches518 hp2_2_evidence518 hp2_2_check518 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches518,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node517 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected517 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected517 ((3 : Int),(2 : Int)) hp2_2_branches517 hp2_2_evidence517 hp2_2_check517 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches517,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node516 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected516 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected516 ((3 : Int),(1 : Int)) hp2_2_branches516 hp2_2_evidence516 hp2_2_check516 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches516,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node517 T childKnown
  · exact hp2_2_node518 T childKnown
theorem hp2_2_node515 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected515 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected515 ((2 : Int),(1 : Int)) hp2_2_branches515 hp2_2_evidence515 hp2_2_check515 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches515,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node516 T childKnown
  · exact hp2_2_node519 T childKnown
  · exact hp2_2_node520 T childKnown
  · exact hp2_2_node521 T childKnown
theorem hp2_2_node514 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected514 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected514 ((2 : Int),(2 : Int)) hp2_2_branches514 hp2_2_evidence514 hp2_2_check514 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches514,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node513 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected513 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected513 ((2 : Int),(2 : Int)) hp2_2_branches513 hp2_2_evidence513 hp2_2_check513 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches513,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node512 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected512 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected512 ((2 : Int),(2 : Int)) hp2_2_branches512 hp2_2_evidence512 hp2_2_check512 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches512,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node511 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected511 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected511 ((2 : Int),(1 : Int)) hp2_2_branches511 hp2_2_evidence511 hp2_2_check511 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches511,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node512 T childKnown
  · exact hp2_2_node513 T childKnown
  · exact hp2_2_node514 T childKnown
theorem hp2_2_node510 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected510 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected510 ((2 : Int),(2 : Int)) hp2_2_branches510 hp2_2_evidence510 hp2_2_check510 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches510,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node509 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected509 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected509 ((2 : Int),(2 : Int)) hp2_2_branches509 hp2_2_evidence509 hp2_2_check509 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches509,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node508 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected508 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected508 ((2 : Int),(2 : Int)) hp2_2_branches508 hp2_2_evidence508 hp2_2_check508 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches508,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node507 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected507 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected507 ((3 : Int),(2 : Int)) hp2_2_branches507 hp2_2_evidence507 hp2_2_check507 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches507,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node506 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected506 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected506 ((3 : Int),(2 : Int)) hp2_2_branches506 hp2_2_evidence506 hp2_2_check506 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches506,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node505 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected505 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected505 ((3 : Int),(1 : Int)) hp2_2_branches505 hp2_2_evidence505 hp2_2_check505 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches505,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node506 T childKnown
  · exact hp2_2_node507 T childKnown
theorem hp2_2_node504 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected504 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected504 ((2 : Int),(1 : Int)) hp2_2_branches504 hp2_2_evidence504 hp2_2_check504 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches504,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node505 T childKnown
  · exact hp2_2_node508 T childKnown
  · exact hp2_2_node509 T childKnown
  · exact hp2_2_node510 T childKnown
theorem hp2_2_node503 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected503 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected503 ((3 : Int),(2 : Int)) hp2_2_branches503 hp2_2_evidence503 hp2_2_check503 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches503,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node502 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected502 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected502 ((2 : Int),(2 : Int)) hp2_2_branches502 hp2_2_evidence502 hp2_2_check502 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches502,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node503 T childKnown
theorem hp2_2_node501 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected501 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected501 ((3 : Int),(2 : Int)) hp2_2_branches501 hp2_2_evidence501 hp2_2_check501 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches501,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node500 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected500 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected500 ((2 : Int),(2 : Int)) hp2_2_branches500 hp2_2_evidence500 hp2_2_check500 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches500,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node501 T childKnown
theorem hp2_2_node499 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected499 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected499 ((4 : Int),(2 : Int)) hp2_2_branches499 hp2_2_evidence499 hp2_2_check499 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches499,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node498 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected498 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected498 ((4 : Int),(0 : Int)) hp2_2_branches498 hp2_2_evidence498 hp2_2_check498 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches498,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node499 T childKnown
theorem hp2_2_node497 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected497 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected497 ((2 : Int),(2 : Int)) hp2_2_branches497 hp2_2_evidence497 hp2_2_check497 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches497,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node498 T childKnown
theorem hp2_2_node496 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected496 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected496 ((3 : Int),(2 : Int)) hp2_2_branches496 hp2_2_evidence496 hp2_2_check496 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches496,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node495 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected495 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected495 ((3 : Int),(2 : Int)) hp2_2_branches495 hp2_2_evidence495 hp2_2_check495 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches495,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node494 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected494 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected494 ((3 : Int),(1 : Int)) hp2_2_branches494 hp2_2_evidence494 hp2_2_check494 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches494,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node495 T childKnown
  · exact hp2_2_node496 T childKnown
theorem hp2_2_node493 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected493 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected493 ((4 : Int),(0 : Int)) hp2_2_branches493 hp2_2_evidence493 hp2_2_check493 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches493,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node492 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected492 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected492 ((4 : Int),(0 : Int)) hp2_2_branches492 hp2_2_evidence492 hp2_2_check492 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches492,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node491 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected491 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected491 ((3 : Int),(1 : Int)) hp2_2_branches491 hp2_2_evidence491 hp2_2_check491 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches491,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node492 T childKnown
  · exact hp2_2_node493 T childKnown
theorem hp2_2_node490 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected490 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected490 ((3 : Int),(2 : Int)) hp2_2_branches490 hp2_2_evidence490 hp2_2_check490 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches490,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node489 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected489 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected489 ((3 : Int),(2 : Int)) hp2_2_branches489 hp2_2_evidence489 hp2_2_check489 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches489,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node488 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected488 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected488 ((3 : Int),(1 : Int)) hp2_2_branches488 hp2_2_evidence488 hp2_2_check488 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches488,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node489 T childKnown
  · exact hp2_2_node490 T childKnown
theorem hp2_2_node487 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected487 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected487 ((2 : Int),(1 : Int)) hp2_2_branches487 hp2_2_evidence487 hp2_2_check487 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches487,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node488 T childKnown
  · exact hp2_2_node491 T childKnown
  · exact hp2_2_node494 T childKnown
  · exact hp2_2_node497 T childKnown
  · exact hp2_2_node500 T childKnown
  · exact hp2_2_node502 T childKnown
theorem hp2_2_node486 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected486 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected486 ((3 : Int),(2 : Int)) hp2_2_branches486 hp2_2_evidence486 hp2_2_check486 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches486,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node485 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected485 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected485 ((3 : Int),(2 : Int)) hp2_2_branches485 hp2_2_evidence485 hp2_2_check485 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches485,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node484 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected484 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected484 ((2 : Int),(2 : Int)) hp2_2_branches484 hp2_2_evidence484 hp2_2_check484 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches484,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node485 T childKnown
  · exact hp2_2_node486 T childKnown
theorem hp2_2_node483 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected483 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected483 ((4 : Int),(0 : Int)) hp2_2_branches483 hp2_2_evidence483 hp2_2_check483 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches483,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node484 T childKnown
theorem hp2_2_node482 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected482 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected482 ((3 : Int),(2 : Int)) hp2_2_branches482 hp2_2_evidence482 hp2_2_check482 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches482,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node481 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected481 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected481 ((3 : Int),(2 : Int)) hp2_2_branches481 hp2_2_evidence481 hp2_2_check481 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches481,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node480 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected480 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected480 ((2 : Int),(2 : Int)) hp2_2_branches480 hp2_2_evidence480 hp2_2_check480 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches480,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node481 T childKnown
  · exact hp2_2_node482 T childKnown
theorem hp2_2_node479 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected479 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected479 ((4 : Int),(2 : Int)) hp2_2_branches479 hp2_2_evidence479 hp2_2_check479 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches479,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node478 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected478 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected478 ((4 : Int),(2 : Int)) hp2_2_branches478 hp2_2_evidence478 hp2_2_check478 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches478,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node477 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected477 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected477 ((2 : Int),(2 : Int)) hp2_2_branches477 hp2_2_evidence477 hp2_2_check477 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches477,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node478 T childKnown
  · exact hp2_2_node479 T childKnown
theorem hp2_2_node476 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected476 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected476 ((4 : Int),(0 : Int)) hp2_2_branches476 hp2_2_evidence476 hp2_2_check476 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches476,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node477 T childKnown
theorem hp2_2_node475 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected475 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected475 ((3 : Int),(2 : Int)) hp2_2_branches475 hp2_2_evidence475 hp2_2_check475 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches475,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node474 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected474 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected474 ((3 : Int),(2 : Int)) hp2_2_branches474 hp2_2_evidence474 hp2_2_check474 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches474,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node473 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected473 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected473 ((3 : Int),(1 : Int)) hp2_2_branches473 hp2_2_evidence473 hp2_2_check473 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches473,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node474 T childKnown
  · exact hp2_2_node475 T childKnown
theorem hp2_2_node472 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected472 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected472 ((4 : Int),(0 : Int)) hp2_2_branches472 hp2_2_evidence472 hp2_2_check472 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches472,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node471 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected471 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected471 ((4 : Int),(0 : Int)) hp2_2_branches471 hp2_2_evidence471 hp2_2_check471 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches471,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node470 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected470 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected470 ((3 : Int),(1 : Int)) hp2_2_branches470 hp2_2_evidence470 hp2_2_check470 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches470,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node471 T childKnown
  · exact hp2_2_node472 T childKnown
theorem hp2_2_node469 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected469 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected469 ((3 : Int),(2 : Int)) hp2_2_branches469 hp2_2_evidence469 hp2_2_check469 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches469,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node468 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected468 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected468 ((3 : Int),(2 : Int)) hp2_2_branches468 hp2_2_evidence468 hp2_2_check468 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches468,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node467 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected467 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected467 ((3 : Int),(1 : Int)) hp2_2_branches467 hp2_2_evidence467 hp2_2_check467 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches467,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node468 T childKnown
  · exact hp2_2_node469 T childKnown
theorem hp2_2_node466 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected466 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected466 ((2 : Int),(1 : Int)) hp2_2_branches466 hp2_2_evidence466 hp2_2_check466 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches466,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node467 T childKnown
  · exact hp2_2_node470 T childKnown
  · exact hp2_2_node473 T childKnown
  · exact hp2_2_node476 T childKnown
  · exact hp2_2_node480 T childKnown
  · exact hp2_2_node483 T childKnown
theorem hp2_2_node465 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected465 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected465 ((0 : Int),(2 : Int)) hp2_2_branches465 hp2_2_evidence465 hp2_2_check465 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches465,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node466 T childKnown
  · exact hp2_2_node487 T childKnown
  · exact hp2_2_node504 T childKnown
  · exact hp2_2_node511 T childKnown
  · exact hp2_2_node515 T childKnown
theorem hp2_2_node464 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected464 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected464 ((2 : Int),(2 : Int)) hp2_2_branches464 hp2_2_evidence464 hp2_2_check464 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches464,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node463 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected463 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected463 ((2 : Int),(2 : Int)) hp2_2_branches463 hp2_2_evidence463 hp2_2_check463 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches463,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node462 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected462 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected462 ((2 : Int),(2 : Int)) hp2_2_branches462 hp2_2_evidence462 hp2_2_check462 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches462,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node461 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected461 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected461 ((3 : Int),(2 : Int)) hp2_2_branches461 hp2_2_evidence461 hp2_2_check461 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches461,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node460 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected460 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected460 ((3 : Int),(2 : Int)) hp2_2_branches460 hp2_2_evidence460 hp2_2_check460 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches460,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node459 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected459 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected459 ((3 : Int),(1 : Int)) hp2_2_branches459 hp2_2_evidence459 hp2_2_check459 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches459,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node460 T childKnown
  · exact hp2_2_node461 T childKnown
theorem hp2_2_node458 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected458 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected458 ((2 : Int),(1 : Int)) hp2_2_branches458 hp2_2_evidence458 hp2_2_check458 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches458,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node459 T childKnown
  · exact hp2_2_node462 T childKnown
  · exact hp2_2_node463 T childKnown
  · exact hp2_2_node464 T childKnown
theorem hp2_2_node457 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected457 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected457 ((2 : Int),(2 : Int)) hp2_2_branches457 hp2_2_evidence457 hp2_2_check457 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches457,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node456 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected456 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected456 ((2 : Int),(2 : Int)) hp2_2_branches456 hp2_2_evidence456 hp2_2_check456 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches456,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node455 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected455 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected455 ((2 : Int),(2 : Int)) hp2_2_branches455 hp2_2_evidence455 hp2_2_check455 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches455,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node454 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected454 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected454 ((2 : Int),(1 : Int)) hp2_2_branches454 hp2_2_evidence454 hp2_2_check454 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches454,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node455 T childKnown
  · exact hp2_2_node456 T childKnown
  · exact hp2_2_node457 T childKnown
theorem hp2_2_node453 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected453 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected453 ((2 : Int),(2 : Int)) hp2_2_branches453 hp2_2_evidence453 hp2_2_check453 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches453,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node452 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected452 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected452 ((2 : Int),(2 : Int)) hp2_2_branches452 hp2_2_evidence452 hp2_2_check452 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches452,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node451 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected451 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected451 ((2 : Int),(2 : Int)) hp2_2_branches451 hp2_2_evidence451 hp2_2_check451 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches451,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node450 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected450 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected450 ((3 : Int),(2 : Int)) hp2_2_branches450 hp2_2_evidence450 hp2_2_check450 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches450,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node449 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected449 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected449 ((3 : Int),(2 : Int)) hp2_2_branches449 hp2_2_evidence449 hp2_2_check449 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches449,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node448 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected448 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected448 ((3 : Int),(1 : Int)) hp2_2_branches448 hp2_2_evidence448 hp2_2_check448 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches448,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node449 T childKnown
  · exact hp2_2_node450 T childKnown
theorem hp2_2_node447 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected447 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected447 ((2 : Int),(1 : Int)) hp2_2_branches447 hp2_2_evidence447 hp2_2_check447 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches447,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node448 T childKnown
  · exact hp2_2_node451 T childKnown
  · exact hp2_2_node452 T childKnown
  · exact hp2_2_node453 T childKnown
theorem hp2_2_node446 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected446 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected446 ((3 : Int),(2 : Int)) hp2_2_branches446 hp2_2_evidence446 hp2_2_check446 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches446,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node445 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected445 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected445 ((2 : Int),(2 : Int)) hp2_2_branches445 hp2_2_evidence445 hp2_2_check445 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches445,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node446 T childKnown
theorem hp2_2_node444 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected444 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected444 ((3 : Int),(2 : Int)) hp2_2_branches444 hp2_2_evidence444 hp2_2_check444 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches444,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node443 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected443 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected443 ((2 : Int),(2 : Int)) hp2_2_branches443 hp2_2_evidence443 hp2_2_check443 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches443,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node444 T childKnown
theorem hp2_2_node442 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected442 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected442 ((4 : Int),(2 : Int)) hp2_2_branches442 hp2_2_evidence442 hp2_2_check442 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches442,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node441 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected441 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected441 ((4 : Int),(0 : Int)) hp2_2_branches441 hp2_2_evidence441 hp2_2_check441 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches441,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node442 T childKnown
theorem hp2_2_node440 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected440 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected440 ((2 : Int),(2 : Int)) hp2_2_branches440 hp2_2_evidence440 hp2_2_check440 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches440,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node441 T childKnown
theorem hp2_2_node439 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected439 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected439 ((3 : Int),(2 : Int)) hp2_2_branches439 hp2_2_evidence439 hp2_2_check439 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches439,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node438 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected438 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected438 ((3 : Int),(2 : Int)) hp2_2_branches438 hp2_2_evidence438 hp2_2_check438 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches438,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node437 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected437 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected437 ((3 : Int),(1 : Int)) hp2_2_branches437 hp2_2_evidence437 hp2_2_check437 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches437,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node438 T childKnown
  · exact hp2_2_node439 T childKnown
theorem hp2_2_node436 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected436 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected436 ((4 : Int),(0 : Int)) hp2_2_branches436 hp2_2_evidence436 hp2_2_check436 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches436,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node435 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected435 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected435 ((4 : Int),(0 : Int)) hp2_2_branches435 hp2_2_evidence435 hp2_2_check435 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches435,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node434 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected434 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected434 ((3 : Int),(1 : Int)) hp2_2_branches434 hp2_2_evidence434 hp2_2_check434 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches434,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node435 T childKnown
  · exact hp2_2_node436 T childKnown
theorem hp2_2_node433 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected433 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected433 ((3 : Int),(2 : Int)) hp2_2_branches433 hp2_2_evidence433 hp2_2_check433 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches433,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node432 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected432 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected432 ((3 : Int),(2 : Int)) hp2_2_branches432 hp2_2_evidence432 hp2_2_check432 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches432,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node431 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected431 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected431 ((3 : Int),(1 : Int)) hp2_2_branches431 hp2_2_evidence431 hp2_2_check431 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches431,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node432 T childKnown
  · exact hp2_2_node433 T childKnown
theorem hp2_2_node430 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected430 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected430 ((2 : Int),(1 : Int)) hp2_2_branches430 hp2_2_evidence430 hp2_2_check430 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches430,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node431 T childKnown
  · exact hp2_2_node434 T childKnown
  · exact hp2_2_node437 T childKnown
  · exact hp2_2_node440 T childKnown
  · exact hp2_2_node443 T childKnown
  · exact hp2_2_node445 T childKnown
theorem hp2_2_node429 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected429 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected429 ((3 : Int),(2 : Int)) hp2_2_branches429 hp2_2_evidence429 hp2_2_check429 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches429,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node428 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected428 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected428 ((3 : Int),(2 : Int)) hp2_2_branches428 hp2_2_evidence428 hp2_2_check428 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches428,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node427 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected427 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected427 ((2 : Int),(2 : Int)) hp2_2_branches427 hp2_2_evidence427 hp2_2_check427 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches427,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node428 T childKnown
  · exact hp2_2_node429 T childKnown
theorem hp2_2_node426 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected426 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected426 ((4 : Int),(0 : Int)) hp2_2_branches426 hp2_2_evidence426 hp2_2_check426 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches426,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node427 T childKnown
theorem hp2_2_node425 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected425 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected425 ((3 : Int),(2 : Int)) hp2_2_branches425 hp2_2_evidence425 hp2_2_check425 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches425,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node424 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected424 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected424 ((3 : Int),(2 : Int)) hp2_2_branches424 hp2_2_evidence424 hp2_2_check424 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches424,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node423 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected423 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected423 ((2 : Int),(2 : Int)) hp2_2_branches423 hp2_2_evidence423 hp2_2_check423 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches423,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node424 T childKnown
  · exact hp2_2_node425 T childKnown
theorem hp2_2_node422 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected422 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected422 ((4 : Int),(2 : Int)) hp2_2_branches422 hp2_2_evidence422 hp2_2_check422 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches422,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node421 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected421 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected421 ((4 : Int),(2 : Int)) hp2_2_branches421 hp2_2_evidence421 hp2_2_check421 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches421,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node420 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected420 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected420 ((2 : Int),(2 : Int)) hp2_2_branches420 hp2_2_evidence420 hp2_2_check420 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches420,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node421 T childKnown
  · exact hp2_2_node422 T childKnown
theorem hp2_2_node419 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected419 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected419 ((4 : Int),(0 : Int)) hp2_2_branches419 hp2_2_evidence419 hp2_2_check419 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches419,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node420 T childKnown
theorem hp2_2_node418 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected418 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected418 ((3 : Int),(2 : Int)) hp2_2_branches418 hp2_2_evidence418 hp2_2_check418 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches418,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node417 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected417 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected417 ((3 : Int),(2 : Int)) hp2_2_branches417 hp2_2_evidence417 hp2_2_check417 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches417,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node416 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected416 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected416 ((3 : Int),(1 : Int)) hp2_2_branches416 hp2_2_evidence416 hp2_2_check416 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches416,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node417 T childKnown
  · exact hp2_2_node418 T childKnown
theorem hp2_2_node415 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected415 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected415 ((4 : Int),(0 : Int)) hp2_2_branches415 hp2_2_evidence415 hp2_2_check415 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches415,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node414 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected414 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected414 ((4 : Int),(0 : Int)) hp2_2_branches414 hp2_2_evidence414 hp2_2_check414 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches414,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node413 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected413 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected413 ((3 : Int),(1 : Int)) hp2_2_branches413 hp2_2_evidence413 hp2_2_check413 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches413,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node414 T childKnown
  · exact hp2_2_node415 T childKnown
theorem hp2_2_node412 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected412 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected412 ((3 : Int),(2 : Int)) hp2_2_branches412 hp2_2_evidence412 hp2_2_check412 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches412,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node411 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected411 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected411 ((3 : Int),(2 : Int)) hp2_2_branches411 hp2_2_evidence411 hp2_2_check411 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches411,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node410 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected410 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected410 ((3 : Int),(1 : Int)) hp2_2_branches410 hp2_2_evidence410 hp2_2_check410 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches410,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node411 T childKnown
  · exact hp2_2_node412 T childKnown
theorem hp2_2_node409 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected409 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected409 ((2 : Int),(1 : Int)) hp2_2_branches409 hp2_2_evidence409 hp2_2_check409 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches409,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node410 T childKnown
  · exact hp2_2_node413 T childKnown
  · exact hp2_2_node416 T childKnown
  · exact hp2_2_node419 T childKnown
  · exact hp2_2_node423 T childKnown
  · exact hp2_2_node426 T childKnown
theorem hp2_2_node408 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected408 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected408 ((0 : Int),(2 : Int)) hp2_2_branches408 hp2_2_evidence408 hp2_2_check408 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches408,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node409 T childKnown
  · exact hp2_2_node430 T childKnown
  · exact hp2_2_node447 T childKnown
  · exact hp2_2_node454 T childKnown
  · exact hp2_2_node458 T childKnown
theorem hp2_2_node407 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected407 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected407 ((0 : Int),(1 : Int)) hp2_2_branches407 hp2_2_evidence407 hp2_2_check407 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches407,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node408 T childKnown
  · exact hp2_2_node465 T childKnown
  · exact hp2_2_node522 T childKnown
  · exact hp2_2_node579 T childKnown
  · exact hp2_2_node600 T childKnown
  · exact hp2_2_node621 T childKnown
  · exact hp2_2_node660 T childKnown
  · exact hp2_2_node664 T childKnown
theorem hp2_2_node406 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected406 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected406 ((1 : Int),(1 : Int)) hp2_2_branches406 hp2_2_evidence406 hp2_2_check406 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches406,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node405 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected405 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected405 ((1 : Int),(0 : Int)) hp2_2_branches405 hp2_2_evidence405 hp2_2_check405 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches405,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node406 T childKnown
theorem hp2_2_node404 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected404 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected404 ((2 : Int),(2 : Int)) hp2_2_branches404 hp2_2_evidence404 hp2_2_check404 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches404,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node403 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected403 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected403 ((2 : Int),(2 : Int)) hp2_2_branches403 hp2_2_evidence403 hp2_2_check403 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches403,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node402 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected402 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected402 ((2 : Int),(2 : Int)) hp2_2_branches402 hp2_2_evidence402 hp2_2_check402 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches402,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node401 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected401 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected401 ((2 : Int),(2 : Int)) hp2_2_branches401 hp2_2_evidence401 hp2_2_check401 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches401,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node400 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected400 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected400 ((4 : Int),(2 : Int)) hp2_2_branches400 hp2_2_evidence400 hp2_2_check400 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches400,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node399 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected399 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected399 ((4 : Int),(2 : Int)) hp2_2_branches399 hp2_2_evidence399 hp2_2_check399 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches399,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node398 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected398 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected398 ((4 : Int),(2 : Int)) hp2_2_branches398 hp2_2_evidence398 hp2_2_check398 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches398,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node397 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected397 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected397 ((5 : Int),(1 : Int)) hp2_2_branches397 hp2_2_evidence397 hp2_2_check397 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches397,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node396 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected396 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected396 ((5 : Int),(1 : Int)) hp2_2_branches396 hp2_2_evidence396 hp2_2_check396 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches396,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node395 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected395 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected395 ((5 : Int),(0 : Int)) hp2_2_branches395 hp2_2_evidence395 hp2_2_check395 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches395,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node396 T childKnown
  · exact hp2_2_node397 T childKnown
theorem hp2_2_node394 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected394 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected394 ((4 : Int),(1 : Int)) hp2_2_branches394 hp2_2_evidence394 hp2_2_check394 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches394,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node395 T childKnown
  · exact hp2_2_node398 T childKnown
  · exact hp2_2_node399 T childKnown
  · exact hp2_2_node400 T childKnown
theorem hp2_2_node393 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected393 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected393 ((4 : Int),(2 : Int)) hp2_2_branches393 hp2_2_evidence393 hp2_2_check393 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches393,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node392 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected392 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected392 ((4 : Int),(2 : Int)) hp2_2_branches392 hp2_2_evidence392 hp2_2_check392 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches392,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node391 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected391 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected391 ((4 : Int),(2 : Int)) hp2_2_branches391 hp2_2_evidence391 hp2_2_check391 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches391,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node390 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected390 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected390 ((4 : Int),(1 : Int)) hp2_2_branches390 hp2_2_evidence390 hp2_2_check390 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches390,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node391 T childKnown
  · exact hp2_2_node392 T childKnown
  · exact hp2_2_node393 T childKnown
theorem hp2_2_node389 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected389 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected389 ((2 : Int),(2 : Int)) hp2_2_branches389 hp2_2_evidence389 hp2_2_check389 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches389,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node390 T childKnown
  · exact hp2_2_node394 T childKnown
theorem hp2_2_node388 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected388 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected388 ((1 : Int),(2 : Int)) hp2_2_branches388 hp2_2_evidence388 hp2_2_check388 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches388,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node389 T childKnown
  · exact hp2_2_node401 T childKnown
  · exact hp2_2_node402 T childKnown
  · exact hp2_2_node403 T childKnown
  · exact hp2_2_node404 T childKnown
theorem hp2_2_node387 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected387 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected387 ((1 : Int),(0 : Int)) hp2_2_branches387 hp2_2_evidence387 hp2_2_check387 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches387,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node388 T childKnown
theorem hp2_2_node386 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected386 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected386 ((1 : Int),(1 : Int)) hp2_2_branches386 hp2_2_evidence386 hp2_2_check386 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches386,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node385 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected385 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected385 ((1 : Int),(0 : Int)) hp2_2_branches385 hp2_2_evidence385 hp2_2_check385 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches385,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node386 T childKnown
theorem hp2_2_node384 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected384 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected384 ((4 : Int),(1 : Int)) hp2_2_branches384 hp2_2_evidence384 hp2_2_check384 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches384,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node383 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected383 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected383 ((2 : Int),(1 : Int)) hp2_2_branches383 hp2_2_evidence383 hp2_2_check383 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches383,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node382 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected382 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected382 ((2 : Int),(1 : Int)) hp2_2_branches382 hp2_2_evidence382 hp2_2_check382 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches382,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node381 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected381 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected381 ((2 : Int),(1 : Int)) hp2_2_branches381 hp2_2_evidence381 hp2_2_check381 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches381,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node380 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected380 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected380 ((3 : Int),(1 : Int)) hp2_2_branches380 hp2_2_evidence380 hp2_2_check380 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches380,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node381 T childKnown
  · exact hp2_2_node382 T childKnown
  · exact hp2_2_node383 T childKnown
  · exact hp2_2_node384 T childKnown
theorem hp2_2_node379 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected379 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected379 ((3 : Int),(1 : Int)) hp2_2_branches379 hp2_2_evidence379 hp2_2_check379 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches379,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node378 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected378 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected378 ((3 : Int),(1 : Int)) hp2_2_branches378 hp2_2_evidence378 hp2_2_check378 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches378,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node377 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected377 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected377 ((3 : Int),(1 : Int)) hp2_2_branches377 hp2_2_evidence377 hp2_2_check377 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches377,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node376 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected376 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected376 ((0 : Int),(2 : Int)) hp2_2_branches376 hp2_2_evidence376 hp2_2_check376 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches376,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node375 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected375 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected375 ((0 : Int),(2 : Int)) hp2_2_branches375 hp2_2_evidence375 hp2_2_check375 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches375,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node374 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected374 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected374 ((0 : Int),(2 : Int)) hp2_2_branches374 hp2_2_evidence374 hp2_2_check374 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches374,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node373 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected373 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected373 ((0 : Int),(1 : Int)) hp2_2_branches373 hp2_2_evidence373 hp2_2_check373 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches373,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node374 T childKnown
  · exact hp2_2_node375 T childKnown
  · exact hp2_2_node376 T childKnown
theorem hp2_2_node372 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected372 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected372 ((3 : Int),(1 : Int)) hp2_2_branches372 hp2_2_evidence372 hp2_2_check372 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches372,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node373 T childKnown
theorem hp2_2_node371 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected371 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected371 ((2 : Int),(1 : Int)) hp2_2_branches371 hp2_2_evidence371 hp2_2_check371 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches371,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node372 T childKnown
  · exact hp2_2_node377 T childKnown
  · exact hp2_2_node378 T childKnown
  · exact hp2_2_node379 T childKnown
theorem hp2_2_node370 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected370 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected370 ((4 : Int),(1 : Int)) hp2_2_branches370 hp2_2_evidence370 hp2_2_check370 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches370,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node369 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected369 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected369 ((4 : Int),(0 : Int)) hp2_2_branches369 hp2_2_evidence369 hp2_2_check369 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches369,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node370 T childKnown
theorem hp2_2_node368 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected368 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected368 ((2 : Int),(1 : Int)) hp2_2_branches368 hp2_2_evidence368 hp2_2_check368 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches368,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node369 T childKnown
theorem hp2_2_node367 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected367 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected367 ((0 : Int),(2 : Int)) hp2_2_branches367 hp2_2_evidence367 hp2_2_check367 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches367,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node366 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected366 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected366 ((0 : Int),(2 : Int)) hp2_2_branches366 hp2_2_evidence366 hp2_2_check366 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches366,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node365 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected365 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected365 ((0 : Int),(2 : Int)) hp2_2_branches365 hp2_2_evidence365 hp2_2_check365 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches365,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node364 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected364 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected364 ((0 : Int),(1 : Int)) hp2_2_branches364 hp2_2_evidence364 hp2_2_check364 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches364,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node365 T childKnown
  · exact hp2_2_node366 T childKnown
  · exact hp2_2_node367 T childKnown
theorem hp2_2_node363 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected363 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected363 ((4 : Int),(0 : Int)) hp2_2_branches363 hp2_2_evidence363 hp2_2_check363 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches363,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node364 T childKnown
theorem hp2_2_node362 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected362 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected362 ((2 : Int),(1 : Int)) hp2_2_branches362 hp2_2_evidence362 hp2_2_check362 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches362,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node363 T childKnown
theorem hp2_2_node361 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected361 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected361 ((2 : Int),(1 : Int)) hp2_2_branches361 hp2_2_evidence361 hp2_2_check361 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches361,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node360 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected360 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected360 ((3 : Int),(0 : Int)) hp2_2_branches360 hp2_2_evidence360 hp2_2_check360 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches360,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node361 T childKnown
  · exact hp2_2_node362 T childKnown
  · exact hp2_2_node368 T childKnown
  · exact hp2_2_node371 T childKnown
  · exact hp2_2_node380 T childKnown
theorem hp2_2_node359 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected359 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected359 ((2 : Int),(2 : Int)) hp2_2_branches359 hp2_2_evidence359 hp2_2_check359 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches359,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node358 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected358 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected358 ((2 : Int),(2 : Int)) hp2_2_branches358 hp2_2_evidence358 hp2_2_check358 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches358,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node357 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected357 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected357 ((2 : Int),(2 : Int)) hp2_2_branches357 hp2_2_evidence357 hp2_2_check357 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches357,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node356 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected356 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected356 ((4 : Int),(2 : Int)) hp2_2_branches356 hp2_2_evidence356 hp2_2_check356 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches356,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node355 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected355 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected355 ((2 : Int),(2 : Int)) hp2_2_branches355 hp2_2_evidence355 hp2_2_check355 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches355,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node356 T childKnown
theorem hp2_2_node354 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected354 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected354 ((4 : Int),(2 : Int)) hp2_2_branches354 hp2_2_evidence354 hp2_2_check354 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches354,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node353 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected353 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected353 ((2 : Int),(2 : Int)) hp2_2_branches353 hp2_2_evidence353 hp2_2_check353 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches353,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node354 T childKnown
theorem hp2_2_node352 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected352 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected352 ((1 : Int),(2 : Int)) hp2_2_branches352 hp2_2_evidence352 hp2_2_check352 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches352,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node353 T childKnown
  · exact hp2_2_node355 T childKnown
  · exact hp2_2_node357 T childKnown
  · exact hp2_2_node358 T childKnown
  · exact hp2_2_node359 T childKnown
theorem hp2_2_node351 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected351 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected351 ((3 : Int),(0 : Int)) hp2_2_branches351 hp2_2_evidence351 hp2_2_check351 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches351,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node352 T childKnown
theorem hp2_2_node350 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected350 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected350 ((5 : Int),(1 : Int)) hp2_2_branches350 hp2_2_evidence350 hp2_2_check350 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches350,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node349 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected349 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected349 ((4 : Int),(1 : Int)) hp2_2_branches349 hp2_2_evidence349 hp2_2_check349 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches349,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node350 T childKnown
theorem hp2_2_node348 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected348 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected348 ((1 : Int),(2 : Int)) hp2_2_branches348 hp2_2_evidence348 hp2_2_check348 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches348,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node347 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected347 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected347 ((1 : Int),(2 : Int)) hp2_2_branches347 hp2_2_evidence347 hp2_2_check347 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches347,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node346 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected346 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected346 ((1 : Int),(2 : Int)) hp2_2_branches346 hp2_2_evidence346 hp2_2_check346 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches346,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node345 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected345 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected345 ((2 : Int),(2 : Int)) hp2_2_branches345 hp2_2_evidence345 hp2_2_check345 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches345,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node346 T childKnown
  · exact hp2_2_node347 T childKnown
  · exact hp2_2_node348 T childKnown
theorem hp2_2_node344 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected344 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected344 ((4 : Int),(1 : Int)) hp2_2_branches344 hp2_2_evidence344 hp2_2_check344 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches344,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node345 T childKnown
theorem hp2_2_node343 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected343 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected343 ((5 : Int),(1 : Int)) hp2_2_branches343 hp2_2_evidence343 hp2_2_check343 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches343,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node342 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected342 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected342 ((5 : Int),(0 : Int)) hp2_2_branches342 hp2_2_evidence342 hp2_2_check342 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches342,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node343 T childKnown
theorem hp2_2_node341 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected341 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected341 ((2 : Int),(2 : Int)) hp2_2_branches341 hp2_2_evidence341 hp2_2_check341 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches341,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node340 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected340 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected340 ((2 : Int),(2 : Int)) hp2_2_branches340 hp2_2_evidence340 hp2_2_check340 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches340,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node339 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected339 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected339 ((2 : Int),(2 : Int)) hp2_2_branches339 hp2_2_evidence339 hp2_2_check339 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches339,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node338 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected338 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected338 ((6 : Int),(2 : Int)) hp2_2_branches338 hp2_2_evidence338 hp2_2_check338 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches338,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node337 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected337 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected337 ((6 : Int),(2 : Int)) hp2_2_branches337 hp2_2_evidence337 hp2_2_check337 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches337,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node336 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected336 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected336 ((5 : Int),(2 : Int)) hp2_2_branches336 hp2_2_evidence336 hp2_2_check336 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches336,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node337 T childKnown
  · exact hp2_2_node338 T childKnown
theorem hp2_2_node335 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected335 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected335 ((2 : Int),(2 : Int)) hp2_2_branches335 hp2_2_evidence335 hp2_2_check335 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches335,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node336 T childKnown
theorem hp2_2_node334 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected334 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected334 ((6 : Int),(2 : Int)) hp2_2_branches334 hp2_2_evidence334 hp2_2_check334 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches334,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node333 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected333 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected333 ((6 : Int),(2 : Int)) hp2_2_branches333 hp2_2_evidence333 hp2_2_check333 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches333,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node332 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected332 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected332 ((5 : Int),(2 : Int)) hp2_2_branches332 hp2_2_evidence332 hp2_2_check332 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches332,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node333 T childKnown
  · exact hp2_2_node334 T childKnown
theorem hp2_2_node331 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected331 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected331 ((2 : Int),(2 : Int)) hp2_2_branches331 hp2_2_evidence331 hp2_2_check331 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches331,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node332 T childKnown
theorem hp2_2_node330 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected330 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected330 ((1 : Int),(2 : Int)) hp2_2_branches330 hp2_2_evidence330 hp2_2_check330 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches330,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node331 T childKnown
  · exact hp2_2_node335 T childKnown
  · exact hp2_2_node339 T childKnown
  · exact hp2_2_node340 T childKnown
  · exact hp2_2_node341 T childKnown
theorem hp2_2_node329 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected329 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected329 ((5 : Int),(0 : Int)) hp2_2_branches329 hp2_2_evidence329 hp2_2_check329 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches329,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node330 T childKnown
theorem hp2_2_node328 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected328 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected328 ((4 : Int),(0 : Int)) hp2_2_branches328 hp2_2_evidence328 hp2_2_check328 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches328,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node329 T childKnown
  · exact hp2_2_node342 T childKnown
  · exact hp2_2_node344 T childKnown
  · exact hp2_2_node349 T childKnown
theorem hp2_2_node327 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected327 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected327 ((3 : Int),(2 : Int)) hp2_2_branches327 hp2_2_evidence327 hp2_2_check327 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches327,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node326 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected326 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected326 ((3 : Int),(2 : Int)) hp2_2_branches326 hp2_2_evidence326 hp2_2_check326 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches326,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node325 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected325 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected325 ((4 : Int),(2 : Int)) hp2_2_branches325 hp2_2_evidence325 hp2_2_check325 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches325,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node324 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected324 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected324 ((4 : Int),(2 : Int)) hp2_2_branches324 hp2_2_evidence324 hp2_2_check324 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches324,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node323 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected323 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected323 ((3 : Int),(2 : Int)) hp2_2_branches323 hp2_2_evidence323 hp2_2_check323 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches323,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node324 T childKnown
  · exact hp2_2_node325 T childKnown
theorem hp2_2_node322 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected322 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected322 ((4 : Int),(2 : Int)) hp2_2_branches322 hp2_2_evidence322 hp2_2_check322 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches322,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node321 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected321 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected321 ((4 : Int),(2 : Int)) hp2_2_branches321 hp2_2_evidence321 hp2_2_check321 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches321,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node320 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected320 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected320 ((4 : Int),(2 : Int)) hp2_2_branches320 hp2_2_evidence320 hp2_2_check320 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches320,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node319 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected319 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected319 ((3 : Int),(2 : Int)) hp2_2_branches319 hp2_2_evidence319 hp2_2_check319 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches319,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node320 T childKnown
  · exact hp2_2_node321 T childKnown
  · exact hp2_2_node322 T childKnown
theorem hp2_2_node318 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected318 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected318 ((4 : Int),(2 : Int)) hp2_2_branches318 hp2_2_evidence318 hp2_2_check318 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches318,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node317 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected317 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected317 ((4 : Int),(2 : Int)) hp2_2_branches317 hp2_2_evidence317 hp2_2_check317 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches317,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node316 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected316 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected316 ((4 : Int),(2 : Int)) hp2_2_branches316 hp2_2_evidence316 hp2_2_check316 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches316,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node315 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected315 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected315 ((3 : Int),(2 : Int)) hp2_2_branches315 hp2_2_evidence315 hp2_2_check315 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches315,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node316 T childKnown
  · exact hp2_2_node317 T childKnown
  · exact hp2_2_node318 T childKnown
theorem hp2_2_node314 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected314 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected314 ((1 : Int),(2 : Int)) hp2_2_branches314 hp2_2_evidence314 hp2_2_check314 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches314,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node315 T childKnown
  · exact hp2_2_node319 T childKnown
  · exact hp2_2_node323 T childKnown
  · exact hp2_2_node326 T childKnown
  · exact hp2_2_node327 T childKnown
theorem hp2_2_node313 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected313 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected313 ((3 : Int),(0 : Int)) hp2_2_branches313 hp2_2_evidence313 hp2_2_check313 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches313,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node314 T childKnown
theorem hp2_2_node312 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected312 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected312 ((2 : Int),(2 : Int)) hp2_2_branches312 hp2_2_evidence312 hp2_2_check312 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches312,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node311 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected311 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected311 ((2 : Int),(2 : Int)) hp2_2_branches311 hp2_2_evidence311 hp2_2_check311 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches311,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node310 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected310 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected310 ((2 : Int),(1 : Int)) hp2_2_branches310 hp2_2_evidence310 hp2_2_check310 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches310,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node311 T childKnown
  · exact hp2_2_node312 T childKnown
theorem hp2_2_node309 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected309 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected309 ((3 : Int),(0 : Int)) hp2_2_branches309 hp2_2_evidence309 hp2_2_check309 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches309,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node308 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected308 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected308 ((3 : Int),(0 : Int)) hp2_2_branches308 hp2_2_evidence308 hp2_2_check308 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches308,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node307 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected307 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected307 ((2 : Int),(1 : Int)) hp2_2_branches307 hp2_2_evidence307 hp2_2_check307 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches307,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node308 T childKnown
  · exact hp2_2_node309 T childKnown
theorem hp2_2_node306 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected306 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected306 ((2 : Int),(2 : Int)) hp2_2_branches306 hp2_2_evidence306 hp2_2_check306 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches306,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node305 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected305 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected305 ((2 : Int),(2 : Int)) hp2_2_branches305 hp2_2_evidence305 hp2_2_check305 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches305,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node304 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected304 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected304 ((2 : Int),(1 : Int)) hp2_2_branches304 hp2_2_evidence304 hp2_2_check304 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches304,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node305 T childKnown
  · exact hp2_2_node306 T childKnown
theorem hp2_2_node303 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected303 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected303 ((2 : Int),(2 : Int)) hp2_2_branches303 hp2_2_evidence303 hp2_2_check303 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches303,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node302 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected302 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected302 ((2 : Int),(2 : Int)) hp2_2_branches302 hp2_2_evidence302 hp2_2_check302 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches302,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node301 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected301 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected301 ((2 : Int),(2 : Int)) hp2_2_branches301 hp2_2_evidence301 hp2_2_check301 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches301,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node300 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected300 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected300 ((2 : Int),(1 : Int)) hp2_2_branches300 hp2_2_evidence300 hp2_2_check300 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches300,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node301 T childKnown
  · exact hp2_2_node302 T childKnown
  · exact hp2_2_node303 T childKnown
theorem hp2_2_node299 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected299 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected299 ((3 : Int),(0 : Int)) hp2_2_branches299 hp2_2_evidence299 hp2_2_check299 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches299,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node298 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected298 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected298 ((3 : Int),(0 : Int)) hp2_2_branches298 hp2_2_evidence298 hp2_2_check298 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches298,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node297 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected297 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected297 ((3 : Int),(0 : Int)) hp2_2_branches297 hp2_2_evidence297 hp2_2_check297 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches297,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node296 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected296 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected296 ((3 : Int),(1 : Int)) hp2_2_branches296 hp2_2_evidence296 hp2_2_check296 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches296,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node295 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected295 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected295 ((3 : Int),(1 : Int)) hp2_2_branches295 hp2_2_evidence295 hp2_2_check295 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches295,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node294 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected294 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected294 ((3 : Int),(0 : Int)) hp2_2_branches294 hp2_2_evidence294 hp2_2_check294 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches294,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node295 T childKnown
  · exact hp2_2_node296 T childKnown
theorem hp2_2_node293 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected293 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected293 ((3 : Int),(1 : Int)) hp2_2_branches293 hp2_2_evidence293 hp2_2_check293 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches293,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node292 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected292 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected292 ((3 : Int),(0 : Int)) hp2_2_branches292 hp2_2_evidence292 hp2_2_check292 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches292,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node293 T childKnown
theorem hp2_2_node291 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected291 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected291 ((2 : Int),(1 : Int)) hp2_2_branches291 hp2_2_evidence291 hp2_2_check291 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches291,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node292 T childKnown
  · exact hp2_2_node294 T childKnown
  · exact hp2_2_node297 T childKnown
  · exact hp2_2_node298 T childKnown
  · exact hp2_2_node299 T childKnown
theorem hp2_2_node290 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected290 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected290 ((1 : Int),(1 : Int)) hp2_2_branches290 hp2_2_evidence290 hp2_2_check290 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches290,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node291 T childKnown
  · exact hp2_2_node300 T childKnown
  · exact hp2_2_node304 T childKnown
  · exact hp2_2_node307 T childKnown
  · exact hp2_2_node310 T childKnown
  · exact hp2_2_node313 T childKnown
  · exact hp2_2_node328 T childKnown
  · exact hp2_2_node351 T childKnown
theorem hp2_2_node289 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected289 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected289 ((1 : Int),(1 : Int)) hp2_2_branches289 hp2_2_evidence289 hp2_2_check289 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches289,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node288 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected288 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected288 ((1 : Int),(1 : Int)) hp2_2_branches288 hp2_2_evidence288 hp2_2_check288 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches288,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node287 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected287 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected287 ((1 : Int),(0 : Int)) hp2_2_branches287 hp2_2_evidence287 hp2_2_check287 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches287,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node288 T childKnown
  · exact hp2_2_node289 T childKnown
theorem hp2_2_node286 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected286 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected286 ((2 : Int),(1 : Int)) hp2_2_branches286 hp2_2_evidence286 hp2_2_check286 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches286,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node285 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected285 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected285 ((1 : Int),(1 : Int)) hp2_2_branches285 hp2_2_evidence285 hp2_2_check285 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches285,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node286 T childKnown
theorem hp2_2_node284 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected284 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected284 ((3 : Int),(2 : Int)) hp2_2_branches284 hp2_2_evidence284 hp2_2_check284 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches284,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node283 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected283 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected283 ((3 : Int),(2 : Int)) hp2_2_branches283 hp2_2_evidence283 hp2_2_check283 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches283,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node282 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected282 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected282 ((3 : Int),(2 : Int)) hp2_2_branches282 hp2_2_evidence282 hp2_2_check282 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches282,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node281 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected281 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected281 ((3 : Int),(1 : Int)) hp2_2_branches281 hp2_2_evidence281 hp2_2_check281 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches281,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node282 T childKnown
  · exact hp2_2_node283 T childKnown
  · exact hp2_2_node284 T childKnown
theorem hp2_2_node280 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected280 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected280 ((1 : Int),(1 : Int)) hp2_2_branches280 hp2_2_evidence280 hp2_2_check280 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches280,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node281 T childKnown
theorem hp2_2_node279 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected279 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected279 ((2 : Int),(1 : Int)) hp2_2_branches279 hp2_2_evidence279 hp2_2_check279 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches279,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node278 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected278 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected278 ((2 : Int),(0 : Int)) hp2_2_branches278 hp2_2_evidence278 hp2_2_check278 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches278,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node279 T childKnown
theorem hp2_2_node277 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected277 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected277 ((3 : Int),(2 : Int)) hp2_2_branches277 hp2_2_evidence277 hp2_2_check277 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches277,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node276 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected276 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected276 ((3 : Int),(2 : Int)) hp2_2_branches276 hp2_2_evidence276 hp2_2_check276 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches276,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node275 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected275 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected275 ((3 : Int),(2 : Int)) hp2_2_branches275 hp2_2_evidence275 hp2_2_check275 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches275,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node274 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected274 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected274 ((3 : Int),(2 : Int)) hp2_2_branches274 hp2_2_evidence274 hp2_2_check274 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches274,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node273 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected273 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected273 ((5 : Int),(2 : Int)) hp2_2_branches273 hp2_2_evidence273 hp2_2_check273 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches273,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node272 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected272 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected272 ((5 : Int),(2 : Int)) hp2_2_branches272 hp2_2_evidence272 hp2_2_check272 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches272,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node271 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected271 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected271 ((5 : Int),(2 : Int)) hp2_2_branches271 hp2_2_evidence271 hp2_2_check271 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches271,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node270 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected270 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected270 ((6 : Int),(1 : Int)) hp2_2_branches270 hp2_2_evidence270 hp2_2_check270 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches270,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node269 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected269 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected269 ((6 : Int),(1 : Int)) hp2_2_branches269 hp2_2_evidence269 hp2_2_check269 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches269,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node268 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected268 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected268 ((6 : Int),(0 : Int)) hp2_2_branches268 hp2_2_evidence268 hp2_2_check268 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches268,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node269 T childKnown
  · exact hp2_2_node270 T childKnown
theorem hp2_2_node267 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected267 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected267 ((5 : Int),(1 : Int)) hp2_2_branches267 hp2_2_evidence267 hp2_2_check267 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches267,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node268 T childKnown
  · exact hp2_2_node271 T childKnown
  · exact hp2_2_node272 T childKnown
  · exact hp2_2_node273 T childKnown
theorem hp2_2_node266 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected266 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected266 ((5 : Int),(2 : Int)) hp2_2_branches266 hp2_2_evidence266 hp2_2_check266 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches266,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node265 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected265 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected265 ((5 : Int),(2 : Int)) hp2_2_branches265 hp2_2_evidence265 hp2_2_check265 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches265,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node264 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected264 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected264 ((5 : Int),(2 : Int)) hp2_2_branches264 hp2_2_evidence264 hp2_2_check264 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches264,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node263 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected263 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected263 ((5 : Int),(1 : Int)) hp2_2_branches263 hp2_2_evidence263 hp2_2_check263 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches263,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node264 T childKnown
  · exact hp2_2_node265 T childKnown
  · exact hp2_2_node266 T childKnown
theorem hp2_2_node262 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected262 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected262 ((3 : Int),(2 : Int)) hp2_2_branches262 hp2_2_evidence262 hp2_2_check262 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches262,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node263 T childKnown
  · exact hp2_2_node267 T childKnown
theorem hp2_2_node261 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected261 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected261 ((2 : Int),(2 : Int)) hp2_2_branches261 hp2_2_evidence261 hp2_2_check261 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches261,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node262 T childKnown
  · exact hp2_2_node274 T childKnown
  · exact hp2_2_node275 T childKnown
  · exact hp2_2_node276 T childKnown
  · exact hp2_2_node277 T childKnown
theorem hp2_2_node260 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected260 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected260 ((2 : Int),(0 : Int)) hp2_2_branches260 hp2_2_evidence260 hp2_2_check260 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches260,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node261 T childKnown
theorem hp2_2_node259 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected259 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected259 ((1 : Int),(0 : Int)) hp2_2_branches259 hp2_2_evidence259 hp2_2_check259 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches259,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node260 T childKnown
  · exact hp2_2_node278 T childKnown
  · exact hp2_2_node280 T childKnown
  · exact hp2_2_node285 T childKnown
theorem hp2_2_node258 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected258 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected258 ((2 : Int),(1 : Int)) hp2_2_branches258 hp2_2_evidence258 hp2_2_check258 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches258,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node257 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected257 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected257 ((1 : Int),(1 : Int)) hp2_2_branches257 hp2_2_evidence257 hp2_2_check257 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches257,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node258 T childKnown
theorem hp2_2_node256 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected256 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected256 ((3 : Int),(2 : Int)) hp2_2_branches256 hp2_2_evidence256 hp2_2_check256 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches256,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node255 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected255 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected255 ((3 : Int),(2 : Int)) hp2_2_branches255 hp2_2_evidence255 hp2_2_check255 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches255,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node254 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected254 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected254 ((3 : Int),(2 : Int)) hp2_2_branches254 hp2_2_evidence254 hp2_2_check254 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches254,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node253 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected253 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected253 ((3 : Int),(1 : Int)) hp2_2_branches253 hp2_2_evidence253 hp2_2_check253 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches253,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node254 T childKnown
  · exact hp2_2_node255 T childKnown
  · exact hp2_2_node256 T childKnown
theorem hp2_2_node252 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected252 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected252 ((1 : Int),(1 : Int)) hp2_2_branches252 hp2_2_evidence252 hp2_2_check252 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches252,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node253 T childKnown
theorem hp2_2_node251 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected251 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected251 ((2 : Int),(1 : Int)) hp2_2_branches251 hp2_2_evidence251 hp2_2_check251 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches251,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node250 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected250 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected250 ((2 : Int),(0 : Int)) hp2_2_branches250 hp2_2_evidence250 hp2_2_check250 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches250,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node251 T childKnown
theorem hp2_2_node249 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected249 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected249 ((3 : Int),(2 : Int)) hp2_2_branches249 hp2_2_evidence249 hp2_2_check249 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches249,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node248 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected248 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected248 ((3 : Int),(2 : Int)) hp2_2_branches248 hp2_2_evidence248 hp2_2_check248 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches248,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node247 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected247 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected247 ((3 : Int),(2 : Int)) hp2_2_branches247 hp2_2_evidence247 hp2_2_check247 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches247,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node246 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected246 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected246 ((3 : Int),(2 : Int)) hp2_2_branches246 hp2_2_evidence246 hp2_2_check246 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches246,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node245 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected245 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected245 ((5 : Int),(2 : Int)) hp2_2_branches245 hp2_2_evidence245 hp2_2_check245 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches245,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node244 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected244 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected244 ((5 : Int),(2 : Int)) hp2_2_branches244 hp2_2_evidence244 hp2_2_check244 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches244,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node243 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected243 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected243 ((5 : Int),(2 : Int)) hp2_2_branches243 hp2_2_evidence243 hp2_2_check243 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches243,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node242 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected242 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected242 ((6 : Int),(1 : Int)) hp2_2_branches242 hp2_2_evidence242 hp2_2_check242 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches242,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node241 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected241 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected241 ((6 : Int),(1 : Int)) hp2_2_branches241 hp2_2_evidence241 hp2_2_check241 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches241,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node240 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected240 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected240 ((6 : Int),(0 : Int)) hp2_2_branches240 hp2_2_evidence240 hp2_2_check240 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches240,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node241 T childKnown
  · exact hp2_2_node242 T childKnown
theorem hp2_2_node239 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected239 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected239 ((5 : Int),(1 : Int)) hp2_2_branches239 hp2_2_evidence239 hp2_2_check239 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches239,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node240 T childKnown
  · exact hp2_2_node243 T childKnown
  · exact hp2_2_node244 T childKnown
  · exact hp2_2_node245 T childKnown
theorem hp2_2_node238 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected238 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected238 ((5 : Int),(2 : Int)) hp2_2_branches238 hp2_2_evidence238 hp2_2_check238 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches238,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node237 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected237 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected237 ((5 : Int),(2 : Int)) hp2_2_branches237 hp2_2_evidence237 hp2_2_check237 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches237,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node236 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected236 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected236 ((5 : Int),(2 : Int)) hp2_2_branches236 hp2_2_evidence236 hp2_2_check236 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches236,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node235 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected235 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected235 ((5 : Int),(1 : Int)) hp2_2_branches235 hp2_2_evidence235 hp2_2_check235 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches235,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node236 T childKnown
  · exact hp2_2_node237 T childKnown
  · exact hp2_2_node238 T childKnown
theorem hp2_2_node234 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected234 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected234 ((3 : Int),(2 : Int)) hp2_2_branches234 hp2_2_evidence234 hp2_2_check234 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches234,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node235 T childKnown
  · exact hp2_2_node239 T childKnown
theorem hp2_2_node233 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected233 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected233 ((2 : Int),(2 : Int)) hp2_2_branches233 hp2_2_evidence233 hp2_2_check233 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches233,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node234 T childKnown
  · exact hp2_2_node246 T childKnown
  · exact hp2_2_node247 T childKnown
  · exact hp2_2_node248 T childKnown
  · exact hp2_2_node249 T childKnown
theorem hp2_2_node232 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected232 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected232 ((2 : Int),(0 : Int)) hp2_2_branches232 hp2_2_evidence232 hp2_2_check232 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches232,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node233 T childKnown
theorem hp2_2_node231 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected231 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected231 ((1 : Int),(0 : Int)) hp2_2_branches231 hp2_2_evidence231 hp2_2_check231 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches231,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node232 T childKnown
  · exact hp2_2_node250 T childKnown
  · exact hp2_2_node252 T childKnown
  · exact hp2_2_node257 T childKnown
theorem hp2_2_node230 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected230 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected230 ((3 : Int),(1 : Int)) hp2_2_branches230 hp2_2_evidence230 hp2_2_check230 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches230,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node229 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected229 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected229 ((1 : Int),(1 : Int)) hp2_2_branches229 hp2_2_evidence229 hp2_2_check229 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches229,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node228 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected228 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected228 ((1 : Int),(1 : Int)) hp2_2_branches228 hp2_2_evidence228 hp2_2_check228 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches228,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node227 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected227 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected227 ((1 : Int),(1 : Int)) hp2_2_branches227 hp2_2_evidence227 hp2_2_check227 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches227,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node226 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected226 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected226 ((2 : Int),(1 : Int)) hp2_2_branches226 hp2_2_evidence226 hp2_2_check226 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches226,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node227 T childKnown
  · exact hp2_2_node228 T childKnown
  · exact hp2_2_node229 T childKnown
  · exact hp2_2_node230 T childKnown
theorem hp2_2_node225 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected225 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected225 ((2 : Int),(1 : Int)) hp2_2_branches225 hp2_2_evidence225 hp2_2_check225 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches225,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node224 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected224 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected224 ((2 : Int),(1 : Int)) hp2_2_branches224 hp2_2_evidence224 hp2_2_check224 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches224,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node223 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected223 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected223 ((2 : Int),(1 : Int)) hp2_2_branches223 hp2_2_evidence223 hp2_2_check223 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches223,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node222 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected222 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected222 ((4 : Int),(2 : Int)) hp2_2_branches222 hp2_2_evidence222 hp2_2_check222 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches222,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node221 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected221 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected221 ((4 : Int),(2 : Int)) hp2_2_branches221 hp2_2_evidence221 hp2_2_check221 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches221,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node220 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected220 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected220 ((4 : Int),(2 : Int)) hp2_2_branches220 hp2_2_evidence220 hp2_2_check220 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches220,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node219 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected219 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected219 ((4 : Int),(1 : Int)) hp2_2_branches219 hp2_2_evidence219 hp2_2_check219 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches219,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node220 T childKnown
  · exact hp2_2_node221 T childKnown
  · exact hp2_2_node222 T childKnown
theorem hp2_2_node218 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected218 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected218 ((2 : Int),(1 : Int)) hp2_2_branches218 hp2_2_evidence218 hp2_2_check218 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches218,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node219 T childKnown
theorem hp2_2_node217 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected217 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected217 ((1 : Int),(1 : Int)) hp2_2_branches217 hp2_2_evidence217 hp2_2_check217 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches217,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node218 T childKnown
  · exact hp2_2_node223 T childKnown
  · exact hp2_2_node224 T childKnown
  · exact hp2_2_node225 T childKnown
theorem hp2_2_node216 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected216 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected216 ((3 : Int),(1 : Int)) hp2_2_branches216 hp2_2_evidence216 hp2_2_check216 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches216,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node215 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected215 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected215 ((3 : Int),(0 : Int)) hp2_2_branches215 hp2_2_evidence215 hp2_2_check215 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches215,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node216 T childKnown
theorem hp2_2_node214 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected214 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected214 ((1 : Int),(1 : Int)) hp2_2_branches214 hp2_2_evidence214 hp2_2_check214 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches214,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node215 T childKnown
theorem hp2_2_node213 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected213 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected213 ((4 : Int),(2 : Int)) hp2_2_branches213 hp2_2_evidence213 hp2_2_check213 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches213,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node212 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected212 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected212 ((4 : Int),(2 : Int)) hp2_2_branches212 hp2_2_evidence212 hp2_2_check212 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches212,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node211 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected211 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected211 ((4 : Int),(2 : Int)) hp2_2_branches211 hp2_2_evidence211 hp2_2_check211 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches211,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node210 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected210 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected210 ((3 : Int),(2 : Int)) hp2_2_branches210 hp2_2_evidence210 hp2_2_check210 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches210,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node211 T childKnown
  · exact hp2_2_node212 T childKnown
  · exact hp2_2_node213 T childKnown
theorem hp2_2_node209 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected209 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected209 ((3 : Int),(0 : Int)) hp2_2_branches209 hp2_2_evidence209 hp2_2_check209 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches209,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node210 T childKnown
theorem hp2_2_node208 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected208 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected208 ((1 : Int),(1 : Int)) hp2_2_branches208 hp2_2_evidence208 hp2_2_check208 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches208,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node209 T childKnown
theorem hp2_2_node207 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected207 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected207 ((1 : Int),(1 : Int)) hp2_2_branches207 hp2_2_evidence207 hp2_2_check207 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches207,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node206 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected206 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected206 ((2 : Int),(0 : Int)) hp2_2_branches206 hp2_2_evidence206 hp2_2_check206 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches206,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node207 T childKnown
  · exact hp2_2_node208 T childKnown
  · exact hp2_2_node214 T childKnown
  · exact hp2_2_node217 T childKnown
  · exact hp2_2_node226 T childKnown
theorem hp2_2_node205 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected205 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected205 ((1 : Int),(2 : Int)) hp2_2_branches205 hp2_2_evidence205 hp2_2_check205 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches205,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node204 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected204 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected204 ((1 : Int),(2 : Int)) hp2_2_branches204 hp2_2_evidence204 hp2_2_check204 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches204,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node203 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected203 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected203 ((1 : Int),(2 : Int)) hp2_2_branches203 hp2_2_evidence203 hp2_2_check203 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches203,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node202 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected202 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected202 ((3 : Int),(2 : Int)) hp2_2_branches202 hp2_2_evidence202 hp2_2_check202 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches202,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node201 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected201 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected201 ((1 : Int),(2 : Int)) hp2_2_branches201 hp2_2_evidence201 hp2_2_check201 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches201,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node202 T childKnown
theorem hp2_2_node200 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected200 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected200 ((3 : Int),(2 : Int)) hp2_2_branches200 hp2_2_evidence200 hp2_2_check200 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches200,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node199 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected199 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected199 ((1 : Int),(2 : Int)) hp2_2_branches199 hp2_2_evidence199 hp2_2_check199 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches199,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node200 T childKnown
theorem hp2_2_node198 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected198 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected198 ((0 : Int),(2 : Int)) hp2_2_branches198 hp2_2_evidence198 hp2_2_check198 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches198,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node199 T childKnown
  · exact hp2_2_node201 T childKnown
  · exact hp2_2_node203 T childKnown
  · exact hp2_2_node204 T childKnown
  · exact hp2_2_node205 T childKnown
theorem hp2_2_node197 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected197 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected197 ((2 : Int),(0 : Int)) hp2_2_branches197 hp2_2_evidence197 hp2_2_check197 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches197,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node198 T childKnown
theorem hp2_2_node196 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected196 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected196 ((4 : Int),(1 : Int)) hp2_2_branches196 hp2_2_evidence196 hp2_2_check196 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches196,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node195 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected195 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected195 ((3 : Int),(1 : Int)) hp2_2_branches195 hp2_2_evidence195 hp2_2_check195 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches195,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node196 T childKnown
theorem hp2_2_node194 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected194 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected194 ((0 : Int),(2 : Int)) hp2_2_branches194 hp2_2_evidence194 hp2_2_check194 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches194,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node193 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected193 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected193 ((0 : Int),(2 : Int)) hp2_2_branches193 hp2_2_evidence193 hp2_2_check193 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches193,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node192 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected192 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected192 ((0 : Int),(2 : Int)) hp2_2_branches192 hp2_2_evidence192 hp2_2_check192 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches192,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node191 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected191 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected191 ((1 : Int),(2 : Int)) hp2_2_branches191 hp2_2_evidence191 hp2_2_check191 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches191,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node192 T childKnown
  · exact hp2_2_node193 T childKnown
  · exact hp2_2_node194 T childKnown
theorem hp2_2_node190 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected190 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected190 ((3 : Int),(1 : Int)) hp2_2_branches190 hp2_2_evidence190 hp2_2_check190 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches190,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node191 T childKnown
theorem hp2_2_node189 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected189 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected189 ((4 : Int),(1 : Int)) hp2_2_branches189 hp2_2_evidence189 hp2_2_check189 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches189,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node188 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected188 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected188 ((4 : Int),(0 : Int)) hp2_2_branches188 hp2_2_evidence188 hp2_2_check188 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches188,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node189 T childKnown
theorem hp2_2_node187 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected187 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected187 ((1 : Int),(2 : Int)) hp2_2_branches187 hp2_2_evidence187 hp2_2_check187 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches187,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node186 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected186 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected186 ((1 : Int),(2 : Int)) hp2_2_branches186 hp2_2_evidence186 hp2_2_check186 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches186,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node185 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected185 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected185 ((1 : Int),(2 : Int)) hp2_2_branches185 hp2_2_evidence185 hp2_2_check185 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches185,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node184 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected184 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected184 ((5 : Int),(2 : Int)) hp2_2_branches184 hp2_2_evidence184 hp2_2_check184 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches184,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node183 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected183 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected183 ((5 : Int),(2 : Int)) hp2_2_branches183 hp2_2_evidence183 hp2_2_check183 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches183,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node182 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected182 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected182 ((4 : Int),(2 : Int)) hp2_2_branches182 hp2_2_evidence182 hp2_2_check182 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches182,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node183 T childKnown
  · exact hp2_2_node184 T childKnown
theorem hp2_2_node181 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected181 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected181 ((1 : Int),(2 : Int)) hp2_2_branches181 hp2_2_evidence181 hp2_2_check181 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches181,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node182 T childKnown
theorem hp2_2_node180 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected180 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected180 ((5 : Int),(2 : Int)) hp2_2_branches180 hp2_2_evidence180 hp2_2_check180 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches180,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node179 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected179 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected179 ((5 : Int),(2 : Int)) hp2_2_branches179 hp2_2_evidence179 hp2_2_check179 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches179,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node178 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected178 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected178 ((4 : Int),(2 : Int)) hp2_2_branches178 hp2_2_evidence178 hp2_2_check178 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches178,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node179 T childKnown
  · exact hp2_2_node180 T childKnown
theorem hp2_2_node177 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected177 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected177 ((1 : Int),(2 : Int)) hp2_2_branches177 hp2_2_evidence177 hp2_2_check177 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches177,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node178 T childKnown
theorem hp2_2_node176 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected176 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected176 ((0 : Int),(2 : Int)) hp2_2_branches176 hp2_2_evidence176 hp2_2_check176 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches176,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node177 T childKnown
  · exact hp2_2_node181 T childKnown
  · exact hp2_2_node185 T childKnown
  · exact hp2_2_node186 T childKnown
  · exact hp2_2_node187 T childKnown
theorem hp2_2_node175 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected175 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected175 ((4 : Int),(0 : Int)) hp2_2_branches175 hp2_2_evidence175 hp2_2_check175 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches175,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node176 T childKnown
theorem hp2_2_node174 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected174 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected174 ((3 : Int),(0 : Int)) hp2_2_branches174 hp2_2_evidence174 hp2_2_check174 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches174,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node175 T childKnown
  · exact hp2_2_node188 T childKnown
  · exact hp2_2_node190 T childKnown
  · exact hp2_2_node195 T childKnown
theorem hp2_2_node173 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected173 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected173 ((2 : Int),(2 : Int)) hp2_2_branches173 hp2_2_evidence173 hp2_2_check173 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches173,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node172 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected172 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected172 ((2 : Int),(2 : Int)) hp2_2_branches172 hp2_2_evidence172 hp2_2_check172 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches172,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node171 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected171 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected171 ((3 : Int),(2 : Int)) hp2_2_branches171 hp2_2_evidence171 hp2_2_check171 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches171,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node170 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected170 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected170 ((3 : Int),(2 : Int)) hp2_2_branches170 hp2_2_evidence170 hp2_2_check170 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches170,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node169 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected169 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected169 ((2 : Int),(2 : Int)) hp2_2_branches169 hp2_2_evidence169 hp2_2_check169 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches169,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node170 T childKnown
  · exact hp2_2_node171 T childKnown
theorem hp2_2_node168 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected168 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected168 ((3 : Int),(2 : Int)) hp2_2_branches168 hp2_2_evidence168 hp2_2_check168 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches168,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node167 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected167 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected167 ((3 : Int),(2 : Int)) hp2_2_branches167 hp2_2_evidence167 hp2_2_check167 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches167,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node166 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected166 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected166 ((3 : Int),(2 : Int)) hp2_2_branches166 hp2_2_evidence166 hp2_2_check166 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches166,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node165 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected165 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected165 ((2 : Int),(2 : Int)) hp2_2_branches165 hp2_2_evidence165 hp2_2_check165 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches165,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node166 T childKnown
  · exact hp2_2_node167 T childKnown
  · exact hp2_2_node168 T childKnown
theorem hp2_2_node164 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected164 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected164 ((3 : Int),(2 : Int)) hp2_2_branches164 hp2_2_evidence164 hp2_2_check164 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches164,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node163 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected163 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected163 ((3 : Int),(2 : Int)) hp2_2_branches163 hp2_2_evidence163 hp2_2_check163 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches163,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node162 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected162 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected162 ((3 : Int),(2 : Int)) hp2_2_branches162 hp2_2_evidence162 hp2_2_check162 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches162,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node161 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected161 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected161 ((2 : Int),(2 : Int)) hp2_2_branches161 hp2_2_evidence161 hp2_2_check161 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches161,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node162 T childKnown
  · exact hp2_2_node163 T childKnown
  · exact hp2_2_node164 T childKnown
theorem hp2_2_node160 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected160 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected160 ((0 : Int),(2 : Int)) hp2_2_branches160 hp2_2_evidence160 hp2_2_check160 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches160,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node161 T childKnown
  · exact hp2_2_node165 T childKnown
  · exact hp2_2_node169 T childKnown
  · exact hp2_2_node172 T childKnown
  · exact hp2_2_node173 T childKnown
theorem hp2_2_node159 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected159 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected159 ((2 : Int),(0 : Int)) hp2_2_branches159 hp2_2_evidence159 hp2_2_check159 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches159,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node160 T childKnown
theorem hp2_2_node158 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected158 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected158 ((1 : Int),(2 : Int)) hp2_2_branches158 hp2_2_evidence158 hp2_2_check158 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches158,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node157 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected157 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected157 ((1 : Int),(2 : Int)) hp2_2_branches157 hp2_2_evidence157 hp2_2_check157 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches157,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node156 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected156 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected156 ((1 : Int),(1 : Int)) hp2_2_branches156 hp2_2_evidence156 hp2_2_check156 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches156,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node157 T childKnown
  · exact hp2_2_node158 T childKnown
theorem hp2_2_node155 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected155 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected155 ((2 : Int),(0 : Int)) hp2_2_branches155 hp2_2_evidence155 hp2_2_check155 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches155,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node154 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected154 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected154 ((2 : Int),(0 : Int)) hp2_2_branches154 hp2_2_evidence154 hp2_2_check154 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches154,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node153 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected153 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected153 ((1 : Int),(1 : Int)) hp2_2_branches153 hp2_2_evidence153 hp2_2_check153 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches153,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node154 T childKnown
  · exact hp2_2_node155 T childKnown
theorem hp2_2_node152 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected152 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected152 ((1 : Int),(2 : Int)) hp2_2_branches152 hp2_2_evidence152 hp2_2_check152 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches152,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node151 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected151 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected151 ((1 : Int),(2 : Int)) hp2_2_branches151 hp2_2_evidence151 hp2_2_check151 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches151,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node150 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected150 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected150 ((1 : Int),(1 : Int)) hp2_2_branches150 hp2_2_evidence150 hp2_2_check150 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches150,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node151 T childKnown
  · exact hp2_2_node152 T childKnown
theorem hp2_2_node149 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected149 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected149 ((1 : Int),(2 : Int)) hp2_2_branches149 hp2_2_evidence149 hp2_2_check149 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches149,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node148 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected148 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected148 ((1 : Int),(2 : Int)) hp2_2_branches148 hp2_2_evidence148 hp2_2_check148 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches148,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node147 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected147 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected147 ((1 : Int),(2 : Int)) hp2_2_branches147 hp2_2_evidence147 hp2_2_check147 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches147,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node146 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected146 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected146 ((1 : Int),(1 : Int)) hp2_2_branches146 hp2_2_evidence146 hp2_2_check146 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches146,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node147 T childKnown
  · exact hp2_2_node148 T childKnown
  · exact hp2_2_node149 T childKnown
theorem hp2_2_node145 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected145 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected145 ((2 : Int),(0 : Int)) hp2_2_branches145 hp2_2_evidence145 hp2_2_check145 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches145,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node144 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected144 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected144 ((2 : Int),(0 : Int)) hp2_2_branches144 hp2_2_evidence144 hp2_2_check144 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches144,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node143 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected143 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected143 ((2 : Int),(0 : Int)) hp2_2_branches143 hp2_2_evidence143 hp2_2_check143 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches143,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node142 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected142 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected142 ((2 : Int),(1 : Int)) hp2_2_branches142 hp2_2_evidence142 hp2_2_check142 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches142,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node141 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected141 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected141 ((2 : Int),(1 : Int)) hp2_2_branches141 hp2_2_evidence141 hp2_2_check141 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches141,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node140 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected140 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected140 ((2 : Int),(0 : Int)) hp2_2_branches140 hp2_2_evidence140 hp2_2_check140 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches140,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node141 T childKnown
  · exact hp2_2_node142 T childKnown
theorem hp2_2_node139 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected139 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected139 ((2 : Int),(1 : Int)) hp2_2_branches139 hp2_2_evidence139 hp2_2_check139 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches139,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node138 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected138 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected138 ((2 : Int),(0 : Int)) hp2_2_branches138 hp2_2_evidence138 hp2_2_check138 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches138,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node139 T childKnown
theorem hp2_2_node137 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected137 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected137 ((1 : Int),(1 : Int)) hp2_2_branches137 hp2_2_evidence137 hp2_2_check137 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches137,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node138 T childKnown
  · exact hp2_2_node140 T childKnown
  · exact hp2_2_node143 T childKnown
  · exact hp2_2_node144 T childKnown
  · exact hp2_2_node145 T childKnown
theorem hp2_2_node136 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected136 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected136 ((0 : Int),(1 : Int)) hp2_2_branches136 hp2_2_evidence136 hp2_2_check136 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches136,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node137 T childKnown
  · exact hp2_2_node146 T childKnown
  · exact hp2_2_node150 T childKnown
  · exact hp2_2_node153 T childKnown
  · exact hp2_2_node156 T childKnown
  · exact hp2_2_node159 T childKnown
  · exact hp2_2_node174 T childKnown
  · exact hp2_2_node197 T childKnown
theorem hp2_2_node135 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected135 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected135 ((2 : Int),(1 : Int)) hp2_2_branches135 hp2_2_evidence135 hp2_2_check135 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches135,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node134 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected134 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected134 ((0 : Int),(1 : Int)) hp2_2_branches134 hp2_2_evidence134 hp2_2_check134 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches134,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node133 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected133 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected133 ((0 : Int),(1 : Int)) hp2_2_branches133 hp2_2_evidence133 hp2_2_check133 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches133,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node132 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected132 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected132 ((0 : Int),(1 : Int)) hp2_2_branches132 hp2_2_evidence132 hp2_2_check132 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches132,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node131 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected131 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected131 ((1 : Int),(1 : Int)) hp2_2_branches131 hp2_2_evidence131 hp2_2_check131 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches131,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node132 T childKnown
  · exact hp2_2_node133 T childKnown
  · exact hp2_2_node134 T childKnown
  · exact hp2_2_node135 T childKnown
theorem hp2_2_node130 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected130 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected130 ((1 : Int),(1 : Int)) hp2_2_branches130 hp2_2_evidence130 hp2_2_check130 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches130,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node129 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected129 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected129 ((1 : Int),(1 : Int)) hp2_2_branches129 hp2_2_evidence129 hp2_2_check129 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches129,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node128 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected128 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected128 ((1 : Int),(1 : Int)) hp2_2_branches128 hp2_2_evidence128 hp2_2_check128 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches128,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node127 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected127 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected127 ((3 : Int),(2 : Int)) hp2_2_branches127 hp2_2_evidence127 hp2_2_check127 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches127,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node126 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected126 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected126 ((3 : Int),(2 : Int)) hp2_2_branches126 hp2_2_evidence126 hp2_2_check126 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches126,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node125 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected125 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected125 ((3 : Int),(2 : Int)) hp2_2_branches125 hp2_2_evidence125 hp2_2_check125 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches125,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node124 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected124 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected124 ((3 : Int),(1 : Int)) hp2_2_branches124 hp2_2_evidence124 hp2_2_check124 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches124,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node125 T childKnown
  · exact hp2_2_node126 T childKnown
  · exact hp2_2_node127 T childKnown
theorem hp2_2_node123 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected123 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected123 ((1 : Int),(1 : Int)) hp2_2_branches123 hp2_2_evidence123 hp2_2_check123 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches123,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node124 T childKnown
theorem hp2_2_node122 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected122 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected122 ((0 : Int),(1 : Int)) hp2_2_branches122 hp2_2_evidence122 hp2_2_check122 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches122,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node123 T childKnown
  · exact hp2_2_node128 T childKnown
  · exact hp2_2_node129 T childKnown
  · exact hp2_2_node130 T childKnown
theorem hp2_2_node121 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected121 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected121 ((2 : Int),(1 : Int)) hp2_2_branches121 hp2_2_evidence121 hp2_2_check121 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches121,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node120 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected120 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected120 ((2 : Int),(0 : Int)) hp2_2_branches120 hp2_2_evidence120 hp2_2_check120 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches120,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node121 T childKnown
theorem hp2_2_node119 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected119 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected119 ((0 : Int),(1 : Int)) hp2_2_branches119 hp2_2_evidence119 hp2_2_check119 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches119,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node120 T childKnown
theorem hp2_2_node118 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected118 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected118 ((3 : Int),(2 : Int)) hp2_2_branches118 hp2_2_evidence118 hp2_2_check118 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches118,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node117 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected117 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected117 ((3 : Int),(2 : Int)) hp2_2_branches117 hp2_2_evidence117 hp2_2_check117 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches117,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node116 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected116 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected116 ((3 : Int),(2 : Int)) hp2_2_branches116 hp2_2_evidence116 hp2_2_check116 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches116,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node115 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected115 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected115 ((2 : Int),(2 : Int)) hp2_2_branches115 hp2_2_evidence115 hp2_2_check115 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches115,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node116 T childKnown
  · exact hp2_2_node117 T childKnown
  · exact hp2_2_node118 T childKnown
theorem hp2_2_node114 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected114 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected114 ((2 : Int),(0 : Int)) hp2_2_branches114 hp2_2_evidence114 hp2_2_check114 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches114,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node115 T childKnown
theorem hp2_2_node113 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected113 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected113 ((0 : Int),(1 : Int)) hp2_2_branches113 hp2_2_evidence113 hp2_2_check113 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches113,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node114 T childKnown
theorem hp2_2_node112 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected112 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected112 ((0 : Int),(1 : Int)) hp2_2_branches112 hp2_2_evidence112 hp2_2_check112 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches112,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node111 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected111 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected111 ((1 : Int),(0 : Int)) hp2_2_branches111 hp2_2_evidence111 hp2_2_check111 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches111,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node112 T childKnown
  · exact hp2_2_node113 T childKnown
  · exact hp2_2_node119 T childKnown
  · exact hp2_2_node122 T childKnown
  · exact hp2_2_node131 T childKnown
theorem hp2_2_node110 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected110 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected110 ((6 : Int),(1 : Int)) hp2_2_branches110 hp2_2_evidence110 hp2_2_check110 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches110,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node109 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected109 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected109 ((4 : Int),(1 : Int)) hp2_2_branches109 hp2_2_evidence109 hp2_2_check109 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches109,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node108 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected108 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected108 ((4 : Int),(1 : Int)) hp2_2_branches108 hp2_2_evidence108 hp2_2_check108 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches108,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node107 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected107 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected107 ((4 : Int),(1 : Int)) hp2_2_branches107 hp2_2_evidence107 hp2_2_check107 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches107,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node106 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected106 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected106 ((5 : Int),(1 : Int)) hp2_2_branches106 hp2_2_evidence106 hp2_2_check106 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches106,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node107 T childKnown
  · exact hp2_2_node108 T childKnown
  · exact hp2_2_node109 T childKnown
  · exact hp2_2_node110 T childKnown
theorem hp2_2_node105 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected105 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected105 ((5 : Int),(1 : Int)) hp2_2_branches105 hp2_2_evidence105 hp2_2_check105 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches105,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node104 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected104 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected104 ((5 : Int),(1 : Int)) hp2_2_branches104 hp2_2_evidence104 hp2_2_check104 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches104,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node103 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected103 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected103 ((5 : Int),(1 : Int)) hp2_2_branches103 hp2_2_evidence103 hp2_2_check103 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches103,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node102 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected102 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected102 ((2 : Int),(2 : Int)) hp2_2_branches102 hp2_2_evidence102 hp2_2_check102 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches102,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node101 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected101 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected101 ((2 : Int),(2 : Int)) hp2_2_branches101 hp2_2_evidence101 hp2_2_check101 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches101,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node100 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected100 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected100 ((2 : Int),(1 : Int)) hp2_2_branches100 hp2_2_evidence100 hp2_2_check100 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches100,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node101 T childKnown
  · exact hp2_2_node102 T childKnown
theorem hp2_2_node99 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected99 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected99 ((5 : Int),(1 : Int)) hp2_2_branches99 hp2_2_evidence99 hp2_2_check99 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches99,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node100 T childKnown
theorem hp2_2_node98 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected98 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected98 ((4 : Int),(1 : Int)) hp2_2_branches98 hp2_2_evidence98 hp2_2_check98 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches98,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node99 T childKnown
  · exact hp2_2_node103 T childKnown
  · exact hp2_2_node104 T childKnown
  · exact hp2_2_node105 T childKnown
theorem hp2_2_node97 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected97 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected97 ((6 : Int),(1 : Int)) hp2_2_branches97 hp2_2_evidence97 hp2_2_check97 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches97,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node96 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected96 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected96 ((6 : Int),(0 : Int)) hp2_2_branches96 hp2_2_evidence96 hp2_2_check96 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches96,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node97 T childKnown
theorem hp2_2_node95 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected95 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected95 ((4 : Int),(1 : Int)) hp2_2_branches95 hp2_2_evidence95 hp2_2_check95 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches95,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node96 T childKnown
theorem hp2_2_node94 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected94 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected94 ((2 : Int),(2 : Int)) hp2_2_branches94 hp2_2_evidence94 hp2_2_check94 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches94,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node93 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected93 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected93 ((2 : Int),(2 : Int)) hp2_2_branches93 hp2_2_evidence93 hp2_2_check93 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches93,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node92 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected92 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected92 ((2 : Int),(1 : Int)) hp2_2_branches92 hp2_2_evidence92 hp2_2_check92 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches92,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node93 T childKnown
  · exact hp2_2_node94 T childKnown
theorem hp2_2_node91 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected91 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected91 ((6 : Int),(0 : Int)) hp2_2_branches91 hp2_2_evidence91 hp2_2_check91 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches91,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node92 T childKnown
theorem hp2_2_node90 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected90 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected90 ((4 : Int),(1 : Int)) hp2_2_branches90 hp2_2_evidence90 hp2_2_check90 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches90,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node91 T childKnown
theorem hp2_2_node89 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected89 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected89 ((4 : Int),(1 : Int)) hp2_2_branches89 hp2_2_evidence89 hp2_2_check89 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches89,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node88 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected88 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected88 ((5 : Int),(0 : Int)) hp2_2_branches88 hp2_2_evidence88 hp2_2_check88 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches88,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node89 T childKnown
  · exact hp2_2_node90 T childKnown
  · exact hp2_2_node95 T childKnown
  · exact hp2_2_node98 T childKnown
  · exact hp2_2_node106 T childKnown
theorem hp2_2_node87 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected87 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected87 ((1 : Int),(1 : Int)) hp2_2_branches87 hp2_2_evidence87 hp2_2_check87 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches87,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node86 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected86 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected86 ((1 : Int),(1 : Int)) hp2_2_branches86 hp2_2_evidence86 hp2_2_check86 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches86,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node85 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected85 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected85 ((1 : Int),(1 : Int)) hp2_2_branches85 hp2_2_evidence85 hp2_2_check85 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches85,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node84 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected84 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected84 ((3 : Int),(2 : Int)) hp2_2_branches84 hp2_2_evidence84 hp2_2_check84 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches84,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node83 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected83 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected83 ((3 : Int),(2 : Int)) hp2_2_branches83 hp2_2_evidence83 hp2_2_check83 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches83,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node82 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected82 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected82 ((3 : Int),(2 : Int)) hp2_2_branches82 hp2_2_evidence82 hp2_2_check82 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches82,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node81 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected81 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected81 ((3 : Int),(1 : Int)) hp2_2_branches81 hp2_2_evidence81 hp2_2_check81 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches81,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node82 T childKnown
  · exact hp2_2_node83 T childKnown
  · exact hp2_2_node84 T childKnown
theorem hp2_2_node80 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected80 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected80 ((1 : Int),(1 : Int)) hp2_2_branches80 hp2_2_evidence80 hp2_2_check80 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches80,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node81 T childKnown
theorem hp2_2_node79 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected79 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected79 ((0 : Int),(1 : Int)) hp2_2_branches79 hp2_2_evidence79 hp2_2_check79 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches79,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node80 T childKnown
  · exact hp2_2_node85 T childKnown
  · exact hp2_2_node86 T childKnown
  · exact hp2_2_node87 T childKnown
theorem hp2_2_node78 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected78 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected78 ((2 : Int),(1 : Int)) hp2_2_branches78 hp2_2_evidence78 hp2_2_check78 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches78,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node77 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected77 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected77 ((2 : Int),(0 : Int)) hp2_2_branches77 hp2_2_evidence77 hp2_2_check77 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches77,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node78 T childKnown
theorem hp2_2_node76 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected76 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected76 ((0 : Int),(1 : Int)) hp2_2_branches76 hp2_2_evidence76 hp2_2_check76 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches76,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node77 T childKnown
theorem hp2_2_node75 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected75 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected75 ((3 : Int),(2 : Int)) hp2_2_branches75 hp2_2_evidence75 hp2_2_check75 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches75,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node74 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected74 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected74 ((3 : Int),(2 : Int)) hp2_2_branches74 hp2_2_evidence74 hp2_2_check74 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches74,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node73 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected73 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected73 ((3 : Int),(2 : Int)) hp2_2_branches73 hp2_2_evidence73 hp2_2_check73 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches73,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node72 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected72 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected72 ((2 : Int),(2 : Int)) hp2_2_branches72 hp2_2_evidence72 hp2_2_check72 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches72,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node73 T childKnown
  · exact hp2_2_node74 T childKnown
  · exact hp2_2_node75 T childKnown
theorem hp2_2_node71 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected71 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected71 ((2 : Int),(0 : Int)) hp2_2_branches71 hp2_2_evidence71 hp2_2_check71 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches71,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node72 T childKnown
theorem hp2_2_node70 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected70 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected70 ((0 : Int),(1 : Int)) hp2_2_branches70 hp2_2_evidence70 hp2_2_check70 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches70,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node71 T childKnown
theorem hp2_2_node69 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected69 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected69 ((0 : Int),(1 : Int)) hp2_2_branches69 hp2_2_evidence69 hp2_2_check69 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches69,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node68 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected68 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected68 ((0 : Int),(1 : Int)) hp2_2_branches68 hp2_2_evidence68 hp2_2_check68 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches68,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node67 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected67 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected67 ((0 : Int),(1 : Int)) hp2_2_branches67 hp2_2_evidence67 hp2_2_check67 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches67,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node66 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected66 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected66 ((3 : Int),(1 : Int)) hp2_2_branches66 hp2_2_evidence66 hp2_2_check66 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches66,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node65 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected65 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected65 ((2 : Int),(1 : Int)) hp2_2_branches65 hp2_2_evidence65 hp2_2_check65 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches65,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node66 T childKnown
theorem hp2_2_node64 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected64 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected64 ((4 : Int),(2 : Int)) hp2_2_branches64 hp2_2_evidence64 hp2_2_check64 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches64,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node63 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected63 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected63 ((4 : Int),(2 : Int)) hp2_2_branches63 hp2_2_evidence63 hp2_2_check63 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches63,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node62 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected62 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected62 ((4 : Int),(2 : Int)) hp2_2_branches62 hp2_2_evidence62 hp2_2_check62 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches62,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node61 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected61 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected61 ((4 : Int),(1 : Int)) hp2_2_branches61 hp2_2_evidence61 hp2_2_check61 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches61,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node62 T childKnown
  · exact hp2_2_node63 T childKnown
  · exact hp2_2_node64 T childKnown
theorem hp2_2_node60 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected60 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected60 ((4 : Int),(2 : Int)) hp2_2_branches60 hp2_2_evidence60 hp2_2_check60 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches60,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node59 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected59 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected59 ((4 : Int),(2 : Int)) hp2_2_branches59 hp2_2_evidence59 hp2_2_check59 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches59,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node58 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected58 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected58 ((4 : Int),(2 : Int)) hp2_2_branches58 hp2_2_evidence58 hp2_2_check58 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches58,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node57 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected57 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected57 ((4 : Int),(1 : Int)) hp2_2_branches57 hp2_2_evidence57 hp2_2_check57 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches57,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node58 T childKnown
  · exact hp2_2_node59 T childKnown
  · exact hp2_2_node60 T childKnown
theorem hp2_2_node56 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected56 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected56 ((4 : Int),(2 : Int)) hp2_2_branches56 hp2_2_evidence56 hp2_2_check56 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches56,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node55 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected55 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected55 ((4 : Int),(2 : Int)) hp2_2_branches55 hp2_2_evidence55 hp2_2_check55 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches55,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node54 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected54 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected54 ((4 : Int),(2 : Int)) hp2_2_branches54 hp2_2_evidence54 hp2_2_check54 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches54,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node53 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected53 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected53 ((4 : Int),(1 : Int)) hp2_2_branches53 hp2_2_evidence53 hp2_2_check53 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches53,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node54 T childKnown
  · exact hp2_2_node55 T childKnown
  · exact hp2_2_node56 T childKnown
theorem hp2_2_node52 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected52 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected52 ((0 : Int),(2 : Int)) hp2_2_branches52 hp2_2_evidence52 hp2_2_check52 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches52,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node53 T childKnown
  · exact hp2_2_node57 T childKnown
  · exact hp2_2_node61 T childKnown
theorem hp2_2_node51 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected51 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected51 ((2 : Int),(1 : Int)) hp2_2_branches51 hp2_2_evidence51 hp2_2_check51 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches51,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node52 T childKnown
theorem hp2_2_node50 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected50 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected50 ((3 : Int),(1 : Int)) hp2_2_branches50 hp2_2_evidence50 hp2_2_check50 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches50,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node49 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected49 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected49 ((3 : Int),(0 : Int)) hp2_2_branches49 hp2_2_evidence49 hp2_2_check49 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches49,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node50 T childKnown
theorem hp2_2_node48 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected48 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected48 ((4 : Int),(2 : Int)) hp2_2_branches48 hp2_2_evidence48 hp2_2_check48 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches48,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node47 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected47 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected47 ((4 : Int),(2 : Int)) hp2_2_branches47 hp2_2_evidence47 hp2_2_check47 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches47,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node46 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected46 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected46 ((3 : Int),(2 : Int)) hp2_2_branches46 hp2_2_evidence46 hp2_2_check46 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches46,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node47 T childKnown
  · exact hp2_2_node48 T childKnown
theorem hp2_2_node45 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected45 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected45 ((4 : Int),(2 : Int)) hp2_2_branches45 hp2_2_evidence45 hp2_2_check45 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches45,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node44 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected44 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected44 ((4 : Int),(2 : Int)) hp2_2_branches44 hp2_2_evidence44 hp2_2_check44 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches44,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node43 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected43 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected43 ((3 : Int),(2 : Int)) hp2_2_branches43 hp2_2_evidence43 hp2_2_check43 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches43,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node44 T childKnown
  · exact hp2_2_node45 T childKnown
theorem hp2_2_node42 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected42 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected42 ((4 : Int),(2 : Int)) hp2_2_branches42 hp2_2_evidence42 hp2_2_check42 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches42,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node41 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected41 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected41 ((4 : Int),(2 : Int)) hp2_2_branches41 hp2_2_evidence41 hp2_2_check41 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches41,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node40 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected40 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected40 ((4 : Int),(2 : Int)) hp2_2_branches40 hp2_2_evidence40 hp2_2_check40 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches40,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node39 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected39 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected39 ((3 : Int),(2 : Int)) hp2_2_branches39 hp2_2_evidence39 hp2_2_check39 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches39,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node40 T childKnown
  · exact hp2_2_node41 T childKnown
  · exact hp2_2_node42 T childKnown
theorem hp2_2_node38 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected38 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected38 ((4 : Int),(2 : Int)) hp2_2_branches38 hp2_2_evidence38 hp2_2_check38 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches38,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node37 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected37 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected37 ((4 : Int),(2 : Int)) hp2_2_branches37 hp2_2_evidence37 hp2_2_check37 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches37,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node36 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected36 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected36 ((4 : Int),(2 : Int)) hp2_2_branches36 hp2_2_evidence36 hp2_2_check36 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches36,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node35 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected35 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected35 ((4 : Int),(2 : Int)) hp2_2_branches35 hp2_2_evidence35 hp2_2_check35 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches35,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node34 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected34 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected34 ((6 : Int),(2 : Int)) hp2_2_branches34 hp2_2_evidence34 hp2_2_check34 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches34,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node33 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected33 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected33 ((6 : Int),(2 : Int)) hp2_2_branches33 hp2_2_evidence33 hp2_2_check33 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches33,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node32 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected32 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected32 ((6 : Int),(2 : Int)) hp2_2_branches32 hp2_2_evidence32 hp2_2_check32 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches32,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node31 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected31 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected31 ((7 : Int),(1 : Int)) hp2_2_branches31 hp2_2_evidence31 hp2_2_check31 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches31,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node30 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected30 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected30 ((7 : Int),(1 : Int)) hp2_2_branches30 hp2_2_evidence30 hp2_2_check30 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches30,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node29 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected29 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected29 ((7 : Int),(0 : Int)) hp2_2_branches29 hp2_2_evidence29 hp2_2_check29 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches29,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node30 T childKnown
  · exact hp2_2_node31 T childKnown
theorem hp2_2_node28 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected28 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected28 ((6 : Int),(1 : Int)) hp2_2_branches28 hp2_2_evidence28 hp2_2_check28 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches28,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node29 T childKnown
  · exact hp2_2_node32 T childKnown
  · exact hp2_2_node33 T childKnown
  · exact hp2_2_node34 T childKnown
theorem hp2_2_node27 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected27 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected27 ((6 : Int),(2 : Int)) hp2_2_branches27 hp2_2_evidence27 hp2_2_check27 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches27,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node26 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected26 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected26 ((6 : Int),(2 : Int)) hp2_2_branches26 hp2_2_evidence26 hp2_2_check26 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches26,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node25 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected25 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected25 ((6 : Int),(2 : Int)) hp2_2_branches25 hp2_2_evidence25 hp2_2_check25 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches25,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node24 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected24 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected24 ((6 : Int),(1 : Int)) hp2_2_branches24 hp2_2_evidence24 hp2_2_check24 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches24,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node25 T childKnown
  · exact hp2_2_node26 T childKnown
  · exact hp2_2_node27 T childKnown
theorem hp2_2_node23 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected23 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected23 ((4 : Int),(2 : Int)) hp2_2_branches23 hp2_2_evidence23 hp2_2_check23 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches23,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node24 T childKnown
  · exact hp2_2_node28 T childKnown
theorem hp2_2_node22 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected22 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected22 ((3 : Int),(2 : Int)) hp2_2_branches22 hp2_2_evidence22 hp2_2_check22 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches22,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node23 T childKnown
  · exact hp2_2_node35 T childKnown
  · exact hp2_2_node36 T childKnown
  · exact hp2_2_node37 T childKnown
  · exact hp2_2_node38 T childKnown
theorem hp2_2_node21 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected21 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected21 ((4 : Int),(2 : Int)) hp2_2_branches21 hp2_2_evidence21 hp2_2_check21 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches21,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node20 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected20 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected20 ((4 : Int),(2 : Int)) hp2_2_branches20 hp2_2_evidence20 hp2_2_check20 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches20,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node19 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected19 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected19 ((4 : Int),(2 : Int)) hp2_2_branches19 hp2_2_evidence19 hp2_2_check19 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches19,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node18 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected18 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected18 ((4 : Int),(2 : Int)) hp2_2_branches18 hp2_2_evidence18 hp2_2_check18 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches18,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node17 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected17 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected17 ((6 : Int),(2 : Int)) hp2_2_branches17 hp2_2_evidence17 hp2_2_check17 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches17,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node16 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected16 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected16 ((6 : Int),(2 : Int)) hp2_2_branches16 hp2_2_evidence16 hp2_2_check16 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches16,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node15 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected15 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected15 ((6 : Int),(2 : Int)) hp2_2_branches15 hp2_2_evidence15 hp2_2_check15 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches15,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node14 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected14 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected14 ((7 : Int),(1 : Int)) hp2_2_branches14 hp2_2_evidence14 hp2_2_check14 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches14,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node13 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected13 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected13 ((7 : Int),(1 : Int)) hp2_2_branches13 hp2_2_evidence13 hp2_2_check13 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches13,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node12 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected12 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected12 ((7 : Int),(0 : Int)) hp2_2_branches12 hp2_2_evidence12 hp2_2_check12 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches12,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node13 T childKnown
  · exact hp2_2_node14 T childKnown
theorem hp2_2_node11 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected11 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected11 ((6 : Int),(1 : Int)) hp2_2_branches11 hp2_2_evidence11 hp2_2_check11 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches11,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node12 T childKnown
  · exact hp2_2_node15 T childKnown
  · exact hp2_2_node16 T childKnown
  · exact hp2_2_node17 T childKnown
theorem hp2_2_node10 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected10 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected10 ((6 : Int),(2 : Int)) hp2_2_branches10 hp2_2_evidence10 hp2_2_check10 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches10,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node9 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected9 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected9 ((6 : Int),(2 : Int)) hp2_2_branches9 hp2_2_evidence9 hp2_2_check9 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches9,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node8 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected8 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected8 ((6 : Int),(2 : Int)) hp2_2_branches8 hp2_2_evidence8 hp2_2_check8 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches8,List.mem_cons,List.not_mem_nil,or_false] at member
theorem hp2_2_node7 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected7 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected7 ((6 : Int),(1 : Int)) hp2_2_branches7 hp2_2_evidence7 hp2_2_check7 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches7,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl
  · exact hp2_2_node8 T childKnown
  · exact hp2_2_node9 T childKnown
  · exact hp2_2_node10 T childKnown
theorem hp2_2_node6 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected6 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected6 ((4 : Int),(2 : Int)) hp2_2_branches6 hp2_2_evidence6 hp2_2_check6 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches6,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl
  · exact hp2_2_node7 T childKnown
  · exact hp2_2_node11 T childKnown
theorem hp2_2_node5 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected5 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected5 ((3 : Int),(2 : Int)) hp2_2_branches5 hp2_2_evidence5 hp2_2_check5 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches5,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node6 T childKnown
  · exact hp2_2_node18 T childKnown
  · exact hp2_2_node19 T childKnown
  · exact hp2_2_node20 T childKnown
  · exact hp2_2_node21 T childKnown
theorem hp2_2_node4 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected4 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected4 ((0 : Int),(2 : Int)) hp2_2_branches4 hp2_2_evidence4 hp2_2_check4 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches4,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node5 T childKnown
  · exact hp2_2_node22 T childKnown
  · exact hp2_2_node39 T childKnown
  · exact hp2_2_node43 T childKnown
  · exact hp2_2_node46 T childKnown
theorem hp2_2_node3 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected3 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected3 ((3 : Int),(0 : Int)) hp2_2_branches3 hp2_2_evidence3 hp2_2_check3 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches3,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl
  · exact hp2_2_node4 T childKnown
theorem hp2_2_node2 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected2 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected2 ((2 : Int),(0 : Int)) hp2_2_branches2 hp2_2_evidence2 hp2_2_check2 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches2,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact hp2_2_node3 T childKnown
  · exact hp2_2_node49 T childKnown
  · exact hp2_2_node51 T childKnown
  · exact hp2_2_node65 T childKnown
theorem hp2_2_node1 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected1 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected1 ((1 : Int),(0 : Int)) hp2_2_branches1 hp2_2_evidence1 hp2_2_check1 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches1,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node2 T childKnown
  · exact hp2_2_node67 T childKnown
  · exact hp2_2_node68 T childKnown
  · exact hp2_2_node69 T childKnown
  · exact hp2_2_node70 T childKnown
  · exact hp2_2_node76 T childKnown
  · exact hp2_2_node79 T childKnown
  · exact hp2_2_node88 T childKnown
theorem hp2_2_node0 (T : Tiling (2 : Int) (2 : Int) 1 0 HalfPlane)
    (known : ∀ s, s∈hp2_2_selected0 → T.world s) : False := by
  apply replay_step (2 : Int) (2 : Int) (by decide) (by decide) T hp2_2_selected0 ((0 : Int),(0 : Int)) hp2_2_branches0 hp2_2_evidence0 hp2_2_check0 ?_ known
  intro t member childKnown
  simp only [hp2_2_branches0,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact hp2_2_node1 T childKnown
  · exact hp2_2_node111 T childKnown
  · exact hp2_2_node136 T childKnown
  · exact hp2_2_node206 T childKnown
  · exact hp2_2_node231 T childKnown
  · exact hp2_2_node259 T childKnown
  · exact hp2_2_node287 T childKnown
  · exact hp2_2_node290 T childKnown
  · exact hp2_2_node360 T childKnown
  · exact hp2_2_node385 T childKnown
  · exact hp2_2_node387 T childKnown
  · exact hp2_2_node405 T childKnown
  · exact hp2_2_node407 T childKnown
  · exact hp2_2_node668 T childKnown

theorem hp2_2_no_half_plane : ¬Tiles (2 : Int) (2 : Int) 1 0 HalfPlane := by
  rintro ⟨T⟩
  exact hp2_2_node0 T (by simp [hp2_2_selected0])
#print axioms hp2_2_no_half_plane

end THalfPlaneFinite

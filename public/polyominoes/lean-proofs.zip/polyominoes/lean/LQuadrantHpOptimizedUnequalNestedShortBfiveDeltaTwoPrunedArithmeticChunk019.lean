import LQuadrantHpOptimizedUnequalNestedShortBfiveDeltaTwoPrunedArithmeticDefs
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace LRegionArithmetic

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n531_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≥ ((-1 : Int) * a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n531_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-1 : Int) * a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n531_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n531_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_4057 a b) ∨ (fact_9fdb227ae99d_4085 a b) ∨ (fact_9fdb227ae99d_5291 a b) ∨ (fact_9fdb227ae99d_5906 a b) ∨ (fact_9fdb227ae99d_4722 a b) ∨ (fact_9fdb227ae99d_4199 a b) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6155 a b))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n531_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3413 a b) ∨ (fact_9fdb227ae99d_3431 a b) ∨ (fact_9fdb227ae99d_4506 a b) ∨ (fact_9fdb227ae99d_5590 a b) ∨ (fact_9fdb227ae99d_3878 a b) ∨ (fact_9fdb227ae99d_3497 a b) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5724 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n531_run_tall (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (a > b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (¬ ((((-3 : Int) ≥ (((-1 : Int) * a) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7501 a b) ∨ (fact_9fdb227ae99d_7424 a b))) ∨ (((-3 : Int) ≥ (((-1 : Int) * a) + (2 : Int))) ∧ (fact_9fdb227ae99d_7501 a b) ∧ (fact_9fdb227ae99d_7424 a b)) ∨ ((-3 : Int) ≥ (((-1 : Int) * a) + (4 : Int))) ∨ (((-3 : Int) = (((-1 : Int) * a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7501 a b) ∧ (fact_9fdb227ae99d_7424 a b) ∧ (((fact_9fdb227ae99d_4951 a b) ∨ (fact_9fdb227ae99d_4968 a b) ∨ (fact_9fdb227ae99d_5732 a b) ∨ (fact_9fdb227ae99d_6478 a b) ∨ (fact_9fdb227ae99d_5473 a b) ∨ (fact_9fdb227ae99d_5045 a b) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6669 a b)) ∨ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (fact_9fdb227ae99d_4205 a b) ∨ (fact_9fdb227ae99d_5071 a b) ∨ (fact_9fdb227ae99d_6147 a b) ∨ (fact_9fdb227ae99d_6158 a b)))) ∨ ((fact_9fdb227ae99d_7501 a b) ∧ (fact_9fdb227ae99d_7424 a b) ∧ ((fact_9fdb227ae99d_4951 a b) ∨ (fact_9fdb227ae99d_4968 a b) ∨ (fact_9fdb227ae99d_5732 a b) ∨ (fact_9fdb227ae99d_6478 a b) ∨ (fact_9fdb227ae99d_5473 a b) ∨ (fact_9fdb227ae99d_5045 a b) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((3 : Int) + a)) ∧ ((1 : Int) ≥ ((3 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) + a)) ∧ (((3 : Int) + a) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6669 a b)) ∧ ((fact_9fdb227ae99d_4067 a b) ∨ (fact_9fdb227ae99d_4095 a b) ∨ (fact_9fdb227ae99d_5301 a b) ∨ (fact_9fdb227ae99d_5916 a b) ∨ (fact_9fdb227ae99d_4730 a b) ∨ (fact_9fdb227ae99d_4205 a b) ∨ (fact_9fdb227ae99d_5071 a b) ∨ (fact_9fdb227ae99d_6147 a b) ∨ (fact_9fdb227ae99d_6158 a b))))))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n531_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (((-1 : Int) * a) ≤ run_x))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_3000 a b run_x) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3611 a b run_x)))
    (h7 : ((-3 : Int) ≥ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n531_run_floor (a b run_x : Int)
    (h0 : ((-3 : Int) ≥ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3573 a b run_x) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5355 a b run_x))))
    (h2 : (((-1 : Int) * a) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n532_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((1 : Int) ≤ b)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n532_run_short (a b : Int)
    (h0 : (¬ ((b - (1 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n532_run_nonnegative (a b : Int)
    (h0 : (¬ ((1 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n532_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n532_run_right (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((0 : Int) ≤ (-(4 : Int))) ∧ ((0 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ (((1 : Int) ≤ (-(4 : Int))) ∧ ((1 : Int) ≥ (-(4 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (b + (1 : Int))) ∧ ((1 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (b + (1 : Int))) ∧ ((2 : Int) ≥ (b + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(4 : Int))) ∧ ((-1 : Int) ≥ (-(4 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ (((1 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n532_run_tall (a b : Int)
    (h0 : (¬ (((((1 : Int) + (3 : Int)) ≤ b) ∧ ((fact_9fdb227ae99d_7326 a b) ∨ (fact_9fdb227ae99d_7270 a b))) ∨ ((((1 : Int) + (2 : Int)) ≤ b) ∧ (fact_9fdb227ae99d_7326 a b) ∧ (fact_9fdb227ae99d_7270 a b)) ∨ (((1 : Int) + (4 : Int)) ≤ b) ∨ ((b = ((1 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7326 a b) ∧ (fact_9fdb227ae99d_7270 a b) ∧ (((fact_9fdb227ae99d_4344 a b) ∨ (fact_9fdb227ae99d_4361 a b) ∨ (fact_9fdb227ae99d_5454 a b) ∨ (fact_9fdb227ae99d_6177 a b) ∨ (fact_9fdb227ae99d_5112 a b) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5218 a b) ∨ (fact_9fdb227ae99d_5229 a b)) ∨ ((fact_9fdb227ae99d_3421 a b) ∨ (fact_9fdb227ae99d_3439 a b) ∨ (fact_9fdb227ae99d_4514 a b) ∨ (fact_9fdb227ae99d_5598 a b) ∨ (fact_9fdb227ae99d_3886 a b) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_4276 a b) ∨ (fact_9fdb227ae99d_4291 a b)))) ∨ ((fact_9fdb227ae99d_7326 a b) ∧ (fact_9fdb227ae99d_7270 a b) ∧ ((fact_9fdb227ae99d_4344 a b) ∨ (fact_9fdb227ae99d_4361 a b) ∨ (fact_9fdb227ae99d_5454 a b) ∨ (fact_9fdb227ae99d_6177 a b) ∨ (fact_9fdb227ae99d_5112 a b) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((1 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((1 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((1 : Int) - (1 : Int))) ∧ (((1 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5218 a b) ∨ (fact_9fdb227ae99d_5229 a b)) ∧ ((fact_9fdb227ae99d_3421 a b) ∨ (fact_9fdb227ae99d_3439 a b) ∨ (fact_9fdb227ae99d_4514 a b) ∨ (fact_9fdb227ae99d_5598 a b) ∨ (fact_9fdb227ae99d_3886 a b) ∨ (((((-1 : Int) - a) ≤ (-((4 : Int) + a))) ∧ ((-((4 : Int) + a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (b + (1 : Int))) ∧ ((0 : Int) ≥ (b + (1 : Int)))) ∨ (((-1 : Int) ≤ (-((4 : Int) + a))) ∧ ((-1 : Int) ≥ (-((4 : Int) + a))) ∧ (((0 : Int) - (0 : Int)) ≤ (b + (1 : Int))) ∧ ((b + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_4276 a b) ∨ (fact_9fdb227ae99d_4291 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n532_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h2 : ((((2 : Int) + a) < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + b) < ((1 : Int) + b)) ∨ (((1 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((1 : Int) ≤ run_x))
    (h5 : (((-3 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-3 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < (((1 : Int) + b) - b)) ∨ ((1 : Int) > (((1 : Int) + b) + (0 : Int)))))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((fact_9fdb227ae99d_2588 a b run_x) ∨ (fact_9fdb227ae99d_2593 a b run_x) ∨ (fact_9fdb227ae99d_3154 a b run_x) ∨ (fact_9fdb227ae99d_3674 a b run_x) ∨ (fact_9fdb227ae99d_3032 a b run_x) ∨ (fact_9fdb227ae99d_2694 a b run_x) ∨ (((((-2 : Int) - b) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(4 : Int))) ∧ ((-2 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(4 : Int))) ∧ ((-(4 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-(4 : Int))) ∧ ((-3 : Int) ≥ (-(4 : Int))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int)))))))
    (h8 : (run_x ≤ b))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n532_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ b))
    (h1 : ((1 : Int) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3321 a b run_x) ∨ (fact_9fdb227ae99d_3325 a b run_x) ∨ (fact_9fdb227ae99d_4336 a b run_x) ∨ (fact_9fdb227ae99d_5470 a b run_x) ∨ (fact_9fdb227ae99d_3678 a b run_x) ∨ (fact_9fdb227ae99d_3353 a b run_x) ∨ (((((-2 : Int) - b) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-2 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-((4 : Int) - (1 : Int))) ≤ ((-3 : Int) + (0 : Int))) ∧ (((1 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-((4 : Int) - (1 : Int)))) ∧ ((-3 : Int) ≥ (-((4 : Int) - (1 : Int)))) ∧ ((((1 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + b) + (0 : Int))))))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((fact_9fdb227ae99d_2817 a b) ∨ (fact_9fdb227ae99d_2818 a b) ∨ (fact_9fdb227ae99d_3202 a b) ∨ (fact_9fdb227ae99d_3848 a b) ∨ (fact_9fdb227ae99d_3060 a b) ∨ (fact_9fdb227ae99d_2894 a b) ∨ ((((2 : Int) ≥ ((-2 : Int) - b)) ∧ ((2 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((2 : Int) ≥ ((-3 : Int) - a)) ∧ ((2 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b = (5 : Int)))
    (h3 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_o1 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_o2 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_o3 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (¬ (((jx = ((2 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h8 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_o6 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (¬ ((((2 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n533_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2819 a b) ∨ (fact_9fdb227ae99d_2821 a b) ∨ (fact_9fdb227ae99d_3203 a b) ∨ (fact_9fdb227ae99d_3849 a b) ∨ (fact_9fdb227ae99d_3065 a b) ∨ (fact_9fdb227ae99d_2898 a b) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3069 a b)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h2 : (b = (5 : Int)))
    (h3 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_o3 (a b jx jy : Int)
    (h0 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h1 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b = (5 : Int)))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_o6 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h2 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n534_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n535_run_four (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n535_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n535_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n535_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3364 a b) ∨ (fact_9fdb227ae99d_3371 a b) ∨ (fact_9fdb227ae99d_4406 a b) ∨ (fact_9fdb227ae99d_5545 a b) ∨ (fact_9fdb227ae99d_3734 a b) ∨ (fact_9fdb227ae99d_3391 a b) ∨ (((((-2 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3816 a b) ∨ (fact_9fdb227ae99d_3739 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n535_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3751 a b) ∨ (fact_9fdb227ae99d_3783 a b) ∨ (fact_9fdb227ae99d_5161 a b) ∨ (fact_9fdb227ae99d_5839 a b) ∨ (fact_9fdb227ae99d_4534 a b) ∨ (fact_9fdb227ae99d_3899 a b) ∨ (((((-2 : Int) - b) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-2 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((2 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4643 a b) ∨ (fact_9fdb227ae99d_4557 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n535_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7491 a b) ∨ (fact_9fdb227ae99d_7606 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7491 a b) ∧ (fact_9fdb227ae99d_7606 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7491 a b) ∧ (fact_9fdb227ae99d_7606 a b) ∧ (((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_4840 a b) ∨ (fact_9fdb227ae99d_4001 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∨ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_5490 a b) ∨ (fact_9fdb227ae99d_4862 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b)))) ∨ ((fact_9fdb227ae99d_7491 a b) ∧ (fact_9fdb227ae99d_7606 a b) ∧ ((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_4840 a b) ∨ (fact_9fdb227ae99d_4001 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∧ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_5490 a b) ∨ (fact_9fdb227ae99d_4862 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n535_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_3001 a b run_x) ∨ (fact_9fdb227ae99d_2482 a b run_x) ∨ (fact_9fdb227ae99d_2944 a b run_x) ∨ (fact_9fdb227ae99d_2931 a b run_x)))
    (h3 : (run_x ≤ ((2 : Int) + b)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n535_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3574 a b run_x) ∨ (fact_9fdb227ae99d_3243 a b run_x) ∨ (fact_9fdb227ae99d_3551 a b run_x) ∨ (fact_9fdb227ae99d_3493 a b run_x))))
    (h2 : (run_x ≤ ((2 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n536_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n536_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n536_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n536_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3366 a b) ∨ (fact_9fdb227ae99d_3373 a b) ∨ (fact_9fdb227ae99d_4408 a b) ∨ (fact_9fdb227ae99d_5547 a b) ∨ (fact_9fdb227ae99d_3736 a b) ∨ (fact_9fdb227ae99d_3393 a b) ∨ (((((-2 : Int) - b) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((4 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((4 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3825 a b) ∨ (fact_9fdb227ae99d_3833 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n536_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3748 a b) ∨ (fact_9fdb227ae99d_3780 a b) ∨ (fact_9fdb227ae99d_5158 a b) ∨ (fact_9fdb227ae99d_5836 a b) ∨ (fact_9fdb227ae99d_4531 a b) ∨ (fact_9fdb227ae99d_3896 a b) ∨ (((((-2 : Int) - b) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-2 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4639 a b) ∨ (fact_9fdb227ae99d_4674 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n536_run_tall (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7496 a b) ∨ (fact_9fdb227ae99d_7601 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7496 a b) ∧ (fact_9fdb227ae99d_7601 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7496 a b) ∧ (fact_9fdb227ae99d_7601 a b) ∧ (((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_4846 a b) ∨ (fact_9fdb227ae99d_4009 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∨ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_5486 a b) ∨ (fact_9fdb227ae99d_4852 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b)))) ∨ ((fact_9fdb227ae99d_7496 a b) ∧ (fact_9fdb227ae99d_7601 a b) ∧ ((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_4846 a b) ∨ (fact_9fdb227ae99d_4009 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∧ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_5486 a b) ∨ (fact_9fdb227ae99d_4852 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b))))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n536_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_3000 a b run_x) ∨ (fact_9fdb227ae99d_2481 a b run_x) ∨ (fact_9fdb227ae99d_2943 a b run_x) ∨ (fact_9fdb227ae99d_2947 a b run_x)))
    (h3 : (run_x ≤ ((1 : Int) + a)))
    (h4 : (b = (5 : Int)))
    (h5 : ((4 : Int) ≤ run_x))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n536_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3573 a b run_x) ∨ (fact_9fdb227ae99d_3242 a b run_x) ∨ (fact_9fdb227ae99d_3550 a b run_x) ∨ (fact_9fdb227ae99d_3558 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n537_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n537_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n537_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n537_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3363 a b) ∨ (fact_9fdb227ae99d_3370 a b) ∨ (fact_9fdb227ae99d_4405 a b) ∨ (fact_9fdb227ae99d_5544 a b) ∨ (fact_9fdb227ae99d_3733 a b) ∨ (fact_9fdb227ae99d_3390 a b) ∨ (((((-2 : Int) - b) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((2 : Int) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3738 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n537_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3750 a b) ∨ (fact_9fdb227ae99d_3782 a b) ∨ (fact_9fdb227ae99d_5160 a b) ∨ (fact_9fdb227ae99d_5838 a b) ∨ (fact_9fdb227ae99d_4533 a b) ∨ (fact_9fdb227ae99d_3898 a b) ∨ (((((-2 : Int) - b) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((-2 : Int) ≥ (((1 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((-3 : Int) ≥ (((1 : Int) + b) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4552 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n537_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_9fdb227ae99d_7375 a b) ∨ (fact_9fdb227ae99d_7443 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_9fdb227ae99d_7375 a b) ∧ (fact_9fdb227ae99d_7443 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7375 a b) ∧ (fact_9fdb227ae99d_7443 a b) ∧ (((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_4836 a b) ∨ (fact_9fdb227ae99d_3993 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∨ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_5488 a b) ∨ (fact_9fdb227ae99d_4858 a b) ∨ (fact_9fdb227ae99d_5393 a b)))) ∨ ((fact_9fdb227ae99d_7375 a b) ∧ (fact_9fdb227ae99d_7443 a b) ∧ ((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_4836 a b) ∨ (fact_9fdb227ae99d_3993 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∧ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_5488 a b) ∨ (fact_9fdb227ae99d_4858 a b) ∨ (fact_9fdb227ae99d_5393 a b))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n537_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : ((2 : Int) ≤ run_x))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_3001 a b run_x) ∨ (fact_9fdb227ae99d_2482 a b run_x) ∨ (fact_9fdb227ae99d_2930 a b run_x)))
    (h4 : (run_x ≤ ((1 : Int) + b)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n537_run_floor (a b run_x : Int)
    (h0 : ((2 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3574 a b run_x) ∨ (fact_9fdb227ae99d_3243 a b run_x) ∨ (fact_9fdb227ae99d_3492 a b run_x))))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (fact_9fdb227ae99d_29 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3379 a b) ∨ ((((-1 : Int) ≥ ((-3 : Int) - a)) ∧ ((-1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≥ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-3 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3332 a b)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + b) < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < (jy - (0 : Int)))))
    (h3 : (b = (5 : Int)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h8 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_o1 (a b jx jy : Int)
    (h0 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h2 : ((jx < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : (b = (5 : Int)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h8 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h9 : (a = (b + (2 : Int))))
    (h10 : (b ≥ (3 : Int)))
    (h11 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_o3 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_o6 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h6 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n538_o7 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h7 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : ((jy - b) ≥ (0 : Int)))
    (h9 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h10 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_point (a b : Int)
    (h0 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_empty (a b : Int)
    (h0 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((fact_9fdb227ae99d_2874 a b) ∨ (fact_9fdb227ae99d_2877 a b) ∨ (fact_9fdb227ae99d_3263 a b) ∨ (fact_9fdb227ae99d_4170 a b) ∨ (fact_9fdb227ae99d_3105 a b) ∨ ((((-4 : Int) ≥ ((-1 : Int) - a)) ∧ ((-4 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-1 : Int)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-4 : Int) ≥ ((-2 : Int) - b)) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - a)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2880 a b)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_o0 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h3 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h6 : (b = (5 : Int)))
    (h7 : (fact_9fdb227ae99d_2923 a b jy))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_o2 (a b jx jy : Int)
    (h0 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h1 : (¬ ((((-4 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (a ≥ (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + a)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h7 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_2922 a b jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_o5 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jx < ((-3 : Int) - a)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h4 : (¬ ((((-4 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_o6 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + b)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h2 : (b = (5 : Int)))
    (h3 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h4 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a > b))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n539_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_point (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ (((-4 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_empty (a b : Int)
    (h0 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h1 : ((fact_9fdb227ae99d_2875 a b) ∨ (fact_9fdb227ae99d_2878 a b) ∨ (fact_9fdb227ae99d_3264 a b) ∨ (fact_9fdb227ae99d_4171 a b) ∨ (fact_9fdb227ae99d_3106 a b) ∨ (fact_9fdb227ae99d_2964 a b) ∨ ((((-4 : Int) ≥ ((-2 : Int) - b)) ∧ ((-4 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((-4 : Int) ≥ ((-3 : Int) - a)) ∧ ((-4 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (-4 : Int)) ∧ ((-4 : Int) ≤ (-3 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2881 a b) ∨ (fact_9fdb227ae99d_4397 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (((((2 : Int) + a) + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((-1 : Int) > (jx + a)) ∨ ((-1 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h6 : (((-3 : Int) > (jx + a)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_o1 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_2923 a b jy))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_o2 (a b jx jy : Int)
    (h0 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (((jx + (0 : Int)) < ((-4 : Int) + ((-1 : Int) * a))) ∨ (((-4 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - b))))
    (h7 : ((jy - b) ≥ (0 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_o3 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + a) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h7 : (b = (5 : Int)))
    (h8 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : ((((-4 : Int) ≥ (jx - b)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (fact_9fdb227ae99d_2922 a b jy))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jx < ((-2 : Int) - b)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((1 : Int) + a)) ∨ (((1 : Int) + a) < (jy - (0 : Int)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : ((((-4 : Int) ≥ (jx - a)) ∧ ((-4 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h8 : ((jx < (((-4 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-4 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_o6 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + b)) ∨ ((-3 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (¬ (((jx = ((-4 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n540_o7 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < (((1 : Int) + a) - a)) ∨ ((((1 : Int) + a) + (0 : Int)) < jy)))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((((-4 : Int) ≥ (jx - (0 : Int))) ∧ ((-4 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-4 : Int) ≥ jx) ∧ ((-4 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n541_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n541_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n541_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n541_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5687 a b) ∨ (fact_9fdb227ae99d_5700 a b) ∨ (fact_9fdb227ae99d_6368 a b) ∨ (fact_9fdb227ae99d_6964 a b) ∨ (fact_9fdb227ae99d_5994 a b) ∨ (fact_9fdb227ae99d_5757 a b) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5707 a b) ∨ (fact_9fdb227ae99d_6981 a b) ∨ (fact_9fdb227ae99d_6986 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n541_run_right (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3416 a b) ∨ (fact_9fdb227ae99d_3434 a b) ∨ (fact_9fdb227ae99d_4509 a b) ∨ (fact_9fdb227ae99d_5593 a b) ∨ (fact_9fdb227ae99d_3881 a b) ∨ (fact_9fdb227ae99d_3498 a b) ∨ (((((-2 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) + a)) ∧ ((4 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((4 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((4 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3448 a b) ∨ (fact_9fdb227ae99d_5726 a b) ∨ (fact_9fdb227ae99d_5729 a b))))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n541_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7897 a b) ∨ (fact_9fdb227ae99d_7675 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7897 a b) ∧ (fact_9fdb227ae99d_7675 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7897 a b) ∧ (fact_9fdb227ae99d_7675 a b) ∧ (((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6214 a b) ∨ (fact_9fdb227ae99d_6707 a b) ∨ (fact_9fdb227ae99d_6293 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_7099 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∨ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4212 a b) ∨ (fact_9fdb227ae99d_5077 a b) ∨ (fact_9fdb227ae99d_4284 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_6162 a b) ∨ (fact_9fdb227ae99d_6168 a b)))) ∨ ((fact_9fdb227ae99d_7897 a b) ∧ (fact_9fdb227ae99d_7675 a b) ∧ ((fact_9fdb227ae99d_6035 a b) ∨ (fact_9fdb227ae99d_6073 a b) ∨ (fact_9fdb227ae99d_6835 a b) ∨ (fact_9fdb227ae99d_7047 a b) ∨ (fact_9fdb227ae99d_6601 a b) ∨ (fact_9fdb227ae99d_6214 a b) ∨ (fact_9fdb227ae99d_6707 a b) ∨ (fact_9fdb227ae99d_6293 a b) ∨ (fact_9fdb227ae99d_6097 a b) ∨ (fact_9fdb227ae99d_7099 a b) ∨ (fact_9fdb227ae99d_7111 a b)) ∧ ((fact_9fdb227ae99d_4075 a b) ∨ (fact_9fdb227ae99d_4103 a b) ∨ (fact_9fdb227ae99d_5309 a b) ∨ (fact_9fdb227ae99d_5924 a b) ∨ (fact_9fdb227ae99d_4738 a b) ∨ (fact_9fdb227ae99d_4212 a b) ∨ (fact_9fdb227ae99d_5077 a b) ∨ (fact_9fdb227ae99d_4284 a b) ∨ (fact_9fdb227ae99d_4117 a b) ∨ (fact_9fdb227ae99d_6162 a b) ∨ (fact_9fdb227ae99d_6168 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n541_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : ((-4 : Int) ≥ run_x))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_3001 a b run_x) ∨ (fact_9fdb227ae99d_2482 a b run_x) ∨ (fact_9fdb227ae99d_2398 a b run_x) ∨ (fact_9fdb227ae99d_3613 a b run_x) ∨ (fact_9fdb227ae99d_3616 a b run_x)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n541_run_floor (a b run_x : Int)
    (h0 : ((-4 : Int) ≥ run_x))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3574 a b run_x) ∨ (fact_9fdb227ae99d_3243 a b run_x) ∨ (fact_9fdb227ae99d_3197 a b run_x) ∨ (fact_9fdb227ae99d_5360 a b run_x) ∨ (fact_9fdb227ae99d_5363 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n542_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((-1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n542_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((-1 : Int) + a) - (2 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n542_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n542_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3583 a b) ∨ (fact_9fdb227ae99d_3587 a b) ∨ (fact_9fdb227ae99d_4720 a b) ∨ (fact_9fdb227ae99d_5750 a b) ∨ (fact_9fdb227ae99d_4339 a b) ∨ (((((-1 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ (-(5 : Int))) ∧ ((-1 : Int) ≥ (-(5 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3589 a b) ∨ (fact_9fdb227ae99d_4484 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n542_run_right (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((fact_9fdb227ae99d_4487 a b) ∨ (fact_9fdb227ae99d_4489 a b) ∨ (fact_9fdb227ae99d_5543 a b) ∨ (fact_9fdb227ae99d_6324 a b) ∨ (fact_9fdb227ae99d_5199 a b) ∨ (((((-1 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-1 : Int) ≤ (-(5 : Int))) ∧ ((-1 : Int) ≥ (-(5 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (((-1 : Int) + a) + (1 : Int))) ∧ ((((-1 : Int) + a) + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_4490 a b) ∨ (fact_9fdb227ae99d_5340 a b))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n542_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((-1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7546 a b) ∨ (fact_9fdb227ae99d_7644 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((-1 : Int) + a)) ∧ (fact_9fdb227ae99d_7546 a b) ∧ (fact_9fdb227ae99d_7644 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((-1 : Int) + a)) ∨ ((((-1 : Int) + a) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7546 a b) ∧ (fact_9fdb227ae99d_7644 a b) ∧ (((fact_9fdb227ae99d_4350 a b) ∨ (fact_9fdb227ae99d_4367 a b) ∨ (fact_9fdb227ae99d_5460 a b) ∨ (fact_9fdb227ae99d_6183 a b) ∨ (fact_9fdb227ae99d_5118 a b) ∨ (fact_9fdb227ae99d_4423 a b) ∨ (fact_9fdb227ae99d_5221 a b) ∨ (fact_9fdb227ae99d_4467 a b) ∨ (fact_9fdb227ae99d_4377 a b) ∨ (fact_9fdb227ae99d_5249 a b)) ∨ ((fact_9fdb227ae99d_5267 a b) ∨ (fact_9fdb227ae99d_5276 a b) ∨ (fact_9fdb227ae99d_5834 a b) ∨ (fact_9fdb227ae99d_6767 a b) ∨ (fact_9fdb227ae99d_5668 a b) ∨ (fact_9fdb227ae99d_5322 a b) ∨ (fact_9fdb227ae99d_5775 a b) ∨ (fact_9fdb227ae99d_5337 a b) ∨ (fact_9fdb227ae99d_5281 a b) ∨ (fact_9fdb227ae99d_5783 a b)))) ∨ ((fact_9fdb227ae99d_7546 a b) ∧ (fact_9fdb227ae99d_7644 a b) ∧ ((fact_9fdb227ae99d_4350 a b) ∨ (fact_9fdb227ae99d_4367 a b) ∨ (fact_9fdb227ae99d_5460 a b) ∨ (fact_9fdb227ae99d_6183 a b) ∨ (fact_9fdb227ae99d_5118 a b) ∨ (fact_9fdb227ae99d_4423 a b) ∨ (fact_9fdb227ae99d_5221 a b) ∨ (fact_9fdb227ae99d_4467 a b) ∨ (fact_9fdb227ae99d_4377 a b) ∨ (fact_9fdb227ae99d_5249 a b)) ∧ ((fact_9fdb227ae99d_5267 a b) ∨ (fact_9fdb227ae99d_5276 a b) ∨ (fact_9fdb227ae99d_5834 a b) ∨ (fact_9fdb227ae99d_6767 a b) ∨ (fact_9fdb227ae99d_5668 a b) ∨ (fact_9fdb227ae99d_5322 a b) ∨ (fact_9fdb227ae99d_5775 a b) ∨ (fact_9fdb227ae99d_5337 a b) ∨ (fact_9fdb227ae99d_5281 a b) ∨ (fact_9fdb227ae99d_5783 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a > b))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n542_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((2 : Int) ≤ run_x))
    (h2 : (b = (5 : Int)))
    (h3 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((((2 : Int) + a) < ((-4 : Int) - a)) ∨ (((-4 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + b) < ((2 : Int) + b)) ∨ (((2 : Int) + b) < ((2 : Int) - (0 : Int)))))
    (h7 : (run_x ≤ ((-1 : Int) + a)))
    (h8 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (fact_9fdb227ae99d_2695 a b run_x) ∨ (fact_9fdb227ae99d_3044 a b run_x) ∨ (fact_9fdb227ae99d_2732 a b run_x) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (fact_9fdb227ae99d_3046 a b run_x)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n542_run_floor (a b run_x : Int)
    (h0 : (run_x ≤ ((-1 : Int) + a)))
    (h1 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (fact_9fdb227ae99d_3354 a b run_x) ∨ (fact_9fdb227ae99d_3744 a b run_x) ∨ (fact_9fdb227ae99d_3361 a b run_x) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (fact_9fdb227ae99d_3746 a b run_x))))
    (h2 : ((2 : Int) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n543_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n543_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n543_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n543_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3584 a b) ∨ (fact_9fdb227ae99d_3588 a b) ∨ (fact_9fdb227ae99d_4721 a b) ∨ (fact_9fdb227ae99d_5751 a b) ∨ (fact_9fdb227ae99d_4340 a b) ∨ (fact_9fdb227ae99d_3622 a b) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3590 a b) ∨ (((((-4 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-4 : Int) ≤ (-(5 : Int))) ∧ ((-4 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n543_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3157 a b) ∨ (fact_9fdb227ae99d_3161 a b) ∨ (fact_9fdb227ae99d_3671 a b) ∨ (fact_9fdb227ae99d_5108 a b) ∨ (fact_9fdb227ae99d_3389 a b) ∨ (fact_9fdb227ae99d_3166 a b) ∨ (((((-2 : Int) - b) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (-(5 : Int))) ∧ ((-2 : Int) ≥ (-(5 : Int))) ∧ ((((1 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (-(5 : Int))) ∧ ((-3 : Int) ≥ (-(5 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3162 a b) ∨ (((((-4 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ (((-4 : Int) ≤ (-(5 : Int))) ∧ ((-4 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n543_run_tall (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a > b))
    (h4 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7526 a b) ∨ (fact_9fdb227ae99d_7411 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7526 a b) ∧ (fact_9fdb227ae99d_7411 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7526 a b) ∧ (fact_9fdb227ae99d_7411 a b) ∧ (((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4424 a b) ∨ (fact_9fdb227ae99d_5222 a b) ∨ (fact_9fdb227ae99d_4468 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_4482 a b)) ∨ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3504 a b) ∨ (fact_9fdb227ae99d_4278 a b) ∨ (fact_9fdb227ae99d_3538 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_3546 a b)))) ∨ ((fact_9fdb227ae99d_7526 a b) ∧ (fact_9fdb227ae99d_7411 a b) ∧ ((fact_9fdb227ae99d_4351 a b) ∨ (fact_9fdb227ae99d_4368 a b) ∨ (fact_9fdb227ae99d_5461 a b) ∨ (fact_9fdb227ae99d_6184 a b) ∨ (fact_9fdb227ae99d_5119 a b) ∨ (fact_9fdb227ae99d_4424 a b) ∨ (fact_9fdb227ae99d_5222 a b) ∨ (fact_9fdb227ae99d_4468 a b) ∨ (fact_9fdb227ae99d_4378 a b) ∨ (fact_9fdb227ae99d_4482 a b)) ∧ ((fact_9fdb227ae99d_3424 a b) ∨ (fact_9fdb227ae99d_3442 a b) ∨ (fact_9fdb227ae99d_4517 a b) ∨ (fact_9fdb227ae99d_5601 a b) ∨ (fact_9fdb227ae99d_3889 a b) ∨ (fact_9fdb227ae99d_3504 a b) ∨ (fact_9fdb227ae99d_4278 a b) ∨ (fact_9fdb227ae99d_3538 a b) ∨ (fact_9fdb227ae99d_3452 a b) ∨ (fact_9fdb227ae99d_3546 a b))))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n543_run_empty (a b run_x : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h3 : ((fact_9fdb227ae99d_2589 a b run_x) ∨ (fact_9fdb227ae99d_2594 a b run_x) ∨ (fact_9fdb227ae99d_3155 a b run_x) ∨ (fact_9fdb227ae99d_3675 a b run_x) ∨ (fact_9fdb227ae99d_3033 a b run_x) ∨ (fact_9fdb227ae99d_2695 a b run_x) ∨ (fact_9fdb227ae99d_3044 a b run_x) ∨ (fact_9fdb227ae99d_2732 a b run_x) ∨ (fact_9fdb227ae99d_2633 a b run_x) ∨ (((((-4 : Int) - a) ≤ (-(5 : Int))) ∧ ((-(5 : Int)) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-(5 : Int))) ∧ ((-4 : Int) ≥ (-(5 : Int))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b))))))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (run_x ≤ a))
    (h6 : (b = (5 : Int)))
    (h7 : ((3 : Int) ≤ run_x))
    (h8 : ((((2 : Int) + a) < ((-4 : Int) - a)) ∨ (((-4 : Int) + (0 : Int)) < ((2 : Int) + a)) ∨ ((2 : Int) > ((2 : Int) + b)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n543_run_floor (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : ((3 : Int) ≤ run_x))
    (h2 : (run_x ≤ a))
    (h3 : (¬ ((fact_9fdb227ae99d_3322 a b run_x) ∨ (fact_9fdb227ae99d_3326 a b run_x) ∨ (fact_9fdb227ae99d_4337 a b run_x) ∨ (fact_9fdb227ae99d_5471 a b run_x) ∨ (fact_9fdb227ae99d_3679 a b run_x) ∨ (fact_9fdb227ae99d_3354 a b run_x) ∨ (fact_9fdb227ae99d_3744 a b run_x) ∨ (fact_9fdb227ae99d_3361 a b run_x) ∨ (fact_9fdb227ae99d_3328 a b run_x) ∨ (((((-4 : Int) - a) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-((5 : Int) - (1 : Int))) ≤ ((-4 : Int) + (0 : Int))) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((-4 : Int) ≤ (-((5 : Int) - (1 : Int)))) ∧ ((-4 : Int) ≥ (-((5 : Int) - (1 : Int)))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n544_run_four (a b : Int)
    (h0 : (¬ ((-4 : Int) ≥ ((-3 : Int) + ((-1 : Int) * b)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n544_run_short (a b : Int)
    (h0 : (¬ (((-4 : Int) - ((-3 : Int) + ((-1 : Int) * b))) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n544_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n544_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5686 a b) ∨ (fact_9fdb227ae99d_5699 a b) ∨ (fact_9fdb227ae99d_6367 a b) ∨ (fact_9fdb227ae99d_6963 a b) ∨ (fact_9fdb227ae99d_5993 a b) ∨ (((((-1 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((((-3 : Int) + ((-1 : Int) * b)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) - (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_5706 a b) ∨ (fact_9fdb227ae99d_6985 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n544_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3415 a b) ∨ (fact_9fdb227ae99d_3433 a b) ∨ (fact_9fdb227ae99d_4508 a b) ∨ (fact_9fdb227ae99d_5592 a b) ∨ (fact_9fdb227ae99d_3880 a b) ∨ (((((-1 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) + a)) ∧ ((3 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((3 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((-4 : Int) + (1 : Int))) ∧ (((-4 : Int) + (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-3 : Int) ≤ ((-4 : Int) + (1 : Int))) ∧ ((-3 : Int) ≥ ((-4 : Int) + (1 : Int))) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3447 a b) ∨ (fact_9fdb227ae99d_5728 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n544_run_tall (a b : Int)
    (h0 : (¬ ((((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7785 a b) ∨ (fact_9fdb227ae99d_7529 a b))) ∨ (((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (2 : Int))) ∧ (fact_9fdb227ae99d_7785 a b) ∧ (fact_9fdb227ae99d_7529 a b)) ∨ ((-4 : Int) ≥ (((-3 : Int) + ((-1 : Int) * b)) + (4 : Int))) ∨ (((-4 : Int) = (((-3 : Int) + ((-1 : Int) * b)) + (1 : Int))) ∧ (fact_9fdb227ae99d_7785 a b) ∧ (fact_9fdb227ae99d_7529 a b) ∧ (((fact_9fdb227ae99d_6033 a b) ∨ (fact_9fdb227ae99d_6071 a b) ∨ (fact_9fdb227ae99d_6833 a b) ∨ (fact_9fdb227ae99d_7045 a b) ∨ (fact_9fdb227ae99d_6599 a b) ∨ (fact_9fdb227ae99d_6212 a b) ∨ (fact_9fdb227ae99d_6705 a b) ∨ (fact_9fdb227ae99d_6291 a b) ∨ (fact_9fdb227ae99d_6095 a b) ∨ (fact_9fdb227ae99d_7109 a b)) ∨ ((fact_9fdb227ae99d_4073 a b) ∨ (fact_9fdb227ae99d_4101 a b) ∨ (fact_9fdb227ae99d_5307 a b) ∨ (fact_9fdb227ae99d_5922 a b) ∨ (fact_9fdb227ae99d_4736 a b) ∨ (fact_9fdb227ae99d_4210 a b) ∨ (fact_9fdb227ae99d_5075 a b) ∨ (fact_9fdb227ae99d_4282 a b) ∨ (fact_9fdb227ae99d_4115 a b) ∨ (fact_9fdb227ae99d_6166 a b)))) ∨ ((fact_9fdb227ae99d_7785 a b) ∧ (fact_9fdb227ae99d_7529 a b) ∧ ((fact_9fdb227ae99d_6033 a b) ∨ (fact_9fdb227ae99d_6071 a b) ∨ (fact_9fdb227ae99d_6833 a b) ∨ (fact_9fdb227ae99d_7045 a b) ∨ (fact_9fdb227ae99d_6599 a b) ∨ (fact_9fdb227ae99d_6212 a b) ∨ (fact_9fdb227ae99d_6705 a b) ∨ (fact_9fdb227ae99d_6291 a b) ∨ (fact_9fdb227ae99d_6095 a b) ∨ (fact_9fdb227ae99d_7109 a b)) ∧ ((fact_9fdb227ae99d_4073 a b) ∨ (fact_9fdb227ae99d_4101 a b) ∨ (fact_9fdb227ae99d_5307 a b) ∨ (fact_9fdb227ae99d_5922 a b) ∨ (fact_9fdb227ae99d_4736 a b) ∨ (fact_9fdb227ae99d_4210 a b) ∨ (fact_9fdb227ae99d_5075 a b) ∨ (fact_9fdb227ae99d_4282 a b) ∨ (fact_9fdb227ae99d_4115 a b) ∨ (fact_9fdb227ae99d_6166 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n544_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((-4 : Int) ≥ run_x))
    (h6 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_3000 a b run_x) ∨ (fact_9fdb227ae99d_2481 a b run_x) ∨ (fact_9fdb227ae99d_2397 a b run_x) ∨ (fact_9fdb227ae99d_3615 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n544_run_floor (a b run_x : Int)
    (h0 : ((-4 : Int) ≥ run_x))
    (h1 : (((-3 : Int) + ((-1 : Int) * b)) ≤ run_x))
    (h2 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3573 a b run_x) ∨ (fact_9fdb227ae99d_3242 a b run_x) ∨ (fact_9fdb227ae99d_3196 a b run_x) ∨ (fact_9fdb227ae99d_5362 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n545_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ a)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n545_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n545_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n545_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3381 a b) ∨ (fact_9fdb227ae99d_3382 a b) ∨ (fact_9fdb227ae99d_4497 a b) ∨ (fact_9fdb227ae99d_5584 a b) ∨ (fact_9fdb227ae99d_3851 a b) ∨ (fact_9fdb227ae99d_3466 a b) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3852 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n545_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (¬ ((fact_9fdb227ae99d_3067 a b) ∨ (fact_9fdb227ae99d_3068 a b) ∨ (fact_9fdb227ae99d_3569 a b) ∨ (fact_9fdb227ae99d_4707 a b) ∨ (fact_9fdb227ae99d_3300 a b) ∨ (fact_9fdb227ae99d_3120 a b) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3301 a b))))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n545_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7380 a b) ∨ (fact_9fdb227ae99d_7295 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7380 a b) ∧ (fact_9fdb227ae99d_7295 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7380 a b) ∧ (fact_9fdb227ae99d_7295 a b) ∧ (((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3903 a b) ∨ (fact_9fdb227ae99d_4838 a b) ∨ (fact_9fdb227ae99d_3997 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∨ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3302 a b) ∨ (fact_9fdb227ae99d_3695 a b) ∨ (fact_9fdb227ae99d_3313 a b) ∨ (fact_9fdb227ae99d_3650 a b)))) ∨ ((fact_9fdb227ae99d_7380 a b) ∧ (fact_9fdb227ae99d_7295 a b) ∧ ((fact_9fdb227ae99d_3756 a b) ∨ (fact_9fdb227ae99d_3788 a b) ∨ (fact_9fdb227ae99d_5166 a b) ∨ (fact_9fdb227ae99d_5844 a b) ∨ (fact_9fdb227ae99d_4538 a b) ∨ (fact_9fdb227ae99d_3903 a b) ∨ (fact_9fdb227ae99d_4838 a b) ∨ (fact_9fdb227ae99d_3997 a b) ∨ (fact_9fdb227ae99d_4649 a b)) ∧ ((fact_9fdb227ae99d_3268 a b) ∨ (fact_9fdb227ae99d_3274 a b) ∨ (fact_9fdb227ae99d_4193 a b) ∨ (fact_9fdb227ae99d_5365 a b) ∨ (fact_9fdb227ae99d_3618 a b) ∨ (fact_9fdb227ae99d_3302 a b) ∨ (fact_9fdb227ae99d_3695 a b) ∨ (fact_9fdb227ae99d_3313 a b) ∨ (fact_9fdb227ae99d_3650 a b))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a > b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n545_run_empty (a b run_x : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((fact_9fdb227ae99d_2444 a b run_x) ∨ (fact_9fdb227ae99d_2445 a b run_x) ∨ (fact_9fdb227ae99d_3064 a b run_x) ∨ (fact_9fdb227ae99d_3570 a b run_x) ∨ (fact_9fdb227ae99d_2980 a b run_x) ∨ (fact_9fdb227ae99d_2531 a b run_x) ∨ ((((3 : Int) ≥ ((-2 : Int) - b)) ∧ ((3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-2 : Int)) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((3 : Int) ≥ ((-3 : Int) - a)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_2981 a b run_x)))
    (h3 : (run_x ≤ a))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((3 : Int) ≤ run_x))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n545_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (¬ ((fact_9fdb227ae99d_3173 a b run_x) ∨ (fact_9fdb227ae99d_3183 a b run_x) ∨ (fact_9fdb227ae99d_3726 a b run_x) ∨ (fact_9fdb227ae99d_5191 a b run_x) ∨ (fact_9fdb227ae99d_3485 a b run_x) ∨ (fact_9fdb227ae99d_3211 a b run_x) ∨ (((((-2 : Int) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-2 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ run_x) ∧ (run_x ≤ (((1 : Int) + a) + (0 : Int))))) ∨ (((((-3 : Int) - a) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((3 : Int) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_3549 a b run_x))))
    (h2 : (run_x ≤ a))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n546_run_four (a b : Int)
    (h0 : (¬ ((-3 : Int) ≥ ((-1 : Int) * a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n546_run_short (a b : Int)
    (h0 : (¬ (((-3 : Int) - ((-1 : Int) * a)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n546_run_nonnegative (a b : Int)
    (h0 : (¬ ((2 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n546_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a = (b + (2 : Int))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n546_run_right (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((0 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((0 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ ((((1 : Int) + b + a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (2 : Int))) ∨ ((((2 : Int) + a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-2 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a)))))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n546_run_tall (a b : Int)
    (h0 : (a > b))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((-3 : Int) ≥ (((-1 : Int) * a) + (3 : Int))) ∧ ((fact_9fdb227ae99d_7351 a b) ∨ (fact_9fdb227ae99d_7317 a b))) ∨ (((-3 : Int) ≥ (((-1 : Int) * a) + (2 : Int))) ∧ (fact_9fdb227ae99d_7351 a b) ∧ (fact_9fdb227ae99d_7317 a b)) ∨ ((-3 : Int) ≥ (((-1 : Int) * a) + (4 : Int))) ∨ (((-3 : Int) = (((-1 : Int) * a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7351 a b) ∧ (fact_9fdb227ae99d_7317 a b) ∧ (((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((0 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ ((((1 : Int) + b + a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))))) ∨ ((fact_9fdb227ae99d_4065 a b) ∨ (fact_9fdb227ae99d_4093 a b) ∨ (fact_9fdb227ae99d_5299 a b) ∨ (fact_9fdb227ae99d_5914 a b) ∨ (fact_9fdb227ae99d_4728 a b) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5069 a b) ∨ (fact_9fdb227ae99d_6156 a b)))) ∨ ((fact_9fdb227ae99d_7351 a b) ∧ (fact_9fdb227ae99d_7317 a b) ∧ ((((((0 : Int) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((0 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((0 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ (((1 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((1 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ ((((1 : Int) + b + a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((2 : Int) + a)) ∧ ((2 : Int) ≥ ((2 : Int) + a))) ∨ ((((2 : Int) + a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - b) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-1 : Int) * a) - (1 : Int))) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ ((2 : Int) + a)) ∧ ((1 : Int) ≥ ((2 : Int) + a))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ (((-1 : Int) * a) - (1 : Int))) ∧ ((((-1 : Int) * a) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((1 : Int) + a))))) ∧ ((fact_9fdb227ae99d_4065 a b) ∨ (fact_9fdb227ae99d_4093 a b) ∨ (fact_9fdb227ae99d_5299 a b) ∨ (fact_9fdb227ae99d_5914 a b) ∨ (fact_9fdb227ae99d_4728 a b) ∨ (((((-1 : Int) - a) ≤ ((-3 : Int) + (1 : Int))) ∧ (((-3 : Int) + (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((2 : Int) + a)) ∧ ((0 : Int) ≥ ((2 : Int) + a))) ∨ (((-1 : Int) ≤ ((-3 : Int) + (1 : Int))) ∧ ((-1 : Int) ≥ ((-3 : Int) + (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) + a) ≤ ((0 : Int) + b)))) ∨ (fact_9fdb227ae99d_5069 a b) ∨ (fact_9fdb227ae99d_6156 a b))))))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n546_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : ((fact_9fdb227ae99d_2365 a b run_x) ∨ (fact_9fdb227ae99d_2382 a b run_x) ∨ (fact_9fdb227ae99d_3038 a b run_x) ∨ (fact_9fdb227ae99d_3479 a b run_x) ∨ (fact_9fdb227ae99d_2926 a b run_x) ∨ (fact_9fdb227ae99d_2460 a b run_x) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ ((2 : Int) ≥ ((1 : Int) + a)) ∧ ((2 : Int) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ ((2 : Int) ≥ (((1 : Int) + a) - a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + a))))))
    (h5 : (((-1 : Int) * a) ≤ run_x))
    (h6 : ((-3 : Int) ≥ run_x))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n546_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3177 a b run_x) ∨ (fact_9fdb227ae99d_3187 a b run_x) ∨ (fact_9fdb227ae99d_3729 a b run_x) ∨ (fact_9fdb227ae99d_5194 a b run_x) ∨ (fact_9fdb227ae99d_3488 a b run_x) ∨ (fact_9fdb227ae99d_3213 a b run_x) ∨ (((((-2 : Int) - b) ≤ run_x) ∧ (run_x ≤ ((-2 : Int) + (0 : Int))) ∧ (((1 : Int) + a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a))) ∨ (((-2 : Int) ≤ run_x) ∧ ((-2 : Int) ≥ run_x) ∧ ((((1 : Int) + a) - a) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((1 : Int) + a) + (0 : Int))))) ∨ ((((((-3 : Int) + ((-1 : Int) * b)) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ (((-3 : Int) + ((-1 : Int) * b)) + b)) ∧ ((1 : Int) ≤ ((2 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((2 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * b)) ≤ run_x) ∧ (run_x ≤ ((-3 : Int) + ((-1 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))))))
    (h1 : ((-3 : Int) ≥ run_x))
    (h2 : (((-1 : Int) * a) ≤ run_x))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (a ≥ b))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a > b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_point (a b : Int)
    (h0 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((2 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_2869 a b) ∨ (fact_9fdb227ae99d_2871 a b) ∨ (fact_9fdb227ae99d_3261 a b) ∨ (fact_9fdb227ae99d_4168 a b) ∨ (fact_9fdb227ae99d_3100 a b) ∨ (fact_9fdb227ae99d_2961 a b) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (2 : Int)) ∧ ((2 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((2 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((2 : Int) ≤ ((1 : Int) + b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_o0 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) = jy) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_o1 (a b jx jy : Int)
    (h0 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((2 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h6 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_o2 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - b) ≥ (0 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((2 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_o3 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + a)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h6 : (¬ ((((-3 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((2 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h4 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - a))))
    (h5 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - a)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_o5 (a b jx jy : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + b)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h9 : (¬ ((((-3 : Int) = jx) ∧ ((2 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int))))))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_o6 (a b jx jy : Int)
    (h0 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((2 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - (0 : Int))) ∧ ((2 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n547_o7 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((2 : Int) ≥ jy) ∧ ((2 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((2 : Int) ≥ (jy - b)) ∧ ((2 : Int) ≤ (jy + (0 : Int))))))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_point (a b : Int)
    (h0 : (¬ (((2 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((2 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_empty (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((fact_9fdb227ae99d_2817 a b) ∨ (fact_9fdb227ae99d_2818 a b) ∨ (fact_9fdb227ae99d_3202 a b) ∨ (fact_9fdb227ae99d_3848 a b) ∨ (fact_9fdb227ae99d_3060 a b) ∨ (fact_9fdb227ae99d_2894 a b) ∨ (fact_9fdb227ae99d_2896 a b) ∨ ((((2 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((2 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((2 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b))))))
    (h2 : (b = (5 : Int)))
    (h3 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_o0 (a b jx jy : Int)
    (h0 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_o1 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jy - a) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_o2 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h1 : ((jy - b) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_o3 (a b jx jy : Int)
    (h0 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (¬ (((jx = ((2 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_o4 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((((2 : Int) ≥ (jx - b)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_o5 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : ((jx < ((2 : Int) + a)) ∨ (((2 : Int) + a) < jx) ∨ ((jy + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jy - (0 : Int)))))
    (h6 : ((((2 : Int) ≥ (jx - a)) ∧ ((2 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h8 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_o6 (a b jx jy : Int)
    (h0 : (¬ ((((2 : Int) = jx) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h4 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h5 : (((1 : Int) > (jx + b)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n548_o7 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((((2 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h7 : ((((2 : Int) ≥ (jx - (0 : Int))) ∧ ((2 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((2 : Int) ≥ jx) ∧ ((2 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_point (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_empty (a b : Int)
    (h0 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : ((fact_9fdb227ae99d_2819 a b) ∨ (fact_9fdb227ae99d_2821 a b) ∨ (fact_9fdb227ae99d_3203 a b) ∨ (fact_9fdb227ae99d_3849 a b) ∨ (fact_9fdb227ae99d_3065 a b) ∨ (fact_9fdb227ae99d_2898 a b) ∨ (fact_9fdb227ae99d_2902 a b) ∨ ((((3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3069 a b)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_o0 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h5 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_o1 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h4 : (((jx + b) < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) + a)) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h2 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b = (5 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_o3 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (¬ (((jx = ((3 : Int) + b)) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h8 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_o4 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h3 : ((jy - a) ≥ (0 : Int)))
    (h4 : (fact_9fdb227ae99d_107 a b))
    (h5 : (b = (5 : Int)))
    (h6 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_o5 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a = (b + (2 : Int))))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - a)) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h6 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + b)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h9 : (b = (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_o6 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < (((3 : Int) + a) - a)) ∨ ((((3 : Int) + a) + (0 : Int)) < jy)))
    (h4 : ((jx < (((2 : Int) + a) - a)) ∨ ((((2 : Int) + a) + (0 : Int)) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h8 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((jy + a) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n549_o7 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (¬ ((((3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h7 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n550_run_four (a b : Int)
    (h0 : (¬ ((3 : Int) ≤ ((2 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n550_run_short (a b : Int)
    (h0 : (¬ ((((2 : Int) + b) - (3 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n550_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n550_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3364 a b) ∨ (fact_9fdb227ae99d_3371 a b) ∨ (fact_9fdb227ae99d_4406 a b) ∨ (fact_9fdb227ae99d_5545 a b) ∨ (fact_9fdb227ae99d_3734 a b) ∨ (fact_9fdb227ae99d_3391 a b) ∨ (fact_9fdb227ae99d_3401 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3816 a b) ∨ (fact_9fdb227ae99d_3739 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n550_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3751 a b) ∨ (fact_9fdb227ae99d_3783 a b) ∨ (fact_9fdb227ae99d_5161 a b) ∨ (fact_9fdb227ae99d_5839 a b) ∨ (fact_9fdb227ae99d_4534 a b) ∨ (fact_9fdb227ae99d_3899 a b) ∨ (fact_9fdb227ae99d_3946 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + b) + (1 : Int))) ∧ ((((2 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4643 a b) ∨ (fact_9fdb227ae99d_4557 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n550_run_tall (a b : Int)
    (h0 : (¬ (((((3 : Int) + (3 : Int)) ≤ ((2 : Int) + b)) ∧ ((fact_9fdb227ae99d_7508 a b) ∨ (fact_9fdb227ae99d_7621 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ ((2 : Int) + b)) ∧ (fact_9fdb227ae99d_7508 a b) ∧ (fact_9fdb227ae99d_7621 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ ((2 : Int) + b)) ∨ ((((2 : Int) + b) = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7508 a b) ∧ (fact_9fdb227ae99d_7621 a b) ∧ (((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_3952 a b) ∨ (fact_9fdb227ae99d_5972 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∨ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_4801 a b) ∨ (fact_9fdb227ae99d_6548 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b)))) ∨ ((fact_9fdb227ae99d_7508 a b) ∧ (fact_9fdb227ae99d_7621 a b) ∧ ((fact_9fdb227ae99d_3759 a b) ∨ (fact_9fdb227ae99d_3791 a b) ∨ (fact_9fdb227ae99d_5169 a b) ∨ (fact_9fdb227ae99d_5847 a b) ∨ (fact_9fdb227ae99d_4540 a b) ∨ (fact_9fdb227ae99d_3905 a b) ∨ (fact_9fdb227ae99d_3952 a b) ∨ (fact_9fdb227ae99d_5972 a b) ∨ (fact_9fdb227ae99d_4654 a b) ∨ (fact_9fdb227ae99d_4559 a b)) ∧ ((fact_9fdb227ae99d_4574 a b) ∨ (fact_9fdb227ae99d_4609 a b) ∨ (fact_9fdb227ae99d_5640 a b) ∨ (fact_9fdb227ae99d_6381 a b) ∨ (fact_9fdb227ae99d_5377 a b) ∨ (fact_9fdb227ae99d_4759 a b) ∨ (fact_9fdb227ae99d_4801 a b) ∨ (fact_9fdb227ae99d_6548 a b) ∨ (fact_9fdb227ae99d_5420 a b) ∨ (fact_9fdb227ae99d_5397 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n550_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_2474 a b run_x) ∨ (fact_9fdb227ae99d_3609 a b run_x) ∨ (fact_9fdb227ae99d_2944 a b run_x) ∨ (fact_9fdb227ae99d_2931 a b run_x)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (run_x ≤ ((2 : Int) + b)))
    (h6 : ((3 : Int) ≤ run_x))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n550_run_floor (a b run_x : Int)
    (h0 : ((3 : Int) ≤ run_x))
    (h1 : (run_x ≤ ((2 : Int) + b)))
    (h2 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3230 a b run_x) ∨ (fact_9fdb227ae99d_5353 a b run_x) ∨ (fact_9fdb227ae99d_3551 a b run_x) ∨ (fact_9fdb227ae99d_3493 a b run_x))))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n551_run_four (a b : Int)
    (h0 : (¬ ((4 : Int) ≤ ((1 : Int) + a))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n551_run_short (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((1 : Int) + a) - (4 : Int)) < b)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n551_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n551_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3366 a b) ∨ (fact_9fdb227ae99d_3373 a b) ∨ (fact_9fdb227ae99d_4408 a b) ∨ (fact_9fdb227ae99d_5547 a b) ∨ (fact_9fdb227ae99d_3736 a b) ∨ (fact_9fdb227ae99d_3393 a b) ∨ (fact_9fdb227ae99d_3403 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((4 : Int) - (1 : Int))) ∧ (((4 : Int) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3825 a b) ∨ (fact_9fdb227ae99d_3833 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n551_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3748 a b) ∨ (fact_9fdb227ae99d_3780 a b) ∨ (fact_9fdb227ae99d_5158 a b) ∨ (fact_9fdb227ae99d_5836 a b) ∨ (fact_9fdb227ae99d_4531 a b) ∨ (fact_9fdb227ae99d_3896 a b) ∨ (fact_9fdb227ae99d_3943 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + a) + (1 : Int))) ∧ ((((1 : Int) + a) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4639 a b) ∨ (fact_9fdb227ae99d_4674 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n551_run_tall (a b : Int)
    (h0 : (¬ (((((4 : Int) + (3 : Int)) ≤ ((1 : Int) + a)) ∧ ((fact_9fdb227ae99d_7513 a b) ∨ (fact_9fdb227ae99d_7616 a b))) ∨ ((((4 : Int) + (2 : Int)) ≤ ((1 : Int) + a)) ∧ (fact_9fdb227ae99d_7513 a b) ∧ (fact_9fdb227ae99d_7616 a b)) ∨ (((4 : Int) + (4 : Int)) ≤ ((1 : Int) + a)) ∨ ((((1 : Int) + a) = ((4 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7513 a b) ∧ (fact_9fdb227ae99d_7616 a b) ∧ (((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_3958 a b) ∨ (fact_9fdb227ae99d_5978 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∨ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_4795 a b) ∨ (fact_9fdb227ae99d_6542 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b)))) ∨ ((fact_9fdb227ae99d_7513 a b) ∧ (fact_9fdb227ae99d_7616 a b) ∧ ((fact_9fdb227ae99d_3769 a b) ∨ (fact_9fdb227ae99d_3801 a b) ∨ (fact_9fdb227ae99d_5179 a b) ∨ (fact_9fdb227ae99d_5857 a b) ∨ (fact_9fdb227ae99d_4546 a b) ∨ (fact_9fdb227ae99d_3911 a b) ∨ (fact_9fdb227ae99d_3958 a b) ∨ (fact_9fdb227ae99d_5978 a b) ∨ (fact_9fdb227ae99d_4663 a b) ∨ (fact_9fdb227ae99d_4688 a b)) ∧ ((fact_9fdb227ae99d_4565 a b) ∨ (fact_9fdb227ae99d_4600 a b) ∨ (fact_9fdb227ae99d_5632 a b) ∨ (fact_9fdb227ae99d_6373 a b) ∨ (fact_9fdb227ae99d_5371 a b) ∨ (fact_9fdb227ae99d_4753 a b) ∨ (fact_9fdb227ae99d_4795 a b) ∨ (fact_9fdb227ae99d_6542 a b) ∨ (fact_9fdb227ae99d_5417 a b) ∨ (fact_9fdb227ae99d_5428 a b))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n551_run_empty (a b run_x : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (run_x ≤ ((1 : Int) + a)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : ((4 : Int) ≤ run_x))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((fact_9fdb227ae99d_2366 a b run_x) ∨ (fact_9fdb227ae99d_2383 a b run_x) ∨ (fact_9fdb227ae99d_3039 a b run_x) ∨ (fact_9fdb227ae99d_3480 a b run_x) ∨ (fact_9fdb227ae99d_2927 a b run_x) ∨ (fact_9fdb227ae99d_2461 a b run_x) ∨ (fact_9fdb227ae99d_2473 a b run_x) ∨ (fact_9fdb227ae99d_3608 a b run_x) ∨ (fact_9fdb227ae99d_2943 a b run_x) ∨ (fact_9fdb227ae99d_2947 a b run_x)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n551_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3178 a b run_x) ∨ (fact_9fdb227ae99d_3188 a b run_x) ∨ (fact_9fdb227ae99d_3730 a b run_x) ∨ (fact_9fdb227ae99d_5195 a b run_x) ∨ (fact_9fdb227ae99d_3489 a b run_x) ∨ (fact_9fdb227ae99d_3214 a b run_x) ∨ (fact_9fdb227ae99d_3229 a b run_x) ∨ (fact_9fdb227ae99d_5352 a b run_x) ∨ (fact_9fdb227ae99d_3550 a b run_x) ∨ (fact_9fdb227ae99d_3558 a b run_x))))
    (h1 : ((4 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + a)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n552_run_four (a b : Int)
    (h0 : (¬ ((2 : Int) ≤ ((1 : Int) + b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n552_run_short (a b : Int)
    (h0 : (¬ ((((1 : Int) + b) - (2 : Int)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n552_run_nonnegative (a b : Int)
    (h0 : (¬ ((4 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n552_run_left (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3363 a b) ∨ (fact_9fdb227ae99d_3370 a b) ∨ (fact_9fdb227ae99d_4405 a b) ∨ (fact_9fdb227ae99d_5544 a b) ∨ (fact_9fdb227ae99d_3733 a b) ∨ (fact_9fdb227ae99d_3390 a b) ∨ (fact_9fdb227ae99d_3400 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) - (1 : Int))) ∧ (((2 : Int) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3738 a b))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n552_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3750 a b) ∨ (fact_9fdb227ae99d_3782 a b) ∨ (fact_9fdb227ae99d_5160 a b) ∨ (fact_9fdb227ae99d_5838 a b) ∨ (fact_9fdb227ae99d_4533 a b) ∨ (fact_9fdb227ae99d_3898 a b) ∨ (fact_9fdb227ae99d_3945 a b) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b) + (1 : Int))) ∧ ((((1 : Int) + b) + (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_4552 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n552_run_tall (a b : Int)
    (h0 : (¬ (((((2 : Int) + (3 : Int)) ≤ ((1 : Int) + b)) ∧ ((fact_9fdb227ae99d_7389 a b) ∨ (fact_9fdb227ae99d_7456 a b))) ∨ ((((2 : Int) + (2 : Int)) ≤ ((1 : Int) + b)) ∧ (fact_9fdb227ae99d_7389 a b) ∧ (fact_9fdb227ae99d_7456 a b)) ∨ (((2 : Int) + (4 : Int)) ≤ ((1 : Int) + b)) ∨ ((((1 : Int) + b) = ((2 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7389 a b) ∧ (fact_9fdb227ae99d_7456 a b) ∧ (((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_3948 a b) ∨ (fact_9fdb227ae99d_5968 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∨ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_4799 a b) ∨ (fact_9fdb227ae99d_6546 a b) ∨ (fact_9fdb227ae99d_5393 a b)))) ∨ ((fact_9fdb227ae99d_7389 a b) ∧ (fact_9fdb227ae99d_7456 a b) ∧ ((fact_9fdb227ae99d_3754 a b) ∨ (fact_9fdb227ae99d_3786 a b) ∨ (fact_9fdb227ae99d_5164 a b) ∨ (fact_9fdb227ae99d_5842 a b) ∨ (fact_9fdb227ae99d_4536 a b) ∨ (fact_9fdb227ae99d_3901 a b) ∨ (fact_9fdb227ae99d_3948 a b) ∨ (fact_9fdb227ae99d_5968 a b) ∨ (fact_9fdb227ae99d_4553 a b)) ∧ ((fact_9fdb227ae99d_4571 a b) ∨ (fact_9fdb227ae99d_4606 a b) ∨ (fact_9fdb227ae99d_5638 a b) ∨ (fact_9fdb227ae99d_6379 a b) ∨ (fact_9fdb227ae99d_5375 a b) ∨ (fact_9fdb227ae99d_4757 a b) ∨ (fact_9fdb227ae99d_4799 a b) ∨ (fact_9fdb227ae99d_6546 a b) ∨ (fact_9fdb227ae99d_5393 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n552_run_empty (a b run_x : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (run_x ≤ ((1 : Int) + b)))
    (h5 : ((2 : Int) ≤ run_x))
    (h6 : ((fact_9fdb227ae99d_2367 a b run_x) ∨ (fact_9fdb227ae99d_2384 a b run_x) ∨ (fact_9fdb227ae99d_3040 a b run_x) ∨ (fact_9fdb227ae99d_3481 a b run_x) ∨ (fact_9fdb227ae99d_2928 a b run_x) ∨ (fact_9fdb227ae99d_2462 a b run_x) ∨ (fact_9fdb227ae99d_2474 a b run_x) ∨ (fact_9fdb227ae99d_3609 a b run_x) ∨ (fact_9fdb227ae99d_2930 a b run_x)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n552_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3179 a b run_x) ∨ (fact_9fdb227ae99d_3189 a b run_x) ∨ (fact_9fdb227ae99d_3731 a b run_x) ∨ (fact_9fdb227ae99d_5196 a b run_x) ∨ (fact_9fdb227ae99d_3490 a b run_x) ∨ (fact_9fdb227ae99d_3215 a b run_x) ∨ (fact_9fdb227ae99d_3230 a b run_x) ∨ (fact_9fdb227ae99d_5353 a b run_x) ∨ (fact_9fdb227ae99d_3492 a b run_x))))
    (h1 : ((2 : Int) ≤ run_x))
    (h2 : (run_x ≤ ((1 : Int) + b)))
    (h3 : (a ≥ b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a > b))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b = (5 : Int)))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_29 a b))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_empty (a b : Int)
    (h0 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_5156 a b) ∨ (fact_9fdb227ae99d_3332 a b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_o0 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h1 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + b) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - (0 : Int)))))
    (h8 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h9 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h10 : (a = (b + (2 : Int))))
    (h11 : (a ≥ b))
    (h12 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_o1 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h3 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h4 : ((jy - a) ≥ (0 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_o2 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : ((jy - b) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h7 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h8 : (b = (5 : Int)))
    (h9 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h10 : ((jx < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h11 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_o3 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_o4 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - a))))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_o5 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h6 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_o6 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h5 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n553_o7 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h7 : (b ≥ (3 : Int)))
    (h8 : ((jx < ((2 : Int) - b)) ∨ (((2 : Int) + (0 : Int)) < jx) ∨ ((jy + (0 : Int)) < ((3 : Int) + a)) ∨ (((3 : Int) + a) < (jy - b))))
    (h9 : ((jy - b) ≥ (0 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_point (a b : Int)
    (h0 : (¬ (((-3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((3 : Int) ≥ (0 : Int)) ∧ ((-3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b = (5 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_empty (a b : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h4 : (((-1 : Int) > (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∨ ((-1 : Int) < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((1 : Int) < ((0 : Int) - (0 : Int))) ∨ ((1 : Int) > ((0 : Int) + b))))
    (h5 : ((fact_9fdb227ae99d_2870 a b) ∨ (fact_9fdb227ae99d_2872 a b) ∨ (fact_9fdb227ae99d_3262 a b) ∨ (fact_9fdb227ae99d_4169 a b) ∨ (fact_9fdb227ae99d_3101 a b) ∨ ((((-3 : Int) ≥ ((-1 : Int) - a)) ∧ ((-3 : Int) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (0 : Int))) ∨ (((-1 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-1 : Int)) ∧ ((3 : Int) ≥ ((0 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((0 : Int) + b)))) ∨ ((((-3 : Int) ≥ ((-2 : Int) - a)) ∧ ((-3 : Int) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (1 : Int))) ∨ (((-2 : Int) ≤ (-3 : Int)) ∧ ((-3 : Int) ≤ (-2 : Int)) ∧ ((3 : Int) ≥ ((1 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)))) ∨ ((((-3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((-3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (2 : Int))) ∨ (((-3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((3 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2873 a b)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((jx + a) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h4 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h5 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_o1 (a b jx jy : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((jy - a) ≥ (0 : Int)))
    (h2 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_o2 (a b jx jy : Int)
    (h0 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((3 : Int) + b)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h1 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h2 : (b = (5 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_o3 (a b jx jy : Int)
    (h0 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + a)) ∨ ((2 : Int) < (jy - (0 : Int)))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (¬ ((((-3 : Int) = jx) ∧ ((3 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (¬ ((((-3 : Int) = jx) ∧ (jy = ((3 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h2 : ((jx < (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) + a) < jx) ∨ ((2 : Int) > (jy + (0 : Int))) ∨ ((2 : Int) < (jy - a))))
    (h3 : (b = (5 : Int)))
    (h4 : ((((-3 : Int) ≥ (jx - b)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - a)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_o5 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jx < ((-2 : Int) - a)) ∨ (((-2 : Int) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + b)) ∨ ((1 : Int) < (jy - (0 : Int)))))
    (h2 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (((jx + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((((-3 : Int) ≥ (jx - a)) ∧ ((-3 : Int) ≤ (jx + (0 : Int))) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + b)))))
    (h7 : (b = (5 : Int)))
    (h8 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_o6 (a b jx jy : Int)
    (h0 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h1 : (¬ (((jx = ((-3 : Int) + ((-1 : Int) * b))) ∧ ((3 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + b)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - (0 : Int))) ∧ ((3 : Int) ≤ (jy + a)))))
    (h4 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (b = (5 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (fact_9fdb227ae99d_107 a b))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n554_o7 (a b jx jy : Int)
    (h0 : (((1 : Int) > (jx + a)) ∨ ((1 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : ((((-3 : Int) ≥ (jx - (0 : Int))) ∧ ((-3 : Int) ≤ (jx + a)) ∧ ((3 : Int) ≥ jy) ∧ ((3 : Int) ≤ jy)) ∨ (((-3 : Int) ≥ jx) ∧ ((-3 : Int) ≤ jx) ∧ ((3 : Int) ≥ (jy - b)) ∧ ((3 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n555_run_four (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ ((3 : Int) ≤ a)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n555_run_short (a b : Int)
    (h0 : (¬ ((a - (3 : Int)) < b)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n555_run_nonnegative (a b : Int)
    (h0 : (¬ ((3 : Int) ≥ (0 : Int))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n555_run_left (a b : Int)
    (h0 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((0 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((2 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((3 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - b) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n555_run_right (a b : Int)
    (h0 : (a = (b + (2 : Int))))
    (h1 : (¬ ((((((0 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) + b)) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((0 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + a)))) ∨ (((((1 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b)) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((1 : Int) + b + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((1 : Int) + b + a) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ ((((1 : Int) + b + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((1 : Int) + b + a)) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ ((((((2 : Int) + ((2 : Int) * b)) - b) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + ((2 : Int) * b)) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ ((((2 : Int) + ((2 : Int) * b)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + ((2 : Int) * b))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + a)))) ∨ ((((((2 : Int) + a) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((2 : Int) + a) + (0 : Int))) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ ((((2 : Int) + a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + a)) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ (a + (1 : Int))) ∧ ((0 : Int) ≥ (a + (1 : Int)))) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (a + (1 : Int))) ∧ ((2 : Int) ≥ (a + (1 : Int)))) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ (a + (1 : Int))) ∧ ((3 : Int) ≥ (a + (1 : Int)))) ∨ (((2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - b) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n555_run_tall (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (a > b))
    (h2 : (¬ (((((3 : Int) + (3 : Int)) ≤ a) ∧ ((fact_9fdb227ae99d_7782 a b) ∨ (fact_9fdb227ae99d_7735 a b))) ∨ ((((3 : Int) + (2 : Int)) ≤ a) ∧ (fact_9fdb227ae99d_7782 a b) ∧ (fact_9fdb227ae99d_7735 a b)) ∨ (((3 : Int) + (4 : Int)) ≤ a) ∨ ((a = ((3 : Int) + (1 : Int))) ∧ (fact_9fdb227ae99d_7782 a b) ∧ (fact_9fdb227ae99d_7735 a b) ∧ (((fact_9fdb227ae99d_6018 a b) ∨ (fact_9fdb227ae99d_6056 a b) ∨ (fact_9fdb227ae99d_6818 a b) ∨ (fact_9fdb227ae99d_7030 a b) ∨ (fact_9fdb227ae99d_6584 a b) ∨ (fact_9fdb227ae99d_6203 a b) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_7078 a b) ∨ (fact_9fdb227ae99d_6084 a b) ∨ (fact_9fdb227ae99d_6712 a b)) ∨ ((fact_9fdb227ae99d_5560 a b) ∨ (fact_9fdb227ae99d_5568 a b) ∨ (fact_9fdb227ae99d_6317 a b) ∨ (fact_9fdb227ae99d_6902 a b) ∨ (fact_9fdb227ae99d_5868 a b) ∨ (fact_9fdb227ae99d_5609 a b) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6942 a b) ∨ (fact_9fdb227ae99d_5574 a b) ∨ (fact_9fdb227ae99d_5944 a b)))) ∨ ((fact_9fdb227ae99d_7782 a b) ∧ (fact_9fdb227ae99d_7735 a b) ∧ ((fact_9fdb227ae99d_6018 a b) ∨ (fact_9fdb227ae99d_6056 a b) ∨ (fact_9fdb227ae99d_6818 a b) ∨ (fact_9fdb227ae99d_7030 a b) ∨ (fact_9fdb227ae99d_6584 a b) ∨ (fact_9fdb227ae99d_6203 a b) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ ((3 : Int) - (1 : Int))) ∧ ((1 : Int) ≥ ((3 : Int) - (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ ((3 : Int) - (1 : Int))) ∧ (((3 : Int) - (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_7078 a b) ∨ (fact_9fdb227ae99d_6084 a b) ∨ (fact_9fdb227ae99d_6712 a b)) ∧ ((fact_9fdb227ae99d_5560 a b) ∨ (fact_9fdb227ae99d_5568 a b) ∨ (fact_9fdb227ae99d_6317 a b) ∨ (fact_9fdb227ae99d_6902 a b) ∨ (fact_9fdb227ae99d_5868 a b) ∨ (fact_9fdb227ae99d_5609 a b) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((((-2 : Int) + ((-1 : Int) * a)) + a) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ (a + (1 : Int))) ∧ ((1 : Int) ≥ (a + (1 : Int)))) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) + a)) ∧ (((1 : Int) - (0 : Int)) ≤ (a + (1 : Int))) ∧ ((a + (1 : Int)) ≤ ((1 : Int) + b)))) ∨ (fact_9fdb227ae99d_6942 a b) ∨ (fact_9fdb227ae99d_5574 a b) ∨ (fact_9fdb227ae99d_5944 a b))))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a = (b + (2 : Int))))
    (h6 : (a ≥ b))
    (h7 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n555_run_empty (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (run_x ≤ a))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a = (b + (2 : Int))))
    (h5 : (a ≥ (5 : Int)))
    (h6 : ((fact_9fdb227ae99d_3628 a b run_x) ∨ (fact_9fdb227ae99d_3637 a b run_x) ∨ (fact_9fdb227ae99d_5036 a b run_x) ∨ (fact_9fdb227ae99d_5789 a b run_x) ∨ (fact_9fdb227ae99d_4411 a b run_x) ∨ (((((-1 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-1 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((2 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ (((-2 : Int) + ((-1 : Int) * a)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((-3 : Int) ≥ ((-2 : Int) + ((-1 : Int) * a))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int)))))))
    (h7 : ((3 : Int) ≤ run_x))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n555_run_floor (a b run_x : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_5411 a b run_x) ∨ (fact_9fdb227ae99d_5414 a b run_x) ∨ (fact_9fdb227ae99d_5989 a b run_x) ∨ (fact_9fdb227ae99d_6842 a b run_x) ∨ (fact_9fdb227ae99d_5795 a b run_x) ∨ (((((-1 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-1 : Int) + (0 : Int))) ∧ ((0 : Int) ≤ run_x) ∧ ((0 : Int) ≥ run_x)) ∨ (((-1 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-1 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((0 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((0 : Int) + b)))) ∨ (((((-2 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-2 : Int) + (0 : Int))) ∧ ((1 : Int) ≤ run_x) ∧ ((1 : Int) ≥ run_x)) ∨ (((-2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((1 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((1 : Int) + b)))) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (((((2 : Int) - (0 : Int)) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((2 : Int) + b)) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((2 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((2 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (((((-3 : Int) - a) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((-2 : Int) + ((-1 : Int) * a)) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ (((3 : Int) + b) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + b))) ∨ (((-3 : Int) ≤ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((-3 : Int) ≥ (((-2 : Int) + ((-1 : Int) * a)) - (1 : Int))) ∧ ((((3 : Int) + b) - b) ≤ run_x) ∧ (run_x ≤ (((3 : Int) + b) + (0 : Int))))))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (run_x ≤ a))
    (h3 : (a = (b + (2 : Int))))
    (h4 : ((3 : Int) ≤ run_x))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (b = (5 : Int)))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_point (a b : Int)
    (h0 : (¬ (((3 : Int) ≥ (-((6 : Int) * ((a + b) + (1 : Int))))) ∧ ((4 : Int) ≥ (0 : Int)) ∧ ((3 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))) ∧ ((4 : Int) ≤ ((6 : Int) * ((a + b) + (1 : Int)))))))
    (h1 : (fact_9fdb227ae99d_107 a b))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (b = (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_empty (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : ((fact_9fdb227ae99d_2820 a b) ∨ (fact_9fdb227ae99d_2822 a b) ∨ (fact_9fdb227ae99d_3204 a b) ∨ (fact_9fdb227ae99d_3850 a b) ∨ (fact_9fdb227ae99d_3066 a b) ∨ (fact_9fdb227ae99d_2899 a b) ∨ (fact_9fdb227ae99d_2903 a b) ∨ ((((3 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((3 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (2 : Int))) ∨ (((3 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((3 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((4 : Int) ≥ ((2 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2823 a b) ∨ ((((3 : Int) ≥ ((-3 : Int) - b)) ∧ ((3 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (4 : Int)) ∧ ((4 : Int) ≤ (3 : Int))) ∨ (((-3 : Int) ≤ (3 : Int)) ∧ ((3 : Int) ≤ (-3 : Int)) ∧ ((4 : Int) ≥ ((3 : Int) - (0 : Int))) ∧ ((4 : Int) ≤ ((3 : Int) + a))))))
    (h2 : (((((2 : Int) + a) + (0 : Int)) < ((-3 : Int) + ((-1 : Int) * a))) ∨ (((-3 : Int) + ((-1 : Int) * a)) < (((2 : Int) + a) - a)) ∨ ((2 : Int) < ((2 : Int) - (0 : Int))) ∨ ((2 : Int) > ((2 : Int) + b))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (a ≥ b))
    (h7 : (a > b))
    (h8 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_o0 (a b jx jy : Int)
    (h0 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h1 : (a = (b + (2 : Int))))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h5 : (((2 : Int) > (jx + a)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h6 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + b)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (((jx + a) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - (0 : Int))) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h9 : (b ≥ (3 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_o1 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - a))))
    (h5 : ((jy - a) ≥ (0 : Int)))
    (h6 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h7 : (b = (5 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_o2 (a b jx jy : Int)
    (h0 : (((-3 : Int) > (jx + (0 : Int))) ∨ ((-3 : Int) < (jx - a)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (b = (5 : Int)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : ((jy - b) ≥ (0 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_o3 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (¬ (((jx = ((3 : Int) + b)) ∧ ((4 : Int) = jy) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b) ∧ ((0 : Int) = (0 : Int))))))
    (h7 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h8 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_o4 (a b jx jy : Int)
    (h0 : ((((3 : Int) ≥ (jx - b)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - a)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (b = (5 : Int)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h6 : (((2 : Int) > (jx + (0 : Int))) ∨ ((2 : Int) < (jx - b)) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h7 : ((jy - a) ≥ (0 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_o5 (a b jx jy : Int)
    (h0 : (((jx + (0 : Int)) < ((2 : Int) + a)) ∨ (((2 : Int) + a) < (jx - a)) ∨ (jy < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jy)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b = (5 : Int)))
    (h3 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h4 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h5 : (((1 : Int) > (jx + (0 : Int))) ∨ ((1 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + a) < jy)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : ((((3 : Int) ≥ (jx - a)) ∧ ((3 : Int) ≤ (jx + (0 : Int))) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + b)))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_o6 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (((2 : Int) > (jx + b)) ∨ ((2 : Int) < (jx - (0 : Int))) ∨ (jy < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + a) < jy)))
    (h5 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + b)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - (0 : Int))) ∧ ((4 : Int) ≤ (jy + a)))))
    (h6 : (b = (5 : Int)))
    (h7 : (a ≥ (5 : Int)))
    (h8 : (¬ ((((3 : Int) = jx) ∧ ((4 : Int) = jy) ∧ (b = b) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int))))))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n556_o7 (a b jx jy : Int)
    (h0 : (¬ ((((3 : Int) = jx) ∧ (jy = ((4 : Int) + b)) ∧ (a = a) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b)))))
    (h1 : ((((3 : Int) ≥ (jx - (0 : Int))) ∧ ((3 : Int) ≤ (jx + a)) ∧ ((4 : Int) ≥ jy) ∧ ((4 : Int) ≤ jy)) ∨ (((3 : Int) ≥ jx) ∧ ((3 : Int) ≤ jx) ∧ ((4 : Int) ≥ (jy - b)) ∧ ((4 : Int) ≤ (jy + (0 : Int))))))
    (h2 : ((jx < ((2 : Int) - (0 : Int))) ∨ (((2 : Int) + b) < jx) ∨ ((3 : Int) > (jy + (0 : Int))) ∨ ((3 : Int) < (jy - b))))
    (h3 : (b = (5 : Int)))
    (h4 : ((jy - b) ≥ (0 : Int)))
    (h5 : (a ≥ b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a > b))
    (h8 : (a ≥ (5 : Int)))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_point (a b : Int)
    (h0 : (fact_9fdb227ae99d_107 a b))
    (h1 : (b = (5 : Int)))
    (h2 : (fact_9fdb227ae99d_29 a b))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b ≥ (3 : Int)))
    (h5 : (a ≥ b))
    (h6 : (a > b))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_empty (a b : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((fact_9fdb227ae99d_3086 a b) ∨ (fact_9fdb227ae99d_3087 a b) ∨ (fact_9fdb227ae99d_3593 a b) ∨ (fact_9fdb227ae99d_5028 a b) ∨ (fact_9fdb227ae99d_3330 a b) ∨ (fact_9fdb227ae99d_3125 a b) ∨ (fact_9fdb227ae99d_3127 a b) ∨ (fact_9fdb227ae99d_5156 a b) ∨ (fact_9fdb227ae99d_3088 a b) ∨ ((((-1 : Int) ≥ ((-3 : Int) - b)) ∧ ((-1 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((1 : Int) + b)) ∧ ((3 : Int) ≥ ((1 : Int) + b))) ∨ (((-3 : Int) ≤ (-1 : Int)) ∧ ((-1 : Int) ≤ (-3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((1 : Int) + b)) ∧ (((1 : Int) + b) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3333 a b)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (a ≥ b))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_o0 (a b jx jy : Int)
    (h0 : ((jx < ((-1 : Int) - a)) ∨ (((-1 : Int) + (0 : Int)) < jx) ∨ ((0 : Int) > (jy + b)) ∨ ((0 : Int) < (jy - (0 : Int)))))
    (h1 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h2 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + b) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - (0 : Int)))))
    (h8 : (((0 : Int) > (jx + a)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h9 : (fact_9fdb227ae99d_1974 a b jx jy))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_o1 (a b jx jy : Int)
    (h0 : ((jy - a) ≥ (0 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ (b = b) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a)))))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (fact_9fdb227ae99d_1977 a b jx jy))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (b = (5 : Int)))
    (h7 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_o2 (a b jx jy : Int)
    (h0 : (b ≥ (3 : Int)))
    (h1 : ((jx < (((2 : Int) + ((2 : Int) * b)) - b)) ∨ ((((2 : Int) + ((2 : Int) * b)) + (0 : Int)) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (b = (5 : Int)))
    (h5 : ((jx < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jx) ∨ ((1 : Int) > (jy + (0 : Int))) ∨ ((1 : Int) < (jy - b))))
    (h6 : (a = (b + (2 : Int))))
    (h7 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h8 : (fact_9fdb227ae99d_1979 a b jx jy))
    (h9 : ((jy - b) ≥ (0 : Int)))
    (h10 : (fact_9fdb227ae99d_107 a b))
    (h11 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + ((2 : Int) * b))) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (a = a) ∧ (b = b)))))
    (h12 : (a ≥ b))
    (h13 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_o3 (a b jx jy : Int)
    (h0 : (((-1 : Int) > (jx + (0 : Int))) ∨ ((-1 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < jy)))
    (h1 : (fact_9fdb227ae99d_1980 a b jx jy))
    (h2 : (fact_9fdb227ae99d_107 a b))
    (h3 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - b)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h4 : (a ≥ (5 : Int)))
    (h5 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - b)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h8 : (b = (5 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_o4 (a b jx jy : Int)
    (h0 : (fact_9fdb227ae99d_1981 a b jx jy))
    (h1 : (b = (5 : Int)))
    (h2 : ((jy - a) ≥ (0 : Int)))
    (h3 : (a ≥ (5 : Int)))
    (h4 : (¬ ((((-1 : Int) = jx) ∧ (jy = ((1 : Int) + b + a)) ∧ ((0 : Int) = (0 : Int)) ∧ ((0 : Int) = (0 : Int)) ∧ (b = b) ∧ (a = a)))))
    (h5 : (b ≥ (3 : Int)))
    (h6 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - a))))
    (h7 : (fact_9fdb227ae99d_107 a b))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_o5 (a b jx jy : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (fact_9fdb227ae99d_1978 a b jx jy))
    (h3 : (((0 : Int) > (jx + (0 : Int))) ∨ ((0 : Int) < (jx - a)) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h4 : (((-2 : Int) > (jx + (0 : Int))) ∨ ((-2 : Int) < (jx - a)) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h7 : (b ≥ (3 : Int)))
    (h8 : (a ≥ b))
    (h9 : (a > b))
    (h10 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_o6 (a b jx jy : Int)
    (h0 : (((0 : Int) > (jx + b)) ∨ ((0 : Int) < (jx - (0 : Int))) ∨ (jy < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + a) < jy)))
    (h1 : (((-2 : Int) > (jx + b)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h2 : ((jy - (0 : Int)) ≥ (0 : Int)))
    (h3 : (fact_9fdb227ae99d_107 a b))
    (h4 : (((-2 : Int) > jx) ∨ ((-2 : Int) < jx) ∨ ((jy + a) < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < (jy - (0 : Int)))))
    (h5 : ((jx < ((-3 : Int) - b)) ∨ (((-3 : Int) + (0 : Int)) < jx) ∨ ((3 : Int) > (jy + a)) ∨ ((3 : Int) < (jy - (0 : Int)))))
    (h6 : (fact_9fdb227ae99d_1976 a b jx jy))
    (h7 : (b = (5 : Int)))
    (h8 : (b ≥ (3 : Int)))
    (h9 : (a ≥ (5 : Int)))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    (h12 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n557_o7 (a b jx jy : Int)
    (h0 : (((jx + a) < ((3 : Int) - (0 : Int))) ∨ (((3 : Int) + b) < (jx - (0 : Int))) ∨ (jy < ((4 : Int) + a)) ∨ (((4 : Int) + a) < jy)))
    (h1 : (b = (5 : Int)))
    (h2 : (((-1 : Int) > jx) ∨ ((-1 : Int) < jx) ∨ ((jy + (0 : Int)) < ((0 : Int) - (0 : Int))) ∨ (((0 : Int) + b) < (jy - b))))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (fact_9fdb227ae99d_1975 a b jx jy))
    (h5 : ((jy - b) ≥ (0 : Int)))
    (h6 : (a ≥ (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    (h8 : (((-2 : Int) > (jx + a)) ∨ ((-2 : Int) < (jx - (0 : Int))) ∨ (jy < ((1 : Int) - (0 : Int))) ∨ (((1 : Int) + b) < jy)))
    (h9 : (fact_9fdb227ae99d_107 a b))
    (h10 : (a ≥ b))
    (h11 : (a > b))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n558_run_four (a b : Int)
    (h0 : (¬ (((1 : Int) + a) ≤ (b + a))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n558_run_short (a b : Int)
    (h0 : (¬ (((b + a) - ((1 : Int) + a)) < b)))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n558_run_nonnegative (a b : Int)
    (h0 : (a ≥ (5 : Int)))
    (h1 : (¬ (((1 : Int) + a) ≥ (0 : Int))))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n558_run_left (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3842 a b) ∨ (fact_9fdb227ae99d_3843 a b) ∨ (fact_9fdb227ae99d_5285 a b) ∨ (fact_9fdb227ae99d_5899 a b) ∨ (fact_9fdb227ae99d_4702 a b) ∨ (fact_9fdb227ae99d_4173 a b) ∨ (fact_9fdb227ae99d_4174 a b) ∨ ((((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((2 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3844 a b) ∨ ((((0 : Int) ≥ ((-3 : Int) - b)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((3 : Int) ≥ (((1 : Int) + a) - (1 : Int)))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ (((1 : Int) + a) - (1 : Int))) ∧ ((((1 : Int) + a) - (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_4703 a b) ∨ (fact_9fdb227ae99d_5345 a b))))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n558_run_right (a b : Int)
    (h0 : (¬ ((fact_9fdb227ae99d_3287 a b) ∨ (fact_9fdb227ae99d_3288 a b) ∨ (fact_9fdb227ae99d_4317 a b) ∨ (fact_9fdb227ae99d_5448 a b) ∨ (fact_9fdb227ae99d_3664 a b) ∨ (fact_9fdb227ae99d_3340 a b) ∨ (fact_9fdb227ae99d_3342 a b) ∨ ((((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((2 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3289 a b) ∨ ((((0 : Int) ≥ ((-3 : Int) - b)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ ((b + a) + (1 : Int))) ∧ ((3 : Int) ≥ ((b + a) + (1 : Int)))) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ ((b + a) + (1 : Int))) ∧ (((b + a) + (1 : Int)) ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3665 a b) ∨ (fact_9fdb227ae99d_4399 a b))))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ b))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n558_run_tall (a b : Int)
    (h0 : (¬ ((((((1 : Int) + a) + (3 : Int)) ≤ (b + a)) ∧ ((fact_9fdb227ae99d_7825 a b) ∨ (fact_9fdb227ae99d_7755 a b))) ∨ (((((1 : Int) + a) + (2 : Int)) ≤ (b + a)) ∧ (fact_9fdb227ae99d_7825 a b) ∧ (fact_9fdb227ae99d_7755 a b)) ∨ ((((1 : Int) + a) + (4 : Int)) ≤ (b + a)) ∨ (((b + a) = (((1 : Int) + a) + (1 : Int))) ∧ (fact_9fdb227ae99d_7825 a b) ∧ (fact_9fdb227ae99d_7755 a b) ∧ (((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_6552 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_4891 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∨ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_5821 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_3703 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_5128 a b)))) ∨ ((fact_9fdb227ae99d_7825 a b) ∧ (fact_9fdb227ae99d_7755 a b) ∧ ((fact_9fdb227ae99d_4587 a b) ∨ (fact_9fdb227ae99d_4622 a b) ∨ (fact_9fdb227ae99d_5652 a b) ∨ (fact_9fdb227ae99d_6391 a b) ∨ (fact_9fdb227ae99d_5381 a b) ∨ (fact_9fdb227ae99d_4763 a b) ∨ (fact_9fdb227ae99d_4805 a b) ∨ (fact_9fdb227ae99d_6552 a b) ∨ (fact_9fdb227ae99d_4645 a b) ∨ (fact_9fdb227ae99d_4891 a b) ∨ (fact_9fdb227ae99d_5431 a b) ∨ (fact_9fdb227ae99d_5752 a b)) ∧ ((fact_9fdb227ae99d_3630 a b) ∨ (fact_9fdb227ae99d_3639 a b) ∨ (fact_9fdb227ae99d_5038 a b) ∨ (fact_9fdb227ae99d_5791 a b) ∨ (fact_9fdb227ae99d_4413 a b) ∨ (fact_9fdb227ae99d_3682 a b) ∨ (fact_9fdb227ae99d_3687 a b) ∨ (fact_9fdb227ae99d_5821 a b) ∨ (fact_9fdb227ae99d_3646 a b) ∨ (fact_9fdb227ae99d_3703 a b) ∨ (fact_9fdb227ae99d_4493 a b) ∨ (fact_9fdb227ae99d_5128 a b))))))
    (h1 : (b = (5 : Int)))
    (h2 : (a ≥ b))
    (h3 : (b ≥ (3 : Int)))
    (h4 : (a > b))
    (h5 : (a ≥ (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n558_run_empty (a b run_x : Int)
    (h0 : ((fact_9fdb227ae99d_2416 a b run_x) ∨ (fact_9fdb227ae99d_2417 a b run_x) ∨ (fact_9fdb227ae99d_3049 a b run_x) ∨ (fact_9fdb227ae99d_3564 a b run_x) ∨ (fact_9fdb227ae99d_2972 a b run_x) ∨ (fact_9fdb227ae99d_2518 a b run_x) ∨ (fact_9fdb227ae99d_2519 a b run_x) ∨ ((((0 : Int) ≥ (((-3 : Int) + ((-1 : Int) * a)) - (0 : Int))) ∧ ((0 : Int) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ (((0 : Int) ≥ ((-3 : Int) + ((-1 : Int) * a))) ∧ ((0 : Int) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_2418 a b run_x) ∨ ((((0 : Int) ≥ ((-3 : Int) - b)) ∧ ((0 : Int) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ (0 : Int)) ∧ ((0 : Int) ≤ (-3 : Int)) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_2973 a b run_x) ∨ (fact_9fdb227ae99d_3110 a b run_x)))
    (h1 : (a ≥ (5 : Int)))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (fact_9fdb227ae99d_3207 a b))
    (h4 : (run_x ≤ (b + a)))
    (h5 : (b = (5 : Int)))
    (h6 : (fact_9fdb227ae99d_107 a b))
    (h7 : (((1 : Int) + a) ≤ run_x))
    (h8 : ((((1 : Int) + b + a) - a) ≥ (0 : Int)))
    (h9 : (a ≥ b))
    (h10 : (a > b))
    (h11 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n558_run_floor (a b run_x : Int)
    (h0 : (b = (5 : Int)))
    (h1 : (¬ ((fact_9fdb227ae99d_3171 a b run_x) ∨ (fact_9fdb227ae99d_3181 a b run_x) ∨ (fact_9fdb227ae99d_3724 a b run_x) ∨ (fact_9fdb227ae99d_5189 a b run_x) ∨ (fact_9fdb227ae99d_3483 a b run_x) ∨ (fact_9fdb227ae99d_3209 a b run_x) ∨ (fact_9fdb227ae99d_3225 a b run_x) ∨ ((((((-3 : Int) + ((-1 : Int) * a)) - (0 : Int)) ≤ ((0 : Int) - (1 : Int))) ∧ (((0 : Int) - (1 : Int)) ≤ (((-3 : Int) + ((-1 : Int) * a)) + a)) ∧ ((2 : Int) ≤ run_x) ∧ ((2 : Int) ≥ run_x)) ∨ ((((-3 : Int) + ((-1 : Int) * a)) ≤ ((0 : Int) - (1 : Int))) ∧ (((0 : Int) - (1 : Int)) ≤ ((-3 : Int) + ((-1 : Int) * a))) ∧ (((2 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((2 : Int) + b)))) ∨ (fact_9fdb227ae99d_3191 a b run_x) ∨ (((((-3 : Int) - b) ≤ ((0 : Int) - (1 : Int))) ∧ (((0 : Int) - (1 : Int)) ≤ ((-3 : Int) + (0 : Int))) ∧ ((3 : Int) ≤ run_x) ∧ ((3 : Int) ≥ run_x)) ∨ (((-3 : Int) ≤ ((0 : Int) - (1 : Int))) ∧ ((-3 : Int) ≥ ((0 : Int) - (1 : Int))) ∧ (((3 : Int) - (0 : Int)) ≤ run_x) ∧ (run_x ≤ ((3 : Int) + a)))) ∨ (fact_9fdb227ae99d_3554 a b run_x) ∨ (fact_9fdb227ae99d_3895 a b run_x))))
    (h2 : (run_x ≤ (b + a)))
    (h3 : (((1 : Int) + a) ≤ run_x))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (fact_9fdb227ae99d_107 a b))
    (h6 : (b ≥ (3 : Int)))
    (h7 : (a ≥ b))
    (h8 : (a > b))
    (h9 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n559_run_four (a b : Int)
    (h0 : (¬ (((2 : Int) + b) ≤ ((3 : Int) + a))))
    (h1 : (a ≥ b))
    (h2 : (b ≥ (3 : Int)))
    (h3 : (a > b))
    (h4 : (a ≥ (5 : Int)))
    (h5 : (b = (5 : Int)))
    (h6 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

theorem HP_optimized_unequal_nested_short_bfive_delta_two_pruned_n559_run_short (a b : Int)
    (h0 : (¬ ((((3 : Int) + a) - ((2 : Int) + b)) < b)))
    (h1 : (b ≥ (3 : Int)))
    (h2 : (a ≥ (5 : Int)))
    (h3 : (((-3 : Int) < ((-1 : Int) - a)) ∨ ((-3 : Int) > ((-1 : Int) + (0 : Int))) ∨ (((3 : Int) + a) < ((1 : Int) + ((2 : Int) * b))) ∨ (((1 : Int) + ((2 : Int) * b)) < ((3 : Int) - (0 : Int)))))
    (h4 : (a ≥ b))
    (h5 : (a > b))
    (h6 : (b = (5 : Int)))
    (h7 : (a = (b + (2 : Int))))
    : False := by
  try subst b
  try subst a
  try simp_all
  all_goals omega

end LRegionArithmetic

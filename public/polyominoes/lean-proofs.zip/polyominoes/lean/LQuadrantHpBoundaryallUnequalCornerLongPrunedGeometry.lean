import LQuadrantHpBoundaryallUnequalCornerLongPrunedArithmetic
import TilingCore
import TPlaneGeometry
import TilingSymmetry
import LHalfPlaneBoundaryTips
import LHalfPlaneAlternatingPairPruning
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
namespace PolyominoFormal.LRegion
open CrossUnits
def HP_boundaryall_unequal_corner_long_pruned_M (a b : Int) : Int := 2*(a+b+1)
def HP_boundaryall_unequal_corner_long_pruned_Box (a b x y : Int) : Prop := -HP_boundaryall_unequal_corner_long_pruned_M a b ≤ x ∧ 0≤y ∧ x≤HP_boundaryall_unequal_corner_long_pruned_M a b ∧ y≤HP_boundaryall_unequal_corner_long_pruned_M a b
def HP_boundaryall_unequal_corner_long_pruned_Inside (t : Cross) : Prop := 0≤t.y-t.south

theorem HP_boundaryall_unequal_corner_long_pruned_node001 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht2 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have in2 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have allowed2 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_corner_long_pruned_Box a b (-1 : Int) ((-1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_point a b ((by simpa only [HP_boundaryall_unequal_corner_long_pruned_Box,HP_boundaryall_unequal_corner_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) (-1 : Int) ((-1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) ((-1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_o0 a b jx jy (hlong) (hit) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_o1 a b jx jy (hstrict) (hit) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_o2 a b jx jy (hlong) (insideT) (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_o3 a b jx jy (hstrict) (sep2).2.2.1 (sep0).2.1 (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_o4 a b jx jy (insideT) (sep2).2.2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_o5 a b jx jy (hit) (hlong) (sep0).2.1 (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_o6 a b jx jy (sep2).2.2.1 (hstrict) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n001_o7 a b jx jy (insideT) (hit) (hlong) (sep2).2.2.1

theorem HP_boundaryall_unequal_corner_long_pruned_node003 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_corner_long_pruned_Box a b (-2 : Int) ((-1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_corner_long_pruned_Box,HP_boundaryall_unequal_corner_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) (-2 : Int) ((-1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) ((-1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_o0 a b jx jy (hlong) (hit) (insideT) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_o1 a b jx jy (hstrict) (hit) (sep3).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_o2 a b jx jy (insideT) (hlong) (sep3).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_o3 a b jx jy (hstrict) (sep2).2.1 (hit) (insideT) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_o4 a b jx jy (sep3).2.2.1 (hit) (hstrict) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_o5 a b jx jy (sep3).2.2.1 (insideT) (hlong) (hit) (sep2).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_o6 a b jx jy (sep3).2.2.1 (hstrict) (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n003_o7 a b jx jy (hlong) (sep3).2.2.1 (insideT) (hit)

theorem HP_boundaryall_unequal_corner_long_pruned_node005 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ht4 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap0_4 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap1_4 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap2_4 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap3_4 : Apart (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht3
  have in4 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht4
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht3
  have allowed4 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht4
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed0_4 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht0 ht4
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed1_4 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht1 ht4
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht2 ht3
  have pairAllowed2_4 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht2 ht4
  have pairAllowed3_4 := avoidPair (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht3 ht4
  have support : HP_boundaryall_unequal_corner_long_pruned_Box a b (-2 : Int) (1 : Int) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_corner_long_pruned_Box,HP_boundaryall_unequal_corner_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) (-2 : Int) (1 : Int) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) (-2 : Int) (1 : Int)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) (1 : Int) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht ht3
  have pairAllowed4 := avoidPair t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht4
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inl hit)))))
    · exact ap
  have sep4 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht4 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr (Or.inr hit)))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_o0 a b jx jy (hlong) (hb) (insideT) (hit) (sep4).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_o1 a b jx jy (hlong) (sep4).2.2.1 (hb) (sep0).2.1 (hit) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_o2 a b jx jy (hit) (sep3).2.2.1 (hb) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_o3 a b jx jy (sep2).2.1 (hstrict) (hit) (insideT) (hb) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_o4 a b jx jy (hb) (sep4).2.2.1 (hit) (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_o5 a b jx jy (sep3).2.2.1 (sep2).2.1 (hb) (insideT) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_o6 a b jx jy (insideT) (hit) (sep3).2.2.1 (hstrict) (hb)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n005_o7 a b jx jy (hlong) (hb) (sep1).2.1 (hit) (insideT)

theorem HP_boundaryall_unequal_corner_long_pruned_node004 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ht3 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_corner_long_pruned_Box a b (-2 : Int) ((-1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_corner_long_pruned_Box,HP_boundaryall_unequal_corner_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) (-2 : Int) ((-1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_empty a b ((by simpa only [Contains] using occupied)) (hb)
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) ((-1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_o0 a b jx jy (sep2).2.1 (insideT) (hit) (hlong) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2 sep3
    exact HP_boundaryall_unequal_corner_long_pruned_node005 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht3 ht ap0_1 ap0_2 ap0_3 (apart_sym sep0) ap1_2 ap1_3 (apart_sym sep1) ap2_3 (apart_sym sep2) (apart_sym sep3)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_o1 a b jx jy (hstrict) (insideT) (sep3).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_o2 a b jx jy (insideT) (sep3).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_o3 a b jx jy (insideT) (sep0).2.1 (hstrict) (hit) (sep1).2.2.1 (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_o4 a b jx jy (hstrict) (insideT) (hit) (sep3).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_o5 a b jx jy (insideT) (sep3).2.2.1 (sep2).2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_o6 a b jx jy (hit) (sep3).2.2.1 (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n004_o7 a b jx jy (sep3).2.2.1 (hit) (insideT)

theorem HP_boundaryall_unequal_corner_long_pruned_node002 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht2 : world (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have in2 := inside (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have allowed2 := avoid (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_corner_long_pruned_Box a b (-2 : Int) b := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_point a b ((by simpa only [HP_boundaryall_unequal_corner_long_pruned_Box,HP_boundaryall_unequal_corner_long_pruned_M] using absent)) (hb) (hlong)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-2 : Int) b ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-2 : Int) b ∨ Contains (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) (-2 : Int) b) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_empty a b (hb) ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-2 : Int) b support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
    rcases separate t (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_o0 a b jx jy (sep2).2.1 (hlong) (insideT) (hit) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_corner_long_pruned_node003 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_o1 a b jx jy (hit) (hlong) (hstrict) (insideT) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_o2 a b jx jy (hlong) (allowed) (sep1).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_o3 a b jx jy (insideT) (hstrict) (hlong) (hit) (sep2).2.1 (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_o4 a b jx jy (insideT) (hstrict) (hlong) (hit) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_o5 a b jx jy (sep1).2.2.1 (sep2).2.2.1 (hit) (insideT) (sep2).2.1 (hlong)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_o6 a b jx jy (sep2).2.1 (hit) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_corner_long_pruned_node004 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n002_o7 a b jx jy (hit) (hlong) (sep1).2.2.1 (allowed)

theorem HP_boundaryall_unequal_corner_long_pruned_node007 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht2 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ht3 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap0_3 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap1_3 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    (ap2_3 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have in2 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht2
  have in3 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht3
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have allowed2 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht2
  have allowed3 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht3
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed0_3 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht0 ht3
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht1 ht2
  have pairAllowed1_3 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht1 ht3
  have pairAllowed2_3 := avoidPair (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht2 ht3
  have support : HP_boundaryall_unequal_corner_long_pruned_Box a b (-1 : Int) ((-2 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_point a b (hlong) ((by simpa only [HP_boundaryall_unequal_corner_long_pruned_Box,HP_boundaryall_unequal_corner_long_pruned_M] using absent)) (hb)
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) ((-2 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) ((-2 : Int) + b) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) (-1 : Int) ((-2 : Int) + b) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) (-1 : Int) ((-2 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) ((-2 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht ht2
  have pairAllowed3 := avoidPair t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht3
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inl hit))))
    · exact ap
  have sep3 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) ht ht3 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr (Or.inr hit))))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_o0 a b jx jy (hlong) (insideT) (hit) (sep3).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_o1 a b jx jy (sep2).2.2.1 (hit) (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_o2 a b jx jy (sep3).2.1 (hit) (hlong) (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_o3 a b jx jy (hit) (insideT) (sep0).2.1 (sep3).2.2.1 (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_o4 a b jx jy (insideT) (sep3).2.2.1 (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_o5 a b jx jy (hit) (sep0).2.1 (hstrict) (sep3).2.2.1 (insideT)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_o6 a b jx jy (hstrict) (insideT) (sep2).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n007_o7 a b jx jy (sep3).2.2.1 (hlong) (hit) (insideT)

theorem HP_boundaryall_unequal_corner_long_pruned_node006 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ht2 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_2 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    (ap1_2 : Apart (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have in2 := inside (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht2
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have allowed2 := avoid (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht2
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht1
  have pairAllowed0_2 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht0 ht2
  have pairAllowed1_2 := avoidPair (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht1 ht2
  have support : HP_boundaryall_unequal_corner_long_pruned_Box a b (-1 : Int) ((-1 : Int) + b) := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_corner_long_pruned_Box,HP_boundaryall_unequal_corner_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) ((-1 : Int) + b) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) (-1 : Int) ((-1 : Int) + b)) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) ((-1 : Int) + b) support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1
  have pairAllowed2 := avoidPair t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht ht2
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact ap
  have sep2 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) ht ht2 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + b) a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_o0 a b jx jy (insideT) (hlong) (sep0).2.1 ((by simpa only [Same,eq_comm] using absent)) (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1 sep2
    exact HP_boundaryall_unequal_corner_long_pruned_node007 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht2 ht ap0_1 ap0_2 (apart_sym sep0) ap1_2 (apart_sym sep1) (apart_sym sep2)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_o1 a b jx jy (sep2).2.2.1 (insideT) (hstrict) (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_o2 a b jx jy (hit) (insideT) (sep2).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_o3 a b jx jy (hit) (sep1).2.2.1 (insideT) (hstrict) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_o4 a b jx jy (insideT) (hstrict) (sep1).2.2.1 (hit)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_o5 a b jx jy (insideT) (hit) (sep2).2.2.1 (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_o6 a b jx jy (sep2).2.2.1 (hit) (insideT) (hstrict)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n006_o7 a b jx jy (hit) (insideT) (sep2).2.2.1

theorem HP_boundaryall_unequal_corner_long_pruned_node000 (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (ht1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    (ap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have in0 := inside (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have in1 := inside (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have allowed0 := avoid (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht0
  have allowed1 := avoid (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht1
  have pairAllowed0_1 := avoidPair (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht0 ht1
  have support : HP_boundaryall_unequal_corner_long_pruned_Box a b (-1 : Int) b := by
    apply Classical.byContradiction
    intro absent
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_point a b (hb) (hlong) ((by simpa only [HP_boundaryall_unequal_corner_long_pruned_Box,HP_boundaryall_unequal_corner_long_pruned_M] using absent))
  have empty : ¬(Contains (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (-1 : Int) b ∨ Contains (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) (-1 : Int) b) := by
    intro occupied
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_empty a b ((by simpa only [Contains] using occupied))
  obtain ⟨t,ht,hit⟩ := cover (-1 : Int) b support
  have insideT := inside t ht
  have allowed := avoid t ht
  have pairAllowed0 := avoidPair t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0
  have pairAllowed1 := avoidPair t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) ht ht0 with eq | ap
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact ap
  have sep1 : Apart t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases separate t (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) ht ht1 with eq | ap
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact ap
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) b a b (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_o0 a b jx jy (hlong) (sep0).2.1 (hit) (insideT) ((by simpa only [Same,eq_comm] using absent))
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_corner_long_pruned_node001 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_o1 a b jx jy (hstrict) (hit) (insideT) (sep1).2.2.1 (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_o2 a b jx jy (hit) (hlong) (sep1).2.2.1 (allowed)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_o3 a b jx jy (insideT) (hstrict) (hit) (sep1).2.2.1 (hlong) (sep0).2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_o4 a b jx jy (hstrict) (insideT) (hit) (allowed) (sep1).2.2.1
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy (0 : Int) b a (0 : Int)) (Cross.mk (-1 : Int) (0 : Int) (0 : Int) b a (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_o5 a b jx jy (hit) (hlong) (sep1).2.2.1 ((by simpa only [Same,eq_comm] using absent)) (sep0).2.1 (insideT)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_corner_long_pruned_node002 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a (0 : Int) (0 : Int)) (Cross.mk ((-1 : Int) + ((-1 : Int) * b)) b b a (0 : Int) (0 : Int)) := by
      apply Classical.byContradiction
      intro absent
      exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_o6 a b jx jy ((by simpa only [Same,eq_comm] using absent)) (insideT) (sep0).2.1 (hit)
    have matched := alternatives
    have eq := same_eq matched
    rw [eq] at ht insideT sep0 sep1
    exact HP_boundaryall_unequal_corner_long_pruned_node006 a b ha hb hstrict hlong world copies inside cover separate avoid avoidPair ht0 ht1 ht ap0_1 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact LRegionArithmetic.HP_boundaryall_unequal_corner_long_pruned_n000_o7 a b jx jy (sep1).2.2.1 (allowed) (hit) (hlong)

theorem HP_boundaryall_unequal_corner_long_pruned_bounded_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b 0 0 t)
    (inside : ∀ t, world t → HP_boundaryall_unequal_corner_long_pruned_Inside t)
    (cover : ∀ x y, HP_boundaryall_unequal_corner_long_pruned_Box a b x y → ∃ t, world t ∧ Contains t x y)
    (disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (avoid : ∀ t, world t → ¬ForbiddenBoundaryTip a b t)
    (avoidPair : ∀ t u, world t → world u → ¬ForbiddenSameBoundaryBars a b t u)
    (anchor0 : world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor1 : world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  classical
  have sep : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases eq : t=u
    · exact Or.inl eq
    · right
      apply TPlane.apart_of_no_common_nonnegative t u
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hx hy; exact eq (disjoint t u x y ht hu hx hy)
  have rootap0_1 : Apart (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) := by
    rcases sep (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)) (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b) anchor0 anchor1 with eq | ap
    · have hx := congrArg Cross.x eq
      have hy := congrArg Cross.y eq
      dsimp only at hx hy
      omega
    · exact ap
  exact HP_boundaryall_unequal_corner_long_pruned_node000 a b ha hb hstrict hlong world copies inside cover sep avoid avoidPair anchor0 anchor1 rootap0_1

theorem HP_boundaryall_unequal_corner_long_pruned_anchored_obstruction (a b : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int)))
    (anchor1 : T.world (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b))
    : False := by
  have avoid : ∀ t, T.world t → ¬ForbiddenBoundaryTip a b t := by
    exact unequal_avoid_boundary_tips a b (by omega) (by omega) (by omega) T
  have avoidPair := avoid_same_boundary_bars a b (by omega) (by omega) (by omega) T
  apply HP_boundaryall_unequal_corner_long_pruned_bounded_obstruction a b ha hb hstrict hlong T.world T.copies ?_ ?_ T.disjoint avoid avoidPair anchor0 anchor1
  · intro t ht
    have nn := TPlane.copy_nonnegative (by omega) (by omega) (by omega) (by omega) (T.copies t ht)
    exact T.inside t ht t.x (t.y-t.south) (by
      unfold Contains; unfold TPlane.Nonnegative at nn; right; omega)
  · intro x y h; exact T.cover x y h.2.1
theorem HP_boundaryall_unequal_corner_long_pruned_no_shifted_anchor (a b p : Int)
    (ha : (a ≥ b))
    (hb : (b ≥ (3 : Int)))
    (hstrict : (a > b))
    (hlong : (a ≥ (5 : Int)))
    (T : Tiling a b 0 0 HalfPlane)
    (anchor0 : T.world (shift p 0 (Cross.mk (0 : Int) (0 : Int) a b (0 : Int) (0 : Int))))
    (anchor1 : T.world (shift p 0 (Cross.mk (1 : Int) ((1 : Int) + b) (0 : Int) (0 : Int) a b)))
    : False := by
  let U : Tiling a b 0 0 HalfPlane :=
    (T.translate (-p) 0).congr (by intro x y; simp only [HalfPlane,Int.sub_zero])
  apply HP_boundaryall_unequal_corner_long_pruned_anchored_obstruction a b ha hb hstrict hlong U
  · refine ⟨_,anchor0,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
  · refine ⟨_,anchor1,?_⟩
    apply same_eq
    unfold Same shift; dsimp
    exact ⟨by omega,by omega,rfl,rfl,rfl,rfl⟩
#print axioms HP_boundaryall_unequal_corner_long_pruned_no_shifted_anchor
#print axioms HP_boundaryall_unequal_corner_long_pruned_bounded_obstruction
end PolyominoFormal.LRegion

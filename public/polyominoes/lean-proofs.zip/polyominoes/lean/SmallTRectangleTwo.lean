import FiniteRectangle

set_option maxHeartbeats 0
set_option maxRecDepth 1000000
namespace PolyominoFormal.SmallTRectangles
open CrossUnits FiniteRectangle

def t2Tiles : List Cross := [
  ⟨0,1,1,2,0,1⟩,
  ⟨1,4,2,0,1,1⟩,
  ⟨2,0,2,1,1,0⟩,
  ⟨3,2,1,0,2,1⟩,
  ⟨4,3,1,1,2,0⟩,
  ⟨5,1,2,0,1,1⟩,
  ⟨7,2,1,1,2,0⟩,
  ⟨6,4,2,0,1,1⟩,
  ⟨8,0,1,1,2,0⟩,
  ⟨9,3,0,1,1,2⟩]

theorem t2_copies : copiesCheck t2Tiles 2 1 1 0 = true := by decide
 theorem t2_inside : insideCheck t2Tiles 10 5 = true := by decide
 theorem t2_cover : coverCheck t2Tiles 10 5 = true := by decide
 theorem t2_separate : separateCheck t2Tiles = true := by decide

theorem t2_rectangle : Tiles 2 1 1 0 (Rectangle 10 5) :=
  ⟨tilingOfChecks t2Tiles 2 1 1 0 10 5
    t2_copies t2_inside t2_cover t2_separate⟩

theorem t2_rectangle_tileable : RectangleTileable 2 1 1 0 :=
  ⟨10,5,by decide,by decide,t2_rectangle⟩
#print axioms t2_rectangle_tileable
end PolyominoFormal.SmallTRectangles

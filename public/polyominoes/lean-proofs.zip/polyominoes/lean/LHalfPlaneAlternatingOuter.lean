import LHalfPlaneAlternatingReflection
import LQuadrantHpAdjacentOuterShortPairPrunedGeometry
import LQuadrantHpSeparatedOuterShortPairAwayPrunedGeometry

namespace PolyominoFormal.LHalfPlaneAlternating
open CrossUnits LRegion
set_option maxHeartbeats 1000000

/-- The two short bars with outward stems cannot start the first row when
its arm difference is not two. Both parameter ranges have actual-world
finite obstruction proofs, with whole tiles allowed beyond the query box. -/
theorem outer_pair_away_impossible {a b : Int}
    (ha : 5≤a) (hb : 3≤b) (hab : b<a) (away : a≠b+2)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T)
    (left : T.world ⟨1,1,b,a,0,0⟩)
    (right : T.world ⟨2*b+2,1,0,a,b,0⟩) : False := by
  rcases bars with ⟨_,_,h0,h1,h2,h3,_,_⟩
  by_cases adjacent : a=b+1
  · apply HP_adjacent_outer_short_pair_pruned_anchored_obstruction a b
      (by omega) hb (by omega) ha adjacent T h0 h1 ?_ ?_ left ?_
    · simpa only [Int.add_comm] using h2
    · simpa only [Int.add_comm] using h3
    · simpa only [Int.add_comm] using right
  · apply HP_separated_outer_short_pair_away_pruned_anchored_obstruction a b
      (by omega) hb (by omega) ha (by omega) away T h0 h1 ?_ ?_ left ?_
    · simpa only [Int.add_comm] using h2
    · simpa only [Int.add_comm] using h3
    · simpa only [Int.add_comm] using right

/-- Eight alternating long boundary bars force arm difference two.
The argument uses the outer-pair obstruction only under the complementary
hypothesis, so it has no dependency on the final mixed-motif contradiction. -/
theorem delta_two {a b : Int} (ha : 5≤a) (hb : 3≤b) (hab : b<a)
    (T : Tiling a b 0 0 HalfPlane) (bars : EightBars T) : a=b+2 := by
  by_cases delta : a=b+2
  · exact delta
  · have forced : a=b+2 := by
      apply delta_two_of_outer_obstruction ha hb hab ?_ T bars
      intro U ubars pair
      exact outer_pair_away_impossible ha hb hab delta U ubars pair.1 pair.2
    exact False.elim (delta forced)

#print axioms outer_pair_away_impossible
#print axioms delta_two
end PolyominoFormal.LHalfPlaneAlternating

import TPlaneShort
import TPlaneDeep
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
namespace PolyominoFormal.TPlaneLong
open CrossUnits TBoundary THalfPlaneStarters THalfPlaneGaps THalfPlaneDeepGaps TPlaneDeep TPlaneShort

/-- The antiparallel pair is already impossible at the first cell above
its horizontal floor in the long-stem regime. -/
theorem antiparallel_reduced {a b c e s : Int} (ha : c≤a) (hc : 3≤c)
    (long : a+c+1≤b) (he : e=a ∨ e=c) (hs : s=a ∨ s=c)
    (T : Tiling a b c 0 Plane) (ho : T.world ⟨0,0,e,b,a+c-e,0⟩)
    (hu : T.world ⟨1+s,1,a+c-s,0,s,b⟩) :
    ∃r,(r=a ∨ r=c) ∧ T.world ⟨1,2+b,a+c-r,0,r,b⟩ := by
  obtain ⟨t,ht,hit⟩ := T.cover 1 2 True.intro
  have empty : ¬(Contains ⟨0,0,e,b,a+c-e,0⟩ 1 2 ∨
      Contains ⟨1+s,1,a+c-s,0,s,b⟩ 1 2) := by dsimp [Contains]; omega
  have avoid : ∀{x y}, (Contains ⟨0,0,e,b,a+c-e,0⟩ x y ∨
      Contains ⟨1+s,1,a+c-s,0,s,b⟩ x y) → ¬Contains t x y :=
    fun blocked => avoid_closed (pair_closed T ho hu) ht hit empty blocked
  obtain ⟨r,hr,forms⟩ := corner_forms (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by left; right; dsimp; omega)) (avoid (by right; left; dsimp; omega))
  rcases forms with eq | eq | eq | eq | eq | eq
  · subst t
    exfalso
    apply blocked_deep_run (L:=1) (R:=r) (h:=3) ha (by omega) (by omega)
      (by omega) (by omega) T _ (pair_closed T ho ht)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; left; right; dsimp; omega
    · intro y h0 h1; right; right; dsimp; omega
  · subst t
    have eq := T.disjoint _ _ (1+r) 1 ht hu
      (by right; dsimp; omega) (by left; dsimp; omega)
    have h := congrArg Cross.y eq; dsimp at h; omega
  · subst t
    exfalso
    let U : Tiling a b c 0 Plane := T.transpose.mirrorX
    have hu' : U.world ⟨-1,1+s,b,a+c-s,0,s⟩ := ⟨_,⟨_,hu,rfl⟩,rfl⟩
    have ht' : U.world ⟨-(2+r),1,r,b,a+c-r,0⟩ := ⟨_,⟨_,ht,rfl⟩,rfl⟩
    apply deep_left_run (L:=-(1+r)) (R:=-2) (h:=2) ha (by omega) (by omega) (by omega)
      U _ (Contains _) (pair_closed U hu' ht') (single_closed U ht') (fun _ _ h => Or.inr h)
    · intros; trivial
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; right; dsimp; omega
    · intro x h0 h1; dsimp [Contains]; omega
    · left; right; dsimp; omega
  · subst t
    have eq := T.disjoint _ _ 0 (2+r) ht ho
      (by left; dsimp; omega) (by right; dsimp; omega)
    have h := congrArg Cross.x eq; dsimp at h; omega
  · subst t
    exfalso
    apply deep_left_run (L:=1) (R:=b) (h:=3) ha (by omega) (by omega) (by omega)
      T _ (Contains _) (pair_closed T ho ht) (single_closed T ho) (fun _ _ h => Or.inl h)
    · intros; trivial
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; right; dsimp; omega
    · intro x h0 h1; dsimp [Contains]; omega
    · right; right; dsimp; omega
  · subst t; exact ⟨r,hr,ht⟩

/-- Apart from the vertical perpendicular-stem tip, the same two
crossbar corner types survive as in the short-stem argument. -/
theorem concave_reduced {a b c e : Int} (ha : c≤a) (hc : 3≤c)
    (long : a+c+1≤b) (he : e=a ∨ e=c) (T : Tiling a b c 0 Plane)
    (ho : T.world ⟨0,0,e,b,a+c-e,0⟩) {t : Cross}
    (ht : T.world t) (hit : Contains t 1 1) :
    ∃r,(r=a ∨ r=c) ∧
      (t=⟨1+r,1,a+c-r,0,r,b⟩ ∨ t=⟨1,1+r,0,a+c-r,b,r⟩ ∨
       t=⟨1,1+b,a+c-r,0,r,b⟩) := by
  have empty : ¬Contains ⟨0,0,e,b,a+c-e,0⟩ 1 1 := by dsimp [Contains]; omega
  have avoid : ∀{x y}, Contains ⟨0,0,e,b,a+c-e,0⟩ x y → ¬Contains t x y :=
    fun blocked => avoid_closed (single_closed T ho) ht hit empty blocked
  obtain ⟨r,hr,forms⟩ := corner_forms (by omega) (by omega) (by omega) (T.copies t ht) hit
    (avoid (by right; dsimp; omega)) (avoid (by left; dsimp; omega))
  rcases forms with eq | eq | eq | eq | eq | eq
  · subst t
    exfalso
    apply blocked_deep_run (L:=1) (R:=r) (h:=2) ha (by omega) (by omega)
      (by omega) (by omega) T _ (pair_closed T ho ht)
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; left; right; dsimp; omega
    · intro y h0 h1; right; right; dsimp; omega
  · exact ⟨r,hr,Or.inl eq⟩
  · subst t
    exfalso
    let U : Tiling a b c 0 Plane := T.transpose.mirrorX
    have ho' : U.world ⟨0,0,0,e,b,a+c-e⟩ := ⟨_,⟨_,ho,rfl⟩,rfl⟩
    have ht' : U.world ⟨-(1+r),1,r,b,a+c-r,0⟩ := ⟨_,⟨_,ht,rfl⟩,rfl⟩
    apply deep_left_run (L:=-r) (R:=-1) (h:=2) ha (by omega) (by omega) (by omega)
      U _ (Contains _) (pair_closed U ho' ht') (single_closed U ht') (fun _ _ h => Or.inr h)
    · intros; trivial
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; right; dsimp; omega
    · intro x h0 h1; dsimp [Contains]; omega
    · left; right; dsimp; omega
  · exact ⟨r,hr,Or.inr (Or.inl eq)⟩
  · subst t
    exfalso
    apply deep_left_run (L:=1) (R:=b) (h:=2) ha (by omega) (by omega) (by omega)
      T _ (Contains _) (pair_closed T ho ht) (single_closed T ho) (fun _ _ h => Or.inl h)
    · intros; trivial
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; right; dsimp; omega
    · intro x h0 h1; dsimp [Contains]; omega
    · right; right; dsimp; omega
  · exact ⟨r,hr,Or.inr (Or.inr eq)⟩

theorem antiparallel_impossible {a b c e s : Int} (ha : c≤a) (hc : 3≤c)
    (long : a+c+1≤b) (he : e=a ∨ e=c) (hs : s=a ∨ s=c)
    (T : Tiling a b c 0 Plane) (ho : T.world ⟨0,0,e,b,a+c-e,0⟩)
    (hu : T.world ⟨1+s,1,a+c-s,0,s,b⟩) : False := by
  obtain ⟨r,hr,ht⟩ := antiparallel_reduced ha hc long he hs T ho hu
  let U : Tiling a b c 0 Plane := T.transpose
  have hu' : U.world ⟨1,1+s,0,a+c-s,b,s⟩ := ⟨_,hu,rfl⟩
  have ht' : U.world ⟨2+b,1,0,a+c-r,b,r⟩ := ⟨_,ht,rfl⟩
  apply weak_left_run (L:=2) (R:=1+b) (h:=2) ha hc (by omega) (by omega)
    U _ (Contains _) (pair_closed U hu' ht') (single_closed U hu') (fun _ _ h => Or.inl h)
  · intros; trivial
  · intros; trivial
  · intros; trivial
  · intro x h0 h1; dsimp [Contains]; omega
  · intro x h0 h1; right; left; dsimp; omega
  · intro y h0 h1; right; dsimp; omega
  · intro x h0 h1; dsimp [Contains]; omega
  · right; right; dsimp; omega

theorem no_anchored_plane {a b c : Int} (ha : c≤a) (hc : 3≤c)
    (long : a+c+1≤b) (T : Tiling a b c 0 Plane)
    (ho : T.world ⟨0,0,a,b,c,0⟩) : False := by
  obtain ⟨t,ht,hit⟩ := T.cover 1 1 True.intro
  obtain ⟨r,hr,forms⟩ := concave_reduced ha hc long (Or.inl rfl) T
    (by simpa only [show a+c-a=c by omega] using ho) ht hit
  rcases forms with eq | eq | eq
  · subst t
    exact antiparallel_impossible ha hc long (Or.inl rfl) hr T
      (by simpa only [show a+c-a=c by omega] using ho) ht
  · subst t
    have eq := T.disjoint _ _ 0 (1+r) ht ho
      (by left; dsimp; omega) (by right; dsimp; omega)
    have h := congrArg Cross.x eq; dsimp at h; omega
  · subst t
    let U : Tiling a b c 0 Plane := T.transpose
    have ho' : U.world ⟨0,0,b,a,0,c⟩ := ⟨_,ho,rfl⟩
    have ht' : U.world ⟨1+b,1,0,a+c-r,b,r⟩ := ⟨_,ht,rfl⟩
    apply weak_left_run (L:=1) (R:=b) (h:=2) ha hc (by omega) (by omega)
      U _ (Contains _) (pair_closed U ho' ht') (single_closed U ho') (fun _ _ h => Or.inl h)
    · intros; trivial
    · intros; trivial
    · intros; trivial
    · intro x h0 h1; dsimp [Contains]; omega
    · intro x h0 h1; right; left; dsimp; omega
    · intro y h0 h1; right; dsimp; omega
    · intro x h0 h1; dsimp [Contains]; omega
    · right; right; dsimp; omega

theorem no_plane {a b c : Int} (ha : c≤a) (hc : 3≤c)
    (long : a+c+1≤b) : ¬Tiles a b c 0 Plane := by
  rintro ⟨T⟩
  obtain ⟨U,ho⟩ := normalize_plane T
  exact no_anchored_plane ha hc long U ho

/-- Every T with all three arms at least three is a plane non-tiler. -/
theorem three_arms_no_plane {a b c : Int} (ha : c≤a) (hc : 3≤c) (hb : 3≤b) :
    ¬Tiles a b c 0 Plane := by
  by_cases short : b≤a+c
  · exact TPlaneShort.no_plane ha hc hb short
  · exact no_plane ha hc (by omega)

#print axioms antiparallel_reduced
#print axioms concave_reduced
#print axioms no_plane
#print axioms three_arms_no_plane
end PolyominoFormal.TPlaneLong

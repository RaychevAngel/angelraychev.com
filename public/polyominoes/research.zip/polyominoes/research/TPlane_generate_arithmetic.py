"""Small-core arithmetic obligations for the T-plane symbolic proof trees.

Every generated Lean lemma is proved by omega; Z3 only finds useful subsets.
The semantic replay explicitly obtains each subset from the geometric state.
"""
from pathlib import Path
import itertools,json,sys,time
sys.path.insert(0,'/tmp/polyomino-research-deps')
import z3
from cross_units_verify_symbolic import V,parse,apart,covers,same
from cross_units_generate_lean import lean

def domain_for(mode):
    a,b,c,d=[V[n] for n in 'abcd']
    return [a>=c,c>=2,b>=3,d==0,c==2,b<a+3 if mode=='two_short' else b>a+3]

def generate(path):
    cert=json.loads(Path(path).read_text());assert cert['result'] is True
    mode=cert['mode'];assert mode in ('two_short','two_long')
    nodes=cert['nodes'];domain=domain_for(mode)
    a,b,c,d=[V[n] for n in 'abcd'];p=(a,b,c,d)
    orientations=[q[k:]+q[:k] for q in (p,p[::-1]) for k in range(4)]
    directory=Path('research')/f'TPlane_queries_{mode}';directory.mkdir(exist_ok=True)
    label='Short' if mode=='two_short' else 'Long'
    lines=['import Std.Tactic','set_option maxRecDepth 100000',
           'set_option maxHeartbeats 20000000','set_option linter.unusedVariables false',
           'namespace TPlaneArithmetic']
    metadata={'mode':mode,'nodes':{}};count=0;started=time.monotonic();matches={}
    def same_orientation(t,o):
        key=(str(t[2:]),str(o))
        if key not in matches:
            s=z3.Solver();s.add(*domain,z3.Not(same(t[2:],o)));matches[key]=s.check()==z3.unsat
        return matches[key]
    def query(i,name,assertions,vars):
        nonlocal count
        solver=z3.Solver();solver.add(*assertions);assert solver.check()==z3.unsat,(i,name)
        (directory/f'n{i:03d}_{name}.smt2').write_text(solver.to_smt2())
        atoms=[]
        def flatten(e,source,projection):
            if z3.is_and(e):
                n=e.num_args()
                for j,arg in enumerate(e.children()):
                    tail=('.2'*j)+('.1' if j<n-1 else '') if n>1 else ''
                    flatten(arg,source,projection+tail)
            else:atoms.append((e,source,projection))
        for j,e in enumerate(assertions):flatten(e,j,'')
        s=z3.Solver()
        for j,(e,_,_) in enumerate(atoms):s.assert_and_track(e,z3.Bool(f'k{j}'))
        assert s.check()==z3.unsat
        core=[int(str(v)[1:]) for v in s.unsat_core()]
        for j in core[:]:
            trial=[k for k in core if k!=j]
            s=z3.Solver();s.add(*[atoms[k][0] for k in trial])
            if s.check()==z3.unsat:core=trial
        core_data=[{'source':atoms[j][1],'projection':atoms[j][2],'formula':lean(atoms[j][0])} for j in core]
        metadata['nodes'].setdefault(str(i),{})[name]=core_data
        lines.extend(['',f'theorem {mode}_n{i:03d}_{name} ({" ".join(vars)} : Int)'])
        for j,data in enumerate(core_data):lines.append(f'    (h{j} : {data["formula"]})')
        lines.extend(['    : False := by','  omega']);count+=1
    for i,node in enumerate(nodes):
        tiles=[tuple(parse(v) for v in t) for t in node['tiles']]
        point=tuple(parse(v) for v in node['point'])
        region=domain+[apart(t,u) for t,u in itertools.combinations(tiles,2)]
        query(i,'empty',region+[z3.Or(*[covers(t,point) for t in tiles])],list('abcd'))
        for k,o in enumerate(orientations):
            next_tile=(*z3.Ints('jx jy'),*o)
            possible=region+[covers(next_tile,point)]+[apart(next_tile,t) for t in tiles]
            matching=[]
            for j in node.get('children',[]):
                t=tuple(parse(v) for v in nodes[j]['tiles'][-1])
                if same_orientation(t,o):matching.append((j,t))
            if matching:possible.append(z3.Not(z3.Or(*[same(next_tile,t) for _,t in matching])))
            query(i,f'o{k}',possible,list('abcd')+['jx','jy'])
            metadata['nodes'][str(i)][f'matches_o{k}']=[j for j,_ in matching]
        if i%25==0:print(mode,'nodes',i+1,'/',len(nodes),'seconds',round(time.monotonic()-started,1),flush=True)
    lines.extend(['','end TPlaneArithmetic'])
    out=Path('lean')/f'TPlane{label}Arithmetic.lean';out.write_text('\n'.join(lines)+'\n')
    metadata['query_count']=count;metadata['source_certificate']=path
    (Path('research')/f'TPlane_{mode}_cores.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(mode,'generated',count,'kernel obligations',round(time.monotonic()-started,1),'seconds',flush=True)

if __name__=='__main__':generate(sys.argv[1])

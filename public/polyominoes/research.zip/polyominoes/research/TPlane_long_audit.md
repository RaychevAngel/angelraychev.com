# Independent audit: the remaining long-stem T obstruction

Domain: `P(a,b,2,0)`, integers `a≥2` and `b>a+3`, arbitrary lattice translations and all D4 symmetries. The complete English proof is in `research/t_plane_negative.md`, section “Candidate human completion for c=2, b>A=a+3”. This audit independently accepts that argument. Its status is a reviewed English proof, not a Lean theorem.

## Productive route and a discarded normalization assumption

The constructions agent observed that the forced upper stem produces a finite row interval whose first and last cells belong to horizontal bars. The half-plane V/S exclusion arguments are local: an interior V meets the starter in its stem direction; an interior S forces a neighboring H and encloses an `a×(b−1)` rectangle in which no orientation fits. Consequently the entire interval is a word of horizontal bars.

An initial finish compared consecutive junction offsets `r,s∈{2,a}`. The intervening gap has size `A−1+s−r≥4`. Using only the small-gap lemma forced offsets to increase, seemingly leaving just `a=3,b=12`. That reduction incorrectly presumed the selected away-crossbar corner was on the original tile's long-arm side: reflecting a short-side corner changes which arm faces east. It is not a valid universal normalization. The final proof explicitly leaves the original east arm unspecified and does not use this reduction.

The boundary agent strengthened the gap lemma to *every* width `g≥3`, provided one endpoint wall extends sufficiently far into the empty side. This immediately excludes every consecutive-H gap and removes all offset casework.

## Independently checked details

* In the deep-wall lemma, the first H bar's near-arm gap has length `2` or `a`. The preceding V/S, if present, has no lateral cells one row above the boundary and reaches height `h+1+a`. The original deep wall has these same stated properties. The new H stem also reaches that height. Thus both walls meet the short-gap requirements. If no H exists, an interior V intersects an adjacent starter; adjacent S follows for widths at least four, while width three uses the deep wall at one end.
* For an antiparallel concave pair, the point `(-1,2)` admits no arm-tip cover. Horizontal and vertical crossbar cases meet the required two-wall short-gap heights. The horizontal-stem-tip case uses O's wall through `a+4≤b`. The vertical-stem-tip case uses the old row-one bar through coordinate `−a−3=−A`, exactly the required depth. Its downward stem cannot intrude into the new run.
* The corner classification retains only an away vertical crossbar with near arm two, or a perpendicular-stem tip. The two corners cannot both use perpendicular-stem tips, since the resulting bars overlap.
* The forced width-two gap yields lower H-down bar R and upper leftward-stem tile W. An upper H's upward stem hits U's row-three stem; its downward stem hits the lower starter. Two S starters overlap. W's vertical arms need not have a unique order.
* U covers W's upper-left corner by its perpendicular-stem tip. W's lower-left corner therefore forces Z with junction `(b−1,1)` and arms `(2,0,a,b)`. R and Z cover opposite ends of the length-b interval under W, and they are distinct because `b>A`.
* Every interior V meets its adjacent starter, including an H whose junction is at distance at most `a+1<b`. Every interior S forces an H junction exactly `a+1` away, enclosing an `a×(b−1)` rectangle. The supporting tiles leave the rectangle empty; edge connectivity traps any covering tile there. Both possible orientation widths, `A` and `b+1`, exceed `a`.
* Hence the interval comprises H bars and contains at least two. Two consecutive junctions enclose a gap of width `A−1+s−r≥4`. The ceiling is complete, both supporting stems extend beyond the required depth `a+2`, and they are straight in the next row. The arbitrary-width deep-wall lemma gives the contradiction.

This proves the entire remaining long-stem domain without a bounded parameter assumption or an incomplete symbolic search. The earlier partial long-domain trees remain discovery evidence only. The short domain `3≤b<a+3` instead has its separate complete 300-state certificate and Lean kernel replay, documented in `lean/TPlaneREADME.md`.

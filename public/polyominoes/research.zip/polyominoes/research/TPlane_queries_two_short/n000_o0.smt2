; benchmark generated from python API
(set-info :status unknown)
(declare-fun c () Int)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(declare-fun jy () Int)
(declare-fun jx () Int)
(assert
 (>= a c))
(assert
 (>= c 2))
(assert
 (>= b 3))
(assert
 (= d 0))
(assert
 (= c 2))
(assert
 (< b (+ a 3)))
(assert
 (let ((?x62 (+ jy b)))
 (let (($x56 (<= 1 ?x62)))
 (let (($x54 (<= (- 1) jx)))
 (let (($x59 (>= (- 1) jx)))
 (let (($x57 (<= 1 jy)))
 (let (($x64 (>= 1 jy)))
 (let ((?x66 (+ jx a)))
 (let (($x63 (<= (- 1) ?x66)))
 (or (and (>= (- 1) (- jx c)) $x63 $x64 $x57) (and $x59 $x54 (>= 1 (- jy d)) $x56)))))))))))
(assert
 (let (($x74 (or (> 0 jx) (< 0 jx) (< (+ jy b) (- 0 0)) (< (+ 0 b) (- jy d)))))
 (let (($x87 (or (< jx (- 0 2)) (< (+ 0 a) jx) (> 0 (+ jy b)) (< 0 (- jy d)))))
 (let (($x73 (or (> 0 (+ jx a)) (< 0 (- jx c)) (< jy (- 0 0)) (< (+ 0 b) jy))))
 (let (($x93 (or (< (+ jx a) (- 0 2)) (< (+ 0 a) (- jx c)) (> 0 jy) (< 0 jy))))
 (and $x93 $x73 $x87 $x74))))))
(assert
 (let (($x111 (= 1 jy)))
(let ((?x98 (+ (- 1) (* (- 1) a))))
(let (($x116 (= jx ?x98)))
(let (($x115 (and $x116 $x111 (= a a) (= b b) (= 2 c) (= 0 d))))
(not (or $x115)))))))
(check-sat)

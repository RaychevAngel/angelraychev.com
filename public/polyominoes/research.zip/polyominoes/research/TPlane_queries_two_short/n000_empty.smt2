; benchmark generated from python API
(set-info :status unknown)
(declare-fun c () Int)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(assert
 (>= a c))
(assert
 (>= c 2))
(assert
 (>= b 3))
(assert
 (= d 0))
(assert
 (= c 2))
(assert
 (< b (+ a 3)))
(assert
 (let (($x34 (and (<= 0 (- 1)) (<= (- 1) 0) (>= 1 (- 0 0)) (<= 1 (+ 0 b)))))
(let (($x29 (and (>= (- 1) (- 0 2)) (<= (- 1) (+ 0 a)) (<= 0 1) (<= 1 0))))
(or (or $x29 $x34)))))
(check-sat)

; benchmark generated from python API
(set-info :status unknown)
(declare-fun c () Int)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(assert
 (>= a c))
(assert
 (>= c 2))
(assert
 (>= b 3))
(assert
 (= d 0))
(assert
 (= c 2))
(assert
 (let ((?x17 (+ a 3)))
 (< b ?x17)))
(assert
 (let (($x871 (< (- 1) 0)))
 (let (($x1009 (< 0 (- 1))))
 (let (($x1003 (or $x1009 $x871 (< (+ 0 b) (- (+ 1 a) a)) (< (+ (+ 1 a) 2) (- 0 0)))))
 (let ((?x1042 (+ (- 1) b)))
 (let (($x1095 (> 0 ?x1042)))
 (let ((?x1329 (- (- 1) 0)))
 (let (($x1134 (< 0 ?x1329)))
 (let (($x361 (or $x1134 $x1095 (< (+ 0 b) (+ 1 a)) (< (+ 1 a) (- 0 0)))))
 (let ((?x20 (- 0 2)))
 (let (($x355 (< (- 1) ?x20)))
 (let ((?x22 (+ 0 a)))
 (let (($x1433 (> (- 1) ?x22)))
 (let (($x1636 (or $x1433 $x355 (< 0 (- (+ 1 a) a)) (> 0 (+ (+ 1 a) 2)))))
 (let (($x1027 (or (< ?x22 ?x1329) (< ?x1042 ?x20) (< 0 (+ 1 a)) (> 0 (+ 1 a)))))
 (and $x1027 $x1636 $x361 $x1003))))))))))))))))
(assert
 (let (($x328 (and (<= (- 1) 1) (<= 1 (- 1)) (>= 1 (- (+ 1 a) a)) (<= 1 (+ (+ 1 a) 2)))))
(let ((?x1042 (+ (- 1) b)))
(let (($x813 (<= 1 ?x1042)))
(let (($x1869 (and (>= 1 (- (- 1) 0)) $x813 (>= 1 (+ 1 a)) (<= 1 (+ 1 a)))))
(let ((?x24 (+ 0 b)))
(let (($x33 (<= 1 ?x24)))
(let ((?x23 (- 0 0)))
(let (($x32 (>= 1 ?x23)))
(let (($x28 (<= 1 0)))
(let (($x27 (<= 0 1)))
(let (($x1075 (or (and (>= 1 (- 0 2)) (<= 1 (+ 0 a)) $x27 $x28) (and $x27 $x28 $x32 $x33))))
(or $x1075 (or $x1869 $x328))))))))))))))
(check-sat)

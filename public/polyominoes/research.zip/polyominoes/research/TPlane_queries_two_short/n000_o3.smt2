; benchmark generated from python API
(set-info :status unknown)
(declare-fun c () Int)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(declare-fun jy () Int)
(declare-fun jx () Int)
(assert
 (>= a c))
(assert
 (>= c 2))
(assert
 (>= b 3))
(assert
 (= d 0))
(assert
 (= c 2))
(assert
 (< b (+ a 3)))
(assert
 (let ((?x126 (+ jy a)))
 (let (($x130 (<= 1 ?x126)))
 (let (($x54 (<= (- 1) jx)))
 (let (($x59 (>= (- 1) jx)))
 (let (($x57 (<= 1 jy)))
 (let (($x64 (>= 1 jy)))
 (or (and (>= (- 1) (- jx b)) (<= (- 1) (+ jx d)) $x64 $x57) (and $x59 $x54 (>= 1 (- jy c)) $x130)))))))))
(assert
 (let (($x83 (< 0 jx)))
 (let (($x82 (> 0 jx)))
 (let (($x310 (or $x82 $x83 (< (+ jy a) (- 0 0)) (< (+ 0 b) (- jy c)))))
 (let ((?x22 (+ 0 a)))
 (let (($x90 (< ?x22 jx)))
 (let ((?x20 (- 0 2)))
 (let (($x68 (< jx ?x20)))
 (let ((?x24 (+ 0 b)))
 (let (($x77 (< ?x24 jy)))
 (let ((?x23 (- 0 0)))
 (let (($x81 (< jy ?x23)))
 (let (($x69 (< 0 jy)))
 (let (($x72 (> 0 jy)))
 (and (or (< (+ jx d) ?x20) (< ?x22 (- jx b)) $x72 $x69) (or (> 0 (+ jx d)) (< 0 (- jx b)) $x81 $x77) (or $x68 $x90 (> 0 (+ jy a)) (< 0 (- jy c))) $x310)))))))))))))))
(assert
 (let (($x44 (= 2 c)))
(let (($x132 (= b b)))
(let (($x37 (= a a)))
(let (($x122 (= 0 d)))
(let (($x251 (= 3 jy)))
(let (($x163 (= (- 1) jx)))
(not (or (and $x163 $x251 $x122 $x37 $x132 $x44))))))))))
(check-sat)

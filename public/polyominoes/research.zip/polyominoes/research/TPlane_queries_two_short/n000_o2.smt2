; benchmark generated from python API
(set-info :status unknown)
(declare-fun c () Int)
(declare-fun a () Int)
(declare-fun b () Int)
(declare-fun d () Int)
(declare-fun jy () Int)
(declare-fun jx () Int)
(assert
 (>= a c))
(assert
 (>= c 2))
(assert
 (>= b 3))
(assert
 (= d 0))
(assert
 (= c 2))
(assert
 (< b (+ a 3)))
(assert
 (let (($x54 (<= (- 1) jx)))
 (let (($x59 (>= (- 1) jx)))
 (let (($x57 (<= 1 jy)))
 (let (($x64 (>= 1 jy)))
 (or (and (>= (- 1) (- jx a)) (<= (- 1) (+ jx c)) $x64 $x57) (and $x59 $x54 (>= 1 (- jy b)) (<= 1 (+ jy d)))))))))
(assert
 (let (($x83 (< 0 jx)))
 (let (($x82 (> 0 jx)))
 (let (($x49 (or $x82 $x83 (< (+ jy d) (- 0 0)) (< (+ 0 b) (- jy b)))))
 (let ((?x22 (+ 0 a)))
 (let (($x90 (< ?x22 jx)))
 (let ((?x20 (- 0 2)))
 (let (($x68 (< jx ?x20)))
 (let ((?x24 (+ 0 b)))
 (let (($x77 (< ?x24 jy)))
 (let ((?x23 (- 0 0)))
 (let (($x81 (< jy ?x23)))
 (let (($x69 (< 0 jy)))
 (let (($x72 (> 0 jy)))
 (and (or (< (+ jx c) ?x20) (< ?x22 (- jx a)) $x72 $x69) (or (> 0 (+ jx c)) (< 0 (- jx a)) $x81 $x77) (or $x68 $x90 (> 0 (+ jy d)) (< 0 (- jy b))) $x49)))))))))))))))
(assert
 (let (($x132 (= b b)))
(let (($x37 (= a a)))
(let (($x122 (= 0 d)))
(let (($x44 (= 2 c)))
(let ((?x50 (+ 1 b)))
(let (($x124 (= jy ?x50)))
(let (($x163 (= (- 1) jx)))
(let (($x243 (or (and (= (- 3) jx) (= 1 jy) $x44 $x122 $x37 $x132) (and $x163 $x124 $x44 $x122 $x37 $x132))))
(not $x243))))))))))
(check-sat)

"""Generate semantic infinite-plane Lean replay of the symbolic proof trees."""
from pathlib import Path
import itertools,json,sys
sys.path.insert(0,'/tmp/polyomino-research-deps')
import z3
from cross_units_verify_symbolic import V,parse,same
from cross_units_generate_lean import lean
from TPlane_generate_arithmetic import domain_for

HEADER='''import CrossUnitsAdjacentArithmetic
import CrossUnitsOneArithmetic

set_option maxRecDepth 100000
set_option maxHeartbeats 2000000

namespace CrossUnits

structure Cross where
  x : Int
  y : Int
  east : Int
  north : Int
  west : Int
  south : Int

/-- A cross is the union of its two closed intervals of integer cells. -/
def Contains (t : Cross) (x y : Int) : Prop :=
  (t.x-t.west ≤ x ∧ x ≤ t.x+t.east ∧ t.y ≤ y ∧ y ≤ t.y) ∨
  (t.x ≤ x ∧ x ≤ t.x ∧ t.y-t.south ≤ y ∧ y ≤ t.y+t.north)

/-- Cartesian separation of each of the four pairs of horizontal/vertical rods. -/
def Apart (t u : Cross) : Prop :=
  (t.x+t.east < u.x-u.west ∨ u.x+u.east < t.x-t.west ∨ t.y < u.y ∨ u.y < t.y) ∧
  (t.x+t.east < u.x ∨ u.x < t.x-t.west ∨ t.y < u.y-u.south ∨ u.y+u.north < t.y) ∧
  (t.x < u.x-u.west ∨ u.x+u.east < t.x ∨ t.y+t.north < u.y ∨ u.y < t.y-t.south) ∧
  (t.x < u.x ∨ u.x < t.x ∨ t.y+t.north < u.y-u.south ∨ u.y+u.north < t.y-t.south)

def Same (t u : Cross) : Prop :=
  t.x=u.x ∧ t.y=u.y ∧ t.east=u.east ∧ t.north=u.north ∧ t.west=u.west ∧ t.south=u.south

theorem same_eq {t u : Cross} (h : Same t u) : t=u := by
  cases t; cases u
  rcases h with ⟨hx,hy,he,hn,hw,hs⟩
  cases hx; cases hy; cases he; cases hn; cases hw; cases hs
  rfl

theorem swap_or {p q r s : Prop} (h : p ∨ q ∨ r ∨ s) : q ∨ p ∨ s ∨ r := by
  rcases h with h | h | h | h
  · exact Or.inr (Or.inl h)
  · exact Or.inl h
  · exact Or.inr (Or.inr (Or.inr h))
  · exact Or.inr (Or.inr (Or.inl h))

theorem apart_sym {t u : Cross} (h : Apart t u) : Apart u t := by
  rcases h with ⟨hh,hv,vh,vv⟩
  exact ⟨swap_or hh,swap_or vh,swap_or hv,swap_or vv⟩

def Positive (t : Cross) : Prop :=
  1≤t.east ∧ 1≤t.north ∧ 1≤t.west ∧ 1≤t.south

/-- For positive crosses the Cartesian condition follows from ordinary
    cellwise disjointness; it is not an extra packing assumption. -/
theorem apart_of_no_common (t u : Cross) (pt : Positive t) (pu : Positive u)
    (empty : ∀ x y, Contains t x y → Contains u x y → False) : Apart t u := by
  rcases pt with ⟨te,tn,tw,ts⟩
  rcases pu with ⟨ue,un,uw,us⟩
  refine ⟨?_,?_,?_,?_⟩
  · apply Classical.byContradiction
    intro blocked
    by_cases hleft : t.x-t.west ≤ u.x-u.west
    · apply empty (u.x-u.west) t.y
      · left; exact ⟨hleft,by omega,by omega,by omega⟩
      · left; exact ⟨by omega,by omega,by omega,by omega⟩
    · apply empty (t.x-t.west) t.y
      · left; exact ⟨by omega,by omega,by omega,by omega⟩
      · left; exact ⟨by omega,by omega,by omega,by omega⟩
  · apply Classical.byContradiction
    intro blocked
    apply empty u.x t.y
    · left; exact ⟨by omega,by omega,by omega,by omega⟩
    · right; exact ⟨by omega,by omega,by omega,by omega⟩
  · apply Classical.byContradiction
    intro blocked
    apply empty t.x u.y
    · right; exact ⟨by omega,by omega,by omega,by omega⟩
    · left; exact ⟨by omega,by omega,by omega,by omega⟩
  · apply Classical.byContradiction
    intro blocked
    by_cases hbottom : t.y-t.south ≤ u.y-u.south
    · apply empty t.x (u.y-u.south)
      · right; exact ⟨by omega,by omega,hbottom,by omega⟩
      · right; exact ⟨by omega,by omega,by omega,by omega⟩
    · apply empty t.x (t.y-t.south)
      · right; exact ⟨by omega,by omega,by omega,by omega⟩
      · right; exact ⟨by omega,by omega,by omega,by omega⟩

def Arms (t : Cross) (a b c d : Int) : Prop :=
  t.east=a ∧ t.north=b ∧ t.west=c ∧ t.south=d

def Copy (a b c d : Int) (t : Cross) : Prop :=
  Arms t a b c d ∨ Arms t b c d a ∨ Arms t c d a b ∨ Arms t d a b c ∨
  Arms t d c b a ∨ Arms t c b a d ∨ Arms t b a d c ∨ Arms t a d c b

theorem copy_positive {a b c d : Int} {t : Cross}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d)
    (h : Copy a b c d t) : Positive t := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals unfold Positive
  all_goals exact ⟨by omega,by omega,by omega,by omega⟩

'''

_positive_section='def Positive'+HEADER.split('def Positive',1)[1].split('def Arms',1)[0]
_positive_section=_positive_section.replace('Positive','Nonnegative').replace('1≤','0≤').replace('apart_of_no_common','apart_of_no_common_nonnegative')
_copy_section='theorem copy_positive'+HEADER.split('theorem copy_positive',1)[1]
_copy_section=_copy_section.replace('copy_positive','copy_nonnegative').replace('Positive','Nonnegative').replace('1≤','0≤')
HEADER='''import CrossUnitsGeometry
import TPlaneShortArithmetic
import TPlaneLongArithmetic
set_option maxRecDepth 100000
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false
namespace TPlane
open CrossUnits
'''+_positive_section+_copy_section

def main(paths):
    modes=[json.loads(Path(path).read_text())['mode'] for path in paths]
    header=HEADER
    if 'two_short' not in modes:header=header.replace('import TPlaneShortArithmetic\n','')
    if 'two_long' not in modes:header=header.replace('import TPlaneLongArithmetic\n','')
    lines=[header]
    a,b,c,d=[V[n] for n in 'abcd'];p=(a,b,c,d)
    orientations=[q[k:]+q[:k] for q in (p,p[::-1]) for k in range(4)]
    def expr(v):return lean(v)
    def tile(t):return '(Cross.mk '+' '.join(expr(v) for v in t)+')'
    def inject(i,n,proof):
        if n==1:return proof
        return '(Or.inr '+inject(i-1,n-1,proof)+')' if i else '(Or.inl '+proof+')'
    for path in paths:
        cert=json.loads(Path(path).read_text());mode=cert['mode'];nodes=cert['nodes']
        metadata=json.loads(Path(f'research/TPlane_{mode}_cores.json').read_text())
        domain=domain_for(mode)
        constraints=['c≤a','2≤c','3≤b','d=0','c=2','b<a+3' if mode=='two_short' else 'a+3<b']
        dom_names=['ha','hc','hb','hd','hceq','hbound']
        for i in reversed(range(len(nodes))):
            node=nodes[i]
            def core_args(name,sources):
                terms=[]
                for item in metadata['nodes'][str(i)][name]:
                    source=sources[item['source']]
                    terms.append('('+source+')'+item['projection'] if item['projection'] else '('+source+')')
                return ' '.join(terms)
            tiles=[tuple(parse(v) for v in t) for t in node['tiles']]
            T=[tile(t) for t in tiles]
            point=tuple(parse(v) for v in node['point']);px,py=map(expr,point)
            pairs=list(itertools.combinations(range(len(T)),2))
            pair_names=[f'ap{x}{y}' for x,y in pairs]
            common=' '.join(dom_names+['world','copies','cover','separate'])
            lines += [f'theorem {mode}_node{i:03d} (a b c d : Int)']
            lines += [f'    ({n} : {f})' for n,f in zip(dom_names,constraints)]
            lines += ['    (world : Cross → Prop)',
                      '    (copies : ∀ t, world t → Copy a b c d t)',
                      '    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)',
                      '    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)']
            lines += [f'    (ht{j} : world {t})' for j,t in enumerate(T)]
            lines += [f'    ({name} : Apart {T[x]} {T[y]})' for name,(x,y) in zip(pair_names,pairs)]
            lines += ['    : False := by','  classical']
            old_cover=' ∨ '.join(f'Contains {t} {px} {py}' for t in T)
            lines += [f'  have empty : ¬ ({old_cover}) := by',
                      '    intro occupied',
                      f'    exact TPlaneArithmetic.{mode}_n{i:03d}_empty a b c d '+core_args('empty',dom_names+pair_names+['(by simpa only [Contains, or_assoc] using occupied)']),
                      f'  obtain ⟨t, ht, hit⟩ := cover {px} {py}']
            for j,t in enumerate(T):
                lines += [f'  have sep{j} : Apart t {t} := by',
                          f'    rcases separate t {t} ht ht{j} with heq | hs',
                          '    · subst t',f'      exact False.elim (empty {inject(j,len(T),"hit")})',
                          '    · exact hs']
            lines += ['  rcases t with ⟨jx,jy,e,n,w,s⟩',
                      '  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho']
            for k,o in enumerate(orientations):
                nextT=tile((z3.Int('jx'),z3.Int('jy'),*o))
                matching=[]
                for j in metadata['nodes'][str(i)][f'matches_o{k}']:
                    u=tuple(parse(v) for v in nodes[j]['tiles'][-1])
                    matching.append((j,u))
                lines += ['  · rcases ho with ⟨he,hn,hw,hs⟩',
                          '    dsimp only at he hn hw hs',
                          '    subst e; subst n; subst w; subst s']
                antecedent=dom_names+pair_names+['hit']+[f'sep{j}' for j in range(len(T))]
                arith=f'TPlaneArithmetic.{mode}_n{i:03d}_o{k} a b c d jx jy'
                if not matching:
                    lines += ['    exact '+arith+' '+core_args(f'o{k}',antecedent)]
                    continue
                disj=' ∨ '.join(f'Same {nextT} {tile(u)}' for _,u in matching)
                lines += [f'    have alternatives : {disj} := by',
                          '      apply Classical.byContradiction',
                          '      intro absent',
                          '      exact '+arith+' '+core_args(f'o{k}',antecedent+['(by simpa only [Same, eq_comm] using absent)'])]
                if len(matching)>1:lines += ['    rcases alternatives with '+ ' | '.join('matched' for _ in matching)]
                else:lines += ['    have matched := alternatives']
                for j,u in matching:
                    indent='    ' if len(matching)==1 else '    · '
                    lines += [indent+'have equal := same_eq matched']
                    base='    ' if len(matching)==1 else '      '
                    lines += [base+'rw [equal] at ht '+ ' '.join(f'sep{q}' for q in range(len(T)))]
                    newpairnames=pair_names+[f'(apart_sym sep{q})' for q in range(len(T))]
                    # itertools.combinations puts the new-pair edge after each
                    # old row, not at the end of the list.
                    child_pairs=list(itertools.combinations(range(len(T)+1),2))
                    old_lookup={pair:name for pair,name in zip(pairs,pair_names)}
                    cp=[old_lookup[(x,y)] if y<len(T) else f'(apart_sym sep{x})' for x,y in child_pairs]
                    args=dom_names+['world','copies','cover','separate']+[f'ht{q}' for q in range(len(T))]+['ht']+cp
                    lines += [base+f'exact {mode}_node{j:03d} a b c d '+' '.join(args)]
            lines += ['']
        lines += [f'/-- No cellwise-disjoint full-plane tiling contains the normalized T in domain {mode} at the origin. -/',
                  f'theorem {mode}_no_anchored_plane (a b c d : Int)']
        lines += [f'    ({n} : {f})' for n,f in zip(dom_names,constraints)]
        lines += ['    (world : Cross → Prop)',
                  '    (copies : ∀ t, world t → Copy a b c d t)',
                  '    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)',
                  '    (cell_disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)',
                  '    (anchor : world (Cross.mk 0 0 a b c d)) : False := by',
                  '  classical',
                  '  have separate : ∀ t u, world t → world u → t=u ∨ Apart t u := by',
                  '    intro t u ht hu',
                  '    by_cases equal : t=u',
                  '    · exact Or.inl equal',
                  '    · right',
                  '      apply apart_of_no_common_nonnegative t u',
                  '      · exact copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies t ht)',
                  '      · exact copy_nonnegative (by omega) (by omega) (by omega) (by omega) (copies u hu)',
                  '      · intro x y hit_t hit_u',
                  '        exact equal (cell_disjoint t u x y ht hu hit_t hit_u)',
                  f'  exact {mode}_node000 a b c d '+' '.join(dom_names)+' world copies cover separate (by simpa only [hceq,hd] using anchor)',
                  f'#print axioms {mode}_no_anchored_plane','']
    lines += ['end TPlane']
    Path('lean/TPlaneGeometry.lean').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':main(sys.argv[1:])

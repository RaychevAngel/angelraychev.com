# Publication proof-package audit

Checked the proof appendix builder, generated appendix, main manuscript, Lean guides, both proof-specific manifests, and source-bundle selection. All 18 recorded proof-source hashes match their files; no declared axiom, admitted proof, or unsafe declaration was found in the Lean sources. The formal theorem scopes remain truthful. Detailed hash readback is `research/TPlane_publication_audit.json`.

## Completed guide correction

Updated `lean/README.md` to include the completed short-T theorem, 300 states and 2,700 arithmetic lemmas, nonnegative-arm geometry, ordinary cellwise disjointness, all D4 orientations, unrestricted infinite-world coverage, and the explicitly English anchor normalization. The guide distinguishes the English long-T proof from the Lean theorem. All commands now use a stated project-root working directory and portable Lean 4.33.1 on PATH; machine runtime availability is explained separately.

The guide's artifact references all resolve. The two specific guides `lean/CrossUnitsREADME.md` and `lean/TPlaneREADME.md` also have no unresolved artifact references.

## Concrete changes sent to the publication owner

These observations refer to the pre-rebuild snapshot, so the owner may have corrected them subsequently:

1. The generated appendix called the completed T Lean proof “being prepared” and omitted the final long-c2 proof. The research source preserves earlier chronological status language; the publication builder should substitute the final status and rebuild after all source updates.
2. Appendix section six was titled for three arms at least three although it also contained c2 cases. Rename it to cover all negative T-plane cases. The builder's old candidate-status cleanup did not recognize the newly added long-c2 heading or pending-review paragraph.
3. The R-to-rep construction must choose `k>1` divisible by the rectangle sides. Divisibility alone could choose k=1 for the monomino, which is not a strictly enlarged copy.
4. The manuscript opening and repository README still described the classification as incomplete or ongoing.
5. The source ZIP deliberately excludes raster files, including the historical Y-hexomino source GIF required by the optional raster extractor. Either include that provenance image or tell readers to download the linked original under the expected filename and install optional Pillow. The saved exact-coordinate witness does not need the raster or Pillow.
6. Bare `t_construct_*` artifact names in the appendix should include their `research/` prefix. The half-plane certificate name `results/t_hpcert_a_b_1.json` is a template, not an actual file; make the placeholders explicit or give an example.
7. The supplied L-paper filenames refer to external originals, not bundled files. Direct published links are `/polyominoes/raychev-2021-l-quadrant.pdf` and `/polyominoes/raychev-2021-l-half-plane.pdf`.

No broken Markdown hyperlink was found in the generated appendix at this checkpoint. A final archive readback should verify its own generated manifest after the publication owner finishes editing; the bundle builder already performs that full readback.

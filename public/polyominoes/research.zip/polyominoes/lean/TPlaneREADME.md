# Short-stem two-arm T obstruction: kernel verification

`TPlane.two_short_no_anchored_plane` rules out a tiling of the integer plane
by `P(a,b,2,0)` for every integer `a≥2` and `3≤b<a+3`.

It quantifies over an arbitrary set of placed tiles, every one of the eight
D4 orientations, coverage of every integer cell, and ordinary cellwise
disjointness. There is no bound on tile count, periods, or parameters. The
proof permits arbitrary integer junctions when it exhausts the copies that
could cover its selected cell.

The theorem assumes that the normalized prototile at the origin belongs to
the tiling. An arbitrary tiling can be brought to this form by choosing one
tile and applying a global translation and inverse D4 symmetry. That
normalization is supplied in English; it is not formalized here.

The semantic proof replays a complete tree of 300 states, with at most seven
additional tiles beyond the anchor. Its 2,700 arithmetic lemmas consist of
one emptiness lemma and eight orientation-specific completeness lemmas per
state. Every arithmetic lemma is proved by Lean's `omega`. Z3 was used to
discover the tree and minimize arithmetic hypotheses; it is not trusted by
the final kernel proof.

The geometry imports the Cartesian cross representation and D4 definition
from `CrossUnitsGeometry.lean`. A separate proved interval-intersection
lemma accepts **nonnegative** arms, so the T's zero fourth arm is handled
explicitly. It derives the rectangle-separation predicate from ordinary
cellwise disjointness. The final theorem is about the actual infinite
covering problem, not merely a collection of arithmetic contradictions.

Verified with Lean 4.33.1. First compile the dependencies as described in
`CrossUnitsREADME.md`, then run from the project root:

```sh
.tools/lean-4.33.1-darwin_aarch64/bin/lean -o lean/TPlaneShortArithmetic.olean lean/TPlaneShortArithmetic.lean
LEAN_PATH=lean .tools/lean-4.33.1-darwin_aarch64/bin/lean -o lean/TPlaneGeometry.olean lean/TPlaneGeometry.lean
```

Both commands succeeded. The final axiom inspection reports:

```text
'TPlane.two_short_no_anchored_plane' depends on axioms: [propext, Classical.choice, Quot.sound]
```

There are no `sorry`, `admit`, additional axioms, or trusted solver results
in this proof. The `.olean` outputs are disposable build artifacts (roughly
251 MB); retain the source and certificates as the durable proof.

Proof sources and evidence:

* `results/t_plane_negative_corners_two_short_d10.json`: complete tree;
* `src/t_plane_negative_verify_symbolic.py`: independent arbitrary-junction
  rectangular-rod verifier, which passed all 2,218 checks;
* `research/TPlane_generate_arithmetic.py` and
  `research/TPlane_generate_geometry.py`: source generators;
* `research/TPlane_two_short_cores.json` and `research/TPlane_queries_two_short/`:
  retained arithmetic cores and standalone SMT queries;
* `research/TPlane_short_arithmetic_compile.log` and
  `research/TPlane_geometry_compile.log`: successful compiler logs;
* `research/TPlane_verified_manifest.json`: hashes and exact proof boundary.

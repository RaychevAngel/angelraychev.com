# Unit-arm cross obstruction: kernel verification

The two theorems in `CrossUnitsGeometry.lean` rule out a plane tiling by:

* `P(1,1,c,d)` for all integers `2≤c≤d`;
* `P(a,1,c,d)` for all integers `2≤a≤c` and `d≥2`.

They quantify over an arbitrary set of placed crosses, all eight D4 arm
orientations, coverage of every integer cell, and ordinary cellwise
disjointness. No bound is placed on the number of tiles, periods, or arm
lengths. A proved interval-intersection lemma derives the Cartesian
separation condition used internally.

Both theorems explicitly assume that the normalized prototile at the origin
belongs to the tiling. To apply them to any plane tiling, choose a tile and
apply a global translation and inverse D4 symmetry. This elementary
normalization is supplied in English; it is not claimed to be formalized in
these files.

The semantic proof follows finite exhaustive trees of 57 and 89 states. Each
state chooses an empty cell and exhausts every possible covering D4 cross,
with an arbitrary integer junction. The 1,314 arithmetic lemmas used in that
replay are proved by Lean's `omega`, with no solver oracle or added axiom.

Verified using Lean 4.33.1. From the project root:

```sh
.tools/lean-4.33.1-darwin_aarch64/bin/lean -o lean/CrossUnitsAdjacentArithmetic.olean lean/CrossUnitsAdjacentArithmetic.lean
.tools/lean-4.33.1-darwin_aarch64/bin/lean -o lean/CrossUnitsOneArithmetic.olean lean/CrossUnitsOneArithmetic.lean
LEAN_PATH=lean .tools/lean-4.33.1-darwin_aarch64/bin/lean -o lean/CrossUnitsGeometry.olean lean/CrossUnitsGeometry.lean
```

All three commands succeeded. The final output is:

```text
'CrossUnits.adjacent_no_anchored_plane' depends on axioms: [propext, Classical.choice, Quot.sound]
'CrossUnits.one_no_anchored_plane' depends on axioms: [propext, Classical.choice, Quot.sound]
```

The JSON case trees, independent rectangular-rod verifier, standalone SMT-LIB
queries, generators, compiler logs, human-readable case tables, and research
history are the `research/cross_units*` files. Z3 was used to discover the
trees and minimize hypotheses. Lean independently checks all retained
arithmetic contradictions and the full infinite-plane case-tree argument.

The `.olean` files are disposable build artifacts; the two arithmetic files
produce roughly 112 MB of compiled output. The source files and certificates
are the durable proof artifacts.

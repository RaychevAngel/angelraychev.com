import Std.Tactic

/-!
An actual geometric tiling obstruction, with no restriction on the number of
tiles or on the arm lengths. Coordinates denote unit cells of the integer grid.
Rotations and reflections are covered because every placed cross is represented
by its own four positive arm lengths.
-/

namespace Polyominoes

structure Cross where
  x : Int
  y : Int
  east : Int
  north : Int
  west : Int
  south : Int

def Cross.contains (t : Cross) (x y : Int) : Prop :=
  (y = t.y ∧ t.x - t.west ≤ x ∧ x ≤ t.x + t.east) ∨
  (x = t.x ∧ t.y - t.south ≤ y ∧ y ≤ t.y + t.north)

def Cross.positive (t : Cross) : Prop :=
  1 ≤ t.east ∧ 1 ≤ t.north ∧ 1 ≤ t.west ∧ 1 ≤ t.south

theorem boundary_tip (t : Cross) (hp : t.positive)
    (inside : ∀ x y, t.contains x y → 0 ≤ y)
    (x : Int) (h : t.contains x 0) :
    t.x = x ∧ 1 ≤ t.y ∧ t.y - t.south = 0 := by
  rcases hp with ⟨he, hn, hw, hs⟩
  have bottom : t.contains t.x (t.y - t.south) := by
    right
    exact ⟨rfl, by omega, by omega⟩
  have hb := inside _ _ bottom
  rcases h with h | h
  · rcases h with ⟨hy, _, _⟩
    omega
  · rcases h with ⟨hx, hlo, hhi⟩
    omega

/-- No family of positive-arm crosses tiles the upper half-plane.
    The index type is arbitrary, so this includes infinite tilings. -/
theorem no_half_plane_tiling {I : Type} (tiles : I → Cross)
    (positive : ∀ i, (tiles i).positive)
    (inside : ∀ i x y, (tiles i).contains x y → 0 ≤ y)
    (cover : ∀ x y : Int, 0 ≤ y → ∃ i, (tiles i).contains x y)
    (disjoint : ∀ i j x y,
      (tiles i).contains x y → (tiles j).contains x y → i = j) : False := by
  obtain ⟨i, hi⟩ := cover 0 0 (by omega)
  obtain ⟨j, hj⟩ := cover 1 0 (by omega)
  obtain ⟨ix, iy, ib⟩ := boundary_tip (tiles i) (positive i) (inside i) 0 hi
  obtain ⟨jx, jy, jb⟩ := boundary_tip (tiles j) (positive j) (inside j) 1 hj
  have different : i ≠ j := by
    intro h
    subst j
    omega
  rcases positive i with ⟨ie, inn, iw, iss⟩
  rcases positive j with ⟨je, jn, jw, js⟩
  by_cases hheight : (tiles i).y ≤ (tiles j).y
  · have hit_i : (tiles i).contains 1 (tiles i).y := by
      left
      exact ⟨rfl, by omega, by omega⟩
    have hit_j : (tiles j).contains 1 (tiles i).y := by
      right
      exact ⟨by omega, by omega, by omega⟩
    exact different (disjoint i j _ _ hit_i hit_j)
  · have hit_i : (tiles i).contains 0 (tiles j).y := by
      right
      exact ⟨by omega, by omega, by omega⟩
    have hit_j : (tiles j).contains 0 (tiles j).y := by
      left
      exact ⟨rfl, by omega, by omega⟩
    exact different (disjoint i j _ _ hit_i hit_j)

#print axioms no_half_plane_tiling

end Polyominoes

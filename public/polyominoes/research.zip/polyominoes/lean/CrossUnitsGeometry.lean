import CrossUnitsAdjacentArithmetic
import CrossUnitsOneArithmetic

set_option maxRecDepth 100000
set_option maxHeartbeats 2000000

namespace CrossUnits

structure Cross where
  x : Int
  y : Int
  east : Int
  north : Int
  west : Int
  south : Int

/-- A cross is the union of its two closed intervals of integer cells. -/
def Contains (t : Cross) (x y : Int) : Prop :=
  (t.x-t.west ≤ x ∧ x ≤ t.x+t.east ∧ t.y ≤ y ∧ y ≤ t.y) ∨
  (t.x ≤ x ∧ x ≤ t.x ∧ t.y-t.south ≤ y ∧ y ≤ t.y+t.north)

/-- Cartesian separation of each of the four pairs of horizontal/vertical rods. -/
def Apart (t u : Cross) : Prop :=
  (t.x+t.east < u.x-u.west ∨ u.x+u.east < t.x-t.west ∨ t.y < u.y ∨ u.y < t.y) ∧
  (t.x+t.east < u.x ∨ u.x < t.x-t.west ∨ t.y < u.y-u.south ∨ u.y+u.north < t.y) ∧
  (t.x < u.x-u.west ∨ u.x+u.east < t.x ∨ t.y+t.north < u.y ∨ u.y < t.y-t.south) ∧
  (t.x < u.x ∨ u.x < t.x ∨ t.y+t.north < u.y-u.south ∨ u.y+u.north < t.y-t.south)

def Same (t u : Cross) : Prop :=
  t.x=u.x ∧ t.y=u.y ∧ t.east=u.east ∧ t.north=u.north ∧ t.west=u.west ∧ t.south=u.south

theorem same_eq {t u : Cross} (h : Same t u) : t=u := by
  cases t; cases u
  rcases h with ⟨hx,hy,he,hn,hw,hs⟩
  cases hx; cases hy; cases he; cases hn; cases hw; cases hs
  rfl

theorem swap_or {p q r s : Prop} (h : p ∨ q ∨ r ∨ s) : q ∨ p ∨ s ∨ r := by
  rcases h with h | h | h | h
  · exact Or.inr (Or.inl h)
  · exact Or.inl h
  · exact Or.inr (Or.inr (Or.inr h))
  · exact Or.inr (Or.inr (Or.inl h))

theorem apart_sym {t u : Cross} (h : Apart t u) : Apart u t := by
  rcases h with ⟨hh,hv,vh,vv⟩
  exact ⟨swap_or hh,swap_or vh,swap_or hv,swap_or vv⟩

def Positive (t : Cross) : Prop :=
  1≤t.east ∧ 1≤t.north ∧ 1≤t.west ∧ 1≤t.south

/-- For positive crosses the Cartesian condition follows from ordinary
    cellwise disjointness; it is not an extra packing assumption. -/
theorem apart_of_no_common (t u : Cross) (pt : Positive t) (pu : Positive u)
    (empty : ∀ x y, Contains t x y → Contains u x y → False) : Apart t u := by
  rcases pt with ⟨te,tn,tw,ts⟩
  rcases pu with ⟨ue,un,uw,us⟩
  refine ⟨?_,?_,?_,?_⟩
  · apply Classical.byContradiction
    intro blocked
    by_cases hleft : t.x-t.west ≤ u.x-u.west
    · apply empty (u.x-u.west) t.y
      · left; exact ⟨hleft,by omega,by omega,by omega⟩
      · left; exact ⟨by omega,by omega,by omega,by omega⟩
    · apply empty (t.x-t.west) t.y
      · left; exact ⟨by omega,by omega,by omega,by omega⟩
      · left; exact ⟨by omega,by omega,by omega,by omega⟩
  · apply Classical.byContradiction
    intro blocked
    apply empty u.x t.y
    · left; exact ⟨by omega,by omega,by omega,by omega⟩
    · right; exact ⟨by omega,by omega,by omega,by omega⟩
  · apply Classical.byContradiction
    intro blocked
    apply empty t.x u.y
    · right; exact ⟨by omega,by omega,by omega,by omega⟩
    · left; exact ⟨by omega,by omega,by omega,by omega⟩
  · apply Classical.byContradiction
    intro blocked
    by_cases hbottom : t.y-t.south ≤ u.y-u.south
    · apply empty t.x (u.y-u.south)
      · right; exact ⟨by omega,by omega,hbottom,by omega⟩
      · right; exact ⟨by omega,by omega,by omega,by omega⟩
    · apply empty t.x (t.y-t.south)
      · right; exact ⟨by omega,by omega,by omega,by omega⟩
      · right; exact ⟨by omega,by omega,by omega,by omega⟩

def Arms (t : Cross) (a b c d : Int) : Prop :=
  t.east=a ∧ t.north=b ∧ t.west=c ∧ t.south=d

def Copy (a b c d : Int) (t : Cross) : Prop :=
  Arms t a b c d ∨ Arms t b c d a ∨ Arms t c d a b ∨ Arms t d a b c ∨
  Arms t d c b a ∨ Arms t c b a d ∨ Arms t b a d c ∨ Arms t a d c b

theorem copy_positive {a b c d : Int} {t : Cross}
    (ha : 1≤a) (hb : 1≤b) (hc : 1≤c) (hd : 1≤d)
    (h : Copy a b c d t) : Positive t := by
  rcases h with h | h | h | h | h | h | h | h
  all_goals rcases h with ⟨he,hn,hw,hs⟩
  all_goals unfold Positive
  all_goals exact ⟨by omega,by omega,by omega,by omega⟩


theorem adjacent_node056 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n056_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n056_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n056_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n056_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n056_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n056_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n056_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n056_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n056_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node055 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n055_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n055_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n055_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n055_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n055_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n055_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n055_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n055_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n055_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node054 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n054_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n054_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n054_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n054_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n054_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n054_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n054_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n054_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n054_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node053 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n053_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n053_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n053_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n053_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n053_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n053_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n053_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n053_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n053_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node052 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((-1 : Int) * d) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n052_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n052_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n052_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n052_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node053 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n052_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node054 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n052_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node055 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n052_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node056 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n052_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n052_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩

theorem adjacent_node051 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n051_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n051_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n051_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n051_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n051_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n051_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n051_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n051_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n051_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node050 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n050_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n050_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n050_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n050_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n050_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n050_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n050_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n050_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n050_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node049 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n049_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n049_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n049_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n049_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n049_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n049_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n049_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n049_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n049_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node048 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n048_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n048_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n048_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n048_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n048_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n048_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n048_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n048_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n048_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node047 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((-1 : Int) * c) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n047_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n047_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n047_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node048 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n047_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node049 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n047_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n047_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node050 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n047_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n047_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n047_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node051 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem adjacent_node046 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n046_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n046_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n046_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n046_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n046_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n046_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n046_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n046_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n046_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node045 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b a d c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b a d c) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n045_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b a d c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n045_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n045_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n045_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n045_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n045_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n045_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n045_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n045_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node044 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n044_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n044_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n044_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n044_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n044_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n044_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n044_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n044_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n044_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node043 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n043_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n043_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n043_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n043_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n043_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n043_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n043_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n043_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n043_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node042 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n042_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n042_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n042_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n042_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n042_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n042_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n042_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n042_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n042_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node041 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n041_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n041_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n041_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n041_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n041_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n041_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n041_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n041_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n041_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node040 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b c d a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b c d a) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n040_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b c d a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n040_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n040_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n040_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n040_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n040_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n040_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n040_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n040_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node039 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n039_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n039_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n039_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n039_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n039_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n039_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n039_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n039_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n039_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node038 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((-1 : Int) * c) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (-2 : Int) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n038_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n038_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node039 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n038_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node040 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n038_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node041 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n038_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node042 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n038_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node043 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n038_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node044 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * c) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n038_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node045 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n038_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node046 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem adjacent_node037 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n037_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n037_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n037_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n037_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n037_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n037_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n037_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n037_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n037_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node036 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n036_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n036_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n036_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n036_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n036_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n036_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n036_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n036_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n036_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node035 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) c b a d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * b))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n035_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * b))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n035_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n035_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n035_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n035_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n035_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n035_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n035_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n035_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node034 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n034_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n034_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n034_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n034_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n034_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n034_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n034_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n034_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n034_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node033 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n033_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n033_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n033_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n033_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n033_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n033_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n033_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n033_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n033_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node032 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n032_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n032_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n032_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n032_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n032_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n032_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n032_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n032_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n032_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node031 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n031_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n031_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n031_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n031_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n031_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n031_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n031_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n031_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n031_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node030 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * b))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n030_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) + ((-1 : Int) * b))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n030_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n030_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n030_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n030_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n030_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n030_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n030_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n030_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node029 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((-1 : Int) * d) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n029_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n029_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node030 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n029_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node031 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n029_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node032 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n029_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node033 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n029_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node034 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * b)) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n029_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node035 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n029_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node036 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n029_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node037 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem adjacent_node028 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n028_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n028_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n028_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n028_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n028_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n028_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n028_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n028_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n028_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node027 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n027_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n027_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n027_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n027_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n027_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n027_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n027_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n027_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n027_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node026 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n026_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n026_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n026_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n026_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n026_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n026_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n026_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n026_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n026_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node025 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n025_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n025_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n025_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n025_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n025_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n025_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n025_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n025_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n025_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node024 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((-1 : Int) * d) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n024_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n024_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n024_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node025 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n024_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node026 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n024_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n024_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node027 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n024_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n024_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n024_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node028 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem adjacent_node023 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n023_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n023_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n023_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n023_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n023_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n023_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n023_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n023_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n023_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node022 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b a d c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b a d c) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n022_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b a d c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n022_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n022_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n022_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n022_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n022_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n022_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n022_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n022_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node021 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n021_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n021_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n021_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n021_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n021_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n021_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n021_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n021_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n021_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node020 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n020_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n020_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n020_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n020_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n020_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n020_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n020_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n020_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n020_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node019 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n019_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n019_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n019_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n019_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n019_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n019_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n019_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n019_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n019_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node018 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n018_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n018_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n018_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n018_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n018_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n018_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n018_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n018_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n018_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node017 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b c d a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b c d a) ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n017_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) + ((-1 : Int) * b)) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b c d a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n017_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n017_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n017_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n017_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n017_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n017_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n017_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n017_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node016 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n016_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) + ((-1 : Int) * a)) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n016_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n016_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n016_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n016_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n016_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n016_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n016_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n016_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node015 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((-1 : Int) * d) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n015_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n015_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node016 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n015_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node017 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n015_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node018 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n015_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node019 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n015_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node020 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n015_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node021 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-2 : Int) + ((-1 : Int) * b)) ((-1 : Int) * d) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n015_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node022 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n015_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node023 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem adjacent_node014 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n014_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n014_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n014_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n014_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n014_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n014_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n014_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n014_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n014_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node013 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n013_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n013_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n013_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n013_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n013_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n013_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n013_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n013_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n013_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node012 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n012_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n012_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n012_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n012_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n012_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n012_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n012_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n012_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n012_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node011 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n011_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n011_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n011_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n011_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n011_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n011_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n011_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n011_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n011_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node010 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n010_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n010_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n010_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n010_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n010_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n010_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n010_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n010_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n010_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node009 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n009_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n009_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n009_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n009_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n009_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n009_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n009_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n009_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n009_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node008 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n008_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n008_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n008_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n008_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n008_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n008_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n008_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n008_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n008_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node007 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n007_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n007_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n007_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n007_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n007_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n007_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n007_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n007_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n007_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node006 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((-1 : Int) * c) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n006_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n006_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node007 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n006_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node008 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n006_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node009 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n006_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node010 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n006_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node011 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n006_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node012 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n006_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node013 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n006_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node014 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem adjacent_node005 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n005_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n005_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n005_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n005_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n005_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n005_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n005_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n005_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n005_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node004 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n004_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n004_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n004_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n004_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n004_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n004_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n004_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n004_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n004_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node003 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n003_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n003_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n003_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n003_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n003_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n003_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n003_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n003_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n003_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node002 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n002_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n002_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n002_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n002_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n002_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n002_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n002_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n002_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n002_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem adjacent_node001 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((-1 : Int) * c) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (-2 : Int) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n001_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n001_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n001_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n001_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node002 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n001_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node003 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n001_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node004 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n001_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact adjacent_node005 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n001_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n001_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩

theorem adjacent_node000 (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-1 : Int) (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.adjacent_n000_empty a b c d ⟨ha, hb, hc, hd, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-1 : Int) (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty hit)
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n000_o0 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n000_o1 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0
    exact adjacent_node001 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ∨ Same (Cross.mk jx jy c d a b) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n000_o2 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    rcases alternatives with matched | matched
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact adjacent_node006 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact adjacent_node015 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n000_o3 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0
    exact adjacent_node024 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ∨ Same (Cross.mk jx jy d c b a) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n000_o4 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    rcases alternatives with matched | matched
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact adjacent_node029 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact adjacent_node038 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n000_o5 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0
    exact adjacent_node047 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n000_o6 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_adjacent_n000_o7 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0
    exact adjacent_node052 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)

/-- No cellwise-disjoint full-plane tiling contains the normalized adjacent-unit cross at the origin. -/
theorem adjacent_no_anchored_plane (a b c d : Int)
    (ha : a=1)
    (hb : b=1)
    (hc : 2≤c)
    (hd : c≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (cell_disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (anchor : world (Cross.mk 0 0 a b c d)) : False := by
  classical
  have separate : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases equal : t=u
    · exact Or.inl equal
    · right
      apply apart_of_no_common t u
      · exact copy_positive (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact copy_positive (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hit_t hit_u
        exact equal (cell_disjoint t u x y ht hu hit_t hit_u)
  exact adjacent_node000 a b c d ha hb hc hd world copies cover separate anchor
#print axioms adjacent_no_anchored_plane

theorem one_node088 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n088_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n088_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n088_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n088_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n088_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n088_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n088_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n088_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n088_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node087 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n087_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n087_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n087_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n087_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n087_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n087_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n087_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n087_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n087_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node086 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n086_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n086_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n086_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n086_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n086_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n086_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n086_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n086_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n086_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node085 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n085_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n085_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n085_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n085_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n085_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n085_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n085_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n085_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n085_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node084 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n084_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n084_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n084_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n084_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n084_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n084_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n084_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n084_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n084_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node083 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n083_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n083_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n083_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n083_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n083_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n083_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n083_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n083_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n083_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node082 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((-1 : Int) * d) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) (-2 : Int) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n082_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n082_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node083 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n082_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n082_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node084 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n082_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node085 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n082_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node086 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n082_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node087 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n082_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n082_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node088 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node081 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n081_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n081_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n081_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n081_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n081_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n081_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n081_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n081_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n081_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node080 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n080_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n080_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n080_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n080_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n080_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n080_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n080_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n080_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n080_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node079 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) c b a d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + ((-1 : Int) * b))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n079_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + ((-1 : Int) * b))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n079_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n079_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n079_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n079_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n079_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n079_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n079_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n079_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node078 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n078_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n078_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n078_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n078_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n078_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n078_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n078_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n078_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n078_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node077 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n077_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n077_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n077_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n077_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n077_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n077_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n077_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n077_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n077_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node076 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n076_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n076_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n076_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n076_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n076_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n076_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n076_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n076_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n076_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node075 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n075_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n075_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n075_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n075_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n075_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n075_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n075_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n075_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n075_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node074 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + ((-1 : Int) * b))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n074_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) + ((-1 : Int) * b))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n074_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n074_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n074_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n074_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n074_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n074_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n074_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n074_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node073 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * a) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ((-1 : Int) * a) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n073_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * a) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n073_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node074 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n073_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node075 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n073_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node076 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n073_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node077 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n073_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node078 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * b)) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n073_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node079 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n073_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node080 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n073_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node081 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node072 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a d c b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a d c b) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n072_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a d c b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n072_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n072_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n072_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n072_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n072_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n072_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n072_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n072_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node071 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (-2 : Int) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c b a d) (-2 : Int) ((1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n071_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c b a d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n071_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n071_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n071_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n071_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n071_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n071_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n071_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n071_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node070 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d c b a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d c b a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n070_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d c b a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n070_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n070_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n070_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n070_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n070_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n070_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n070_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n070_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node069 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d a b c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d a b c) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n069_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d a b c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n069_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n069_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n069_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n069_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n069_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n069_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n069_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n069_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node068 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (-2 : Int) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n068_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c d a b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n068_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n068_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n068_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n068_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n068_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n068_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n068_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n068_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node067 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a b c d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * a)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a b c d) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * a))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n067_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * a))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a b c d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n067_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n067_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n067_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n067_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n067_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n067_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n067_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n067_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node066 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((-1 : Int) * a) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) (-2 : Int) ((-1 : Int) * a)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n066_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((-1 : Int) * a)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n066_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node067 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n066_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n066_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node068 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n066_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node069 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n066_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node070 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * a) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n066_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node071 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n066_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * a) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n066_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node072 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node065 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n065_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n065_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n065_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n065_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n065_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n065_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n065_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n065_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n065_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node064 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n064_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n064_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n064_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n064_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n064_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n064_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n064_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n064_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n064_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node063 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n063_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n063_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n063_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n063_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n063_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n063_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n063_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n063_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n063_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node062 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n062_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n062_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n062_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n062_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n062_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n062_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n062_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n062_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n062_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node061 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n061_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n061_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n061_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n061_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n061_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n061_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n061_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n061_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n061_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node060 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n060_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n060_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n060_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n060_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n060_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n060_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n060_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n060_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n060_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node059 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ((-1 : Int) * c) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n059_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n059_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n059_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node060 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n059_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node061 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n059_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node062 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n059_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node063 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n059_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n059_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node064 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n059_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node065 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node058 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b) (2 : Int) (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n058_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (2 : Int) (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b) := by
    rcases separate t (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n058_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n058_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n058_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n058_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n058_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n058_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n058_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n058_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node057 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c) (2 : Int) (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n057_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (2 : Int) (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c) := by
    rcases separate t (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n057_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n057_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n057_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n057_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n057_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n057_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n057_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n057_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node056 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) a (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) a (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d) a (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n056_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover a (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n056_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n056_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n056_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n056_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n056_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n056_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n056_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n056_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node055 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) a (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) a (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b) a (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n055_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover a (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n055_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n055_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n055_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n055_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n055_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n055_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n055_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n055_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node054 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a) (2 : Int) (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n054_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (2 : Int) (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a) := by
    rcases separate t (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n054_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n054_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n054_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n054_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n054_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n054_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n054_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n054_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node053 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ht2 : world (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d) (2 : Int) (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n053_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (2 : Int) (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d) := by
    rcases separate t (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n053_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n053_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n053_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n053_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n053_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n053_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n053_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n053_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node052 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (1 : Int) (-2 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) (1 : Int) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n052_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (1 : Int) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n052_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node053 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n052_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node054 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n052_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node055 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n052_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n052_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n052_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node056 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n052_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node057 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n052_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node058 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node051 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n051_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n051_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n051_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n051_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n051_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n051_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n051_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n051_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n051_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node050 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n050_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n050_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n050_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n050_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n050_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n050_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n050_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n050_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n050_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node049 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n049_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n049_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n049_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n049_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n049_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n049_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n049_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n049_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n049_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node048 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n048_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n048_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n048_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n048_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n048_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n048_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n048_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n048_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n048_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node047 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n047_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n047_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n047_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n047_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n047_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n047_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n047_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n047_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n047_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node046 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n046_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n046_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n046_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n046_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n046_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n046_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n046_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n046_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n046_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node045 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ((-1 : Int) * d) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n045_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n045_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n045_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node046 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n045_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node047 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n045_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node048 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n045_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node049 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n045_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n045_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node050 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n045_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node051 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node044 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ht2 : world (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b) (2 : Int) (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n044_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (2 : Int) (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b) := by
    rcases separate t (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n044_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n044_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n044_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n044_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n044_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n044_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n044_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n044_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node043 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ht2 : world (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) d (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) d (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c) d (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n043_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover d (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c) := by
    rcases separate t (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n043_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n043_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n043_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n043_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n043_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n043_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n043_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n043_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node042 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ht2 : world (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) a (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) a (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d) a (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n042_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover a (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n042_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n042_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n042_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n042_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n042_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n042_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n042_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n042_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node041 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ht2 : world (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) a (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) a (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b) a (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n041_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover a (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b) := by
    rcases separate t (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n041_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n041_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n041_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n041_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n041_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n041_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n041_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n041_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node040 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ht2 : world (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) d (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) d (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a) d (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n040_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover d (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a) := by
    rcases separate t (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n040_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n040_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n040_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n040_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n040_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n040_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n040_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n040_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node039 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ht2 : world (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (2 : Int) (-1 : Int) ∨ Contains (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d) (2 : Int) (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n039_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (2 : Int) (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d) := by
    rcases separate t (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n039_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n039_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n039_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n039_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n039_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n039_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n039_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n039_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node038 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (1 : Int) (-2 : Int) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) (1 : Int) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n038_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (1 : Int) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((1 : Int) + c) (-2 : Int) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n038_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node039 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((1 : Int) + d) (-2 : Int) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n038_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node040 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((1 : Int) + a) (-2 : Int) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n038_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node041 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n038_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n038_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((1 : Int) + a) (-2 : Int) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n038_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node042 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((1 : Int) + d) (-2 : Int) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n038_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node043 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((1 : Int) + c) (-2 : Int) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n038_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node044 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node037 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n037_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n037_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n037_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n037_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n037_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n037_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n037_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n037_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n037_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node036 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n036_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n036_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n036_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n036_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n036_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n036_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n036_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n036_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n036_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node035 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n035_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n035_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n035_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n035_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n035_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n035_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n035_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n035_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n035_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node034 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n034_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) ((-1 : Int) * a)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n034_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n034_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n034_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n034_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n034_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n034_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n034_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n034_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node033 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n033_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n033_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n033_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n033_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n033_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n033_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n033_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n033_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n033_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node032 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ht2 : world (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n032_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * d)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n032_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n032_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n032_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n032_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n032_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n032_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n032_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n032_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node031 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ((-1 : Int) * d) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n031_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n031_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n031_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node032 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n031_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node033 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n031_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node034 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n031_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node035 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n031_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n031_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node036 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * d) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n031_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node037 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node030 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n030_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n030_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n030_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n030_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n030_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n030_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n030_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n030_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n030_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node029 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n029_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n029_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n029_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n029_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n029_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n029_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n029_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n029_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n029_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node028 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n028_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n028_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n028_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n028_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n028_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n028_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n028_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n028_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n028_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node027 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n027_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n027_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n027_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n027_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n027_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n027_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n027_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n027_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n027_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node026 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n026_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n026_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n026_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n026_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n026_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n026_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n026_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n026_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n026_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node025 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * d)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * d))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n025_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * d))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n025_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n025_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n025_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n025_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n025_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n025_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n025_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n025_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node024 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((-1 : Int) * d) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) (-2 : Int) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n024_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n024_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node025 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n024_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n024_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node026 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n024_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node027 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * d) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n024_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node028 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n024_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node029 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n024_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n024_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node030 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node023 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n023_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n023_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n023_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n023_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n023_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n023_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n023_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n023_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n023_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node022 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n022_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n022_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n022_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n022_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n022_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n022_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n022_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n022_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n022_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node021 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n021_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n021_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n021_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n021_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n021_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n021_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n021_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n021_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n021_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node020 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n020_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n020_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n020_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n020_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n020_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n020_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n020_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n020_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n020_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node019 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n019_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n019_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n019_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n019_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n019_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n019_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n019_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n019_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n019_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node018 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n018_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n018_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n018_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n018_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n018_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n018_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n018_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n018_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n018_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node017 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n017_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n017_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n017_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n017_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n017_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n017_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n017_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n017_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n017_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node016 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ht2 : world (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b)) ∨ Contains (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d) ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n016_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * c)) ((-1 : Int) + ((-1 : Int) * b))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n016_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n016_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n016_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n016_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n016_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n016_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n016_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n016_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node015 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * c) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ((-1 : Int) * c) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n015_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * c) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n015_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node016 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n015_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node017 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n015_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node018 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n015_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node019 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n015_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node020 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * b)) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n015_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node021 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n015_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node022 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * c) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n015_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node023 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node014 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n014_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n014_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n014_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n014_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n014_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n014_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n014_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n014_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n014_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node013 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (-2 : Int) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) (-2 : Int) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n013_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n013_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n013_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n013_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n013_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n013_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n013_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n013_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n013_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node012 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n012_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * d) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n012_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n012_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n012_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n012_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n012_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n012_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n012_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n012_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node011 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (-2 : Int) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) (-2 : Int) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n011_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n011_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n011_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n011_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n011_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n011_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n011_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n011_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n011_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node010 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (-2 : Int) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) (-2 : Int) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n010_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n010_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n010_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n010_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n010_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n010_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n010_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n010_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n010_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node009 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ht2 : world (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d))
    (ap12 : Apart (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * c)) ∨ Contains (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d) ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * c))) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n009_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * a) ((1 : Int) + ((-1 : Int) * c))
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d) := by
    rcases separate t (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n009_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n009_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n009_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n009_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n009_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n009_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n009_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n009_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node008 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-2 : Int) ((-1 : Int) * c) ∨ Contains (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) (-2 : Int) ((-1 : Int) * c)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n008_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-2 : Int) ((-1 : Int) * c)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n008_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node009 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n008_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n008_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node010 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n008_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node011 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-2 : Int) + ((-1 : Int) * d)) ((-1 : Int) * c) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n008_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node012 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-2 : Int) + ((-1 : Int) * c)) ((-1 : Int) * c) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n008_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node013 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n008_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-2 : Int) + ((-1 : Int) * a)) ((-1 : Int) * c) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n008_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node014 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node007 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n007_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n007_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n007_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n007_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n007_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n007_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n007_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n007_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n007_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node006 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n006_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n006_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n006_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n006_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n006_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n006_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n006_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n006_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n006_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node005 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n005_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n005_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n005_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n005_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n005_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n005_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n005_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n005_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n005_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node004 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n004_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n004_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n004_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n004_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n004_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n004_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n004_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n004_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n004_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node003 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n003_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) ((-1 : Int) * d)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n003_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n003_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n003_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n003_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n003_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n003_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n003_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n003_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node002 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ht2 : world (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ap02 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    (ap12 : Apart (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n002_empty a b c d ⟨ha, hb, hc, hd, ap01, ap02, ap12, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((1 : Int) + ((-1 : Int) * a)) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inl hit)))
    · exact hs
  have sep2 : Apart t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
    rcases separate t (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a) ht ht2 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr (Or.inr hit)))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n002_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n002_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n002_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n002_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n002_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n002_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n002_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n002_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, ap02, ap12, hit, sep0, sep1, sep2⟩

theorem one_node001 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    (ht1 : world (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    (ap01 : Apart (Cross.mk (0 : Int) (0 : Int) a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) ((-1 : Int) * a) (-2 : Int) ∨ Contains (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ((-1 : Int) * a) (-2 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n001_empty a b c d ⟨ha, hb, hc, hd, ap01, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover ((-1 : Int) * a) (-2 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty (Or.inl hit))
    · exact hs
  have sep1 : Apart t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) := by
    rcases separate t (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) ht ht1 with heq | hs
    · subst t
      exact False.elim (empty (Or.inr hit))
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n001_o0 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n001_o1 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node002 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n001_o2 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node003 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n001_o3 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node004 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n001_o4 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node005 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    exact CrossUnitsArithmetic.cross_units_oriented_one_n001_o5 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1⟩
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n001_o6 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node006 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) * a) ((-2 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n001_o7 a b c d jx jy ⟨ha, hb, hc, hd, ap01, hit, sep0, sep1, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0 sep1
    exact one_node007 a b c d ha hb hc hd world copies cover separate ht0 ht1 ht ap01 (apart_sym sep0) (apart_sym sep1)

theorem one_node000 (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (separate : ∀ t u, world t → world u → t=u ∨ Apart t u)
    (ht0 : world (Cross.mk (0 : Int) (0 : Int) a b c d))
    : False := by
  classical
  have empty : ¬ (Contains (Cross.mk (0 : Int) (0 : Int) a b c d) (-1 : Int) (-1 : Int)) := by
    intro occupied
    exact CrossUnitsArithmetic.one_n000_empty a b c d ⟨ha, hb, hc, hd, (by simpa only [Contains, or_assoc] using occupied)⟩
  obtain ⟨t, ht, hit⟩ := cover (-1 : Int) (-1 : Int)
  have sep0 : Apart t (Cross.mk (0 : Int) (0 : Int) a b c d) := by
    rcases separate t (Cross.mk (0 : Int) (0 : Int) a b c d) ht ht0 with heq | hs
    · subst t
      exact False.elim (empty hit)
    · exact hs
  rcases t with ⟨jx,jy,e,n,w,s⟩
  rcases copies _ ht with ho | ho | ho | ho | ho | ho | ho | ho
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a b c d) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a b c d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n000_o0 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0
    exact one_node001 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b c d a) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) b c d a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n000_o1 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0
    exact one_node008 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c d a b) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c d a b) ∨ Same (Cross.mk jx jy c d a b) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) c d a b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n000_o2 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    rcases alternatives with matched | matched
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact one_node015 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact one_node024 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d a b c) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d a b c) ∨ Same (Cross.mk jx jy d a b c) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) d a b c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n000_o3 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    rcases alternatives with matched | matched
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact one_node031 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact one_node038 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy d c b a) (Cross.mk ((-1 : Int) + ((-1 : Int) * d)) (-1 : Int) d c b a) ∨ Same (Cross.mk jx jy d c b a) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * c)) d c b a) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n000_o4 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    rcases alternatives with matched | matched
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact one_node045 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact one_node052 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy c b a d) (Cross.mk ((-1 : Int) + ((-1 : Int) * c)) (-1 : Int) c b a d) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n000_o5 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0
    exact one_node059 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy b a d c) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * a)) b a d c) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n000_o6 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    have matched := alternatives
    have equal := same_eq matched
    rw [equal] at ht sep0
    exact one_node066 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
  · rcases ho with ⟨he,hn,hw,hs⟩
    dsimp only at he hn hw hs
    subst e; subst n; subst w; subst s
    have alternatives : Same (Cross.mk jx jy a d c b) (Cross.mk ((-1 : Int) + ((-1 : Int) * a)) (-1 : Int) a d c b) ∨ Same (Cross.mk jx jy a d c b) (Cross.mk (-1 : Int) ((-1 : Int) + ((-1 : Int) * d)) a d c b) := by
      apply Classical.byContradiction
      intro absent
      exact CrossUnitsArithmetic.cross_units_oriented_one_n000_o7 a b c d jx jy ⟨ha, hb, hc, hd, hit, sep0, (by simpa only [Same, eq_comm] using absent)⟩
    rcases alternatives with matched | matched
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact one_node073 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)
    · have equal := same_eq matched
      rw [equal] at ht sep0
      exact one_node082 a b c d ha hb hc hd world copies cover separate ht0 ht (apart_sym sep0)

/-- No cellwise-disjoint full-plane tiling contains the normalized one-unit cross at the origin. -/
theorem one_no_anchored_plane (a b c d : Int)
    (ha : 2≤a)
    (hb : b=1)
    (hc : a≤c)
    (hd : 2≤d)
    (world : Cross → Prop)
    (copies : ∀ t, world t → Copy a b c d t)
    (cover : ∀ x y : Int, ∃ t, world t ∧ Contains t x y)
    (cell_disjoint : ∀ t u x y, world t → world u → Contains t x y → Contains u x y → t=u)
    (anchor : world (Cross.mk 0 0 a b c d)) : False := by
  classical
  have separate : ∀ t u, world t → world u → t=u ∨ Apart t u := by
    intro t u ht hu
    by_cases equal : t=u
    · exact Or.inl equal
    · right
      apply apart_of_no_common t u
      · exact copy_positive (by omega) (by omega) (by omega) (by omega) (copies t ht)
      · exact copy_positive (by omega) (by omega) (by omega) (by omega) (copies u hu)
      · intro x y hit_t hit_u
        exact equal (cell_disjoint t u x y ht hu hit_t hit_u)
  exact one_node000 a b c d ha hb hc hd world copies cover separate anchor
#print axioms one_no_anchored_plane

end CrossUnits

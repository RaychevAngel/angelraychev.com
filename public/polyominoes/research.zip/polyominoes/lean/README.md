# Lean verification

`HalfPlane.lean` formalizes unit-cell crosses with arbitrary positive integer arm lengths and proves that no family indexed by an arbitrary type can tile the upper half-plane. The assumptions are exact coverage, containment in the half-plane, and pairwise disjointness. It includes infinite tilings and allows each placed tile to have different arm lengths, so rotations/reflections of any fixed positive-arm P are covered.

Verified with Lean 4.33.1 (official arm64 macOS release). Commands in this
guide run from the project root and assume that version is available as
`lean` on PATH. The research run used
`.tools/lean-4.33.1-darwin_aarch64/bin/lean`; that runtime is not distributed
in the source archive.

```
lean lean/HalfPlane.lean
```

The command succeeds. `#print axioms no_half_plane_tiling` reports only Lean's standard `propext`, `Classical.choice`, and `Quot.sound`; there are no admitted proofs or additional axioms.

The Lean files do not formalize the whole classification. The human proofs,
independently checked finite certificates, and compiled Lean theorems are
identified separately in the manuscript.

## Crosses with unit arms

`CrossUnitsAdjacentArithmetic.lean`, `CrossUnitsOneArithmetic.lean`, and `CrossUnitsGeometry.lean` additionally formalize the two remaining cross obstructions. The normalized domains are:

- a=b=1, 2<=c<=d: two adjacent unit arms;
- b=1, 2<=a<=c, 2<=d: exactly one unit arm.

The final theorems `CrossUnits.adjacent_no_anchored_plane` and `CrossUnits.one_no_anchored_plane` quantify an arbitrary world of placed crosses. They assume every integer cell is covered, each placed cross has one of the eight D4 arm assignments, distinct placed crosses share no cell, and the normalized original cross is present at the origin. They prove `False`.

To apply this to an unanchored tiling, choose any tile, translate its junction to the origin, and apply the inverse of its D4 symmetry to the entire tiling. This ordinary normalization argument is written in English; it is not part of these Lean theorem statements. There is no finite-period or bounding-box hypothesis.

The arithmetic files contain 1,314 lemmas proving all orientation alternatives and queried-cell emptiness at the 146 proof-tree nodes. Z3 supplied proposed proof cases and small sets of relevant inequalities, but every resulting implication is checked by Lean's `omega` tactic and kernel. The geometric replay proves separation from ordinary cellwise disjointness and follows the finite trees using arbitrary world coverage.

From the project root, using Lean 4.33.1:

```sh
lean -o lean/CrossUnitsAdjacentArithmetic.olean lean/CrossUnitsAdjacentArithmetic.lean
lean -o lean/CrossUnitsOneArithmetic.olean lean/CrossUnitsOneArithmetic.lean
LEAN_PATH=lean lean -o lean/CrossUnitsGeometry.olean lean/CrossUnitsGeometry.lean
```

Both final theorems compiled and their axiom reports contain only `propext`,
`Classical.choice`, and `Quot.sound`. The report is retained in
`research/cross_units_geometry_compile.log`. The source hashes and exact
scope are recorded in `research/cross_units_verified_manifest.json`.

## T shapes with a two-cell crossbar arm

`TPlaneShortArithmetic.lean` and `TPlaneGeometry.lean` prove
`TPlane.two_short_no_anchored_plane` for every integer `a>=2` and
`3<=b<a+3`, with prototile `P(a,b,2,0)`.

The theorem uses the same arbitrary-world coverage and ordinary cellwise
disjointness conditions as the cross theorems, together with all eight D4
orientations and an anchor at the origin. There is no upper parameter
bound, finite-period assumption, tile-count bound, or junction-coordinate
cutoff. A proved interval-intersection lemma handles nonnegative arms,
including the T's zero fourth arm. The normalization of an arbitrary
tiling to the stated anchor is again an English reduction.

The finite tree has 300 states. Its 2,700 arithmetic lemmas comprise one
selected-cell emptiness lemma and eight orientation-specific completeness
lemmas per state. Lean's `omega` proves every lemma; the semantic replay
then derives the impossibility of a full-plane tiling. No Z3 result is
trusted by the compiled proof.

Compile the cross dependencies above first, then run:

```sh
lean -o lean/TPlaneShortArithmetic.olean lean/TPlaneShortArithmetic.lean
LEAN_PATH=lean lean -o lean/TPlaneGeometry.olean lean/TPlaneGeometry.lean
```

Both commands succeeded with Lean 4.33.1. The final theorem's axiom report
contains only `propext`, `Classical.choice`, and `Quot.sound`. Compiler logs
are `research/TPlane_short_arithmetic_compile.log` and
`research/TPlane_geometry_compile.log`; source hashes and the precise
formal boundary appear in `research/TPlane_verified_manifest.json`.
`lean/TPlaneREADME.md` gives the detailed artifact map.

The other negative T families, including `c=2, b>a+3`, have independently
reviewed English proofs; they are not claimed to be Lean theorems here.
No admitted proof or added axiom is used by the compiled theorems described
in this guide. Compiled artifacts are intentionally excluded from the
research archive.

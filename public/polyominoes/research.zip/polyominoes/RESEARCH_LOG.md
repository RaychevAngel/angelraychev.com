# Four-arm polyominoes: research log

## 2026-09-11 — authorized investigation begins

The user has now posed the actual task. Earlier general-hierarchy exploration was preliminary and must not be confused with reproducing the user's T classification.

Goal sequence:
1. Classify all T shapes P(a,b,c,0), excluding P(4,1,1,0), P(5,1,1,0), with proofs.
2. Write a readable English exposition and publish verified results on angelraychev.com.
3. Investigate the two exceptions and full four-arm family, especially all arms greater than one.

Primary supplied context:
- /Users/angel/Downloads/Tiling_the_Quadrant_with_L_Polyominoes_Student_Conference_2021.pdf (18 pages, internally titled L Polyominoes). Thin L dimensions m×n correspond to P(m−1,n−1,0,0). Includes prime-area short-L rectangle classification, long-L rectangle obstruction, plane constructions. Its theorem statements say rectangles; the half-plane successor describes prior work as excluding quadrants. Preserve this distinction pending full proof audit.
- /Users/angel/Downloads/Tiling_the_Half-Plane_with_L_Polyominoes_Spring_Conference_2021.pdf (14 pages). Theorem 1 states half-plane tileability exactly for L dimensions 2×n, 3×n, 4×5; positive constructions tile strips. Boundary case analysis includes the difficult 4×6 exclusion.

Conventions and proof standards are in AGENTS.md.

Parallel approaches started: boundary/corner impossibility arguments; positive constructions and hierarchy placement; finite computational certificates. Root handles integration, independent checks, writing, and website publication.

Unresolved at start: the T classification itself; an all-parameter proof; exact website source/deployment workflow. No classification claims are established yet.

User steering: expanded target to COMPLETE classification of every nonnegative tuple P(a,b,c,d), with instruction to continue until achieved. The original T write-up remains the first milestone; no assumption that the complete four-arm classification is easy or already established.

Website located: https://github.com/RaychevAngel/angelraychev.com, public GitHub Pages site, cloned to website/. Existing Astro structure is to be preserved. No new hosting service or domain change is needed.

### Construction and counterexample checkpoint

- Proved by direct boundary overlap: every four-positive-arm cross fails to tile a half-plane. Thus it is either plane-only or a non-tiler.
- Explicit two-copy lattice tiling for P(a,1,c,1): lattice generators (a+c+3,0),(1,2), second copy half-turned at (a+2,1). Residue proof in research/cross_theory.md. Rotations cover any opposite unit arms.
- Candidate general non-plane proof for all arms≥2 uses maximal arms, diagonal direction assignments, and two adjacent forced vertical tips. Independent review requested.
- REJECTED CONJECTURE: all T shapes with c≥2,b≥3 are non-tilers. Computation found persistent locally satisfiable configurations for (2,5,2),(3,6,2). Construction agent subsequently found and derived the additional plane family P(a,a+3,2,0), a≥2. This is a substantive correction, not a numerical timeout interpreted as a tiling.
- T positive constructions now include b=1 full strips; b=c=1 bent strips; c=1 plane tilings; b=2 plane tilings; and the newly discovered c=2,b=a+3 plane tilings. Parameter-wide negative proofs remain necessary.
- Independently checked explicit rectangle witnesses for P(1,1,1,0), P(2,1,1,0), P(3,1,1,0); the last has 92 tiles in a 24×23 rectangle from Reid's historical database, re-extracted and verified cell-by-cell. No minimum-order claim is made.
- Finite impossibility claims have exhaustive placement-tree certificates, distinct from arbitrary solver UNSAT reports. Representative certificates and their precise finite regions are under results/.

### Universal cross results and formal verification

- Independent boundary-agent audit accepted the full maximal-arm proof: ALL four-positive-arm shapes with min(a,b,c,d)>=2 are non-tilers. This is a parameter-wide theorem.
- The half-plane obstruction now compiles in Lean4.33.1, `lean/HalfPlane.lean`. It directly quantifies arbitrary infinite indexed families of positive-arm crosses, exact cover, containment, and pairwise disjointness. Axiom audit reports only standard propext/Classical.choice/Quot.sound; no admitted proof or added axiom.
- For crosses with positive arms<=6, all231 symmetry classes were surveyed. The21 classes with opposite unit arms have constructions; the210 others have finite anchored UNSAT reports. The remaining universal gap concerns one unit arm or two adjacent unit arms; survey evidence alone does not close it.
- The written T half-plane obstruction for a>=c>=2,b>=2 has passed root's independent review. It excludes stem-tip and vertical-bar boundary contacts, then forces an impossible gap between horizontal-bar boundary contacts. The c=1 case is undergoing reduction to15 independently verifiable finite cases.

### Historical lead concerning the two excluded T shapes

Located Karl Dahlke's primary-source Gun Theorem, now at https://github.com/eklhad/trec/blob/master/theorems/gun. Section23 expressly treats one-face-cell guns with barrel lengthk>=4, exactly P(k,1,1,0), and claims nonrectifiability by a three-state corner-propagation argument. This addresses the initially excluded k4/k5 on its face. However, the proof's local states and transitions are being independently audited; no theorem is accepted merely on the strength of a historical claim. Extending it to half-strips requires a separate check of strict vertical progress along every cycle.

Independent finite-state boundary closure certificates exclude all half-strip heights for k6 (a three-column prefix) and each k7through40 (a two-column prefix). Observed statecount3k^2+9k+38 for k7through40 is a conjectural structural pattern, not yet a universal certificate.

### The two exceptions and the entire long-T family

- Both P(4,1,1,0) and P(5,1,1,0) are now classified in the seven-region hierarchy: bent-strip tileable, but no half-strip and therefore no rectangle. The explicit bent-strip construction and the infinite-height impossibility are separate proofs.
- Finite clean-corner DAGs have 1,750 nodes for a=4 and 872 for a=5. The original checker and root's independently written `src/check_corner_proofs.py` both enumerate every whole D4 placement through each queried cell; neither discards inconvenient overhangs.
- The proof uses five corner states. Every successor is coordinatewise farther into the quadrant, old occupied cells are absent from the new open quadrant except for its declared corner decoration, and the graph of zero-vertical-progress transitions is acyclic. Thus a hypothetical half-strip tiling produces an unbounded sequence of corner heights inside a finite-height region.
- For EVERY integer a>=6, an affine lift of the a=6/a=7 proof skeleton was proposed and then independently proved valid, with no upper arm or coordinate bound: 7,325 QF_LIA queries with Z3, and a separately encoded 808-query CVC5 replay. Sample agreement was used only for conjecture generation. Root reviewed the universal geometric encoding and the infinite-height inference. Result: ALL P(a,1,1,0), a>=4, tile bent strips but no half-strip.
- Caution: this does not itself rule out rep-tilings. That branch is being attacked via horizontal/vertical drift and the long arm of an enlarged T.

### Completed T boundary theorem

- `research/t_boundary.md` proves, for normalized genuine T shapes a>=c>=1, that HP holds if and only if b=1. The c=1 reduction leaves 15 finite cases, all covered by exhaustive whole-placement certificates and an independent checker. Root reviewed the parameter reduction and reran the finite verification.
- A corner argument then gives Q if and only if b=c=1. Therefore b=1,c>=2 is exactly strip-only above the half-plane, and every plane-tileable b>=2 case is plane-only.

### Cross unit-arm proof and independent attack

- Two symbolic finite obstruction trees cover every remaining positive cross without opposite unit arms: 57 nodes when a=b=1,2<=c<=d, and 89 nodes when b=1,a>=2,c>=a,d>=2.
- An independent verifier checked arbitrary integer candidate junctions, not merely the tip placements proposed by the generator. All 850 queries were UNSAT without upper parameter or coordinate bounds. Thus no hidden non-tip placement or unlisted orientation survives the proof.
- Lean replay is in progress. Both arithmetic batches have compiled: 1,314 lemmas, with all eight D4 candidate orientations at each node plus queried-cell emptiness. The semantic link to arbitrary infinite plane tilings is being compiled separately. Do not call that final semantic theorem compiled until its output has been inspected.
- Rejected route: counting diagonal-to-tip assignments by density does not prove that facing arms have equal lengths. A maximum-length arm can receive no assignment while another receives two. This approach was abandoned rather than used as a lemma.

### Remaining T-plane gap and writing

- Plane constructions for c=1, b=2, and c=2,b=a+3 have parameter-wide residue proofs. Root independently checked every rod interval in the four-copy exceptional construction; its quotient table is exhaustive for b>=5 and each row supplies all four transverse residues.
- The conjectured negative complement is c>=3,b>=3, or c=2,b>=3,b!=a+3. A finite survey is consistent with it but is not a proof. Symbolic exact-geometry trees are now being developed for those domains.
- English manuscript and nine exact SVG figures are in `paper/` and `figures/`. The existing Astro website has a draft article and an interactive tuple explorer. Nothing has been deployed; unfinished plane cases remain explicitly marked open in the explorer.

### Full cross closure, rep-tile closure, and further T progress

- The cross-unit geometric Lean replay compiled successfully. Both `adjacent_no_anchored_plane` and `one_no_anchored_plane` quantify arbitrary infinite worlds, ordinary cellwise disjointness, D4 copies, and complete plane coverage; their axiom reports are only the standard three. Translation/D4 normalization to the explicit anchor is a separate elementary English step. All positive-arm crosses are now classified: plane-only exactly when opposite unit arms exist, otherwise non-tilers.
- The rep-tile branch for ALL P(a,1,1,0), a>=4, is also excluded. Exact state potentials [0,2,2,1,0] give X-4Y<=-h. In a scaled T whose stem begins at X=ak, the actual wall of height w>=4 gives Y+w<=k, hence ak-X> a+8. Every local whole-tile placement stays before the stem, making every query valid. Infinite height growth then contradicts the finite arm height. The wall-buffer inequality resolves the initially delicate equality case a=4. Root independently attacked this inference and accepted it; `results/t_rep_ratio_verified.json` checks all local inequalities by exact arithmetic.
- Root independently reviewed the full human non-plane proof for c>=3,b>=3, including its separate short-stem and long-stem gap lemmas. The proof forces opposed horizontal crossbars, a vertical crossbar above them, and an uncovered next cell. A fresh second adversarial review is running.
- The c=2,3<=b<a+3 domain now has a closed 300-node symbolic tree and 2,218 independent unbounded-junction checks. The remaining c=2,b>a+3 tree is still being completed. The positive equality b=a+3 already has a full construction.
- Root attacked the proposed plane criterion at 16 larger parameter tuples. The two equality-family positives have verified local covers; all 14 others produced finite anchored UNSAT reports. These are recorded as supporting evidence, not a replacement for the universal proof.
- Found a small dimensional mismatch in the 2021 L half-plane paper: its page 3 drawing for bounding dimensions 4-by-5 reconstructs as strip width8/period8, while page4 says width6. The exact eight-tile motif was reconstructed and independently verified. The classification remains unchanged. No impossibility claim for every width-six tiling follows from this observation.


## Final mathematical closure — 2026-09-11

The final negative family, normalized T shapes `P(a,b,2,0)` with `a>=2` and `b>a+3`, is proved by a human geometric argument and independently reviewed by root, the constructions/formalization agent, and the computation agent. The decisive strengthening is a blocked-run lemma of arbitrary width `g>=3` when one endpoint wall is sufficiently tall. It eliminates the earlier offset-order route and its apparent `(a,b)=(3,12)` subcase. A reflection-dependent assumption about which arm of the original tile is long was found during the attack and removed. The final R/W/Z forcing permits both original arm orders and both orientations of W’s vertical arms. Exact borderline wall heights `b=a+4` and the rotated endpoint `x=-A` were checked explicitly.

The geometric proof and its independent audit are in `research/t_plane_negative.md` and `research/TPlane_long_audit.md`. The short complement `3<=b<a+3` is separately Lean-verified: 300 nodes, 2,700 arithmetic lemmas, and a complete arbitrary-world geometric replay. No partial long-domain symbolic tree is being represented as a proof.

Consequently, for `a>=c>=1,b>=1`, a T tiles the plane exactly when `b<=2`, `c=1`, or `(c=2,b=a+3)`. Its half-plane criterion is `b=1`; its quadrant criterion is `b=c=1`. The latter family tiles rectangles for `a<=3`, and has exact BS profile with no rep-tiling for every `a>=4`. In particular both original exceptions are settled. A positive-arm cross tiles the plane exactly when an opposite pair of arms equals one, and never tiles a half-plane. The bar cases and supplied L results exhaust all remaining tuples. No classification proof obligation remains open.

The complete theorem is being assembled in `paper/manuscript.md` and `paper/proofs.md`, with exact formalization boundaries. Lean formalizes specified obstruction families, not the entire classification. The L negative inputs remain explicitly cited prior work from the two supplied 2021 papers. The reconstructed 4-by-5 L strip has width eight and period eight; the paper’s width-six sentence is a dimensional mismatch, and we make no claim that every width-six construction is impossible.

Publication verification is a separate final step: local build, visible rendering, classifier agreement, archive hash readback, and then actual GitHub Pages deployment and live URL checks.

# Four-arm polyominoes

Research project for Angel Raychev's family

\[
P(a,b,c,d)=([-c,a]\times\{0\})\cup(\{0\}\times[-d,b])\subset\mathbb Z^2.
\]

Parameters are nonnegative integers; copies may be translated, rotated, or reflected. A genuine T is normalized as P(a,b,c,0) with a>=c>=1. The investigation covers rectangle, half-strip, bent strip, quadrant, strip, half-plane, and plane tileability; the additional rep-tile question is kept distinct.

The classification is complete for every nonnegative integer tuple, including the rep-tile branch. The illustrated theorem and proofs are in `paper/manuscript.md` and `paper/proofs.md`; `RESEARCH_LOG.md` preserves the discovery process and independent attacks. No parameter domain remains open. Numerical failure at selected widths or parameters is never used as a universal impossibility argument.

## Reading map

- `paper/manuscript.md`: illustrated English exposition.
- `RESEARCH_LOG.md`: discoveries, false conjectures, proof attacks, and final closure.
- `research/t_constructions.md`: exact periodic T constructions, including the exceptional four-copy family.
- `research/t_boundary.md`: T half-plane and quadrant obstructions.
- `research/t_computation.md`: exact finite witnesses and clean-corner propagation.
- `research/t_plane_negative.md`: complete T-plane obstruction proofs.
- `research/cross_theory.md`: cross half-plane obstruction, opposite-unit-arm tiling, and all-long-arm obstruction.
- `research/cross_units.md`: symbolic cross obstructions.
- `lean/README.md`: exact formalization boundary and reproduction instructions.
- `src/`: search and independent verification programs.
- `results/`: explicit witnesses, proof DAGs, and verification receipts.
- `figures/`: deterministic geometric SVG drawings.
- `website/`: the existing angelraychev.com Astro repository, with the published article, interactive classifier, and proof downloads.

The supplied 2021 L-polyomino papers remain untouched in the user's Downloads folder. Their statements are cited as prior work, not represented as new results from this investigation.

## Reproduction

The classifier and ordinary finite certificate checkers use Python's standard library. `src/verify_classification.py` also requires Node.js to compare the included browser classifier. Searches and symbolic replay use the pinned packages in `requirements.txt`; install them in an isolated environment. The saved exact Y-hexomino coordinate witness can be checked without Pillow. Optional historical raster extraction additionally requires Pillow and the source GIF from Michael Reid’s page (https://sicherman.net/mikereid/y6_rect.html); that third-party image is not included in the archive.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python src/classify.py 4 1 1 0
.venv/bin/python src/t_boundary_verify_finite.py
.venv/bin/python src/check_corner_proofs.py
```

See `lean/README.md` and the domain-specific Lean guides for formal checks. Lean 4.33.1 is pinned in `lean/lean-toolchain`; the sources need the standard library but no Mathlib dependency. The machine-specific `.tools` runtime used during research is not distributed. The Lean guides give portable commands from the project root with that version of `lean` on PATH.

The website is the original Astro repository in `website/`; the illustrated article, proof appendix, and downloadable research archive are built from `paper/`, `research/`, and `figures/`. The archive's `MANIFEST.json` records file sizes and SHA-256 digests, all checked after writing the ZIP.

## Final classification at a glance

For a genuine T, normalize `P(a,b,c,0)` with `a>=c>=1`. It tiles the plane exactly when `b<=2`, `c=1`, or `c=2` and `b=a+3`. It tiles a half-plane exactly when `b=1`. With `b=1`, `c>=2` has profile S; `c=1,a<=3` has profile R; and `c=1,a>=4` has profile BS with no rep-tiling.

A genuine four-arm cross tiles the plane exactly when two opposite arms equal one; it never tiles a half-plane. Bars and the prior L classification complete all degenerate tuples. The manuscript’s two tables specify all eight capabilities exactly.

Lean verifies the positive-arm half-plane obstruction, the one-unit and adjacent-unit cross obstructions, and the T domain `c=2,3<=b<a+3`. Other parts use reviewed English proofs and independently checked certificates. The whole classification is not represented as a single Lean theorem.

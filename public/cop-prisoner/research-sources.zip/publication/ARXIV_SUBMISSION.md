# arXiv submission package

Status: prepared for author review; not submitted. The approved author order is Angel Ivanov Raychev, then Alexandra Ignatova. The printed contacts are angel.ivanov.raychev@gmail.com and alex.igntv@proton.me; Alexandra's affiliation is Eindhoven University of Technology. Angel's metadata follows the preceding polyomino paper and prints no affiliation.

## Files

Upload `output/arxiv/arxiv-source.zip`, a byte-identical local copy of the released `manuscript-source.zip`. It contains `main.tex`, `references.bib`, and all nine required PDF figures. Select `main.tex` and PDFLaTeX. The bibliography is already rendered into the TeX; no bibliography run or external style is required. The release builder independently extracts and compiles this archive and compares the resulting PDF text with the reviewed manuscript.

The review copy is `output/pdf/guaranteed-indirect-delivery.pdf`. Do not upload that PDF in place of its LaTeX source. The timing companion is separate and is not included in this submission.

The article links its companion website for the Lean sources, source-pinned verification receipt, full research source archive, and finite strategy certificate archive. Those larger archives need not enter the TeX upload. Their contents and proof boundaries are described in the paper and `publication/EVIDENCE_GUIDE.md`.

## Metadata and remaining submission choices

Use the title, author order and abstract printed in the paper. `publication/arxiv-metadata.json` records the metadata. Recommended primary category: Combinatorics (`math.CO`). Copy the final page and figure counts from the release receipt into the Comments field, followed by the companion URL. Leave journal reference, DOI and report number blank unless one is subsequently assigned.

The author must choose the license in the actual submission flow. No license is silently carried over from the polyomino submission. Review the processed PDF and metadata before the final Submit action. The present preparation does not submit the article or assert a public arXiv identifier.

## Verification statement

The mathematical classification uses ordinary proofs and finite computational proofs. The Lean development proves actual-game equivalence, all dense extrema from order 11, the entire main interval from order 115 and its upper part above 3n from order 25, seventeen smaller complete main intervals, uniform even sparse attainers from support 85 and odd attainers from support 98, sharp unrestricted budgets 0..10, complete joint tables through order 5, and additional certified finite scores and exclusions. It does not yet formalize the complete classification. The exact remaining domains and source-pinned replay boundary are recorded in lean/README.md and research/LEAN_ROADMAP.md. The authorship/contribution statement credits the original project, the prior joint upper bound and construction direction, and the substantial Astra 6 assistance through Codex in the later work.

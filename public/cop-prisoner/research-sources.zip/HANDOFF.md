# Active continuation: 23 October 2026

The user prioritizes **full Lean verification**, beginning with the dense
staircase and a difficult finite exclusion in parallel. Keep the arXiv
package ready; simplify only where it directly helps. The ordinary and
computer-assisted classification remains complete. Full Lean classification
is still unfinished. Do not equate these completion conditions.

The local October campaign has proved the full dense region for n≥20,
the adjacent missing-budget interval 2n..3n for n≥16, the general sparse
parity upper bounds, actual padding and local-arena composition, complete
nine-vertex strict exclusion I≤53, and additional explicit circle families
and exact finite graph scores. See `lean/README.md` for precise domains and
`research/lean-verification-campaign-2026-10-23.md` for proof/performance history.
Sharper finite exclusions and the remaining sparse/main construction chain
are actively being formalized. The source-pinned replay, manuscript, website
and download receipts must agree before calling a new release verified.

The October source snapshot passed a fresh full replay of all148 Lean modules,
including the final axiom audit. The source-pinned receipt identifies the exact
snapshot; only Lean standard axioms occur. The explicit construction and
numerical audit data remain unchanged cell-for-cell; only source pins and
formal-coverage descriptions change. The manuscript remains125 pages and9
figures. Publication/deployment receipts separately record release status.
No arXiv submission or outreach is authorized.
Current user reconciliation threshold is30% remaining account usage. Preserve
approved authorship and contributions.

Continuation priorities: instantiate the six-type cyclic projection and552
canonical local objectives, finish its sparse even/odd bridges; then the
separated pair-code family and finite main-interval bridge; then sharp finite
upper tables and final quantified assembly. The campaign record contains
exact module/API plans and pilot paths. The Hamiltonian-first-factor score30
proof passed and covers one of eight regular factor types; it does not settle
all regular nine-vertex graphs or the18-arrow global maximum. Complete the
lower dense orders11..19 in parallel with those construction/formal-certificate
lanes. For the small tables, prefer one reusable row-prefix checker at the
sharp thresholds; weaker milestone certificates would duplicate final work.

The site worktree was merged with October23 origin/main; preserve its shared
math renderer and typography gate. Lean files now live exclusively in the
existing lean-proofs.zip, rather than also being duplicated in the research
ZIP. Extract research, finite-certificate and Lean archives into one root.

## Previous published checkpoint (18 September 2026)

# Guaranteed indirect delivery: completed classification, simplified proof

Updated 18 September 2026. The objective is complete: determine exact M(n,m) and give an explicit attaining graph for every admissible pair. The current pass simplifies the proof, preserving all values, stronger construction guarantees and finite proof premises. The arXiv-prepared candidate has125pages and9figures: approved two-author metadata, abstract, literature comparison and precise formalization coverage are added; common guide and local-strategy lemmas shorten the proofs. The preceding simplified release had124pages (earlier136). Build, visual acceptance and public deployment are separately recorded in the current receipts; consult them for actual release status.

## Start here

Read README.md, research/CLASSIFICATION_SCOPE.md, research/CLASSIFICATION_GAPS.md, research/EXPLICIT_CONSTRUCTIONS.md, paper/joint-classification-resume.md, paper/finite-completion.md and paper/finite-values.md. The execution record for the new arguments is research/proof-slimming-execution.md. Private brainstorming notes are not current proofs or public release evidence.

The combined formula covers every n>=12; complete tables cover n<=11. ME0..23 is0,0,0,0,1,1,2,2,4,5,6,8,9,11,13,15,19,28,33,40,53,60,79,83. Larger sparse budgets use the retained parity formulas. The main missing-pair formula starts sharply at12, the dense staircase sharply at11, and the zero band is exact at every order. MV7..11 is21,32,48,65,85; MVn=n(n-3) for n>=12.

## Current proof architecture

- Shared source/sink deletion and positive-support counting give the sparse parity upper bounds, equality shapes and stability statements. The finite sparse proof proceeds in budget order12..23. No finite exclusion was inferred from the arithmetic checker or discarded.
- Generalized Theorem59 permits separated pair codes. It gives a two-move, arbitrary-optional-subset interval from B=(4k-2)n-2k(2k+1) through n(n-3), for k>=6 and2k<=n<=k(k-3). The ordinary circle overlap covers3n..n(n-3) at every n>=79. The finite upper bridge is12..78; the distinct low-budget bridge through114 remains. Larger/mixed codes and their stronger ranges are retained.
- An exact functional-tail attachment identity consolidates dense constructions. The n9 rooted-core exception requires four moves, not three; larger cores require at most three. The full dense staircase retains its four-move bound from11 and two-move bound from16.
- The odd periodic projection starts at support98, with residue period bounds15,15,15,17,17,18. Its required finite bridge is13..97; the complete old archive13..144 remains unchanged. Actual frozen-local rank replay, not summary flags, supports the local lemmas.

New read-only checks: src/sparse_upper_kernel_check.py --check; src/main_interval_pair_codes_check.py --check; src/dense_functional_transfer_check.py --check; src/odd_projection_threshold_check.py --check. publication/EVIDENCE_GUIDE.md explains their separate scopes. Cross-reviews checked the new symbolic proofs and preservation of all earlier numbered claims and stronger domains.

## Evidence and replay boundaries

publication/classification-coverage.json still has493,924 exact cells and zero gaps, identical cell-for-cell to the preceding release. research/explicit-construction-coverage.json separately has zero construction gaps. The previous independent finish-ledger review closes all101 formerly unresolved representatives and verifies the1090 cells newly settled in that earlier pass.

The finite proofs retain actual source/sink deletion, live capacities, complete degree families, permanent loss unions and guarded optimistic paths. Some have two full graph enumerators; others have independently reviewed coverage/pruning and full leaf-game replay. Receipts distinguish them. No incomplete run or restricted camping-free bound is an unrestricted upper proof.

Frozen receipts and certificates must not be regenerated merely to match changed source hashes. Explicit historical-pin entries preserve original provenance; fresh audits support the revised proofs. Frozen small-case consumers verify the original odd-theorem bytes retained at research/history/before-slimming-odd-endpoint-resume.md. The older code overlap is also archived. Current numerical and construction receipts are regenerated only after their source changes are reviewed.

## Scope, provenance and authorization

The game is on a loopless simple digraph, opposite arrows allowed. Both players may wait; the messenger moves first; visibility is complete. Actual recipient receipt wins before collision. All other collisions and indefinite evasion lose. Every cop start c!=s and every policy is quantified. Graph reversal and arbitrary vertex/arrow deletion do not preserve strategies automatically.

Explicit means prescribed adjacency or composition with parameters determined from(n,m); generic search, bare existence or derandomization alone is insufficient. Earlier stronger subset/time/routing claims remain. The Lean development remains partial. The current preparation pass adds finite winning/loss certificates, an extremal specification and general vertex bound, a small complete finite-cover pilot and guide attachment. The continuation closes semantic completeness for arbitrary history-dependent policies, proves the dense zero theorem directly from the game and graph, and adds exact-score certificates for mixed winning/losing pairs. Exact compiled coverage is recorded in lean/README.md and lean/verification.json; full classification remains unformalized.

The user authorized proof simplification and website/artifact publication, and lifted the old10% stopping rule. No arXiv submission or outreach is authorized. Optimal delivery time, all-extremizer classification and a general structural D(G) theory remain parked. Approved publication authors are Angel Ivanov Raychev first and Alexandra Ignatova second (Eindhoven University of Technology); emails and the approved contribution statement are recorded in publication/arxiv-metadata.json and paper/main.md. The current user authorizes arXiv preparation, Lean work and further slimming, with the latest reconcile threshold of30% remaining account usage (superseding40%). No actual arXiv submission has occurred. Preserve Alexandra Ignatova's original author credit, Angel Raychev's mentorship, and their original upper bound/two-in-two-out direction; September2026 extensions used Astra6 through Codex.

## Build and release

Website sources are in .site-worktree. The publisher assembles the manuscript and proofs from publication/manifest.json and preserves the existing ten download entry points and parked companion. Historical manuscript arguments remain under research/history. The research ZIP uses reviewed lossless BZIP2 compression for large text evidence; use Python's zipfile extraction and combine it with finite-strategy-certificates.zip in the same directory.

Current receipts: research/publication-build.json, research/pdf-verification.json, research/pdf-visual-review.json and research/website-deployment.json. All served assets and five routes must match the final local build on live readback before reporting deployment verified. Never confuse a completed proof with a published artifact or complete Lean instantiation.


## Earlier verified proof-simplification release — 18 September 2026

The revised 124-page manuscript is published, down from the preceding release's
136 pages. All 124 pages received visual review; the separate eight-page
delivery-time companion remains separate. The seven checks rerun from fresh
extractions of the final downloadable archives all passed, including the new
arithmetic/construction checks and actual replay of all 847 odd-family local
certificate modules. The 493,924 classified finite ledger cells and their
providers are unchanged, and the explicit-construction audit has zero gaps.
Earlier stronger construction guarantees and finite certificates are preserved.

Mathematical/source release commit: de220ab9b9001f87b5831f12168ba17cbbfc3899.
Website commit: dc725f9d65310e2aaba20cc453f207ff992a63a9.
Successful GitHub Pages run: 35328708118.
Live readback matched all five routes, all 36 served assets, and the release
manifest (42 checks). The complete deployment and extracted-archive replay
receipts are preserved in research/website-deployment.json. The earlier public
release receipt remains under research/history.

This pass does not add Lean coverage: the 12 existing modules remain partial
formalization. No arXiv submission or outreach was performed. Further proof
simplification and full formalization remain separate work. This checkpoint is
appended after packaging; the archived notes retain their unchanged prefixes.

## Verified arXiv-preparation checkpoint — 18 September 2026

The125-page,9-figure manuscript is prepared with Angel Ivanov Raychev first and Alexandra Ignatova second, Eindhoven University of Technology. Contacts match publication/arxiv-metadata.json. The approved contribution statement, abstract, literature comparison and rule distinctions are included. No arXiv submission occurred. Upload package: output/arxiv/arxiv-source.zip; guide: publication/ARXIV_SUBMISSION.md.

Two common guide/local-composition arguments remove approximately780proof words while preserving construction domains, optional-subset and move bounds. Added front matter, literature and formalization coverage explain why the final paper is125pages versus the preceding124. All125pages and the separate8-page timing companion were visually checked. Standalone TeX recompilation matches; no overfull boxes or unresolved references remain.

All18Lean modules pass, including the general vertex bound for the finite-strategy score, the exact cell M(12,24)=108, finite exclusion interfaces and a complete64graph pilot, and guide attachment. A fresh extracted copy compiled all18modules. Full classification and the converse from arbitrary eventual strategies remain outside Lean; research/LEAN_ROADMAP.md gives the dependency-ordered continuation. No percentage estimate is implied by module count.

The complete493924-cell ledger and every provider are unchanged; explicit construction gaps remain zero. Guide, pair-code, all-parity and847odd-module replays pass. Refreshed current receipts preserve their original bytes in history and have identical mathematical fields. Historical registry/fourth-pass commands are now explicitly distinguished from current validation commands. Final extracted source, ledger and recipe checks passed; all64 numbered labels and212local links are preserved.

Research source commits:2bb1dd1a4eae8b11b83180b85e6c3e5325ceebcb and a43aa3428220b125568c105c12fafeb7d505ef17. Website commit:fa84dac6a6df1c753e1569bc02f238125193d3cf. GitHub Pages run35334806328 succeeded. Live readback matched all5routes,42assets and release manifest (48checks). research/website-deployment.json retains the final readback and extracted replay.

The final scope-document correction was inserted into the research archive with all other members byte-verified identical, followed by the full artifact audit; the builder's output and release manifest were updated consistently. Research ZIP is104825838bytes, near the100MiB hosting limit: repartition preserved evidence before materially growing it. This is a packaging limit, not a proof limit.

Stable checkpoint reached with42%account usage remaining at the last check, ahead of the requested40%reconciliation threshold. No new searches or proof campaign remain running. These checkpoint lines are appended after packaging; the archive contains the unchanged earlier note prefix.


## Verified semantic-completion checkpoint — 18 September 2026

The continuation closes finite-game semantic completeness in Lean: one fixed legal messenger policy works against every permitted initial cop and every legal history-dependent cop policy exactly when the finite winning-tree predicate holds. A uniform bound is derived rather than assumed. The new exact-score interface kernel-checks both winning and losing pairs, with a four-vertex/six-arrow graph having exactly two guarantees. This example is not a formal extremal upper bound for its cell.

The entire dense zero region is now a Lean extremal theorem, including attainment: DenseZero.maximum_zero proves IsMaximum n m 0 for n(n-2)<m<=n(n-1). The explicit graph takes the first m nonloop ordered pairs lexicographically. Looplessness, enumeration cardinality and exact arrow count are proved. No graph-existence or counting premise is imported. Independent reviews checked both semantic quantifiers and the exact-budget constructor.

All21modules pass the pinned build in37.617seconds, with only propext, Classical.choice and Quot.sound. A fresh combined-archive extraction independently rebuilt all21modules with identical source hashes. The current roadmap is research/LEAN_ROADMAP.md; sparse bounds, the staircase graph-counting bridge, infinite construction parameters and large finite exclusions remain outside Lean. Full classification is not yet a Lean theorem.

The arXiv-ready manuscript remains125pages with9figures, and output/arxiv/arxiv-source.zip is the verified272059-byte upload package. No arXiv submission occurred. All31changedPDFpages were visually reviewed;94others are pixel-identical to the prior accepted rendering. The separate8-page companion PDF is unchanged. Both numerical and explicit-construction ledgers are identical apart from updated source hashes. Standalone TeX replay, extracted source/ledger/recipe checks,64numbered labels and215local links pass.

Research source commit:b0b5ec61222f4a231f39f74225b8a4a302daea29. Website commit:80cd430ac5d0afdea129a242259469f524b9c160. Successful Pages run:35336749386. Live readback matched all5routes,45assets and release manifest (51checks). research/website-deployment.json preserves the identities and extracted replay. The archive partition now places six intact gzip certificates in finite-strategy-certificates.zip. Research/finiteZIP sizes are104673548/104747675bytes, both below100MiB; paths and certificate bytes are unchanged.

Publication preparation, formal source integration and public readback are at a stable checkpoint. All workers are finished; no search or proof job remains running. These lines are appended after packaging, preserving the archived note prefix.

# Dense constructions: explicit adjacency audit

The original audit below records the initial scope-correction checkpoint.
Its finite checks and former threshold twenty are retained as historical
evidence. The dated third-pass supplement at the end gives the new exact
band from order thirteen and preserves the stronger two-move domain.

The current dense domains have explicit attaining graphs. Theorem 58 does not require a random search, a graph solver, or an unspecified root graph. The functional-root condition is an elementary choice of distinct two-element subsets of a prescribed set. Its other branch uses a direct modular core, with a literal eleven-vertex exception. The quadratic caps likewise have formulas for every arc.

The numerical coverage ledger records matching bounds and a source rule; it is not itself an adjacency generator. The parameter choices and composition rules below already specify the attaining graphs. A unified executable dispatcher would be optional implementation consolidation. I found no currently marked exact dense-boundary cell that must be downgraded to existence-only because an attaining graph is unspecified. This conclusion is restricted to the dense families and dense-boundary cells audited here; it does not certify the construction status of every other coverage rule.

This audit preserves the theorems and coverage file. It inspected sources, instantiated existing recipes to check their vertex and arc counts, and compared the coverage predicates. It ran no graph search, attractor solve, or new mathematical exploration.

## Conventions that the construction must expose

Given `(n,m)`, write `L=n(n-1)` and `h=L-m`. The dense routines return a **missing-arrow graph** `F`, not the delivery graph. The required output adjacency is

`G = {(u,v): 0 <= u,v < n, u != v} minus F`.

For any robust envelope `(B,O)` with `|B|=2n`, fix lexicographic order on `O` and take its first `h-2n` pairs. Then `F=B union prefix(O,h-2n)` has exactly `h` missing arrows. The ordinary robust-witness proof covers every optional subset, so prefix selection requires no feasibility search. Confusing `h` with `m`, or returning `F` as `G`, would produce the wrong budget and game.

## The direct core and dense endpoint

At `h=2n`, for every `n>=10`, use `core(n)` in `src/dense_unified_core.py:24`.

- For even `n=2k`, label `P_i=i`, `L_i=k+i` modulo `k`. Missing rows are `P_i -> L_i,L_(i-1)` and `L_i -> P_(i+4),P_(i+6)`.
- For odd `n=2k+1>=13`, add `w=2k`, and replace `P_0 -> L_0` and `P_3 -> L_3` by the two paths through `w`.
- For `n=11`, the eleven missing rows are written literally both in Theorem 58 and in the function. This branch does not ask a solver to find an eleven-vertex core.

These formulas give `|F|=2n`; the resulting graph attains `I=2n`. The proof and the literal eleven-vertex danger-set argument are in `paper/dense-unified-core.md`, “The two-type core.” The finite eleven-vertex certificate and Lean verification strengthen the evidence for the explicit listed graph; they are not needed to select a graph during construction.

## Robust bridge and the finite tiny envelopes

For `n>=16` and `2n<=h<=3n`, call `envelope(n)` in `src/dense_unified_core.py:41` and apply the prefix rule.

- At orders 16 through 21, the routine reads prescribed optional lists. These are also written in the manuscript. Orders 16 through 18 use `research/routing-defect-phase2-dense-tiny-checks.json`; orders 19 through 21 use `research/routing-defect-phase2-dense-small-checks.json`.
- At even orders at least 22, the optional rows are the displayed modular offsets `P_i -> P_(i+6)` and `L_i -> L_(i+4)`.
- At odd orders, the function specifies the subdivided rows and extra optional pair. Four fixed repairs at 23, 25, 27, and 31 are literal constants in the function; 29 and every odd order at least 33 use the uniform rule.

The small lists were discovered computationally, but the published construction is their literal lookup and composition. It does not rerun their discovery programs. Complete compulsory-safe-intermediary lists and independent direct readback establish the arbitrary-subset quantifier.

The separately incorporated `dense_tiny` coverage is also explicit. At orders 10 through 18, read that order's literal `base` and complete `optional` list, and choose the first `h-2n` optional pairs. The respective optional capacities are `0,1,0,4,7,11,16,17,21`. At order 18 the full list reaches `h=57`, whereas the manuscript's selected eighteen optional pairs and corresponding Lean statement reach `h=54`. The full list is a certified external construction, not an existential extension of the selected list. Its literal witness coverage is independently replayed by the coverage generator.

## The two quadratic caps

Both caps use only division with remainder, residue sets, and arc-list comprehension. If both apply, compute the two integer caps and select the larger, breaking ties in favor of the residue-five family. Then apply the same optional-prefix rule for the requested `h`.

For `n=10q+s>=30`, `0<=s<=9`, set `k=5q` and use `src/dense_phase2_uniform_envelope.py:8`. Its old core is the preceding two-type core. Its optional core offsets are

`D={10,15,...,k-5}` on point-to-point rows and `E={5,10,...,k-5}` on line-to-line rows.

Each added vertex `x_a=2k+a` has the two compulsory missing neighbors `P_a,L_(a+3)`. Every directed nonloop pair between added vertices is optional. The full size is exactly

`H5(n)=10q^2+5q+s^2+s`.

For `n=4q+s>=44`, `0<=s<=3`, set `k=2q` and use `src/dense_phase2_quarter_envelope.py:8`. Here the line core row is `L_i -> P_(i+4),P_(i+7)`. The point optional offsets are all nonzero even residues except `±2,±4,±6,±8`; the line optional offsets are all nonzero even residues except `±2,±4,8,10,12`, taken modulo `k`. Each added vertex has compulsory row `{P_a,P_(a+5)}`, and again all nonloop pairs between added vertices are optional. The full size is

`H4(n)=4q^2-26q+s^2+s`.

The complete modular danger-set proofs, including added vertices, are in Theorem 58. Their validity is not inferred from the finite receipts. No choice of a favorable modulus, high-girth graph, or randomly successful offset set remains.

The old `dense48` tag need not force use of an older construction. Its entire numerical domain is covered by the current direct bridge at orders 19 through 29 and by `H5` thereafter. A construction dispatcher can route those cells to these explicit current recipes while retaining the original theorem as provenance.

## The staircase: what “functional roots” actually means

For `n<=h<2n`, compute `r=2n-h` and `k=n-r`. The target value is

`2n-r-ceil(r/2)-1`.

The implemented routine is `staircase(n,r)` in `src/dense_unified_core.py:123`. The direct choices are:

- If `r=1` and `n>=16`, use `first_step(n)`: a core of order `n-4`, four named new vertices, and the seven listed missing arrows. Even and odd attachment rows are fixed constants. There is no attachment search.
- If `r>=2`, first build `functional(r)`: the missing two-cycle `0 <-> 1`, chains `2+2i -> 3+2i -> 0` for `0<=i<floor((r-2)/2)`, and the extra arrow `r-1 -> 0` when `r` is odd.
- If `k=0`, this is the full graph `F`, giving the endpoint `h=n`.
- If `k>=10`, take the disjoint union, as missing graphs, of that functional graph and `core(k)` on labels shifted by `r`. All cross-block delivery arrows are therefore present. Lemma 28 applies because each vertex has a missing outgoing neighbor. The `k=11` branch uses the explicit literal core above.
- Otherwise let `R` be the known indegree-zero vertices of the functional graph: its chain sources and, when present, the spare vertex `r-1`. Its size is `floor((r-1)/2)`. If `1<=k<=binom(|R|,2)`, give each added vertex the next distinct two-element subset of `R` in lexicographic order as its missing row.

Thus the word “root” names vertices of a graph already specified by a formula. It does not refer to an unknown base graph or a graph-existence oracle. The last inequality is exactly the number of available distinct pairs. The code uses `itertools.combinations(roots,2)`; no testing or rejection of candidate pairs is required.

These branches cover every `1<=r<=n` at `n>=20` and the stated smaller-order predicates. A failed predicate is not a claim that no attaining graph exists. The remaining dense cells below order twenty remain unresolved in the ledger.

For `h<n`, every graph has `I=0`. An explicit output can be the first `m` nonloop arrows in row order, as in Proposition 4; no optimizer is needed. The same prescription handles all zero-valued cells and the one-vertex case.

## Coverage semantics and optional implementation consolidation

The relevant coverage rules are `dense58_endpoint`, `dense58_bridge`, `dense58_caps`, `dense58_staircase`, `dense_tiny`, `dense48`, and `dense_zero`. Each now has the direct selection rule described above. The single `dense_zero` name covers two different recipes: the positive functional endpoint at `h=n`, and a zero-count graph at `h<n`. A graph-producing interface must branch on the parameters rather than treat the rule name as a complete instruction.

Coverage stores whichever lower rule first supplied the final bound; it is not a preferred-construction selector. For example, 26 exact endpoint cells in the current finite ledger carry `antichain59` as their retained lower source even though the direct dense core suffices. It is valid to route them to the simpler core without changing the numerical theorem or claiming anything new about antichain selection.

I inspected all 13,155 exact cells in the current ledger with `n>=2` and `m>=n(n-3)`. Every such cell with `n>=7` falls under one of the explicit dense endpoint, staircase, or zero recipes above. The remaining exact cells at orders at most six have literal `witness_arcs` in their complete enumeration records; they do not require rerunning enumeration to recover a graph. There was no existence-only exception in this audit.

I also instantiated 105 core recipes, 99 bridge recipes, 6,479 qualifying staircase recipes, 156 cap recipes, and nine saved tiny envelopes through order 114. Their vertex labels, nonloop conditions, and applicable missing-arrow counts passed. These are adjacency/count checks, not new semantic game verification or a substitute for the ordinary proofs.

The specified branch conditions, literal records, modular parameters, optional-prefix rule, and final complementation already meet the mathematical requirement to obtain adjacency or a clearly specified composition from `(n,m)`. A single executable dispatcher could consolidate these steps, but its absence is not an unmet mathematical construction requirement. The current coverage program calculates bounds and coverage, while the existing construction routines supply graphs; several script entry points regenerate receipts rather than expose one common adjacency-output command. None of the dense recipes needs a solver to decide what graph to output, and certificate replay is separate from graph selection. The central inventory is `research/EXPLICIT_CONSTRUCTIONS.md`; the durable coverage audit is `research/explicit-construction-coverage.json`.

## Third-pass supplement: 13 September 2026

The ordinary strategy and composition proofs in `paper/dense-third.md`,
together with the listed finite graphs, now give the complete final dense
band for every `n>=13`. Write `m=n(n-3)+r`, `1<=r<=n`. Its exact
value is `2n-r-ceil(r/2)-1`, with an explicit attaining graph and a
delivery bound of at most four messenger moves. Every `n>=16` retains
a two-move construction throughout the entire band. The larger domain is
not being labelled two-move merely because the former family had that
stronger property.

**Root-colored cycles.** On the old functional `r`-vertex missing graph,
let `R` be its `floor((r-1)/2)` named roots, and put `k=n-r`.
For `k>=2`, add a missing directed cycle on the `k` new vertices and
one arrow from each to its root color. Alternate two roots when `k` is
even; for odd `k` alternate on the first `k-1` vertices and use a third
root on the final vertex. This gives two-move delivery when `r>=7`
for all `k>=2`, and when `r>=5` with even `k`. At `k=1`, use two
distinct roots; at `k=0`, use the functional endpoint. Equal-color cop
positions are handled by the cycle successor, so no supply of distinct
root pairs is needed for the larger cases.

**Two roots with an odd number of added vertices.** For odd `k>=3`
and `r=5,6`, use the alternating even cycle on `k-1` vertices and a
singleton missing both roots. Its source pairs may use three moves:
first move safely to a cycle cop's successor, then use the already proved
cycle-source strategy. This proves the exact count for every `r>=5`
and every `k`. The constructor `src/dense_third_root_cycles.py:missing_graph`
selects the appropriate fixed rule. It does not solve a game to select
neighbors. The older distinct-pair rule remains an explicit two-move
alternative on its own capacity domain.

**The literal nine-core and exact block addition.** The new missing rows
are `{1,3},{4,7},{5,6},{0,2},{6,8},{2,8},{0,4},{1,5},{3,7}` on
vertices zero through eight. Taking the complement gives `M(9,54)=18`;
all counted pairs win in three moves, while only fourteen pass the exact
two-move criterion. The graph and full certificate are fixed finite data,
implemented by `src/dense_third_core_compose.py:core9`.

Disjoint union of missing graphs with positive missing outdegree has
exactly additive `I`, without a two-move assumption. The source gives the
ordinary strategy proof in both directions. With an original bound `D`,
the general composition gives `max(2,D+1)` moves; the previous two-move
lemma retains its sharper two-move conclusion when its hypothesis holds.
Thus a functional block plus the nine-core works at every `r>=2,k=9`,
and the existing direct core works for every `r>=2,k>=10`. This is a
fully specified composition, not an unspecified small-core existence
claim. In particular it supplies the new smaller cells `(11,90)`,
`(12,111)` and `(13,134)`.

**Three fixed first steps.** At `r=1,n=13,14,15`, start respectively
with the nine-, ten-, and eleven-vertex core and add the old four-vertex
gadget `c->x`, `x->y,z`. Give `y,z` the missing rows `{1,2}/{3,4}`,
`{0,7}/{1,8}`, and `{0,3}/{1,5}`, respectively. These fixed choices
give counts 23,25,27 and move bounds 4,3,3. They are implemented by
`src/dense_third_first_step.py:first_step`; its separate discovery option
is unnecessary for construction or fixed-certificate verification. The
existing first-step formula handles every `n>=16` unchanged.

These cases give a direct selector for the whole `n>=13` final band:
use the first-step branch at `r=1`; at `2<=r<=4`, use the core of
size `k=n-r>=9`; at `r>=5`, use the root cycle/singleton rule.
For the stronger whole-band two-move result at `n>=16`, use the old
core for `2<=r<=6` and the pure colored-cycle rule for `r>=7`.
All parameters and fixed exceptions are determined from `(n,m)`.

The three construction verifiers have read-only `--check` modes and retain
both independent actual-game evaluations and full alternating-state rank
replay on the fixed graphs. Their receipts are
`dense-third-root-cycle-checks.json`, `dense-third-core-compose-checks.json`,
and `dense-third-first-step-checks.json`. This finite evidence is separate
from the unbounded ordinary proofs; no new Lean verification is claimed.
The original eleven-core, optional envelopes, quadratic caps and their
stronger subset/timing properties remain available as previously stated.

**Current residual boundary.** There are 21 dense unknown values:
`r=1,2,3,4` at `n=7,8,9,10`; `r=1,3,4` at `n=11`; and
`r=1,4` at `n=12`. The new second-step equality proof shows that
attaining `2n-4` at `r=2` is equivalent to a fully attaining dense core
on `n-2` vertices. Its missing outdegrees are two; no indegree condition
or two-move hypothesis is inserted. Existing exact tables therefore give
the genuine strict upper bounds `M(7,30)<=9`, `M(8,42)<=11`, which
are not claimed sharp. Failure of a former root-pair or two-move template
still proves no other nonattainment. Every newly known value has a direct
recipe or listed graph, so there is no newly introduced construction-only
gap. The root task owns the final numerical ledger and its source pins.

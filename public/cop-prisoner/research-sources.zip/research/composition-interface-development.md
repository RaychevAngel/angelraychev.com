# Composition-interface research log

13 September 2026. This file records the sparse-composition lane. The
separate core/code and packed-hole improvements belong to the root team's
other research lanes and are not asserted or rederived here.

## Objective and current mathematical boundary

The aim was a genuinely non-ring sparse universal family, ideally retaining
two incoming and two outgoing arcs while reducing delivery time to a
constant times the diameter of a quotient network. The existing ring
families have linear-time delivery. Arbitrary regular covers and naive
independent permutation substitutions were explicitly tested rather than
assumed to preserve their winning strategies.

The independently reviewed result is a ten-type, two-in/two-out safe-cell
navigation lemma. It needs a quotient with no reduced relation through
length eight, has one-move initialization and 32-move steps in either
negative generator. Its exact graph, six exclusions, proof, full finite
layers, and independent audit are in `composition-interface-navigation*`.

The later checkpoint uses twelve exclusions, initialization in two moves,
the same 32-move steps, and full terminal certificates for eight of the ten
recipient types. Its independent audit is now complete: literal arena
reconstruction, all 825,843 new-state obligations, all seven exact seed and
input sets, lane symmetry, and the branch-aware finite-quotient projection
passed. Types 2 and 7 remain open. See
`composition-interface-terminal-checkpoint.md` for the exact domains,
source/recipient placement, and time constants, and
`composition-interface-terminal-independent-audit.md` for the review.

## Negative tests that changed the approach

1. **Arbitrary covers do not preserve universal delivery.** A connected,
   strongly connected two-sheet cover of a universal twelve-vertex graph
   has 24 vertices and 48 arcs, no immediate source-camping obstruction,
   and a losing recipient. For recipient 2 there are 119 losing starts,
   115 with distinct base projections. Both existing exact game solvers
   agreed, and losing-state closure / finite rank data were retained in
   `composition-interface-cover-counterexample.json`. Sixteen sampled
   two- or three-sheet covers of the twelve- and thirteen-vertex bases
   also failed (`composition-interface-covers.json`). These are
   counterexamples to blanket cover preservation, not an impossibility
   theorem for all covers.
2. **Replacing the ring shifts by unrelated permutations fails.** Of 18
   finite tests, the three ring controls passed and fifteen altered lifts
   failed. Some failures were immediate camping; others were actual game
   traps (`composition-interface-lifts.json`). A base strategy cannot
   silently be transported through an arbitrary quotient map.
3. **A finite non-ring gadget is not a parametric construction.** A search
   over 127 port-cycle templates found a twelve-type graph that passed one
   noncircular eleven-cell quotient, giving a 132-vertex finite graph with
   29-move delivery. That is finite evidence only; no universal quotient
   theorem followed (`composition-interface-gadget-screen.json`).
4. **Small group candidates gave mixed evidence.** The directed Cayley
   graph of $A_4$ on generators ($(123),(124)$) is universal on twelve
   vertices, with twelve-move delivery, verified by both exact solvers.
   The tested $A_5,S_4,A_6$ and lamplighter/wreath examples failed. The
   receipts are `composition-interface-cayley.json`,
   `composition-interface-lamplighter.json`, and
   `composition-interface-wreath.json`. No infinite group-family theorem
   or broad group-theoretic obstruction was inferred from these tests.

## Why the joint-state interface was productive

Two copies of the old five-type lane gadget were joined through selected
switches in one arc permutation. Positive quotient steps have a single
entrance gate and cannot be demanded from all local states. Negative
steps have several distinct entrance types. The useful switch set is
$\{0,1,3\}$.

Demanding either negative step from every uncaught state still failed at
three starts. Removing entire messenger types caused many new failures.
Removing six specific messenger/cop configurations instead produced a
closed interface. Its direct certificate checked 121,340 newly winning
states, two sets of 5,384 required inputs, and six literal normalization
cases. A second agent independently reconstructed the transition system
and verified the ordinary quotient projection.

A second switch set $\{1,2,3\}$ gave eight exclusions and 46-move
navigation, but its terminal modules did not improve the main result.
Additional bounded tests of $\{0,3\},\{0,1,2,3\},\{1,3\},\{0,2,3\}$
either collapsed under interface closure or left other terminal failures.
The last set gave a 42-exclusion interface with two-move normalization,
but did not solve all recipient types.

## Terminal-module progression

- The type-0 module needed a nine-exclusion, recipient-specific interface,
  with two-move initialization and 32-move navigation. It delivers to
  type 0 one positive-$a$ cell away in 39 moves. Its lane mirror handles
  type 5. These input conditions were not identical to the initial
  six-exclusion interface.
- A radius-three messenger window gave delivery to type 3 two
  negative-$a$ cells away in 35 moves; symmetry handles type 8.
- An exact context-free closure for empty-voltage paths showed that all
  100 ordered within-cell type pairs are ordinarily reachable. Shortest
  witnesses use at most nine moves and reduced-word depth two. Thus the
  remaining issue was pursuit, not ordinary reachability.
- Restricting arrival types to $\{4,9\}$ gave a valid 356-state boundary
  interface, seven-move initialization, and 49-move transfers. This did
  not finish all terminal types. Several other natural arrival-type
  restrictions collapsed.
- Retaining the cop's exterior branch was decisive. Prefix depth two
  reduced type-1 terminal failures to zero at one negative-$a$ cell,
  with a 62-move bound. Type 4 at the same cell had a single failing
  start: messenger 3 and cop 5 in the anchor cell. Excluding it and its
  lane mirror preserved 32-move navigation and allowed two-move
  initialization. Symmetry gives types 6 and 9.
- Finally, the union of the type-0 and type-5 interface exclusions gave a
  single twelve-exclusion interface. It is closed without further
  losses, normalizes in two moves, and is contained in every successful
  terminal module's input set. Full certificates are saved for the four
  representative recipient types and the three common navigation /
  initialization modules.

The resulting independently audited theorem gives time $32D+64$ for
the eight types on every finite connected simple four-regular quotient
with girth at least 133 and negative-generator directed diameter $D$.
This is not a universally winning family. The high constant girth makes
this an asymptotic structural result, not a small-order construction.

## Why simply enlarging the window cannot finish type 2

The tests retained all exterior components of a radius-three tree, and
also enlarged the represented windows to radius four. Roughly three
hundred failures for type 2 persisted at the best tested anchor. Trying
all seventeen target displacements of length at most two in the
radius-three, depth-two-prefix arena also left failures.

There is a genuine infinite-tree obstruction at the recipient's own
cell. For target $2_x$, a cop camping at $0_x$ guards $6_x$ and the
sole positive-$a$ entrance $0_{xa}$. Starting at $1_x$, the messenger
cannot reach either predecessor $6_x$ or $1_{xa}$ safely. A finite
quotient can bypass this cut outside the local window. A complete proof
must therefore retain how the global approach bypasses a guard, or alter
the gadget, rather than infer that an arbitrarily large terminal ball
will necessarily work from the same unrestricted interface.

One promising partial refinement survives: a negative-$a$ navigation
step can finish in types $\{1,2,3,4\}$, and a negative-$b$ step in
$\{6,7,8,9\}$, in the original 32 moves while preserving the
eight-exclusion interface. Restricting further to $\{1,2,4\}$ leaves
only two exceptional input states for that generator, but has not been
assembled into a point-delivery proof. See
`composition-interface-last-generator-ports.json`.

## Additional arcs and replacement cores

These were bounded diagnostics, not new constructions.

- Several symmetric within-cell chord pairs preserved navigation but
  solved only selected terminal types. The receipts are
  `composition-interface-extra-arcs.json`,
  `composition-interface-terminal-chords.json`, and
  `composition-interface-gate-bypass.json`.
- Adding $4\to6$ and $9\to1$ creates immediate source-camping
  obstructions: the cop can control both original successors of source
  0 or its mirror. Such variants cannot give universal delivery.
- The smallest direct repair of the troublesome target type was to add
  $0_x\to2_x$ and $5_x\to7_x$, raising the arc count from $2n$ to
  $2.2n$. It preserved a six-exclusion navigation interface, but the
  tested branch-aware terminal games still had 199 type-2 failures at
  the recipient cell and 220 type-4 failures at the previous successful
  anchor. It did not complete point delivery
  (`composition-interface-middle-skip.json`).
- The universal $A_4$ core has a useful local property: ports 0 and 11
  tolerate a cop-only exterior that may leave and reenter either port,
  while every recipient inside the core remains reachable in thirteen
  moves. However, assembling cells needs safe port arrival, not immediate
  receipt at a port. Matching- and switched-port transfer tests failed.
  Eighty bounded random involutive cross-matchings also failed the
  strongest two-cell exterior model. These negative sufficient-game
  tests do not prove that all finite core networks fail. See
  `composition-interface-core-ports.json`, `...-core-transfer.json`,
  `...-core-typed.json`, and `...-core-expander.json`.

## Computational discipline and corrected diagnostics

The principal statements are supported by full layers and direct replay,
not merely a fixed-point success flag. Both the original navigation and
the later eight-type terminal checkpoint now have separate literal-rule
and mathematical projection audits. The latter checks all 825,843 newly
winning states across its seven finite certificates.

A Boolean-array implementation of the attractor was added to keep the
larger exploratory windows inexpensive. It was cross-checked, state by
state and layer count, against the integer-mask implementation on both a
170-by-570 arena and a 530-by-650 arena. It is a speed optimization, not
independent theorem verification. The final checkpoint producer uses the
original integer implementation and directly replays the finite layers.

Two diagnostic implementation issues were corrected before any relevant
theorem promotion. A bounded interface loop's `fixed` flag could have
reported convergence after exhausting its iteration cap; the saved
positive case had genuinely converged, and the flag is now explicit.
The full-component exterior-prefix test also initially compared the
prefix of an inside endpoint instead of its outside predecessor when
the prefix was longer than the represented radius. That exploratory
test was rerun after correction. Prefix-depth-two successful modules
were unaffected, and the final certificate producer uses the corrected
entry rule.

No large exhaustive graph enumeration, new Lean formalization, site
publication, or claim of resolving the two remaining types occurred in
this lane. The independently audited result is conditional only on its
explicit quotient hypotheses, not on a missing proof step. The next
sharply defined problem is a final-approach interface for recipient types
2 and 7 that is compatible with global navigation.

# Superseded development: girth-based uniform missing graphs

This draft is retained as research history. Its numbered claims were
superseded before publication by the stronger direct danger-set constructions
in `paper/dense-unified-core.md`. It is not a second live theorem catalogue.

The finite insertion catalogue used in Theorem 19 can be replaced by a
single modular construction. Its smaller orders also improve the dense
staircase. Every construction in this section guarantees the counted
indirect pairs within two messenger moves. These are ordinary proofs;
the accompanying finite checks are not premises of the theorems.

Write $L=n(n-1)$ and let $h=L-m$ be the number of missing arcs.

**Theorem 58 (uniform cores).** A four-regular undirected graph of girth
at least six has a direct construction at every even order $n\ge26$
and every odd order $n\ge41$. In particular,
$$M(n,n(n-3))=2n$$
at all these orders, with two-move delivery. The construction is
deterministic and polynomial in $n$, and uses no stored graph certificate.

**Proof.** For $k\ge13$, use vertices $P_i,L_i$, indexed modulo $k$,
and join $P_i$ to $L_{i-s}$ for
$$S=\{0,1,4,6\}.$$
The six positive differences between members of $S$ are precisely
$1,2,3,4,5,6$. Hence its twelve ordered differences remain distinct
modulo every $k\ge13$. Two point vertices cannot have two common line
neighbors: that would give two representations of the same nonzero
ordered difference. The graph is four-regular and bipartite, and has
no four-cycle. Thus its girth is at least six. This gives every even
order at least 26.

For odd order $n=2k+1\ge41$, begin with this graph on $2k$ vertices.
Remove the edges $P_0L_0$ and $P_{13}L_7$, and introduce a new vertex
$x$ joined to their four endpoints. Both removed edges exist, the
second having step six. We check that every endpoint of one edge has
distance at least four from every endpoint of the other in the old graph.

Vertices in the same bipartition class have distance two only when
their index difference belongs to
$$S-S=\{-6,-5,\ldots,5,6\}.$$
The differences 13 and 7 do not belong to this set modulo $k\ge20$.
For opposite classes, a path of length one or three from $P_i$ to
$L_j$ requires
$$i-j\in S+S-S=\{-6,-5,\ldots,11,12\}\pmod k.$$
Neither 13 nor $-7$ belongs to this interval modulo $k\ge20$.
Thus both cross-class endpoint distances are at least five.

All degrees remain four after the insertion. A new simple cycle uses
two edges incident with $x$. If their old endpoints belonged to the
same removed edge, the remaining old path has length at least five,
so the new cycle has length at least seven. Otherwise their old
distance was at least four, so the cycle has length at least six.
No old cycle becomes shorter. This gives every odd order at least 41.

Orient an Euler tour in the resulting four-regular graph. Each vertex
has two incoming and two outgoing arcs. Its directed complement has
$n(n-3)$ arcs, and Lemma 18 guarantees every pair within two moves.
The missing-pair bound supplies equality. The modular edge lists and
Euler tour take polynomial time. $\square$

## A smaller first step and a complete staircase from order 61

The four-vertex attachment in Theorem 32 only needs four core vertices
$a,b,d,e$ such that
$$\operatorname{dist}(a,b),\operatorname{dist}(d,e)\ge4,$$
with every opposite-branch distance at least two. The new cores provide
these vertices by fixed indices, rather than the degree-ball bound in
that theorem.

In an even core of order $2k\ge28$, take
$$a=P_0,\quad b=P_7,\quad d=P_1,\quad e=P_8.$$
The two designated differences are seven, outside $S-S$ modulo
$k\ge14$. Thus their distances are at least four. All four vertices
are distinct point vertices, so the other required distances are at
least two.

In an odd core of order $2k+1\ge41$, take instead
$$a=P_1,\quad b=P_8,\quad d=P_2,\quad e=P_9.$$
The old bipartite graph has the same distance properties. Its insertion
can create a new path of length two or three between point vertices
only when at least one endpoint is $P_0$ or $P_{13}$: a path through
$x$ with neither endpoint adjacent to $x$ has length at least four.
The selected vertices avoid both exceptions. Their required distances
therefore remain valid.

**Corollary 58.1 (sharper dense staircase).** The equality
$$
M\bigl(n,n(n-3)+r\bigr)
=2n-r-\left\lceil\frac r2\right\rceil-1
$$
has a deterministic polynomial construction with two-move delivery in
each of the following parameter ranges:

1. $r=1$, with either even $n\ge32$ or odd $n\ge45$;
2. $r\ge2$, where $k=n-r$ is even and at least 26, or odd and at
   least 41;
3. $r\ge2$, $k=n-r\ge1$, and
   $k\le\binom{\lfloor(r-2)/2\rfloor}{2}$;
4. $r=n$ and $n\ge2$.

In particular, the entire final dense band is exact at **every
$n\ge61$ and every $1\le r\le n$**.

**Proof.** For the first range, use the preceding four core vertices
in Theorem 32's missing-arc attachment
$$c\to x,\quad x\to y,z,\quad y\to a,b,\quad z\to d,e.$$
Its proof requires precisely the distance conditions just verified.
There are $2n-1$ missing arcs. Every missing pair except $(x,y)$ and
$(x,z)$ has a safe two-move intermediary, while a pursuer at $c$
blocks both exceptional pairs. Hence exactly $2n-3$ pairs count.

For the second range, join the functional missing graph on $r$
vertices with the $k$-vertex core of Theorem 58, exactly as in
Theorem 29. The two-move composition lemma preserves the
$\lfloor(r-2)/2\rfloor+2k$ counted pairs. The third range is the
distinct-pair extension in Proposition 31. The fourth is the
functional endpoint in Theorem 13. The universal bound in Theorem 27
proves optimality in every case.

Now fix $n\ge61$. The first range covers $r=1$. For $r\ge2$ and
$k=n-r\ge40$, Theorem 58 supplies the required core. For
$1\le k\le39$, we have $r\ge22$, so
$$\binom{\lfloor(r-2)/2\rfloor}{2}\ge\binom{10}{2}=45\ge k.$$
The third range applies. Finally $k=0$ is the fourth range. These
cases exhaust the band. $\square$

## A denser optional envelope at smaller orders

**Corollary 58.2 (the linear dense bridge).** At every even order
$n\ge70$, at the additional order $n=62$, and at every odd order
$n\ge129$, each integer $2n\le h\le3n$ satisfies
$$M(n,L-h)=h.$$
One deterministic four-regular missing core and a specified list of
optional missing arcs suffice at each order: **every subset** of the
optional list is safe, including every prescribed intermediate budget.
Every pair delivers within two moves. In particular, the bridge holds
at every order $n\ge128$.

**Proof.** The same bipartite incidence construction works with any
step set whose ordered nonzero differences are distinct modulo the
index modulus. Use
$$
S_6=\{0,1,4,10,12,17\},\qquad
S_7=\{0,1,4,10,18,23,25\}.
$$
Their positive differences are respectively
$$\{1,2,3,4,5,6,7,8,9,10,11,12,13,16,17\}$$
and
$$\{1,2,3,4,5,6,7,8,9,10,13,14,15,17,18,19,21,22,23,24,25\}.$$
Thus $S_6$ gives a six-regular girth-six graph at every even order
at least 70, and $S_7$ gives a seven-regular girth-six graph at every
even order at least 102. Select four step matchings as a spanning
four-regular subgraph, orient its Euler tours, and orient the remaining
edges arbitrarily. Adding any subset of those edges preserves
minimum outgoing degree two and girth at least six. In the six-regular
case the total missing-arc count ranges from $2n$ to $3n$.

At order 62, the step set $\{0,1,3,8,12,18\}$ has all thirty
ordered differences distinct modulo 31, providing the same
six-regular construction directly.

For odd $n\ge129$, take a four-regular 26-vertex block and a
seven-regular block of even order $n-27\ge102$. In the latter,
again select four step matchings. Remove one selected edge from
each block and introduce a vertex joined to their four endpoints.
The two blocks were disconnected, so the insertion preserves girth
at least six in the **full** graph, as well as four-regularity in
the selected spanning subgraph. The initial missing graph has $2n$
arcs after Euler orientation. The full graph has
$$52+\frac72(n-27)+2=\frac{7n-81}{2}\ge3n$$
edges. Its extra edges therefore supply every required missing budget
through $3n$. All subsets retain the oriented four-regular base;
Lemma 18 applies without any order requirement on the additions.
$\square$

Combining Corollary 58.2 with Theorem 48 and Corollary 58.1 gives
the exact formula, with two-move attaining constructions, at every
$n\ge128$ and every
$$n\le h\le n\left\lceil\frac{n-1}{13}\right\rceil.$$
The value is the staircase in Corollary 58.1 for $h<2n$, and $h$
for $h\ge2n$. The earlier protected-difference construction retains
its smaller-order domain $n\ge19$ and arbitrary-subset guarantee;
the isolated periodic endpoints at orders 20 and 25 retain their
separate three-move construction.

The generator `src/dense_unified_core.py` and receipt
`research/dense-unified-core-checks.json` verify the stated modular
graphs, insertion distances, and complete two-move conditions on
explicit finite ranges. The uniform conclusions follow from the
proofs above; no new Lean formalization is claimed.

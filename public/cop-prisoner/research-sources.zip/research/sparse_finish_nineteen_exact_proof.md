# Nineteen arrows: the host row and global maximum

This proposed ordinary proof is for independent review. It gives

`M(9,19)=35`, `M(10,19)=38`, and `M(n,19)=M_E(19)=40` for every `n>=11`.

The positive-degree exclusion sources are the complete joint-profile engine
`src/sparse_finish_positive_fullmax.cpp` and its earlier-guard variant
`src/sparse_finish_positive_fullmax_earlyguard.cpp`. The latter applies exactly
the same sound guarded test one row earlier; it introduces no different game
or pruning assumption. Source and ordinary coverage review of the shared engine
at budget18 is recorded in `research/finish_eighteen_review.md/json`. The new
19-arrow traversals still require their own independent leaf replay and review.

## Smaller budgets and vertices of degree zero

The reviewed14–16 package gives `M_E(15)<=15` and `M_E(16)<=19`.
The independent stronger17 replay in
`research/finish_eighteen_review_seventeen.json` bounds positive9/17 by24 and
positive10/17 by28. An actual source or sink at17 arrows contributes at most
`max(M_E(16),M_E(15)+7)<=22` by the deletion lemma below. Positive support at
least11 has eligible bound at most28, and support at most8 has score at most19
from `research/endpoint40_n8_low_receipt.json`. Thus `M_E(17)<=28`.
The independently reviewed18 package gives `M_E(18)=33`.

For an actual source with outgoing degree `d`, delete that vertex. Old-source
messenger paths cannot enter it, and the cop can remain in the core, so only
the deleted row can add to the core's score. Every live target needs two
predecessors of positive indegree. The `d` removed source arrows cannot supply
them. For an actual sink, old-target winning play cannot enter the sink, and
every live source requires two nonsink successors. Its `d` removed incoming
arrows cannot supply those successors. These two original-direction arguments
give, separately,

`I(G)<=M_E(m-d)+floor((m-d)/2)`.

If `d=1` the relevant row or column is zero, giving `M_E(m-1)` instead.
Budget monotonicity follows by adjoining a new sink with one incoming arrow.
At budget19 every graph with an actual source or sink therefore satisfies

`I<=max(M_E(18),M_E(17)+8)<=36`.

For the fixed9-vertex cell a sharper bound is available. Removing a source or
sink of other degree `d` adds at most `8-d` pairs in its row or column. If
`d=1`, the bound is `M(8,18)=21`; if `d=2`, it is `M(8,17)+6=25`; and if
`d>=3`, it is at most `M_E(16)+5=24`. Isolates can be removed separately, and
support at most8 has score at most22 from the same fixed-host receipt. Hence every zero-degree9/19 case is
strictly below35.

## Positive degree profiles

After isolates are removed, let the support size be `N`, with every indegree
and outdegree positive. For active source and target sets of sizes `q,r`,
overlap `b`, and `w` complement-to-complement arrows, the exact count is

`e(A,B)=19-2N+q+r+w`,

and `q,r<=min(9,19-N)`. The eligible-pair upper is therefore

`q*r-max(0,q+r-N)-max(0,19-2N+q+r)`.

It is at most38 at `N=12`, at most31 for `N>=13`, and the already reviewed
`M_V(8)=32` handles `N<=8`. Supports9,10,11 are the only possible exceptions
to the global upper40.

At `N=11`, an upper above40 requires `q=r=8`; all smaller rectangles give at
most40. The total degree19 then forces eight outdegrees2 and three outdegrees1,
and the same incoming multiset. If `h` is the overlap of the three low-out and
three low-in vertices, then `h=0,1,2,3`, and the eligible count is `46-h-w`.
These are exactly the four generated joint-degree multisets. No camping-free
restriction is imposed on them.

At9 and10 vertices, every decreasing positive outdegree partition and every
indegree assignment sorted only within equal-outdegree classes is generated.
Above35 this gives69 and80 surviving joint-degree multisets respectively.
The exact set of69 nine-vertex multisets agrees with the independently written
`endpoint40_positive_joint_inputs.py` generator, as checked in
`research/sparse_finish_nineteen_profile_control.json`.

## Complete adjacency coverage and changing thresholds

Adjacency coverage, permanent camping losses, stationary-cop guarded losses,
and exact-game early exits are the same mechanisms explained and reviewed in
the18-arrow package. Future vertices may be permuted only when their prescribed
degree pairs and incoming prefixes agree. Every such permutation fixes all
completed rows, so choosing target prefixes retains a representative of every
completion. Loss unions exclude diagonal and direct pairs and retain the
initial-cop-equals-source exception. An unassigned source can receive a column
loss only once that column is full, preventing a future direct arrow from
being counted as a lost indirect pair.

The maximum search begins with threshold35 at hosts9 and10. If an exact leaf
game returns a larger value, the threshold is raised to that literal attained
score. Every later pruning inequality bounds the corresponding completions by
the attained score. Degree-profile generation is finished before any threshold
update, so a larger value cannot suppress an unexamined potentially better
profile. A completed run thus proves the final threshold upper. The9-vertex
threshold remains35. The10-vertex threshold rises from35 to38 only after the
literal38 graph is evaluated.

The11-vertex upper runs begin at40 and never change their threshold. Their
disjoint ranges1 and2–4 cover all four overlap multisets. Timed partial runs
used for discovery and scheduling are excluded from the final upper proof.

| Positive case | Complete profiles | Upper | Final receipt |
|---|---:|---:|---|
|9,19|69|35|`sparse_finish_positive_fullmax_n9_m19_t35.json`|
|10,19|80|38|`sparse_finish_positive_fullmax_n10_m19_t35.json`|
|11,19, profile1|1|40|`sparse_finish_positive_fullmax_n11_m19_t40_p1_complete.json`|
|11,19, profiles2–4|3|40|`sparse_finish_positive_fullmax_earlyguard_n11_m19_t40_p2_4.json`|

## Literal attainment and resulting host row

The final manifest identifies the literal9/19 score35 certificate and its
independent fixed-graph review. The newly found10/19 score38 and11/19 score40
graphs are saved in `sparse_finish_nineteen_38_certificate.json` and
`sparse_finish_nineteen_40_certificate.json`. Their independent reviews verify
2000 and2662 alternating-state obligations respectively, including the complete
closed losing regions. These are exact graph values, not heuristic scores.

For9 vertices, the positive upper35 and zero-degree bound25 match the35
attainer. For10 vertices, positive support10 is bounded by38, support9 by35,
smaller support by32, and zero-degree graphs by36, matching the38 attainer.
For every larger host, the global positive upper40 and zero-degree bound36
match the11-vertex40 graph with added isolates. Hence the least host attaining
the global19-arrow maximum is11.

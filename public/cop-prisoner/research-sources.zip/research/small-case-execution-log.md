# Small-case execution, 13 September 2026

Starting checkpoint: commit `9bc812f4f9b0422918904d9036631968214646ae`, clean
source tree, 454 canonical unknowns (254 sparse, 179 main, 21 dense).
Authorization: execute all proposed research directions and reallocate effort
according to results. The old usage cutoff is lifted. No arXiv submission or outreach.

## Accepted mathematical checkpoint

The canonical registry is `small-case-results.json`, generated from separately
approved upper proofs and independently checked literal/staged lower certificates.
`small-case-approved-bounds.json` is the explicit upper/reduction inventory.
The current ledger has 101 representatives: 69 sparse and 32 main, none dense.
All representatives have at most eighteen vertices. This reduction combines new
exact values with proved equivalence of larger hosts, not 353 individually solved
old values. The independent affine-ledger regression records that distinction.

- Every seven-vertex budget is exact. Twenty formerly open budgets have complete
  independent upper enumerations and matching saved graphs.
- The whole final dense band is exact at every order. The uniform staircase
  starts sharply at eleven. Its explicit construction uses at most four moves
  from eleven, retaining the stronger two-move theorem from sixteen. The finite
  nine-vertex, 55-arrow witness needs five moves; it is not silently included
  in the four-move bound.
- Literal asymmetric stages establish the missing-pair bound on n8:24..26,
  n9:24..54, n10:28..70, n11:25..88 (some endpoints were already known).
  All 64 new stages have independent checks for every optional subset between
  base and envelope, including every legal cop reply and decreasing ranks.
- M_V(11)=85. The exceptional eleven-vertex budgets22,23,24 have values79,78,79.
  Thus every admissible n>=11,m>=22 has its value and an explicit attainer;
  the uniform main-interval formula still starts sharply at twelve.
- A regular ten-vertex, twenty-arrow graph scores53. The global bound is now
  53<=M_E(20)<=57. Complete regular and one-transfer exclusions do not establish
  the global value53; other profiles remain relevant.
- For budgets12..21, respective universal host caps are
  12,13,16,18,15,18,15,18,11,15. The20-arrow argument first excludes support13
  above53, then compresses the remaining twelve-vertex form to eleven using
  Angel's fresh-sink attachment. It does not assert every competitive graph
  already has support at most eleven.
- M(8,12)=M(9,12)=9, M(8,13)=11, M(8,39)=14 are exact.
  The reviewed loss argument gives12<=M(8,40)<=13; this pair remains open.

## Independent attacks and precise verification boundaries

`src/small_case_certificate_review.py` imports no game solver or constructor.
It reconstructs all legal alternating moves, receipt/collision priority,
strictly decreasing winning ranks and the closed losing region. Those checks
prove fixed-graph scores, not completeness of an extremal graph enumeration.
`src/small_case_stage_review.py` independently replays arbitrary optional subsets
through a base/envelope state certificate rather than checking only endpoints.

The n7 upper computation has two complete independent enumerations. The large
n11,m23 and m24 exclusions have ordinary completeness/pruning reviews and
independent controls; we did not rerun a second complete hundred-million-node
traversal. Tiny rooted dense families were independently re-expanded, with
negative full-game rank certificates. The8,39 review independently covers all
22 symmetry representatives and their3168 leaves, not a second traversal of
the original46344 prefixes. The8,40 loss review replays both complete two-out
normal-form checks, combined with the separately reviewed degree-one cases.
The tiny-budget review compares the enumerator to the independently audited
n7 code, checks profile completeness and literal witnesses; it is not a second
complete larger-host enumeration. Support arithmetic has two independent
implementations and a separate ordinary compression proof.

All new finite proofs remain external to Lean. The existing twelve Lean modules
and their exact source-pinned verification are preserved; no full concrete
classification in Lean is claimed.

## Failed approaches, corrections, and lessons

- The tentative20-arrow score50 was disproved by the53 graph. Degree profiles
  capable of beating53 replaced the old target; unsuccessful discovery supplies
  no upper bound.
- A rooted-interface draft wrongly made every root arrival terminal. Review
  caught it: only actual recipient arrival wins immediately; an intermediate
  root must survive capture. Current certificates use this corrected rule.
- Deleting one arrow while protecting every old indirect pair failed on both
  universal7/21 and8/24 seeds. Optimizing the actual score and then certifying
  asymmetric stages succeeded. This supports studying controlled losses rather
  than assuming all old pairs must survive each edit.
- Ascending-degree enumeration at n11,m24 was incomplete after its bounded run.
  Placing the largest degree first reached a complete exclusion. The incomplete
  pilot is retained as history, not used as nonexistence evidence.
- Early arithmetic host-cutoff pilots used a nominal19-arrow score30 at ten
  vertices without an actual witness. The verified comparison uses eleven
  vertices: the9/18 graph plus a disjoint arrow. The final cutoff18 is unchanged.
  `small-case-host-cutoff-pilot.json` and `small-case-host-cutoff-independent.json`
  are historical arithmetic experiments, not the current witness inventory.
- Source and predecessor camping losses must be counted as a union. Rooted
  arrival semantics and repeated-pair losses were actively audited to avoid
  a false exclusion based on double counting.

## Resource decisions and remaining work

Dense constructions and finite exclusions proved productive and received more
attention. The new eleven-vertex graph was promoted into a stage interval and
reviewed before incorporation. Structural degree accounting replaced unrestricted
large-host search; the fresh-sink compression further reduced the20-arrow host.
The remaining101 representatives, their exact domains and next approaches are in
`CLASSIFICATION_GAPS.md`. They still require upper proofs and explicit attainers.

This file is the research record. Build, visual review, archive validation and
actual website deployment are separate claims recorded in `pdf-verification.json`,
`publication-build.json`, the publication audit and `website-deployment.json`.
The existing download entrypoints are retained; the consolidated registry is the
entry to this pass, while raw pilot files preserve unsuccessful work and provenance.

# Independent audit of the 11-vertex 22/23-arc enumerations

## Accepted conclusion and verification boundary

Both complete enumerations are sound. Their maxima of 66 at22 arcs and
74 at23 arcs apply to the class with no source or recipient camping
obstruction. Combining these values with the elementary obstruction
bounds proves the unconditional statement:

> Every graph on11 vertices with22 or23 arcs has I<=81.

This is not an assertion that either unrestricted maximum equals81.
I independently reviewed the mathematical coverage, pruning, recursion,
and exact game semantics, freshly compiled and reran both original
sources, and reproduced all counts and witnesses. This is independent
review and re-execution of the same enumerator sources, not a separately
implemented enumeration. Both returned witnesses were additionally
checked using the two original independent game solvers and every
explicit rank/losing-closure obligation.

The proof below combines this with completed support12 exclusions to
sharpen the global arc-only bound to83<=M_E(23)<=86. It asserts no more
than these completed checks support. No new Lean coverage is claimed.

## Coverage of the degree patterns

If some vertex has outdegree at most one, at most ten vertices can
contribute source rows; each row contributes at most11-3=8 pairs, so
I<=80. A low-indegree vertex gives the same bound through columns.
Thus it suffices to treat graphs of minimum indegree and outdegree two.
At22 arcs all these degrees equal two. At23 arcs there is exactly one
outdegree-three vertex U and exactly one indegree-three vertex V.

For22 arcs, the usual bipartite representation is2regular and its even
cycles decompose into two perfect matchings, hence two permutations.
One matching is fixed to each cycle partition with no singleton cycles,
and all compatible second permutations are enumerated. Simultaneous
relabeling of source and recipient labels puts the first permutation
in one of these representatives, so the cover is complete.

For23 arcs, a perfect matching still exists. If S is a set of left
vertices, its incident arcs number at least2|S|. The total incoming
capacity of N(S) is at most2|N(S)|+1. Therefore |N(S)|>=|S|. One can
use the standard augmenting-path proof: a nonperfect maximum matching
would yield alternating reachable sets with |N(S)|=|S|-1, contradicting
this inequality. Removing a perfect matching leaves residual outgoing
degrees one, except U of degree two, and residual incoming degrees one,
except V of degree two.

The first matching is again represented by a loopless permutation P
in canonical cycle-partition form. Its symmetries rotate each cycle and
permute cycles of equal length. Consequently U can be placed at the
first vertex of one representative cycle for each distinct cycle length.
Every location of V is still enumerated. This justifies `u_options` in
`small_exceptional_one_excess.cpp`; it is not an unexplained restriction.

Residual rows are then filled completely. Every ordinary row chooses
one head; row U chooses two distinct heads in increasing order. Each
column's residual capacity is one or two according as it differs from
V or equals V. All assignments respect those capacities. At the final
row, their total equals the total capacity n+1, so every column capacity
is met. Forbidding the diagonal and the already used P-edge ensures a
simple loopless graph. This covers every residual graph and may count
some more than once, which is harmless for maximization.

## Partial pruning is safe

A completed source row with N+(s) contained in N+[c], c!=s, is a valid
source camping obstruction. A completed recipient column with N-(t)
contained in N+[c] is a valid recipient camping obstruction. It is safe
to use an incomplete cop row: later additions only preserve an inclusion
already true. It is not safe to use an incomplete messenger row or
recipient column, and neither implementation does so.

In the regular source, the current row is complete after its second
permutation edge is inserted; old rows are guarded by `assigned`.
A recipient is complete exactly when its second predecessor is assigned,
guarded by `beta_inv`. The new row is tested against old complete
columns; each newly completed column is tested against all current cop
rows. Thus every completed graph with a camping obstruction is pruned.

In the one-excess source, `ready` identifies complete residual rows,
and `used[t]==cap[t]` identifies complete recipient columns. The row U
is marked ready only after both residual heads are inserted. Tests
include both newly touched columns and all previously completed columns.
The backtracking operations restore capacities, readiness and bit masks;
P-edges cannot be accidentally removed because residual heads differ
from P[r]. Distinct residual heads in U avoid overlapping rollback bits.

These pruning rules restrict the enumerated class, but that does not
invalidate the claimed unconditional bound. At22 arcs there are88
missing pairs. Source camping destroys8 of them and recipient camping
at least7, so any pruned graph has I<=81. At23 arcs there are87 missing
pairs. Outdegree is at most3, so source camping destroys at least7 pairs.
Indegree is at most3, so a recipient camper rules out every source
outside N-(t) union {t,c}, at least11-3-2=6 sources. Hence again I<=81.
Every counted failure concerns a missing nonloop pair and a legal initial
pursuer distinct from its source.

## Recurrence and replay

Both sources use the least finite reachability attractor. The recipient
row is initially winning against every cop position. A messenger
successor is safe when all cop moves, including waiting, lead into the
preceding winning set; nonrecipient collision positions are removed.
The fixed point is reached from the terminal seed, so eventual receipt,
rather than mere perpetual evasion, is required. Only missing nonloop
pairs winning against every legal initial cop position are counted.
These semantics agree with the explicit alternating-state verifier.

Fresh replay results (excluding elapsed time) agree exactly with the
primary receipts, including their maximizing graph:

| Arcs | Matching partitions | Excess locations | Partial nodes | Camping-free completed graphs | Maximum I there |
|---:|---:|---:|---:|---:|---:|
|22|14|not applicable|2177946|120302|66|
|23|14|330|31536058|792080|74|

Sources:
- `src/small_exceptional_regular_max.cpp`;
- `src/small_exceptional_one_excess.cpp`.

Independent re-execution receipts:
- `research/odd-endpoint-regular-max-audit-replay.json`;
- `research/odd-endpoint-one-excess-audit-replay.json`.

The two-solver full rank certificates for the saved maxima are
`research/odd-endpoint-eleven-maxima-witness-audit.json.gz`.
`research/odd-endpoint-eleven-enumeration-audit.json` hashes the exact
sources, primary/replay receipts and witness certificate.

## Global consequence at23 arcs

Assume I>=87, and use the active-set notation of
`research/odd-endpoint-near23-reduction.md`.
The cases q,r<=10 and min(q,r)<=9 still give at most83 and82.
For (q,r)=(10,11), I<=91-b. If b>=5 this is at most86. If b<=4,
A\B has at least6 vertices, at least5 of indegree zero. They emit at
least10 arcs; at most3 can land in the one possible indegree-three
recipient (and then none can land outside B). Thus at least4 distinct
indegree-two zero columns occur, giving I<=10(11-4)=70. The dual handles
(11,10). Consequently q=r=11.

The previous bounds for b<=9 are all at most84. When b=10, either a
zero row/column already gives at most82 or the graph is one of the
two support12 patterns with distinct degree-one source and recipient.
When b=11, an all-internal23-arc graph or a surviving22-arc core is now
bounded by81 using the audited lemma. The external sink/source cases
kill whole rows or columns and are below87. The only remaining case
is the support12 pattern with one vertex of indegree and outdegree one.

All three support12 enumerations were already completed at threshold87,
not merely at threshold88 or89. They found no graph with I>=87.
Therefore the assumed global I>=87 is impossible, and M_E(23)<=86.
The independently certified83-pair witness gives83<=M_E(23)<=86.

# Explicit functional extensions for every fixed dense offset

## Status and provenance

This construction was derived in September 2026 while investigating Angel
Raychev's proposal to determine the growing loss in the final dense band.
It extends the functional missing-edge extremizer, using distinct pairs of
its source vertices instead of requiring a separate universal complement
block. The proof was independently checked by the root agent and the
construction-audit agent. It is ordinary mathematics, not a new Lean result.

The polished statement and proof are Proposition 31 of
`paper/followup-extrema.md`.

## Construction

Let `n=r+k`, `r>=2`, `k>=1`, and `j=floor((r-2)/2)`. Suppose
`k<=binomial(j,2)`. Start with the missing-edge functional graph on r
vertices:

* a two-cycle `a->b->a`;
* `s_i->t_i->a` for `1<=i<=j`;
* an extra `z->a` if r is odd.

Add k vertices H. Assign a distinct two-element subset A_v of the roots
`{s_1,...,s_j}` to each v in H, and put precisely the two arcs `v->A_v`
in the missing-edge graph F. Thus F has n vertices and h=r+2k=2n-r arcs.

In the actual graph G, the complement of F, all 2k missing pairs whose
sources lie in H are guaranteed in two messenger moves:

* A functional pursuer c has exactly one missing outgoing neighbor u,
  which is an a, b, or t_i. It is a safe intermediate between the H-source
  v and its root recipient t.
* A pursuer c in H different from source v has an element
  `u in A_c minus A_v`, because the two-element sets are distinct. Then
  `v->u->t` are actual arcs: the only missing arc from root u is to its
  own t_i, whereas recipient t is another root. Also u differs from t,
  because t belongs to A_v.

All j original missing pairs `s_i->t_i` remain guaranteed:

* A functional pursuer c different from s_i can use its sole missing
  outgoing neighbor as a safe intermediate, exactly as before. The only
  functional missing arc entering t_i comes from s_i, and none enters s_i.
* For a pursuer c in H, select a root `s_l in A_c` with l different from
  i. Then `s_i->s_l->t_i` is safe.

Every selected intermediate is distinct from source, recipient, and
pursuer, and the pursuer has no actual outgoing arc to it. Thus waiting
and collision conventions introduce no exception. After one safe response
the next messenger move reaches the recipient with immediate receipt.

The j+2k guarantees equal

`2n-r-ceil(r/2)-1`.

The growing-loss upper bound proves exact attainment. The upper bound also
avoids any need to classify the other missing pairs directly.

## Uniform consequence

At every n>=75 and every k=1,...,51, one has r=n-k>=24 and j>=11, so
binomial(j,2)>=55>=k. Thus all these offsets are attained. For k>=52,
the separate high-girth complement block gives the previously proved
attainment whenever r>=2. The k=0 endpoint is the functional theorem.
Together these prove the growing bound sharp for every r=2,...,n at n>=75.
The separate r=1 construction supplied by the other proof branch closes
the entire final band; its proof and precise threshold are documented
independently in `paper/dense-first-step.md`.

## Reproduction and adversarial checks

`src/dense_functional_extension.py` generates the missing arcs and checks
every candidate pair against every legal initial pursuer position using
the exact safe-two-move criterion. On a missing arc s->t, put
`B=Fout(s) union Fin(t)`; this already contains s and t. A legal cop c
admits a safe intermediate precisely when `Fout(c) minus B` is nonempty.
The check found exactly the predicted count at n=75 for all 51 offsets.

The five cases `(r,k)=(6,1),(7,1),(8,2),(8,3),(9,3)` additionally pass both
full reachability solvers and all explicit winning-rank and losing-closure
certificate checks. Their respective `(n,I)` are `(7,4),(8,4),(10,7),
(11,9),(12,9)`. The receipt, including every n=75 missing-edge graph and
the generator hash, is `research/dense-functional-extension-verification.json`.

The finite calculations are support for the ordinary proof, not its
parameter justification. The proof depends on distinct two-element sets,
not a conjecture inferred from the samples. Assigning the same pair to two
H-vertices would fail: one can camp as pursuer and intercept every allowed
departure from the other, so the distinctness condition is essential.

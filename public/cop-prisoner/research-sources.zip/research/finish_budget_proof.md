# Global budgets 14, 15, and 16

The completed finite exclusions in this package give

\[
M_E(14)=13,\qquad M_E(15)=15,\qquad M_E(16)=19.
\]

Each value is attained on eight vertices, and hence on every larger host by
adding isolates. The smallest attaining host is eight: the already reviewed
seven-vertex values at these budgets are respectively 10, 11, and 12. This
package is a proposed proof for independent ordinary review. Its separate
leaf replay checks every graph reaching the game solver with an independent
explicit alternating attractor; it does not independently regenerate all
graph branches.

## Inputs and budget order

Use the approved global values through 13 arrows, in particular
`M_E(11)=8`, `M_E(12)=9`, and `M_E(13)=11`. Prove 14 first, then 15, then 16.
The reviewed fixed-host results `M(8,14)=13`, `M(8,15)=15`, and `M(8,16)=19`
are recorded in `endpoint40_n8_sparse_receipt.json`, with literal full-state
ranks in `endpoint40_n8_sparse_lower_certificates.json`. They cover all graphs
with support at most eight because adding isolates preserves the score.
The seven-vertex strict inequalities come from
`small-case-n7-independent.json`.

All graphs are loopless digraphs. Messenger and cop may wait, the messenger
moves first, the initial cop differs from the source, and receipt at the target
precedes capture. A counted pair is distinct and is not an arrow. No assumption
of strong connectivity is made.

## Deleting an actual source or sink

Write `v` for a vertex of indegree zero and outdegree `d>0`. Old-source
messenger paths cannot enter `v`. Restrict the cop to the remaining graph:
every old pair guaranteed in the original graph is guaranteed after deleting
`v`. Thus the only additional counted pairs can belong to row `v`.

Every live target column needs at least two predecessors of positive
indegree. Indeed, any indirect delivery must enter the target from a
predecessor reached by an earlier arrow, so that predecessor has positive
indegree. If there is only one such predecessor, a cop initially stationed
there prevents delivery. It differs from the source of every counted pair:
otherwise the pair would have been direct. The `d` arrows from `v` cannot
provide these predecessors. Consequently

\[
 I(G)\le M_E(m-d)+\lfloor(m-d)/2\rfloor. \tag{1}
\]

For an actual sink, delete its incoming arrows instead. A successful old-target
strategy never needs to enter that sink; entry would trap the messenger away
from the target. Restricting the cop again gives the comparison with the
deleted graph. Every live source row needs at least two nonsink successors:
if there is just one, the cop camps on that successor; a move to any other
successor traps the messenger, and immediate receipt is excluded because the
counted pair is not direct. The arrows entering the deleted sink do not provide
nonsink successors. This proves (1) separately for sinks.

When `d=1`, the relevant row or column contributes zero, so the sharper bound
is `M_E(m-1)`. The use of smaller budgets in these inequalities is justified
by monotonicity: adjoining a new sink with one incoming arrow preserves every
old guaranteed pair and does not create new counted pairs. If the cop moves
to the new sink it is trapped; old losing pairs retain their old cop strategy.
The new sink's column has a sole predecessor and its row is empty.

For a graph exceeding the proposed upper, degree-one sources/sinks are therefore
impossible. If `d>=3`, (1) and budget monotonicity give the following upper
bounds:

| Budget | Proposed upper | Bound for `d>=3` |
|---|---:|---:|
|14|13|`M_E(11)+5=13`|
|15|15|`M_E(12)+6=15`|
|16|19|`M_E(13)+6=17`|

Thus every source or sink of a hypothetical counterexample has other degree
exactly two. Such a source must have a live row, and such a sink a live column:
otherwise deleting it already leaves the upper 9, 11, or 13 respectively.
There can be no source-to-sink arrow, since that leaves its degree-two source
with at most one nonsink successor. After isolates are removed, each vertex
has total degree at least two. The support is therefore at most `m`.

## All-source and all-sink capacity bounds

Let `S` be the sum of outgoing degrees of **all** vertices of indegree zero;
let `T` be the sum of incoming degrees of **all** vertices of outdegree zero.
None of the `S` source arrows supplies a predecessor of positive indegree,
and none of the `T` sink arrows supplies a nonsink successor. If `R,C` are the
numbers of live rows and columns, respectively, then

\[
 R\le\lfloor(m-T)/2\rfloor,\qquad
 C\le\lfloor(m-S)/2\rfloor. \tag{2}
\]

These are two separate counts; there is no claim that a graph may be replaced
by its active vertices. For any degree-two source, deletion also gives
`I<=M_E(m-2)+C`; for any degree-two sink it gives `I<=M_E(m-2)+R`.
The profile inventory rejects a shape when either comparison already bounds
the proposed score.

Let `A={v:d+(v)>=2}`, `B={v:d-(v)>=2}`, with sizes `q,r` and overlap `b`.
Every counted pair lies in `A x B`. If exactly `u<=R` rows and `v<=C` columns
are live, their overlap has size at least `max(0,b-q-r+u+v)`. At least
`max(0,2u+2v-m)` arrows run from those rows to those columns, by intersecting
their outgoing and incoming arrow sets. Therefore

\[
 I\le\max_{0\le u\le R,\ 0\le v\le C}
 \{uv-\max(0,b-q-r+u+v)-\max(0,2u+2v-m)\}. \tag{3}
\]

The inventory applies (2), (3), and the deletion comparisons together. They
are necessary conditions only; no surviving integer pattern is presumed
realizable.

## Complete joint-degree inventories

For positive-degree graphs on `N` vertices, `q,r<=m-N`. At budget 14,
supports `N>=11` have score at most 9. At budget 15, supports `N>=11` have
score at most 15: if `q=r=4` the rectangle contains at least one direct arrow;
all smaller rectangles have size at most 12. At budget 16, supports `N>=12`
have score at most 16. This leaves the positive families shown below.

For each remaining support, `finish_budget_run.py` generates every
nonincreasing outdegree partition of `m`. It assigns incoming degrees with
sum `m`, sorting them only within equal-outdegree groups. Every joint-degree
multiset appears once. In the zero-degree mode it permits precisely
`(d+,d-)=(2,0),(0,2)`, or pairs having both entries positive, and requires at
least one zero entry. The support cutoff is the proved `N<=m` above.

Put `ell_out=sum_{d+<2}d+` and `ell_in=sum_{d-<2}d-`. There are at least
`m-ell_out-ell_in` arrows from `A` to `B`, so an additional safe eligible-pair
upper is `q*r-b-(m-ell_out-ell_in)`. The inventory discards only when this
upper, (3), or the deletion bound is at most the threshold.

The complete remaining degree-multiset counts are:

| Budget, threshold | Positive supports and counts | Degree-two source/sink supports and counts |
|---|---|---|
|14, 13|9: 11; 10: 1|9: 267; 10: 68; 11: 4; 12–14: 0|
|15, 15|9: 35; 10: 7|9: 726; 10: 294; 11: 65; 12: 4; 13–15: 0|
|16, 19|9: 52; 10: 17; 11: 2|9: 76; 10: 19; 11–16: 0|

## Adjacency coverage and permanent losses

The positive and zero-degree engines assign each outgoing row completely.
Earlier vertices are singleton target choices. Future vertices sharing the
same desired degree pair and identical already-assigned incoming prefix may
be permuted freely while fixing every assigned row. Choosing a prefix of each
such class therefore retains a representative of every graph orbit. Both
directions of an arrow remain independent. Required degree sums and residual
capacities are enforced. Only the zero-degree mode forbids source-to-sink
arrows, by the ordinary argument above.

At a prefix, the eligible upper is refined by subtracting every already-fixed
arrow from `A`'s complement to `B`'s complement. Future such arrows can only
reduce it. Two permanent camping losses are unioned, preserving the exception
that the initial cop cannot equal the source:

* If an assigned row's entire outneighborhood lies in the closed outneighborhood
  of an assigned cop vertex different from its source, all its indirect pairs
  lose.
* If a completed target column has all its predecessors in such a closed
  outneighborhood, its pairs lose except possibly the pair whose source equals
  that cop vertex.

Losses are subtracted only for distinct, nonadjacent eligible pairs. For an
unassigned source, a column loss is used only after the column is full, so that
the pair cannot later become direct. No arbitrary collection of guaranteed
pairs is treated as messenger reachability.

The guarded test gives the messenger all individually possible remaining
arrows, while retaining only already-fixed cop arrows. A cop may remain at any
vertex `c`. Internal messenger positions must avoid its closed outneighborhood
to avoid capture on the next cop move. The test computes transitive closure
in that allowed region, allows the initial escape from the source, and treats
the final arrow into the actual target separately because receipt precedes
capture. Failure even in this optimistic messenger envelope proves a permanent
loss. Unions over cop vertices retain all initial-source exceptions.

The zero-degree engine also applies deletion at each prefix. For each actual
source `s`, add the core bound 9, 11, or 13 to the number of eligible pairs in
its row that are neither fixed direct arrows nor permanent losses. For an
actual sink use its column instead. Unassigned arrows can only reduce that
potential. If any such bound is at most the threshold, the whole branch is
excluded. At no point are cop vertices removed from the actual game by this
prune: it is a comparison with the separately bounded graph obtained by
deleting an actual source or sink.

## Terminal checks and evidence boundary

Every completed adjacency surviving those tests is solved by the ordinary
least winning fixed point. Direct pairs are omitted from the count. Early
termination is allowed only when the accumulated count plus all remaining
eligible columns is at most the threshold. Every primary receipt has
`complete=true`, `counterexample_found=false`, and equal visited and total
degree-pattern counts. A deadline sets `complete=false`; incomplete earlier
experiments in the exploratory logs are not used as upper evidence.

`finish_budget_leaf_review.py` replaces the compressed game at every reached
leaf with `finish_alternating_review.hpp`, an independent queue over both turn
types. It solves every target completely and checks equality of the traversal
counters with each primary receipt. Sampled guarded-loss checks use the same
independent game with distinct messenger and cop move sets; their exact sample
counts are separate from the complete leaf replay. The manifest pins all
sources, profile lists, final receipts, full-rank lower inputs, and logs.

The completed replay checked all **118,547** reached leaf games across the
28 residual families, with identical enumeration counters. It also verified
2,387 permanent losing pairs from 443 sampled guarded-prune states. Those
samples supplement the ordinary prune proof; they are not complete prune
enumeration. An additional 17-arrow family happened to be present during the
first replay and is visible in the raw log, but is outside this manifest and
outside every claim here. The final replay receipt includes only 14–16.

The required conclusion follows in budget order from the complete support
split, the finite exclusions, and the eight-vertex attainers. Larger hosts add
isolates; smaller hosts are bounded by the retained seven-vertex row.

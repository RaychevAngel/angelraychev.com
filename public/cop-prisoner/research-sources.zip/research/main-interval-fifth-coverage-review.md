# Final fifth-pass coverage and constructor review

13 September 2026. This independently reviews the finalized67-record,
638-stage bundle, its use by `src/main_interval_complete.py`, and the
change from `research/history/classification-coverage-before-fifth.json`
to the current numerical ledger. No mathematical source was edited.

## Final bundle identity and stage coverage

The final bundle SHA256 is
`e37ebadb62816223fbba35109886d02dd994e3d09f8fd83104ac3f7925d9d411`.
Every638 member hash and raw byte length was read back, covering214714264
uncompressed bytes. The internal manifest agrees with the external record
file, and the summed complete-replay counts agree:

* 53678566 source/pursuer/recipient states;
* 177279925 nonterminal pursuer replies;
* 2495953 direct terminal moves.

These are the root's complete replay totals recovered from the verified
manifest, not claimed as a second full Python replay. The previous
441-stage snapshot review remains preserved separately.

The generalized constructor correctly uses the actual base arrow count,
including downward-discovered chains whose base is not2n. It locates both
the record and containing stage, so two records at the same order do not
collide. Reversed deletion lists are now increasing arrow lists; each saved
certificate independently proves its literal lower-base/upper-envelope
claim, so no monotonicity of deletion is assumed. All prefix indices,
arrow ranges, looplessness, uniqueness, stage counts and containing
intervals were checked.

The supplied stages cover2752 formerly unknown cells in the ascending
low/middle prefixes and another538 in the descending small-order part.
All3290 satisfy the final ledger's asserted value. Previously known cells
between stages retain their independent old constructions; they are not
silently attributed to an unverified stage prefix.

## Independent new rank samples

`research/main-interval-fifth-fresh-rank-review.json` supplies fresh checks
against the final bundle for the upward order13 stage75..78 and the
downward order18 stage108..110. An independent Python parser and direct
rank replay checked all8029 states and30769 pursuer replies in these two
envelopes, for every recipient. A separately written explicit two-turn
priority-queue attractor matched the stored minimum ranks at the first,
middle and last recipient of each envelope. This complements the earlier
independent samples at orders12,91,103 and specifically exercises the new
extended and reversed chains.

## Conservation of every previous numerical claim

All493924 admissible cells in the stored finite box were decoded
individually. Every one of the486698 previously exact values is unchanged.
No lower bound decreased; no upper bound increased. Exactly5962 lower
bounds improved and became exact. No upper bound changed. All new exact
cells lie in the intended main interval at orders12..103.

The canonical unresolved count falls from6416 to454:254 sparse cells,
179 main cells, and21 dense cells. The179 remaining main cells have order
at most11. This is not a claim that the other remaining regions are solved.

## Actual branch selection and literal graphs

The dispatcher check passed2980 planned boundary/middle constructions and
tail regressions. Separately, this review reconstructed the **first
matching** branch intervals used by the actual constructor. That differs
from the furthest-reaching intervals used to display a short coverage plan.
The independently reconstructed branch partition covers every342700 main
pair at orders12..103 without a gap.

At7394 boundaries and midpoints of those actual branch intervals, the
returned graph had exactlym distinct valid nonloop arrows, the expected
branch, and the claimed missing-pair count. This exercised all14 possible
finite branch names, including the retained five-type, tiny dense and
endpoint families. For2142 new-branch graphs, their actual returned edges
were additionally checked against literal certified base/envelope data:
staged graphs matched their exact stored arrow prefixes; circle graphs
lay in a matching certified residue envelope; reduced-hub graphs lay in
base/envelopes independently reconstructed from hub and guide rules.

Some subconstructors choose among several proved envelopes at the same
budget. The check therefore validates actual edges against a matching
certificate instead of treating an interval-selection row as necessarily
the unique graph description. No incorrect graph or unsupported branch
was found.

For the small protected-circle branch, all77 admissible(n,h) parameters
at orders25..42 were reconstructed independently. The six oriented core
differences are distinct and each has exactly its original ordered
representation in the final envelope. Symmetry of the difference set
makes the greedy insertion test check both orientations. Coprimality and
the size inequalities of the ordinary theorem were also checked. These
finite residue/parameter loops are a specified direct construction; they
do not invoke game search, generic graph search, or an existence oracle.

The infinite tail is delegated unchanged to the previous constructor;
the ordinary tail theorem supplies its proof. Concrete instantiation of
the new finite catalogue in Lean remains outside the claim. The generic
rank-envelope semantic theorem and independently replayed finite
certificate boundary are preserved.

Machine-readable details and source hashes are in
`research/main-interval-fifth-coverage-review.json`. No defect was found.

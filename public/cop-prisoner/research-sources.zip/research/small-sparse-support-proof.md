# Small sparse support: exact exceptional-degree accounting

Research note, 13 September 2026. This strengthens a necessary support
reduction; it does not determine either remaining maximum. The ordinary
inequalities and finite integer replay require independent review before
promotion into the manuscript. No graph search is used here.

Let A be the vertices of outdegree at least two, and B those of indegree at
least two. Write q=|A|, r=|B|, b=|A intersection B|, a=m-2q, d=m-2r.
Only A can supply a nonzero indirect source row, and only B a nonzero
recipient column. The following uses the manuscript's actual directed game.

Let x be the total outgoing surplus above two in A, and y the incoming
surplus above two in B. Let p count the indegree-one vertices of A minus B,
and t the outdegree-one vertices of B minus A. Let Z consist of the
nonisolated vertices outside A union B, with z=|Z|. Their outgoing and
incoming degree totals are

    o=a-x-t,  i=d-y-p.

Each vertex of Z has both degrees at most one and positive total degree.
Consequently max(o,i)<=z<=o+i. Also

    0<=x<=a,  0<=y<=d,
    0<=p<=min(q-b,d-y),  0<=t<=min(r-b,a-x).

The exact nonisolated support is q+r-b+z.

## Counting all outside sinks and inaccessible predecessors

There are r-b-t sinks in B minus A. They receive at least 2(r-b-t)
arrows. Exactly z-o members of Z are sinks: an outdegree-zero nonisolated
vertex of Z has indegree one. Thus the indicated sinks receive at least

    2(r-b-t)+(z-o)

arrows altogether. Arrows whose tails are outside A number a-x. Vertices
of outgoing degree at least three have total outgoing degree at most 3x,
because e<=3(e-2) for each e>=3. Therefore at least

    2(r-b-t)+(z-o)-a-2x

of those arrows have degree-two tails in A. Each such tail has a sink
successor, making its entire indirect source row zero: the pursuer camps
at its other successor. Each tail accounts for at most two arrows, so at
least the nonnegative ceiling of half this expression gives distinct zero
rows. If R counts nonzero source rows,

    R <= q-max(0,ceil((2(r-b-t)+(z-o)-a-2x)/2)).

Substitute t=a-x-o and use r-q=(a-d)/2. This is equivalent to

    R <= min(q,b+a+floor((d-o-z)/2)).                   (1)

For columns, argue separately in the original directions. There are
q-b-p indegree-zero vertices in A minus B and exactly z-i in Z. They
emit at least 2(q-b-p)+(z-i) arrows. At most d-y of these can end outside
B, and at most 3y can end at higher-indegree vertices in B. All remaining
arrows go to indegree-two recipients with inaccessible predecessors, whose
indirect columns are zero. Each such recipient receives at most two arrows.
Thus the analogous bound on the number C of nonzero columns is

    C <= min(r,b+d+floor((a-i-z)/2)).                   (2)

These are separate camping arguments, not an assumption that graph reversal
preserves delivery. Dropping z>=o,i yields the simpler reviewed marginal
bounds R<=min(q,b+a+floor(d/2)-o) and
C<=min(r,b+d+floor(a/2)-i). Dropping o,i as well gives the improvements
R<=min(q,b+a+floor(d/2)), C<=min(r,b+floor(a/2)+d).

## Eligible pairs and the actual winning rectangle

Let w count arrows with tail outside A and head outside B. Inclusion and
exclusion of the arrows leaving A and entering B gives

    e(A,B)=2q+2r-m+x+y+w.

Therefore

    I <= qr-b-max(0,2q+2r-m+x+y).                      (3)

For actual nonzero row/column sets of cardinalities u,v, their intersection
has size at least max(0,b-q-r+u+v). The arrows leaving the former and
entering the latter give at least max(0,2u+2v-m) direct pairs between them.
These direct and diagonal exclusions are disjoint, so

    I <= uv-max(0,b-q-r+u+v)-max(0,2u+2v-m).           (4)

Maximize (4) over 0<=u<=R and 0<=v<=C. This avoids any assumption that
the displayed function is monotone at very small u,v.

For fixed q,r,b,o,i,z, the least possible surpluses are

    x_min=max(0,a-o-(r-b)),
    y_min=max(0,d-i-(q-b)).

Using these in (3) only weakens the upper bound; (1)-(2) are independent of
x,y. Thus the finite replay need only enumerate q,r,b,o,i,z. It retains
every possible actual graph profile, while some retained integer profiles
may not be realizable by a graph.

## Bounded replay and result

Run

    python3 src/small_sparse_support.py --out research/small-sparse-support-checks.json

It enumerates 0<=q,r<=floor(m/2), 0<=b<=min(q,r), 0<=o<=a,
0<=i<=d, max(o,i)<=z<=o+i. Profiles whose bounds (3) or (4) do not
exceed the proposed lower value are discarded. The maximum surviving
support is:

* m=18, I>30: at most 15 nonisolated vertices; 67 active (q,r,b) profiles.
* m=20, I>50: at most 13 nonisolated vertices; 22 active (q,r,b) profiles.

These support bounds depend on the complete finite integer replay and the
ordinary inequalities above. They do not assert that 30 or 50 is optimal,
that the surviving profiles exist, or that only regular cores need checking.

## Progress, failures, and next step

The older marginal concentration estimate gave support bounds 23 and 24
at these scores. Retaining the original surplus variable improves its
constants, then tracking actual outside degrees gives 18 and 16. Counting
the previously omitted outside leaves yields the stronger 15 and 13 above.
All row/column inequalities passed structural sanity checks on every 4,165
loopless directed graph through four vertices and 1,700 additional sparse
graphs. These tests checked degrees and the explicit camping witnesses;
they did not invoke a game solver and do not replace the proof.

The next obstruction should retain w in (3), and distinguish outside arrows
that feed the core from arrows used to avoid forced zero rows or columns.
Several maximal integer profiles spend the same small supply of arrows in
incompatible ways. Establishing that incompatibility could exclude whole
profiles without enumerating their adjacency lists. No such exclusion is
claimed yet. The saved lower witnesses remain 30 at (9,18), 50 at (10,20).

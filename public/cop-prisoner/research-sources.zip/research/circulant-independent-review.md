# Independent review: sparse circulants and their game bridge

12 September 2026. Review of `research/circulant-construction.md`, followed by a generalization and an elementary all-order parameter choice. This is September 2026 research; no literature-priority claim is made.

## Review conclusion

The root's `{1,3,7}` proof is correct under the stated hypotheses `n≥15` and `gcd(n,7)=1`. The two essential points withstand independent attack:

- Distinct closed outgoing neighborhoods meet in at most one vertex. This includes waiting and immediate collision, not only the pursuer's strict outgoing arcs.
- Each bootstrap step first moves to an intermediate outside the pursuer's entire closed outgoing neighborhood. The intervening pursuer turn therefore cannot invalidate concatenation. The bootstrap is finite and strictly bounded, so perpetual avoidance is not mistaken for success.

The initial quartet has rank at most two. Four successive applications suffice to translate the quartet, hence `4n−2` is a valid, conservative delivery-time bound. A sharper rank estimate is unnecessary for the extremal construction.

Padding an `(n−1)`-vertex example by one isolated vertex is legitimate and preserves I. In particular the `{1,3,7}` construction alone gives `M_V(n)≥n²−6n+5` for multiples of seven large enough for the smaller graph, and `M_V(n)≥n²−4n` otherwise. Combined with the universal bound `M_V(n)≤n²−3n`, this already establishes `n²−M_V(n)=Θ(n)` for all large n, without unproved interpolation.

The parameter choice below strengthens the lower construction to `n²−4n` at every `n≥25` and removes the need for padding in this statement. It is still a lower bound, not an exact extremal formula.

## Parameterized theorem

Let `a≥3`, `b=2a+1`, `n≥2b+1=4a+3`, and `gcd(n,b)=1`. On `Z/nZ`, use arcs

\[
x\longrightarrow x+1,\quad x+a,\quad x+b.
\]

Then every source can guarantee delivery to every recipient. Thus `m=3n` and `I=n(n−4)`.

**Closed neighborhoods.** Put `C={0,1,a,b}`. Its six positive differences are

\[
1,\ a-1,\ a,\ a+1,\ 2a,\ 2a+1.
\]

For `a≥3` these are distinct. The modulus is at least `2b+1`, so no positive difference is congruent to a negative one. Distinct translates of C therefore have at most one common member. Two already-guaranteed, distinct successors of a source cannot both lie in a pursuer's closed outgoing neighborhood. The messenger chooses a safe one after observing the pursuer and survives the next response.

**Bootstrap.** Translate the recipient to zero, and write

\[
Q(z)=\{z,z-1,z-a,z-a-1\}.
\]

Zero, −1, and −a are delivered or immediate. Vertex `−a−1` has successors `−a` and `−1`, so Q(0) is guaranteed. If Q(z) is guaranteed, apply safe branching to the following pairs in order:

| New source | Two already-guaranteed successors |
|---|---|
| z−b | z−a−1, z |
| z−b−1 | z−b, z−1 |
| z−b−a | z−b, z−a |
| z−b−a−1 | z−b−a, z−a−1 |

These establish Q(z−b). Every listed arc has step 1, a, or b, and the two successors are distinct modulo n. Since multiplication by b permutes `Z/nZ`, at most n quartets cover every source. The universal initial-pursuer quantifier is preserved at each bootstrap step.

## A coprime odd parameter for every n≥25

We need an odd integer b satisfying `7≤b≤(n−1)/2` and `gcd(n,b)=1`. Set `a=(b−1)/2` afterward.

1. If `n≡0 mod4`, use `b=n/2−1`. Any common divisor divides 2 and is odd, so it is one.
2. If `n≡2 mod4`, use `b=n/2−2`. Any common divisor divides 4 and is odd, so it is one.
3. If `n≡3 mod4`, use `b=(n−1)/2`; then `n−2b=1`.
4. Suppose `n≡1 mod4`. Write `n−1=2^k d` with d odd and k≥2.
   - If d≥7, use b=d. It divides n−1, hence is coprime to n, and is at most `(n−1)/4`.
   - If d belongs to `{1,3,5}` and 3 does not divide n, use `b=(n−3)/2`. Its common divisors with n divide 3.
   - If d=1 and 3 divides n, use `b=(n−7)/2`. No number `2^k+1` is divisible by seven: powers of two modulo seven are 1,2,4, never −1.
   - The case d=3 and `3|n` cannot occur.
   - If d=5 and 3 divides n, k is even. Use `b=(n−11)/2`. Divisibility of `5·2^k+1` by eleven would imply `2^k≡2 mod11`. But for even k, the possible residues are `{1,3,4,5,9}`, excluding two.

Every parameter is odd and within the required interval; the weakest lower estimate is `(n−11)/2≥7`, valid for n≥25. This proves existence without prime-distribution results or search.

For `15≤n≤24`, direct choices cover every n except 21 (for example choose an admissible b from 7,9,11). This exception concerns this parameterized construction alone.

## Formal verification delivered

The owned `lean/` directory uses Lean 4.33.1 and Std only. The initial two modules establish:

- `DeliveryGame.lean`: actual waiting/arcs, messenger-first execution, success before collision at the recipient, finite contingent winning trees, and a theorem that those trees produce real delivery against every legal history-dependent pursuer policy. It also proves an actual-game interpretation for finite-rank certificates.
- `SafeBranching.lean`: safe intermediate concatenation, the two-successor rule under closed-neighborhood overlap at most one, a finite bootstrap proof system, and its end-to-end interpretation as real play.

The parameterized modular arithmetic, quartet coverage, numerical counting, and all-n parameter lemma in this note are currently **ordinary proofs**, not fully formalized claims. The general overlap hypothesis is explicit in the Lean bootstrap theorem; Lean does not yet establish it for every circulant in the infinite family. The semantic bridge itself is proved, rather than assumed.

## Independent attack of the arc-budget bounds and equality cases

I independently reviewed Sections 7–10 of `research/extremal-bounds.md` after their completion. **The even and odd upper bounds and both k≥6 equality characterizations are accepted at the ordinary-proof level.** No assumption about invariance under arc reversal is needed.

Checks concentrated on the following possible weak points:

1. **Generic bookkeeping.** With A the degree-at-least-two sources and B the degree-at-least-two recipients, the elementary bound `I≤qr−b−e(A,B)` subtracts disjoint diagonal and direct-arc pairs. The inequality `e(A,B)≥2q+2r−m` counts the outgoing-A and incoming-B arcs by inclusion–exclusion. The truncated product bound is nondecreasing in each variable for q,r≥2, including its transition across zero.
2. **The one-extra-arc observation.** At odd budget with r=k, the total indegree above the mandatory two per B vertex plus every arc ending outside B is exactly one. Thus at most one A\B vertex can have positive indegree. An indegree-zero vertex of outdegree at least two really does have an indegree-two successor in B: either one outgoing arc may end outside B, or one B target may have indegree three, but not both obstructions together. The two-successor pigeonhole is therefore sound.
3. **Several zero columns.** Three distinct indegree-zero sources, each pointing to an indegree-two recipient, force at least two distinct zero target columns. Each target has only two incoming arcs, regardless of how the chosen sources share other neighbors. This handles the delicate odd equality case b=2 at k=6, where at least k−3=3 such sources remain.
4. **Odd equality at b=k−1.** Equality forces `e(A,B)=2k−1` and every eligible missing pair to be guaranteed. The exact identity
   `d⁺(A)+d⁻(B)=m+e(A,B)−e(Aᶜ,Bᶜ)`
   shows both degree sums equal 2k and there are no arcs from Aᶜ to Bᶜ. Hence exactly one arc starts outside A, exactly one ends outside B, and these arcs are distinct. This justifies a step which would be invalid if the two exceptional arcs were silently allowed to coincide.
5. **Support of the odd equality graph.** If the unique v∈A\B had indegree zero, one of its successors would give a zero target column with at least k−3 eligible missing pairs. That contradicts equality. The direct dead-end/source argument similarly forces the unique u∈B\A to have outdegree one. These consume all exceptional indegree/outdegree budget, so every vertex outside A∪B is isolated. The absent arc u→v and the deletion-from-two-regular description follow.
6. **Strict inequalities at k=6.** The generic gaps, zero-row/column gaps, and intersection cases are strict at the smallest stated equality parameter. No unmentioned k=6 exception remains. The k≥5 upper bounds do not themselves assert the k=5 rigidity conclusion.

The converse in each equality characterization is valid by counting eligible missing pairs under the explicitly stated game condition. Completing an odd equality graph by adding u→v does **not** automatically preserve its guarantees; the source correctly avoids that inference.

These upper bounds do not by themselves establish eventual attainment. The required families or finite witnesses remain separate inputs.

## Final formal checkpoint

The final Lean delivery consists of five replayed modules: `DeliveryGame`, `SafeBranching`, `CampingObstruction`, `TwelveVertexCertificate`, and the axiom audit. The 12-vertex module proves an actual universal delivery guarantee for its explicit 24-arc graph and kernel-checks the count I=108. The generator and Python solver are not assumptions of that theorem.

`lean/verification.json` records the pinned compiler version, source hashes, all compiler outputs, and a fresh sequential replay totaling **7.211 seconds**. All modules passed. The published proof boundary should retain the distinction between these formal statements and the ordinary infinite-family and extremal-counting arguments.

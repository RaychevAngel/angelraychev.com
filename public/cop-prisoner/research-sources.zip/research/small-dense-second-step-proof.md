# Exact second dense steps at orders seven through ten

Private research proof for independent review. The proposed exact values are

    M(7,30)=8, M(8,42)=10, M(9,56)=12, M(10,72)=15.

The four literal witnesses are in `src/small_dense_second_step.py` and
`research/small-dense-second-step-certificates.json`, with two independent
full-game solvers and complete winning/losing rank replay. Their missing
arrows are specified directly, without discovery during construction.

At order ten, the upper bound15 follows from the retained second-step
equivalence and the independently checked failure of an all-delivery
eight-core. The new witness meets it. It remains to prove the stricter
upper bound 2n-6 at n=7,8,9.

Write h=2n-2 and Delta=h-I. The dense upper bound gives Delta>=2.
Equality Delta=2 reduces to a disjoint missing two-cycle and an ordinary
all-delivery missing core on n-2 vertices. It is excluded here by the
known five-/six-vertex values and the independently checked seven-core
upper bound M(7,28)<=12. Suppose therefore that Delta=3.

Let S be the degree-one missing vertices, ell=|S| and
e=sum max(q(v)-2,0). Then ell=2+e and
Delta>=ceil(ell/2)+1, so ell is2,3 or4.

## Four degree-one vertices

The same counting equality used for the third/fourth steps forces the
closed functional path rho->t0->a<->b. Its three killed rows exhaust
Delta. All other rows must avoid {t0,a,b} and all their missing pairs
must win. They form a corrected safe-root interface on k=n-4 vertices,
with total degree excess2: either one row has degree4 or two rows have
degree3, and all other rows have degree2.

The complete fixed-degree checks exclude both profiles at each k=3,4,5.
Vertices are simply ordered by their prescribed degree; every loopless
row with that degree is then enumerated. There is no neighborhood
normalization or missing-indegree restriction. The six prefix node
counts are1,3,8,69,396,4211; all have zero static leaves under the
previously justified source and predecessor camping predicates.

## Three degree-one vertices

The degree-one image argument from the third-step equality proof again
forces f(S) contained in S; the possible b=1 case would require two
unique images but necessarily duplicates one. The functional part is a
three-cycle or a two-cycle with a free root. All three functional pairs
fail. The outside core has exactly one degree-three missing row and all
others degree two. It must satisfy the corrected rooted interface on
k=n-3 vertices, with a possibly unused root in the three-cycle case.

The previous complete checks excluded k=4,5. The new k=6 check has29,852
prefix nodes and12 static leaves. None of those twelve interfaces is
universal. Each leaf is additionally converted into a full nine-vertex
delivery graph with the three-vertex functional gadget; both existing
independent game solvers and every winning/losing rank obligation agree
with the corrected interface's core-position masks.

## Two degree-one vertices

All other missing outdegrees are two. If their images stay within S,
the two vertices form a missing two-cycle. Its rows already give two
losses, leaving only one further loss. No outside row can point into
that cycle, because it would lose its entire two-pair row. Exact missing
block addition reduces I to the ordinary (n-2)-vertex core value. The
known values M(5,10)=3, M(6,18)=6 and upper M(7,28)<=12 are all below
2n-5, excluding Delta=3.

If their images leave S, the only shape compatible with three losses is

    c -> d -> x,       q(c)=q(d)=1, q(x)=2.

Distinct outside images kill two degree-two rows, and a common outside
image kills both degree-one rows as well; either gives at least four
losses. In the displayed path the killed rows d and x exhaust Delta.
Let Y=F(x), a two-element set. Both missing columns addressed to Y are
killed by the pursuer at d. The set Y cannot contain d, since then the
otherwise winning pair(c,d) would also fail. It does not contain x by
looplessness. Every other good missing row avoids {d,x} and avoids Y;
the sole permitted good arrow into d is c->d.

If c belongs to Y, deleting {c,d,x} and the other member of Y leaves an
ordinary universal two-out missing core on n-4<=5 vertices. This
contradicts the retained small-order results. If c does not belong to Y,
the vertices outside {c,d,x} union Y form a corrected rooted two-out
interface with root c, on n-5=2,3,4 vertices. R2(3) and R2(4) were
completely excluded. R2(2) is immediate: both rows must consist of the
other core vertex and the root, and each is source-camped by the other.

Every possible Delta=3 shape is excluded. Thus Delta>=4 and
I<=2n-6 at n=7,8,9; the literal witnesses attain it.

New finite dependencies are
`src/small_dense_r2_gap.py`,
`research/small-dense-r2-rooted-profiles.json`,
`research/small-dense-r23-six-enumeration.json`, and
`research/small-dense-r2-profile-certificates.json`.
The last file contains entries {degrees,missing_rows,interface,full_game},
where full_game has the standard actual alternating-game certificate.
The earlier small rooted and endpoint exclusions retain their separate
files and scope. No completeness claim is based on an unsuccessful
bounded construction search, and no new Lean formalization is asserted.

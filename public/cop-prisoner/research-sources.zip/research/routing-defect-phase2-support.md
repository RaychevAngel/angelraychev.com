# Quantitative concentration of support below the sharp sparse cutoff

2026-09-13. Second-phase ordinary deduction. Not yet a manuscript
theorem; requires a second mathematical review before promotion.

The existing sparse stability theorems identify exact support shapes
above a cutoff. The following argument is weaker near that cutoff but
continues below it: losing only O(m) pairs relative to the quadratic
leading term forces only O(1) exceptional support vertices and arcs.
It is a statement about the original graph, not a claim that deleting
those arcs preserves its strategies.

## A refined eligible-rectangle bound

Let G be a finite simple loopless directed graph, with m arrows and
I guaranteed indirect pairs. Put

    A={v:outdegree(v)>=2}, B={v:indegree(v)>=2},
    q=|A|, r=|B|, b=|A∩B|,
    a=m-2q, d=m-2r.

Both a,d are nonnegative integers of the same parity. Let R and C
be the numbers of source rows and recipient columns that contain at
least one guaranteed indirect pair. Then

    R <= min(q, b+2a+floor(d/2)),
    C <= min(r, b+floor(a/2)+2d),                  (1)
    I <= R C.

To prove the column bound, at most d arrows end outside B, so at
least z=max(0,q-b-d) vertices of A\B have indegree zero. They emit
at least 2z arrows. Write x for the total excess indegree above two
inside B. Then x<=d, at most d-x arrows end outside B, and the total
indegree of the vertices in B with indegree at least three is at most
3x: for each such degree e, e<=3(e-2). Consequently at most

    (d-x)+3x <= 3d

arrows from the chosen vertices can avoid indegree-two recipients in
B. At least 2z-3d arrows enter those recipients. Each recipient
receives at most two of them, so at least z-floor(3d/2) columns are
zero (when this lower bound is negative, it is simply vacuous).

The game justification is the established directed camping argument:
an indegree-two recipient with an indegree-zero predecessor cannot
have an indirect guarantee. A different indirect source cannot reach
that predecessor and must pass through the other predecessor, where
the cop can wait. Hence

    C <= r-z+floor(3d/2)
      <= r-q+b+d+floor(3d/2)
       = b+floor(a/2)+2d.

The final identity uses r-q=(a-d)/2 and the common parity of a,d.

For the row bound, use the original directions rather than reversing
the game. At most a arrows start outside A, so at least r-b-a
members of B\A are sinks. Their incoming arrows force outdegree-two
predecessors except for at most 3a arrows, by the same degree-surplus
count on outgoing degrees. An outdegree-two source with a sink
successor has a zero row: the cop camps at the other successor.
This gives R<=b+2a+floor(d/2). Only rows in A and columns in B can
contribute, giving the minima and the product bound in (1).

## A compact structural consequence

Define the nonnegative real quantity

    eta = m-2 sqrt(I).

It is nonnegative since I<=qr<=m²/4. Then, for the induced core
K=G[A∩B],

    m/2-3 eta <= |V(K)| <= m/2,                  (2)
    nonisolated_support(G) <= m/2+4 eta,         (3)
    at most 12 eta arrows lie outside K.        (4)

These real inequalities can of course be rounded in the favorable
integer direction.

Put S=a+d. Since I<=qr and q+r=m-S/2, arithmetic-geometric mean
gives S<=2m-4sqrt(I)=2eta. On the other hand, (1) yields

    2sqrt(I) <= R+C <= 2b+(5/2)S,

so b>=sqrt(I)-5S/4>=m/2-3eta. Its upper bound is b<=q,r<=m/2.
This proves (2).

Every nonisolated vertex outside A∪B contributes at least one to
the sum of its incoming and outgoing degrees. The sum of all outgoing
degrees outside A is at most a; the sum of all incoming degrees outside
B is at most d. Therefore at most S=a+d nonisolated vertices lie outside
A∪B. This improves the first draft's weaker estimate of 2S, which counted
both endpoints of arrows outside A×B without using the degree budgets.
The total nonisolated support is consequently at most

    q+r-b+S = m-b+S/2
      <= m-sqrt(I)+(7/4)S
      <= (9/2)m-8sqrt(I) = m/2+4eta.

For (4), the number of arrows whose tail lies outside A∩B is at
most 2(q-b)+a. Indeed, outgoing degree excess inside A plus all
outgoing degree outside A totals exactly a. The analogous incoming
bound is 2(r-b)+d. Counting an arrow with both endpoints outside
twice only weakens the estimate. Hence arrows outside the induced
core number at most

    2(q+r-2b)+S = 2m-4b
      <= 2m-4sqrt(I)+5S
      <= 12m-24sqrt(I) = 12eta.

## Meaning and limitations

For an even budget m=2k and I>=k(k-3)-Delta, with nonnegative right
side, eta<=2k-2sqrt(k²-3k-Delta). In particular, if Delta=O(k),
then eta=O(1), so the nonisolated support has at most k+O(1)
vertices and all but O(1) arrows lie in a core of at most k vertices.
This extends structural control below the previous exact-support
cutoff; it does not identify the best constants or all exception
families there.

The conclusion does NOT assert I(K)>=I(G), nor any monotonicity of
delivery under deletion, nor that adding arrows to regularize K
preserves a strategy. The earlier Theorems 56–57 remain stronger in
their exact-support ranges. This new counting mechanism is a
candidate quantitative extension of that framework, not a reason
to discard its sharper alternatives or genuine game restriction
arguments.

No graph enumeration or new formalization was used to obtain (1)–(4).
All references to zero rows and columns are to proved camping facts
in the original messenger-first, receipt-before-capture game.

The separate finite checks now cover 181 random/larger/maximizing witness
graphs and all 4,165 labelled loopless directed graphs through four vertices.
Both original game solvers agree on each example. All three real
inequalities are checked through their exact squared integer equivalents.
See the two `routing-defect-phase2-support-*-checks.json` receipts; these
are adversarial finite evidence, not a substitute for the ordinary proof.

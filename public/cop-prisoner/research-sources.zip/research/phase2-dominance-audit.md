# What the composition phase actually supersedes

Use the stable thirty entry IDs in catalogue-after-unification-2026-09-12.md.
This is a mathematical dominance audit, not an attempt to count multipart
statements as single results merely because they share a theorem number.

- Entry1: same full main-interval conclusion and deterministic construction,
  threshold1664→115. The source now gives an executable combined constructor.
- Entry5: sparse52 now n≥115 instead1075, full envelope2n..20k−11r,
  arbitrary optional subsets, time9ceil(n/6)+21 instead+26. Thus the new
  theorem improves every advertised dimension of this entry and also
  subsumes the earlier41 numerical/time/robustness statement. The old41
  proof is removed from the main manuscript and retained as a research file.
- Entry7: same protected-circle strategy and arbitrary optional subsets,
  with an additional run construction increasing its envelope. Oldsmall
  orders/steps and greedy guarantee are retained.
- Entry9: full variable-density protected-routing theorem retained. Its
  half-density specialization now has the simpler orientation algorithm and
  sharper sufficient b=ceil(24lnn+4); exact counts and specifiedhubset remain.
- Entry10: lower bound unchanged, finite orientation upper improved, explicit
  antichain upper constant5.3555763082 added. Exact q2 constant remains open.
- Entries11 and12 become ONE stronger numerical dense-envelope result:
  every n≥16, missing counts2n..3n; H5 cap for30+, H4 cap for44+;
  every optional subset and two moves. This subsumes ALL of old48's domain,
  including19..21. Its protected-difference hypothesis remains useful as a
  separate proof criterion, not a second numerical interval. The new caps
  genuinely extend the earlier ranges rather than just putting them under
  one heading.
- Entry13: denseendpoint now every n≥10, closing11 with a concrete Lean-
  checked graph. Smaller orders below the robustenvelope16 survive.
- Entry14: fullstaircase24→20, generalizedcoreclausek≥10 nowincludes11;
  smaller r1≥16 and the conditionalrootcriterion are retained.
- Entry30: ten Lean modules insteadseven, adding robust-envelope actual
  semantics, the concrete11core, and all six16..21 robust dense envelopes. Not a full Lean classification.
- New independent structural entry: the generic antichain composition59,
  including variable code sizes and every outside-arrow assignment. Its
  q2/main corollaries sit in entries1/10; its structural hypotheses and
  exact budget envelope contain additional mathematical content.
- New independent structural entry: concentration60 below the exact-support
  cutoffs. It does not supersede56/57, whose game-restriction/sharp alternatives
  remain stronger on their domains. No deletion-monotonicity claim.

At the same granularity, the manuscript catalogue is therefore31 entries:
30−1 dense numerical interval+2 new structural theorems. Claiming a smaller
overall count would hide new content or discard retained dimensions. The
numerical/construction fragmentation has decreased, but the entire catalogue
has grown because two genuinely general structural theorems were added.
Fast-navigation research and failed covers are not counted as published
extremal theorems. Remaining sparse smaller-order families and their better
special times are still independent; no artificial consolidation is claimed.

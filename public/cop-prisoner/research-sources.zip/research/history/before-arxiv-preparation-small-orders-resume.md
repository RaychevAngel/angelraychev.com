# Small vertex orders

The smallest order attaining the vertex bound is twelve. This statement is
about attaining the bound, not about the first noncomplete network in which
all pairs are guaranteed: the latter already occurs at seven vertices.

**Theorem 46 (with finite exhaustive certificates).**
The seven-, eight-, and eleven-vertex maxima are
$$M_V(7)=21,\qquad M_V(8)=32,\qquad M_V(11)=85.$$
In addition, $M(11,23)=78$ and $M(11,24)=79$. The current vertex bounds at orders nine
through eleven are:

| $n$ | Lower bound for $M_V(n)$ | Upper bound for $M_V(n)$ |
|---|---:|---:|
| 9 | 48 | 53 |
| 10 | 62 | 69 |
| 11 | 85 | 85 |

There is no universally winning two-in/two-out regular digraph on any of
$7,8,9,10,11$ vertices. Together with the previous exact results through
six vertices and Theorem 40, this implies that twelve is the smallest
order $n\ge4$ for which $M_V(n)=n(n-3)$.

**Proof of the lower bounds.** The finite witnesses at orders seven through
ten have respectively $21,24,24,28$ arcs and guarantee every pair.
Their complete graph and winning-strategy certificates are provided in
`research/small-exceptional-general-certificates.json`, with the improved
nine-vertex witness in
`research/root-small-structured-9-certificate.json`. The earlier eleven-vertex
witness with 26 arrows remains in
`research/small-exceptional-structured-11-certificate.json`. A new
25-arrow witness improves its count from 84 to 85; its outgoing rows are
$$
(1,7,9),\ (2,5),\ (3,8),\ (5,10),\ (0,6),\ (1,4,6),\
(8,10),\ (1,8),\ (6,7,9),\ (3,4),\ (0,2).
$$
Two independent
attractor algorithms agree; each stored alternating-state rank satisfies
all messenger-choice and universal pursuer-response obligations. Thus
$I=n(n-1)-m$ gives $21,32,48,62,85$ respectively. The new literal witnesses
are consolidated in `research/small-case-results.json` and independently
replayed by `src/small_case_certificate_review.py`. For concreteness, the
seven-vertex witness is the following graph, whose guarantees require at
most four messenger moves:

| Vertex | Outgoing neighbors |
|---|---|
| 0 | 1, 3, 6 |
| 1 | 0, 4, 6 |
| 2 | 0, 5, 6 |
| 3 | 1, 2, 5 |
| 4 | 0, 2, 3 |
| 5 | 1, 3, 4 |
| 6 | 2, 4, 5 |

**Seven-vertex upper bound.** If a graph has at most thirteen arcs, the
arc-only bounds give $I\le20$; it suffices here to use monotonicity of
$M_E$ (pad by disjoint one-way arcs) and $M_E(13)\le20$. A graph with at
least twenty-one arcs has at most $42-21=21$ missing pairs. It remains to
exclude $I\ge22$ for $14\le m\le20$.

We describe the finite reduction and every rejection rule. Write
$O_s=N^+(s)$, $P_t=N^-(t)$ and $C_c=\{c\}\cup N^+(c)$. A counted pair
$(s,t)$ necessarily satisfies

1. $s\ne t$, $t\notin O_s$, $|O_s|\ge2$ and $|P_t|\ge2$;
2. $O_s\not\subseteq C_c$ for every $c\ne s$;
3. $P_t\not\subseteq C_c$ for every $c\ne s$.

The degree conditions are the one-neighbor camping obstructions. For
condition 2, a pursuer waiting at $c$ captures the messenger after its
first departure from $s$. For condition 3, it waits at $c$ and captures
the messenger upon the first entry into a predecessor of $t$, before the
next messenger move can deliver. Indefinite waiting by the messenger
also fails to deliver. These arguments respect receipt priority because
an indirect source is not itself a predecessor of its recipient.

Let $U(G)$ be the number of pairs satisfying these three conditions.
Then $I(G)\le U(G)$. A source contributes at most four pairs, so
$I\ge22$ requires at least six sources of outdegree at least two.
Every graph can be relabeled in nondecreasing outdegree order, allowing
only the first row to have degree below two. We enumerate every loopless
outgoing row mask in that order, with total degree between fourteen and
twenty. This includes every possible graph, with harmless repetitions.
At a partial assignment, the following bounds allow safe pruning:

- A completed row of degree $d\ge2$ contributes at most $6-d$, or zero
  if a known completed row already violates condition 2. Each remaining
  row contributes at most $6-\max(2,d_0)$, where $d_0$ is the smallest
  outdegree still allowed by the ordering.
- A target currently of indegree $d$ contributes at most
  $6-\max(2,d)$. Its contribution is zero if the remaining rows cannot
  raise its indegree to two.
- The total arc count must remain extendible to the interval $[14,20]$.

No omitted edge can repair a rejected completed source: the covering
closed neighborhood only grows. The incoming-degree bounds likewise
use upper estimates on all possible completions. At every surviving
complete graph we count $U(G)$ directly. The exhaustive enumeration
has $109,941,961$ recursion nodes and $4,299,624$ complete leaves before
an optional indegree tie normalization. None has $U(G)\ge22$.
A separate implementation uses boolean adjacency, descending outdegree
order, and no indegree tie normalization; it completes $123,280,819$
nodes and the same $4,299,624$ leaves, again with no survivor. This proves
$I\le21$ in the remaining arc range. The lower witness proves equality.

**Eight-vertex upper bound.** At most fifteen arcs give $I\le M_E(15)\le30$;
at least twenty-four arcs leave at most thirty-two missing pairs. To
exclude $I\ge33$, it therefore suffices to examine $16\le m\le23$.
Each source contributes at most five pairs, so at least seven sources
must have outdegree at least two. The same camping conditions and partial
bounds used above apply with eight vertices.

For this slightly larger search we also remove labeling redundancy.
Fix a nondecreasing outdegree sequence. After the outgoing rows numbered
less than $r$ have been chosen, partition the unassigned vertices into
cells with equal prescribed outdegree and identical adjacency from all
completed rows. Vertices in such a cell may be permuted without changing
any completed row or degree requirement. Therefore, when choosing row
$r$, its neighbors among the future vertices of each cell may be required
to form a prefix of that cell. This loses no graph: permute within each
cell to put the neighbors first, fixing row $r$ and all previous vertices,
and continue recursively. The new cells are obtained by splitting the
old cells, so their contiguity is preserved. The analogous suffix rule
and reversed degree order are equally complete.

The primary search completes all $178$ degree sequences, with
$946,676,955$ recursion nodes and $22,465,453$ complete leaves. Only $373$
leaves satisfy the necessary pair bound $U(G)\ge33$. Exact least-attractor
evaluation rejects all of them; the largest actual $I$ among these
survivors is seventeen. Thus no graph has $I\ge33$, proving $M_V(8)=32$.
The ordinary canonicalization and every pruning rule were independently
audited; as an additional small positive check, every labeled loopless
four-vertex graph was canonicalized in both prefix and suffix conventions
and its relabeling and prefix conditions checked. Independent complete
suffix enumeration and the explicit alternating-state game provide a
second finite verification: its completed intervals $[0,160)$ and
$[160,178)$ cover all degree profiles. They visit $1,179,975,770$ nodes
and $63,717,034$ complete leaves, with $1,115$ static survivors, all
rejected. The differing counts reflect the opposite degree order and
suffix convention, which choose a different redundant collection of
representatives. Both implementations give the same zero-survivor
conclusion.

**Eleven vertices and twenty-three arrows.** We prove $M(11,23)=78$.
If $q$ vertices have outdegree at least two, the other $11-q$ vertices
emit at most $11-q$ arrows and cannot be indirect sources. The eligible
rows therefore contain at most
$$10q-\bigl(23-(11-q)\bigr)=9q-12$$
missing pairs. This is at most 78 for $q\le10$. The incoming argument
is identical: an indirect recipient requires at least two predecessors.
Consequently, a graph with at least 79 guarantees must have all indegrees
and outdegrees at least two. There is exactly one outdegree-three vertex
$U$ and one indegree-three vertex $V$, which may coincide; all other
degrees are two.

The bipartite arrow graph has a perfect matching. Indeed, a source set
$S$ emits at least $2|S|$ arrows, whereas fewer than $|S|$ recipient
columns have total capacity at most $2(|S|-1)+1$. This contradicts a
failure of Hall's condition. The matching is a fixed-point-free
permutation. Up to simultaneous relabeling there are fourteen possible
cycle partitions of eleven into parts at least two. Rotating cycles and
swapping cycles of equal length places $U$ at the first vertex of one
cycle of each distinct length. Allowing all eleven positions for $V$
retains every relation between the exceptional vertices and gives 330
patterns in total. The remaining arrows have outgoing degree one except
two at $U$ and incoming capacity one except two at $V$. Enumerating all
residual rows, avoiding loops and matching arrows, covers the entire
class. The two residual neighbors at $U$ are chosen in increasing order.

During this enumeration, source and predecessor camping identify
permanent losing pairs, retaining the exception when the initial source
equals the camping vertex. No camping class is excluded in advance.
A partial cop row contains only arrows that persist; a predecessor set
is used only when its prescribed capacity is full. The permanent losing
pairs are copied separately at each recursion depth. A row contributes
at most the smaller of its final missing-pair count and the number of
targets not already direct, diagonal, or permanently losing.

The guarded-path bound uses every still-possible messenger arrow and
only fixed cop arrows. It permits the first move to escape the cop's
closed neighborhood and the final move to deliver anywhere; only
interior positions must avoid that neighborhood. Thus a failed
optimistic route certifies a losing pair in every completion. Surviving
graphs receive exact recipient least-attractor evaluation. Solved
recipient counts plus the remaining potentially winning pairs form an
upper bound, so the game calculation may stop once this is at most 78.

The complete ranges of cycle partitions $1$--$6$ and $7$--$14$ visit
121,790,823 nodes and reach 1,152,430 exact game decisions. Every decision
rejects a score of at least 79. The recorded value $-1$ is an early
rejection sentinel, not a graph score. The source, complete receipts,
and independent ordinary audit are respectively
`src/small_sparse_one_excess.cpp`,
`research/small-sparse-one-excess11-partitions1-6.json`,
`research/small-sparse-one-excess11-partitions7-14.json`, and
`research/small-plateau-one-excess-review.md`.
The independently rank-verified literal 78 witness is included in
`research/small-case-results.json`, proving equality.

**Eleven vertices and twenty-four arrows.** We prove $M(11,24)=79$.
The certified attaining graph has outgoing rows
$$
(1,7,9),\ (2,4),\ (3,8),\ (4,6),\ (0,5),\ (1,6),\
(7,10),\ (1,8),\ (5,7,9),\ (3,10),\ (0,2).
$$
Suppose a graph at this budget has $I\ge80$. If exactly ten source rows
have outdegree at least two, at least 23 arrows start in those rows, so
they contribute at most $100-23=77$ pairs. At most nine eligible rows
give at most $9\cdot8=72$. The incoming-degree count is identical.
Thus every indegree and outdegree is at least two. The total surplus
above two is two on each side, so the outgoing degree profiles are
$(4,2,\ldots,2)$ and $(3,3,2,\ldots,2)$, and no degree exceeds four.

There are 86 missing pairs, permitting at most six failures. Source
camping would make an entire row fail. To lose at most six pairs that
source would need outdegree four. It then uses all outgoing surplus,
while every other cop has a closed neighborhood of size three and
cannot cover its four successors. Hence source camping is impossible.

First suppose there is no predecessor camping either. The preceding
canonical row method, in descending degree order, enumerates both
degree profiles. Incoming feasibility requires enough unassigned tails
to reach indegree two and to escape every completed cop neighborhood
covering a current predecessor set. If no single tail escapes them all,
at least two new predecessors are required; summing these lower bounds
over recipients cannot exceed 24. At a complete graph, each counted
pair must also have a route to a predecessor of its recipient through
vertices outside every stationary cop's closed neighborhood. The final
arrow into the recipient is exempt from this avoidance requirement,
so receipt priority is respected. This gives a necessary pair-count
filter before exact game evaluation.

The complete target-80 run visits 186,865,392 nodes, 2,805,991 complete
camping-free graphs, and 371,060 guarded-path survivors. Its largest
actual count is 79. Every pruned branch has a proved upper below 80.
The frozen receipt is
`research/small-loss-n11-m24-camping-free-80.json`.

If predecessor camping occurs at $t$ with cop $c$, at least
$10-d^-(t)-1$ missing pairs fail. Thus $d^-(t)$ is three or four, and
no other column may be camped. For degree four there are three cases:
$c\notin N^-(t)\cup\{t\}$, $c\in N^-(t)$, or $c=t$.
In each case $c$ has outdegree four, and its outgoing set is respectively
$N^-(t)$, $\{t\}\cup(N^-(t)\setminus\{c\})$, or $N^-(t)$.
All other degrees are two. For degree three, the exceptional cop-source
pair must be indirect, so $c\notin N^-(t)\cup\{t\}$. The cop has
outdegree three or four. In the latter case its extra neighbor can be
normalized to one outside vertex, and the second indegree-three vertex
has ten possible labels. In the former case the second outdegree-three
vertex has three symmetry types: $t$, a predecessor of $t$, or an
outside vertex. Retaining all ten possible labels of the second
indegree-three vertex gives another 30 configurations. Together with
the three degree-four cases, this is $3+10+30=43$ configurations.

Exact incoming caps, the prescribed predecessor set at $t$, and colored
prefix cells preserve all these cases. The colors retain degrees,
recipient status, and predecessor membership. Source camping and camping
at every other column remain forbidden. A complete enumeration of all
43 configurations visits 113,000,606 nodes, 603,453 leaves, and 66,362
guarded-path survivors; its largest evaluated count is 73, and no graph
reaches 80. This proves $M(11,24)\le79$, matching the witness. The source
and complete receipt are `src/small_loss_camped_profiles.cpp` and
`research/small-loss-n11-m24-camped80.json`; the ordinary completeness
audit is `research/small-plateau-camped80-review.md`.

At most 21 arrows give $I\le71$ by the retained arc bounds. At budgets
22 and 23 the bounds are respectively 79 and 78. We have just
proved the value 79 at budget 24. At least 25 arrows leave at most 85
missing pairs. The universal 25-arrow witness therefore proves
$M_V(11)=85$.

**Nonattainment at orders eight through eleven.** By the vertex equality
criterion, an attaining graph would be universally winning and have
indegree and outdegree exactly two everywhere. Any such directed graph
is the union of two arc-disjoint permutation factors. Indeed, its
bipartite tail/head incidence graph is two-regular, so alternating the
edges around each even cycle gives the two perfect matchings. Both
permutations are fixed-point-free. Up to simultaneous relabeling, the
first permutation may be put in canonical cycle form for each partition
of $n$ having no part one; enumerate every second permutation avoiding
both the diagonal and the first permutation's arcs.

The source and predecessor camping conditions above reject a branch as
soon as a completed two-element neighborhood is covered by a known
closed outgoing neighborhood. For the predecessor condition, at least
$n-3\ge2$ sources are indirect, so a covering vertex can be avoided as
the initial source. Every remaining complete graph is evaluated by the
finite least-attractor algorithm. The exhaustive counts are:

| $n$ | Cycle partitions | Recursion nodes | Locally admissible complete graphs | Universally winning graphs |
|---|---:|---:|---:|---:|
| 7 | 4 | 142 | 0 | 0 |
| 8 | 7 | 1,446 | 0 | 0 |
| 9 | 8 | 10,996 | 535 | 0 |
| 10 | 12 | 231,676 | 35,610 | 0 |
| 11 | 14 | 2,177,946 | 120,302 | 0 |

An independent implementation reverses the permutation assignment
order. Its local tests forbid directed transitive triangles, two distinct
length-two walks with the same ordered endpoints, and duplicate
completed outgoing pairs; these are precisely the same camping
obstructions in adjacency-matrix form. It then uses an explicit
alternating-state AND/OR queue attractor instead of the primary
synchronous bitmask iteration. Both complete enumerations give exactly
the displayed counts. As a positive control, a known universal
twelve-vertex graph passes every incremental pruning test and the game
check of the primary enumeration. Hence equality $M_V(n)=n(n-3)$ is impossible at these orders,
which lowers the integer upper bound by one. $\square$

The seven-vertex example also gives the first noncomplete universally
winning graph. At orders at most three, the previously established zero
maximum excludes any missing guaranteed pair. At orders four through
six, the density bound for a noncomplete universal graph would require
$m\le n(n-3)$ and hence $I\ge2n$, contradicting the exact maxima
$2,4,7$.

**Proposition (complete seven-vertex joint table).** Every arrow budget
at order seven is determined:

| $m$ | $M(7,m)$ | $m$ | $M(7,m)$ | $m$ | $M(7,m)$ |
|---:|---:|---:|---:|---:|---:|
|0|0|15|11|30|8|
|1|0|16|12|31|7|
|2|0|17|12|32|6|
|3|0|18|14|33|5|
|4|1|19|15|34|4|
|5|1|20|18|35|2|
|6|2|21|21|36|0|
|7|2|22|14|37|0|
|8|4|23|12|38|0|
|9|5|24|12|39|0|
|10|6|25|11|40|0|
|11|8|26|10|41|0|
|12|9|27|10|42|0|
|13|10|28|9|||
|14|10|29|8|||

**Proof.** The previously established small-arrow bounds and witnesses
give budgets zero through eleven. The universal 21-arrow graph gives
the central value 21, and the dense results give budgets 33 through 42.
The twenty other budgets are certified by complete independent
descending-degree, suffix-cell enumeration, using the normalization
already proved above and an explicit alternating-state game solver.

For completeness, the additional sparse pruning bound is as follows.
If $q$ rows and $r$ columns contain winning indirect pairs, they include
at least $\max(0,q+r-7)$ diagonal coincidences and at least
$\max(0,2q+2r-m)$ direct arrows between them. These exclusions are
disjoint, giving
$$I\le qr-\max(0,q+r-7)-\max(0,2q+2r-m).$$
Partial assignments overestimate the possible live rows using the
permanent source-camping obstructions. For each potential live column,
the cost of reaching indegree two is
$\max(0,2-d^-_{\rm current})$. The remaining arrow budget bounds how many
of the cheapest columns can become live. Maximizing the displayed
inequality over both dimensions below these caps is therefore a valid
upper bound. Fixed source and column capacity sums give further
necessary bounds. Every surviving complete graph is checked by the
explicit game attractor with receipt priority and waiting.

The independent runs cover every degree profile at every one of the
twenty budgets, visiting 193,302,277 nodes. None reaches one above the
displayed value. They reproduce all eighteen completed primary
exclusions and also finish the two cases $m=22,23$; in particular, the
sharp values there are 14 and 12. Literal attaining graphs have complete
winning and losing rank certificates independently replayed by
`src/small_case_certificate_review.py`. The upper receipts and ordinary
audit are `research/small-case-n7-independent.json` and
`research/small-case-n7-independent-review.md`; the consolidated records
are in `research/small-case-results.json`. $\square$

**Proposition (further fixed-host values).**
$$M(8,12)=M(9,12)=9,\qquad M(8,13)=11,\qquad M(8,39)=14.$$
In particular, $M_E(13)\ge11$; no unrestricted equality at budget thirteen
is asserted.

**Proof.** The seven-vertex 12-arrow witness embeds by isolates at orders
eight and nine. At order eight and budget thirteen, the graph with rows
$$
(5,6,7),\ (6,7),\ (1,5),\ (2,4),\ (0,3),\ (4),\ (1),\ ()
$$
has eleven guarantees. Its 1,024 alternating-state rank obligations are
checked directly. Complete fixed-host exclusions of scores 10, 10, and
12 at $(8,12)$, $(9,12)$, and $(8,13)$ cover respectively 55, 61, and 52
degree profiles. They use the descending-degree, suffix-cell method and
the two-dimensional incidence bound proved above. The source differs
from the independently audited seven-vertex implementation only in
comments, array capacity, and the host-order guard. The ordinary coverage
review and literal rank replay are recorded by
`src/small_case_tiny_review.py` in `research/small-case-tiny-review.json`.
This is independent source review, not a second complete negative
enumeration at these host orders.

For $(8,39)$ there are seventeen missing arrows. To exceed fourteen
guarantees, at most two missing pairs could fail. A zero missing row
makes every indirect pair fail. If $\ell$ missing rows have degree one,
their degree-one loss bound forces $\ell\le2$. When $\ell=2$, the two
functional rows must form a two-cycle; the other rows avoid that cycle
and would give a universal six-vertex core with fifteen missing pairs,
contradicting $M_V(6)=7$. When $\ell=1$, its unique image row already
accounts for two failures. The remaining rows avoid its forced bad
targets. Restriction gives either an impossible universal five-vertex
core or a four-vertex core with one safe root. The latter has one of the
four degree profiles $(2,2,2,2)$, $(3,2,2,2)$, $(4,2,2,2)$, or
$(3,3,2,2)$, all excluded by the reviewed rooted certificates. The root
is useful only if the current cop cannot capture there; root arrival is
not declared unconditional success.

With no degree-one row, the missing degrees are $(3,2,\ldots,2)$.
Normalize the degree-three source and its neighbors, then enumerate
every remaining missing row. A union of permanent source and recipient
camping losses rejects only prefixes with at least three forced failures.
The complete search has 46,344 prefixes and 3,168 surviving leaves.
An independent orbit reconstruction covers every leaf using 22 fixed
representatives; all 22,528 negative-state rank obligations are checked.
Their largest score is thirteen, while discarded graphs have score at
most fourteen. Thus the upper bound is fourteen, met by the separately
rank-verified literal graph in `research/small-case-results.json`.
The complete degree reduction, corrected root semantics, source audit,
and full leaf-orbit review are in
`research/small-sparse-eight39-review.md/json`, checked by
`src/small_sparse_eight39_review.py`. This review does not claim a second
traversal of the full search tree or a Lean proof of its enumeration.
$\square$

**Proposition (complete finite intervals).** The missing-pair upper bound
is attained at every budget in each of the following intervals:
$$
\begin{array}{c|c}
n&\text{budgets }m\text{ with }M(n,m)=n(n-1)-m\\\hline
8&24\le m\le26\\
9&24\le m\le54\\
10&28\le m\le70\\
11&25\le m\le88
\end{array}
$$

**Proof.** Saved staged envelopes cover $[24,26]$ at order eight,
$[24,30]\cup[29,53]$ at order nine, $[28,69]$ at order ten, and
$[25,87]$ at order eleven. At each stage the messenger uses only arrows
of a fixed base graph $B$, while the rank obligations permit every cop
move in the larger envelope $E$. Hence the same decreasing ranks prove
delivery for every graph $B\subseteq G\subseteq E$, including every
optional subset and every intermediate arrow budget. The ranks depend
on both positions and are checked at every recipient and initial cop
position. The order-nine stages obtained from the two ends overlap;
no inference from winning endpoints is used. The previously certified
dense endpoints supply $(9,54)$, $(10,70)$, and $(11,88)$. All resulting
counts equal the missing-pair upper bound. The consolidated literal
recipes and certificates are indexed in `research/small-case-results.json`;
`src/small_case_stage_review.py` independently replays the interval
obligations. $\square$

**Verification boundary.** These are finite computer-assisted proofs,
with ordinary completeness and pruning arguments; they are not presently
Lean formalizations. The seven-vertex vertex-maximum exclusion needs no
game solver after the static camping reduction; its complete joint table
also uses explicit game evaluation. The lower witnesses have saved rank
certificates checked directly.
Every remaining degree-two graph and every eight-vertex static survivor
is evaluated by the exact game algorithms in the independent exhaustive
runs; full per-graph ranks for those negative enumerations are not stored.
The vertex maxima at orders nine and ten remain open. The eleven-vertex
maximum is exact, but this does not determine every joint budget below
25. Absence of a two-regular universal graph alone does not determine
the vertex maximum.

Primary sources are `src/small_exceptional_n7_exact.cpp` and
`src/small_exceptional_regular.cpp`; independent sources are
`src/small_exceptional_n7_independent.cpp` and
`src/small_exceptional_independent.cpp`. The eight-vertex sources are
`src/small_exceptional_canonical.cpp` and
`src/small_exceptional_canonical_independent.cpp`; the independent ordinary
audit is `research/small-eight-canonical-independent-audit.md`. The reproduction receipt is
`research/small-exceptional-verification.json` and the research record is
`research/small-exceptional-progress.md`.

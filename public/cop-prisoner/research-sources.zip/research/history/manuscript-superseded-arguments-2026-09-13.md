# Superseded manuscript arguments, archived 13 September 2026

This file preserves text removed from the current manuscript during an editorial
cleanup. These are historical proofs and intermediate bounds, not the current
result catalogue. Theorem 57 now provides the general sparse support reduction;
Theorem 53 proves M_E(23)=83. The eleven-vertex core lemma remains in the current
manuscript because Theorem 53 uses it. Theorem 54 contains the full-vertex
probabilistic and exact-budget argument formerly proved separately as Theorem 25.
No original computational receipt or certificate is removed by this cleanup.

## Former first 23-arc reduction

Original source: paper/odd-endpoint-resume.md, lines 512–618 before cleanup.

**Lemma (first reduction at 23 arcs).** Every graph with 23 arcs
satisfies $I(G)\le87$.

**Proof.** Write $A,B,q,r,b,e$ as in the general arc-bound proof. Then
$q,r\le11$, $e\ge2q+2r-23$, and $I\le qr-b-e$. We first show that
$I\ge88$ would force one of three degree patterns on 12 nonisolated
vertices.

If $q,r\le10$ the elementary bound is at most 83; if either is at
most 9 it is at most 82. For $(q,r)=(10,11)$, the bound is $91-b$,
so only $b\le3$ needs consideration. There are then at least six
indegree-zero vertices in $A\setminus B$: all indegree outside $B$
totals at most one. They emit at least twelve arcs. At most one
recipient in $B$ can have indegree three, and then no arc ends outside
$B$; alternatively at most one arc ends outside $B$. At least nine
of the twelve arcs therefore enter indegree-two recipients in $B$,
producing at least five zero-contribution columns. This gives
$I\le10(11-5)=60$. The case $(11,10)$ uses the corresponding zero-row
argument. Hence $q=r=11$.

If $b\le7$, at least three members of $A\setminus B$ have indegree
zero. Their at least six outgoing arcs produce at least two
indegree-two zero columns by the same argument. Deleting those
columns removes at most four of the at least 21 direct pairs, so
$I\le99-17=82$. If $b=8$ or 9, there is at least one such zero
column. Indeed, the two distinct successors of any indegree-zero
member cannot both avoid indegree-two vertices of $B$: an
indegree-three recipient already uses the whole available unit of
indegree surplus. Removing the column gives
$I\le110-19-(b-1)=92-b\le84$.

Suppose $b=10$, and write $A\setminus B=\{v\}$,
$B\setminus A=\{u\}$. If $v$ has indegree zero or $u$ has outdegree
zero, a zero column or row gives $I\le82$. Otherwise their respective
degrees equal one and exhaust all indegree outside $B$ and all
outdegree outside $A$. All degrees in $A$ and $B$ equal two, and all
other vertices are isolated. This gives the first two patterns below,
according as $u\to v$ is absent or present.

Finally suppose $b=11$, so $A=B=C$ has 11 vertices. At most one arc
starts outside $C$ and at most one ends outside $C$. If all arcs lie
in $C$, there are only $110-23=87$ missing pairs. An arc with both
endpoints outside $C$ leaves a two-regular 11-vertex core; such a core
is not universal by the completed small regular exclusion, so again
$I\le87$. If there is exactly one crossing arc, either deleting it
leaves a two-regular core, or its active endpoint has degree two and
a zero-degree external neighbor. In the former case a losing core
strategy still applies: the messenger cannot use an inaccessible
external source or enter an external sink on a successful route to
an eligible recipient. In the latter case an entire eligible row or
column, containing at least nine missing pairs, contributes zero.
Neither permits $I\ge88$.

If there are two crossing arcs, they are $C\to x$ and $y\to C$.
When $x\ne y$, the same sink or indegree-zero-source obstruction
applies. When $x=y$, this is the third pattern. Thus the only
possibilities under $I\ge88$ are:

| Pattern on 12 vertices | Eligible missing pairs |
|:--|--:|
| Distinct degree-one source $u$ and recipient $v$, all other corresponding degrees two, $u\to v$ absent | 90 |
| The same distinct exceptions, with $u\to v$ present | 89 |
| One vertex of both indegree and outdegree one, every other vertex two-in/two-out | 89 |

All three finite classes can be covered by permutation factorization.
For the first, add the missing $0\to1$ as before. For the second,
add a second copy of $0\to1$ and factor the resulting bipartite
multigraph; both permutation factors then contain $0\to1$. For
the third, add the dummy loop $0\to0$ and choose the first factor
to contain it. All other cycles of that factor have length at least
two. Remove the added copy or loop before all game tests. These
conventions cover every simple graph in the displayed classes.

The same camping prunes remain sound even for a search allowing a
few failed pairs: a source obstruction destroys at least eight
eligible missing pairs, and a recipient obstruction destroys at
least seven. Since each class has at most 90 eligible missing pairs,
no such graph can have $I\ge87$. For every surviving complete graph,
the exact game now counts unsuccessful eligible source-recipient
pairs; evaluation may stop only once the remaining possible count
falls below 87.

All three enumerations complete and find no graph with $I\ge87$.
The respective numbers of complete graphs surviving local
obstructions are 16,902,091, 1,125,588, and 3,558,672. In particular
none reaches 88, contradicting the proposed $I\ge88$. Therefore
$I(G)\le87$. $\square$

The detailed degree reduction is
`research/odd-endpoint-near23-reduction.md`. The exact enumerator
`src/odd_endpoint_near23_exhaustive.cpp` and its three finished
receipts `research/odd-endpoint-near23-absent.json`,
`research/odd-endpoint-near23-present.json`, and
`research/odd-endpoint-near23-same.json` specify the finite checks.
An independent source and mathematical audit is recorded in
`research/odd-endpoint-near23-independent-audit.md`; it does not
claim a separately implemented repetition of the enumeration.
The next lemma strengthens the treatment of eleven-vertex cores and
will reduce the final upper bound by one further pair.

For comparison, a fixed 12-vertex graph with 23 arcs has 83 guaranteed
indirect pairs. Both original game solvers and every direct rank
condition verify this in `src/odd_endpoint_m23_lower.py`, with complete
proof data in `research/odd-endpoint-m23-lower-certificate.json.gz`.
This witness supplies the lower bound in the final 23-arc corollary
below.


## Former intermediate 23-arc corollary

Original source: paper/odd-endpoint-resume.md, lines 676–696 before cleanup.

**Corollary (intermediate 23-arc bounds).**
$$83\le M_E(23)\le86.$$

**Proof.** Suppose $I\ge87$. Repeat the preceding active-set reduction.
The bounds for $q,r\le10$, for $\min(q,r)\le9$, and for $q=r=11$
with $b\le9$ are already below 87. In the corner $(q,r)=(10,11)$,
$I\le91-b$ suffices when $b\ge5$. If $b\le4$, at least five vertices
of $A\setminus B$ have indegree zero. Their at least ten outgoing
arcs produce at least four indegree-two zero columns, giving
$I\le10(11-4)=70$. The dual treats $(11,10)$.

Hence $q=r=11$ and $b=10$ or 11. For $b=10$, the preceding argument
leaves only the two support-12 patterns with distinct exceptional
vertices. For $b=11$, the all-internal graph and every surviving
22-arc core now have at most 81 guaranteed pairs by the lemma;
the external sink or indegree-zero-source cases also lie below 87.
The only remaining possibility is the support-12 pattern with one
vertex of both indegree and outdegree one. All three support-12
searches were completed at threshold 87 and found no graph reaching
it. Therefore $I\le86$. The previously verified 83-pair witness
supplies the lower bound. $\square$

## Former separate proof of Theorem 25

Original source: paper/followup-extrema.md, lines 18–28 before cleanup.

**Proof.** Choose each nonloop arc independently with probability $p$. Fix distinct vertices $s,t$ and a legal initial pursuer position $c\ne s$. Each $u\notin\{s,t,c\}$ is a safe intermediate vertex when
$$s\to u,\quad u\to t\quad\text{are present, and}\quad c\to u\quad\text{is absent}.$$
These three distinct arcs give probability $p^2(1-p)$, including when $c=t$. Different candidates use disjoint sets of arcs, so their success events are independent. There are at least $n-3$ candidates. The probability that this triple has no safe intermediate is at most
$$\exp\bigl(-(n-3)p^2(1-p)\bigr).$$
There are fewer than $n^3$ triples. The probability that any triple fails is therefore less than $n^{-2}$ under the hypothesis.

It remains to enforce the exact arc count. That count has the binomial distribution with parameters $L,p$, and $m$ is a mode because $p=m/L$. Indeed, the ratio of the probabilities at $j+1$ and $j$ is
$$\frac{(L-j)p}{(j+1)(1-p)},$$
which decreases with $j$, is greater than one at $j=m-1$, and is less than one at $j=m$. Hence the probability of exactly $m$ arcs is at least $1/(L+1)>n^{-2}$. It exceeds the entire failure probability, so at least one graph with exactly $m$ arcs satisfies every safe-intermediate condition.

In that graph the messenger moves to its chosen intermediate vertex. The pursuer neither occupies that vertex nor can reach it on its response. The messenger then reaches the recipient, and receipt precedes any further interception. All $L-m$ missing pairs are consequently guaranteed. $\square$

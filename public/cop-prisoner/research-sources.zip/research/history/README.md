# Historical research material

The active paper objective is defined in `research/CLASSIFICATION_SCOPE.md` and its unresolved numerical domain in `research/CLASSIFICATION_GAPS.md`. Use those files and `HANDOFF.md` to resume work.

Dated checkpoint, resume, side-conversation, and development files in `research/` are retained records of what was known or proposed at their dates. Their words such as “current”, “next”, and “priority” are historical unless repeated in the active scope and gap assessment. They do not authorize work outside the agreed exact M(n,m) classification.

The specialized two-move threshold and fast-delivery programme are parked in `paper/delivery-time-companion.md`. The original navigation, terminal, failure, and audit files remain in their original locations so source references and certificate provenance do not break. The shared research archive includes both programmes, with the evidence guide identifying their role.

Superseded manuscript argument bodies are preserved in this folder. Moving a result to a companion or appendix is an editorial scope decision, not a mathematical strengthening or a withdrawal. Original verification receipts and hashes remain untouched. The publication evidence index explicitly identifies historical hash mismatches.

# Historical pre-completion snapshot

This records the superseded101-case checkpoint. Use the current root documents for status.

# Guaranteed indirect delivery in directed networks

The main objective is to determine the exact value of `M(n,m)` for every `n≥1` and `0≤m≤n(n−1)`, and provide explicit adjacency rules or composition procedures attaining the value, with parameters determined from each resource pair. `M(n,m)` maximizes the number `I(G)` of guaranteed missing nonloop source–recipient pairs among graphs with exactly `n` vertices and `m` arcs. The complete classification remains open. The vertex-only and arc-only maxima `M_V` and `M_E` are consequences of the joint problem.

A messenger moves first on a finite loopless directed graph; a pursuer moves after it. Both see all positions and may wait or follow an outgoing arrow. Receipt wins before collision; every other collision loses, and indefinite evasion does not count. Every legal pursuer policy and every initial pursuer position other than the source are quantified. Isolated vertices are allowed.

The original problem and layered construction arose in Alexandra Ignatova's 2023 project under Angel Raychev's mentorship, retained in a February 2024 manuscript. The `n(n−3)` upper bound and two-in/two-out direction are their prior work. September 2026 corrections, attaining families, and extensions were developed with Astra 6 through Codex. Final human publication authorship remains unresolved; no arXiv submission has occurred.

## Start here

- [HANDOFF.md](HANDOFF.md) records the current objective, authorization boundaries, proved domains, and restart instructions.
- [Classification scope](research/CLASSIFICATION_SCOPE.md) defines the private research scope; [classification gaps](research/CLASSIFICATION_GAPS.md) tracks the exact coverage and outstanding cases. [Explicit constructions](research/EXPLICIT_CONSTRUCTIONS.md) audits recipes separately from value proofs. None of these files is a new extremal theorem or release receipt.
- [publication/manifest.json](publication/manifest.json) defines manuscript order, source mapping, and public artifacts.
- [The evidence guide](publication/EVIDENCE_GUIDE.md) maps current proofs to finite evidence and separates them from historical material.
- [The small-case registry](research/small-case-results.json) indexes approved literal graphs, staged intervals, upper proofs and support cutoffs; its independent review records separate those proofs from discovery searches.
- [paper/main.md](paper/main.md) and [the combined formula](paper/joint-classification-resume.md) state the mathematical problem and eventual joint classification.
- [lean/README.md](lean/README.md) gives exact formalization coverage; [RESEARCH_LOG.md](RESEARCH_LOG.md) preserves discoveries, failed approaches, and intermediate checkpoints.

The website sources provide the [exact-count overview](https://angelraychev.com/cop-prisoner/), [classification proofs](https://angelraychev.com/cop-prisoner/proofs/), [paper and evidence](https://angelraychev.com/cop-prisoner/paper/), [Lean coverage](https://angelraychev.com/cop-prisoner/lean/), and a separate [delivery-time companion](https://angelraychev.com/cop-prisoner/delivery-time/). Publication status is recorded separately from source edits. [research/website-deployment.json](research/website-deployment.json) records the last verified public readback.

## The four count regimes

For `n≥5`, the following intervals form a disjoint partition of the feasible budgets. Orders one through four are covered by the complete finite classification and must not inherit this interval ordering without qualification.

1. **Sparse budgets, `0≤m<2n`.** For even `m=2k≥24`, the exact value is `k(k−3)` on every host `n≥k`; for odd `m=2k+1≥25`, it is `k(k−3)+2` on every host `n≥k+1`. These constructions may be padded with isolates. Separately, `M(n,22)=79` for `n≥11` and `M(n,23)=83` for `n≥12`. Arc-only budgets 12 through 21 remain unresolved; small-host joint cases require their own coverage.
2. **Main interval, `2n≤m≤n(n−3)`.** Every missing pair can win: `M(n,m)=n(n−1)−m` throughout the interval at every `n≥12`. Fixed staged envelopes, six-offset circles and a reduced hub interface bridge the smaller orders to the retained infinite constructions. The uniform threshold twelve is sharp: `M(11,22)=79`, below the missing-pair count 88. The sparse endpoint retains its earlier delivery bound, the dense endpoint still works at every `n≥9`, and the older protected, layered, antichain and dense families retain their full domains and stronger guarantees.
3. **Final dense band, `m=n(n−3)+r`, `1≤r≤n`.** Every admissible cell is now exact with an explicit construction. At every `n≥11`, the value is `2n−r−ceil(r/2)−1`, attained within four moves; the uniform staircase threshold eleven is sharp. The earlier two-move construction covers the whole band at every `n≥16`. Smaller orders have complete finite values, including strict departures from the staircase; the final endpoint remains `floor((n−2)/2)` at every `n≥2`.
4. **Zero range, `n(n−2)<m≤n(n−1)`.** The exact value is zero at every `n≥2`; any graph with those resources attains it. At `n=1`, the only feasible value is also zero.

Together, the results determine every `M(n,m)` with `n≥11` and `22≤m≤n(n−1)`, with explicit attaining graphs. At order eleven, the boundary values at budgets 22, 23 and 24 are respectively 79, 78 and 79; budgets 25 through 88 attain the missing-pair bound, followed by the dense staircase and zero range. The uniform main-interval formula itself still starts at order twelve. Complete joint tables are known through order seven. The remaining main cases have orders eight through ten.

The current [coverage ledger](publication/classification-coverage.json) leaves 101 canonical numerical gaps: 69 sparse, 32 main, and no dense gaps. The approved support reductions place every unresolved representative at host order at most 18. Budgets 12 through 21 and the remaining main cases still require exact proofs and attainers; the open endpoint `(8,40)` has bounds `12≤M(8,40)≤13`. The separately refreshed construction audit matches this ledger and finds no known-value construction-only gaps.

## Research priority and the parked companion

Further research must address both unknown values and missing explicit constructions. An existence or derandomization proof can settle a value while leaving the explicit recipe open. Closing the small numerical cases alone is not the completion condition. Structural lemmas, finite exclusions, and new routing constructions are useful when they serve that objective. A classification of all maximizing graph shapes and a future structural `D(G)` program are private, parked directions unless a specific argument is needed for the count problem.

Delivery-time optimization is a separate parked companion. Preserve the proved `q₂(n)=Θ(n log n)` result, its constant bounds, existing sparse delivery bounds, and the partial eight-recipient-type construction there. Types two and seven remain open; no universal logarithmic-time sparse construction is claimed. Moving these results does not prove or withdraw them. Two-move routing remains in the main manuscript wherever it constructs graphs attaining `M(n,m)`.

## Construction and evidence distinctions

The required output is a concrete adjacency rule or specified composition with parameters from `(n,m)`. Fixed certified exceptional graphs and proved finite parameter selections are allowed. Generic graph search and conditional-expectation adjacency selection are distinct methods and do not automatically complete this objective. The separate construction audit records where a direct alternative already covers the same resources.

The general proofs are ordinary mathematical arguments. Sparse ring constructions use finite local strategy certificates plus proofs that every actual pursuer move is represented locally and that composition terminates. Finite ring tests alone do not establish an infinite family. The full main interval is not a two-move theorem. Its new finite bridge uses saved ranks on both player positions, replayed against every legal pursuer response. The six-offset periodic circles and reduced twelve-hub interface have ordinary parameterized proofs. The general `StagedEnvelopes` Lean module proves the asymmetric rank-to-delivery implication; it does not instantiate the finite tables, circle parameters, hub codes or complete interval coverage. A uniform repeatable vertex-attachment rule remains open and is not required for this finite bridge.

The new dense and small-order results combine ordinary support and safe-root reductions with complete finite exclusions, independently checked literal graphs, and full winning/losing rank certificates. [The dense proof](paper/dense-third.md) preserves safe root arrival and the actual pursuer replies. [The small-case registry](research/small-case-results.json) records the approved inputs. These concrete finite results are external computer-assisted proofs, not new Lean instances of the complete classification.

Preserve smaller-order, exact-budget, support, and optional-subset hypotheses when consolidating constructions. An arbitrary-subset guarantee applies to its prescribed envelope, not to arbitrary arrow additions. The support reductions retain sharper conclusions than the general concentration theorem, which does not assert that deleting exceptional arrows preserves `I`.

Lean proves selected game semantics, certificate-to-strategy implications, explicit sparse and dense examples, six small robust envelopes, and selected branching, camping, dense-counting, and routing-preservation results. The general extremal theorems and infinite constructions are not fully formalized. [lean/verification.json](lean/verification.json) records checked module hashes; the evidence guide states the other proof boundaries. Dated notes and [research/history/](research/history/) preserve earlier bounds and approaches.

## Build and replay

Edit individual sources listed in the manifest, not generated `paper/assembled.md`, `paper/main.tex`, or website proof HTML. `src/build_publication.py` assembles the manuscript and web proof text, checks Lean source hashes, packages downloads, and recompiles the standalone LaTeX archive. It requires the publishing Python, LaTeX, and isolated website checkout at `.site-worktree`.

`python3 lean/check.py --lean /path/to/lean` replays the Lean modules. Read each certificate script's help or main function before replaying it; saved graphs and complete ranks avoid rediscovering witnesses. Most Python checks use the standard library; optional NumPy accelerates the larger odd-bridge verifier, which also offers a scalar mode. `src/check_web_solver.py` compares the website explorer with Python.

The manuscript PDF is [output/pdf/guaranteed-indirect-delivery.pdf](output/pdf/guaranteed-indirect-delivery.pdf). The receipts `research/publication-build.json`, `research/pdf-verification.json`, `research/pdf-visual-review.json`, and `research/website-deployment.json` distinguish building, document verification, visual review, and public readback. Consult those receipts for the release actually built and deployed; earlier PDFs and receipts describe their recorded releases. The current research pass closes additional mathematical cases; it does not establish full classification or publication readiness.

Extract `finite-strategy-certificates.zip` and `research-sources.zip` into the same directory for full finite replay. The former contains the two large even and odd finite rank files; local-window certificates remain in the research archive. The manifest and evidence guide define current artifact entry points.

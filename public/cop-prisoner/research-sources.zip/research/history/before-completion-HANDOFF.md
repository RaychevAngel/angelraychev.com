# Historical pre-completion snapshot

This records the superseded101-case checkpoint. Use the current root documents for status.

# Guaranteed indirect delivery: current handoff

Updated 13 September 2026 (Pacific Time). Start here, then README.md,
`research/CLASSIFICATION_SCOPE.md`, `research/CLASSIFICATION_GAPS.md`,
`research/EXPLICIT_CONSTRUCTIONS.md`, and the latest RESEARCH_LOG.md entry. The complete classification remains
open. Consult
`research/website-deployment.json` before calling current sources deployed.

Current mathematical checkpoint, 13 September 2026: every admissible final dense-band cell is exact, with the uniform staircase from order eleven, and the full joint range `n>=11,m>=22` has explicit attainers. At order eleven the three boundary values at budgets 22, 23 and 24 are 79, 78 and 79; the uniform main-interval missing-pair formula still starts sharply at order twelve. The full seven-vertex table is complete. The current ledger has 101 canonical gaps, all represented on at most eighteen vertices. In these counts the endpoint m=2n is assigned to the sparse group; the 32 main gaps use m>2n. Build verification and live deployment are separate claims: consult the current publication/deployment receipts. Older release notes below are historical and do not certify later source changes.

## Main objective and source organization

Determine the exact joint maximum `M(n,m)` for every `n≥1` and every
`0≤m≤n(n−1)`, with explicit adjacency rules or specified composition procedures attaining each value, with parameters determined from `(n,m)`. `M_V` and
`M_E` are consequences obtained by maximizing over the other resource.
For `n≥5`, organize coverage as sparse `m<2n`, main interval
`2n≤m≤n(n−3)`, final dense band `n(n−3)<m≤n(n−2)`, and zero above
`n(n−2)`. Smaller orders are already covered by the finite classification;
the interval ordering must not be assumed there. Use separate numerical and explicit-construction inventories. Generic search or a bare existence proof is insufficient; deterministic derandomization does not automatically supply the required direct recipe. Certified listed finite exceptions are accepted. A finite reduction of numerical values alone does not close this stronger objective.

The source reorganization keeps the count classification in the main
manuscript and places specialized delivery-time questions in a separate,
parked companion. It uses `publication/manifest.json`; existing theorem
labels and distinct domain, time, and subset guarantees are preserved.
Two-move routing arguments remain in the main proof wherever they establish
an attaining graph. The website sources have the overview, classification
proofs, paper/evidence, Lean coverage, and `/cop-prisoner/delivery-time/`.
Use `research/website-deployment.json` for verified public readback of these routes.
`publication/EVIDENCE_GUIDE.md` and `publication/evidence-index.json` identify
current proof dependencies and historical receipts. Redundant argument bodies
are retained in `research/history/`. The builder uses a fresh standalone TeX replay and
an explicit inventory of every served asset; an unclassified leftover fails
the build. Historical release records are retained below. This reorganization does not establish new mathematical cases or publication readiness; build, verification and deployment receipts state the checks actually performed.

## Authorization, priorities, and credit

Angel accepted the five classification priorities and authorized execution after the bounded scope audit. The research priority is to close both numerical gaps and explicit-construction gaps, even where the count is already known. The current pass includes bounded mathematical research, independent review, and artifact publication. Stronger support lemmas, finite exclusions,
or routing constructions serve that priority when they close an identified
gap. Preserve earlier parameter domains, exact budgets, and arbitrary-subset
freedom when a theorem is subsumed. Delivery-time optimization is parked.
The future structural `D(G)` program and classification of all maximizing
shapes remain private and parked unless needed for the count problem.

Prior authorization includes continued research and website/artifact
publication; the old 10% stopping rule was explicitly lifted. New investigations remain within the joint-count and explicit-construction objective.
No arXiv submission or outreach is authorized for this project.

Preserve Alexandra Ignatova's original author credit and Angel Raychev's
mentor credit. The original upper bound and two-in/two-out direction are
theirs. September2026 extensions were developed with Astra6 through the
Codex harness. Final human publication authorship remains unresolved.

## Exact game

Finite simple loopless directed graph, opposite arrows allowed. Both players
see both positions and may wait or follow an outgoing arrow. Messenger moves
first. Receipt wins immediately, before collision, even when cop occupies
the recipient. Any other collision loses; infinite evasion loses. Every
initial cop c≠s and every history-dependent legal cop policy are quantified;
the messenger may adapt to c. Time means messenger moves.

I counts only guaranteed missing nonloop ordered pairs. L=n(n−1), h=L−m.
M(n,m) is central; M_V and M_E maximize over the other parameter. Isolates
preserve I. Two-move witnesses use u in N+(s)∩N−(t) outside {c}∪N+(c).
For robustness, messenger may be restricted to base B while cop receives
full envelope E: a safe witness for every B-missing pair then works in
EVERY graph between B and E. `RobustTwoMove.lean` proves this semantics.

## Current checkpoint: values and explicit constructions

The indexed coverage has **101 canonical unknown pairs**: 69 sparse, 32 main-interval and no dense gaps. All main gaps have orders eight through ten. The approved comparison-witness support reductions lower the containing host bound to eighteen, with separate budget-specific cutoffs for budgets 12 through 21. The full seven-vertex table and every dense cell are complete. The additional exact value `M(8,39)=14` has independent review; `(8,40)` remains open with `12<=M(8,40)<=13`. The ledger retains its old audit box through order 114 for comparison; its canonical counts omit the repetitions removed by the approved support reductions.

The new approved exact cases have literal graphs, staged recipes or proved composition rules, indexed in `research/small-case-results.json`. The separately refreshed recipe audit matches the enlarged ledger and finds zero known-value construction-only gaps. A future existential equality can leave a recipe obligation. Read `publication/classification-coverage.json` for the current numerical intervals and `research/CLASSIFICATION_GAPS.md` for their discussion. Full classification, publication readiness and complete Lean verification are not claimed.

## Current proved domains

- **Combined joint range:** every `n>=11` and `22<=m<=n(n-1)` has its exact value and an explicit construction. At order eleven, `(M(11,22),M(11,23),M(11,24))=(79,78,79)`; budgets 25 through 88 attain the missing-pair bound, followed by the staircase and zero range. From order twelve use the separate 22/23 values, sparse parity formulas, main missing-pair value, staircase and zero range. This broader coverage does not extend the uniform main-interval formula to order eleven.
- **Main interval:** every `n>=12`, `2n<=m<=n(n-3)`, has value `L-m`. `src/main_interval_complete.py` selects literal adjacency from proved intervals, fixed staged lists and retained arithmetic families; it delegates unchanged to the previous construction from 104. The finite bridge is computer-assisted, with complete ranks against the actual pursuer responses. The six-offset circles, reduced hub interface and retained infinite tail have ordinary proofs. The uniform threshold twelve is sharp because `M(11,22)=79<88`. This is not a uniform two-move result. Earlier 43/104 and 106/115 domains and all stronger component guarantees remain valid.

- **Sparse endpoints:** Theorem 40 gives `M_V(k)=M_E(2k)=M(k,2k)=k(k-3)` for `k>=12`, with `9ceil(k/6)+18` moves. Theorem 45 gives `M_E(2k+1)=k(k-3)+2` on `k+1` vertices for `k>=12`. Its uniform bound from support 145, faster period-six subfamily and finite bridge remain distinct.
- **Optional sparse envelopes:** Theorem 52 retains its infinite family `n>=115`, `2n<=m<=20k-11d`, where `k=ceil(n/6)`, `d=6k-n`, every optional subset allowed, and at most `9k+21` moves. A finite supplement verifies the same canonical envelopes at `S={60} union [64,66] union [68,72] union [75,78] union [80,90] union [92,114]`. The repaired 109 envelope restores `(8,22)` and `(14,108)` and covers budgets 218 through 327. The finite certificates retain arbitrary optional subsets and use at most 72 moves. One 32 MB bundle holds all 48 records, with separate primary and independent replays.
- **Dense staircase:** for every `n>=11`, `1<=r<=n`, the value at `m=n(n-3)+r` is `2n-r-ceil(r/2)-1`, with an explicit construction within four moves. The threshold eleven is sharp. Every `n>=16` retains the full band within two moves. Root-colored cycles cover `r>=5` and all `k=n-r>=0`, preserving the stated two-/three-move distinctions. The main interval's dense endpoint is attained from order nine. The old robust bridge and quadratic caps retain their optional-subset claims.
- **Small budgets and projections:** budgets 12 through 21 remain the sparse numerical task in the current ledger. Approved upper bounds, matching lower witnesses and budget-specific support cutoffs are indexed in `research/small-case-results.json`; every remaining representative has host order at most eighteen. The full joint table is complete through order seven. In addition to `M_V(7)=21` and `M_V(8)=32`, the new reviewed value is `M_V(11)=85`. These projections must not be mistaken for complete joint tables at orders eight through eleven.
- **Small dense values:** all 21 formerly unresolved dense cells are closed. For orders 7, 8, 9, 10 respectively, the `r=1` values are `(8,11,14,16)`, `r=2` gives `(8,10,12,15)`, `r=3` gives `(7,9,11,14)`, and `r=4` gives `(6,8,10,12)`. These literal exceptions retain their actual time bounds, including five moves at `(9,55)`. `paper/dense-third.md` states the ordinary reductions and complete finite proof dependencies.

## New arguments and proof boundaries

`paper/main-interval-complete.md` proves the interval selection from order twelve. `research/sparse-staged-records.json` stores the fixed arrow lists and certified prefix intervals; `research/sparse-staged-certificates.zip` stores their two-position ranks and policies. The stages allow earlier added arrows to become compulsory messenger resources. Every optional subset within each individual stage works; no arbitrary-subset claim across unrelated stages is inferred. A repeatable uniform marked extension remains a possible simplification, not a missing premise of this finite bridge.

`paper/main-interval-six-circle.md` replaces the safe pair by a third alternative move and proves the same four-position propagation. Period-four and period-five envelopes have ordinary arithmetic proofs. Literal smaller envelopes use the same premises; promoted finite circles have separate source-rank certificates. `paper/main-interval-reduced-hubs.md` gives an ordinary five-move interface for two through seven guides and arbitrary permitted bulk antichains, with base `106+18g+12b+W` and `b(g+b+8)` optional arrows. The independent ordinary review and literal reconstruction are recorded in `research/main-interval-fifth-ordinary-review.json`.

`lean/StagedEnvelopes.lean` proves the generic position-dependent asymmetric rank implication for every intermediate graph and actual delivery. The large finite records, their computed ranks, the circle parameters, hub codes and complete numerical overlap are not instantiated in Lean. Consult the current Lean receipt for the exact checked module set.

`paper/main-interval-half-density.md` proves a base with five offsets and a cop envelope containing roughly half the circle. The full residue family covers5n..n(n/2-1) at every order divisible by4 from16; guarded variants handle further orders under their explicit gcd and interval hypotheses. Four-source patterns propagate by-h to prove delivery. Every optional subset works. The earlier eight-offset proof remains a consequence.

`paper/main-interval-layered.md` gives explicit twelve-/fourteen-hub, guide and bulk constructions. Distinct equal-size guide subsets supply safe entries to a region from which delivery takes at most two further moves. Every allowed optional subset works within three moves. Both adjacency formulas and all parameter bounds are recorded; the twelve-hub pair codes have a separate proof, not an invalid appeal to the size-three antichain theorem.

`research/main-interval-new-independent-checks.json` independently reconstructs both families without importing their constructors:145 envelopes,1,238 recipients and4,416,069 rank obligations pass. `research/main-interval-fourth-review.json` independently decodes493,924 ledger cells, preserves every old exact value and validates all new rule uses against the frozen prior ledger. These are bounded checks supporting the ordinary infinite arguments, not replacements for them.

`lean/RobustLayers.lean` proves the generic source-rank envelope induction and safe-entry composition against arbitrary legal cop policies. All twelve Lean modules pass in the current receipt, including the generic staged-envelope addition. The concrete residues, guide codes, counts and interval overlap are not claimed formalized.

`paper/core-code-composition.md` counts every core parity. Odd cores have capacity `2C(k,r)`; even cores have capacity `C(k,r)+sum_i C(k/2,i)C(k/2,r-i)`, where C counts independent subsets of a cycle. Direct listing requires no arbitrary graph search. The `k=10,r=3` capacity is 100 and supplies `37n-400<=m<=L-(3n-20)` for `20<=n<=120`. Its independent checker verifies 900 formula identities, 10,156 literal code comparisons and 2,822,210 asymmetric witnesses. The mixed order-105 list adds 85 codes of total weight 268, interval 3472 through 10612, and 774,592 witness checks. Fixed circles at 100 through 111 are structurally checked. Those order105 gaps are now closed by the new families; the fixed envelopes remain valid retained constructions.

`paper/sparse-third.md` proves the stronger original-graph support reduction and exact 22-arrow result. For `k>=7`, a graph with `2k` arrows and `I>k^2-5k+8` has exactly k nonisolated vertices; do not use this conclusion below its threshold. The first proof had a surplus/sink equality gap, found by independent review. The repaired outer-diamond argument is recorded. The 14/16 bounds use existing small-order upper theorems; 18/20 add reviewed complete directional transfer enumerations; 22 uses the regular eleven-vertex exclusions and a fixed 79-guarantee graph. Review did not rerun a second complete enumeration. The three new best lower witnesses have two-solver and full-rank checks.

`paper/dense-third.md` now gives complete final-band coverage: colored cycles, singleton and safe-root attachments, exact missing-block addition, strict small values and the sharp staircase threshold eleven. A root reached before the actual recipient is useful only after safe arrival; an unsafe root arrival remains capturable. Ordinary degree-one reductions lead to complete small rooted and ordinary-core exclusions, with all surviving finite graphs checked in the actual game. The earlier nine-core and first-step records at orders thirteen through fifteen remain valid with their original guarantees.

`research/small-case-results.json` is the approved small-case registry. Its fixed certificate bundle supplies literal adjacency and complete winning/losing ranks; its stage inputs specify every allowed intermediate graph. `research/small-case-independent-review.json`, `research/small-case-rooted-independent-review.json`, `research/small-case-first-step-independent-review.json`, `research/small-case-first-step-literal-review.json`, and the order-seven independent receipts record the relevant separate replays. Support reductions and their explicit isolate lifting are in `research/small-case-support-cutoffs.json`. Incomplete discovery searches and private follow-up candidates are not upper proofs. These concrete exclusions and certificates are external finite proofs combined with ordinary mathematics, not a new full Lean classification.

`research/sparse-interface-third-proof-registry.json` identifies the 48 asymmetric finite certificates in one ZIP. The independent checker reconstructs adjacency without project imports. Literal graph rules, full ranks and finite domains are explicit. These records do not prove an additional infinite projection theorem.

The existing concentration theorem does not assert `I(core)>=I(G)` or justify deleting exceptional arrows. Protected routing and orientation retain their conditional-expectation methods and stronger prescribed-routing properties. Direct alternatives at the same resources do not inherit those properties automatically.

## Sparse finite proof and failure boundaries

Canonical holes0,3,...,3(r−1), not arbitrary gap3 sets. Suppress precisely
seven relative optional rules perhole; see52. M5 messengerwindow, R8 cop,
Omega reenters±6,±7,±8. All101 possible canonical crops;696 objectives.
Two adjacent final entries−3/−2 give39/38 moves; transfers≤9. First hit
of the two entries takes at mostk−2 transfers. Allk≥20 crop coverage and
no-wrap/exterior projection have ordinary proofs.

Full certificate:
`research/dense-phase2-sparse-two-entry-certificates.json.gz`.
Independent checker: `python3 src/dense_phase2_sparse_two_entries.py --check`.
Primary collapsed solver separately verifies all101/696:
`research/composition-budget-phase2-two-entry-root-check.json`.
M4 withentry−3 fails96 objectives; M5 repairs them. Arbitrary gap3 crop
[-3,1] fails: do not generalize from canonicalcluster toallholepatterns.

## Delivery-time companion: proved results and parked partial work

These results remain valid with their stated hypotheses, but optimizing
delivery time is separate from the current exact-count objective. Preserve
the delivery bounds in Theorems 40, 45 and 52 when describing their
constructions; do not use the companion's open questions as new main goals.

The extracted two-move consequence of the former full Corollary55 proves q2=Theta(nlogn), with lowerceil(n(log2n−1)/2).
The orientation specialization improves b toceil(24lnn+4), exactA=Q/2,
specifiedhubset, every exterior subset, polynomialderandomization.
Theorem59 gives q2≤(5.3555763082+o1)nlog2n with an explicit rule
at every n≥30. Exact leading constant and threshold saturation remain
open. The full variable-density/random-sampling Theorem54 remains an
independent result; its routing construction is still used by the count
proofs where appropriate.

Ten-type two-generator gadget: independently audited safe navigation≤32
moves in either negative quotient generator under a six-exclusion interface,
with one-move normalization. This transfers to girth≥9 quotients. Full
layers and independent geometry/rank review are retained. A stronger common
twelve-exclusion interface has new finite certificates: initialization≤2,
navigation≤32, terminal delivery for types0,1,3,4,5,6,8,9≤62. The
finite-girth projection (conservative girth133) and all825843 new rank
obligations passed a separate independent audit. For simple4regular
quotients of girth≥133 and inverse-generator diameterD, all eight recipient
types deliver within32D+64; see terminal-independent-audit.md.
Types2/7 remain open. A cop can camp on an infinite-tree gate, so a proof for
finite quotients needs global bypass information. Adding two extra arrows
per ten-type cell (budget2.2n) did not repair the failure. No O(logn)-time
universal sparse theorem is claimed. Connected24vertexdoublecover of the
known12core is NOTuniversal (119 losing starts for target2); naivecover/
projection fails. Logs are research/composition-interface-*.

## Formalization and publication

Lean4.33.1/Std modules and their checked source identities are recorded in `lean/verification.json`. New RobustTwoMove semantics and explicit
ElevenVertexDense88-arcs/22-guarantees join the old12vertex sparse certificate.
SmallDenseEnvelopes proves the six16..21 base/envelope counts, correspondence
to the published row lists, and actual delivery for every intermediate graph.
All finite witnesses checked by kernel reduction; no sorry/customaxioms/
native_decide. General59/60, denseinfinitefamilies, sparseprojection,
existence/counting remain ordinary proofs. Receipt `lean/verification.json`.

Build: `/Users/angel/code/math/princess/.tools/publishing/bin/python src/build_publication.py`.
Lean: `python3 lean/check.py --lean /Users/angel/code/math/polyominoes/.tools/lean-4.33.1-darwin_aarch64/bin/lean`.
TinyTeX: `/Users/angel/Library/TinyTeX/bin/universal-darwin/`.
Websiteworktree `.site-worktree`, branchcop-prisoner-research,
remoteRaychevAngel/angelraychev.com. PreserveparallelPrincesswork and
node_modules symlink. Fetch/rebase before scopedpush. Build checks source
archive recompile, Lean hashes, figures, mathrendering. Visually inspectPDF
andsite beforepush; verifydeploymentandliveartifacthashes afterward.

## Historical phase-two publication checkpoint

The phase-two mathematics is committed locally at e70cb4c. Website commit
427472af1d4d6e5c66957a62caceb6b6cdcd488a deployed successfully in
GitHub Actions run34745653181. All four routes returned successfully and
all eight public download hashes match the checked local release. The PDF
is88pages/8figures. Live browser review confirms threshold115, densebridge16,
and the explicitly partial eight-type result, with no formula errors or
horizontal overflow. Exact readback is in research/website-deployment.json.
The mathematical open boundary above is unchanged. All research workers
and local checking jobs have finished; no expensive computation remains
running from this phase.


## Historical publication audit release — 13 September 2026

This release supersedes the earlier deployment record above. Mathematical
claims are unchanged. Source commit `212fa69`; site commit `4d10f2a`;
GitHub Pages run `34746687576` succeeded. The 87-page, eight-figure manuscript
has eight thematic chapters. All 63 numbered statement labels and all 79
previous proof heading anchors remain. All 87 pages were rendered and
visually reviewed; the fresh-directory TeX replay matches the PDF text.

An independent artifact audit verified 31 served assets, all four source
archives (624 research entries, 15 Lean entries, 10 manuscript entries,
two large finite certificates), 179 source pins and the three explicitly
classified historical exceptions. All Lean source pins remain current;
this editorial turn did not rerun Lean or the mathematical searches.
All 135 local links/assets passed, and an intentional test leftover was
rejected. Live readback verified every served asset hash and all four routes;
live proof-page inspection confirmed eight chapters, no math errors and no
horizontal overflow. See `research/website-deployment.json` for exact hashes.
That verified release had four pages and the same eight root downloads.
It predates the present scope reorganization and the companion route; its
page count, route count, and verification details must not be used as proof
that the reorganized sources are built, inspected, or deployed.


## 13 September 2026: scoped classification artifacts deployed

The reorganized checkpoint is live at https://angelraychev.com/cop-prisoner/. Website commit `65df9f4b4a9405d6c6463ef45f8ff7ead9fd7b10` was deployed by successful GitHub Actions run `34750333023`; research source commit is `49b6ea367b0dd614c75e283a95b01abe93e1584d`. The prior Princess-only site update was preserved.

The main manuscript has 86 pages and eight figures; the separate parked delivery-time companion has eight pages. Both standalone TeX archives were recompiled and matched their respective published PDF text. All 94 final PDF pages were visually inspected. All 63 numbered main-result labels and the moved two-move anchor are preserved. The local five-route check covered 154 links/assets with no broken targets. Live HTTPS readback matched all five built pages byte for byte and all 33 served-asset hashes. Browser checks found no formula errors or horizontal overflow.

The independently audited numerical coverage leaves 61,742 canonical representatives outside the explicitly incorporated proved domains: 288 sparse, 61,393 main-interval, and 61 dense. The containing order bound is 114. This is an inventory of current source coverage, not a claim that every consequence of the conditional theorems has been extracted. The fixed `(11,22,71)` witness was reverified as a lower bound. No new extremal search or full Lean classification is claimed. Current Lean source pins match the existing receipt; the Lean compiler was not rerun in this editorial/audit checkpoint.

Current scope: `research/CLASSIFICATION_SCOPE.md`. Exact ranges, attempts and prioritized next investigations: `research/CLASSIFICATION_GAPS.md`. Independent coverage review: `research/classification-coverage-review.md`. Actual live verification: `research/website-deployment.json`. The source package was frozen before this appended deployment note; no archived source was overwritten to retrofit a receipt.


## 13 September 2026: explicit-construction scope correction deployed

The corrected scope and construction inventory are live at https://angelraychev.com/cop-prisoner/#explicit-constructions. Research source commit `391877a3a1a6c1980b48e8bcc0df5ac464721a64` and website commit `5611b654a49ed77511ff6fee154999faefa92914` identify the release. GitHub Actions run `34753363908` succeeded. Live readback matched all five built pages byte for byte and all 33 served-asset hashes. Browser inspection confirmed the separate construction requirement, the audited zero known-value construction-only gaps, the 87-page manuscript link, no formula errors and no horizontal overflow.

The main manuscript has 87 pages and eight figures; all pages were rendered and visually reviewed. Its standalone source archive recompiles to matching PDF text. The eight-page delivery-time companion PDF is byte-for-byte unchanged, retains its prior visual review, and its source archive was freshly recompiled. All 63 numbered main-result labels remain. The local five-route check covered 160 links/assets without broken targets. The artifact audit passed 157 referenced paths, 289 source pins, the three classified historical exceptions, and all archive contents. Lean source hashes remain unchanged; the compiler was not rerun.

No numerical result or remaining interval changed. The normalized numerical rows retain SHA-256 `c067c951ccd496f6f9642292af03680f85a5acc43fd2669dd7a37b7ecc4a40ad`. The source audit independently found a direct recipe or certified listed finite graph for every currently indexed exact value. All 61,742 canonical unresolved numerical representatives still require both their exact-value proof and an explicit attaining construction. Conditional-expectation results retain their methods and stronger properties; alternative count-attaining graphs do not inherit those properties automatically. No new extremal search or mathematical gap-solving was performed.

See `research/EXPLICIT_CONSTRUCTIONS.md`, `research/CLASSIFICATION_SCOPE.md`, and `research/CLASSIFICATION_GAPS.md` for the operative boundary and exact family domains. `research/website-deployment.json` records the live verification. This post-release note is appended after freezing the source archive; the archived prefix is unchanged.


## 13 September 2026: stronger classification checkpoint deployed

The updated site is live at https://angelraychev.com/cop-prisoner/. Website commit `ea97ba9d64366a46daf0c8fe605c3555d066d17a` deployed successfully in GitHub Actions run `34756071574`. The research source commit is `0f61bfc7af983aa5ce89ca4557fb80119cd773d8`. The preceding Princess site changes were preserved.

Live readback matched all five routes and all 33 served asset hashes against the local build. The main manuscript is 101 pages with eight figures. All pages passed visual review; its standalone source recompiled with matching text and no overfull boxes. The unchanged eight-page delivery-time companion retains its separate review. All 168 checked website links and anchors resolve, and 63 existing numbered statement labels remain. The consolidated sparse certificate bundle is included in the research archive.

The checkpoint closes 13,196 canonical unknown pairs. The remaining 48,546 split into 254 sparse, 48,271 main-interval and 21 dense cases. Every incorporated exact value still has a separately audited direct recipe or certified finite graph. Exact22=79, the full main interval from106, the full dense band from13, and the reviewed sparse bounds are recorded above and in the gap inventory. Full classification remains open. New results are ordinary or computer-assisted proofs; no new Lean compilation or formalization is claimed. Existing formal source hashes match their retained receipt.


### Fourth main-interval checkpoint: final build verification

The107-page main manuscript and nine figures are built. All107 pages were rendered and reviewed; the final wording/figure rebuild changed only pages3,6,60, which were reinspected, and104 other page renders are identical. The eight-page companion PDF is unchanged. Standalone source replay has matching text and no overfull boxes. All eleven Lean modules pass, with the generic RobustLayers boundary stated above. The final artifact audit checks35 served files,231 referenced paths and475 source pins, with six explicitly historical source-pin mismatches retained unchanged in their original receipts. Five local routes have176 checked links/assets and no broken targets; all63 earlier numbered result labels remain. This entry records build verification. Consult research/website-deployment.json for the separate live deployment/readback result.


### Fourth main-interval checkpoint: live publication verified

Website commit eed8def30ed5badd8a7b287b193737ce12b18842 is live; GitHub Pages run34759149978 succeeded. Fresh live readback matches all35 served asset hashes and allfive route HTML files to the local build. Both large archives were fully downloaded and verified; a first timeout did not count as a successful check. The107-page/nine-figure release reports6,416 canonical gaps (254sparse,6,141main,21dense), with zero audited known-value construction-only gaps. The live overview and interval figure were also visually checked. Research source commit1a226ec contains the mathematical checkpoint; research/website-deployment.json records this subsequent readback. The project remains unsubmitted and the classification remains open.


## Verified release after the order-twelve theorem

The current public checkpoint is website commit c04b3241007156f8d704b28956a74a633dc8de67, Pages run 34762675567: 114 manuscript pages, all five routes and 36 served assets checked against local bytes. Mathematical source checkpoint: 92b1169. The main interval is explicit for every n>=12, with sharp threshold; 454 canonical numerical cases remain (254 sparse, 179 main, 21 dense). No known-value construction-only gap remains in the indexed coverage.

For a saved-stage replay use `python3 src/check_sparse_staged.py`. Do not invoke historical `src/sparse_staged.py --certify` against the current coverage ledger: it selects old unresolved cells and would overwrite the frozen catalogue. Construction via `src/main_interval_complete.py` and saved-certificate replay do not use discovery. Both the staged replay and the independent ordinary-review script pass from the final extracted research archive. The full concrete classification is not a Lean theorem.

## 13 September 2026: small-case checkpoint published and verified

Website commit `76eb7458f17b2df5651c65a8e0949ce1e0eeea1f` is live;
GitHub Pages run `34768459410` completed successfully. Mathematical source
commit `39932e4` and manuscript commit `62b4c9d` preserve this checkpoint.
Fresh HTTPS readback matched all five route HTML files, all36 served asset
hashes (including both large evidence archives), and the release manifest.
The live overview also passed desktop and phone browser checks.

The130-page main manuscript has nine figures. Its standalone LaTeX archive
recompiled with matching text and no overfull boxes. All130 pages were rendered
and visually inspected; the final correction changed only page117, which was
reinspected. The eight-page companion PDF is unchanged. Both proof pages now
wrap long paths and allow wide tables to scroll on narrow screens; their
mathematics and the site's presentation conventions are preserved.

The independent ledger reconstruction checks all493,924 audited cells, preserves
all492,660 previously exact values, and verifies174 newly exact cells. A further
179 still-unknown representatives are removed through proved host reductions.
The resulting101 gaps are69 sparse and32 main, none dense, all represented at
orders at most18. The separately refreshed construction audit reports zero
known-value construction-only gaps. Every admissible n>=11,m>=22 is exact with
explicit attainers; every order-seven budget and every final dense-band case
is complete. The whole classification remains open.

The full artifact audit checked311 referenced paths,1187 source pins and all36
served files, preserving22 explicitly historical pin mismatches. The182 checked
local links/assets and63 earlier numbered result labels remain valid. Extracted
archive replay passed all56 literal graphs (77,350 alternating-state conditions)
and all64 new asymmetric stages. Twelve Lean modules and their exact verified
sources are retained; the new concrete finite classification is externally
reviewed, not a new full Lean theorem. No arXiv submission or outreach occurred.

`research/website-deployment.json` records the complete readback. This section is
appended after freezing the research download; the archived prefix is unchanged.
Resume from `research/CLASSIFICATION_GAPS.md` and the consolidated
`research/small-case-results.json`, not from historical pilot scores.

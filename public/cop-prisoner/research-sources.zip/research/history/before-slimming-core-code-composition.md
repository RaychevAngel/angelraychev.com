# Composition through incomparable hub sets

The construction below reduces a delivery problem on an arbitrarily large
outside set to a family of subsets of a small core. The subsets specify
which hubs an outside vertex cannot reach. Incomparability makes one outside
vertex's inaccessible hubs available to another vertex. A two-part core
handles the remaining configurations, including recipients inside the core.
This produces an entire robust interval of exact budgets.

**Theorem 59 (antichain composition).** Let $k\ge5$. Take two sets of hubs
$P_i,L_i$, indexed modulo $k$. Their missing arrows are
$$P_i\to L_i,L_{i-1},\qquad L_i\to P_{i+4},P_{i+6};$$
all other distinct hub pairs are arrows. For each of $q$ outside vertices
$x$, choose a set $K_x$ of hubs subject to these conditions:

* $|K_x|\ge3$, and $K_x$ lies entirely in one of the two hub parts;
* a set in the $P$ part contains no two indices differing by $\pm2$;
  a set in the $L$ part contains no adjacent indices;
* the sets $K_x$ form an antichain: no one contains another.

Include every hub-to-outside arrow, and include $x\to u$ for precisely the
hubs $u\notin K_x$. Every subset of the arrows between distinct outside
vertices may then be included. Every resulting graph has universal delivery
within two messenger moves.

Writing $n=2k+q$ and $W=\sum_x|K_x|$, this gives every exact budget
$$A\le m\le A+q(q-1),\qquad A=2k(2k-3)+4kq-W.$$
At the upper endpoint the number of missing arrows is $4k+W$. The assertion
holds for every optional subset, not merely a specially chosen subset of
each size.

**Proof.** Let $F$ denote the missing graph inside the hubs. For a missing
pair $(s,t)$ and a pursuer at $c\ne s$, we seek a hub $u$ with arrows
$s\to u\to t$, with $u\ne c$ and no arrow $c\to u$. The messenger can
move to $u$, survive every pursuer response, and then reach $t$. The case
$c=t$ is included.

First suppose all three vertices are hubs. For a missing hub pair, the
set $D=F^+(s)\cup F^-(t)$ contains two points and two lines. If $s=P_i$,
the line indices are $i,i-1$ and the point indices are either $i,i+1$ or
$i-1,i$. A point pursuer has its entire missing row in $D$ only when it
is $s$; a line pursuer's point pair has difference two and cannot fit
inside the adjacent point pair. If $s=L_i$, the point indices are
$i+4,i+6$ and the line indices are either $i,i-2$ or $i,i+2$. The same
argument with the two parts exchanged applies. Thus $F^+(c)$ contains a
hub outside $D$, which is the desired intermediary.

Now consider the other nondirect configurations.

1. **Both endpoints outside.** If the pursuer is outside, choose
   $u\in K_c\setminus K_s$, which exists by incomparability. It is
   reachable from $s$, inaccessible from $c$, and reaches $t$. If the
   pursuer is a hub, its missing row consists of an adjacent line pair
   or a point pair of difference two. The restrictions on $K_s$ prevent
   that entire row from lying in $K_s$. A remaining member works.

2. **Source outside, recipient a hub.** Missingness means $t\in K_s$.
   For an outside pursuer whose code lies in the same part, choose
   $u\in K_c\setminus K_s$; that part is a clique, so $u\to t$.
   For an outside pursuer using the other part, $K_c$ is disjoint from
   $K_s$ and has at least three members. At most two are missing
   predecessors of $t$, so one of the others works. For a hub pursuer
   whose missing row lies in the part containing $t$, the code restriction
   leaves a member outside $K_s$, and the clique supplies the last arrow.
   For the other hub pursuer part, both missing neighbors are reachable
   from $s$. Their adjacent or difference-two pair cannot equal the
   opposite kind of pair $F^-(t)$, so at least one reaches $t$.

3. **Both endpoints hubs, pursuer outside.** The set $D$ above contains
   only two members in either part. Since $K_c$ has at least three
   members in one part, choose a member outside $D$.

A hub source reaches an outside recipient directly. All intermediaries
used in the proof are hubs, so optional arrows between outside vertices
cannot invalidate a witness. Counting the compulsory and optional arrows
gives the stated interval. $\square$

![Two incomparable missing-hub sets leave a hub that the source can reach but the pursuer cannot. Every hub reaches the outside recipient, completing a safe two-move delivery. The theorem separately handles recipients and pursuers inside the core.](figures/antichain-routing.pdf){width=90%}

**Equal-weight codes at every core parity.** For a cycle of length $t\ge3$,
write $C(t,0)=1$, put $C(t,j)=0$ if $j<0$ or $2j>t$, and otherwise put
$$C(t,j)=\frac{t}{t-j}\binom{t-j}{j}.$$
This counts its independent $j$-sets: for $j\ge1$, distinguish a selected
vertex and distribute the unselected vertices among the $j$ nonempty
gaps. Dividing by the $j$ choices of distinguished selected vertex gives
$\frac{t}{j}\binom{t-j-1}{j-1}$, the same expression.

For every $k\ge5$ and $3\le r\le\lfloor k/2\rfloor$, the total number
of permitted size-$r$ codes in the two hub parts is
$$Q(k,r)=C(k,r)+
\begin{cases}
C(k,r),&k\text{ odd},\\
\displaystyle\sum_{j=0}^{r}C(k/2,j)C(k/2,r-j),&k\text{ even}.
\end{cases}$$
Indeed, the forbidden graph in the line part is a $k$-cycle. For odd
$k$, multiplication by two identifies this cycle with the forbidden
difference-two graph in the point part. For even $k$, the even and odd
indices instead form two disjoint cycles of length $k/2$. Choosing $j$
indices in one and $r-j$ in the other gives the displayed convolution.
The two parts have disjoint hub labels, so their counts add. All distinct
size-$r$ codes are incomparable.

Consequently every $q\le Q(k,r)$ supplies the explicit interval in
Theorem 59, with
$$A=(4k-r)n-2k(2k+3-r),\qquad L-A-q(q-1)=2n+(r-2)q.$$
List independent sets by taking increasing indices with at least one
unselected index between consecutive selections and across the cyclic
boundary. For even cores, list the two component choices in increasing
order of $j$ and then in lexicographic order within each component. List
line codes first, then point codes, and take the first $q$. This gives a
concrete rule from $(k,r,q)$ without pursuit-game search. It includes all
previous odd-core ranges. The implementation and independent counting and
asymmetric witness checks are `src/core_code_all_parities.py` and
`src/core_code_all_parities_check.py`; the original odd-core implementation
and its earlier receipts remain available unchanged.

For example, $Q(10,3)=100$: the line ten-cycle gives 50 triples, and the
two point five-cycles give $2\cdot5\cdot5=50$. Thus for every
$20\le n\le120$ there is a direct attaining graph at every budget
$$37n-400\le m\le n(n-1)-(3n-20).$$
At $n=114$, the interval is $3818\le m\le12560$. It overlaps the saved
circle interval ending at 3876 and the dense bridge beginning at 12540.
This fills the formerly uncovered middle interval $3877\le m\le4097$.
The all-parity family is an ordinary consequence of Theorem 59; finite
checks support the implementation and do not replace the counting proof.

**A fixed mixed-code refinement at order 105.** The saved list in
`research/core-code-third-mixed-105.json` contains 85 permitted, pairwise
incomparable codes on the $k=10$ core. Their total size is $W=268$.
Theorem 59 therefore gives every budget $3472\le m\le10612$, with
arbitrary optional subsets and two-move delivery. The literal list is
part of the construction; no optimization is run to instantiate it.
The independent checker verifies the code conditions and all 774,592
source--recipient--pursuer witnesses. Its discovery by a bounded integer
optimization supplies no upper bound on $M$ and is not used in the proof.

The separate minimum-arrow problem under a two-move deadline, including the
asymptotic consequence of these codes, is treated in the
[delivery-time companion](https://angelraychev.com/cop-prisoner/delivery-time/#antichain-two-move-sparsity).
The exact code budgets and main-interval overlap remain here.

# A wider protected circle and the main-interval overlap

Here we use the protected differences of Theorem 38 without changing its
strategy. Let $h$ be an allowed odd step, $a=(h-1)/2$, and
$$A_0=\{0,1,a,2a+1\},\qquad
D=\{\pm(a-1),\pm(a+1),\pm2a\}.$$
Put $p=3a-1$ and
$$J=\{jp+t:0\le j<\lfloor n/p\rfloor,\ 0\le t<a-1\}.$$
No difference between two members of $J$ belongs to $D$: within a run it
has magnitude at most $a-2$, while between runs, including the cyclic gap,
the shortest gap is at least $2a+1$. For any translate $J+v$, remove all
members of $A_0\cup(A_0+D)$ and then adjoin $A_0$. Every protected difference
still has exactly its original representation. Thus the result is an
allowed envelope in Theorem 38. The excluded set has at most 19 elements,
by expanding the four translates of the six differences. Averaging over
$v$ gives an envelope of size at least
$$4+\left\lceil\frac{|J|(n-19)}{n}\right\rceil.$$
One may then apply the greedy extension from Theorem 38. In particular the
old guarantee $|A|\ge\lceil n/7\rceil$ is preserved. Searching the $n$
translations is explicit and takes polynomial time.

**Additional finite circles and the threshold 106.** The literal protected
sets in `research/core-code-third-circle-envelopes.json` supply circle
envelopes at orders 100 through 111. Each of the six protected differences
has exactly its prescribed representation, which is the hypothesis of
Theorem 38. Select optional arrows in row order to obtain every budget
from $3n$ through $n(|A|-1)$.

At orders 106 through 111 these saved endpoints reach the base $37n-400$
of the $k=10,r=3$ code interval. The earlier saved circles do the same at
112 through 114. The code interval ends at $n(n-1)-(3n-20)$, overlapping
the dense bridge beginning at $n(n-1)-3n$. The finite sparse envelopes in
the packed-hole chapter cover $2n$ through $3n$ at each of these nine
orders, including the explicitly repaired order-109 envelope. Thus the
whole main interval is covered for every $n\ge106$: these finite recipes
cover 106 through 114, and the following ordinary proof supplies the
unchanged infinite tail. The saved inputs and all overlap inequalities
are independently checked; finite game success is not extrapolated to
an infinite family.

**Main-interval overlap certificate.** This protected-circle construction,
Theorem 59, and the dense constructions cover every budget from $3n$ to
$n(n-3)$ for every $n\ge115$. Combined with Theorem 52, they prove the
improved order threshold in Theorem 44. Here are the complete finite and
unbounded parts of the overlap argument.

For $115\le n\le390$, the finite parameter certificate supplies a valid
circle step and translation and valid code parameters whose base $A$ is
at most the circle's maximum budget. It also checks that the code's
terminal missing count is within the dense envelope of Theorem 48.
These are integer inequalities and protected-difference checks, not
extrapolations from small pursuit games. The records and an independent
replay are listed below. Two orders use the following refinements:

* At $n=116$, use $k=11$, two allowed codes of size five, and 92 allowed
  codes of size four contained in neither larger code. The two larger
  codes exclude at most ten of the 110 available size-four codes, so
  there are enough. Their weight is $W=378$, giving base budget 4176,
  exactly the verified protected-circle endpoint.
* At $n=117$, use $a=20$, $h=41$, and
  $A_0\cup[41,59]\cup[100,115]=\{0,1,20\}\cup[41,59]\cup[100,115]$.
  This has 38 members and each protected ordered difference occurs
  exactly once. The circle reaches 4329 arrows, above the code base 4218.

For $391\le n\le480$, choose $k=15,r=4$; for $481\le n\le699$, choose
$k=17,r=5$. Their code bases are $56n-870$ and $63n-1088$, respectively.
Each is at most $T=n(\lceil n/7\rceil-1)$: replace the ceiling by $n/7$,
check the left endpoint, and observe that the quadratic difference
increases thereafter. The code capacities are 900 and 2244, and the
terminal missing counts $4n-60$ and $5n-102$ are within Theorem 48.

For $n\ge700$, take $r=3$ and an odd $k$ with
$$(6n)^{1/3}+5\le k<(6n)^{1/3}+7.$$
Then $C(k,3)=k(k-4)(k-5)/6\ge n$, the core fits inside $n$ vertices, and
$$A<4kn<4n((6n)^{1/3}+7)\le n^2/7-n\le T.$$
Indeed, $n/7\ge4(6n)^{1/3}+29$ holds at 700, where $(6n)^{1/3}<17$,
and its difference is increasing thereafter. The terminal missing count
$3n-2k$ is between $2n$ and $3n$, so Theorem 58 completes the interval.
This exhausts all orders in the assertion.

**Verification and scope.** The ordinary antichain proof was independently
reviewed case by case. The executable constructor is
`src/core_code_composition.py`; direct asymmetric witness tests are recorded
in `research/core-code-composition-checks.json`. The finite overlap checks
are in `research/routing-defect-phase2-code-overlap-checks.json`, with the
mixed-size 116 and explicit 117 constructions in
`research/routing-defect-phase2-mixed-code-checks.json`. The mixed 116 graph
alone passes 1,053,860 source--recipient--pursuer witness checks. The general
antichain existence, cycle counts, and numerical overlap are ordinary
proofs. `RobustTwoMove.lean` formalizes the semantic implication from supplied
asymmetric witnesses to actual delivery, not the combinatorial construction
of those witnesses or this entire theorem.

The complete main-interval constructor is available as
`src/main_interval_composed.py`. Given $n\ge106$ and an admissible $m$,
it selects one of the proved envelopes and outputs the exact arrow list.
Its boundary checks exercise all five branches and independently replay
every finite parameter certificate; see
`research/main-interval-composed-checks.json` for the original infinite-tail
implementation and the separate finite-extension receipt for orders 106--114. This executable selection
uses the ordinary overlap proof, not a new search for each graph.

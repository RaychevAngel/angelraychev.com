# Historical pre-completion snapshot

This records the superseded101-case checkpoint. Use the current root documents for status.

# Exact values and explicit attaining constructions

This is the active scope of the extremal classification project. It supersedes the open-ended priority lists in historical research checkpoints. The current manuscript and `HANDOFF.md` remain the authority for proved mathematical statements.

For every integer `n >= 1` and `0 <= m <= n(n-1)`, determine `M(n,m)`: the largest number of guaranteed indirect ordered source–recipient pairs among simple loopless directed graphs with exactly those vertex and arrow counts. Provide an explicit construction attaining the value at every parameter pair. Opposite arrows are allowed. Both players may wait; the messenger moves first; receipt at the recipient precedes collision, including when the cop occupies the recipient. The guarantee quantifies over every legal initial cop position and history-dependent cop strategy. Infinite evasion is not delivery.

The programme has two independent obligations at each `(n,m)`: prove the exact value, and provide a concrete adjacency rule or clearly specified composition procedure whose parameters are determined from `(n,m)`. "Attaining" describes optimality; it does not describe how the graph is obtained. A generic graph search, a bare existence argument, or the availability of deterministic derandomization does not by itself meet the explicit-construction requirement. Certified listed graphs are acceptable for genuine finite exceptions.

A direct procedure may use explicit integer inequalities, fixed finite parameter records, lexicographic listing of a specified combinatorial family, or a greedy rule with proved progress and no backtracking. These are part of a concrete graph recipe. They differ from searching arbitrary graphs until a solver accepts one, or fixing arbitrary adjacency bits by conditional expectation. Classify the actual procedure rather than its historical discovery method: a graph originally found by search can be an acceptable saved finite exception.

Completion requires both a matching upper proof and such an explicit attaining recipe for every pair, with proved domain coverage and terminating delivery. Closing the numerical gaps alone is insufficient. A graph generator, if provided, must expose its parameters and its dependencies on saved data; having runnable code is not a substitute for the ordinary argument. One need not classify every extremizer or use one universal formula. Preserve every earlier theorem and stronger subset/time guarantee even if another family supplies the explicit graph needed for `(n,m)`.

## Numerical reduction and separate construction audit

For `m > 0`, at most `2m` vertices are nonisolated. Adding isolated vertices preserves the count, so

`M(n,m) = M(min(n,2m),m)`.

The zero-arrow case is identically zero. The current combined classification settles every `n >= 11, 22 <= m <= n(n-1)`. At order eleven the first three values are `M(11,22)=79`, `M(11,23)=78`, and `M(11,24)=79`; every budget from 25 through 88 attains its missing-pair upper bound. The dense range is determined at every order, and the uniform sharp dense staircase starts at eleven. All budgets at orders one through seven are exact.

The full main-interval conclusion remains `M(n,m)=n(n-1)-m` for every `n>=12` and `2n<=m<=n(n-3)`. Its sharp uniform order threshold follows from the failure at `(11,22)`, whose value is 79 rather than 88. The remaining main-interval gaps have only orders eight through ten. In the current incorporated ledger there are 32 such representatives: 19 below `3n` and 13 at or above `3n`. Together with 69 sparse representatives and no dense representatives, this gives 101 unresolved values. These are the indexed unresolved domains, not claims that each case needs an unrelated proof.

For budgets 12 through 21, the comparison-witness support theorem improves the host cutoffs to
`B=(12,13,16,18,15,18,15,18,11,15)` in budget order, with
`M(n,m)=M(min(n,B_m),m)`. Thus every remaining unknown numerical value has a representative of order at most eighteen. Larger hosts repeat one of these values; they are not additional independent gaps. The ledger retains its larger audited box through order 114 for historical comparison. In particular, `M(n,20)=M(11,20)` for every `n>=11`, while its value remains bounded by 53 and 57. The reviewed tiny cases give `M(8,12)=M(9,12)=9` and `M(8,13)=11`, hence `M_E(13)>=11`; the further endpoint is `M(8,39)=14`. These counts and cutoffs describe the currently incorporated evidence; newly reviewed improvements are included only when its source-pinned registry is refreshed.

This reduction concerns numerical values. It does not automatically reduce the explicit-construction objective to finitely many cases: an infinite known-value family could still lack direct recipes. The separate audit in `research/EXPLICIT_CONSTRUCTIONS.md` checks that obligation against the actual construction sources and has no identified known-value construction-only gap. That zero is an independent audit result, not a consequence of support concentration or numerical equality. Attainers for the support-reduced budgets lift by adding isolates, and the new finite exceptions have literal adjacency and checked ranks.

This is a containing box for unknown values, not the unresolved set. The explicit complement after incorporating the current numerical theorems and certified finite evidence is in `publication/classification-coverage.json`. `research/CLASSIFICATION_GAPS.md` explains it. The ledger distinguishes an equality proved by matching a lower witness with an upper bound from an unclosed interval. Its source list defines the coverage claim: it does not assert that every further deduction from every retained source has already been discovered.

## What remains in the main argument

The support reductions, camping obstructions, protected routing, finite-state strategy composition, robustness under prescribed optional arrows, antichain codes, and dense complement constructions remain proof tools. Stronger conclusions already obtained—such as arbitrary-subset robustness or the functional-complement characterization—remain stated accurately. `M_V` and `M_E` are consequences and useful projections of the joint classification. They do not create extra requirements to classify optimizing graphs.

The current construction rule should retain delivery bounds that are already proved. Exact optimization of delivery time `T_*`, a universal logarithmic-time sparse construction, exact `q_2`, its leading constant, and all intermediate time–arrow tradeoffs are parked in the specialized companion. The unfinished eight-type terminal interface is not an obstacle to the already proved extremal counts and is not a prerequisite for completing this scope.

## Acceptance evidence

For an exact case, retain its matching upper theorem or complete finite exclusion, the graph recipe or literal adjacency data, and the ordinary strategy proof or complete rank certificate. A theorem about all allowed optional subsets must establish that quantifier. A local arena proof must establish faithful projection and finite termination in the actual graph. Finite success at selected circumferences cannot replace an all-order argument.

Separate ordinary proof, finite computer-assisted proof, and the precise Lean subset. A historical search maximum is a candidate lower witness until the fixed graph is checked; an incomplete search is never an upper bound. Source and certificate hashes identify evidence versions, not mathematical truth by themselves. Do not rewrite old receipts to make an editorially changed source appear unchanged.

The next work should close an unknown-value gap, supply an explicit recipe on a listed construction gap (even where a value is known), or simplify the construction and proof rule within this scope. It should have a bounded check capable of rejecting the proposed route. The assessments in `CLASSIFICATION_GAPS.md` and `EXPLICIT_CONSTRUCTIONS.md` propose the next bounded targets. Angel subsequently authorized execution of the five classification priorities. New research remains inside this scope; an interesting structural or timing question is not automatically an added objective.

## Parked structural programme

A future structural object is `D(G)`, the set of missing nonloop ordered pairs whose delivery is guaranteed against every permitted initial cop. Thus `I(G)=|D(G)|`. A useful structural account may require target-indexed winning positions `(source,cop)` before quantifying away the cop; no simple local characterization is assumed. General characterization of this set is parked. A target-dependent obstruction or composition lemma may still be developed inside the main project when it closes a named classification gap.

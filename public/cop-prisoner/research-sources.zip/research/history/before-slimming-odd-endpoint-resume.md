# The odd endpoint and completion of its degree defect

The odd arc-budget equality theorem prescribes a particularly small defect:
on $n=k+1$ vertices there is one vertex $u$ of outdegree one, a different
vertex $v$ of indegree one, all other indicated degrees are two, and the arc
$u\to v$ is absent. The candidate extremal value is
$$M_E(2n-1)=(n-2)(n-3).$$
The equality theorem reduces attainment to guaranteeing every missing pair
whose source differs from $u$ and whose recipient differs from $v$. It does
not make arbitrary deletion from, or completion to, a two-regular graph
preserve the relevant guarantees.

## Two necessary structural properties

**Lemma.** Every odd-extremal graph with the preceding degree pattern is
strongly connected. Moreover, for each vertex $c$, the graph with $c$
deleted has a directed path from every $s\notin\{u,c\}$ to every
$t\notin\{v,c\}$.

**Proof.** Each such ordered pair with $s\ne t$ is either a direct arc or
a guaranteed missing pair. Against a pursuer initially at $c$ and waiting
there, any successful delivery path avoids $c$ internally. Since its
endpoints differ from $c$, it gives the asserted path in the deleted graph.

To prove strong connectivity without deleting a vertex, all vertices
different from $u$ already reach all vertices different from $v$. The
unique predecessor $b$ of $v$ is different from $u$, because $u\to v$ is
absent. Thus all vertices other than $u$ reach $v$ by first reaching $b$.
The unique successor $a$ of $u$ differs from $u$, and $u$ reaches every
vertex by first going to $a$. $\square$

These are necessary conditions, not substitutes for the full game: the
pursuer can move, so ordinary connectivity and stationary separators do
not establish an attaining strategy.

## Completing an odd extremizer can fail

**Proposition (finite certified example).** There is a graph $G$ on 19
vertices with 37 arcs attaining $I(G)=272=M_E(37)$ such that adding the
unique degree-completing arc yields a two-in/two-out graph which is not
universally winning. Its completed indirect count is 276, whereas a
universally winning two-regular graph on 19 vertices would have 304.

The example has vertex set $\{0,\ldots,18\}$ and the following outgoing
neighbors:

| Vertex | Outgoing neighbors | Vertex | Outgoing neighbors |
|--:|:--|--:|:--|
| 0 | 5, 12 | 10 | 2, 17 |
| 1 | 15, 10 | 11 | 1, 6 |
| 2 | 7, 0 | 12 | 3, 8 |
| 3 | 1, 18 | 13 | 4, 5 |
| 4 | 15 | 14 | 4, 12 |
| 5 | 11, 9 | 15 | 0, 16 |
| 6 | 8, 13 | 16 | 7, 9 |
| 7 | 13, 17 | 17 | 14, 11 |
| 8 | 10, 16 | 18 | 2, 6 |
| 9 | 3, 14 | | |

Its exceptional vertices are $u=4$ and $v=18$. The finite actual-game
certificate verifies every guarantee required by odd equality and the
count 272. The upper bound follows from Theorem 7 with $k=18$.

There is also a short ordinary obstruction after adding $4\to18$. Fix
recipient zero and start the messenger at 1, the pursuer at 4. Define
$$
S_4=\{1,3,5,6,7,8,9,11,12,13,14,16,17\},\qquad
S_{13}=\{6,11,12,14\}.
$$
The following four classes of messenger-turn states form a pursuer trap:
$$
(s,4)\ (s\in S_4),\qquad (10,18),\qquad (17,6),\qquad
(s,13)\ (s\in S_{13}).
$$
They contain the initial state and exclude every state where the messenger
has reached zero. The pursuer acts as follows, in terms of the messenger's
new vertex $x$:

| Current pursuer | Response |
|--:|:--|
| 4 | If $x=10$, move to 18. If $x=15$ or $18$, capture at $x$. Otherwise wait at 4. |
| 18 | If $x=2$, capture there. If $x=17$, move to 6. If $x=10$, wait. |
| 6 | If $x=11$ or $14$, move to 13. If $x=17$, wait. |
| 13 | If $x\in\{1,3,4,8\}$, move to 4, capturing if $x=4$. Otherwise wait at 13. |

An immediate collision with the current pursuer already loses. Direct
inspection of the outgoing-neighbor table shows that every other possible
move either permits the stated capture or returns to one of the four trap
classes. Waiting is included. Since infinite play without receipt loses,
the messenger cannot deliver to zero. This explicitly identifies how the
new arc helps the pursuer: the transition from cop position 4 to 18 after
the messenger moves from 1 to 10 was unavailable before completion.

`src/odd_endpoint_completion.py` contains the fixed graph and runs both
independent game solvers, checking every winning rank and every losing
closure obligation. `research/odd-endpoint-completion-certificate.json`
stores the complete finite certificates for the original and completed
graphs. The ordinary trap proves nonuniversality without computation;
the original graph's attainment and the completed count 276 use the
verified finite certificates. This example is not presently embedded in
Lean. The subsequent construction settles the odd endpoint at every
sufficiently large budget.

## A useful degree-preserving search operation

Given a two-in/two-out graph, split one vertex $w$ into vertices $v,u$.
Assign one old incoming and one old outgoing arc to each new vertex, then
add $v\to u$. This adds one vertex and one arc, giving exactly the odd
equality degree pattern: $v$ has indegree one and outdegree two, while $u$
has indegree two and outdegree one. The forbidden opposite arc $u\to v$
is absent because the original graph was loopless.

This operation supplies a structured family to investigate, but it is not
a preservation theorem. A split of the 20-vertex five-type graph attains
$M_E(41)=342$, while all twenty canonical splits of its 30-vertex member
fail to attain the corresponding odd bound. Likewise, changing the two
horizontal lane speeds to three produces attaining single-arc deletions
at 40 and 50 vertices but failures at neighboring and larger orders.
These counterchecks prevent promoting isolated success to a uniform
construction. A different six-type family supplies the following uniform
positive result.

## A proved infinite family attaining the odd bound

**Theorem (with finite local certificates).** For every integer $q\ge15$,
$$M_E(12q-1)=(6q-2)(6q-3).$$
An explicit attaining graph has $n=6q$ vertices and $2n-1$ arcs. Every
eligible pair can be guaranteed within $14q+12$ messenger moves.

**Proof.** Use vertices $(i,j)$, with $i$ modulo $q$ and $0\le j\le5$.
The first permutation follows the six types in order and then advances
one column:
$$\alpha(i,j)=(i,j+1)\ (j<5),\qquad \alpha(i,5)=(i+1,0).$$
The second permutation is
$$
\begin{aligned}
\beta(i,0)&=(i-1,0),&\beta(i,1)&=(i-1,2),\\
\beta(i,2)&=(i+1,5),&\beta(i,3)&=(i+1,1),\\
\beta(i,4)&=(i-1,4),&\beta(i,5)&=(i+1,3).
\end{aligned}
$$
These permutations have distinct nonloop images at every vertex. Delete
the single arc $u\to v$, where $u=(0,0)$ and $v=(0,1)$. The graph now
has the exact odd equality degree pattern. We must guarantee every pair
whose source differs from $u$ and whose recipient differs from $v$.

Construct a local arena with messenger columns $[-4,4]$, pursuer columns
$[-6,6]$, and a pursuer outside state $\Omega$. The messenger may use
only moves remaining in its represented columns. The pursuer may leave
to $\Omega$, wait there, and re-enter at any vertex in columns
$-6,-5,5,6$. Include both the unchanged arena and, for each
$h\in\{-6,\ldots,6\}$, the arena with the translated arc
$(h,0)\to(h,1)$ deleted.

In every such arena the certificates prove two kinds of statement:

- From each vertex of column $-1$ other than the degree-one source, reach
  some vertex of column zero other than that source safely, at the
  beginning of a messenger turn, in at most 14 moves.
- From each vertex of column $-2$ other than the degree-one source,
  deliver to each recipient in column zero other than the degree-one
  recipient, in at most 26 moves.

All legal initial pursuer positions, including $\Omega$, are quantified.
Safe transfer goals exclude collision and are seeded only on messenger
turns; delivery goals retain immediate terminal receipt. Two independent
implementations check the full 97 objectives, all 44,850 required initial
states, and every winning-rank and losing-closure condition. These are
finite proof certificates for the displayed local statements.

For $q\ge15$, the thirteen pursuer columns are distinct and at least two
columns remain outside. Every actual move changes its column by at most
one, so an outside pursuer can first re-enter only at a permitted boundary
column. No represented move can jump across the outside gap. The actual
game therefore projects into this stronger local arena. A deletion in
the represented columns gives one of the listed translated modules;
otherwise the module is unchanged.

Fix an eligible recipient. Repeated safe transfers advance the messenger
one column at a time until it reaches the column two places before the
recipient. At most $q-1$ transfers are needed. Each transfer avoids the
exceptional source even at its final state, so the next module's initial
requirement continues to hold. The delivery module then applies. This
proves finite delivery in at most $14(q-1)+26=14q+12$ moves.

Finally, there are $(n-1)^2$ pairs with an eligible source and recipient.
Exactly $n-2$ are diagonal. The unique arc leaving $u$ and the unique arc
entering $v$ are distinct because $u\to v$ is absent, so precisely
$(2n-1)-2=2n-3$ arcs belong to this rectangle. Hence the number of eligible
missing pairs is
$$
(n-1)^2-(n-2)-(2n-3)=(n-2)(n-3).
$$
All are guaranteed, and the odd arc-budget upper bound proves equality.
$\square$

The primary proof data are generated by `src/odd_endpoint_certificates.py`
and stored in `research/odd-endpoint-uniform-certificates.json.gz`. The
independent checker `src/six_type_independent_odd.py` constructs its own
graph and explicit alternating arena; its full ranks are in
`research/six-type-independent-odd-certificates.json.gz`, with a summary
and independent review in the adjacent files. The projection and finite
composition argument are ordinary proofs. This result is not currently
formalized in Lean. The next theorem removes the congruence restriction.

## Every sufficiently large odd budget

**Theorem 45 (the odd endpoint).** For every integer $n\ge145$,
$$
M_E(2n-1)=(n-2)(n-3).
$$
Equivalently, for every odd $m\ge289$,
$$
M_E(m)=\frac{(m-3)(m-5)}4.
$$
An explicit attaining graph has $n$ vertices. Every pair required for
attainment has a delivery strategy using at most
$34\lceil n/6\rceil+27$ messenger moves. The construction and its
composition proof are ordinary finite arguments; the bounded local
strategy lemmas are supplied by independently verified finite
certificates.

**Proof.** Put $q=\lceil n/6\rceil$ and $r=6q-n$, so $q\ge25$ and
$0\le r\le5$. We first describe a graph on the surviving vertices of
$(\mathbb Z/q\mathbb Z)\times\{0,\ldots,5\}$. Its two initial
permutations are
$$
\alpha(i,j)=
\begin{cases}(i,j+1)&j<5,\\(i+1,0)&j=5,\end{cases}
\qquad
\beta(i,j)=(i+e_j,\sigma(j)).
$$
Use the following four choices of $(\sigma,e)$, whose entries are in
type order $0,1,\ldots,5$:

| Pattern | $\sigma$ | $e$ |
|:--|:--|:--|
| $A$ | $(0,2,5,1,4,3)$ | $(-1,-1,1,1,-1,1)$ |
| $B$ | $(0,5,1,4,3,2)$ | $(-1,1,1,-1,-1,1)$ |
| $C$ | $(3,5,0,2,4,1)$ | $(-1,1,-1,-1,-1,0)$ |
| $D$ | $(4,1,5,2,0,3)$ | $(-1,-1,1,1,-1,1)$ |

For a set $H$ of deleted vertices, smooth each permutation separately:
from a surviving vertex, follow that permutation until first reaching
another surviving vertex, and use the resulting arc. Finally delete
one specified arc of the smoothed graph. The complete choices are:

| $r$ | Pattern | Tail $u$ of deleted arc | Which arc | Direction $d$ |
|--:|:--:|:--|:--:|--:|
| 0 | $A$ | $(0,0)$ | $\alpha$ | $1$ |
| 1 | $B$ | $(1,4)$ | $\beta$ | $1$ |
| 2 | $C$ | $(0,5)$ | $\beta$ | $-1$ |
| 3 | $D$ | $(0,1)$ | $\alpha$ | $1$ |
| 4 | $D$ | $(0,1)$ | $\alpha$ | $1$ |
| 5 | $C$ | $(0,5)$ | $\beta$ | $-1$ |

The corresponding deleted vertex sets are:

- $r=0$: $H=\varnothing$.
- $r=1$: $H=\{(0,3)\}$.
- $r=2$: $H=\{(0,0),(0,1)\}$.
- $r=3$: $H=\{(0,2),(0,3),(0,4)\}$.
- $r=4$: $H=\{(-1,4),(0,2),(0,3),(0,4)\}$.
- $r=5$: $H=\{(0,0),(0,1),(1,0),(1,1),(1,5)\}$.

Write $v$ for the head of the final deleted arc. Every type cycle of
each displayed $\sigma$ has a nonzero total displacement $e$ with
$|e|$ no greater than its length $\ell$. Its cyclic lift has length
$\ell q/\gcd(q,e)\ge q$, whereas $\alpha$ is a cycle of length $6q$.
At most five vertices are removed, so no permutation cycle disappears.
The smoothing operation therefore preserves the permutation property
on surviving vertices. Inspection
of these six fixed patterns shows that the two smoothed images at each
surviving vertex are distinct, are not the vertex itself, and change
the column by at most two. The changes to outgoing arcs are confined
to tails in columns $[-2,2]$; removed vertices lie in columns $[-1,1]$.
These are finite checks on the displayed tables, independent of $q$.
Because $q\ge25$, reducing these local coordinates modulo $q$ introduces
neither a coincidence nor a loop. Thus the final graph has $n=6q-r$
vertices, $2n-1$ arcs, precisely one outdegree-one vertex $u$, precisely
one indegree-one vertex $v$, and all other corresponding degrees two.
Moreover $u\ne v$ and $u\to v$ is absent.

We now specify the finite strategy lemmas and explain exactly how they
apply to arbitrary $q$. Work first in the infinite column strip. In a
local arena the messenger is restricted to columns $[-5,5]$; the pursuer
has columns $[-7,7]$ together with an outside state $\Omega$. Inside
these windows both players have their actual graph moves and may wait.
A pursuer move leaving its window goes to $\Omega$, from which the
pursuer may wait or re-enter at any surviving vertex in columns
$-7,-6,6,7$. Include the unchanged arena and every translation of the
finite defect whose anchor belongs to $\{-10,\ldots,10\}$.

For $r\le4$, the certificates prove the following statements for every
such arena, every admissible messenger vertex in the stated source
column, and every initial pursuer position different from that vertex,
including $\Omega$:

- **Safe transfer:** from column $-d$, reach a surviving vertex of column
  zero different from $u$, at the start of a messenger turn.
- **Delivery:** from column $-2d$, deliver to any surviving recipient
  in column zero different from $v$.

In both statements the starting messenger vertex must differ from $u$.
For $r=5$, where $d=-1$, safe transfer instead permits either column
zero or column $-1$ as its final column, and delivery is guaranteed
from either column $2$ or column $3$. The exclusion of $u$ at the
starting and final transfer states remains unchanged. Safe transfer
goals exclude collision and are terminal only at the start of a
messenger turn. Delivery goals give receipt priority over collision,
exactly as in the original game.

The maximum certified move counts are:

| $r$ | Safe transfer | Delivery |
|--:|--:|--:|
| 0 | 14 | 26 |
| 1 | 9 | 22 |
| 2 | 17 | 26 |
| 3 | 34 | 23 |
| 4 | 28 | 27 |
| 5 | 9 | 26 |

The primary checker verifies all 903 local objectives with the same
windows for all six rows. A separately written checker verifies the
five nonempty deletion patterns in 750 objectives, covering 425,176
required initial states and 7,590,092 explicit alternating states.
The unchanged-vertex pattern has its earlier independent 97-objective
certificate. Every certificate includes the full attractor ranks and
checks each existential messenger move and every universal pursuer
response. Thus the displayed local statements are finite lemmas, not
inferences from testing increasing ring lengths.

For the projection to a cyclic graph, represent the fifteen pursuer
columns by their consecutive integer lifts. All actual moves have
column jump at most two. An outside pursuer can therefore first enter
only one of the four boundary columns allowed from $\Omega$. Since
$q\ge25$, the outside gap has at least ten columns, so no move can
cross that gap between the two represented ends. Messenger positions
remain in their eleven distinct represented columns, and $\Omega$
cannot conceal a collision there. Consequently each actual pursuer
move has a permitted projected response in the stronger local arena.

The only defect anchors which can affect a represented outgoing move
are within nine columns of the arena center, since changed tails lie
within two columns of their anchor. Vertex deletions and the two
degree exceptions are covered by the same bound. Testing anchors
from $-10$ to $10$ therefore covers every relevant configuration.
This interval has length 21, less than $q$, so at most one periodic
copy of the defect can occur in it. If no copy occurs, the unchanged
arena applies. These observations prove the projection for every
cyclic position of the local window.

Fix a source other than $u$ and a recipient other than $v$. For
$r\le4$, repeatedly apply safe transfer in direction $d$ until the
messenger is two columns before the recipient. At most $q-1$
transfers are needed, after which the delivery module applies.
Each transfer ends at a messenger turn away from $u$, so it satisfies
its next module's initial requirements regardless of the pursuer's
history.

For $r=5$, measure the messenger's column distance to the recipient
in the leftward direction by an integer $a\in\{0,\ldots,q-1\}$.
Delivery applies as soon as $a\in\{2,3\}$. Otherwise a transfer
decreases this distance by one or two modulo $q$. If $a\ge4$, this
cannot pass below 2 without first reaching 2 or 3. If initially
$a=0$ or 1, at most two transfers either reach those distances or
wrap to $q-1$ or $q-2$, after which the preceding decreasing argument
applies. In every case at most $q$ transfers suffice. This proves
finite delivery, uniformly bounded by $34q+27$ moves.

Every missing pair with source different from $u$ and recipient
different from $v$ is therefore guaranteed. Their number is
$(n-1)^2-(n-2)-(2n-3)=(n-2)(n-3)$, as in the preceding theorem.
The odd arc-budget upper bound proves equality. $\square$

The generator `src/odd_endpoint_all_residues.py` supplies the six graph
families and the complete primary proof data in
`research/odd-endpoint-all-residues-certificates.json.gz`.
`src/six_type_independent_odd_residues.py` independently constructs
the smoothed graphs and explicit alternating games; its full proof
data and summary are
`research/six-type-independent-odd-residues-certificates.json.gz` and
`research/six-type-independent-odd-residues-summary.json`.
The original six-type pattern is additionally checked by
`src/six_type_independent_odd.py`. These certificates and the ordinary
projection argument establish an explicit all-order result; this new
endpoint theorem has not yet been formalized in Lean.

**Corollary 45.1 (the odd endpoint from 25 arcs).** For every $n\ge13$,
$$
M(n,2n-1)=M_E(2n-1)=(n-2)(n-3).
$$
Consequently the exact odd arc-only extremum is
$$M_E(m)=\frac{(m-3)(m-5)}4\qquad(m\ge25\text{ odd}).$$

**Proof.** Theorem 45 covers $n\ge145$. For every one of the remaining
132 integers $13\le n\le144$, the supplementary data give a fixed
simple graph with $2n-1$ arcs, one outdegree-one vertex $u$, one different
indegree-one vertex $v$, all other corresponding degrees two, and
$u\to v$ absent. The displayed six-type residue families supply most
of these graphs. Deleting one arc from independently verified finite
two-regular examples supplies the remaining orders from 19 upward.
Six further fixed witnesses cover orders 13 through 18.

For every recipient other than $v$, the finite certificates specify
an integer rank for every explicit messenger-turn and pursuer-turn
state. Terminal receipt has rank zero, nonterminal collision has rank
$-1$, and every other nonnegative messenger rank has a legal successor
of smaller nonnegative rank. Every legal successor of a nonnegative
pursuer rank has smaller nonnegative rank. The direct checker verifies
these conditions against the original graph, together with the entire
complementary losing closure. Every initial messenger state whose
source differs from $u$ and whose pursuer position differs from the
source has nonnegative rank. Strict rank descent therefore forces
finite delivery from each required state against every pursuer policy.
This proves all required guarantees for each listed graph.

The full check contains 10,236 recipient objectives and 215,967,810
explicit alternating states. The same degree count as in Theorem 45
then gives $(n-2)(n-3)$ guaranteed missing pairs. The arc-only upper
bound applies to all support sizes, and hence also to the fixed support
size $n$. This proves both equalities. $\square$

The 126 graphs at orders 19 through 144 are in
`research/odd-endpoint-finite-bridge-graphs.json`.
Their complete ranks are in the streamable archive
`research/odd-endpoint-finite-bridge-certificates.jsonl.gz`, with source
hashes and a full numerical summary in
`research/odd-endpoint-finite-bridge-verification.json`.
The producer `src/odd_endpoint_finite_certify.cpp` uses an explicit
alternating-game attractor. The separate direct verifier
`src/odd_endpoint_finite_verify.py` checks the original legal moves;
it does not rerun or trust the producer's queue logic. Its accelerated
array checks have an equivalent standard-library scalar mode.
Scalar replay of all objectives at orders 19 through 24 also passes,
and the earlier two independent game algorithms agree with selected
saved certificates at orders 19, 28 and 144. The complete direct rank
checks, rather than these additional sample comparisons, prove the
finite bridge. The six smaller witnesses are fully checked by both
original game algorithms and the direct transition verifier in
`src/odd_endpoint_small_verify.py`; their complete proof data and
summary are `research/odd-endpoint-small-certificates.json.gz` and
`research/odd-endpoint-small-verification.json`. These finite
certificates have not yet been imported into Lean.

**Proposition (small odd exceptions; exhaustive finite check).** For
$6\le k\le11$, the general odd upper bound is not attained:
$$M_E(2k+1)\le k(k-3)+1.$$
In particular, $M_E(23)\le89$.

**Proof.** Equality in the upper bound $k(k-3)+2$ would, by the equality
characterization, have precisely $n=k+1$ nonisolated vertices, one
outdegree-one vertex $u$, one distinct indegree-one vertex $v$, all
other corresponding degrees two, and $u\to v$ absent. Add this missing
arc. The resulting two-in/two-out digraph is a bipartite two-regular
graph when its sources and recipients are represented in separate
parts. Each of its bipartite cycles has even length, so alternating
edge colors decompose it into two permutation factors $A,B$. Choose
$A$ to contain $u\to v$ and label $u=0,v=1$.

Up to relabeling fixing these two vertices, the $A$-cycle through zero
is $(0,1,\ldots,\ell-1)$ for one $\ell\ge2$. Its other cycles are
represented by an integer partition of $n-\ell$ into parts at least
two. For each such choice, enumerating all permutations $B$ with
$B(i)\ne i,A(i)$ covers every candidate graph; remove $0\to1$ before
applying any game test.

Two necessary obstructions safely prune this enumeration. Once the
outgoing neighborhood of an eligible source $s$ is complete, if some
$c\ne s$ has $N^+(s)\subseteq N^+[c]$ and there is an eligible missing
recipient for $s$, the pursuer can wait at $c$ and capture the first
nonwaiting messenger move. Once the incoming neighborhood of an
eligible recipient $t$ is complete, if
$N^-(t)\subseteq N^+[c]$ and there is an eligible source outside
$N^-(t)\cup\{t,c\}$, waiting at $c$ until the messenger first enters
$N^-(t)$ likewise permits capture. In a partial assignment the cop's
outgoing row may be incomplete: coverage already present persists
under later additions. The source or recipient neighborhood used in
the inclusion is always complete. The code checks explicitly that
the required eligible missing partner exists.

All remaining completed graphs are evaluated by the exact finite
reachability game, with receipt priority and finite termination.
Enumeration finishes at every $7\le n\le12$ and finds no attaining
graph. Its counts are:

| $n$ | Distinguished cycle partitions | Partial nodes | Completed graphs surviving local obstructions |
|--:|--:|--:|--:|
| 7 | 7 | 756 | 0 |
| 8 | 11 | 6,338 | 21 |
| 9 | 15 | 59,375 | 2,092 |
| 10 | 22 | 800,507 | 64,992 |
| 11 | 30 | 10,079,292 | 767,210 |
| 12 | 42 | 164,276,910 | 16,902,091 |

These finite exclusions and the equality characterization prove the
claimed strict bounds. $\square$

The complete enumerator is `src/odd_endpoint_exhaustive.cpp`; its
finished receipts are `research/odd-endpoint-small-exhaustive.json`
and `research/odd-endpoint-n12-exhaustive.json`. A known attaining
13-vertex graph passes every partial pruning test as a positive control.
The independent review `research/odd-endpoint-twelve-independent-audit.md`
checks the permutation coverage, both pruning arguments, and the
final game semantics. It is an independent source and proof audit,
not a separately implemented repetition of the enumeration. Neither
this result nor the preceding odd endpoint certificates currently
has Lean coverage. The proposition does not determine the exact
small odd maxima.

The general support reduction in Theorem 57 and the exact finite exclusions
in Theorem 53 supersede the earlier bespoke 23-arc reductions and
intermediate bounds. Their original arguments and receipts are preserved in
`research/history/manuscript-superseded-arguments-2026-09-13.md`.
The following eleven-vertex core lemma remains a dependency of Theorem 53.

**Lemma (eleven-vertex cores).** Every graph on 11 vertices with
22 or 23 arcs satisfies $I(G)\le81$.

**Proof.** A vertex of outdegree at most one leaves at most ten
contributing source rows, each of size at most eight, giving $I\le80$.
A low-indegree vertex gives the same column bound. We may therefore
assume minimum indegree and outdegree two. At 22 arcs all degrees
equal two. At 23 arcs exactly one vertex has outdegree three and
exactly one has indegree three.

If a source camping obstruction occurs, at least eight missing pairs
fail at 22 arcs, and at least seven fail at 23 arcs. If a recipient
camping obstruction occurs at $t$ with pursuer position $c$, every
source outside $N^-(t)\cup\{t,c\}$ fails. This gives at least seven
failed pairs at 22 arcs and at least six at 23 arcs. The total numbers
of missing pairs are 88 and 87, respectively, so every graph with
one of these obstructions has $I\le81$.

It remains to enumerate the graphs with neither obstruction. The
22-arc case uses the two-permutation decomposition already described.
For 23 arcs, the bipartite graph still has a perfect matching: a set
$S$ of source vertices emits at least $2|S|$ edges, whereas a set
of possible heads $T$ can receive at most $2|T|+1$. Thus
$|N(S)|\ge|S|$, which implies a perfect matching by the augmenting-path
criterion. Its removal leaves residual degree one at every source
except the unique degree-three source, where two choices remain;
recipient capacities are analogous.

Fix the matching permutation to each cycle partition with no singleton.
Its cycle rotations and permutations of equal-length cycles allow
the degree-three source to be placed at one representative vertex
for each distinct cycle length. Enumerate all positions of the
degree-three recipient, then every residual row subject to the
prescribed column capacities. This covers every graph in question.
Only complete source rows or recipient columns are used in camping
prunes; a partial cop row suffices because any coverage already
present persists under later additions.

The complete 22-arc enumeration has 120,302 graphs surviving these
prunes, with maximum $I=66$. The complete 23-arc enumeration has
792,080 such graphs, with maximum $I=74$. Both use the exact finite
game recurrence and were freshly recompiled and replayed with all
counts and witnesses matching. Thus the graphs surviving the prunes
also have $I\le81$, proving the lemma. $\square$

The source and mathematical audit, including the matching argument,
symmetry reduction and rollback checks, is
`research/odd-endpoint-eleven-enumeration-audit.md`. The enumerators
are `src/small_exceptional_regular_max.cpp` and
`src/small_exceptional_one_excess.cpp`; matching replay receipts and
hashes are indexed by
`research/odd-endpoint-eleven-enumeration-audit.json`.
The saved maximizing witnesses additionally pass both original game
solvers and all direct rank checks. This is independent review and
re-execution of the same enumeration sources, rather than a second
independently implemented enumeration.

Theorem 53 combines this eleven-vertex bound with Theorem 57 and the
three finite exceptional-family exclusions to prove $M_E(23)=83$.
Its verified twelve-vertex witness also proves $M(n,23)=83$ for every
$n\ge12$ after adding isolates.

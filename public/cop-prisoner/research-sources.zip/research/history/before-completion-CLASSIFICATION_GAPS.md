# Historical pre-completion snapshot

This records the superseded101-case checkpoint. Use the current root documents for status.

# Numerical gaps and explicit-construction obligations

The current incorporated ledger leaves **101 distinct representative parameter pairs** numerically unresolved: **69 sparse**, **32 main-interval**, and **zero dense** pairs. All budgets at orders one through seven are exact. Every remaining main-interval gap has order eight, nine, or ten. The support cutoffs for the remaining sparse budgets are at most eighteen.

Every `n>=11, 22<=m<=n(n-1)` is now determined explicitly. At order eleven, the first three values are `M(11,22)=79`, `M(11,23)=78`, and `M(11,24)=79`; budgets 25 through 88 attain the missing-pair upper bound. The dense range is complete at all orders, with its sharp uniform staircase starting at eleven. The full missing-pair main formula still starts at twelve, and that threshold is sharp because `(11,22)` has value 79 rather than 88.

These counts are the exact complement of the proved domains and certified data incorporated in `publication/classification-coverage.json`. They do not assert that every further consequence of every retained theorem has been extracted. The current fixed audit box through order 114 contains 493,924 admissible cells, 492,834 exact cells and 1,090 unresolved cells. Of the latter, 989 repeat one of the 101 canonical unknowns under the proved host reductions. The previous checkpoint had 454 representatives; the current pass removes 353. Later source-reviewed results enter these totals only after the ledger is refreshed.

## Separate explicit-construction inventory

Each pair requires both an exact upper/lower match and concrete attaining adjacency or composition with parameters determined from `(n,m)`. A certified listed graph is an acceptable genuine finite exception. Existence, a fresh arbitrary-graph search, or conditional-expectation derandomization does not automatically satisfy this construction requirement.

The separate recipe inventory has no identified known-value construction-only gap. Its zero finding comes from checking actual procedures and saved finite graphs, not from the numerical order threshold or support bound. Read `EXPLICIT_CONSTRUCTIONS.md` and `research/explicit-construction-coverage.json` for the separate audit and its source version. A future existential equality would leave a recipe obligation until an explicit construction is supplied. Newly incorporated exact finite exceptions have literal arrows and direct winning/losing rank replay; staged intervals read fixed arrows and certified optional subsets.

Prescribed-hub, delivery-time and arbitrary-subset guarantees stay attached to the theorems that prove them. Another attainer of the same value does not inherit those stronger properties automatically. A unified executable can make the recipes easier to use, but running code is not a replacement for the ordinary adjacency and delivery arguments.

## Numerical reduction and completed domains

For `m>0`, at most `2m` vertices are nonisolated and adding isolates preserves the count. The stronger comparison-witness support result gives `M(n,m)=M(min(n,B_m),m)` for budgets 12 through 21, with the current approved cutoffs:

| Arrows `m` |12|13|14|15|16|17|18|19|20|21|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Host cutoff `B_m` |12|13|16|18|15|18|15|18|11|15|

A strict-score support estimate becomes an all-graph host reduction by comparison with a fixed witness: a graph above the witness score has bounded support, while a graph at or below that score is dominated by the witness. This does not claim that every low-scoring graph itself has small support. The selected attainer then lifts to larger hosts by adding isolates. The reviewed twenty-arrow compression improves its host cutoff to eleven: `M(n,20)=M(11,20)` for every `n>=11`. This does not settle its value, which remains between 53 and 57. The stronger thirteen-arrow lower witness reduces that budget's comparison cutoff to thirteen.

The complete order-seven row includes the sharp values `M(7,22)=14` and `M(7,23)=12`; its twenty newly settled budgets have complete independent degree/suffix enumeration and separately replayed literal lower graphs. The ordinary audit and receipts are `research/small-case-n7-independent-review.md/json` and `research/small-case-n7-independent.json`. The eleven-vertex exceptions use complete camping-free and camping-pattern enumerations at 24 arrows, and a complete one-excess factor enumeration at 23 arrows. The latter retains camping whenever the certified losses permit the proposed score; it does not silently restrict to a camping-free family.

Saved staged envelopes establish every missing-pair count in `n=8,m=24..26`, `n=9,m=24..54`, `n=10,m=28..70`, and `n=11,m=25..88`. Their asymmetric ranks quantify over every optional subset of each stage. The previous infinite circle, hub, sparse and dense constructions remain in force, including their stronger subset and time conclusions.

The additional reviewed fixed cases are `M(8,12)=M(9,12)=9`, `M(8,13)=11`, and `M(8,39)=14`. The thirteen-arrow graph also gives `M_E(13)>=11`; it does not prove a global upper. The tiny-budget upper proofs have independent ordinary source/coverage review and literal rank replay, not a second full negative enumeration at the new orders. Their source-pinned boundary is in `research/small-case-tiny-review.md/json`. The 39-arrow case has an ordinary defect split, corrected safe-root reductions, and full independent leaf-orbit and negative-rank replay in `research/small-sparse-eight39-review.md/json`.

The dense classification now has no residual exceptions. Literal small-core certificates, exact rooted and ordinary exclusions, missing-block composition, and the ordinary staircase recipes close the former 21 gaps. The threshold eleven refers to uniform attainment of the staircase expression; smaller exceptional values are separately determined.

`src/classification_coverage.py` reads saved evidence and performs coverage arithmetic; it does not search for graphs. Recompute with `python3 src/classification_coverage.py --check` and separately check recipe coverage with `python3 src/audit_explicit_constructions.py --check`. Source hashes identify the evidence version. They do not prove correctness by themselves.

## What still needs proof

**Sparse: 69 representatives.** Their budgets are 12 through 21. The retained global bounds include `M_E(12)>=9`, `M_E(13)>=11`, `M_E(14)<=22`, `M_E(16)<=32`, `30<=M_E(18)<=44`, `53<=M_E(20)<=57`, and `56<=M_E(21)<=71`. These lower values are witnesses, not presumed optima. The regular ten-vertex degree family at twenty arrows has maximum 53, but the full upper proof must also cover the surviving nonregular patterns. The support reduction is precisely what makes that missing quantifier finite.

**Main interval: 32 representatives.** There are 20 at order eight, five at order nine and seven at order ten. Nineteen lie below `3n`, and thirteen lie at or above `3n`. A literal graph attaining the missing-pair bound closes a cell immediately. Where the bound is unattainable, the exact number of unavoidable failures and a matching graph are both needed. Failed constructions and incomplete searches provide neither a sharp upper nor an impossibility theorem.

**Dense: none.** Dense cores and rooted constructions remain useful ingredients for the main-interval endpoints, but there is no separate unknown dense value in the current ledger.

## High-value next investigations

1. **Use support profiles to organize sparse exclusions.** Retain active row/column counts, their overlap, surplus degrees, and nonisolated vertices outside the active sets. Count compulsory zero rows and columns before enumerating adjacency. Every live row needs two nonsink successors, and every live column needs two predecessors of positive indegree; these conditions can sharpen the loss accounting when the basic rectangle estimate is close. A surviving integer profile is only a necessary shape. It is not a realizable graph, and excluding only a convenient regular subfamily cannot close the global budget. Start each proposed score with the complete surviving profile list and use bounded, source-pinned exclusions only on the residual shapes.
2. **Derive normal forms from a small allowed loss count.** For each remaining main cell, subtract the proposed score from the missing-pair count. Compare that loss allowance with a single source-camping row or predecessor-camping column. This can force minimum degrees and a few exceptional high-degree vertices, as at `(11,23)` and `(11,24)`. Keep initial-source exceptions and all camping classes whose losses still fit; preserve complete symmetry coverage and run the actual delivery game on survivors. A completed target exclusion proves an upper, while a best score from an incomplete search does not.
3. **Target constructive interval endpoints and preserve selected pairs.** At order eight the remaining upper blocks are `m=27..38` and `m=40`, between the certified interval ending at 26 and dense core data. The exact intermediate anchor `M(8,39)=14` provides a concrete starting point for preserving selected pairs while changing the budget. Orders nine and ten have only the short low main bands `m=19..23` and `m=21..27`. Seek literal endpoint witnesses, then certify a fixed set of surviving pairs against a larger cop envelope. Installed arrows may support later stages, but each stage needs its own asymmetric rank proof. Universal endpoints alone do not imply that their intermediate graphs are winning. Where some failures are forced, a protected-pair stage can still propagate the optimal score across several budgets.

The old marked one-vertex extension remains a possible simplification, not a prerequisite for the completed full interval. Delivery-time optimization and classification of all extremizers remain parked. A new structural lemma belongs in this programme when it closes a named value gap, supplies a missing explicit recipe, or simplifies a proved recipe without dropping its required guarantee.

## Exact canonical unknown-value ranges

The following inclusive ranges are generated from the current ledger's `canonical_representatives.unresolved_by_n` field. They omit repeated host-equivalent values. Current source bounds and lower-witness identities remain in the machine-readable ledger.

- `n=8`: `m=14..23, 27..38, 40`.
- `n=9`: `m=13..23`.
- `n=10`: `m=12..27`.
- `n=11`: `m=12..21`.
- `n=12`: `m=12..19, 21`.
- `n=13`: `m=13..19, 21`.
- `n=14`: `m=14..19, 21`.
- `n=15`: `m=14..19, 21`.
- `n=16`: `m=14..15, 17, 19`.
- `n=17`: `m=15, 17, 19`.
- `n=18`: `m=15, 17, 19`.

# Frozen 12- and 13-arrow checkpoint

13 September 2026. No graph search remains running. These results concern
the fixed host orders stated below; they do not supply unrestricted upper
bounds for either budget.

## Results

* A literal eight-vertex, 13-arrow graph has 11 guaranteed indirect pairs,
  improving the unrestricted lower bound to `M_E(13)>=11`. Its rows are
  `(5,6,7),(6,7),(1,5),(2,4),(0,3),(4),(1),()`.
  `research/small-plateau-tiny-m13-witness.json` contains both winning and
  losing rank certificates. Both existing Python game solvers agree, and
  all 1,024 alternating states pass the direct certificate obligations.
* The complete fixed-host exclusion at `n=8,m=12,target=10` covers 55
  degree profiles and 32,503,165 recursion nodes, taking 4.64285 seconds.
* The complete fixed-host exclusion at `n=9,m=12,target=10` covers 61
  degree profiles and 107,061,187 nodes, taking 14.0721 seconds.
* The complete fixed-host exclusion at `n=8,m=13,target=12` covers 52
  degree profiles and 110,083,489 nodes, taking 17.6315 seconds. The
  independently solved literal 11 witness meets this fixed-host upper.

The 12-arrow lower value nine is already witnessed at seven vertices;
isolates embed it at orders eight and nine without changing its score.
An isolated initial cop never obstructs a finite route, and it cannot
enter the original component. Consequently the completed upper tests,
after independent source review, establish `M(8,12)=M(9,12)=9` and
`M(8,13)=11`. The latter is not the fixed seven-vertex value, which is ten.

## Source and upper-proof boundary

`src/small_plateau_tiny_budget.cpp` copies the independently audited
`src/small_case_n7_independent.cpp`. Its only differences are explanatory
comments, array sizes enlarged from 12 to 20, and the host-order input
guard. In particular, degree enumeration, suffix-cell normalization,
the conservative maximum over both live dimensions, all necessary
pruning rules, and the explicit alternating AND/OR game are unchanged.
Their ordinary correctness arguments in
`research/small-case-n7-independent-review.md` apply verbatim to the
actual host orders eight and nine. No historical source was modified.
Only those orders are claimed by this checkpoint; its command interface
has not been validated for every order it syntactically accepts.

The four raw receipts are:

* `research/small-plateau-tiny-n8-m12.json`;
* `research/small-plateau-tiny-n8-m13.json`, the initial decision run that
  stopped on the new 11 witness and is not a completed exclusion;
* `research/small-plateau-tiny-n8-m13-target12.json`;
* `research/small-plateau-tiny-n9-m12.json`.

Each negative run covers profile zero through every generated profile,
has equal total and checked profile counts, and reports `complete:true`
and `counterexample_found:false`. The initial positive run instead
reports a counterexample and `complete:false`, as required. Its graph
is a valid lower witness independently of search coverage. The sources,
receipts, witness and this note are pinned in
`research/small-plateau-tiny-budget-checkpoint.json`. The parent task is
performing the independent source and lower-certificate review before
promoting the fixed-host upper results.

## Remaining global question

The previous necessary integer system gives a hypothetical `I>9` graph
at twelve arrows nonisolated support at most twelve. Updating the lower
bound at thirteen arrows from ten to eleven reduces the corresponding
necessary support cutoff from fourteen to thirteen (38 active degree
profiles and 400 auxiliary integer profiles). These are structural
necessary conditions, not graph existence or unrestricted exclusions.
The one maximum-support tuple is `q=r=4,b=1,o=i=3,z=6`.

The additional condition that each live row needs two nonsink outgoing
neighbors, and each live column needs two positive-indegree predecessors,
is sound but does not by itself remove any of the surviving integer
profiles at these thresholds. A broader graph search or a further
ordinary structural argument is still required for the global upper
bounds. No such search was launched after the stop instruction.

# Proposed global nineteen-arrow upper49

13 September 2026. New ordinary reduction and two complete finite exclusions;
independent review is pending. This strengthens the separately reviewed
global upper53, but does not assert equality at nineteen arrows.

## A live-column deletion bound

Let v have indegree0 and outdegree d in a graph with m arrows. Restrict the
cop to G-v. No messenger from a surviving source can enter v, so all old
guarantees are bounded by I(G-v). Only row v can add pairs. Every live
recipient column needs at least two predecessors of positive indegree.
The total arrows starting at positive-indegree vertices is at most m-d,
and the two required incoming arrows for different recipients are distinct.
Thus there are at most floor((m-d)/2) live columns, bounding row v by that
number. This proves

    I(G) <= M_E(m-d) + floor((m-d)/2).

For an outdegree-zero sink v of indegree d, old messenger excursions to v
cannot reach surviving recipients. Every live source row has two nonsink
successors; at most m-d arrows end at nonsinks. The separate original-
direction argument gives the same bound. If d=1 the deleted row/column is
zero, so the floor term may be replaced by0. Isolates are deleted first.
Harmless fresh-sink padding proves M_E is nondecreasing in its arrow budget.

At m19, d1 leaves18 arrows and gives at most44. For d>=2, the remaining
budget is at most17. The retained strict odd theorem gives M_E(17)<=41,
so monotonicity and the displayed bound give at most41+8=49. This covers
all graphs with any zero indegree/outdegree, regardless of host order.

## Positive-degree ordinary reduction

For all-positive graphs, q,r<=m-n. Use the active rectangle bound

    I <= qr-b-e(A,B),
    b>=max(0,q+r-n),
    e(A,B)>=max(0,2q+2r-m).

At n>=12, q,r<=7, so I<=49-max(0,28-19)=40; reducing either active count
cannot increase the maximum beyond49. At n11, q,r<=8, and the diagonal
lower bound strengthens the maximum to46 (at q=r8). Thus every positive-
degree competitor above49 fits on at most10 vertices.

At n10, q,r<=9. If either count is at most8, the exact positive-degree
surpluses x=19-n-q=9-q and y=9-r give
e(A,B)=2q+2r-19+x+y+w=q+r-1+w. Together with b>=q+r-10 this gives at
most49, attained by the count bound q=8,r=9 or q=9,r=8. The residual
q=r9 family has one low-in and one low-out vertex, all other degrees2.

At n9, if either active count is at most8, positive-degree surpluses give
e(A,B)=q+r+1+w and the active rectangle has at most46. The residual
q=r9 family has minimum degree2, with one outdegree-three and one
indegree-three vertex. At n<=8 the missing-pair bound is at most37.

## Complete finite exclusions

The n10/m19 one-defect family is enumerated by a perfect matching plus a
nine-edge matching, with complete cycle normalization and every omitted
row/column. Unlike the original threshold53 run, the new source retains
permitted camping patterns: it counts the union of permanent source-row
and recipient-column failures, excluding the initial-source/cop exception,
diagonals and direct arrows. Completed rows/columns are required whenever
their full neighborhood is used. Optimistic guarded paths and actual game
fixed points are unchanged. The complete run has12 factors,220 patterns,
1275911 nodes and749 actual-game threshold decisions; none exceeds49.
Source/result: sparse_finish_nineteen49_one_defect.cpp and
sparse_finish_nineteen49_one_defect_10_19.json.

The n9/m19 one-excess family uses the existing Hall matching normalization
and complete residual degree enumeration, with its retained camping-loss
union. There are8 cycle partitions,135 patterns and306286 nodes; the
guarded-path bound rejects every complete threshold candidate, so no
actual-game call is needed. Source/result:
sparse_finish_nineteen49_one_excess.cpp and
sparse_finish_nineteen49_one_excess_9_19.json.

Both runs completed. Their measured times were0.470 and0.093 seconds.
These finite exclusions plus the ordinary reductions prove the proposed
global upper M_E(19)<=49, subject to independent review. They do not supply
a49 witness, an exact nineteen-arrow value, or new Lean coverage.

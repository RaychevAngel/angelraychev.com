# Delivery time: non-authoritative side-conversation handoff

Prepared 2026-09-12 PT (2026-09-13 UTC).

**Status: discussion notes and proposed deductions, not an authoritative project update.** This file does not supersede `HANDOFF.md`, the paper, research log, verification records, or the main agent's plan. Angel requested this handoff after agreeing with the scope recommendation below. No paper, website, Lean file, existing research artifact, or project plan was changed in this side conversation. No main-thread agent was contacted.

## 1. What Angel asked and agreed with

The conversation began by clarifying the delivery-time bounds in the sparse even/odd constructions. Angel then asked when two moves become possible, what the best time at `m = 2n` might be, and how delivery time changes with the edge budget.

We introduced `T_*(n,m)`: the smallest worst-case delivery time among graphs attaining `M(n,m)`. Angel's next question was whether this quantity deserves attention at all.

The recommendation he agreed with was:

- Keep `M(n,m)` as the current paper's central object.
- Define `T_*` and record time guarantees already obtained, separating construction bounds from optimal times.
- Investigate a few decisive speed questions, especially the growth of `T_*(n,2n)` and the budgets admitting two-move attainment.
- Do not automatically make a full classification of delivery time a prerequisite for finishing the current paper.
- Let the mathematical results determine whether this becomes a substantial section or a separate paper.

This is agreement with a research framing, not an instruction from this file to begin experiments, revise the manuscript, formalize new claims, or publish anything. The current request was only to prepare a non-authoritative handoff.

Angel values exact parameter domains and a clear distinction between what follows and what remains open. Avoid using “explicit construction” versus “algorithmic construction” as if those labels determine the delivery time.

## 2. Quantities and a terminology trap

Use the existing visible messenger/pursuer game, with waits allowed and receipt preceding collision. In particular, the pursuer may initially occupy the recipient. Time here always counts **messenger moves**, not alternating player turns and not algorithm running time.

For a graph `G`, let `D(G)` be the indirect pairs counted in `I(G)`. For a counted pair `(s,t)` and legal initial pursuer `c != s`, let `tau_G(s,t,c)` be the minimum number of messenger moves sufficient against every pursuer strategy. Define

\[
T(G)=\max_{(s,t)\in D(G)}\max_{c\ne s}\tau_G(s,t,c),
\qquad
T_*(n,m)=\min_{\substack{|V(G)|=n,\ |E(G)|=m\\I(G)=M(n,m)}}T(G).
\]

For `M(n,m)=0`, leave this quantity undefined unless the paper explicitly chooses an empty-maximum convention. Direct pairs take one move and do not affect the maximum when an indirect pair is present.

This is a lexicographic objective: maximize the number of guaranteed pairs first, then minimize their worst-case time. It does not measure the tradeoff obtained by sacrificing a few pairs for a much shorter deadline.

A natural broader object, discussed but not adopted as a new central classification task, is

\[
M_T(n,m)=\max_{|V(G)|=n,\ |E(G)|=m}
\#\{(s,t)\text{ indirect}:\text{delivery is guaranteed within }T\text{ moves}\}.
\]

When `M(n,m)>0`,

\[
T_*(n,m)=\min\{T:M_T(n,m)=M(n,m)\}.
\]

`M_T` is nondecreasing in the deadline `T`. No monotonicity in the exact edge budget `m` was proved. An added arrow helps both players.

**Important distinction:** the new quantity `q_2(n)` below concerns the first budget permitting *universal* two-move delivery. It is not the first budget with `T_*(n,m)=2`. At small budgets, a graph can attain `M(n,m)` by guaranteeing only a few indirect pairs in two moves. In the final dense band, two-move attainment likewise does not mean every missing pair wins.

## 3. Existing results checked directly in the files

### Sparse even and odd bounds

For even budget `m=2k`, Theorem 40 has a uniform construction from `k>=85`. The finite witnesses for `12<=k<=84` also satisfy the same bound

\[
9\lceil k/6\rceil+18.
\]

Thus that time bound is stated for **all `k>=12`**, not only the uniform range.

For odd budget `m=2k+1`, Theorem 45 gives the uniform construction and bound

\[
34\lceil(k+1)/6\rceil+27
\]

from support size `k+1>=145`. Corollary 45.1 supplies verified attaining graphs at every support size `13<=k+1<=144`, but its written proof does not assert that those finite graphs satisfy this same numerical time bound. Do not silently extend it without checking their actual times.

Sources: `paper/sparse-all-orders.md`, `paper/odd-endpoint-resume.md`.

### What the full main-interval theorem says about time

Theorem 44 combines direct construction families and a deterministic exact-budget algorithm. The algorithmic part **does** guarantee two moves. The absence of a two-move promise across the whole interval comes from the sparse end, not from the absence of one closed formula for the graph.

Put `L=n(n-1)`. Proposition 51 supplies two-move universal delivery whenever

\[
(n-3)p^2(1-p)>4\ln n+\ln(8/3),\qquad p=m/L.
\]

Theorems 48 and 50 cover all missing budgets

\[
2n\le h\le n\left\lceil\frac{n-1}{13}\right\rceil
\]

for `n>=166`, also with two moves. Together, for `n>=1800`, these prove a continuous two-move universal range

\[
\lfloor Lp_-(n)\rfloor+1\le m\le n(n-3),
\]

where `p_-(n)` is the smaller root in `(0,1)` of

\[
(n-3)p^2(1-p)=4\ln n+\ln(8/3).
\]

A simpler sufficient lower endpoint is `ceil(L/7)`. This was explained as an easily stated subrange, not the sharp endpoint of the method.

At `n=1800`, the sharper integer interval starts at `m=458805` and ends at `3234600`. A 60-digit decimal evaluation gave margins against the strict density inequality of approximately `-0.0000784273305774453` at `458804` and `+0.0000454049203050235` at `458805`. These are numerical checks, not new formal certificates. This endpoint is sufficient, not a necessary threshold for two moves.

Corollary 33 gives two-move attainment for every **counted** pair throughout

\[
n(n-3)<m\le n(n-2),\qquad n\ge75.
\]

Some missing pairs necessarily fail in that band. Whenever a positive extremal count is achieved within two moves, `T_*=2` automatically, because an indirect pair cannot be delivered in one move.

Sources: `paper/exact-budget-sharpening.md`, `paper/exact-budget-derandomization.md`, `paper/dense-protected-envelope.md`, `paper/dense-incidence-bridge.md`, `paper/dense-first-step.md`.

## 4. Sparse time: deductions and evidence

Every extremizer at `m=2n`, for `n>=12`, is two-in/two-out regular. Ignoring the pursuer, at most

\[
1+2+\cdots+2^T=2^{T+1}-1
\]

vertices can be reached from one source in at most `T` moves. Waiting does not enlarge that set. Therefore

\[
\boxed{\lceil\log_2(n+1)\rceil-1
\le T_*(n,2n)\le9\lceil n/6\rceil+18.}
\]

This is a logarithmic-to-linear gap. No matching asymptotic bound for `T_*(n,2n)` was proved here.

The current six-type ring construction itself has linear worst-case time: it has `q=ceil(n/6)` columns, each arrow changes the column by at most two, and some source/recipient columns have circular separation `floor(q/2)`. Thus even ordinary travel needs at least `ceil(floor(q/2)/2)` moves for some pair. Combined with the theorem, this family has time `Theta(n)`. A logarithmic construction would need a different global layout, not just a faster analysis of this ring.

The stored verification receipt gives the following selected worst-case times, with ordinary directed diameters computed read-only during this conversation:

- `n=12`: delivery 14, diameter 4.
- `n=20`: delivery 17, diameter 5.
- `n=24`: delivery 23, diameter 6.
- `n=32`: delivery 17, diameter 6 (bounded two-permutation search).
- `n=40`: delivery 21, diameter 8.
- `n=50`: delivery 25, diameter 8.
- `n=60`: delivery 29, diameter 10.
- `n=70`: delivery 32, diameter 11.
- `n=80`: delivery 34, diameter 11.
- `n=84`: delivery 36, diameter 11.

The solver's retained layer `j` means delivery in at most `j` messenger moves; the final repeated fixed point is not appended. Thus these are minimax times for the selected universal graphs, not merely loose certificate ranks. They do **not** optimize over graph choice. The larger examples mostly come from the existing periodic families, so their trend is not evidence that every extremizer needs linear time.

Sources: `research/sparse-finite-bridge-verification.json`, `research/sparse-finite-bridge-witnesses.json`, `src/game_solver.py`.

An `O(log n)` time construction at `m=2n` was suggested as a worthwhile hypothesis to test. It was not asserted as likely enough to be a theorem. Low diameter or expansion alone does not prove pursuit-resistant delivery.

## 5. New proposed result: the first universal two-move budget has order n log n

Define

\[
q_2(n)=\min\{|E(G)|:|V(G)|=n,\ \text{every source--recipient pair is guaranteed within two moves}\}.
\]

The following short arguments appear to prove `q_2(n)=Theta(n log n)`. The side assistant stated this conclusion to Angel, supplied the arguments, and performed finite sanity checks. **There has been no independent-agent review, Lean verification, integration into the paper, or literature/novelty audit of this game-specific conclusion. Treat it as a proposed result to independently attack before promotion.**

### 5a. Lower bound by a separating system

For each vertex `u`, define disjoint sets

\[
A_u=\{u\}\cup N^-(u),\qquad B_u=N^+(u)\setminus N^-(u).
\]

For each unordered reciprocal pair, add a separating pair consisting of its two singleton endpoints.

These pairs of sets separate every pair of distinct vertices:

1. If `s->t` exists and `t->s` does not, then `s in A_s` and `t in B_s`.
2. A reciprocal pair is handled by its singleton separator.
3. If neither arrow exists, start the pursuer at the recipient `t`. Universal two-move delivery requires an intermediary `u` such that `s->u`, `u->t`, and `t` has no arrow to `u`. Hence `s in A_u` and `t in B_u`.

Case 3 uses the actual timing convention: the pursuer may start at `t`, but cannot prevent final receipt merely by occupying `t`. It can capture the intermediary if `t->u` exists.

Write `b` for the number of unordered reciprocal pairs. The total memberships in the first `n` separators are

\[
\sum_u(|A_u|+|B_u|)=n+2m-2b.
\]

The added singleton separators contribute `2b`, giving total `n+2m`.

Hansel's separating-system lemma bounds this total below by `n log_2 n`. Consequently

\[
\boxed{q_2(n)\ge\left\lceil\frac n2(\log_2 n-1)\right\rceil.}
\]

For a self-contained proof of the lemma, independently delete one uniformly chosen side of each separator. At most one vertex survives, because every pair is separated somewhere. If a vertex belongs to `d_v` separator sides, its survival probability is `2^{-d_v}`. Thus `sum_v 2^{-d_v}<=1`; convexity yields `sum_v d_v>=n log_2 n`.

Reference actually consulted: Béla Bollobás and Alex Scott, *Separating systems and oriented graphs of diameter two*, manuscript dated April 24, 2006, Lemma 1 and the following proof discussion:

https://people.maths.ox.ac.uk/scott/Papers/diam2.pdf

The paper attributes the lemma to Hansel, with an independent result by Katona and Szemerédi. Its oriented-diameter results must not be transferred directly: our digraphs permit reciprocal arrows and our game is stronger than ordinary diameter two. The game-specific translation above is the proposed new deduction.

### 5b. Upper order by a small random routing set

Choose `h=ceil(24 ln n+4)` routing vertices `H` (for all sufficiently large `n`, `h<=n`; in particular this holds from 128). Permit each nonloop arrow with at least one endpoint in `H`, and include every permitted arrow independently with probability `1/2`. There are no arrows between two vertices outside `H`.

The number of permitted arrows is

\[
Q=h(2n-h-1)\le2nh=O(n\log n).
\]

For a fixed triple `(s,t,c)` with `s!=t` and `c!=s`, each `u in H\{s,t,c}` has probability `1/8` of satisfying

\[
s\to u,\qquad u\to t,\qquad c\not\to u.
\]

All three tested arrows are permitted, distinct, and have the required independent distribution. The tests for different candidates use disjoint arrow variables. This remains true when `c=t`; `c=s` is excluded by the game rules.

A successful candidate differs from the initial pursuer, cannot be reached on the pursuer's response, and lets the messenger reach the recipient on the next move. A pursuer response to the recipient does not invalidate the final receipt.

The probability that any legal triple lacks such a candidate is at most

\[
n^3(7/8)^{h-3}
\le n^3e^{-(h-3)/8}
\le e^{-1/8}<1.
\]

Therefore some graph guarantees all pairs in two moves and has at most `Q=O(n log n)` arrows. Together with the lower bound this gives the proposed order-of-growth result.

**Scope limitations:**

- This construction has a random edge count; the argument bounds that count above. It does not specify an arbitrary exact budget `m`.
- It therefore establishes the order of the *first possible universal budget*, not attainment at every budget beyond that scale.
- Adding arbitrary arrows is not a valid way to fill the missing budgets: it may empower the pursuer and destroy the argument.
- No optimal constant or exact formula for `q_2(n)` was derived.
- The existing exact-budget conditioning/derandomization method might be adaptable to the restricted set of permitted arrows. That extension was not proved or executed here.

### 5c. Read-only sanity checks performed

Using Python's `random.Random(62000+n)`, the routing construction was sampled at `n=128` and `n=256`. Iterate ordered vertex pairs in increasing order, and call `getrandbits(1)` only for permitted nonloop arrows.

- `n=128`, `h=121`, sampled `m=8033`: zero failing source/pursuer start states.
- `n=256`, `h=138`, sampled `m=25749`: zero failing source/pursuer start states.

For each `c!=s`, verification formed all safe routing intermediaries `u in N^+(s) intersect H` outside `{c} union N^+(c)`, then checked that their outgoing neighborhoods together with the direct recipients and `s` cover every vertex. This checks all recipients simultaneously, using the exact two-move criterion.

The separating sets in 5a were constructed independently from these sampled adjacency sets. They covered every unordered pair, were disjoint on each separator, and their total memberships were exactly `n+2m` (16194 and 51754 respectively).

These were sanity checks, not evidence replacing either proof. No sampled graph files or new verification receipts were saved.

## 6. Why degree imbalance changes the picture

For a graph that is both in- and out-regular of degree `d`, each missing pair needs at least two distinct length-two intermediaries: the pursuer could start at a unique one. Counting length-two directed walks gives the necessary condition

\[
nd^2\ge2\bigl(n(n-1)-nd\bigr),
\qquad d\ge\sqrt{2n-1}-1.
\]

Thus regular universal two-move graphs require `Omega(n^(3/2))` arrows. The proposed routing construction has highly unequal degrees and avoids that restriction. **Do not substitute average degree for `d` in this argument for arbitrary graphs.**

In particular, the proposed `Omega(n log n)` general lower bound excludes universal two-move delivery at every fixed budget `m=cn` for sufficiently large `n`, even allowing unequal degrees. The exact optimal longer time at such budgets remains open.

## 7. How to interpret the research value

The agreed interest is structural:

- Is the linear delay at the sparse endpoint forced by the game or by the current construction?
- At which budgets can the extremal number of pairs be delivered in two moves?
- Does uneven allocation of edges produce substantially faster extremizers?

A sharper constant for one construction is less significant than resolving one of those questions. The existing count classification does not automatically answer the time problem, and the new time problem need not become a requirement for completing the count paper.

Potential verification priorities, offered only as suggestions: independently audit the game-specific separating-system reduction and random-routing proof; keep universal `q_2` separate from extremal `T_*`; then decide whether the new order-of-growth statement belongs in the manuscript. No execution or publication is authorized merely by this note.

# Layered routing execution checkpoint

13 September 2026. This note records the bounded construction work assigned
to the layered-routing branch. The root agent owns classification counts,
public integration, and the combined checkpoint.

## Incorporated ordinary results

The fourteen-hub guide construction from the earlier research log is now
implemented in `src/main_interval_layered.py` and proved in
`paper/main-interval-layered.md`. Its pair codes generalize immediately to
distinct equally sized r-subsets of the guides, for 2<=r<=g<=14 and
b<=binomial(g,r). The base is154+25g+(22+r)b and the optional count is
b(g+b-1). The maximum number of messenger moves is three.

The new twelve-hub variant uses the point/line missing graph modulo six.
Its guide codes are the two line parity triples, three point antipodal
pairs, and three line antipodal pairs, in that order. The old size-three
sufficient hypothesis is unnecessary for antipodal pairs: every relevant
two-element danger set has difference one or two, while these pairs have
difference three. The exact case argument is in the manuscript chapter.

All bulk vertices access the seven hubs outside
{P0,P3,L0,L2,L4}. This gives the new interval

    n=12+g+b, 2<=r<=g<=8, 0<=b<=binomial(g,r),
    A=106+22g+(19+r)b,
    A<=m<=A+b(g+b-1).

Both families tolerate every subset of optional guide-to-bulk and
bulk-to-bulk arrows. The messenger uses only the compulsory arrows, and
every safe-entry witness avoids the pursuer's full optional neighborhood.

## Verification and API

The direct arrow-list checker proves every two-move obligation for hub and
guide sources and every safe-entry obligation for bulk sources. It checks
all twelve-hub guide counts and uniform guide-subset weights at full
capacity, all fourteen-hub guide counts at full pair capacity, and several
higher-weight cases. Its receipt is
`research/main-interval-layered-checks.json`.

The independent branch reconstructed both families without importing their
constructors. It separately checked the twelve-hub local premises (2,132
obligations) and actual asymmetric game ranks at selected boundary cases.
It reviewed the ordinary proof including every guide/hub/bulk pursuer
configuration and confirmed the three-move bound. The independent receipts
are maintained by that branch, not this note. No Lean claim is made.

The final callable interface is:

* `interval(n,g,r=2,hubs=14)` returns an inclusive interval or None.
* `intervals(n)` returns all parameter records for both hub sizes.
* `parameters(n,m)` returns `(g,b,added,r,hubs)`.
* `construction(g,b,added=0,r=2,hubs=14)` builds that exact graph.
* `construct(n,m)` selects parameters arithmetically and builds the graph.

No constructor performs a pursuit-game search. Vertices are hubs first,
guides next, then bulk vertices. The chosen guide subsets and optional
arrows have fixed lexicographic order.

## Failed or deferred directions

1. **Reduce the eight bulk hub connections on the fourteen-hub core.**
   This cannot work within the present immediate-entry architecture.
   A bulk source must meet every hub pursuer's missing row. Its hub access
   set is therefore a vertex cover of each of two seven-cycles, requiring
   four vertices in each part. Allowing additional moves or changing
   hub-to-outside arrows could evade this restriction; merely choosing a
   better eight-element access set cannot lower the count.

2. **Use the same point/line architecture on ten hubs.**
   A bounded direct enumeration of omitted hub sets of sizes two through
   six found none satisfying the robust two-move guide conditions. These
   conditions require an omitted code to escape every hub-pair danger set
   and every guide-source/hub-recipient/hub-pursuer obstruction. This is a
   limitation of this interface, not a proof that ten hubs cannot support
   a different or longer routing scheme. On twelve hubs the same check
   found exactly the six antipodal pairs and two parity triples used above.

3. **Use the existing eleven-vertex literal core.**
   The same omitted-code conditions produced only one code, {2,8,10},
   among sizes two through six. It does not supply the required mutually
   distinguishable guides. The nine-vertex core produced none under this
   stronger two-move interface; that core's ordinary internal delivery
   already needs three moves for some pairs. These observations do not
   rule out a more permissive multi-stage interface.

4. **Mix pairs and triples assigned to bulk vertices.**
   This can save thirteen arrows near order50 using thirteen pairs not
   contained in a six-guide block and triples within that block. The same
   antichain entry argument works, with compulsory cost determined by total
   subset weight. However, the root's new circles already cover the
   improved main-value domains. The formulas remain privately recorded in
   `research/main-interval-layered-mixed-idea.md`; the constructor and
   manuscript retain the simpler uniform-weight family. No independent
   proof review is claimed for this deferred refinement.

## Remaining structural issue

The twelve-hub family has compulsory slope at least21 arrows per bulk
vertex with pair guide codes, or22 with triples. Most of this is twelve
hub-to-bulk arrows plus seven compulsory bulk-to-hub arrows. Substantial
further savings require changing that universal hub access architecture,
not simply optimizing the guide antichain. A later layer could allow only
some hubs to reach a given recipient, but then safe entry and subsequent
delivery must be proved together against all pursuer positions.

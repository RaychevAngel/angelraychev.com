# A composable six-type construction at every sufficiently large order

## Current strongest result: every n>=85

The exact sparse endpoint is now attained at every integer n>=85:

    M_V(n)=M_E(2n)=M(n,2n)=n(n-3).

The same six-type smoothing construction works when removal columns have
cyclic gaps at least THREE. Every one of the189 subsets of[-6,6] with
successive gaps at least3 was checked in the same local arena. Its1,287
objectives all passed. An independently written explicit-state verifier
checked560,885 required starts and10,271,740 alternating states, including
winning rank descent and losing-region closure. Safe transfer costs at
most9 moves; local delivery now costs at most27 (rather than26 in the
more widely spaced initial version).

Set k=ceil(n/6), r=6k-n, and use removal columns0,3,...,3(r-1). Then r<=5,
k>=15, and the cyclic wrap gap is at least15-12=3. The unchanged projection
needs k>=15 because the thirteen represented pursuer columns must leave
at least two exterior columns. Every phase sees one of the189 certified
patterns. The resulting delivery bound is9k+18. The clean final proof is
Theorem40 in `paper/sparse-all-orders.md`.

Complete current primary artifacts:

- `src/sparse_composition_multi_certificate.py`
- `research/sparse-composition-multi-certificates.json.gz`
- `research/sparse-composition-multi-summary.json`

Independent artifacts:

- `src/six_type_independent_spacing.py`
- `research/six-type-independent-spacing-3-certificates.json.gz`
- `research/six-type-independent-spacing-3-summary.json`

Both the full primary saved-rank replay and the independent alternating
verification passed. The source and artifact hashes are in those receipts.
This is a computer-assisted ordinary proof, not a new Lean theorem.

Intermediate progress: minimum spacing4 passed all95 local patterns and
would have given threshold115. Spacing3 passed all189 and gives85, so
there was no need to stop at the intermediate threshold. Arbitrarily
adjacent removals are NOT proved: deleting type4 in every column fails
local delivery in the tested arena, especially recipient types0 and5.
The remainder records the earlier, simpler single-removal-window proof
and discovery history without promoting its former threshold as current.

## First certified version: n>=385 (superseded by n>=85 below)

For every integer n>=385 there is an explicit loopless two-in/two-out
regular directed graph on n vertices in which every source–recipient pair
is guaranteed. Consequently

    M_V(n)=M_E(2n)=M(n,2n)=n(n-3),  n>=385.

The construction and projection below are ordinary mathematical arguments.
The finite local claims have complete rank certificates in
`research/sparse-composition-six-certificates.json`, generated and replayed
by `src/sparse_composition_certificate.py`. An independently written explicit alternating-state implementation has
verified all97 modules, 44,317 required initial states and 808,212 full
alternating states, including winning rank descent and losing-region
closure. Its implementation is `src/six_type_independent_verify.py`;
complete ranks and summary are in `research/six-type-independent-certificates.json.gz`
and `research/six-type-independent-summary.json`. The construction is therefore
independently audited at the stated computer-assisted proof boundary.
This construction is not yet formalized in Lean.

## Graph definition

Start with k columns indexed modulo k, each containing types0,1,2,3,4,5.
The first permutation A follows the Hamilton cycle

    0_i -> 1_i -> 2_i -> 3_i -> 4_i -> 5_i -> 0_(i+1).

The second permutation B is

    0_i -> 5_i,
    1_i -> 4_(i+1),
    2_i -> 1_(i+1),
    3_i -> 0_(i-1),
    4_i -> 2_(i+1),
    5_i -> 3_(i-1).

Choose a set S of column indices with consecutive cyclic gaps at least13.
For each h in S, delete vertex4_h and smooth its path in EACH permutation:

    A: replace 3_h -> 4_h -> 5_h by 3_h -> 5_h;
    B: replace 1_(h-1) -> 4_h -> 2_(h+1)
       by 1_(h-1) -> 2_(h+1).

Every other arc is unchanged. There are 6k-|S| vertices and twice as many
arcs. Deleting and smoothing in a permutation preserves bijectivity, and
the displayed new arcs have distinct endpoints. The two resulting
permutations never give the same outgoing neighbor: the modified A arc
from type3 ends at type5 while its B arc ends at type0; the modified B arc
from type1 ends at type2 two columns ahead while its A arc ends at type2
in the same column. All remaining outgoing pairs were already distinct.
For the stated k no modular identifications affect these checks. Therefore
the graph is simple, loopless and two-in/two-out regular.

## Fixed local arena

Fix reference column0. The messenger is restricted to columns[-4,4].
The pursuer occupies columns[-6,6], together with a state Omega.
Both players retain their waits and their real arcs. Messenger moves
leaving its window are discarded. Pursuer moves leaving its window go
to Omega. From Omega the pursuer may wait or enter ANY existing vertex
in columns -6,-5,5,6.

The cyclic hole separation ensures the thirteen-column pursuer window
contains either no deleted vertex or a single deletion in column h,
where -6<=h<=6. These are fourteen fixed patterns. There are seven goals
per pattern, except that delivery to deleted type4 is omitted when h=0,
giving exactly97 local certificates.

1. Safe transfer from any existing type in column-1 to column0 takes
   at most9 messenger moves. Success is seeded only at an uncaught
   messenger-turn state. A move into column0 must survive every pursuer
   response before the phase ends.
2. From any existing type in column-2, delivery to any existing type
   in column0 takes at most26 messenger moves. Here the actual recipient
   has terminal receipt priority over collision, as required by the game.

Every allowed initial pursuer position, including Omega, is covered,
apart from forbidden initial collision. The certificate checker checks
every chosen legal action, all pursuer responses, immediate and delayed
capture exclusion, and strict rank decrease. It also rebuilds the arena
from the graph definition when replaying the saved certificates.

## Local-to-ring projection

Assume k>=15, and every consecutive cyclic hole gap is at least13.
The thirteen represented pursuer columns are distinct and leave at least
two exterior columns. Every arc changes the column by at most two.
An arc starting in the represented window cannot jump across the entire
exterior gap and back into the opposite represented boundary in one
move. Therefore a local outside transition really may be mapped to
Omega. An arc from outside back into the represented window lands within
two columns of a boundary, all of which Omega permits.

The local pattern is determined by any deletion INSIDE the pursuer
window. A deletion outside the window cannot change a represented
vertex or a represented-to-represented arc. The only outward effect
is when a hole at column7 changes the arc from type1 in column6:
its old head4_7 and its new head2_8 both map to Omega. Effects coming
from outside into boundary columns are already allowed by Omega.
The analogous changes at the messenger boundary leave an outgoing move
outside its allowed window, so it is discarded in either case.

At most one hole lies in any represented window, because that window
has diameter12 and distinct holes have cyclic separation at least13.
Thus every phase has one of the certified local arenas. The real
pursuer has no more options than its abstract representative. Every
local messenger move is a genuine graph move.

Translate the intended recipient's column to0. Repeatedly apply the
safe-transfer lemma, recentering so that the current messenger column
is-1. Each phase increases its column by one, and finishes after the
pursuer response. Within at most k-1 phases it reaches column-2.
It then uses the appropriate local delivery certificate. This is a
finite guaranteed strategy using at most

    9(k-1)+26 = 9k+17

messenger moves. Reaching the actual recipient during an earlier transfer
simply ends the game sooner.

## Every order n>=385

Set k=ceil(n/6) and r=6k-n. Then 0<=r<=5 and k>=65. Take

    S={0,13,...,13(r-1)}

when r>0, and S empty when r=0. Consecutive displayed gaps are13;
the wraparound gap is at least65-52=13. The graph has exactly n vertices.
The existing universal bounds now give the displayed exact extrema.

The threshold385 is conservative and explicit. No claim about all smaller
orders follows from this theorem or from a numerical interpolation.

## Discovery and rejected alternatives

This construction came from testing vertex removal with separate
smoothing in both permutation factors, rather than adding a vertex to
the old five-type graph. Among168 six-type periodic candidates recorded
earlier, two one-type removals retained finite universality at column
counts8 and10. Only the mixed-direction pattern used above supplied
the complete local proof.

The other candidate had second permutation sigma=[3,1,5,0,2,4] and all
column shifts+1. It passed those finite rings but failed many local
delivery obligations; no infinite theorem is asserted for that smoothing.
This is another concrete example of finite circumference success being
insufficient for a compositional proof.

An initial window with messenger radius3 and pursuer radius5 failed
exactly at the hole offset-3 and recipient type4 (35 failing entry
states). Increasing the messenger radius to4 resolves this: all local
patterns pass with pursuer radius6 and the full two-layer exterior
reentry rule. The theorem uses the passing radius4/6 arena only.

Other bounded probes in this resumption tested generalized Kautz maps,
and a different five/six-column insertion pattern. Their failures did
not contribute any claimed theorem. In particular, generalized Kautz
maps at the even tested orders have twin outgoing neighborhoods and
cannot be universally winning in this game.

## Reproducibility

- `src/sparse_composition_smooth.cpp`: finite candidate-discovery screen.
- `research/sparse-composition-smooth-screen.json`: two surviving candidates.
- `src/sparse_composition_smoothing.py`: exact variable-column definition.
- `research/sparse-composition-pattern162-screen.json`: exploratory local tests.
- `research/sparse-composition-six-hole-window-screen.json`: all tested windows.
- `src/sparse_composition_certificate.py`: full generator and direct rank checker.
- `research/sparse-composition-six-certificates.json`: all97 complete certificates.

Replay with `python3 src/sparse_composition_certificate.py --check`.
This checks the saved ranks rather than regenerating the attractor.

## Odd-budget screen passed to the independent odd branch

All twelve canonical single-arc deletions from the unmodified six-type
family were tested at k=6,8,10 using the exact finite game solver.
Only the k=6 deletion3_0->0_-1 attained the odd bound; none did at k=8
or10. At k=10 that deletion was best but gaveI=3251 against the upper
bound3306. This finite exception is not an odd infinite-family theorem.
The full table is `research/sparse-composition-odd-deletion-screen.json`,
with source `src/sparse_composition_odd_screen.cpp`. The odd branch owns
further investigation; this screen avoids duplicated work there.

# Independent audit and quantitative consequences of the core-code construction

Status: ordinary mathematical derivation and independent adversarial review,
2026-09-12. The core-code construction was proposed by the parent research
agent in this phase. This note checks the doubled code variant, supplies an
explicit logarithmic parameter family, and records a finite numerical bridge.
It does not alter the manuscript or claim Lean formalization.

## The robust construction

The strongest statement allows variable code sizes. Fix k>=5 and take any
family of pairwise inclusion-incomparable hub subsets K_x, each of size at
least three. Every K_x must lie wholly in P or wholly in L, and must have
the corresponding forbidden-difference restriction below. Oddness is only
needed for the uniform counting formula, not for this structural theorem.
If there are q codes and W=sum_x |K_x|, the exact-budget envelope is

    A <= m <= A+q(q-1),
    A = 2k(2k-3)+4kq-W,
    L-A-q(q-1) = 4k+W.

The construction and two-move proof below apply unchanged. Inclusion
incomparability supplies both directional code differences; equal weights
are merely an easy way to produce such a family.

Let k be odd, k>=7, and 3<=r<=floor(k/2). Put

    C(k,r) = k/(k-r) binom(k-r,r).

There are C(k,r) independent r-subsets of a k-cycle: distinguish one selected
vertex, record the r positive gaps after reserving one unselected vertex
between consecutive selected vertices, then divide the resulting rooted
count by r. Equivalently the answer is
k/r binom(k-r-1,r-1), which equals the displayed expression.

Take two hub parts P_i,L_i, i modulo k. The missing arrows inside the hubs are

    P_i -> L_i,L_(i-1),
    L_i -> P_(i+4),P_(i+6).

All other distinct hub pairs are actual arrows. In particular each part is a
clique. For q<=2C(k,r) outside vertices x, assign distinct r-subsets K_x from
the following two collections: subsets of P with no index difference +/-2;
and subsets of L with no adjacent indices. Each collection has C(k,r)
elements because k is odd. Put in every hub-to-outside arrow, and every
outside-to-hub arrow x->u except u in K_x. Permit an arbitrary subset of the
q(q-1) outside-to-outside arrows.

With n=2k+q and L=n(n-1), every graph in this envelope has universal delivery
in at most two messenger moves. Its possible exact budgets are all integers

    A <= m <= A+q(q-1),
    A = 2k(2k-3)+(4k-r)q
      = (4k-r)n-2k(2k+3-r).

The upper endpoint has exactly

    L-A-q(q-1) = 4k+rq = 2n+(r-2)q

missing arrows. This is an arbitrary-subset assertion, not just existence at
each total budget. No new outside arrows are used by the safe witnesses.

## Full game-case audit

For a missing pair (s,t) and initial cop c!=s, it suffices to find a hub u
with s->u->t and u neither c nor reachable from c in one actual arrow. The
message can then move to u safely and reaches t on the next move before the
cop's next response. The case c=t is included throughout.

First check the internal hub core. For a missing internal pair define
D=F^+(s) union F^-(t), where F is the missing graph. It has two vertices in
each hub part. A cop in the same part as s has both its missing outneighbors
in D only if c=s. A cop in the other part has an adjacent pair opposed to a
pair of difference two, so its two missing outneighbors cannot both belong
to D. These statements use k>=5; the potential coincidence for very short
cycles is excluded. A member of F^+(c) outside D is a safe intermediate.
The endpoints s,t already lie in D, since (s,t) is a missing arrow.

There are three remaining nondirect configurations.

1. Both endpoints outside. For an outside cop, inclusion-incomparable codes
   give u in K_c minus K_s. All hubs reach t. For a hub cop, its missing
   outneighbors cannot both lie in K_s: the P-cop pair is adjacent in L,
   and the L-cop pair has difference two in P, precisely the restrictions
   imposed on the two code families.

2. Source s outside and recipient t a hub. Missingness means t in K_s.
   For an outside cop with a code in the same part, choose u in K_c minus
   K_s and use the clique in that part. For a code in the other part,
   K_c is disjoint from K_s and has at least three vertices, whereas at
   most two are missing predecessors of t; choose any of the others.
   For a hub cop whose missing neighbors lie in the part containing t,
   the code-independence condition leaves one outside K_s, and the clique
   supplies its arrow to t. For the other hub-cop part, all missing
   neighbors are accessible from s; the cop's adjacent or difference-two
   pair cannot equal the opposite kind of missing predecessor pair of t.

3. Both endpoints hubs and cop outside. The danger set D from the internal
   argument has only two members in either part. The code K_c has at least
   three, so a member outside D is safe. An internal cop was handled by
   the core argument.

A hub source and outside recipient are already directly adjacent. Optional
outside arrows never invalidate the above witnesses because intermediates
are hubs and all arrows incident to a hub remain fixed.

## An explicit logarithmic parameter sequence, valid at every n>=30

For even d>=2 put k=7d+1 and r=2d. Choose the least even d for which

    2 C(7d+1,2d) >= n.

This is stronger than the required capacity n-2k. Its hub set fits whenever
n>=30. Indeed d=2 gives 2k=30. If d>=4, minimality gives

    n > 2 C(7d-13,2d-4)
      >= 2 binom(5(d-2),2(d-2))
      >= 5(d-2)(5(d-2)-1)
      >= 14d+2 = 2k.

The middle binomial inequality follows from unimodality, since
2<=2(d-2)<=5(d-2)/2. The final elementary quadratic inequality holds for
d>=4. Thus the construction is valid for every n>=30, with exact base

    A = (26d+4)n - 2(7d+1)(12d+5).

The explicit upper endpoint remains A+(n-14d-2)(n-14d-3). No asymptotic
qualification is needed for these integer formulas.

For a simple asymptotic interpretation, the binomial distribution with
5d trials and success probability 2/5 has mode 2d. Its modal probability
is at least 1/(5d+1), giving

    C(7d+1,2d) >= binom(5d,2d)
      >= (3125/108)^d/(5d+1).

Consequently the least even d above is at most

    log(n)/log(3125/108) + O(log log n).

It follows that

    q_2(n) <= (26 log(2)/log(3125/108) + o(1)) n log_2 n
           = (5.3555763082... + o(1)) n log_2 n.

This is a fully deterministic family. The chosen k is O(log n), so even
enumerating all 2^k hub subsets and retaining the first q valid codes takes
polynomial time in n. The proof also retains an entire exact-budget interval
and arbitrary exterior subsets; it does not assert that every sparse budget
below its base has a two-move realization.

## Finite bridge to the protected-run envelopes

`src/routing_defect_phase2_code_overlap.py` checks every n=100,...,391 using
integer arithmetic. For each n it tries valid code parameters and explicit
translations of the independent-run set from the current protected-circle
argument. Each newly best resulting envelope is directly checked to have
exactly one ordered realization of each protected difference. The code
upper endpoint is also checked against the established dense envelope
h<=n ceil((n-1)/13).

Result: every n=118,...,391 passes. n=115 also passes: k=11,r=4 gives
A=4138, while h=39 and run translation 2 gives capacity 4140. n=116 and
117 do not pass this particular family of run certificates. The n=116
shortfall is two arrows. This is not an impossibility result.

The receipt is `research/routing-defect-phase2-code-overlap-checks.json`.
It supports a finite bridge, conditional on the ordinary core-code,
protected-circle and dense-envelope theorems. It is not a pursuit-game
search or a formal proof of those prerequisite theorems.

The two uncovered orders are now filled by explicit finite constructions.
At n=116 use k=11, two allowed size-five codes, and 92 allowed size-four
codes contained in neither. There are initially 110 size-four codes;
the two larger codes exclude at most ten, leaving at least 100. Thus the
94 chosen codes form an antichain and have W=378. Their base has A=4176
arrows, exactly the protected-run capacity already verified at this order.
The explicit list, selected lexicographically, is saved in
`research/routing-defect-phase2-mixed-code-checks.json`. A separate direct
bitmask calculation checks all 1,053,860 missing-pair/cop triples against
the full optional-cop envelope. Its terminal missing count is 422, below
the dense-envelope endpoint 1044.

At n=117 take a=20,h=41 and

    A_circle = {0,1,20} union [41,59] union [100,115].

It has 38 elements. Each of the six protected ordered differences occurs
exactly once, as checked directly in the same receipt. Its capacity is
117*37=4329, exceeding the fixed-size code base 4218. These constructions
were found after the first run scan; its recorded failures remain failures
of that particular run family, not current gaps in the bridge.

For the unbounded continuation, n=391,...,699 is already covered by the
following simple parameters and the old protected endpoint
T=n(ceil(n/7)-1): k=15,r=4 for n<=480, and k=17,r=5 for 481<=n<=699.
The inequalities A<=T follow directly, even using ceil(n/7)>=n/7; the
quadratic differences are positive at the left endpoints and increasing.
The code capacities suffice and the terminal missing counts fit the dense
envelope. For n>=700, take r=3 and an odd k with

    (6n)^(1/3)+5 <= k < (6n)^(1/3)+7.

Then C(k,3)=k(k-4)(k-5)/6>=n. Also

    A < 4kn < 4n((6n)^(1/3)+7) <= n^2/7-n <= T.

For the penultimate inequality use
n/7>=4(6n)^(1/3)+29: at n=700 the cube root is below 17, and the difference
is increasing thereafter. The core has fewer than n vertices, and the
terminal missing count is 3n-2k, inside [2n,3n]. Thus the finite bridge has
an ordinary unbounded continuation. A full main-interval onset at 118
would additionally require the separately developed sparse bridge to hold
from that order. With the two additional explicit constructions, the
code/protected/dense bridge in fact starts at n=115. Consequently a fully
explicit main-interval theorem for every n>=115 follows as soon as the
separate sparse bridge at n>=115 has passed its independent audit. This
note does not assume that outstanding audit complete.

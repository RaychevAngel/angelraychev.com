# Independent audit of the combined joint classification

**Updated final range:** Proposition 51 and Theorem 52, combined with
Theorems 38, 48 and 50, lower the host threshold
to `N>=1800`, and the independently replayed finite odd bridge lowers
the uniform budget threshold to `m>=24` (even budgets start at 24,
odd budgets at 25). The intervening host thresholds `2419`, `5442` and the
historical audit below using `10^12` and 289 are superseded;
its piecewise algebra and endpoint checks remain unchanged.

The revised host threshold is independently checked in
`research/six-type-packed-holes-independent-audit.md` and
`research/exact-budget-mode-bound-independent-audit.md`. The revised odd support
threshold is independently checked in
`research/odd-endpoint-finite-independent-audit.md`. For odd
`m=2k+1>=25`, use the now proved support size `k+1>=13`, which fits
exactly when `m<=2N-1`. The even support argument still uses `k>=12`.
Thus the final piecewise formula covers every budget at least 24 on
every host of order at least 1800, without making a claim about
smaller budgets or all smaller host orders.

This is an ordinary deduction audit, not a new search or formalization.
The finite-certificate dependencies of Theorems 40 and 45 and the
structural bridge in the dense construction remain part of the result.

Let `N>=10^12` be the host order and write `L=N(N-1)`.
For every integer `289<=m<=L`, the proposed piecewise formula is
consistent and follows from the stated results:

- If `m=2k<=2N`, the value is `k(k-3)`.
- If `m=2k+1<=2N-1`, the value is `k(k-3)+2`.
- If `2N<=m<=N(N-3)`, the value is `L-m`.
- If `m=N(N-3)+r` with `1<=r<=N`, the value is
  `2N-r-ceil(r/2)-1`.
- If `N(N-2)<m<=L`, the value is zero.

## Sparse supports and isolate padding

For even budgets `m=2k>=24`, Theorem 40 provides an extremizer on
`k>=12` vertices, with exactly `2k` arcs and `k(k-3)` indirect pairs.
Whenever `m<=2N`, its support fits inside the host. Add `N-k` isolates.
For odd `m=2k+1>=289`, Theorem 45 provides an extremizer on
`k+1>=145` vertices, with `(k-1)(k-2)=k(k-3)+2` indirect pairs.
The condition `m<=2N-1` is exactly `k+1<=N`.

Isolate padding preserves the indirect count exactly. A pair involving
an isolate cannot deliver unless source and recipient coincide, and
diagonal pairs are not counted. A pair in the original graph that was
losing stays losing because the pursuer retains its original strategy.
For a winning pair, internal cop starts retain the original winning
strategy. A cop starting in an isolate remains there; the original
winning guarantee in particular implies that a directed delivery path
exists inside the old graph, so that path now succeeds without any
collision. Thus no old winning pair is lost and no new one is created.

The order-free arc upper bounds give the matching upper bounds for
the fixed host as well. In particular, every even budget starting at
24 is covered by this argument, including those below 289; the concise
combined statement starts at 289 to have one uniform lower threshold
covering both parities. It does not silently settle smaller odd budgets.

## Remaining pieces and endpoints

Theorem 44 covers the entire main interval. Corollary 33 covers the
final dense band because `N>=10^12` implies `N>=75`. The proved zero
criterion covers all denser graphs.

At `m=2N`, the even sparse value and the main value are both
`N(N-3)`. At `m=N(N-3)`, the main value is `2N`; the dense staircase
starts with `2N-3` at the next budget, as intended. At its last point
`m=N(N-2)`, the value is
`N-ceil(N/2)-1=floor((N-2)/2)`. It drops to zero at the next budget,
as independently required by the zero theorem. These jumps do not
indicate omitted budgets or a continuity assumption.

All intervals are intervals of integer arc budgets. They cover every
integer from 289 through `L`, with only the harmless shared endpoint
`m=2N`. No monotonicity of `M(N,m)` is used.

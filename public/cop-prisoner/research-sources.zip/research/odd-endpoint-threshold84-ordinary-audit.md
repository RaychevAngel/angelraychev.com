# Independent audit of the exact 23-arc endpoint

**Result:** the ordinary reduction below, the previously audited
eleven-vertex core bounds, and the three completed cutoff-84 enumerations
give `M_E(23) <= 83`. The independently certified 83-pair witness therefore
gives **`M_E(23) = 83`**.

This is an independent mathematical and source review, including inspection
of the complete receipts. It is not a second implementation or repetition
of the three new enumerations, and it adds no Lean coverage. No search was
run for this audit.

## 1. Active sets and two elementary obstructions

Let `A={s:d+(s)>=2}`, `B={t:d-(t)>=2}`, and write
`q=|A|`, `r=|B|`, `b=|A∩B|`, `e=e(A,B)`. With 23 arcs,

```
q,r <= 11,
e >= max(0,2q+2r-23),
I <= qr-b-e.
```

Every counted pair belongs to `A×B`; the last expression excludes its
diagonals and direct arcs.

If an indegree-two recipient `t` has an indegree-zero predecessor `z`, its
column contributes zero indirect guarantees. An indirect source is
neither `z` nor the other predecessor `p`; the messenger cannot enter `z`,
and a pursuer waiting at `p` blocks every possible arrival at `t`.

Separately, if an outdegree-two source `s` has an outdegree-zero successor
`z`, its row contributes zero indirect guarantees. A pursuer at the other
successor blocks that exit, while entering `z` traps the messenger away
from every indirect recipient. Waiting forever does not deliver. This
argument does not assume that reversing the directed graph preserves the
game.

When `r=11`, the exact one-unit budget identity is

```
sum_{t in B}(d-(t)-2) + sum_{t outside B}d-(t) = 1.
```

At most one vertex outside `B` has positive indegree. Every indegree-zero
vertex of `A` has a successor in `B` of indegree two: its at least two
distinct successors cannot both be the sole possible indegree-three
vertex, and the alternative allowance permits only one arc ending outside
`B`. Such a successor gives a zero column. Three indegree-zero vertices of
`A` force at least two such columns: their at least six outgoing arcs
cannot all enter one indegree-two vertex together with either the possible
indegree-three vertex (capacity five), or the possible single arc outside
`B` (capacity three).

The outgoing version of this identity when `q=11` gives the corresponding
zero-row statements.

## 2. Active sizes other than (11,11)

If `q,r<=10`, the elementary bound is at most 83. If either is at most
nine, it is at most 82. These statements follow directly from
`qr-max(0,2q+2r-23)` on the indicated integer ranges. Thus only `(10,11)`,
`(11,10)` and `(11,11)` can have `I>=84`.

Suppose `(q,r)=(10,11)`. Then `e>=19` and `I<=91-b`.

* For `b>=8`, this is at most 83.
* For `1<=b<=7`, `A\B` contains at least three vertices and at most one
  has positive indegree. There is therefore an indegree-two zero column.
  Deleting it leaves 100 positions, at least `19-2=17` direct arcs, and
  at least `b-1` diagonals. Consequently
  `I<=100-17-(b-1)=84-b<=83`.
* For `b=0`, there are at least nine indegree-zero vertices in `A`, so
  certainly at least two indegree-two zero columns. Deleting two gives
  `I<=10*9-(19-4)=75`.

The separately proved zero-row argument gives precisely the same bounds
for `(q,r)=(11,10)`. Hence these active sizes cannot have `I>=84`.

## 3. Both active sizes eleven, overlap at most nine

Now `e>=21`. If `b<=7`, at least three vertices of `A\B` have indegree
zero, yielding two indegree-two zero columns. Removing them gives
`I<=11*9-(21-4)=82`, even without excluding diagonals.

If `b=8` or `b=9`, both `A\B` and `B\A` contain at least two vertices.
At least one vertex of the former has indegree zero, and at least one
vertex of the latter has outdegree zero. Thus there is simultaneously
an indegree-two zero column and an outdegree-two zero row. Removing both
leaves 100 positions, at least `21-2-2=17` direct arcs, and at least
`b-2` diagonals. Therefore

```
I <= 100-17-(b-2) = 85-b,
```

which is 77 for `b=8` and 76 for `b=9`. The row and column may have the
same vertex label; the bounds remain valid, since we only overestimate
how many direct pairs or diagonals were deleted. Both obstructions hold
independently against arbitrary strategies, so they can be removed
simultaneously.

## 4. Overlap ten: exactly the two distinct-exception classes

Write `A\B={v}` and `B\A={u}`. If `d-(v)=0`, a zero column gives
`I<=110-(21-2)-(10-1)=82`. If `d+(u)=0`, the zero-row argument gives the
same bound. Thus `I>=84` forces `d-(v)=d+(u)=1`.

These two degrees exhaust the entire incoming allowance outside `B` and
outgoing allowance outside `A`. All outdegrees in `A` and indegrees in
`B` equal two, and every other vertex is isolated. The support is exactly
twelve vertices. The exceptional arc `u->v` is either absent or present.
The eligible missing-pair counts are respectively

```
121-10-21 = 90,       121-10-22 = 89.
```

These are modes 0 and 1 of the cutoff enumerator.

## 5. Overlap eleven: common active set and every outside case

Put `A=B=C`, with `|C|=11`. At most one arc starts outside `C` and at
most one arc ends outside `C`. The previously completed and independently
audited core results give `I<=81` for every eleven-vertex graph with
22 or 23 arcs.

If all 23 arcs are internal, use that core bound. If an arc has both
endpoints outside `C`, it consumes both allowances; all other 22 arcs
form a two-regular core. A messenger starting in `C` cannot leave it,
and all losing pursuer strategies confined to that core remain available.
Thus this case also has `I<=81`.

Suppose exactly one crossing arc exists, first `a->x` with `a∈C` and
`x∉C`. There are no arcs starting outside, so `x` is a sink. The internal
indegrees are all two. If `a` has outdegree three in the full graph,
deleting the crossing arc leaves a two-regular 22-arc core, giving
`I<=81`: exiting to a sink cannot rescue any lost delivery to `C`, and
the pursuer can use its losing core strategy until such an exit. If
`a` has outdegree two, its row is zero; there are 88 eligible internal
missing pairs, and nine belong to this row, giving `I<=79`.

For a single incoming crossing `y->t`, the source `y` has indegree zero
and is inaccessible from `C`. If `t` has indegree three, deleting the
crossing gives the same 22-arc core, with `I<=81`; if it has indegree two,
its zero column contains nine of the 88 eligible missing pairs, giving
`I<=79`. These are direct reachability/strategy arguments, not reversal
of the game.

Finally suppose both crossings occur: `a->x` and `y->t`. All full-graph
degrees of vertices of `C` are two, and there are 21 internal arcs, hence
89 eligible internal missing pairs. If `x!=y`, then `x` is a sink; the
outdegree-two source `a` has only one internal successor, so its zero row
contains nine eligible pairs. This gives `I<=80`. If `x=y`, it is the
unique nonisolated vertex outside `C`, of indegree and outdegree one.
This is exactly mode 2, the third twelve-vertex class, with 89 eligible
missing pairs.

These cases exhaust both outside allowances. Therefore **every graph
with 23 arcs and `I>=84`, after deletion of isolates, belongs to one of
the three enumerated classes**.

## 6. Source and completed-receipt audit at cutoff 84

The source `src/odd_endpoint_near23_threshold.cpp` differs from the
previously audited enumerator only by choosing default cutoff 84 and
accepting a validated cutoff parameter at least 84. Its three factorization
normal forms cover the required classes: add the missing exceptional arc,
add a parallel copy if it already exists, or add a dummy loop at the common
exceptional vertex, then factor the resulting two-regular bipartite
multigraph into two matchings. The added arc is placed in the first factor
and is omitted from the actual graph. The distinguished first-factor
cycle and the partition of all remaining cycles give complete
representatives. Parallel factors are permitted only for the exceptional
arc in mode 1; the dummy loop is confined to mode 2.

Every row or predecessor column used as the obstructed set is complete;
the covering pursuer row may be partial because coverage persists when
more arcs are added. Source camping loses at least eight eligible pairs.
Recipient camping loses at least seven, even after removing the pursuer
vertex itself from the possible sources. Since no class has more than
90 eligible pairs, either prune proves `I<=83` and is sound at cutoff 84.

The exact game loop includes waiting, universally quantifies over the
pursuer's closed outneighborhood, gives delivery terminal priority, and
removes nonterminal collisions. Starting from the recipient terminal set,
its least fixed point gives precisely finite winning strategies. The
count starts at 90 or 89 and subtracts failed pairs from active sources to
active recipients. Direct and diagonal pairs are automatic successes and
cannot be subtracted. Early exit after potential drops below 84 is safe;
its returned value need not be the exact score of the leaf.

All three new receipts are complete, target 84, and report no value at
least that threshold:

| Class | Partitions | Nodes | Camping-free leaves | Seconds |
|---|---:|---:|---:|---:|
| Distinct, absent | 42 | 164,276,910 | 16,902,091 | 45.49 |
| Distinct, present | 42 | 13,448,216 | 1,125,588 | 2.52 |
| Common exception | 14 | 49,814,092 | 3,558,672 | 8.12 |

Receipts are `research/odd-endpoint-threshold84-absent.json`,
`research/odd-endpoint-threshold84-present.json`, and
`research/odd-endpoint-threshold84-same.json`. The normal forms, pruning,
game evaluation, and complete receipts therefore establish the upper bound
83. The existing witness in
`research/odd-endpoint-m23-lower-certificate.json.gz` was checked by both
game solvers and direct rank conditions and supplies the matching lower
bound. No new numerical extrapolation or uncompleted search is used.

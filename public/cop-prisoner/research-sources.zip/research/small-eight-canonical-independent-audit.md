# Independent completeness audit of the eight-vertex enumeration

## Scope and conclusion

The canonical row enumeration and every pruning rule in
`src/small_exceptional_canonical.cpp` are sound. Its completed saved
run excludes `I>=33` for every eight-vertex graph in the only necessary
arc range `16..23`. Together with the previously rank-verified
32-pair witness, this establishes `M_V(8)=32`, subject to the stated
finite exhaustive-computation evidence boundary. This is not Lean
verification or a claim that the much larger orders have been
enumerated.

The independently ordered implementation
`src/small_exceptional_canonical_independent.cpp` was also source-audited.
It uses descending degrees, suffix selection and an explicit two-turn
attractor, rather than the primary prefix selection and compressed
synchronous game iteration. Its complete execution receipts are owned
by the construction-audit task; this note does not claim their
completion before those receipts are present.

## Why the arc range and degree profiles suffice

With at least 24 arcs there are at most `56-24=32` missing ordered
pairs. At at most 15 arcs, the order-free bound at 15 gives at most
30 indirect pairs; lower budgets cannot improve it, since disjoint
one-way-edge padding preserves all existing guarantees and shows
monotonicity of the arc-only maximum. Thus any counterexample has
`16<=m<=23`.

A counted source has outdegree at least two and contributes at most
`8-3=5` missing pairs. Reaching 33 requires at least seven such sources.
Any graph can be relabeled in nondecreasing outdegree order, with at
most the first degree below two. The degree recursion enumerates all
such sorted integer profiles with the stated total. The analogous
descending enumeration puts the seven required active sources first.
No degree profile is omitted by these ordering conventions.

## Proof of canonical completeness

Suppose rows `0..r-1` have been fixed, and row `r` is next. Consider
any contiguous run of future vertices `r+1..n-1` that have equal
prescribed outdegree and equal incoming bit patterns from the fixed
rows. Any permutation within this run, fixing all other vertices,
leaves each completed outgoing row unchanged: its membership bit is
constant on the run. The permutation also preserves the prescribed
future outdegrees. It therefore preserves all decisions already made
by the recursion.

For the next row, choose such a permutation that puts its neighbors
first inside the run. This makes the new row's membership bits a
prefix of ones followed by zeros, exactly the primary adjacent-bit
test. The current vertex `r` is excluded from these permutations,
so its row and the forbidden diagonal have the intended interpretation.
Applying this choice in every run gives an allowed representative of
any continuation. Repeating the argument row by row proves every
isomorphism class has a representative accepted by the recursion.

The equal-key vertices need not form one contiguous run. Treating two
separated runs as different cells permits more representatives; it
does not exclude any. The proof uses only permutations inside each
actual tested run. The independent implementation instead moves the
neighbors to the end of each run, and the same proof gives its suffix
condition.

As a bounded corroboration, this auditor independently implemented the
successive relabeling argument on all **4,096** labeled loopless graphs
of order four, in both ascending/prefix and descending/suffix forms.
All **8,192** constructed representatives satisfied every recursive
condition, retained the prescribed degrees, preserved completed rows,
and were explicitly checked to be relabelings of the input graph.
The ordinary argument, not this small test, proves arbitrary-order
completeness.

## Pruning rules

Write `O_s` for a completed open outgoing neighborhood and `C_c` for
the completed closed outgoing neighborhood of another vertex.
If `O_s` is contained in `C_c`, all indirect pairs from `s` fail:
the pursuer waits at `c` and intercepts the first nonterminal departure.
At a partial assignment this test uses only completed source and cop
rows, so the obstruction cannot disappear in any continuation.
Every other source of prescribed degree `d>=2` contributes at most
`n-1-d`, regardless of its future row choice. Adding these bounds is
therefore a valid partial source upper bound.

For a target with current indegree `d`, at most
`n-row-1_{target>=row}` remaining rows can add an incoming arc. The
subtracted term excludes its own still-unassigned loop. If even this
cannot raise indegree to two, its contribution is zero. Otherwise
its eventual contribution is at most `n-1-max(2,d)`, since incoming
degree only increases. This is a valid independent column upper bound.

The degree-total recursion rejects only profiles whose least possible
completion already exceeds the maximum budget or whose greatest
possible completion cannot reach the minimum budget. All such bounds
are overestimates of admissible completions and cannot lose a graph.

At complete graphs, a missing pair `(s,t)` also fails if every
predecessor of `t` belongs to some `C_c` with `c!=s`: camping at `c`
intercepts the first predecessor entered. Because `(s,t)` is missing,
the source is not itself such a predecessor. Receipt priority is
therefore respected. This and the source obstruction produce the
static count used before an exact game evaluation. It is only an upper
bound, and is never treated as a sufficient winning condition.

## Exact game evaluation and saved result

The primary game routine starts from recipient states only and
iterates the monotone least reachability attractor. Waiting is included
in both closed move sets, nonterminal collision is removed, and the
target row remains terminally winning. Its universal test over the
pursuer's successors is exactly the original game quantifier. Starting
from the least terminal seed ensures finite delivery, not merely
indefinite evasion. The independent queue implementation reconstructs
the explicit alternating state graph with the same terminal priorities.

The completed primary receipt
`research/small-exceptional-canonical-8.json` reports 178 degree
profiles, 946,676,955 recursion nodes, 22,465,453 complete leaves and
373 graphs passing the static bound. Exact game evaluation rejects all
373 as candidates for `I>=33`. Its reported `best_I=17` refers only
to that statically surviving subset; it is **not** a proposed global
maximum. The genuine lower witness has 24 arcs and is intentionally
outside this counterexample search interval.

The run's `complete=true` and `counterexample_found=false` fields show
the wall-time exit was not taken. The combination of complete search,
ordinary symmetry/pruning arguments and the separate lower witness
is the claimed finite computer-assisted proof.

# Full-density attainment conjecture and a proved interval

## Scope and provenance

Angel proposed the stronger conjecture that, for every sufficiently large n,
every integer budget 2n <= m <= n(n-3) attains the missing-pair bound
M(n,m)=n(n-1)-m. His point is about the large-order regime; the six-vertex
nonmonotonicity example does not argue against that conjecture. He also
proposed prioritizing attaining constructions and understanding the last
dense band through the missing pairs destroyed by domination.

The deductions below were developed during this bounded discussion and
independently checked by a second agent. They are ordinary proofs, not new
Lean theorems. No large computational search was launched. The current
website/PDF checkpoint predates these deductions.

## Exact-budget probabilistic lemma

Let n>=4, L=n(n-1), 0<m<L, and p=m/L. If

    (n-3) p^2 (1-p) > 5 log n,

then there is a loopless digraph on n vertices and exactly m arcs in which
every source-recipient pair is guaranteed within two messenger moves.
Consequently M(n,m)=L-m.

**Proof.** Include each nonloop directed arc independently with probability
p. Fix distinct s,t and an initial pursuer c!=s. Each vertex u outside
{s,t,c} is a safe two-move intermediary if s->u and u->t are present and
c->u is absent. These are three distinct arcs, even when c=t, so their
joint probability is p^2(1-p). Different candidates u use disjoint arcs;
their success events are independent. At least n-3 candidates are available.
The chance of no safe intermediary is at most
exp(-(n-3)p^2(1-p)). A union bound over fewer than n^3 triples gives failure
probability less than n^-2 under the displayed hypothesis. A graph with a
safe intermediary for every triple certainly guarantees every pair;
the test is stronger than necessary for pairs already joined by an arc.

The arc count has distribution Bin(L,p). Since p=m/L, m is a mode. For
example, the successive probability ratio is
(L-j)p/((j+1)(1-p)), which is above one at j=m-1 and below one at j=m.
Its probability is therefore at least 1/(L+1), the reciprocal of the
number of possible arc counts. Since L+1<n^2, this is greater than n^-2.
Thus the bad-graph probability is smaller than the probability of exactly
m arcs, and at least one good graph has exactly m arcs. The safe intermediary
is not occupied by, or accessible in one move from, the pursuer. After
surviving that response, the messenger reaches t with immediate receipt.
Subtracting diagonal and direct pairs gives I=L-m. QED.

This is an exact integer-budget existence theorem, not a graph with merely
the correct expected number of arcs. For fixed n,m satisfying the test,
repeatedly sampling uniform m-arc graphs and checking the two-move condition
is a randomized search with positive success probability. No practical
running-time claim near the threshold is made here.

## Combining sparse random graphs with the dense complement interval

**Theorem.** There is an absolute N such that for every n>=N and every
integer m satisfying

    ceil(10 n^(3/2) sqrt(log n)) <= m <= n(n-3),

we have M(n,m)=n(n-1)-m. All pairs can be delivered in at most two moves.

**Proof.** Let h=L-m and p=m/L. For n>=6, n-3>=n/2.
If p<=1/2, the lower bound on m gives p>=10 sqrt(log n/n), whence

    (n-3)p^2(1-p) >= 25 log n > 5 log n.

If p>=1/2 and h>=100 n log n, then 1-p=h/L>=100 log n/n, whence

    (n-3)p^2(1-p) >= (100/8) log n > 5 log n.

The exact-budget lemma covers both cases.

The existing high-girth complement theorem (paper/dense-extensions.md,
Theorem 20) covers every integer h from 2n through L_D(n), where
D=floor((n/2)^(1/4)). For sufficiently large n it applies and gives

    L_D(n) >= n(D/4+1)-1.

Because D grows as a positive constant times n^(1/4), this upper endpoint
eventually exceeds 100 n log n. Thus the dense construction covers every
remaining h between 2n and the probabilistic range. These intervals overlap,
so no integer budget is skipped. Both constructions use two-move strategies.
QED.

The unspecified N can be very large with these conservative estimates.
This theorem is not a claim of complete interval coverage at n=52 or any
other moderately sized order. The lower constant 10 is unoptimized.
The sparse interval from 2n to order n^(3/2)sqrt(log n) remains open in
general, including its two-regular endpoint.

## The final dense band in missing-arc coordinates

Let F be the loopless directed complement, h=|E(F)|, and
q(v)=d_F^+(v), the number of absent outgoing arcs at v.

If q(c)=0, then I(G)=0. Indeed, the pursuer can start at c and intercept
every nonterminal departure from any other source; source c has no missing
recipient to contribute. Hence I>0 implies q(v)>=1 for every v.

For n<=h<2n and I>0, at least 2n-h vertices have q(c)=1. If there are l
such vertices, h>=l+2(n-l)=2n-l.

If q(c)=1 with unique missing neighbor x, then C_G(c)=V\{x}. Therefore
no missing pair with source x is guaranteed: the pursuer at c waits while
the messenger stays at x and captures any nonterminal departure. This
eliminates all q(x) missing pairs from source x, not merely c->x.

Let U be the set of distinct unique missing neighbors of the q=1 vertices.
The resulting quantitative bound, with duplicate images counted once, is

    I(G) <= h - sum_{x in U} q(x).

Moreover, for a missing pair (s,t) and such a c!=s, a necessary condition
against the stationary pursuer at c is

    x notin {s,t}, and s->x and x->t are arcs of G.

The only possible safe internal vertex is x; successful delivery must pass
through it in two moves, possibly interspersed with waits. This connects
the local defect to both source and recipient. It is not asserted sufficient
against a moving pursuer or all other initial positions.

**Corollary.** For n>=2 and n<=h<2n with h<=n(n-1),

    M(n,n(n-1)-h) <= h-2.

**Proof.** If I=0 the bound holds since h>=2. Otherwise some q(c)=1;
write its missing neighbor as x. If q(x)>=2, the destroyed source row
already contains at least two missing pairs. If q(x)=1 with missing neighbor
y, then y!=x and both source rows x,y are destroyed. Each contains at least
one missing pair, since all q are positive. In either case at least two
of the h missing pairs fail. QED.

No sharpness claim is made for this dense-band bound. Determining how these
forced source losses and further target-specific obstructions overlap is
an open part of the extremal classification.

## Next priorities

1. Treat Angel's full large-order interval statement as the main joint
   conjecture, with the new proved interval distinguished from it.
2. Seek universal constructions filling sparse and intermediate budgets;
   avoid assuming arbitrary edge additions preserve universality.
3. Use exact verification of candidate graphs at selected large n,m,
   rather than exhaustive extremal enumeration, for empirical guidance.
4. For n<h<2n missing arcs, optimize the forced losses from q=1 vertices
   together with their source-recipient constraints.

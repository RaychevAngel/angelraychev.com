# Proposed exact twenty-one-arrow maximum60

13 September 2026. Complete primary proof package, pending independent
review. Proposed conclusions are M_E(21)=60, M(n,21)=60 for all n>=12,
M(10,21)=56 and M(11,21)=58. Every upper run used by this package is complete.

## Dependencies and source/sink removal

The global20-arrow value53 has now passed independent whole-implication
review in research/finish-sparse-review.md/json. The new proposed global
19-arrow upper49 is proved in sparse_finish_nineteen49_proof.md, including
its two completed residual finite exclusions and the retained ME17<=41.
The retained ME18<=44 is used for the smaller-host refinement below.

For any indegree-zero source v with other degree d, old guarantees are
bounded by G-v, while its row contributes at most the number of live
recipient columns. Each such column needs two predecessors of positive
indegree, supplied by at most m-d arrows. Thus

    I(G)<=ME(m-d)+floor((m-d)/2).

The separate sink argument counts two nonsink successors per live row.
For d=1 the extra row/column contributes0. All claims concern the actual
directed game; no graph reversal or arbitrary vertex contraction is used.

At m21, d1 gives at most ME20=53. If d>=2, harmless-sink monotonicity and
the proposed ME19<=49 give at most49+floor(19/2)=58. Thus every graph
with a nonisolated zero-indegree or zero-outdegree vertex scores at most58,
regardless of host order. Isolates may be deleted first.

## All positive-degree support sizes

Let q,r count active outdegree>=2 and indegree>=2 vertices, and b their
overlap. At positive support n, the degree sums give q,r<=min(10,21-n).
The eligible rectangle has size at most

    qr-max(0,q+r-n)-max(0,2q+2r-21).

For n>=13 this is at most53, since q,r<=8. At n12, q,r<=9 and the maximum
is60, at q=r9,b=6. These are finite elementary integer inequalities, not
graph enumerations. For n<=9 the ordinary missing-pair count is at most51.
It remains to handle positive supports10 and11.

When all degrees are positive, the exact outgoing and incoming surpluses
are x=21-n-q and y=21-n-r. Hence

    e(A,B)=q+r+21-2n+w,

where w counts arrows from outside A to outside B.

### Eleven vertices

Here q,r<=10. If both counts are at most9, the eligible rectangle is at
most57; if one is at most8 the bound is at most56 even when the other is10.
The remaining possibilities are q=r10 and (q,r)=(9,10),(10,9).

At q=r10, every degree is one or two, with one low-in and one low-out
vertex. Its eligible cap is71 or72. The complete perfect-matching plus
ten-edge-matching enumeration retains every overlap, every permissible
camping-loss union and every residual injection. It proves upper56.
Source/result: sparse_finish_twentyone_one_defect_loss.cpp and
sparse_finish_twentyone_one_defect_loss_11_21.json. Completion covers14
cycle types,330 patterns,40933974 nodes and269146 actual-game decisions;
none exceeds56. Runtime27.527 seconds.

At q=9,r=10, there is one outdegree-three vertex, two outdegree-one
vertices, and one indegree-one vertex; all other degrees are2. The low-in
vertex can occupy the high-out, normal-out or low-out class, yielding three
joint degree-pair multisets. The separate incoming family gives three more.
Their eligible bound is at most64. The existing generator also lists five
q=r9 multisets, which are skipped immediately by their bound at most57.

The complete threshold58 direct row enumeration covers all eleven listed
multisets, including those five arithmetic skips. Future vertices with
equal joint degrees and identical incoming prefix are interchangeable;
each outgoing subset selects every possible count and a canonical prefix
in each class. This is the same prefix-symmetry mechanism accepted in the
20-arrow review, without a perfect-matching assumption.

Any source camping obstruction in these six relevant families loses at
least6 eligible pairs. A predecessor camping obstruction can lose only5
after its initial-source/cop exception. A score above58 can permit5 losses,
so the source retains camping patterns whenever their union of certified
failures still permits the target. Every complete row/column used by the
obstruction is fixed; the initial-source exception, diagonals and direct
arrows are excluded from the counted losses. The optimistic guarded-path
bound uses only fixed cop arrows and all possible messenger arrows, counts
failure unions, and handles initial entry and actual receipt separately.
Every surviving complete graph is evaluated in the actual game.

Source/result: sparse_finish_twentyone_residual_ranges.cpp and
sparse_finish_twentyone_residual_11_21_threshold58.json. The completed
range is patterns1..11 of11, with31547001 nodes and89307 actual-game
threshold decisions; none exceeds58. Runtime34.988 seconds. A completed
subset alone would not establish this full family; the receipt explicitly
records requested and completed ranges.

### Ten vertices

If q,r are not both10, the only patterns possibly above56 are q=9,r=10
and its incoming version. The q=r10 family has minimum degree2, with one
outdegree-three and one indegree-three vertex. Its complete Hall-matching
normalization and residual enumeration, retaining permissible camping,
proves upper56:12 cycle types,220 patterns,20436706 nodes and54708 game
decisions,9.997 seconds. Source/result:
sparse_finish_twentyone_one_excess.cpp and
sparse_finish_twentyone_one_excess_10_21.json.

At q=9,r=10 there is one outdegree-one vertex and either one outdegree-four
vertex or two outdegree-three vertices; incoming degrees are2 except for
one degree3. The high-in vertex can occupy each outgoing-degree class.
Together with the separate incoming versions these give12 joint degree-
pair multisets. Their complete direct row enumeration retains camping
losses as a union and proves upper56. It covers793627 nodes and912 game
decisions in1.304 seconds. Source/result:
sparse_finish_twentyone_ten_residual.cpp and
sparse_finish_twentyone_ten_residual_10_21.json.

The other positive-degree q/r combinations have eligible bound at most54.
For zero-degree graphs on at most10 vertices, d1 deletion leaves at most9
vertices with20 arrows, with missing-pair bound52. At d2, the remainder
has at most9 vertices and19 arrows, bounded by49 in the new subsidiary
exclusion; the removed row/column has at most10-1-2=7 missing pairs.
This gives56. At d>=3, the remaining budget is at most18, with global
upper44, and the extra row/column has at most6 pairs, giving50. Thus all
ten-vertex twenty-one-arrow graphs are bounded by56, matching the saved
literal56 witness. This smaller-host conclusion uses the new19-arrow
exclusion, not just the generic source/sink upper58.

## Literal attainers and extension

The eleven-vertex score58 graph in
sparse_finish_twentyone_58_certificate.json matches the new upper58. Both
solvers agree and independent literal-rank replay checks all2662 alternating
states; sparse_finish_twentyone_58_review.json records adjacency SHA256
a649bc68e493fb9c27696738fe9405bdd95667cb9b3829cf474382ddbb816023.
The ten-vertex score56 graph and its2000 checked alternating states are in
sparse_finish_twentyone_56_ten_certificate.json and the matching review JSON.

The following twelve-vertex graph has21 arrows and exactly60 guarantees:

    0: 1,6       1: 2,7       2: 0,8
    3: 4,9       4: 5,10      5: 3,11
    6: 5,9       7: 4,11      8: 3,10
    9: 1         10: 0        11: 2

Both independent game formulations agree. The independent literal-rank
review verifies all3456 alternating-state obligations, including losing
closure, receipt priority and finite winning ranks. Files:
sparse_finish_twentyone_60_certificate.json and
sparse_finish_twentyone_60_review.json. Adjacency SHA256 is
3e093605bfaeec6b9c65bc380de5f59d86fe61549eac8b6418e5c2239bb9c279.
Adding n-12 isolates gives an explicit60 attainer at every n>=12.

All support sizes and zero-degree cases are now bounded by60. The literal
graph therefore matches the proposed global upper and supplies the stated
joint range. The earlier12-vertex discovery run was incomplete and is not
an upper-proof dependency. The ordinary positive-support bound replaces it.

## Remaining verification boundary

Independent review of this complete new implication, the19-arrow upper49,
the threshold-dependent camping allowances and the adapted finite sources
is still required. Every upper receipt used here is complete. Earlier incomplete discovery runs remain excluded from the upper
dependencies; the final threshold58 upper run is complete. No new concrete Lean coverage or canonical publication update
is claimed by this package.

# Literature and submission preparation audit — 18 September 2026

This pass prepares the approved two-author manuscript and preserves the complete classification and its explicit constructions. It is not a new search campaign or an arXiv submission.

Primary references consulted for the introduction:

- Chandra and Stockmeyer, *Alternation*, FOCS 1976, pp.98–108: IBM's publication record, https://research.ibm.com/publications/alternation--1. This is the historical cat-and-mouse antecedent; no equivalence of rule variants is assumed.
- Arefin Huq, *Undirected Cat-and-Mouse is P-complete*, 2015 preprint, https://arxiv.org/html/1511.00984v1. The introduction distinguishes starting turn, waiting, the cat's access to the hole, receipt priority, and fixed-state decision versus the present all-pairs extremal question. The earlier waiting variant and the paper's own variants must not be conflated.
- Bonato and Nowakowski, *The Game of Cops and Robbers on Graphs*, AMS Student Mathematical Library61, 2011. Author's book page: https://math.ryerson.ca/~abonato/copsandrobbers.html. This provides broader pursuit-game context, not a theorem about the present target-delivery game.
- Berwanger, *Graph Games with Perfect Information*, https://lsv.ens-paris-saclay.fr/~dwb/gtc.pdf. Finite reachability attractors and positional strategies are standard; the paper does not claim invention of that machinery.
- Bollobás and Scott, *Separating Systems and Oriented Graphs of Diameter Two*, retained Oxford author manuscript https://people.maths.ox.ac.uk/scott/Papers/diam2.pdf. Used only for the precise two-move separating-system connection already proved in the manuscript and parked timing companion.

The original 2023 abstract and February2024 retained manuscript remain cited. Focused searches found no immediate prior statement of this exact joint extremal formula; this is a bounded comparison, not proof that the literature contains no equivalent result.

arXiv's current submission instructions require TeX source for TeX-generated articles (https://info.arxiv.org/help/submit/index.html). Its moderation guidance (https://info.arxiv.org/help/moderation/index.html) places responsibility with human authors and calls for disclosure of substantial generative assistance. The manuscript has two human authors and explicitly states the assistance and proof-verification boundaries.

Independent proof work this pass:

- A common guide-attachment theorem replaces repeated entry and count arguments across three explicit families; mixed antichain codes are allowed. Concrete constructor replays and a new Lean safe-entry/composition module supplement the ordinary proof. The construction domains and stronger move/subset claims are preserved.
- A shared local simulation, cyclic-window projection and progress theorem replaces repeated sparse-family arguments. Optional edges remain confined to the pursuer envelope; terminal receipt and handoff after the pursuer response are distinguished. Finite certificate premises and crop coverage remain required.
- The two lanes independently reviewed one another. The sparse progress inequality received a bounded arithmetic check; that check is supporting evidence and does not replace the short ordinary proof.
- The expanded Lean development defines the extremal score and maximum specification and proves a general vertex upper bound, certificate interfaces and a tiny complete coverage pilot. It does not turn the large external enumeration into a Lean theorem. Its guarantee predicate uses finite winning trees; soundness for actual play is formal, while the converse from unrestricted eventual strategies remains an ordinary finite-game argument.

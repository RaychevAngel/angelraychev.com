# Independent semantic review of the new main-interval proof infrastructure

13 September 2026. Read-only review; no Lean source was changed and the
compiler was not rerun by this reviewer. The root reports successful
compilation separately.

## Generic Lean statements: passed

Reviewed `lean/RobustLayers.lean` against the definitions and lemmas in
`DeliveryGame.lean`, `SafeBranching.lean`, and `RobustTwoMove.lean`.

* `SourceRanks` requires, for every nonterminal source, either a compulsory
  direct arrow with rank at least one, or a compulsory successor of strictly
  smaller rank against every distinct pursuer position. Safety excludes the
  pursuer's **closed** envelope neighborhood, including waiting.
* `ranked_envelope_universal` uses strong induction on the source rank.
  Compulsory moves are available in the intermediate graph by the lower
  inclusion. The upper inclusion transports closed-envelope safety to that
  graph. `safe_successor` checks both collision immediately after the
  messenger move and collision after every legal pursuer response. Strict
  rank decrease supplies the required finite move bound.
* `ranked_envelope_actual_delivery` invokes the existing concrete-play
  interpretation. It proves delivery against every legal history-dependent
  pursuer policy, with the receiver taking precedence over collision and
  with timeout treated as failure. It does not silently replace finite
  delivery by indefinite evasion.
* `safe_routing_layer` requires every vertex inside the chosen region to be
  universally winning within the supplied bound, and requires safe entry
  from every outside vertex against every distinct pursuer position. It
  concludes a bound larger by one messenger move. The intervening pursuer
  response is included; entry is not treated as an instantaneous transfer.

No global `ClosedOverlapAtMostOne` condition is imported as an implicit
premise of these new lemmas. Only the unrestricted `safe_successor` lemma
is used. Thus the semantic infrastructure applies to the new three-way
circle argument, whose envelope need not satisfy that old overlap bound.

The quantifiers and move counts match the claims in `lean/README.md` and
`paper/main-interval-new-overlap.md`. The source-rank and safe-entry
conditions remain supplied hypotheses. This file does **not** construct
circle ranks, prove modular arithmetic or guide-code conditions, formalize
the new explicit graph families, or establish their extremal values in
Lean. The ordinary family proofs and separate executable checks supply
those concrete obligations outside this generic Lean theorem. The existing
classical selected-move interpretation is not an exported executable
strategy algorithm.

## Final ordinary circle proof: passed

Re-read `paper/main-interval-half-density.md` after the final five-offset
update. Checked the three local escape sets, the integer lift across the
empty interval, seed, all four propagation identities, coprimality-based
coverage, smallest permitted h and n, both envelope counts, parameter rule
at every order divisible by four, and exact-budget optional-arrow rule.

In particular, the gap of h-1 absent offsets prevents a translated escape
set of diameter at most h-1 from wrapping: two resulting representatives
would differ by at least n-h+1, which is too large for [0,n-h]. The full
circle argument uses n divisible by four; the gapped argument uses integer
residues and does not assume that divisibility. The only protected pair
requires deleting 2h-1, so restoring 2h-5 is justified. The five compulsory
offsets are distinct and avoid that deletion at h>=7.

The initial pattern P(-h) has three direct predecessors and one safe-pair
addition. Each new copy of P is obtained by four finite rank increases;
no circular winning-state premise is used. Translation is applied to the
base/envelope witness proof, so arbitrary nonsymmetric optional subsets
are covered. The old eight-offset family is contained in the new robust
family and retains its previous guarantee.

No mathematical defect or correction request was found in this review.

# Six-type sparse construction campaign — 23 October 2026

## Concrete graph and semantic chain

The uniform checkpoint is the actual explicit sparse attainer at every
support order at least 85, with exact even-budget maximum after isolate
padding. The finite support range 13–84 and odd endpoint family remain
separate. No full-classification claim follows from this checkpoint.

The following new source modules compile with Lean 4.33.1, two workers,
and only the standard foundational axioms:

- `SixTypeLocal`: fixed local state types `Fin 54` and `Fin 79`, literal
  smoothed successor formulas, waits, clipped cop replies and the outside
  state. Removed messenger rows collide with every cop state and have no
  moves; checked goals require an existing vertex. This makes the semantic
  embedding total without granting strategies from nonexistent vertices.
- `SixTypeGraph`: the actual cyclic graph on retained `(column,type)`
  vertices. Both successors are retained; the graph is loopless and its
  two outgoing heads are distinct. These facts require no hole-spacing
  premise. The canonical holes are columns `0,3,...,3(r−1)`, `r≤5`.
- `SixTypeProjection`: the concrete `LocalArena.Simulation`, including
  every cop reply, waits, the possible outside hole at column seven, and
  the four outside-entry boundary columns. The full initial-state collision
  equivalence is proved for existing local messenger vertices. The exact
  circumference premise is `k≥15`.
- `SixTypeComposition`: safe one-column transfer followed by terminal
  delivery gives actual winning strategies with bound `9k+18`. Canonical
  crop coverage supplies all parameter cases. The only remaining input to
  this module is the explicit `SixTypeLocal.Certificates` predicate for
  each of the 81 catalog patterns.
- `SixTypeCounts`: a prescribed lexicographic list of retained vertices
  gives an explicit inverse correspondence with `Fin (6k−r)`. The removed
  list has exactly `r` entries, outgoing rows have exactly two arrows, and
  actual universal delivery gives score `n(n−3)`. Taking
  `k=(n+5)/6`, `r=6k−n` proves the conditional `core_exists` for every
  `n≥85` without supplied graph-count or support premises.

The compiled four-module graph/projection/composition/count chain took
under two seconds in its final warning-free replay. This timing excludes
the literal local-certificate family.

`SixTypeConstruction` is the final unconditional wrapper importing
`SixTypeCertificates`: it exposes the delivery-time bound, `core_exists`,
and `maximum_even` for every host order at least the support order, with
support at least 85. At this log entry, that wrapper is written but awaits
the independent certificate batch and aggregate compilation. No successful
wrapper replay is asserted yet.

## Certificate boundary

The immutable source is
`research/sparse-composition-multi-certificates.json.gz`, SHA256
`53daceac01e67909c70c9a06d6390e0858950212d29d66bae70b70d15342fd65`.
`SparseCropCoverage` already proves unbounded coverage of the 81 canonical
patterns and the count of 552 required objectives. That theorem alone
does not verify their strategies. The root lane owns the literal exporter,
shared arenas, 552 objective replays and `SixTypeCertificates.certificates`.
The seven earlier private empty-hole pilots remain distinct from this
complete-family checkpoint.

No frozen historical receipt or certificate was regenerated. No custom
axioms, `sorry`, `native_decide`, or external solver correctness premise is
used in the compiled semantic chain.


## Complete uniform theorem replay

The integrated continuation replay has now accepted all81 literal arena
agreements, all552 objective proofs, the aggregate catalogue, concrete
projection/composition/counts and `SixTypeConstruction.maximum_even`. The
unconditional domain is every host n≥s≥85 at budget2s, with value s(s−3).
Only the standard foundational axioms were reported. The final whole-artifact
receipt and publication remain gated on the other distributed modules.

# Independent review of the new 18- and 20-arrow upper bounds

2026-09-13. Reviewer: the dense research subagent, independently of the
sparse proof/enumerator author. No graph enumeration was rerun for this
review. No sparse source, certificate, manuscript or central ledger was
edited by the reviewer.

## Conclusion

No mathematical or implementation gap was found in the final argument
for M_E(18)<=44 and M_E(20)<=58 in paper/sparse-third.md, or in the
degree-transfer class coverage implemented by
src/sparse_third_one_transfer.cpp and src/sparse_third_transfer_family.cpp.
The earlier arbitrary-degree support reduction was also read, including
its delicate q=r=k-1, b=k-4 case. The finite upper conclusions retain
their computer-assisted enumeration boundary; they are not Lean proofs
or independently re-enumerated upper bounds.

## Degree patterns and original-game reductions

On k vertices with 2k arrows, the active-set count bounds all cases by
T=k^2-5k+8 except (q,r)=(k,k),(k-1,k),(k,k-1). In the full-active case
all degrees are two. In the outgoing-exception case every indegree is
two, while the one exceptional outgoing degree is zero or one. Degree
one gives precisely one outgoing degree-three vertex. Degree zero has
two surplus units: unless an outdegree-two predecessor of the sink gives
a zero row, its two predecessors must be the two degree-three vertices.
Deleting that sink leaves a two-in/two-out core on k-1 vertices. A
messenger delivering elsewhere cannot use the sink. Restricting the cop
to the core therefore justifies the actual-game upper comparison. At
most k-3 additional indirect pairs have the removed sink as recipient.

The incoming-exception case was checked separately. An indegree-zero
source cannot be reached from the remaining core; unless one of its
successors gives a zero column, its two successors are exactly the two
indegree-three vertices, and removal leaves a two-in/two-out core. At
most k-3 additional pairs have the removed vertex as source. This uses
no reversal invariance of the delivery game.

## Eligible camping losses

Either degree-one/degree-three transfer family has
U=k^2-4k+2 eligible missing pairs. Every eligible source row and every
eligible recipient column has at least k-4 such pairs. Source camping
destroys the entire source row. Predecessor camping destroys the whole
eligible column except possibly the one pair whose source is the camping
vertex, because that initial pursuer position is excluded. Thus every
eligible camping obstruction destroys at least k-5 counted candidates,
giving I<=U-(k-5)=T-1. This checks the exact threshold needed to reduce
the remaining upper search to the eligible-camping-free class.

## Perfect matching and normalization coverage

For the outgoing-transfer family, any source set S emits at least
2|S|-1 arrows and every recipient has capacity two. Therefore
2|N(S)|>=2|S|-1, and integrality gives Hall's condition. For the
incoming-transfer family, S emits exactly 2|S| arrows, whereas any
recipient set T has total capacity at most 2|T|+1. The inequality
|T|<=|S|-1 would contradict the required arrow count. A perfect
matching therefore exists in both families.

Its directed permutation has no fixed points, since the graph has no
loops. The programs enumerate every partition into cycle lengths at least
two and fix one canonical permutation for that partition. A permutation
commuting with this matching can rotate any cycle and interchange cycles
of equal length. Consequently choosing the high-degree vertex at one
representative of each distinct cycle length loses no isomorphism type.
The low-degree vertex remains unrestricted among all other labels.
The residual row and column degrees enumerate every completion of that
matching, including both outgoing and incoming transfer directions.

## Pruning and game evaluation

Source camping is tested only when the source row is complete and eligible.
The competing cop row can be partial: containment in its current closed
outgoing set persists when more arrows are added, so that pruning is
monotone and sound. A predecessor set is tested only after its residual
column capacity is filled. Its containment in a partial cop row is again
persistent. The low outgoing-degree source is omitted in the outgoing
family; the low incoming-degree recipient is omitted in the incoming
family. These are exactly the ineligible rows or columns.

Residual targets exclude loops, matching arrows and duplicate arrows.
At a leaf the prescribed residual row sum equals the total column capacity;
the capacity upper checks therefore imply every column has its exact
required degree. The backtracking removes only residual arrows, never a
matching arrow. There is no target-score early termination. A timed
interruption sets complete=false, and the four relevant receipts instead
record complete=true.

The evaluated game recurrence matches the existing exact solver: it starts
from terminal receipt, existentially chooses a messenger move, universally
quantifies all pursuer moves, permits both waits, excludes nonterminal
collisions, and computes the least finite-reachability fixed point. The
incoming and outgoing graphs are evaluated in their original directions.

The parameterized one-predecessor-camping-pair source was also inspected.
Its completed predecessor columns and partial-row pruning are monotone;
it evaluates every remaining leaf, with no target-triggered stop. The
regular-core loss split yields upper bounds 44 and 58 regardless of the
smaller maxima in the zero/one-camping classes.

## Readback and independent fixed-graph verification

The completed transfer receipts record these eligible-camping-free maxima:

- order 9, outgoing transfer: 13 over 21 leaves;
- order 9, incoming transfer: 29 over 738 leaves;
- order 10, outgoing transfer: 32 over 13,754 leaves;
- order 10, incoming transfer: 50 over 56,467 leaves.

All ten source/receipt hash entries in
research/sparse-third-transfer-commands.json match the current files.
All 33 pins in research/sparse-third-source-audit.json also match.
The command manifest records each direction separately and the explicit
order macro used for compilation.

The reviewer independently replayed all saved rank certificates for the
four transfer maximizers (6,916 alternating states), and re-evaluated them
with both existing Python game solvers. Every count and every winning
pursuer mask agreed. The order-nine and order-ten camping-free maximizing
graphs were also independently checked by both solvers, with fresh full
certificate replay, giving counts 30 and 38. The author has now frozen
the strongest lower witnesses at 18, 20 and 22 arrows, with respective
counts 30, 50 and 79, in
research/sparse-third-fixed-lower-certificates.json.

These fixed-graph checks establish the lower witnesses and validate the
game evaluator on those inputs. Completeness of the upper enumeration
rests on the reviewed Hall reduction, cycle normalization, residual-degree
enumeration and safe pruning, together with the retained completed runs.

# Odd endpoint investigation after quota reset

## Scope and proof boundary

The target is an all-order or infinite-family construction attaining
`M_E(2k+1)=k(k-3)+2`; a degree-matched graph on n=k+1 must have one
outdegree-one vertex u and one distinct indegree-one vertex v, absent u→v,
and all remaining degrees two. This new note owns only odd-endpoint work;
it does not change the shared website or assembled manuscript.

Current mathematical progress is in `paper/odd-endpoint-resume.md`:

1. Ordinary necessary connectivity lemma: every odd extremizer is strongly
   connected, and after deleting any c it still connects every eligible
   source s≠u,c to every eligible recipient t≠v,c. This is strictly weaker
   than the actual moving-pursuer condition and is not advertised as a
   characterization.
2. Verified counterexample: odd equality does not imply universality after
   adding u→v. The explicit n19,m37 graph has I272; completing4→18 gives
   I276 rather than304. An ordinary four-class/19-state trap proves the
   completed graph cannot deliver from1 to0 against a cop initially at4.
   Thus completion relates degree patterns, not the winning strategies.

## Bounded experiments and their interpretation

### Vertex splitting

A two-in/two-out vertex can split into v and u, assigning one old incoming
and one old outgoing edge to each, and adding v→u. Counts become n+1 and
m+1, with exactly the desired exceptional degree pattern. This is a
natural structural alternative to arbitrary deletion.

All twenty canonical splits of the five-type family were tested at
circumferences4 and6. At k4, splitting type0 so old incoming from0_(−1)
and outgoing to1_0 move to the new vertex attains n21,m41,I342. Every
canonical split fails at k6. Best loss there is52. Files
`research/odd-endpoint-splits-k4.json` and `...-k6.json` preserve the
scores. The one finite success is evidence of possibility only.

### Parameterized lane speeds

`src/odd_endpoint_voltage.py` changes the horizontal beta step at type0
to +p and at type3 to −q, preserving the two-in/two-out pattern. The
bounded p,q=1,2,3 screen at circumference8 found a useful isolated odd
success for p=q=3: deleting2_0→4_(−1) attains the bound at n40. It also
attains at n50, but fails at n45,55,60,65,70,80. Full scores are in
`research/odd-endpoint-voltage-screen.json` and
`research/odd-endpoint-speed3-validation.json`. Modulus-dependent mixing
is a real obstacle; this family does not supply a uniform theorem.

### Completion counterexample

Starting with the saved n19 odd extremizer, a bounded head-swap walk
preserved indegrees, outdegrees, and absent4→18. It evaluated583 valid
mutants in4.4seconds and accepted five that remained odd-extremal before
finding a nonuniversal completion. This search merely discovered the
fixed graph; the resulting theorem does not depend on trust in its search.

`src/odd_endpoint_completion.py` hard-codes the graph and verifies both
full-game solvers and every transition certificate. The full receipt is
`research/odd-endpoint-completion-certificate.json`. It confirms all
eligible source/recipient guarantees in the odd graph and finds exactly
276 indirect guarantees after completion. The ordinary obstruction in the
paper is independently hand-checked against the adjacency table. Notably,
the failed completed pair1→0 has no stationary closed-neighborhood
separator; the cop must change position. Restoring4→18 enables precisely
the first transition of the displayed avoidance strategy.

## Routes considered but not promoted

The new odd example could be attached to a uniform even family by a
connected-sum operation if such an operation preserves delivery. This is
being coordinated with the independent composition branch; no general
gluing lemma is assumed. The existing disjoint-union formula cannot attain
the quadratic arc-only endpoint because it lacks cross-component pairs.

A brief primary-literature search found adjacent directed cops-and-robbers
work, including Loh and Oh's *Cops and robbers on planar directed graphs*
(https://arxiv.org/abs/1507.01023). It does not supply the current prescribed
recipient or odd-degree endpoint, and no theorem from it is used here.

## Uniform odd family proved

The newer six-type periodic catalogue supplied a successful structural
route after the original five-type and the smoothable six-type pattern162
failed all single-arc deletion classes. Pattern0 has
`sigma=[0,2,5,1,4,3]` and `voltage=[-1,-1,1,1,-1,1]`, with the first
permutation the Hamilton column cycle. Delete `(0,0)->(0,1)`.

Every translated local module passes with messenger radius4, pursuer
radius6, outside re-entry in the two boundary layers, and the precise
exception exclusions. There are97objectives: the base and each of13
defect positions, with the low-indegree target omitted when it coincides
with the objective. Transfers from column−1 to0 exclude the low-outdegree
vertex from initial and final messenger positions; delivery from column−2
excludes it from initial positions but permits it as a recipient.

Primary certificate generator `src/odd_endpoint_certificates.py` records
all ranks in `research/odd-endpoint-uniform-certificates.json.gz`.
Independent implementation `src/six_type_independent_odd.py` rebuilt the
graph and alternating game and checked97modules,44,850requiredstarts,
827,604states, and full winning/losing closure. Maximum bounds14transfer,
26delivery agree. For q>=15 the ordinary outside projection and composition
give every eligible guarantee at n=6q, yielding

`M_E(12q-1)=(6q-2)(6q-3)`, q>=15.

The polished proof is appended to `paper/odd-endpoint-resume.md`.

The bounded candidate screen itself is separate evidence:
`src/odd_endpoint_patterns.cpp` tested all168six-type patterns and twelve
deletion classes at q8,10,12;93passedq8,62passedq10,45passedq12.
The fixed local screen then found19passing deletion choices across13
patterns. No circumference extrapolation enters the proved theorem.

## Still open and next structural route

Arbitrary sufficiently large odd budgets remain unresolved. The odd-friendly
patterns do not admit the simple individually smoothed vertex operation
used in pattern162. A bounded screen of every nonempty proper subset of
the six types removed in one column also found no plain smoothing
survivors among the13odd-friendlypatterns. This blocks that simple modular
composition route but does not establish impossibility of a richer patch.

The next option is to place smoothing and the arc deletion in the same
finite defect block, allowing the one bad source/recipient of the smoothed
configuration to coincide with the permitted degree exceptions. The
counterexample above remains important: neither odd equality nor even
universality is transferred merely by adding or deleting the degree-
completing arc.

## All sufficiently large odd budgets resolved

Six fixed patterns now cover every residue of the vertex count modulo six.
The primary proof data contain 903 fully verified local objectives; the
five nontrivial defects were independently reconstructed and checked in
750 objectives (425,176 required starts; 7,590,092 alternating states),
with the original zero-deletion residue independently checked earlier.
The complete construction and ordinary projection/composition proof are
Theorem 45 in `paper/odd-endpoint-resume.md`.

The resulting exact theorem is
`M_E(2n-1)=(n-2)(n-3)` for every `n>=145`, equivalently every odd arc
budget `m>=289`. This is an explicit construction for every such integer,
not finite extrapolation. The graph generator is
`src/odd_endpoint_all_residues.py`; full primary certificates are
`research/odd-endpoint-all-residues-certificates.json.gz`; the fresh
independent checker and full data are
`src/six_type_independent_odd_residues.py` and
`research/six-type-independent-odd-residues-certificates.json.gz`.
The independent proof audit is
`research/six-type-independent-odd-residues-proof.md`.

The nontrivial conceptual repair occurs for five removed vertices.
Requiring the messenger to finish a transfer in precisely the next
column left produced two losing local starts: a smoothed move may skip
that column. Permitting either of the next two columns as a safe goal,
and furnishing delivery from distances two and three, makes every
module succeed. A distance descending by one or two must encounter
one of these two terminal distances, so this wider partial-state
interface composes on every long cycle. This replaces futile enlargement
of the failed exact-column interface by an interface matching the graph.

All four nonempty smaller defects retain exact-column transfer. The
largest verified local bounds are 34 transfers moves and 27 delivery
moves, giving the conservative global bound `34*ceil(n/6)+27`.
The degree deficiency is preserved at every interface: the unique
outdegree-one vertex may be a recipient or an intermediate state, but
never an initial or final transfer state; only the unique indegree-one
vertex is excluded as recipient. These new results are computer-assisted
ordinary proofs, not yet Lean formalizations.

The remaining numerical endpoint question is the finite interval below
289 odd arcs. A bounded finite screen of these explicit residue families
is now underway; each successful graph needs full actual-game rank
certificates before it may lower the proved threshold.

## Finite bridge: exact formula for every odd budget at least 37

The residue construction succeeds at every order from 34 through 144
in a cheap C++ actual-game screen. Saved finite two-regular witnesses,
with one carefully chosen arc deleted, fill every remaining order
19 through 33. No such deletion succeeds in the selected witnesses
at orders 12 through 18; this is a failed construction screen, not an
impossibility theorem for those orders.

All 126 graphs from 19 through 144 now have complete finite proofs.
A C++ explicit alternating-state attractor emitted full signed16
ranks, and an independent Python direct checker tested every original
legal move, strict winning rank progress, and all losing closure
conditions. Vectorizing the simple rank comparisons avoided repeating
an expensive solver and reduced the full 215,921,496-state verification
to 12.7 seconds. This is 10,143 recipient objectives. The standard-library
scalar implementation also replayed every objective at orders 19..24;
the original two independent game solvers matched selected certificates
at orders 19, 28, and 144. The complete checks establish the proof;
the latter comparisons additionally attack the new encoding/verifier.

Combining this finite bridge with Theorem 45 proves, for every n>=19,
`M(n,2n-1)=M_E(2n-1)=(n-2)(n-3)`, equivalently
`M_E(m)=(m-3)(m-5)/4` for every odd m>=37. Written as Corollary45.1 in
`paper/odd-endpoint-resume.md`.

Artifacts: `research/odd-endpoint-finite-bridge-graphs.json`,
`research/odd-endpoint-finite-bridge-certificates.jsonl.gz`,
`research/odd-endpoint-finite-bridge-verification.json`,
`research/odd-endpoint-finite-bridge-crosscheck.json`.
The producer and direct verifier are
`src/odd_endpoint_finite_certify.cpp` and
`src/odd_endpoint_finite_verify.py`. The verifier has both accelerated
NumPy and dependency-free scalar replay modes. No new Lean coverage
is claimed. An independent agent is additionally reviewing and
replaying these artifacts.

## Lower threshold to every odd budget at least 25

A brief targeted search of two permutations with a fixed missing arc
0->1 found witnesses at every order 13..18. The representation preserves
all degree equalities throughout search; it avoids assuming that completion
of an odd extremizer must be a universal even graph. Full independent
replay immediately verified each graph with both existing game solvers
and every explicit transition/rank obligation: 93 recipient objectives,
46,314 states. Thus Corollary45.1 now states the exact formula for every
odd m>=25, equivalently fixed support n>=13.

Artifacts: `src/odd_endpoint_small_search.cpp` records the bounded
candidate search; its output `research/odd-endpoint-small-n13.json`
through `...-n18.json` fixes the witnesses. The proof script is
`src/odd_endpoint_small_verify.py`, with complete ranks in
`research/odd-endpoint-small-certificates.json.gz` and summary in
`research/odd-endpoint-small-verification.json`. The two algorithms
and direct transition checks all pass.

The eight-second search at n=12 reached 1312 of the 1331 required
winning initial states and did not attain equality. This is evidence
only about a bounded search; n=12 (m=23) remains unresolved. Earlier
odd budgets also require further exact analysis or enumeration.

## Exhaustive exclusion of sharp odd equality below 25 arcs

Following the root's suggested exact factorization route, the candidate
space is now completely exhausted at every support size n7..12.
Add the missing exceptional arc0->1; decompose the resulting bipartite
2regular graph into permutation factors A,B; distinguish the A-cycle
through0->1 and enumerate partitions of all remaining cycle lengths.
This covers every graph allowed by the odd equality characterization.
Then enumerate B, pruning only sound source/target camping obstructions
once the relevant messenger neighborhood is complete. Eligible missing
partners are checked explicitly; the cop row may be partial because
any domination already present persists after additional arcs.

No equality witness occurs at any n7..12. The n12 enumeration completes
in41.45seconds, visiting164,276,910 partial nodes and16,902,091 completed
graphs surviving local obstructions. All smaller cases combined finish
inunder2seconds. A known13-vertex attaining graph passes every partial
prefix as a positive control. The independent source/ordinary proof audit
`research/odd-endpoint-twelve-independent-audit.md` accepts coverage,
pruning, and game semantics, while explicitly recording that the41second
run was not repeated with a second enumerator.

Consequently `M_E(2k+1)<=k(k-3)+1` for k6..11, especially
`M_E(23)<=89`. This is a strict-upper result, not an exact determination
of those small maxima. Source `src/odd_endpoint_exhaustive.cpp`; finished
receipts `research/odd-endpoint-small-exhaustive.json` and
`research/odd-endpoint-n12-exhaustive.json`. A proposition and full
coverage argument are appended to `paper/odd-endpoint-resume.md`.

## Stronger global upper bound M_E(23)<=87

The ordinary near-equality reduction and all three exact searches now
complete. If I>=88 with23 arcs, the active sets must both have size11.
Small intersections force many zero columns; the intersection10 case
gives distinct degree-one source/recipient, with their exceptional arc
absent OR present. Intersection11 gives either an already excluded
11-vertex two-regular core or one additional vertex with both indegree
and outdegree one. Thus only three support12 degree families remain.

All three are completely enumerated. Their ordinary factorization
models respectively add the absent arc, add a duplicate of the present
arc, or add a dummy loop at the shared exceptional vertex. After the
added edge is removed, every graph is simple and has23 arcs. Camping
prunes destroy at least7 eligible pairs and hence are still sound at
the relaxed threshold87. Exact evaluation counts failed eligible pairs,
not just failed initial pursuer states. No graph in any of the three
families has I>=87. Counts and times:
- absent arc:42 partitions,164276910 nodes,16902091 leaves,40.94sec;
- present arc:42 partitions,13448216 nodes,1125588 leaves,2.31sec;
- shared exceptional vertex:14 partitions,49814092 nodes,3558672 leaves,7.83sec.

The resulting global conclusion is M_E(23)<=87. It is not an exact
value claim: the best currently retained23-arc candidate has I83.
The11-vertex pattern with one outgoing and one incoming degree3 is
not excluded at I87 by this argument.

Source `src/odd_endpoint_near23_exhaustive.cpp`, receipts
`research/odd-endpoint-near23-{absent,present,same}.json`, ordinary
reduction `research/odd-endpoint-near23-reduction.md`. The independent
source and ordinary proof audit found no gap; it does not repeat the
full enumeration with a separately written solver. A sharper-bound
proposition is appended to `paper/odd-endpoint-resume.md`.

Final verification of the retained23-arc lower witness passes both
original game solvers and every direct rank obligation. Its exact
I=83 is recorded in `research/odd-endpoint-m23-lower-certificate.json.gz`
and `research/odd-endpoint-m23-lower-verification.json`, generated by
`src/odd_endpoint_m23_lower.py`. Together with the accepted near-equality
reduction and exhaustive checks, the current rigorous interval is
83<=M_E(23)<=87. No jobs remain running from this branch.

## Independent eleven-core audit and global upper86

The construction-audit agent's new exact enumerations at n11 were
independently reviewed, recompiled, and replayed. Results reproduce
exactly (except elapsed time): at22 arcs,14 partitions,2177946 nodes,
120302 camping-free leaves, maximum66; at23 arcs,14 matching partitions,
330 excess-endpoint patterns,31536058 nodes,792080 camping-free leaves,
maximum74. Both saved maxima additionally pass both original game
solvers and every direct rank condition.

Ordinary coverage of the23-arc enumeration uses a perfect matching,
not a2factor: Hall follows from2|S|<=2|N(S)|+1. Residual degrees are one,
exceptone source and recipient of residual degree two. Matching cycle
symmetries justify restricting the excess source to one representative
per distinct cycle length while enumerating every excess recipient.
The implementation respects complete source/recipient neighborhoods
when pruning; partial cop rows are valid persistent lower bounds.

The maxima66/74 concern only camping-free graphs. Graphs with a low
degree have I<=80; a camping obstruction gives I<=81. Thus every
11-vertex graph with22 or23 arcs has I<=81, without asserting sharpness.
Combining this with the previous support12 exclusions, and treating
(q,r)=(10,11),b4 via four zero columns, proves the stronger global bound
M_E(23)<=86. The current rigorous interval is83<=M_E(23)<=86.

Audit and proof: `research/odd-endpoint-eleven-enumeration-audit.md`;
source/replay hashes: `research/odd-endpoint-eleven-enumeration-audit.json`;
complete maxima witness checks:
`research/odd-endpoint-eleven-maxima-witness-audit.json.gz`.
An unnumbered lemma and corollary have been appended to the odd
manuscript. This involved source/ordinary review and re-execution of
the same enumerators, not a separately implemented exhaustive search.
No new Lean coverage is claimed; no further computation is running.

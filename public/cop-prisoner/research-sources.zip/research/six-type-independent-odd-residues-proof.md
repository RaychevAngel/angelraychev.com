# Independent audit of all odd-budget residue patches

## Conclusion and evidence boundary

The five smoothed patches, together with the earlier unremoved six-type
family, prove the odd arc bound is attained on every support size
`n>=145`. Consequently, for every odd `m=2k+1>=289`,

`M_E(m)=k(k-3)+2`.

The verification combines ordinary cyclic projection and composition
with independently generated finite local ranks. It does not assert
new Lean coverage. The earlier note
`research/six-type-independent-odd-proof.md` supplies the unremoved
residue and its exact pair-count argument.

## Independent graph and finite game construction

The executable specification is
`src/six_type_independent_odd_residues.py`. It does not import a primary
graph builder, arena builder, or primary solver. It imports only the
previously independent explicit alternating-state attractor and its
rank/losing-closure checker.

The first permutation follows the Hamilton order on six types per
column. The second is given in this table, where `sigma` specifies the
new type and `v` the integer column displacement. Remove the indicated
vertices, smooth each permutation separately through removed vertices,
and then delete the indicated smoothed arc from `u`. Write `v_low` for
that deleted arc's recipient. The notation `A` and `B` in the final
column names the first and second permutations, respectively.

| Removed count | Second permutation sigma; displacements | Removed vertices | Deleted arc |
|---|---|---|---|
| 1 | `[0,5,1,4,3,2]`; `[-1,1,1,-1,-1,1]` | `(0,3)` | `B:(1,4)->(-1,4)` |
| 2 | `[3,5,0,2,4,1]`; `[-1,1,-1,-1,-1,0]` | `(0,0),(0,1)` | `B:(0,5)->(1,5)` |
| 3 | `[4,1,5,2,0,3]`; `[-1,-1,1,1,-1,1]` | `(0,2),(0,3),(0,4)` | `A:(0,1)->(0,5)` |
| 4 | same as count 3 | `(-1,4),(0,2),(0,3),(0,4)` | `A:(0,1)->(0,5)` |
| 5 | same as count 2 | `(0,0),(0,1),(1,0),(1,1),(1,5)` | `B:(0,5)->(2,5)` |

All patch translations `-10..10` and the locally absent patch were
checked. The messenger window and cop window, respectively, are
`[-4,4],[-6,6]` for counts 1 and 2, and `[-5,5],[-7,7]` for counts
3, 4 and 5. The extra cop state `Omega` may wait or reenter any retained
vertex in the outer `J` cop layers at either end, where `J=1` for
count 1 and `J=2` for the others. These are the maximum jumps of the
final graphs, after the deficient arc is deleted.

The safe transfer objective is seeded only at a noncollision messenger
turn, after the pursuer has responded. Both its source set and terminal
set exclude `u`. Delivery sources exclude `u`, and recipients exclude
`v_low`; recipients may equal `u`. Receipt has priority over collision.

For counts 1, 3 and 4, transfer starts in column `-1` and finishes in
column zero; delivery starts in column `-2`. Count 2 reverses direction,
using source columns `+1` and `+2`. Count 5 also travels left, but its
transfer starts in column `+1` and may finish in either column `0` or
column `-1`. Its delivery certificates cover **both** starting columns
`+2` and `+3`. This wider interface is essential: an exact-column
interface discards legitimate jumps across the intended exit column.

All **750 modules** pass, covering **425,176 required starts** and
**7,590,092 alternating states**. The independent checker validates the
chosen messenger moves, all pursuer responses, terminal priorities,
strict rank progress and the entire complementary losing closure.

| Removed count | Modules | Maximum transfer moves | Maximum delivery moves |
|---|---:|---:|---:|
| 1 | 152 | 9 | 22 |
| 2 | 151 | 17 | 26 |
| 3 | 150 | 34 | 23 |
| 4 | 149 | 28 | 27 |
| 5 | 148 | 9 | 26 |

The full ranks and chosen moves are saved in
`research/six-type-independent-odd-residues-certificates.json.gz`;
`research/six-type-independent-odd-residues-summary.json` records the
counts, specification checks and source/certificate hashes. In
particular, the certificate SHA-256 is
`95c5c40124b6109fb1e48acdff6a864fd9e35cc3f22d542432242aba67715b76`.

## Uniform graph structure and projection

Reduce columns modulo any `q>=25`. Smoothing preserves each permutation:
none of its cycles is entirely removed. For completeness, the type
cycles of the three second permutations have lengths and total
displacements `(1,-1),(3,3),(2,-2)`; `(3,-3),(2,1),(1,-1)`; and
`(2,-2),(1,-1),(3,3)`, respectively. A cyclic lift of a type cycle of
length `ell` and displacement `d` has length
`ell*q/gcd(q,d)>=q` in each of these cases. At most five vertices were
removed, so no lifted cycle disappears. The first permutation is the
single Hamilton cycle. The displayed local formulas also show the two
smoothed successors remain distinct and different from their source.
After the single deletion, only `u` has outgoing degree one and only
`v_low` has incoming degree one; all other such degrees are two.

Removed columns are within one of the patch anchor; changed retained
tails are within two. The maximum surviving jump is at most two (one
for count 1). These facts are finite consequences of the displayed
patch formulas, also checked in the independent specification. Thus
any patch that affects an internal cop move in a radius-seven window
has an anchor within nine of its center. The tested translations through
ten also cover local role exclusions and all removed vertices.

Since `q>=25`, at most one periodic patch anchor has a representative
in `[-10,10]`. If there is none, the unmodified local arena applies.
Otherwise its translated patch is one of those certified. No change
outside this range can modify an internal move. The cop window is
injective modulo `q`, and the circular distance between its opposite
boundaries through the omitted exterior is at least `q-2R>=11`, larger
than every surviving jump. Consequently, no local internal move is
mistakenly represented as an exterior move followed by an instantaneous
crossing to the other internal boundary.

Map every actual external cop position to `Omega`. An actual reentry
lands within the outer `J` layers and is therefore permitted by the
local arena. Exterior waiting or movement is overapproximated by
`Omega`. All retained messenger moves and all internal collisions are
represented correctly. Hence every local winning strategy lifts to
the cyclic graph against every initial cop position.

## Composition, including the two-column exit

For counts 1 through 4, each safe transfer advances one column in its
declared direction. Starting from any source other than `u`, perform
at most `q-1` such transfers until the messenger is at the appropriate
delivery-entry column two columns from the actual recipient. Every
transfer ends on a safe messenger turn at a vertex other than `u`,
which is exactly the next module's precondition. Then deliver. Arrival
at the actual recipient during an earlier transfer only shortens the
strategy.

For count 5 put `d=(current column - recipient column) mod q`. A
transfer reduces this distance by either one or two modulo `q`. If
`d` is 2 or 3, use the corresponding delivery module immediately.
If `d>=4`, another transfer strictly reduces the ordinary integer
distance and cannot jump over the set `{2,3}`. If initially `d=0` or
`d=1`, transfers cross the residue-zero boundary at most once before
entering the preceding decreasing regime. More explicitly, after at
most two preliminary transfers the distance is between `q-2` and
`q-1`; from there at most `q-3` transfers suffice. Thus at most `q-1`
transfer modules are needed in all cases. The terminal exclusion of
`u` remains valid for **both** exit columns, and both delivery entries
were independently checked.

This proves delivery for every source other than `u` and every
recipient other than `v_low`, with finite termination; a uniform loose
bound for all five patches is `34(q-1)+27` messenger moves. The proof
does not rely merely on evading capture indefinitely.

## Exact count and all orders

The missing arc `u->v_low` remains absent. Camping at the unique
out-neighbor of `u` rules out every indirect pair from `u`; camping at
the unique in-neighbor of `v_low` rules out every indirect pair into
`v_low`. All other missing pairs win by the preceding composition.
Their number is exactly

`(n-1)^2 - (n-2) - (2n-3) = (n-2)(n-3)`.

Here the terms remove, respectively, the eligible diagonal and the
eligible direct arcs; the two direct arcs excluded by the deficient
row and column are distinct because `u->v_low` is absent.

For any `n>=145`, set `q=ceil(n/6)>=25` and `r=6q-n`. Use the
unremoved family when `r=0` and the corresponding smoothed patch when
`1<=r<=5`. The graph has exactly `2n-1` arcs and attains the preceding
count. Substituting `m=2k+1` and `n=k+1` gives
`(n-2)(n-3)=k(k-3)+2`, matching the proved odd-budget upper bound.

The bounded cyclic degree checks at circumferences 25 and 31 in the
receipt corroborate the formulas; they are not the justification for
all circumferences. That justification is the ordinary permutation,
projection and composition argument above.

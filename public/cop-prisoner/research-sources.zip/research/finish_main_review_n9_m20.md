# Independent review of M(9,20)=37

The complete positive-family exclusion and literal score37 graph establish
`M(9,20)=37` after the ordinary zero-degree split below. The source, profile,
independent game, and lower-rank checks are recorded in
`finish_main_review_n9_m20.json`.

For support at most eight, the approved fixed-host result is `M(8,20)=24`.
For a nine-vertex graph with an actual source or sink of other degree `d`,
delete that vertex. Every old guaranteed pair is bounded by the eight-vertex
remainder, and the removed row or column has at most `8-d` missing pairs.
At `d=1` it contributes zero, giving `M(8,19)=22`. At `d=2` the bound is
`M(8,18)+6=21+6=27`. At `d>=3` the remainder has at most17 arrows; approved
global `M_E(17)=28` and budget monotonicity give at most `28+5=33`.
Thus every possible score above37 has all nine vertices of positive indegree
and outdegree. The actual-source/sink comparison does not remove arbitrary
cop positions or assume arrow-reversal symmetry.

The independent incoming-degree sum recursion reproduces the entire supplied
set of303 joint-degree multisets above37. Every positive outdegree partition
is covered; indegrees are sorted only within equal-outdegree groups. The
active eligible rectangle and its diagonal/direct-arrow subtraction are the
same independently reviewed bounds used in the earlier sparse families.

The new maximizing source is checked as an exact textual transformation of
the already reviewed positive-family source. Its only search-behavior change
is to continue after finding an improvement and raise the pruning threshold
to that fully computed game score. Positive mode is now explicitly required.
The initial and final thresholds in this particular run are both37 and no
larger leaf score is reported, so no threshold update occurs. Row coverage,
future-vertex symmetry, degree capacities, camping-loss unions, optimistic
guarded reachability, and all initial-source exceptions are unchanged.

The `counterexample_found` field alone is not an improvement detector in the
new maximizing source: its old flag is never set. This review instead checks
the initial threshold, final threshold, completed count, and actual largest
reported score. All303 profiles complete at37. The stale field causes no
omission in this run.

Every surviving leaf is independently solved for every target by the explicit
two-turn queue, with receipt before capture. Its complete traversal counters
must match the primary receipt. Guarded-loss samples use the independent
asymmetric game and are counted separately. The tiny-deadline control requires
a nonzero exit status and `complete=false`. These controls supplement the
ordinary source proof; the graph generation and pruning traversal itself is
retained from the reviewed producer.

The literal nine-vertex, twenty-arrow graph is independently checked directly
from its complete winning ranks and closed losing regions. All1458 alternating
states obey the receipt, collision, messenger-choice, and cop-choice rules.
Exactly37 missing distinct ordered pairs win for every permitted initial cop.
This supplies the matching lower bound without relying on the maximizing
producer's reported witness status.

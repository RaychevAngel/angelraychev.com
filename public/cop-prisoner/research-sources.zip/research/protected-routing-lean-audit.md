# Protected routing: narrow Lean semantics and conditional-counter audit

Date: 2026-09-12. Independent review by the proposal-check agent.

## Formal statement and exact scope

The new module `lean/ProtectedRouting.lean` imports the existing
`DenseCounting.lean`. It does not change the game, the executable play function,
or the existing semantic bridge.

For an arbitrary vertex type, protected-vertex predicate `H`, and graphs `E,F`,
`IncidentAgreement H E F` says that `E x y ↔ F x y` whenever at least one of
`x,y` belongs to `H`. Thus both incoming and outgoing arrows incident with `H`
are fixed. No agreement is required on an arrow wholly outside `H`.

`ProtectedWitnesses H E` explicitly assumes that for every source `s`, distinct
recipient `t`, and initial pursuer position `c ≠ s`, there is a vertex `z ∈ H`
such that `E s z`, `E z t`, `z ≠ c`, and `¬ E c z`. The witness may depend on
the observed initial pursuer position. In particular, the hypothesis includes
the case `c = t` and also includes source–recipient pairs already joined by an
arrow.

The module proves:

1. `protected_witness_winning`: a single such witness remains a winning
   two-move strategy in every graph `F` with incident agreement. The proof
   transfers the two positive arrows and the negative arrow, then invokes
   `DenseCounting.safe_intermediate_winning`. The inequality `z ≠ c` rules
   out pursuer waiting at the intermediary, while `¬ F c z` rules out moving
   to it.
2. `protected_routing_universal`: `Universal F t 2 s` for every `s,t`.
   If `s=t`, receipt has already occurred; otherwise the protected witness
   supplies the strategy.
3. `protected_routing_actual_delivery`: the existing concrete `play` function
   returns `.delivered` with a budget of two messenger moves against every
   legal history-dependent pursuer policy and every supplied initial history.
   This invokes the previously proved `winning_play_delivers`; it retains
   messenger-first play, pursuer waiting, and receipt before capture.

These statements do not require a finite vertex type or graph looplessness;
the paper's finite loopless graphs are instances. The actual-play statement
uses the existing `DecidableEq` requirement of `play`.

**Not formalized here:** existence of protected witnesses, the random model,
independence or probability estimates, exact-budget conditioning,
derandomization, asymptotic bounds, the size of the protected set, and arc
counts. These remain ordinary mathematical arguments and computational
evidence. No existence or counting claim is inserted as an axiom.

## Compilation and axiom readback

Compiled successfully with exit code zero using Lean 4.33.1:

```text
LEAN_PATH=/Users/angel/code/math/cop-prisoner/lean \
  /Users/angel/code/math/polyominoes/.tools/lean-4.33.1-darwin_aarch64/bin/lean \
  -o ProtectedRouting.olean ProtectedRouting.lean
```

The working directory was `lean/`. Existing imported `.olean` modules were
used; this was a narrow module compilation, not a fresh rebuild of the entire
formal development.

Actual `#print axioms` output:

```text
Delivery.ProtectedRouting.protected_witness_winning: no axioms
Delivery.ProtectedRouting.protected_routing_universal:
  [propext, Classical.choice, Quot.sound]
Delivery.ProtectedRouting.protected_routing_actual_delivery:
  [propext, Classical.choice, Quot.sound]
```

There are no `sorry`, custom axioms, or `native_decide` calls in the new
module. The standard axioms in the last two theorems are not evidence of a
formalized probabilistic existence theorem.

Lean source SHA-256:
`af7717615600f7d042f2e4f4b515c11cc67c72d272d0e8f9db35c42db8af0cb7`.

This agent did not edit `lean/check.py`, `lean/README.md`, `lean/Audit.lean`,
or the aggregate verification receipt. Integration and a complete fresh
verification are separate parent-agent work.

## Independent review of `src/routing_unification.py`

Reviewed source SHA-256:
`9c70fb8589f57c5a15eca55f4777816b6fef67b644b60d2912db982582245aea`.

For valid inputs, no correctness defect was found in the conditional counter
or its default all-triple construction. The key checks were:

- The variable universe is exactly the loopless incident-arrow set, of size
  `b(2n-b-1)`. Every witness requirement belongs to this universe.
- For distinct source/recipient and pursuer distinct from the source,
  `u ∈ H \ {s,t,c}` gives three distinct variables. Different choices of `u`
  give disjoint triples even when `c=t`.
- A candidate with `q` free variables contributes `(1+x)^q-x^j` precisely
  when its fixed variables still permit the safe witness, where `j` counts
  free variables required to be present. If fixed values already rule out
  that witness, its factor is `(1+x)^q`. The `q=0` cases correctly distinguish
  an already guaranteed witness from an already excluded one.
- The final binomial coefficient accounts for every free variable outside
  the disjoint candidate groups. Infeasible remaining budgets contribute
  zero. Python integers preserve the counts exactly.
- The construction maintains `bad < total` over exact-budget completions.
  Splitting the next variable partitions both counts, so a branch retaining
  strict inequality exists. Infeasible branches have zero total and cannot
  be selected. At the end the unique completion has zero bad triples and
  exactly the requested incident budget.
- `objectives=None` checks every legal triple. The small restricted-objective
  demonstration is correctly labelled as restricted; it is not by itself a
  universal-graph construction.
- The batched witness checker includes all source–recipient pairs, including
  direct ones. Intermediaries equal to source/recipient cannot contribute in
  the valid loopless input graphs. It excludes the pursuer and its outgoing
  neighbors. Arrows wholly outside `H` cannot change these witness facts.
- The larger sample section tests exact-size random cores, explicitly not
  outputs of a large deterministic conditional-expectation run. Floating
  margins there are corroborating computations, not proofs of the theorem's
  real-number inequalities.

The public counter routines assume valid finite sets of hubs and valid fixed
incident-arrow assignments. The `construct` entry point validates the latter;
this audit makes no claim about malformed input or single-use generator
objects passed in place of its reusable collections.

## Additional bounded finite checks

An independent direct-completion check used `random.Random(550733)`, orders
`n=2,...,6`, every hub-set size including zero and all vertices, six partial
assignments per size, at most six free arrows, and up to eight sampled legal
triples per assignment. Every exact-budget completion was enumerated directly
and tested by the literal three-arrow witness condition.

All checks passed:

- 1,092 individual bad-completion counts;
- 335 cases with the pursuer initially at the recipient;
- 150 summed objective counts and their two-branch partitions (where a free
  variable existed).

These tests supplement the source-level counting proof; they neither replace
it nor establish the asymptotic existence theorem. No large search or large
deterministic graph construction was performed in this audit.

# Independent audit: routing sets, exact budgets, and the separating lower bound

2026-09-12. This is an independent ordinary mathematical audit of the
proposed routing theorem and the game-specific separating-system
argument in the side-conversation handoff. No experiment, exhaustive
search, formalization, or literature/novelty audit is claimed here.

## Routing theorem: precise domain and robustness

Take n vertices, a fixed routing set H of size b, and let U be the
set of all nonloop directed arcs having at least one endpoint in H.
Its size is

    Q = n(n-1)-(n-b)(n-b-1) = b(2n-b-1).

For integers 4<=b<=n and 0<a<Q, put p=a/Q. The proposed sufficient
condition

    (b-3)p^2(1-p) > 4 ln(n)+ln(8/3)

does yield a deterministic polynomial-time choice E_0 subset U,
|E_0|=a, such that EVERY graph E_0 union J, where J is ANY subset
of the nonloop arcs outside H, has every source-recipient pair
guaranteed within two messenger moves. Thus every exact total
budget a<=m<=a+n(n-1)-Q is attained by this one incident-arc choice.

This is a simultaneous assertion over all outside subsets, not a
separate random construction for each of their exponentially many
possibilities. It does not allow modifying the selected incident
arcs: adding an omitted arc from a cop into H could destroy safety.

## Witness variables and move order

For each s!=t and c!=s use candidates u in H outside {s,t,c}. The
desired pattern is

    s->u present, u->t present, c->u absent.

Every tested variable belongs to U. The three arcs are distinct.
Variables for different candidate u are also disjoint: a collision
between an incoming-to-u arc and an outgoing-from-u' arc would force
u' to equal s or c, which was excluded. The potential equality
s->u=c->u is prevented by c!=s. In particular, c=t is permitted and
causes no dependence: t->u and u->t are distinct directed variables.
There are at least b-3 candidates, each with independent probability
p^2(1-p) of success.

A successful u differs from the initial cop and cannot be reached by
any of its legal responses, including waiting. The messenger moves
s->u, survives the pursuer response, then uses u->t. Receipt occurs
before the terminal collision check, so a pursuer moving to t cannot
prevent that second move. An arbitrary outside-H arc subset affects
none of these three facts, since every arc into or out of u belongs
to U and is fixed. Extra messenger choices may be ignored.

For independent sampling of the incident arcs, the probability that
the displayed certificate fails for at least one legal triple is at
most

    n^3 (1-p^2(1-p))^(b-3)
    <= n^3 exp(-(b-3)p^2(1-p)).

This is also an upper bound for the probability that the robust
universal-delivery conclusion fails. Some graphs lacking the chosen
certificate may still win, so equality is not asserted.

## Exact incident count and deterministic construction

Let Z count bad triples and let T count the sampled incident arcs.
Then T is Binomial(Q,p), with mean a and a as a mode. Its variance
is at most Q/4. The interval |T-a|<sqrt(Q) contains at most2n-1
integers because Q<=n(n-1), and Chebyshev gives mass at least3/4
in this interval. Therefore

    P(T=a) >= 3/(4(2n-1)) >= 3/(8n).

The strict displayed exponent condition gives E[Z]<3/(8n), so

    E[Z | T=a] <= E[Z]/P(T=a) < 1.

No independence between Z and T is used. Conditional on T=a, the
incident graph is uniform over the exactly a-element subsets of U.

The exact completion-count method of Theorem43 applies with U as
its variable universe. For a triple, each candidate has a disjoint
three-variable group. Under a partial assignment, a candidate group
contributes (1+x)^q if its witness is already impossible, and
(1+x)^q-x^d otherwise, where q variables remain free and d of them
must be present in the unique witness assignment. Variables of U
outside all candidate groups contribute the remaining factor
(1+x)^q0. Taking the coefficient of the remaining incident budget
counts bad completions exactly. Fully assigned witnesses correctly
give the zero factor.

Sum over triples to get B; let C be the number of all fixed-budget
completions. Initially B<C. Revealing one incident arc partitions
B=B_0+B_1 and C=C_0+C_1, so some feasible branch retains B_j<C_j.
After all Q decisions, C=1 and B=0. The argument never enumerates
outside subsets or assumes they were sampled independently.

There are at most Q=O(n^2) decisions, O(n^3) triples per decision,
and at most b=O(n) small factors per triple. Coefficient arrays have
polynomial length; all counts are at most n^3*2^Q and have
O(n^2+log n) bits. Straightforward exact arithmetic is polynomial
in n. This does not promise a small practical runtime.

Taking b=n, U is the entire arc universe and a=m, so this theorem
recovers Proposition51 with its exact existing domain and bound.

## Half-density routing interval

Let b=ceil(32 ln(n)+11), provided b<=n. Q is ALWAYS EVEN:
Q=2nb-b(b+1). Hence a=Q/2 is an integer and p=1/2 exactly; no
rounding correction is needed. Then

    (b-3)p^2(1-p) = (b-3)/8
        >= 4 ln(n)+1 > 4 ln(n)+ln(8/3).

The last strict inequality follows from e>8/3. The routing theorem
therefore realizes every exact total budget

    Q/2 <= m <= n(n-1)-Q/2

with the same two-move guarantee, allowing any prescribed subset of
the outside arcs of the required size. The condition b<=n must be
retained or replaced by a proved explicit sufficient order. This
interval alone does not extend to n(n-3); another proven overlapping
parameter choice or dense construction is needed for that claim.

## Game-specific separating-system lower bound

Assume every pair of an n-vertex graph is guaranteed within two
messenger moves. For each vertex u define

    A_u = {u} union N^-(u),
    B_u = N^+(u) minus N^-(u).

These two sides are disjoint, using looplessness. For each unordered
reciprocal pair, add the singleton separator consisting of its two
endpoints. Every unordered vertex pair is separated:

* If only s->t is present, then s belongs to A_s and t to B_s.
* A reciprocal pair has its added singleton separator.
* If both arrows are absent, use the actual game with source s,
  target t and initial cop t. A two-move guarantee supplies u with
  s->u and u->t present and t->u absent. Consequently s belongs to
  A_u and t to B_u. Waiting first cannot deliver the missing pair
  within two moves.

If there are r unordered reciprocal pairs, the first n separators
have total membership n+2m-2r, and the singleton separators add2r.
The full total is therefore exactly n+2m.

For completeness, the separating-system inequality follows by
independently deleting one uniformly chosen side of every separator.
At most one vertex can survive. A vertex appearing in d_v separators
has survival probability2^(-d_v), since it is in at most one side
of each separator. Thus sum_v 2^(-d_v)<=1. Convexity gives
n*2^(-sum_v d_v/n)<=1, hence sum_v d_v>=n log_2(n).

It follows that

    m >= ceil((n/2)*(log_2(n)-1)).

Together with the routing existence bound this proves the proposed
order q_2(n)=Theta(n log n) for the FIRST universal two-move budget,
subject to retaining credit for the classical separating-system
inequality. This audit verifies its game-specific translation; it
does not assess novelty against the literature. q_2 by itself is
neither an arbitrary exact-budget theorem nor the first budget
where an extremizer guarantees its counted subset within two moves.

## Audit conclusion

The routing theorem, its robust outside-arc quantifier, exact-budget
derandomization, half-density interval, and separating lower bound
all pass ordinary proof review. No missing small-order hypotheses,
optimal constants, full-range overlap, or stronger formalization
are inferred from these statements alone.

## Further independent check: the full two-move interval from n=4096

The proposed Corollary55 overlap is valid. At n=4096,
ln(n)=12 ln(2)<9, so32 ln(n)+12<300<(n-1)/13. The derivative
of (n-1)/13-32 ln(n)-12 is1/13-32/n>0 for n>416. Therefore,
for every n>=4096, b=ceil(32 ln(n)+11) satisfies

    b <= 32 ln(n)+12 <= (n-1)/13 < n.

Set A=Q/2 and H_dense=n*ceil((n-1)/13). Then

    A <= nb <= n(n-1)/13 <= H_dense.

The routing interval [A,L-A] and the previously proved dense
interval [L-H_dense,L-2n] thus overlap. Their union contains every
integer from A through L-2n=n(n-3), with universal two-move delivery.
The dense results apply because n>=4096 also exceeds166. This
checks the proposed sufficient order4096; it is not an assertion
that this order or the lower endpoint A is necessary or optimal.

## Integration check: lowering the existing full-main threshold to 1664

The protected-routing theorem also strengthens the existing full-main
classification, without introducing another independent family of result
statements. The following calculation passes independent ordinary review.
It improves the previous sufficient threshold 1800 to 1664; neither value
is asserted to be sharp.

Let n>=1664, L=n(n-1), and define the integer quantities

    T=n(ceil(n/7)-1), b=ceil(n/6),
    Q=b(2n-b-1), a=T+1, p=a/Q.

First, the rounding is harmless but must be handled explicitly:

    n²/7-n <= a <= n²/7.

The lower bound follows immediately from ceil(n/7)>=n/7. For the upper
bound, integrality gives ceil(n/7)<=(n+6)/7 and hence
a<=n²/7-n/7+1<=n²/7 for n>=7. Merely using ceil(x)<x+1 would not give
this particular upper bound on a.

The bounds n/6<=b<=n/6+1 give the convenient weaker estimates

    11n²/36-n/3 <= Q <= 11n²/36+11n/6.

For example, the lower estimate follows from
b>=n/6 and 2n-b-1>=11n/6-2; the upper follows from
b<=n/6+1 and 2n-b-1<=11n/6. All factors are positive in the present
range. Consequently,

    23/50 <= p <= 47/100.

More explicitly, comparison of the lower estimate for a with the upper
estimate for Q reduces the first inequality to

    (29/252)n²-(553/6)n >= 0,

which holds at every integer n>=801. Comparison of the upper estimate
for a with the lower estimate for Q reduces the second to

    (19/252)n²-(47/3)n >= 0,

which holds at every integer n>=208. These inequalities also verify
0<a<Q, as required by the routing theorem.

The function f(p)=p²(1-p) is increasing on [23/50,47/100], since this
interval lies below 2/3. Thus

    f(p) >= f(23/50) = 14283/125000,
    (b-3)f(p) >= (n/6-3)*14283/125000.

At n=1664 the last expression is exactly
11754909/375000>31. In contrast,

    4 ln(1664)+ln(8/3) < 4*(15/2)+1 = 31.

Here ln(1664)<15/2 follows from the previously recorded finite rational
Taylor proof that exp(15/2)>1800, and ln(8/3)<1 follows from e>8/3.
The difference between the linear lower bound and
4 ln n+ln(8/3) increases for n>=1664, because its derivative is
14283/750000-4/n>0. Therefore the strict routing condition holds at
every order under consideration.

The protected-routing interval is

    [a, a+L-Q].

Its lower endpoint is the next integer after T. Moreover,

    L/2 - (11n²/36+11n/6) = 7n(n-12)/36 >= 0,

so Q<=L/2 for n>=12 and the routing interval reaches at least L/2.
Since L is even, there is no half-integer endpoint issue.

For the remaining middle part, put H_dense=n*ceil((n-1)/13). Whenever

    L/2 <= m <= L-H_dense,

the full-hub case b=n, a=m has p=m/L in [1/2,12/13]. On this interval
the minimum of p²(1-p) occurs at an endpoint, and both endpoint values
are greater than 1/16: they are 1/8 and 144/2197. Therefore

    (n-3)p²(1-p) >= (n-3)/16.

At n=1664 this lower bound is 1661/16>31, and its difference from
4 ln n+ln(8/3) increases thereafter since 1/16-4/n>0. The full-hub
routing theorem therefore supplies all these exact budgets as well.

The complete integer-interval chain is now:

1. Theorem 52 supplies [2n,3n], since 1664>=1075.
2. Theorem 38 supplies [3n,T], since 1664>=25.
3. Protected routing supplies [T+1,a+L-Q], with its upper endpoint
   at least L/2.
4. Full-hub routing supplies [L/2,L-H_dense].
5. Theorems 48 and 50 supply [L-H_dense,L-2n], since 1664>=166.

All intervals are nonempty at these orders; in particular T>=3n and
H_dense>=2n. Their union contains every exact integer budget
2n<=m<=L-2n=n(n-3). At every one of those budgets the graph is
universally winning and therefore attains M(n,m)=L-m.

The routing and dense portions retain their two-move guarantee. The
sparse portions retain their existing longer strategies and finite local
certificates; this integration does not claim that the entire main
interval becomes a two-move theorem. It also preserves the existing
construction and verification boundaries: the new overlap arithmetic
is an ordinary proof, not newly formalized Lean arithmetic or a new
finite exhaustive classification.

# The joint case with eleven vertices and twenty-three arrows

Research checkpoint, 13 September 2026. The ordinary reduction below and the
two completed finite exclusions establish the upper bound 78, subject to the
independent source audit recorded separately. The existing literal graph gives
the matching lower bound. This is a finite computer-assisted theorem, not a
Lean formalization of the enumeration.

## Statement and reduction

**Claim.** `M(11,23) = 78`.

Let `A` be the vertices of outdegree at least two and put `q=|A|`.
A vertex outside `A` is not an indirect source: with one outgoing neighbor,
the pursuer can begin there; with none, there is no route. There are at most
`n-q` arrows from outside `A`. Thus the number of eligible nonadjacent pairs
whose source lies in `A` is at most

    q(n-1) - (m-(n-q)) = q(n-2)+n-m.

At `(n,m)=(11,23)`, if `q<=10` this is at most 78. The separate incoming
argument gives the same bound if fewer than eleven vertices have indegree
at least two: an indirect recipient needs two incoming neighbors, because a
pursuer at its unique predecessor prevents every indirect delivery. Therefore
a hypothetical graph with at least 79 guarantees has every indegree and
outdegree at least two. Its degree sums force one outdegree-three vertex `U`,
one indegree-three vertex `V`, and all other degrees two. The vertices `U,V`
may coincide.

Form the bipartite arrow graph, with a source copy and a target copy of every
vertex. This bipartite graph has a perfect matching. Indeed, a nonempty source
set `S` emits at least `2|S|` arrows. If its neighborhood had size at most
`|S|-1`, the total capacity of those columns would be at most
`2(|S|-1)+1 < 2|S|`, a contradiction. A matching therefore gives a
loop-free permutation `P` of the eleven vertices.

Up to simultaneous relabeling, `P` is specified by its cycle lengths, all at
least two. There are exactly fourteen nondecreasing partitions of eleven
with no part one. Put each cycle on a consecutive interval in the usual
cyclic order. Rotations of a cycle and swaps of equal-length cycles let us
place `U` at the first vertex of one cycle of each distinct length. After
that normalization, `V` is allowed to be any of the eleven vertices. The
residual graph has outgoing degree one everywhere except degree two at `U`,
and incoming degree one everywhere except degree two at `V`. The search
enumerates every residual assignment, excluding loops and the arrows of `P`.
The two residual neighbors of `U` are enumerated in increasing order.

These normal forms are complete, not necessarily disjoint. Repetition is
harmless for an upper bound. There is no assumption that `U` and `V` are in
different cycles or are different vertices.

## Permanent losing-pair bounds during enumeration

The source is `src/small_sparse_one_excess.cpp`. A prefix specifies all rows
before its current index and the matching arrow in every remaining row.
Only facts valid for every completion may prune the prefix.

1. If a completed source row `O(s)` lies in the current closed outgoing
   neighborhood of a distinct vertex `c`, the pursuer can start at `c` and
   capture after the messenger's first nonterminal move. Every indirect
   pair from `s` loses. Waiting at `s` does not help: when necessary the
   pursuer waits at `c` until the messenger moves.
2. If the completed predecessor set of a target `t` lies in the current
   closed outgoing neighborhood of `c`, every indirect pair to `t` with
   source different from `c` loses. The pursuer camps at `c` until the
   messenger enters a predecessor of `t`, then captures. The initial-source
   exception is explicitly retained. A final move directly to `t` is never
   treated as an interception, since delivery precedes collision.

The search stores the union of these killed pairs. Partial cop rows contain
only arrows that will persist, and predecessor sets are used only when their
prescribed final capacity is filled. Completed source rows are used only
after all their prescribed outgoing arrows are fixed. Thus each stored fact
is permanent. For source `s`, the number of possible remaining indirect
pairs is bounded by the smaller of

    10 - final_outdegree(s)
    number of targets outside {s}, existing O(s), and killed_pairs(s).

Summing these row bounds gives a valid upper bound. The first term accounts
for missing arrows that an unfinished row must still add. A prefix is
discarded only when this sum is at most 78.

At depths eight and later, a stronger necessary condition is also checked.
Give each unfinished messenger row every still-available residual arrow,
ignoring simultaneous capacity conflicts; this produces a supergraph of
every completion. For each cop vertex `c`, remove the fixed closed outgoing
neighborhood `F_c={c} union O(c)` from possible *interior* messenger
positions. Compute all reachability through the remaining vertices in the
optimistic graph. Starting at `s!=c`, the first step may leave `F_c`; the
final step may enter the recipient anywhere, including inside `F_c`.
If no such optimistic route reaches `t`, camping at `c` followed by capture
at the first interior visit to `F_c` defeats that pair in every completion.
Such pairs are added to the permanent union. Waits do not create a route
absent from this reachability calculation.

The implementation keeps a separate killed-pair array at each prefix depth.
Children inherit parent facts; sibling-specific facts are not retained when
backtracking. Fixed cop arrows and the optimistic messenger graph make the
guarded-path bound one-sided in the required direction.

## Exact game and its early decision rule

Every surviving complete graph is evaluated with the ordinary recipient
least fixed point. Both players may wait; the messenger moves first;
delivery is terminal before capture; a nonterminal collision loses. A pair
`(s,t)` counts only when it is nonadjacent and wins for every initial cop
vertex other than `s`.

For each unsolved recipient, the number of eligible pairs not in the
permanent killed-pair union is a valid upper bound for that column. After a
recipient is solved exactly, its potential is replaced by its actual count.
If the accumulated actual count plus the remaining potential is at most 78,
the evaluation returns the sentinel `-1`. This sentinel is a decision
rejection, not an actual graph value. A graph with at least 79 guarantees
cannot be rejected by this rule.

## Completed coverage and evidence

Compile with a C++17 compiler, for example:

    c++ -O3 -std=c++17 src/small_sparse_one_excess.cpp -o /tmp/cop-prisoner-small-sparse-one-excess

Run the two independent parameter ranges (the second argument is a seconds
cap; any `complete:false` output proves no upper bound):

    /tmp/cop-prisoner-small-sparse-one-excess 11 60 78 1 6
    /tmp/cop-prisoner-small-sparse-one-excess 11 60 78 7 14

The saved complete outputs are:

- `research/small-sparse-one-excess11-partitions1-6.json`: six complete
  permutation types, 154 excess patterns, 67,882,213 search nodes, 467,394
  actual game decisions; elapsed 38.3843 seconds.
- `research/small-sparse-one-excess11-partitions7-14.json`: eight complete
  permutation types, 176 excess patterns, 53,908,610 search nodes, 685,036
  actual game decisions; elapsed 32.4925 seconds.

Together these cover all fourteen types and all 330 excess patterns. Every
reached game evaluation returned the sound rejection sentinel; there was no
candidate of score at least 79. The final source SHA-256 and hashes of both
outputs are pinned in `research/small-sparse-eleven23-checkpoint.json`.

The lower witness is
`research/small-plateau-search-n11-m23-seed111323-certificate.json`, with
eleven recipients and 2,662 alternating game states. It gives 78 guaranteed
indirect pairs. Its degree pattern need not belong to the enumerated class:
the reduction to minimum degrees two applies only to a putative score
strictly above 78. In fact this witness has a vertex of indegree one.

Earlier whole-range pilots were stopped at their time caps and are retained
as historical evidence only. The completed two-range result supersedes
those pilots as an upper-bound certificate. No empirical maximum from an
incomplete run is used in the proof.

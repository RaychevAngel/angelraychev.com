# Independent review of the tiny live-capacity extension

13 September 2026. The added prunes in `src/finish_tiny_live.cpp` pass ordinary source review and independent adversarial-prefix tests. The completed `(n,m,target)=(12,12,10)` exclusion and disjoint completed `(13,13,12)` exclusions pass profile and termination checks. This review covers actual runs at n>=4; the inherited n=3 input guard is outside the approved scope because profile generation divides by n-3.

## New source-row condition

A source of an indirect guarantee must have at least two nonsink outgoing neighbors. If it has at most one, place the pursuer at the unique nonsink neighbor and camp there. Moving to it is captured; every other outgoing move enters a sink. Such a sink cannot be the missing recipient on the first move, and cannot make later progress. With no nonsink neighbor, any allowed initial cop position suffices. Waiting does not produce receipt. All sink statuses come from the fixed complete degree profile, so the test is sound before their rows are assigned.

The separate check that an unassigned source has at least two possible positive-outdegree vertices other than itself is weaker than its eventual requirement. It can remove only an impossible source.

## Viable recipient predecessors

An indirect guarantee requires at least two predecessors of the recipient having positive indegree. A zero-indegree predecessor cannot be reached after the initial position. If the initial source itself were such a predecessor, the pair would be direct and not counted. When at most one reachable predecessor remains, a pursuer can camp there and prevent every indirect delivery.

For each vertex v, `incoming_possible` contains every vertex whose final indegree could be positive: it includes any existing predecessor, or any unassigned positive-outdegree tail distinct from v. Ignoring whether that tail can actually spend an arrow on v makes this a superset. Likewise `pred[t]` united with all unassigned positive-outdegree tails other than t contains every possible final predecessor of t. Intersecting this set with `incoming_possible` still contains every actual positive-indegree predecessor of t. Thus `viable[t]` is an upper approximation. A target with fewer than two members cannot support an indirect pair.

If the closed delivery neighborhood of a completed cop c contains the entire viable predecessor set, c can camp there. Every reachable last predecessor of t is captured before delivery. A zero-indegree predecessor cannot be entered on a later move, and the missing initial pair excludes immediate receipt from an initial predecessor. This holds for t=c as well: recipient priority is retained, but prevents capture only after actual receipt. Cop c is excluded when the initial source is c; the code explicitly preserves that exception.

The live candidate count removes only impossible recipient columns, diagonal pairs, known direct arrows, and pairs with a permitted camping cop. For an unfinished source it does not pretend to know the future direct-arrow set. Taking the minimum of its possible candidate count and the general row capacity n-1-deg[s] is therefore an upper bound. Adding these per-row bounds is conservative.

## Coverage and earlier components

The `delivery_count`, `recurse`, `profiles`, and `main` function bodies are exactly unchanged from `src/small_plateau_tiny_budget.cpp`. Only source blocking and `possible` gain the new live-capacity logic. Degree generation and the chronological equal-degree/equal-incoming suffix normalization consequently retain the earlier reviewed completeness argument. Both live dimensions are still maximized in the incidence table. The remaining arrow-budget and recipient-capacity estimates remain conservative.

The completed n=12 log has target10, exact budget12, first profile0, 65 total and checked profiles, no counterexample and no timeout. A separate combinations-with-replacement count reproduces all 65 possible sorted degree profiles with the necessary number of degree-at-least-two sources. The run reports 46,591,853 prefixes and 8.64694 seconds. Its reported best8 is a filtered evaluated maximum, not a global upper8. The complete exclusion proves only that no score10 exists. Combined with the separately retained score9 witness this gives M(12,12)=9. The accepted host reduction then supplies the global budget12 conclusion; that host theorem is not reproved here.

## Independent checks of the actual added prunes

`src/endpoint40_tiny_live_review.cpp` imports the producer only to call its actual `source_blocked` and `live_possible` functions. Its game calculation is an independently written compressed least-fixed-point solver and does not call the imported game solver.

It tests every loopless directed graph through order4, 2,400 deterministic random graphs on orders5 through12, and 86 saved literal graphs. All chronological prefix lengths are tested. The actual live bound never falls below the actual completed graph's score; every blocked source has no indirect guarantee. It also reconstructs viable predecessor supersets by literal loops and checks every claimed specific cop-camping state against the independent game.

All checks pass: 6,651 graphs (1,459 with positive score), 44,376 prefixes, and 662,312 specific camping states, in 0.0934105 seconds. The commands were:

    c++ -O3 -std=c++17 src/endpoint40_tiny_live_review.cpp -o src/endpoint40_tiny_live_review.bin
    src/endpoint40_tiny_live_review.bin > research/endpoint40_tiny_live_review_tests.json

These tests attack the added rules, not the full n=12 enumeration tree. The source-pinned receipt is `research/endpoint40_tiny_live_review.json`. It claims ordinary/source coverage review, independent profile counting, and independent prune tests. It does not claim a second full traversal; the incomplete n=13,m=13 pilot is not used.

## Completed budget13 extension

The producer source hash is unchanged from the approved budget12 review. A separate integer-partition recurrence independently counts 88 possible degree profiles at n=13,m=13,target12. The source orders these profiles identically in each invocation.

The completed head file `research/finish-tiny-live-n13-m13-t12-head85.json` covers exactly indices0 through84: 85 checked profiles, 229,265,070 prefixes, 50.9939 seconds. The completed tail file `research/finish-tiny-live-n13-m13-t12-tail85.json` covers exactly indices85 through87: three checked profiles, 269,856,493 prefixes, 48.6109 seconds. Both report all88 total profiles, no counterexample, and completion. The independently checked intervals are disjoint and their union is exactly0 through87.

Consequently these completed runs exclude score12 at (13,13). The retained literal eight-vertex, thirteen-arrow, score11 graph provides the lower bound after isolates. The accepted host cutoff13 transfers this equality to the unrestricted budget13 maximum and every larger host. The original timed-out pilot is historical only and contributes no exclusion coverage. The same source-pinned receipt now includes both completed split logs without changing the approved budget12 result.

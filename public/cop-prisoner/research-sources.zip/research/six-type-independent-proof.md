# Independent verification of the six-type all-order construction

## Result and proof boundary

The independently checked local certificates prove a universally winning
two-in/two-out directed graph at **every order `n>=385`**, using the
ordinary projection and composition argument below. Consequently

`M_V(n)=M_E(2n)=M(n,2n)=n(n-3)` for every `n>=385`.

The upper bounds were established previously. The new construction and
its primary local certificates are due to the current construction
analysis. This note independently reconstructs the graph and finite
arenas, checks every relevant alternating game state, and audits the
infinite/cyclic interpretation. This is a computer-assisted proof with
finite rank certificates, not a Lean formalization and not extrapolation
from successful finite circles.

## Graph and deletion rule

The unwrapped graph has vertices `(i,j)` with `i in Z`, `0<=j<=5`.
There are two outgoing permutations:

| Type j | First successor | Second successor |
|---|---|---|
| 0 | (i,1) | (i,5) |
| 1 | (i,2) | (i+1,4) |
| 2 | (i,3) | (i+1,1) |
| 3 | (i,4) | (i-1,0) |
| 4 | (i,5) | (i+1,2) |
| 5 | (i+1,0) | (i-1,3) |

At selected columns `h`, delete `(h,4)` and smooth each permutation
separately. The only changed arcs are

`(h,3)->(h,5)`

and

`(h-1,1)->(h+1,2)`.

The first replaces passage through the deleted vertex in the first
permutation; the second does so in the second permutation. In particular,
every arc changes the column by at most two, and the only jump of two
is the displayed positive jump.

Reduce the column coordinate modulo a circumference `k>=15`. Each
unsmoothed map is a permutation: the first is the Hamilton cycle, and
the second has permutation of types `(0 5 3)(1 4 2)` with fixed column
translations. Deleting vertices from permutation cycles and connecting
each retained predecessor to the next retained successor again gives
a permutation. No cycle is entirely deleted, since only type four is
removed. The explicit successor formulas show that each retained
vertex has two distinct, nonloop successors when `k>=15`. Thus the
smoothed graph is simple, loopless, and two-in/two-out.

## Independently defined finite arenas

The messenger is restricted to columns `[-4,4]`. The cop has all existing
vertices in columns `[-6,6]` and one additional exterior state `Omega`.
There is either no deleted vertex in that cop window or exactly one,
at `(h,4)` with `-6<=h<=6`. These are 14 distinct local patterns.

Both players may wait. Messenger moves leaving its window are omitted.
For an internal cop position, every move leaving the cop window leads
to `Omega`. From `Omega`, the cop may wait or move to **any existing
vertex** in columns `-6,-5,5,6`. This reentry includes every possibility
for a real cop whose column jump is at most two.

Each pattern has one safe-transfer objective: starting at any existing
type in column `-1`, reach column zero safely. Success is seeded **only
on the messenger's turn**, with unequal player positions. Reaching the
goal column before the cop's response is not treated as success. This
makes safe transfers composable in the actual game.

For each existing target type in column zero, the pattern also has a
delivery objective: start at any existing type in column `-2` and deliver
to that target. Delivery seeds both turn layers at the target, even if
the cop is there, respecting immediate receipt priority. All other
collisions are losing terminals.

There are `14*7-1=97` objective instances; the missing one is delivery
to type four when column zero contains the hole.

## Independent computation and full certificate checks

`src/six_type_independent_verify.py` imports neither the primary graph
builder nor the primary game solver. It uses direct formulas for both
smoothed successors and constructs the two alternating turns explicitly.
An AND/OR reverse attractor computes winning ranks and a chosen move at
each winning messenger state.

A separate pass over all states checks:

- every genuine success state has rank zero;
- every other collision state is losing;
- every winning messenger state chooses an actual lower-rank winning
  successor;
- every possible successor of a winning cop state is lower-rank winning;
- all successors of a losing messenger state are losing;
- every losing nonterminal cop state has a losing successor.

The last two checks verify the full losing-region closure as well as
the winning strategies. Rank descent proves finite completion. The
required starts include every legal internal cop position and `Omega`.

All 97 instances passed: **44,317 required starting states and 808,212
alternating states** were checked. The largest required bound is nine
messenger moves for safe transfer and 26 for delivery. These bounds
agree with the separately produced primary certificates, despite the
different solver and state representation.

The full ranks and chosen moves are saved in
`research/six-type-independent-certificates.json.gz`. This gzip stream
is deterministic and accompanied by the summary and SHA-256 values in
`research/six-type-independent-summary.json`. Run the independent checker
with:

```sh
python3 src/six_type_independent_verify.py
```

## Projection from the cyclic graph

Assume the deleted columns have cyclic separation at least 13. Around
any chosen center, the 13 cop-window columns `[-6,6]` then contain at
most one hole, so one of the 14 patterns applies. When `k>=15`, these
columns are distinct and at least two exterior columns remain.

Map a real cop inside the window to its actual vertex and every real
cop outside it to `Omega`. A real arc has column jump at most two.
It cannot go directly from one boundary of the displayed window to
the opposite boundary through a missing exterior interval: the shortest
such jump has length `k-12>=3`. Hence every internal-to-internal move
agrees with the local arena. Internal-to-exterior moves go to `Omega`,
and exterior-to-internal moves can only enter the four reentry columns
`-6,-5,5,6`. Exterior-to-exterior moves stay at `Omega`.

A hole immediately outside the cop window can change a boundary arc,
but only replaces one exterior endpoint by another exterior endpoint.
For example, a hole at column seven replaces the arc from `(6,1)` to
`(7,4)` by the arc to `(8,2)`, both projected to `Omega`. No omitted
exterior hole changes an internal endpoint or a messenger move retained
within `[-4,4]`. Thus the single-pattern arena covers every actual
move even when other holes exist elsewhere on the cycle.

The messenger's retained local moves are real graph moves. An exterior
cop cannot coincide with a messenger vertex in `[-4,4]`. Internal
collisions agree exactly. The arena grants the cop extra reentry choices,
so a strategy winning against every arena response also wins against
the actual cop. This is an overapproximation of the adversary, not an
assumption that the real cop teleports.

## Safe composition and all orders

Fix an arbitrary source, recipient, and legal initial cop. Repeatedly
apply the safe-transfer certificate centered at the next column. Each
application advances the messenger by one column and ends on a safe
messenger turn, with no restriction on its type or on the cop position.
After at most `k-1` transfers, the messenger lies two columns before
the recipient. Apply that recipient's delivery certificate. If the
actual recipient was reached during an earlier transfer, delivery has
already succeeded. Otherwise the concatenated strategy delivers within

`9(k-1)+26 = 9k+17`

messenger moves. The objective is finite delivery, not merely evasion.

For any `n>=385`, set

`k=ceil(n/6)`, `r=6k-n`,

so `k>=65` and `0<=r<=5`. Delete type four at columns

`0,13,26,...,13(r-1)`

when `r>0`. Consecutive gaps are 13 and the final cyclic gap is at least
13, since `k>=65` and `r<=5`. For zero or one hole the separation
condition is immediate. The graph has exactly `6k-r=n` vertices and
`2n` arcs. The preceding strategy proves that every missing nonloop pair
is guaranteed, giving `I=n(n-3)` and the announced three exact maxima.

## Issues specifically checked

1. Using a cop window of 13 columns at circumference 14 would permit a
   jump of two directly across the exterior gap. The proof explicitly
   requires circumference at least 15 and does not make that mistake.
2. A safe-transfer terminal occurs after the cop response, unlike final
   receipt. This distinction is built into the independently generated
   two-turn certificates.
3. The exterior state permits two reentry layers, because smoothing
   creates jumps of two. One layer would be insufficient.
4. Multiple holes are separated in the **cyclic** metric, including the
   final gap. Merely separating their listed integer representatives
   would not justify the window argument.
5. Deleted target types and deleted source types are omitted, rather
   than treated as winning or empty game states.
6. The finite checks establish local games only. The all-order conclusion
   additionally uses the explicit projection and finite composition
   arguments above; no untested family of circles is assumed.

## Stronger spacing verification: every n>=85

The preceding single-hole verification was subsequently strengthened.
`src/six_type_independent_spacing.py` enumerates **all 189 subsets** of
the 13 cop-window columns whose distinct hole columns have separation
at least three. For each subset it reconstructs both smoothed successor
maps directly, omits all removed vertices, and invokes the independent
explicit-state solver and full checker described above.

All **1,287 objective instances**, **560,885 required starts**, and
**10,271,740 alternating states** passed. The maximum safe-transfer
bound remains nine moves; the maximum delivery bound is now 27 moves.
Full ranks are in
`research/six-type-independent-spacing-3-certificates.json.gz`, and
their hash and summary are in
`research/six-type-independent-spacing-3-summary.json`.

The ordinary projection proof is unchanged except that a window may
contain several holes and uses its corresponding local subset. The
same direct smoothing formulas remain valid: every deleted vertex has
type four, and its next vertex in either permutation is not deleted,
so smoothing never creates a longer jump. Exterior holes still only
change exterior boundary endpoints. Every actual local subset has
linear separation at least three when the global holes have cyclic
separation at least three.

For any `n>=85`, take `k=ceil(n/6)>=15`, `r=6k-n<=5`, and holes
`0,3,...,3(r-1)`. Their last cyclic gap is at least three, including
the extremal case `k=15,r=5`. The independent certificates and
composition therefore establish universal two-in/two-out graphs at
every such order. The improved conclusion is

`M_V(n)=M_E(2n)=M(n,2n)=n(n-3)` for every `n>=85`,

with delivery bound `9(k-1)+27=9k+18`. This supersedes the initial
threshold 385; the original 97-module certificate remains valid as a
smaller independently reproducible subset of the argument.

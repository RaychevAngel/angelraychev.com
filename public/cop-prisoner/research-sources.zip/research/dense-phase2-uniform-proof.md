# Uniform robust dense envelopes: ordinary proofs

The numerical statements here are stronger than the old protected-envelope
bound, with exactly the same two-move and arbitrary-subset guarantees. No
published source has been edited by this lane. The parent must independently
review these proofs before promotion.

## Common criterion

Let B be a compulsory missing graph and F=B union O its full envelope. If

    B+(c) is not contained in F+(s) union F−(t)

for every (s,t) in F and every c distinct from s, then every graph of missing
arcs B union O′, O′ subset O, has every missing pair winning in two messenger
moves. A witness u outside the displayed danger set is reachable from s, is
unreachable by the cop on its reply from c, and can reach t on the next move.
Removing optional missing arcs shrinks the danger sets and retains every
compulsory witness.

All constructions below have exactly2n compulsory missing arcs. All missing
counts from2n through the stated cap therefore occur, and every subset of the
optional set works. The algorithms are explicit and run in polynomial time
(writing their quadratic output is already sufficient).

## A. A residue-five construction for every n>=30

Write n=10q+s, q>=3, 0<=s<=9, and put k=5q. Use points P_i and lines L_i,
i modulo k. The compulsory arcs of the core are

    P_i -> L_i,L_(i−1);        L_i -> P_(i+4),P_(i+6).

Its optional arcs are

    P_i -> P_(i+d), d in D={10,15,...,k−5};
    L_i -> L_(i+e), e in E={5,10,...,k−5}.

For a=0,...,s−1 add a vertex x_a with compulsory arcs

    x_a -> P_a,L_(a+3).

There are no compulsory arcs to the added vertices. Every ordered nonloop arc
x_a -> x_b between distinct added vertices is optional.

The resulting cap is

    H5(n)=10q²+5q+s²+s.

Indeed |D|=q−2, |E|=q−1, and the core has4k compulsory plus k(2q−3) optional
arcs. The added part contributes2s compulsory and s(s−1) optional arcs.

### Proof on the core

Translate each source to index0. The six possible danger sets, written as
(point indices; line indices), are:

```
P0 -> L0:   (D union {0,1};       {0,−1} union (−E))
P0 -> L−1:  (D union {−1,0};      {0,−1} union (−1−E))
P0 -> Pd:   (D union (d−D);       {0,−1,d−4,d−6})
L0 -> P4:   ({4,6} union (4−D);   E union {0,−2})
L0 -> P6:   ({4,6} union (6−D);   E union {0,2})
L0 -> Le:   ({4,6,e,e+1};         E union (e−E))
```

A compulsory point row consists of two adjacent lines; a compulsory line row
consists of two points at distance2. D and E contain only multiples of5.
Consequently every displayed set contains no forbidden pair of the relevant
kind, except the source's own compulsory row. The only optional-point exception
not excluded by residues would be d=5, which is excluded from D. For example,
{0,−1,d−4,d−6} can acquire an additional adjacent pair only at d=2,4,5,7;
only5 is a multiple of5. In the final point set {4,6,e,e+1}, an apparent
distance-two pair at e=5 is just the existing pair {4,6}. All modular wrap
arguments are valid because5 divides k and k>=15.

### Added vertices as cops

The row of x_a is {P_a,L_(a+3)}. It is not contained in an old danger set.
For the two optional-arc types this follows immediately modulo5: optional
P->P dangers have all point indices equal to the source residue and their line
residues differ from it by0,1,or4; optional L->L dangers have one line residue
and point residues differing from it by0,1,or4. The difference3 is absent.
The four compulsory-arc types give the same exclusion, except potentially the
isolated pair (P_(i+1),L_(i−1)) in P_i->L_i or (P_(i+4),L_(i+2)) in
L_i->P_(i+6). Their line-minus-point difference is−2, which is not3 modulo
k>=15.

### Added vertices as sources

For x_a->P_a the old point part of the danger is

    {P_a} union {P_(a−d):d in D},

all one residue modulo5, and the old line part is

    {L_(a+3),L_(a−4),L_(a−6)}.

The latter has differences7,9,2, none congruent to±1 modulo k>=15.
Thus neither kind of old compulsory row is blocked. Another new row x_b
could be blocked only if b−a is a multiple of5 and belongs to{0,−7,−9};
this forces b=a, the excluded source.

For x_a->L_(a+3), the old point part is{P_a,P_(a+3),P_(a+4)}; its differences
are3,4,1, none congruent to±2 modulo k>=15. The old line part has one residue
modulo5. Another new row would require b−a in{0,3,4} to be a multiple of5,
again forcing b=a.

An optional arc x_a->x_b has old danger part exactly{P_a,L_(a+3)}.
No old compulsory row, or distinct new compulsory row, is contained in it.
Incoming arcs from new vertices merely add new vertices to other danger sets;
every compulsory row lies entirely in the old core. They therefore do not
invalidate any previous witness. The common criterion proves the theorem.

### Comparison with the previous cap

H5(n)>3n because

    H5(n)−3n=5q(2q−5)+(s−1)²−1 >=14.

Moreover

    13H5(n)−n(n+11)=30q²−45q−20qs+12s²+2s >0.

Completing the square in s gives minimum
[260(q−1)²−261]/12>0 for q>=3. Since
ceil((n−1)/13)<=(n+11)/13, H5 strictly exceeds
n max{3,ceil((n−1)/13)} at every n>=30.

## B. A parity construction with cap n²/4−O(n)

Write n=4q+s, q>=11, 0<=s<=3; hence n>=44. Put k=2q. Use the compulsory core

    P_i -> L_i,L_(i−1);        L_i -> P_(i+4),P_(i+7).

Let D contain every nonzero even residue modulo k except

    ±2, ±4, ±6, ±8,

and let E contain every nonzero even residue except

    ±2, ±4, 8, 10, 12.

The optional old arcs are P_i->P_(i+d), d in D, and L_i->L_(i+e), e in E.
For a=0,...,s−1 add x_a with compulsory row{P_a,P_(a+5)}. All directed nonloop
arcs among added vertices are optional. No old vertex has a missing arc to an
added vertex.

This construction has cap

    H4(n)=4q²−26q+s²+s.

The counts are |D|=q−9 and |E|=q−8, since k>=22 makes all listed exclusions
distinct within their respective lists. Together with2n compulsory arcs this
gives the stated cap.

### Core proof by parity and excluded offsets

The six source-translated danger sets are now

```
P0 -> L0:   (D union {0,1};       {0,−1} union (−E))
P0 -> L−1:  (D union {−1,0};      {0,−1} union (−1−E))
P0 -> Pd:   (D union (d−D);       {0,−1,d−4,d−7})
L0 -> P4:   ({4,7} union (4−D);   E union {0,−3})
L0 -> P7:   ({4,7} union (7−D);   E union {0,3})
L0 -> Le:   ({4,7,e,e+1};         E union (e−E))
```

Point-cop rows are adjacent line pairs; line-cop rows are point pairs of
distance3. Both forbidden differences are odd. All D,E indices are even.
For each displayed danger set, the only exceptional offsets that could block
an old cop distinct from the source are as follows:

* P0->L0: D offsets4,−2 or E offset2.
* P0->L−1: D offsets2,−4 or E offset−2.
* P0->Pd: d=2 or8.
* L0->P4: D offset−6 or E offsets−2,−4.
* L0->P7: D offset6 or E offsets2,4.
* L0->Le: e=0 or10.

All are excluded. Coincidences producing the source's own row do not create a
second blocked cop: adjacent line pairs and distance-three point pairs have
unique source indices for k>=22. This proves robustness for the old core.

### Added vertices as cops

A new row is a point pair of distance5. Applying this distance to the point
parts in the displayed list gives the following possible exceptional offsets:

* P0->L0: D offsets6,−4.
* P0->L−1: D offsets4,−6.
* L0->P4: D offsets2,−8.
* L0->P7: D offsets−2,8.
* P0->Pd: none, because every point index is even.
* L0->Le: E offsets−2,8,2,12.

Again every exception is excluded. Thus all new compulsory rows provide valid
cop witnesses for old missing pairs.

### Added vertices as sources

For x_a->P_a the old point danger is
{P_a,P_(a+5)} union{P_(a−d):d in D}; the old line danger is
{L_(a−4),L_(a−7)}. The latter pair is not adjacent. A distance-three point pair
could arise only at D offsets−2 or−8, which are excluded.

For x_a->P_(a+5), the old point danger is
{P_a,P_(a+5)} union{P_(a+5−d):d in D}; the old line danger is another pair of
distance3. A distance-three point pair would require D offset2 or8, excluded.

In either case a distinct new row {P_b,P_(b+5)} cannot be blocked: the danger
has only one point of one parity, so this would require b=a or b=a±5 modulo k.
But a,b belong to{0,1,2} and k>=22. The first is the excluded source and the
latter two are impossible.

For an optional new-to-new arc, the old danger is precisely the source's
distance-five point pair. It contains neither an old distance-three point row
nor an old line row, and distinct added vertices have distinct rows. As before,
all additional danger vertices are new and occur in no compulsory row. This
completes the robust two-move proof.

### Comparison with the previous cap

H4(n)>3n: its difference is4q²−38q+(s−1)²−1, at least65 for q>=11.
Also

    13H4(n)−n(n+11)=36q²−382q−8qs+12s²+2s >0.

At q=11 the four values for s=0,1,2,3 are154,80,30,4. Increasing q increases
each value. Thus H4 strictly exceeds the old protected cap at every n>=44.

## What this supersedes, and what it does not

Taking H5 for n>=30 and the larger of H5,H4 where both apply strictly extends
the old protected-envelope numerical theorem for every n>=30, preserving its
delivery time, explicit polynomial construction, and arbitrary optional subsets.
Its old n=19,...,29 range had cap exactly3n. It must be retained separately:
the newly repaired envelopes cover all2n<=h<=3n for n>=22, while the former
protected construction still supplies h=3n at n=19,20,21.

The quarter-density construction dominates H5 for all n>=52. At smaller
overlapping orders H5 is stronger at44,45,46,47,49,50,51; H4 is stronger at48.
These are finite cap comparisons, not separate asymptotic research results.
No new public theorem is needed for the intermediate mod-three or mod-four
experiments that led to this construction; they were not promoted.

## Evidence and proof boundary

`src/dense_phase2_uniform_envelope.py` verifies every full-envelope pair/cop for
all n30,...,200 and records `research/dense-phase2-uniform-envelope.json`.
`src/dense_phase2_quarter_envelope.py` verifies n44,...,160 and records
`research/dense-phase2-quarter-envelope.json`. These finite tests support the
ordinary proofs above; they do not replace them. No Lean extension is claimed.

Two unsuccessful bounded directions are retained only as research history:
local repairs of the existing modular template at19,20,21 found no witnesses;
this is not an impossibility result. The original residue-five family was
first derived through separate even and two-block odd constructions. Both are
subsumed by the single mixed-row construction and are not separate results.

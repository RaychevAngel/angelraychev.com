# Superseded numerical proof, retained for reproducibility

The statement is superseded in order, budget and time by Theorem52.
The old construction and proof below remain a research record.

# Bridging the entire sparse interval at every large order

The six-type construction can also support optional arcs. We keep those
arcs away from deleted vertices, allowing two separately verified local
strategies to cover every part of the graph.

**Theorem 41 (with finite local certificates).** For every integer
$n\ge2419$ and every integer $2n\le m\le3n$, there is an explicit graph
with
$$M(n,m)=n(n-1)-m.$$
Every pair can be delivered within $9\lceil n/6\rceil+26$ messenger moves.

**Proof.** Put $k=\lceil n/6\rceil\ge404$ and $r=6k-n\in\{0,\ldots,5\}$.
Use the six-type graph of Theorem 40, with deletions of type 4 in columns
$$S=\{0,17,\ldots,17(r-1)\}$$
when $r>0$, and no deletions when $r=0$. The cyclic gaps are at least 17.
Smooth both permutation paths as in that theorem, obtaining exactly $n$
vertices and $2n$ arcs.

The following eight triples $(j,d,t)$ specify optional arcs
$(i,j)\to(i+d,t)$:
$$
(1,-3,5),\ (3,-3,5),\ (4,-3,0),\ (4,3,1),\
(2,3,0),\ (3,3,0),\ (3,-3,0),\ (5,-2,0).
$$
Allow them only at columns $i$ whose cyclic distance from every member of
$S$ exceeds 16. Their target types are never 4, and their source columns
contain no deleted vertex. They are distinct nonloop arcs, absent from the
smoothed base graph: all but the last have column displacement $\pm3$;
the last has displacement $-2$, whereas the base displacements are $0,\pm1$
and the sole smoothed displacement is $+2$.

For $r\ge1$, the forbidden source columns are contained in the cyclic
image of the integer interval
$$[-16,17(r-1)+16],$$
which has $17r+16\le101$ elements. At least $k-101$ columns therefore
permit all eight optional arcs, giving at least
$$8(k-101)=8k-808\ge6k\ge n$$
optional arcs. With no deletions there are $8k\ge n$. Thus any prescribed
$m-2n\le n$ of these arcs may be selected. It remains to prove that every
such selection preserves universal delivery.

Consider local messenger columns $[-4,4]$ and pursuer columns $[-8,8]$,
with an outside state $\Omega$. The messenger uses only base arcs and may
not leave its window. A pursuer move leaving its window enters $\Omega$;
from $\Omega$ it may wait or enter any existing vertex in columns
$-8,-7,-6,6,7,8$. These three boundary layers cover every possible
three-column re-entry.

There are two kinds of certified arenas:

1. There is no deletion inside the pursuer window. The messenger has only
   the original six-type moves, while the pursuer has all eight optional
   arc types at every source column in its window.
2. There is one deletion, at some offset $h\in[-8,8]$. Both players use
   the smoothed base moves; the pursuer still has the same three-layer
   outside re-entry rule.

The finite certificates prove safe transfer from any existing type in
column $-1$ to column zero in at most nine messenger moves, and delivery
from any existing type in column $-2$ to any existing recipient in column
zero in at most 35 moves. The transfer completes only on a messenger turn
after the pursuer response, with distinct positions. Delivery has immediate
receipt priority. There are 125 certificates: seven for the augmented
unmodified arena, and seven for each of the 17 possible deletion offsets,
except for the absent recipient at $(0,4)$ when $h=0$.

Every actual local window fits one of these cases. Its 17 represented
pursuer columns have diameter 16, so cannot contain two deletions. If it
contains a deletion $h$, each represented pursuer source column is at
cyclic distance at most 16 from $h$, and hence none of its optional arcs
was allowed. If it contains no deletion, the augmented arena contains
every possible actual pursuer move and every messenger move used by the
strategy. An exterior deletion changes no represented-to-represented
base arc: the only affected boundary tail has both its original and
smoothed heads outside. Discarded messenger exits are likewise unaffected.

All actual moves have column displacement at most three. Since $k\ge404$,
the exterior gap between the two ends of the represented pursuer window
has at least three columns. No single move can cross that entire gap
between two represented vertices. An exterior return lands in one of the
three allowed boundary layers. Thus mapping every exterior pursuer to
$\Omega$ correctly includes all possible responses. The actual pursuer
has no options beyond the relevant certified arena.

Repeatedly use safe transfer to advance the messenger by one column,
ending each phase after the pursuer response. At most $k-1$ transfers
place it two columns before the recipient. Apply the appropriate delivery
certificate. The total is at most
$$9(k-1)+35=9k+26.$$
This proves universal delivery for every selected subset of optional arcs.
All $n(n-1)-m$ missing pairs are consequently guaranteed. $\square$

The primary generator and saved-rank checker are
`src/six_type_budget_certificate.py` and
`research/six-type-budget-certificates.json.gz`. The independent explicit
alternating-game implementation checks all 125 modules, 75,085 required
initial states, and 1,365,108 complete states, including winning rank
decrease and closure of losing states. Its sources and receipts are
`src/six_type_independent_augmented.py` and
`research/six-type-independent-augmented-certificates.json.gz`.
These are finite proof certificates coupled with the ordinary uniform
projection above. They are not presently Lean formalizations.

**Corollary 42 (the complete main interval at all sufficiently large
orders).** There is an absolute integer $N$ such that, for every $n\ge N$
and every integer $2n\le m\le n(n-3)$,
$$\boxed{M(n,m)=n(n-1)-m.}$$

**Proof.** Increase the threshold from Corollary 39, if necessary, to be
at least 2419. Theorem 41 supplies every integer budget from $2n$ to $3n$;
Corollary 39 supplies every remaining budget through $n(n-3)$. $\square$

This proves Raychev's main-interval conjecture with a sufficiently-large
order threshold. The threshold $N$ is not claimed to be 2419: the latter
is sufficient for Theorem 41 only, while the combined existence argument
retains the asymptotic threshold from Corollaries 26 and 39. The
construction is explicit in the intervals furnished by Theorems 38 and
41; the middle-density existence step is probabilistic. The result does
not settle odd arc-only extrema, the exact small-order threshold, or all
joint extrema below $2n$.

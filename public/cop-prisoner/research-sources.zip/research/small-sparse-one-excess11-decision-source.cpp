// Full one-excess threshold class; permanent killed-pair union retains camping when potentially competitive.
// Adapted from frozen small_exceptional_one_excess.cpp; perfect-matching normalization unchanged.
// Complete search among min-in/outdegree2 graphs with 2n+1 arcs,
// including every camping pattern whose certified losses permit the threshold. Hall ensures a perfect matching.
// Fix matching alpha by cycle partition; enumerate residual 1/2 degrees.
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <set>
#include <vector>
using namespace std;constexpr int n=11;int P[12],O[12],pred[12],used[12],cap[12],U,V;bool ready[12],complete=true;long long nodes=0,leaves=0,parts=0,patterns=0;int best=-1,BO[12];double limit;auto began=chrono::steady_clock::now();
int threshold=78;extern int bad_stack[13][12];long long early_game_rejects=0;
int game(){
 int all=(1<<n)-1,I=0,W[12],safe[12],NW[12],potential[12],remaining=0;
 for(int t=0;t<n;t++){
  potential[t]=0;
  for(int ss=0;ss<n;ss++)if(ss!=t&&!(O[ss]>>t&1)&&!(bad_stack[n][ss]>>t&1))++potential[t];
  remaining+=potential[t];
 }
 for(int t=0;t<n;t++){
  if(!potential[t])continue;
  fill(W,W+n,0);W[t]=all;
  while(true){
   for(int v=0;v<n;v++){safe[v]=0;for(int c=0;c<n;c++)if(!((O[c]|1<<c)&~W[v]))safe[v]|=1<<c;}
   bool diff=false;
   for(int r=0;r<n;r++){int w=0,x=O[r]|1<<r;while(x){int v=__builtin_ctz(x);x&=x-1;w|=safe[v];}if(r!=t)w&=~(1<<r);NW[r]=w;diff|=w!=W[r];}
   copy(NW,NW+n,W);if(!diff)break;
  }
  for(int r=0;r<n;r++)if(r!=t&&!(O[r]>>t&1)&&(W[r]|1<<r)==all)I++;
  remaining-=potential[t];
  if(I+remaining<=threshold){++early_game_rejects;return -1;}
 }
 return I;
}
int bad_stack[13][12];long long guarded_checks=0,guarded_rejects=0;
int upper_from_bad(const int*bad){
 int upper=0,all=(1<<n)-1;
 for(int s=0;s<n;s++)upper+=min(n-1-(2+(s==U)),__builtin_popcount(unsigned(all&~(bad[s]|O[s]|1<<s))));
 return upper;
}
bool check(int row,int aa,int bb){
 int bad[12];copy(bad_stack[row],bad_stack[row]+n,bad);
 int C=O[row]|1<<row;
 for(int c=0;c<n;c++){
  int D=O[c]|1<<c;
  if(c!=row&&!(O[row]&~D))bad[row]=(1<<n)-1;
  if(c!=row&&ready[c]&&!(O[c]&~C))bad[c]=(1<<n)-1;
  if(used[c]==cap[c]&&!(pred[c]&~C))for(int ss=0;ss<n;ss++)if(ss!=row)bad[ss]|=1<<c;
  if(used[aa]==cap[aa]&&!(pred[aa]&~D))for(int ss=0;ss<n;ss++)if(ss!=c)bad[ss]|=1<<aa;
  if(bb>=0&&used[bb]==cap[bb]&&!(pred[bb]&~D))for(int ss=0;ss<n;ss++)if(ss!=c)bad[ss]|=1<<bb;
 }
 if(upper_from_bad(bad)<=threshold)return false;
 copy(bad,bad+n,bad_stack[row+1]);return true;
}
bool guarded_possible(int row){
 ++guarded_checks;int optimistic[12],all=(1<<n)-1,bad[12];copy(bad_stack[row],bad_stack[row]+n,bad);
 for(int s=0;s<n;s++){
  optimistic[s]=O[s];
  if(!ready[s])for(int v=0;v<n;v++)if(used[v]<cap[v]&&v!=s&&v!=P[s])optimistic[s]|=1<<v;
 }
 for(int c=0;c<n;c++){
  int allowed=all&~(O[c]|1<<c),reach[12]={};
  for(int u=0;u<n;u++)if(allowed>>u&1)reach[u]=(optimistic[u]|1<<u)&allowed;
  for(int k=0;k<n;k++)if(allowed>>k&1)for(int u=0;u<n;u++)if(reach[u]>>k&1)reach[u]|=reach[k];
  for(int s=0;s<n;s++)if(s!=c){
   int internal=0,first=optimistic[s]&allowed;
   while(first){int u=__builtin_ctz(first);first&=first-1;internal|=reach[u];}
   int possible=optimistic[s];
   while(internal){int u=__builtin_ctz(internal);internal&=internal-1;possible|=optimistic[u];}
   bad[s]|=all&~(possible|1<<s);
  }
  if(upper_from_bad(bad)<=threshold)return false;
 }
 copy(bad,bad+n,bad_stack[row]);return true;
}
void visit(int r){if(!complete)return;if((++nodes%65536)==0&&chrono::duration<double>(chrono::steady_clock::now()-began).count()>limit){complete=false;return;}if(r>=n-3&&!guarded_possible(r)){++guarded_rejects;return;}if(r==n){leaves++;int value=game();if(value>best){best=value;copy(O,O+n,BO);}return;}
for(int a=0;a<n;a++)if(a!=r&&a!=P[r]&&used[a]<cap[a]){O[r]|=1<<a;pred[a]|=1<<r;used[a]++;if(r==U){for(int b=a+1;b<n;b++)if(b!=r&&b!=P[r]&&used[b]<cap[b]){O[r]|=1<<b;pred[b]|=1<<r;used[b]++;ready[r]=true;if(check(r,a,b))visit(r+1);ready[r]=false;used[b]--;pred[b]&=~(1<<r);O[r]&=~(1<<b);if(!complete)break;}}else{ready[r]=true;if(check(r,a,-1))visit(r+1);ready[r]=false;}used[a]--;pred[a]&=~(1<<r);O[r]&=~(1<<a);if(!complete)return;}}
void partition(const vector<int>&p){parts++;int s=0;vector<int>u_options;set<int>seen;for(int d:p){if(seen.insert(d).second)u_options.push_back(s);for(int j=0;j<d;j++)P[s+j]=s+(j+1)%d;s+=d;}for(int u:u_options)for(int v=0;v<n;v++){if(!complete)return;U=u;V=v;patterns++;fill(bad_stack[0],bad_stack[0]+n,0);fill(pred,pred+n,0);fill(used,used+n,0);fill(ready,ready+n,false);for(int x=0;x<n;x++){O[x]=1<<P[x];pred[P[x]]|=1<<x;cap[x]=1+(x==V);}visit(0);}}
void build(int left,int lower,vector<int>&p){if(!complete)return;if(!left){partition(p);return;}for(int d=lower;d<=left;d++){p.push_back(d);build(left-d,d,p);p.pop_back();}}
int main(int argc,char**argv){int requested_order=argc>1?atoi(argv[1]):11;if(requested_order!=n)return 2;limit=argc>2?atof(argv[2]):25;threshold=argc>3?atoi(argv[3]):78;if(n<3||n>11||limit<=0||limit>60)return 2;vector<int>p;build(n,2,p);cout<<"{\"n\":"<<n<<",\"m\":"<<2*n+1<<",\"complete\":"<<(complete?"true":"false")<<",\"partitions\":"<<parts<<",\"excess_patterns\":"<<patterns<<",\"nodes\":"<<nodes<<",\"evaluated_threshold_survivors\":"<<leaves<<",\"guarded_checks\":"<<guarded_checks<<",\"guarded_rejects\":"<<guarded_rejects<<",\"early_game_rejects\":"<<early_game_rejects<<",\"maximum_among_evaluated\":"<<best<<",\"upper_if_complete\":"<<max(best,threshold)<<",\"threshold\":"<<threshold<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-began).count()<<",\"arcs\":[";bool first=true;if(best>=0)for(int u=0;u<n;u++)for(int v=0;v<n;v++)if(BO[u]>>v&1){if(!first)cout<<",";first=false;cout<<"["<<u<<","<<v<<"]";}cout<<"]}\n";}

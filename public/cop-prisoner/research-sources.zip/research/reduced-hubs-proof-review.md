# Reduced hub interface: producer checkpoint

This is the scoped implementation and ordinary proof for the reduced hub
direction authorized after the private threshold-bridging analysis. It does
not edit the shared ledger, main manuscript includes, website, or deployment.

The theorem is in `paper/main-interval-reduced-hubs.md`, with the direct
constructor `src/main_interval_reduced_hubs.py`. It permits any bulk antichain
of guide subsets of size at least two, on the first two through seven fixed
guide codes. The base is `106+18g+12b+W`; all `b(g+b+8)` optional arrows can
be chosen independently. Delivery takes at most five messenger moves.

The key fixed sets, in hub labels0..11, are:

* Incoming compulsory hubs: `R={1,2,3,4,6,7,9,10}`.
* Bulk compulsory hub successors: `S={1,4,7,9}`.
* Hubs inaccessible to a bulk cop even in the full envelope: `T={0,2,3}`.

Unlike the original private candidates, hubs outside R need not reach bulk
vertices compulsorily. Their four arrows into each bulk vertex are optional.
Five extra outgoing hub arrows per bulk vertex are also optional, leaving T
inaccessible. These nine optional arrows per bulk vertex repair the upper
overlaps at smaller orders as well as preserving the cheaper base.

The ordinary proof gives hub-only routes. To an outside recipient, hubs in R
have rank1; hubs0,5 rank2; hubs8,11 and point-code guides rank3; the remaining
line-code guides rank4. To a hub recipient, the unchanged hub witnesses and
the three-point safe set T give rank at most2. Bulk sources enter the top
interface safely in one move. A hypothetical bulk cop may reach all guides,
so the interface proof is independent of bulk multiplicity and code weight.

The checks in `research/reduced-hubs-checks.json` replay 8,199 fixed-interface
rank obligations, 485,041 obligations across all21 full-capacity equal-weight
families plus one mixed antichain, and the four targeted budget endpoints.
They are supplemental finite checks of an ordinary parameterized proof.
Independent proof review and independent arrow reconstruction are still
separate obligations; no Lean formalization is claimed.

Useful pair-code intervals are:

| n | g | b | exact budgets |
|---|---|---|---|
|19|4|3|220..265|
|20|4|4|234..298|
|21|4|5|248..333|
|22|4|6|262..370|
|23|5|6|280..394|
|24|5|7|294..434|
|25|5|8|308..476|
|26|5|9|322..520|
|27|5|10|336..566|

The n25 and n27 intervals include every residual middle budget from the
preceding private checkpoint. At n19..24 their upper endpoints overlap the
retained old layered intervals. Their lower endpoints must additionally be
joined by the independently developed circle families before any complete
interval threshold is asserted.

The eighth guide code `{8,11}` is not admitted: it misses the displayed
rank2 witnesses. This failure of the chosen interface is not an upper bound
or a game impossibility result. The older three-move construction remains
valid with its original stronger delivery-time guarantee.

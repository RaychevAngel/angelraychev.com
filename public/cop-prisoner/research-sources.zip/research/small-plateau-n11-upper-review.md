# Independent review of the n=11, m=24 universality exclusion

**Verdict: PASS.** The complete frozen run
`research/small-loss-n11-m24-universal.json`, together with the audited
coverage and pruning argument below, excludes a universal 11-vertex graph
with 24 arrows. The certified graph
`small-plateau-search-n11-m25-seed111325-certificate.json` has I=85.
Existing bounds at all other budgets then give **M_V(11)=85**.

This is an independent source-level ordinary proof review and bounded
canonicalization check, not an independent second n=11 enumeration.
The executable review and hash receipt are
`src/small_plateau_upper_review.py` and
`research/small-plateau-n11-upper-review.json`.

## Reduction to the enumerated family

At n=11, every eligible source row and recipient column contains at most
eight counted pairs. If any vertex has outdegree below two or indegree
below two, at most ten eligible rows or columns remain, giving I<=80.
Thus a graph with I=86 must have minimum indegree and outdegree two.

With 24 arrows its degree surplus over the two-regular budget is two.
Each degree is at most four. A source camping obstruction makes an entire
row zero, losing at least 10-4=6 missing pairs. A predecessor camping
obstruction loses at least 10-4-1=5 missing pairs, allowing the exception
whose source equals the covering cop. Universality permits no losses, so
both types of obstruction may be excluded completely. These reductions
depend on the target: they are not valid unchanged for arbitrary lower
scores.

The outgoing degree profiles are precisely `(4,2,...,2)` and
`(3,3,2,...,2)`. The degree recursion lists every nondecreasing profile
with degrees at least two, total 24, and each degree below n. Reversing
the list before graph enumeration gives the advertised descending order
and loses no graphs.

## Canonical row enumeration

Before choosing row r, future vertices are partitioned by prescribed
outdegree and their incoming pattern from completed rows. Initially each
cell is contiguous because the degrees are sorted. Requiring the chosen
neighbors in each future cell to be a prefix is without loss: permute
vertices within that cell, fixing r and every completed vertex, to put the
neighbors first. This preserves all completed arrows and all prescribed
degrees. The assignment splits each cell into two contiguous cells. When
the next source vertex is removed from the future list, contiguity remains.
Induction proves that the adjacent-cell prefix test retains a representative
of every graph. The proof works for descending as well as ascending degree
order; no global sorting of completed adjacency patterns is assumed.

Both source-camping tests at a new row involve two fully assigned outgoing
rows. Each detects a forbidden domination and is permanent. The incoming
bitsets and row masks are updated and restored correctly under recursion;
stale masks beyond the completed prefix are never used by a pruning test.

## Incoming feasibility pruning

For a prospective recipient t, `available` is the full set of unassigned
tails except t itself. These are exactly the vertices that might supply a
new incoming arrow. The existing predecessor set has fixed size d. If
fewer than two total predecessors remain possible, the minimum-degree
condition cannot be met.

For each completed cop whose closed neighborhood covers all current
predecessors, some future predecessor must lie outside that neighborhood,
or the final graph has predecessor camping. If no available tail escapes
one such cop, the branch is impossible. If no single available tail
escapes all currently covering cops, at least two new predecessors are
needed. Otherwise at least one is needed. Taking the maximum of this
requirement with the indegree-two requirement is a valid lower bound.
It need not be the exact minimum hitting-set size.

Summing current indegree plus the necessary extra over distinct recipients
is valid, since total indegree equals the fixed arrow budget. A sum above
24 excludes every completion. This neither assumes that a predecessor's
outgoing row is already fixed nor double-counts an arrow at different heads.

## Guarded-path and actual-game checks

For an indirect pair (s,t) and a legal stationary cop c!=s, every
nonterminal vertex visited after the messenger leaves s must be outside
the cop's closed outgoing neighborhood. Otherwise the cop captures on its
reply. The messenger must reach a predecessor of t through these safe
vertices before delivering. The guarded-path test computes exactly this
necessary reachability condition, beginning with safe outgoing neighbors
of s. Waiting cannot create a route that this stationary-cop test misses.
The final arrow into t is permitted even when t is unsafe, so receipt
priority is respected. Failure for any legal c makes that pair nonguaranteed.
Counting pairs passing all such tests is therefore a valid upper bound.

Every complete graph passing that bound at target 86 receives an exact
least-attractor game evaluation. The game loop includes both waits,
initializes recipient states as successful, removes all other collisions,
and universally quantifies over cop replies.

## Completion and scope

The frozen run has `complete=true`, `found=false`, both degree profiles,
186,865,392 recursion nodes, 2,805,991 camping-free leaves, and 371,060
guarded-path survivors. A timeout instead propagates `complete=false`
through every recursion level. Thus the completed frozen run excludes
all graphs with I>=86 at this budget, proving M(11,24)<=85.

Its best evaluated score 79 is **not** a proof of M(11,24)<=79: graphs
discarded because their guarded-path upper is below 86 can still have
intermediate scores. Lower-target exclusions need their own completion
and, where applicable, separate handling of camping-obstruction families.

After the frozen run, the producer removed only the entry-point
loss-allowance abort and added an explicit restricted-family label to its
output. All enumeration and pruning code is unchanged. The review receipt
hashes the current source and records this metadata difference explicitly.

The bounded independent check enumerates every labelled loopless
four-vertex graph with minimum indegree and outdegree two and finds an
accepted canonical representative under both degree orders. It complements
the unbounded canonicalization proof, rather than substituting for it.

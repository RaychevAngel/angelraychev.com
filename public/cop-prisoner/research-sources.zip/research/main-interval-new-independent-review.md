# Independent review of the new main-interval constructions

Date: 13 September 2026. This review concerns the two constructions first
recorded in the latest brainstorming entry of `RESEARCH_LOG.md`, and their
subsequent five-move, general-order, arbitrary-guide-weight, and twelve-hub
improvements. It does not change the numerical coverage ledger or claim new
Lean verification.

## Outcome and evidence boundary

The ordinary arguments pass independent mathematical review. The independent
implementation `src/main_interval_new_independent.py` imports no project graph
constructor, pursuit solver, or certificate checker. It reconstructs both the
compulsory messenger graph and the full optional pursuer envelope directly
from the adjacency descriptions. It then computes universally winning source
ranks and separately replays every nonterminal source/pursuer rank obligation.

The current receipt is `main-interval-new-independent-checks.json`. The checked
sample has 145 reconstructed envelopes, 1,238 recipient instances, and
4,416,069 replayed nonterminal source/pursuer obligations. It additionally
checks 26,184 individual safe-set/pursuer obligations for circles and 9,594
local hub-intermediary/safe-entry premises for the layered constructions.
The sample includes the minimum circle orders, all congruence classes in the
general-order extension, the motivating sixty-vertex circle, maximum pair
capacities, several higher guide weights, and both hub-core sizes.

These are bounded checks. The infinite claims rely on the ordinary arguments
below, not on extrapolating their success. In particular, a successful full
graph alone would not justify intermediate budgets. The checks and proofs
both restrict messenger moves to the compulsory graph while permitting the
pursuer the entire optional envelope, which is the stronger statement needed
for every intermediate subset.

## Five-move circles

The final hypotheses are `h >= 7`, `h = 3 (mod 4)`, `gcd(h,n)=1`, and
`n >= 2h+2`. The five compulsory offsets are

    1, h-3, h-2, h, h+2.

The full modulo-four envelope, when four divides `n`, contains residues zero
and one, adds `h`, and removes `2h-1`. It has exactly `n/2` closed offsets.
The arbitrary-order version restricts the regular residues to the integer
interval `[0,n-h]` before the same addition and deletion.

Three local safe alternatives suffice:

    {h,1}, {h,h-3,h-2}, {h,h-2,h+2}.

For the full envelope, condition on a pursuer covering `h`. A zero-class
pursuer must be the excluded source itself; a one-class pursuer cannot cover
`h`; a two-class pursuer covers no zero-class point and at most one one-class
point; a three-class pursuer covers no one-class point. This rules out both
triples. Covering the pair forces pursuer `1-h`, which would require the
deleted offset `2h-1` to cover `h`.

The wraparound repair is valid for every order, including odd orders. Each
safe alternative set has integer diameter `d <= h-1`. If its translated
representatives cross zero, their extremes differ by `n-d >= n-h+1`, which
exceeds the envelope's containing interval length `n-h`. Consequently every
purported covering admits a common integer lift, and the preceding residue
argument applies to that lift. This argument does not incorrectly reduce
residues modulo four on a cycle whose length is not divisible by four.

For `P(z)={z-2,z-1,z,z+2}`, three members of `P(-h)` are direct predecessors
of the recipient. The fourth, `-h-1`, branches to predecessors `-1,-h`.
The four ordered propagation steps in the proof establish `P(z-h)`. The
independent checker verifies these successor identities as affine integer
expressions in `h`, not at sampled numerical values. Coprimality ensures
that repeated shifts visit every residue, and finite branching ranks ensure
actual delivery rather than indefinite evasion. Modular coincidences only
identify vertices already proved winning.

The exact robust interval is `5n <= m <= n(|A|-1)`. At every order divisible
by four from sixteen onward, the displayed parameter rule gives a valid
`h` and the endpoint is `n(n/2-1)`. For a gapped envelope, counting regular
residues through `n-h` and then the exceptional addition/deletion gives the
stated explicit endpoint. No graph search is used in parameter selection.

The older eight-move construction remains independently checked in the
receipt. Its base contains the five-move base and its envelope is contained
in the newer one for the same `n,h`. Therefore its old graph-by-graph
optional-subset guarantee is preserved. The old one-third density ceiling
concerned a stronger three-pair protection condition that the new proof
does not impose.

## Guides and bulk vertices

For the fourteen-hub construction, the independently reconstructed omitted
guide triples, accessible bulk hub set, core arrows, and optional arrows
match the proof description. Allowing each bulk vertex a distinct equal-size
`r`-subset of guides, for `2 <= r <= g`, preserves the proof: against a guide
pursuer there is another assigned guide; against a bulk pursuer the two
distinct equal-size guide sets have a nonempty directed difference. The
base count is `154+25g+(22+r)b`, with `b(g+b-1)` optional arrows.

The twelve-hub improvement needs a separate justification for its size-two
guide codes; Theorem 59's former size-three hypothesis cannot simply be
discarded. The proof supplies the needed justification. An antipodal pair
on six vertices cannot lie inside an adjacent pair or a difference-two pair,
which are exactly the relevant hub danger and missing-predecessor pairs.
The two line parity triples and the six antipodal pairs form an antichain,
and each avoids containing a full hub missing row. The triples are placed
first, so every prefix of at least two guides has total omitted-code weight
`2g+2`. The compulsory count is consequently
`106+22g+(19+r)b`, with the same optional count.

The delicate new case is a guide source, hub recipient, and bulk pursuer.
For the twelve-hub graph the safe hub set is
`T={P0,P3,L0,L2,L4}`. A point-code guide can reach all three safe line hubs,
and at most two fail to reach a hub recipient. For a line-code guide, the
two safe point hubs are reachable. A missing hub recipient is then a line,
and its adjacent missing-predecessor pair cannot contain the antipodal
pair `{P0,P3}`. Thus this case is covered without assuming three safe hubs
in both parts. Bulk entry against a hub also works because `T` contains no
full missing hub row.

The independent checker verifies the complete finite local premise list for
each full guide catalogue: every nondirect source/recipient/pursuer triple
with source a hub or guide has a safe hub intermediary, including one bulk
pursuer and one bulk recipient representative. This finite reduction is
valid for arbitrary admissible bulk counts: all bulk pursuers have exactly
the same hub access, every hub reaches every bulk target, and every checked
intermediary lies in the hubs. Removing a guide suffix merely removes
possible cases. The remaining bulk-source cases use the elementary
equal-size-set argument. These observations justify the all-parameter
extension of the finite core premises, rather than assuming that a few full
games represent untested bulk configurations.

Every checked hub or guide source has rank at most two and every checked
bulk source at most three. The formal proof handles an arbitrary pursuer
response after safe entry, because the hub/guide claim is universal over
pursuer locations. This is the necessary bridge between the routing layers.

## Reproduction

Run from the project directory:

    python3 src/main_interval_new_independent.py

The receipt records source identities and the rank/layer summaries. The
checker uses synchronous closure for discovery and a separate explicit-set
witness replay for validation. Direct receipt is treated as terminal before
interception, and every nonterminal witness is outside the pursuer's closed
move set, including its current position. No new Lean claim is made.

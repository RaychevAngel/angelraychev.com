# Exact values and explicit attaining constructions

The objective is complete: determine `M(n,m)` for every `n>=1` and `0<=m<=n(n-1)`, and provide explicit constructions attaining those values. The accepted classification has no unknown-value gap and no explicit-construction gap. The completion date is 13 September 2026. Building, visual verification, and public deployment are recorded separately in their receipts.

## Mathematical object and rules

`M(n,m)` is the largest number of guaranteed missing nonloop ordered source-recipient pairs in a finite simple directed graph with exactly n vertices and m arrows. Opposite arrows and isolated vertices are allowed. Both players see both positions and may wait or follow outgoing arrows. The messenger moves first. Receipt at the actual recipient wins before collision, even if the pursuer occupies that recipient. Every other collision loses; infinite evasion loses. The guarantee covers every initial pursuer position other than the source and every legal history-dependent pursuer policy.

The two obligations at each pair remain separate: prove the exact maximum, and specify concrete adjacency or composition with parameters determined from `(n,m)`. A generic graph search, bare existence proof, or conditional-expectation procedure alone is insufficient. Certified listed finite exceptions are acceptable. A direct recipe may use fixed parameter records, explicit arithmetic tests, or lexicographic listing of a prescribed family; its delivery proof must terminate in the actual game.

## Completed domain

The combined theorem gives every order n>=12. Budgets0..23 use the exact arc-budget table. At larger budgets use the sparse parity formulas, the main missing-pair formula, the dense staircase, and the zero range. The complete finite tables cover all orders 1..11. Their union is every admissible pair; this is not only an eventual classification.

For budgets 12..21 the least attaining hosts are7,8,8,8,8,10,9,11,10,12. Literal graphs at those hosts extend by isolates; smaller hosts have their own exact entries. The numerical ledger contains 493,924 exact cells and zero unknowns in the retained audit box through114. The ordinary parameterized theorems and support arguments establish coverage outside that box. Finite testing alone is not used to infer an infinite result.

The separate recipe audit verifies direct or fixed-literal attainment for every exact provider without relying on orientation derandomization. Earlier constructions retain their full parameter domains, prescribed routing, optional-subset freedom, and delivery bounds. A different graph attaining the same count does not inherit those stronger properties automatically.

The September18 pass simplifies the proof inside this boundary. The shared sparse induction, separated pair codes, exact functional attachment identity and sharper odd projection preserve the completed classification. The finite low-budget exclusions and stronger earlier constructions remain premises or independent results; reducing the main-interval upper bridge to orders12..78 does not eliminate the distinct sparse bridge or the finite local certificates.

## Proof and project boundary

Ordinary arguments, complete finite exclusions, independent game replays, sampled pruning checks, and Lean proofs are identified separately. Incomplete searches are never upper proofs. Hashes identify evidence versions rather than establish mathematics. The independent closure preserves all previous equalities and numerically closes all 101 formerly unresolved representatives.

The Lean development proves actual-game equivalence, general upper bounds and explicit attaining constructions on substantial complete parameter domains. These include the full dense range from order11, the complete main interval from115, its upper part from25 and uniform even sparse maxima from support 85 and odd sparse maxima from support 98, complete joint tables through order 5, and sharp unrestricted budgets 0..10. The complete classification is not yet a Lean theorem. The exact source snapshot and all current theorem domains are recorded in `lean/verification.json` and `lean/README.md`; remaining construction, finite-exclusion and assembly obligations are in `research/LEAN_ROADMAP.md`. Those documents distinguish completed target checks from an accepted whole-source release. This is a verification boundary, not an unresolved mathematical value.

The completed programme does not include classifying every maximizing graph, characterizing all guaranteed pairs structurally, or optimizing delivery time. The timing results and remaining timing problems stay in the parked companion. Further compression of arguments or finite parameter lists is possible, but does not change the completed value-and-construction objective. Human publication authorship is approved: Angel Ivanov Raychev first, Alexandra Ignatova second. The manuscript is prepared for arXiv; actual submission, journal selection and outreach remain separate decisions.

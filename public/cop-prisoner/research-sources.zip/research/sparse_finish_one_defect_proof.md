# Ten vertices and nineteen arrows: proposed upper53

13 September 2026. Draft ordinary reduction plus complete finite exclusion;
independent review is required before incorporation. This does not yet state
the exact value because a matching53 witness has not been supplied here.

## Complete degree reduction

Use the approved outside-vertex lemma and notation A,B,q,r,b,a,d,Z,z,o,i.
Retain exact outgoing/incoming surplus x,y, and w=e(V minus A,V minus B).
Then e(A,B)=2q+2r-m+x+y+w. The exact number of indegree-one vertices in
A minus B is d-y-i; the exact number of outdegree-one vertices in B minus A
is a-x-o. Their counts must lie between zero and q-b or r-b respectively.

The complete necessary integer inventory in sparse_finish_profiles.json
retains just q=r=9 and b=8 or9 at support10, m19 and score above53. Removing
one active row or column makes the approved live-rectangle upper at most53,
so all nine active rows and columns are nonzero. The live-degree conditions
therefore apply: every live row has two nonsink successors, and every live
column has two predecessors of positive indegree.

The positive-degree profiles have x=y=0: every degree is one or two, with
one low-out vertex l and one low-in vertex p. If l differs from p, b=8 and
the eligible count is56 minus the indicator of l->p. If l=p, b=9 and the
eligible count is55. (The count-only inventory deliberately permits an
additional unrealizable self-arrow w=1 in this latter case.)

Only two zero-degree profiles remain. Each has A=B of size9 and a single
outside one-arrow source or sink. In the sink case x=1,y=0: the core has one
outdegree-three vertex and every incoming degree two. Its arrow to the sink
must start at that degree-three vertex, since a degree-two predecessor would
have a zero row. Removing the sink leaves a regular nine-vertex eighteen-
arrow core. Messenger excursions to the sink cannot reach a core recipient;
the sink has no indirect row or column. Thus the score is at most44 by the
approved eighteen-arrow upper. In the source case x=0,y=1: its arrow must
enter the unique indegree-three core vertex, since an indegree-two head
would have an inaccessible predecessor and a zero column. Removing the
source again leaves a regular nine-vertex eighteen-arrow core; old messenger
play cannot enter the source. The same upper44 follows. These arguments use
the original directions of play, without reversal invariance.

Support at most9 is already bounded by n(n-1)-19 <=53. Therefore every
ten-vertex nineteen-arrow competitor above53 belongs to the positive-degree
family enumerated below, including graphs originally having isolates.

## Complete matching normalization

The bipartite incidence graph of a member of this family has maximum degree
two. Alternating colors along its paths and cycles give two matchings. Their
total size is19 and each has size at most10, so the sizes are10 and9.
The first is a loopless directed permutation. Its twelve cycle partitions
are all enumerated. Under rotations of cycles and permutations of equal
cycles, the single omitted row of the second matching can be chosen at the
first vertex of one cycle of each distinct length. Every omitted column is
then retained. Every injection on the remaining rows and columns is listed,
excluding loops and arrows already in the first factor. This covers every
graph in the family, with repetitions permitted.

## Permanent exclusions and actual game

The eligible rectangle has at most56 pairs, so a score at least54 permits
at most two failures. A source camping obstruction in an active row loses
at least6 eligible pairs. A predecessor camping obstruction in an active
column loses at least5: at least6 eligible source pairs exist, and the
initial-source/cop exception removes at most one. Hence these obstructions
may be rejected completely at this threshold. During a partial assignment,
a source neighborhood is tested only when its row is finished; a recipient
predecessor set only when its column is finished. The cop receives only
already fixed outgoing arrows. Every reported obstruction is permanent.

The guarded-path bound gives an unfinished messenger row every still-
available residual arrow, and gives the cop only fixed arrows. Intermediate
vertices avoid the cop's closed outgoing neighborhood. Source entry and
final receipt are handled separately; the recipient may lie in that closed
neighborhood. Failure in this optimistic stationary-cop game supplies a
permanent missing-pair loss. Losses are counted as a union across cops.
A pair certified impossible cannot later become a direct arrow because
every such possible arrow was already included optimistically.

Every surviving complete graph is evaluated by the actual monotone winning
fixed point, with waits, receipt priority, forbidden nonterminal collisions,
all legal initial cops, and eventual delivery. Evaluation can stop only when
the obtained score plus every unexamined eligible pair is at most53.

## Primary completion

Source: src/sparse_finish_one_defect.cpp.
Receipt: research/sparse_finish_one_defect_10_19.json.
The complete traversal covers12 first-factor types and220 degree patterns,
607500 partial nodes and267 actual-game threshold decisions. All reject a
score above53. The measured traversal time was0.151 seconds, excluding
compilation. A timeout would instead return complete=false.

This is a proposed all-graph upper M(10,19)<=53, conditional on independent
review of the ordinary reduction, coverage, pruning and fixed-point code.
No matching lower value, exact nineteen-arrow classification, or formal
Lean coverage is claimed by this file.

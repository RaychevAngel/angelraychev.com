# Independent review of the small-case support reduction

13 September 2026. Ordinary proof review plus independently written integer
enumeration. No graph search, game-solver call, or producer import is used.

**Verdict:** every 20-arrow graph with more than 50 guaranteed indirect pairs
has at most 13 nonisolated vertices. Every 18-arrow graph with more than 30
has at most 15. The respective necessary parameter relaxations retain 22
and 67 triples `(q,r,b)`. These are counts of integer profiles, not graphs,
isomorphism classes, degree sequences, or realizable constructions.

The replay is `small-case-support-review-2026-09-13.py`; its complete receipt
is the adjacent `.json`. The argument below supplies every constraint used.

## Parameters and elementary constraints

Let `A={v:outdeg(v)>=2}`, `B={v:indeg(v)>=2}`, `q=|A|`, `r=|B|`,
`b=|A∩B|`, `a=m-2q`, and `d=m-2r`. Then `0<=q,r<=floor(m/2)`,
`0<=b<=min(q,r)`, and `a,d` are nonnegative integers of the same parity.

Let `Z` contain the nonisolated vertices outside `A∪B`. Put `z=|Z|`,
`o=sum_Z outdeg(v)`, and `i=sum_Z indeg(v)`. Both degrees of a vertex in
`Z` are at most one, and their sum is positive. Consequently

    0<=o<=a,  0<=i<=d,  max(o,i)<=z<=o+i.

The nonisolated support is exactly `q+r-b+z`. Isolates do not enter any
of these counts. No bound on the host order is assumed.

## Stronger zero-column and zero-row bounds

Write `x=sum_{v in B}(indeg(v)-2)`. Exactly `d-x` arrows end outside `B`.
Of these, exactly `i` end in `Z`. Each vertex of `A\B` has indegree zero
or one, so exactly `q-b-d+x+i` of these vertices have indegree zero.
They emit at least twice that many arrows. In addition, precisely `z-i`
vertices of `Z` have indegree zero; since they are nonisolated, each emits
one arrow. These two disjoint source sets therefore emit at least

    2(q-b-d+x+i)+(z-i)

arrows. At most `d-x` can end outside `B`. Vertices in `B` of indegree at
least three receive at most `3x` arrows in total, because
`e<=3(e-2)` for each integer `e>=3`. Thus at least

    max(0, 2q-2b-3d+i+z)

of the selected arrows end at indegree-two recipients. Each such recipient
receives at most two arrows, so the number of distinct affected recipients
is at least the ceiling of half this quantity.

Each affected recipient has a zero indirect column. Its indegree-zero
predecessor cannot be reached from another source; an indirect source must
therefore enter the other predecessor, where the cop can wait. Either
predecessor as initial source gives a direct pair and is not counted. This
uses the original directions and receipt-before-capture convention.

If `C` is the number of recipient columns containing any guaranteed
indirect pair, the resulting bound, including negative and odd cases, is

    C <= min(r, b+d+floor((a-i-z)/2)).                    (1)

The separate original-direction sink argument gives the corresponding row
bound. Put `y=sum_{v in A}(outdeg(v)-2)`. Exactly `r-b-a+y+o` vertices in
`B\A` are sinks and have indegree at least two. There are also `z-o`
one-incoming-arrow sinks in `Z`. Their incoming arrows force at least
`max(0,2r-2b-3a+o+z)` arrows from outdegree-two predecessors, after
allowing at most `a-y+3y` arrows from other sources. Each degree-two
predecessor supplies at most two of the selected arrows. A degree-two
source with a sink successor has a zero indirect row: the cop waits at the
other successor, while entering the sink cannot help reach an indirect
recipient. Thus

    R <= min(q, b+a+floor((d-o-z)/2)).                    (2)

This is not an appeal to game invariance under arrow reversal. Taking
`i=z=0` or `o=z=0` in the weaker estimates recovers the independently
reviewed bounds `C<=min(r,b+floor(a/2)+d)` and
`R<=min(q,b+a+floor(d/2))`. More directly, dropping the nonnegative
subtractions in (1)-(2) proves those weaker bounds for every graph.

## Two necessary pair-count bounds

Total outdegree outside `A` is at most both `a` and `r-b+o`. Total
indegree outside `B` is at most both `d` and `q-b+i`. Hence at least

    max(0, m-min(a,r-b+o)-min(d,q-b+i))

arrows lie in `A×B`. Its `qr` ordered pairs also contain exactly `b`
diagonals. Arrows and diagonals are disjoint because the graph is loopless,
and neither can be counted indirectly. Therefore

    I <= qr-b-max(0,m-min(a,r-b+o)-min(d,q-b+i)).          (3)

For the actual live row and column sets of sizes `R,C`, their intersection
has size at least `max(0,R+C-(q+r-b))`, since their union lies in `A∪B`.
Their total outgoing and incoming degrees are at least `2R` and `2C`.
Inclusion-exclusion among the `m` arrows forces at least
`max(0,2R+2C-m)` arrows from a live row to a live column. Thus

    I <= RC-max(0,R+C-q-r+b)-max(0,2R+2C-m).             (4)

The replay explicitly maximizes (4) over all nonnegative integer `R,C`
permitted by (1)-(2), rather than assuming monotonicity. It then takes the
minimum with (3). Negative row or column caps cannot arise for an actual
graph and are rejected. Python integer division implements mathematical
floor, including when the numerator is negative.

## Finite arithmetic and proof boundary

Every graph maps to one enumerated tuple: `q,r<=floor(m/2)`, the stated
intersection range, `o<=a`, `i<=d`, and `max(o,i)<=z<=o+i` cover all
possibilities. Keep a tuple only when both necessary pair bounds allow
`I>=51` for `m=20`, or `I>=31` for `m=18`. The largest permitted support
`q+r-b+z` is respectively 13 and 15. There are respectively 22 and 67
triples `(q,r,b)` admitting at least one surviving auxiliary tuple.

Ingredient (3) matters: retaining (1), (2), and (4) without (3) permits
support 14 for the 20-arrow case. For example,
`(q,r,b,z,o,i)=(8,9,7,4,4,0)` passes that weaker relaxation with upper 51,
but (3) lowers its upper to 50 and excludes it from the strict-improvement
case. The transpose parameter tuple is excluded likewise.

These are valid conditional support deductions, with ordinary counting
proofs and finite exact arithmetic. They do not prove `M_E(20)=50` or
`M_E(18)=30`; all surviving graphs still require exclusion or improved
witnesses. They do not assert that any surviving parameter tuple is
realizable. They also do not assert that deleting the exceptional vertices
or arrows preserves a strategy. Only deleting isolates is automatically
harmless for the underlying fixed-budget search reduction.

# Independent review: eleven vertices suffice at budget twenty

13 September 2026. The ordinary argument in
`small-sparse-twenty-host-compression.md` passes independent root review.
The conclusion is `M(n,20)=M(11,20)` for all `n>=11`, with the explicit
comparison construction described there. The maximum remains between 53 and 57.

The review checked all sixteen possible large-support tuples. Their live
rectangle must be exactly nine by nine. A live source needs two nonsink
successors, and a live target needs two positive-indegree predecessors;
the two directed arguments are separate. These requirements force the
claimed surplus values. The independent arithmetic replay recomputes all
tuples and surplus constraints directly, without importing the producer.

In the unmatched-vertex cases, the degree-zero vertex forces its arrows
away from indegree-two recipients, and the sink forces its predecessors
away from outdegree-two sources. Exhaustion of the outside degree totals
then separates one-way appendages from the common core. Restricting the
pursuer to that core is legitimate because a messenger between core
vertices either cannot enter the incoming appendage or cannot return
after entering the outgoing appendage. Thus the core's missing pairs
that fail internally remain failed in the whole graph. The argument
subtracts these failed pairs from the full eligible rectangle; it does
not incorrectly assert that all cross-core pairs fail.

The support-thirteen tuple is impossible above 53. At support twelve,
all cases give a score at most 53 except two forms consisting of a
ten-vertex, nineteen-arrow component and a disjoint single arrow. In
the equal-active-set three-outside-vertex case, a source-to-middle arrow
must be followed by middle-to-sink: the sink cannot receive an arrow
from a live degree-two core source. This excludes an otherwise tempting
unaccounted middle-to-core alternative.

For the two surviving forms, replace the separate arrow by an arrow from
any old vertex to one fresh sink, as previously proposed by Angel. This
preserves the score. Old losing pairs stay losing under a cop confined to
the old graph; entering the sink cannot help reach an old target. An old
winning strategy still works until the cop enters the sink, after which
the cop is trapped and an old directed delivery path suffices. The new
vertex contributes no counted source or target pairs. This is an explicit
compression, not deletion of an arbitrary exceptional vertex.

Graphs scoring at most 53 are matched by the saved ten-vertex example.
All others are reduced by the preceding cases and padded to eleven if
needed. This proves the host comparison and its construction transfer.
The tests of the live-degree lemma support the ordinary proof but do not
replace its quantified argument or constitute a new extremal enumeration.

# Two-loss obstruction at the seven/eight-vertex dense endpoint

Private proof/evidence note for independent review. The finite exclusion
establishes upper bounds, not exact values or an exhaustive joint table.

## Reduction to two-out missing graphs

Let F be the missing graph, with exactly 2n missing arrows. If some vertex
has missing outdegree zero, the delivery count is zero. If any vertex has
missing outdegree one and I>0, the existing degree-one counting argument
in Theorem 27 gives at least two failed missing pairs. Its proof of this
fact uses only the existence of the degree-one set, not the strict
inequality h<2n. Otherwise every missing outdegree is at least two, and
their sum 2n makes every missing outdegree exactly two. No incoming-degree
condition follows or is imposed.

It therefore suffices to prove that every two-out missing graph on n=7
or n=8 has two failed missing pairs.

## Two ordinary camping witnesses

1. If c != s and F(c) is contained in F(s) union {s}, the pursuer camping
   at c intercepts every nonterminal departure from s. Both missing pairs
   in source row s fail. Waiting at s cannot give finite receipt.

2. If F(c)={u,v} and u and v both have missing arrows to t, the pursuer
   camping at c reaches every delivery predecessor of t: its closed
   delivery neighborhood is V minus {u,v}. Both missing pairs (u,t) and
   (v,t) fail. They are distinct, and c differs from both u and v because
   F has no loops. This argument also permits c=t.

Each rejection in the independent prefix tree records one of these two
witnesses and its two explicit failed missing pairs. No different
obstructions are added together, so double counting is absent.

## Two complete normalized cases

Suppose neither witness occurs. Designate an arbitrary vertex as 0 and
label its two missing neighbors 1 and 2.

The first witness forbids a missing arrow 1->2 or 2->1: such an arrow
would make source 1 or 2 dominated by the pursuer at 0. The second witness
forbids any intersection of F(1) and F(2). Thus their four missing
neighbors are distinct and avoid 1 and 2. At most one can be vertex 0.

- If neither row contains 0, relabel the four neighbors so that
  F(1)={3,4}, F(2)={5,6}.
- If one row contains 0, exchange labels 1 and 2 if needed and relabel
  so that F(1)={0,3}, F(2)={4,5}.

These two normal forms cover every graph avoiding the two witnesses.
Remaining vertices have unused labels. No graph is omitted by symmetry
assumptions about later rows, incoming degrees or connectivity.

## Complete finite check and independent replay

The C++ implementation enumerates every remaining loopless two-element row,
using minimum-remaining-values order and the equivalent local conditions:
distinct rows, no missing arrow between a row's two neighbors, and disjoint
outgoing rows of those two neighbors. Completed runs have zero leaves:
8 search nodes at order seven and 114 at order eight.

The separately implemented Python check uses fixed chronological row order
and the two camping predicates directly. It records the full rejected
prefix tree. At order seven it visits 227 prefixes and rejects 212; at
order eight it visits 4,307 prefixes and rejects 4,102. No full graph
survives. All remaining row choices are enumerated, including arbitrary
missing indegrees. The existing nine-core is a positive control: every
prefix of its explicitly normalized rows survives the same predicates.

Sources: `src/small_dense_endpoint_enumeration.cpp` and
`src/small_dense_endpoint_independent.py`. Primary logs are
`research/small-dense-endpoint-7.jsonl` and `-8.jsonl`. The independent
proof tree and source hashes are in
`research/small-dense-endpoint-independent-tree.json` and
`research/small-dense-endpoint-independent-checks.json`.

Together with the degree reduction, this gives

    M(7,28) <= 12,     M(8,40) <= 14.

The existing second-dense-step equivalence consequently excludes its
staircase equality at (9,56) and (10,72), giving

    M(9,56) <= 13,     M(10,72) <= 15.

These are not claimed exact. The separate bounded deletion pilot supplies
verified lower witnesses I=9 at (7,28) and I=12 at (8,40), stored in
`research/small-dense-endpoint-certificates.json`. Its failures prove no
upper bound. The complete prefix exclusions above do not use a game
solver, an incomplete construction search, or those lower witnesses.

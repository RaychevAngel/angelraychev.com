# Independent review of the fixed 12- and 13-arrow cases

13 September 2026. Approved exact values are `M(8,12)=M(9,12)=9` and
`M(8,13)=11`. The latter also improves the global lower bound to eleven;
neither budget's unrestricted maximum is claimed exact.

The enumerator is exactly the already independently audited descending-
degree, suffix-cell, alternating-state implementation, apart from two
comment lines, larger arrays, and the host input guard. This equality is
checked mechanically. The proof of degree-profile completeness, suffix-cell
coverage, source/predecessor camping, and the maximum over both live rectangle
dimensions applies at orders eight and nine without a seven-vertex premise.
All arrays have sufficient space and the actual orders have positive `n-3`.
The wider syntactic command domain is not part of this validation.

The three negative receipts cover every generated degree profile, start
at zero, finish without a timeout or counterexample, and use the exact
requested budget. An independently written integer-partition count agrees
with their 55, 61, and 52 profile counts. Their reported best evaluated
scores are not used as upper bounds; complete target exclusion supplies
the upper bound. The earlier positive search is correctly incomplete.

The seven-vertex nine-pair graph supplies the two 12-arrow lower bounds
by adding isolates. The new eight-vertex eleven-pair graph at budget
thirteen has been independently checked through all 1,024 alternating
state rank obligations. Waiting, actual recipient receipt, other collisions,
and all losing-state closure obligations are included.

This is independent source/completeness review plus fixed-certificate
replay, not a second full graph enumeration at the new host orders and
not Lean formalization. The ordinary review and source pins are recorded
by `src/small_case_tiny_review.py` in the adjacent JSON receipt.

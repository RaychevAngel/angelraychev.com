# Independent audit: safe two-generator navigation

Date: 2026-09-13. Reviewed statement:
`research/composition-interface-navigation.md`.

**Conclusion:** the safe-navigation lemma passes independent ordinary
projection review and an independent replay of its complete finite
certificates. Radius-four injectivity is sufficient. This establishes safe
navigation to quotient cells, not delivery to arbitrary individual types
inside those cells. No Lean formalization or logarithmic-time universal
point-delivery family is asserted.

## Literal graph and interface

I checked the two ten-type rules directly against the displayed graph.
For A, the head types form a permutation; the two generator-labelled
steps have types 4->0 along a and 9->5 along b. For B, the head types in
each five-type lane form a permutation, and their cell maps are the
appropriate generator permutations. The A and B destinations have different
types at every source, so their arrows are distinct independently of the
quotient. Radius-four injectivity excludes the possible loops in the
same-type B arrows. Thus the graph is simple, loopless, and exactly
two-in/two-out regular on 10|X| vertices.

The six forbidden joint states are exactly those encoded in the certificate.
For normalization, I independently applied the stated B arrow and checked
the cop's wait, A and B responses in each case. None causes a collision.
The resulting messenger types are 3,3,1,8,8,6; the two types 3 and 8 avoid
their new-cell exclusions, while 1 and 6 have no additional exclusion.
All compared words have length at most two. This is an ordinary six-case
argument, not an inference from the attractor synthesis.

## Why radius four is enough

Fix a reference cell x. Let M be the image of the reduced-word ball of
radius two and C the image of the ball of radius three. By hypothesis,
words of length at most four label distinct physical cells.

1. **Messenger moves.** A step from a represented messenger cell has word
   length at most three. If its reduced length exceeds two, it cannot
   alias a represented messenger cell. The arena deliberately forbids
   such a step. Every allowed arena move is therefore an actual move
   within M, with exactly the claimed destination type.

2. **Represented pursuer moves.** A step from a cell in C has reduced
   word length at most four. A word of length at most three has its
   exact represented successor. A word of length four cannot alias any
   represented cell and is correctly sent to the exterior state of its
   actual new type. Internal type changes and waiting remain exact.

3. **Exterior reentry.** Suppose an actual exterior pursuer at y enters
   represented cell xz along generator g. Then y=x(zg^{-1}). The reduced
   word zg^{-1} has length at most four. Because y was outside C, that
   length must be four. Conversely, injectivity prevents a length-four
   word from aliasing C. This is exactly the arena's boundary-entry test.
   An internal arrow cannot enter from outside. An exterior move that
   stays exterior has the permitted successor type, and waiting preserves
   the type. The arena may permit more exterior choices than a particular
   physical position has; this is a sound overapproximation of the cop.

4. **Collisions.** The messenger always remains in M, a subset of C.
   An exterior cop cannot collide with it. For represented positions,
   equality of word and type is equivalent to physical coincidence.
   Thus no collision is hidden or invented by the representation.

5. **Safe endpoints and recentering.** The endpoint cell has word length
   one. Its six relative exclusions involve only that cell or one of its
   adjacent cells, all at original word distance at most two. An exterior
   cop therefore cannot secretly violate an endpoint exclusion. Relative
   words for represented comparisons have length at most four, and the
   hypothesis prevents an accidental identification with an excluded
   location. Each seeded state is a genuine uncaught messenger-turn
   interface state after the last cop response. Recentring is therefore
   legitimate and supplies every hypothesis of the next module.

No identification beyond radius four is used. In particular, the proof
does not require a radius-four ball to be an induced tree all the way
through its outward boundary: only the represented radius-three cop
transitions and their radius-four endpoints are inspected.

The graph-theoretic sufficient condition is also correct when stated as
in the source: a **simple four-regular** underlying graph of girth at least
nine. Its four distinct generator neighbors make a freely reduced word
a nonbacktracking walk. A nontrivial closed such walk of length at most
eight would contain a cycle of length at most eight. Conversely, equality
of two distinct reduced words of length at most four gives a nontrivial
reduced relation of length at most eight. The degree and simplicity
conditions matter; girth language applied after suppressing repeated
generator neighbors would not suffice.

## Independent finite replay

`src/routing_defect_phase2_navigation_audit.py` imports none of the primary
arena, invariant-synthesis, or attractor code. It writes the ten A and B
rules literally, independently reduces words, reconstructs both position
sets and every transition, and compares them with the stored archive.
It then checks the exact endpoint layer, every newly claimed winning
state, and every cop response in the preceding layer. No fixed-point
conclusion is trusted.

Results:

- 170 messenger positions and 540 cop descriptions, including ten typed
  exterior descriptions; all stored moves match the reconstruction.
- Both 33-layer certificates replay: 60,670 newly entering states each,
  for a total of 121,340.
- All 5,384 required interface starts per objective belong to the final
  layer. Every move reduces the layer by at least one after the full cop
  response, giving the stated bound of 32 messenger moves.
- All six normalization cases pass their literal response checks.
- The original source hashes and archive hash match their receipt.

The new receipt is
`research/composition-interface-navigation-independent-audit.json`.
Its archive hash is
`8f5cad6d9e1d8a3c3c479b6a9519663631b708ce6c8191bb9b3928ef2d1da56c`.

## Quotient existence and the remaining terminal requirement

Connectedness is sufficient for finite directed diameter using a^{-1},b^{-1}:
on a finite set every positive generator step can be expressed by repeated
inverse steps. It does not by itself give a logarithmic bound, and a small
undirected diameter alone should not be substituted for that assertion.

A useful stronger sufficient input is a family of simple four-regular
undirected graphs with girth at least nine and uniform edge expansion
epsilon>0. No special group labelling is needed. Orient Euler tours to
obtain indegree and outdegree two. The bipartite incidence graph of this
orientation is two-regular, so alternating colors on its cycles split the
arcs into two permutations a,b. The underlying graph is unchanged, hence
the local injectivity condition holds.

For any vertex set S of size at most half the quotient order N, balance
gives equal incoming and outgoing cut sizes, each at least
epsilon|S|/2. As every outside vertex has indegree two, the forward
directed neighborhood gains at least epsilon|S|/4 new vertices. The same
holds backwards and after reversing all arrows. Forward and backward
balls therefore grow by a factor at least 1+epsilon/4 until they exceed
half the vertices. In particular the inverse-generator diameter obeys

    D <= 2 ceil(log N / log(1+epsilon/4)).

Such an expander family would consequently provide logarithmic-time safe
cell navigation by the proved lemma. This audit neither invokes nor proves
the existence of a particular expander family, an all-order construction,
or a quantitative best constant for its expansion.

To obtain actual point delivery, a terminal certificate must accept every
joint interface state produced at an available entry cell and reach the
specified recipient type, with receipt treated as terminal even if the cop
is there. If its bound is T, compatible composition would give
1+32D+T messenger moves. A terminal module that assumes a particular
messenger type or a stricter cop condition does not yet close this gap.
Safe navigation alone must not be promoted to universal recipient delivery,
arbitrary additional-arc robustness, or an all-order extremal construction.

#!/usr/bin/env python3
"""Bounded exact forbidden-triple feasibility; only the local circle template."""
import math,json,time
from pathlib import Path

def problem(n,h):
 C={(x%n) for x in (1,h-3,h-2,h,h+1,h+2)}
 if len(C)!=6 or 0 in C or math.gcd(n,h)!=1:return None
 sets=[(h,1,h+1),(h,h-3,h-2),(h,h-2,h+2)]
 clauses={sum(1<<((x-q)%n) for x in S)for S in sets for q in range(1,n)}
 return C,clauses

def find(n,h,target,seconds=1):
 p=problem(n,h)
 if p is None:return None,0,'invalid'
 C,clauses=p;start=time.monotonic();nodes=0;allmask=(1<<n)-1
 def dfs(inside,outside):
  nonlocal nodes
  nodes+=1
  if nodes%1024==0 and time.monotonic()-start>seconds:raise TimeoutError
  if n-outside.bit_count()<target:return None
  while True:
   forced=0;active=[]
   for c in clauses:
    if c&outside:continue
    unknown=c&~inside
    if not unknown:return None
    if unknown&(unknown-1)==0:forced|=unknown
    else:active.append(unknown)
   if not forced:break
   outside|=forced
   if n-outside.bit_count()<target:return None
  if inside.bit_count()>=target:return inside
  unknown=allmask&~(inside|outside)
  if not active:return inside|unknown
  scores={i:0 for i in range(n) if unknown>>i&1}
  for c in active:
   weight=4 if c.bit_count()==2 else 1
   for i in scores:
    if c>>i&1:scores[i]+=weight
  v=max(scores,key=lambda i:scores[i]);bit=1<<v
  ans=dfs(inside|bit,outside)
  if ans is not None:return ans
  return dfs(inside,outside|bit)
 try:
  ans=dfs(sum(1<<c for c in C)|1,0)
  return ([i for i in range(n) if ans>>i&1]if ans is not None else None),nodes,'feasible'if ans is not None else'infeasible-template'
 except TimeoutError:return None,nodes,'timeout'

if __name__=='__main__':
 rows=[]
 for n,target in [(25,15),(27,15)]:
  for h in range(1,n):
   A,nodes,status=find(n,h,target,2)
   if status=='invalid':continue
   row={'n':n,'h':h,'target':target,'status':status,'nodes':nodes,'A':A};rows.append(row)
   print(json.dumps(row),flush=True)
   if A:break
 Path('research/six-circle-target-search.json').write_text(json.dumps({'scope':'Exhaustion concerns only the three-clause six-offset sufficient condition, not graph impossibility','rows':rows},indent=2)+'\n')

# Independent audit: the incidence bridge and the 2419 threshold

Reviewed 2026-09-12 by the independent proposal-check agent. This is
an ordinary mathematical proof and source review. It is not a new
exhaustive game search, and it does not extend the Lean development.

## Theorem 50

The incidence construction in `paper/dense-incidence-bridge.md` is
valid. In the projective plane over F_p, the point and line classes
each have p^2+p+1 members and every incidence degree is p+1. Two
distinct points span their unique common line, ruling out four-cycles;
bipartiteness rules out odd cycles. Thus the underlying girth is at
least six. The two components have the advertised sizes and edge
counts: J_5 has 62 vertices and 186 edges, and J_7 has 114 vertices
and 456 edges.

Hall's inequality follows by counting edges from any subset of one
bipartition class. Successively removing a perfect matching leaves a
regular bipartite graph, so selecting four of the matchings gives a
spanning four-regular subgraph. Its Euler orientations have outdegree
two at every vertex, even if the selected subgraph is disconnected.
Orienting additional edges arbitrarily and adding them individually
cannot reduce this outdegree or introduce a cycle absent from the
original incidence graph. No reciprocal arcs arise, since there is
only one orientation of each selected undirected edge.

For every n>=166, Euclidean division of n-166 by 62 gives uniquely
n=114+62k+r, with k>=0 and 52<=r<=113. The existing Theorem 19
provides the final r-vertex four-regular girth-six component. The
initial number of oriented edges is exactly 2n. The number available
after all additions is

    456+186k+2r = 3n+114-r >= 3n+1.

Consequently every integer h in [2n,3n] occurs. The directed missing
graph can be disconnected: Lemma 18 only needs minimum outgoing
degree two and the underlying girth condition, so its complement
still has all indirect pairs guaranteed in two messenger moves.

I also inspected `src/dense_incidence_bridge.py`. Normalizing the
first nonzero vector coordinate gives one representative per
projective class, and the dot-product test constructs the stated
incidence relation. Four successive bipartite matchings, Euler
orientation, residual component replay, and individual extra-edge
selection implement the proof. This receipt does not claim a new
independent execution of the generator. Its sole finite structural
input is the previously verified Theorem 19 family on 52..113
vertices; the projective-plane argument itself is not empirical.

## Revised full main interval: every n>=2419

The sparse construction of Theorem 41 covers [2n,3n], and Theorem 38
continues to T=n(ceil(n/7)-1). Theorem 50 followed by Theorem 48
covers every missing-arc budget from 2n to at least n(n-1)/13.
The overlap at 3n is exact and requires no monotonicity assumption.

For an arc budget m outside these explicit intervals, set
L=n(n-1) and p=m/L. Then

    p > (n-7)/(7(n-1)) > 7/50  (n>301),
    p < 12/13.

The function p^2(1-p) increases up to 2/3 and decreases afterwards.
Its minimum on [7/50,12/13] is therefore at an endpoint, and both
endpoint values exceed 1/60:

    2107/125000 > 1/60,       144/2197 > 1/60.

At n=2419, (n-3)/60>40>5 log(n). To justify the last inequality
without relying on rounded decimals, e>8/3 follows from its Taylor
series, and (8/3)^8>2419, so log(2419)<8. The difference
(n-3)/60-5 log(n) is increasing for n>300. Thus the strict condition
of Theorem 25 holds throughout the remaining interval for every
n>=2419, and Theorem 43 supplies its deterministic exact-budget
construction.

This independently verifies the revised Theorem 44 threshold 2419
and, with the already audited even and odd support families, the
joint piecewise classification for every N>=2419 and every m>=24.
The earlier thresholds 5442 and 10^12 were valid conservative
checkpoints and are superseded; they are not separate current gaps.

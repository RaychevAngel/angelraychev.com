# Six-offset execution record, 13 September 2026

This bounded pass began from the frozen three-triple conditional theorem
and its literal circle envelopes at orders25..42. The final constructor
performs no candidate discovery.

## Conditional proof audit

The four-position pattern now has a wholly direct predecessor seed because
h+1 is compulsory. The replacement escape triple(h,1,h+1) gives the last
two propagation steps with already winning successors. Every move is safe
against the full closed envelope, so arbitrary optional subsets, waiting,
both capture checks, and finite delivery are handled. The theorem requires
all six offsets distinct and nonzero; no unmentioned lower bound onh is
used in the conditional version.

## Failed fixed-template targets

At n25 and27, the immediate target was |A|>=15. An exact bounded
branch-and-propagate search exhausted all admissibleh without a timeout.
No such envelope met the three fixed escape clauses. The record is
six-circle-target-search.json and the search code is six-circle-search.py.
This limits that sufficient template; it is NOT an upper bound onM or an
impossibility statement about actual delivery graphs. No negative graph
theorem is claimed from this local search.

## Successful promotion of new arrows

Instead of retaining only the six old messenger moves, enlarge the envelope
by one or a few offsets and use some of those offsets in the compulsory
graph. Two immediate successful tests at25 and27 add offset2 and omit
offset1 from the otherwise compulsory nonzero envelope, giving325..350
and351..378. These cover the previously surviving326..339 and352..375.

The same bounded neighboring-envelope test then produced bridges at every
order19..24 in only25 candidate checks. Their exact intervals are:

* n19:171..228;
* n20:200..240;
* n21:210..252;
* n22:242..264;
* n23:253..299;
* n24:288..312.

Each begins at the corresponding six-offset envelope's upper endpoint.
The graph families retain arbitrary-subset robustness. Their supplied
source ranks were replayed directly for every recipient without importing
the discovery solver. Failure of an attempted source closure elsewhere
would not prove the full game losing. Frozen recipes and ranks are in
six-circle-recipes.json; the search histories remain in the separate
promoted and superset attempt records.

## Uniform residue families

At every order divisible byfour, the modulo-four envelope needs no holes
once the protected pair is replaced by a triple. With h>=7,h=3mod4,
gcd(h,n)=1 and2h+2<=n, its interval is6n..n²/2. The preceding arithmetic
parameter rule covers every4|n,n>=16.

A new periodfive pattern takes residueclasses0,1,4 and the exceptionalh,
then removes h+3,h-4,2h-1. For5|n,h>=8,h=3mod5,gcd(h,n)=1,2h+2<=n,
it has density3/5 up toconstant corrections and gives6n..n(3n/5-3).
Choosingh8 handles every odd multipleof5 at least25. The ordinary proof
checks which member of each escape triple could use the exceptionaloffset;
the three removals and missing residueclass eliminate all such covers.
This is a direct all-parameter construction, not extrapolation from tables.

## Check boundary

src/main_interval_six_circle.py --check passes35 literal recipes,
432 periodic parameterchoices through order160,188410 escape/rank
obligations, and138 exact-budget constructions. The finite promoted rows
use supplied rank vectors, whereas the conditional and periodic families
have ordinary proofs plus local premise checks. Concrete Lean
formalization is not claimed. Shared ledgers, publication pages, build
scripts, and HANDOFF were not edited by this subtask.

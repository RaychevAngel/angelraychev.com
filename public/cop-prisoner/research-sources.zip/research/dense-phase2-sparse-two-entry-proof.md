# Adjacent delivery entries: verified improvement of the sparse time bound

## Result and failed first attempt

The original M=4,R=8 arenas do not prove entry from column−3. Across the101
canonical crops,96 target objectives have missing initial states there. One
example is holes{−7,−4}, target(0,0), messenger(−3,5), cop(−1,3). This is a
failure of that restricted local arena, not a global losing position.

Enlarging only the messenger window to M=5 repairs every case. With cop radius
R=8 unchanged, all101 crops have full rank certificates proving:

* safe transfer from column−1 to column0 in at most9 messenger moves;
* delivery from column−3 to every existing target in column0 in at most39 moves;
* delivery from column−2 to every existing target in column0 in at most38 moves.

Every assertion includes every existing source type in the entry column and
every cop position other than the source, including the exterior state Omega.

## Saved finite proof artifact and direct checker

`research/dense-phase2-sparse-two-entry-certificates.json.gz` contains696 full
objectives over101 crops, with separate messenger-turn and cop-turn ranks and
a messenger policy for every winning nonterminal messenger state. It is
approximately3.16MB compressed. The summary receipt is
`research/dense-phase2-sparse-two-entry-check.json`.

`src/dense_phase2_sparse_two_entries.py --check` rebuilds every arena from the
independent literal six-type arrow definitions, checks that the saved list
contains every required pattern/objective exactly once, and checks that each
certificate claims exactly the required entry columns. It then replays every
rank obligation without rerunning the attractor:

* every positive messenger rank selects a legal successor with smaller cop rank;
* every winning nonterminal cop state has only noncollision replies with
  messenger rank at most its cop rank;
* zero messenger ranks satisfy the correct delivery or safe-transfer terminal
  condition;
* all required entry states have nonnegative ranks.

Ranks count messenger moves, so messenger transitions cost one and cop
transitions cost zero. The generator uses an independent explicit two-turn
AND/OR priority-queue algorithm; it imports neither the primary collapsed-round
solver nor the primary arena builder.

## Projection remains valid with M=5

The messenger's permitted columns are now−5,...,5. The cop keeps the unchanged
window−8,...,8 and Omega may wait or reenter any existing vertex in columns
−8,−7,−6,6,7,8. Smoothed base arcs change columns by at most2 and optional arcs
by at most3. An actual cop outside the window therefore cannot jump directly
into columns−5,...,5; all its possible reentries remain among the permitted
three boundary layers.

All messenger moves retained in the enlarged window are literal legal base
arcs, with smoothing determined by the holes in the cop crop. No periodic
identifications occur inside the cop window because k>=20>16. Omitting holes
outside the crop has the same conservative effect established in the prior
audit: it may grant the cop extra optional moves but cannot remove an actual
reply. The101-crop coverage argument is unchanged.

## At most k−2 transfers

Let the target column be t and the current source column be a, modulo k.
There are now two acceptable delivery-entry columns, t−3 and t−2. Apply safe
forward transfers until first reaching either of them, then switch to its
delivery policy. If a already belongs to this two-element set, use zero
transfers and start delivery immediately.

For an explicit count, put p=(t−3−a) modulo k in{0,...,k−1}. The distances to
the two entry columns are p and(p+1) modulo k. If p<=k−2 the first distance is
at most k−2; if p=k−1 the second distance is zero. Therefore the first hit uses
at most k−2 transfers in every case.

Safe transfer ends at a noncollision messenger-turn state, exactly the initial
condition required by the next transfer or either delivery certificate. It
does not require the cop to be absent from the entire destination column.
Every cop position in that column other than the messenger's own vertex is
already included in the certificates. If the messenger visits the recipient
before the planned handoff, receipt terminates the game immediately, so the
strategy can only finish earlier. Initial source-recipient equality is also
immediate delivery; the usual nontrivial statement concerns distinct vertices.

The resulting global time bound is

    9(k−2)+39 = 9k+21,

with k=ceil(n/6), for every graph produced by the canonical sparse construction
at every n>=115 and every optional subset. This improves the prior9k+26 bound
while preserving its full graph and budget scope. The finer entry−2 bound38
is retained in the certificates but is not needed for the uniform inequality.

No new Lean proof is claimed; this is an ordinary computer-assisted result
with complete finite rank evidence and a separate global coverage/projection
argument.

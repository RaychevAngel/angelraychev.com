# Resumed main-interval investigation: protected differences

Date: 12 September 2026. The user renewed the research budget and lifted
the earlier cutoff. This note owns the bounded investigation of stronger
explicit or probabilistic attainment in the main interval. It does not
change the original authorship or provenance of the project.

## New result

For every `n>=25`, every integer budget

`3n <= m <= n(ceil(n/7)-1)`

attains the missing-pair bound `M(n,m)=n(n-1)-m`, by an explicit
deterministic construction. Combining this quadratic interval with the
already proved probabilistic/dense interval gives the same equality for
**every sufficiently large n and every integer 3n<=m<=n(n-3)**.

For sufficiently large multiples of five, the published two-regular
family and its certified cop-only augmentation fill `2n..3n`. Thus the
entire conjectured main interval `2n..n(n-3)` is now established on that
infinite set of orders. The arbitrary-order gap `2n..3n` remains open.

The proofs are Theorem 38 and Corollary 39 in
`paper/main-interval-resume.md`. The result was derived in the current
assistant analysis and independently checked by the parent research
agent. It is not credited to the original 2023 manuscript. No new Lean
theorem is claimed.

## Why the earlier extension was unnecessarily restrictive

The original extension kept every nonzero difference of the closed move
set unique. Its greedy exclusion count was cubic, limiting the move-set
size to order `n^(1/3)` and the arc budget to order `n^(4/3)`.

The actual messenger proof uses only three core moves `S={1,a,h}`,
where `h=2a+1` and `gcd(h,n)=1`. Every safe-branching step chooses two
of these moves. Therefore it only needs uniqueness of the six ordered
differences

`D={u-v:u,v in S,u!=v}={±(a-1),±(a+1),±2a}`.

Start with `A0={0,1,a,h}`, whose differences already have the required
uniqueness by the original coprime-step proof. Enlarge it by selecting
each new residue outside `A union (A+D)`. This introduces no new pair
with a protected difference. With `k` chosen residues, at most `7k`
residues are excluded. Thus one can always reach `ceil(n/7)` residues.

Every actual graph between the three-move core and the enlarged move
envelope remains universally winning. To see the crucial point, suppose
both successors `r+u,r+v`, for distinct core moves `u,v`, belong to a
different cop's closed envelope `c+A`. Their difference is protected,
so uniqueness forces their two representatives in `A` to be exactly
`u,v`, whence `c=r`, contradiction. At least one protected successor
therefore survives the cop response. The same finite quartet proof
uses only these protected pairs.

Extra arcs can be chosen individually, with no translation symmetry.
They change neither the presence of the core moves nor the enclosing
closed envelope. This fills every integer budget in the stated interval.

Concrete non-Sidon example: at `n=29`, the core is `{1,3,7}` and the
envelope is `{0,1,3,7,8}`. The protected differences `±2,±4,±6` remain
unique, but `0-1=7-8=-1 mod29` is a repeated unprotected difference.
The receipt explicitly records this example. Hence the enlarged proof
is not merely another way to check the old full distinct-difference
condition; it admits graphs that condition excludes.

## Independent attacks and limitations

- The proof does **not** use a global bound on intersections of actual
  closed neighborhoods. Such intersections may now be large. It only
  controls the particular successor pairs used by the core strategy.
- Both signs of every protected difference are forbidden when adding
  a residue. Otherwise a reversed ordered representation could break
  uniqueness. The construction uses the symmetric set `D` explicitly.
- Existing core pairs at distances in `D` are intentionally retained;
  the greedy rule forbids only new pairs. The covering/count argument
  `|A union(A+D)|<=7|A|` does not require the original set to be
  independent in this auxiliary difference graph.
- The initial source `-a-1` uses moves `1,a`; the four propagated
  quartet steps use `(a,h),(1,h),(a,h),(1,h)`. All required protected
  differences are therefore included, and no unprotected pair is used.
- The source-pair argument explicitly excludes cop position equal to
  the messenger position. A successful branch lands outside the cop's
  closed neighborhood, so the intervening cop turn is fully respected.
- The existing all-order choice of `h` is used only at orders `n>=25`.
  No assertion about smaller orders is inferred from its formula.
- The all-large-order overlap uses the already proved Corollary 26,
  whose very dense part comes from the high-girth complement interval.
  It must not be described as a random-graph argument that works all
  the way to `h=2n` on its own.
- The common threshold is asymptotic and unspecified. The explicit
  interval itself applies at every `n>=25` with exactly its displayed
  finite endpoints.

## Finite verification

`src/main_interval_resume.py` supplies the deterministic move extension
and exact-budget graph construction. Run it without arguments to write
`research/main-interval-resume-checks.json`.

The completed check used orders 25, 29, 35, 49, 75, 100, 200, and 1000.
It verifies the six protected ordered representations in each envelope.
For the seven orders through 200 it also checks every core successor
pair against every different cop envelope directly.

At orders 29, 35, and 49, it constructs four budgets each: the base,
one extra arc, a middle budget, and the envelope endpoint. For recipient
zero and recipient `n-1`, both independent full solvers and the explicit
rank-certificate verifier confirm all sources and legal initial cop
positions, for 24 recipient-game checks. Intermediate budgets generally
break translation symmetry. The whole bounded run took under a second.

These checks validate listed instances and code, while the all-order
proof is ordinary mathematics. The receipt includes the generator hash
and the full exact test scope.

## Approaches considered before the simplification

An initial possibility was to enlarge the parabola construction or to
analyze bootstrap growth in random sparse graphs. Random graph degree
and common-neighbor fluctuations make a naive global two-successor
criterion too restrictive. Likewise, the full distinct-difference
condition had been preserving properties unused by the strategy.
Inspecting the actual four quartet steps exposed the smaller invariant
and avoided both an algebraic extension and a probabilistic bootstrap
calculation. No unsuccessful probabilistic heuristic is asserted as a
theorem here.

# Extremal bounds: independent September 2026 investigation

Status: ordinary proofs below; finite experiments are identified separately. This file is owned by the extremal-bounds research agent. The main game semantics are those of `HANDOFF.md`.

## 1. Source and target camping obstructions

Write `N⁺[c]={c}∪N⁺(c)`.

**Source obstruction.** If `s≠c` and `N⁺(s)⊆N⁺[c]`, source `s` supports no guaranteed indirect delivery. The pursuer begins at `c` and waits while the messenger waits. Every nonterminal departure from `s` enters either the pursuer's present vertex or one of its outgoing neighbors, and is captured before the next messenger turn. This respects infinite-play failure.

Consequently an indirect-guaranteed source has outdegree at least two. Distinct sources with identical outgoing neighborhoods cannot support any indirect guarantee: one can serve as the pursuer blocking the other. This invalidates a naive attempt to multiply the diamond construction by cloning its source.

**Predecessor obstruction.** If `D_t=N⁻(t)⊆N⁺[c]`, every guaranteed indirect source for `t` must equal `c`. A pursuer initially at `c` waits until the messenger first enters `D_t` and captures before transmission. As usual, a source already in `D_t` is a direct pair and is excluded from this claim.

These are necessary obstructions, not sufficient criteria.

## 2. An exact dense boundary for the joint extremal problem

Let `M(n,m)` denote the maximum number of guaranteed indirect pairs among loopless digraphs with `n` vertices and `m` arcs.

**Theorem.** For every `n≥2`,

1. `M(n,m)=0` if `m>n(n−2)`;
2. `M(n,n(n−2))=floor((n−2)/2)`.

Thus the last arc count supporting any positive indirect guarantee is exactly `n(n−2)` for every `n≥4`.

### Proof of the vanishing range

Suppose `(s,t)` is an indirect guaranteed pair. Row `s` is missing the arc `s→t`. For each `c≠s`, the source obstruction implies that some `u∈N⁺(s)` is outside `N⁺[c]`. Therefore row `c` is missing at least the nonloop arc `c→u`. All `n` rows are missing at least one arc. Hence the number of missing nonloop arcs is at least `n`, or `m≤n(n−2)`.

### Equality characterization

Suppose `m=n(n−2)` and `I(G)>0`. Every row then misses exactly one arc. Write `f(v)` for its missing endpoint; `f(v)≠v`.

For a possible indirect pair, necessarily `t=f(s)`. The source obstruction says, for every `c≠s`, that `f(c)` belongs to `N⁺(s)=V\{s,t}`. Equivalently,

- `f⁻¹(s)=∅`;
- `f⁻¹(t)={s}`.

Conversely these two conditions imply the actual two-move delivery strategy. Given any initial `c≠s`, let `u=f(c)`. The conditions give `u∉{s,t}` and hence `s→u`. The pursuer cannot capture at `u`, because `u≠c` and `c→u` is missing. Also `u→t` is present: the only vertex whose missing endpoint is `t` is `s`, while `u≠s`. The messenger transmits to `t` on its second move, including if the pursuer moved to `t` meanwhile.

Therefore `I(G)` is exactly the number of directed functional-graph edges `s→t=f(s)` with indegrees `deg_f⁻(s)=0` and `deg_f⁻(t)=1`.

### Sharp counting

If there are `k` such pairs, their `k` sources and `k` targets are all distinct: sources have indegree zero, targets indegree one, and a target cannot receive two source edges. No vertex outside these `2k` vertices can map into a source or target. Thus the outside set is closed under `f`. It is nonempty because every finite functional graph contains a directed cycle, while the selected sources and targets cannot lie on one. Since `f` has no fixed point, the outside set contains at least two vertices. Hence `2k≤n−2`.

For attainment choose vertices `s_i,t_i` for `1≤i≤floor((n−2)/2)`, and two further vertices `a,b`. Set `f(s_i)=t_i`, `f(t_i)=a`, `f(a)=b`, `f(b)=a`; send any one leftover vertex to `a`. Let `G` contain every nonloop arc except `v→f(v)`. Exactly the displayed `k` pairs are guaranteed indirect pairs.

### Independent checks

The independently implemented least-attractor probe agrees with the theorem on its explicit constructions. The separate solver agent's exhaustive tables through `n=6` give the predicted boundary values `1,1,2` for `n=4,5,6`, and zero at every larger arc count.

## 3. Failed strengthening: indegree two

The conjecture that a target of indegree two supports at most one indirect guaranteed source is **false**.

A small independently found counterexample on vertices `0,…,4` has outgoing neighborhoods

```
0: {2,4}
1: {4}
2: {0,3}
3: {1,2}
4: {3}
```

Target `4` has predecessors `{0,1}`, but both `(2,4)` and `(3,4)` are guaranteed indirect. The complete indirect-pair list in the independent solver is `{(0,3),(2,4),(3,4)}`.

The separate solver agent independently found another five-vertex counterexample with four indirect pairs, saved among the `m=8` witnesses in `solver-enumeration-n5.json`.

An even stronger finite counterexample from the construction-audit agent appends a sink with two incoming arcs to an all-delivery 23-vertex circulant. That indegree-two recipient has 21 guaranteed indirect sources. This larger result is computational at this point; consult the owning agent's construction file and certificates before public use.

Thus neither the individual-target bound `I_t≤n−4` nor any logarithmic indegree lower bound follows from source counts. An attempted universal upper bound `I≤n(n−4)` based on that premise was abandoned.

## 4. Sparse construction direction

A proposed operation on two arcs `u→v` and `w→z` is to delete them, add a new vertex `x`, and add `u→x,w→x,x→v,x→z`. It adds one vertex and exactly two arcs when the chosen tails and heads are distinct. It is **not proved to preserve delivery guarantees in general**.

The construction-audit agent found many successful instances starting from all-delivery three-regular circulants, including the 16-vertex circulant with steps `{1,3,7}`: replace `0→1,1→2` with `0→16,1→16,16→1,16→2`. Its independently verified all-delivery graph has `n=17,m=50,I=222`, exceeding `17(17−4)=221`. Repeated successful choices kept `m−2n=16` through further finite sizes. A uniform valid growth rule would approach the elementary vertex upper bound to a constant additive gap and establish the sharp leading coefficient `1/4` in the arc-only extremal problem; such a rule is not yet established here.

## 5. Early arc-only upper bound and conditional implications (superseded below)

At this early stage the upper bound was `M_E(m)≤floor(m/2)^2`: counted sources and targets each have respective degree at least two. Sections 7–10 below substantially sharpen it and classify equality. No exact all-`m` formula follows without attaining constructions at the remaining sizes.

If a family with every pair guaranteed, `n` vertices, and `m=2n+C` arcs were proved for all sufficiently large `n`, it would give `I=n(n−3)−C`. With disjoint one-way arcs to pad odd edge counts, this would imply `M_E(m)=m²/4−O(m)`. This statement records a conditional consequence, not an attained theorem.

## 6. Additional small dense example

At one arc below the dense boundary, corrections are not simply one per missing arc. On seven vertices take missing neighborhoods

```
0: {1,2}
1: {3}
2: {4}
3: {5}
4: {5}
5: {6}
6: {5}
```

The complementary digraph has `m=34=7(7−2)−1` and four indirect pairs `(0,1),(0,2),(1,3),(2,4)`, all verifiable by the two-move criterion. The boundary value at `m=35` is only two. Thus one deleted arc can increase the joint optimum by at least two in this range. This also discourages assuming Lipschitz behavior under graph edits.

## 7. Sharp universal upper bound for an even number of arcs

**Theorem.** Every loopless digraph with `m=2k` arcs, where `k≥5`, satisfies

```
I(G) ≤ k(k−3).
```

In particular, whenever an all-delivery two-regular digraph on `k` vertices exists, it is extremal not only at its vertex count but among **all** digraphs with exactly `2k` arcs, with no restriction on vertex count.

### Two zero-degree consequences

- If a vertex `z` has indegree zero and `z→t`, where `t` has indegree two, then `t` supports no indirect guaranteed source. An indirect source cannot be `z` (its arc to `t` is direct), cannot be the other predecessor `p` (also direct), and cannot reach `z`. A pursuer initially at `p` camps there and blocks every route to `t`.
- If a vertex `z` has outdegree zero and `s→z`, where `s` has outdegree two, then `s` supports no indirect guaranteed target. Its other successor `p` can be occupied by a camping pursuer. Entering `z` is a dead end unless `z` is the recipient, which would be a direct pair.

These use actual strategies, not a presumed reversal invariance of the game.

### Degree bookkeeping

Let `A={v:d⁺(v)≥2}`, `B={v:d⁻(v)≥2}`, `q=|A|`, `r=|B|`, and `b=|A∩B|`. Every counted pair belongs to `A×B`. Each pair on the diagonal or corresponding to an arc is excluded, so

```
I ≤ qr − b − e(A,B).
```

The outgoing arcs of `A` and the incoming arcs of `B` together give

```
e(A,B) ≥ max(0, 2q+2r−2k),   q,r≤k.
```

For `q,r≥2`, the function `F(q,r)=qr−max(0,2q+2r−2k)` is nondecreasing in both variables. Unless `(q,r)` is one of `(k,k),(k−1,k),(k,k−1)`, it is bounded by the larger of

```
F(k,k−2)=k²−4k+4,
F(k−1,k−1)=k²−4k+5.
```

Both are at most `k(k−3)` for `k≥5`. If `q≤1` or `r≤1`, simply use `I≤k≤k(k−3)`.

### Case q=r=k

All arcs have tails in `A`, heads in `B`, and all these relevant degrees equal two. If `A=B`, then `b=k` and `e(A,B)=2k`, giving the result.

Otherwise choose `z∈A\B`. It has indegree zero, and its two distinct successors belong to `B` and have indegree two. Both target columns contribute zero by the first zero-degree consequence. The other `k−2` columns receive exactly `2k−4` arcs, all from `A`. Thus, even ignoring diagonal exclusions,

```
I ≤ k(k−2)−(2k−4)=k²−4k+4 ≤ k(k−3).
```

### Case q=k−1, r=k

If `b≥2`, the bookkeeping inequality gives `I≤k(k−3)+2−b≤k(k−3)`.

If `b≤1`, choose `z∈A\B`. Every arc has its head in `B` and each member of `B` has indegree two, so `z` has indegree zero. Select two of its distinct successors. Both columns contribute zero. The other `k−2` target columns receive `2k−4` arcs. At most two arcs have tails outside `A`, since `A` has total outdegree at least `2k−2`. Consequently at least `2k−6` of those remaining-column arcs have tails in `A`, and

```
I ≤ (k−1)(k−2)−(2k−6)=k²−5k+8 ≤ k(k−3).
```

### Case q=k, r=k−1

If `b≥2`, the same bookkeeping inequality suffices. Otherwise choose `z∈B\A`. Every arc has its tail in `A` and each member of `A` has outdegree two, so `z` has outdegree zero. Select two of its predecessors. Both source rows contribute zero by the second zero-degree consequence. The remaining `k−2` source rows emit `2k−4` arcs, of which at most two have heads outside `B`. The same bound `k²−5k+8≤k(k−3)` follows.

### Finite equality cases currently available

The solver agent has independently certified all-delivery two-regular examples for every `k=12,…,24` (check its latest witness file for the exact certified range). Each certified example therefore establishes `M_E(2k)=k(k−3)`, not merely a lower bound. The upper bound itself is universal for every `k≥5`; a general attaining family remains separate work.

## 8. Sharp universal upper bound for an odd number of arcs

**Theorem.** Every loopless digraph with `m=2k+1` arcs, where `k≥5`, satisfies

```
I(G) ≤ k(k−3)+2.
```

Keep `A,B,q,r,b` from Section 7. We have

```
I ≤ qr−b−max(0,2q+2r−2k−1),  q,r≤k.
```

For `q,r≥2`, the expression without `−b` is nondecreasing in both variables. Outside `(q,r)=(k,k),(k−1,k),(k,k−1)`, its maximum is bounded by the larger of `k²−4k+5` and `k²−4k+6`, which are at most `k(k−3)+2` for `k≥5`. The cases `q≤1` or `r≤1` are immediate.

### A useful one-extra-arc observation

If `r=k`, then

```
(number of arcs ending outside B) + sum_{t∈B}(d⁻(t)−2) = 1.
```

In particular, at most one vertex outside `B` has positive indegree. Also every indegree-zero source of outdegree at least two has a successor in `B` of indegree exactly two: if an arc ends outside `B`, all members of `B` have indegree two and there is only one such outside-ending arc; otherwise at most one member of `B` has indegree above two. Such a successor contributes a zero target column by Section 7.

The dual statement holds if `q=k`: at most one vertex outside `A` has positive outdegree, and every outdegree-zero target of indegree at least two has an outdegree-two predecessor, giving a zero source row.

### Case q=k−1, r=k

The degree inequality gives `I≤k(k−3)+3−b`, so `b≥1` suffices.

If `b=0`, all `k−1` vertices of `A` lie outside `B`, and at most one has positive indegree. Choose an indegree-zero one. The preceding observation gives a zero target column. The `k−1` other target columns receive at least `2k−2` arcs; at most three of these have tails outside `A`, since total outdegree in `A` is at least `2k−2`. Hence

```
I ≤ (k−1)²−(2k−5)=k²−4k+6 ≤ k(k−3)+2.
```

The case `q=k,r=k−1` is proved by the dual zero-row argument; it does not assume that reversing arcs preserves the game.

### Case q=r=k

The degree inequality gives `I≤k²−2k+1−b`, so `b≥k−1` suffices.

Suppose `2≤b≤k−2`. There are at least two members of `A\B`, and at most one has positive indegree. Choose an indegree-zero one to obtain a zero target column. The remaining `k−1` target columns receive at least `2k−2` arcs. At most one arc has its tail outside `A`, so at least `2k−3` of these are direct pairs in `A×B`. At least `b−1≥1` diagonal pair also remains. Thus

```
I ≤ k(k−1)−(2k−3)−1 = k(k−3)+2.
```

Finally suppose `b≤1`. There are at least `k−2≥3` indegree-zero members of `A\B`. Each has an indegree-two successor. At most two of these sources can point to the same indegree-two vertex, so there are at least two distinct zero target columns. The other `k−2` columns receive at least `2k−4` arcs, at most one from outside `A`. Therefore

```
I ≤ k(k−2)−(2k−5)=k²−4k+5 ≤ k(k−3)+2.
```

This finishes the proof.

### Finite equality witnesses

Deleting a single arc `u→v` from a two-regular all-delivery graph on `k+1` vertices leaves `2k+1` arcs, with `u` of outdegree one and `v` of indegree one. If every other eligible missing pair remains guaranteed, exactly `k(k−3)+2` indirect pairs remain. The separate solver agent has independently certified such attaining deletions for every `k=18,…,23`, saved in `solver-odd-budget-delete.json`. The deletion condition is verified for these witnesses; preservation under arbitrary deletion is false and is not asserted.

## 9. Current extremal summary from these bounds

For all `k≥5`, universally,

```
M_E(2k) ≤ k(k−3),
M_E(2k+1) ≤ k(k−3)+2.
```

These improve the handoff's `floor(m/2)^2` upper bound by an exact linear term. Existing finite attaining graphs certify equality at their listed arc counts. The full eventual equality statement requires a uniform attaining construction and is not obtained by the upper-bound proof alone.

## 10. Rigidity of equality in the arc-budget upper bounds

The following statements concern equality in the numerical upper bounds, whether or not it is attained at a particular size.

### Even arc budgets

**Theorem.** For `k≥6`, a graph with `2k` arcs satisfies `I=k(k−3)` if and only if, after removing isolated vertices, it is a two-in/two-out-regular graph on exactly `k` vertices in which every source–recipient pair is guaranteed.

For necessity, the generic bounds outside the top three `(q,r)` cases in Section 7 are strict when `k≥6`. In the case `q=k−1,r=k`, if `A\B` is nonempty then a zero-indegree member yields the strict zero-column bound `k²−5k+8`. If `A⊆B`, then `b=k−1` and the degree bound is `k²−4k+3`, also strict. The dual excludes `q=k,r=k−1`. In the remaining case `q=r=k`, if `A≠B` the zero-column bound `k²−4k+4` is strict. Therefore `A=B`, all arcs lie inside this `k`-vertex set, and all indegrees and outdegrees there equal two. Equality in the count says every missing nonloop pair is guaranteed; diagonal and direct pairs are automatic. All outside vertices are isolated. Sufficiency is immediate by counting.

### Odd arc budgets

**Theorem.** For `k≥6`, equality `I=k(k−3)+2` in a graph with `2k+1` arcs forces the following structure after isolated vertices are removed:

- exactly `k+1` vertices;
- one vertex `u` has outdegree one and indegree two;
- a different vertex `v` has indegree one and outdegree two;
- every other vertex has indegree and outdegree two;
- the arc `u→v` is absent;
- every missing nonloop pair whose source has outdegree two and recipient has indegree two is guaranteed.

Conversely, these structural and game conditions imply equality. Thus every equality graph is obtained by deleting one arc from a two-regular digraph, though the completed digraph need not automatically be all-delivery.

To prove necessity, outside the top three `(q,r)` cases the Section 8 bound is strict. If `q=k−1,r=k`, a positive intersection `b≥2` already gives strictness. If `b≤1`, there is a zero-indegree member of `A\B` and the zero-column proof gives the strict bound `k²−4k+6`; the dual deals with `q=k,r=k−1`.

For `q=r=k`, the case `b=k` gives a strict degree bound. If `3≤b≤k−2`, the single-zero-column proof retains at least `b−1≥2` diagonal exclusions and is strict. If `b=2`, then `A\B` has at least `k−2` vertices, at least `k−3≥3` of indegree zero. These force at least two zero columns, again strict. The same two-column argument excludes `b≤1`. Thus necessarily `b=k−1`.

Write `A\B={v}` and `B\A={u}`. Equality requires `e(A,B)=2k−1` and every eligible missing pair to be guaranteed. The outgoing degrees in `A` and incoming degrees in `B` have sum at most `(2k+1)+(2k−1)=4k`, and each sum is at least `2k`; hence all these degrees equal two. There is exactly one arc with tail outside `A` and exactly one arc with head outside `B`, and these are distinct arcs.

If `v` had indegree zero, it would have an indegree-two successor in `B`, giving a zero target column with at least `k−3>0` eligible missing pairs, a contradiction. Thus `v` has indegree one, and it receives the unique arc ending outside `B`. Dually, `u` has outdegree one, and emits the unique arc starting outside `A`. The two exceptional arcs are distinct, so `u→v` is absent. Every vertex outside `A∪B` is isolated. Adding `u→v` makes the support two-regular, as claimed.

## 11. Exact dense threshold for all-delivery networks

Call a graph *all-delivery* when every source–recipient pair is guaranteed.

**Theorem.** A noncomplete all-delivery digraph on `n≥2` vertices has at most `n(n−3)` arcs.

A noncomplete all-delivery graph has some indirect pair. The source obstruction then implies that no row is complete: a pursuer in a complete row blocks every indirect source other than itself, and the complete-row vertex has no indirect target itself. Hence every vertex has at least one missing outgoing arc. If row `c` were missing exactly `c→t`, then `N⁺(t)⊆N⁺[c]`. Since `t` also has a missing outgoing arc, it has an indirect recipient, which the source obstruction forbids. Thus every row has at least two missing arcs, proving the bound.

### An infinite family attaining the threshold

**Theorem.** For every integer `k≥4`, there is an all-delivery graph on `n=5k` vertices with exactly `n(n−3)` arcs. Consequently

```
M(5k,5k(5k−3))=10k.
```

This assertion does **not** depend on the sparse-family universal strategy: the complementary graph below has an independent three-move proof. The sparse-family strategy has since been proved separately by the bounded local certificates and the six small-ring certificates recorded in `paper/sparse-certificates.md`.

On vertices `Z/(5k)`, define permutations `α(v)=v+1` and `β` by writing `v=5i+j`, `0≤j≤4`, and setting

```
β(5i+0)=5(i+1)+0,
β(5i+1)=5(i−1)+2,
β(5i+2)=5(i−1)+4,
β(5i+3)=5(i−1)+3,
β(5i+4)=5(i−1)+1.
```

All values are read modulo `5k`. Let `H` contain exactly the two arcs `v→α(v),v→β(v)` from each vertex, and let `G` contain precisely the nonloop arcs absent from `H`. The two permutations have no fixed point and never agree for `k≥4`, so `H` has `2n` arcs and `G` has `n(n−3)` arcs.

We prove every missing pair of `G` is guaranteed within three messenger moves. Fix such a pair `(s,t)` and a pursuer `c≠s`. A safe two-move intermediate is any vertex in

```
{α(c),β(c)} \ F(s,t),
F(s,t)={s,t,α(s),β(s),α⁻¹(t),β⁻¹(t)}.
```

Indeed, the intermediate is an `H`-successor of the pursuer and therefore cannot be captured on the pursuer's next move in `G`; its exclusion from `F` says it is distinct from the source and recipient, is a `G`-successor of the source, and is a `G`-predecessor of the recipient.

Translate the source by a multiple of five to put `s∈{0,1,2,3,4}`. There are ten missing-pair types. The following table computes the forbidden set using integer representatives. A pursuer can fail the two-move criterion only if `α(c)∈F`, hence `c∈F−1`. The fourth column lists `β(c)` for those candidate pursuers other than `s`.

| `s` | `t` | `F(s,t)` | `(c,β(c))` for `c∈F−1`, `c≠s` |
|---:|---:|---|---|
| 0 | 1 | `{0,1,5,9}` | `(-1,-9),(4,-4),(8,3)` |
| 0 | 5 | `{0,1,4,5}` | `(-1,-9),(3,-2),(4,-4)` |
| 1 | 2 | `{-3,1,2,6}` | `(-4,-8),(0,5),(5,10)` |
| 1 | -3 | `{-4,-3,1,2}` | `(-5,0),(-4,-8),(0,5)` |
| 2 | 3 | `{-1,2,3,8}` | `(-2,-7),(1,-3),(7,4)` |
| 2 | -1 | `{-2,-1,2,3}` | `(-3,-6),(-2,-7),(1,-3)` |
| 3 | 4 | `{-2,3,4,7}` | `(-3,-6),(2,-1),(6,2)` |
| 3 | -2 | `{-3,-2,3,4}` | `(-4,-8),(-3,-6),(2,-1)` |
| 4 | 5 | `{-4,0,4,5}` | `(-5,0),(-1,-9),(3,-2)` |
| 4 | -4 | `{-5,-4,4,5}` | `(-6,-14),(-5,0),(3,-2)` |

The only listed value `β(c)` in its forbidden set occurs in the penultimate row at `c=-5`. This integer check remains valid modulo every `5k≥20`: every difference tested between a displayed `β(c)` and its row's forbidden-set members has absolute value at most `19`, so no new modular equality appears. The same bound, or the smaller displayed ranges, prevents spurious identification of a candidate pursuer with the source.

Thus the sole exceptional state, up to translation by five, is

```
s=4, t=5, c=-5.
```

In that state the messenger moves to `0`. This is a legal `G`-arc from `4` because the two missing successors of `4` are `5` and `-4`. It is safe against the pursuer at `-5`, whose two missing successors in `G` are `0` and `-4`. After the pursuer's move, the messenger is at `0` with recipient `5`, a nonexceptional pair covered by the table for every surviving pursuer position. It wins in at most two further moves. This proves the theorem uniformly for all `k≥4`.

### Verification boundary

The local ten-row arithmetic and the three-move game argument above are an ordinary proof. The script `src/extremal_bounds_periodic.py` independently checks the two-move exceptions for finite moduli; the proof does not extrapolate those computations. No Lean formalization of this theorem has yet been supplied in this agent's files.

## 12. General dense-complement theorem and all sufficiently large orders

### Complement of an oriented high-girth graph

**Theorem (root construction, independently audited here).** Let `F` be an orientation of a simple undirected graph of girth at least six, with every outdegree at least two. Let `G` be its directed complement, containing every nonloop arc absent from `F`. Then every source–recipient pair in `G` is guaranteed within two messenger moves.

It suffices to consider a missing arc `s→t` of `G`, hence an arc of `F`. Put

```
B=N_F⁺(s) ∪ N_F⁻(t).
```

This contains both `s` and `t`. The underlying graph induced by `B` is a double star with centers `s,t`: the other outneighbors of `s` and other predecessors of `t` are distinct leaves, and extra edges would create a triangle or quadrilateral. Its diameter is at most three.

For `c` outside `B`, two neighbors inside `B` would complete an undirected cycle of length at most five, so `c` has at most one outgoing neighbor in `B`. For `c∈B\{s}`, the same bound follows from the orientations: a leaf adjacent to `s` has that edge directed toward it and has no other edge into `B`; a leaf adjacent to `t` has only its edge toward `t`; and `t` has no outgoing edge into `B`. Thus every `c≠s` has at most one outgoing `F`-neighbor in `B`.

Since every outdegree in `F` is at least two, choose `u∈N_F⁺(c)\B`. Then `s→u` and `u→t` are arcs of `G`, while `c→u` is absent from `G`; also `u≠c` since `F` is loopless. Moving through `u` therefore gives a safe two-move delivery.

### Four-regular girth-six graphs at every order n≥52

**Theorem.** There is a four-regular undirected simple graph of girth at least six on every number `n≥52` of vertices.

For the base building block use two copies of `Z/13`, interpreted as points and lines, with adjacency differences in `{0,1,3,9}`. Each vertex has degree four. The twelve nonzero ordered differences between distinct members of this set are precisely the twelve nonzero residues modulo 13, so two points share at most one line. The graph is bipartite and has no four-cycle, hence girth at least six. It has 26 vertices.

For a growth operation, choose two edges `ab,cd` with every endpoint of the second at distance at least four from every endpoint of the first. Delete these edges, add a new vertex `x`, and connect `x` to `a,b,c,d`. All old degrees remain four; the new vertex has degree four. Any new cycle uses two new spokes. If these attach to endpoints of the same removed edge, the remaining old path has length at least five, yielding a new cycle of length at least seven. Otherwise the old path has length at least four, yielding a cycle of length at least six. Girth is preserved.

Such an edge pair exists in every four-regular graph with more than 120 vertices. Fix an edge `ab` and let `B` be the set within distance three of its endpoints. The branching bound gives

```
|B| ≤ 2(1+3+9+27)=80.
```

The induced subgraph on `B` is connected, so it has at least `|B|−1` edges. If no edge had both endpoints outside `B`, four-regularity would imply

```
4|V\B| = e(B,V\B)
          = 4|B|−2e(B)
          ≤ 2|B|+2.
```

Consequently `n≤floor((3|B|+1)/2)≤120`, a contradiction. An outside edge is the required second edge.

Starting with five disjoint 26-vertex building blocks proves the all-order statement for `n≥130` without any finite certificate. To lower the threshold to 52, start with two disjoint building blocks and use the 78 explicit insertions in `research/extremal-bounds-girth-growth.json`. The accompanying generator/replayer `src/extremal_bounds_girth_family.py` verifies each required endpoint separation, all degrees, and the absence of cycles of length at most five. This supplies every size from 52 through 130; the universal growth argument handles every larger size. The threshold-52 claim has this explicit finite structural-certificate dependency, while threshold 130 is wholly ordinary and self-contained from the preceding proof.

### Exact dense joint-extremal theorem

Orient an Euler circuit in each component of a four-regular girth-six graph. Every vertex then has indegree and outdegree two. Its directed complement is universally two-move by the complement theorem. Therefore, for every `n≥52`,

```
M(n,n(n−3)) = 2n.
```

The upper bound is simply the number of missing arcs. This is the highest possible arc density for a noncomplete all-delivery network, by Section 11. The all-order theorem for `n≥130` has a fully ordinary proof; the extension down to 52 uses the small explicit growth certificate above.

## 13. An interval of exact dense joint extrema

The minimum-outdegree formulation of the complement theorem permits adding undirected edges to the high-girth graph and orienting them arbitrarily. Previously oriented arcs remain fixed, so minimum outdegree two persists.

Fix integers `n≥52` and `5≤D≤n−1`. Define

```
B_D = 1 + D[1+(D−1)+(D−1)²+(D−1)³]
    = D⁴−2D³+2D²+1,
L_D(n) = floor([Dn−(D−4)B_D]/2).
```

**Theorem.** For every integer `h` with `2n≤h≤L_D(n)`,

```
M(n,n(n−1)−h)=h.
```

An empty interval makes no assertion.

Start from the four-regular girth-six graph and repeatedly add an edge between two vertices of current degree less than `D` whose distance is at least five (vertices in different components have infinite distance). This preserves simplicity, maximum degree `D`, and girth at least six. Let `U` be the set of vertices of degree less than `D` when no further insertion is possible. If `U` is nonempty, every member of `U` is within distance four of any fixed member, so `|U|≤B_D`. If `U` is empty this bound also holds. Minimum degree remains at least four, and hence the final graph has at least

```
[ D(n−|U|)+4|U| ]/2 ≥ [Dn−(D−4)B_D]/2
```

edges. The process adds edges one at a time, so it passes through every edge count from `2n` to `L_D(n)`. Orient the initial four-regular graph by Euler circuits and every new edge arbitrarily. The complement theorem gives all-delivery at each stage, proving equality with the missing-arc bound.

For example, when `n≥2D⁴`, we have `B_D≤D⁴≤n/2` and `L_D(n)≥n(D/4+1)−1`. Taking `D=floor((n/2)^(1/4))` for sufficiently large `n` yields a uniform interval of exact dense extrema with missing-edge counts extending to a positive constant times `n^(5/4)`. The explicit parameterized bound above is the primary statement; no asymptotic optimization is needed to use it.

### Independent structural certificate replay

A second implementation, `src/extremal_bounds_girth_verify.py`, rebuilt the base directly from the point–line incidence condition and replayed all 78 insertions. At every one of the 79 orders, it verified degree four and excluded cycles of lengths three, four, and five by enumerating simple paths and testing closing edges. This differs from the generator's edge-deleted breadth-first checks. All checks passed. The receipt is `research/extremal-bounds-girth-verification.json`; the certificate SHA-256 is `1704af642ee37904ea88c7b586d325605e2dc5ce19ba9a1919ba1a73932bfc00`.

The general dense-interval proof was then re-audited against its degree cap, distance threshold, parity, and orientation requirements: adding one undirected edge between vertices at distance at least five creates no cycle shorter than six; arbitrary orientation preserves the two pre-existing outgoing arcs at every vertex; no regularity assumption is needed after the initial Euler orientation. The interval can be empty, and the theorem explicitly makes no assertion in that case.

## 14. Exact arc-only extrema for budgets zero through seven

The complete proofs are in `paper/small-arcs.md`, Propositions 23 and 24.

* Ordinary proof: `M_E(0..6) = (0,0,0,0,1,1,2)`, over arbitrary vertex counts. A counted pair consumes at least four distinct arcs (two leaving its source, two entering its nonadjacent recipient). The degree-support bound handles most remaining cases. At six arcs, the extreme support sizes `(q,r)=(2,3),(3,2),(3,3)` require the zero-indegree predecessor / zero-outdegree successor camping obstructions. Every case is included in the manuscript supplement.
* Computer-assisted proof: `M_E(7)=2`. Two positive weak components require at least eight arcs. A connected component with at most seven arcs and at least seven vertices has a tree or unicyclic underlying multigraph, retaining opposite arcs as parallel edges. A counted pair must lie on the unique cycle and have both cycle paths directed from source to recipient, so at most one pair is possible. The remaining component has at most six vertices, where the complete exhaustive enumeration records maximum two for seven arcs. Thus the finite enumeration applies after an explicit all-order structural reduction.
* The four-arc diamond has one guarantee; the six-arc graph with arcs `0→1,0→2,1→3,1→4,2→3,2→4` has two. Padding by a disjoint arc gives the odd budgets five and seven.

I briefly attacked budgets eight through eleven using sharper equality cases in the degree-support bookkeeping. One critical eight-arc case `(q,r,b)=(3,3,0)` appears to exclude five guarantees by an exhaustive classification of its two residual arcs on each side, but other support corners were not completed. No exact all-order claim for those budgets is made. Their six-vertex maxima are computational evidence only, until an all-order reduction or further structural proof is supplied.

# Exact endpoint decision M(8,40)=12

13 September 2026. Complete producer result with literal full-game replay.
Independent source/coverage review is pending; no canonical registry, paper,
or handoff has been edited by this endpoint pass.

The proposed theorem is

    M(8,40)=12.

The lower graph and all negative leaf certificates are literal finite evidence.
The upper search is a complete decision, not a bounded heuristic maximum.
It does not depend on any of the newly proposed rooted-core reductions.

## Upper decision domain

Use missing-arrow rows F(v), q(v)=|F(v)|. There are h=56-40=16 missing arrows.
An upper counterexample would have I>=13, hence at most three failed missing
pairs.

If q(c)=0, the pursuer at c can capture every first nonterminal messenger move.
No source other than c can guarantee a missing recipient, while source c has
no missing recipient. Therefore I=0. It suffices to enumerate positive missing
outdegrees. Every positive degree vector has a relabeling with nondecreasing
degrees. The producer enumerates every such vector of length8, entries1 through7,
and sum16. There are exactly20. There is no missing-indegree restriction and
no requirement that a strategy finish within two or any other fixed number
of messenger moves.

The independent Python receipt enumerates these degree vectors separately using
combinations with replacement, checks their exact correspondence to all20
producer profile records, and checks the complete flags and node/leaf totals.
No degree-one counting inequality is needed for this coverage argument.

## Partial source-camping bound

If distinct completed vertices c,s satisfy

    F(c) subset F(s) union {s},

then a pursuer initially at c can camp there and defeat every missing pair
from s. The only messenger position safe from its next reply is in F(c).
Among those positions a messenger at s can directly reach only s itself:
all other members of F(c) belong to F(s). A missing recipient cannot be
reached on that first move. Waiting allows no progress; a nonterminal departure
is captured. Thus the entire completed missing row at s consists of failures.
This remains true under every completion of the other rows.

## Partial predecessor-camping bound, including safe target arrival

Fix a completed pursuer row c and a target t. If each v in F(c) satisfies

    v=t, or row v is completed and t belongs to F(v),

then a pursuer camping at c defeats every completed missing pair (s,t) with
s!=c. Its safe nonterminal positions lie in F(c) minus {t}, and none of those
positions has a delivery arrow to t. An attempted departure to any other
nonterminal position is captured. An initial missing pair cannot reach t
immediately. Safe arrival at the actual recipient remains immediate success,
but the stated conditions prevent reaching it. This includes t in F(c);
that case is not silently omitted. It also includes t=c, when receipt would
have priority over a collision there.

The excluded initial cop position c=s is retained. A prefix is pruned only
after taking the literal union of all exhibited failed pairs and finding
at least four distinct pairs. Completed rows never change in a continuation.
The test never treats an unassigned row as empty: its contribution to the
safe-target condition is only the always-valid alternative v=t.

In the source implementation the guaranteed common target set is

    intersection over v in F(c) of
      (F(v) union {v}) if v is completed, and {v} otherwise.

This is exactly the preceding condition. Source losses and column losses are
stored as bit masks per source and united before their sizes are added.

## Complete symmetry coverage

Rows are assigned in chronological order0 through7. Prescribed degrees are
nondecreasing. Before assigning row r, future vertices having the same degree
and identical incoming patterns from completed rows may be permuted without
changing the completed prefix or degree vector. They form contiguous cells:
initially the degree cells are contiguous, and a preceding suffix selection
splits each cell into its zero part followed by its one part.

Permute each future cell so that the new row's selected neighbors are a suffix
of that cell. The source r is fixed during this permutation. Future outgoing
rows may change under relabeling, which is harmless because they are unassigned.
Every possible row having the prescribed degree, no loop, and these suffix
properties is generated. Removing r from the remaining vertices and splitting
by the new incoming bit preserves the cell induction. Hence every graph has
at least one generated representative. No uniqueness claim is required.

The adjacent-bit test in the source forbids exactly a selected neighbor followed
by an unselected neighbor inside an equal-degree/equal-incoming future cell.
The test starts at r+2, so it does not improperly exchange the current source
with a future vertex. Source and column loss pruning is invariant under the
permutations just described.

## Complete finite result

`src/endpoint40_positive.cpp` is standalone. The actual run

    c++ -O3 -std=c++17 src/endpoint40_positive.cpp -o src/endpoint40_positive.bin
    src/endpoint40_positive.bin 60 > research/endpoint40_positive.jsonl

completed all20 profiles in0.584467 seconds, visiting6,308,606 prefixes.
Every profile with a missing-degree-one vertex has zero static leaves.
The all-degree-two profile has158 leaves. Each has game value7, strictly below
13. The final record says all requested profiles completed, no target witness,
and no timeout. The Python receipt additionally verifies that the requested
profile range covers the complete list, rather than merely a successful slice.

The profile receipts are:

| Index | Missing degrees | Prefixes | Static leaves |
|---:|---|---:|---:|
| 0 | 1,1,1,1,1,1,3,7 | 63,978 | 0 |
| 1 | 1,1,1,1,1,1,4,6 | 63,941 | 0 |
| 2 | 1,1,1,1,1,1,5,5 | 23,119 | 0 |
| 3 | 1,1,1,1,1,2,2,7 | 102,376 | 0 |
| 4 | 1,1,1,1,1,2,3,6 | 182,042 | 0 |
| 5 | 1,1,1,1,1,2,4,5 | 180,152 | 0 |
| 6 | 1,1,1,1,1,3,3,5 | 111,984 | 0 |
| 7 | 1,1,1,1,1,3,4,4 | 86,684 | 0 |
| 8 | 1,1,1,1,2,2,2,6 | 160,089 | 0 |
| 9 | 1,1,1,1,2,2,3,5 | 334,220 | 0 |
| 10 | 1,1,1,1,2,2,4,4 | 157,420 | 0 |
| 11 | 1,1,1,1,2,3,3,4 | 264,713 | 0 |
| 12 | 1,1,1,1,3,3,3,3 | 105,056 | 0 |
| 13 | 1,1,1,2,2,2,2,5 | 300,753 | 0 |
| 14 | 1,1,1,2,2,2,3,4 | 698,795 | 0 |
| 15 | 1,1,1,2,2,3,3,3 | 369,727 | 0 |
| 16 | 1,1,2,2,2,2,2,4 | 527,548 | 0 |
| 17 | 1,1,2,2,2,2,3,3 | 668,122 | 0 |
| 18 | 1,2,2,2,2,2,2,3 | 1,179,348 | 0 |
| 19 | 2,2,2,2,2,2,2,2 | 728,539 | 158 |

The maximum7 among the158 surviving leaves is not an upper bound7 for the
whole endpoint family. The retained score12 graph correctly fails the
three-loss filter. The exhaustive decision excludes only I>=13.

## Every negative game is independently checked from its literal arrows

The C++ producer scores a complete graph by the explicit alternating AND/OR
attractor. Its delivery neighborhoods are complements of the missing rows and
include waiting once. Recipient states on either turn start winning, including
collision there. Every other collision stays losing. Messenger predecessors
enter after one winning option; pursuer states enter after every legal response
wins. The least finite attractor makes infinite avoidance losing.

`src/endpoint40_certify.py` reconstructs all158 graphs from the saved missing
masks and runs both established Python solvers. Both agree with every C++ score.
It saves all158 complete alternating winning ranks and losing regions in
`research/endpoint40_negative_certificates.json`; no orbit grouping is used.
The separate literal checker `src/small_case_certificate_review.py` imports no
game solver and checks all161,792 negative alternating-state obligations.
Winning states have the required decreasing ranks; every losing messenger
move remains losing, and a losing pursuer state has an avoiding reply.
This is a certificate of actual-game failure, not failure of a limited strategy.

The same pass reconstructs the partial camping witnesses by set operations on
all nine chronological prefixes of every leaf. It checks1,480 explicit initial
cop witnesses against the corresponding losing ranks. These checks help attack
the direction and initial-source exception of the pruning rules. They are
not an independent traversal of every pruned node; the ordinary argument above
is what proves those rules for arbitrary prefixes and completions.

## Literal lower graph

The retained attaining missing rows, in order0 through7, are

    {3,6}; {4,5}; {0,1}; {5,7}; {1,7}; {2,3}; {0,4}; {2,6}.

Take every other nonloop arrow as a delivery arrow. Its12 winning missing pairs
are all16 listed missing pairs except

    (2,0), (5,2), (6,0), (7,2).

The literal record `research/endpoint40_lower12_certificate.json` is copied from
the already incorporated fixed certificate. Both Python solvers were rerun on
its literal arrows and the separate rank checker replays its1,024 states.
This supplies a direct attaining construction; constructing it does not require
rerunning the enumeration or any graph search.

Together the complete exclusion of I>=13 and this literal I=12 graph prove the
stated exact value, subject to completion of the requested independent source
and coverage review. The durable producer/literal receipt is
`research/endpoint40_literal_receipt.json`; it pins every input/source by SHA-256.
No Lean formalization or canonical incorporation is claimed by this note.

# Main-interval Lean construction campaign — 23 October 2026

This lane extends the proved construction chain after the 148-module release.
It does not alter that release or assert full classification in Lean.

## Selected route

Formalize the separated pair-code corollary of `paper/core-code-composition.md`:
for `k≥6` and `2k≤n≤k(k−3)`, every budget from
`(4k−2)n−2k(2k+1)` through `n(n−3)` attains every missing pair, within two
moves, with arbitrary subsets of the optional outside-to-outside arrows.
Use the existing two-type core with the documented line reindexing, followed
by literal code enumeration, vertex relabeling and optional-prefix counting.
Parameter overlap and the saved finite bridge follow only after this theorem.

## Geometry checkpoint

`PairCodeGeometry.lean` defines a code as two vertices in one part with index
differences avoiding `0, ±1, ±2`. Its literal row/column exclusions and the
mixed source/recipient obstruction are proved from `DenseTwoType`.
The initial geometry checkpoint compiled with Lean 4.33.1, two workers,
using only standard foundational axioms. It is not yet an attaining-family
theorem: routing, capacity and exact budgets remain to be connected.

## Generalized pair-code interval proved

Four new modules compile independently with Lean 4.33.1 (`-j 2`):
`PairCodeGeometry`, `PairCodeRouting`, `PairCodeCapacity`, and
`PairCodeConstruction`. All printed axiom dependencies are confined to
`propext`, `Classical.choice`, and `Quot.sound`.

`PairCodeConstruction.maximum` proves the complete requested domain
`k≥6`, `2k≤n≤k(k−3)`, and
`(4k−2)n−2k(2k+1)≤m≤n(n−3)`, with value `n(n−1)−m`.
There are no supplied game, graph-cardinality, code-existence, or finite-search
premises. `attainer_exact` additionally proves looplessness, exact arrow
count, exact score, and universal two-move delivery for the literal prefix
constructor. `PairCodeRouting.two_move` establishes the stronger arbitrary
optional-subset statement before prefix selection.

The code order intentionally differs from the paper's point-first list:
entry `x<k(k−5)` uses `i=x mod k`, `j=i+(3+floor(x/k)) mod k`, and chooses
point vertices if `i<j`, line vertices otherwise. The distance lies between
3 and `k−3`; orientation distinguishes the two copies of each unordered
pair. Lean proves membership-extensional injectivity, so every first `q`
entries are valid distinct codes. This direct enumeration avoids division
by two and an unnecessary separate binomial-cardinality development.

The graph is transported to `Fin (2k+q)` with explicit inverse maps. Full
missing count is `2(2k+q)`, and the lower envelope has missing count
`4k+q(q+1)`. These are derived from actual row counts. Ordinary polynomial
identities give the stated base and upper arrow budgets. The graph proof
covers all source/recipient/pursuer type cases with the existing actual-game
semantics; no simulation or local-certificate assumptions enter this family.

This checkpoint is frozen for independent review. Next work is confined to
new overlap modules, joining these intervals to the already proved circle
constructors and the retained finite bridge. The full classification remains
unfinished in Lean.

## Full overlap from order 79

`PairCodeOverlap.maximum` now proves `IsMaximum n m (n(n−1)−m)` for
every `n≥79` and `3n≤m≤n(n−3)`. The graph constructors are exactly the
proved protected circle, guarded five-offset circle, and separated pair
codes. There are no residual arithmetic, graph, game, or finite-certificate
premises in this theorem.

For `n≥896`, choosing `k=floor(n/28)` replaces the more elaborate least-
parameter argument: `k≥32`, `n≤28k+27≤32(k−3)≤k(k−3)`, and the pair-code
base is at most the protected-circle endpoint. For `79≤n≤895`, a single
kernel-checked arithmetic table verifies the literal least admissible `k`
and the first coprime member of `[7,11,15,19]`, including every guarded-circle
domain and overlap inequality. The table contains no graph or strategy data;
`finite_overlap` has no axiom dependencies. The resulting `maximum` depends
only on `propext`, `Classical.choice`, and `Quot.sound`.

Root independently reviewed the four preceding pair-code modules without
finding a gap. The overlap module compiles with Lean 4.33.1 and two workers,
and is frozen for independent review. Lower main budgets and orders below 79
remain separate assembly obligations; this result does not claim that every
graph in the combined interval has the pair-code family's two-move bound.

## Order-twelve finite stage milestone (held outside the frozen replay)

The complete unit under `tmp/lean-main-stage/` contains `MainStageRows`,
`MainTwelveStage00` through `MainTwelveStage29`, and `MainTwelve`. All 32
modules compile with the pinned Lean 4.33.1 and one worker. The 30 literal
stages are translated from the existing frozen rank/action bundle; their
closed intervals cover 24 through 107 arrows. The pair-code core supplies
108. Consequently `MainTwelve.maximum` proves
`24≤m≤108 → IsMaximum 12 m (132−m)`.

The generic checker validates every nonterminal, noncollision initial
position, every chosen lower-graph move, and every upper-graph cop reply.
Receipt is terminal before collision; every other move requires safety and
strict rank descent after the cop turn. Each concrete module also checks
looplessness, lower/upper inclusion, complete reply lists including waits,
and actual arrow counts. The existing prefix theorem supplies each exact
budget and arbitrary optional subsets within its stage.

The exporter verifies the source JSON, ZIP and each member's SHA256. It
performs no graph search. Negative rank/action entries are encoded as zero;
their correctness is not assumed, because the resulting total data undergo
the universal kernel check. All printed axioms are standard foundational
ones. Source self-audit found no hidden graph/count premise; independent
peer reviews passed. One peer reviewed the generic semantics, representative
stage, and complete assembly. Another independently parsed all actual Lean
literal tables and matched all 51,840 rows to the frozen archive, checking
43,560 safe nonterminal rows and 130,710 cop replies. The prepared relocatable
exporter regenerates all 30 concrete modules and member provenance exactly.

These 32 files are intentionally not yet installed in `lean/`: the root's
942-module replay rejects inventory changes. The complete prepared unit,
relocatable exporter, per-member provenance, and replay logs remain in the
scratch directory until the frozen pass ends. This milestone must not be
advertised as part of that earlier replay's source inventory.

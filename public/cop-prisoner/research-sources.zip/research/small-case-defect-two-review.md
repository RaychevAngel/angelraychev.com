# Independent review of the three-loss endpoint bounds

13 September 2026. The ordinary argument and both existing complete finite
checks support

    M(7,28) <= 11,     M(8,40) <= 13.

The second is an upper bound, not a claim that 13 is attained. This review
adds no new construction search, new graph family, or Lean theorem. Both
existing normalized checks were freshly replayed without changing their
saved files; the accompanying JSON pins the reviewed proof, sources and logs.

## Degree-one branches

There are `2n` missing nonloop arrows. Let `q(v)` be missing outdegree,
`Delta=2n-I`, and let `ell` count rows of missing degree one. The retained
endpoint argument already proves `Delta>=2`; it remains to exclude equality.
A missing degree-zero vertex makes every indirect pair fail by immediate
capture, so all missing degrees are positive in a counterexample.

The total degree surplus over two equals `ell`. The existing degree-one
loss bound gives `Delta>=ceil(ell/2)+1`, so equality requires `ell=0,1,2`.
If `ell=2`, the stronger image count forces a closed missing two-cycle.
Those two rows consume all permitted loss. Every other missing row avoids
the cycle, or it would be wholly lost against a degree-one pursuer. Thus the
remaining `n-2` vertices form an ordinary universal missing core, with
`2n-2` missing pairs. A confined core pursuer captures excursions into the
cycle. At `n=7,8`, universality contradicts the retained vertex bounds at
orders five and six.

If `ell=1`, write the unique functional row as `c -> x`. There is exactly
one degree-three missing row and all other nonfunctional rows have degree
two. The wholly lost row at `x` must have degree two. Put `Y=F(x)`. Both
missing columns into this two-element set are blocked by a pursuer at `c`;
there is no initial-source exception among those pairs because `F(c)={x}`
and `x` is not in `Y`. All other rows avoid `Y`, and all other nonfunctional
rows avoid `x`, or an additional whole row would fail.

If `c` belongs to `Y`, the remaining four- or five-vertex set is an
ordinary universal missing core of minimum degree two, contradicting the
retained small-order bounds. If `c` does not belong to `Y`, deleting
`{c,x} union Y` leaves a corrected safe-root interface on three or four
core vertices, with root `c`. A nonterminal root arrival must still survive
capture by the current cop; it is not unconditional success. All other
removed vertices are immediately capturable by a confined core cop. The
core has all missing degrees two except possibly one degree three. Both
profiles at both orders have complete, independently reviewed exclusions.
The required data remain pinned by
`research/small-case-rooted-independent-review.json`.

## Complete two-out normal forms

For `ell=0`, every missing row has size two. Suppose first that there is a
source-camping witness `F(c) subset F(s) union {s}`, with `c!=s`. Equal rows
kill both rows and give four losses. Otherwise the two rows have the form
`F(c)={s,t}`, `F(s)={t,u}`. If `u=c`, the row at `c` is also killed, again
giving four losses. Hence all four vertices are distinct and may be
normalized as

    F(0)={1,2}, F(1)={2,3}.

The two pairs in row1 exhaust the loss allowance. The cop at0 also blocks
every missing pair to2 except a pair from source0. Thus all rows other
than0 and1 must avoid2. Every additional source or recipient obstruction
must have its failed pairs contained in row1. This is the fourth complete
normal form in the finite checks.

If there is no source-camping witness, the retained complete endpoint
exclusion forces a predecessor-camping witness. Its recipient `t` cannot
belong to `F(c)`: the other missing neighbor would then yield a source
camp. Normalize the recipient as0 and the cop's missing neighbors as1,2.
Then `F(1)={0,a}`, `F(2)={0,b}`. The further neighbors `a,b` are distinct
and avoid1,2; equality or an arrow between1 and2 would create a source
camp. The whole missing column0 fails, and its indegree is exactly two,
since more predecessors would exceed the allowed loss.

If the cop is0, normalize `a=3,b=4`. Otherwise normalize the cop as3.
At most one of `a,b` equals3; exchanging1 and2 permits that one to be
`a`, giving `a=3,b=4`. If neither equals3, use `a=4,b=5`. These are exactly
the other three listed forms. No missing indegree or later-row symmetry
restriction is silently imposed.

## The loss union and the recipient exception

The independent C++ checker reconstructs a literal set of failed missing
pairs for every partial assignment and rejects only when its union has
size greater than two. An overlapping source row and recipient column
must not be added with multiplicity.

For the recipient rule, the necessary intermediate blockers are
`F(c) minus {t}`, not necessarily all of `F(c)`. If every vertex in that
set has a missing arrow to `t`, the cop at `c` blocks every indirect pair
into `t` except the pair whose source is `c`. The target itself is removed
because arriving there is immediate receipt, and an indirect initial pair
cannot reach it on its first move. No other safe intermediate can deliver
to it. The implementation checks only completed blocker rows and retains
the initial-source exception explicitly. This stronger rule is sound with
receipt preceding collision.

The Python checker uses fixed chronological order and equivalent
restrictions in the three column forms and the one-row form. In particular,
another failed column in a no-source-camp form supplies at least one new
failed pair; it cannot be absorbed by the designated column0. The C++
checker uses minimum remaining domain order. Both enumerate every permitted
loopless two-element row. Partial assignments and known-row flags are
restored when changing candidates and when backtracking.

## Fresh exact replays and boundary

The Python functions `enumerate_order` and `one_killed_row` were invoked
directly rather than running their file-writing entrypoint. Their complete
prefix counts match the saved output exactly:

- Order7: 61, 26, 86, 686; every form has zero leaves.
- Order8: 2,146, 712, 1,417, 33,352; every form has zero leaves.

The independent C++ source was freshly compiled and its eight output
records were compared literally with its frozen log:

- Order7: 6, 2, 7, 46; every form has zero leaves.
- Order8: 85, 37, 80, 1,089; every form has zero leaves.

Both implementations have therefore independently completed the normalized
degree-two branch. No game solver is needed at a surviving leaf, since
there are none. The two degree-one branches are ordinary reductions to
previously checked small cores. Together these exclude total loss two and
prove the stated upper bounds. The sources and all dependencies used in
this review are pinned in `small-case-defect-two-review.json`.

# The finite bridge: exact sparse endpoints at every order n>=12

## Result

For every integer n>=12,

    M_V(n)=M_E(2n)=M(n,2n)=n(n-3).

For n>=85 this follows from the uniform six-type construction and the
independently verified minimum-spacing-three local certificates in
Theorem40. The remaining73 orders n=12,...,84 now have explicit universal
two-in/two-out graph witnesses. Two independent exact game algorithms
agree for every witness, and complete alternating-state rank certificates
have been checked for every recipient, source, pursuer position and turn.

Every witness has2n arcs, so universal delivery counts all n(n-1)-2n
missing pairs. The previously proved vertex and even-budget upper bounds
give equality. No assertion about the still-open orders7,...,11 follows.

## Explicit witnesses and strategy certificates

`research/sparse-finite-bridge-witnesses.json` contains every graph's arcs
and its construction provenance. The uniform interface

    python3 src/sparse_finite_bridge_construct.py N --out graph.json

returns an explicit attaining graph for any integer N>=12. It selects
the finite witness when N<=84 and uses the stated six-type formula when
N>=85. All finite witnesses also satisfy the time bound
9*ceil(N/6)+18 already proved for the uniform construction.

The complete proof artifact is
`research/sparse-finite-bridge-certificates.jsonl.gz` (28,686,719 bytes).
Each decompressed line contains one graph and the complete legal-move
rank and messenger-action arrays for all its recipient games. The
SHA-256 is

    2dd832310d92f2f7e2fa14ce155085e5dc3dfa2a411f96f7a0182b8f06b8c2d9.

The exact receipt, source hashes and per-order bounds are in
`research/sparse-finite-bridge-verification.json`. Verification completed
in111.6 seconds on one core. No proof obligation was accepted solely
from a search score or from finite-size extrapolation.

## Independent checks

`src/sparse_finite_bridge_verify.py` invokes the synchronous bit-mask
attractor and the independently implemented explicit alternating-state
attractor from `src/game_solver.py`, requiring identical winning regions.
The explicit certificate checker verifies terminal receipt priority,
initial and intermediate collision exclusion, every chosen messenger
move, every possible pursuer response, strict rank descent, and closure
of the losing region. Both players' waits are included.

The generator additionally checks that there are exactly2n distinct
nonloop arcs and that every incoming and outgoing degree is two. The
saved certificate can be replayed directly, without regenerating either
attractor:

    python3 src/sparse_finite_bridge_verify.py --check

The full generation run has already checked every certificate before
serialization and recorded the complete file hash. The replay command
is provided as an independent reuse path, not as a claim of a second
redundant full rerun during this checkpoint.

## How the finite bridge was found

Orders12,...,24 reuse previously independently verified witnesses.
The five-type construction and explicit six-type graphs with selected
type-four vertices removed directly supplied52 of the60 orders25,...,84.
The exceptional orders were

    26,27,31,32,37,38,43,49.

A deterministic two-permutation search found universal witnesses at all
eight in a total of approximately0.79 CPU seconds; no run exhausted its
four-second cap. These searches supplied candidate graphs only. The
subsequent exact dual-solver and certificate verification established
the claims. Their sources and raw discovery records are

- `src/sparse_finite_bridge_family.cpp`
- `research/sparse-finite-bridge-family-screen.json`
- `src/sparse_finite_bridge_search.cpp`
- `research/sparse-finite-bridge-search.json`

The result is a computer-assisted ordinary theorem. The new73-graph
bridge is not presently formalized in Lean, although the earlier
12-vertex example is covered by the existing Lean artifact.

# Audit of the current result catalogue

Read-only mathematical extraction from the published 74-page checkpoint after
commit 7182066354507c140194755782f4706902e6bbee. The user's requested presentation
is a numbered list, without tables, of exact nonredundant statements. This audit
does not change theorem domains or claim new proof runs.

## Nonredundancy rule

Compare parameter domains together with the conclusion: exact value,
construction availability, delivery-time guarantee, and independently useful
structural characterization. A new proof alone does not justify repeating a
strictly weaker statement. A faster strategy or an arbitrary-graph criterion
can survive even when its extremal-value domain is already covered.

## Surviving extremal and construction sources

- Theorem44: all n>=1800, every 2n<=m<=n(n-3), exact missing-pair bound and
  deterministic construction. Corollary47 is its useful assembly with the other
  regions, not another construction result.
- Theorem40: even sparse values on every host n>=k>=12, with support k,
  M(n,2k)=k(k-3); also M_V(k)=k(k-3). Delivery <=9ceil(k/6)+18.
- Theorem45 and Corollary45.1: every odd budget 2k+1>=25, host n>=k+1,
  value k(k-3)+2. The uniform move bound 34ceil((k+1)/6)+27 is stated only
  for support k+1>=145. Stored witnesses supply supports13..144.
- Earlier unnumbered odd family: support6q, budget12q-1, q>=15,
  value(6q-2)(6q-3), and the sharper bound14q+12 moves.
- Theorem52: n>=1075, all2n..3n, time9ceil(n/6)+26.
- Theorems36--37: multiples5 at n>=80, all2n..3n, time8n/5+16;
  additionally n50,55,60,65,70,75 and2n..11n/5, time8n/5+18.
- Theorem38: n>=25, all3n..n(ceil(n/7)-1). Three core moves plus
  individually optional arcs. No two-move claim.
- Theorem11 adds the 3n endpoint at n15,16,17,18,19,20,22,23,24.
- Theorem35: prime p>=5, orderp^2, budgets4p^2..p^2(p-1), time5p-3.
  This survives because of the square-root time bound (and p5 adds a value
  outside Theorem38). No extension-field or two-move claim.
- Proposition51 with Theorem43: exact prescribed budget and polynomial
  deterministic construction when (n-3)p^2(1-p)>4log(n)+log(8/3), p=m/[n(n-1)].
  Every pair delivers within two moves. The fixed-p random-graph high-probability
  statement in the final section is separately stronger than bare existence.
- Theorem48: n>=19, every missing budget3n..n max(3,ceil((n-1)/13)), two moves.
- Theorem50: n>=166, every missing budget2n..3n, two moves.
- Theorem19: missing budget2n at every n>=52, and the explicit base graph
  also supplies n26, all within two moves. Theorem15 adds n20,25,30,35,40,45,50
  at that budget with three moves.
- Theorem27: universal dense-staircase upper bound at every admissible n>=2.
  Corollary33 attains every r=1..n at n>=75, within two moves.
- Smaller staircase domains: r1 at n68..74 (Theorem32); n54..74 with
  2<=r<=n-52 (Theorem29); r=n-26 at n28..43 using the explicit26-vertex block;
  and n<75, r>=2, k=n-r>=1 with k<=binom(floor((r-2)/2),2) (Proposition31).
  The26-block cases from n44 onward are already covered by Proposition31
  or Corollary33. The endpoint r=n is known for all n>=2 by Theorem13.
- Theorem13: all n>=2, exact m=n(n-2) value floor((n-2)/2), zero above.
  Its functional-complement iff criterion is independently useful.
- Complete joint enumeration at n<=6; exact arc budgets0..11 over all hosts,
  with every arc maximum attained on at most7 vertices.
- Theorem46: M_V7=21, M_V8=32; exact joint points(9,24)->48,
  (10,28)->62,(11,26)->84; vertex intervals9:48..53,10:62..69,11:84..87.
- Theorem53: M_E23=83, M(n,23)=83 for all n>=12. Separate eleven-core
  lemma gives M(11,22),M(11,23)<=81. Every budget12..23 fails to attain the
  eventual sparse polynomial (even equality structure plus finite exclusions,
  and the small-odd-exceptions proposition).

## Independently useful structural and other statements

- Equality structures in Theorems8--9, including the necessary connectivity
  conditions in the odd-endpoint supplement. These concern equality in the
  universal bounds, not a full classification of all small-budget maximizers.
- Proposition30: commuting two-permutation construction has I<=n.
- Certified19-vertex odd extremizer whose completion is not universal.
- Exact two-move criterion, source/recipient camping obstructions, and the
  safe-branching principle (Lemmas1--3,10).
- General missing-graph girth>=6 sufficient condition (Lemma18) and
  complementary-block two-move composition (Lemma28).
- Zero minimum at every admissible resource pair (Proposition4).
- Exact correction to the original layered family (Theorem16), with its
  domain x>0 not a power of2, and standalone balanced-complement classification
  (Lemma17). Preserve original author/mentor credit.
- Partial Lean semantic/certificate theorem and explicit12-vertex example.
  General extremal classification is not formalized. The arbitrary-graph
  attractor solver is standard machinery, not a new research theorem.

## Omitted historical statements

- Theorem34 is subsumed by38.
- Theorem20 is subsumed, including two-move delivery, by48+50: its nonempty
  domain implies n>=B_D>=426, and L_D<=Dn/2<=n ceil((n-1)/13).
- Theorem25 is weaker than51. Corollary26 is a coarse asymptotic consequence
  of the sharper exact-budget criterion and the dense intervals.
- Theorem21's value and stated time guarantees are covered by40,37 and the
  stored smaller witnesses. In particular old21's n85 time152 is also in37;
  finite witnesses n50/n55 deliver within25/27, better than old bounds96/104.
- Corollary22, Corollaries39/42, Theorem41's2419 threshold, and all intermediate
  23-arc upper bounds are superseded.
- Preserve Theorem14's conceptual boundary within the dense statements,
  rather than list the same necessary inequality twice.

## New deductions not promoted by this catalogue

Reading the numerical branches of Theorem6 suggests tighter upper bounds
M_E14<=26, M_E16<=37, M_E22<=82. These have not received an independent
proof audit in this extraction task. They are candidates for a later verified
update, not changes to the published theorem statements. No new enumeration
was run.

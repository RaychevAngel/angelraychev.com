# Proposed global nineteen-arrow upper53

13 September 2026. This ordinary extension depends on the independently
reviewed finite implication M(10,19)<=53 when that review is accepted.
It does not require an exact value at nineteen arrows or the new20-arrow
theorem, and therefore can be used without a circular dependency.

First, M_E is nondecreasing in its arrow budget. Add a fresh sink z and
one arrow v->z to any nonempty graph. The score is exactly unchanged:
old losing pairs stay losing against a cop confined to the old graph;
old winning strategies remain valid until a cop enters z, at which point
the cop is trapped and any old route to the recipient succeeds. The same
route argument works when the cop starts at z. The new sink has outdegree0
and indegree1, so it contributes no indirect row or column. Repeating this
operation pads any smaller arrow budget to a desired larger budget.

Only active sources A={s:d+(s)>=2} and active recipients B={t:d-(t)>=2}
can participate in an indirect pair; put q=|A| and r=|B|. For a source v of
indegree0, deletion does not affect any old messenger route, and a cop may
be restricted to the remaining graph for an upper comparison. Thus

    I(G) <= I(G-v) + r - |N+(v) intersection B|.

There is no diagonal correction because v is outside B. For a sink v of
outdegree0, old messenger excursions to v cannot reach an old recipient;
restricting the cop gives separately

    I(G) <= I(G-v) + q - |N-(v) intersection A|.

There is no diagonal correction because v is outside A. These inequalities
are in the original directions of the game, not a reversal argument.

Consider a nineteen-arrow graph. Delete isolates. If there is a source or
sink whose other degree is1, its counted row/column is zero and deleting it
leaves18 arrows, giving I<=44. If its other degree is at least2, deletion
leaves at most17 arrows. The retained strict odd-budget theorem at k=8
gives M_E(17)<=8(8-3)+1=41 (paper/odd-endpoint-resume.md, Proposition for
6<=k<=11). By harmless padding the remaining graph also has score<=41.
Since q,r<=floor(19/2)=9, the deleted row/column contributes at most9,
giving I<=50. These bounds do not depend on the original host order.

Every remaining graph has all degrees positive. On n>=11 vertices, the
degree sum gives q,r<=19-n<=8. The basic eligible rectangle obeys

    I <= qr - max(0,2q+2r-19) <= 51  (0<=q,r<=8).

This last integer inequality is immediate at q=r=8; increasing a count
when the other is at least2 cannot decrease the expression, and a count
at most1 gives at most8. At n=10 use the proposed complete upper53 in
sparse_finish_one_defect_proof.md. At n<=9, the missing-pair bound is
n(n-1)-19<=53.

Therefore M_E(19)<=53. Independently, once M_E(20)=53 is accepted, the
same conclusion also follows at once from harmless-sink monotonicity.
No matching nineteen-arrow witness or equality is claimed here.

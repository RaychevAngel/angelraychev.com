# The four remaining first dense steps

Private research proof for independent review. Proposed exact values:

    M(7,29)=8, M(8,41)=11, M(9,55)=14, M(10,71)=16.

The four literal witnesses are in `src/small_dense_first_step.py`, with
two-solver full alternating-state certificates in
`research/small-dense-first-step-certificates.json`. The seven-vertex
upper bound belongs to the separately completed finite table.

Write h=2n-1, Delta=h-I, and use S,ell,e from the degree-one proof.
Positive I forces all missing outdegrees positive, and ell=1+e.
The staircase gives Delta>=2 and Delta>=ceil(ell/2)+1.

## Equality Delta=2 at orders eight through ten

Here ell is one or two. If ell=2, the stronger degree-one image count
forces a closed missing two-cycle. Its two losses exhaust Delta, so all
outside rows avoid the cycle and must form an ordinary universal core.
The core has k=n-2 vertices and 2k+1 missing arrows. At n=8, this is
excluded by M_V(6)=7. At n=9, it is excluded by the independently
completed value M(7,27)=10. At n=10, it is the (8,39) universal-core
question addressed below.

If ell=1, every other missing degree is two. Write the unique row as
c->x and put Y=F(x), a two-element set. The two missing pairs from x
fail and exhaust Delta. Every missing column into Y fails under the
pursuer at c. All remaining rows therefore avoid Y; all nonfunctional
rows other than x also avoid x, since otherwise the pursuer at c kills
their whole row. If c belongs to Y, removing {c,x} and the other member
of Y leaves an ordinary universal two-out core on n-3 vertices, of
orders5,6,7. The retained finite values and seven-core exclusion rule
this out. Otherwise removing {c,x} union Y leaves a corrected safe-root
two-out interface on n-4 vertices, root c, of orders4,5,6. All those
interfaces were completely excluded in the reviewed rooted checks.

A universal (8,39) core must have missing degrees (3,2,2,2,2,2,2,2):
a zero degree prevents any indirect guarantee, and a degree-one row
kills the nonempty row at its image. Label the unique degree-three
source0 and its neighbors1,2,3. Every remaining loopless degree-two row
is enumerated. `src/small_dense_first_step_profiles.cpp` mode `core`
completed all3,322 MRV prefixes with zero static leaves. No missing
indegree condition or further neighborhood normalization is imposed.
The complete log is `research/small-dense-first-step-core-eight.jsonl`.
Thus Delta>=3 at all three orders, giving upper bounds12,14,16.
The literal nine- and ten-vertex witnesses attain14 and16.

## Excluding Delta=3 at order eight

Now ell is one,two,three orfour.

For ell=4, the degree-one image count forces the four-vertex functional
path rho->t0->a<->b. Its three killed rows exhaust Delta. The outside
core is a corrected rooted four-core with total excess3. Its complete
degree profiles are (5,2,2,2), (4,3,2,2), (3,3,3,2), up to relabeling.
All loopless rows are enumerated with the already reviewed source and
predecessor camping predicates. They have1,6,45 prefixes respectively,
all with zero static leaves. Degree5 is included as an empty domain,
since a rooted four-core row has only four possible distinct neighbors.

For ell=3, the reviewed degree-one image argument forces a closed
functional three-vertex graph (three-cycle or two-cycle plus free root).
It contributes three losses. The outside rooted five-core has total
excess2, hence profiles (4,2,2,2,2) or (3,3,2,2,2). Both profiles were
completely excluded in the independent second-step review.

For ell=2, precisely one outside missing degree is three. If the two
functional vertices form a closed two-cycle, no outside row may point
into it: the two existing losses plus its entire outside row would
exceed three. Exact missing-block addition reduces to an ordinary
six-vertex graph, whose value is at most M_V(6)=7<12.

Otherwise the only shape compatible with three losses is c->d->x,
where q(c)=q(d)=1 and q(x)=2. Two distinct outside images kill at least
four pairs, as does a common outside image; a degree-three x also gives
four. The rows d and x exhaust the three losses. The earlier second-step
argument applies to Y=F(x): Y excludes d, every other good row avoids
{d,x} and Y, except the good pair c->d. If c belongs to Y, the remaining
ordinary core has four vertices and every row has degree at least two,
contradicting the known four-vertex maximum. Otherwise the remaining
core has three vertices and root c; each row has degree two, with at
most one row of degree three. Both rooted profiles were excluded.

Finally let ell=1. All other missing degrees are exactly two. Normalize
F(0)={1}. Up to relabeling, F(1) is either {0,2} or {2,3}. Enumerate
every other loopless degree-two row. The C++ check's `first 8` mode
visits578 prefixes with zero leaves under the condition that the union
of its explicitly forced lost pairs has size at most three. The log is
`research/small-dense-first-step-one-leaf-eight.jsonl`.

The exact union is essential. A source-camping witness
F(c) subset F(s) union {s}, with c!=s, marks all pairs in source row s.
For a completed cop row F(c), if all its neighbors' rows share target t,
camping at c marks every missing pair into t except a pair whose source
is c, because that initial cop position is excluded. The implementation
stores a separate bitmask of marked targets per source and counts their
union, never their sum with multiplicity. Both predicates are necessary
conditions for a small-defect graph; every pruned prefix supplies too
many distinct forced losses in all its completions.

All four cases are excluded. Thus Delta>=4, so I<=11 at (8,41), and the
literal witness attains it.

The added rooted profile data are
`research/small-dense-first-step-rooted-profiles.json`. This file also
contains a larger positive exploration: six-core profile(3,3,2,2,2,2)
has96 universal leaves among888 static leaves. The first gives the new
nine-vertex witness through the three-vertex functional attachment.
Its exact core rows are

    {1,2,3}, {2,4,5}, {0,6}, {1,6}, {0,5}, {4,6},

with root6. `research/small-dense-first-step-rooted-certificates.json`
contains its interface and full attached actual-game certificate. The
unneeded n9 one-leaf search is retained as exploratory evidence only;
it is not a dependency of the stated upper bounds.

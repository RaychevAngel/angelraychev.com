# Independent audit of the two uniform dense envelopes

Date: 2026-09-13. Reviewer: the independent `proposal_check` research lane.
Reviewed source: `research/dense-phase2-uniform-proof.md`, compared with
the actual previous statement in `paper/dense-protected-envelope.md`.

**Conclusion:** both parameterized constructions and their stated exact
caps pass ordinary proof review. The new envelope at every n>=30 strictly
extends the old Theorem 48 interval, preserving its two-move delivery,
arbitrary optional-subset guarantee, and explicit polynomial construction.
This is not an assertion that every old theorem below order 30 has been
replaced. The proof remains ordinary mathematics, not Lean verification.

## Review method and semantic boundary

I independently derived the possible blocked compulsory rows from the six
displayed danger sets; I did not infer the infinite result from the primary
scripts or their graph samples. The only numerical calculation in this
review was a twenty-entry evaluation of the two explicit cap polynomials,
used to confirm the additional comparison H4>H5 for all n>=52.

The common criterion has the correct direction: compulsory missing
outneighbors of the initial cop remain missing in every optional subset,
while the messenger's two arrows exist outside the *full* danger set.
For a missing pair (s,t), the endpoints belong to that danger set because
s is a missing predecessor of t and t is a missing successor of s. Thus the
witness differs from both endpoints. It differs from the cop because every
compulsory missing arc is loopless. This also covers an initial cop at t,
and prevents capture by waiting. Arrival at t on the second messenger move
uses the established receipt-before-response convention.

## Residue-five family

There are 4k compulsory core arrows and 2s compulsory added arrows, exactly
2n. The optional core count is k((q-2)+(q-1)); the optional added count is
s(s-1). Hence the full missing cap is exactly

    H5(n)=10q^2+5q+s^2+s,  n=10q+s, q>=3.

For point cops, the forbidden row is an adjacent line pair; for line cops
it is a point pair of difference two. Within either multiple-of-five class
neither pair can occur. For the only nontrivial optional point-source case,
the set {0,-1,d-4,d-6} acquires an additional adjacent pair only for
d in {2,4,5,7}. Values 3 and 6 merely duplicate the source's existing row.
The only multiple of five in the exceptional set is 5, excluded from D.
For the optional line-source case, e=5 only reproduces the source pair
{4,6}; it does not create a different blocked cop. The four compulsory
cases give only their respective source rows where a row can be contained.
The modular statements are valid for k divisible by five and k>=15.

An added cop's row has line-minus-point difference three. Independently
checking the six old danger sets leaves just the two potential residue
coincidences described in the source: (P_(i+1),L_(i-1)) and
(P_(i+4),L_(i+2)). Their actual difference is -2, so equality with three
would require k dividing five, which is impossible here.

For a new source x_a delivering to P_a, its old line danger has pairwise
differences 7,9,2, none equal to +/-1 modulo k>=15. Its point danger is in
one residue class. A different added cop would need b-a simultaneously a
multiple of five and one of {0,-7,-9}, hence b=a modulo k. For delivery to
L_(a+3), the old point danger has differences 1,3,4, none equal to +/-2;
the possible new-cop displacement is in {0,3,4} and is a multiple of five,
again forcing b=a. Actual added indices are distinct because 0<=a,b<=8<k.

For new-to-new missing arrows the old danger is exactly the source's
mixed point/line row. No old row or distinct added row is contained.
Additional danger vertices caused by incoming arrows from new vertices
are harmless: every compulsory candidate row lies entirely in the core.

## Parity family

At k=2q>=22, all eight excluded nonzero even residues in D are distinct,
and all seven in E are distinct. Hence |D|=q-9, |E|=q-8. The counts give
2n compulsory missing arrows and exactly

    H4(n)=4q^2-26q+s^2+s,  n=4q+s, q>=11

in the full envelope.

I derived the core exceptions afresh by pairing the even and odd members
of each danger set. In the six displayed orders they are respectively:

    D:4,-2; E:2.
    D:2,-4; E:-2.
    d:2,8.
    D:-6; E:-2,-4.
    D:6; E:2,4.
    e:0,10.

These exactly agree with the source, and every listed value is excluded.
Collisions at d=4,6 or e=4,6 merely duplicate an existing source row rather
than producing a second cop. The row types are unique at k>=22; reversing
an adjacent or difference-three pair cannot produce the same row from a
different initial vertex.

For the added point-pair row of difference five, my independently derived
exceptions are D:{6,-4}, D:{4,-6}, D:{2,-8}, D:{-2,8} in the four
compulsory cases, and E:{-2,8,2,12} in the optional line case. The optional
point case is all one parity and has no such pair. Every exception is
excluded in the definition.

A new source targeting its first endpoint can block a difference-three
old row only at D offsets -2,-8; targeting its second endpoint requires
2,8. All are excluded. Its old line danger has difference three, not one.
For other new cops, a potential blocked row would require b=a or b=a+/-5
modulo k. The first is the excluded source, while the latter are impossible
for 0<=a,b<=2 and k>=22. The new-to-new and extra-danger-vertex arguments
then work exactly as in the residue-five construction.

## Strict comparison with the previous theorem

The old cap is n max(3,ceil((n-1)/13)), with lower endpoint 3n.
Both new constructions start at 2n. For H5,

    H5-3n = 5q(2q-5)+(s-1)^2-1 >=14,
    13H5-n(n+11)
      = 30q^2-45q-20qs+12s^2+2s
      >= [260(q-1)^2-261]/12 >0.

The completion of the square is correct. Since
ceil((n-1)/13)<=(n+11)/13, this proves strict containment of the old
numerical interval at every n>=30.

For H4 the corresponding differences are

    H4-3n = 4q^2-38q+(s-1)^2-1 >=65,
    13H4-n(n+11)=36q^2-382q-8qs+12s^2+2s.

At q=11 the latter takes 154,80,30,4 for s=0,1,2,3, and its increment
with q is 72q-346-8s>0. This proves its separate strict comparison for
every n>=44.

For completeness, H4-H5 is positive at each n=52,...,71. Write n=20t+r,
0<=r<=19. Its difference increases on replacing n by n+20 by

    120t-80+40(floor(r/4)-floor(r/10)) >0  (t>=2).

Thus H4>H5 for all n>=52, not just for the tested examples. The leading
missing density improves from 1/13 to 1/4, and the robustness/time/algorithm
claims are retained, not replaced by weaker existence statements.

The old n=19,...,29 cap is exactly 3n; its small-domain provisions must
remain available unless separately subsumed. The claimed new repairs for
n=22,...,29 are external to this particular proof review.

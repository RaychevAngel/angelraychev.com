# Full verification campaign — 23 October 2026

## Objective and release boundary

User priority: full Lean verification, starting with the dense staircase and a
difficult finite exclusion in parallel. Keep the existing arXiv package ready;
only simplify arguments when that directly helps verification. The frozen
September publication remains the release until a new audited checkpoint is
built. New local proofs below do not retroactively change its verification
receipt.

Baseline: commit `f343776`, 125-page manuscript, 21-module Lean 4.33.1 replay.
The ordinary/computer-assisted classification is complete; the full formal
classification was not complete at that checkpoint and is not yet complete.

## Initial compiled additions (retained history)

- `DenseCombinatorics.lean`: actual finite cardinalities, injections with two
  excluded images, and partitions of graph pairs into arrows, missing pairs,
  successful pairs, and losses.
- `DenseStaircase.lean`: the **unconditional** dense staircase upper bound for
  arbitrary loopless graphs. The previously exposed graph-counting hypothesis
  has been discharged. The numerical conditional lemma is preserved.
- `GraphRelabeling.lean`: graph isomorphisms preserve exact-rank winning,
  guarantees, arc counts, missing counts, and scores; complete covers up to
  isomorphism transport upper bounds.
- `FunctionalEndpoint.lean`: exact characterization for complements of a
  fixed-point-free function, the explicit paired-root graph, literal counts,
  and `IsMaximum n (n*(n-2)) ((n-2)/2)` for every `n≥2`.
- `CyclicArithmetic.lean`, `DenseTwoType.lean`: literal modular core for every
  even order `2k≥10`, with actual two-move strategies and exact maximum at
  `(n,m)=(2k,2k*(2k-3))`.
- `RootAttachment.lean`, `ConstructionCounts.lean`,
  `SmallRootAttachment.lean`: generic root-attachment strategy, literal finite
  counting, and an explicit graph attaining
  `M(r+k,(r+k)*(r+k-3)+r)=(r-2)/2+2k` whenever `r≥11`, `k≤9`.
- `FiniteHall.lean`: finite Hall theorem, its two-regular degree hypothesis,
  and decomposition of an arbitrary loopless two-in/two-out graph into two
  fixed-point-free, disjoint permutation factors.

All completed modules above compile with the pinned toolchain and no proof
holes. Printed dependencies contain only the usual logical axioms
`propext`, `Classical.choice`, and/or `Quot.sound`. Independent source review
has passed for the dense upper, functional endpoint, relabeling, generic root
attachment, counting, and even core. Further reviews are in progress.

## Current compiled mathematical boundary

1. **Complete dense classification.** `DenseClassification.maximum` proves
   the exact maximum for every `n≥20` and every
   `n(n−3)≤m≤n(n−1)`. `DenseClassification.attainer` supplies the literal
   adjacency construction and proves looplessness, exact arc count and score.
   This includes the first staircase step, every later step, the functional
   endpoint and the final zero region. `DenseFirstStep`, `DenseOddCore`,
   `DenseCore`, `ComplementarySum`, `DenseBlockAttachment` and
   `DenseStaircaseConstruction` discharge the construction premises.
2. **Adjacent main-interval band.** `DenseEnvelopeClassification.maximum`
   proves the exact maximum `n(n−1)−m` for every `n≥16` and
   `n(n−1)−3n≤m≤n(n−1)−2n`. Even/odd modular envelopes and the ten finite
   repaired orders are proved, including arbitrary optional subsets, safe
   two-move strategies, and the exact prefix budget. Consequently the two
   classifications together cover all `m≥n(n−4)` for `n≥20`.
3. **Difficult finite strict exclusion.**
   `FiniteExclusion.UnrestrictedNine.upper`
   proves score at most53 for every loopless graph on nine vertices.
   The proof includes saturation-to-two-regular rigidity, finite Hall
   factorization, canonical cycle normalization, and complete checked trees
   for all eight first-permutation types. The 10,996 recorded search nodes
   and535 losing leaves are accompanied by explicit coverage of every child,
   including invalid and camping-pruned branches. This is a strictness
   theorem; it does **not** establish the sharper two-regular bound30,
   the separate global arc-budget value `M_E(18)=33`, or the full small table.
4. **Sparse upper-bound reductions.** `SparseSupport` proves actual support
   counting inequalities. `GraphRestriction` proves retained-game transport.
   `SparseDeletion` proves source and sink deletion with exact arc drop,
   preservation of retained guarantees, the remaining-arc/2 capacity and
   the fixed-order nonadjacency capacity. Waiting, initial cops at the newly
   isolated vertex, and the original direction of all arrows are handled.
   Supported-count and scalar parity induction are continuing.

The full classification is still **not** a Lean theorem. Infinite sparse and
main-interval construction parameters, their full finite bridges, sharper
finite exclusions and the final all-budget assembly remain unfinished.
The frozen September arXiv package has not been changed by these local
additions; its old verification receipt remains an accurate release boundary.
A new integrated source-pinned replay is required before updating public
formalization claims.

## Finite-checker performance work

- The complete first strict exclusion is compiled, including all canonical
  types, normalization and degree rigidity. Its largest family took127s
  with two Lean workers and approximately2.7GB observed resident memory.
- A reflected Hamiltonian tree reduced source from roughly755KB to141KB;
  depth-three chunks checked in43.3s with5.34GB peak resident memory.
  This is a source-compression result, not yet a demonstrated speed win.
- The first untrusted serializer omitted two valid prefixes having no valid
  completions. Lean rejected its completeness check. Adding all invalid-child
  branches repaired it; the corrected certificate passed. This negative
  test confirms that omitted branches are not accepted as proof.
- Optimistic partial-game pruning is proved through a messenger-upper /
  pursuer-lower sandwich. A bounded full Hamiltonian producer visited26,985
  nodes in14.1s, with4,466 local and13,358 robust prunes. This producer
  result is not itself a Lean upper bound.
- Bitset losing-region checks and a cached union of permitted pairs improved
  one six-mask score30 leaf's kernel checking by approximately9×. Complete
  reflected-family generation and replay are in progress; no sharp30
  family result is claimed yet.

## Useful simplification found during formalization

The dense image-count argument does not need a full finite-functional-cycle
existence theorem. In the closed image set, choose `x`, then `y=f(x)` and
`z=f(y)`. Fixed-point-freeness makes `y,z` distinct. Both have predecessors
inside the image, so neither can be the unique image of a surviving source
outside it. Those two excluded images give exactly the required extra loss.
This shorter argument is now kernel checked.

## Current next steps

1. Formalize the remaining sparse scalar induction and infinite circle /
   pair-code construction chain, preserving exact construction requirements.
2. Scale the checked finite-exclusion machinery to the sharp bounds needed
   by the small tables, with measured CPU and memory limits.
3. Import saved mixed winning/losing witnesses and remaining finite stages;
   kernel-checking each graph does not replace exhaustive upper coverage.
4. Independently review and replay the integrated source snapshot, then
   update formalization summaries, publication artifacts and the website
   together at a stable checkpoint.

## Failed approaches / implementation lessons

- For Hall factorization, alternating degree-two walks initially looked
  shorter, but formalizing their parity and orbit closure would duplicate the
  orbit machinery still required for canonicalization. Tight-subset Hall
  induction gave a reusable proof and compiled quickly.
- Finite construction counts are more robust as cardinalities of explicit
  images and filtered lists than as simplifier comparisons between different
  `Decidable` instances. All current count results concern literal graph
  pairs, not supplied numerical certificate claims.
- Finite replay is bounded to two Lean worker threads. The largest generated
  family took about 127 seconds and roughly 2.7 GB observed memory. No new
  broad graph search is running.

## Later October progress (supersedes the earlier in-progress list)

- `SparseParity.upper`, `even_upper`, and `odd_upper` complete the unrestricted
  sparse induction. Source/sink deletion and supported-degree counting are
  actual graph lemmas; no external finite enumeration is a premise.
- `GraphPadding` proves exact score preservation for isolates and sinks with
  at most one predecessor. `SparseAttainment.maximum_twentyfour` proves
  `M(n,24)=108` for every host order at least twelve.
- `CircleParameters.maximum` proves the full five-offset interval for orders
  divisible by four; `CircleGuardedConstruction` has its exact closed endpoint.
- `ProtectedParameters.maximum` proves every
  `n≥25, 3n≤m≤n(ceil(n/7)−1)`. Parameter selection checks arithmetic only;
  offset growth scans residues and six protected differences. The size bound,
  actual strategy and exact optional-prefix count are proved. Independent
  source review passed.
- `SignedRankCertificate` and the three `SparseWitness` modules prove exact
  scores30,50,79 for the saved graphs at(9,18),(10,20),(11,22). These are not
  unrestricted extremal upper bounds. Changing identical rank data from
  indexed arrays to nested literal functions reduced the nine-vertex kernel
  check from over140 seconds without completion to2.66 seconds; ten and
  eleven took3.73 and5.25 seconds. Independent review passed.
- `LocalArena` and `LocalArenaRows` prove asymmetric local simulation and
  safe sequential composition. Transfer includes the intervening cop reply;
  terminal delivery retains receipt priority. Independent review passed.
- `SparseCropCoverage.coverage` proves every canonical crop at circumference
  k≥15 is one of81 literal patterns, corresponding to552 local objectives.
  The proof reduces k≥25 to circumference25 or an empty crop; the small
  remainder is checked in the kernel. Independent enumeration and review
  agree. This reduces the required family from189 patterns/1287 objectives
  without claiming that all reduced objectives or the geometry have been
  imported. The seven empty-hole pilot objectives compile; their receipt
  remains in `tmp/lean-oct23/counting/local-six-type-pilot.json`.

The complete sparse attainer still needs the concrete cyclic window projection,
all required local certificates, exact graph counts and finite bridge. The
sharp finite tables and final all-pairs assembly remain unfinished.

## Precise next construction: separated pair codes

Reuse the even dense core's point/line vertices and missing rows. A code is a
pair of same-part indices whose cyclic difference is not0,±1,±2. Prove that
no missing row is contained in a code, no code is contained in a missing
predecessor row, and no code lies in the union of the outgoing/incoming missing
rows of a missing hub pair. These are finite geometric lemmas, not game premises.

Add q outside vertices with distinct codes: hubs point to every outside
vertex, each outside vertex points to every hub outside its own code, and
outside-to-outside arrows are optional. Check the mixed endpoint/cop cases
through the robust two-move witness interface, retaining the actual cop reply.
Then count the exact missing pairs and apply `PrefixEnvelope`.

A useful counting simplification avoids unordered-pair division: enumerate
ordered separated pairs(i,j); map i<j to the point code{i,j}, and i>j to the
line code{j,i}. Each row excludes exactly five offsets, yielding k(k−5)
distinct codes. Taking the first q gives a prescribed procedure. The order
differs harmlessly from the paper's point-first list and must be documented.
Numerical overlap with the already verified circle families is a separate
arithmetic obligation; no new graph search is needed for this chain.

## Publication integration

The October draft replaces obsolete21-module coverage prose with exact theorem
domains and explicit remaining obligations. No mathematical theorem or prior
certificate is removed. Lean sources will be shipped only in the existing
`lean-proofs.zip`, removing their duplication from `research-sources.zip` to
stay under the100MiB hosting limit. All three evidence archives extract into
the same root. A successful source-pinned replay and independent artifact
checks are required before the updated publication is served.


## Six-type sparse construction: exact continuation boundary

The reusable dependency chain is `LocalArenaRows → LocalArena → FiniteGame`,
with `CyclicWindow → CyclicArithmetic → Std` for window geometry and
`SparseCropCoverage → Std` for canonical crop coverage. All these modules
compile. `CyclicWindow.internal_short` requires exactly `w+J<k`; with
`w=12,J=2`, this is `k≥15`. `radius_six_entries` proves that outside cop
entries can land only at offsets 0,1,11,12, corresponding to columns
−6,−5,5,6. These are geometric facts, not an instantiated graph simulation.

The immutable primary data are
`research/sparse-composition-multi-certificates.json.gz`, SHA256
`53daceac01e67909c70c9a06d6390e0858950212d29d66bae70b70d15342fd65`.
They contain 189 patterns and 1287 objectives. For each list `p` in
`SparseCropCoverage.catalog`, subtract six from every entry and use the
resulting ordered tuple as the saved record's `holes` key. Select the unique
record for each `(holes,target_type)` pair: `None` is safe transfer; 0..5 are
delivery targets, omitting 4 precisely when 0 belongs to `holes`. A read-only
lookup confirmed all 81 catalog patterns exist in the frozen data and select
exactly 552 records; 15 patterns omit the central type-four target. This is
coverage of the canonical holes `{0,3,...,3(r−1)}`, `r≤5`, sufficient for the
explicit all-orders constructor. It does not replace the stronger arbitrary
spaced-hole theorem by an equivalent statement.

The private pilot generator is
`tmp/lean-oct23/counting/local_arena_pilot.py`; its receipt is
`tmp/lean-oct23/counting/local-six-type-pilot.json`. It imports only the seven
empty-hole objectives (saved record indices 0..6), round-trips packed ranks
and moves against the saved values, and emits `LocalSixTypeTransfer.lean`
and `LocalSixTypeDelivery0.lean` through `LocalSixTypeDelivery5.lean` in that
scratch directory. All seven compiled in roughly 8–11 seconds each with
kernel-checked row obligations and initial-state bounds. Packing uses
`rank+1` (zero marks excluded states), and the sparse reply lists feed
`LocalArenaRows.safe_checked` / `delivery_checked`. The full 552-objective
family has not been replayed. The pilot receipt predates the unbounded
`SparseCropCoverage.coverage` theorem; its old bounded-coverage description
is not the current theorem boundary. Keep the pilot outside public Lean
until a concrete simulation is connected. For nonempty patterns, derive
indices and collision tests from the saved `messenger_vertices` and
`pursuer_vertices` lists: the empty-hole dimensions 54/79 and formula
`r+12=c` must not be reused blindly after vertices are removed.

The next semantic obligations, in order, are:

1. Define existing vertices `(column,type)` with type four removed at the
   canonical holes. Define the two paper permutations and their two smoothed
   arrows `3_h→5_h` and `1_(h−1)→2_(h+1)`. Prove the two permutations remain
   bijective, loopless and pointwise distinct; enumerate exactly `6k−r`
   vertices and count exactly twice that many arcs.
2. For each center, let `c` be its column minus six modulo `k`; connect its
   saved holes to `SparseCropCoverage.crop k r c`. Embed messenger columns
   −4..4 and project cop columns −6..6, with all other cops sent to `Ω`.
   Discharge all three `LocalArena.Simulation` fields: legal messenger moves,
   coverage of every actual cop reply including waits, and reflection of
   actual collisions. `CyclicWindow` supplies internal no-wrap and boundary
   entry geometry. Still prove that a hole outside the window cannot change
   an internal arc: the relevant outward smoothing at hole 7 changes
   `1_6→4_7` to `1_6→2_8`, with both heads projected to `Ω`; analogous
   messenger-boundary changes remain outside its permitted window.
3. Extend the byte-preserving pilot exporter to the 552 selected objectives;
   prove every required initial state and the 9/27 rank bounds. Apply
   `safe_projection` and `delivery_projection`, then
   `transfer_then_delivery`: advance safely one column per transfer until
   two columns before the recipient, giving at most `9(k−1)+27=9k+18`.
   Transfer must retain the intervening cop reply; terminal receipt keeps
   its immediate priority over collision.
4. Reindex the resulting graph onto `Fin (6k−r)` via `GraphRelabeling`, then
   use `SparseAttainment.maximum_even_of_core` and `GraphPadding` where
   their hypotheses apply. This closes the uniform constructor for orders
   at least 85 only. The finite 12..84 bridge remains separate: adjacency is
   in `research/sparse-finite-bridge-witnesses.json`, full ranks in
   `research/sparse-finite-bridge-certificates.jsonl.gz`, and the ordinary
   dispatcher is `src/sparse_finite_bridge_construct.py`. Order 12 already
   has the compiled `SparseAttainment.maximum_twentyfour` endpoint. The odd
   endpoint construction is another obligation; the even six-type result
   alone does not supply it.


## Finite-exclusion continuation: keep the two targets separate

Read-only continuation review during the final source-pinned replay. No new
graph search was run and no frozen Lean or tooling was changed for this review.
The following are future tasks, not additional verified theorem claims.

**Sharp regular-nine bound 30.** The remaining first-factor cycle types are
`2+2+2+3`, `2+2+5`, `2+3+4`, `2+7`, `3+3+3`, `3+6`, and `4+5`.
`FiniteHall`, `CycleNormalizationNine`, the conjugacy transport, and the
existing all-eight aggregator already close their structural coverage. The
new prefix-loss, bitset and Boolean-tree soundness proofs apply to each fixed
first factor. Consequently no new game semantics or factorization theorem is
needed: produce complete threshold-30 certificates, check them in small
modules, and replace the eight bounds in the regular-nine aggregator. The
saved score-30 witness supplies equality.

The frozen `research/small-sparse-regular-9-threshold30.json` records all eight
types, 693,572 nodes and 42,473 evaluated graphs. It contains aggregate
counters and one witness, not the complete per-node proof tree or losing
regions. It cannot itself be imported as a Lean certificate. The existing
all-eight bound-53 trees also cannot simply be relabeled as bound-30 proofs:
their early pruning proves only the weaker conclusion. Future untrusted
certificate generation must reconstruct the stronger traversal or use the
new optimistic-prefix producer; preserve the original receipt bytes.

Do not blindly scale the Hamiltonian replay. The already saved probe
`tmp/lean-oct23/finite/sharp-other-families-probe.json` has five complete
non-Hamiltonian traversals using 160,565 selected target masks in total; the
two interrupted probes already add 79,764 masks. These are workload counts,
not verified upper bounds or complete certificates. They exceed 31 times the
Hamiltonian certificate's 7,707 masks even before completing the two probes.
A linear extrapolation of the measured kernel workload is hours, not the
subsecond C++ receipt time.

The best candidate speed improvement before bulk replay is one generic
centralizer-normalization theorem. Choose a lexicographically minimal second
factor among its relabelings commuting with the fixed first factor; an
explicit commuting permutation then certifies each improving-prefix prune.
This can use cycle rotations and equal-length cycle swaps. The respective
centralizer orders for the seven types above are 144, 40, 24, 14, 162, 18,
and 20. Those are symmetry opportunities, not promised speedups: ties and
stabilizers reduce the gain. Prove normalization first, then measure one
family and retain the current small-module replay strategy.

**The unrestricted eighteen-arrow value follows a different dependency
path.** Sharp regular-nine at 30 is *not* required to prove the upper 33.
The corrected `research/sparse_finish_positive_fullmax_n9_m18_t33.json`
covers all 48 nine-vertex joint profiles, including the regular family,
with zero inherited skips. Do not use
`research/sparse_finish_positive_n9_m18_t33.json`: it incorrectly skipped
three whole families using bounds on smaller camping-free subfamilies.
Likewise, the partial `sparse_finish_positive_n11_m18_t33.json` is replaced
by the completed ranges in `sparse_finish_positive_full_n11_m18_t33_p1_2.json`
and `sparse_finish_positive_n11_m18_t33_p3.json`.
`research/finish_eighteen_review.md` and its JSON/manifest document these
corrections and exact joint-profile set comparisons.

The ordinary reduction needs only the weak bounds `ME15 <= 26` and
`ME16 <= 25`, followed by the auxiliary `ME17 <= 33`. In fact one global
`ME16 <= 25` theorem supplies both smaller-budget premises, using the already
proved fresh-sink budget-raising construction. Establishing that weak global
sixteen-arrow bound is still real finite work: the current unrestricted
`SparseParity` bound is 30 at budget 15 and 40 at budget 16. The older exact
14--16 package has its own smaller-budget prerequisites; none may be silently
assumed to be Lean theorems.

The five positive-support inventories at threshold 33 are:

| Budget | Support | Joint profiles | Saved evaluated leaves |
|---|---:|---:|---:|
| 17 | 9 | 8 | 27 |
| 17 | 10 | 1 | 0 |
| 18 | 9 | 48 | 1,620 |
| 18 | 10 | 13 | 64,277 |
| 18 | 11 | 3 | 7,548 |

The completed reviewed traversals contain 79,718,358 nodes and 73,472
independently solved leaves, including the auxiliary budget-17 runs. These
aggregate receipts do not save a complete kernel-ready tree. Replaying only
the leaves would not prove coverage or the pruned branches.

The new proof obligation is a general prescribed-degree **row-prefix cover**,
rather than another permutation-factor cover. It must prove completeness of
the sorted joint-degree inventory and of the row symmetry rule: future
vertices may be permuted only when their degree pairs and incoming prefixes
agree; the permutation must fix completed rows. Residual capacities and each
possible subset cardinality also need checked coverage. Existing
`GraphRelabeling` supplies the semantic transport, while `SparseSupport`,
`SparseSupported` and `SparseDeletion` supply the ordinary game/counting
reductions. Support compression/reindexing and the small numerical range
maxima still need to be connected explicitly.

For pruning, generalize the existing bitset envelopes from nine-vertex
permutation prefixes to arbitrary row prefixes at orders 8--11. The generic
`RobustLosingRegion` theorem already supplies the game meaning of optimistic
messenger/fixed-cop certificates. Export closed losing regions for the old
stationary-cop guarded prunes, union losses before counting, and check only
the remaining eligible-pair upper. Upper exclusions need no winning-rank
certificates. A useful first coverage/guard prototype is the sole positive
10/17 profile: its saved traversal has 786,077 nodes and no game-evaluation
leaves. Do not emit tens of millions of proof nodes before this prototype
has a measured compact certificate and acceptable replay cost.

There is a smaller-host shortcut: formalizing all of `MV8 = 32` is unnecessary
for this target. Hosts at most seven satisfy the existing vertex bound 28.
At order eight and budgets 17 or 18 there are respectively 39 or 38 missing
pairs. A source row or target column of degree at most one is inactive and
contains at least six missing pairs, giving score at most 33 or 32.
Therefore a counterexample must have every in/out degree at least two.
Budget 17 then has only two joint profiles, according as the unique outdegree-3
and indegree-3 vertices coincide. Budget 18 has nine: out/in surplus partitions
are `4` or `3+3`, with respectively 2, 2, 2 and 3 possible overlaps.
These eleven small-host profiles can use the same general row checker.
This reduction is an ordinary argument here; its short counting proof and
profile-cover theorem have not yet been added to Lean.

Finally, the lower 33 is an immediate certificate-translation task:
`research/finish-sparse-lower-n9-m18-seed2026091498-certificate.json` contains
all nine targets' signed ranks and messenger successors in the same format
already handled by `SignedRankCertificate`. Use a new module/name rather
than overwriting the existing score-30 `SparseWitness9`. No new graph search
or game solution is necessary for that lower witness; padding gives larger
hosts after the exact graph theorem is checked.

Recommended order for the next campaign: translate that literal lower 33;
prove/benchmark the general row-prefix coverage and guarded-loss checker on
one small profile; establish the necessary weak sixteen-arrow bound and
small-host controls; then certify the five positive-support inventories and
compose source/sink induction. Complete the seven regular-nine families as
a separate milestone, with centralizer reduction first, rather than making
them an unnecessary prerequisite of the eighteen-arrow route.


## Six-type simulation: concrete case inventory and shared lemmas

This continuation is an ordinary derivation and a small table-consistency
check, not an additional Lean theorem or local-rank replay. It reads the
current `sparse_finite_bridge_construct.py`, `SmoothStrip`, and saved local
arenas directly. Write `H_i` for removal of type four in column `i`;
all subscripts below are modulo `k` for the actual graph and integers for
the local strip. On existing vertices the complete successor/predecessor
inventory is:

| Type at column i | First successor F | Second successor G | First predecessor | Second predecessor |
|---|---|---|---|---|
| 0 | 1_i | 5_i | 5_(i−1) | 3_(i+1) |
| 1 | 2_i | H_(i+1) ? 2_(i+2) : 4_(i+1) | 0_i | 2_(i−1) |
| 2 | 3_i | 1_(i+1) | 1_i | H_(i−1) ? 1_(i−2) : 4_(i−1) |
| 3 | H_i ? 5_i : 4_i | 0_(i−1) | 2_i | 5_(i+1) |
| 4 (when present) | 5_i | 2_(i+1) | 3_i | 1_(i−1) |
| 5 | 0_(i+1) | 3_(i−1) | H_i ? 3_i : 4_i | 0_i |

Only two successor branches inspect holes: first-color type three at its
own column, and second-color type one one column ahead. Skipping never
continues through a second removed vertex, since the two possible deleted
intermediaries are followed by types five and two. Consequently regularity
and window simulation need **no spacing assumption on H**. Spacing enters
only when selecting a certified local pattern. For `k≥3`, outgoing colors
are distinct: their target types differ except at a smoothed type-one
source, where the two type-two targets are separated by two columns.
All arrows change type, so there are no loops.

A reusable counting helper can remove separate inverse proofs. Given a
bijection `f` and a deleted predicate `D` with
`D x → ¬D (f x)`, define on retained vertices
`skip_D(f,x) = if D(f x) then f(f x) else f x`.
It is a bijection of retained vertices, with inverse
`if D(f⁻¹ y) then f⁻¹(f⁻¹ y) else f⁻¹ y`.
The displayed no-consecutive-deletions premise holds automatically for
both colors, for any column predicate H. Thus two base permutation proofs,
this helper, and pointwise color distinctness suffice for exact degree and
arc counts; the table supplies an alternative direct inverse proof.

The main shared simulation lemma should be **projected smoothing**. For
arbitrary `f : X→X`, `π : X→Option Y`, and decidable predicates H,K, assume

- `π y ≠ none → (H y ↔ K y)` for every y;
- `π(f x)=none → π(f(f x))=none` for the source x in question.

Then `π(skip_H(f,x)) = π(skip_K(f,x))`. Proof: if the first head projects
inside, the branch predicates agree; otherwise both possible heads project
to `none`. Here π must first be the **raw column-window projection**, which
still represents deleted vertices inside the window. Do not collapse
inside deleted vertices to Ω in this lemma. Refine to existing local vertices
only after proving that the smoothed head is retained.

Take K to be H restricted to the represented columns. The no-return premise
follows from `CyclicWindow` and the following pairs of column displacements
for the *unsmoothed* first and second iterates, in source-type order 0..5:

- F: `(0,0),(0,0),(0,0),(0,0),(0,1),(1,1)`;
- G: `(0,−1),(1,2),(1,2),(−1,−1),(1,2),(−1,−2)`.

Each pair advances monotonically in one direction by at most two. A path
starting inside offsets 0..12 cannot leave and return under `12+2<k`.
A useful algebraic sublemma is: for `u≤w`, `0≤a≤b≤J`, `w+J<k`, if
`shift (shift base u) a` is outside `Inside base w`, then so is
`shift (shift base u) b`; use `forward_internal` on a hypothetical inside
second endpoint. Precisely, the backward version assumes
`shift y a = shift base u` and `shift z b = shift base u` under the same
bounds and concludes `¬Inside base w y → ¬Inside base w z`. If z had
inside offset v, then `v+b=u`; hence `u−a` is an inside offset for y.
These are not claimed for arbitrary two short moves, which could reverse
direction and re-enter.

The complete cop-window exits at radius B are: first-color source `5_B`;
second-color sources `1_(B−1)` when `H_B`, `1_B`, `2_B`, `4_B` when present,
`3_(−B)`, and `5_(−B)`. For B=6, the only branch whose hole query lies
outside the crop is `1_6`: the full graph may give `2_8` while the cropped
strip gives `4_7`; both project to Ω. All other branch predicates agree.
For messenger radius four, these same exit forms are omitted, and every
hole queried by a retained source lies within the larger cop window.
Outside-to-inside cop replies follow directly from the jump-two bound and
`radius_six_entries`; Ω already allows every existing type in the four
boundary columns. At k=15 the left and right descriptions of outside
columns can name the same actual column, so do not require distinct outside
lifts. Only the represented offset 0..12 is unique.

One additional semantic lemma is essential for importing initial states:
prove **full collision equivalence**
`localCollision(r,project(c)) ↔ embed(r)=c`.
`Simulation.collision_complete` uses only actual equality implying local
collision, sufficient for sound strategy projection. The reverse direction
is separately needed to turn an actual noncolliding initial cop into the
noncolliding local state covered by the saved certificate. It follows from
unique represented offsets and the inverse enumeration of existing vertices;
Ω never collides with an embedded messenger.

A read-only independent formula check matched all 81 selected saved arena
records (one per pattern), including exact vertex order, waits, clipping,
and Ω replies: 4,239 messenger rows/12,231 move entries and 6,180 cop
rows/20,238 reply entries. A symbolic Boolean-branch check of all represented
source columns and six types found exactly the raw `1_6` difference above
and zero projected differences. All 552 selected objective records also have identical decoded arena
data within their 81 pattern groups. No ranks were solved
or replayed. For the next exporter, share each pattern's arena definition
and table-equality check across its six or seven objective certificates
instead of repeating that identical semantic work 552 times.

## Integrated replay reporting correction

The first full run rebuilt all147 mathematical modules successfully, but
`Audit.lean` failed on one reporting reference: the theorem namespace is
`Delivery.FiniteExclusion.UnrestrictedNine.upper`, not
`Delivery.FiniteExclusionUnrestrictedNine.upper`. No successful receipt was
written. The report and corresponding README reference were corrected.
A direct Audit precheck passed, and an independent source-level review
matched all83 printed theorem identifiers and all13 qualified project
identifiers in the README. The complete source-pinned replay was restarted
after those corrections; only its eventual successful receipt authorizes
the release. Future long replays should precheck the audit list first.

Independent bounded source review passed for the successor/predecessor
inventory, projected-smoothing lemma, both monotone no-return directions,
window-exit list and separate collision-equivalence obligation. This review
involved no Lean edits or compilation and does not promote these proposed
helper statements to formal theorems.


## Weak sixteen-arrow reduction: reviewed ordinary preparation

This section records a bounded read-only investigation during the final Lean
replay. The following arguments were independently challenged by
`next_slim_upper` and passed ordinary mathematical review. They are **not new
Lean theorems**. No graph search, rank replay, or compilation was run, and no
frozen source or receipt was changed. Small arithmetic checks only filtered
saved degree inventories or counted explicitly described degree multisets.

### A thirteen-arrow equality case removes two deletion exceptions

Use the already formalized parity bounds `B10 = 10`, `B11 = 12`, `B12 = 18`,
and `B13 = 20`. Bounds for budgets below ten follow by the proved fresh
one-predecessor-sink budget-raising construction, not by adding arbitrary
arrows (which need not preserve the score). Let a loopless graph H have
exactly thirteen arrows and score twenty.

First H has no nonisolated source or sink. Deleting one of degree one leaves
at most eighteen pairs and adds none. Degree two leaves an eleven-arrow
remainder and adds at most five, giving at most seventeen. Degree at least
three leaves a remainder of budget at most ten and adds at most five,
giving at most fifteen. These are the original-direction source and sink
deletions in `SparseDeletion`, including its usable-neighbor capacities.
Thus every vertex incident to an arrow has both positive indegree and
positive outdegree. All other vertices are isolated: there are no arrows
outside, into, or out of the resulting positive support K.

Write N for the size of K, q and r for the numbers of its vertices with
outdegree and indegree at least two, and b for their overlap. Positive
degrees give q,r <= min(6,13-N). The active rectangle gives

    I(H) <= qr - b - max(0,13-2N+q+r),
    b >= max(0,q+r-N).

For N <= 6, the missing-pair count is at most 6*5-13 = 17. For N >= 8,
the displayed bounds give at most sixteen. Therefore N = 7. At N = 7,
if either q or r is at most five, the bound is at most sixteen; consequently
q = r = 6. Every degree is then two except for one outdegree-one vertex
and one indegree-one vertex. The rectangle bound is 25-b, so score twenty
forces b = 5: those two exceptional vertices are distinct. More precisely,
if w counts the arrow from the low-outdegree vertex to the low-indegree
vertex, the active cut has exactly 11+w arrows, giving I(H) <= 20-w;
hence w = 0. None of these conclusions presumes a sharp small-budget table.

**Adding a source.** Add a new source v with degree two or three, allowing
its arrows to any of the old vertices. A counted pair (v,t) is missing, so
adding v has not changed t's incoming arrows. Its target therefore lies in
the six active-in vertices of H. If v has any counted target, the proved
nonsink-successor lemma gives two distinct successors of v with positive
outdegree. Both lie in K; among K only one vertex is outside those six
active-in vertices. At least one successor is therefore an active-in
vertex, and that direct pair cannot count. The new row contributes at most
five. A zero row already satisfies that conclusion.

**Adding a sink.** This requires its own argument, not reversal of the
game. Add a new sink v of indegree two or three. For a counted pair (s,v),
the missing arrow means s's outgoing arrows have not changed; hence s is
one of the six active-out vertices of H. If the added column is nonempty,
the usable-predecessor lemma gives two distinct predecessors of v having
positive indegree. Both lie in K, so one belongs to those six active-out
vertices and loses its pair to v because that pair is direct. The column
contributes at most five.

For an arbitrary thirteen-arrow remainder, a score at most nineteen plus
the usual six-pair capacity is already at most twenty-five. The equality
case above supplies twenty plus five. Therefore both exceptional deletion
cases improve from twenty-six to twenty-five:

- budget fifteen, deleting a degree-two source or sink;
- budget sixteen, deleting a degree-three source or sink.

This is a reusable equality/capacity argument; no new finite exclusion is
needed for either case.

### Precise residual positive-degree inventories

Choose a counterexample of minimum budget among graphs with at most sixteen
arrows and score greater than twenty-five. Budgets at most thirteen are
already excluded by parity. Degree-one sources/sinks are excluded by
minimality; degree at least four is bounded by `B12 + 6 = 24`; the exceptional
cases just proved dispose of the two remaining potentially large deletions.
The only source/sink case still possible is budget sixteen with degree two.
Such a source row or sink column must be nonempty, again by minimality.

For positive support, the active-rectangle bound and small-host missing-pair
count leave the following exact joint-degree multisets up to simultaneous
vertex relabeling. These are candidate degree profiles, not claims that
every profile is realizable or that its graphs have been checked.

| Arrows | Positive support | Candidate profiles above 25 |
|---|---:|---:|
| 14 | 7 | 1 (two-in/two-out regular) |
| 15 | 7 | 2 |
| 15 | 8 | 2 |
| 16 | 7 | 9 |
| 16 | 8 | 14 |
| 16 | 9 | 11 |
| 16 | 10 | 1 |

At (7,15), all degrees are at least two, with one degree three on each
side; the high vertices coincide or differ. At (8,15), each direction has
one degree one and seven degree twos; the low vertices coincide or differ.
All other support sizes at budget fifteen give at most twenty-five by
counting. At (7,16), score above twenty-five would mean every one of the
26 missing pairs wins. A degree at most one would make at least five of
those pairs inactive, so all degrees are at least two. Each direction's
surplus partition is either one degree four or two degree threes. Their
joint overlap types give 2+2+2+3 = 9 profiles.

At (8,16), the surviving active-set sizes (q,r) and profile counts are
(8,8):1, (8,7):1, (7,8):1, (8,6):2, (6,8):2, and (7,7):7. In the last case
there is one high and one low vertex in each direction; the seven cases
are identical ordered pairs, reversed pairs, four possible single
coincidences, and all four vertices distinct. At (9,16), seven degree-twos
and two degree-ones in each direction give three overlap types. Active-set
sizes (6,7) and (7,6) each give four more: the six-active side has one degree
three, five degree-twos and three degree-ones; its degree-three vertex may
or may not be active in the opposite direction, and the active overlap is
four or five. Filtering the existing positive inventories confirms eleven
of the saved 52 order-nine profiles, one of the 17 order-ten profiles, and
none of the two order-eleven profiles survive threshold twenty-five.

The sole (10,16) profile is particularly rigid:

    2 vertices of degree pair (2,2),
    4 vertices of degree pair (2,1),
    4 vertices of degree pair (1,2).

Its eligible bound is 26-w, where w counts arrows from the low-outdegree
vertices to the low-indegree vertices. A counterexample therefore requires
w = 0 and every one of the 26 eligible pairs guaranteed. One additional
proved losing eligible pair suffices; a checker need not certify the much
larger permanent-loss count used for sharp regular-nine exclusion.

There is also a small existing certificate opportunity at (7,14).
`small-exceptional-regular-enumeration.json` records four first-factor cycle
types, 142 visited nodes and zero local-obstruction-free leaves. Inspecting
`small_exceptional_regular.cpp` shows only source-neighborhood or complete
predecessor-neighborhood camping prunes. A source obstruction loses all four
missing pairs in its row; a predecessor obstruction loses at least three
of the four missing pairs in its column (one initial source may equal the
camping vertex). Either gives score at most twenty-five from the 28 missing
pairs. Translating this tiny cover would avoid replaying the stronger
seven-vertex threshold-ten package. The aggregate receipt still does not
contain a kernel-ready tree: complete branch coverage and the seven-vertex
cycle-normalization wrapper would have to be proved and checked.

### Zero-degree support twelve disappears structurally

Continue with the minimum-budget counterexample. Its sources and sinks all
have degree two and live rows or columns. Write s,t for their counts, N for
nonisolated support, and u,v for the actual numbers of live rows and columns.
Active-degree and usable-neighbor capacities imply

    u <= min(16-N+t, 8-t),
    v <= min(16-N+s, 8-s),
    I <= uv - max(0,u+v-N) - max(0,2u+2v-16).

In particular 2u,2v <= 24-N. Every nonisolated vertex has total degree at
least two, so N <= 16. For N >= 13, u,v <= 5 and the displayed rectangle
bound is at most twenty-one.

At N = 12, u,v <= 6; if either is at most five the bound is at most
twenty-four. Thus a counterexample requires u = v = 6. Equality in the
capacities forces s = t = 2, six active vertices in each direction, and
all positive degrees equal to one or two. Let A,B be these active sets,
which are also exactly the live sets; let S,T be the two sources and two
sinks. A has twelve outgoing arrows. Each live row requires two nonsink
successors, so these exhaust all twelve arrows not entering T. Thus A
sends no arrow into T and every positive row outside A sends its sole
arrow into T. Similarly B's twelve incoming arrows exhaust all twelve
arrows not leaving S. Thus source arrows avoid B, and all non-source
arrows enter B.

Put b = |A intersect B|. The rectangle has at most 28-b eligible pairs.
Since |A|+|B| = N, there are also b vertices Z outside both sets. Every
vertex of Z has degree pair (1,1), with predecessor in S and successor in
T. If b >= 1, choose a source x pointing to z in Z and camp at x's other
successor. That successor differs from x by looplessness. Departure to z
can subsequently reach only a sink; departure to the other successor is
captured. All four targets in B minus T are therefore losing from x.
These four pairs are missing and off-diagonal, so they are additional to
the rectangle's diagonal/direct-arrow deductions. The score is at most
28-b-4 <= 23.

If b = 0, let X = A minus S and Y = B minus T, both of size four. Every
x in X has precisely two successors in Y, and every y in Y sends its
only arrow into T. Hence x cannot reach its other two Y targets at all.
The four rows contribute eight distinct missing losing pairs, and the
score is at most 28-8 = 20. Thus support twelve is impossible in either
case, without a graph certificate. Supports at most six have the smaller
vertex/missing-pair bounds; at support seven a source or sink removes six
missing pairs from the total 26, giving at most twenty. The remaining
zero-degree domain for this weak target is therefore **budget sixteen,
supports eight through eleven, with every source and sink of degree two
and live**. Its complete joint-profile cover has not been established here.

### Which route serves full formalization

The weak bound is a possible shortcut to the eighteen-arrow upper 33, not
an alternative to eventually proving the sharp sixteen-arrow value 19.
The saved exact 14--16 package already has 125 positive-support profiles
(12,42,71 by budget) and 1,523 zero-degree profiles (339,1,089,95), with
118,547 independently replayed leaf games. At budget sixteen its 95
zero-degree profiles have no evaluated leaves; the 71 positive profiles
account for 79,890 leaf games. Its inherited small-host and smaller-budget
premises are additional formal obligations.

The weak route reduces the positive candidate inventory to 1+4+35 profiles,
but it does not yet supply a complete zero-degree inventory. In particular,
the saved `*_zero_two.json` inventories use exact smaller-budget deletion
bounds in `finish_budget_run.py`; simply filtering those files at threshold
25 would silently inherit unproved sharp premises. Thus no net kernel-work
saving has been established for a separate weak certificate corpus.

For the full-classification goal, the default remains one reusable
prescribed-degree row-prefix coverage checker, first benchmarked on a small
sharp family and then used at the actual sharp thresholds. The new equality,
usable-neighbor saturation, and trapping-path arguments are concrete reusable
pruning lemmas. Retain the weak inventory as an optional eighteen-arrow
milestone route only if measured certificate cost justifies it; do not
produce duplicate weaker families merely to obtain an earlier partial claim.

## Accepted source-pinned replay checkpoint

The fresh replay completed at 2026-10-24T02:00:30.581122+00:00: all148 modules passed,
including Audit, with 152 current source pins. Summed module wall
time was 1116.861 seconds. Reported axioms were only
`propext`, `Classical.choice`, and `Quot.sound`. The corrected audit namespace
and README are included in the verified source snapshot.

The full classification remains unformalized. The complete domains and
finite-family boundary are exactly those in lean/README.md. New ordinary
simplifications recorded later in this log are preparation, not additional
Lean theorems. The manuscript stays125 pages/9figures; package audits and
live website deployment are separate acceptance stages.

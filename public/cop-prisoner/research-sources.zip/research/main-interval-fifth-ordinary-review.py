#!/usr/bin/env python3
"""Independent literal proof-obligation replay; imports no project modules.

Circle inputs are fixed published residue/rank data. Hub adjacency and ranks
are reconstructed directly from the manuscript. Optional envelope moves are
always all enabled for the cop, and disabled for the messenger.
"""
from itertools import combinations
from math import gcd,comb
from pathlib import Path
import hashlib,json,time

ROOT=Path(__file__).resolve().parents[1]
FILES=['paper/main-interval-six-circle.md','src/main_interval_six_circle.py',
       'research/six-circle-recipes.json','paper/main-interval-reduced-hubs.md',
       'src/main_interval_reduced_hubs.py']


def hashes():
    return {f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest()for f in FILES}


def circle_rank(n,h,C):
    rank={0:0,**{(-d)%n:1 for d in C}}
    z=-h
    for _ in range(n):
        for source,offsets in [(z-h+2,(h,h-3,h-2)),(z-h,(h,h-2,h+2)),
                               (z-h-1,(h,1,h+1)),(z-h-2,(h,1,h+1))]:
            if source%n in rank:continue
            heads=[(source+d)%n for d in offsets]
            assert all(v in rank for v in heads),(n,h,source,heads)
            rank[source%n]=1+max(rank[v]for v in heads)
        z-=h
    assert len(rank)==n
    return [rank[v]for v in range(n)]


def replay_circle(row,all_targets=True):
    n=row['n'];C=set(row['C']);A=set(row['A'])
    assert len(C)==len(row['C']) and len(A)==len(row['A'])
    assert C|{0}<=A<=set(range(n)) and 0 not in C
    assert (row['m_min'],row['m_max'])==(n*len(C),n*(len(A)-1))
    clauses=0
    if row['kind']=='six-clause':
        h=row['h'];assert gcd(n,h)==1
        assert C=={d%n for d in [1,h-3,h-2,h,h+1,h+2]} and len(C)==6
        for S in [(h,1,h+1),(h,h-3,h-2),(h,h-2,h+2)]:
            for cop in range(1,n):
                assert {d%n for d in S}-{(cop+a)%n for a in A}
                clauses+=1
        ranks=circle_rank(n,h,C)
    else:
        assert row['kind']=='finite-source-ranks'
        ranks=row['rank_t0'];assert len(ranks)==n and ranks[0]==0
        assert all(isinstance(k,int)and k>0 for k in ranks[1:])
    obligations=0
    if all_targets:
        B=[{(s+d)%n for d in C}for s in range(n)]
        E=[{(c+d)%n for d in A}for c in range(n)]
        for t in range(n):
            for s in range(n):
                if s==t or t in B[s]:continue
                earlier={u for u in B[s]if ranks[(u-t)%n]<ranks[(s-t)%n]}
                for c in range(n):
                    if c!=s:
                        assert earlier-E[c],(n,t,s,c)
                        obligations+=1
    return clauses,obligations


def periodic_rows():
    rows=[]
    for n in range(16,321):
        for period,start,residues in [(4,7,{0,1}),(5,8,{0,1,4})]:
            if n%period:continue
            for h in range(start,(n-2)//2+1,period):
                if gcd(n,h)!=1:continue
                C={1,h-3,h-2,h,h+1,h+2}
                A={d for d in range(n)if d%period in residues}|{h}
                if period==5:
                    removed={h+3,h-4,2*h-1}
                    assert len(removed)==3 and removed<=A and not removed&(C|{0,h})
                    assert all(0<d<n for d in removed)
                    A-=removed
                assert len(A)==(n//2+1 if period==4 else 3*n//5-2)
                rows.append(dict(n=n,h=h,C=sorted(C),A=sorted(A),kind='six-clause',
                                 m_min=6*n,m_max=n*(len(A)-1),period=period))
    return rows


H=set(range(12));R={1,2,3,4,6,7,9,10};S={1,4,7,9};T={0,2,3}
K=[{6,8,10},{7,9,11},{0,3},{1,4},{2,5},{6,9},{7,10}]


def hubs(g,codes):
    b=len(codes);top=12+g;n=top+b
    assert 2<=g<=7 and all(len(J)>=2 and J<=set(range(g))for J in codes)
    assert all(not x<=y for i,x in enumerate(codes)for j,y in enumerate(codes)if i!=j)
    B=set();optional=set()
    missing=[{6+i,6+(i-1)%6}for i in range(6)]+[{(i+4)%6,i}for i in range(6)]
    for s in range(n):
        if s<12:
            heads=(H-{s})-missing[s]
            if s in R:heads|=set(range(12,n))
        elif s<top:heads=H-K[s-12]
        else:heads=S|{12+j for j in codes[s-top]}
        B|={(s,t)for t in heads}
        if 12<=s<n:optional|={(s,t)for t in range(top,n)if s!=t}
        if s in H-R:optional|={(s,t)for t in range(top,n)}
        if s>=top:optional|={(s,t)for t in H-(T|S)}
    assert not B&optional and all(s!=t for s,t in B|optional)
    A=106+18*g+12*b+sum(map(len,codes));cap=b*(g+b+8)
    assert (len(B),len(optional))==(A,cap)
    out=[{v for u,v in B if u==s}for s in range(n)]
    closed=[{s}|{v for u,v in B|optional if u==s}for s in range(n)]
    obligations=ghost=0
    for t in range(n):
        ranks=[]
        for s in range(n):
            if s==t:r=0
            elif t in out[s]:r=1
            elif s>=top:r=5
            elif t<12:r=2
            elif s in {0,5}:r=2
            elif s in {8,11,14,15,16}:r=3
            else:r=4
            ranks.append(r)
        for s in range(n):
            if ranks[s]<=1:continue
            earlier={u for u in out[s]if ranks[u]<ranks[s]}
            earlier&=H if s<top else set(range(top))
            for c in range(n):
                if c!=s:
                    assert earlier-closed[c],(g,b,t,s,c)
                    obligations+=1
            if s<top:
                # Ghost can occupy an extra vertex and reach every outside
                # vertex and all nine unsafe hubs. Only T stays safe.
                ghost_closed=(H-T)|set(range(12,n+1))
                assert earlier-ghost_closed,(g,b,t,s,'ghost')
                ghost+=1
    return dict(n=n,g=g,b=b,W=sum(map(len,codes)),m_interval=[A,A+cap],
                full_target_rank_obligations=obligations,ghost_obligations=ghost)


def entry_checks():
    count=0
    missing=[{6+i,6+(i-1)%6}for i in range(6)]+[{(i+4)%6,i}for i in range(6)]
    assert {c for c in H if missing[c]&S}==R
    for g in range(2,8):
        all_codes=[set(q)for r in range(2,g+1)for q in combinations(range(g),r)]
        for J in all_codes:
            for guide_cop in range(g):assert J-{guide_cop};count+=1
            for other in all_codes:
                if not(J<=other or other<=J):assert J-other;count+=1
    return count


def main():
    started=time.monotonic();before=hashes()
    literals=json.loads((ROOT/'research/six-circle-recipes.json').read_text())['rows']
    circle_checks=[replay_circle(r)for r in literals]
    periods=periodic_rows();periodic_checks=[replay_circle(r,False)for r in periods]
    # All-target boundary samples exercise both periodic formulas independently
    # of translation symmetry, including h near the largest allowed value.
    samples=[]
    for n in [20,25,40,45,60,65,80]:
        candidates=[r for r in periods if r['n']==n]
        for p in [4,5]:
            matching=[r for r in candidates if r['period']==p]
            if matching:
                for r in [matching[0],matching[-1]]:
                    c,o=replay_circle(r);samples.append(dict(n=n,h=r['h'],period=p,obligations=o))
    hub_records=[]
    for g in range(2,8):
        hub_records.append(hubs(g,[]))
        for r in range(2,g+1):
            hub_records.append(hubs(g,[set(q)for q in combinations(range(g),r)]))
    mixed=[{i,6}for i in range(6)]+[set(q)for q in combinations(range(6),3)]
    hub_records.append(hubs(7,mixed))
    for g,b in [(5,8),(5,10)]:
        hub_records.append(hubs(g,[set(q)for q in list(combinations(range(g),2))[:b]]))
    after=hashes();assert before==after,'Sources changed during independent review'
    report={'passed':True,'scope':'ordinary proof review plus independent literal reconstruction and full-envelope source-rank replay; no producer imports',
            'circle_literal_rows':len(literals),'circle_literal_escape_checks':sum(x[0]for x in circle_checks),
            'circle_literal_all_target_rank_obligations':sum(x[1]for x in circle_checks),
            'periodic_parameter_rows':len(periods),'periodic_escape_checks':sum(x[0]for x in periodic_checks),
            'periodic_all_target_samples':samples,'hub_reconstructions':hub_records,
            'bulk_entry_set_checks':entry_checks(),'source_sha256':after,
            'reviewer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'seconds':round(time.monotonic()-started,3)}
    (ROOT/'research/main-interval-fifth-ordinary-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in ['periodic_all_target_samples','hub_reconstructions','source_sha256']}))

if __name__=='__main__':main()

# Exceptional small orders: research record

## Established checkpoint

* `M_V(7)=21`: two independent exhaustive static-obstruction enumerations,
  with complete ordinary reductions in `paper/small-orders-resume.md`,
  Theorem46. Primary3.97s, independent12.91s. They inspect109,941,961 and
  123,280,819 partial nodes respectively; both leave4,299,624 complete
  graphs before final pair counting and find no possible I>=22.
* No universally winning two-in/two-out regular digraph at any n7..11:
  two complete independent permutation-factor enumerations, identical
  locally admissible leaf counts0,0,535,35610,120302. Primary and
  independent game attractors differ. The known12vertex graph passes
  every primary incremental prune as a positive control.
* Therefore n12 is the first nontrivial equality order for n(n−3).
  This is NOT the first noncomplete universally winning graph: n7 has one.
* `M_V(8)=32`: complete primary and independent canonical enumerations,
  described below, with separately audited symmetry/pruning arguments.
* The remaining intervals are48≤M_V(9)≤53,62≤M_V(10)≤69, and
  84≤M_V(11)≤87. Only these three small vertex orders remain unresolved.
* Additional complete reductions give M(11,22)≤81 and M(11,23)≤81;
  proofs, independent audit, and failed m24/25 follow-ups are recorded in
  `research/small-exceptional-profiles.md`.
* `research/small-exceptional-verification.json` hashes all theorem-critical
  sources/receipts. All five saved full rank certificates were directly
  replayed, and both game solvers freshly recomputed their guarantees.

## Failed approaches and computational evidence

1. Contracting vertices of a universal12 graph does not preserve delivery.
   Best greedy contractions down to n11..7 gave I71,43,24,17,9, with arc
   counts22,20,19,16,15; none universal. Exact arcs saved in
   `small-exceptional-contractions.json`; source
   `src/small_exceptional_contract.py`.
2. Bounded unrestricted arc-toggle annealing,3seconds per order, found
   universal graphs at n7..11 with m21,24,26,28,31. These are lower
   witnesses only. Source `src/small_exceptional_search.cpp`, outputs
   `small-exceptional-general-search.json`, full verified strategy arrays
   `small-exceptional-general-certificates.json`.
3. Degree-two nonattainment is not a proof of exact M_V at n8..11.
   Denser irregular graphs may win more indirect pairs than any failed
   degree-two design; the upper-bound rigidity only excludes equality.
4. Parent suggested smoothing a vertex separately in the two permutation
   factors of a universal12 graph, then repairing by a few extra arcs or
   local rewiring. The successful bounded result is recorded below.

## Reproduction

Compile the four `small_exceptional_*.cpp` exhaustive sources individually
with a standard C++17 compiler and optimization. For n7 static decision,
run `small_exceptional_n7_exact 45` and
`small_exceptional_n7_independent 55`; both must report complete true and
zero survivors. Run the regular and independent enumerators with each
n7..11 and a55second limit; every run completes well within one second.
Do not treat a timed-out run as a proof. No results in this record are
new Lean formalizations; the existing actual-game Lean development is
unchanged.

## Structured repair improvement

Smoothing one to three vertices independently in two permutation factors
of the finite universal12..14graphs provided2,735 seeds across orders9..11.
A20second n11 anneal improved the universal witness from31 to26arcs, hence
I84 rather than79. Both full solvers agree, and the saved ranks were directly
replayed in `small-exceptional-structured-11-certificate.json`. The maximum
delivery bound is12moves. This is a finite construction, not a general
smoothing-preservation theorem. Theorem46 and the receipt now use I84.

The root agent extended the factor-smoothing seeds through oldorder16,
and found a universal24arc n9graph (I48) in15seconds. Its independently
checked certificate is `root-small-structured-9-certificate.json`; these
ranks were also replayed here before updating Theorem46.

## Canonical n8 milestone

Primary canonical enumeration completed178outdegree profiles in44.985s:
946,676,955nodes,22,465,453completeleaves,373static-pair survivors, all
exactgame-rejected with bestI17. Therefore M_V(8)=32, subject to the
ordinary canonicalization reduction independently approved by
proposal_check in `small-eight-canonical-independent-audit.md`. That
audit also canonicalized every4vertex labeledgraph inbothprefix/suffix
conventions,8,192checks. At that stage, the independent descending/suffix enumeration
was being completed in bounded intervals; its timeouts were not used as
complete proof receipts. Only explicitly completed profile ranges count.

### Eight-vertex independent completion

Independent suffix search now has two COMPLETE interval receipts:
`small-exceptional-canonical-independent-8-prefix.json` covers0..159
(45.35seconds) and `small-exceptional-canonical-independent-8-c.json`
covers160..177(28.80seconds). Total1,179,975,770nodes,63,717,034leaves,
1,115static survivors, all rejected by the explicit queue attractor;
best I17. Counts differ from primary because degreeorder/canonical
convention change multiplicities. Thus M_V(8)=32 is independently
verified, and Theorem46+hashreceipt have been updated. The older incomplete
receipts are merely progress records and are NOT used in the proof.

The n9 lower48 reduces a candidate improvement to target49 and budgets
18..23. The bounded50second primary canonical decision run was incomplete
and supplied no new upper theorem. Subsequent capacity, matching, and
symmetry reductions are fully consolidated in
`research/small-exceptional-profiles.md`. No search process remains running.

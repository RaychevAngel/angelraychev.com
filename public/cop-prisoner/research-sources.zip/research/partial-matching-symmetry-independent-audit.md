# Independent audit of partial-matching symmetry reduction

2026-09-12. Source reviewed: `src/small_exceptional_partial_matching_symmetry.cpp`.
Scope: n=11, m=24 or25, and counterexample target I>=85. This is a
reduction/source audit, not a completed enumeration or a new upper
theorem. The owning agent reports only partial bounded runs.

## Matching normal form

With all incoming and outgoing degrees at least two and m=2n+E,
Hall deficiency is at most floor(E/2): a tail set S sends at least
2|S| arcs into N(S), whose total incoming capacity is at most
2|N(S)|+E. For E<=3 there is therefore a matching of size at least
n-1. Select exactly n-1 matching arcs, discarding one if necessary.
As a directed graph this matching has one incoming and outgoing arc
at most at each vertex. It is a union of directed paths and cycles;
n-1 arcs force exactly one path component, counting an isolated
vertex as a path of length zero. All cycles have length at least two.

The normal form used by the source, one path 0->1->...->endpath
followed by sorted cycle lengths, covers every such matching.
The matching centralizer fixes the path pointwise and independently
rotates cycles and permutes cycles of equal length. The implemented
permutations enumerate exactly this group.

## Row-wise canonical extension

At entry to row r the retained subgroup fixes each vertex through r
and preserves every previously completed outgoing row. It therefore
acts on possible added outgoing masks at row r, fixes its prescribed
matching arc, and does not change any earlier decision. Every orbit
has a least integer mask. Requiring that representative is complete:
apply a minimizing group element to the entire remaining completion.

After selecting the mask, retaining its setwise stabilizer and then
fixing r+1 gives exactly a subgroup with the same induction property
for the next row. Identity survives every filter; hence a subgroup
with one element is identity, justifying the source's shortcut in
that case. Unassigned degrees need not be individually fixed: the
search permits every allocation of the remaining extra-arc budget,
which the relabeling preserves. Cycle-to-cycle symmetries never move
a path vertex.

## Other pruning at the requested threshold

The maximal final indegree expression correctly subtracts both the
forbidden loop and any incoming matching arc already counted from an
unassigned tail; those tails are distinct because matching loops are
absent. Partial excess above indegree two cannot exceed E.

For n=11, E=2 or3, target85, no final source or predecessor camping
obstruction is possible: even its smallest lost row or column costs
more than the one or zero missing pairs that may fail at this target.
Every currently covered predecessor set of size at least two must
therefore acquire at least one incoming arc outside its witnessing
cop's final closed neighborhood. Such an addition uses one extra
indegree unit in that column. Distinct columns use distinct units,
which proves the implemented b=0 bound
dominated_columns <= E-current_indegree_excess.

The source-camping tests only reject completed messenger rows already
covered by a current cop neighborhood; subsequently enlarging that
neighborhood cannot undo the obstruction. The reverse comparison
uses an earlier completed row, so it is safe too. The remaining row
enumeration assigns exactly one baseline added arc, or two at the
path's missing-outgoing endpoint, plus every permitted extra count.

No assertion about the more general nonzero-b repair expression, or
about a completed search beyond these parameter values, is needed
for this audit.

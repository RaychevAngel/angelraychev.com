# Independent audit of the odd six-type endpoint family

## Verified conclusion

For every integer `q>=15`, there is a graph on `n=6q` vertices with
`2n-1=12q-1` arcs and exactly `(n-2)(n-3)` guaranteed indirect pairs.
Thus

`M_E(12q-1)=(6q-2)(6q-3)`.

This is an infinite residue class of odd budgets, not yet an all-odd-
budget statement. It uses finite local rank certificates and the
ordinary cyclic projection below. No new Lean coverage is claimed.

## Independently rebuilt graph and games

There are six types per integer column. The first permutation follows
the Hamilton order `(i,0)->...->(i,5)->(i+1,0)`. The second sends types
to `[0,2,5,1,4,3]` with column displacements `[-1,-1,1,1,-1,1]`.
Delete the single arc `(0,0)->(0,1)` of the first permutation.

Write `u=(0,0)` and `v=(0,1)`. Only `u` has outdegree one, only `v`
has indegree one, and all other incoming and outgoing degrees are two.
The deleted arc `u->v` is absent. At circumference at least 15 the
explicit formulas produce no loops or repeated arcs.

`src/six_type_independent_odd.py` reconstructs this graph directly,
without importing the primary graph builder or primary solver. It
builds local arenas with messenger columns `[-4,4]` and cop columns
`[-6,6]` plus `Omega`. The latter may wait or reenter any vertex of
columns `-6,-5,5,6`. The arc defect is either absent locally or situated
at each translated column `-6..6`, giving 14 local patterns.

The transfer objective has source column `-1`, excluding `u` when
present there. Its terminal set is column zero excluding `u`, and is
seeded only on a noncollision messenger turn after the cop response.
Each delivery objective starts in column `-2`, again excluding `u`,
and targets an existing column-zero type other than `v`. Receipt
succeeds immediately on either turn, even on collision at the target.
Other collisions lose.

There are 97 local objectives. The independent explicit AND/OR attractor
followed by the full rank checker verified **44,850 required starts**
and **827,604 alternating states**. Every required state wins. The
maximum bound is 14 messenger moves for transfer and 26 for delivery.
The checker validates chosen winning moves, every cop response, all
terminal conditions, and the full losing-region closure.

Full ranks and chosen moves are in
`research/six-type-independent-odd-certificates.json.gz`; the summary
and source/certificate hashes are in
`research/six-type-independent-odd-summary.json`.

## Cyclic interpretation and composition

Reduce columns modulo `q>=15`. Each 13-column cop window is injective
and sees either the unique defect or no defect. The deleted arc stays
within one column, so an outside defect cannot modify an internal
move. Every original arc has column displacement at most one. The
chosen exterior representation with two reentry layers is therefore
conservative. At circumference at least 15 no internal cop move can
cross the exterior interval directly to the opposite displayed boundary.

Map every real exterior cop position to `Omega`. Internal moves and
collisions are represented exactly; exterior behavior is overapproximated
by `Omega`. Messenger moves retained by the local arena are real moves.
Thus local winning strategies lift to the cyclic graph.

Take any source other than `u` and any recipient other than `v`.
Repeated safe transfers move the messenger one column forward and
always finish at a vertex other than `u`, on a safe messenger turn.
After at most `q-1` such phases the messenger is two columns before
the recipient. The delivery certificate then applies, including its
source exclusion. The recipient itself may be `u`; immediate receipt
then succeeds normally. Conversely, the source may be `v`, which still
has outdegree two and is a permitted starting point. These roles must
not be confused with the excluded source row and recipient column.

Every eligible pair is therefore guaranteed within

`14(q-1)+26=14q+12`

messenger moves. Earlier arrival at the real recipient during a
transfer only shortens the strategy.

## Exact indirect-pair count

No indirect pair can have source `u`, by camping at its unique outgoing
neighbor. No indirect pair can have recipient `v`, by camping at its
unique incoming neighbor. Every other source-recipient pair is covered
by the preceding composition.

The eligible rectangle has `(n-1)^2` pairs and `n-2` diagonal pairs.
The unique arc leaving `u` and the unique arc entering `v` are distinct
because `u->v` is absent. Hence exactly `(2n-1)-2=2n-3` direct pairs
lie in the rectangle. The guaranteed missing count is

`(n-1)^2-(n-2)-(2n-3)=n^2-5n+6=(n-2)(n-3)`.

With `2n-1=2(n-1)+1`, the proved odd arc upper bound is
`(n-1)(n-4)+2`, which is the same number. This proves equality over
arbitrary graph orders at the stated budgets.

# Finite cyclic completion of the sparse optional interface

13 September 2026. Active bounded construction work; this note belongs to the
sparse-interface lane. Central scope/coverage records are updated by the root.

## Aim and distinction

The first target was the unresolved `n=114, m=229..341` interval. Theorem52's
specified six-type construction already has enough optional arrows here; its
old cop-window projection requires `k>=20`, whereas this ring has `k=19`.
The finite cyclic game models all actual vertices and every wrap-around move.
It neither adds an artificial exterior jump nor silently omits a real reply.

The second issue is capacity. With `n=6k-r`, the old optional count is `8k-9r`;
reaching `3n` requires `k>=4r`. At `n=109`, proving all existing optional arrows
safe still reaches only325 arrows, two below327. Better ranks cannot add arrows.

## Construction and finite-certificate proof

Use exactly Theorem52's two permutation rules, smooth through deleted type4
vertices at columns `0,3,...,3(r-1)`, and retain the same eight optional types
and seven relative exclusions. The producer reconstructs the two permutations
first and then removes vertices from each permutation cycle. Its independently
written checker instead reconstructs every source-type arrow directly.

Let `B` be the compulsory graph and `E` its union with every allowed optional
arrow. Consider the stronger asymmetric game in which the messenger uses only
`B` (or waits) while the cop uses `E` (or waits). A positional messenger rank
certificate supplies, for every nonterminal noncollision state `(s,c)`, a legal
compulsory successor `u`. Either `u` is the recipient, ending immediately, or
`u!=c` and every cop successor `c'` is distinct from `u` and has a strictly
smaller nonnegative messenger rank at `(u,c')`. Thus delivery terminates against
every cop strategy. The same policy works for every `B subseteq G subseteq E`:
its compulsory messenger moves are available and the actual cop has no additional
responses. Every budget from `|B|` to `|E|` is obtained by the corresponding
lexicographic prefix of optional arrows.

These are proofs of specified finite envelopes, not successful simulations or
extrapolations to an infinite family. The existing ordinary Theorem52 continues
to supply the infinite tail. The finite certificates can lower that theorem's
construction threshold only on their explicitly listed domains.

For graphs without deleted vertices, simultaneous one-column translation is
an exact automorphism of both `B` and `E`. The independent checker verifies
this identity on the complete arrow sets, so six target types at column zero
suffice. With holes, every literal recipient is certified separately.

## First verified result

At `n=114`, `B` has228 arrows and `E` has380. All six representative targets
have saved full ranks and policies. The primary checker checks155952 explicit
messenger/cop state obligations. The independent checker ignores the saved cop
ranks and directly checks77976 messenger states and326118 cop replies against
its separately reconstructed graph. Its largest messenger rank is66.

Consequently every `228<=m<=380` has an explicit universally winning graph,
so `M(114,m)=114*113-m` throughout that interval. In particular it fills the
previously recorded229..341 low-budget gap. This is ordinary computer-assisted
mathematics; no new Lean theorem is asserted.

## Reproduction and evidence

- `src/sparse-interface-third.py`: graph generator, bounded exact cyclic game,
  primary rank replay and per-order compressed certificate output.
- `src/sparse-interface-third-independent.py`: no project imports; independent
  literal graph construction, actual rotation verification and collapsed-round
  rank proof replay.
- `research/sparse-interface-third-certified.json`: per-order results, exact
  compulsory/optional counts, failures and certificate identities.
- `research/sparse-interface-third-certificates.zip`: the named order114 member
  retains the first complete finite proof artifact; all positive records are now bundled.
- `research/sparse-interface-third-independent.json`: independent replay receipt.

A preliminary screen of85..114 passes every order except91. The failure at91
is in the stronger asymmetric game for recipient `(15,4)`; it does not prove
that the common graph with all optional arrows is losing, because that graph
also grants the messenger the optional arrows. The screen is being expanded
only over the finite lower-order domain, with retained certificates for positive
results and explicit failures for negative results.

Known failed arbitrary-hole and cover extensions were not retried. No claim
is made that either failure proves an unknown extremal value is smaller.


## Completed first finite checkpoint

The retained positive domain is
`{60} union [64,66] union [68,72] union [75,78] union [80,90] union [92,114]`.
There are47 envelopes; all have exact interval `2n..20k-11r` and maximum
certified messenger rank at most72. Every saved certificate passed both the
primary replay and the separate no-project-import direct round replay. The
primary records cover59779830 explicit-turn state obligations. The per-order
compressed artifacts total30927586 bytes. The ordinary finite-supplement proof
is included in `paper/sparse-packed-holes.md`.

Below60 the prescribed full optional envelope did not pass in any tested
admissible canonical instance. Orders where the canonical holes are not
cyclically separated by three were rejected as outside this recipe, not as
mathematical failures. Actual negative B/E records remain in the summary.
No upper-bound exclusion is inferred from them.

The initial opportunity is therefore real but bounded: existing graph formulas
already work substantially below the old proof threshold. Capacity still leaves
the listed shortfalls, and the B-only/E-cop certificate still genuinely fails
at91. The next bounded experiment attempts to restore just two of the suppressed
optional arrows at109, retaining literal finite additions if it succeeds.


## Order109 repair and package consolidation

The bounded lexicographic reinsertion experiment found two safe fixed additions
in8.8seconds: `(1,3)->(4,0)` and `(2,3)->(18,5)`, in column/type coordinates.
At109 these lift the exact optional capacity from107 to109. Every recipient
then passed full rank generation and direct replay; the separate checker
confirmed1295029 messenger states and4991328 cop replies. The maximum rank
remains72. Thus every218..327 is explicitly attained, including both capacity
shortfall budgets. The failed reinsertion candidates and exact first losing
states remain in `research/sparse-interface-third-repair109.json`.

All47 canonical records and this one extension are consolidated in
`research/sparse-interface-third-certificates.zip`, with exactly48 named members
and a manifest. The single external registry is
`research/sparse-interface-third-proof-registry.json`. Split certificate files
are removed only after hash-preserving package verification. The existing
older research certificates are untouched. Check the exact fixed order/variant
inventory, every recipient requirement and all saved ranks with:

```
python3 src/sparse-interface-third.py --check research/sparse-interface-third-certificates.zip
python3 src/sparse-interface-third-independent.py research/sparse-interface-third-certificates.zip
```

The first checker uses explicit two-turn ranks. The independently written second
checker reconstructs literal source-type arrows and checks actual cop replies
after each compulsory move; it does not import the first checker or a solver.
Neither command generates graphs through a search or recomputes an attractor.
The finite supplementary proof and fixed109 additions are in
`paper/sparse-packed-holes.md`. The109 repair makes the full low interface
`2n..3n` complete at every108..114, independently of the main-interval circle/code
work being handled in the root lane.

# Independent audit of the all-order sparse-budget bridge

## Conclusion

The optional-arc six-type construction proves, for every `n>=2419` and
every integer budget `2n<=m<=3n`,

`M(n,m)=n(n-1)-m`.

This statement uses finite local rank certificates plus the ordinary
projection and counting proof below. It is not a Lean formalization.
The optional-arc construction was proposed by the parent researcher;
the graph and arena were independently reconstructed and every local
game was verified using the separate explicit-state checker.

Together with Theorem 38 and Corollary 39, this fills the remaining
sparse gap and proves the entire main-interval conjecture

`M(n,m)=n(n-1)-m`, `2n<=m<=n(n-3)`,

for every sufficiently large `n`. The asymptotic threshold for the
complete main interval also includes the threshold in Corollary 26;
it is not asserted to be 2419. The standalone sparse bridge itself has
the explicit threshold 2419.

## Optional moves and independent local arenas

Use the six-type family and smoothing operation in
`research/six-type-independent-proof.md`. The optional moves are given
as `(source type, column displacement, target type)`:

```
(1,-3,5), (3,-3,5), (4,-3,0), (4, 3,1),
(2, 3,0), (3, 3,0), (3,-3,0), (5,-2,0).
```

They are pairwise distinct at each column and differ from the original
two moves. Their target types are never four, so no optional endpoint
is a deleted vertex. They create no loops at the stated circumferences.
The messenger continues to use only the original smoothed moves; the
cop is allowed all applicable optional moves in the stronger arena.

The messenger window is `[-4,4]`, and the cop window is `[-8,8]` plus
`Omega`. The latter may wait or reenter **any existing vertex** of
columns `-8,-7,-6,6,7,8`. Three reentry layers account for the optional
displacements of magnitude three.

There are two kinds of arenas:

1. No local hole, and every cop optional move is allowed.
2. Exactly one hole at column `h` for each `-8<=h<=8`, and no optional
   cop moves from inside the window. The exterior `Omega` still has
   all three reentry layers.

As before, safe transfer starts in column `-1` and ends only on a
noncollision messenger turn in column zero. Delivery starts in column
`-2` and has immediate receipt at each existing target type in column
zero. This yields `18*7-1=125` local objectives.

The independent code `src/six_type_independent_augmented.py` does not
import any primary arena or primary solver. It builds the moves and
uses the independent explicit AND/OR solver, followed by verification
of every rank, chosen messenger move, universal cop response, and
losing-region closure. All **75,085 required starts** and **1,365,108
alternating states** passed. Maximum bounds are nine messenger moves
for transfer and 35 for delivery. The largest delivery bound arises
in the augmented no-hole arena; the single-hole cases need at most 26.

Full certificates and source hashes are in
`research/six-type-independent-augmented-certificates.json.gz` and
`research/six-type-independent-augmented-summary.json`.

## Placement and suppression of optional arcs

Let `k>=404` be the circumference and let `0<=r<=5` vertices of type
four be deleted at columns

`0,17,...,17(r-1)`.

Their cyclic separation is at least 17. Suppress every optional arc
whose tail column has cyclic distance at most 16 from at least one
deleted column. Retain any chosen subset of the remaining optional
arcs.

Every cop window of 17 columns has at most one hole. If it has a hole,
each tail column inside that window is at cyclic distance at most 16
from the hole, so it has no optional outgoing arc. Its actual moves
are contained in the corresponding single-hole arena. If the window
has no hole, its actual optional moves are a subset of those in the
augmented no-hole arena. This proves the required local dichotomy.

An exterior hole can modify an internal boundary arc only by changing
an exterior endpoint, as in the unaugmented projection proof. Every
actual arc has column jump at most three. At circumference `k>=20`,
such an arc cannot jump directly from one displayed cop boundary to
the other across the exterior gap: that would require displacement
at least `k-16>=4`. Every exterior reentry is therefore represented by
one of the three `Omega` layers. The construction uses the much larger
`k>=404`, so this requirement is satisfied.

All messenger moves used by a certificate remain actual base moves.
Collisions and delivery priority agree under the projection. Thus the
local certificates compose to guarantee every source-recipient pair,
for every choice of a subset of the permitted optional arcs. As usual,
at most `k-1` safe transfers followed by delivery suffice, here within
`9(k-1)+35=9k+26` messenger moves.

## Exact arc budget

There are eight candidate optional arcs at each undeleted column
before the suppression rule. For `r>=1`, the union of all suppressed
tail columns is contained in the cyclic image of the integer interval

`[-16,17(r-1)+16]`,

whose length in vertices is `17r+16<=101`. The overlapping forbidden
neighborhoods must be counted as a union, rather than as five disjoint
33-column sets. For `r=0` no optional arcs are suppressed.

At most `8*101=808` candidates are lost. Every deleted tail vertex is
inside this suppressed set, so it produces no additional uncounted
loss. At least `8k-808` distinct optional arcs remain. Since `k>=404`,

`8k-808 >= 6k >= 6k-r`.

For an arbitrary `n>=2419`, set `k=ceil(n/6)>=404` and
`r=6k-n<=5`. The smoothed base has `n` vertices and exactly `2n` arcs,
and there are at least `n` permitted optional arcs. Selecting exactly
`m-2n` of them supplies every integer budget `2n<=m<=3n`. Universality
follows from the same stronger cop arenas for every selection. Hence
all `n(n-1)-m` missing pairs are guaranteed, giving equality.

## Pitfalls explicitly excluded

- The no-hole certificate is asymmetric: the messenger uses only the
  original moves, while the cop has all optional moves. This is why
  arbitrary subsets of optional arcs are allowed.
- A window containing a hole uses a different certificate. The fully
  augmented near-hole arena was not assumed to pass.
- Suppression depends on the **tail** column of an optional arc, and
  its radius is 16, the maximum distance between a hole and any tail
  in a common 17-column cop window.
- The exterior state still has three reentry layers in near-hole
  arenas, because actual exterior cop moves can remain augmented.
- The cyclic final gap between holes, exact vertex count, candidate
  arc distinctness, and possible deleted tails are included in the
  count. No periodicity of the selected subset is required.
- The full main-interval conclusion uses an additional asymptotic
  overlap theorem. Its common large-order threshold is not inferred
  merely from the sparse bridge's explicit value 2419.

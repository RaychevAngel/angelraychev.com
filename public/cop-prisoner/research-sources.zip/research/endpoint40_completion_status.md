# Endpoint worker completion checkpoint

13 September 2026. All assigned endpoint and order-eight main-interval decisions are complete. No canonical registry, paper, or handoff was edited by this worker. No process is running.

## Exact results and entry points

- **M(8,40)=12.** Independent ordinary/source review, two separate complete enumerations, full literal negative/lower ranks. Final independent receipt: `research/finish-endpoint40-review.json`; complete proof: `research/endpoint40_exact_proof.md`; literal lower: `research/endpoint40_lower12_certificate.json`. The proof note's dated pending-review language is superseded by the independent review receipt.
- **M(8,35..38)=(19,18,16,15).** Primary complete positive-profile exclusions, independent full traversal, and full literal ranks. Final independent receipt: `research/finish-n8-review.json`; worker replay receipt: `research/endpoint40_n8_high_receipt.json`; fixed lowers: `research/endpoint40_n8_high_lower_certificates.json`.
- **M(8,17..23)=(19,21,22,24,25,28,29).** Complete source-reviewed profile exclusions and every literal surviving graph replayed independently. Final receipt: `research/endpoint40_n8_low_receipt.json`; source/coverage proof: `research/endpoint40_n8_low_proof.md`; all seven lower graphs with full ranks: `research/endpoint40_n8_low_lower_certificates.json`. The conditional opening in the proof note is now discharged by the completed receipt.

The low-band independent compressed solver replayed all **1,512,673** emitted literal survivors. It checked every producer score and exact graph budget; independent profile counts and completed profile intervals cover every required profile. The m20 timeout pilot is historical and unused: completed head[0,118) plus tail[118,119) supplies the actual exclusion.

Combined with the construction agent's certified m27..34 missing-pair attainers, this finishes all20 original main-interval gaps at order eight. It does not itself finish the remaining order-nine/order-ten main gaps or the order-eight sparse cells14..16.

## Independent reviews for the parent

`research/endpoint40_tiny_live_review.md/.json` approves the parent live-prune additions and both completed budget12 and budget13 exclusions. It independently checks source equality of inherited components, counts65 and88 profiles, verifies the disjoint complete budget13 head/tail, and checks the actual new prunes on all graphs through order4, 2,400 random larger graphs, and86 fixed literal graphs. All6,651 tested graphs and44,376 prefixes pass, including662,312 specific camping states. This is source/coverage review and adversarial testing, not a second full n12/n13 graph traversal.

All source pins in the endpoint, upper-band, low-band and tiny-review receipts were checked again at this checkpoint and match. The exact finite computations are external evidence with ordinary proofs; no new Lean formalization is claimed.

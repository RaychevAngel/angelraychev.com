# Independent audit of the follow-up results

Date: 12 September 2026.

Scope: a bounded independent proof and publication-claim review of the
three discussion notes listed below. No new exhaustive enumeration,
literature search, Lean development, manuscript edit, or website edit was
performed for this audit.

## Verdict

The stated new mathematical results pass this independent review. The
full large-order interval down to `m=2n` remains a conjecture. The proved
probabilistic interval has an unspecified sufficiently-large-order
threshold. The sharp final-band construction has the explicitly stated
finite structural-certificate dependency for core orders 52 through 129.
None of these new results is claimed as a new Lean theorem.

## Sources reviewed

SHA-256 hashes identify the note versions audited:

| Source | SHA-256 |
|---|---|
| `research/2026-09-12-full-density-conjecture.md` | `9f07a6cc07dc5f4c4e74bffe4d8a34c9c60603ab240955e623a35fb513ebbd79` |
| `research/2026-09-12-final-dense-band.md` | `433157d2772211b3eecabaac86b5fb6586123e4c9bd1a2af81779c8004ddaf3a` |
| `research/2026-09-12-strategy-discussion.md` | `1be501d5b6efa76099223a7946b614c742691405fe35041b9f8450f55c7d7545` |

The review also checked the referenced functional construction in
`research/extremal-bounds.md` and Theorems 19--20 in
`paper/dense-extensions.md`. The latter had hash
`82a35e6623fa277dbabe5aa2b40f65e39d9a5979617b328b1047b5b0dfaa862f`.

## Exact-budget probabilistic result

For each triple `(s,t,c)` with `s!=t` and `c!=s`, a candidate intermediate
`u` outside `{s,t,c}` uses the distinct arc variables `s->u`, `u->t`, and
`c->u`. They remain distinct when `c=t`. The variable sets for different
candidates are disjoint: a possible cross-identification would require a
candidate to equal `s` or `c`, or require `s=c`, all of which are excluded.
Thus the probability calculation `p^2(1-p)` and independence across at
least `n-3` candidates are valid. The final union bound is over fewer than
`n^3` triples. Direct and diagonal pairs cause no extra difficulty.

For `L=n(n-1)` and `0<m<L`, taking `p=m/L` makes `m` a binomial mode.
The two successive probability ratios displayed in the note establish
this directly. Therefore `P(|E|=m)>=1/(L+1)>n^(-2)`. Under the stated
exponent hypothesis, the total bad-event probability is less than
`n^(-2)`, so some good graph really has exactly `m` arcs. No assumption
of independence between the bad event and the edge count is made or
needed. This is an ordinary existence proof, not a numerical experiment.

The lower-density estimate with constant 10 and the upper-density
estimate with missing-arc threshold `100 n log n` both exceed the needed
`5 log n` exponent for sufficiently large `n`. Here logarithms have
their usual natural-logarithm meaning.

For the overlap argument, set `D=floor((n/2)^(1/4))`. For sufficiently
large `n`, the hypotheses `5<=D<=n-1` hold, and
`B_D<=D^4<=n/2`. Substitution in Theorem 20 gives
`L_D(n)>=n(D/4+1)-1`, as used. Since `n^(1/4)/log n` tends to infinity,
this endpoint eventually exceeds `100 n log n`. Both component theorems
cover integer intervals, and their overlap leaves no omitted budgets.
The common threshold `N` can be chosen to satisfy all these conditions;
neither a numerical threshold nor moderate-order coverage is asserted.

Consequently the ordinary proof establishes, for every sufficiently
large `n` and every integer budget in the stated interval,

`M(n,m)=n(n-1)-m`,

with a two-move strategy. Its lower endpoint remains of order
`n^(3/2) sqrt(log n)`, not `2n`.

## Growing losses in the final dense band

The proof distinguishes the case `I=0` correctly and uses positivity
only to infer that every missing outdegree is at least one. The count
`ell>=2n-h` has the right inequality direction.

Every image of a degree-one missing row is a killed source, with a
legal initial cop because the missing graph has no loops. Duplicate
images also kill the corresponding missing edges from their distinct
preimages. In the subsequent count, losses whose tails lie in `L` and
those whose tails lie in `U\L` are disjoint. The estimate
`D>=ell-rho+2b` therefore does not count the same pair twice.

For `b>=1`, the two bounds on `rho` and the ceiling arithmetic are
correct. For `b=0`, the finite loopless functional graph on `L` contains
a cycle of length at least two. Its vertices already receive from `U`
and cannot also be unique images of members of `R`. Hence `rho<=a-2`
is justified. The resulting inequality is valid throughout the
admissible range `n<=h<2n`, including `n=2` and `I=0`.

The endpoint `h=n` reduces to `floor((n-2)/2)` as claimed. The loss
sequence `2,2,3,3,...` is indexed by `r=2n-h`, not by increasing `h`.

## Joining blocks and attaining the bound

The join lemma uses **two-move** winning strategies, and its proof
requires this. After the cop leaves the original block, the messenger's
very next move is already the final delivery, which has priority over
collision and any further response. This argument does not preserve
arbitrary longer strategies.

For an external initial cop, a missing outneighbor in that cop's own
block exists by the positive-missing-outdegree hypothesis. That vertex
is distinct from the cop, source, and recipient and supplies the safe
cross-block intermediate. Thus the external-cop case is also complete.

The explicit functional block uses exactly `r` vertices and `r`
missing arcs for both parities of `r`, including `r=2,3`. Its
`floor((r-2)/2)` claimed pairs have the required two-move proof. The
large block has `k` vertices and `2k` missing arcs. Combining the counts
with the growing-loss upper bound proves equality without needing to
classify every other pair in the join.

The construction works uniformly when `k>=52` and `r>=2`, equivalently
`n+52<=h<=2n-2`; this interval is nonempty exactly when `n>=54`.
The referenced ordinary construction supplies every core order
`k>=130`. Core orders 52 through 129 rely on the previously supplied
finite structural certificate, not on extrapolation of game searches.
The existing receipt reports all 79 orders from 52 through 130 verified
by an independent graph verifier. That receipt was inspected, not rerun
in this bounded audit.

The separate 26-vertex incidence block is also a valid two-move core.
The five-type complement has a three-move exceptional state and is
correctly excluded from automatic use in this joining lemma. This audit
does not certify the unresolved first step `r=1` or the remaining small
offsets by that construction.

## Other discussion results

The set-valued-map/permutation equivalence follows from alternating
edge colors on the bipartite incidence cycles. The terminal-block
construction has the stated arc capacity and fills every intermediate
integer budget; no unsupported exact count is asserted for partial
fillings. Single-predecessor sink padding preserves `I` exactly.

The odd-budget eligible-pair count correctly distinguishes killed
source rows from killed recipient columns. The commuting-permutation
obstruction respects the forbidden initial cop position and immediate
receipt timing, and the seven-vertex sharp example has a full elementary
proof. The stationary-separator criterion is explicitly sufficient
only; its five-vertex counterexample to completeness has a correct
elementary moving-cop strategy.

The attribution statements preserve Angel and Alexandra's original
upper bound and two-regular research direction and Angel's terminal
and sink proposals. No authorship decision is introduced by this audit.

## Lightweight checks performed in this audit

1. Read the existing exhaustive tables for orders 2 through 6 and checked
   the new growing-loss bound against all 19 entries in their admissible
   final dense bands. All passed. The exhaustive enumeration itself was
   not repeated; this is a check against existing finite evidence.
2. Constructed the explicit functional blocks for every order 2 through
   30 and directly checked the safe-intermediate condition for every
   missing pair and legal initial cop. In all 29 cases the number of
   two-move winning pairs was exactly `floor((r-2)/2)`. These finite
   checks corroborate, rather than replace, the ordinary functional
   proof.
3. Inspected `research/extremal-bounds-girth-verification.json`, whose
   SHA-256 was
   `4037ec069422826c183d5ae5bdf5c5dc3a2330944520220aa6b7f675af4c8a44`.
   It records successful independent verification of 79 graph orders,
   with separate certificate and verifier hashes.

## Editorial scope note

The earlier full-density note records the intermediate bound `I<=h-2`
and says its sharpness remains open. The later final-dense-band note
supersedes that intermediate status on its stated interval. When these
notes are presented together, the later growing-loss theorem and its
matching construction should govern the current status description.
This is a chronology/cross-reference issue, not a proof failure.

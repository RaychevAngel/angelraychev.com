# Audit of the strategy discussion, 12 September 2026

This is a bounded research note responding to Angel's discussion of the
extremal questions. It does not change the manuscript or website. Statements
below are ordinary proofs except the explicitly identified exhaustive
six-vertex table.

## Provenance

Angel clarified in this discussion that the upper bound `I(G) <= n(n-3)`
and the research direction of attaining it with two incoming and two outgoing
arcs at every vertex were already part of his work with Alexandra Ignatova.
They had not obtained an attaining construction. These two ideas should not
be presented as new contributions of the September 2026 investigation.

The terminal-clique construction and the single-predecessor sink padding
below were proposed by Angel in this discussion. The present note checks
their proofs and arithmetic and observes that the terminal construction
fills intermediate arc budgets. The commuting-permutation obstruction was
derived in the current assistant analysis and independently checked; it is
not attributed to the original work. This note makes no decision about a
future paper's human author line.

## Game convention

The graph is finite, simple, directed, and loopless. Both players may wait.
The messenger moves first; reaching the recipient immediately succeeds,
before any collision test or pursuer response. At every other vertex a
collision loses. The messenger must deliver in finite time. `W(s,t)` means
that delivery is guaranteed from source `s` to recipient `t` for every initial
pursuer position other than `s`. `I(G)` counts ordered pairs `(s,t)` with
`s != t`, no arc `s -> t`, and `W(s,t)`.

Write `N+[v] = {v} union out(v)` for the closed outgoing neighborhood and
`pred(t)` for the incoming neighbors of `t`.

## 1. Set-valued maps and two permutations

The appropriate set-valued notation for an outdegree-two graph is

`f : V -> binom(V,2)`, with `v notin f(v)`.

The indegree-two condition says that **each vertex belongs to exactly two
of the sets `f(v)`**. It does not say that each two-element set occurs twice
as a value of `f`.

Every simple two-in/two-out directed graph can equivalently be written

`f(v) = {alpha(v), beta(v)}`,

where `alpha` and `beta` are permutations of `V`, neither has a fixed point,
and `alpha(v) != beta(v)` for every `v`.

**Proof.** Form a bipartite graph with left and right copies of `V`; join
left `u` to right `v` exactly when `u -> v` is an arc. Every vertex of this
bipartite graph has degree two, so every connected component is an even
cycle. Alternately color its edges red and blue. Each color meets each left
and each right vertex exactly once, and therefore specifies a permutation.
The original graph has neither loops nor duplicate arcs, yielding the two
stated restrictions. Conversely, two permutations satisfying those
restrictions supply exactly two incoming and two outgoing arcs per vertex.

This representation gives a useful construction language. The permutations
need not commute; Section 6 shows that commuting is a severe obstruction.

## 2. Terminal vertices preserve the core

Let `H` be a directed graph on a set `C` of `q` vertices. Add a disjoint set
`T` of `r` vertices. Keep all arcs of `H`, add arbitrary arcs from `C` into
`T` and arbitrary arcs inside `T`, and add no arcs from `T` into `C`.

**Preservation lemma.** For every source and recipient in `C`, their
guaranteed-delivery status is unchanged.

**Proof of preservation of a guarantee.** If the pursuer starts in `C`,
follow a winning strategy in `H` as long as the pursuer stays there. If the
pursuer enters `T`, it can never return to `C`, so the messenger can follow
a directed path in `H` to its recipient without interception. Such a path
exists from every state reached while following the winning strategy:
otherwise that strategy could not guarantee delivery in `H`. If the
pursuer starts in `T`, use any directed source-to-recipient path in `H`;
existence follows from the original guarantee. The messenger never needs
to leave `C`.

**Proof that a nonguarantee cannot improve.** Choose an initial pursuer
position in `C` and a pursuer strategy witnessing failure in `H`. The
pursuer can continue to stay in `C` and use that strategy. If the messenger
ever enters `T`, it cannot return to its recipient in `C`, so it fails to
deliver. If it stays in `C`, the old obstruction applies. Thus the extra
vertices cannot create a new core-to-core guarantee.

Now assume `H` is universally winning and two-in/two-out. It has `2q`
arcs and exactly `q(q-3)` guaranteed indirect pairs. Each of these remains
an indirect pair in the enlarged graph, because no new core-to-core arc
was added. There are

`qr + r(r-1)`

available additional arcs. Choosing any number of them proves

`M(q+r,m) >= q(q-3)`

for **every integer**

`2q <= m <= 2q + qr + r(r-1)`.

Thus this construction gives full intervals of budgets, not just isolated
checkpoints. The inequality is conditional only on the availability of the
chosen universal core. Presently proved orders include `12 <= q <= 24`
and every multiple of five `q >= 20`.

At the fully populated endpoint, all core-to-terminal pairs and all
distinct terminal-to-terminal pairs are direct, while terminal-to-core
pairs are unreachable. Consequently the construction has **exactly**
`q(q-3)` indirect guarantees there. At partial fillings, additional
indirect guarantees involving terminal recipients may occur; only the
lower bound is asserted.

Putting `n=q+r`, the endpoint arithmetic proposed by Angel is correct:

`2q + qr + r(r-1) = 2q + r(n-1) = 2n + r(n-3)`.

The elementary missing-pair upper bound at that endpoint equals

`n(n-1) - (2n+r(n-3)) = q(n-3)`.

Its gap from this construction is `q(n-3)-q(q-3)=qr`.

## 3. A single-predecessor sink preserves I exactly

Add one new vertex `z` to any graph `H` and one arc `x -> z`, with no
other new arcs. Then `I` is unchanged.

**Proof.** Section 2 preserves exactly all core-to-core guarantees. The
new vertex `z` cannot be an indirect source because it has no outgoing
arc. For any potential indirect delivery from `s` to `z`, we have
`s != x`; a pursuer initially at `x` can wait there forever. Every path to
`z` must first reach `x`, where the messenger is caught before it can
deliver to `z`. The pair `(x,z)` itself is direct and is not counted.

In particular, an attaining even-budget graph on `k` vertices and `2k`
arcs gives a graph with `2k+1` arcs and the same `k(k-3)` guarantees. This
does not by itself attain the additional `+2` permitted by the odd upper
bound.

## 4. The odd-budget exceptional vertices and the exact count

Consider a graph on `k+1` vertices with the following degree pattern:

- one vertex `u` has indegree two and outdegree one;
- a distinct vertex `v` has indegree one and outdegree two;
- every other vertex has indegree two and outdegree two;
- `u -> v` is absent.

It has `2k+1` arcs. Sources of counted pairs must have outdegree at least
two, so eligible sources are `A=V\{u}`. Recipients must have indegree at
least two, so eligible recipients are `B=V\{v}`. Both sets have size `k`,
and their intersection has size `k-1`.

There are `k^2` pairs in `A x B`, of which `k-1` are diagonal. The one
arc leaving `u` and the one entering `v` are distinct, because `u -> v`
is absent. Every other arc lies in `A x B`. Therefore that rectangle
contains exactly `(2k+1)-2=2k-1` direct pairs, leaving

`k^2 - (k-1) - (2k-1) = k(k-3)+2`

eligible missing pairs. If every one of them is guaranteed, the graph
attains the odd arc-budget bound.

The important distinction is between rows and columns: indegree one
disqualifies `v` as an **indirect recipient**, not as an indirect source.
Outdegree one disqualifies `u` as an **indirect source**, not as an
indirect recipient. These exceptional vertices can contribute in their
other roles; it is incorrect to discard both vertices from the count.

The already established rigidity theorem proves that, for `k >= 6`,
every graph attaining `k(k-3)+2` with `2k+1` arcs must have exactly this
structure after isolated vertices are removed, together with the stated
game condition. Adding `u -> v` completes the degree pattern to a
two-in/two-out graph. Such a completion is not automatically universally
winning, and arbitrary arc deletion from a universally winning graph is
not automatically safe.

## 5. The joint maximum need not descend monotonically

The saved exhaustive six-vertex computation gives

| Number of arcs m | 12 | 13 | 14 |
|---|---:|---:|---:|
| M(6,m) | 7 | 6 | 7 |

Thus the joint maximum can fall and then rise even in the regime
`m >= 2n`. It should not be described as necessarily decreasing there.
These are exact finite enumeration results, rather than scores of
candidate constructions. The receipt `research/solver-enumeration-n6.json`
records `complete: true`; the method and safe degree/symmetry reductions
are documented in `research/solver-method.md`. Maximizing witnesses were
independently checked by the two Python solvers and their certificates.
This discussion did not repeat the exhaustive search.

The elementary inequality `I <= n(n-1)-m` remains valid at every density.
Near completeness it becomes unattainable, rather than becoming false.
The previously proved dense boundary is

`M(n,n(n-2)) = floor((n-2)/2)`, for `n >= 2`,

and every larger arc count forces `I=0`.

## 6. Commuting permutations force at most n indirect guarantees

**Camping lemma.** If `pred(t) subseteq N+[c]`, then no missing pair
`(s,t)` with `s != c` is guaranteed.

**Proof.** The pursuer may start at `c` because `s != c`. Wait there
until the messenger first enters a predecessor `p` of `t`. The messenger
did not start at a predecessor, since `(s,t)` is a missing pair. If
`p=c`, it is caught immediately. Otherwise the pursuer can move from `c`
to `p` on its ensuing turn and catch it. The messenger has not yet
reached `t`; immediate receipt priority therefore does not circumvent
the interception. If the messenger never visits a predecessor, it never
delivers.

**Theorem.** Suppose the two outgoing neighbors are specified by commuting
permutations `alpha,beta` as in Section 1. Then `I(G) <= n`.

**Proof.** Fix a recipient `t`, and put

`c_t = alpha^{-1}(beta^{-1}(t))`.

Commutation gives

`alpha(c_t)=beta^{-1}(t)` and
`beta(c_t)=alpha^{-1}(t)`.

The right-hand vertices are precisely the two distinct predecessors of
`t`. Hence `out(c_t)=pred(t)`, and the camping lemma rules out every
indirect source except possibly `c_t`. Each target contributes at most
one pair, so summing over all targets proves `I <= n`.

If `c_t=t`, it cannot contribute an indirect pair. If `c_t != t`, the
pair `(c_t,t)` is missing: neither predecessor of `t` equals `t`, since
the graph is loopless. There is also an exact local criterion for the
remaining candidate:

`W(c_t,t)` holds if and only if no vertex `c != c_t` satisfies
`pred(t) subseteq N+[c]`.

Necessity is the camping lemma. For sufficiency, consider any legal
initial cop position `c != c_t`. Choose
`p in pred(t) \ N+[c]`, which exists by the assumption. Since
`out(c_t)=pred(t)`, the messenger can move to `p`. It neither collides
with the cop nor can be caught on the cop's next turn, because
`p notin N+[c]`. On its next turn it moves to `t`, completing delivery.

Thus every indirect guarantee in this commuting subclass is a two-move
diamond, and the local criterion completely determines its indirect
pairs. In particular, since `n(n-3)>n` for `n>=5`, a commuting pair of
permutations cannot yield a vertex-extremal universal construction in
that range. Noncommutation is necessary, but is not asserted sufficient.

### Sharp example on seven vertices

Use `V=Z/7Z` with arcs `x -> x+1` and `x -> x+3`. These translations
commute. For target zero its predecessors are `6` and `4`, and its sole
possible indirect source is `3`.

The cop positions whose closed outgoing neighborhoods contain `6` are
`{6,5,3}`; those whose neighborhoods contain `4` are `{4,3,1}`. Their
intersection is exactly `{3}`. Since that position is excluded as an
initial cop position when the messenger starts at `3`, the local
criterion proves `W(3,0)` in at most two messenger moves.

Translation proves exactly the seven indirect pairs `(s,s+4)`. The
general theorem excludes all others, so `I=7=n`. This is an elementary
proof of sharpness. As an additional independent check, both existing
solvers and the explicit strategy-certificate verifier returned these
same seven pairs during this audit; that computation is not needed for
the proof.

## 7. Target-specific stationary separators: useful but incomplete

For a missing pair `(s,t)`, suppose there is a vertex `c != s` such that
every directed `s`-to-`t` path has an **internal** vertex in `N+[c]`.
Then `(s,t)` is not guaranteed.

**Proof.** The pursuer starts at `c` and waits until the messenger first
visits an internal vertex of its eventual delivery walk lying in
`N+[c]`. Such a visit must occur before delivery: a successful walk
contains a simple `s`-to-`t` path, and every such path has the asserted
internal vertex. Entering `c` causes immediate capture; entering another
vertex in `N+[c]` permits capture on the pursuer's ensuing turn. If the
messenger never makes such a visit, it never delivers. This also covers
the case where no source-to-recipient path exists.

The separator test is equivalent to deleting
`N+[c] \ {s,t}` and testing whether `t` remains reachable from `s`.
Both endpoints must be retained: a pursuer neighborhood containing the
source or the recipient alone does not prove an obstruction under the
game's initial-move and immediate-delivery conventions.

Let `B` be the set of distinct missing, nonloop pairs for which at least
one such `c` exists. Then

`I(G) <= n(n-1)-m-|B|`.

The objects subtracted are **pairs**, not witnesses `c`: several cop
positions may certify the same blocked pair and must not be counted
separately. The predecessor camping lemma is a special case, because
the penultimate vertex of every missing-pair delivery path belongs to
`pred(t)`.

### A five-vertex obstruction requiring a moving pursuer

The stationary-separator criterion is not necessary for failure. On
five vertices `s,a,b,d,t`, take exactly these six arcs:

`s -> a,b; a -> t; b -> d; d -> t; t -> d`.

For every legal initial cop position there is a path avoiding its closed
outgoing neighborhood at internal vertices:

| Cop position | Closed outgoing neighborhood | Avoiding path |
|---|---|---|
| a | {a,t} | s -> b -> d -> t |
| b | {b,d} | s -> a -> t |
| d | {d,t} | s -> a -> t |
| t | {t,d} | s -> a -> t |

Nevertheless `W(s,t)` is false. Start the pursuer at `a` and wait while
the messenger waits at `s`. The messenger cannot enter `a` without
immediate capture, so to make progress it must move to `b`. The pursuer
then moves from `a` to `t`. Wait there while the messenger waits at `b`.
If the messenger moves from `b` to `d`, the pursuer moves from `t` to
`d` and catches it before its final move to the recipient. Waiting
forever also fails to deliver. This exhausts the messenger's choices.

Thus a different safe path for each **stationary** cop position is not
enough: the cop can change which route it blocks as play progresses.
The exact general criterion remains the alternating reachability
attractor on pairs of messenger and pursuer positions, with the recipient
fixed. The stationary obstruction is a potentially useful simplification
for bounds, not an asserted replacement for that game analysis.

The example was obtained by independently verifying a six-vertex
counterexample supplied by the parent research analysis, greedily
deleting arcs while retaining both properties, and removing an isolated
vertex. The elementary proof above is independent of computation.
`research/2026-09-12-stationary-separator-counterexample.json` preserves
the normalized graph, all four avoiding paths, the complete target-game
certificate, and the original graph and reduction history. Both solvers
agree; the explicit certificate verifier checks both winning rank
decrease and losing-region closure. No global minimality is claimed.

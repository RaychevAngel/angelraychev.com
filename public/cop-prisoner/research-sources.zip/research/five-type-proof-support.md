# Five-type family: independent proof support

12 September 2026. This file distinguishes a successfully checked uniform
interface from failed strategy and defect abstractions.

## Accepted independent local interface

`src/five_type_local_verify.py` constructs a fresh explicit alternating game,
independently of the construction agent's bitset implementation. There are
35 messenger vertices (columns -3 through 3), 45 ordinary pursuer vertices
(columns -4 through 4), and an exterior state Ω. The pursuer at Ω may wait or
enter any of the ten vertices in either boundary column -4 or 4. Moves from
ordinary pursuer vertices that leave its window enter Ω. Messenger moves
leaving its smaller window are disallowed.

The transfer goal seeds **only messenger-turn states** in column zero with
distinct messenger and pursuer positions. Pursuer-turn states in that column
are not seeded. Consequently a move into the goal must survive every
intervening pursuer response before the module terminates. This is essential
for composing successive transfers. The delivery goals instead use the actual
terminal-receipt rule and succeed before a collision check.

All six certificates passed independent checking of winning and losing rank
conditions on every explicit state and legal transition:

| Task | Initial messenger column | Number of initial states | Maximum messenger moves |
|---|---:|---:|---:|
| Safe transfer to column 0 | 1 | 225 | 8 |
| Delivery to type 0 in column 0 | 2 | 225 | 24 |
| Delivery to type 1 in column 0 | 2 | 225 | 16 |
| Delivery to type 2 in column 0 | 2 | 225 | 16 |
| Delivery to type 3 in column 0 | 2 | 225 | 17 |
| Delivery to type 4 in column 0 | 2 | 225 | 18 |

For cyclic length k>=10, the nine represented pursuer columns are distinct.
Every actual exterior pursuer move either remains exterior or enters one of
the boundary columns, so Ω overapproximates it. This would not be valid
unchanged at k=9: the represented boundary columns can be adjacent around the
cycle, producing an immediate boundary-to-boundary move absent from the
abstract graph. Those small lengths are handled separately.

Successive left transfers may re-center their windows after the intervening
pursuer turn. After at most k-1 such transfers, the messenger can be placed
two columns to the right of the recipient, then use the delivery module.
This gives the uniform sufficient bound `8(k-1)+24=8k+16`. The certificates
and exterior argument establish all k>=10; independent exact finite checks
cover k=4,...,9. Thus the **unmodified five-type family is proved universal
for every k>=4**, subject to the final manuscript's explicit certificate
interpretation. It is ordinary computer-assisted verification, not yet a
claim of Lean formalization.

The complete independent ranks, winning moves, and source hash are in
`research/five-type-independent-local-certificates.json`.

## Failed simple policy abstractions

The policy “take the second (fast-lane) arc whenever safe, otherwise the first
arc,” even with immediate-delivery overrides, does not win universally.
Choosing the safe action of minimum ordinary graph distance also fails.

Adding an exact bounded finishing controller does not repair the unphased
fast-lane policy: even following a truly optimal strategy whenever its rank
is at most 20 still fails at k=16, and for every recipient type at k=24 and
k=40. A 23-step pursuer countercycle at k=16 is saved in
`five-type-finisher-countercycle.json`. Every state on it has actual optimal
rank between 21 and 33, so it never enters that finishing controller.

These failures concern the chosen policies, not existence of winning
strategies. Their purpose was to test abstractions before promoting a
general proof. The successful left-transfer interface above avoids their
unjustified greedy choices.

## Failed finite local-patch generalization

Four degree-preserving patches with one through four extra vertices were
found by changing arcs only from columns -2 through 2. Each patch gives a
universal graph when placed on the cyclic backbone of length k=8, as checked
by both game solvers. Their coordinates are saved in
`five-type-local-defect-patches.json`; their graph generator is
`src/five_type_defect_graph.py`.

**These patches are not uniform constructions.** Independent insertion into
other lengths immediately refuted the proposed generalization: all four
patches fail at every tested length k=9,...,12, and also at the valid shorter
instantiations. At k=4 some coordinates alias and the patches are not even
two-regular. The search optimized a finite cyclic game and overfit its
circumference. It cannot support the all-residue extremal theorem.

The correct next search objective is the local exterior-state interface
itself: safe exit to the left from every patch source, and delivery from a
right entry column to all nearby or added recipients. Finite global
universality alone is insufficient evidence for such a patch.

## Corrected exterior-state patch search: still incomplete

The first exterior-state objective used entry column 4 and recipient columns
-3 through 3. That was too weak for gluing, and its rightmost recipients were
only one column from the entry. The already proved base delivery interface
requires two columns. The remaining 14 failures in that objective were not
evidence that only 14 cases remained for the desired all-order theorem.

The corrected objective is implemented in
`src/five_type_expanded_defect_search.cpp`:

* Messenger window: columns -11 through 10, plus added vertices.
* Pursuer window: columns -12 through 11, added vertices, and Ω.
* Safe exit to column -6 from every source in columns -5 through 8 and every
  added vertex, against every distinct initial pursuer position.
* Delivery from every source type in column 8 to every recipient in columns
  -8 through 6 and every added vertex, against every distinct pursuer start.

The unmodified five-type graph passes this objective completely: 8,400 safe
exit states and 45,000 delivery states. Thus the objective itself is feasible
and matches the intended conservative gluing interfaces. The copied base
module must avoid the patch in its **pursuer window**, not just its messenger
window; ignoring the extra column on each side was another potential gap.

The best bounded one-extra-vertex repair passes every one of 8,591 safe-exit
states but only 44,176 of 45,980 delivery states. It remains **incomplete**.
The failed-state count and graph are saved in
`research/five-type-expanded-defect-search.json`; the baseline control is
`research/five-type-expanded-baseline-check.json`. These are experimental
search outputs, not accepted defect certificates. No all-residue extremal
classification follows from them.

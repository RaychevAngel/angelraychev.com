# Independent coverage review

Reviewed on 2026-09-13 after incorporation of the fixed 22-arrow witness. This is an independent source and certificate audit of the current coverage calculation, not a new classification proof or a graph search.

**Result:** no false exact cell or omitted, numerically non-subsumed unconditional theorem domain was found among the current numbered manuscript results. The explicit scope qualification is necessary: the ledger is the complement of its incorporated numerical rules, not the complement of every possible consequence of the retained conditional construction theorems. In particular, even-core and mixed-size antichain capacities remain unincorporated, as stated.

## Checks completed

- Compared the encoded predicates with the ordinary source statements: sparse endpoint support requirements, the separate 23-arrow theorem, small-budget and small-order upper exclusions, circle admissibility and protected differences, five-type intervals, prime-square constructions, equal-weight odd-core codes, the integer orientation inequality, dense caps and the finer small-order functional-root criterion. Earlier numerical families were checked for subsumption or inapplicability in the residual box.
- Completed 102,516 independent arithmetic assertions against selected source domains, including their boundaries, support plateaus, sparse formulas and dense conditional cases. Recomputed the frozen ledger with `python3 src/classification_coverage.py --check`; its affine encoding expands to all 493,924 admissible cells without disagreement.
- Independently expanded the final ledger and checked every cell satisfies `0 <= lower <= upper <= n(n-1)-m`. Confirmed all displayed canonical ranges in `CLASSIFICATION_GAPS.md` agree exactly with the ledger. There are 431,302 exact box cells and 62,622 unresolved box cells; removing 880 isolate repetitions leaves 61,742 representatives: 288 sparse, 61,393 main-interval and 61 dense.
- Independently replayed 13,478 saved alternating game states across seven fixed certificates, checking receipt before collision, both players' waits, a decreasing rank on winning transitions, closure of the losing region, and the initial-cop quantifier. This includes all 2,662 states of the newly retained `(n,m,I)=(11,22,71)` graph. It establishes a lower bound only. No attractor computation, graph enumeration or new graph search was run by this reviewer.
- Reviewed isolate propagation and disjoint-component padding. These preserve the original component's counted guarantees; adding arbitrary arrows to that component would not. The final encoding records the base component's order and budget so those two operations remain distinguishable.
- Reviewed the complete structural readback for saved circle envelopes and tiny dense envelopes. The final generator checks the circle's allowed step and all six protected differences, and checks every tiny-envelope safe intermediary against the full compulsory/optional sets. The full order-18 optional cap of 21 is correctly labelled external finite certificate evidence, rather than attributed to the selected cap of 18 in the Lean statement.

## Scope and research assessment

The support argument safely reduces all outstanding questions to orders at most 114: the eventual theorem handles `n >= 115, m >= 24`, the separate theorem handles `m=23`, and each remaining budget `m <= 22` stabilizes by order `2m <= 44`. This is a finite reduction, not a practical exhaustive-search claim.

The private assessment keeps finite witness scores separate from global upper exclusions and labels proposed investigations as proposals. Its even-core suggestion follows the actual hypotheses of Theorem 59: for even `k >= 6`, the difference-two graph consists of two cycles, while the other hub part has one cycle. Deriving and using the resulting capacity remains future work. The order-114 example now requires both endpoints of a proposed code interval to span the gap; two additional protected circle steps would reach 4104 and cover the current gap ending at 4097.

No blocking review finding remains. This review does not independently reprove every ordinary theorem, repeat the complete small-graph exclusions, or enlarge the recorded Lean coverage.

## Reviewed evidence versions

| File | SHA-256 |
| :-- | :-- |
| `src/classification_coverage.py` | `f99e803f97a25aee2575c588960631e65ea9c0b54424f293330325fb8956c15d` |
| `publication/classification-coverage.json` | `9ef9cd54a8bd3c7be912fabe30efe1683e07cd2d9a0d97541be18f749f671eeb` |
| `research/classification-fixed-witnesses.json` | `1a1842b5bc9360e040d7027686968d97c214dde36b5832660050deb4eb029c79` |

The ledger itself pins the complete incorporated source inventory. These hashes identify the reviewed versions; they are not substitutes for the arguments or certificate checks above.

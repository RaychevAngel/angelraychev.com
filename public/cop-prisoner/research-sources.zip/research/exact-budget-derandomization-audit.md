# Independent audit: deterministic exact-budget construction

## Verdict and scope

The proposed conditional-counting argument is correct. It yields a
deterministic algorithm, polynomial in the number of vertices `n`, that
constructs an exact-`m`-arc universally winning graph whenever the
hypothesis of Theorem 25 holds. Its guarantee uses a safe two-move
intermediary for every source-recipient-initial-cop triple. The argument
does not assume conditional independence after fixing the arc count.

This is a bounded independent audit of the parent researcher's new
derandomization proof. It is ordinary mathematics, not a new Lean
formalization or a practical performance benchmark. The conservative
polynomial bound below is not a claim that the naive algorithm will
be fast at the large orders supplied by the asymptotic theorem.

## 1. The required first-moment inequality is available

Let `L=n(n-1)`, `p=m/L`, and let `T` denote the random number of present
arcs in the independent model. For every triple `(s,t,c)` with `s!=t`
and `c!=s`, call the triple bad when no safe intermediary exists among
vertices outside `{s,t,c}`. Let `Z` count bad triples, with multiplicity
one for each such triple.

The calculation in Theorem 25 proves the stronger statement

`E_p[Z] <= n^3 exp(-(n-3)p^2(1-p)) < n^(-2)`.

This follows by summing individual bad-triple probabilities; it does
not merely bound `P(Z>0)`. The binomial mode argument gives

`P(T=m) >= 1/(L+1) > n^(-2)`.

Since `Z>=0`,

`E[Z | T=m] <= E_p[Z]/P(T=m) < 1`.

Conditional on `T=m`, all exact-`m` graphs are equiprobable. Thus the
initial conditional-counting invariant really does hold on the desired
uniform exact-budget sample space.

## 2. Candidate variable sets remain disjoint

For a fixed triple, candidate `u` uses the three binary variables for

`s->u`, `u->t`, `c->u`,

and succeeds precisely at the assignment `(1,1,0)`. They are distinct
even when `c=t`, because `u` is different from all listed endpoints.
For two different candidates, their three-variable sets are disjoint.
An equality of two arcs with different tail roles would force a
candidate to equal `s` or `c`, or would force `s=c`; equal tail roles
instead force the two candidates to agree. These possibilities are
excluded. All the variables represent nonloop arcs.

Deleting some variables from the free set through a partial assignment
does not disturb this disjointness. It permits exact generating-function
counts for each triple, although the remaining variables are dependent
under an exact total budget.

## 3. Exact completion counts under a partial assignment

Suppose `F` arc variables remain free and exactly `b` of them must
be present. The number of admissible completions is

`C=binom(F,b)`,

with zero for an infeasible budget. Fixed present arcs have already
been subtracted from the original budget to obtain `b`.

For a candidate with `q` free variables among its three variables:

- If a fixed variable contradicts the witness pattern `(1,1,0)`, the
  candidate cannot succeed. Every assignment to its free variables
  keeps it failed, giving factor `(1+x)^q`.
- Otherwise exactly one assignment to its `q` free variables completes
  the witness. If that assignment requires `a` present free arcs, its
  contribution is `x^a`. Removing it gives the factor
  `(1+x)^q-x^a`.

The exponent counts only **free** present variables; fixed present
variables were already charged to the budget. At `q=0`, a completed
witness gives factor `1-1=0`, correctly making the triple's bad count
zero. A fixed contradiction instead gives factor one. All factor
coefficients are nonnegative integer counts.

Multiply these factors over the candidates. If `F_out` free variables
belong to no candidate group for this triple, multiply also by
`(1+x)^F_out`. The coefficient of `x^b` is exactly the number of
admissible completions in which this triple is bad. No probabilistic
independence assumption is being made here; the coefficient enforces
the total number of present free arcs exactly.

Summing the coefficient over all triples gives

`B = sum_over_completions Z(completion)`.

Different triples may share variables, which causes no difficulty:
their counts are added, not multiplied. A completion with several bad
triples is intentionally counted several times.

## 4. Deterministic invariant and termination

Initially `B/C=E[Z|T=m]<1`, so the integer inequality `B<C` holds.
Reveal one free arc. Let `(B_0,C_0)` and `(B_1,C_1)` be the two branch
counts, calculated with the updated budget. Every completion is in
exactly one branch, and its value of `Z` is unchanged, so

`B=B_0+B_1`, `C=C_0+C_1`.

At least one branch has `B_j<C_j`; otherwise summing the two opposite
inequalities contradicts `B<C`. A branch with `C_j=0` cannot qualify,
since `B_j` is nonnegative. Choose a qualifying branch deterministically,
for example choose zero if it qualifies and one otherwise. The desired
invariant and budget feasibility continue.

After all `L` variables are fixed, exactly one admissible completion
remains, so `C=1`. The invariant forces the nonnegative integer `B` to
equal zero. The produced graph therefore has no bad triple and exactly
`m` arcs. Every source-recipient pair is guaranteed in two moves by the
same safe-intermediary argument as Theorem 25.

The proof only needs to preserve `B<C`; it does not need to preserve
monotonicity of the precise expectation from one step to the next.
Alternatively the usual branch with nonincreasing expectation could
be selected, but that is an unnecessary stronger selection criterion.

## 5. Polynomial arithmetic and bit lengths

There are `O(n^2)` variables, `O(n^3)` triples, and `O(n)` candidate
factors per triple. All generating polynomials have degree at most
`L=O(n^2)`. Straight integer convolution, truncated above the remaining
budget if desired, computes every required coefficient in polynomial
time. Recomputing the counts for both branches at every reveal is
still polynomial; efficiency improvements are optional for correctness.

Every coefficient for one triple counts subsets of at most `L`
variables and is at most `2^L`. Summing over all triples increases the
bit length by only `O(log n)`. Thus all relevant integers have
`O(n^2)` bits. Exact integer arithmetic therefore gives polynomial
**bit** complexity as well, not merely a unit-cost arithmetic bound.
A deliberately loose implementation bound is `O(n^9)` arithmetic
operations on these integers, or `O(n^13)` bit operations with
schoolbook multiplication; no optimized exponent is claimed.

The term polynomial refers to `n`, the explicit graph order. It does
not assert polynomial time in the binary length of `n`, which would
be inconsistent with writing an arbitrary `n`-vertex graph explicitly.

The algorithm need not decide an inequality involving logarithms:
it can compute the initial integers `B,C` directly and proceed whenever
`B<C`. Theorem 25 is a sufficient analytic guarantee for that exact
integer test. The construction may succeed for other parameter pairs
as well, without extending the proved analytic range automatically.

## 6. Lightweight finite sanity checks

The audit separately enumerated all 27 partial assignments to one
three-variable candidate and compared the proposed polynomial with
the exact count of its failing free completions. Every coefficient
agreed, including the fully fixed and contradictory cases.

It also checked all 729 pairs of such partial assignments, with two
additional free variables outside the candidate groups. The product
of the two factors and `(1+x)^2` agreed coefficient-by-coefficient
with direct enumeration of all free completions. These bounded checks
corroborate the factor formula; the ordinary proof establishes its
arbitrary-size use. They do not test or benchmark the full derandomized
graph-construction implementation, which is owned by the parent task.

## 7. Consequence for the main-interval presentation

Replacing the randomized existence step by this deterministic algorithm
means the eventual full main-interval theorem can provide a deterministic
polynomial-time graph construction at every claimed budget. Its other
parts already have explicit construction algorithms. The finite local
certificate dependencies of the sparse bridge and the finite girth-growth
bridge remain exactly as stated; derandomization does not turn those
arguments into Lean proofs or remove their provenance.

The appropriate description is an explicit deterministic algorithm,
with a conservative polynomial-time guarantee. It need not be described
as a simple closed-form graph formula or as a practical construction at
all enormous asymptotic orders.

## 8. Audit of the explicit sufficient order threshold

The subsequent Theorem 44's sufficient threshold `n>=10^12` is valid.
Here is an independent check of the numerical overlaps; it is not a
claim that the threshold is close to optimal.

Put `T=n(ceil(n/7)-1)`. After the protected-difference construction,
any remaining budget `m>T` has `p=m/[n(n-1)]>1/8` when `n>49`.
For `p<=9/10`, the random criterion's exponent satisfies

`(n-3)p^2(1-p)>(n-3)/640>5 log n`.

The final inequality holds at `10^12` and persists because
`(n-3)/log n` is increasing in this range. If `p>9/10` and
`h=n(n-1)-m>=7n log n`, then instead the exponent is greater than

`5.67 [(n-3)/(n-1)] log n > 5 log n`.

The last inequality already holds for `n>=18`. Thus deterministic
Theorem 43 covers all remaining budgets with at least `7n log n`
missing arcs.

For the dense complement interval choose `D=floor((n/2)^(1/4))`.
Theorem 20 has `B_D<=D^4<=n/2`, giving endpoint
`L_D(n)>=nD/4+n-1`. To see it overlaps, the ratio
`(n/2)^(1/4)/log n` is increasing for `n>exp(4)`. At `n=10^12`,
its numerator exceeds 840, whereas
`29 log n=348 log 10<812`, using `log 10<7/3`. Therefore
`(n/2)^(1/4)>29 log n` throughout the range, and

`D>(n/2)^(1/4)-1>28 log n`.

Consequently `L_D(n)>=7n log n+n-1>=ceil(7n log n)`, so the
integer intervals overlap. The remaining conditions `n>=52` and
`5<=D<=n-1` are automatic. The sparse bridge's order threshold 2419
and the protected-difference threshold 25 are also automatic.

Hence every integer budget from `2n` through `n(n-3)` is covered at
every `n>=10^12`. The randomized portion is supplied by the exact
integer conditional-counting algorithm reviewed above, so the combined
result has a deterministic construction throughout its stated range.

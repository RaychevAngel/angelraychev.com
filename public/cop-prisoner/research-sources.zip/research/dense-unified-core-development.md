# Dense unification development

Execution-authorized bounded lane, 2026-09-12. Owner: catalogue_dense.
Only this new note, `paper/dense-unified-core.md`, its uniquely named
generator and receipt are edited by this lane. The existing publication
and theorem sources are unchanged.

## Current result, superseding the initial girth-only route

`paper/dense-unified-core.md` now states the **direct** Theorem58,
with no girth hypothesis or finite graph-certificate premise:

- Dense endpoint in2 moves at n10 and every n>=12.
- Robust arbitrary-subset missing envelope2n..3n at evenn>=22,
  oddn>=33, and29; in particular every n>=32.
- First staircase step at every n>=16; complete staircase at every
  n>=24. The functional distinct-root bound improves to
  binomial(floor((r-1)/2),2), by using the spare root in odd order.
- With the existing protected envelope, every dense missingbudget
  n..nceil((n-1)/13) is now covered for every n>=32.

These follow from two point/line types with compulsory arcs
P_i->L_i,L_(i-1), L_i->P_(i+4),P_(i+6). The initial lane found
the robust optional arcs P_i->P_(i+6), L_i->L_(i+4), which reduce
to six tiny danger sets. Root independently noticed the original
base works down to k5, the envelope down to k11, and a single
P0/P3 subdivision supplies oddcores from13. Independent lane checks
confirmed these ranges. Direct first-step attachments then give16,
and the improved functional root pool gives the staircase24.

The odd robust envelope uses a P0/P7 subdivision, retaining all old
optionals plus w->P2. Its proof is the explicit finite symbolic
danger-set analysis in the paper, valid for all k>=16 and k14.
This avoids the much weaker two-block order53 proof considered first.

The old girth derivation below and its former public draft survive in
`research/dense-unified-core-girth-development.md` as superseded research
history. Its executable is `src/dense_unified_girth_core.py`, using its
own receipt path. No superseded threshold is retained as a separate
new paper result.

## Independent review and source supersession

Root reported an independent literal-adjacency and witness audit of25
coreorders,17envelopes,20firststeps, and all130 staircase cases at n24..28.
The review also used independent alternating-state game checks at
n10,12,13. All passed. Root reviewed the direct proof algebra and found
no gap. This is distinct from the lane's larger generator-based finite
receipt; the ordinary proofs remain the basis for the infinite ranges.

After that review, the older dense manuscript sources were updated:
Theorems19,29,32,50 and Corollary33 now state the stronger ranges and
refer to the common direct proof. Proposition31 includes the extra odd
functional root. Theorem20 retains its exact D-dependent statement as
a short consequence of58 and48, replacing its superseded growth proof.
GenericLemma18, universalTheorem27, compositionLemma28, and the
commuting-permutation restriction30 remain. No shared main/build/site
file was edited by this lane.

## Additional bounded experiments

- Incremental additions protected by the original two missing cop
  neighbors reached3n at n52,53,60,61 in under0.02seconds total.
  This motivated the two-type modular optional list; no finite
  greedy examples are needed by the final proof.
- The fixed optional offsets6/4 passed direct tests at k13..40;
  root's symbolic audit improved the threshold to11. Direct checks
  showed failures below11 for this specific envelope; no global
  impossibility result is asserted.
- Odd core P0/P3 subdivision passed every oddorder13..81. The
  corresponding first-step attachment passed odd17..85 and even16..82.
- Odd robust P0/P7 subdivision plus w->P2 passed k14 and every16..50.
  Its failures at k11,12,13,15 are failures of this specific template,
  not upper bounds on M or on universal two-move attainability.

## Initial girth-based deductions (superseded)

- Replace the original cyclic order-26 incidence set by `{0,1,4,6}`.
  Its positive differences are exactly 1 through 6, giving every even
  girth-six four-regular order at least 26.
- Initial odd construction used disconnected even blocks26 and n-27,
  giving every odd order at least53. Root independently checked that
  proof and the even modular core on 2026-09-12. This initial version
  is superseded below.
- Stronger odd construction: in even core2k, k>=20, remove
  P0--L0 and P13--L7 and insert one vertex attached to all4 endpoints.
  Same-class endpoint differences13 and7 avoid S-S; cross differences
  13 and-7 avoid S+S-S=[-6,12] modulo k. Thus every odd order>=41.
  This sharper odd statement and consequences require a fresh
  independent review; root review of the earlier disconnected-block
  version is not represented as review of this version.
- Explicit first-step attachments: even core>=28 uses point indices
  0,7,1,8. Odd core>=41 uses1,8,2,9, avoiding the two point endpoints
  adjacent to the inserted vertex. This gives r=1 at even n>=32 and
  odd n>=45.
- All core orders>=40 plus the existing distinct-pair functional
  extension give the complete final dense staircase for n>=61:
  remaining k<=39 has r>=22 and binomial(floor((r-2)/2),2)>=45.
- Six-mark ruler{0,1,4,10,12,17} gives robust bridge2n..3n at every
  even n>=70. Fixed Singer set{0,1,3,8,12,18} supplies n62.
- Seven-mark ruler{0,1,4,10,18,23,25} gives degree7 even cores>=102.
  Combine one with a26-block by the original disconnected insertion:
  all odd n>=129 have a4-regular base and at least3n total edges.
  All optional subsets preserve girth and minimum missing outdegree2.
  The bridge therefore starts at every n>=128, plus the stated even
  orders and62. This does not settle every order52..127.

## Bounded failed avenue

A tiny normalized cyclic-Sidon search for six marks modulo31..34
found `{0,1,3,8,12,18}` at31, but no sets at32,33,34. Runs used
14,3801,6873,5321 search nodes respectively and under0.05seconds total.
This is recorded only as a failed route to a direct cyclic bridge at
orders64,66,68, not promoted as a new exhaustive nonexistence theorem.

## Verification boundary

`dense_unified_core.py` constructs the direct modular missing graphs and
checks safe two-move intermediaries and compulsory-witness robustness
against every legal pursuer for each examined missing pair. The archived
`dense_unified_girth_core.py` contains the superseded girth-based checks. It is not a full pursuit-game search;
the universal upper bounds independently supply optimality once the
displayed count is attained. General proofs do not depend on tests.

The current receipt records its own source hash and finite scope.
There are no claims of new Lean coverage, publication, or complete
resolution of all moderate-order dense budgets from this lane alone.

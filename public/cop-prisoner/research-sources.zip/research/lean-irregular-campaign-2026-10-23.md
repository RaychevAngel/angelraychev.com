# Irregular finite-exclusion campaign — 23 October 2026

## Exact checkpoint and current boundary

The target is the actual-game theorem
`Delivery.IrregularTen14.positive_upper`: every loopless graph on ten vertices
with fourteen arrows and positive indegree/outdegree at every vertex has
score at most thirteen. This is a complete prescribed-degree exclusion
benchmark. It is not the global fourteen-arrow maximum and does not replace
the other support sizes, zero-degree cases, or smaller-budget prerequisites.

The new generic modules, the normalization wrapper, and the first literal
piece have compiled. All reported dependencies are the standard `propext`,
`Classical.choice`, and/or `Quot.sound`. The complete sixty-piece certificate
and final unconditional wrapper are frozen for the root's integrated,
source-pinned replay. **Do not claim the full benchmark passed until that
replay accepts every piece and the final theorem.** No historical receipt
or manuscript source was changed by this lane.

## Complete mathematical interfaces

- `IrregularTenProfile.rigid` and `.normalize` (root-owned) derive the sole
  relevant joint-degree profile from an arbitrary putative counterexample.
  Positive degrees and fourteen arrows force at most four active sources
  and four active targets. Score above thirteen forces four of each; the
  active-cut lower bound forces these sets disjoint. Equality in the degree
  sums then forces profile `4*(2,1)+4*(1,2)+2*(1,1)`. An explicit bijection
  puts those classes at indices 0..3, 4..7, and 8..9. This lane independently
  reviewed the argument and its final isomorphism orientation: PASS.
- `RowPrefixKernel.Prescribed D R E` means actual looplessness and exact
  outgoing/incoming degrees. A prefix is a list of completed adjacency
  rows. `row_exists` encodes every actual row as a bounded bitmask;
  `branch_upper` uses a checked complete list of masks of the required
  degree. `IrregularTen14Base.cover_one/cover_two` check those finite lists.
- `RowPrefixKernel.prefix_ok` proves all accepted completions meet every
  completed row's degree/loop constraint and the partial incoming-column
  lower and upper capacities. `invalid_upper` rejects only prefixes with
  no prescribed completion.
- `RowPrefixSymmetry.map_upper` transports an upper bound through an actual
  graph isomorphism. Each literal route supplies an involution preserving
  both degree functions, fixing completed row indices, and preserving all
  completed adjacency bits after permuting columns. `RoutesOK` checks every
  raw next row: it is either impossible or routed to a retained child. The
  producer's future-vertex equivalence classes are never trusted as a
  coverage premise.
- `RowPrefixEnvelope.remaining_capacity` proves that an unfinished row
  cannot enter an already saturated incoming column. Its proof adds that
  predecessor disjointly to the known predecessor set and compares actual
  cardinalities. This gives the optimistic messenger envelope and fixed
  pursuer subgraph for every prescribed completion.
- `RowPrefixLoss.regionCertificate` converts cached bitset closure checks
  into a `LosingRegion` for the actual graph. It covers waiting, immediate
  terminal receipt, capture on the messenger move or cop reply, and excludes
  initial cops at the source when claiming a losing ordered pair.
  `bound_sound` covers every counted pair and counts the remaining allowed
  union once, also using actual live-degree lower bounds.
- `RowPrefixTree.sound` supplies a general complete reflected tree. The
  concrete export currently assembles its local branch/bound lemmas into
  separate declarations to limit reduction-cache growth.
  `RowPrefixBoolean` proves equivalent, unrolled finite checks for order ten;
  it changes evaluation representation, not the mathematical obligations.

## Bounded production and literal proof coverage

`src/irregular_ten_producer.py` searches only this one fixed 10/14 profile,
with a mandatory at-most-sixty-second cap. The completed run took about
0.41 seconds and produced the following **untrusted data**, subsequently
rendered as ordinary Lean literals by `src/irregular_ten_export.py`:

| Item | Count |
|---|---:|
| Prefix nodes | 2,929 |
| Branch nodes | 758 |
| Prefix bound certificates | 2,171 |
| Closed losing-region masks | 934 |
| Raw next-row choices covered | 17,380 |
| Choices rejected by checked degree/loop capacities | 12,567 |
| Valid choices routed by nontrivial symmetry | 1,885 |
| Retained canonical children | 2,928 |

The valid-choice identity is `17,380-12,567 = 2,928+1,885`.
Every branch retains every canonical child and checks the route for every
other valid raw row. The last bound prefixes have nine completed rows;
no full-graph terminal score returned by an external solver is used as proof.
The producer computes optimistic game regions, but only the explicit closed
regions and pair-cover checks enter the Lean theorem.

The old ordinary receipt recorded 23,724 nodes and six evaluated full graphs.
The smaller new traversal comes from stronger optimistic-prefix game pruning;
this count reduction is not itself a verified upper bound. Complete Lean
coverage, including the degree-profile normalization, remains the acceptance
criterion.

The export consists of a base, sixty depth-two pieces, and the final
aggregator/wrapper, totaling about 1.53 MB of literal source. The largest
piece contains 175 prefix nodes. Input tree, source hashes, exact piece list
and generated-source hashes are recorded in
`tmp/lean-irregular/export-manifest.json`. The tree is in
`tmp/lean-irregular/producer-tree.json`; neither file is a proof axiom or a
required run-time oracle for readers of the literal Lean sources.

## Measured replay preparation

On Case00 (57 nodes, 22 branches, 28 losing masks), ordinary kernel replay
passed in these successive representation experiments with at most two
Lean workers:

| Representation | Wall time | Maximum resident memory |
|---|---:|---:|
| One reflected term with proposition quantifiers | 10.60 s | 3.44 GB |
| One reflected term with equivalent Boolean finite checks | 9.12 s | 3.06 GB |
| Separate local proofs using the same Boolean checks | 7.65 s | 2.73 GB |

These are single-piece measurements, not a promised full-table speedup.
The final representation is the last one. The root owns the full replay and
resource scheduling; this lane stopped all compilation before that replay
continued, avoiding concurrent writes to the same object files.

## Next acceptance and scope

The root's complete source-pinned replay must accept all sixty pieces,
`canonical_upper`, and `positive_upper`, then record exact compiler/import,
source, and object hashes. No remaining arbitrary-graph coverage assumption
is exposed in the final theorem: the only hypotheses are looplessness,
exact budget fourteen, and positivity of both degree directions.

Once accepted, this benchmark validates the reusable irregular-degree
coverage route. Extending it to other degree profiles and support sizes still
requires their complete inventories and literal certificates. It does not
justify extrapolating from the original solver's runtime or treating only
surviving graph leaves as a proof. The intended continuation remains the
sharp finite tables, not a duplicate weak-threshold certificate corpus.


## Complete benchmark theorem replay

All60 split certificates, the degree normalization and
`IrregularTen14.positive_upper` passed the integrated kernel replay. The
assembled theorem assumes only looplessness, ten vertices, fourteen arrows,
and positive incoming/outgoing degrees. It has no supplied profile or
search-result premise. Only standard foundational axioms were reported.
The unrestricted M_E(14) maximum and other finite families remain separate.

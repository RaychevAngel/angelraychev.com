# Dense third pass: root-colored cycle attachments

2026-09-13. Authorized bounded research on the 61 residual dense cells.
Owned outputs use dense-third/dense_third prefixes; no central manuscript,
ledger, website or deployment changes are made by this subtask.

## Initial obstruction and new idea

At (19,314), the functional ten-vertex block has four roots. The old
attachment rule can assign only six distinct root pairs to nine added
vertices. The existing disjoint core alternative begins at ten added
vertices. This is a failure of those sufficient recipes, not an upper
obstruction.

The old rule unnecessarily sends both missing arrows of each added vertex
to roots. Instead, send one to a root and one to the successor in an added
cycle. Different root colors separate distinct-color pursuers immediately;
for equal colors, the cycle successor is the safe intermediate. Proper
cycle coloring eliminates the dangerous equality in the second step.

The resulting ordinary proof is in paper/dense-third.md. It applies to
every r>=7 and arbitrary k=n-r, and to r>=5 with k even or k=1, as well as
the existing k=0 endpoint. It supplies 26 formerly unresolved dense cells.
The core mathematical claim was sent to the parent for independent attack.

## Checks and failed extension

An initial exact two-move check covered r=7..30 and k=1..49: every instance
matched the staircase target. The persistent constructor now checks the
larger rectangle r=2..40,k=0..60 on its applicable domain. Each of the 26
new finite cells is additionally checked by both existing actual-game
solvers, with full alternating-state rank certificate replay.

A possible two-root odd-cycle extension was tested at r=5,k=3 by complete
enumeration of the 216 ways for each new vertex to choose two distinct
missing neighbors among the two roots and other new vertices. None gives
all the target pairs by the two-move criterion. This excludes only this
fixed functional block/attachment class under that sufficient criterion;
it says nothing about arbitrary-duration delivery or other missing graphs.
The analogous k=1 and k=2 classes have respectively one and two successes.

The new theorem does not require root pairs to be globally distinct. It
does require a proper coloring of the cyclic adjacency; dropping that
condition permits a same-color predecessor to obstruct a counted pair.

## A third move closes the two-root odd cases

The parent proposed an even alternating cycle plus a singleton missing both
roots. Its singleton-source pairs fail the two-move criterion, but both
actual-game solvers return the full staircase count, with three moves,
at r=5,6 and k=3,5,7,9. This is the precise reason the preceding negative
two-move enumeration could not be interpreted as an impossibility result.

The ordinary proof first retains the two-move strategies for every cycle
source even against the singleton cop. The singleton then moves safely to
a cycle cop's successor and uses that already-established strategy, so
three moves suffice. The resulting theorem covers every r>=5 and every
k, closing eight further dense cells, for a total of 34. The pure cycle theorem
retains the stronger two-move domains separately.

The first theorem plus the existing core/first-step constructions also
lowers the complete dense-band threshold from 20 to 16, still with two-move
delivery. This is a proved parameter split, not a finite extrapolation.

The parent independently attacked and approved the first ordinary proof.
The singleton extension was sent separately for review. Its quantitative
certificate checks are distinct from that ordinary proof review.

The source now freezes the original 61 dense cells. Its read-only --check
mode recomputes fixed graphs/certificates against that list, so later
coverage updates cannot silently change what this receipt certifies.

## Nine-core and arbitrary-duration composition

A bounded new search used the actual finite game rather than the
two-move sufficient test. Its nine-vertex two-out missing graph reached
all 18 guaranteed pairs after about 0.05 seconds, inside its 20-second cap.
The literal result appears in src/dense_third_core_compose.py. Both
independent Python solvers and rank-certificate replay confirm 18 pairs;
only 14 meet the two-move criterion, with three moves sufficient globally.
The raw best-score trail is dense-third-small-core-search.jsonl. A separate
five-second eight-vertex probe reached 12 of 16, with no upper exclusion
claimed. No further broad small-core search was launched.

The retained two-move block lemma could not by itself compose this graph.
Directly reviewing the game yielded a stronger statement: disjoint union
of positive-outdegree missing blocks gives exact addition of I, even for
arbitrary-duration guarantees. If the cop exits, the messenger can use its
missing neighbor in that outside block, then cross-deliver. If an internal
pair loses, its cop stays inside and immediately captures any messenger
excursion via the complete cross arrows. The parent independently suggested
the equality direction, and the proof is now in paper/dense-third.md.

The nine-core resolves (9,54). Combining it with functional r=2,3,4
additionally resolves (11,90), (12,111), (13,134), beyond the 34 root-cycle cells.
The same formula works for every r>=2 with k=9. Its six fixed verification
graphs include r=5,6 as an adversarial composition check. The recipe itself
is a fixed literal finite core and a formula, never a rerun of its search.

## First-step attachments and the threshold thirteen

The existing four-vertex first-step gadget was tested against the fixed
nine-, ten-, and eleven-vertex cores, keeping the core unchanged and
choosing only the two attachment rows. There were 341 evaluated templates
in total, taking about 0.37 seconds. All three target first-step values were
found and then verified with both solvers and full alternating certificates:
n=13 uses rows {1,2}/{3,4}; n=14 uses {0,7}/{1,8}; n=15 uses {0,3}/{1,5}.
The other added rows remain c→x and x→y,z. Delivery bounds are 4,3,3.

Those finite constructions plus the root and composition theorems complete
the entire final dense band for every n>=13, with a four-move bound. The
previous independent two-move proof remains available for every n>=16;
the larger construction domain is not misreported as a two-move domain.
There are now 40 new dense cells plus one main endpoint cell, and 21 residual
dense cells below 13. The fixed graph recipes and --check verifier are retained
in src/dense_third_first_step.py; --search is a separate discovery option.

## A genuine small-order loss in the second step

The parent requested a bounded equality analysis rather than further broad
small-core search. Theorem 27's proof forces a staircase attainer at r=2
to have exactly two missing-outdegree-one vertices, forming a disjoint
two-cycle. Every other missing row has outdegree two and cannot enter that
cycle: doing so makes its whole source row lose against the other cycle cop.
The arbitrary-duration additivity lemma then proves exact equivalence between
attaining the r=2 staircase at n and attaining the dense endpoint at n−2.

This is an outdegree-two missing core, not a two-in/two-out regularity
claim. No two-move restriction is used. The existing complete tables
M(5,10)=3 and M(6,18)=6 therefore give M(7,30)<=9 and M(8,42)<=11,
one below their previous staircase caps of 10 and 12. No matching new
graphs are asserted here. The analogous seven/eight-core endpoints remain
unresolved; the earlier five-second eight-core failure is not promoted to
an exclusion.

The ordinary proof and its maximal-bound consequence are in
paper/dense-third.md. src/dense_third_r2_reduction.py pins and checks only
the existing numerical premises, with its proof boundary explicitly saved.

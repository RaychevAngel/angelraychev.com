# A sharp staircase across most of the final dense band

## Provenance and status

Angel proposed separating the sparse endpoints, existence across the main
interval, explicit optimal constructions, and forced losses in the final
dense band. He pointed out that a constant loss of two was inadequate to
describe the progression toward a loss of approximately n/2. The following
growing-loss bound and matching construction were derived in response and
independently checked by a second agent. They are ordinary proofs; they
are not yet incorporated into Lean or the public manuscript. No heavy
computation was required.

Use the exact delivery timing in HANDOFF.md, especially immediate receipt
before a pursuer response. All graphs are finite, simple, loopless, directed.

## Notation

Let F be the loopless directed complement of G. Write

    h=|E(F)|=n(n-1)-m,
    q(v)=d_F^+(v),
    D=h-I(G).

Thus D counts the missing ordered pairs which are not guaranteed. In the
final band n<=h<2n, put r=2n-h=m-n(n-3), so 1<=r<=n.

## The growing-loss bound

**Theorem.** For n>=2 and any admissible n<=h<2n,

    I(G) <= h-ceil((2n-h)/2)-1.

Equivalently, for 1<=r<=n and admissible m=n(n-3)+r,

    M(n,m) <= 2n-r-ceil(r/2)-1.

**Proof.** If I=0, the bound holds: its right-hand side is increasing
with h and at h=n equals floor((n-2)/2)>=0. Otherwise q(v)>=1 for every
vertex. Indeed, a vertex c with q(c)=0 can intercept every nonterminal
departure from every other source, while its own source row has no
missing pair to contribute.

Let L={c:q(c)=1}, with cardinality ell. Since

    h >= ell+2(n-ell)=2n-ell,

we have ell>=2n-h>=1. For c in L let f(c) be its unique missing neighbor;
f(c)!=c. Put U=f(L), a=|U intersect L|, and b=|U minus L|.

Every source x in U is killed: choose c in L with f(c)=x. The pursuer
at c has closed outgoing neighborhood V minus {x}; any nonterminal
departure from source x is intercepted. This loses all q(x) pairs in
that source row.

There is a second obstruction. If two distinct c,c' in L satisfy
f(c)=f(c')=x, then the missing pair (c,x) loses against a pursuer at c'.
Every possible intermediate vertex is in its closed outgoing neighborhood;
the one excluded vertex is the recipient, which cannot be reached directly.

Let R consist of c in L minus U for which f(c) has exactly one preimage
in L, and let rho=|R|. Every missing edge with tail in L minus R loses,
by one of the preceding two obstructions. These supply ell-rho losses.
The killed source rows U minus L supply at least 2b further losses,
disjoint because their tails lie outside L. Therefore

    D >= ell-rho+2b.

If b>=1, then rho<=ell-a and rho<=a+b. The latter follows because
distinct members of R have distinct images in U. Consequently

    D >= max(a+2b, ell-a+b)
      >= ceil((ell+3b)/2)
      >= ceil(ell/2)+1.

If b=0, f maps L into itself and has no fixed point. Its finite functional
graph has a directed cycle of length at least two. The cycle vertices lie
in U, and each already has a preimage in U. None can be the image of a
member of R: that would give two preimages in L, since R is disjoint from
U. At least two possible images are therefore excluded, so rho<=a-2.
Together with rho<=ell-a this gives

    D >= max(a, ell-a+2) >= ceil(ell/2)+1.

In both cases D>=ceil((2n-h)/2)+1. QED.

The loss relative to the naive missing-pair bound is therefore at least

    2,2,3,3,4,4,...,ceil(n/2)+1

as r runs from 1 to n. At r=0 this argument does not apply; the previously
proved all-delivery construction has zero loss. At r=n the bound matches
the known exact value floor((n-2)/2).

## Joining complementary blocks

**Lemma.** Suppose F is a disjoint union of missing-edge graphs F_i, each
vertex has positive outgoing degree in its own F_i, and in the complement
G_i every counted winning pair has a two-move strategy. Let G be the
complement of the entire F, so every cross-block directed arc belongs to G.
Then all those within-block winning missing pairs remain winning in G.

**Proof.** For source and target in block i and an initial cop in that
block, use the old safe intermediate vertex. Its absence from the cop's
closed outgoing neighborhood is unchanged. Even if the cop next moves
outside the block, the messenger immediately delivers on its next move.

For an initial cop c in another block, choose any outgoing F-neighbor u
of c in that other block. Both s->u and u->t are cross-block arcs in G,
while c->u is missing. Also u!=c,s,t. Thus the same two-move delivery
works. QED.

No general preservation of arbitrary multi-move strategies is claimed.
The two-move guarantee and positive missing outgoing degree are essential
to this stated argument.

## An explicit attaining construction

**Theorem.** For every n and every integer r with

    2<=r<=n-52,

there is an explicit graph with m=n(n-3)+r arcs satisfying

    M(n,m)=I(G)=2n-r-ceil(r/2)-1.

Equivalently, equality in the growing-loss bound holds whenever

    n+52<=h<=2n-2.

The interval is nonempty for n>=54.

**Construction and proof.** Put k=n-r>=52. On a block of r vertices,
take the functional missing-edge extremizer from Theorem 13 of the existing
manuscript. More explicitly, set j=floor((r-2)/2); use vertices a,b and
pairs s_i,t_i (1<=i<=j), with one additional vertex z when r is odd.
The missing arcs are

    s_i->t_i, t_i->a, a->b, b->a,

and z->a when present. There is exactly one missing outgoing arc per
vertex. Its complement has j guaranteed missing pairs (s_i,t_i), each
deliverable in two moves, as established by the functional-graph proof.

On a disjoint block of k vertices, use the four-regular girth-six graph
from Theorem 19 and orient Euler tours. The resulting missing-edge graph
has two incoming and two outgoing arcs per vertex. Its complement
guarantees all 2k missing pairs in two moves. This is the existing explicit
all-order construction for k>=52, with its finite structural certificate
below k=130 and ordinary induction from k=130.

Take F to be the disjoint union of these two missing-edge blocks. Then

    |V(F)|=r+k=n,
    |E(F)|=r+2k=2n-r=h.

By the joining lemma, its complement guarantees at least

    j+2k
      = floor((r-2)/2)+2(n-r)
      = 2n-r-ceil(r/2)-1

missing pairs. The growing-loss upper bound proves equality, so no
additional analysis of other pairs is needed. QED.

## What remains

The newly sharp interval leaves r=1 and the fixed-width range
n-51<=r<=n-1 outside its uniform claim. The endpoint r=n is already
known exactly, and r=0 is known for n>=52. Other available two-move
all-delivery complement blocks supply additional individual offsets:
the explicit 26-vertex incidence block already covers k=26 when r>=2.
The five-type complement proof has a three-move exceptional state, so
the joining lemma above does not automatically apply to that family.
This note does not classify every remaining small offset.

For larger k, the entire sharp interval above is explicit. Thus the
fourth research direction now has both a growing upper bound and matching
constructions across all but a fixed-width portion of the final band,
plus the first step. General sparse attainment and the main-interval
existence conjecture remain separate open goals.

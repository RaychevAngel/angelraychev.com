# Explicit-construction audit: main-interval families

## Current simplified recipe — 18 September 2026

The current dispatcher is `src/main_interval_complete.py`, with the pair-code
construction in `src/main_interval_pair_codes.py`. For k>=6 and
2k<=n<=k(k-3), separated two-element missing-hub codes provide every budget
(4k-2)n-2k(2k+1)<=m<=n(n-3), with every optional subset and two-move delivery.
The generalized Theorem59 preserves all old larger codes. The ordinary circle
overlap covers3n..n(n-3) for every n>=79; below79 the retained finite interval
plans need layered/reduced hubs and the tiny dense providers at13 and14, but
no unbounded larger-code family or generic dense connector. The sparse
2n..3n proof remains separate. Fresh checks have their own receipts; all old
source-pinned records below retain their original historical scopes.


The original audit below records the initial scope-correction checkpoint.
Its source hashes and threshold 115 are retained as historical evidence.
The dated third-pass supplement at the end gives the current direct domains,
including the complete main interval from order 106.

Date: 2026-09-13. Scope: read-only inspection of the current main-interval proofs, adjacency procedures, and existing parameter/certificate records. No graph search, parameter search, new proof, or numerical-ledger change was performed. The audit applies the requested meaning of an explicit construction: a concrete adjacency or composition rule with parameters selected from `(n,m)`. A generic search for a winning graph or a conditional-expectation algorithm is not classified as a direct recipe merely because it terminates deterministically.

## Conclusion

**Every `n >= 115` and `2n <= m <= n(n-3)` already has a direct, nonderandomized attaining recipe.** Theorem 44 and the executable `src/main_interval_composed.py` use only packed sparse, protected-circle, antichain, protected-missing, and direct dense constructions. They do not call either conditional-expectation constructor or a game solver when producing a graph.

Theorem 54 and the orientation specialization retain genuine stronger statements about specified routing sets, incident budgets, arbitrary exterior arrows and two-move delivery. Their current general procedures are conditional-expectation algorithms. They should remain labelled that way under the requested construction criterion. Their numerical count consequences do not create a new infinite construction gap: the complete main interval has the separate direct recipe above. This numerical replacement does not establish those stronger routing properties for the replacement graph.

## Direct families and their precise domains

1. **Three-step circle, Theorem 11.** Odd `h >= 7`, `2h+1 <= n`, `gcd(h,n)=1`; budget `m=3n`. Put arrows `v -> v+1, v+(h-1)/2, v+h` modulo `n`. `paper/main.md:197`. Lemma 12 supplies such an `h` for every `n >= 25`; its appendix gives casewise choices.

2. **Protected circle, Theorem 38.** Every `n >= 25`, `3n <= m <= n(ceil(n/7)-1)`. Start with `A={0,1,(h-1)/2,h}`; repeatedly adjoin the least residue outside `A union (A+D)`, where `D` is the six specified core differences. Include the three compulsory steps and the first required optional arrows. `paper/main-interval-resume.md:5`; `src/main_interval_resume.py:21,45`.

3. **Wider protected circle.** For any allowed `h`, put `a=(h-1)/2`, `p=3a-1`, `J={jp+t: 0<=j<floor(n/p), 0<=t<a-1}`. The guaranteed envelope size is at least `max(4,ceil(n/7),4+ceil(|J|(n-19)/n))` when combined with Theorem 38 at `n >= 25`; any resulting envelope `A` gives every `3n <= m <= n(|A|-1)`. Translate this specified set `J`; remove `A0 union (A0+D)`; adjoin `A0`; apply the same residue-extension rule if needed. Check at most `n` translates to meet the proved size bound. `paper/core-code-composition.md:97`. Saved larger envelopes give their literal finite domains after direct difference checks.

4. **Sidon circle, Theorem 34.** `n >= 25,m=3n`; additionally `d>=4,n>d^3+2d` gives every `3n<=m<=dn`. Least-residue extension avoiding the explicitly listed old/new difference collisions, followed by an optional-arrow prefix. `paper/main-interval-explicit.md:5`; `src/sidon_main_interval.py:21,46`. The protected-circle theorem numerically supersedes this guarantee but its recipe remains direct.

5. **Equal-weight antichain, Theorem 59.** Odd `k>=7`, `3<=r<=floor(k/2)`, `q=n-2k>=0`, `q<=2C(k,r)`, where `C(k,r)=k*binom(k-r,r)/(k-r)`. Every `A<=m<=A+q(q-1)`, with `A=2k(2k-3)+(4k-r)q`. List cyclic nonadjacent `r`-subsets in lexicographic order; their doubled indices give point codes and their original indices give line codes. Take the first `q` codes. Use the displayed two-part hub adjacency, all hub-to-outside arrows, and all outside-to-hub arrows except each vertex's code; take a prefix of outside-to-outside arrows. `paper/core-code-composition.md:10,80`; `src/core_code_composition.py:21,38`.

6. **General antichain, Theorem 59.** Any `k>=5` and supplied family of `q` incomparable hub sets satisfying the stated part, size and spacing conditions. With total code weight `W`, every `2k(2k-3)+4kq-W <= m <= 2k(2k-3)+4kq-W+q(q-1)`. The adjacency composition is completely specified once the codes are supplied. The general conditional theorem alone is not a parameter-selection rule from every `(n,m)`. Unprovided even-core or mixed-size codes must not be called an already completed direct construction. The particular mixed order-116 codes are supplied explicitly.

All entries above guarantee `I=n(n-1)-m` on the stated domain. Antichain delivery takes at most two messenger moves. The protected circles retain their finite propagation strategy, not a uniform two-move claim.

### Why the local listing procedures qualify

The circle extension checks membership in an explicit forbidden-residue set. Its counting proof guarantees an available residue at every step. It neither backtracks nor tests whether a candidate graph wins. Selecting the least admissible coprime step is likewise bounded integer parameter selection; the appendix even supplies casewise alternatives.

The equal-weight code routine lists subsets satisfying a fixed spacing condition. Every listed code is certified by that condition and the ordinary composition proof; there is no pursuit-game test or optimization over graph topologies. Parameter selection can check the displayed capacity and interval inequalities in a bounded integer loop, then use the first applicable tuple. This is a specified family procedure, not “enumerate graphs until an attainer is found.”

Do not overstate runtime for unrestricted antichain inputs: the current `codes()` implementation scans combinations and the audit does not claim it is polynomial for every growing `k,r`. The complete main-interval recipe only uses `r=3,4,5`; its unbounded branch has `r=3` and `k=O(n^(1/3))`. Its stated polynomial construction therefore does not depend on unrestricted subset enumeration.

## Complete recipe at every order from 115

The source is `paper/exact-budget-derandomization.md:26` (Theorem 44), with the actual overlap proof at `paper/core-code-composition.md:118` and selection code at `src/main_interval_composed.py:63,192`. The filename containing “derandomization” is historical; the current proof of Theorem 44 does not use derandomization.

The selected intervals are:

1. Theorem 52 supplies the packed sparse base on `n=6k-r` vertices, `k=ceil(n/6)`, `0<=r<=5`, with fixed holes at `0,3,...,3(r-1)`. Its explicit allowed-arrow list supplies every `2n<=m<=20k-11r`, including `2n..3n`. The proof uses retained local certificates and ordinary projection; the adjacency rule is fixed. See `src/main_interval_composed.py:108` and `paper/sparse-packed-holes.md:8`.
2. The protected circle supplies `3n..circle_max`.
3. The selected antichain supplies `code_base..code_max`, with `code_base<=circle_max`.
4. Its terminal missing count is within the direct dense envelopes. Theorem 48 supplies `3n<=h<=n*max(3,ceil((n-1)/13))` by a least-residue missing-step recipe, and Theorem 58 supplies `2n<=h<=3n` by a fixed two-type core and optional arcs. Taking complements reaches `m=n(n-3)`. See `src/main_interval_composed.py:176`, `src/dense_protected_envelope.py:12,32` and `paper/dense-unified-core.md`.

These are exact budgets because every optional subset is proved valid; an ordered prefix supplies the requested number of arrows without evaluating the game.

- **`115..390`.** The 276 saved rows in `research/core-code-circle-overlap-screen.json` give literal `h`, closed envelope `A`, and `k,r`. The chosen equal-code tuples belong to `{(11,3),(11,4),(13,4),(13,5)}`. The constructor checks their protected differences, capacity and overlap.

- **`n=116` correction.** Use the saved 94 codes in `research/routing-defect-phase2-mixed-code-checks.json`: two of size five and 92 of size four, total weight 378 and base 4176. The ordinary alternative recipe takes the first two size-five codes, deletes their contained size-four codes, and takes the first 92 remaining.

- **`n=117` correction.** Use `h=41` and the literal 38-member envelope `{0,1,20} union [41,59] union [100,115]`, reaching 4329 arrows; code base 4218.

- **`391..480`.** Fixed `k=15,r=4`, code base `56n-870`; ordinary Theorem 38 circle.

- **`481..699`.** Fixed `k=17,r=5`, code base `63n-1088`; ordinary Theorem 38 circle.

- **`n>=700`.** Set `r=3`; let `c` be the least integer with `c^3>=6n`; take `k=c+5` if odd and `k=c+6` otherwise. This is precisely the proved interval `(6n)^(1/3)+5 <= k < (6n)^(1/3)+7`. The code terminal missing count is `3n-2k`, inside the dense bridge.

The finite table is a **parameter certificate for 276 orders**, not 276 unrelated literal game exceptions and not an assumption that a search will succeed later. Each record supplies a concrete core and optional envelope that generates every intervening budget by an ordinary theorem. Its discovery may have used parameter screening; using the fixed records requires no renewed screening. The historical screen's order-116 and order-117 rows still flag their original overlap failure; the composed constructor correctly applies the separate two corrections above instead of treating those flags as positive evidence.

The tail `n>=391` is independently covered by the displayed fixed choices and the ordinary all-order inequality; no finite experiment is extrapolated to establish it. The current executable uses exact integer cube-root arithmetic. The saved `research/main-interval-composed-checks.json` records 223 boundary constructions, all five branches and all 276 finite parameter rows. This audit read that existing receipt and confirmed its source hash, without rerunning its graph checks.

## Algorithms that remain derandomization or existence results

Theorem 54 (`paper/routing-unification.md:8`) has `n>=4`, specified `H` of size `b`, `Q=b(2n-b-1)`, integer `0<a<Q`, `p=a/Q`, and sufficient condition

`(b-3)p^2(1-p) > 4 log n + log(8/3)`.

It covers every `a<=m<=a+(n-b)(n-b-1)`. The implementation `src/routing_unification.py:70` assigns incident arrows one by one using exact bad-completion counts. That is a valid deterministic polynomial algorithm, but not the requested direct structural recipe. Its independent random-sampling probability bound is an existence/probability result, not a concrete adjacency rule.

The full-vertex specializations are Theorem 25/43 with `(n-3)p^2(1-p)>5 log n`, and Proposition 51 with `(n-3)p^2(1-p)>4 log n+log(8/3)`, `p=m/[n(n-1)]`. `src/exact_budget_derandomize.py:45` performs the corresponding conditional-count decisions. These have the same classification.

The orientation specialization (`paper/routing-unification.md:110`) covers `[Q/2,L-Q/2]` when

`n(n-1)(n-2)(7/8)^(b-3) + n(n-1)(3/4)^(b-2) < 1`.

Its coarser condition is `n(n-1)^2(7/8)^(b-3)<1`. Corollary 55 selects `b=ceil(24 log n+4)` when `b<=n`, and extends the interval through `n(n-3)` at `n>=4096`. The implementation `src/routing_defect_phase2_orientation.py:61` also chooses each orientation by conditional-completion counts. Its existing large examples are sampled and checked, not executions of a general direct adjacency formula. Neither deterministic termination nor replacing polynomial coefficients by products changes this construction classification.

Corollary 39's older asymptotic overlap uses a probabilistic middle interval. Its numerical conclusion now has the separate direct Theorem 44 construction at the explicit threshold 115; the older proof need not be recategorized.

## Construction gaps and limits of the conclusion

There is no remaining construction-only gap in the full `n>=115` main interval. The coordinate-level recipe and parameter split are already present.

For the residual box `1<=n<=114`, the root task performed a separate arithmetic comparison with the orientation contribution omitted: no lower bound changed, no exact cell lost equality, and no final exact cell was supplied only by orientation. The report is `research/explicit-construction-coverage.json`. Thus orientation creates no extra construction-only numerical cells relative to the other incorporated recipes in this box. Theorem 54's sufficient inequality is already recorded as inapplicable throughout this box. This observation is about the numerical ledger; it does not replace the audit of the other sparse/dense/finite recipes.

Actual unresolved numerical intervals remain unresolved. General unprovided antichains and unprovided protected sets remain conditional family opportunities. A direct graph with the same `I` does not inherit a specified routing set, a prescribed incident budget, every exterior-arrow freedom or a two-move bound from the derandomized graph. No stronger replacement is claimed here.

The reviewed composed-constructor source SHA-256 is `5ae54a716a8584d802f19f0d95790f84c0d59119a456caf52a9328de9580f973`, matching its retained receipt. All other files were left unchanged.

## Third-pass supplement: 13 September 2026

This source review adds the following direct construction domains to the
historical audit. No new parameter or graph search was run to update this
document, and the preceding source identities are not overwritten by fresh
ledger hashes.

**All-parity equal-weight codes are now supplied.** The counting and
listing proof in `paper/core-code-composition.md` applies to every `k>=5`
and `3<=r<=floor(k/2)`. Write `C(t,0)=1`, zero for negative `j` or
`2j>t`, and `C(t,j)=t*binom(t-j,j)/(t-j)` otherwise. The line-part
capacity is `C(k,r)`. The point-part capacity is another `C(k,r)` at
odd `k`, and `sum_j C(k/2,j)C(k/2,r-j)` at even `k`. Their sum is
`Q(k,r)`. Every `q=n-2k` with `0<=q<=Q(k,r)` gives all budgets
`A..A+q(q-1)`, where `A=2k(2k-3)+(4k-r)q`.

`src/core_code_all_parities.py` lists line codes first, then point codes.
Independent sets are produced by a gap recursion. For an even point part,
the numbers selected on its two cycles are enumerated in increasing order,
and their independent sets are listed in the stated fixed order. Taking
the first `q` codes is sufficient; there is no candidate-game evaluation.
The adjacency is the original two-part hub construction, with the specified
outside-to-hub exclusions and an outside-arrow prefix. The method preserves
two-move delivery and every optional subset. Thus the former statement
about *unprovided even-core codes* no longer applies to this supplied
equal-weight family. Arbitrary other code inputs remain conditional.

In particular, `k=10,r=3` has `Q=100` and covers every
`37n-400<=m<=n(n-1)-(3n-20)` for `20<=n<=120`. The literal mixed
list at `n=105,k=10` contains 85 codes of total weight 268 and gives
`3472..10612`. It is read from `research/core-code-third-mixed-105.json`;
its bounded optimization history is not part of the construction procedure.
Its two-move and arbitrary-optional-subset guarantees are retained.

**The additional protected circles are fixed inputs.** At orders
`100,101,...,111`, the corresponding exact ranges are `3n..b_n`, where
`b_n` is respectively
`3100,3131,3264,3296,3432,3465,3604,3638,3780,3706,3740,3774`.
`research/core-code-third-circle-envelopes.json` stores every `h` and
every residue of the envelope. `src/core_code_third_circles.py` checks the
six protected differences directly and takes an optional prefix. Its
separate `--discover` option is not called to construct or verify a graph.
The ordinary protected-circle strategy establishes the supplied inputs;
these are not finite game tests extrapolated to other orders.

**The complete main interval now starts at 106.** For each `106<=n<=114`,
the finite sparse envelope covers `2n..3n` (with the two listed extra
optional arrows at 109). Use the newly saved circle through 111 and the
earlier saved circle at 112,113,114. Its endpoint reaches `37n-400`,
the base of the `k=10,r=3` code interval. The latter reaches
`n(n-1)-(3n-20)`, beyond the start `n(n-1)-3n` of the direct dense
bridge. These exact integer overlaps give every budget through `n(n-3)`.
The unchanged ordinary/fixed-parameter procedure above supplies all
`n>=115`. Select a covering family in this order and its optional prefix;
the resulting composition is also implemented in the updated `src/main_interval_composed.py`.

This extension does not alter the classification of Theorem 54 or the
orientation algorithms: their general procedures still use conditional
expectation, and their specified-routing and timing guarantees remain
their own. The new direct count coverage requires no such algorithm.
The current unknown numerical box is contained in `n<=105`, and the
main-region canonical count is 48,271. A separate source/method audit is
still required for explicit coverage; the smaller numerical box alone is
not its proof. No ledger hash is pinned by this supplement while the root
task consolidates the release.

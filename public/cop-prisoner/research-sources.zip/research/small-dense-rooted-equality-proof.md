# Equality reductions for the third and fourth dense steps

Private research note for independent review; no canonical theorem or
ledger change is made by this note.

Write q(v)=d_F^+(v), h=2n-r and Delta=h-I. If I>0, every q(v)>0.
Let S={v:q(v)=1}, ell=|S| and e=sum_v max(q(v)-2,0). Then

    ell = r+e,       Delta >= ceil(ell/2)+1.

Use the notation from the established degree-one proof: U=f(S),
a=|U intersect S|, b=|U minus S|, and R consists of vertices in S minus U
whose images have exactly one preimage in S. Write rho_count=|R|.
That proof gives

    Delta >= ell-rho_count+2b;
    b>0 => Delta >= max(a+2b,ell-a+b);
    b=0 => Delta >= max(a,ell-a+2).

Every vertex of U has a completely killed missing source row. Additionally,
if v outside S has a missing arrow into U, a degree-one pursuer whose image
is that neighbor kills the entire row of v. Thus, when the losses already
fill their allowed total, all other missing rows must avoid U.

## Fourth step: exact rooted two-out reduction

Equality at r=4 requires Delta=3. The degree identity and bound force
ell=4 and e=0. If b>=1, the displayed bound gives Delta>=4, impossible.
Thus f maps S to itself. The b=0 inequality forces a=3, and equality
requires exactly one member of R. A loopless functional graph on four
vertices with this property must be

    rho -> t0 -> a <-> b.

Indeed rho is the sole vertex outside U; its image t0 must have a unique
preimage and therefore cannot lie on a cycle. The other two vertices
form the required cycle. Exactly the rows t0,a,b supply the three losses.
All outside rows have degree two and avoid U={t0,a,b}, so they have the
corrected safe-root interface on K=V minus S, with root rho.

The transfer and converse in `small-dense-root-designation-proof.md` now
give the proposed exact equivalence

    M(n,n(n-3)+4)=2n-7  iff  R2(n-4) exists.

## Third step: exactly two rooted degree families

Equality at r=3 also has Delta=3, so ell is three or four.

If ell=4, e=1. The same functional argument gives the four-vertex path
gadget above. Exactly one outside missing row has degree three; the others
have degree two. All avoid U and all must win. This is the corrected
rooted interface on n-4 vertices with one degree-three row.

If ell=3, e=0. The case b>=2 is excluded immediately. If b=1, the two
displayed inequalities force a=1 and rho_count>=2. Then U={u,x}, where
u lies in S and x is outside S. The two members of S minus U would need
unique, distinct images u,x. But f(u)=x (looplessness excludes u), which
duplicates the image x, a contradiction. Hence b=0.

The functional graph on S is either a three-cycle or a two-cycle with a
single incoming tail rho. All three functional pairs fail. In the latter
case outside missing rows may use rho but must avoid the two cycle
vertices: exactly the rooted two-out interface on n-3 vertices. In the
three-cycle case outside rows avoid all of S, giving the same interface
with an unused root (every cop can capture an attempted root entry).

Conversely either rooted interface supplies equality by the corresponding
functional gadget. Therefore the proposed equality characterization is

    r=3 equality at n iff R2(n-3) exists, or a rooted interface on n-4
    vertices exists with exactly one degree-three row and all others two.

## Complete small rooted-family enumeration

The complete finite checks are in `src/small_dense_rooted_exclusion.py`.
Every core row is loopless and the root is fixed. No indegree restriction
is imposed. Two partial obstructions are sufficient for pruning:

- F(c) contained in F(s) union {s}, for distinct core vertices c,s,
  kills source row s. This includes unsafe root-arrival behavior.
- If all members of F(c) lie in K and their completed outgoing missing
  rows have a common target t (including t=root), camping at c blocks
  every delivery predecessor of t and loses its exhibited missing pairs.
  A row containing root is not pruned by this intersection test.

For two-out rows, if any row uses root, label its source 0 and other
neighbor 1. Source camping forbids root in row1. Up to relabeling the
remaining core vertices, row1 is {0,2} or {2,3}. These are the two root-use
normal forms. If no row uses root, the game reduces to the ordinary core:
the two depth-two normal forms from the endpoint note apply. Four distinct
second neighbors avoiding the first two require at least six core vertices,
so the no-root class is impossible below six. At six only the mutual form
is possible; at seven both are included.

For one degree-three row, label its unique source 0. Its neighbors either
include root, giving {1,2,root}, or exclude root, giving {1,2,3}. All
remaining two-element rows are enumerated in chronological order.

The complete results are:

| Core family | Prefix nodes | Static leaves | Universal leaves |
|---|---:|---:|---:|
| R2(3) | 4 | 0 | 0 |
| R2(4) | 14 | 0 | 0 |
| R2(5) | 72 | 0 | 0 |
| R2(6) | 1168 | 6 | 0 |
| One degree-three row, k=3 | 4 | 0 | 0 |
| One degree-three row, k=4 | 74 | 0 | 0 |
| One degree-three row, k=5 | 1442 | 0 | 0 |

The six static leaves are additionally converted into full nine-vertex
delivery graphs with the three-vertex functional gadget. Both independent
existing actual-game solvers agree, and every winning and losing rank is
replayed. Their core-position winning masks agree with the corrected
rooted solver. These full negative certificates are in
`research/small-dense-rooted-small-negative-certificates.json`; the complete
prefix data are in `research/small-dense-rooted-small-enumeration.json`.

Subject to independent review of the reductions and finite coverage, this
would give the stricter bounds

    r=3: (7,31)<=7, (8,43)<=9, (9,57)<=11;
    r=4: (7,32)<=6, (8,44)<=8, (9,58)<=10, (10,74)<=12.

These bounds are not claimed exact. Together with the newly certified
R2(7), they make the individual eventual-staircase thresholds sharp: order
ten for r=3 and order eleven for r=4. The safe-root definition is essential;
an unconditional root terminal would invalidate this analysis.

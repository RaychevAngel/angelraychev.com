# Independent review of the staged sparse certificates

13 September 2026. Reviewed `src/sparse_staged_engine.cpp`,
`src/sparse_staged_replay.cpp`, and `src/sparse_staged.py`. No source changes
were made. The quantitative receipt is
`research/sparse-staged-independent-review.json`.

## Semantic audit

The engine's collapsed recurrence matches the actual alternating game.
The target row is universally terminal; consequently a direct messenger
move to the occupied recipient succeeds before capture. For a nonterminal
successor, the engine requires every **closed** envelope successor of the
pursuer to belong to the previously winning layer. Since that layer excludes
nonterminal collisions and the envelope includes waiting, this checks both
immediate and post-response capture. The messenger may wait because the
base neighborhoods are closed too.

All new ranks and policies use the preceding complete layer. There is no
same-layer circular dependence. The recurrence is monotone from its
terminal initialization, even though the code does not separately union
the old winning set into each new set. Its stopping condition includes
every noncollision source/pursuer pair. The engine reports failure of its
finite reachability computation without turning that into an extremal
upper-bound claim.

The separate C++ replay uses literal byte adjacency, saved ranks, and
saved actions, not the engine's masks or fixed-point iteration. It checks
the target exception first, gives every other collision rank minus one,
requires positive rank elsewhere, validates the messenger action, and
requires every legal pursuer reply to avoid capture and strictly decrease
rank. These obligations prove finite delivery against arbitrary legal
history-dependent pursuer choices. No future pursuer action is revealed
to the messenger by this certificate.

For n<=120, the largest possible discovery layer is at most the number
of nonterminal game states, less than32767. Signed16bit ranks and actions
are therefore sufficient for these finite records. The metadata audit
also checks vertex ranges, looplessness, uniqueness, and the promised2n
base count, so no out-of-range mask bit occurs in the reviewed inputs.

## Encoding, stages, and skipped cells

The raw member layout is exactly two consecutive arrays of n³ little-endian
signed16bit entries: ranks[t,s,c], then policies[t,s,c]. The independent
parser checks byte length4n³, explicitly handles host endianness, and
checks the saved member hash. The zip's internal manifest agrees with the
external record file on records, encoding, and counts. The whole bundle
hash also agrees.

Each stage uses a fixed messenger base and a larger pursuer envelope.
Its binary-search predicate is monotone because only the pursuer's options
grow while that base stays fixed. This is not the invalid assertion that
adding arrows to both players preserves winning. Every intermediate
prefix graph lies between the certified base and envelope; indeed every
subset of the stage's optional arrows works. Stage endpoints, prefix
indices, unique arrow counts, and constructor bounds were checked.

Previously proved cells may lie between recorded stages. The dispatcher
does not claim their literal prefix graphs work; the earlier construction
families supply those cells. Against the frozen preceding ledger, all2217
previously unknown2n..3n cells were covered by recorded stages. Every stored
stage has a nonnegative prefix start. The updated certifier's dynamic
maximum len(added) and discovery m_max correctly replace the old hardcoded
3n endpoint when extending the small orders farther. A refreshed bundle
must receive its own coverage/hash readback before its larger domain is
attributed to this receipt.

## Independent executable attack

To avoid races with the next certificate build, this review used a frozen
copy of the60-order,441-stage bundle with SHA256
`ecac7b6ae1d7dd0fe5a037fc461c1192de11190f26cd439e7cc4f3d9491eabac`.
All metadata were checked. Five selected envelopes received an independent
Python replay of every supplied rank obligation for every recipient:

* n12, first stage24..25 and last stage31..36;
* n91, first stage182..206 and last stage263..273;
* n103, its stage305..309.

These checks covered2603325 source/pursuer/recipient states and9376249
pursuer replies. They also exercised masks above the low64bit boundary.

A separately written explicit two-turn game graph then computed its
least attractor by a priority queue. Messenger states are existential
with one move of cost; pursuer states are universal with zero additional
messenger cost. Terminal receipt and nonterminal collision are handled as
distinct terminal cases. At recipient0, the middle recipient, and the last
recipient of each selected envelope, all82377 messenger-state minimum
ranks exactly matched the stored C++ ranks. This implementation does not
use the collapsed C++ recurrence or call either C++ library.

No semantic defect was found. The selected independent replay is not
described as a full Python replay of all441 stages; the root's complete
C++ certificate replay supplies the full finite catalogue check.

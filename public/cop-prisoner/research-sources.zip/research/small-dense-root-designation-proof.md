# Safe root designation and small dense constructions

Private research proof and evidence note. The numerical conclusions below
require independent review before canonical integration. No full Lean claim.

## Correct safe-root interface

Let K have k vertices and let rho be one additional vertex. Every v in K
has a missing-neighbor set F(v) contained in (K minus v) union {rho}.
The messenger may wait or follow a delivery arrow in K union {rho}.
Nonterminal pursuer positions lie in K. Pursuer moves within K retain the
ordinary rules, including waits and capture. An attempted messenger arrival
at rho is treated as follows:

- For recipient rho, receipt wins before the pursuer replies.
- For recipient t in K, arrival is useful only if rho belongs to F(c), where
  c is the current pursuer. Otherwise the pursuer captures at rho.
- A safe arrival at rho gives direct receipt on the following messenger move.

In particular, merely restricting surviving pursuer positions to K must not
remove the pursuer's ability to capture an unsafe arrival at rho.

## Root designation lemma

Suppose the complement of a missing graph H on k+1 vertices guarantees all
its missing pairs. Designate any vertex rho as a root and retain the other
missing rows, forgetting only H(rho). The corrected rooted interface
guarantees every retained missing pair.

Fix such a pair and an initial pursuer in K. Follow the original winning
strategy while both players remain in K. An original direct delivery remains
available. If that strategy first reaches rho and rho is the recipient,
receipt wins immediately. If rho is not the recipient, an original winning
strategy can choose it only with safe arrival: otherwise the original
pursuer could capture immediately. After safe arrival the root's strengthened
delivery row supplies the actual recipient on the following move. If rho is
never reached, every move and every pursuer response is an original legal
play, so the original finite winning strategy succeeds. This proves the
lemma without resetting its rank after a pursuer excursion.

## Functional replacement lemma

Assume each retained missing row has at least two distinct neighbors, and
the corrected rooted interface guarantees all retained missing pairs. Attach
either of the following missing functional gadgets, with no other missing
arrows involving their nonroot vertices:

- three vertices total: rho -> a, a -> b, b -> a;
- four vertices total: rho -> t0, t0 -> a, a -> b, b -> a.

The delivery graph is the loopless complement. While a pursuer stays in K,
it can capture every messenger excursion into a nonroot gadget vertex.
Safe arrival at rho permits direct delivery to each core recipient. Thus the
corrected interface is the relevant restricted game.

If the pursuer leaves K without capturing, let w be its unique missing
neighbor in the gadget. It is a nonroot gadget vertex. From any messenger
position in K, moving to w is legal and safe; w has a direct delivery arrow
to every core vertex and to rho. Therefore a pursuer departure gives a
two-move finish against every subsequent legal response. Captures are
resolved before this departure argument is used.

Conversely, a nonwinning rooted pair stays nonwinning when its pursuer uses
the confined-core avoiding strategy, including capture at an unsafe root
arrival. The messenger cannot profit from the other gadget vertices.
Consequently the set of winning missing pairs from K is exactly preserved.

All three functional pairs in the three-vertex gadget fail: the two-cycle
vertices have killed rows, and rho -> a has another degree-one pursuer
missing a. In the four-vertex gadget, precisely t0 -> a, a -> b and b -> a
fail by the degree-one image obstruction. The remaining pair rho -> t0
wins in two moves. Against a core pursuer c, choose a missing neighbor of c
lying in K; one exists because its missing row has at least two distinct
members and only one can be rho. That vertex is directly reachable from
rho and directly delivers to t0. Against a gadget pursuer use its unique
missing neighbor, which is a or b and directly delivers to t0.

For k two-out core rows, the resulting counts are I=2k at n=k+3,r=3,
and I=2k+1 at n=k+4,r=4. Both meet the existing dense staircase bound.

## Frozen applications

The existing literal nine-core has missing rows

    0:{1,3}, 1:{4,7}, 2:{5,6}, 3:{0,2}, 4:{6,8},
    5:{2,8}, 6:{0,4}, 7:{1,5}, 8:{3,7}.

Designate vertex 8 as rho and retain rows 0..7. The two gadgets yield
(n,m,I)=(11,91,16) and (12,112,17). Both concrete graphs have at most
three messenger moves in the independent full-game computations.

Two separate literal core changes yield the other anchors:

- Add missing arrow 2 -> 4 to the nine-core: (9,53,19).
- In the direct ten-core with point vertices 0..4 and line vertices 5..9,
  add missing arrow 0 -> 1: (10,69,21).

Their two-cycle missing-block joins yield (11,89,19) and (12,109,21).
The ordinary arbitrary-duration missing-block addition lemma proves the
joins from the fixed core guarantees. The new core guarantees themselves
have finite proofs, not an asserted new parameterized ordinary argument.

`src/small_dense_rooted.py` checks the corrected interface and its complete
agreement with actual full-graph winning masks on every retained source,
recipient and initial core pursuer. Its semantic control has three core
vertices whose only nonwaiting delivery move is to a root reachable by
every pursuer; no indirect core pair wins, whereas actual root receipt
remains immediate. `src/small_dense_anchors.py` constructs the other four
graphs. Both invoke the existing independent collapsed and explicit
alternating solvers and replay every winning and losing rank obligation.

Frozen data and receipts are `small-dense-rooted-certificates.json`,
`small-dense-rooted-checks.json`, `small-dense-anchor-certificates.json` and
`small-dense-anchor-checks.json`. The bounded discovery sweep checked only
the 54 single missing-arrow additions to the specified nine-core and the
70 additions to the specified ten-core. Its failures exclude no other
construction; details are in `small-dense-anchor-additions.json`.

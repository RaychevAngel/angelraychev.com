# Independent audit: packed deleted columns and the 1800 threshold

2026-09-12. Reviewed `paper/sparse-packed-holes.md` (Theorem 52) and
`src/six_type_budget_multihole_certificate.py`. The proof and source
pass within their stated ordinary computer-assisted scope. No Lean
coverage is added. Existing independently checked local game
certificates are reused; the new independent computation verifies
arena maps and graph construction, not a new game attractor.

## Projection of local arenas

The wider arena has messenger columns -4..4, cop columns -8..8 and
Omega, with Omega permitted to reenter columns +-6,+-7,+-8. Crop its
deleted-column set H to -6..6 and map every wider cop outside -6..6
to the old Omega. Keep messenger positions unchanged.

The independent explicit successor rules in
`src/six_type_independent_spacing.py` show that a removed type4 at h
changes only the first move at type3 in column h and the second move
at type1 in column h-1. Thus deletion h=7 is the only cropped-away
deletion that can change an old represented cop tail: its head moves
from type4 in column7 to type2 in column8, and both map to Omega.
No retained messenger move is affected. A cop newly mapped to Omega
can enter the smaller window only at column +-5 or +-6, because base
moves have displacement at most two. These are exactly the old
permitted reentry layers. The wider Omega's own reentry maps to
either the old Omega or column +-6 and is also allowed.

Every messenger lies within -4..4, so collision equality is
preserved. Terminal receipt and the safe messenger-turn transfer
goal are preserved as well. An old winning strategy therefore lifts
through this simulation. There is no need to claim that a negative
old rank implies a losing state in the new arena.

The independent checker
`src/six_type_independent_multihole_projection.py` rebuilt all 865
patterns from the separate explicit successor rules. It verified
286414 projected cop edges and 4496692 collision equalities, as well
as equality of messenger moves and agreement with all 865 primary
arena definitions. Cardinality counts were 1,17,105,286,330,126.
The complete receipt is
`research/six-type-independent-multihole-projection.json`.

The old independent gap-three certificate receipt reports 1287
modules, 560885 required starts, and 10271740 alternating game
states, with transfer at most9 and delivery at most27. The old
independent augmented receipt reports transfer at most9 and delivery
at most35. These are the bounds actually needed here; replacing35
by26 would be incorrect for the augmented module.

## Arbitrary optional-arc subsets on a ring

For n>=1075, k=ceil(n/6)>=180 and r=6k-n<=5. Delete type4 at
0,3,...,3(r-1), smoothing both permutations. Their cyclic separation
is at least three. The resulting graph has exactly two incoming and
two outgoing arcs at every remaining vertex, without loops or
duplicate arcs. The permitted optional tails have cyclic distance
greater than16 from every deletion.

For r>0, all forbidden tail columns lie in the cyclic image of the
integer interval [-16,3(r-1)+16], of size3r+30<=45. Hence at least
8(k-45)>=6k>=n distinct optional arcs are available. If r=0 there
are8k. Their specified heads are existing vertices, and their eight
types give distinct nonloop arcs outside the base graph. Selecting
any m-2n of them gives every exact budget2n..3n. Independently
constructed rings at n=1075..1080 verify the six residue cases,
including baseline degrees and intermediate exact arc counts.

If a represented cop window contains a deletion, every represented
tail is at distance at most16 from it. There are no optional cop
arcs from represented tails, so the lifted unaugmented module
applies. If the window has no deletion, the fully augmented module
includes every actual cop move, while the messenger still uses only
the base moves. A deletion just outside the window can change only
an exit into another exit, not a represented-to-represented move.

Actual jumps are at most three columns. The large cyclic period
prevents a jump across the exterior gap from secretly landing at the
other represented end. Every exterior return is therefore covered
by the three permitted Omega reentry layers. This proves the global
simulation for every selected subset of optional arcs, without
assuming that winning guarantees are generally monotone under
adding graph arcs.

At most k-1 safe one-column transfers put the messenger two columns
before its recipient, followed by a delivery of at most35 moves.
The total is9(k-1)+35=9k+26, as stated.

## Full main interval consequence

Theorem52 supplies the sparse premise in Proposition51's already
independently checked overlap calculation. Combined with Theorems38,
48 and50, the full main interval is therefore proved for all n>=1800.
The current joint piecewise range is correspondingly N>=1800,m>=24.
The older sufficient host thresholds2419,5442 and10^12 remain valid
historical checkpoints, not unresolved gaps in the new range.

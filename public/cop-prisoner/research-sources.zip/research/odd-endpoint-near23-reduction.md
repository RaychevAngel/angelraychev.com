# Reduction of the 23-arc problem near its upper bound

Status: ordinary proof drafted for independent review; the three resulting
finite searches are in progress. No new exact M_E(23) value is claimed here.

Let A be the vertices of outdegree at least two, B those of indegree at
least two, q=|A|, r=|B|, b=|A∩B|, and e=e(A,B). For 23 arcs we have
q,r<=11, e>=2q+2r-23, and I<=qr-b-e. As in the proved general upper bound,
only pairs in A×B can contribute.

Claim: if I>=88, then, after isolated vertices are deleted, the graph
has 12 vertices and is one of the following three types:

1. One outdegree-one vertex u and a distinct indegree-one vertex v;
   all other corresponding degrees two; u->v absent. There are90
   eligible missing pairs.
2. The same distinct exceptional vertices, but u->v present. There
   are89 eligible missing pairs.
3. One vertex x of both indegree and outdegree one; all other vertices
   have indegree and outdegree two. There are89 eligible missing pairs.

The claim uses the previously completed exclusion of universal
two-in/two-out graphs on11 vertices.

## Degree sizes other than (11,11)

The elementary rectangle bound is at most83 when q,r<=10, and at most82
when one is at most9. Therefore only (10,11),(11,10),(11,11) matter.

For (q,r)=(10,11), I<=91-b. If b>=4 this is at most87. Otherwise A\B has
at least7 vertices. At most one has positive indegree, since total
indegree outside B is at most23-22=1. Thus there are at least6
indegree-zero vertices in A.

They emit at least12 arcs. Among B, at most one vertex can have indegree
three, and then no arc ends outside B; otherwise at most one arc ends
outside B. Hence at least9 of these arcs enter indegree-two vertices of
B. At least5 distinct such recipients result. An indegree-two recipient
with an indegree-zero predecessor has no guaranteed indirect pair:
all other sources must approach through its sole other predecessor,
where the pursuer can wait. Removing these five zero columns gives
I<=10*(11-5)=60. The case (11,10) is dual, using outdegree-zero
successors and zero source rows (the established elementary row lemma,
not an assumption that the whole game reverses).

## The (11,11) corner with b<=9

Again, at most one vertex of A\B has positive indegree. If b<=7, there
are at least3 indegree-zero vertices in A, emitting at least6 arcs.
At most3 of these can be swallowed by the one possible indegree-three
recipient; alternatively only one can end outside B. At least two
indegree-two zero recipient columns follow. Removing them deletes at
most4 arcs from e>=21. Thus

I<=11*9-(21-4)=82.

If b=8 or9, choose any indegree-zero x∈A\B. Its two distinct successors
cannot both avoid indegree-two vertices of B: an indegree-three vertex
uses the entire unit of indegree surplus, whereas an arc outside B
also uses that unit. Therefore there is at least one zero column.
It contains at most2 direct pairs and at most one diagonal, giving

I<=11*10-(21-2)-(b-1)=92-b<=84.

## b=10: distinct exceptional vertices

Write A\B={v}, B\A={u}. If v has indegree zero, the preceding single
zero-column argument gives I<=110-19-9=82; the dual statement holds
if u has outdegree zero. For I>=88 we therefore have indegree(v)=1
and outdegree(u)=1. These exhaust all indegree outside B and all
outdegree outside A. All degrees in A and B consequently equal two;
every other vertex is isolated. This is precisely type1 or type2,
according as u->v is absent or present. The eligible rectangle has121
pairs,10 diagonals, and either21 or22 direct arcs, giving90 or89
eligible missing pairs.

## b=11: one common active set

Here A=B=C has11 vertices. At most one arc starts outside C and at
most one ends outside C.

If an arc has both endpoints outside C, it exhausts both allowances.
The other22 arcs form a two-regular graph on C. Any winning strategy
in the full graph against pursuers starting in C would also win in
this graph: the messenger cannot leave C. Such a graph is not universal
on11 vertices by the completed small regular exclusion, so I<=87.

If all arcs lie in C, there are at most110-23=87 missing pairs.
Suppose exactly one arc crosses the boundary. If it is C->x, then x
has outdegree zero. The total outgoing degree in C is23, so exactly
one C-vertex has outdegree three. If the crossing arc leaves this
vertex, deleting the crossing arc leaves a two-regular core, and its
losing pursuer strategies remain available; entering the outside sink
cannot help delivery to an eligible recipient. Again I<=87. If the
crossing arc instead leaves an outdegree-two vertex, its other outgoing
neighbor can be occupied by the pursuer; all its eligible indirect
pairs fail. There are at least9 such pairs, while the eligible
rectangle contains88 missing pairs, so I<=79. The incoming-crossing
case is dual by the elementary zero-column obstruction; if the
receiving vertex has indegree three the core is two-regular, otherwise
its inaccessible indegree-zero predecessor causes a zero column.

Finally suppose both crossing arcs exist. They have the form C->x
and y->C. All vertices of C have indegree and outdegree two. If x≠y,
x is a sink and y has indegree zero, so the previous zero-row or
zero-column obstruction rules out I>=88. If x=y, it is the unique
vertex of indegree and outdegree one, giving type3. The active
rectangle has121 pairs,11 diagonals,21 direct pairs, hence89 eligible
missing pairs. This completes the reduction.

## Finite proof interfaces

Type1 is covered by the earlier distinguished-cycle enumerator. For
type2, add a second copy of u->v, factor the bipartite regular multigraph
into two permutations, and require A(0)=B(0)=1. Only this duplicate is
allowed before the added copy is removed. For type3, add the dummy
loop0->0 and choose A(0)=0; all other A-cycles have length at least two,
and B is loopless and disjoint from A. Removing the dummy loop gives
the required simple graph.

For any of these types, a source camping obstruction destroys at least
8 eligible missing pairs; a recipient camping obstruction destroys at
least7. Since there are at most90 eligible pairs, such a graph has
I<=83. Thus the same local pruning is sound for a search targeting
I>=87, even though it was originally introduced to test full equality.
The exact game evaluation must count failed eligible source-recipient
pairs, rather than just stopping at the first failure. Enumeration
may stop a leaf after its remaining possible count falls below87.

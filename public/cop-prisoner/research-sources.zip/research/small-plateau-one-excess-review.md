# Independent review of the eleven-vertex, 23-arrow exclusion

13 September 2026. **Verdict: the complete finite upper bound
`M(11,23)<=78` is sound.** Together with the independently replayed literal
78 witness, this establishes equality. This review checks the ordinary
degree reduction and source-level completeness, not just the game outcomes
of a sample. It is not a second full enumeration or a Lean formalization.

Reviewed producer: `src/small_sparse_one_excess.cpp`, SHA-256
`98235daaa6dc7ce28ca13b14f85cb2aa180fc9e01cd114ba561204dfcd37c798`.
The ordinary producer proof is `research/small-sparse-eleven23-proof.md`.
The two complete receipts are
`research/small-sparse-one-excess11-partitions1-6.json` and
`research/small-sparse-one-excess11-partitions7-14.json`.

## Reduction and exhaustive normal forms

Let `q` count vertices with outdegree at least two. Every other vertex has
at most one outgoing arrow and cannot be an indirect source. At least
`m-(n-q)` arrows therefore leave the eligible sources, and at most

    q(n-1) - (m-(n-q)) = q(n-2)+n-m

indirect pairs start there. At `(n,m)=(11,23)` this is `9q-12`, at most 78
when `q<=10`. The incoming argument is separate and identical: a recipient
with one predecessor is defeated by a cop at that predecessor for every
indirect source. Thus any counterexample of score at least 79 has minimum
indegree and outdegree two. Its only degree surplus is one outgoing arrow
at `U` and one incoming arrow at `V`; equality `U=V` is allowed.

The bipartite arrow graph has a perfect matching. If a source subset `S`
had fewer neighbors than its size, its at least `2|S|` emitted arrows would
have total recipient capacity at most `2(|S|-1)+1`, a contradiction.
The matching is a permutation without fixed points, since graph loops are
forbidden. Simultaneous relabeling puts it in consecutive cyclic form for
one partition of eleven into parts at least two. The producer's recursive
partition generator lists all fourteen such partitions exactly once.

The centralizer of that permutation rotates cycles and swaps equal-length
cycles. It can move `U` to the first vertex of the first cycle having its
length. The producer chooses one such location for each distinct length,
and then allows **every** vertex for `V`. It therefore preserves all
relations between the two exceptional vertices. The independent review
constructs the required commuting permutation explicitly for all eleven
choices of `U` in every partition, giving 154 normalization checks.

After deleting the chosen matching, residual outgoing degrees are one
except two at `U`; residual incoming capacities are one except two at `V`.
The recursive source enumerator chooses each legal residual neighbor and
chooses the two neighbors of `U` in increasing order. It rejects only
loops, the already chosen matching arrow, and a full residual recipient
capacity. On a complete assignment the number of selected residual arrows
equals the sum of all capacities, so every capacity is filled. No further
degree class is missing. Duplicate matching decompositions are harmless.

The independently generated partition list has
`11 * sum(number of distinct cycle lengths) = 330` exceptional patterns:
154 in partitions 1--6 and 176 in partitions 7--14. The receipt ranges are
disjoint and cover all fourteen; their completed-partition counters equal
the requested sizes six and eight.

## Permanent loss facts and their lifetime

All rows initially contain their matching arrow. A completed row contains
all its final arrows. The `ready` flag marks precisely those completed
rows. The `used` counts measure residual incoming arrows only; consequently
`used[t]==cap[t]` means that `pred[t]`, which also contains the matching
predecessor, is the final predecessor set.

The routine `check` adds only two types of permanent facts:

* A completed source row contained in a distinct cop's current closed
  outgoing neighborhood loses every indirect pair. Partial cop rows are
  safe here because their arrows persist in every completion.
* A full predecessor set contained in a cop's current closed outgoing
  neighborhood loses all indirect pairs in that column except a pair
  whose initial source equals that cop vertex. The code retains this
  exception in all three predecessor checks.

When the newly completed row gives the cop new arrows, the code checks old
full columns against it. When newly assigned arrows fill either of their
recipient capacities, it checks those columns against every current cop
row. This is a union of necessary losing-pair facts; no camping class is
excluded wholesale.

`bad_stack[row]` belongs to one prefix. Each child receives a copy of its
parent facts plus the current row's new facts. Before any sibling recurses,
`check` overwrites that child depth from the current parent again. The
guarded routine modifies only the current depth. Each new exceptional
pattern resets depth zero. Sibling-specific facts therefore do not leak
into a different branch.

For a source row the code bounds possible guarantees by the minimum of its
final number of missing nonself arrows and the number of targets outside
its self, already fixed arrows, and permanent bad-pair set. These are two
independent valid upper bounds; the minimum stays an upper bound even for
an unfinished row. Summing over rows and rejecting at most 78 is sound.

## Optimistic guarded paths

For every unfinished row, the optimistic messenger graph adds all residual
arrows individually compatible with current capacities. It ignores joint
capacity restrictions and hence contains every completion. Completed rows
are exact. For a fixed cop vertex `c`, the forbidden interior set is its
**current** closed outgoing neighborhood. Every arrow in that set persists.

If a messenger path starts at `s!=c`, its first move may leave that set;
all later interior positions must avoid it; its final move may deliver at
any recipient, including one in the set. The routine computes precisely
this permissive reachability by closing the allowed interior vertices and
then taking one unrestricted final arrow. It also includes every optimistic
direct first move. Thus it never rejects merely because delivery occurs at
the cop or within the cop's outgoing neighborhood. Waiting cannot create a
missing route. Failure of even this optimistic route lets a cop camp at
`c` and capture at the first nonterminal forbidden visit, so it is a
permanent loss fact. Calling this routine only at depth eight or later
affects speed, not coverage or soundness.

## Game decision and completed receipts

The game routine computes the recipient least fixed point. `W[t]` starts
as all cop positions; because the messenger may wait at the recipient,
this remains terminal in every iteration. At every other messenger
position, a collision bit is removed. `safe[v]` requires every outgoing
cop reply and waiting to belong to `W[v]`; the messenger then chooses an
outgoing arrow or waiting. This exactly implements receipt before capture
and finite delivery. A missing ordered pair counts only when every
initial cop position other than its source wins.

The game is evaluated column by column. An unsolved column's eligible
nonadjacent pairs outside the permanent bad union overestimate its winning
count. Once a column is solved, its potential is replaced by the actual
count. If actual solved counts plus remaining potential are at most 78,
the graph is rejected. A counterexample of score at least 79 cannot be
lost this way. A column of potential zero can be skipped entirely. The
return value `-1` is a decision sentinel, **not an actual graph score**.

The two complete runs visited 121,790,823 nodes and reached 1,152,430 game
decisions. All were sound early rejections. Each run has `complete:true`,
all requested partition types completed, and `upper_if_complete:78`.
The source checks the time cap periodically, marks timeout incomplete,
and unwinds; none of those runs timed out. No value from an incomplete
pilot enters the theorem.

## Independent executable checks and boundary

`src/small_plateau_one_excess_review.py` verifies the frozen source/proof/
receipt hashes, independently reconstructs all fourteen cycle partitions
and 330 exceptional patterns, and explicitly checks the normalization
automorphisms. For four deterministic sample graphs per partition, it
constructs a matching plus disjoint permutation plus one additional arrow.
Each graph is solved by the separate explicit alternating game and every
winning and losing rank is replayed.

A small compiled harness then calls the **actual frozen producer routines**
on every prefix of those graphs with pruning disabled by a negative
threshold. At every depth it verifies that the producer's bad union kills
no independently winning pair and its row upper bound dominates the true
score. It also verifies the complete fixed-point score and decision calls
at the true score and one below it. These bounded regression checks support
the source audit; they do not replace the ordinary arguments for all
prefixes or the two complete producer receipts. The source-pinned numerical
receipt is `research/small-plateau-one-excess-review.json`.

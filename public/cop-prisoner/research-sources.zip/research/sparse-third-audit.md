# Sparse support and camping-class audit — 13 September 2026

This pass was authorized to sharpen the small sparse gaps using structural
reductions and complete justified finite checks, without a broad random
search. It authored only `paper/sparse-third.md` and the `sparse-third-*` /
`sparse_third_*` files. No shared ledger or website was edited by this agent.

## Ordinary results and independent attack

The first result sharpens Theorem 56's nonregular-support cutoff from
`k^2−4k+3` to `k^2−4k+2`, for every `k>=7`. The active-set corners that
could attain the old value were checked individually. In the nested
`q=k−1,r=k` case, two arrows from outside the active source set cannot both
come from its single exceptional recipient. An outside tail therefore has
indegree zero and forces a zero column. The transpose is a direct sink
argument in the original game, not an assertion about reversing pursuit.
For `q=r=k−1,b<=2`, the two indegree-zero sources required by the earlier
surplus argument still exist because `k>=7`. Root independently reviewed
the complete written proof and reported no gap.

The source-camping loss lemma is also new: in a two-in/two-out graph, source
camping forces at least `2(n−3)` missing-pair losses. The alternatives are
duplicate outgoing pairs, or a transitive triangle. In the triangle case
one zero row and one zero column have a *direct* intersection, so their
missing-pair losses are disjoint. Root separately reviewed this lemma.

A second reduction retains arbitrary degrees on a small support: if
`I>k^2−5k+8`, then the original graph has exactly k nonisolated vertices.
Its first proposed proof contained a gap found by root: up to two arrows
entering sinks may start outside A. That outgoing-surplus argument was
withdrawn before integration. The repaired proof treats the only disputed
value explicitly. Equality forces two outer diamonds; the induced overlap
core must itself be universally winning. The original vertex bound then
forces every core arrow to stay internal, contradicting delivery from the
core to an outer recipient. This is an actual-game restriction with an
explicit reason outside vertices cannot serve as intermediaries. Root
independently reviewed the repaired mechanism; a separate assigned agent
is reviewing its complete written equality-shape proof.

Both arithmetic case splits have a bounded exact-integer attack for every
`7<=k<=100` and every admissible active-set size/intersection triple. The
source-camping loss count is checked on all two-permutation factor pairs
through order six. These are finite arithmetic/counting checks supporting
the ordinary proofs, not extrapolated proofs of the unbounded range.

## Finite regular-core result and its exact dependencies

For a two-in/two-out graph with no source camping, a predecessor camping
pair cannot have its cop in the recipient's predecessor set: that would
supply a transitive triangle and hence source camping. Its two predecessors
are therefore precisely the cop's two outgoing neighbors. Two cops camping
the same recipient would have identical outgoing pairs, again source
camping. Thus two distinct camping pairs refer to distinct recipient
columns and lose at least `2(n−4)` missing pairs in total.

The remaining classes have no pair or exactly one pair. The zero-pair
class on eleven vertices was already fully audited and replayed in
`research/odd-endpoint-eleven-enumeration-audit.json`; the pinned original
receipt `research/small-exceptional-regular-max-11.json` has 120,302 leaves
and maximum66. The earlier construction-first one-pair run was *not*
previously promoted to an upper-bound theorem. This pass independently
reviewed its scope, pruning and actual game recurrence, and root performed
an additional independent source review before approving promotion.

### Coverage and pruning, with source line map

Source: `src/one_diamond_eleven_search.cpp`.

- Lines81–98 enumerate all fourteen cycle partitions of11 with no singleton
  and form a canonical first permutation for each. Every two-in/two-out
  simple loopless graph has two arc-disjoint permutation factors by
  alternating its bipartite incidence cycles. Simultaneous relabeling puts
  one factor in one of these canonical forms.
- Lines71–78 assign every second permutation avoiding the diagonal and
  first-factor arrows. `used` enforces distinct heads; each recursion path
  completes all eleven rows. Every adjacency update, assigned flag and
  inverse-column flag is rolled back before the next branch. No connectivity,
  cycle-length, orbit-size or order normalization is hidden here.
- Lines45–55 use completed source rows (`assigned[s]`) and completed
  recipient columns (`inv[t]>=0`). A partially known cop row can safely
  certify coverage because its neighborhood only grows during extension.
  Source camping, direct-predecessor camping, or two distinct camping pairs
  persist and disqualify the intended class. The test does not reject a
  branch merely because its source/recipient neighborhood is still partial.
- Lines61–69 require exactly one camping pair at a leaf and evaluate its
  actual game. The harmless case in which cop equals recipient is included.
  The old target81 early exit never occurred. The new replay driver removes
  target-triggered stopping; all leaves were visited within the30-second cap.
- Lines22–43 compute the least reachability attractor. The target row starts
  with every cop position winning and remains so through the wait action.
  Nonterminal collision states are excluded. A messenger successor is safe
  precisely if *all* legal cop replies are already winning. Synchronous
  iteration from the terminal set is monotone and stops at the least fixed
  point, matching the existing exact-game semantics.

The fresh replay in `src/sparse_third_verify.cpp` inherits the audited
enumeration but supplies a separate scalar, asynchronous legal-action
attractor as an extra check. It is deliberately **not described as a
second independent graph enumeration**. All14 cycle types,7,016,903 partial
nodes and484,471 leaves match the old run, and the maximum is71. The scalar
solver agrees on482 sampled leaves and every successive maximizing witness.
Its total elapsed time was2.36seconds at lower CPU priority.

The exact same justified zero/one-pair classes were replayed at orders9
and10. The parameter-only adaptation `src/sparse_third_one_pair.cpp`
changes the order, makes output metadata parametric, and removes target
termination; it otherwise preserves the audited enumerator.

- Order9: zero-pair535 leaves, maximum30; one-pair1,567 leaves, maximum24.
- Order10: zero-pair35,610 leaves, maximum38; one-pair20,658 leaves, maximum45.
- Order11: zero-pair120,302 leaves, maximum66; one-pair484,471 leaves, maximum71.

The elementary multiple-camping bound therefore gives regular-core upper
bounds44,58,74, respectively. Every recorded maximum witness was separately
recomputed by both Python game solvers and all its literal winning/losing
rank certificates were checked. That verifies the witnesses but does not
substitute for the enumeration coverage proof for the upper bounds.

## Consequences and preserved limits

The first degree-sensitive refinement gave upper bounds23,34,47,62,79 at
budgets14,16,18,20,22. The repaired original-support theorem further gives
22 and32 at14 and16 using the prior seven/eight-vertex bounds. Complete
justified finite degree-transfer checks further reduce18 and20 to44 and58.
These last refinements require the independently checked support repair and
the stated finite family coverage; they are not claims from a random search.

The incoming-degree-transfer family at11 vertices unexpectedly contains a
79-guarantee graph. Both exact game solvers and all2,662 literal rank
conditions verify it. Together with the already independently reviewed
79 upper bound, this proves `M_E(22)=79` and `M(n,22)=79` at every n>=11.
That exact result does NOT depend on the new transfer enumeration being
complete or on the repaired stronger support theorem: a single certified
witness and the first reviewed cutoff suffice. Its eleven outgoing pairs
and full ranks are frozen in
`research/sparse-third-one-transfer-in-certificate.json`.

The outgoing-degree-transfer family at11 has camping-free maximum56,
whereas the incoming family reaches79. This concrete asymmetry demonstrates
why arrow reversal must never be assumed to preserve the game.

At18/20 arrows the separate incoming-family maxima are29/50 and outgoing
maxima13/32. Camping in an eligible row or column destroys at least k−5
of the U=k²−4k+2 eligible pairs, below the T=k²−5k+8 threshold. The remaining
full-support degree cases are regular, have a zero degree exception that
reduces to a smaller regular core plus at most k−3 additional pairs, or have
active-set counts already belowT. These are complete structural reductions
for the proposed upper bounds, detailed in the paper.

No Lean formalization of any new ordinary or finite statement is claimed.
Previous receipts and weaker valid theorems remain unchanged. The14/16/18/20
bounds are not exact values; the22-arrow result is exact at every host>=11.

## Reproduction

From the project root:

```
python3 src/sparse_third_checks.py
c++ -std=c++17 -O3 src/sparse_third_verify.cpp -o tmp/sparse-third-verify
nice -n 10 tmp/sparse-third-verify
c++ -std=c++17 -O3 src/small_exceptional_regular_max.cpp -o tmp/sparse-third-camping-free
nice -n 10 tmp/sparse-third-camping-free 9 30
nice -n 10 tmp/sparse-third-camping-free 10 30
c++ -std=c++17 -O3 -DSPARSE_THIRD_ORDER=9 src/sparse_third_one_pair.cpp -o tmp/sparse-third-one-pair-9
nice -n 10 tmp/sparse-third-one-pair-9 30
c++ -std=c++17 -O3 -DSPARSE_THIRD_ORDER=10 src/sparse_third_one_pair.cpp -o tmp/sparse-third-one-pair-10
nice -n 10 tmp/sparse-third-one-pair-10 30
```

Receipts use the matching `research/sparse-third-*.json` names; source and
receipt hashes are in `research/sparse-third-source-audit.json`.

## Degree-transfer follow-up receipts

`src/sparse_third_one_transfer.cpp` is the frozen11-vertex source;
`src/sparse_third_transfer_family.cpp` is its order-parameterized copy.
Both preserve every allowed residual assignment and use completed eligible
source rows/recipient columns only in camping tests. Unlike the earlier
regular enumerator, an inactive degree-one row/column is deliberately not
used as an obstruction to the counted rectangle. The high-degree vertex is
normalized by cycle centralizers and the low-degree vertex is unrestricted.
Outgoing and incoming cases were run sequentially with30-second caps at11
and10-second caps at8,9,10. All finished, none stopped at a target score.

The complete11-vertex outgoing check has11,358,437 nodes,316,456 leaves,
maximum56; the incoming check has26,747,408 nodes,1,285,464 leaves,
maximum79. Smaller checks are in the matching sparse-third-transfer receipts.
New witness certificates are independently verified by both game solvers and
by explicit winning/losing rank conditions.

# Proposed exact twenty-arrow maximum53

13 September 2026. This is the complete primary proof package, pending
independent review. No canonical manuscript or ledger has been changed.

## Statement and inherited ingredients

Proposed conclusion: M_E(20)=53 and M(n,20)=53 for every n>=10.
The approved ten-vertex regular witness scores53. The approved comparison
host theorem reduces all orders n>=11 to11. Orders at most9 have at most
n(n-1)-20<=52 missing pairs. Thus it remains to exclude scores above53
on ten and eleven nonisolated vertices.

Inherited ingredients are the approved outside-vertex/live-rectangle bounds,
the eighteen-arrow upper44, the regular ten-vertex maximum53, and the two
complete directional one-transfer threshold53 exclusions. The new proposed
upper M(10,19)<=53 is proved separately in sparse_finish_one_defect_proof.md.
Its two exceptional one-arrow appendage cases and complete positive-degree
enumeration are dependencies of this theorem, not presumed conclusions.

## Exact count inventory

Let A be vertices of outdegree at least2, B those of indegree at least2,
q=|A|,r=|B|,b=|A intersection B|,a=20-2q,d=20-2r. Let Z be nonisolated
vertices outside A union B, with size z and outgoing/incoming totals o,i.
Let x,y be the total outgoing/incoming surplus above2 within A,B and let
w count arrows from outside A to outside B. Then

    e(A,B)=2q+2r-20+x+y+w.

The exact numbers of indegree-one vertices in U=A minus B and outdegree-one
vertices in V=B minus A are d-y-i and a-x-o respectively. These counts must
be nonnegative and at most |U|,|V|. Nonisolated support is q+r-b+z.
The supplied inventory retains every permitted integer tuple and may retain
unrealizable ones. When the live-rectangle bound with q-1 rows or r-1 columns
is already at most53, all active rows or columns respectively must be live.
Only then are the corresponding live-degree bounds applied:

    2(r-b)+2x+o+z <= 3a,
    2(q-b)+2y+i+z <= 3d.

The source sparse_finish_profiles.py and its JSON retain x,y,w individually.
Every surviving q=r9 case used below forces all9 rows and all9 columns live.
Therefore every active source needs two nonsink successors, and every active
recipient needs two predecessors of positive indegree. In particular an
indegree-zero predecessor at an indegree-two recipient makes its column
zero; an outdegree-two source with a sink successor has a zero row.

## Deleting an actual source or sink

If v has indegree0, no old messenger can enter v. Restrict the cop to G-v.
Every guarantee between surviving vertices in G therefore remains a guarantee
in G-v. The only extra possible pairs of G belong to row v. If v has
outdegree0, an excursion to v cannot deliver to an old recipient; restricting
the cop similarly bounds every surviving old pair by G-v, and only column v
can contribute additional pairs. No reversal invariance is asserted.

Consequently a one-arrow source or sink contributes no indirect pair and
can be deleted for an upper comparison. From an eleven-vertex twenty-arrow
graph this gives a ten-vertex nineteen-arrow comparison, bounded above53
by the separate proposed theorem.

If a source of indegree0 has outdegree2, deletion leaves eighteen arrows.
If at least one successor lies in B and r=9, its row has at most8 eligible
pairs, so I(G)<=44+8=52. If both successors lie in B the bound is51.
Separately, deleting a sink of indegree2 leaves eighteen arrows; when q=9
and at least one predecessor belongs to A its column contributes at most8,
or at most7 when both predecessors belong to A. These upper comparisons
do not contract paths or remove arbitrary routing vertices.

## Every zero-degree eleven-vertex profile

The complete inventory gives the following exhaustive split.

1. If q=r9 and Z contains a source or sink, that vertex has its other degree
   exactly1. Delete it and use M(10,19)<=53. This covers every non-positive
   b=9,z=2 profile and every b=8,z=1 profile except o=i=1.
2. If (q,r,b)=(9,10,9), the sole Z vertex is a one-arrow indegree-zero
   source. If (10,9,9), it is a one-arrow sink. Use the same deletion.
3. If (q,r,b)=(9,10,8), A minus B contains an indegree-zero vertex of
   outdegree at least2. All indegrees in B are2, so at least two distinct
   recipient columns are zero. The live rectangle with at most9 rows and8
   columns is at most52. For (10,9,8), B minus A contains a sink receiving
   at least2 arrows from outdegree-two sources; two zero rows give the
   separate bound52.
4. If (q,r,b)=(10,10,9), there is an indegree-zero source and an outdegree-
   zero sink. All active degrees are2. The former gives two zero columns,
   and the latter two zero rows. The live-rectangle bound at R=C=8 is47.
5. The only remaining zero-degree profiles have q=r9 and either b=7,z=0
   or b=8,z=1,o=i=1. Their surpluses satisfy x,y in {0,1}, with at least
   one equal1. Suppose y=1. There is a unique indegree-zero u in U, and a
   unique indegree-three h in B. All other B indegrees are2. Nonzero
   columns force u to avoid all of those indegree-two recipients. At b=7,
   the only other allowable successor is the other vertex u' of U; at b=8
   it is the vertex of Z. Thus u has exactly the two successors h and that
   outside-B vertex. Its degree is2 and one successor lies in B. Source
   deletion bounds the score by52. If x=1, argue directly with the unique
   sink v in V: nonzero rows force its predecessors to be the unique
   outdegree-three member of A and the only available outside-A vertex.
   It has indegree2 and the separate sink deletion gives52. This covers
   the cases x=y=1 too.

Every zero-degree eleven-vertex competitor is therefore bounded by53.

## Every zero-degree ten-vertex profile

There are exactly four surviving parameter forms.

- q=r9,b=8,x=1,y=2: U consists of one indegree-zero source u, with every
  other vertex in B. All columns must be nonzero. Its at least two distinct
  successors must have indegree at least3. Surplus2 therefore forces two
  indegree-three successors and outdegree exactly2 at u. Both successors
  lie in B, so source deletion bounds I by44+7=51.
- q=r9,b=8,x=2,y=1: the separate incoming argument gives a sink with
  indegree2 and two outdegree-three predecessors in A. Its deletion gives51.
- q=9,r=10,b=9,x=2,y=0: the vertex of B minus A is a sink of indegree2;
  both predecessors belong to A. Delete it and obtain the bound51.
- q=10,r=9,b=9,x=0,y=2: the vertex of A minus B is an indegree-zero
  source of outdegree2; both successors belong to B. Delete it and obtain51.

## Positive-degree eleven-vertex family

If every degree is positive, q,r<=9. The rectangle bound with either count
at most8 is at most52. Thus q=r9. The degree sums then force all degrees
one or two, with two low-in and two low-out vertices. All three overlap
sizes are retained; strong connectivity is not assumed.

The bipartite incidence graph has exactly four degree-one endpoints, hence
two path components, together with cycles. A proper alternating coloring
can be balanced into two matchings of size10: even-edge paths and cycles
balance individually; if both paths have odd length, interchange the colors
on one as necessary. Each directed matching has a unique path, allowing an
isolated vertex, plus cycles. Normalize its path and cycle partition. The
path is rigid; rotations and permutations of equal-length cycles normalize
the single omitted row of the second matching. Every omitted column and
every remaining matching assignment is retained.

With low-out set L and low-in set J, the eligible count is

    58-|L intersection J|-e(L,J).

At a partial assignment the already fixed e(L,J) gives an upper bound.
Every source camping obstruction loses at least6 eligible pairs, and every
predecessor camping obstruction loses at least5 after its initial-source
exception. Since a target54 allows at most4 losses, these may be rejected.
The guarded-path filter counts the union of permanent failures under an
optimistic messenger and only fixed cop arrows. Every surviving complete
graph uses the actual game fixed point, with a safe remaining-column upper
for early rejection. These semantics are detailed in the nineteen-arrow
proof and are unchanged here.

The complete run sparse_finish_two_defect_11_20.json covers42 first-factor
types,1640 patterns,59613217 nodes and18678 actual-game threshold decisions.
No graph exceeds53. Runtime was18.553 seconds. The code is
src/sparse_finish_two_defect.cpp. The balanced normalization and every
overlap are new proof obligations, rather than claims inherited from the
old equality58-only enumeration.

## Positive-degree ten-vertex residual families

The complete inventory retains the regular and directional one-transfer
families already bounded by53, plus only the following new families.

- Two outdegree-one vertices and either one outdegree-four vertex or two
  outdegree-three vertices; all other degrees, including all indegrees,
  are2. These graphs have at most54 eligible pairs.
- The incoming versions of those two degree families, argued/enumerated
  separately.
- One outdegree-one and one outdegree-three vertex, and one indegree-one
  and one indegree-three vertex; all other degrees are2. The low vertices
  may coincide or differ. These have at most54 or55 eligible pairs.

The source sparse_finish_coupled_degrees.cpp enumerates all11 possible
multisets of joint (outdegree,indegree) pairs. It does not assume that a
perfect matching exists. Rows are assigned complete neighbor subsets.
Already assigned vertices are fixed. Future vertices with the same joint
degree pair and identical incoming prefix are interchangeable by an
automorphism of the partial assignment: they have no assigned outgoing
rows. An outgoing subset therefore chooses a canonical prefix of each
such class. Choosing every count in every class covers all completions,
with repetitions allowed. Column capacities and the number of still
available distinct neighbors provide additional necessary pruning.

At this target, any source camping obstruction loses at least5 eligible
pairs, and any predecessor camping obstruction at least4, exceeding the
at most1 allowed failure. The same optimistic guarded-path bound and actual
game decision apply. The complete receipt sparse_finish_coupled_degrees_10_20.json
covers all11 patterns,940202 partial nodes and341 actual-game decisions;
none exceeds53. Runtime was1.373 seconds.

## Conclusion and exact proof boundary

All ten-/eleven-vertex cases are covered by these ordinary implications,
three complete new finite exclusions, and inherited reviewed family bounds.
Combined with the already certified53 witness and approved host reduction,
they give the proposed exact value53 at every host n>=10 and globally.
Independent review of the complete implication and new enumeration code
is still required. No new concrete Lean theorem or publication update is
claimed by this package.

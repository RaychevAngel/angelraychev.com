# Independent audit of the finite odd-budget bridge

## Verdict

The finite bridge and its independent replay pass. Together with the
ordinary all-residue theorem, they establish

`M(n,2n-1) = M_E(2n-1) = (n-2)(n-3)` for every `n>=13`,

equivalently the exact odd arc-only formula at every odd `m>=25`.
This remains a proof using finite executable certificates, not new
Lean coverage. It does not decide the remaining odd budget 23.

## Source audit

The C++ producer `src/odd_endpoint_finite_certify.cpp` computes explicit
alternating-state ranks by queue propagation. The Python verifier
`src/odd_endpoint_finite_verify.py` does not trust those propagation
steps: it reconstructs every legal successor from the original arcs
and checks strict rank obligations directly.

The graph checks require the correct number of distinct nonloop arcs,
different deficient source and recipient, the absent deficient arc,
and exactly the prescribed incoming and outgoing degree pattern.
Waiting is included as a legal successor for both players.

The accelerated arrays have axes `(messenger,cop,turn)`. Their
messenger-successor indexing changes the first axis only; their
pursuer-successor indexing changes the second axis only. Padding the
unique smaller move list by a repeated wait changes neither existential
nor universal quantification. Thus the array conditions are the same
as the displayed scalar implementation.

Receipt at the target has rank zero on both turns, including collision
at the target. Other collisions have rank minus one. Every other
winning messenger state has a legal successor with smaller nonnegative
rank, and every legal response from a winning pursuer state has
smaller nonnegative rank. Every losing messenger state has only losing
successors; every losing pursuer state has a losing successor. Zero
at a nonterminal state cannot pass the strict inequalities. These
conditions establish the true reachability-game winning region.

Required initial states include every legal cop start and every source
except the deficient source, for every recipient except the deficient
recipient. The replay also checks that the saved archive contains
every required recipient exactly once, with no additional or missing
objectives. Signed little-endian ranks are decoded explicitly; their
fixed byte length is checked.

The smaller-witness checker `src/odd_endpoint_small_verify.py` compares
both original independent game solvers and then checks every saved
rank. Its graph checks and required source-recipient guarantees agree
with the same definitions. The aggregate count is 10,236 objectives
and 215,967,810 alternating states across orders 13 through 144.

## Independent saved-artifact replays

This auditor independently replayed all **10,143** saved objectives at
orders 19 through 144 using the direct verifier. The complete replay
passed in **4.18 seconds** using the bundled Python with NumPy 2.3.5.
The archive SHA-256 is
`4236ecc33012be2269cb807559beb356dff45a7c1cc64511e87cddce05615625`.

The initial attempt used system Python without NumPy and entered the
slower scalar implementation. That owned replay was interrupted and
restarted with the bundled runtime; it was not reported as a completed
check. The completed direct array replay is the one described above.

The auditor separately loaded and replayed all **93** saved objectives
at orders 13 through 18 against their actual arc lists. Every direct
rank obligation passed. The small archive SHA-256 is
`4fd61afbece62c3efbbbbd88330a698375bc04228d93a9404826561d368b4d27`.

No new search was conducted by this auditor. The ordinary degree
count and the already proved order-free upper bound turn the verified
guarantees into exact extrema, and the all-residue theorem covers all
larger support sizes.

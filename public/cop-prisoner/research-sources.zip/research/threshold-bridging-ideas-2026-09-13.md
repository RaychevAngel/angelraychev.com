# Lowering the main-interval thresholds: private analysis, 13 September 2026

This responds to Angel's request for worked-through ideas for lowering the
remaining sparse order 103 and middle order 42 into the twenties. It is a
bounded analysis with small local experiments, not a new public release.
The current published thresholds remain 104 for the full main interval and
43 for its part m >= 3n. Every old theorem and proof boundary is retained.

## New finite evidence and its exact consequence

The frozen data are in `threshold-bridging-2026-09-13-checks.json`; replay with
`python3 research/threshold-bridging-2026-09-13-check.py` from the project root.
The checker reconstructs adjacency independently of the candidate producer,
computes source ranks for every recipient, and separately replays every
source/cop obligation against the full optional cop envelope. It also checks
the frozen producer ranks under the stricter top-intermediary rule below.

Root replay passed 27 envelopes, 872 recipient checks, 689,714 ordinary
nonterminal rank obligations and 125,564 additional restricted-top obligations.
The literal constructions fill all old unresolved cells with

    28 <= n <= 42, 3n <= m <= n(n-3),

and all such cells at n=26. Together with the existing n>=43 theorem, this is
a finite-certificate extension to every n>=28 for this part of the interval.
The extension is not yet incorporated into the manuscript, public ledger,
website, or Lean files. It does not close the sparse part 2n<m<3n.

Among orders 25..42, exactly these middle cells survive the new recipes:

* n=25, 326<=m<=339;
* n=27, 352<=m<=375.

This removes 1,822 of the old 1,860 middle cells at these orders. Cases n<=24
are outside this bounded check. Failed local optimization gives no upper bound
and no evidence that the displayed surviving cells are unattainable.

## Mechanism A: a third escape choice in the circle

Let vertices be Z/nZ, gcd(h,n)=1, and require all six nonzero, distinct offsets

    C = {1,h-3,h-2,h,h+1,h+2}.

Let A contain 0 and C. Optional arrows are all remaining shifts in A\{0}.
Require, for each q != 0 and each of the following three sets S, that
S is not contained in q+A:

    S0={h,1,h+1}, S1={h,h-3,h-2}, S2={h,h-2,h+2}.

All arithmetic here is modulo n. The requirement means that from any source,
at least one of the indicated destinations avoids every immediate move of
the cop. A recipient reached on the messenger's move receives immediately,
as in the project's existing game semantics.

Here is a conditional ordinary proof, independent of finite optimization.
Set the recipient to 0 and P(z)={z-2,z-1,z,z+2}. All of P(-h) consists of
direct predecessors, including -h-1 because the new offset h+1 is compulsory.
If all of P(z) are universally winning, add in order:

1. z-h+2, using S1 to reach z+2,z-1,z;
2. z-h, using S2 to reach z,z-2,z+2;
3. z-h-1, using S0 to reach z-1,z-h,z;
4. z-h-2, using S0 to reach z-2,z-h-1,z-1.

Every successor is already winning. Thus P(z-h) is winning. Coprimality makes
the successive translates cover the whole circle. Each addition carries a
strict finite rank; this is delivery, not merely indefinite safe travel.
Coincident vertices modulo n can be skipped when already winning.

For every 6n<=m<=n(|A|-1), take the base and the first m-6n optional arrows in
lexicographic order. The same proof works for every subset of optional arrows.
The frozen data specify h,A for every n=25..42, so no search is needed to
construct any graph in these finite intervals.

Why this changes the constraint: the old pair {h,1} required the two sets
h-A and 1-A to intersect only at 0. Hence 2|A|-n<=1. That is a real ceiling
|A|<=floor((n+1)/2), not slack in the wraparound estimate. Replacing it by a
triple removes this half-density ceiling. A triple still implies
3|A|-2n<=1, but that necessary bound is not an attainment theorem.

The six-offset instances alone bridge all existing middle gaps at n=32..42.
For example n=32 uses h=9 and |A|=18, giving every 192<=m<=544.

## Mechanism B: remove cop moves together with messenger moves

Start with the existing twelve-hub construction, guides 12..11+g, and b bulk
vertices, using distinct lexicographic pairs of guides for the bulk codes.
Keep its hub core and guide codes. Replace the common bulk access set

    {1,2,4,5,7,9,11} by {1,4,7,9}.

Also remove every hub-to-guide arrow from hubs {0,5,8,11}. These are exactly
the hub cops whose missing rows no longer meet the smaller bulk access set.
A bulk messenger can escape such a cop through one of its assigned guides.
Keep all the old optional guide-to-bulk and bulk-to-bulk arrows.

The old compulsory count was 106+22g+21b. The coordinated deletion saves
3b+4g, leaving 106+18g+18b = 18n-110 compulsory arrows. Its interval ends at
18n-110+b(g+b-1). Simply deleting bulk access without weakening the relevant
hub cops would lose the escape premise; the paired deletion is essential.

The deletion creates new missing hub-to-guide pairs. Their delivery does not
follow from the old two-move proof. Frozen finite source-rank certificates
handle them, with maximum rank five. Root independently checked the stronger
restriction that hub/guide sources use only hub/guide intermediaries, except
for a direct final arrow to a bulk recipient. This suggests a small reusable
interface theorem, but no new general interface theorem is claimed here.

At n=28, g=6,b=10, this interval is 394..544. The new circle interval is
168..420. Their overlap closes the old gap. Likewise orders 29..31 and 26
close. Do not extend the certificate to g=8: one guide-recipient source-rank
test fails there. Failure of this sufficient rank condition is not a proof
that the actual graph loses.

For n25 the circle reaches 325 and this layer starts at 340; for n27 the
circle reaches 351 and the layer starts at 376. These are concrete further
targets: increase the circle capacity, lower the compulsory layer cost, or
bridge precisely these short intervals with another certified recipe.

## Sparse priority: use earlier extra arrows in later strategies

The six-type construction writes n=6k-r, 0<=r<=5. After deletions it has
8k-9r optional arrows above its 2n base. Reaching 3n therefore needs k>=4r.
The old local-window proof also uses k>=20; the old separated deletion sites
need k>=3r. Improving the proof's window constant cannot repair the lost
optional capacity or supply nonexistent separated sites at small orders.

The main proposed change is to stop requiring the messenger to use the same
2n-arrow base while the cop gets the entire final envelope. Seek explicit
stages G0 subset G1 subset ... subset Gq, with |G0|=2n and |Gq|>=3n, and prove
delivery using Gi against a cop allowed Gi+1. At each new stage, previously
installed arrows become legitimate messenger resources. Each interval between
consecutive stages is then covered by choosing a specified prefix of arrows.

Use ranks R_t(s,c) on BOTH positions when source-only ranks are insufficient:
at a nonterminal state choose a legal messenger successor u that either is t,
or avoids capture and has R_t(u,c')<R_t(s,c) for every legal cop reply c'.
This permits temporary retreats and changes of route in response to the cop.
It also isolates exactly which new cop move breaks an old strategy and what
earlier helper arrow could repair it.

This is a genuine new construction requirement. Existing fixed policies were
already screened for further uniform safe offsets without success. Merely
changing their displayed rank numbers is not enough. Also, winning endpoints
do not imply winning intermediate budgets. Even Gi and Gi+1 both winning need
not imply the asymmetric Gi/Gi+1 condition: a strategy may need a newly added
arrow immediately. If stages are too restrictive, use overlapping envelopes
with different bases rather than insisting on a single nested chain.

Useful initial tests are known sparse bases near n25..29 and the existing
obstruction at n91. The research output must be an edge ordering or composition
rule in n,m with a proof, not an open-ended search prescription.

## Higher-risk consolidation: an order extension with two budget choices

Aim for a marked construction family with an operation adding one vertex and
either two or three arrows net, preserving both universal delivery and the
marked structure needed to repeat it. The arithmetic is decisive:

    [2n,3n] + {2,3} = [2(n+1),3(n+1)].

Such a lemma plus constructions at all 26 budgets 50..75 on 25 vertices would
cover the entire sparse main band at every n>=25. A natural candidate replaces
two marked arrows a->b,c->d by a->x,c->x,x->b,x->d (net +2), with a controlled
extra arrow for the +3 variant. This candidate is NOT known to preserve play.

The necessary interface must handle old-to-old delivery, escape from x,
delivery to recipient x, every cop entry/exit, and preservation of the marked
configuration. Previous insertion attempts achieved safe transfer but failed
terminal delivery. Extensive old splice screens found no successful generic
rule. A lemma for arbitrary winning graphs is therefore not a credible
assumption; one needs a specially designed family and a recipient-sensitive
interface. Derive that interface from successful small staged constructions
rather than starting with unrestricted graph substitution.

Priority: the circle/layer change already supports a middle threshold of 28
by finite certificates; finish its small interface analysis and target n25/27.
Spend the larger research effort on the sparse stage/routing change. Use the
order-extension goal as the criterion for consolidating successful recipes.

# Independent review of the eighteen-arrow package

This review accepts the ordinary reduction and finite-family coverage in
`research/sparse_finish_eighteen_manifest.json`, conditional on the approved
smaller-budget bounds. Root has independently approved the stronger
`M_E(15)=15` and `M_E(16)=19` package. The completed numerical replay is recorded
in `finish_eighteen_review.json`; the separate stronger seventeen-arrow checks
are in `finish_eighteen_review_seventeen.json`.

The eighteen-arrow conclusion is `M_E(18)=33`, attained on every host of size
at least nine. Since the retained `M_V(8)=32` excludes attainment on smaller
hosts, the smallest attaining host is nine. The eighteen-arrow proof also
establishes the subsidiary bound `M_E(17)<=33`; the separately reviewed
seventeen-arrow exclusions below are stronger.

## Ordinary support reduction

Only actual indegree-zero sources and outdegree-zero sinks are deleted.
An old-source messenger cannot enter a source; a messenger delivering to an
old target never needs to enter a sink. Restricting the cop to the remaining
graph therefore bounds every old guaranteed pair by the deleted graph.
The only possible extra pairs lie in the deleted source's row or sink's
column. A source row needs two nonsink successors, and a target column needs
two predecessors of positive indegree. The respective one-neighbor camping
arguments preserve the initial-source exception: the sole successor differs
from its source, and a sole predecessor equal to the initial source would
make the pair direct.

For other degree `d>=2`, the deleted vertex's arrows supply none of the
necessary nonsink-successor or positive-indegree-predecessor capacity.
This proves `I<=M_E(m-d)+floor((m-d)/2)`. At `d=1`, the removed row or
column is empty, giving `M_E(m-1)`. One-arrow fresh-sink attachments justify
monotonicity in the arrow budget without changing the score. Thus zero-degree
graphs have score at most 22 at budget17, and at most
`max(M_E(17),27)` at budget18. First proving the positive17 upper33 and then
the positive18 upper33 is noncircular. No assertion about strong connectivity
or deleting arbitrary vertices having no counted pairs is used.

For positive degrees, set `q=|{d+>=2}|`, `r=|{d->=2}|`, and let the overlap
be `b`. All other degrees equal one, so `q,r<=min(floor(m/2),m-N)` and
the number of arrows in the eligible rectangle equals
`m-2N+q+r+w`, where `w>=0` counts arrows between the two inactive complements.
Subtracting the lower bound on the rectangle's diagonal and on its arrows
gives precisely

`q*r-max(0,q+r-N)-max(0,m-2N+q+r)`.

Maximizing this expression yields 28 for `m17,N>=11`, and 30 for
`m18,N>=12`. For supports at most eight the retained global vertex bound32
suffices; padding with isolates is legitimate. Positive support cannot exceed
the arrow budget. This leaves exactly the five support/budget families listed
in the manifest.

## Joint-degree and adjacency coverage

The producer first lists every positive nonincreasing degree partition by a
direct sum recursion. It pairs each incoming partition with each outgoing
partition, distributing the incoming multiset among vertex labels. Sorting
incoming values only inside equal-outdegree classes loses no joint-degree
multiset. Its partial overlap count can only increase. Consequently the
partial-profile rejection `q*r-current_overlap-minimum_direct<=33` is safe.

The reviewer independently regenerates incoming degrees by a sum recursion
without iterating the producer's incoming partitions. It compares the entire
joint-degree sets, not only their cardinalities, with an instrumented producer
that emits its inventory before any adjacency enumeration. The counts are
8 and 1 at budget17 on supports9 and10, and 48, 13, and3 at budget18 on
supports9,10,11. The two eleven-vertex ranges are `[1,2]` and `[3,3]` in that
same ordered inventory, so they are disjoint and exhaustive.

The row recursion's only symmetry restriction groups future vertices with
the same degree pair and identical already-fixed incoming prefix. Permuting
such vertices fixes every completed row and every required degree. Selecting
a prefix of each class of each possible cardinality therefore preserves a
representative of every completion. Earlier vertices are singleton choices;
the current vertex is excluded to prevent loops. Residual capacities never
discard a feasible completion. Both arrow directions remain independent.

## Prunes and game semantics

The dynamic eligible upper subtracts fixed arrows between inactive complements;
future such arrows only reduce it. Camping losses are unioned before counting.
Row camping uses a cop different from the source. Column camping retains the
possible source-equals-cop exception. Losses for unfinished rows refer only
to completed columns, so those pairs cannot later become direct. There is no
double subtraction of a future direct arrow.

The guarded test is an optimistic messenger game with only fixed cop arrows.
Against a cop that stays until it can capture, an internal messenger position
must avoid the cop's closed outneighborhood. The initial escape is allowed;
the final target arrow is treated separately because receipt precedes capture.
Extra messenger arrows and fewer cop arrows can only make this test easier
for the messenger. Failure is a permanent losing pair, with all initial-source
exceptions retained. A guarantee relation is never substituted for actual
messenger reachability.

The ordinary compressed game uses the least winning fixed point, masks
nonterminal collision states, retains every terminal target state, and
quantifies over all initial cop vertices other than the source. It excludes
diagonal and direct pairs. Its early column cutoff uses an upper bound on all
remaining eligible pairs. The independent replay replaces that entire game
with the explicit two-turn queue in `finish_alternating_review.hpp`, solving
every target completely. Receipt still precedes capture. Every visited graph
is checked, and every traversal counter must match its primary receipt.

Guarded-prune tests are sampled separately with the independent asymmetric
game. They supplement the ordinary argument and are not represented as a
complete replay of all pruned branches. The inherited small-order controls are
also supplementary; the proof does not infer large-order completeness from
those examples.

## Corrected skip and stopping conditions

The original9/18 source skipped three whole degree families although earlier
results covered only their camping-free subfamilies. That shortcut is invalid
and its receipt is not evidence here. The corrected full9/18 source removes
the skip line entirely. The remaining old-source receipts are at budget17 or
support at least10, where the predicate is identically false; their recorded
skip count is zero. The independent replay checks those same counters.

The fullmax9/18 variant may raise its search threshold only after computing
a larger actual game score. Its initial and final thresholds are both33 in
this run, and every evaluated game returns below the threshold, so no dynamic
change occurs. All listed ranges finish completely. Tiny-deadline controls
independently verify `complete=false` and nonzero exit status after interruption.
The historical partial eleven-vertex receipt is excluded in favor of the
complete split ranges.

## Independent lower and stronger seventeen-arrow checks

The reviewer directly checks every supplied rank and losing-region obligation
of the nine-vertex eighteen-arrow literal, without importing its certificate
producer or fixed-certificate checker. All1458 alternating states satisfy the
receipt, collision, existential messenger, and universal cop obligations.
Exactly33 distinct missing ordered pairs win for every permitted initial cop.

The separate17 receipt compares full degree sets and replays 21,382 leaves
for positive9/17 at threshold24 and5,280 leaves for positive10/17 at threshold28.
These establish the two positive-family upper bounds. With the source/sink
bound22, the larger-positive-support bound28, the retained fixed-host8 upper19,
and the separately supplied ten-vertex literal28, they give the stronger
global conclusion `M_E(17)=28`. The eighteen-arrow argument does not require
that stronger conclusion or its lower witness.

The review boundary is ordinary source/coverage proof plus full independent
leaf-game replay. It is not a second independently designed graph enumeration.

All six package runs passed, totaling **73,472** independently solved leaves:
73,445 at budget18 and27 in its auxiliary budget17 exclusions. Traversal
counters match every primary receipt. The separate stronger17 runs check
another26,662 leaves. At615 sampled guarded states,4,248 claimed losing pairs
passed the independent mixed-game test. All six deadline controls reported
incompletion correctly. No incomplete or formerly skipped-family result is
used.

# A sparse universal-delivery circulant

12 September 2026. New derivation during the authorized continuation. Ordinary proof; independent review requested. This is a construction lower bound, not an extremal upper bound.

## Theorem

For n >= 15 with gcd(n,7)=1, let G have vertex set Z/nZ and arcs x -> x+1, x+3, x+7. Every source can guarantee delivery to every recipient against every initial pursuer position other than the source. Consequently m=3n and I(G)=n(n-4).

## Safe branching lemma

Put C={0,1,3,7}. Its six positive differences are 1,2,3,4,6,7, each occurring once. Since n>=15, their negatives are distinct from them modulo n. Thus two distinct translates r+C and c+C intersect in at most one vertex.

Suppose r is different from the recipient and two distinct outgoing neighbors u,v of r each have a guaranteed delivery to the recipient. For every c!=r, at least one of u,v is outside c+C. Move there. This is neither the current pursuer position nor any of its possible next positions. After every pursuer response, the messenger is uncaught and at a universally winning source. Continue using that source's guaranteed strategy for the observed new pursuer position. This concatenation is valid because the intermediate move is explicitly safe for the intervening pursuer turn. It gives a finite winning strategy.

The lemma also applies if one selected successor is the recipient, by terminal receipt; in the proof below this case can simply be handled as immediate delivery.

## Bootstrap argument

Translate the recipient to 0. The sources 0,-1,-3,-7 are guaranteed: the first is already delivered and the other three have direct arcs into 0. Source -4 is guaranteed by its outgoing neighbors -3 and -1. Thus the quartet Q(a)={a,a-1,a-3,a-4} is guaranteed for a=0.

If Q(a) is guaranteed, apply the safe branching lemma in this order:

1. a-7 has outgoing neighbors a-4 and a.
2. a-8 has outgoing neighbors a-7 and a-1.
3. a-10 has outgoing neighbors a-7 and a-3.
4. a-11 has outgoing neighbors a-10 and a-4.

This proves Q(a-7). All displayed pairs of successors are distinct modulo n. Repeating n-1 times gives Q(-7k) for k=0,...,n-1. Since gcd(n,7)=1, the entries -7k cover every vertex. The recursion is finite, so it supplies actual terminating strategies, not only perpetual evasion.

One explicit uniform upper bound is 4n-2 messenger moves: the initial quartet has maximum rank two, and each quartet translation increases the rank by at most four. This bound is only a sufficient delivery-time bound.

## Counting and limits

The three steps are distinct and nonzero. Every distinct ordered pair is guaranteed; remove the n diagonal pairs and 3n direct arcs from n² to obtain I=n²-4n.

When 7 divides n, this proof covers only the four residue classes 0,3,4,6 modulo seven. Independent finite computations show the graph is not universally winning in that case. A failure of this particular graph does not impose a restriction on the extremal problem.

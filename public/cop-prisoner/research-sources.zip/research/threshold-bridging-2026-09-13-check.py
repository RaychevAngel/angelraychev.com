"""Replay the frozen private September 13 threshold-bridging candidates.

Independent adjacency reconstruction and all-recipient source-rank replay.
No candidate discovery or changes to the public classification ledger.
"""
import sys,json,math,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from main_interval_new_independent import bits,audit_graph,layer_rows,replay_ranks,source_ranks
frozen=json.load(open(root/'research/threshold-bridging-2026-09-13-checks.json'))
circles=frozen['circle_candidates']
layers=frozen['layer_candidates']
records=[]
intervals={}
for row in circles['rows']:
 n,h,A=row['n'],row['h'],set(row['A'])
 C={d%n for d in [1,h-3,h-2,h,h+1,h+2]}
 S=[{d%n for d in s} for s in [(h,1,h+1),(h,h-3,h-2),(h,h-2,h+2)]]
 assert math.gcd(h,n)==1 and len(C)==6 and 0 not in C and C<=A and 0 in A
 assert all(0<=x<n for x in A)
 assert all(any((d-q)%n not in A for d in s) for s in S for q in range(1,n))
 B=[bits((x+d)%n for d in C) for x in range(n)]
 E=[bits((x+d)%n for d in A if d) for x in range(n)]
 rec=audit_graph(B,E,range(n),{'family':'six-offset-circle','h':h,'A':sorted(A),'C':sorted(C)})
 assert [rec['base_arcs'],rec['envelope_arcs']]==[row['m_min'],row['m_max']]
 records.append(rec);intervals.setdefault(n,[]).append([row['m_min'],row['m_max']])
for row in layers['rows']:
 n,g,b=row['n'],row['g'],row['b']
 assert n==12+g+b and row['r']==2 and g<=7
 B,E=layer_rows(g,b,2,6)
 for x in range(12+g,n):
  for hub in [2,5,11]:
   assert B[x]>>hub&1
   B[x]&=~(1<<hub);E[x]&=~(1<<hub)
 for hub in [0,5,8,11]:
  for guide in range(12,12+g):
   assert B[hub]>>guide&1
   B[hub]&=~(1<<guide);E[hub]&=~(1<<guide)
 rec=audit_graph(B,E,range(n),{'family':'reduced-hub-access','g':g,'b':b})
 assert [rec['base_arcs'],rec['envelope_arcs']]==[row['m_min'],row['m_max']]
 assert rec['base_arcs']==18*n-110
 restricted_obligations=0
 for t in range(n):
  # Reconstruct stricter messenger rules separately for each recipient.
  restricted=[r for r in B]
  for s in range(12+g):
   restricted[s]&=((1<<(12+g))-1)|(1<<t)
  ranks,_=source_ranks(restricted,E,t)
  restricted_obligations+=replay_ranks(restricted,E,t,ranks)
  replay_ranks(restricted,E,t,row['ranks'][t])
 rec['restricted_top_obligations']=restricted_obligations
 records.append(rec);intervals.setdefault(n,[]).append([row['m_min'],row['m_max']])
ledger=json.load(open(root/'publication/classification-coverage.json'))
coverage=[]
for row in ledger['rows']:
 n=row['n']
 if not 25<=n<=42:continue
 missing={m for l,u in row['unresolved_m_ranges'] for m in range(max(l,3*n),min(u,n*(n-3))+1)}
 after=sorted(m for m in missing if not any(l<=m<=u for l,u in intervals.get(n,[])))
 ranges=[]
 for m in after:
  if ranges and ranges[-1][1]+1==m:ranges[-1][1]=m
  else:ranges.append([m,m])
 coverage.append({'n':n,'previous_middle_missing':len(missing),'now_missing':len(after),'remaining_ranges':ranges})
 assert n in (25,27) or not after
assert [r['remaining_ranges'] for r in coverage if r['n'] in (25,27)]==[[[326,339]],[[352,375]]]
report={'status':'Private independently checked extension; no public ledger, manuscript, website, or Lean update','source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'src/main_interval_new_independent.py',root/'publication/classification-coverage.json']},'circle_candidates':circles,'layer_candidates':layers,'audits':records,'coverage':coverage}
p=root/'research/threshold-bridging-2026-09-13-checks.json'
p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'envelopes':len(records),'all_target_checks':sum(len(r['target_records']) for r in records),'independent_rank_obligations':sum(r['rank_obligations'] for r in records),'restricted_top_obligations':sum(r.get('restricted_top_obligations',0) for r in records),'new_middle_pairs':sum(r['previous_middle_missing']-r['now_missing'] for r in coverage),'remaining_25_to_42':[r for r in coverage if r['now_missing']],'report':str(p)},indent=2))

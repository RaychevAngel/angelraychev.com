# Three protected missing neighbors: a quadratic dense interval

## Research derivation

The earlier high-girth complement argument supplies two outgoing
missing neighbors per cop. Preserving those two fixed candidates while
adding many missing arcs is restrictive: both can become blocked by a
recipient's missing predecessors. In a Cayley graph the two commuting
steps expose that obstruction immediately. The useful change is to
keep three designated candidates, rather than preserve the entire
high-girth condition.

For fixed missing source-recipient difference `a` and initial cop
offset `z!=0`, choose missing core steps `S={1,3,7}`. Protect their
six ordered differences `D={±2,±4,±6}` in a larger step set `A`.
Then at most one member of `z+S` lies in the forbidden source set `A`,
and at most two lie in the forbidden recipient set `a-A`.

The sole remaining blocking pattern has two reflected candidates
with steps `u,v`, forcing `a-z=u+v`, and the third candidate `z+w`
in `A`. It would give two members of `A` whose difference is
`w-u-v`, one of `3,-5,-9`. Forbid these differences and their negatives.
This rules out that final pattern and supplies a safe intermediary
for every missing pair and every legal initial cop.

The exact arbitrary-size proof is saved in
`paper/dense-protected-envelope.md` as Theorem 48. Greedy extension
excludes at most `13|A|+1` residues and yields at least
`ceil((n-1)/13)` steps. This is a robust envelope theorem: arbitrary
subsets of optional missing arcs are permitted, filling every integer
budget between the three-step core and its quadratic envelope.

## Independent attacks built into the argument

- The initial modulus threshold `n>=19` keeps all six core differences
  distinct and keeps them disjoint from the forbidden differences.
- Zero is explicitly excluded from `A`, preventing loops in the
  missing graph. The three core moves also exclude zero.
- Source and recipient endpoints are automatically blocked candidates
  (`a` belongs to `A`, and zero belongs to `a-A`); the chosen candidate
  therefore differs from both endpoints as required.
- The initial pursuer may be the recipient. Nothing requires `c!=t`.
- An overlap of the source and recipient blocking sets does not create
  an omitted case: to cover three candidates with cardinalities at
  most one and at most two, their candidate intersections must be
  disjoint and must have those exact sizes.
- With two candidates in the reflected set, the direction of the
  protected difference is reversed. Its representation is `(v,u)`,
  not `(u,v)`; this yields `a-z=u+v` with the correct sign.
- Actual missing neighborhoods need only be subsets of the translated
  envelope. Thus optional arcs can be chosen independently; the
  result is not limited to arc budgets divisible by `n`.

## Full-main threshold consequence

For `n>=5442`, Theorem 20 with `D=7` connects missing budgets `2n`
through `3n`, since `B7=1814` and `L7(n)>=3n`. The new theorem then
continues through `n ceil((n-1)/13)>=n(n-1)/13`.

On the sparse side, the existing Theorem 41 covers actual arc budgets
`2n..3n`, and Theorem 38 continues through
`T=n(ceil(n/7)-1)`, for which `T/[n(n-1)]>1/8` when `n>49`.
Any budget not covered by either explicit side therefore has
`1/8<p<12/13`. On this interval,

`p^2(1-p)>=min(7/512,144/2197)=7/512`.

The cubic has its only internal maximum at `p=2/3`, so the endpoint
minimum is justified. At `n=5442`,
`7(n-3)/512>74>45>5 log n`: the last inequality follows from
`n<(8/3)^9<exp(9)`. The ratio `(n-3)/log n` is increasing thereafter.
Thus Theorem 25's criterion holds throughout the middle range, and
its exact-budget derandomization supplies a deterministic graph.

This proves the full-main theorem with sufficient threshold 5442,
instead of the earlier `10^12`. This is a consequence of a new
quadratic explicit dense construction, not just a numerical improvement
of the previous asymptotic estimates. The number 5442 is not asserted
optimal. The parent task owns the revised main theorem and combined
joint classification. The original `10^12` proof remains in the audit
history rather than being retrospectively presented as the final bound.

## Evidence scope

`src/dense_protected_envelope.py` builds the envelope and arbitrary
prescribed missing budgets. It checks all safe-intermediary triples
for explicitly listed finite cases and compares both independent full
game solvers with rank verification on selected recipients. Its receipt
is `research/dense-protected-envelope-checks.json`. These finite checks
corroborate the ordinary proof; no new Lean verification is claimed.

The parent task independently checked the argument and rebuilt the
envelope with different greedy choices in
`src/dense_envelope_independent.py`. Its check covered 210 envelopes
on 105 orders and 735,000 source-recipient-cop checks. This is a
separate finite implementation, not merely a second execution of this
agent's construction.

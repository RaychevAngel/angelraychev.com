# Equivalent incremental counting of camping losses

This source variant changes only the `camping` function's bookkeeping in the complete monotone-incumbent engine. It adds no new obstruction and changes neither graph coverage nor the game's rules. The review checks the entire source against the previously frozen source with precisely this function replacement. The positive-degree domain reduction, chronological future-cell normalization, exact incoming capacities, guarded paths and monotone-incumbent proof remain those in the preceding endpoint40 proof files.

In the original function, `bad[source]` is the union of all source-camping and completed-recipient-camping targets, and the final loss count is

    sum over source in A of popcount(bad[source] ∩ B \ ({source} ∪ O[source])).

The replacement forms exactly the same counted union, while maintaining its cardinality as entries are added:

1. In the source-camping pass, only completed sources of degree at least two are considered. The first applicable cop sets the entire source bad mask and adds the number of eligible missing targets in that row. Further cops cannot add another row contribution, so they are skipped once that bad mask is set.
2. In the full-recipient pass, only eligible recipients with exhausted incoming capacity are considered, exactly as before. For each applicable cop, a pair is added only if its source is eligible, differs from both the cop and recipient, has no direct arrow to the recipient, and has not already entered the bad union. These conditions are exactly the filters applied by the old final popcounts, together with its initial-source/cop exception. Each newly added pair increases the count by one.
3. The eligible upper bound is computed once because no graph row changes during this function call. The loss count only increases. Returning false immediately when the current count already makes the upper bound no larger than the threshold is therefore identical to waiting until the entire union is formed.

At the end, both functions return the same comparison. This argument applies to every legal prefix and every threshold. It does not infer correctness from a benchmark speedup.

The actual replacement is also compared directly with the original function for every cutoff from minus one through `n(n-1)` at every tested chronological prefix. The frozen fixture comprises every positive-degree graph through order four, 600 deterministic random positive-degree graphs of orders five through ten, and 81 admissible retained literal graphs. All473,080 exact old/new comparisons agree. The same fixtures independently check the game's actual score and guarded-path claims:2,399 graphs,14,444 prefixes and177,481 specific initial-cop states. The precise fixture, results and source hashes are retained.

The final cell receipt independently checks the complete initial joint-pattern inventory, the source/sink boundary, complete traversal, exact final incumbent, every emitted game leaf, and the full-rank matching lower graph. The earlier timed-out unoptimized pilot is historical only and supplies no part of the complete upper proof.

# Independent review of Theorem52: packed holes and optional arcs

**Conclusion: accepted as an ordinary computer-assisted proof.** I reviewed
`paper/sparse-packed-holes.md`, the primary lift/checker, the independently
written successor/projection checker, the earlier arena and smoothing
implementations, and their receipts. I found no missing move, collision,
boundary case, or subset-monotonicity assumption. No new attractor search
or large rank replay was needed for this review.

## The local simulation

Let A use messenger columns[-4,4], cop columns[-8,8], holesH, and outside
re-entry into±6,±7,±8. Let B use the same messenger columns, copcolumns
[-6,6], cropped holesH0, and outside re-entry into±5,±6. The projection
keeps represented cop vertices in[-6,6] and collapses every other cop
vertex, including A's outside state, to B's outside state.

The graph has precisely two smoothing changes at a removed4_h:
3_h→5_h and1_(h−1)→2_(h+1). Neither new head is of removed type4,
so smoothing never chains through a second hole; maximum base jump is2.
Consequently holes outside[-6,6] cannot affect a retained messenger move.

I checked the potentially troublesome boundary cases explicitly:

* Holeh7 changes the represented tail1_6 from head4_7 to head2_8.
  Both project to B's outside state, so the cropped graph's unchanged
  arc represents the move correctly.
* A hole at−7 can send the outer cop1_−8 directly to2_−6. This is
  precisely a permitted B outside-to-boundary move. Similarly a cop
  at−7 may jump to−5 after smoothing at−6. Both old entry layers are
  needed and present.
* Any A cop in±7,±8 that reaches B's represented region lands in
  ±5 or±6, because base jumps have magnitude at most2.
* A's outside transitions into±6,±7,±8 project only to B's outside
  state or to±6. Those transitions are all permitted by B.

All cop transitions are therefore simulated. Every messenger remains
inside[-4,4], so no collapsed cop can coincide with it; represented
collisions are preserved exactly. The same identity on messenger
vertices preserves delivery targets. Safe-transfer rank0 is allowed
only on a noncollision messenger-turn state. Positive transfer ranks
check every cop response before stopping, whereas terminal delivery is
allowed immediately on arrival, as required by receipt priority.

The rank lift copies the old rank and messenger choice at the projected
cop position. Since messenger move lists coincide and every projected
cop response is legal in B, every positive rank decreases on every real
response. Negative entries make no losing-state or optimality claim.
The source-column checks cover every noncollision cop start, including
outside, for every existing source type and recipient type.

## From an actual ring to A

The hole columns are0,3,...,3(r−1), with r≤5. At k≥180, all cyclic gaps
are at least3 and a17column window contains at most those five distinct
holes. Thus its exact local pattern belongs to the865-pattern list;
patterns with six holes, though geometrically possible in an abstract
17column interval, never arise in this construction.

If a represented cop window contains even one hole, every represented
source column is at cyclic distance≤16 from that hole. Hence ALL
optional arcs at represented cop tails are forbidden. This justifies
using the unaugmented multi-hole arena, even when several holes occur.
If the window contains no hole, the previously checked augmented arena
contains every actual cop move. It may contain additional optional
moves that were globally forbidden near an exterior hole; extra cop
options only strengthen that verified adversary.

An omitted exterior hole at relative+9 can change tail1_8 from4_9 to2_10;
both are outside A. At the left side the affected tail lies outside A.
No exterior deletion creates or removes a represented-to-represented
move. Optional targets are never type4, so exterior deletions cannot
invalidate an optional destination. Actual exterior cops may still use
optional arcs even when the current represented window contains a hole:
this is why A retains THREE re-entry layers. Its outside abstraction
covers their possible jumps of length3.

The two ends of A are separated in the ring by k−17≥163 exterior
columns. A jump of at most3 cannot go directly from one represented end
to the other through that gap. Every exterior-to-interior return lands
in one of±6,±7,±8. This excludes the wraparound shortcut that would be
an issue in much smaller rings.

## Arbitrary subsets, counting, and concatenation

The augmented helper mutates only `pursuer_moves`. Messenger strategies
always use the original/smoothed base arcs. Thus ANY subset of the
allowed optional arcs, not merely the lexicographic subset chosen by
the implementation, preserves every verified strategy.

For r>0 the forbidden source columns form a subset of the cyclic image
of[-16,3(r−1)+16], containing3r+30≤45 integers. Hence at leastk−45
columns each supply eight distinct additional arcs. At k≥180,
8(k−45)≥6k≥n. Optional targets have types0,1,5 and therefore survive;
allowed source columns contain no removed type4. Their nonzero offsets
−3,+3,−2 cannot coincide with a base offset0,±1,+2 modulo k≥180.
There are consequently at leastn eligible nonloop, nonduplicate arcs.
Any requested extra count0..n is attainable.

Every transfer advances one column and ends after the cop response.
At mostk−1 transfers reach the column two before the recipient, taking
at most9(k−1) moves. Local delivery takes≤27 near holes and≤35 in the
augmented clean case. The uniform bound is therefore9k+26.

## Evidence inspected and scope

The primary receipt records865 patterns,5,886 lifted objectives,
3,365,384 required starts, and9/27 local bounds. The independent checker
uses separately written successor formulas and verifies286,414 projected
cop edges,4,496,692 collision equalities, agreement with all865 primary
arenas, and structural counts at n1075..1080. Its inspected receipt is
`research/six-type-independent-multihole-projection.json`.

The result is Theorem52 for every n≥1075 and every2n≤m≤3n, with the
stated finite-certificate dependencies. It is not a new Lean theorem,
and this review makes no additional classification claim outside that
range. It also does not rely on any of the incomplete exceptional-order
searches recorded elsewhere.

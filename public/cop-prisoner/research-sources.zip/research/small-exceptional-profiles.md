# Sharper finite reductions after the seven/eight-vertex solution

These notes preserve verified reductions and bounded incomplete searches.
They do not upgrade Theorem46's still-open n9,10,11 values.

## Capacity and repair bounds

Every source and every recipient contributes at most n−3 indirect pairs.
If a source has fewer than two outgoing arcs, or its entire outgoing
neighborhood is covered by another vertex's closed outgoing neighborhood,
its contribution is zero. Hence I≤(n−1)(n−3). The same bound follows from
any recipient of indegree below two.

A predecessor-camped recipient contributes at most one pair (only the
covering cop vertex itself can be exempt as the initial source). Therefore
b such recipients give I≤n(n−3)−b(n−4).

In a partial outgoing-row assignment, at least q=ceil(T/(n−3)) recipient
columns must eventually have indegree≥2 if target scoreT is to be reached.
The cheapest q deficits max(0,2−current_indegree) cannot exceed the number
of arcs still to be assigned. The new source
`src/small_exceptional_canonical_flow.cpp` implements this necessary test.

When q=n and final arc count is2n+E, let e be the sum of current indegree
excesses above2. A recipient whose current predecessor set has size≥2
and is already covered by a completed cop row needs at least one extra
incoming edge to escape that camping obstruction. If D recipients are
currently so covered, at most E−e can be repaired. Thus
D≤E−e+floor((n(n−3)−T)/(n−4))
is necessary. `src/small_exceptional_canonical_repair.cpp` implements it.
Completed cop neighborhoods are immutable; any later enlargement of a
predecessor set costs an extra incoming edge, so this cannot reject a
valid repair for free.

## Complete n11 budgets22 and23

A score≥85 at n11 forces every source and target to have degree≥2, no
source camping, and no predecessor camping. The remaining camping-free
class at m22 was completely enumerated by canonical permutation factors:
14partitions,2,177,946nodes,120,302leaves, maximum I66 (1.56seconds).
See `src/small_exceptional_regular_max.cpp` and
`research/small-exceptional-regular-max-11.json`.

For m=2n+1, min in/outdegree2 forces a directed perfect matching. If Hall
failed on S, the ≥2|S| arcs leaving S would all enter a set of size≤|S|−1,
whose total indegree is at most2(|S|−1)+1<2|S|. Fix that matching in
canonical derangement cycle form. Its residual graph has outgoing degree1
except for one vertex U of degree2, and incoming degree1 except for one
vertex V of degree2. The centralizer of the fixed permutation is transitive
on all vertices in cycles of a given length, so U can be normalized to one
representative per distinct cycle length, while V ranges over all vertices.
This covers every graph, with harmless duplication.

The complete n11,m23 enumeration has14cycle partitions,330(U,V)patterns,
31,536,058nodes and792,080camping-free leaves. Maximum I in that entire
class is74 (10.92seconds). Code `src/small_exceptional_one_excess.cpp` and
receipt `research/small-exceptional-one-excess-11.json` preserve the exact
winning example. A separate agent independently audited Hall, the cycle
normalization, all residual degree choices, and every incremental pruning
rule. Its complete source/game audit passed. No independent full numerical
re-enumeration of this new maximum74 is claimed here.

Graphs outside the camping-free/minimum-degree class have I≤81 by the
ordinary bounds above. Consequently M(11,22)≤81 and M(11,23)≤81. Since
m≤21 gives at most72 by the arc-only bound, and m≥26 leaves at most84
missing pairs, any improvement over the verified n11 witnessI84 must occur
at m24 or25. These are upper bounds, not claims of equality at budgets22/23.

## Normal form for the remaining budgets

More generally, if all in/outdegrees are≥2 and m=2n+E, Hall deficiency is
at most floor(E/2). In particular for E≤3 there is a matching of size n−1.
As a partial permutation, such a matching is a single directed path
(possibly one isolated vertex with both matching arcs missing) together
with disjoint directed cycles. It can therefore be fixed canonically by
its path length and cycle partition. Enumerating sparse residual graphs
would cover even the cases without a perfect matching. This is a proved
search reduction; a completed exhaustive E2/3 computation is not yet
claimed.

## Failed bounded searches

* n9 target49,m18..23: initial canonical run entered8of19profiles (only7completed)
  in50seconds, with no witness. Capacity-only improvement entered9of19 (only8completed)
  in50seconds. Both incomplete receipts are research evidence, not proofs.
* n11 target85,m22..25 with repair-budget pruning: only2of7profiles entered
  before50seconds, no witness; maximum encountered74. This motivated the
  complete perfect-matching reduction above. It is not an exhaustive
  n11 upper certificate.
* A25second fixed-budget m25 construction search, maintaining every
  indegree/outdegree≥2, found only I78 after1,929,753evaluations. No
  nonexistence conclusion follows.
* `src/small_exceptional_partial_matching.cpp` now implements the proved
  size-(n−1) matching normal form with42path/cycle patterns at n11,
  residual outgoing-degree distribution and the dynamic predecessor
  repair bound. A50second m24,target85 run is in progress; it is a
  bounded attempt, not yet a complete certificate.

All new exhaustive results remain C++ finite certificates with ordinary
reductions; no new Lean coverage is asserted.

## Centralizer reduction and the final bounded decision attempt

For a fixed path/cycle matching, its automorphism group fixes the unique
path pointwise and rotates/permutates equal-length cycle components.
The first n11matching type has five2cycles and group order3840. Maintain
the subgroup fixing every vertex up to the current row and preserving
all earlier outgoing rows. Within that group the new outgoing-neighbor
mask may be chosen minimal; afterward intersect with the stabilizer of
the chosen mask and the next row vertex. This is a complete orbit
reduction: any completion can be relabeled by that subgroup, leaving
all established information invariant. The identity always remains.
`src/small_exceptional_partial_matching_symmetry.cpp` implements this
exact stabilizer chain.

The unsymmetrized m24attempt entered only the first of42matching types
in50seconds:297,861,120nodes and2,702,294leaves, bestencounteredI68.
The centralizer version completed3types and entered the fourth in50s:
393,084,928nodes,1,511,956leaves,bestencounteredI74. Neither is a proof
of nonexistence. These outcomes motivated decision-only game evaluation:
at m24,target85, reject a graph as soon as two missing pairs fail, since
only86missing pairs exist. At m25 the threshold permits no failed pair.
`src/small_exceptional_partial_matching_decision.cpp` implements this
early rejection; it records an actual score only for a successful witness.
The final decision-only run also completed only3types and entered the
fourth:530,907,136nodes and2,035,323leaves in50.00seconds, with no
I>=85 witness. It is incomplete and proves no new global upper bound.
The independently audited source/stabilizer reductions remain available
for a future partitioned or better-pruned search. No jobs remain running.

## Completed checkpoint integrity

The inherited optional positive-control mode of regular_max was corrected
to test I==n(n−3), rather than treating an integer score as a boolean.
The theorem-producing two-argument enumeration never used that mode.
A fresh full n11 replay reproduces all120,302leaves and maximum66.
Both saved extremal class witnesses (scores66and74) were independently
rechecked by both game solvers and full rank certificates saved; the
current hashes are in `small-exceptional-verification.json`.

The partial-matching/stabilizer normal form was independently audited in
`research/partial-matching-symmetry-independent-audit.md`. The audit accepts
the reduction and pruning for n11,target85; it explicitly makes no claim
that the bounded searches completed.

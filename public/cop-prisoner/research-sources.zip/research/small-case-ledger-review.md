# Independent ledger regression and closure review

13 September 2026. This audit compares the current source-pinned numerical
classification with the exact file at starting revision
`9bc812f4f9b0422918904d9036631968214646ae`. It performs arithmetic and saved-data
checks only. It neither imports `classification_coverage.calculate` nor runs
a graph search, game solver, or another exhaustive upper enumeration.

**Result:** all 493,924 admissible cells in the common order-one-through-114
audit box pass. Every one of the 492,660 previously exact values is unchanged.
Every new lower bound is at least its old lower bound, and every new upper
bound is at most its old upper bound. The ledger contains 492,834 exact cells
and 1,090 unresolved cells. It has 174 genuinely newly exact cells:

| Order | Newly exact cells |
|---:|---:|
|7|20|
|8|9|
|9|33|
|10|45|
|11|65|
|12|2|

The canonical unknown count changes from 454 to 101: 69 sparse, 32 main,
and zero dense. This difference of 353 consists of **174 newly exact
values and 179 still-unknown representatives removed by stronger host
reductions**. The latter are not newly solved values. The current raw
unresolved count includes 989 larger-host repetitions of the 101 canonical
unknowns. The saved receipt includes every new exact interval and every
remaining canonical interval, independently generated from cell values.

## Baseline and independent affine decoding

`research/small-case-baseline.json.gz` is a deterministic gzip archive of
the exact starting-revision ledger blob. Its decompressed SHA-256 is
`f83cd50669d06c0cb5d1f6e04280f910416c24f15611d0cef09da9b792cf0273`.
The reviewer asserts this digest before decoding it. Historical source
hashes identify that baseline; they are not incorrectly checked against
today's edited files.

`src/small_case_ledger_review.py` independently expands each lower and upper
affine segment. It checks contiguous, disjoint coverage of every budget,
exact/unresolved status against numerical equality, valid rule references,
and `0<=lower<=upper<=n(n-1)-m`. It also checks each recorded lower recipe's
support and disjoint-padding budget are arithmetically feasible. All row
counts, raw unresolved intervals, total counts, and region splits are
reconstructed rather than trusted from the ledger's summaries.

This arithmetic feasibility check is not a new proof of the graph recipes.
Their delivery ranks and ordinary family proofs remain separate inputs.

## Independent incremental closure

The source diff since the starting revision adds only the finite small-case
registry and its host cutoffs to the existing numerical calculation. The
reviewer reconstructs the full numerical update from the frozen old bounds,
using its own direct loops and no producer import:

1. Each approved upper statement is applied only at its stated order and
   budget, or globally in the dimension explicitly marked unrestricted.
2. Each literal graph supplies only a lower bound. It may be placed at its
   own order or combined with a separate zero-count row-prefix component
   whose vertex and arrow capacities are checked. No arbitrary arrows are
   added inside its winning component.
3. Each independently certified stage interval supplies its stated
   missing-pair equality. Optional-subset correctness is an input from the
   separate rank review, not inferred from interval endpoints.
4. Isolate invariance propagates lower bounds to larger hosts. The approved
   host reduction also transports the representative's upper bound once
   the host exceeds the relevant cutoff.

The resulting pair of bounds agrees with the current ledger at **every
cell**, including all cells still unresolved. The review separately checks
that the consolidated upper and host-cutoff lists exactly match the
approved registry. This validates the integration of the new evidence;
it does not replace the independent mathematical review of that evidence.

## Canonical expansion and exact domains

The current cutoffs at budgets 12 through 21 are

    (12,13,16,18,15,18,15,18,11,15).

At other positive budgets the generic cutoff remains `2m`. For every
unresolved raw cell, the reviewer maps `(n,m)` to `(min(n,B_m),m)` and
checks equality of both bounds. It independently counts and groups the
canonical images, then checks the ledger's complete canonical range list.
It also checks the entire bound plateau above every cutoff, including
already exact budgets. Thus removing a repeated host cannot conceal a
different recorded bound or an omitted canonical unknown. The maximum
remaining canonical order is eighteen.

All 43 budgets at order seven are exact. Every final dense cell in the
audit box is exact. Every cell with `n>=11,m>=22` is exact and agrees with
the ordinary formulas, including the eleven-vertex values 79, 78, and 79
at budgets 22, 23, and 24. The main missing-pair formula is used from
budget 25 at order eleven and from its full stated interval at larger
orders. The sparse parity and dense staircase formulas are checked at
their proper boundaries. Remaining main-interval representatives occur
only at orders eight through ten.

Selected new cells are checked explicitly:

    M(8,12)=M(9,12)=9, M(8,13)=11, M(8,39)=14,
    12<=M(8,40)<=13.

The last interval remains open and is not marked exact. Its final upper
improvement changes the bound but not the count of unresolved cells.

## Marginal readback

Taking independent maxima of lower and upper entries gives

    M_V(8)=32,
    48<=M_V(9)<=53,
    62<=M_V(10)<=69,
    M_V(11)=85.

At twenty arrows, maximizing over all admissible rows gives
`53<=M_E(20)<=57`. The host-eleven plateau check and its separately proved
compression extend that finite readback to all larger orders. This is a
bound interval, not an exact value. Exact joint values do not imply that
all the remaining marginal bounds coincide.

## Evidence boundary and reproduction

Run `python3 src/small_case_ledger_review.py` for the final pinned audit.
The optional `--preview` performs the arithmetic without writing the final
receipt or requiring the final `(8,40)` source state. The ordinary review,
source, compressed baseline, current ledger, approved registry, and relevant
integration sources are hashed in `research/small-case-ledger-review.json`.
The audit also checks every source hash embedded in the current ledger and
rejects a ledger that changes during the run.

This is an independent regression, arithmetic-coverage and evidence-
integration check. It does not prove every input theorem anew, infer
winning graphs from numerical equality, or formalize the new claims in
Lean. Explicit attaining recipes remain a separate audit. Since this
receipt pins the final ledger, it belongs downstream of that ledger and
must not be added to its own source-input hash list.

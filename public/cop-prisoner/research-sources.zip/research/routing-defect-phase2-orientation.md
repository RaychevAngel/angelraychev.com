# Exact-count routing from orientations

2026-09-13. New deduction in the second routing/support phase. This is an
ordinary proof with bounded independent finite attacks; it is not yet a
manuscript theorem or a new Lean existence theorem.

## Statement

Fix n>=4 vertices and a specified set H of b routing vertices, where
3<=b<=n. Put L=n(n-1), Q=b(2n-b-1), and A=Q/2. The integer A counts
the unordered pairs having at least one endpoint in H.

Suppose

    n(n-1)^2 (7/8)^(b-3) < 1.                         (O)

There is a deterministic algorithm, polynomial in n, orienting exactly
one arrow on every unordered pair touching H such that every assignment
of directed arrows wholly outside H guarantees every source–recipient
pair within two messenger moves. In particular, one incident-arrow
choice supplies every exact integer budget A<=m<=L-A.

A slightly sharper sufficient condition is

    n(n-1)(n-2)(7/8)^(b-3)
      + n(n-1)(3/4)^(b-2) < 1.                      (O+)

Condition (O) implies (O+). The robust conclusion does not permit
changing an incident arrow or adding its reverse: those arrows are
fixed. It does permit arbitrary reciprocal arrows outside H.

## Random construction and the recipient-cop coincidence

Orient every incident unordered pair independently and uniformly. The
number of incident arrows is ALWAYS A, so there is no conditioning on
an arc count.

For distinct s,t and an initial cop c!=s, consider a routing vertex
u outside {s,t,c}. If c!=t, the three orientation requirements are

    s->u, u->t, u->c.

They have probability 1/8. The last arrow guarantees the absence of
c->u, because exactly one direction of that incident pair is present.
The orientation variables for different choices of u are disjoint.
This remains true when any of s,t,c belongs to H: candidates exclude
all three endpoints, so a variable between two candidates is never
used by either test.

When c=t, the last two requirements coincide. There are only two
variables, and the success probability is 1/4, not 1/8. There are at
least b-3 candidates in the first case and b-2 in the second. Counting
n(n-1)(n-2) and n(n-1) triples respectively gives (O+) as an upper
bound on the expected number Z of bad triples and on the probability
of any bad triple. The coarser (O) is valid since
(3/4)^(b-2)<=(7/8)^(b-3).

Whenever a witness exists, u differs from the cop, and the cop cannot
reach u on its response. Both messenger arrows are present. Receipt
on the second messenger move precedes interception at the recipient.
None of these facts depends on arrows wholly outside H, so the
conclusion is simultaneous over all exterior assignments.

## Simpler exact derandomization

For a partial orientation assignment, let ell be the number of undecided
unordered pairs. There are C=2^ell completions, and every one still
has exactly A incident arrows.

For a fixed triple, each candidate has two or three distinct required
orientation variables. If its fixed orientations already contradict a
witness, its q free variables allow 2^q bad assignments. Otherwise
exactly one assignment completes the witness, so the number is 2^q-1.
Candidate variable sets are disjoint. Multiply these factors and
multiply by 2^q0 for undecided variables not used by a candidate.
The result counts exactly the bad completions for this triple.

Summing over triples gives an integer B. Under (O+) initially B<C.
On fixing the next orientation, B=B0+B1 and C=C0+C1. Choose a child
with Bi<Ci. At the end C=1 and B=0. The completed orientation supplies
every witness.

This algorithm has O(n²) decisions, O(n³) triple counts per decision,
and O(n) factors per count. Counts have O(n²+log n) bits, so ordinary
exact arithmetic is polynomial. Unlike the previous directed-arc
algorithm, this special case does not require generating polynomials
or coefficient extraction. No fast practical large-instance runtime
is asserted.

## Consequences and preserved boundaries

Taking b=ceil(24 ln n+4), when b<=n, gives

    n(n-1)^2(7/8)^(b-3)
      < n³ exp(-(b-3)/8) <= exp(-1/8) < 1.

Thus the former exact-budget sufficient routing-set size
ceil(32 ln n+11) can be reduced in this half-density specialization,
while retaining a specified H, a polynomial deterministic algorithm,
two-move delivery, and arbitrary exterior subsets. Using the exact
(O) instead of its exponential relaxation improves the constant
further; the condition itself is straightforward integer arithmetic.

This does NOT supersede arbitrary incident density p=a/Q in Theorem
54. The orientation theorem treats the exact incident count A=Q/2.
The original directed sampling model and its other density/budget
conclusions remain separately valid. The new proof can become a
stronger special case within a unified routing theorem.

## Ordinary full-main overlap at n>=1075

Set b=floor(3n/20). Since ln(8/7)>2/15 (for example by integrating
2/(1-x²)>2 from 0 to 1/15),

    (b-3)ln(8/7) > (3n/20-4)*2/15 = n/50-8/15.

At n=1075 this last quantity is 629/30, greater than 419/20.
Also ln(1075)<419/60, so 3 ln(1075)<419/20. One exact verification
is the finite rational sum

    sum_{j=0}^{24} (419/60)^j/j! > 1075;

the receipt gives its exact numerator and denominator. The derivative
of n/50-8/15-3 ln n is 1/50-3/n, positive for n>150. Hence (O)
holds for every n>=1075.

Let T=n(ceil(n/7)-1), the existing sparse envelope endpoint. The
monotonicity of b(2n-b-1)/2 for b<=n gives

    A <= 111n²/800-3n/40,
    T-A >= 23n²/5600-37n/40 >= 0                 (n>=226).

The interval [A,L-A] therefore overlaps the old sparse endpoint T and
reaches L/2. The existing full-vertex routing theorem handles densities
1/2<=p<=12/13 at n>=1075, since (n-3)p²(1-p)>=(n-3)/16 and the
logarithmic condition already holds there. The previous dense bridge
and protected missing envelope handle the rest through L-2n.

Thus, together with the already proved sparse bridge from n=1075, this
would lower the old full-main threshold from 1664 to 1075. A separate
parent-agent sparse improvement may lower that bridge further; the
number 1075 here is only the independently justified overlap above.
The entire main interval is not claimed to become a two-move result:
its sparse pieces still have their longer strategy bounds.

## Bounded attacks and receipt

`src/routing_defect_phase2_orientation.py` implements the integer
orientation counter and conditional construction. Direct enumeration
of at most seven free variables checked 1,230 triple counts at orders
2 through 7, including 327 cases c=t. Branch partitions passed.
A complete restricted-objective construction was also checked; it is
not represented as a full universal graph construction.

Exact-size sampled orientations at n=128 and n=256 passed every
source–recipient–cop test, including empty, full and alternating
exterior assignments. Their budgets are respectively [8107,8149]
and [25737,39543]. One initial n=256 sample failed at source 61,
cop 60; a second independent seed succeeded. Both facts are retained
in the receipt. A probability-of-failure bound does not say every
random sample succeeds.

The saved receipt is
`research/routing-defect-phase2-orientation-checks.json`.
No large deterministic run, new Lean existence proof, optimal leading
constant, or exact q2 formula is claimed.

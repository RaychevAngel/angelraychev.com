# Independent ordinary-proof audit: sparse support stability

Date: 2026-09-12.
Proof source: `paper/sparse-stability.md`, Theorems 56--57 and their
corollaries. Proof authoring was delegated to the sparse-support agent;
the parent/root agent independently read and attacked the saved proofs
line by line before approving their integration.

## Result

**PASS for the ordinary statements and their stated ranges.**

- At `m=2k`, for every `k>=6`, either deleting isolates leaves exactly
  `k` vertices of indegree/outdegree two, or
  `I<=(k-1)(k-3)`.
- At `m=2k+1`, for every `k>=3`, a count above `k^2-4k+6` forces the
  stated induced-core reduction or one of the three `k+1`-vertex
  degree-one exception families.
- The induced core has at least the original graph's count. This is
  justified by restricting actual delivery play, not by an unsupported
  monotonicity claim about deleting arcs or vertices.

The independent review checked all active-set corners and the numerical
remainder. In particular it checked the new even case
`q=r=k-1,b<=1`: two indegree-zero active sources and only two surplus
indegree units force either a zero recipient column or duplicate
outgoing pairs giving a zero source row. It also checked that the
`b<=2` full-active case bounds surviving rows AND columns by `b`,
and that the `b>=3` case retains a diagonal exclusion.

For the odd proof it checked zero-row/zero-column intersections,
the `max(0,k-5)` diagonal term at `k=3,4`, the positive exceptional
degrees when `b=k-1`, and every allowed configuration of outside arcs
when `A=B`. An outside sink cannot occur on a successful path to a
core recipient; an outside indegree-zero vertex cannot be reached from
the core. When the crossing arcs share their outside vertex, that
vertex may be useful and is correctly retained as a separate family.
No invariance of the game under reversing every arc is assumed.

The even statement extends to `k=5` using the existing finite value
`M_E(10)=6`, and fails at `k=4` because the known eight-arc witness
has four guarantees. The uniform even proof itself is ordinary for
`k>=6`. The conditional odd statement is vacuous at `k=0,1,2` by
the existing elementary values. Its ordinary proof covers `k>=3`.

## Arithmetic check: exact scope

The proof-authoring agent additionally checked every numerical case for
all integer triples `0<=q,r<=k`, `0<=b<=min(q,r)` at `6<=k<=50`
in the even proof and `3<=k<=50` in the odd proof. All1,217,795
cases passed; the recorded runtime was0.38seconds. The detailed counts
are in `research/sparse-stability-development.md`.

**These are arithmetic parameter checks, not graph enumerations.**
They neither establish the unbounded parameter range nor verify the
game-theoretic camping and induced-core arguments. Those conclusions
come from the ordinary proofs and their independent review.

## Existing finite dependencies and integration

The four new numerical consequences are upper bounds only:
`M_E(12)<=15`, `M_E(14)<=24`, `M_E(16)<=35`, `M_E(22)<=81`.
Their existing finite premises are `M(6,12)=7`, `M_V(7)=21`,
`M_V(8)=32`, and `M(11,22)<=81`. No new graph enumeration is
needed to combine those premises with Theorem56.

In `paper/main.md`, Theorem6 now uses Theorem56 for `k>=6` and
retains a direct ordinary ten-arc argument for `k=5`; it therefore
does not acquire the finite dependency of the optional five-core
extension. Theorems7 and9 use Corollary57.1, and Theorem8 uses the
strict gap in Theorem56. The new support proofs depend only on the
previous elementary camping facts and active-set count, not on these
old upper/equality theorems, so these forward references are acyclic.

Theorem53 now applies Theorem57 at `k=11`, with cutoff83, and excludes
its induced-core alternative using the unchanged eleven-vertex
22/23-arc bound81. It retains the original three complete finite
enumerations, their pruning rules, the actual-game evaluation, all
counts, the lower witness, and their existing verification boundaries.
The historical specialized ordinary audit remains linked separately;
this document records the independent review of the new general
reduction replacing it.

## Separate bounded 22-arc search

The construction-first search in
`src/one_diamond_eleven_search.cpp` and
`research/one-diamond-eleven-search.json` is a separate experiment.
It completed its candidate class in2.31915seconds, with all14 first
permutation types,7016903partial nodes and484471 leaf games;
the largest candidate count was71 and no81-witness was found.
The class includes a harmless extra case where the camping cop is
also the recipient.

**No additional 22-arc upper bound is promoted in this audit.**
Promoting that negative search requires a separate independent review
of its coverage, pruning and game evaluation. The ordinary stability
theorems and the corollary `M_E(22)<=81` do not depend on that run.
No Lean formalization of Theorems56--57 or the new consequences is
claimed.

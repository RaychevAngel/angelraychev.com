# Independent review of the joint case M(8,39)

13 September 2026. Review of the existing dense-family construction and finite
exclusion; no new construction search. The claim passes ordinary/source
review and the independent literal/orbit checks described below:

    M(8,39) = 14.

There are seventeen missing nonloop arrows. Write `F(v)` for a missing
outgoing row, `q(v)=|F(v)|`, and `Delta=17-I`. An upper proof must exclude
`Delta<=2`. The lower14 is the literal certificate
`research/small-plateau-search-n8-m39-seed81339-certificate.json`.

## Ordinary degree reduction

If any missing row is empty, a pursuer at that vertex captures every first
nonterminal messenger move and there are no guaranteed indirect pairs.
Thus every `q(v)>0` in a putative counterexample. Let `ell` count the
degree-one missing rows and let `e=sum max(q(v)-2,0)`. The degree sum gives
`e=ell+1`. When `ell>0`, the previously proved degree-one counting bound
`Delta>=ceil(ell/2)+1` gives `ell<=2`.

For `ell=2`, the stronger degree-one image count forces the two functional
vertices to map to one another. Indeed, an image outside that two-element
set would give `Delta>=ceil((2+3)/2)=3`. The two-cycle rows already account
for the entire allowed loss. Every other missing row must avoid that cycle:
a missing arrow into it would make that whole row lose against the
corresponding degree-one pursuer. The other six vertices would consequently
form an ordinary universal missing core, with fifteen missing arrows.
A pursuer confined to that core captures any excursion to the cycle, so
universality in the original graph really implies universality in the
induced core. This contradicts the retained `M_V(6)=7`.

For `ell=1`, write the functional row as `c -> x`. The row at `x` is wholly
lost, so `q(x)=2`; a larger row would already exceed the allowed loss.
Put `Y=F(x)`, a two-element set not containing `x`. Against a pursuer at
`c`, every missing pair into a member of `Y` fails. The usual exception
for source `c` contributes no missing pair into `Y`, since `F(c)={x}`.
Therefore all missing rows other than `x` avoid `Y`. Every other
nonfunctional row also avoids `x`, because a missing arrow into `x`
would make its entire row lose against the same pursuer. All pairs outside
the row at `x` have to win.

If `c` belongs to `Y`, the five vertices outside `{c,x} union Y` have
all their missing neighbors within that five-vertex set. They would form
an ordinary universal core of missing minimum degree two, contradicting
`M_V(5)=4`. The core pursuer has delivery arrows to each removed vertex,
so an outside excursion does not invalidate this restriction.

If `c` does not belong to `Y`, the four remaining vertices have missing
rows contained in that core plus the root `c`. The root has direct delivery
to each core recipient. An attempted nonterminal arrival at the root is
useful only when it is safe from the current core pursuer; otherwise the
pursuer captures there. This is precisely the corrected safe-root game,
not a game that declares every root arrival an unconditional success.
The other removed vertices are reachable for immediate capture by every
core pursuer. All retained missing pairs would thus win in the corrected
four-core interface.

There are exactly two units of excess above degree two among all seven
nonfunctional rows. Some may occur at removed vertices. Hence the complete
list of possible four-core degree profiles is

    (2,2,2,2), (3,2,2,2), (4,2,2,2), (3,3,2,2),

up to relabeling. Every profile has been excluded in the independently
reviewed rooted checks. The first two occur in
`research/small-dense-rooted-small-enumeration.json`; the latter two occur
in `research/small-dense-r2-rooted-profiles.json`. The review receipt
`research/small-case-rooted-independent-review.json` contains all four
families with no surviving leaves. This audit checks that the required
data hashes still agree with that receipt. Thus the degree-one branches
are fully covered.

## No degree-one row: complete normalization and pruning

For `ell=0`, the seventeen missing arrows force degrees `(3,2,2,2,2,2,2,2)`.
Relabel the unique degree-three source as0 and its three neighbors as1,2,3.
Every remaining source chooses an arbitrary two-element subset of the
other seven vertices. No missing indegree condition is assumed.

The wrapper `src/small_dense_near_endpoint_profiles.cpp` sets exactly this
domain and calls the unchanged engine `src/small_dense_first_step_profiles.cpp`
with defect cap2 and target score15. The source has been read and reviewed.
Its two partial pruning rules count a literal union of forced lost pairs:

- If completed `F(c)` is contained in completed `F(s) union {s}`, where
  `c!=s`, the cop starting at `c` kills every missing pair in source row `s`.
- If `F(c)` and every row at its missing neighbors are complete, and those
  neighbor rows all contain a target `t`, the cop at `c` kills every
  completed missing pair to `t` except a pair from source `c`.

The second rule retains the excluded initial cop position, and the union
prevents double-counting a pair. Both rules remain true under every
completion of the unfinished rows. The engine discards a prefix only if
this union has more than two pairs. Its choice of the next row by smallest
remaining domain changes traversal order without removing a candidate:
every valid row choice is visited, and an empty domain means that every
possible choice already has too many forced losses. Candidate assignments
and assigned flags are restored when scanning another row and when
backtracking; no sibling-specific row is retained.

The complete log records 46,344 prefixes and 3,168 leaves, without a time
cap or score15 witness. The ordinary C++ game uses closed movement
neighborhoods for waits, immediate recipient success, and exclusion of
nonterminal collision states. Independently verified fixed certificates
below provide a separate check of every complete graph's score.

## Orbit and full negative-rank replay

After enumeration, the producer grouped leaves using all permutations
fixing0 and separately permuting `{1,2,3}` and `{4,5,6,7}`. This group has
order144 and preserves the normalized first row. It is not a further
unjustified restriction on the graph search: it is used only to share
fixed-game certificates between isomorphic completed leaves.

The independent reviewer `src/small_sparse_eight39_review.py` reconstructs
these permutations and their action on literal missing arrows without
importing the producer. The 22 representative orbits contain exactly all
3,168 stored leaves, with no missing or duplicate leaf. Each stored
representative index and leaf score is checked against this independent
orbit map. The full negative certificates are read from
`research/small-dense-near-endpoint-negative-certificates.json` and checked
using the separate literal verifier `src/small_case_certificate_review.py`.
That verifier imports no game solver: it checks every winning rank decrease
and every losing-region closure obligation directly against legal arrows,
including recipient priority, waits, collision and both players' turns.
This gives 22,528 negative-state obligations. The same checker verifies
the lower14 witness and its 1,024 states.

The review also checks the explicit cop position in every source/recipient
camping witness obtained from eight nested partial prefixes of each of the
22 negative representatives. Each such starting state is losing in the
independently replayed rank certificate. These checks attack the actual
direction and initial-cop exception of the pruning statements.

**Important boundary:** the maximum13 among the filtered surviving leaves
is not an upper bound13 on the entire `(3,2,...,2)` degree family. The
lower14 witness has that same degree pattern and is legitimately discarded
by the upper-proof filter because it already has at least three explicit
forced losses. The enumeration establishes the exclusion of scores15 and
above. Together with the degree-one branches and the fixed lower14, that
proves the stated exact value.

This audit comprises ordinary/source completeness review, independent full
leaf-orbit coverage, and direct full-game certificates. It does not claim
a second complete traversal of the 46,344-prefix search tree, nor a Lean
formalization of the concrete finite enumeration. It asserts nothing new
about `(8,40)`.

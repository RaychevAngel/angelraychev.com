# Catalogue after the stronger-theorem phase

Prepared for Angel's request for an exact status comparison and research priorities. This is an explanatory audit of the current manuscript, not a new publication checkpoint. It does not change the paper, website, or verification claims.

## Counting honestly

At the same granularity as the original 30-entry answer, the catalogue still has **30 entries**. The original catalogue was not a list of 30 logically atomic theorems: it already included collections of finite values, structural lemmas, counterexamples, and a formal-verification artifact.

- The former exact-budget and random-density entries become one protected-routing theorem: 2 to 1.
- The former dense endpoint, bridge, whole staircase, and additional staircase entries become three substantive claims: 4 to 3. The universal upper bound remains part of the staircase entry, as before; it is not superseded by construction at particular orders.
- The former even/odd equality-shape entry becomes two stronger quantitative support theorems: 1 to 2.
- The order of the first universal two-move budget is a new entry: plus 1.

Thus 30 - 1 - 1 + 1 + 1 = 30. Counting the three parts of Theorem 58 as a single result would artificially improve this tally. The mathematics and proofs have improved substantially, but the sparse construction families have not yet been superseded.

Write L=n(n-1), h=L-m. “Universal” means every source–recipient pair is guaranteed against every legal initial pursuer and subsequent strategy. I(G) counts only indirect, nonloop pairs. All times count messenger moves. Arbitrary-subset robustness means every subset of a specified optional-arrow list works, not merely that some graph exists at each arrow count.

## The current 30 entries

1. **Full main interval.** For every n>=1664 and 2n<=m<=n(n-3), M(n,m)=L-m, with deterministic attaining constructions. The threshold was 1800. This is not a two-move theorem across the whole interval. The combined joint formula for m>=24 is an assembly of this result and the sparse/dense results below, not an additional entry. Source: paper/exact-budget-derandomization.md; paper/joint-classification-resume.md.

2. **Every sufficiently large even sparse budget, with a delivery bound.** For k>=12, M_E(2k)=k(k-3), attained on k vertices and every larger host, within 9 ceil(k/6)+18 moves. Consequently M_V(k)=M(k,2k)=k(k-3). The uniform family starts at 85; finite certificates cover 12 through 84. Source: paper/sparse-all-orders.md.

3. **Every sufficiently large odd sparse budget.** For k>=12, M_E(2k+1)=k(k-3)+2, attained on k+1 vertices and every larger host. Delivery within 34 ceil((k+1)/6)+27 is proved for support k+1>=145. The smaller supports 13 through 144 have finite witnesses; the written theorem does not assert the same numerical time bound for them. Source: paper/odd-endpoint-resume.md.

4. **A faster odd subfamily.** At support n=6q with q>=15 and budget m=12q-1, the extremal value is (6q-2)(6q-3), with delivery within 14q+12 moves. Its better time bound prevents its deletion from the catalogue. Source: paper/odd-endpoint-resume.md.

5. **Robust sparse interval at every sufficiently large order.** For n>=1075 and every 2n<=m<=3n, M(n,m)=L-m. Every subset of the prescribed optional arrows works, with delivery within 9 ceil(n/6)+26 moves. Source: paper/sparse-packed-holes.md.

6. **Robust sparse intervals at smaller multiples of five.** For n divisible by five and n>=80, every 2n<=m<=3n is attained with arbitrary optional subsets and time 8n/5+16. At n=50,55,60,65,70,75, every 2n<=m<=11n/5 is attained with the same robustness and time 8n/5+18. These smaller-order guarantees survive entry 5. Source: paper/sparse-budget-interval.md.

7. **Protected circular construction beyond 3n.** For n>=25, every 3n<=m<=n(ceil(n/7)-1) is attained, with individually optional extra arrows. The base has three outgoing arrow types; this does NOT assert delivery in three moves. The construction also covers m=3n at n=15,16,17,18,19,20,22,23,24. Source: paper/main-interval-resume.md; paper/main.md.

8. **Prime-square construction with square-root delivery time.** For prime p>=5 and n=p^2, every 4p^2<=m<=p^2(p-1) is attained with arbitrary intermediate subgraphs and time 5p-3. The statement is for primes, not automatically all prime powers. Source: paper/parabola-family.md.

9. **Protected routing at exact budgets, including random sampling.** Let n>=4, prescribe a routing set H of size b, and put Q=b(2n-b-1). For integer 0<a<Q, p=a/Q, the condition (b-3)p^2(1-p)>4 ln n+ln(8/3) gives a deterministic polynomial algorithm choosing exactly a incident arrows. Every exterior-arrow assignment works within two moves, giving all a<=m<=a+(n-b)(n-b-1). Independently, for every real 0<p<1, random incident-arrow sampling fails with probability at most n(n-1)^2(1-p^2(1-p))^(b-3). The latter assertion does not require the inequality or an exact integer budget. This contains both old density entries in full. Source: paper/routing-unification.md, Theorem 54.

10. **The first universal two-move budget has order n log n.** Define q_2(n) as the least arrow budget allowing universal two-move delivery. For n>=2, q_2(n)>=ceil((n/2)(log_2 n-1)). Set b=ceil(32 ln n+11), A=b(2n-b-1)/2. If b<=n, every A<=m<=L-A admits a deterministic universal two-move construction; for n>=4096 this extends through m=L-2n. Thus q_2(n)=Theta(n log n). Its exact value, leading constant, and absence of holes immediately above q_2(n) remain open. Source: paper/routing-unification.md, Corollary 55.

11. **The wider protected dense interval.** For n>=19, every 3n<=h<=n max(3,ceil((n-1)/13)) attains M(n,L-h)=h in two moves, with arbitrary optional subsets. Its larger range and smaller orders are not subsumed by the next entry. Source: paper/dense-protected-envelope.md, Theorem 48.

12. **The improved robust dense bridge.** Every 2n<=h<=3n is attained in two moves, with arbitrary subsets of one optional list, for every even n>=22, every odd n>=33, and n=29. In particular it holds at every n>=32; the old all-order threshold was 166. Source: paper/dense-unified-core.md, Theorem 58(2).

13. **The improved dense endpoint at smaller orders.** M(n,n(n-3))=2n, with two-move constructions, at n=10 and every n>=12. This includes orders below entry 12 and improves old three-move endpoint constructions. Source: paper/dense-unified-core.md, Theorem 58(1).

14. **The dense staircase, including its universal upper bound and smaller-order clauses.** For every admissible n>=2 and 1<=r<=n, M(n,n(n-3)+r)<=2n-r-ceil(r/2)-1. Equality with two-move attaining graphs holds throughout the band for n>=24, formerly 75. It also holds for r=1 at every n>=16; for r>=2 when k=n-r is 10 or at least 12; and for r>=2, k>=1 when k<=binomial(floor((r-1)/2),2). The endpoint k=0 holds at every n>=2. These clauses preserve useful smaller cases rather than hiding them behind the threshold 24. Sources: paper/followup-extrema.md, Theorem 27; paper/dense-unified-core.md, Theorem 58(3) and its proof.

15. **The final nonzero endpoint, zero band, and functional-graph characterization.** For every n>=2, M(n,n(n-2))=floor((n-2)/2), and M(n,m)=0 for m>n(n-2). If the missing graph is the loopless function f, its missing pair (s,f(s)) wins exactly when f^(-1)(s) is empty and f^(-1)(f(s))={s}; every such pair wins in two moves. This arbitrary-graph iff statement survives the staircase formula. Source: paper/main.md, Theorem 13.

16. **Complete smallest-order and smallest-budget values.** The joint values are known at every admissible (n,m) with n<=6. The values M_E(0),...,M_E(11) are 0,0,0,0,1,1,2,2,4,5,6,8, attained on every host n>=7. Sources: paper/small-arcs.md; paper/small-arcs-resume.md; paper/small-orders-resume.md.

17. **Small vertex maxima and exact supporting joint values.** M_V(7)=21 and M_V(8)=32, with M(7,21)=21, M(8,24)=32, M(9,24)=48, M(10,28)=62, M(11,26)=84. Remaining intervals are 48<=M_V(9)<=53, 62<=M_V(10)<=69, 84<=M_V(11)<=87. The smallest noncomplete universal graph has order seven; the smallest order n>=4 attaining n(n-3) is twelve. Source: paper/small-orders-resume.md and its cited finite certificates.

18. **The exceptional 23-arrow maximum.** M_E(23)=83, attained on every host n>=12. Its support reduction is now a consequence of entry 21, but the exhaustive exclusions within the reduced families remain necessary. Source: paper/odd-endpoint-twenty-three-exact.md.

19. **Finite exclusions below the eventual sparse formulas.** Every arrow budget 12 through 23 fails to attain the eventual even/odd polynomial. The established eleven-vertex core bounds include M(11,22)<=81 and M(11,23)<=81. The new support theorem yields M_E(12)<=15, M_E(14)<=24, M_E(16)<=35, M_E(22)<=81. Exact M_E(12),...,M_E(22) remain open; the one-diamond experiment has not established a promoted upper bound of 80 at 22 arrows. Sources: paper/small-orders-resume.md; paper/sparse-stability.md; research/sparse-stability-development.md.

20. **Quantitative even sparse stability.** For m=2k, k>=6, either deleting isolates leaves exactly k vertices with both degrees two, or I(G)<=(k-1)(k-3). Thus being within fewer than k-3 pairs of the eventual optimum forces the regular support shape. It does not imply that this shape is universally winning. The k=5 extension uses the existing finite ten-arrow result. Source: paper/sparse-stability.md, Theorem 56.

21. **Quantitative odd support reduction and equality.** For m=2k+1, k>=3, I(G)>k^2-4k+6 implies either an induced k-vertex graph with at least the same score, or a nonisolated support of k+1 vertices in three specified degree families. The induced core has 2k regular arrows or 2k+1 arrows with one outdegree-three and one indegree-three exception. The larger support has distinct outdegree-one and indegree-one exceptions, with their connecting arrow absent or present, or one common degree-one exception. For k>=5, equality in I<=k(k-3)+2 requires the distinct exceptions with their connecting arrow absent and all eligible missing pairs winning. The old connectivity and reachability consequences of winning those pairs remain valid. Source: paper/sparse-stability.md, Theorem 57 and Corollary 57.1; paper/odd-endpoint-resume.md.

22. **Commuting permutations cannot produce large sparse extremizers.** If the two outgoing arrows are given by commuting permutations, with no loops or repeated neighbors, I(G)<=n. The bound is sharp at n=7. This rules out the ordinary two-step circulant approach; it does not rule out all algebraic constructions. Source: paper/followup-extrema.md, Proposition 30.

23. **Odd extremizers need not arise by deleting an arrow from a universal regular graph.** A certified 19-vertex, 37-arrow extremizer has I=272; its degree-completing arrow gives I=276 rather than the universal value 304. This is a structural counterexample, not an additional extremal formula. Source: paper/odd-endpoint-resume.md and its cited certificate.

24. **Exact two-move criterion and camping obstructions.** For an indirect pair, let B=N^+(s) intersect N^-(t). It wins within two moves iff B is not contained in {c} union N^+(c) for every c!=s. Source domination kills a source row; domination of the recipient's predecessor set excludes all indirect sources except possibly the dominating pursuer vertex. These are arbitrary-graph statements. Source: paper/main.md, Lemmas 1–3.

25. **Safe branching for longer strategies.** If distinct closed move sets intersect in at most one vertex, a source with two distinct outgoing neighbors that each guarantee the recipient also guarantees it. This supports iterative winning-set propagation and is not subsumed by the two-move criterion. Source: paper/main.md, Lemma 10.

26. **General dense construction criteria and composition.** The complement of an orientation of an undirected graph of girth at least six and minimum directed outdegree at least two has universal two-move delivery. Separately, complementary-block composition preserves existing two-move guarantees when each missing block has positive outgoing degrees. The old catalogue already placed these two structural lemmas in one entry; their arbitrary-graph conclusions remain independent of the specific new modular construction. Sources: paper/dense-extensions.md, Lemma 18; paper/followup-extrema.md, Lemma 28.

27. **Zero is the minimum at every admissible order and budget.** For every (n,m), there is a graph with I(G)=0. This classifies a minimum, whereas the central M problem is a maximum. Source: paper/main.md, Proposition 4.

28. **Exact evaluation of the original layered set-system family.** For positive x not a power of two, set q=2x, a=binomial(2x,x)/2, N=2a+4q. The original balanced construction has I=2a(N-1-q)+4q. At x=3 it gives N=44 and I=764. This evaluates a particular historical construction; it is not an extremal claim. Source: paper/main.md, Theorem 16.

29. **Balanced complementary halves iff criterion.** For positive x, the x-subsets of [2x] split into two coordinate-balanced families with complements in opposite families iff x is not a power of two. This set-system theorem has content independent of the delivery extrema. Source: paper/main.md, Lemma 17.

30. **Verified formal foundations and certificates.** Seven Lean 4.33.1/Std modules verify the game semantics, certificate-to-strategy reasoning, selected obstructions and constructions, and protected two-move delivery under exterior-arrow changes. They do not formalize the full extremal classification, general existence/counting arguments, or all finite enumerations. This is a verification entry, not a thirtieth numerical theorem. Sources: lean/verification.json; README.md.

## A new limitation checked during this audit

The following deduction was independently checked by the root and proposal-check reviewer. It is not yet integrated into the manuscript or Lean.

Let B be a two-in/two-out graph on n>=4 vertices. Suppose E contains B and every intermediate graph B subset G subset E is universal. Then

    |E| <= n floor((n-1)/2).

Fix a pursuer c, and put D_c=V minus ({c} union N_E^+(c)). Form G from B by adding only E's additional arrows out of c. For every s!=c, the row at s is still its two-arrow B row, and s has an indirect recipient because n>=4. Source domination therefore forbids N_B^+(s) from being contained in {c} union N_E^+(c). Thus each of the n-1 such sources has a B-arrow into D_c. Since B has indegree two, n-1<=2|D_c|. Hence d_E^+(c)<=floor((n-1)/2), and summing proves the bound.

In particular, for n>=6 such an arbitrary-subset envelope cannot reach n(n-3) arrows. This does not obstruct existence at each exact budget or a construction using stages, changed bases, or highly unequal routing degrees.

## Precisely localized next targets

- Sparse composition must preserve the actual pursuer state across modules and support enough optional arrows after changes of order. The saved-policy scan admits no new nearby arrow types even when strict rank decrease is dropped; changing ranks alone does not address this obstruction. The unpromoted 32-arrow recovery suggests 967 instead of 1075, not a replacement for the surviving smaller families.
- Quantitative support reductions must apply above the best known lower witness, not merely near the eventual polynomial. At 23 arrows the cutoff 83 exactly matches the witness; at 22 arrows the regular-support cutoff 80 lies well above the known witness 71. That is the concrete reason the same reduction closes one budget and not the other.
- Universal two-move saturation remains open between the known first-budget lower bound and the explicit sufficient budget A. A candidate eventual characterization is all budgets q_2(n) through L-2n, together with the complete graph L. This is a conjectural target, not a proved monotonicity result.
- An 11-vertex, 88-arrow universal two-move graph would fill the missing dense core order. Together with existing arguments it would prove the whole staircase for every n>=20: use cores k>=10, and for k<=9 use r=n-k>=11 and binomial(floor((r-1)/2),2)>=10. Its existence is not established.
- Robust bridges at the four missing odd orders 23,25,27,31 would lower the all-order bridge threshold from 32 to 22. Their failure in the current template does not prove nonexistence.
- A logarithmic-time sparse extremizer would resolve the gap ceil(log_2(n+1))-1 <= T_*(n,2n) <= 9 ceil(n/6)+18 for n>=12. The current bounded-jump rings themselves require linear time. This is a distinct speed question, not a prerequisite for the extremal count paper.

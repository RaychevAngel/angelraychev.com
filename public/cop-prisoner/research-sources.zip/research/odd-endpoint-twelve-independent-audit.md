# Independent audit of the 23-arc nonattainment enumeration

The ordinary reduction and source of `src/odd_endpoint_exhaustive.cpp`
pass independent review. Its completed saved twelve-vertex run excludes
equality in the odd arc bound at 23 arcs. With Theorem 9's equality
classification, this implies `M_E(23)<=89`. It does not by itself
determine the exact value at that budget.

## Complete factorization enumeration

Theorem 9 says any graph attaining the 23-arc bound of 90 has exactly
twelve nonisolated vertices, with different deficient vertices `u,v`,
the arc `u->v` absent, and all the specified degree-two eligible pairs
guaranteed. Add this absent arc. The resulting two-in/two-out regular
graph decomposes into two arc-disjoint permutation factors by
alternating the edges of its degree-two bipartite incidence cycles.
Choose the factor containing the added arc as `A`.

Relabel `u=0,v=1`. The distinguished cycle of `A` through `0->1` can
be written in cyclic order on the first `ell` labels. Every other cycle
has length at least two, because the graph is loopless, and their
lengths can be listed in nondecreasing order. Thus the code's choices
of distinguished length `2..12` and partitions of the remaining order
into parts at least two include a representative of every possible
factor `A`. The distinguished cycle must be enumerated separately;
an ordinary undistinguished partition would not suffice. The source
does make that distinction.

The second factor `B` is enumerated as every permutation avoiding its
own diagonal and all `A` arcs. These are exactly the simplicity and
arc-disjointness conditions. Deleting only `A[0]=1` reconstructs a
graph of the required deficient degree type, with `0->1` still absent.
No supplementary symmetry assumptions restrict the second factor.

## Safe partial obstructions

The current `out` array includes all retained `A` arcs and all assigned
`B` arcs. The `pred` array is their exact transpose. A source row is
complete exactly when its `B` row has been assigned. A target column
is complete exactly when its `B` predecessor has been assigned, as
tracked by `binv`.

The source-camping test is used only on complete source rows. It
explicitly excludes the deficient source and requires at least one
missing eligible recipient other than the deficient target. If a cop's
current closed outgoing set covers the complete source row, that
coverage persists when unassigned cop arcs are added. The cop row
therefore need not itself be complete for this rejection to be valid.

The target-camping test is used only on complete predecessor columns.
It excludes the deficient target and requires an eligible missing
source distinct from the deficient source, the target and the chosen
cop. Such a source really remains missing because the predecessor
column is already complete. Coverage by the cop's current closed row
again persists. These role exclusions prevent an obstruction affecting
only an uncounted deficient row or column from rejecting a candidate.

After a new `B` arc is assigned, the routine checks the newly completed
source against every cop, all previously completed sources against the
new cop row, the newly completed target against every cop, and all
previously completed targets against the new cop row. All tests are
necessary conditions; none is treated as sufficient for delivery.
Incomplete other rows can only make detection weaker, which is safe.

## Terminal evaluation and evidence

The surviving complete graphs are tested by the finite least-attractor
iteration for all recipients except vertex 1 and all sources except
vertex 0. Waiting, target receipt priority, nonterminal collision and
every legal initial cop are represented as in the established game
solver. Infinite nonreceipt does not enter the least attractor.

The receipt `research/odd-endpoint-n12-exhaustive.json` reports
`complete=true`, `attainment_found=false`, 42 distinguished-cycle
partitions, 164,276,910 recursion nodes and 16,902,091 leaves after
local pruning. Its full run took 41.45 seconds. This auditor reviewed
the reduction, pruning and terminal routine against that completed
receipt; it did not claim a second complete twelve-vertex enumeration.
The producing task also supplied a thirteen-vertex positive control
passing every prefix and the actual game test.

The conclusion is finite computer-assisted nonattainment, with its
ordinary coverage proof and explicit exhaustive source. It is not a
new Lean theorem, and the precise maximum at 23 arcs remains separate
from the fact that the value 90 is impossible.

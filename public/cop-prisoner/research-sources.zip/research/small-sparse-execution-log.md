# Sparse small-case execution log

13 September 2026. Scope: small sparse upper bounds and the constructions
needed to tighten them. Canonical publication sources are owned by root.

1. Derived the leaf-aware integer support reduction. Independent agent replay
   agrees: I>30 at m18 implies support<=15 (67 active profiles); I>50 at m20
   implies support<=13 (22 active profiles). Proof/replay paths are in
   `small-sparse-support-proof.md` and `small-sparse-support-checks.json`.
2. Full regular ten-vertex threshold check found a 53-guarantee witness at
   twenty arrows, improving the prior lower 50. Both Python solvers and the
   complete alternating certificate replay it. The independent regular-
   family audit accepts the upper 53 in that family, with source/canonical
   coverage review but not a second full independent enumeration.
3. Full regular and directional transfer checks at orders7..9 were cheap.
   They rediscovered lower10 at (7,14), lower19 at (8,16), and regular30 at
   (9,18). Another agent already had the first two; these are duplicate
   checks, not separate novel results. Both transfer families at9 exclude
   scores above30. At10 they exclude scores above53; their largest evaluated
   counts are50 incoming and37 outgoing. Low-threshold pruned counts are not
   asserted exact maxima of a family when the threshold itself is higher.
4. Deleting each vertex from the fixed universal12-vertex sparse seed failed
   to improve the20-arrow example: the twelve resulting counts were17..27.
   Saved in `small-sparse-delete12.json`; this is a failure of one template.
5. Narrowed a hypothetical I58 at m20 to one maximum-degree-two family on11
   vertices with two low-in and two disjoint low-out exceptions. The first
   complete-matching/path-factor pilot hit20 seconds after81.8 million nodes;
   incomplete, no upper claim. Adding optimistic guarded-path pruning reached
   twelve factor types in20 seconds, still incomplete. A valid centralizer
   reduction on the first matching then completed all44 types in9.67 seconds.
   This excludes equality58 in that family, pending independent audit. The
   ordinary full reduction is `small-sparse-twenty-upper.md`.
6. Root's independent outside-leaf observation agrees with the proof: the
   sole support13 tuple at threshold54 is an isolated9-core plus outside
   source-to-sink edges. At z3, one case instead leaves a19-arrow component,
   so the correct inherited bound is55, not an unjustified53. Keep that
   distinction when attempting the next upper improvement.

Current proposed new bound after finite/reduction review: 53<=M_E(20)<=57.
Exact20-arrow optimality remains open. The next target is a loss-aware version
of the small outside-profile argument, not another unrestricted graph search.

## Completed next checkpoint

7. The whole implication `M_E(20)<=57` passed the independent audit in
   `small-plateau-double-defect-review.md/.json`, including the eleven integer
   tuples, 44 first-factor types, 2,802 degree patterns, centralizer coverage,
   and ordinary core restrictions. The bound has been passed to root for
   canonical integration; no exact twenty-arrow value is claimed.
8. Redirected to `(n,m)=(11,23)`. A score above78 forces all indegrees and
   outdegrees at least two, hence one excess outgoing and one excess incoming
   arrow. Hall matching normalization covers fourteen cycle partitions and
   330 excess patterns. Initial whole-range pilots at25,30,45 seconds remained
   incomplete; none supplied an upper bound. Incremental permanent losing-pair
   pruning, optimistic guarded-path bounds, and an exact remaining-column
   decision rule made two fixed disjoint ranges complete in38.38 and32.49
   seconds. Total:121,790,823 nodes and1,152,430 game decisions, all rejecting
   score above78. The matching78 witness was replayed by both Python solvers
   and all2,662 alternating rank states. This proves `M(11,23)=78` with the
   ordinary reduction and finite boundary in `small-sparse-eleven23-proof.md`
   and source/output hashes in `small-sparse-eleven23-checkpoint.json`.
   The later independent audit `small-plateau-one-excess-review.md/.json`
   accepts the entire implication and source semantics; it does not claim a
   second full121-million-node enumeration.
9. Found a stronger simple necessary condition for a nonzero row: its source
   has at least two nonsink outgoing neighbors. Separately, a nonzero column
   has at least two predecessors of positive indegree. If S is total sink
   indegree and T total outdegree of indegree-zero vertices, this gives
   `2R<=m-S` and `2C<=m-T`. Substituting the minimum active degree surpluses
   alone did not remove additional twenty-arrow integer profiles; the useful
   step was keeping the actual surpluses and the fact that all nine active
   rows/columns must be nonzero above53.
10. Used these conditions to classify all fifteen support-twelve tuples and
    the sole support-thirteen tuple at twenty arrows and score above53.
    The only possible surviving twelve-vertex form is a ten-vertex,
    nineteen-arrow graph disjoint from one directed arrow. Angel's earlier
    harmless-sink attachment replaces that separate arrow by one new vertex,
    preserving the score on eleven vertices. Proposed consequence:
    `M(n,20)=M(11,20)` for all n>=11. This is a comparison-host theorem, not
    an actual-support bound. The complete proof, arithmetic inventory and
    4,357 checks of the elementary live-degree lemma are in
    `small-sparse-twenty-host-compression.md/.json` and
    `src/small_sparse_host_compression.py`. It is frozen for independent
    review; the canonical B20=12 must remain until that review passes.

Stopped new searches at root's requested freeze. The remaining work in this
lane is independent review of item10 and, in a later authorized research
pass, excluding or finding scores54..57 in the remaining ten-/eleven-vertex
twenty-arrow classes. Neither the existing equality58-only double-defect
check nor a support comparison alone settles those scores.

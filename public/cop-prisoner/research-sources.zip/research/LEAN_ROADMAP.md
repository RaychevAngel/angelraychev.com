# Roadmap to the full Lean classification

Checkpoint: 23 October 2026. The source-pinned `lean/verification.json` identifies
which snapshot has passed the complete replay. `lean/README.md` gives the exact
formal theorem domains. The ordinary value-and-explicit-construction
classification is complete; its full formal verification remains unfinished.

## What is now proved

The actual-game semantics, unrestricted vertex bound and dense zero band remain
proved. New unconditional theorems establish the complete dense range from
order twenty, the adjacent band from order sixteen, the functional endpoint at
every order, sparse even/odd budget upper bounds, isolate and sink padding,
and the exact twenty-four-arrow maximum at every host order from twelve.
Five-offset circles have concrete modular proofs, exact counts, prescribed
parameters and every intermediate budget in their stated range. Other protected
and guarded constructions retain their explicit parameter domains.

The difficult finite pilot now excludes equality in the vertex bound on all
nine-vertex graphs: the score is at most 53. Its degree rigidity, matching
factorization, canonical cycles and eight complete exclusion trees are proved.
A separate normalized exclusion and explicit attainer prove maximum 30 in
the Hamiltonian-first-factor family. The other seven cycle types, the full
two-regular bound 30 and the complete finite tables remain unfinished. Signed certificates also establish exact scores 30, 50, 79 for the saved
nine-, ten- and eleven-vertex witnesses, without asserting their extremality.

All these statements concern actual graphs and actual alternating play.
Generic local-arena projection now distinguishes safe transfer after a cop
reply from terminal delivery. The concrete cyclic geometry and complete local
certificate family still require instantiation.

## Remaining work in dependency order

1. **Finish the sparse attaining construction.** Instantiate the six-type
cyclic graph, its local window projection (including an outside cop state),
canonical hole patterns and saved rank certificates. Compose safe transfers
and final delivery, then prove the exact order and arrow count. A bounded
empty-hole pilot is not the complete theorem. Canonical holes may reduce the
required catalogue; that reduction needs its own coverage proof. Import the
finite bridge and the odd-budget attainers with equally explicit provenance.
The uniform sparse upper bounds are already proved, so these attainers will
immediately yield new exact maxima through the padding lemmas.

2. **Complete the main-interval construction chain.** Protected-circle parameter selection and greedy growth are now proved.
Instantiate the separated pair codes and
required hub attachments; replay the bounded stages and prove their coverage.
Preserve exact budgets, every claimed optional subset and the actual strategy
semantics. Existing circle and dense families cover substantial ranges but do
not yet overlap across the entire interval from order twelve. Prefer the
shortest sufficient family chain; alternative constructions are separate
formalization targets when they are unnecessary to the classification.

3. **Prove the sharp finite upper exclusions.** Extend the complete nine-vertex
pilot to score thresholds and all remaining finite families used by the paper.
Optimistic partial-game losing regions, cached loss unions and rotation
normalization now have proved soundness interfaces. Every concrete exclusion
still needs a complete tree and successful kernel replay. Check all degree
reductions, symmetry coverage and pruning branches; replaying surviving graph
leaves alone is insufficient. The strict bound 53 and exact lower witness 30
must never be combined into an equality.

4. **Close small dense orders and assemble the finite tables.** The uniform
formal dense threshold is twenty; the ordinary theorem has sharp threshold
eleven. Import the lower-order constructors and their matching exclusions,
including the exceptional smaller cells. Maintain a dependency map from each
table entry to a proved upper bound and a counted attaining graph.

5. **Assemble the quantified classification.** Define the full piecewise value
and explicit constructor, including every finite exception, and prove
`forall n >= 1, forall m <= n*(n-1), IsMaximum n m (formula n m)`.
The constructor must use prescribed adjacency/composition or listed finite
recipes; fresh graph search is not the explicit-construction objective.
Discharge every interval overlap, parameter, count and coverage premise.
Then replay the complete source snapshot and align every public claim with
that theorem. Module counts and external audit-cell counts are not percentages
of formal completeness.

## Verification lessons and resource discipline

Kernel reduction of nested literal functions can be much faster than indexed
arrays containing the same ranks. A small sparse witness replay fell from more
than two minutes without completion to a few seconds after changing only its
data representation. Exhaustive upper trees benefit from proved symmetry and
cached losing masks, but large proof terms must be split into bounded modules.
The full checker rebuilds all distributed modules sequentially with two workers,
checks allowed axioms and rejects source changes during replay. Untrusted
producers are not required by a reader replaying the literal Lean sources.

Slimming is useful when it removes a formal dependency, reduces a finite
catalogue with proved coverage, or makes kernel checking practical. The parked
delivery-time optimization programme is not reopened by this work.

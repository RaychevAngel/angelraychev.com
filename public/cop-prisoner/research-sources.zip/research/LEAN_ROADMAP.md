# Roadmap to the full Lean classification

Checkpoint: 23 October 2026. The ordinary value-and-explicit-construction
classification is complete. Full Lean verification is unfinished. The accepted
source snapshot is identified by `lean/verification.json`; exact theorem
domains are in `lean/README.md`. This roadmap separates remaining construction
proofs from universal exclusions and final assembly.

## Completed formal domains

Actual-game semantics and the general counting bounds are proved. The full
dense range starts at its sharp order 11, with explicit counted attainers.
The adjacent band from order 16 retains its stronger two-move,
arbitrary-optional-subset guarantee. The functional endpoint and zero band
hold at every admissible order.

The main interval is complete in Lean at every order at least 115, at orders
12..18, and at 65,70,75,80,85,90,95,100,105,110. Its upper part
`3n≤m≤n(n−3)` is complete from order 25, with additional smaller intervals
listed below. Every local certificate, actual cop reply, geometric projection,
safe transfer, terminal delivery and optional-prefix budget is supplied.
The stronger `LowBandPrefix.top n` endpoint and individual circle/hub
construction domains are retained.

Uniform sparse attainers are formalized for even budgets on support at least
85 and odd budgets on support at least 98, with padding to every larger host.
The finite even supports 12..18,50,55,65,70,75,80 and odd supports
13..18,88,89,90,94,95,96 are also covered. These are prescribed graphs or
retained listed graphs, not existence assertions or generic graph search.

Unrestricted sharp upper bounds at budgets 0..10 and their stated attaining
host domains are proved. Every admissible budget at every host order at most
5 is classified. Retained graphs give all exact lower-witness scores for
budgets 11..23, but their matching unrestricted upper bounds remain unfinished.
The nine-vertex bound 53 covers all graphs. The sharper regular-nine maximum
30 covers all two-in/two-out graphs, including every first-factor cycle type;
it does not establish the unrestricted eighteen-arrow value 33.

The fourteen-arrow benchmark proves score at most 13 when the nonisolated
support has at least nine vertices and every supported vertex has positive
incoming and outgoing degree. Arbitrary isolates are permitted. The proof
covers eleven normalized nine-vertex joint profiles and 160,718 DAG nodes,
then combines the ten-vertex proof and larger-support counting. It does not
cover smaller supports or graphs with sources/sinks.

## Exact remaining construction domains

1. **Main interval.** Budgets 38..94,40..99,42..125,44..109,46..114,48..119
   at orders 19,20,21,22,23,24, respectively; 111..149 at order 50;
   122..164 at order 55; and `2n≤m<3n` at all other orders 25..114 except
   65,70,75,80,85,90,95,100,105,110. Existing ordinary envelope/stage
   certificates supply these graphs; their exact counts, state coverage and
   actual-play interpretation still need complete Lean instantiation.
2. **Even sparse bridge.** Supports 19..84 except 50,55,65,70,75,80:
   sixty support orders. Reuse each completed main endpoint before exporting
   an independent full-graph certificate.
3. **Odd sparse bridge.** Supports 19..97 except 88,89,90,94,95,96:
   seventy-three support orders. Retained signed-rank graphs exist. For each
   graph, verify its exact budget and degree defect, every needed winning
   state and every pursuer reply; the proved parity bound then gives equality.
   The same support proof covers every larger host through isolate padding.

These are finite support/order bridges, but the unclosed sparse statements
range over infinitely many larger hosts. They are formalization gaps, not
unknown numerical values or missing ordinary constructions.

## Exact remaining upper-bound and assembly obligations

4. **Sharp unrestricted budgets 11..23.** Proceed in budget order, using
   actual source/sink deletion and positive-support counting first. The
   positive fourteen-arrow result is one component. Smaller supports and
   degree-zero cases must be joined before claiming an unrestricted maximum.
   Verifying a surviving graph's winning/losing ranks is not enough: every
   normalized degree profile and every permitted row choice must be covered.
5. **Joint tables at orders 6..11.** Global budget bounds and completed dense
   results settle many entries, but the remaining host-specific exclusions
   require their own reductions and certificates. Preserve the original
   finite upper arguments; do not replace them with an attaining-graph test.
6. **Final quantified theorem and constructor.** Assemble one explicit
   piecewise graph and one maximum theorem for every admissible `(n,m)`.
   Prove exact budgets, all overlaps and every finite exception. This theorem
   is not presently available.

## Fastest sound next pass

The next construction pass should reuse the main endpoint proofs and the
proved envelope symmetries before exporting duplicate recipient certificates.
The five-type charts demonstrate the gain: at orders 65,70,75, symmetry
reduced 210 saved recipient objectives to 15 representatives while still
covering every optional graph and every cop reply. Local-window proofs are
preferable when their complete geometry is already available; retained
full-graph ranks remain valid for genuine finite exceptions.

For the odd finite bridge, a source-reviewed export contract is recorded in
`research/lean-continuation-2026-10-23.md`. Keep only the winning region needed
by the lower-bound proof, preserving all necessary intermediate states.
Select each legal move with strict alternating-rank descent and verify every
reply. Group states sharing their move and rank behind proved mask semantics.
Sampled reductions establish the potential compression, not the full bridge.
Batch several recipient objectives per module to avoid repeated compiler
startup. No new graph discovery is needed.

The upper-bound work is the main uncertainty. Use source/sink deletion to
remove branches mathematically before asking Lean to replay profile trees.
The completed five-vertex classification tests this reduction end to end.
The irregular nine-vertex benchmark tests a substantially harder complete
family. Their real replay costs are more informative than raw graph counts;
they do not imply that every remaining exclusion will cost the same.
Continue with a complete unrestricted budget before scaling to the largest
host-specific tables. One concrete preprocessing improvement is worth testing:
the ten-arrow common row-cover proof took 69 seconds despite only 39 DAG
nodes. Prove coverage generically for degree-filtered lists of all masks,
then check equality with each literal bucket once. This could replace repeated
linear membership searches with one list comparison per bucket. It is a
future optimization proposal, not an accepted speed result or a change to the
current frozen proofs. The corner-witness optimization is reusable only where
its proved hypotheses apply, never as an unchecked pruning rule.

## Verification and release discipline

Grouped states and shared mask identities remove repeated computation without
removing initial states or legal replies. The low-band pilot reduced kernel
CPU cost by roughly sixfold; shared odd-family masks reduced representative
checks from 22–26 seconds to about 2 seconds. Negative tests and independent
source review accompany these checker changes. Pure comment preprocessing is
memoized by immutable source content only; all source, import and object pins
are still checked.

The coordinator reuses only actual successful compiler invocations with
identical source, transitive dependencies, compiler and object hashes. Final
acceptance covers every distributed source plus the axiom audit. The public
`lean/check.py` retains a fresh sequential replay. Producers are untrusted and
unnecessary for replaying literal sources. Native proofs, custom axioms and
proof holes are not accepted.

Keep the arXiv package ready with exact partial-Lean language. Preserve every
ordinary result, stronger construction guarantee and source credit. The
parked delivery-time optimization programme is not reopened. The planning
estimate is about 80 percent complete, with a broad 70–85 percent uncertainty
range; it estimates remaining proof work, not files, finite ledger cells,
CPU time or the fraction of parameter pairs covered.

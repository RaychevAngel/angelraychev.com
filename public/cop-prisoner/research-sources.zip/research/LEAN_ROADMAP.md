# Roadmap to the full Lean classification

Checkpoint: 23 October 2026. The source-pinned `lean/verification.json` identifies
which snapshot has passed the complete replay. `lean/README.md` gives the exact
formal theorem domains. The ordinary value-and-explicit-construction
classification is complete; its full formal verification remains unfinished.


## What is now proved

The actual-game semantics, unrestricted vertex bound and dense zero band remain
proved. New unconditional theorems establish the complete dense range from
order twenty, the adjacent band from order sixteen, the functional endpoint at
every order, sparse even/odd budget upper bounds, isolate and sink padding,
and the exact twenty-four-arrow maximum at every host order from twelve.
`SixTypeConstruction.maximum_even` supplies explicit attaining graphs at every
support order `s≥85`, proving `M(n,2s)=s(s−3)` for every host `n≥s`. All 81
canonical local patterns, 552 rank objectives, actual geometric projections,
safe-transfer composition and exact vertex/arrow counts are instantiated.
`PairCodeOverlap.maximum` proves the full range `3n≤m≤n(n−3)` for every
`n≥79`, using explicit pair-code and circle recipes with proved arithmetic
overlap and exact optional-prefix budgets. `MainTwelve.maximum` supplies the
complete twelve-vertex main interval: `M(12,m)=132−m` for `24≤m≤108`.
Thirty literal asymmetric stages cover 24..107, including every optional
subset and every upper-envelope cop reply; the pair-code endpoint supplies
108. Actual adjacency counts and exact prefix budgets are proved.
Five-offset circles have concrete modular proofs, exact counts, prescribed
parameters and every intermediate budget in their stated range. Other protected
and guarded constructions retain their explicit parameter domains.

The difficult finite pilot now excludes equality in the vertex bound on all
nine-vertex graphs: the score is at most 53. Its degree rigidity, matching
factorization, canonical cycles and eight complete exclusion trees are proved.
A separate normalized exclusion and explicit attainer prove maximum 30 in
the Hamiltonian-first-factor family. The other seven cycle types, the full
two-regular bound 30 and the complete finite tables remain unfinished. Signed certificates also establish exact scores 30, 50, 79 for the saved
nine-, ten- and eleven-vertex witnesses, without asserting their extremality.

`IrregularTen14.positive_upper` proves score at most 13 for every loopless
ten-vertex graph with fourteen arrows and positive in-degree and out-degree
at every vertex. Joint-profile rigidity and relabeling reduce every possible
counterexample to the prescribed profile. A reusable row-prefix checker then
proves complete coverage, explicit symmetry, sound pruning and losing-region
bounds. This is one essential family, not the unrestricted fourteen-arrow
maximum or the complete finite table.

All these statements concern actual graphs and actual alternating play.
Local-arena projection distinguishes safe transfer after a cop reply from
terminal delivery; the uniform six-type theorem now supplies all its concrete
geometry and certificate premises.

## Remaining work in dependency order

1. **Close the sparse finite bridge and odd attaining family.** The complete
uniform even construction from support 85 is now supplied. Replay the finite
even bridge at supports 13..84; support twelve is already covered. Formalize
the odd periodic geometry, complete local certificates and exact counts, then
its required finite bridge at supports 13..97. The ordinary odd construction
starts at support 98; the retained archive through 144 is larger than the
necessary bridge. Preserve its evidence and stronger guarantees. The general
parity upper bounds and exact padding lemmas are already available.

2. **Close the remaining main-interval gaps.** Pair codes and the circle
parameter overlap already establish every `3n≤m≤n(n−3)` for `n≥79`.
Formalize the uniform low band `2n<m<3n` for `n≥115`, its separate finite
bridge at orders 13..114, and the upper finite bridge at orders 13..78.
The complete main interval at order twelve is already supplied.
Replay complete stage inventories with exact budgets and every claimed
optional subset, including cop replies through optional arrows. Prefer the
shortest sufficient family chain; alternative constructions remain separate
when they are unnecessary to the classification.

3. **Prove the sharp finite upper exclusions.** Extend the complete nine-vertex
pilot to score thresholds and all remaining finite families used by the paper.
Optimistic partial-game losing regions, cached loss unions and rotation
normalization now have proved soundness interfaces. Every remaining concrete exclusion
needs a complete tree and successful kernel replay. The positive
ten-vertex/fourteen-arrow family now supplies the first complete irregular
benchmark, including its profile reduction; extend its row-prefix checker at
the sharp thresholds required for the remaining exact tables. Do not generate
duplicate weaker certificate families merely to claim an earlier milestone.
Check all degree reductions, symmetry coverage and pruning branches; replaying
surviving graph leaves alone is insufficient. The strict bound 53 and exact
lower witness 30 must never be combined into an equality.

4. **Close small dense orders and assemble the finite tables.** The uniform
formal dense threshold is twenty; the ordinary theorem has sharp threshold
eleven. Import the lower-order constructors and their matching exclusions,
including the exceptional smaller cells. Maintain a dependency map from each
table entry to a proved upper bound and a counted attaining graph.

5. **Assemble the quantified classification.** Define the full piecewise value
and explicit constructor, including every finite exception, and prove
`forall n >= 1, forall m <= n*(n-1), IsMaximum n m (formula n m)`.
The constructor must use prescribed adjacency/composition or listed finite
recipes; fresh graph search is not the explicit-construction objective.
Discharge every interval overlap, parameter, count and coverage premise.
Then replay the complete source snapshot and align every public claim with
that theorem. Module counts and external audit-cell counts are not percentages
of formal completeness.

## Concrete next-step assessments

For the uniform low band, reuse the proved six-type base graph, smoothing,
retained-vertex enumeration, base2n count, local-game semantics and exact-budget
prefix theorem. The remaining geometry is an asymmetric optional-edge envelope
with a wider66/103 arena,101 canonical crops and696 local objectives. The saved
two-turn ranks can be collapsed into the existing round checker; no separate
cop-rank formalism is needed. Actual optional cop arrows need inclusion in the
cropped arena, not equality with its possibly stronger reply relation. Nine
forbidden optional candidates per canonical hole give the required capacity.
This is a read-only route assessment, not a completed new theorem.

The smaller-order main bridge can avoid the general fourteen-hub construction:
only five cells at n19,m279..283 require it, and one fixed277..285 envelope
suffices. The shortest assessed geometric chain uses two twelve-hub interfaces,
19 saved six-circle parameter rows and actual protected-envelope counts at25..35,
plus the finite stages and sparse records. The stage inventory has588 records
and40,519,351 rank rows before redundancy removal. These are retained external
certificates, not already completed kernel proofs. Benchmark a larger record
and share source-rank structure before expanding the entire catalogue.

For finite exclusions, the next manageable sharp block is positive support9
at budget14. A direct3+3+5 degree-placement derivation yields its eleven joint
profiles. Combined with the current positive10/14 theorem and support counting,
this would cover positive supports of order at least9. The unrestricted14-arrow
maximum additionally needs smaller-budget sharp inputs and source/sink cases;
the retained eight-vertex traversal alone has62,252,531 nodes and1,243,868
leaf games. Those ordinary counts are not Lean timing estimates or existing
literal proof trees. Generalize the row-prefix producer and measure complete
profile certificates before committing to a full bulk replay.

## Verification lessons and resource discipline

Kernel reduction of nested literal functions can be much faster than indexed
arrays containing the same ranks. A small sparse witness replay fell from more
than two minutes without completion to a few seconds after changing only its
data representation. Exhaustive upper trees benefit from proved symmetry and
cached losing masks, but large proof terms must be split into bounded modules.
The full checker rebuilds all distributed modules sequentially with two workers,
checks allowed axioms and rejects source changes during replay. The campaign's
separate staged coordinator uses bounded parallel jobs and reuses only current
campaign compilations with identical source, transitive-dependency, compiler
and object pins. Final acceptance still covers the complete distributed graph;
`check.py` retains its public sequential default. Untrusted producers are not
required by a reader replaying the literal Lean sources.

Slimming is useful when it removes a formal dependency, reduces a finite
catalogue with proved coverage, or makes kernel checking practical. The parked
delivery-time optimization programme is not reopened by this work.

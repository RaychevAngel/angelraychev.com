# Finite lower-construction completion pass

13 September 2026. These files are a separate research checkpoint. No accepted
classification registry, manuscript, coverage report, or handoff was edited.

The first bounded pass made 616,051 exact game evaluations in 180.12 seconds.
It first enumerated every fresh-sink predecessor subset of the saved 7/21 and
9/18 cores, then made two finite adjacent-budget sweeps, then spent one fixed
time slice per cell. The random part had a fixed total budget and was not
restarted indefinitely. Failed discovery is not an upper bound.

## Certified numerical consequences

Literal graphs attain the general missing-pair upper bound in these ten
formerly unresolved cells:

- `n=8,m=27..34`: scores `29,28,27,26,25,24,23,22`.
- `n=10,m=26..27`: scores `64,63`.

Their literal arrows and full winning/losing alternating-state certificates
are in `finish_constructions_certificates.json`. The original independent
literal reviewer, which imports neither constructor nor game solver, replayed
them in a separate invocation; its source-pinned receipt is
`finish_constructions_independent_review.json`.

Other current lower witnesses in that same file are:

| Order | Budgets | Literal scores |
|---|---|---|
|8|17..23|19,21,22,24,25,28,29|
|8|35..39|19,18,16,15,14|
|9|19..23|35,36,39,40,44|
|10|19..25|35,53,56,55,56,60,60|

These are graph scores, not assertions that the remaining extrema equal the
listed values. The 19-arrow score35 is attained on nine vertices. The21-arrow
score56 is attained on ten vertices. Those smaller/stronger witnesses may
improve comparison-support arithmetic after separate review.

## Selected-pair stage certificate

For fixed arrows `B` and cop envelope `E`, where `B` is contained in `E`, let
`P` be the nonloop pairs absent from `B` which win against every initial cop
position other than their source, when messenger moves use `B` and cop moves
use `E`. For every intermediate graph these pairs remain guaranteed. However,
an installed optional arrow can make one of them direct and remove it from
the indirect score.

Put `F=E-B`. The literal recipe installs `F-P` first, followed by `F intersect P`,
with lexicographic order inside each part. At budget `m=|B|+k`, its certified
score is at least

    |P| - max(0, k-|F-P|).

The proof is the inclusion of available messenger moves and cop replies,
followed by the exact count of protected pairs made direct. All cop positions
are retained. Only actual recipient arrival is terminal. Ranks strictly
decrease through both alternating turns; the certificates also check the
closed losing region of the asymmetric game.

`finish_constructions_stages.json` contains eight stages. The strongest are
optimal intervals `8:27..29`, `8:30..32`, and `10:26..27`. The selected-pair
stage `8:34..36` gives lower values `20,19,18`; its first value need not equal
the larger fixed-graph score22 at34. The further stages are overlapping lower
recipes, not additional extrema claims.

The separate reviewer `src/finish_constructions_stage_review.py` imports no
game solver or producer. It reconstructs every legal state transition from
the literal base/envelope, verifies all winning and losing ranks, reconstructs
the protected pair set, and checks the recipe/counting formula. Its receipt
is `finish_constructions_stage_independent_review.json`.

## Hand-derived fresh-sink lifts

The initial observations were generated and fully replayed before discovery:

- Add a sink to the universal7/21 graph and arrows into it from six old
  vertices, excluding a source `s` with a guaranteed missing old recipient.
  The resulting8/27 graph has exactly22 indirect pairs.
- Add all seven old-to-sink arrows instead. The8/28 graph has exactly21.
- Add a fresh sink and one arrow to the saved9/18 score30 graph. The resulting
  10/19 graph has exactly30.

These graphs and their complete ranks are retained in
`finish_constructions_simple_sink_lifts.json`; they are dominated by the
better literals above and are not used as the strongest lower witnesses.

For the six-arrow claim, fix an old initial cop `c != s`. If every genuine
successor of `s` lies in the cop's closed outneighborhood, the cop waits until
the messenger first leaves `s`, then captures that move. A missing recipient
cannot be reached on the first move. Thus an old guaranteed missing pair in
row `s` forces a successor outside that closed outneighborhood. Move there,
then to the new sink. A cop moving to the sink cannot prevent receipt, and a
cop initially at the sink is trapped. Every old guaranteed pair survives
because the old strategy remains available; after the cop exits to the sink,
the messenger can follow any old path to its old recipient. The new sink
cannot deliver to an old vertex. These facts count all new missing pairs and
give the claimed exact graph score.

More generally a sink predecessor set `D` gives a two-move guarantee from
an excluded source `s` if `D` meets `N+(s)-C(c)` for every old `c != s`.
The finite sink-family pass evaluates the actual game as well, including
guarantees that might need more than two moves.

## Additional bounded descendants

`finish_constructions_nineteen_summary.json` records a complete67,384-candidate
collection of saved-core descendants, single-vertex removals, subdivisions,
and subdivisions with one deletion. It took1.66seconds and did not improve
the19-arrow score35 or20-arrow score53. Completeness refers only to each
listed fixed-core family. It is not an exclusion of other graphs or profiles.

Any post-pass improvements are retained separately in
`finish_constructions_propagated_certificates.json` and its summary, so the
earlier reviewed checkpoint remains stable.

The post-pass completed932,725 evaluations in18.03seconds without improving
the checkpoint. All listed fixed-anchor families completed: extensions from
8/32,8/33,8/34 to budgets35..38; deletions from10/26 to21..25,9/24 to19..23,
and8/24 to17..23; and neighboring-budget sweeps before and after those families.
The propagated certificate list is consequently empty. This is a stopping
signal for this particular lower-construction family, not a proof that the
remaining listed lower scores are optimal.

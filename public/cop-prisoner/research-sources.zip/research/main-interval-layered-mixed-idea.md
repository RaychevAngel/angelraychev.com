# Deferred mixed bulk antichains

This ordinary refinement is retained privately because root's newer circles already cover its improved main-value domains. It is excluded from the constructor and manuscript to preserve focus. It has not had independent proof review.

**Mixed-size bulk sets.** Both proofs require only that the bulk guide
sets have at least two elements and form an antichain. If their total
size is \(W\), the compulsory budgets are therefore
\[
154+25g+22b+W\quad\hbox{and}\quad106+22g+19b+W
\]
for the fourteen- and twelve-hub cores, respectively; the optional
count remains \(b(g+b-1)\). This generalization has the same safe-entry
proof because \(A\setminus B\ne\varnothing\) for distinct members of
an antichain. To supply direct parameters rather than leave an unspecified
antichain to be found, choose \(3\le r\le t\le g\). List first all
guide pairs not contained in the first \(t\) guides, then all \(r\)-sets
contained in those \(t\) guides. These sets form an antichain and give
capacity
\[
\binom g2-\binom t2+\binom tr.
\]
Taking the first \(b\) gives
\[
W=2b+(r-2)\max\left(0,b-\left(\binom g2-\binom t2\right)\right).
\]
All lists use lexicographic order within each size. For example, eight
guides with \(t=6,r=3\) give thirteen pairs and twenty triples. At
order 50, the twelve-hub construction with thirty bulk vertices consequently
covers 929 through 2039. This saves thirteen compulsory arrows compared
with assigning every bulk vertex a triple. The mixed construction is
another parameter choice of the same antichain proof, not a search for
each budget.

# Independent seven-vertex upper review

13 September 2026. This is an ordinary source audit plus a complete independent
finite replay, not a Lean proof or an enumeration of all labeled graphs.

The new `src/small_case_n7_independent.cpp` is a copy of the pre-existing
independent enumerator `src/small_arcs_sparse_independent.cpp`, with a
conservative two-dimensional incidence table, witness output, and bounded
fixed-order interface. The historical source is unchanged. Unlike the primary
search it uses descending degrees, suffix normalization within future cells,
and an explicit alternating AND/OR queue for the delivery game.

## Completed results

`src/small_case_n7_independent_run.py` completed all twenty budgets in
`research/small-case-n7-primary.json`. The durable output
`research/small-case-n7-independent.json` pins the copied source, historical
source, runner, and primary input by SHA-256. Every record starts at profile
zero, checked every generated profile, finished without timeout, and found
no graph meeting its target of lower bound plus one.

| Arrows | Independently proved upper |
|---:|---:|
|12|9|
|13|10|
|14|10|
|15|11|
|16|12|
|17|12|
|18|14|
|19|15|
|20|18|
|22|14|
|23|12|
|24|12|
|25|11|
|26|10|
|27|10|
|28|9|
|29|8|
|30|8|
|31|7|
|32|6|

The run visited 193,302,277 nodes in 15.35099232 seconds of reported search
time. It independently reproduced all eighteen completed primary upper
bounds and finished the two primary timeouts. Literal lower graphs for the
newly completed cases are
`research/small-case-n7-neighbor-m22-certificate.json` (14) and
`research/small-case-n7-neighbor-m23-certificate.json` (12). They came from
single and double additions to the known 21-arrow universal graph; their
winning ranks were generated and checked with both existing Python game
solvers. The parent task separately replays these lower certificates. No
monotonicity under arrow addition is assumed.

## Degree and symmetry coverage

Every loopless digraph can be relabeled to have nonincreasing outdegrees.
The profile recursion enumerates each such sequence in the requested arrow
range. An indirect source has at least two outgoing arrows and contributes
at most `n-3` guarantees, so a target `T` requires at least
`ceil(T/(n-3))` such vertices. Descending order places them first. The
remaining degree-sum cuts discard only totals that cannot reach the budget.

Before assigning a row, future vertices with equal prescribed degree and
identical incoming patterns from completed rows can be permuted without
changing that prefix. The code chooses the new neighbors as a suffix of
each contiguous such cell. The initial degree cells are contiguous, and
each suffix choice splits a cell into its zero and one subcells, preserving
contiguity. Inductively every graph therefore has a generated representative.
No permutations of completed vertices are required for this argument.

## Necessary upper bounds

An outdegree-zero or outdegree-one vertex cannot be an indirect source. A
recipient likewise needs indegree at least two. The code additionally marks
a completed source permanently blocked if either:

* it has two outgoing neighbors and one is a prescribed sink, so the cop
  can camp at the other; or
* its outgoing set is contained in the closed outgoing set of a distinct
  completed cop vertex.

Only fixed rows are inspected. Unassigned row masks cannot cause pruning.
The cop may wait until the messenger takes its first nonterminal step; all
indirect recipients are outside the initial outgoing set.

The possible-source count `qcap` and the sum of their `n-1-outdegree`
capacities consequently overestimate the remaining score. For recipients,
current indegree plus the number of unassigned nonself tails is an upper
bound on final indegree. A potentially eligible column contributes at most
`n-1-max(2,current_indegree)`. Its minimum remaining arrow cost is
`max(0,2-current_indegree)`. Taking as many cheapest such columns as the
remaining arrow budget can afford gives a valid upper bound `rcap` on the
number of live columns. This ignores tail restrictions and shared capacity
conflicts, which can only make the bound more permissive.

For actual sets of `q` live rows and `r` live columns, the score is at most

    f(q,r) = qr - max(0,q+r-n) - max(0,2q+2r-m).

The first subtraction counts forced diagonal coincidences. The second
counts forced arrows from the live rows into the live columns: the rows
emit at least `2q` arrows and the columns receive at least `2r`, from only
`m` total arrows. Diagonals and arrows are disjoint because loops are
forbidden. The new table computes the maximum of `f` over **both**
`0<=q<=qcap` and `0<=r<=rcap`, by a two-dimensional prefix maximum.
For a budget range it substitutes the larger endpoint for `m`, only
weakening the bound. All recorded runs use a single exact budget.

At complete graphs, predecessor camping supplies another necessary bound.
If the predecessors of recipient `t` lie in the closed outgoing set of
cop vertex `c`, any indirect pair `(s,t)` with `s!=c` loses. The code keeps
the initial-source exception. It counts all pairs surviving these
necessary conditions and runs the game only if that count reaches `T`.

### Review of the historical shortcut

Both historical enumerators fixed `q=qcap` while maximizing over `r`.
This shortcut is sound for these particular seven-vertex runs, though the
new replay does not depend on it. For fixed `r>=3`, increasing `q` changes
`f` by at least `r-1-2>=0`. A score of at least nine requires at least
three live columns, because each contributes at most four. The only
recorded exclusion targets below nine are at budgets 31 and 32. More
generally, for `m>=2n+4=18`, the direct-arrow penalty vanishes for all
`r<=2,q<=n`, and `f` is nondecreasing in `q` there as well. Thus none of
the completed primary upper bounds is invalidated by this issue.

## Independent game and termination semantics

For each recipient, the independent solver uses two states for each pair
of messenger and cop positions. Recipient states on either turn are
terminal winning states, including a collision there because delivery has
priority. All other collision states stay losing. Reverse adjacency lists
include waiting once, and each outgoing cop move plus waiting is counted
once in the AND-state counter. A winning state after a messenger choice
propagates existentially to its messenger predecessors; a cop state wins
only after every legal reply has become winning. This is the least finite
attractor, so infinite avoidance cannot create a false guarantee. A
nonadjacent pair is counted only if all initial cop positions other than
the source win.

The clock check marks a timed-out run incomplete and unwinds the recursion.
A graph meeting the target likewise stops the decision search but is
explicitly labeled as a counterexample and not complete. Every saved upper
record has `complete:true`, `counterexample_found:false`, and equal total
and checked profile counts. The reported `best_I` describes only games
actually evaluated after pruning; it is not a global maximum by itself.
The complete target exclusion, together with a separately verified lower
witness, is what establishes each exact value.

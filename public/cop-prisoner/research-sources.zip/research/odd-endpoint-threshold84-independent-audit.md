# Independent software audit of the 23-arc cutoff84 exclusion

2026-09-12. The parameterized source
`src/odd_endpoint_near23_threshold.cpp` and all three completed
cutoff84 receipts pass independent review. They exclude I>=84
within the three specified twelve-vertex degree families. This
audit concerns the software exclusion; the separate ordinary
reduction of every putative global I>=84 graph to these families
is being independently reviewed by the construction-audit agent.

## Exact changes from the earlier audited source

The diff against `src/odd_endpoint_near23_exhaustive.cpp` changes
only two explanatory comments, the default cutoff87 to84, and CLI
validation/selection of a cutoff in84..90. The permutation coverage,
partial obstruction tests, graph updates and rollback, leaf game,
and recursive enumeration are unchanged.

The new source fixes n=12 and hence m=23. It accepts only modes0,1,2
and rejects a requested cutoff below84. This restriction matters:
the current camping prunes can discard graphs with I=83 and cannot
prove a cutoff83 exclusion.

The absent exceptional-arc type is obtained by adding0->1 and
decomposing the resulting two-regular bipartite graph into two
permutations. For the present exceptional-arc type one adds a second
copy of0->1; its two copies belong to opposite permutation factors,
so A(0)=B(0)=1, with only one copy retained in the actual graph.
For the common deficient vertex, add a dummy loop at0, place it in
A, and omit it from the actual graph. All other factor cycles are
loopless. The canonical distinguished-cycle and remaining cycle
partitions still cover every graph of the respective types.

## Why the unchanged camping pruning is safe at84

There are90 eligible missing pairs in the absent-arc family and89
in each other family. The unique low-outdegree source is0 and the
unique low-indegree recipient is1, or0 in the common-deficiency
family. These excluded rows/columns cannot contribute indirect
guarantees by the elementary degree-one obstruction.

Every source tested by `source_block` has its complete two-element
outgoing neighborhood. Apart from its two neighbors, itself, and
the excluded low recipient, there are at least12-4=8 eligible
recipients. A distinct initial cop whose closed neighborhood covers
both exits defeats every one of them. Such a rejection leaves
I<=90-8=82.

Every recipient tested by `target_block` has its complete two-element
predecessor set. Excluding those predecessors, the low source, the
recipient itself and the proposed initial cop leaves at least
12-5=7 eligible missing source pairs. Camping at the witness defeats
each. This leaves I<=90-7=83, still strictly below84.

The completion guards in `admissible` are correct: the new source
row is complete after assigning its B edge; previous source rows
are guarded by `assigned`. A newly assigned B predecessor completes
the nonexceptional recipient column, and old columns are guarded by
`binv>=0`. Exceptional rows/columns are explicitly skipped. A cop
row may still be partial because subsequent additions cannot undo
an inclusion already true. No pruning uses an incomplete messenger
row or incomplete ordinary recipient column.

## Leaf calculation and the meaning of the output fields

The leaf game starts from terminal receipt and computes the least
reachability attractor, allowing waiting and excluding nonterminal
collisions. Thus finite delivery is required. Its potential is90 in
mode0 and89 in modes1,2. It subtracts each failed eligible pair.
Direct and diagonal pairs always succeed, so their presence in the
iteration cannot spuriously reduce the potential.

An early exit occurs only when potential minus losses is below84;
that value is an upper bound on the remaining possible final score.
It must not be read as the exact score of that discarded leaf. At
a surviving leaf every eligible pair has been considered, and any
value at least84 is recorded in `best_I_at_least_threshold`.

The inherited `found` flag and output field
`attained_global_upper89` still concern a score at least89, not the
new cutoff84. This is harmless here but affects how receipts must be
read: a negative flag alone would not exclude84..88. The decisive
facts are `complete:true`, `threshold_checked:84`, and
`best_I_at_least_threshold:0`, all of which hold in each receipt.

## Completed receipts

| Family | Partitions | Partial nodes | Obstruction-free leaves | Seconds |
|---|---:|---:|---:|---:|
|Distinct deficient vertices, absent arc|42|164276910|16902091|45.4904|
|Distinct deficient vertices, present arc|42|13448216|1125588|2.5165|
|Common deficient vertex|14|49814092|3558672|8.12328|

The node and leaf counts exactly match the previous cutoff87 runs,
as expected because only the terminal evaluation cutoff changed.
The receipts are `research/odd-endpoint-threshold84-absent.json`,
`research/odd-endpoint-threshold84-present.json`, and
`research/odd-endpoint-threshold84-same.json`. The source SHA256 is
`523b8565bcd75fec0380770298f9b4b2f2271f4eca517c24570f032559c53e2c`.

## Additional bounded independent checks

`src/odd_endpoint_threshold84_independent_test.py` compiles a small
harness around the actual leaf routine, without running enumeration
or pruning. It compares36 fixed-seed examples, twelve of each degree
type, plus the retained83-pair lower witness, against the independent
explicit alternating game and all its winning-rank/losing-closure
checks. All37 exact leaf scores agree; all37 cutoff84 returns agree
with their intended remaining-potential bound. In particular, the
83-pair lower witness is checked directly by the leaf game, not used
as an invalid positive control for the pruned cutoff83 search.

The CLI rejects cutoff83, and the consolidated summary's source and
receipt hashes all matched their actual files. The receipt is
`research/odd-endpoint-threshold84-independent-tests.json`.

These checks are independent source/proof review plus bounded leaf
tests. The three exhaustive enumerations were not rerun by this
auditor and are not a separately implemented enumeration. No new
Lean coverage is claimed.

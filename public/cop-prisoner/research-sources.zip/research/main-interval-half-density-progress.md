# Half-density circle execution, 13 September 2026

Scope: direct constructors and ordinary proofs for the circle family;
the original eight-move proof is now strengthened to five moves. This note
does not update manuscript coverage counts or publication artifacts.

## New ordinary extension: leave a short empty interval

The first idea was to remove the final h+1 offsets, sufficient for every
abstract safe triple of the old proof. Inspecting the actual six safe sets
improved this: their maximum diameter is h-1, so only the last h-1 offsets
need be absent. This gives the envelope cutoff L=n-h under the unchanged
arithmetic assumptions h>=11,h=3mod4,2h+2<=n,gcd(h,n)=1.

If a translated safe set wraps around, its extreme representatives differ
by at least n-h+1, larger than the occupied interval [0,n-h]. Hence it
cannot be covered. Nonwrapping translates obey the original integer
modulo-four argument. The original seed and propagation are unchanged.
An independent agent reviewed this precise lift/gap argument and found
no gap; independent executable checks are owned by that reviewer.

This is an ordinary all-parameter proof, not an extrapolation from checks.
The direct constructor tries only the explicit arithmetic h parameters;
it never searches graph space. The recipe chooses optional arrows by
lexicographic endpoint order and preserves arbitrary-subset robustness.

## Remaining investigations

The gap construction loses O(h) allowed offsets. It does not prove a
half-density endpoint at arbitrary odd orders. Better endings might recover
some of these offsets. The eight compulsory offsets might also admit a
different, shorter propagation certificate after deleting some moves;
finite successes alone would not establish that parameterized claim.

The old three-protected-difference packing ceiling remains valid for its
old template and is not contradicted by the new three-way proof.

## Five compulsory moves and a four-step propagation

A bounded experiment deleted each of the eight compulsory moves at ten
representative full-circle orders. Five deletions still gave complete
universal-source closure; three stalled. The stall only concerns the
restricted closure argument, not a proof of losing in the full game.
At n=100 a further subset check found two successful five-offset subsets.
One of these has the parameterized form

    C={1,h-3,h-2,h,h+2}.

The resulting proof is shorter, not just a finite certificate. The pattern
P(z)={z-2,z-1,z,z+2} propagates by -h in four steps. Its initial copy
P(-h) requires only one application of the safe pair(h,1); the other three
vertices are direct predecessors. Only the protected pair(h,1) remains,
so the previously deleted offset2h-5 can be restored. The exact domain is

    h>=7, h=3mod4, gcd(h,n)=1, 2h+2<=n;
    5n <= m <= n(|A|-1).

The full modulo-four envelope has |A|=n/2, supplying every
5n<=m<=n(n/2-1) for all n>=16 divisible byfour. The gapped envelope works
at every admissible order. Choosingh7 covers every n>=16 notdivisibleby7;
other h values cover many of the multiplesof7.

The independent reviewer checked the seed, allfour successor identities,
the reduced safe-set list, the sharpenedh7 threshold, and the newenvelope
count; all passed. Finite structural replay subsequently checked1424
admissible(n,h,variant) triples at n16..160,468636 copescape obligations,
and5696 integer propagationsteps. The receipt is
research/main-interval-half-density-checks.json. Independent game-rank
checks are maintained by the separate reviewer.

This strictly preserves the prior eight-move family: its compulsory set
contains the newone and its envelope lies in the newenvelope. No existing
optional-subset theorem was sacrificed. NewLean verification remainsopen.

## Parked observation at the execution cutoff

For h7 and 7|n, adding compulsoryoffset20 may remove the coprimality
restriction at six compulsory arrows pervertex when n>=28. The existing
pattern orbit covers residueclasses0,2,5,6 modulo7. The directpredecessor
-20 seedsclass1. Its backwardh propagation could use the triple(h,h-3,h-2)
and the alreadycomplete classes5,6. Thenclass3 can use classes0,1 andclass4
can use classes1,2. This has NOT received independent review or executable
verification and is not included in the theorem, constructor, or coverage.
Research stopped at the root's requested checkpoint before pursuing it.

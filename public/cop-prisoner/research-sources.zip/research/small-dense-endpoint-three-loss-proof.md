# Excluding total defect two at the two small dense endpoints

Private research proof for independent review. This is a refinement of the
separately frozen two-loss endpoint bound, with additional dependencies.

The proposed conclusions are

    M(7,28) <= 11,       M(8,40) <= 13.

Neither is claimed exact. Verified lower witnesses give 9 and 12.

Let F have h=2n missing arrows and Delta=h-I. The previous endpoint
exclusion rules out Delta<=1. Suppose Delta=2. If a missing outdegree is
zero, I=0, impossible here. Let ell count missing outdegree-one vertices
and e=sum max(q(v)-2,0). Then e=ell and, if ell>0,
Delta>=ceil(ell/2)+1. Thus ell is zero, one or two.

## No missing degree-one vertices

All missing outdegrees are exactly two. A duplicate pair of missing rows
kills both rows and gives four losses. Any source camping obstruction
therefore has distinct rows and the form

    F(c)={s,t},      F(s)={t,u}.

Here u cannot equal c: that would also kill row c. The four vertices are
distinct, so relabel c=0,s=1,t=2,u=3. Row1 already contributes both
allowed losses. Camping at0 also blocks recipient2 except for initial
source0. Consequently only rows0 and1 may have a missing arrow to2.
Every other source row must avoid source camping, and every predecessor
camp must have all its failed missing pairs contained in row1.

This is the fourth normal form in the finite check. The apparent overlap
between a killed row and a killed column must be handled correctly: a
transitive missing triangle alone need give only the two losses in row1.
It cannot be counted as an automatic third loss.

If there is no source camping obstruction, the earlier zero-defect
enumeration forces a predecessor camping obstruction. Its cop cannot
have the recipient as a missing neighbor, because the other missing
neighbor would then be a source camping obstruction. Thus its two
missing neighbors are distinct missing predecessors of the recipient,
and the entire missing recipient column fails. It has indegree exactly
two and consumes both allowed losses.

Normalize the recipient as0 and its missing predecessors as1,2. The
camping cop has missing row {1,2}; it is either0 or a separate vertex3.
No other row may have a missing arrow to0. Write
F(1)={0,a}, F(2)={0,b}. Their additional neighbors are distinct and avoid
1,2. The complete normal forms are:

    F(0)={1,2}, F(1)={0,3}, F(2)={0,4};
    F(3)={1,2}, F(1)={0,3}, F(2)={0,4};
    F(3)={1,2}, F(1)={0,4}, F(2)={0,5}.

The Python check enumerates these three forms and the killed-row form
with fixed chronological row order. The independent C++ check uses
minimum-remaining-values order and computes the literal union of all
currently forced failed pairs. A predecessor camping cop c excludes
only source c, if that pair is missing; this exception is retained.
No missing pair is counted twice. Both implementations have zero leaves
in all eight order/form combinations.

The Python source is `src/small_dense_defect_two.py`, with complete logs
in `research/small-dense-defect-two-columns.json`. The independent source
is `src/small_dense_defect_two_independent.cpp`, with logs in
`research/small-dense-defect-two-independent.jsonl`. Both checks are
static: no game solver is needed for these exclusions. The C++ replay
also checks that the transitive-triangle example above contributes two
losses, whereas duplicate rows contribute four.

## Exactly two missing degree-one vertices

The degree-one counting equality forces a disjoint missing two-cycle.
Its two rows exhaust Delta=2. Every outside missing pair must win and
no outside missing row may point into that two-cycle, since such a row
would be killed. The remaining k=n-2 vertices therefore form an ordinary
universal missing core with 2k+2 missing arrows. For n=7,8 this contradicts
the already established vertex maxima M_V(5)=4 and M_V(6)=7. This step
uses those retained complete small-order proofs.

## Exactly one missing degree-one vertex

Write its row c->x. The total excess e=1 makes exactly one other row
have missing degree three; all remaining nonfunctional rows have degree
two. The killed row x must have degree two, or Delta would exceed two.
Let F(x)=Y={y,z}.

Every missing column addressed to Y is killed by the pursuer at c. There
is no missing-pair exception from source c, because its only missing
recipient is x and x is not in Y. Thus every missing arrow into Y must
have tail x. Similarly every other nonfunctional row avoids x, or that
entire source row would be killed by c. All remaining pairs must win.

If c belongs to Y, say Y={c,y}, then the vertices outside {c,x,y}
form an ordinary universal missing core: their missing rows stay inside
that set, and a pursuer kept there captures every outside excursion.
Its order is four or five, and every missing outdegree is at least two,
contradicting the established small-order maxima.

If c does not belong to Y, remove {c,x,y,z}. The remaining core has
three or four vertices. Its missing rows lie in the core plus the root c
and have degree two, except possibly for the unique degree-three row.
All must win in the corrected safe-root interface: against a confined
core pursuer, other outside excursions are capturable, while root c
directly delivers to every core recipient after safe arrival. The
complete rooted exclusions for R2(3), R2(4), and the one-degree-three
families at those orders rule this out. Their static completeness proof
and files are in `small-dense-rooted-equality-proof.md`.

All possible missing-outdegree families with Delta=2 are excluded.
Together with the preceding Delta<=1 exclusion, this gives the proposed
three-loss bounds stated above. These conclusions depend on reviewing
both finite normalizations and the ordinary degree-one case split; the
incomplete witness searches are not upper-bound evidence.

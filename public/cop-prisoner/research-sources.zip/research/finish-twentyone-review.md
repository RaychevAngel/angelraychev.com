# Independent review of the twenty-one-arrow implication

13 September 2026. Review in progress until `finish-twentyone-review.json`
contains `verified: true`. The frozen producer manifest is
`sparse_finish_twentyone_manifest.json`.

The ordinary reductions have been checked separately: remove actual indegree-zero
sources or outdegree-zero sinks, never arbitrary vertices. Surviving pairs restrict
to the remaining graph; the deleted row/column has at most half the remaining
arrow budget of live recipients/sources, using two positive-indegree predecessors
or two nonsink successors. Degree one adds no pairs. This gives the new19-arrow
upper49 from the retained17-arrow upper41 and18-arrow upper44. The checked20-arrow
upper53 and new19-arrow upper49 then bound zero-degree21-arrow graphs by58.
On ten vertices deletion gives the sharper56 using the host-size cap on the deleted
row/column. Source and sink arguments are separate, not a graph-reversal assumption.

For positive degrees, the exact eligible rectangle is
`qr-b-(q+r+m-2n+w)`, where `w` counts arrows from low-outdegree vertices to
low-indegree vertices. Maximizing with `b>=max(0,q+r-n)` and `w>=0` independently
reproduces all residual active-count families. No matching assumption is used for
the unequal joint degree families.

Positive degrees at most two and one low degree on each bipartite side decompose
into cycles and one path. Alternating edges supply a perfect matching and a partial
matching. For minimum degree two with a single degree-three vertex on each side,
Hall's inequality follows from `2|S|<=2|N(S)|+1`; thus a perfect matching exists.
Conjugacy normalizes its cycles. One distinguished vertex per distinct cycle size
and every choice of its partner cover all residual marked configurations. Direct
joint-degree enumerations cover the remaining families using only permutations of
future vertices with equal degrees and identical incoming prefixes.

Camping pruning was checked at the level of individual permanently failing pairs.
A completed source row covered by another vertex's closed outgoing neighborhood
fails; a completed predecessor column covered by a cop neighborhood fails except
when that cop would be the initial source. Diagonals and actual or possible future
direct arrows are excluded before comparing losses with the eligible rectangle.
Counting the union is essential: separate losses may overlap. The guarded-path
prune gives the messenger every unfixed arrow and retains only fixed cop arrows;
initial entry, receipt priority, and the initial-source exception are handled
separately. This is a necessary condition, not an assumption that stationary cops
solve the full game.

Every complete leaf in each frozen upper run is replayed with an explicit two-turn
alternating attractor independent of the producer's compressed recurrence. Sampled
prune claims are also checked against that more favorable messenger game. Node,
family, and leaf counts must match the frozen completed producers. Literal56,58,60
attainers have all their finite winning ranks and losing-closure conditions replayed.

Boundary: graph enumeration and pruning sources are independently reviewed, but
replayed using the producer's enumeration, not a separately implemented full graph
enumeration. This review does not instantiate the new concrete cases in Lean.

# Stronger constructions and support concentration: 13 September 2026

> Historical mathematical checkpoint. The active scope and priorities are now in `research/CLASSIFICATION_SCOPE.md` and `research/CLASSIFICATION_GAPS.md`; the specialized fast-delivery programme below is parked. This snapshot preserves its original results and proof boundaries.

This is a research checkpoint, not a claim of a complete classification.
Publication state is recorded separately in website-deployment.json and
publication-build.json; mathematical claims below have independent checks.

## Independently checked advances

1. **Packed sparse envelope:** canonical six-type smoothing at n=6k-r,
   k>=20, 0<=r<=5, holes0,3,...,3(r-1). Eight optional types, with seven
   relative rules suppressed per hole, give exactly8k-9r optional arrows.
   All101 possible local crops pass two independently written game
   verifiers. Thus every n>=115 has arbitrary-subset robust constructions
   for 2n<=m<=20k-11r, including all2n<=m<=3n. The two-entry refinement is now independently proved: M5/R8 local
   arenas give transfer9, entry−3 delivery39, entry−2 delivery38, hence
  9k+21 global moves. Both independent solvers checked all696 objectives. Canonical clusters are essential: arbitrary gap-at-least3
   patterns FAIL, with crop[-3,1] a recorded counterexample to that approach.

2. **Antichain composition:** attach outside vertices through incomparable
   subsets of either part of a small two-type core. Codes have size>=3 and
   avoid difference2 in P or adjacency in L. Every subset of outside arrows
   preserves two-move delivery. For q codes, total weight W, and core order2k,
   the exact interval is A through A+q(q-1), A=2k(2k-3)+4kq-W. A full
   case proof was independently attacked, including c=t and mixed code
   parts/sizes. Equal-weight capacity is2k/(k-r)*binom(k-r,r), oddk.
   This gives deterministic q2(n)<=(5.3555763082+o(1))*n*log2(n).

3. **Main interval:** the antichain construction bridges the protected
   circle and dense envelopes at every n>=115. A finite list of explicit
   parameter/set certificates covers115..390, with separate mixed-weight
   codes at116 and an explicit protected set at117. Elementary parameter
   inequalities cover391..699 and alln>=700. Together with1 this yields
   M(n,m)=n(n-1)-m for every n>=115 and2n<=m<=n(n-3). This is not a
   two-move assertion at sparse budgets. Full argument and receipts:
   research/routing-defect-phase2-code-composition.md.

4. **Dense gaps:** explicit11-core and repaired odd envelopes23,25,27,31
   independently checked using literal witnesses and/or both fullgame
   solvers. The h=2n endpoint holds at every n>=10, full staircase at every
   n>=20, arbitrary-subset bridge2n<=h<=3n at every n>=16. Two ordinary
   uniform envelope proofs reaching approximately n²/10 andn²/4 are written
   and finite-tested; their independent ordinary review passed; full proofs are integrated in58.

5. **Quantitative support:** with eta=m-2sqrt(I), the induced core on vertices
   with both degrees>=2 has between m/2-3eta andm/2 vertices. Nonisolated
   support is at most m/2+4eta; at most12eta arrows lie outside that core.
   Root reviewed the degree-surplus and zero-row/column arguments and the
   arithmetic; independent finite checks cover all4165 labelled graphs
   through4vertices and181 larger/random/extremal examples with bothgame
   solvers. No claim that deleting those outside arrows preserves I.

6. **Orientation routing:** exactly half the hub-incident arrows can be
   fixed by orienting each touching undirected pair. Independent witness
   failure is at most n(n-1)²*(7/8)^(b-3), yielding b=ceil(24lnn+4).
   Conditional expectation counts products rather than coefficient sums.
   This is an alternative general hub-selection algorithm, not a claim
   to supersede all density parameters of Theorem54.

## Fast sparse composition: open terminal step

A ten-type two-generator local interface safely navigates either generator
in at most32moves, normalizes arbitrary initial states in one move, and has
full finite strategy certificates. Its transfer to girth>=9 quotients passed
independent geometry and complete rank-layer audit. A new common twelve-
exclusion interface has finite certificates for eight of ten recipient types;
the branch-aware projection and all825843 new rank obligations passed
independent review. On qualifying simple4regular quotients of girth>=133
and inverse-generator diameterD, those eight types deliver within32D+64.
Types2/7 remain open; a stationary cop blocks relevant infinite-tree gate
states, and the attempted2.2n-arrow repair fails. No logarithmic-delivery
universal sparse theorem is claimed. A strongly connected two-sheet cover
of the known12-vertex universal graph fails universality despite having no
immediate source-camping obstruction; projection alone is insufficient.
Records: composition-interface-*, especially terminal-checkpoint.md.

## Integration boundary

Ten Lean modules now pass, including robust envelope semantics, the
explicit11vertex dense core, and all six16..21 robust dense envelopes.
General existence/counting and the infinite families remain ordinary proofs.
The publication receipts distinguish local builds from public deployment.
Open: M_V(9..11), M_E(12..22), jointclassification below the new general order
threshold, exact q2 constant and exact delivery-time tradeoffs. Do not fill
these with the eventual formula or confuse the new safe-navigation lemma
with terminal delivery.

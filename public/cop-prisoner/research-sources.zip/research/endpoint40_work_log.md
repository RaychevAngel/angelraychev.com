# Endpoint40 work log

13 September 2026. Assigned exact decision M(8,40)=12 versus13. Only new endpoint40 files may be created; no canonical edits. One sustained compute process at a time.

## Initial decision domain

Positive score forces all missing outdegrees positive. At h=16 and putative I>=13, the existing degree-one inequality Delta>=ceil(ell/2)+1 bounds ell<=4. The degree sum gives excess e=ell. Rather than depend on the proposed ell2..4 reductions, the initial standalone producer enumerates every sorted positive missing-degree profile with sum16 and ell<=4. It uses ascending degrees, fixed chronological row order, and suffix normalization inside equal-degree/equal-incoming future cells. The partial loss count is a literal union of source and predecessor camping pairs with the initial-source exception retained. Full static leaves are scored with the explicit alternating AND/OR queue.

## Actual commands

- Read the existing small_dense_first_step_profiles.cpp, small_dense_near_endpoint_profiles.cpp, small_dense_defect_two_independent.cpp, small_case_n7_independent.cpp and small_case_certificate_review.py.
- Compile: `c++ -O3 -std=c++17 src/endpoint40_complete.cpp -o src/endpoint40_complete.bin`.
- Initial bounded run: `src/endpoint40_complete.bin 60 > research/endpoint40_primary_first.jsonl`.

Initial result not yet recorded. A timeout is incomplete, never an upper proof. The new rooted-profile arguments remain proposals and are not needed for this producer's coverage.

## First result and simplification

The first run completed all12 profiles in0.48925 seconds, visiting5,494,330 prefixes and158 static leaves; the explicit game gave score7 for every leaf. No target13 witness appeared. This is producer evidence pending independent review. No timeout or stopped search occurred.

A conservative standalone variant now removes the ell<=4 restriction, covering every positive missing-degree profile of total16. This avoids importing the degree-one inequality into the upper proof. Original producer/log remain unchanged.

- Compile: `c++ -O3 -std=c++17 src/endpoint40_positive.cpp -o src/endpoint40_positive.bin`.
- Run: `src/endpoint40_positive.bin 60 > research/endpoint40_positive.jsonl`.

## Complete-positive result and full literal replay

The conservative run completed all20 positive degree profiles in0.584467 seconds, visiting6,308,606 prefixes;158 static leaves all haveI7. No timeout, interrupted run, or graph construction search occurred.

- `python3 src/endpoint40_certify.py > research/endpoint40_certify_stdout.json` completed. It checks all20 expected profiles independently, generates full negative certificates for every saved leaf using both established Python solvers, directly replays161,792 negative state obligations with the separate literal checker, and reruns/replays the retained12 graph's1,024 states. It also checks1,480 explicit camping cop witnesses over1,422 prefixes.
- Wrote the ordinary/source coverage argument and literal adjacency to `research/endpoint40_exact_proof.md`.

The proposed exact value is12. Outstanding at this checkpoint: the parent-assigned independent reviewer must audit/retraverse the new producer and inspect the proof. The proposed ell2..4 rooted reductions were not needed and were not promoted. No canonical registry, paper, or handoff has been edited.

## Authorized extension to the remaining n8 main cells

The parent independently completed the endpoint exclusion with a separate delivery-row/OR-predecessor engine, 20 profiles and34 surviving games. The parent then authorized extending this worker to n8 main-interval cells.

The parameterized positive-missing producer is `src/endpoint40_n8_profiles.cpp`. Actual completed commands were:

- `src/endpoint40_n8_profiles.bin 35 20 60 > research/endpoint40_n8_m35_t20.jsonl`
- `src/endpoint40_n8_profiles.bin 36 19 60 > research/endpoint40_n8_m36_t19.jsonl`
- `src/endpoint40_n8_profiles.bin 37 17 60 > research/endpoint40_n8_m37_t17.jsonl`
- `src/endpoint40_n8_profiles.bin 38 16 60 > research/endpoint40_n8_m38_t16.jsonl`
- `python3 src/endpoint40_n8_high_certify.py > research/endpoint40_n8_high_certify_stdout.json`

These completely exclude the construction agent's lower+1 targets and replay every negative game with both Python solvers and the independent literal checker. The proposed exact values are19,18,16,15 respectively. The receipt is `research/endpoint40_n8_high_receipt.json`. Parent reports a separate complete independent upper traversal also passed.

A capacity variant `src/endpoint40_n8_capacity.cpp` adds ordinary zero rows/columns when delivery degree<=1, plus the already reviewed row/column incidence bounds. Commands:

- `src/endpoint40_n8_capacity.bin 23 30 60 > research/endpoint40_n8_m23_t30.jsonl` completed147 profiles,134,711,685 prefixes,797 leaves in16.1335 seconds.
- `src/endpoint40_n8_capacity.bin 22 29 60 > research/endpoint40_n8_m22_t29.jsonl` completed146 profiles,323,280,214 prefixes,18,697 leaves in39.3694 seconds.

The lower graphs give29 and28, respectively. Literal complete independent game replay is pending at this checkpoint.

For lower budgets, `src/endpoint40_n8_live.cpp` freezes the parent-reviewed `finish_tiny_live.cpp`, changes its order guard to n=8, and emits every evaluated leaf. The worker independently reviewed the original live-prune addition in `research/endpoint40_tiny_live_review.md/.json`, including the completed budget12 and disjoint budget13 exclusions.

- `src/endpoint40_n8_live.bin 8 26 21 21 60 > research/endpoint40_n8_live_m21_t26.jsonl` completed77 profiles,481,908,606 prefixes,187,157 leaves in59.1217 seconds. Lower25 matches.
- `src/endpoint40_n8_live.bin 8 25 20 20 60 > research/endpoint40_n8_live_m20_t25.jsonl` timed out in profile118 after60.0068 seconds. It is explicitly incomplete and is not a complete exclusion.
- `src/endpoint40_n8_live.bin 8 25 20 20 60 118 > research/endpoint40_n8_live_m20_t25_tail118.jsonl` completed the final profile118 in22.0776 seconds. A separately completed head is still needed for the intended strict split receipt.
- `src/endpoint40_n8_live.bin 8 20 17 17 60 > research/endpoint40_n8_live_m17_t20.jsonl` is the next bounded pilot; outcome pending at this checkpoint.

The parent chose full independent C++ game replay of every emitted literal leaf for the large sets, rather than generating hundreds of megabytes of duplicate rank arrays. `src/endpoint40_n8_leaf_replay.cpp` supplies that separately written compressed fixed-point replay and imports no producer. It does not constitute an additional full graph enumeration or Lean proof.

## Final completed low-band exclusions and independent replay

- m17 target20 completed all98 profiles,161,529,420 prefixes,569,948 leaves in31.0467 seconds.
- `src/endpoint40_n8_live.bin 8 22 18 18 60 > research/endpoint40_n8_live_m18_t22.jsonl` completed all73 profiles,218,691,375 prefixes,243,894 leaves in35.476 seconds.
- `src/endpoint40_n8_live.bin 8 23 19 19 60 > research/endpoint40_n8_live_m19_t23.jsonl` completed all94 profiles,365,807,033 prefixes,345,149 leaves in53.0951 seconds.
- `src/endpoint40_n8_live.bin 8 25 20 20 60 0 118 > research/endpoint40_n8_live_m20_t25_head118.jsonl` completed118 profiles in38.9318 seconds. Combined with the already completed final tail, this supplies a clean exact disjoint cover of all119 profiles; the initial timed-out pilot is unused.
- `python3 src/endpoint40_n8_low_review.py > research/endpoint40_n8_low_review_stdout.json` completed. It independently counted all degree-profile sets and intervals, checked the seven full lower rank certificates, verified the frozen live source differs only by its n8 guard and leaf emission, compiled the separate compressed-game replayer, and replayed every one of1,512,673 emitted leaves.

The exact low row is19,21,22,24,25,28,29 for budgets17 through23. Together with the earlier endpoint and high exclusions plus the construction agent's m27..34 graphs, all order-eight main gaps are closed.

At completion, source hashes in `finish-endpoint40-review.json`, `finish-n8-review.json`, `endpoint40_n8_low_receipt.json` and `endpoint40_tiny_live_review.json` all match. No sustained process remains. Proposed rooted-core lemmas were unnecessary and were never promoted. No canonical ledger/paper/handoff edits or additional goal claims were made.


## Continued authorized small-main completion

The order-eight sparse cells also closed: `endpoint40_n8_sparse_receipt.json` certifies M(8,14)=13, M(8,15)=15, and M(8,16)=19, with every one of 4,101,518 literal leaves independently replayed. The full order-eight row is now exact. No canonical files were edited by this worker.

For n9,m23,target45, the generic missing-row pilot `endpoint40_small_main_profiles.bin 9 23 45 60` timed out in outgoing profile5 after 60 seconds (406,010,186 prefixes,305 leaves). This log is incomplete and unused for the final upper. Coupling exact incoming and outgoing degrees instead gave a much smaller complete search. `endpoint40_small_joint.cpp` is a frozen copy of the reviewed positive coupled engine; changes only remove an optional leaf cutoff, emit exact literal leaves, and update the header.

Actual coupled commands:

- `python3 src/endpoint40_small_joint_inputs.py 9 23 45 --out-profile 5` and `src/endpoint40_small_joint.bin 9 23 44 60 0 < research/endpoint40_joint_n9_m23_t45_out5.txt > research/endpoint40_joint_n9_m23_t45_out5_run.jsonl` completed all70 patterns in8.70175s,3,776,935 prefixes,19 leaves.
- `python3 src/endpoint40_small_joint_inputs.py 9 23 45` and the analogous full run completed all338 joint patterns in43.317s,19,755,818 prefixes,1,222 leaves.
- `python3 src/endpoint40_small_joint_review.py 9 23 44` independently regenerated the complete degree inventory, checked source lineage, replayed all1,222 leaves with the independent compressed game, and replayed all1,458 full lower state obligations. The cell receipt is `endpoint40_joint_n9_m23_t45_receipt.json`; proposed ordinary exact value44 is sent to the parent for source-boundary review. No second complete graph traversal is claimed.
- Actual-source min-degree-two prefix tests passed780 graphs,6,326 prefixes,78,310 specific cop states. The extended positive-degree tests passed2,399 graphs,14,444 prefixes,177,481 states. Both use independent full games and a BFS check of guarded paths, while invoking actual producer prunes.

For n10,m24 the initial target61 run found a score61 literal at pattern84/109 in7.29013s. It is a witness discovery, not an exclusion. Full ranks and independent replay are in `endpoint40_joint_n10_m24_discovered61_certificate.json` and `_review.json`.

The target62 full pilot timed out at pattern104/109 in60.0002s. A six-pattern tail[103,109) pilot timed out at its fifth pattern in60.0284s. Both incomplete logs are retained and unused as complete intervals. After measuring these runs, a180-second cap was assigned to the same six-pattern tail, under `endpoint40_joint_n10_m24_t62_tail103full_run.jsonl`; outcome pending at this checkpoint. A separate completed head[0,103) will still be needed. No workload above ten minutes was launched.

For n10,m25 the initial target61 pilot timed out at251/339 in60.0171s and is unused. Instead, all66 one-arrow additions to the new24-arrow graph were checked in0.061s. Adding(6,8) gives a literal with I65, equal to all90-25 missing pairs. Full lower ranks and independent replay establish M(10,25)=65 in `endpoint40_joint_n10_m25_exact_receipt.json`.

The new universal25-arrow graph was also tested under all25 one-arrow deletions,300 two-arrow deletions, and2,300 three-arrow deletions (0.028s,0.246s,1.700s). The maxima were61,59,54 respectively. This improves the23-arrow lower to59, with a full-rank certificate in `endpoint40_joint_n10_m23_deletion_certificate.json`. The22-arrow retained lower55 remains better. Every construction is retained with exact arrows and independent rank review.

The next positive-degree inventories for n9,m19..22 contain69,303,237,825 joint patterns above35,36,39,40 respectively. Source/sink deletion against the completed n8 row bounds the corresponding zero-degree boundary by25,27,28,30. These are input/proof preparations, not completed exclusions.


## Completed ten-vertex cells and the next nine-vertex cell

The n10,m24 target62 split completed with unchanged source: head[0,103) in50.1981s,20,234,173 prefixes,37,070 leaves; tail[103,109) in98.2755s,41,291,684 prefixes,74,902 leaves. `endpoint40_small_joint_split_review.py 10 24 61 ... head103 tail103full` independently regenerated all109 patterns, checked the exact disjoint cover, and independently replayed every111,972 leaf. `endpoint40_joint_n10_m24_t62_split_receipt.json` establishes61 with the full-rank lower. Both sixty-second pilot logs remain incomplete and unused.

For n10,m23, the target60 run found a score60 literal after27.1037s at pattern28/31; the target61 run found score61 after27.279s at the final pattern. These are discoveries, not complete exclusions. Each found graph has a full-rank certificate and independent replay. The23 single-arrow deletions of the60 graph did not improve m22 (best54).

To avoid repeating the same traversal on further improvements, `endpoint40_small_joint_max.cpp` keeps a monotone incumbent and continues after a better leaf. It changes no enumeration, prune or game body. The source transformation is checked exactly, and each earlier pruned prefix remains bounded by the final incumbent. The final target62 run completed all31 patterns in11.8298s,4,962,324 prefixes,12,584 leaves, with no improvement beyond the supplied61 lower. `endpoint40_joint_n10_m23_t62_max_receipt.json` establishes M(10,23)=61 after independent input and every-leaf replay.

The parent completed n10,m22=60 separately and assigned n9,m19 and m20 to other workers. This worker retained n9,m21 and m22 only.

- `src/endpoint40_small_joint_max.bin 9 21 39 60 0 < research/endpoint40_positive_n9_m21_t40.txt > research/endpoint40_positive_n9_m21_t40_max_run.jsonl` completed all237 positive-degree joint patterns in34.1713s,19,605,891 prefixes,10,888 leaves. Full independent input regeneration, every-leaf replay, and matching full-rank39 are in `endpoint40_positive_n9_m21_t40_max_receipt.json`. The ordinary source/sink boundary is28, using the completed n8 row. Hence M(9,21)=39.
- `src/endpoint40_small_joint_max.bin 9 22 40 60 0 < research/endpoint40_positive_n9_m22_t41.txt > research/endpoint40_positive_n9_m22_t41_max_run.jsonl` starts the final assigned main-cell pilot, with all825 positive joint patterns. Its outcome is pending at this log checkpoint. The source/sink boundary is30.

No canonical paper, registry, ledger or handoff file was edited by this worker. Source-pinned files remain unchanged; new variants and receipts use unique endpoint40 names.


## Final assigned main-cell completion

The initial n9,m22 run timed out at pattern790/825 in60.0058 seconds and is historical only. The equivalent incremental camping counter changes no obstruction: it forms the same eligible-pair union, counts each pair once, and exits once losses already exceed the cutoff. Exact old/new decisions agreed on473,080 prefix/cutoff comparisons; the independent game and BFS fixtures also passed.

`src/endpoint40_small_joint_fast.bin 9 22 40 180 0 < research/endpoint40_positive_n9_m22_t41.txt > research/endpoint40_positive_n9_m22_t41_fast_run.jsonl` completed all825 patterns in100.022 seconds,62,479,591 prefixes and8,916 leaves. `endpoint40_small_joint_fast_review.py 9 22 40 research/endpoint40_joint_n9_m22_local_certificate.json --positive` independently checked the inventory, exact source transformation, source/sink bound30, every literal leaf, and matching full ranks. Hence M(9,22)=40. The receipt is `endpoint40_positive_n9_m22_t41_fast_receipt.json`.

All six final small-main receipts pass the source/file-pin audit in `endpoint40_main_source_pin_audit.json`;145,582 upper leaves were independently replayed across the five coupled exclusions. The sixth cell, n10,m25=65, uses the direct missing-pair upper. No sustained computation remains in this lane.

The parent additionally assigned preparation of `src/finite_value_tables.py` and `paper/finite-values.md`, conditional on exact refreshed ledger data, and independent review of the final classification assembly. That is new explicitly authorized scope; website files remain outside this worker's scope.


## Final classification assembly and compact tables

The parent completed and regenerated the canonical ledger: all493,924 stored admissible cells are exact and the refreshed explicit-construction inventory reports zero known-value construction gaps. The parent explicitly authorized the two new non-prefix files `src/finite_value_tables.py` and `paper/finite-values.md`.

The generator independently decodes every affine ledger segment without importing the classifier, checks all451 admissible cells through order11 are covered by the compact tables and interval rules, checks493,473 cells from order12 upward against the sparse/main/staircase/zero formulas and the new ME0..23 table, and checks519 small-budget support cells. Removing isolates gives support at most2m<=46 for budgets at most23; fitting attainers on at most12 vertices give the matching infinite extension. The large-order bands use the retained ordinary family theorems, rather than inferring an infinite claim from the finite audit box.

Actual commands `python3 src/finite_value_tables.py --receipt research/endpoint40_finite_value_tables_audit.json` and `python3 src/finite_value_tables.py --check` both passed on the exact ledger and the fresh ledger-pinned construction audit. The Markdown output has the parent-requested anchor `complete-tables-through-eleven-vertices`. Dense-table zero entries are actual zero values; em dashes are reserved for inadmissible budgets. The paper and generator are source-pinned in the receipt. Parent was told to rerun the generator/receipt if later ledger regeneration changes its hash.

This worker's assignment is complete. No sustained process remains, no website file was changed, and no global goal-tool status was changed by this worker.

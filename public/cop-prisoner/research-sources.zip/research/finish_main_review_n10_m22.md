# Independent review of M(10,22)=60

The complete positive-family maximum and literal attainer give
`M(10,22)=60`, subject to the already approved global `M_E(19)<=49` dependency
in the ordinary zero-degree bound below. The source, complete degree inventory,
and every reached game leaf pass the independent checks in
`finish_main_review_n10_m22.json`.

Supports of size at most nine have at most `9*8-22=50` missing ordered pairs.
For a ten-vertex graph with an actual source or sink of other degree `d`, delete
that vertex and compare old guaranteed pairs with the remainder. If `d=1`,
the removed row or column contributes zero and the remaining nine-vertex,
21-arrow graph has at most `72-21=51` missing pairs. If `d=2`, the reviewed
`M(9,20)=37` plus at most seven new row/column pairs gives44. For `d>=3`, the
remainder has at most19 arrows and the removed row/column contributes at most
six; approved `M_E(19)<=49` gives55. Thus any graph above55 has full positive
support on ten vertices. This deletes only actual sources or sinks and does
not alter the set of cop positions in a graph being evaluated.

The independent incoming-degree sum recursion reproduces the entire supplied
set of61 joint-degree multisets whose eligible bound exceeds the **initial**
threshold55. Every initially omitted multiset is bounded by55 and therefore
by the final60. The maximizing source has the same hash as the exact adaptation
reviewed for `M(9,20)`. Its degree constraints, adjacency coverage, future-vertex
symmetry, camping-loss union, guarded optimism, and game semantics are unchanged.

The independent replay starts at55, in the producer's original profile order.
It solves every target of every leaf using the separate explicit two-turn
queue. It reproduces exactly two updates, **55 to56** and **56 to60**, each
only after computing the complete score of an actual graph. Both update
witnesses' outgoing masks are retained in the review receipt. Every subsequent
prune bounds its branch by the then-current attained score. Every earlier
prune used a smaller threshold, so it remains bounded by the final60.
Monotonicity of the threshold therefore preserves every exclusion; no
monotonicity of game score under adding arrows is assumed.

All61 patterns finish, and all47,716 leaf decisions are independently replayed.
Every traversal counter, both threshold updates, the final60, and the final
literal arrows match the primary result. At64 sampled guarded states,838
claimed losing pairs pass the independent asymmetric-game test. The tiny
deadline control reports `complete=false` and a nonzero exit code. The old
`counterexample_found` field is not used to infer improvement: this maximizing
source never sets it, so the explicit initial/final thresholds and actual
game values are the relevant evidence.

The final ten-vertex,22-arrow literal's ranks are independently checked directly,
without its certificate producer. All2000 alternating-state obligations pass,
including receipt before collision, messenger choices, universal cop responses,
and closed losing regions. Exactly60 missing distinct ordered pairs win for
every allowed initial cop. Its arrows exactly match the final producer witness.

This is ordinary/source coverage review, independent exact degree-set
regeneration, and complete independent game replay at every reached leaf.
The adjacency and pruning traversal is retained from the reviewed producer;
it is not a second independently implemented complete graph enumeration.

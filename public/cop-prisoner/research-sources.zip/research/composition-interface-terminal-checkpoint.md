# Sparse composition: eight recipient types and the final two-type gap

Checkpoint: 13 September 2026. The original six-exception navigation lemma
has an independent mathematical and certificate audit in
`composition-interface-navigation-independent-audit.md`. The strengthened
interface and terminal modules below have also passed independent literal
transition reconstruction, replay of all 825,843 new winning states, and
review of the branch-aware finite-quotient projection. The complete audit
is `composition-interface-terminal-independent-audit.md`, with its matching
JSON receipt. No Lean theorem is claimed here.

The graph is exactly the ten-type, two-in/two-out graph displayed in
`composition-interface-navigation.md`; no additional arcs are used in the
positive checkpoint. The quotient is a finite set $X$ with permutations
$a,b$. Its undirected edges $\{x,xa\},\{x,xb\}$ form a connected
simple four-regular graph. In particular, $xa,xa^{-1},xb,xb^{-1}$ are
four distinct neighbors of every $x$. The messenger may navigate using
$a^{-1},b^{-1}$.

## One common interface

Write $(i;w,j)$ for messenger type $i$ at cell $x$ and cop type $j$
at cell $xw$. In addition to collisions, exclude precisely these twelve
joint states:

\[
\begin{aligned}
 &(3;e,5),\ (3;e,9),\ (3;b,7),\ (3;b^{-1},5),\ (3;b^{-1},9),\ (4;e,0),\\
 &(8;e,0),\ (8;e,4),\ (8;a,2),\ (8;a^{-1},0),\ (8;a^{-1},4),\ (9;e,5).
\end{aligned}
\]

Call the remaining uncaught messenger-turn states $J$. The finite
certificates verify both of the following.

1. Every initial uncaught state reaches $J$ safely in at most two
   messenger moves. The cell may change during normalization.
2. From $J$ at cell $x$, either prescribed cell $xa^{-1}$ or
   $xb^{-1}$ is safely reachable within 32 messenger moves, ending in
   $J$ after the final cop response.

The twelve exclusions are the union of the nine-exception interface
previously used for recipient type 0 and its lane mirror. This avoids
assuming that the earlier eight-exception interface was contained in the
type-0 interface: it was not. The common interface is contained in every
successful terminal module's input condition.

## Exact terminal modules

Each statement starts in $J$ at cell $x$, with arbitrary cop position.
Arrival at the recipient ends the game immediately, before a cop response.

- Type 0 at $xa$: at most 39 moves. The messenger window has radius 2,
  the cop window radius 3, and the cop exterior retains only its type.
- Type 1 at $xa^{-1}$: at most 62 moves. Both windows have radius 3;
  exterior cop states retain their type and the first two letters of
  their reduced quotient word.
- Type 3 at $xa^{-2}$: at most 35 moves. Both windows have radius 3;
  the cop exterior retains only its type.
- Type 4 at $xa^{-1}$: at most 38 moves. Both windows have radius 3;
  the exterior again retains its type and first two reduced letters.
- Interchange $a\leftrightarrow b$ in the parameterized rule scheme
  and add 5 to every type modulo 10. The rules and $J$ have this exact
  symmetry for every pair of permutations; no automorphism of a fixed
  quotient interchanging $a,b$ is required. It gives, respectively,
  types 5 at $xb$, 6 at $xb^{-1}$, 8 at $xb^{-2}$, and 9 at
  $xb^{-1}$, with the same bounds.

Types 2 and 7 remain unresolved. They are not obtained from these modules
by treating a successful receipt at a predecessor as safe intermediate
arrival: receipt permits a final collision, while an intermediate step
must survive the cop response.

## Why branch provenance matters

The old exterior symbol allowed a cop that left one branch of the free
quotient tree to enter another branch immediately. Retaining the first
two reduced letters removes some of these artificial jumps.

In the branch-aware finite arena, a cop outside the radius-three window
has descriptor $(\Omega_p,i)$, where $p$ is one of the twelve reduced
words of length two and $i$ is its type. It may wait or make either
type change while retaining $p$. For an arc labelled $g$, it may enter
a represented cell $z$ exactly when the prior cell $zg^{-1}$ lies
outside the radius-three ball and has prefix $p$. There are 530
messenger positions and 650 cop positions. This is an overapproximation
of the game on the infinite free quotient tree.

For type 4, the original six-exception interface had exactly one failing
start in this arena: messenger 3 and cop 5 in the anchor cell. Excluding
that state and its lane mirror produced the eight-exception interface;
both 32-move navigation modules survived, and normalization took at most
two moves. The final twelve-exception interface also handles the separate
type-0 input conditions.

## Audited finite-quotient projection, with an explicit girth bound

The following ordinary argument and its finite certificates have passed
the independent audit cited above.

For a branch-aware terminal module lasting at most $T$ moves, let

\[
R=3,\qquad L=R+T.
\]

Assume the undirected quotient ball of radius $L$ about the anchor is
an induced tree. Girth at least $2L+3$ is a sufficient conservative
condition. A cop initially farther than $L$ cannot enter the represented
radius-$R$ window before the module ends. It can be assigned any exterior
prefix, with its true type, and mapped to exterior transitions throughout.

Otherwise, use the cop's unique word in this tree. At time $t$, call it
relevant if its distance from the anchor is at most $R+T-t$. While it is
relevant, all relevant moves lie in the induced radius-$L$ tree. Thus its
exterior prefix cannot change without passing through the represented
ball. If it becomes irrelevant, no remaining play can bring it into that
ball before the deadline; retain its last exterior prefix and its actual
type. If irrelevance first occurs on an outward step from the represented
ball, initialize that frozen prefix from the departure edge. This defines
a causal projection and does not assume knowledge of the cop's future
choices. Every possible collision with the messenger is inside the
represented ball and is preserved.

The largest terminal bound is $T=62$, so girth at least 133 suffices
simultaneously for these branch-aware modules. It also implies the
girth-nine condition for the ordinary navigation and other terminal
modules.

**Eight-type delivery theorem (computer-assisted, independently audited).**
On every finite quotient satisfying the connected simple four-regular
hypothesis above and having girth at least 133, let $D$ be its directed
diameter using $a^{-1},b^{-1}$. Every recipient of types

\[
\{0,1,3,4,5,6,8,9\}
\]

is reachable from every source and every uncaught initial cop position in
at most $32D+64$ messenger moves. Normalize, navigate to the appropriate
anchor, and invoke its terminal module. For example, recipient $0_y$
uses anchor $ya^{-1}$, while $1_y,4_y$ use $ya$ and $3_y$ uses
$ya^2$. This is a statement about eight recipient types, not universal
delivery or a new exact value of $M(n,m)$.

## Final gap and a real infinite-tree obstruction

For recipient $2_x$, the predecessors are $6_x$ and $1_{xa}$.
A cop camping at $0_x$ controls $6_x$ and $0_{xa}$. In the infinite
free quotient tree, every passage from the $x$-side of the edge
$x\!-\!xa$ into the $xa$-side has head $0_{xa}$. Thus a messenger
starting at $1_x$ cannot safely reach either recipient predecessor.
The state belongs to $J$.

This rules out a terminal theorem from all of $J$ at the recipient's own
cell on the infinite lift, regardless of the window radius. A finite
quotient can bypass that cut through a long outside route. The remaining
composition problem is therefore to retain enough information about
that final approach, or to change the gadget.

A useful next interface fact survives: the 32-move negative-$a$ module
can finish specifically in types $\{1,2,3,4\}$, and the negative-$b$
module in $\{6,7,8,9\}$, while retaining the eight-exception interface.
This last-generator information was tested but is not included as a
separately replayed claim in the current terminal certificate archive.

## Files and proof boundary

- `src/composition_interface_terminal_checkpoint.py` generates the seven
  full finite proofs: two navigation modules, normalization, and four
  terminal modules. It directly checks a legal messenger action and all
  cop responses for every new winning state.
- `research/composition-interface-terminal-checkpoint-certificates.json.gz`
  contains their arenas and all layers.
- `research/composition-interface-terminal-checkpoint-verification.json`
  records counts, source hashes, and the archive hash.
- `research/composition-interface-development.md` records successful
  reductions, failed alternatives, and the finite/infinite distinction.

The original direct replay shares its arena producer. The subsequent
independent audit reconstructed the literal ordinary and branch-aware
transitions, checked all seven complete layer certificates and their exact
seed/input conditions, verified lane symmetry, and reviewed the quotient
projection. Its files are
`composition-interface-terminal-independent-audit.md` and
`composition-interface-terminal-independent-audit.json`. The immutable
production archive retains its original pre-audit status text; the later
independent audit supersedes that status. Earlier exploratory JSON files
are diagnostics, not replacements for these full certificates.

# Independent review of the regular 20-arrow family

The frozen `src/small_sparse_regular.cpp` and completed receipt
`research/small-sparse-regular-10-threshold50.json` establish that the maximum
among loopless two-in/two-out digraphs on ten vertices is 53. The literal
53 witness was independently replayed with both actual-game solvers and
all winning/losing rank obligations. This does not settle the maximum
among nonregular graphs or larger supports.

**Coverage.** Replace vertices by their tail/head copies. The bipartite
incidence graph of a two-in/two-out digraph is two-regular and hence a union
of even cycles. Alternating each cycle decomposes its edges into two
perfect matchings, giving disjoint permutations `alpha,beta`. Looplessness
makes each a derangement. Simultaneous relabeling puts `alpha` in the
canonical cycle form of an integer partition with every part at least two.
The recursive partition generator visits all such partitions, and the
`beta` recursion visits every permutation avoiding the diagonal and alpha.
Duplicate graph representations are harmless; none is omitted.

**Permanent pruning.** An assigned source row is complete: both alpha and
beta arrows are fixed. If its outgoing set lies in the closed outgoing
neighborhood of another cop vertex, its indirect row is zero. Even when
the cop row is incomplete, later additions only enlarge that neighborhood.
Likewise, when beta has used a head, its two-element predecessor set is
complete. A cop neighborhood covering it makes every indirect pair in that
column lose except possibly the pair whose source equals the cop. The code
excludes exactly that exceptional source. Both obstructions persist under
every completion. The source row, predecessor column, and used-head flags
are restored correctly when their unique beta assignment is undone.

The local upper counts all cells not yet eliminated by these permanent
obstructions, currently present arrows, or the diagonal. A future direct
arrow can only remove a counted cell, so incomplete rows are safely
overcounted. The separate cap `n(n-3)` is valid for a completed degree-two
graph. Thus pruning at `local_upper()<=threshold` discards only graphs
whose I is at most the threshold, here 50.

**Completion and maximum.** The timeout sets `complete=false` and interrupts
all recursive layers; only a receipt with `complete=true` supports full
coverage. The frozen run reports all 12 partitions completed, 5,652,419
nodes, and 289,163 exact game evaluations. Its maximum among evaluated
graphs is 53. Together with the <=50 bound on every pruned branch, this
proves the regular-family upper 53. `upper_if_complete` must never be read
as an upper bound from an incomplete run.

**Independent bounded check.** `src/small_plateau_regular_review.py`
enumerates all ordered pairs of disjoint derangements at n=3,4,5, evaluates
each full graph, and checks every assignment prefix using an independent
set-based transcription of the permanent-obstruction bound. It also
replays the literal n=10 witness with both original game solvers and saves
source hashes and the frozen completed receipt. Its adjacent JSON result
records the counts. This supplements the ordinary source audit; it is not
claimed as an independent full n=10 enumeration.

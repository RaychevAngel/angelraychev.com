# Explicit prime-field parabola constructions

## Result

For every prime `p>=5`, the four moves `(t,t^2)` with parameters
`t in {1,-1,-2,-3}` give a universally winning graph on `F_p^2`.
Every supergraph obtained by adding arbitrary arcs from the full parabola
graph (all nonzero parameters) remains universally winning. Consequently

`M(p^2,m)=p^2(p^2-1)-m`

for every integer `4p^2<=m<=p^2(p-1)`. Theorem 34 extends the lower
endpoint to `3p^2` when `p>=11`. Thus an explicit consecutive interval
reaches `m=n^(3/2)-n` at prime-square orders. The full conjecture down to
`2n` remains unresolved.

The construction and proof were derived during the current assistant
follow-up and independently checked. They are not attributed to the
original Angel/Alexandra work. The full manuscript proof is Theorem 35
in `paper/parabola-family.md`. No new Lean theorem is claimed.

## Key proof checks

1. The closed outgoing neighborhood is a translate of the full parabola
   `A={(t,t^2):t in F_p}`, including its zero point for waiting. Its
   nonzero ordered differences are unique: from `(t-s,t^2-s^2)` recover
   the difference and sum of `t,s`, then divide by two. Thus distinct
   closed outgoing neighborhoods overlap in at most one vertex.
2. Two distinct universally winning successors suffice to make a source
   winning. At most one is accessible to any other initial cop, so the
   messenger can choose a successor surviving the entire cop response.
   There is no arrival-before-response shortcut at intermediate vertices.
3. The three distinct core moves
   `u=(1,1)`, `v=(-2,4)`, `h=(-3,9)` satisfy `h=u+2v`.
   A quartet `Q(z)={z,z-u,z-v,z-u-v}` propagates to `Q(z-h)` by four
   applications of the preceding rule. `Q(0)` is initialized from the
   target and its direct predecessors.
4. Iteration fills the whole line `L={lambda*h}` because the field is
   prime. The fourth move `w=(-1,1)` satisfies `w-v=-h/3 in L`, while
   `det(h,v)=6!=0`. Whenever the whole coset `L+z` is winning, both the
   `v` and `w` successors of each vertex in `L+z-v` are in that winning
   coset. One safe-branching step fills the next coset. Repeating covers
   all `p` cosets, and therefore the entire graph.
5. Every actual closed neighborhood in a graph between the uniform
   four-move core and the full parabola graph is a subset of its full
   parabola translate. Its intersections remain at most one, so the
   proof survives arbitrary extra arcs. The core supplies the shifted
   proof for every recipient; the extra arcs need not have any symmetry.

All denominators and the four distinct moves are valid at every prime
`p>=5`, including `p=5`. The prime-power extension is not established:
integer multiples in an extension field cover only its prime subfield.
The proof yields the conservative finite bound `5p-3` messenger moves.

## Reproducible finite checks

Run:

```sh
python3 src/parabola_cayley.py
```

The script checks `p=5,7,11`, corresponding to graph orders 25, 49, 121.
It verifies the full parabola's closed-neighborhood intersection bound
directly and then computes the four-move core's safe-branching closure
from recipient zero and its direct predecessors. All vertices enter
the closure, at maximum ranks 4, 8, and 18 respectively. The translated
core rank proof covers every other recipient in every intermediate graph.
The ranks certify finite delivery bounds; they are not claims of optimal
delivery times.

The checker also adds the remaining parabola arcs in a fixed order and
checks all 827 resulting integer budgets across the three primes. Each
graph contains the entire core and lies inside the full parabola graph.
This is a structural preservation check, not 827 independent runs of the
full pursuit-game solver; the distinction is explicit in the receipt.

At `p=5` the script also runs both independent full game solvers, with
all explicit alternating-game rank certificates checked. They confirm
universal delivery to all 25 recipients and `I=500`.

The receipt `research/parabola-cayley-checks.json` contains the complete
bootstrap ranks, summaries of the full-game verification, and hashes of
the checker and game solver. The all-prime theorem rests on the ordinary
proof, not on extrapolation from these three checks.

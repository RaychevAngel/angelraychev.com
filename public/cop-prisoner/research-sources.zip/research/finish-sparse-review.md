# Independent review of the nineteen-/twenty-arrow completion

13 September 2026. Reviewer: small_case_completion_strategy, independently
of the sparse_finish producer lane. The frozen twenty-arrow manifest and
its source/result hashes were checked before review. No canonical source,
ledger, manuscript, or handoff is edited by this review.

## Decision

The supplied evidence supports the all-graph conclusions

    M(10,19) <= 53,
    M_E(20) = 53,
    M(n,20) = 53 for every n >= 10.

The harmless-sink extension then also gives `M_E(19)<=53`. The separate
ordinary global-nineteen argument in `sparse_finish_nineteen_global.md`
is sound and supplies a noncircular route to the same upper bound.
No exact nineteen-arrow value is asserted. The new literal witness at
nine vertices gives35, so the reviewed global interval is35..53.

These conclusions use the already reviewed comparison-host reduction,
eighteen-arrow upper44, ten-vertex regular maximum53, and both directional
one-transfer upper53 results. Those inherited results were read and their
receipts are hashed in `finish-sparse-review.json`; their large enumerations
were not rerun during this review. The53 lower witness was independently
replayed directly against all2,000 alternating-state obligations.

## Independent all-graph reduction

The positive-degree cases can be classified directly without relying on the
new profile producer's pruning implementation. If support is N and all
degrees are positive, the number q of outdegree-at-least-two vertices and
the number r of indegree-at-least-two vertices obey `q,r<=m-N` unless they
already equal N. The eligible rectangle is bounded by

    qr - max(0,q+r-N) - max(0,2q+2r-m).

At N=10,m=19, a score above53 forces q=r=9. Degree sums then force one
degree-one vertex and nine degree-two vertices in each direction. At
N=11,m=20 the same argument forces q=r=9, hence two degree-one vertices
and nine degree-two vertices in each direction. At N=10,m=20, the only
remaining positive-degree possibilities are the regular family, either
single directional transfer, either directional double transfer (one
degree4 or two degree3 vertices), and a single transfer in each direction.
The new direct enumerator covers all11 joint degree multisets of the last
families. Regular and single directional transfers are inherited cases.

For additional arithmetic control, `finish_sparse_review.py` independently
enumerates the full count tuples, importing neither the producer nor its
support helpers. It reproduces exactly6,12,47 tuples at10/19,10/20,11/20,
including4,8,9 positive-degree tuples respectively. Surviving count tuples
are necessary shapes, not claims of graph realizability.

The source/sink cases admit a shorter independent argument than the frozen
primary case list. Delete an actual nonisolated source or sink v, whose
other degree is d. For every surviving source/recipient pair, restrict the
cop to the remaining graph. An old messenger cannot enter a deleted source;
entering a deleted sink cannot deliver to an old recipient. Consequently
the old indirect count is bounded by that in G-v. The removed row/column
contributes at most `N-1-d` additional pairs. If d=1 it contributes zero.

At19 arrows and N<=10, d=1 leaves an18-arrow graph with score<=44; d>=2
leaves at most17 arrows and contributes at most7 pairs, hence<=51 using
the18-arrow upper and harmless padding. At20 arrows and N<=11, d=1 leaves
at most a10/19 graph, now bounded by53; d>=2 leaves at most18 arrows and
contributes at most8 pairs, hence<=52. Isolates are removed first. This
covers every zero-degree profile without assuming strong connectivity or
reversal invariance. It removes actual sources/sinks, never arbitrary
vertices with zero indirect rows or columns.

Harmless padding adds one fresh sink with one incoming arrow. Old winning
strategies remain valid while the cop stays old; once the cop exits, or
starts in the sink, any old route reaches the old recipient. Old losses
retain a cop confined to the original graph; a messenger cannot escape
through a sink and return. The new indegree-one sink has no indirect
column or row. Thus the operation preserves the score and implies global
budget monotonicity.

At20 arrows, support at most9 has at most52 missing pairs. The approved
host compression reduces every larger host to at most11. The cases above
therefore cover all graphs. The saved53 graph on10 vertices, plus isolates,
proves equality globally and at every host at least10.

## Matching coverage and vertex symmetry

For10/19, the bipartite incidence graph has maximum degree2 and exactly
two degree-one endpoints, one on each side. Its one path has odd length;
all other components are even cycles. Alternating colors give matchings
of sizes10 and9. The perfect matching is a loopless directed permutation.
Every cycle partition is retained. Rotations within cycles and permutations
of equal cycles normalize the omitted residual row to one representative
of each cycle length. No omitted-column orbit is discarded.

For11/20, the incidence graph has four degree-one endpoints and exactly
two path components. Even paths balance individually. If the paths are
odd, flipping one path's colors balances their excesses. This supplies
two matchings of size10. A size10 directed partial permutation on11
vertices has exactly one directed path, allowing a single isolated vertex,
and otherwise cycles. The path is rigid under automorphisms; every allowed
position on it is a distinct omitted-row representative. Equal cycles
may be permuted and rotated. The second matching must omit a row other
than the first path's end and a column other than its start, or a zero
degree would result; these are exactly the code's exclusions. Loops and
duplicate arrows are rejected, and all remaining injections are listed.
All overlaps of the two low-in and low-out sets survive this normalization.

Independent arithmetic gives12 first-factor types and220 patterns at10/19,
and42 types and1,640 patterns at11/20. Exhaustive labelled controls at
orders3..5 independently compare every positive maximum-degree-two graph
against all suitable matching unions. All10,909 graphs across six controls
are covered, including every balanced-factor case tested.

The coupled-degree enumerator assumes no matching. After a row prefix is
assigned, future vertices of the same joint degree and identical incoming
prefix may be freely permuted while fixing all assigned vertices: no
outgoing row of a future vertex has been assigned. Selecting each possible
count from each class, using a prefix inside the class, therefore retains
a representative of every completion. Current-row self loops are excluded
separately. An independent comparison against every labelled positive
four-vertex graph at budgets6,7,8 covers all65 isomorphism classes across
39 joint degree patterns. Its canonical-prefix generator produces84 leaves.

## Permanent pruning and actual game

Source camping is tested only for a finished active source and a different
initial cop vertex. If every genuine first move lies in the cop's fixed
closed outneighborhood, the cop waits until the messenger moves and then
captures before any nonadjacent recipient can be reached. This destroys
the whole eligible row. Waiting does not evade eventual-delivery failure.

Predecessor camping is tested only after an active recipient's predecessor
set is complete. The cop waits, then captures first entry into that set.
An eligible source is not already a predecessor, because such a pair would
be direct. The one possible initial-source/cop exception is explicitly
allowed in the loss lower bound. Minimum permanent losses are6 for a row
and5 for a column in the degree-one/two families; in the coupled family
they are at least5 and4 respectively. These exceed all available loss
allowances at target54, including eligible count58 in the two-defect family.
The code uses only fixed cop arrows, so these obstructions survive every
remaining assignment.

The guarded filter gives unfinished messenger rows every still-possible
arrow, and the cop only fixed arrows. It computes paths whose intermediate
vertices avoid a camping cop's closed outneighborhood. The initial source
is treated separately, and final recipient arrival is allowed even inside
that closed neighborhood. Failures are accumulated as a union across cops.
Every possible future direct arrow was already offered to the optimistic
messenger, so a counted failure cannot become direct in a completion.
Subtracting these failures from the active eligible upper is sound.

The primary actual game uses the least winning fixed point seeded at
recipient receipt. It includes waiting, all initial cops except the source,
and collision failure outside the recipient. Its early upper subtracts
exactly the remaining eligible column counts. This review replaced that
entire leaf evaluation with an explicit alternating reverse-edge attractor
which evaluates every recipient and every missing pair, without that
remaining-column shortcut.

| Family | Full replay nodes | Independently evaluated leaves | Guard samples |
|---|---:|---:|---:|
|10/19 one defect|607,500|267|34|
|10/20 coupled degrees|940,202|341|51|
|11/20 two defects|59,613,217|18,678|159|

Every replay completed, with exactly the original node and prune counts.
All19,286 complete leaf games reject scores above53. Their maximum scores
are20,42,41 respectively, but these are only maxima among surviving leaves;
they are not maxima over the full graph families. At244 sampled guarded
rejections, the independent optimistic mixed game verifies all2,230 claimed
permanent losing pairs, and each such pair is also absent from every
optimistically possible direct arrow. There were no failed checks.

Forced tiny-timeout controls stop each traversal at16,384 nodes and return
exit status1 with `complete=false`. The numeric `upper_if_complete` field
alone is never accepted as proof. The completed receipts have
`complete=true`; every outer family loop and recursion propagates a stop.

## Global nineteen upper and evidence boundary

The separate global-nineteen extension is also correct. A degree-one
source/sink leaves18 arrows and contributes zero. For other source/sink
degrees, deletion leaves at most17 arrows; the retained small odd-budget
theorem gives41 at17, and the removed row/column has at most9 active
recipients/sources. Thus these graphs score at most50. If all degrees are
positive on at least11 vertices, q,r<=8 and the rectangle gives at most51.
Support10 uses the new finite upper53; smaller support uses missing pairs.
The inherited17-arrow claim is the proposition at
`paper/odd-endpoint-resume.md`, lines447 onward. Independently, nineteen's
upper53 follows directly from the newly reviewed twenty-arrow equality
and harmless padding.

This review contains an independent ordinary coverage/pruning argument,
independent arithmetic, complete small-family controls, and a complete
large replay with a distinct game implementation. The large graph
generation and pruning traversal remain those of the reviewed producer;
this is not a second independently designed large graph enumeration.
The guarded mixed-game checks are sampled and their exact counts are
reported. The source-pinned receipt is `finish-sparse-review.json` and its
reproducer is `src/finish_sparse_review.py`. No Lean formalization or
publication/deployment claim is made.

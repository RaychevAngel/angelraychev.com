# Eighteen arrows: complete positive families and global reduction

This is a proposed ordinary proof for independent review, not an incorporated
result. Its conclusion is `M_E(18)=33` and `M(n,18)=33` for every `n>=9`.
It depends on the separately proposed bounds `M_E(15)<=15` and `M_E(16)<=19`
in `research/finish_budget_proof.md`; the weaker premises `<=26` and `<=25`
would suffice. No strong connectivity or positive-degree assumption is imposed
on the final result.

## Removing zero-degree vertices

Delete isolates, which preserve the score. If an actual source has outgoing
degree `d`, every guaranteed old pair is bounded by the graph with that source
deleted: an old-source messenger cannot enter it, and the cop can stay in the
remaining graph. Only the deleted source's row can contribute additional pairs.
Every live recipient column requires two predecessors of positive indegree;
otherwise a cop can camp on its sole usable predecessor. That predecessor
cannot be the initial source of an indirect pair, since such a pair would be
direct. The `d` removed arrows supply no such predecessors. Hence

`I(G) <= M_E(m-d) + floor((m-d)/2)`.

For an actual sink, old-target winning play never needs to enter the sink,
because the messenger could not leave it. Every live source row requires two
nonsink successors; with only one the cop camps on it. The arrows entering
the deleted sink supply no nonsink successors. This gives the same inequality
in the original game direction, without invoking reversal of arrows. At
`d=1` the deleted row or column contributes zero, giving `M_E(m-1)` instead.
Smaller budgets are bounded by larger ones by adjoining a new sink with one
incoming arrow; this preserves the old score exactly.

At budget 17, a graph with an actual source or sink therefore has
`I<=max(M_E(16),M_E(15)+7)<=22`. At budget 18, it has
`I<=max(M_E(17),M_E(16)+8)<=max(M_E(17),27)`.
It remains to prove that all-positive graphs at both budgets have score at
most 33. This proves `M_E(17)<=33` first and then `M_E(18)<=33`, without a
circular dependency.

## Finite support ranges

On a support of size `N` with every indegree and outdegree positive, let
`A={v:d+(v)>=2}`, `B={v:d-(v)>=2}`, and let their sizes and overlap be `q,r,b`.
All degrees outside each active set equal one. Thus

`q,r <= min(floor(m/2),m-N)`,

`e(A,B)=m-2N+q+r+w`,

where `w` counts arrows from the complement of `A` to the complement of `B`.
The number of eligible pairs is at most

`q*r-max(0,q+r-N)-max(0,m-2N+q+r)`.

For `m=17,N>=11`, this is at most 28; for `m=18,N>=12`, at most 30.
For `N<=8`, the already reviewed vertex bound `M_V(8)=32` applies
(`paper/small-orders-resume.md`). Only positive supports 9 and 10 at budget17,
and 9,10,11 at budget18 require finite exclusions.

## Complete profile and adjacency coverage

The finite engine generates every decreasing positive outdegree partition of
`m` into `N` entries. It assigns a positive indegree partition to those vertices,
sorting incoming degrees only within equal-outdegree classes. This gives every
joint-degree multiset. A partial multiset is discarded only when the eligible
upper is already at most33; its current overlap is a lower bound for the final
overlap. All surviving multisets are enumerated in sorted order.

Outgoing adjacency rows are then assigned completely. Earlier vertices are
individual choices. Future vertices of the same desired degree pair and the
same incoming prefix are interchangeable while all completed rows are fixed.
Taking a prefix of each such class for every possible subset cardinality
therefore preserves a representative of every graph orbit. Loops are excluded,
both arrow directions are independent, and residual indegree capacities are
checked. The search needs coverage, not unique isomorphism generation.

The eligible upper subtracts already assigned complement-to-complement arrows.
Permanent camping losses are counted as a union. A completed source row loses
if all its successors lie in a different cop's closed outneighborhood. A
completed target column loses if all its predecessors lie in a cop's closed
outneighborhood, with the initial-source-equals-cop exception retained. A loss
is counted only for distinct, nonadjacent active pairs. In an unassigned row,
a counted column loss concerns a full target column, so the pair cannot later
become direct. Consequently it cannot double count a future direct arrow.

The guarded reachability bound gives the messenger every individually possible
future edge and retains only fixed cop edges. For each stationary cop it allows
the initial escape, computes internal reachability outside the cop's closed
outneighborhood, and permits the final target edge with receipt priority.
Failure even with these additional messenger edges is permanent. Its failure
union includes only pairs that cannot become direct. At leaves, a synchronous
game attractor evaluates the actual remaining graph; an early exit is allowed
only when the current score plus all eligible unprocessed pairs is at most33.

The engine's exhaustive small controls compare its generated isomorphism-class
set with all labelled positive-degree graphs through four vertices, across
14 order/budget cases and96 isomorphism classes. These are implementation
controls, not an independent proof of the larger search or of its pruning.

## Receipts and known discarded shortcut

| Case | Complete degree profiles | Game decisions | Receipt |
|---|---:|---:|---|
|9,17|8|27|`sparse_finish_positive_n9_m17_t33.json`|
|10,17|1|0|`sparse_finish_positive_n10_m17_t33.json`|
|9,18|48|1620|`sparse_finish_positive_fullmax_n9_m18_t33.json`|
|10,18|13|64277|`sparse_finish_positive_n10_m18_t33.json`|
|11,18, profiles1–2|2|1443|`sparse_finish_positive_full_n11_m18_t33_p1_2.json`|
|11,18, profile3|1|6105|`sparse_finish_positive_n11_m18_t33_p3.json`|

Every listed range is complete, with no score above33. For the corrected9/18
receipt the working threshold stays33 throughout. Dynamic threshold updates
are allowed only after a literal larger game score has been obtained; none
occurs here. The11/18 ranges1–2 and3 are disjoint and cover all three profiles.

The original9/18 receipt `sparse_finish_positive_n9_m18_t33.json` is explicitly
excluded: it incorrectly skipped three whole families using bounds that only
covered their camping-free subfamilies. The corrected full source removes all
inherited skips, and its complete9/18 receipt covers those three families too.
The other old-source receipts above invoke zero inherited skips. The timed
11/18 prefix receipt is also excluded in favor of the completed range1–2.

## Attainment

The literal graph in
`research/finish-sparse-lower-n9-m18-seed2026091498-certificate.json` has18
distinct loopless arrows and33 guaranteed indirect pairs. Its complete ranks
and closed losing regions pass the independent fixed-certificate checker in
`research/sparse_finish_eighteen_lower_review.json`, with1458 alternating-state
obligations. Adding isolates preserves its score. Thus the proposed global
upper matches a literal attainer at every host of order at least9.

# Independent review of the common interface and eight terminal types

Date: 2026-09-13. Reviewed checkpoint:
`research/composition-interface-terminal-checkpoint.md`.

**Conclusion:** the eight-type conditional theorem is sound. The common
twelve-exclusion interface, all seven finite rank certificates, lane
symmetry, and the finite-horizon branch projection pass independent review.
On a qualifying quotient of girth at least 133 and negative-generator
directed diameter D, every recipient of type 0,1,3,4,5,6,8,9 is deliverable
from every source and uncaught initial cop position within 32D+64 messenger
moves. Types 2 and 7 remain open. This is not universal delivery, an
all-order construction, or a new assertion about M(n,m).

## Independent finite proof replay

The verifier `src/routing_defect_phase2_terminal_audit.py` imports none of
the primary arena, attractor, interface-synthesis, or terminal-checkpoint
code. It reuses only the previously independently written literal ten-type
rules and elementary free-word functions. From those rules it reconstructs
all represented states, ordinary exterior states, twelve prefix classes,
messenger moves, and every cop response. All reconstructed transitions
agree with the stored archive.

It independently checks the exact seed of every module. Safe-interface
seeds exclude collisions and the twelve listed relative states. Terminal
seeds contain every cop position at the specified recipient, so receipt
may precede a cop response or collision. At every nonterminal newly
winning state, the verifier checks an actual messenger action and all cop
responses in the preceding layer. Moving onto the current cop is excluded
except when that move delivers directly to the terminal recipient.

All 825,843 newly entering states pass. The checked modules are:

- Normalization: two moves, all 5,390 uncaught initial states.
- Each negative-generator navigation module: 32 moves, all 5,378 starts
  in the common interface.
- Type 0 at the positive-a neighbor: 39 moves, 5,378 starts.
- Type 1 at the negative-a neighbor: 62 moves, 6,478 starts.
- Type 3 at the second negative-a neighbor: 35 moves, 5,378 starts.
- Type 4 at the negative-a neighbor: 38 moves, 6,478 starts.

The larger terminal start count includes all 120 prefix/type exterior
descriptions. At an anchor, none can coincide with a forbidden relative
location, since every exclusion lies at distance at most one. Safe endpoint
seeds and normalization seeds are also correct: every potentially forbidden
cop cell is still represented in the ordinary radius-three cop window.

Both literal arc permutations are equivariant under interchanging a,b
and shifting every type by five. The twelve exclusions have exactly the
same symmetry. This derives the other four recipient statements. It is
a symmetry of the **parameterized rule scheme**; no automorphism of a
particular fixed quotient interchanging its two permutations is needed.

The original source hashes and archive hash all match. The new receipt is
`research/composition-interface-terminal-independent-audit.json`.
The verified archive has SHA256
`e9deeda4964c96504843d1997f2647df5ec8030340361bd3386ed2820e5f7ef1`.

## Finite-horizon branch projection

The ordinary typed-exterior arenas use the already audited local projection.
Allowing the messenger radius to be three still only requires identifying
represented cells and adjacent cells through radius four.

For the two prefix-aware terminal modules, take R=3 and the module's
fixed move bound T. Assume the ball of radius L=R+T is an induced tree.
At messenger-turn time t, a cop is relevant when its true quotient
distance from the anchor is at most R+T-t. A single cop move changes
this distance by at most one. Therefore, once

    distance > R+T-t,

the cop remains irrelevant at all later times and cannot enter the
represented radius-R ball before the deadline. This uses actual graph
distance, so even an outside shortcut cannot defeat the argument.

While the cop is relevant, its relevant transitions are edges of the
induced radius-L tree. Outside the represented ball, appending or deleting
a final free-word letter cannot change the first two letters without
passing through that ball. Represented-to-exterior transitions therefore
have exactly the prefix specified by the arena, and exterior reentry
satisfies its generator/predecessor-prefix test. Waiting and internal
type changes preserve the prefix.

An initially irrelevant cop may be assigned any fixed exterior prefix,
with its actual type. A cop becoming irrelevant while exterior retains
its last prefix. If irrelevance begins on a departure from a represented
cell, initialize the frozen prefix from that departure edge. The last
sentence clarifies the checkpoint's phrase "retain its last exterior
prefix"; it does not require a new hypothesis. Every later action maps
to a permitted exterior transition with the true successor type. Since
such a cop never reenters the represented ball during the remaining
time, the chosen frozen prefix cannot conceal a collision.

This projection is causal: it uses the current position, elapsed time,
and an already fixed prefix, not future choices. It handles arbitrary
history-dependent cop play. It can be restarted at each terminal module,
so it does not require the whole preceding navigation route to lie in a
single tree ball.

The largest T is 62, hence L=65. A simple quotient of girth at least 133
has an induced radius-65 ball at every anchor: an extra edge in that ball
would give a cycle of length at most 131. Thus the stated bound is
conservative and sufficient. The same girth assumption also supplies the
ordinary local projection for navigation and the other terminal modules.

## Composition and the remaining gap

Normalization ends in the common interface within two moves. Each chosen
negative-generator quotient step takes at most 32 moves and ends safely
in that same interface, after the cop response. Navigate to the terminal
module's anchor, then use its at-most-62-move strategy. This proves
2+32D+62=32D+64. The target-dependent anchors in the checkpoint are correct:
ya^{-1} for type 0 at y, ya for types 1 and 4, and ya^2 for type 3,
with their lane mirrors for the other four types. If receipt occurs
earlier, play simply terminates earlier.

I also checked the stated infinite-tree obstruction for type 2. Its
predecessors are 6_x and 1_(xa). A cop at 0_x controls 6_x and the
only entry head 0_(xa) across the free-tree edge from x to xa.
Starting at 1_x is an allowed common-interface state, but neither
predecessor is safely reachable while the cop camps. This blocks that
particular universal terminal module on the infinite lift. It does not
prove failure on a finite quotient, where an outside detour may exist.

The additional last-generator/interface diagnostic is not certified in
this archive and is not included in the reviewed positive theorem.
No Lean formalization, universal point delivery, optional-arc robustness,
or explicit qualifying expander family is asserted by this audit.

# Exact seventeen-arrow values

13 September 2026. The root ordinary review and independent finite leaf review
establish

    M_E(17)=28; M(9,17)=24; M(n,17)=28 for n>=10.

For support at most8, the already exact eight-vertex row gives upper19.
Remove isolates. If a vertex has zero indegree or outdegree and other degree1,
its deletion gives at most M_E(16)=19. If the other degree d>=2, the independently
reviewed source/sink comparison gives

    I(G)<=M_E(17-d)+floor((17-d)/2)<=M_E(15)+7=22.

The new14–16 package has passed the ordinary and finite reviews; in particular
M_E(15)=15. For positive support N, active out/in counts q,r<=min(N,17-N),
and the exact active rectangle is bounded by

    qr-max(0,q+r-N)-max(0,q+r+17-2N).

For all N>=11 this is at most28. For N>17 there is no positive-degree graph
with17 arrows. Thus only positive supports9 and10 remain.

The frozen positive joint-degree enumerator covers all80 eligible multisets
on9 vertices at threshold24 and all8 on10 at threshold28. Both exclusions
complete. The separately regenerated pattern lists coincide exactly; all21,382
and5,280 respective leaf games are replayed using an explicit two-turn alternating
attractor, with identical traversal counters. Sound coverage and pruning are the
same frozen positive engine reviewed in `finish_budget_proof.md` and approved in
`finish-budget-ordinary-review.json`. Separate17 evidence is in
`finish_eighteen_review_seventeen.json`. No source-to-sink exclusions or other
zero-degree-only assumptions enter these positive runs.

Literal full-state certificates in `finish-sparse-new-lowers.json` attain24 on
9 vertices and28 on10. Isolates extend the latter to every larger host. No smaller
host attains28 because the nine-vertex upper24 is strict. This is an ordinary
reduction plus reviewed finite computational proof, not a new concrete Lean
instantiation or a second independently implemented complete graph enumeration.

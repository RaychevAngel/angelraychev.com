# Independent review of the exceptional n11 predecessor column

**PASS:** the ordinary reduction and complete normalized enumeration support
M(11,24)<=80, when combined with the separate complete camping-free upper79.
The current lower witness has I=79; this audit does not choose between79 and80.

Suppose a graph at n=11,m=24 has I>=81. If any indegree or outdegree is below
two, at most ten eligible rows or columns each contribute at most eight,
giving I<=80. Thus every degree is at least two and at most four.
There are 86 missing pairs, so at most five may fail.

Source camping makes a whole indirect row fail, losing at least10-4=6
pairs. It is impossible. For predecessor camping at recipient t, the
column has10-indeg(t) missing pairs. A covering cop c makes all these
pairs fail except possibly the one whose source is c. Indegree at most
three therefore loses at least six. Thus indeg(t)=4 is necessary.

The exception must itself be an indirect pair: c!=t and c is not a
predecessor of t. Otherwise all six missing pairs in this column fail.
The four predecessors are consequently disjoint from c, so a closed cop
neighborhood covering them requires outdeg(c)>=4. The degree bound forces
outdeg(c)=4 and O(c)=P(t). All remaining outdegrees and indegrees are two,
because the total surplus on each side is exactly two. Every other target
has indegree two, and any covered predecessor column there loses at least
eight minus one = seven pairs. Those other camping columns are impossible.

Simultaneous relabeling now fixes c=0, t=1, P(t)={2,3,4,5}. The remaining
vertices6..10 are unrestricted labels. Row0 is exactly{2,3,4,5}; rows2..5
must include target1; every other row must exclude target1; rows1..10
have exactly two distinct nonloop neighbors. Target1 has incoming cap4;
all other targets have cap2. At a completed assignment these caps enforce
the exact prescribed indegrees, since total indegree is24.

The producer correctly partitions future vertices by immutable color
(target, predecessor, or other) and incoming pattern. Prefix selection
within these cells preserves a representative, by the same inductive
relabeling argument as the general row-prefix enumeration. Colors preserve
the prescribed row0 arrows and which rows must point to target1.

A full other predecessor column covered by a completed cop row is a
permanent forbidden obstruction. A source row covered by another completed
cop row is likewise forbidden. The source and predecessor tests never
exclude the permitted exceptional target1 camping relation itself.
Incoming caps and the count of remaining possible nonloop tails are
necessary conditions for every completion.

The independent Python replay uses literal sets, combinations of neighbors,
and explicit future-cell lists rather than producer bit masks or its
adjacent-cell test. It imports neither producer nor game solver. It visits
all14,248 nodes and obtains zero complete leaves, matching the frozen C++
receipt. Hence no normalized exceptional graph survives the necessary
other-row/column conditions; no actual-game bound is needed for this class.

The complete target80 run of the separately audited camping-free enumerator
gives I<=79 in that class. Every hypothetical I>=81 graph is either in
that class or in the normalized exceptional class, now excluded. Thus
M(11,24)<=80. This conclusion uses the completed lower-target camping-free
run, not the earlier target86 run's best evaluated score.

Reproduction: `python3 src/small_plateau_exceptional_review.py`.
The adjacent JSON receipt records counts and source hashes. The reviewed
producer is `src/small_loss_exceptional_column.cpp`; its included
`small_loss_profiles.cpp` supplies only shared helpers at these zero leaves.

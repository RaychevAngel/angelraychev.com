# Independent review of the small dense reductions

13 September 2026. Root review, separate from the construction/exclusion author.

The safe-root replacement, third/fourth-step equality reductions, and the
second-step defect-three split have passed ordinary proof review. Their fixed
positive graphs have additionally passed the literal alternating-rank checker.
The approved consequences at this checkpoint are:

- Exact third steps `(7,31)=7`, `(8,43)=9`, `(9,57)=11`.
- Exact fourth steps `(7,32)=6`, `(8,44)=8`, `(9,58)=10`, `(10,74)=12`.
- Exact second steps `(7,30)=8`, `(8,42)=10`, `(9,56)=12`, `(10,72)=15`.
- The ordinary safe-root designation supplies the remaining eventual-band
  anchors at orders eleven and twelve, after checking their literal graphs.

The review explicitly retained capture at an unsafe root entry. Restricting
the pursuer's nonterminal positions to the core does not prevent it from
capturing a messenger who enters the root. Arrival at the root as the actual
recipient instead wins immediately. Confusing these cases would invalidate
the reductions.

For the fourth step, the degree-one count forces the four-vertex functional
path with three killed image rows. Every surviving core row avoids those
images, giving exactly the safe-root interface. For the third step, the only
additional possibility has three functional vertices and a two-out core;
with four functional vertices there is one excess missing arrow in the core.
The purported one-outside-image case duplicates a necessary unique image and
is impossible. These arguments do not assume any missing indegree condition.

For the second-step improvement, defect three permits two, three, or four
functional vertices. The four-vertex case has core excess two; the
three-vertex case has core excess one. With two functional vertices, either
they form a missing two-cycle, reducing to the already bounded ordinary
core, or form an open path. In the latter case, the killed path rows and
recipient columns force all remaining rows into an ordinary small core or
the corrected safe-root interface. The exception for a camping cop equal
to the initial source is absent from these killed columns because that
cop's sole missing recipient is outside those columns.

`src/small_case_rooted_review.py` independently expands every normalized
row choice using a different variable order and literal sets, without
importing a producer enumerator or game solver. It checks all 21 finite
normal-form/profile cases and all 18 surviving full-game negative rank
certificates. Complete surviving adjacency lists agree exactly. Every
positive rank step strictly decreases and every negative state has the
required closed avoiding response; receipt precedes collision. The receipt
is `research/small-case-rooted-independent-review.json`.

The endpoint two-loss exclusion was independently rerun through
`src/small_dense_endpoint_independent.py`: 227 and 4,307 prefix nodes at
orders seven and eight, with no surviving two-out missing graph. Each
rejected prefix carries an explicit source or recipient camping witness.
The nine-core positive control survives every prefix. Its depth-two normal
forms include both the mutual and nonmutual cases. This supplies the
endpoint premise used in the second-step proof.

The full proof dependencies are the rooted designation, rooted equality,
second-step, and two-free-root notes. This review does not prove a general
classification of rooted interfaces, an unrecorded first-step bound, or
full Lean formalization. Exhaustive finite coverage and the ordinary
reduction are distinct parts of the computer-assisted upper proof.

## First-step completion

The subsequent first-step proof also passed ordinary review. At defect two,
the degree-one image count leaves either a closed missing two-cycle with
an ordinary universal core, or a single functional row whose killed image
row and recipient columns force an ordinary or safe-root small core. The
only new ordinary-core premise is the universal `(8,39)` profile: missing
degrees must be exactly one three and seven twos. At `(8,41)`, defect three
has four possible counts of functional rows. The one-functional-row case
requires the direct forced-loss union check; the other three reduce to
the already excluded small cores or the three excess-three rooted profiles.

The independent set-based checker `src/small_case_first_step_review.py`
completed 189,190 prefixes for the universal eight-core, 12,160 and 9,934
for the two normalized single-functional-row cases, and 103, 78, 55 for
the three rooted degree profiles. Every case had zero leaves. Its two
forced-loss controls distinguish a transitive triangle's two failed pairs
from duplicate rows' four; the cop-equals-source exception is retained.
The positive graphs were independently checked by the literal rank verifier.

Together with the complete seven-vertex table, this approves
`(7,29)=8`, `(8,41)=11`, `(9,55)=14`, `(10,71)=16`.
The complete dense band is now determined at every admissible order, with
the uniform staircase from order eleven and explicit listed exceptions.
The new evidence remains external to Lean.

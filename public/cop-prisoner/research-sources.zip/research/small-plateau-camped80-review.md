# Independent review of all n11,m24 camping classes at target80

**PASS:** the43 normalized configurations in
`src/small_loss_camped_profiles.cpp` cover every predecessor-camping graph
that could have I>=80 at n=11,m=24. The complete frozen run
`research/small-loss-n11-m24-camped80.json` excludes all of them. Combined
with the separately completed camping-free exclusion and the saved79
witness, this proves **M(11,24)=79**.

This is an independent ordinary source/completeness audit. It does not
claim a second independent full enumeration of all43 configurations. The
earlier independent set-based replay already covers kind0 completely.

## Minimum degrees and loss budget

If exactly ten vertices have outdegree at least two, the remaining vertex
has outdegree at most one. At least23 of the24 arrows therefore start in
the ten eligible rows, whose total indirect capacity is at most100-23=77.
With at most nine eligible rows, capacity is at most9*8=72. The identical
incoming-degree count applies to columns. Thus I>=80 forces minimum
indegree and outdegree two. Both total degree surpluses are two, and each
degree is at most four. There are86 missing pairs, permitting six losses.

Source camping cannot occur. Its source would need outdegree at least
four to leave at most six missing pairs in its zero row. That source then
uses all outgoing surplus; every other cop has outdegree two, and a closed
neighborhood of size three cannot cover its four successors.

For predecessor camping at t, a covering cop c spoils every missing pair
in that column except possibly the one sourced at c. If indeg(t)<=2,
at least seven pairs fail, which is impossible. Hence indeg(t)=3 or4.
Any second camped column would lose at least six additional, disjoint
pairs; consequently all other columns must be uncamped.

## All five normalized kinds

1. **indeg(t)=4, c outside P(t) and c!=t.** The four predecessors must lie
   in O(c), so outdeg(c)=4 and O(c)=P(t). Normalize c0,t1,P(t)={2,3,4,5}.
   All other degrees on both sides are two. This is kind0.
2. **indeg(t)=4, c in P(t).** The cop must point to t because it is a
   predecessor, as well as to the other three predecessors to cover the
   column. Thus outdeg(c)=4 and O(c)={t}∪(P(t)\{c}). Normalize
   c0,t1,P(t)={0,2,3,4}. This is kind1, with all other degrees two.
3. **indeg(t)=4, c=t.** Looplessness puts c outside its own predecessor
   set. It must have outdegree four exactly to that set. Normalize c=t=0
   and P(t)={1,2,3,4}. This is kind2, again with all other degrees two.
4. **indeg(t)=3, outdeg(c)=4.** Losing at most six of the seven missing
   column pairs requires the cop-source exception to be an indirect pair.
   Hence c!=t and c is outside P(t). Normalize c0,t1,P(t)={2,3,4}.
   The fourth outgoing neighbor cannot be c, t, or a predecessor, and is
   normalized to5. There is one further indegree-three vertex u!=1;
   retaining all ten possible labels covers every relative position.
   This is kind3, giving ten configurations.
5. **indeg(t)=3, outdeg(c)=3.** The same cop-source exception is necessary,
   and O(c)=P(t), normalized to c0,t1,P(t)={2,3,4}. There is exactly one
   further outdegree-three vertex w!=0. Its three symmetry types are t,
   a predecessor, or an outside vertex, normalized respectively to1,2,5.
   For each, every label u!=1 for the second indegree-three vertex is
   retained, giving30 configurations. This is kind4.

These exhaust outdegree possibilities because a cop outside a three-vertex
predecessor set needs at least three outgoing arrows and every degree is
at most four. The total is3+10+30=43. Some labels can represent isomorphic
cases; this redundancy only enlarges the search.

## Row choices, colors, and pruning

Each configuration sets exact outgoing degrees D, exact incoming caps,
the exceptional target, its complete predecessor set, and row0. Every
other row is enumerated with exactly its prescribed number of distinct
nonloop neighbors. Its arrow to the exceptional target is mandatory
exactly when that row belongs to the prescribed predecessor set.
These conditions encode all fixed arcs and all forbidden incoming arcs
at the exceptional target; no additional graph property is assumed.

Colors preserve outgoing degree, incoming cap, exceptional-target status,
and predecessor membership. The incoming bitsets also preserve row0's
extra neighbor in kind3. The adjacent prefix test only permutes vertices
inside contiguous runs with the same color and completed incoming pattern.
It remains complete even when a distinguished cap splits a color into
separate runs: this uses a smaller permitted permutation group, retaining
more representatives. Prefix splitting preserves these runs inductively.
Global contiguity of every equal-color set is not required here.

The incoming feasibility check enforces exact caps and remaining possible
tails. For every other column, if a completed cop covers all existing
predecessors, an unassigned escaping predecessor must remain available.
Otherwise that forbidden camping obstruction can never be repaired.
The exceptional target is explicitly exempt from these cop tests. Source
camping between completed rows is always forbidden by the reduction above.
The flags and masks are restored under backtracking and reset between
configurations; the target-guard and exact-game checks only run at full
graphs, where every row is assigned.

The guarded-path bound and actual-game solver are the previously audited
functions from `small_loss_profiles.cpp`. In particular, the guarded-path
test allows the final receipt at an unsafe recipient and is only a
necessary upper filter. The source-level changes after the earlier run
affected entry/output metadata, not these shared functions.

## Completed inference

The frozen run has complete=true, found=false, all43 configurations,
113,000,606 nodes,603,453 complete leaves, and66,362 guarded-path survivors.
Its evaluated maximum is73, below80; the guarded-path filter certifies
all omitted complete graphs are also below80. Timeout or an early found
graph would instead make the output incomplete. Thus every camping graph
has I<=79. The separate complete target80 run proves the same for the
camping-free class, and the fixed witness attains79.

# Small sparse-budget research log — 13 September 2026

1. Read Theorems56,57,60 and the old one-diamond source/receipt. The old
   complete construction search was correctly not a promoted global bound.
2. First idea: exclude score81 by auditing the exactly-one-camping class.
   Stronger observation: source camping in a regular graph loses two full
   rows' worth, because a transitive triangle also destroys a recipient
   column. This made the reduction reusable across9,10,11.
3. Refined ordinary degree corners. The nested short active-set case cannot
   attain the old nonregular cutoff unless its two outside arrows somehow
   avoid an indegree-zero tail; with only one exceptional recipient that is
   impossible. This gives a one-unit unbounded improvement for k>=7.
4. Completed bounded enumeration replays, preserving scope. The11-vertex
   source replay matched all oldcounts andmax71, plus482 independent scalar
   game checks. Tiny justified9/10 replays supplied stronger regular caps.
5. Root independently attacked the ordinary proof and finite coverage/game
   recurrence and accepted them. The consequences improve five even-budget
   upper bounds, but do not close any exact case by themselves.
6. Root suggested retaining more diagonal/zero-row losses. This led to a
   different, stronger support reduction: above k²−5k+9, the original graph
   must fit on k vertices even when its degree pattern is not regular.
   The borderline q=r=k−1 case is resolved by splitting the two outgoing
   surplus units among0,1,2 and counting unavoidable sink predecessors.
7. Failed shortcut: claiming the regular shape below k²−4k+2. The nested
   q=k−1,r=k corner can instead be a k-vertex graph with one outdegree1
   vertex and one outdegree3 vertex, with indegree2 throughout. A new game
   argument or complete degree-family enumeration is required there.
8. Most promising next step is therefore a complete threshold-pruned
   enumeration of the eleven-vertex22-arrow degree families, rather than
   discarding their exceptions or searching arbitrary large supports.
   The bipartite matching decomposition still exists for the one-outdegree1,
   one-outdegree3 family: any source set emits at least2|S|−1 arrows,
   while each recipient has capacity2, so Hall's inequality follows.
   Removing a matching leaves one zero residual row, one two-entry residual
   row and all other residual rows/columns of size1. This is a concrete
   smaller family to attack next. No such enumeration was launched here.
9. Further unresolved support: at22 arrows, scores72–75 remain outside the
   new eleven-support forcing threshold. Proving that a graph beating71
   belongs to a complete tractable list remains a separate task.
10. Independently reviewed the root agent's all-parity code capacity and
    explicit generator as a sidecheck. The difference-two graph splits into
    two cycles for even core order; its product count and direct code listing
    are correct, including the small even core6. No graph-search step is
    present in that constructor.

11. Independent attack found a genuine gap in the proposed support cutoff
    k²−5k+8: some arrows entering sinks can start outside the active source
    set. That proposed stronger claim is withdrawn. The safe corrected
    cutoff is k²−5k+9. At the disputed equality, the active sets differ
    by three vertices each, and the two incoming/outgoing budget units
    force an outer source diamond and an outer recipient diamond. This is
    a concrete residual family, not an impossibility theorem. No global
    upper bound in the pass depended on the withdrawn stronger claim.

12. The discarded stronger support argument has now been repaired by an
    equality analysis, not reinstated on faith. At the disputed T+1 value,
    two outer diamonds are forced. Delivery between overlap-core vertices
    cannot use either outside diamond. The induced core must have every
    missing pair winning; the vertex bound forces all its outgoing arrows
    internal, contradicting required delivery to the outer recipient part.
    Root checked this mechanism and assigned another independent review.
13. New exact result: the11-vertex indegree1/3 transfer family produced79,
    attaining the reviewed global upper79 at22 arrows. Both solvers and all
    rank conditions agree. The outgoing1/3 family only reached56; this is
    a sharp reminder that game reversal is invalid. The exact22 theorem
    depends on a single frozen witness and the independently reviewed first
    cutoff, not on completeness of this new search or the repaired cutoff.
14. Tiny sequential8/9/10 transfer replays found no further attaining
    witness, but yielded complete finite family bounds that, with the
    repaired support theorem, reduce18/20 upper bounds to44/58. The14/16
    consequences become22/32. No exact claim is made at those four budgets.

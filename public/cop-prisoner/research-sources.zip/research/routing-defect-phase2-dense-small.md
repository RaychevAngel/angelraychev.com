# Bounded completion of the small robust dense envelopes

Date: 2026-09-13. This completes the finite order gap in the robust
two-move missing-arc construction; it is not a classification of all
possible envelopes on these orders.

The parent requested a bounded greedy attempt at orders 19,20,21 after
uniform optional offsets had failed at order 20. I retained the existing
two-in/two-out compulsory missing graph B and considered all other
nonloop missing arcs in a random order. An arc was added only when every
full-envelope pair still had a safe witness among the cop's compulsory
neighbors. Only pairs in the changed source row or recipient column need
rechecking after a single insertion. A final complete criterion check
guards that incremental implementation.

The first order tested at each size succeeded, producing respectively
23,30,31 optional arcs. Taking the first 19,20,21 gives the required
exact envelopes. The search took about 0.01 seconds. These are explicit
finite constructions, not probabilistic existence claims.

A further request allowed at most five greedy orders per core at sizes
10 through 18. Orders 16,17,18 produced respectively 16,17,21 optional
arcs, within two, one, and one tries. The valid attained optional counts
at 10,11,12,13,14,15 were 0,1,0,4,7,11. Those smaller counts are research
evidence only: no impossibility statement about their orders is inferred,
and the search was stopped at the authorized boundary.

For every saved full-envelope pair (s,t) and legal initial cop c, the
archive records an explicit vertex u such that

    (c,u) belongs to B,
    (s,u),(u,t) do not belong to the full missing envelope F,
    u is distinct from s,t,c.

These conditions prove two-move delivery for every intermediate missing
graph between B and F: the messenger's two arcs remain available, while
the cop's arc to u remains missing. Waiting cannot capture u either.
There is consequently no need to enumerate all optional subsets.

Separate readback verifiers import neither the producer nor its graph
helpers. They check the vertex bounds, exact compulsory and optional
counts, both compulsory degrees, every witness, and complete pair/cop
coverage. They passed for all saved envelopes. At order 18 the full
archive has 21 optional arcs, and the displayed 18-arc subset inherits
the stronger full-envelope witnesses.

Artifacts:

- `src/routing_defect_phase2_dense_small.py` and
  `research/routing-defect-phase2-dense-small-checks.json`.
- `src/routing_defect_phase2_dense_small_verify.py` and
  `research/routing-defect-phase2-dense-small-independent.json`.
- `src/routing_defect_phase2_dense_tiny.py` and
  `research/routing-defect-phase2-dense-tiny-checks.json`.
- `src/routing_defect_phase2_dense_tiny_verify.py` and
  `research/routing-defect-phase2-dense-tiny-independent.json`.

Together with the previously established families from order 22, this
proves an arbitrary-subset, two-move envelope for every order n>=16 and
every missing count 2n<=h<=3n. Combined with H5/H4 from order 30, the
envelopes now subsume every numerical domain of the old Theorem 48,
including its former last small fragments at orders 19,20,21. This does
not erase the independently useful generic safe-witness criteria that
supported that earlier construction.

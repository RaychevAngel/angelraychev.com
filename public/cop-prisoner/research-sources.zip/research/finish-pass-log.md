# Completion pass, 13 September 2026

Objective: close the 101 canonical numerical gaps and supply explicit attaining
graphs, preserving every existing theorem and construction guarantee. No new
arXiv submission, outreach, or delivery-time optimization is included.

## Work allocation

- Endpoint `(8,40)`: complete target-13 exclusion or literal attainer; independent
  replay and coverage review before incorporation.
- Sparse budgets 19/20: necessary degree profiles, full treatment of zero-degree
  vertices, then complete residual matching families.
- Small main intervals: literal endpoint modifications and selected-pair
  envelopes; full winning and losing ranks for every promoted graph.
- Root: independent upper-proof review, small-budget exclusions and stronger
  partial-graph bounds; canonical evidence integration only after review.

## Initial observations

The accepted starting ledger has 101 representatives (69 sparse, 32 main).
The endpoint agent's initial positive-degree enumeration completed quickly;
this is not yet a reviewed upper theorem. The construction agent reports
literal full-rank witnesses attaining the missing-pair bound at `(8,27..29)`.

The unmodified audited tiny-budget enumerator at `(10,12)`, target10, exhausted
its 15-second pilot after 129,695,744 prefixes without completion. Its evaluated
best score8 is not an upper bound. Receipt:
`research/finish-tiny-n10-m12-t10-pilot.json`. This workload motivates stronger
necessary conditions before scaling enumeration to the support cutoff12.

Fresh-sink composition was independently checked by hand: old guaranteed pairs
survive arbitrary old-to-sink arrows. The special one-arrow attachment preserves
the exact score. These facts justify lower propagation, not deletion of arbitrary
zero-score vertices. Stronger found literals can supersede these lower examples.

## Proof discipline

Search maxima and timeouts never become upper bounds. A completed exclusion
requires exhaustive domain coverage, sound pruning and an independently checked
game interpretation. Numerical and recipe inventories are updated separately.
Concrete external certificates are not silently described as instantiated Lean
theorems. All failed routes and superseded receipts remain available privately.

## Verified first integration

The initial101 canonical representatives are now54 in the accepted generated
ledger. This is35 numerically closed representatives and12 removed host repetitions;
the latter are not counted as numerical solutions. All492834 previously exact
cells are preserved,341 additional audit cells are exact, and explicit recipes
cover every493175 exact audit cell. The separate recipe objective remains in force.
`finish-ledger-review.json` independently reconstructs this closure from the frozen
initial ledger; `finish-case-baseline.json.gz` preserves that baseline.

Accepted in this pass: global ME12=9, ME13=11, ME20=53, with literal attainers
from hosts7,8,10 respectively; subsidiary ME19<=53. Every n8 arrow budget is
now exact, combining new upper exclusions at14..23,35..38,40, literal all-missing
attainers at27..34, and inherited exact cells. New literal10/26=64 and10/27=63
also close their main-interval cases. Concrete case proofs remain external.

Root independently re-enumerated positive missing-degree endpoint families at
n8,m35..38,40, and replayed all surviving leaves. The low-budget n8 upper proof
uses source-reviewed complete profile coverage and a separately implemented
leaf-game replay; it is not described as a second full graph enumeration.

## Current candidates, not yet promoted

The global21-arrow optimum60 and joint host values56 on10 and58 on11 have a
frozen complete primary proof; root is replaying every residual leaf with an
explicit two-turn alternating attractor. A subsidiary ME19<=49 is part of that
proof and does not assert an exact19-arrow value. A bug in the audit adapter
initially treated camping masks containing direct arrows as pure missing-pair
masks; the adapter now filters those arrows before validating each loss. This
was an audit-adapter issue, not a changed producer exclusion.

Global14,15,16 candidate maxima13,15,19 now have complete primary exclusions.
The effective new reduction counts all source arrows and all sink arrows when
bounding live columns and rows, then combines each degree-two source/sink's
remaining possible pairs with the already settled smaller-budget core. This
replaced two timeouts with strictly smaller complete inventories. Independent
review is in progress.

Positive-degree18-arrow upper33 is complete in the primary package; the global
implication needs only much weaker14–16 bounds than the candidate exact values.
The nine-vertex23-arrow candidate44 now has a complete338-joint-degree-pattern
exclusion. Fixing both incoming and outgoing degrees was substantially faster
than completing outgoing partitions alone. Every candidate awaits its stated
independent review before entering the canonical registry.

Root next investigates17 arrows. The new14–16 values, if approved, bound every
zero-degree17-arrow graph by22. Positive support>=11 has ordinary upper28;
only positive supports9 and10 need graph exclusions against the saved lower28.
The nine-vertex host value is treated separately rather than inferred from the
ten-vertex literal.


## Complete classification and explicit attainers (final finite pass)

All101 formerly unresolved canonical pairs now have matching upper proofs and
explicit attaining graphs. The independent closure replay preserves all 492,834
previously exact stored cells, adds 1,090 exact host/budget cells, and checks
493,924 admissible pairs through order 114 with zero unresolved cells. Ordinary
parameterized constructions and finite-support reductions give the unbounded
classification; no extrapolation from the audit box is used. A separate recipe
audit finds zero numerical gaps and zero construction-only gaps.

The newly final arc maxima for budgets 12..21 are
9,11,13,15,19,28,33,40,53,60, with least attaining hosts
7,8,8,8,8,10,9,11,10,12. Complete finite tables cover all orders 1..11;
the uniform formula applies from order 12. Exactness includes the corrected
small hosts, such as M(9,22)=40, M(10,23)=61 and M(10,25)=65.

The principal useful reduction was to fix incoming and outgoing degree
partitions together, charge all source/sink arrows against the remaining live
rows and columns, and enumerate only residual patterns that could beat a saved
literal. Initial best-found graphs were not mistaken for optima: several scores
improved during complete enumeration. A restricted camping shortcut inherited
by an 18-arrow prototype was rejected, its omitted patterns restored, and the
complete corrected inventory independently reviewed before promotion.

The final dependencies and review distinctions are recorded in
publication/EVIDENCE_GUIDE.md, research/finish-case-approved-bounds.json,
research/finish-ledger-review.json, and the individual frozen review manifests.
Existing stronger construction properties and historical evidence are retained.
The concrete finite proofs remain externally reviewed computational proofs;
the 12 Lean modules do not yet instantiate the entire classification. Delivery
time optimization and all-extremizer classification remain outside the goal.
Mathematics is complete; the final PDF, package and public deployment are being
verified separately and will receive their own release receipts.

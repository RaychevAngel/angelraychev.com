#!/usr/bin/env python3
"""Independent necessary-integer-profile replay; no graph enumeration/imports."""
from pathlib import Path
import hashlib
import json


def live_upper(m, q, r, b, rows, columns):
    """Live rectangle: remove forced diagonals and forced direct arrows."""
    return (rows * columns
            - max(0, rows + columns - (q + r - b))
            - max(0, 2 * rows + 2 * columns - m))


def review(m, threshold):
    profiles = []
    maximum_support = -1
    maximum_tuples = []
    total_auxiliary_tuples = 0
    for q in range(m // 2 + 1):
        for r in range(m // 2 + 1):
            a, d = m - 2 * q, m - 2 * r
            for b in range(min(q, r) + 1):
                profile_maximum = -1
                profile_count = 0
                for o in range(a + 1):
                    for i in range(d + 1):
                        rectangle = q * r - b - max(
                            0, m - min(a, r - b + o) - min(d, q - b + i))
                        if rectangle < threshold:
                            continue
                        for z in range(max(o, i), o + i + 1):
                            row_cap = min(q, b + a + (d - o - z) // 2)
                            column_cap = min(r, b + d + (a - i - z) // 2)
                            if row_cap < 0 or column_cap < 0:
                                continue
                            # Explicitly maximize over actual live dimensions:
                            # no monotonicity assumption about the displayed bound.
                            live = max(live_upper(m, q, r, b, rows, columns)
                                       for rows in range(row_cap + 1)
                                       for columns in range(column_cap + 1))
                            upper = min(rectangle, live)
                            if upper < threshold:
                                continue
                            support = q + r - b + z
                            profile_count += 1
                            total_auxiliary_tuples += 1
                            profile_maximum = max(profile_maximum, support)
                            item = dict(q=q, r=r, b=b, z=z, o=o, i=i,
                                        row_cap=row_cap, column_cap=column_cap,
                                        necessary_pair_upper=upper)
                            if support > maximum_support:
                                maximum_support = support
                                maximum_tuples = [item]
                            elif support == maximum_support:
                                maximum_tuples.append(item)
                if profile_count:
                    profiles.append(dict(q=q, r=r, b=b, a=a, d=d,
                                         maximum_support=profile_maximum,
                                         auxiliary_tuples=profile_count))
    return dict(m=m, assumed_minimum_I=threshold,
                surviving_q_r_b_profiles=len(profiles),
                auxiliary_integer_tuples=total_auxiliary_tuples,
                maximum_permitted_nonisolated_support=maximum_support,
                maximum_support_tuples=maximum_tuples, profiles=profiles)


def main():
    results = [review(20, 51), review(18, 31)]
    assert [(r['surviving_q_r_b_profiles'],
             r['maximum_permitted_nonisolated_support']) for r in results] == [
                 (22, 13), (67, 15)]
    receipt = dict(
        verified=True, date='2026-09-13',
        scope='Independent exhaustive arithmetic over necessary integer profiles; '
              'no graph search, game solve, or producer import.',
        boundary='These are conditional support reductions for graphs beating '
                 'the existing lower witnesses. They prove neither extremum, '
                 'nor realization of any surviving parameter tuple, nor '
                 'strategy preservation after deleting vertices or arrows.',
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        results=results)
    destination = Path(__file__).with_suffix('.json')
    destination.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(verified=True, receipt=str(destination),
                          results=[{k: r[k] for k in (
                              'm', 'assumed_minimum_I',
                              'surviving_q_r_b_profiles',
                              'auxiliary_integer_tuples',
                              'maximum_permitted_nonisolated_support')}
                                   for r in results]), indent=2))


if __name__ == '__main__':
    main()

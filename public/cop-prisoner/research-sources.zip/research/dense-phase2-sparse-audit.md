# Independent audit of the packed-hole sparse budget construction

## Conclusion

The proposed canonical family passes an independent graph-map and alternating
game audit. The finite pattern list is complete for every k>=20, not merely
the circles sampled in the primary screen. Together with the projection and
composition argument below, it gives the proposed robust2n..3n sparse family
at every n>=115. The parent owns the primary theorem and publication changes.

## Independent implementation

`src/dense_phase2_sparse_independent.py` imports none of the primary graph
generators, arena builders, or solvers. It spells out the six source-type
arrows directly after smoothing type4:

* type0: (i,1) and (i,5);
* type1: (i,2) and either(i+1,4), or(i+2,2) if column i+1 is a hole;
* type2: (i,3) and (i+1,1);
* type3: either(i,4) or(i,5) if column i is a hole, and(i−1,0);
* type4: (i,5) and(i+1,2), when this vertex exists;
* type5: (i+1,0) and(i−1,3).

It builds separate messenger-turn and cop-turn states. Messenger states use
existential predecessors; cop states use a remaining-successor counter and
become winning only when every reply is winning. Nonterminal collisions are
losing. Delivery is terminal before collision; transfer requires surviving the
cop reply and handing off a noncollision messenger-turn state. This differs
from the primary combined-round bit-mask attractor implementation.

Every one of the101 independently generated crops passes every required
source/cop condition. Independent maximum strategy bounds are9 messenger moves
for transfer and38 for delivery, agreeing with the primary certificates.
The receipt is `research/dense-phase2-sparse-independent.json`.

## Global graph audit and exact optional count

For canonical holes{0,3,...,3(r−1)} in a k-cycle, k>=20 and0<=r<=5,
n=6k−r. Literal global maps at every k20,...,30 and every r0,...,5 pass:

* exactlyn vertices,2n base arcs, two incoming and two outgoing base arcs;
* no loops, duplicate base arcs, or optional/base overlap;
* every optional target is an existing vertex;
* exactly8k−9r optional arcs, hence at leastn.

The final count is also algebraic for all k>=20. Each hole deletes the two
optional arcs from its absent type4 source. Its seven blocked relative rules
delete seven further distinct arcs. The source columns h,h+1,h+2 belonging to
different holes are disjoint because successive hole gaps are at least3,
including the wrap gap. The seven rules do not refer to the absent source,
and all optional targets have type0,1,or5. Thus the deleted optional arcs total
exactly9r. Since8k−9r−n=2k−8r>=0 when k>=20,r<=5, every budget2n..3n is
available by choosing an arbitrary subset of optional arcs.

The independent map receipt is `research/dense-phase2-sparse-global-map.json`.

## Why the101 local crops cover all orders

An arena contains columns−8,...,8, a17-column interval of span16. For
k20,...,29 enumerate all six r values and all centers. This independently
produces the same101 distinct crops as the primary list.

For every k>=29, the gap from the last hole back to the first is at least
k−3(r−1)>=k−12>=17. Therefore a17-column crop cannot contain holes from both
sides of this gap. Its holes lie in one arithmetic-progression cluster with
step3 and at most five terms. Every such cropped cluster already occurs among
the k=29 cases with r<=5. Thus no new crop can appear at larger k. This argument
is restricted to the canonical single-cluster pattern; it does not claim
arbitrary hole sets of minimum spacing3 work.

## Projection to the local game

The messenger is restricted to columns−4,...,4. Cop positions in−8,...,8
retain their exact vertices; all others project to Omega. The17 columns are
distinct modulo k>=20. Smoothed base arrows change a column by at most2 and
optional arrows by at most3. Hence an outside cop can reenter only at columns
with absolute index at least6. The local Omega state permits all those entries
and permits waiting, so it includes every actual projected cop reply.

Omitting holes outside the crop is conservative. A smoothed base jump that
meets the only relevant omitted right-hand hole still lands outside the cop
window, hence projects to Omega either way. An omitted hole to the left can
only suppress some optional arcs by its blocked rules; the cropped arena
instead grants these additional moves to the cop. Messenger moves in its
smaller window are modeled literally. Thus the local arena never grants the
messenger an illegal move or removes an actual cop reply.

The messenger uses only base arcs, whereas the cop receives every permitted
optional arc simultaneously. Therefore the same certificates work for every
subset of optional arcs, not merely one choice at each cardinality.

## Global strategy and time bound

Repeated safe transfers advance by one column. After at most k−1 transfers the
messenger reaches the column two before the recipient's column. Apply the
local delivery certificate there. This gives a bound

    9(k−1)+38 = 9k+29

messenger moves from any distinct source and cop position to any recipient;
reaching the recipient during a transfer may finish earlier. With
k=ceil(n/6), the canonical construction is available at every n>=115.

This is an ordinary computer-assisted proof backed by two independent finite
game implementations and an explicit finite-pattern coverage argument. No Lean
formalization of these new certificates is claimed here.

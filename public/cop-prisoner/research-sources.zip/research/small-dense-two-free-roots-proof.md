# Two free roots attain the strict small third/fourth-step bounds

Private research proof and evidence note, subject to independent review.

Take a missing two-cycle a<->b and two free roots alpha->a, beta->a.
Every one of these four functional pairs fails. The cycle rows are killed
by their degree-one predecessors, and each root's missing pair to a is
blocked by the other root. No missing arrow enters alpha or beta.

Attach k vertices by the existing colored-cycle construction using alpha
and beta. For even k>=2, use an alternating missing cycle and give each
cycle vertex its color root as its other missing neighbor. For odd k>=3,
use an alternating cycle on k-1 vertices and a final singleton whose
missing neighbors are the two roots. For k=1 use just that singleton.

The old colored-cycle and singleton routing proofs apply without change
to all 2k new missing pairs. Against a functional pursuer, its unique
missing neighbor is a or b; that vertex is directly accessible from every
new source and directly delivers to every root or new-vertex recipient.
Against different-color cycle pursuers use the other root. Against a
same-color pursuer use its successor. The singleton is handled by the
same safe-entry argument through a cycle successor, followed by the
already guaranteed cycle-source pair when needed. At most three moves
suffice; the even-cycle and single-vertex cases need only two.

All four functional pairs remain failed in the larger graph by the same
camping arguments. Thus the graph has h=2k+4 missing arrows and exactly
I=2k guaranteed missing pairs at n=k+4, i.e. the fourth dense step.

For n=7,8,9,10 this meets the independently checked strict upper bound
2n-8 from the rooted equality reduction. The resulting exact values are

    M(7,32)=6, M(8,44)=8, M(9,58)=10, M(10,74)=12.

Use labels a=0,b=1,alpha=2,beta=3 and new vertices4 onward. Adding the
single missing arrow4->6 also gives the literal third-step witnesses

    M(7,31)=7, M(8,43)=9, M(9,57)=11.

These extra-arrow counts have full finite game certificates; no unstated
arbitrary-addition or arbitrary-subset guarantee is asserted. Exactness
uses the separate third-step equality/profile exclusions. All seven
graphs are constructed by `src/small_dense_two_roots.py`; full alternating
certificates and source hashes are frozen in
`research/small-dense-two-root-certificates.json` and
`research/small-dense-two-root-checks.json`.

The direct one-root alternative was also checked: complete all-row
evaluation at k=3,4,5 gives best rooted counts2,4,7; a k=6 literal gives10,
matching the previously proved at-least-two-loss upper bound. Those tests
are in `research/small-dense-rooted-best.json` and its certificate file.
They are not needed for the two-free-root proof or its exact-value claims.

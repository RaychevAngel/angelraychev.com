# Packed holes: new sparse budget threshold

Theorem 52 is written in `paper/sparse-packed-holes.md`. Its uniform
threshold is n>=1075 rather than the previous n>=2419. This is a proof
improvement obtained by packing at most five deletions at column spacing
three, not by extrapolating finite cyclic tests.

The main observation is an arena simulation: new M=4,R=8 with three
outside re-entry layers maps to old M=4,R=6 with two layers, after
discarding holes outside [-6,6]. Messenger positions and moves coincide;
outer pursuer positions map to old Omega. The only exterior hole that
changes an old represented tail is h=7, but both its original head at7
and smoothed head at8 map to Omega. Entry from outside R=6 has jump at
most2 and hence is covered by old boundary columns±5,±6. The larger
Omega's entries±7,±8 remain Omega, and±6 are old permitted entries.

An exhaustive check of this finite mapping for all865 patterns completed
in0.51seconds. Existing strategy ranks then lift without any fresh
attractor computation. Every positive-rank implication is checked
directly against the larger arena's actual moves. Negative ranks are
not asserted losing; no full attractor claim is needed.

Full generation and direct verification passed5,886 objectives and
3,365,384 required initial states in41.65seconds, including serialization
of all lifted ranks. Maximum local bounds are9transfer and27delivery.
The prior fully augmented no-hole arena has delivery35, so the combined
uniform bound stays9ceil(n/6)+26. The artifact SHA256 and exact source
hashes are recorded in research/six-type-budget-multihole-summary.json.
The saved file was then reloaded and all5,886 objectives checked again
in15.89seconds; receipt research/six-type-budget-multihole-readback.json.
An independent direct-formula implementation also passed all865 maps,
286,414 mapped cop arcs and4,496,692 collision equivalences, and checked
the six boundary-order constructions1075..1080. Its separate source and
receipt are src/six_type_independent_multihole_projection.py and
research/six-type-independent-multihole-projection.json.

The optional-arc suppression union is now contained in[-16,3(r−1)+16],
of length3r+30<=45. The eight arc types give8(k−45)>=6k>=n optional arcs
at k>=180, that is every n>=1075. Every subset remains safe by the same
adversarial-augmentation argument as Theorem41.

Potential gaps specifically checked: both turn/collision priorities;
deleted recipients omitted; exactly one excluded collision per required
start; holes just beyond both old and new boundaries; cop re-entry from
augmented exterior vertices; wraparound separation; optional arcs neither
repeat nor coincide with base arcs; preservation of two-in/two-out after
smoothing. Independent review is recorded separately when available.

The user lifted the earlier10%-quota stopping rule. This work continues
the authorized extremal research and claims no new Lean coverage.

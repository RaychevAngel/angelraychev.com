# Twenty arrows: compressing the remaining host bound to eleven

Research note, 13 September 2026. This is an ordinary case argument after the
independently reviewed necessary integer-profile reduction. No new graph
enumeration is used. Independent review of the argument is requested before
promoting the conclusion to the canonical manuscript.

**Proposed theorem.** For every `n>=11`,

    M(n,20) = M(11,20).

Thus eleven vertices suffice for an extremal twenty-arrow graph. This is
not a claim that every graph scoring above 53 has at most eleven nonisolated
vertices. A twelve-vertex graph may need a score-preserving modification.
The numerical interval remains `53 <= M_E(20) <= 57`.

## Two simple live-row and live-column constraints

Write `A={outdegree>=2}`, `B={indegree>=2}`, with sizes `q,r`, intersection
size `b`, and `a=20-2q`, `d=20-2r`. The outgoing surplus over two inside `A`
is `x`; the incoming surplus over two inside `B` is `y`. Outside `A union B`,
there are `z` nonisolated vertices with total outgoing/incoming degrees `o,i`.
Each has both degrees at most one. Consequently there are exactly `z-o`
outside sinks and `z-i` outside indegree-zero sources.

An indirect source with a nonzero row needs at least two outgoing neighbors
that are not sinks. Otherwise the pursuer starts at the sole nonsink neighbor;
every other first move enters a sink and can never reach a nonadjacent
recipient. With no nonsink neighbor, there is no indirect delivery at all.
Waiting at the source does not evade this obstruction.

Separately, a recipient with a nonzero column needs at least two predecessors
of positive indegree. An indirect source cannot reach an indegree-zero
predecessor. If there is at most one other predecessor, the pursuer starts
there. The initial-source exception is already a direct pair and hence does
not count. This argument uses the original arrow directions, not reversal
invariance of the game.

In particular, if all `q` active source rows are nonzero, each active source
can send at most its outgoing surplus to sinks. Summing, arrows into sinks
from `A` number at most `x`, and arrows from outside `A` number at most
`a-x`. The total indegree of all sinks is therefore at most `a`.
The separate incoming argument says that if all `r` active recipient columns
are nonzero, the total outdegree of all indegree-zero vertices is at most `d`.

Put `t=a-x-o`, the number of outdegree-one vertices in `B minus A`, and
`p=d-y-i`, the number of indegree-one vertices in `A minus B`. All-row and
all-column nonvanishing therefore imply respectively

    2(r-b-t)+(z-o) <= a,
    2(q-b-p)+(z-i) <= d,

or equivalently

    2(r-b)+2x+o+z <= 3a,
    2(q-b)+2y+i+z <= 3d.                         (1)

More generally, if `S` is the total indegree of sinks and `T` the total
outdegree of indegree-zero vertices, the live row and column counts satisfy
`2R<=m-S` and `2C<=m-T`. These elementary inequalities are useful on their
own; they do not assert that all surviving rows are actually nonzero.

## Which large-support tuples remain

The existing integer receipt
`research/small-sparse-support-20-threshold53.json` lists every necessary
tuple for a graph with `I>53`. It has one tuple with support thirteen and
fifteen with support twelve. All other tuples already have support at most
eleven. The adjacent replay for this note checks that the case list below
equals the complete list in that receipt.

For every listed tuple with `q=r=9`, all nine rows and all nine columns must
be nonzero. Indeed, if either live count is at most eight, the existing
live-rectangle bound is at most `59-b<=53` since `b>=6`. For the two tuples
with `(q,r)=(9,10)` or `(10,9)`, the prior capacity bound allows at most nine
live columns or rows respectively; losing another row or column gives at
most 51. The stated nonzero-row or nonzero-column conditions used below
therefore follow from `I>53`.

## The thirteen-vertex tuple

The only such tuple is `(q,r,b,o,i,z)=(9,9,9,2,2,4)`. The nine core vertices
have indegree and outdegree exactly two. Outside are two indegree-zero
one-arrow sources and two one-arrow sinks. There are at most 56 eligible
core pairs.

An outside source pointing to a core target makes that entire eligible
column zero: a core source cannot reach that indegree-zero predecessor,
and the pursuer can camp at the other predecessor. The only excluded
initial cop position would itself be a direct source, already uncounted.
A core source pointing to an outside sink similarly has a zero row. Each
such eligible row or column has at least six entries, giving `I<=50`.
If neither interaction occurs, all outside arrows run from the outside
sources to the outside sinks, while the core is a separate eighteen-arrow
nine-vertex graph. Its score is at most `M_E(18)<=44`. Thus support thirteen
cannot occur at `I>53`.

## Three unmatched vertices on each side

For `(q,r,b,z)=(9,9,6,0)`, write `C=A intersection B`, `U=A minus B`,
`V=B minus A`. Both `U,V` have three vertices. Equation (1) forces `x=y=0`.
Some `a0` in `U` has indegree zero; its two successors must avoid the
indegree-two set `B` and are therefore the other two vertices `v,w` of `U`.
These arrows exhaust all indegrees outside `B`. Similarly some sink `t0`
in `V` has as predecessors the other two vertices `p,q0` of `V`, exhausting
all outgoing arrows outside `A`.

A messenger in `C` cannot enter `a0,v,w`, and cannot return to `C` after
entering `p,q0,t0`. Thus any guaranteed missing pair in `C` would already
be guaranteed in `G[C]`, by restricting the pursuer to `C`. This core has
at most twelve arrows and at least eighteen missing pairs. At most
`M_V(6)=7` are guaranteed. At least eleven of the at most 59 eligible
pairs in the whole graph lose, so `I<=48`.

## Two unmatched vertices on each side and one outside vertex

Here `q=r=9,b=7,z=1` and `(o,i)` is `(0,1)`, `(1,0)`, or `(1,1)`.
Equation (1) forces `x=y=0` in all three cases.

If `(o,i)=(0,1)`, the outside vertex is a sink. Of the two vertices of
`U=A minus B`, exactly one, `a0`, has indegree zero. Its two successors
must avoid `B`, so they are the other vertex of `U` and the outside sink.
Its row is zero, a contradiction. The case `(1,0)` uses the separate
incoming argument: a sink in `V=B minus A` must have as predecessors the
other vertex of `V` and the outside indegree-zero vertex, making its
column zero.

For `(o,i)=(1,1)`, call the outside vertex `zeta`. Write `U={a0,v}` with
`a0` of indegree zero and `V={p,t0}` with `t0` a sink. Nonzero rows and
columns force `a0 -> v,zeta` and `p,zeta -> t0`. These exhaust all arrows
ending outside `B` and starting outside `A`. Play between vertices of
the seven-vertex core cannot use the outside part and return. The core
has at least 28 missing pairs, at most `M_V(7)<=21` of which are guaranteed.
At least seven of the at most 58 eligible pairs lose, giving `I<=51`.

## One unmatched vertex on each side and two outside vertices

Now `q=r=9,b=8,z=2`. Write `U={a0}`, `V={b0}` and `C=A intersection B`.
The six possible `(o,i)` pairs are `(0,2),(1,1),(1,2),(2,0),(2,1),(2,2)`.

- For `(0,2)`, equation (1) and the degree totals force `x=1,y=0`.
  The vertex `a0` has indegree zero. Its successors must avoid `B`, and
  the only possible targets are the two outside sinks. Its row is zero.
  For `(2,0)`, the separate incoming argument gives a zero column at
  `b0`: both its available predecessors are outside indegree-zero sources.
- For `(1,2)`, equation (1) forces `x=y=0`. The outside vertices are one
  vertex of degrees `(1,1)` and one sink. Again `a0` has indegree zero;
  its two successors must be those outside vertices, including the sink,
  so its row is zero. For `(2,1)`, the incoming version gives a zero column
  at `b0`.
- For `(2,2)`, equation (1) forces `x=y=0`. The two outside vertices
  `u,v` have degrees `(1,1)`. The vertices `a0,b0` have indegree zero and
  outdegree zero respectively. Nonzero rows and columns force the separate
  diamond `a0 -> u,v -> b0`. The eight-vertex core is a separate regular
  component. Only one indirect pair is possible in the diamond, so
  `I<=M_V(8)+1<=33`.
- For `(1,1)`, equation (1) forces `x=y=0`. The outside vertices are an
  indegree-zero source `u` and a sink `v`; both have their other degree one.
  The vertices `a0,b0` have indegree one and outdegree one respectively.
  The source `u` cannot point into `B`, and the sink `v` cannot be reached
  from `A`. Thus either `u -> v`, a separate one-arrow component, or
  `u -> a0` and `b0 -> v`. In the former case the remaining component has
  ten vertices and nineteen arrows. In the latter, the eight-vertex core
  cannot reach `a0` or return after exiting through `b0`. It has at most
  sixteen arrows and at least forty missing pairs, at most 32 guaranteed.
  At least eight of the whole graph's at most 57 eligible pairs lose,
  giving `I<=49`.

The last estimate is deliberately weakened; the exact eligible count in
that forced form is 55, which would give 47. Either bound suffices.

## Equal active sets with three outside vertices

Here `q=r=b=9,z=3`, with `(o,i)=(1,2),(2,1)`, or `(2,2)`.

For `(1,2)`, the degree totals give `x=1,y=0`. There is one outside
indegree-zero source and two outside sinks. The source must point to one
sink, since pointing to a core indegree-two target makes a zero column.
The other sink must receive its arrow from the unique outdegree-three core
vertex. Removing the outside vertices leaves a regular nine-vertex
eighteen-arrow graph. A messenger between core vertices cannot use a sink
and return, so restricting the pursuer to the core gives `I<=M_E(18)<=44`.
For `(2,1)`, the outside consists of two indegree-zero sources and one sink.
The sink must receive its arrow from one source, since every core outdegree
is two. The other source points to the unique indegree-three core vertex.
Again removing the outside leaves a regular core, and no core messenger
route can use the indegree-zero sources; the same restriction gives at most44.

For `(2,2)`, `x=y=0`. Outside are a source `u`, a vertex `v` of degrees
`(1,1)`, and a sink `w`. The source cannot point into the core, and the
core cannot point to the sink. Either `u -> v -> w` is a separate path,
leaving the eighteen-arrow core, or `u -> w` is a separate arrow and
`v` has its predecessor and successor in the core. The latter form leaves
a ten-vertex nineteen-arrow component after the separate arrow is removed.

## Unequal active-set sizes

The last two support-twelve tuples are `(q,r,b,o,i,z)=(9,10,9,2,0,2)`
and `(10,9,9,0,2,2)`.

In the first, the common nine-vertex core has outgoing degree two and
the one vertex of `B minus A` is a sink. All nine core rows must be
nonzero, so its two incoming arrows come from the two outside indegree-zero
sources. This separates a two-arrow in-fork from the regular eighteen-arrow
core, which has score at most44. In the second, the separate incoming
argument forces the one indegree-zero vertex of `A minus B` to point to
the two outside sinks. This separates an out-fork from the same sort of
core. Again the score is at most44.

## Compressing the only surviving form

We have exhausted every tuple of support at least twelve. At score above53,
the only possible twelve-vertex form is a ten-vertex, nineteen-arrow graph
`H` disjoint from a single directed arrow. The separate arrow contributes
no indirect guarantee, so the score is `I(H)`.

Use Angel Raychev's previously proposed harmless-sink attachment: choose
any vertex of `H`, add one fresh sink, and add the arrow from that vertex
to the sink. The result has eleven vertices and twenty arrows with exactly
`I(H)` guarantees. For old recipients, a messenger gains nothing by entering
the new sink; restricting the pursuer to `H` proves the upper direction.
For the lower direction, play an old winning strategy while the pursuer
remains in `H`; if the pursuer enters or starts at the fresh sink, it is
trapped and any old source-to-recipient route succeeds. The fresh sink is
neither an indirect source nor an indirect recipient, by degrees zero and
one. Thus the score is unchanged.

Every twenty-arrow graph with score at most53 is matched by the existing
ten-vertex 53-guarantee witness. Every higher-scoring graph either loses only
isolates when reduced to at most eleven vertices, or admits the preceding
compression. Pad the resulting graph with isolates if necessary. This
proves `M(n,20)<=M(11,20)` for every `n>=11`; the reverse inequality follows
by adding isolates.

## What this does and does not settle

This reduction eliminates the need to optimize on host order twelve at
budget twenty. It supplies an explicit score-preserving operation for the
only surviving larger-host form. It does not eliminate all ten- or
eleven-vertex exceptional degree classes, and it does not prove the lower53
optimal. A complete count above53 on those remaining classes still needs
further structure or finite exclusions. The earlier maximum-degree-two
double-defect enumeration excluded equality58 only; it cannot be reused
as an exclusion above53 without changing its pruning proof and replaying.

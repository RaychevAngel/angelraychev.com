# Independent review of the fifth main-interval ordinary arguments

13 September2026. Reviewed `paper/main-interval-six-circle.md` and
`paper/main-interval-reduced-hubs.md` against their current constructors.
The mathematical assertions below were checked from their hypotheses and
literal adjacency, not accepted from producer success messages.

**Finding: no mathematical blocker found in either ordinary theorem.** The
conditional six-circle argument, both periodic residue recipes, and the
reduced-hub antichain interface have valid universal optional-subset proofs
with the stated parameter restrictions. Promoted circle rows remain finite
rank-certificate claims; the ordinary periodic theorem does not subsume them.

## Circle proof audit

The four propagation identities are correct over the integers before modular
reduction. The initial pattern P(-h) uses compulsory differences
h+2,h+1,h,h-2. Every later source reaches three previously winning sources,
and the nonzero-cop escape clause supplies a destination outside the full
closed envelope. Thus every possible reply preserves the smaller source rank.
If modular positions coincide, omitting an already assigned source preserves
the argument. Coprimality supplies all translates; no finite sampling of ring
sizes is needed for this conclusion. Direct final receipt is handled separately
and retains priority over collision.

For period4, residue-class reasoning remains valid on the cyclic group because
4 divides n. The exceptional point h has class3. If the cop has class0,
covering h via that exceptional point requires cop0; a cop of class1 cannot
cover h. Cops of class2 cannot cover the zero-class member of S1, and can
cover at most one one-class member of S0/S2. Cops of class3 cannot cover the
one-class member. Hence no nonzero cop covers a triple. The exceptional point
is outside the periodic half, giving exactly n/2+1 allowed offsets.

For period5, the periodic classes {4,0,1} are three consecutive classes, and
none of the three escape triples has three consecutive classes. Thus every
putative cover uses exceptional h. This leaves exactly these nonzero cops:

| Triple | Cop offset | Required unavailable envelope offset |
| --- | --- | --- |
| S0 | 1 | h-1, absent class2 |
| S0 | 1-h | 2h-1, deleted |
| S1 | -2 | h-1, absent class2 |
| S1 | -3 | h+3, deleted |
| S2 | -2 | h+4, absent class2 |
| S2 | 2 | h-4, deleted |

The remaining possibility in each triple is cop0, excluded by the initial
noncollision condition. Since5 divides n, modular reduction preserves the
residue exclusions. The bounds h>=8 and2h+2<=n put all three deleted offsets
strictly between0 and n, keep them distinct, and keep them outside C union
{0,h}. They lie in the periodic part, so the exact count is3n/5-2. For odd
multiples of5, h=8 has gcd(h,n)=1 and meets every hypothesis from n25.

The constructors reproduce these exact sets, delete the same offsets, require
the same gcd and range conditions, and count the same budgets. The optional
ordered-endpoint prefix contains neither compulsory arrows nor loops.

For the promoted finite rows, the reconstructed verifier checks each supplied
rank against every literal recipient, source and permitted cop. It does not
infer intermediate graph success from the winning endpoints. The n24 prose
was flagged for a minor clarity change: 'every nonzero offset except one'
should explicitly mean every nonzero offset **in the enlarged envelope**
except **offset1**. This does not change the data or proof.

## Reduced-hub proof audit

The core has108 arrows. For g>=2 the first two omitted guide codes have size3
and all remaining codes size2, so guide-to-hub arrows total10g-2. Together
with8(g+b) incoming arrows and4b+W bulk outgoing arrows, the compulsory count
is106+18g+12b+W. The optional classes are disjoint: gb guide-to-bulk,
b(b-1) bulk-to-bulk,4b additional hub-to-bulk, and5b additional bulk-to-hub.
They total b(g+b+8). No optional arrow is a loop or a compulsory arrow.

The five additional bulk-to-hub arrows expand a bulk cop's accessible hubs
from S to H minus T. Therefore the proof genuinely needs the remaining safe
triple T={0,2,3}; using the old eight safe hubs would be invalid. Each displayed
top-interface stage has a safe earlier **hub** even against a ghost cop with
all nine hubs outside T and every guide. The checker explicitly grants that
ghost every outside vertex too. This is sound because the top witnesses are
restricted to hubs; the ghost is not substituted for a bulk cop during entry
from a bulk source, where the actual guide-code distinction is essential.

Hub-recipient cases also work against the ghost. For a missing hub-to-hub
pair at most two safe points are forbidden intermediaries. For a point-code
guide and a missing point recipient, T cannot fit inside its two-element code;
the remaining safe point reaches the recipient in the point clique. A
line-code guide reaches all of T and at most two safe points fail to reach a
missing line recipient. The actual hub and guide cops retain the earlier
core's missing rows/codes, and literal checking confirms their two-move cases.

The source stages match the manuscript and constructor: R rank1, P0/P5 rank2,
L2/L5 and point-code guides rank3, remaining guides rank4. The source's own
cop position is excluded. Code incomparability supplies safety for other guide
cops. These rank comparisons are strict after each actual cop reply.

The4b optional arrows from H minus R do not invalidate bulk entry through an
assigned guide: those arrows end only in bulk vertices, while those four hubs
still reach no guide. A hub in R is handled by S intersecting its missing row.
A guide cop cannot cover two assigned guides. A different bulk cop fails to
cover J_source minus J_cop by the antichain hypothesis. The optional5b hub
arrows do not enlarge a bulk cop's guide set. Thus all four entry cases remain
valid against the final envelope, giving at most1+4=5 messenger moves.

Mixed-size antichains are allowed because only J_source not contained in
J_cop is needed. The minimum code size2 is separately necessary in the guide
cop case. The constructor validates both conditions, and its equal-weight
specialization lists actual subsets without searching for a game-winning
graph. The g<=7 restriction is essential to this particular interface: the
omitted eighth code fails one of the early escape sets, not a global theorem.

## Independent bounded evidence

`research/main-interval-fifth-ordinary-review.py` imports only the Python
standard library. It reconstructs hub adjacency from the manuscript and
constructs six-circle ranks by the four propagation identities, rather than
calling either producer's rank or graph functions. It reads promoted ranks
only as untrusted proof data and directly checks their obligations.

The saved JSON records:

- 35 literal circle recipes,2,268 escape clauses and654,412 all-target rank
  obligations;
- 1,833 periodic parameter rows over orders16..320, with1,193,487 escape
  clauses and exact nonwrap/deletion/count checks;
- 20 full-target periodic samples, including the smallest and largest allowed
  coprime h at the selected orders, with3,466,360 additional rank obligations;
- 30 independently reconstructed hub envelopes, including every g2..7,
  empty bulk sets, full-capacity equal-weight codes, one mixed antichain and
  the n25/n27 bridge instances:779 targets,508,475 actual-cop rank obligations
  and5,136 stronger ghost-cop obligations;
- 15,540 guide/bulk entry set checks over all guide subsets of size at least2
  in the finite g<=7 domain.

Source hashes before and after this replay were equal and are saved in
`research/main-interval-fifth-ordinary-review.json`. These finite checks
support the reviewed ordinary all-parameter arguments; they are not themselves
an extrapolation theorem or a new concrete Lean instantiation.

## New generic Lean bridge

`lean/StagedEnvelopes.lean` defines a position-dependent `RankEnvelope B E t`.
It maps the messenger's legal base move into any G containing B, and every
legal cop reply in G into E. The unchanged rank/move fields therefore give a
`Delivery.RankCertificate G t`. The existing semantic theorem then supplies
finite winning trees and actual delivery against every legal history-dependent
cop, with waits and terminal-receipt priority.

The new module compiled under Lean4.33.1. The two exported theorem axiom
reports contain only propext, Classical.choice and Quot.sound. No sorry,
custom axiom, concrete staged graph instantiation or updated global Lean
receipt is claimed here. The root owns adding this module to the shared check
list and refreshing the formal verification receipt.

# Exact game solver and small extremal tables

Research computation, 12 September 2026. These calculations use the final
messenger/pursuer rules in `HANDOFF.md`: both players may wait; the messenger
moves first; the pursuer starts at any vertex other than the source; delivery
at the target succeeds before a collision check; infinite avoidance loses.

## Exact recurrence

Fix recipient `t`. Write `C(v)={v} union N+(v)` for legal moves, and let
`X_k(r)` be the set of pursuer positions from which delivery can be forced in
at most `k` messenger moves. The initial layer is `X_0(t)=V` and
`X_0(r)=empty` for `r!=t`. For `r!=t`, put

```
X_(k+1)(r) = {c != r : there is v in C(r) such that
                       v=t, or [v!=c and C(c) subset X_k(v)]}.
```

The omitted `v!=c` check in the bitset implementation is redundant: for
nonterminal `v`, membership of `c=v` would require `v in X_k(v)`, which never
holds; waiting is one pursuer action. The explicit implementation retains
collisions as separate terminal failure states and does not rely on this
simplification. The target row remains `V` in every layer.

Induction on `k` proves the recurrence using exactly the actual move order.
The ascending sequence stabilizes on the finite state space. Its union is the
eventual-delivery winning region: any winning finite reachability game has a
finite attractor rank, whereas outside the union the pursuer can keep play
outside forever or capture. Thus a greatest fixed point, or a mere
cycle-avoidance test, would be incorrect.

The guaranteed pair test is the universal condition
`V minus {s} subset X_infinity(s)`. The implementation does not replace this
with existence of a favorable pursuer start.

## Independent implementation and certificate checks

`src/game_solver.py` has two implementations:

* `recipient_fast`: synchronous bitset layers with pursuer turns eliminated;
* `recipient_explicit`: an explicit alternating graph of `2*n*n` states,
  followed by queue-based existential/universal attractor propagation.

The explicit solver produces integer ranks and positional messenger moves.
`verify_certificate` checks every legal transition, independently of the
queue that produced the ranks. Every winning messenger state has a legal
strictly decreasing-rank move; every pursuer response at a winning pursuer
state decreases rank. Every losing messenger move remains losing, and every
losing pursuer state has a losing response. Terminal target states and other
collisions are checked separately. This certifies the losing region too.

These are ordinary executable checks, not Lean theorems. The code is short
enough to review against the game rules. The elementary identity
`sum(W)=n+m+I` is checked for every graph returned by the public API.

## Enumeration scope and result

For `n<=5`, `src/enumerate_small.cpp` enumerates all labeled loopless digraphs.
Its arc bits are in lexicographic `(u,v)` order, skipping loops. It records the
full joint distribution by arc count and `I`, an attaining graph for every arc
count, and total graph counts. `src/enumerate_small.py` compiles and runs that
program, then independently checks every graph for `n<=4` with both Python
algorithms and full explicit certificates. For `n=5`, every maximizing witness
is independently checked; the remaining graphs are evaluated only by the
compiled implementation. Binomial totals are also verified for each arc count.

For `n=6`, `src/enumerate_small_n6.cpp` enumerates only labelings with
lexicographically nondecreasing `(outdegree,indegree)`. Every graph admits
such a relabeling, so this is exhaustive for extrema. It is not enumeration
of labeled distributions or exactly one representative per isomorphism class.
The degree restrictions reduce `2^30` graphs to 23,850,312 candidates before
the indegree tie check, and 3,503,861 after it. A graph can be skipped when
the number of its missing ordered pairs whose source outdegree and target
indegree are at least two is no greater than the already attained maximum
at that arc count. This is the elementary degree obstruction, not a conjectural
upper bound. The completed run solved 2,526,765 graphs, in 1.344 seconds.
Every maximizing witness is then checked with both independent Python solvers
and explicit strategy certificates. The compiled program has a time cap and
records `complete`; only a result with `complete: true` supports exhaustion.

The resulting fixed-order maxima are

| n | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|
| max I | 0 | 0 | 0 | 2 | 4 | 7 |

Complete arc-count rows, from `m=0` through `n(n-1)`:

```
n=4: 0,0,0,0,1,1,2,1,1,0,0,0,0
n=5: 0,0,0,0,1,1,2,2,4,3,3,3,2,2,2,1,0,0,0,0,0
n=6: 0,0,0,0,1,1,2,2,4,5,6,7,7,6,7,6,6,6,6,4,4,4,4,3,2,0,0,0,0,0,0
```

JSON files `research/solver-enumeration-n*.json` include all attaining arcs
and guaranteed indirect pairs. A finite-order table does not resolve extrema
for arbitrary order or arbitrary arc count alone.

## Counterexample to a proposed indegree-two shortcut

It is false that a recipient of indegree two admits at most one guaranteed
indirect source. On five vertices use arcs

```
0->4; 1->2,3; 2->1,4; 3->0,1; 4->0.
```

Recipient `0` has predecessors `3,4`, but both `1` and `2` are guaranteed
indirect sources. The four indirect pairs are `(1,0),(1,4),(2,0),(3,4)`.
This graph is the `n=5,m=8` maximizing witness and has been checked by both
solvers and strategy certificates. Consequently the tempting per-target
proof of an `n(n-4)` global bound is invalid.

## Reproduction

From the project root, run `python3 src/enumerate_small.py`. For the reduced
six-vertex run, compile `src/enumerate_small_n6.cpp` with a C++17 compiler and
run its executable with a time budget in seconds (default 50). Inputs to the
game CLI are JSON objects containing `n` and `arcs`; use
`python3 src/game_solver.py GRAPH.json --crosscheck --certificates --out RESULT.json`.

Source hashes for the small labeled enumeration are recorded in
`research/solver-enumeration-receipt.json`. The separate heuristic search in
`src/enumerate_small_two_regular.cpp` is explicitly nonexhaustive: its saved
graphs establish lower bounds only, regardless of how long it runs.

## Universal two-regular graphs: finite attaining witnesses

Degree-preserving search found loopless directed graphs with indegree and
outdegree two and **every ordered pair guaranteed**, for every order from
12 through 24. The arc lists are in `solver-two-regular-hillclimb.json` and
`solver-two-regular-hillclimb-odd.json`. Every saved witness was re-evaluated
by both Python algorithms, with the explicit winning/losing certificate
checker enabled. Since these graphs have `m=2n`, they have `I=n(n-3)` and
attain the elementary fixed-order upper bound for those orders. The failed
bounded searches at smaller orders are not impossibility proofs.

A particularly simple order-12 witness is the Cayley digraph of `A4` with
arcs `g -> ga` and `g -> gb`, where `a=(0 1 2)` and `b=(0 1 3)`. Group
elements are permutation tuples, composed by `(xy)[i]=x[y[i]]`, and generated
from the identity in breadth-first insertion order using `a,b`. These
conventions fix the vertex labels in `solver-a4-certificate.json`. Left
translation preserves arcs, so the one-recipient certificate for the identity
covers every recipient. There are 133 winning messenger states for that target:
all 132 distinct-position states and the terminal collision at the recipient.
The synchronous layers stabilize after 12 messenger moves, with sizes
`12,34,70,94,104,110,118,122,124,126,127,129,133`.

Deleting one arc from suitable universal witnesses of orders 19 through 24
gives the following additional attaining candidates for the separately
derived odd-budget upper bound. The checked graphs and deleted arcs are
recorded in `solver-odd-budget-delete.json`:

```
(m,I)=(37,272),(39,306),(41,342),(43,380),(45,420),(47,462).
```

## Parameterized five-type family: experimental, not yet an infinite theorem

For `k>=2`, let vertices be `(x,j)` with `x` in `Z/kZ` and `j` in `{0,1,2,3,4}`.
The first successor advances one step on the global directed `5k`-cycle:
`(x,j)->(x,j+1)` for `j<4`, and `(x,4)->(x+1,0)`. The second successor is

```
(x,0)->(x+1,0)
(x,1)->(x-1,2)
(x,2)->(x-1,4)
(x,3)->(x-1,3)
(x,4)->(x-1,1).
```

This is two-regular. Exact checks show universal delivery for **every
`4<=k<=40`** (orders 20 through 200), and failure at `k=2,3`.
Only the five recipient types in column zero need separate analysis because
column translations are automorphisms. Both independent solvers and explicit
certificates were checked for `k<=10`; the larger cases use the fast solver.
The per-type maximal ranks and status are saved in
`solver-five-type-family.json`.

The family was found by the reproducible finite search
`src/enumerate_small_voltage.cpp`: one permutation is the global cycle, the
other is a fixed permutation of types with voltages in `{-1,0,1}`. A finite
sample of lengths cannot establish the proposed theorem for every `k>=4`.
The physical interpretation of the second successor may assist its proof:
type zero moves right one column per move, while types `1,2,4` cycle among
themselves moving left one column per move, and type three also moves left.

An independent candidate is the Cayley graph on `A4 x Z/kZ` with generators
`(a,1),(b,0)`. It has universal delivery for every tested `k=1 mod 3`, through
`k=22`, but fails for the other tested residues with these particular
generators. See `solver-a4-cyclic-lifts.json` and
`solver-a4-voltage-search.json`; this remains finite evidence as well.

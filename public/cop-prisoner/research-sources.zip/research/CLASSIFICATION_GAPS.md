# Classification completion and proof boundaries

**Unknown-value gaps: none. Explicit-construction gaps: none.** Every admissible pair n>=1,0<=m<=n(n-1) has a proved exact value and a direct recipe or certified listed graph attaining it.

The independently replayed ledger contains 493,924 exact cells and zero unknown cells. It preserves all 492,834 earlier equalities and closes all 1,090 previously open audit cells, including all 101 canonical representatives. No representative is merely hidden by a support reduction at the final checkpoint. The numerical ledger and the separate explicit-construction audit have matching source versions.

## The final finite results

For m=12..21, the global maxima are respectively9,11,13,15,19,28,33,40,53,60. Their least attaining hosts are7,8,8,8,8,10,9,11,10,12. Larger hosts add isolates. Among smaller hosts, M(9,17)=24; M(9,19)=35; M(10,19)=38; M(10,21)=56; M(11,21)=58. The exact finite tables state every remaining entry.

The final small main values are M(9,20)=37,M(9,21)=39,M(9,22)=40,M(9,23)=44, and M(10,22)=60,M(10,23)=61,M(10,24)=61,M(10,25)=65. Every order-eight budget is exact, including M(8,40)=12. These give the previously missing vertex maxima M_V(9)=48 and M_V(10)=65.

At n>=12, the combined theorem covers every budget with the small-budget lookup, sparse parity formulas, main missing-pair formula, dense staircase and zero branch. The full tables cover n<=11. The sharp uniform main threshold remains12; the sharp uniform dense staircase threshold remains11.

## What closed the cases

Actual source/sink deletion compares with a smaller arrow budget without deleting arbitrary useful routing vertices. Two positive-indegree predecessors are needed for a live recipient; two nonsink successors are needed for a live source. Counting all source arrows and all sink arrows strengthens those capacities. The already settled smaller budgets then rule out whole support families and make the remaining comparisons finite.

Fixing incoming and outgoing degree multisets together is substantially faster than fixing only outgoing degrees. Partial incoming capacities, precise future-vertex symmetry, and unions of permanent camping losses reduce the residual graphs. Optimistic guarded paths retain the initial-source exception and final receipt; failure there is only a necessary obstruction. Every surviving graph is evaluated in the actual game.

Lower values were not presumed optimal:19 arrows improved from35 to38 to40; ten vertices with22 arrows improved from55 to60; ten vertices with23 arrows improved from56 to61. Complete maximization raises its cutoff only after checking a literal improvement. Earlier discarded branches stay below the final cutoff. Independent replay reproduces the increases.

One proposed shortcut incorrectly reused a camping-free bound as an unconditional family bound. Review caught it; the corrected eighteen-arrow proof directly enumerates the omitted families. Timeouts and the rejected shortcut remain in the private research log. None is an upper-proof dependency.

## Remaining boundaries

There are no remaining parameter gaps inside the stated mathematical objective. Finite upper proofs retain their precise computational premises: ordinary coverage and pruning review, complete independent leaf-game replay where stated, and separate sampled checks. Only designated cases have a second full graph enumeration. The full classification is not claimed formalized in Lean.

The September18 simplification replaces repeated sparse casework with one induction, gives a shorter pair-code construction proof above3n from order79, consolidates dense attachments, and lowers the odd periodic threshold from145 to98. These simplify proofs and dependencies; they do not close new numerical gaps. All earlier stronger guarantees and finite exclusions are preserved. The execution record is research/proof-slimming-execution.md; current build and deployment receipts state artifact status. Full Lean instantiation and further proof compression remain separate work. Broader theory of maximizing shapes, structural guaranteed-pair sets, and optimal delivery time remains parked. Historical gap inventories are retained under research/history with explicit superseded status.

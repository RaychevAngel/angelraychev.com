# Complete low main-interval row at order eight

13 September 2026. This note describes the source/coverage proof for the seven target exclusions and their literal attaining graphs. Final completion and independent full-leaf replay are recorded separately in `endpoint40_n8_low_receipt.json` when all runs finish. Until that receipt exists, this note is a proof plan with individually completed logs, not a promoted seven-cell theorem.

The intended exact row is

| m |17|18|19|20|21|22|23|
|---|---:|---:|---:|---:|---:|---:|---:|
| M(8,m) |19|21|22|24|25|28|29|

All seven lower graphs are literal fixed arrows with full alternating ranks in `research/endpoint40_n8_low_lower_certificates.json`. The separate literal checker replays every lower certificate. Constructing an attainer means reading its listed arrows; no graph search is needed.

## Two complete finite decision domains

For m=22,23, `src/endpoint40_n8_capacity.cpp` enumerates every positive missing-degree profile with sum56-m and all loopless rows under chronological suffix normalization. A zero missing row forces I=0 by camping at its source, so no counterexample is omitted. Profile generation, prefix camping, and suffix symmetry are the same complete methods proved in `endpoint40_exact_proof.md`; this source only parameterizes the budget/target and adds the conservative capacity bounds below.

For m=17..21, `src/endpoint40_n8_live.cpp` enumerates descending delivery-degree profiles, including zero-degree vertices. A guaranteed indirect source has degree at least two and contributes at most five pairs, so a target T requires at least ceil(T/5) such rows. The source includes every sorted degree vector of the correct budget satisfying this necessary condition, then every loopless row up to the already reviewed chronological equal-degree/equal-incoming suffix rule. The live-prune and game function bodies are frozen from `finish_tiny_live.cpp`; only the order guard and literal leaf emission change. Their ordinary source review and independent adversarial-prefix tests are in `endpoint40_tiny_live_review.md/.json`.

## Capacity additions in the missing-row producer

A delivery outdegree at most one makes its entire missing source row lose: camp at the sole outgoing neighbor, or observe that the source cannot leave at all. The degree profile determines this status even before its row is assigned. The producer counts the known row's missing mask in the loss union, and counts its prescribed degree directly for an unassigned row. No pair is counted twice.

A recipient with delivery indegree at most one cannot be an indirect recipient, by camping at its only delivery predecessor. That predecessor cannot be the source of a missing pair because its arrow to the recipient is present. Six already assigned missing predecessors suffice to force indegree at most one at order eight. The producer marks only the already fixed missing pairs in such a column.

For source capacity, every not-yet-excluded row of delivery degree at least two contributes at most its missing degree. Completed source-camping rows are removed. A row of delivery degree two with a sink among its successors also fails: the cop camps at the other successor, while a nonterminal move into the sink cannot progress. All sink statuses come from prescribed degrees. Summing the remaining row capacities overestimates the score. Their number is qcap.

For columns, let d be the already installed delivery indegree of a recipient. Current missing indegree plus the unassigned row count bounds its possible final indegree. A column that could attain indegree at least two contributes at most7-max(2,d), and reaching that status costs at least max(0,2-d) additional arrows. Counting as many cheapest columns as the remaining delivery budget could afford gives rcap; ignoring individual tail restrictions can only make it too large.

For actual live row/column counts q,r, their rectangle has qr possible ordered pairs. At least max(0,q+r-8) of these are diagonals. Since live rows emit at least2q arrows and live columns receive at least2r, at least max(0,2q+2r-m) arrows lie inside the rectangle. Arrows and diagonals are disjoint. Hence

    I <= q*r - max(0,q+r-8) - max(0,2*q+2*r-m).

The source takes the maximum of this expression over BOTH0<=q<=qcap and0<=r<=rcap using a two-dimensional prefix-maximum table. It does not assume that simply substituting qcap,rcap is monotone. These are the same conservative incidence and column-cost estimates in the reviewed seven-vertex enumerator.

## Full game and independent replay

Every complete graph still capable of the target under the static necessary conditions is evaluated by an explicit alternating AND/OR least attractor. It uses all legal arrows and waits, terminal receipt before collision, excluded nonterminal collisions, and every permitted initial cop. The source emits each graph as literal row masks and its exact evaluated score. An evaluated maximum below the target is never promoted to a global maximum; the complete target exclusion plus the separate lower graph is the argument.

`src/endpoint40_n8_leaf_replay.cpp` imports no producer or game code. It reconstructs every emitted graph and independently computes the compressed messenger/pursuer least fixed point. It checks looplessness, exact budget, every printed score, the maximum against the exclusion target, the final complete flag, and exact correspondence between emitted leaf count and the completed producer summary. Every saved leaf is replayed; there is no sampling or orbit assumption.

For large leaf sets this is a full independent actual-game computation on each literal graph, rather than stored ranks for every duplicate graph. The positive attainers retain full ranks. This proof boundary is ordinary reviewed enumeration plus independent exhaustive leaf replay, not a second full graph traversal or a Lean formalization.

## Split runs and timed-out pilots

Every claimed exclusion must be covered by completed, source-identical profile intervals. Their independently counted union must equal the whole applicable degree-profile list, without a gap. Historical timeouts do not supply a completed interval in the final receipt. At m=20, the original60-second full pilot timed out in its last profile; the formal receipt will use a separately completed head[0,118) and completed tail[118,119).

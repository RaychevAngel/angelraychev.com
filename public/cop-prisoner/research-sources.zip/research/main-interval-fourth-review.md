# Independent arithmetic regression of the fourth main-interval checkpoint

The source-independent checker is `src/main_interval_fourth_review.py`; its
machine-readable output is `research/main-interval-fourth-review.json`.
The input baseline is the frozen compressed
`research/main-interval-fourth-baseline.json.gz`, and the current input is
`publication/classification-coverage.json`. Neither input is modified.

## Result

All 493,924 finite-box cells were compared. Every one of the previous
444,568 exact values is unchanged. No lower bound decreased and no upper
bound increased. Exactly 42,130 previously unresolved values became exact.
Their selected lower-bound providers are 36,405 circle entries and 5,725
layered-guide entries; these attribution counts do not claim that the
mathematical domains of the two families are disjoint.

The new canonical unresolved total is 6,416:

- 254 sparse representatives, unchanged;
- 6,141 main-interval representatives;
- 21 dense representatives, unchanged.

The entire retained box contains 7,226 unresolved cells because it also
contains repeated isolate-equivalent sparse cells. The canonical and raw
counts are therefore intentionally different.

## Independent checks

The checker imports neither the coverage generator nor any construction
module. It expands the piecewise-affine row encoding itself, checks every
integer budget without relying on stored totals or unresolved intervals,
and reconstructs all remaining interval lists. The recomputed totals and
lists agree exactly with the current ledger.

For the circle ranges it enumerates only the explicitly permitted integer
parameters, counts the residue classes directly, and applies the compulsory
and envelope counts. For the layered ranges it independently counts the
four distinct compulsory arrow classes, the binomial guide capacity, and
the two optional arrow classes. These are formula checks, not graph searches.

Every newly exact cell is supported by one of these ordinary theorem
ranges on the same order and budget, attaining `n(n-1)-m`. The checker also
validates every occurrence of the new lower-bound providers, including
isolate padding and a disjoint zero-contribution component when specified.
It checks the component's order, capacity for the remaining arrows, the
base budget, and the claimed contribution. In all, 54,387 such source cells
were checked. Every direct interval implied by either new family within
the box is fully incorporated; no further direct parameter interval was
silently omitted.

The independent graph/proof validation of these new source families is a
separate receipt, `research/main-interval-new-independent-checks.json`.
This arithmetic audit does not substitute a formula for that proof review.

## Shape of the remaining main interval

Every remaining main-interval cell at order at least 43 has `m < 3n`.
All unresolved main cells with `m >= 3n` are confined to orders at most 42.
Thus the previous broad middle-density gap has been reduced to a much
smaller order range; this does not assert that the low-budget interval
`2n < m < 3n` is complete above 42.

The entire main interval is exact at orders 104 through 114 in the
independently checked box. Combining the two new orders 104 and 105 with
the preceding ordinary construction for every order at least 106 gives
the full main interval for every order at least 104. This is distinct
from the stronger upper-main threshold of 43. The exact remaining bands
at every order are recorded in the JSON receipt under `main_remaining_rows`;
no larger enclosing box is presented as though every cell in it were open.

The expanded dispatcher has also been inspected and its checks executed.
The independent arithmetic checker replays its full covering chain at every
order 43 through 105, recomputing each family's parameter conditions and
intervals. This includes independently counted equal-weight hub capacity
and precise references to the saved sparse envelopes. The dispatcher uses
the preceding constructor unchanged for every order at least 106; its
regression checks compare actual outputs at selected boundaries in that tail.
The finite overlap plus the already proved infinite tail establishes the
two stated thresholds. No new Lean claim is made.

The review corrected an introductory endpoint typo in the overlap proof:
the certified sparse intervals are 208 through 316 at order 104 and 210
through 327 at order 105. Both still overlap the interval beginning at
`3n`; the correction changes neither the graph recipes nor the theorem.

## Reproduction and source identities

Run from the project directory:

    python3 src/main_interval_fourth_review.py

The receipt records hashes of the frozen baseline, current ledger, coverage
source, new constructor sources, and expanded dispatcher when available.
Regenerate after their final shared edits so those identities describe the
published checkpoint. The checker only writes its assigned review receipt.

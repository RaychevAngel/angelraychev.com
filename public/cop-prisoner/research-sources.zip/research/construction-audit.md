# Audit of the original layered subset construction

12 September 2026. Original construction: Alexandra Ignatova, manuscript dated February 2024, with Angel Raychev as mentor. The corrected proof and exact count below are September 2026 work assisted by Astra 6 through Codex. Original sources in Downloads are unchanged.

## Outcome

The construction is useful, but its printed count is false. For the balanced original family with `q=2x` coordinates, `a=binom(2x,x)/2`, and `N=2a+4q`, the exact answer is

\[
I(G)=2a(N-1-q)+4q.
\]

For the first admissible parameter `x=3`, this is **764**, not the draft lower bound **1252**. The independently implemented game solver agrees with 764 on the explicit 44-vertex, 240-arc graph. The formula is proved below without relying on that computation.

The leading term is still `N²−O(N log N)` along the original constructed sizes. No interpolation is inferred from this fact. New constant-degree candidates investigated elsewhere may supersede its extremal lower bound, but do not change its historical provenance or this audit.

## Exact arcs

Allow two row families F and F' on coordinates `[q]`, of sizes a and a'. There are vertices `A_X` for X in F, `A'_Y` for Y in F', and `b_i,b'_i,c_i,c'_i` for each coordinate i. The only arcs are:

- `A_X → b_i,b'_i` if i belongs to X;
- `b_i → A'_Y` if i belongs to Y, and `b'_i → A'_Y` otherwise;
- `A'_Y → c_i,c'_i` if i belongs to Y;
- `c_i → A_X` if i belongs to X, and `c'_i → A_X` otherwise.

This is exactly the incidence pattern in the original manuscript and its figures. It is a four-layer directed cycle, where the two primed/unprimed coordinate classes form one layer each.

The following sufficient conditions replace the unnecessary balancing requirement in the pursuit proof:

1. Each row family is an antichain, with every row containing at least two coordinates.
2. In each row family, its 2q literal columns (`i belongs`, `i does not belong`) form an antichain under inclusion, and each contains at least two rows.

The balanced original family satisfies these conditions. Its rows have size x≥3. Its literal columns all have size a/2≥5. No two literal columns are equal: any equality would remain true on complementary rows and therefore on all x-subsets of `[2x]`, which is impossible for distinct literals when x≥2. Equal cardinalities then imply incomparability. The corrected complementary selection lemma establishes such a balanced family exactly for positive x not a power of two.

## Safe progress lemma

In this graph, from every noncollision state the messenger can advance one layer and survive the pursuer's next move.

If both players are in the same layer, their outgoing neighborhoods are incomparable; choose a messenger successor not in the pursuer's outgoing neighborhood. Neither player has an arc inside its own layer, so waiting by the pursuer is harmless. If the pursuer is in the next layer, choose a successor different from its current vertex, using outdegree at least two. The pursuer can only wait there or advance another layer. If the pursuer occupies either remaining layer, it cannot reach a chosen successor in one move. Thus the claim handles every legal pursuer response, including waiting.

The needed outgoing-neighborhood incomparability follows from row incomparability in the A layers and literal-column incomparability in the coordinate layers.

## Every recipient in A or A' is guaranteed

First, from any `A_X` there is a guaranteed delivery to any specified `A'_Y` within two messenger moves. If the pursuer starts at another `A_Z`, choose `i∈X\Z`, and choose between `b_i,b'_i` according to whether i belongs to Y. The intermediate is outside the pursuer's closed outgoing neighborhood. If the pursuer starts in the intermediate coordinate layer, avoid its occupied coordinate, using |X|≥2, and again choose the correct polarity. A pursuer in either other layer cannot reach the intermediate next turn. Delivery to `A'_Y` on the next messenger move is terminal, even if the pursuer now occupies it. The reverse direction through C is identical.

For a general source and a recipient in A, use the safe progress lemma at most three times to reach A', surviving after each pursuer response. Then use the two-move delivery just proved. For a recipient in A', reach A analogously. Thus these guarantees take at most five messenger moves. In particular, this proof explicitly distinguishes a safe intermediate arrival from a terminal arrival.

There are `a+a'` such recipients, each with `N−1` distinct sources and q direct predecessors. Therefore their exact contribution to I is

\[
(a+a')(N-1-q).
\]

## Coordinate recipients: the missed camping obstruction

For target `b_i` or `b'_i`, its entire predecessor set is

\[
S_i=\{A_X:i\in X\}=N^+(c_i).
\]

Unless the source is `c_i` itself, the pursuer may start at `c_i` and wait. Every indirect delivery must enter S_i, where the pursuer captures on its next move before the final delivery action. Waiting elsewhere forever is not success. Therefore **the only possible indirect source for either target is `c_i`**.

That exceptional source does win in two moves. Its available intermediates are S_i. A pursuer in the same C layer has an incomparable outgoing neighborhood, so cannot cover all of S_i. A pursuer in A occupies at most one member and has no arcs within A; |S_i|≥2. A pursuer in either remaining layer cannot reach S_i in its next move. Pick a safe intermediate and then deliver. Thus `(c_i,b_i)` and `(c_i,b'_i)` both count.

Symmetrically, the only indirect sources for `c_i,c'_i` are `b_i`, and both pairs win. There are exactly 4q coordinate-recipient pairs, proving

\[
\boxed{I(G)=(a+a')(N-1-q)+4q.}
\]

Several original lemmas asserting many indirect A-to-coordinate or coordinate-to-coordinate pairs are therefore false. The source's claim that the pursuer must align with the messenger's layer is specifically refuted by this stationary camping strategy. The original A-to-A' quantifier also needs the repaired coordinate choice depending on the observed pursuer row, as above.

## Reproduction

`src/original_construction.py` builds the corrected balanced family and graph, verifies the exact incidence hypotheses, and prints the theorem count. Run:

```sh
python3 src/original_construction.py --x 3 --solve
```

The solver is a saved computational cross-check, not the universal proof. Larger x grows exponentially and should not be run without estimating graph size.

## Additional independent attack on a proposed extremal bound

A recipient of indegree two can have many indirect guaranteed sources. Take the directed circulant on Z/23 with arcs `v→v+1,v+3,v+7`, append a new sink t, and add `0→t,8→t`. Every one of the 23 old vertices can guarantee delivery to t, so t alone has 21 indirect guaranteed sources. Both the fast eliminated-turn solver and the independent explicit alternating-state attractor returned the same winning masks for this recipient. This is a finite counterexample to a proposed assertion that an indegree-two target has at most one indirect source; it is not a theorem about all such circulants.

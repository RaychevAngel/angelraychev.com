# Sparse stability development

Date: 2026-09-12. Authoring agent: Astra 6 via Codex, sparse-support subtask.
Scope: ordinary parametric proof work; no graph enumeration, publication,
shared manuscript rebuild, or shared-file edits. The only authored files
in this subtask are this log and `paper/sparse-stability.md`.

## Objective and original proposal

The initial even target was the dichotomy: at `m=2k`, either the
nonisolated support is a `k`-vertex two-in/two-out graph, or
`I <= k^2-4k+5`. This follows by retaining losses that were discarded in
Theorem 6. The odd target was to parametrize Theorem 53's 23-arc support
reduction above `k^2-4k+6`, rather than repeat an exceptional-case proof
for each odd budget.

## Strengthened even statement

The first even cutoff is not the cleanest obtainable bound. It can be
improved by two to `(k-1)(k-3)` for every `k>=6`, with an ordinary proof.

The main new point concerns `q=r=k-1`, `b<=1`. At least two active
sources have indegree zero. The recipient set has only two total surplus
indegree units. Unless one selected source points to an indegree-two
recipient (giving a zero column), both must point to precisely the same
two indegree-three recipients, giving zero source rows. This excludes
the two highest values left by the raw rectangle bound.

Two other losses must not be discarded:

- For `q=k,r=k-2,b=0`, all arcs start in the outdegree-two set, and all
  recipients are sinks. At least `k-2` source rows are zero. The
  directionally dual case uses indegree-zero predecessors explicitly.
- For `q=r=k,A!=B`, if `b>=3`, deleting two zero columns still leaves a
  diagonal exclusion. If `b<=2`, both zero-row and zero-column counts
  leave at most `b^2` eligible pairs, not merely `b` times all rows.

The proof distinguishes all high active-set cases and covers the
remaining rectangle by direct numerical inequalities. Its declared
ordinary-proof range is `k>=6`. The known exact `M_E(10)=6` extends the
statement to `k=5`, using that existing finite proof. It fails at `k=4`:
the known six-vertex eight-arc graph has `I=4`, larger than3.

## Odd statement and proof audit targets

The odd cutoff remains `T=k^2-4k+6`. Above it, the only surviving
possibilities are:

1. An induced `k`-vertex two-regular or one-extra-arc core with at least
   the original graph's indirect count.
2. A `k+1`-vertex graph with distinct degree-one source/recipient
   exceptions; split according to whether their connecting arc exists.
3. A `k+1`-vertex graph with one common degree-one exception.

The arithmetic proof works uniformly for `k>=3`. The double-deletion
case `b=k-3` must retain `max(0,k-5)` diagonal exclusions: substituting
the possibly negative expression `k-5` would be invalid at3 and4.
With the maximum, those cases give exactly the required cutoff. At
`k=0,1,2` the conditional assertion is vacuous by the existing elementary
small-budget values.

For induced-core reductions, the proof uses a real strategy implication:
all counted endpoints lie in the active core; a successful messenger
path cannot visit an outside sink or an inaccessible outside predecessor.
Restrict the pursuer to the core to conclude that an original guarantee
is also a core guarantee. No blanket monotonicity under deleting arcs
or vertices is invoked. When the two crossing arcs use the same outside
vertex, that vertex may be a useful intermediate and MUST be retained
as the third exception family.

No invariance under reversing the digraph is assumed. Every zero-row
argument using sinks is stated separately from the zero-column argument
using indegree-zero predecessors.

## Numerical consequences pending independent review

From the even theorem and already verified small-core facts:

`M_E(12)<=15`, `M_E(14)<=24`, `M_E(16)<=35`, `M_E(22)<=81`.

These are new upper bounds, not exact values. Their numerical premises
are respectively `M(6,12)=7`, `M_V(7)=21`, `M_V(8)=32`, and
`M(11,22)<=81`. No new exhaustive search is required for these
consequences. The odd theorem recovers the previous odd upper bound and
equality structure; it does not supply new small odd exact values on its
own.

## Bounded arithmetic verification

A Python exact-integer check visited all integer triples `(q,r,b)` with
`0<=q,r<=k` and `0<=b<=min(q,r)`, including triples not necessarily
realizable by a graph. Each triple was sent to the same numerical case
as the written proof; the resulting cap was compared with the theorem's
cutoff. The runs covered every `6<=k<=50` for the even proof and every
`3<=k<=50` for the odd proof. All 1,217,795 cases passed in 0.38 seconds:

- Even numerical remainder:601365; rectangular corner:2430;
  second corner:1260; off corner:2520; full-active mismatch:1260.
- Odd numerical remainder:605192; off corner:2544;
  lower-intersection cases:1224.

The odd outside-core loss expressions were also checked strictly below
the odd cutoff at every tested `k`. This check only attacks arithmetic
and omitted numerical cases; the written proofs, not the finite test,
establish the unbounded parameter range and game-theoretic premises.
An initial arithmetic-only loop set to200 was deliberately interrupted
to keep the check small; no completion claim is made for that loop.
No graph construction or exhaustive graph enumeration was run.

## Verification status

The parent agent independently reviewed the saved proof line by line,
including all active-set corners, the two-surplus-unit trichotomy,
diagonal exclusions after deleting rows and columns, and the actual-game
restriction to induced cores. Its review returned approval of both
theorems and the four numerical corollaries. It separately checked the
odd arithmetic at3 and4, and the equality-shape consequence at5. The
parent will store its independent audit separately. This is an ordinary
proof with independent review, not a Lean proof. The bounded arithmetic
check above validates only the numerical split; it does not replace the
game-theoretic reasoning.

## Bounded construction continuation

The strongest new small-budget opportunity is an attaining witness for
`M_E(22)=81`. Theorem 56 restricts any such witness to eleven vertices
and two incoming/outgoing arcs everywhere. There are88 missing pairs.
A source camping obstruction loses at least8 pairs, so none is allowed.
A predecessor camping obstruction must therefore come from an outside
cop whose two outgoing neighbors equal the target's two predecessors;
it loses precisely the7 indirect sources other than that cop. Two
different camped targets would already lose14 pairs. Two distinct cops
covering the same predecessor pair would have duplicate outgoing pairs,
which is a forbidden source obstruction.

Thus an81-witness must have exactly one directed diamond, no directed
transitive triangle, and no duplicated outgoing pair. The old complete
camping-free eleven-vertex enumeration has maximum66, so zero diamonds
cannot attain81. A construction-first search limited to20--30 seconds
in this sharply defined class could settle the22-arc maximum outright
if it finds81.

The parent subsequently authorized that bounded construction-first run,
with a30-second cap and separate source/receipt. The new source
`src/one_diamond_eleven_search.cpp` preserves the old enumerator and
uses only permutation-factor coverage and static source/predecessor
camping pruning. It completed all14 first-permutation cycle types in
2.31915seconds, visiting7016903partial nodes and evaluating484471
one-camping-pair leaf games. The best count was71, matching an existing
lower bound; no81-witness was found. The raw search result, source and
binary hashes, and actual command are in
`research/one-diamond-eleven-search.json`.

The implemented class is slightly larger than the distinct-endpoint
diamond class: it also permits the single camping cop to equal the
recipient. Such a graph loses at least8 missing pairs in that column
and cannot attain81, but including it is harmless for a construction
search or subsequent exclusion argument. All leaves are evaluated by
the existing synchronous actual-game recurrence copied into the new
source. No independent software review or upper-bound promotion is
claimed from this run. The parent was notified of its unexpected full
completion. No further search was launched.

# Dense phase2: finite holes, explicit witnesses, and revised domains

This is a research log and ordinary proof supplement, not an update to the
published theorem files. The parent is independently reviewing all promotions.

## 1. Eleven-vertex core: found and separately checked

Let F be the missing-arc graph on vertices0,...,10. Its outgoing pairs are

```
0: 4,8       1: 9,10      2: 8,9       3: 7,10
4: 0,1       5: 2,6       6: 3,5       7: 3,4
8: 2,7       9: 0,5      10: 1,6
```

Every vertex has indegree and outdegree2. Thus its complement G has88 arcs.
Every one of its22 missing pairs wins in at most two messenger moves.

Here is an ordinary finite proof, with no reliance on optimization being
correct. For every arc s→t of F, put D(s,t)=F+(s) union F−(t). Directly checking
the above eleven two-element rows shows that the only row contained in D(s,t)
is row s. The22 danger sets, with the source repeated for its two destinations,
are written explicitly in `dense-phase2-certificates.json`. Consequently, for
every cop c≠s choose u in F+(c) outside D(s,t). The moves s→u and u→t exist in G,
while the cop cannot reach u from c in one move, including by waiting. Receipt
therefore occurs on the second messenger move regardless of the cop's reply.
Pairs already adjacent in G arrive immediately. This proves the claim.

The witness was found by a bounded annealing search with exactly two outgoing
missing arcs per row and no indegree constraint. It appeared in under a second;
the final indegrees happened also to be2. The search is only a discovery tool.
`src/dense_phase2_certificates.py` independently uses literal legal-move sets,
with no imported bit-mask checker, to validate every actual game witness. Its
receipt contains220 explicit intermediate vertices, one for every pair/cop.
The prior bit-mask criterion also passed separately.

**Consequence:** combine this finite core with Theorem58's even construction
for n>=10 and odd construction for n>=13. The dense endpoint now has a universal
two-move construction for every n>=10, with no omitted order.

## 2. Complete staircase for every n>=20

Assume the previously proved universal upper bound and the existing generic
core/functional composition lemmas. For n>=20 and 1<=r<=n,

    M(n,n(n−3)+r) = 2n−r−ceil(r/2)−1.

All counted pairs have explicit strategies taking at most two messenger moves.

Proof: r=1 uses the already proved four-vertex attachment for every n>=16.
For r>=2 put k=n−r. The functional block on r vertices has r missing arcs,
j=floor((r−2)/2) winning pairs, and q=floor((r−1)/2) roots with no incoming
missing arcs. If k>=10, use the new complete core family on k vertices and the
existing composition lemma. This gives2k+j wins and2k+r missing arcs. If k<=9,
then r>=11 and q>=5. There are at least binom(5,2)=10 distinct root pairs, enough
to give every one of k added vertices its own two-element missing neighborhood.
The root-extension lemma again gives2k+j wins and2k+r missing arcs. Finally,

    2k+r=2n−r,
    2k+j=2n−r−ceil(r/2)−1.

This matches the universal bound. For k=0 simply use the functional block.
The existing argument at n=19 still has a genuine construction gap at r=10,
k=9: q=4 gives only6 pairs. The new theorem does not settle that finite case.

## 3. Four odd robust-envelope holes: all repaired

Use Theorem58's even base on2k vertices P_i=i,L_i=k+i. Introduce w=2k,
replace P0→L0 and Pj→Lj with the two paths through w, and retain the standard
optional arcs P_i→P_(i+6), L_i→L_(i+4), together with w→P_z. All indices are modk.
Make the following explicit finite substitutions in the optional arcs:

* n=23,k=11,j=5,z=0: replace L1→L5 by L1→L7 and L7→L0 by L7→L2.
* n=25,k=12,j=5,z=2: replace L1→L5 by L1→P10.
* n=27,k=13,j=6,z=2: replace L2→L6 by L2→P12.
* n=31,k=15,j=5,z=0: replace L1→L5 by L1→P10.

Each case has2n compulsory missing arcs and n distinct optional missing arcs.
For every missing pair in the full3n-arc envelope and every cop distinct from
its source, the receipt provides a safe intermediate among the cop's compulsory
two missing neighbors. Removing any subset of optional missing arcs only shrinks
the danger set while retaining that compulsory witness. Therefore **every
subset**, not merely one prefix at each cardinality, has the universal two-move
property.

These are finite directly checked constructions, not a claim that the same
substitution works at every odd order. Together with the existing all-even
n>=22 family, n29 witness, and odd n>=33 family, they establish a robust optional
envelope for every n>=22 with every missing budget2n<=h<=3n.

The parent independently verified the four envelopes using literal legal moves
and every prefix budget. Its separate receipt is
`research/dense-phase2-independent-root-check.json`. Its independent review of
the11-core and revised staircase was pending when this log was first written.

## 4. Denser optional families: subsequently resolved

The11-core and four odd holes fully solve this bounded lane's first two goals.
The subsequent structural investigation also succeeded. Full ordinary proofs
are in `research/dense-phase2-uniform-proof.md`: one residue-five envelope works
at every n>=30 with cap n²/10−O(n), and one parity envelope works at every n>=44
with cap n²/4−O(n). Both have2n compulsory arcs, arbitrary optional subsets, and
universal two-move delivery. Their precise cap functions and small-order
dominance comparisons are given there. These conclusions are supported by
separate bounded receipts, but parent review remains required before promotion.

# Independent audit of the one-excess matching enumeration

The matching reduction, symmetry convention and partial pruning in
`src/small_exceptional_one_excess.cpp` pass independent review.
The completed eleven-vertex receipt computes a maximum within the
minimum-degree-two, camping-free class. Its value 74 is not asserted
to be the unrestricted maximum.

## Hall and residual degrees

With all incoming and outgoing degrees at least two and `2n+1` arcs,
precisely one outgoing degree and one incoming degree are three. Any
tail subset `S` emits at least `2|S|` edges. If its head neighborhood
had at most `|S|-1` vertices, it could receive at most
`2(|S|-1)+1`, a contradiction. Hall therefore supplies a perfect
matching, which is a loopless permutation factor.

The residual outgoing degrees are one except at `U`, where there are
two; the residual incoming capacities are one except at `V`, where
there are two. This residual graph need not be a permutation. The code
correctly enumerates row sets against capacities instead of assuming
a second matching.

## Complete symmetry convention

Put the matching in canonical disjoint-cycle form. All cycle lengths
are at least two. Its centralizer rotates cycles and exchanges equal-
length cycles, so is transitive on the vertices belonging to cycles
of a fixed length. Thus `U` may be one representative vertex for each
distinct cycle length, with `V` arbitrary, including `V=U`.

Ordinary rows choose one residual neighbor; row `U` chooses an unordered
pair represented by `a<b`. Loops and matching arcs are excluded, and
the incoming capacities are enforced. Every permissible marked graph
has a representative in these choices.

## Pruning at eleven vertices and 23 arcs

There are 87 missing pairs. If any incoming or outgoing degree is below
two, at least nine missing pairs in its column or row fail. Thus
`I>=85` forces the minimum-degree hypothesis. In that class every
degree is at most three. Source camping kills at least seven missing
pairs; predecessor camping kills at least six after allowing the cop
itself as a possible exceptional source. Neither can coexist with
`I>=85`.

The source tests use only completed rows. The predecessor tests use
only columns whose residual capacity is full. Partial cop coverage can
only increase. The exceptional row becomes complete only after both
residual arcs are chosen. Hence the incremental rejections are sound.
The exact least-attractor routine has the established waiting and
receipt-priority semantics.

## Receipt and scope

`research/small-exceptional-one-excess-11.json` reports complete
enumeration: 14 cycle partitions, 330 marked patterns, 31,536,058
nodes and 792,080 camping-free leaves. Their maximum indirect count is
74, with a 10.92-second run. This safely excludes `I>=85` at the stated
order and budget, which is the requested application.

This auditor reviewed the ordinary completeness proof and actual source
against the completed receipt; it did not claim a second full run.
This is finite computer-assisted evidence, not new Lean verification.

# Independent review of the nineteen-arrow classification

The final package
`research/sparse_finish_nineteen_exact_manifest.json` passes independent
ordinary/source coverage review and complete finite leaf replay. The verified
receipt is `finish_nineteen_review.json`: all four final ranges and all three
literal certificates pass. No historical incomplete range is evidence here.

The resulting row is

`M(9,19)=35`, `M(10,19)=38`, and `M(n,19)=M_E(19)=40` for every `n>=11`.

The least host attaining the global value40 is eleven.

## Ordinary reduction and dependencies

The smaller global values used here have independent approval: `M_E(16)=19`,
`M_E(17)=28`, and `M_E(18)=33`. The eight-vertex fixed values at budgets17,
18,19 are respectively19,21,22. No conclusion about budget19 is used to
establish any of those inputs.

Only actual sources and sinks are deleted. An old-source messenger cannot
enter an indegree-zero source; a messenger delivering to an old target never
needs to enter an outdegree-zero sink. Restricting the cop to the remaining
graph compares every old pair with that graph. The deleted row or column is
the only extra contribution.

Every live target needs two predecessors of positive indegree, and every
live source needs two nonsink successors. Otherwise a cop camps at the only
usable intermediate vertex; it differs from the initial source of a counted
pair, or else the pair would be direct. The deleted source's outgoing arrows
cannot supply the first capacity, and the deleted sink's incoming arrows
cannot supply the second. Consequently, for other degree `d>=2`,

`I(G)<=M_E(m-d)+floor((m-d)/2)`.

At `d=1`, the removed row or column contributes zero. Repeated one-arrow
fresh-sink attachments justify using a larger global budget as an upper
bound for any smaller budget: they preserve the old score. These are separate
original-direction proofs for sources and sinks, with no reversal assumption.

At budget19, all nonisolated zero-degree cases therefore have score at most
`max(M_E(18),M_E(17)+8)=36`. For the fixed nine-vertex cell, deleting the vertex
leaves eight vertices and at most `8-d` potential extra pairs. The bounds are
21 when `d=1`, `M(8,17)+6=25` when `d=2`, and `M_E(16)+5=24` when `d>=3`.
An isolated vertex leaves `M(8,19)=22`. Thus the full zero-degree bound on
nine vertices is25, including isolates. Arbitrary zero-score rows or columns
are never removed from an actual game.

For positive support `N`, active source and target counts satisfy
`q,r<=min(9,19-N)`. Subtracting both the necessary diagonal overlap and the
necessary direct arrows gives

`q*r-max(0,q+r-N)-max(0,19-2N+q+r)`.

The reviewer independently maximizes this expression for every support
12 through19. The maxima are38,31,24,16,9,4,1,0 respectively. Positive support
above19 is impossible. Support at most eight is already bounded by the
retained vertex upper32. Only positive supports9,10,11 require enumeration.

On support11, exceeding40 requires `q=r=8`: the maximum with either count
at most7 is40. The nineteen arrows then force exactly eight degrees2 and
three degrees1 on each side. The intersection `h` of the two three-vertex
degree-one sets can be0,1,2,3; the eligible count is `46-h-w`, with `w>=0`
counting complement-to-complement arrows. This yields exactly four joint
degree multisets, including every camping pattern.

## Independent degree coverage and source audit

The complete producer generates positive outdegree and indegree partitions,
then distributes the incoming multiset among vertices, sorting only within
equal-outdegree classes. Its partial overlap is a lower bound on the final
overlap, so a partial-profile rejection cannot omit a better completion.

The reviewer regenerates indegrees with a direct sum recursion instead of
iterating the producer's incoming partitions. It compares entire degree sets
against a producer variant that emits the full inventory before entering
adjacency recursion. The sets agree exactly:69 profiles on nine vertices
above35,80 on ten vertices above the initial35, and4 on eleven vertices
above40. The four eleven-vertex profiles have degree-one intersections0,1,2,3
in the producer's actual order. The completed ranges `[1,1]` and `[2,4]` are
therefore disjoint and exhaustive.

The fullmax source is byte-identical to the one independently reviewed in the
eighteen-arrow package. It has no inherited family skips. The earlyguard
variant is checked as an exact textual transformation: it invokes the same
guarded test one row earlier and adds progress logging. Applying a sound
prefix bound earlier does not strengthen its assumptions. Neither variant
changes messenger or cop moves.

Outgoing rows are completed one at a time. Only future vertices with the
same desired degree pair and identical incoming prefix may be permuted;
these permutations fix all completed rows. Prefix choices within each such
class therefore retain a representative of every completion. Earlier targets
are singleton choices, loops are forbidden, both arrow directions are
independent, and degree capacities are conservative.

## Permanent losses and changing thresholds

The dynamic eligible upper subtracts already fixed arrows between inactive
complements. Future such arrows can only lower it. Camping losses are unioned
before counting, omit diagonal/direct pairs, and preserve the exception that
the cop cannot initially equal the source. For an unfinished source, a counted
column loss concerns an already full column, so it cannot later become a
direct edge and be subtracted twice.

The guarded test grants the messenger every individually feasible future
arrow and gives the cop only already fixed arrows. It allows the initial
escape, computes internal reachability outside a stationary cop's closed
outneighborhood, and treats the final target edge separately because receipt
precedes capture. Failure in this easier messenger game proves a permanent
loss. No guarantee relation is used as if it were messenger reachability.

The nine-vertex run starts and finishes at35. The ten-vertex run starts at35
and raises its threshold to38 only after computing the exact score of a
literal graph. The independent replay begins at35, preserves the original
inventory order, and records that update with its actual outgoing masks.
Every earlier prune bounded its branch by35, hence also by the final38.
Every later prune uses the attained38. All profiles were generated before
the update, and an initially omitted profile was bounded by35. Thus increasing
the threshold preserves the final upper proof. Both eleven-vertex ranges
start and finish at40, without updates.

Every reached leaf is solved independently for all targets with the explicit
two-turn queue in `finish_alternating_review.hpp`, rather than the producer's
compressed synchronous recurrence and early target cutoff. Receipt takes
precedence over nonterminal collision in both. The replay requires identical
profile, node, leaf, camping, guarded, early-return, threshold, and literal
counters. Independent asymmetric games additionally check sampled guarded
losses; those samples supplement the ordinary argument and are reported
separately from the complete leaf replay.

The chosen profile1 receipt is the clean completed
`sparse_finish_positive_fullmax_n11_m19_t40_p1_complete.json`. The incomplete
earlyguard profile1 trial and earlier timed prefixes are explicitly excluded.
Each used range reports completion and the exact selected profile count.
Tiny-deadline controls require a nonzero exit code and `complete=false`.

## Literal attainment and evidence boundary

The three literals have9,10,11 vertices, nineteen arrows, and scores35,38,40.
The reviewer checks their supplied full ranks and closed losing regions
directly, without importing their producer or fixed-certificate checker.
All1458,2000,2662 alternating-state obligations respectively must pass,
including every possible initial cop position other than the source.

The nine-vertex positive upper35 and full zero-degree upper25 match its literal.
On ten vertices the positive upper38, smaller-support upper35, and zero-degree
upper36 match its literal. At larger hosts all positive support cases are at
most40 and all zero-degree cases at most36. The eleven-vertex literal extends
by isolates. The strict ten-vertex upper38 proves the least attaining host11.

This review supplies an ordinary source/coverage proof, independent complete
joint-degree sets, and an independently solved game at every reached leaf.
The adjacency/pruning traversal is retained from the reviewed producer. It
does not claim a second independently designed full graph enumeration or
new concrete Lean instances.

All **153** distinct joint-degree patterns are covered. The complete replay
independently solves **291,301** reached leaf games, with every traversal
counter matching the primary receipts. It also verifies11,853 claimed losing
pairs at1,253 sampled guarded states. All four tiny-deadline controls report
incompletion correctly, and the three literal checks satisfy all6,120 state
obligations. The ten-vertex incumbent update is exactly35 to38; all other
thresholds remain fixed. No process remains running.

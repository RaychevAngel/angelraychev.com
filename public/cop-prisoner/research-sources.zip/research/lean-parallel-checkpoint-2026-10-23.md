# Three-lane Lean continuation — 23 October 2026

The user authorized three parallel efforts and requested the next percentage
checkpoint after both the irregular-degree exclusion benchmark and the uniform
six-type construction are complete. The previous planning estimate was 60%,
with a 50–70% uncertainty interval; it is not a count of cases or modules.
This milestone instruction resumes work after the earlier quota checkpoint.

The accepted starting release is the source-pinned 148-module replay. New
files and individually compiled lemmas below do not update that release's
receipt or justify a full-classification claim.

## Ownership and completion conditions

- Finite lane: a reusable prescribed-degree row-prefix checker, plus an
  unrestricted upper bound 13 for positive-in/out-degree ten-vertex graphs
  with fourteen arrows. Complete degree normalization and every symmetry,
  pruning, and branch obligation must be proved.
- Sparse lane: an explicit six-type attainer at every support order at least
  85, with concrete graph-to-arena projection, all local certificates, safe
  composition, exact counts, and actual-game interpretation. The lower-order
  finite bridge and odd-budget family remain separate obligations.
- Main-interval lane: separated pair-code construction, counts, arbitrary
  optional subsets, prescribed parameters, and the shortest sufficient range
  overlap chain. This work continues in parallel with the two milestones.

Root also owns shared certificate translation, degree normalization, review,
integrated replay, and artifact coordination. No submission or outreach.

## Progress and checks

`IrregularTenProfile.rigid` and `normalize` compile. For any proposed
positive-degree 10/14 counterexample above 13, the two active sets are
disjoint and each has four vertices; all degrees are one or two. A proved
enumeration and graph isomorphism relabel them into the prescribed 4+4+2
profile. This is the coverage reduction, not yet the profile exclusion.

The six-type exporter reads the immutable archive with SHA256
`53daceac01e67909c70c9a06d6390e0858950212d29d66bae70b70d15342fd65`.
It selects the 81 already-covered patterns and 552 objectives. Removed local
vertices are padded with empty regions into fixed 54/79 state spaces. Each
pattern has a shared literal arena whose agreement with the symbolic arena
must be kernel checked; each objective has its own strategy/rank proof.
The empty-hole arena agreement, transfer proof, and initial-state bound pass.
The full family and global graph connection are not yet asserted here.


## Integration and independent attack

The source review found no hidden geometric or finite-coverage premises in
`SixTypeConstruction.maximum_even`, `IrregularTen14.positive_upper` or
`PairCodeOverlap.maximum`. The pair-code family has a concrete injective
code enumeration and counts; its all-order overlap uses a proved formula
above895 and a kernel-checked arithmetic selection at79..895. It does not
trust graph search.

The order12 bridge was also completed as32 staged source modules. All30
rank envelopes compiled in a separate sequential pilot; two peers reviewed
the actual-game semantics and continuous budget coverage. One independently
parsed all51840 literal rows against the frozen archive, checking43560
nonterminal rows and130710 cop replies. These sources cover24..107; the
explicit pair core supplies108. Their32 source hashes were checked before
integration; no pilot object files were copied into the release replay.

The combined kernel replay began with three single-worker processes. After86
successful current-campaign records, it was deliberately drained and resumed
with four single-worker processes, under the same source/compiler/dependency/
object-pinned cache. The new schedule prioritizes milestone prerequisites,
not only matching filenames. Three interrupted-in-flight jobs are rebuilt,
not presumed accepted. Memory pressure reported53% free before the increase.
The current pass covers974 modules excludingAudit; finalization addsAudit and
pins the full source inventory, replay script, compiler and guide. No old
successful receipt is used as a substitute for these kernel compilations.

The public summaries were also audited: the proof page and evidence guide
still named the old21-module artifact. Those stale summaries are corrected
in the staged release. Full Lean verification is still explicitly unfinished.


## Requested milestones reached

Both `SixTypeConstruction.maximum_even` and
`IrregularTen14.positive_upper` have passed their complete kernel replay.
The planning estimate advances from60% to about70%, with a60–80% uncertainty
range. This estimates remaining proof effort; neither module counts nor the
number of finite cells measures formal completeness. Sharp finite upper
exclusions remain the main uncertainty. The remaining combined replay,
final axiom audit and artifact acceptance are still required for release.

## Accepted integrated replay

All 975 distributed modules passed the current campaign kernel replay, including the final Audit module. The continuation records are pinned to source, transitive dependencies, compiler and object bytes. All audited theorem axioms are among propext, Classical.choice and Quot.sound. The manuscript is 126 pages with nine figures; all changed pages were visually reviewed, with 118 unchanged pages checked by pixel comparison. Full Lean classification remains incomplete; the 70 percent estimate (60–80 percent range) describes proof-work progress, not the share of modules checked.

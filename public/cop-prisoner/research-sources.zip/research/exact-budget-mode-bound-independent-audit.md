# Independent audit: a sharper exact-budget conditioning bound

2026-09-12. Ordinary proof review; no exhaustive search and no new
Lean verification. The threshold consequence below is conditional on
the proposed improvement of the sparse construction and is not by
itself a new published classification range.

Let L=n(n-1), let 0<m<L, set p=m/L, and let T be the number of arcs
of the independent directed random graph. Then T is Binomial(L,p),
has mean m, and has variance Lp(1-p)<=L/4. Chebyshev's inequality
gives

    P(|T-m|<sqrt(L)) >= 3/4.

Because sqrt(n(n-1))<n-1/2, this open interval contains at most
2n-1 integers, even before truncating to the support [0,L]. The
integer m is a mode: floor((L+1)p)=floor(m+m/L)=m. Therefore

    P(T=m) >= (3/4)/(2n-1) > 3/(8n).

The weaker non-strict lower bound 3/(8n) is convenient and sufficient.
The endpoints m=0,L are deterministic and do not satisfy the desired
positive-exponent hypothesis anyway.

Let Z count the bad source-recipient-cop triples used in Theorem 25.
Its original disjoint-witness argument bounds its expectation, not
merely the probability that Z>0:

    E[Z] <= n^3 exp(-(n-3)p^2(1-p)).

Thus the strict hypothesis

    (n-3)p^2(1-p) > 4 log(n)+log(8/3)

implies E[Z]<3/(8n)<=P(T=m), and hence

    E[Z | T=m] <= E[Z]/P(T=m) < 1.

The conditioning is on an event of positive probability. No
independence between Z and T is asserted or needed. The exact
completion-count derandomization of Theorem 43 is unchanged: start
with B<C, split both integers according to the next free arc, select
a nonempty branch with B_j<C_j, and finish with zero bad triples.

## Conditional full-main threshold 1800

Suppose the improved sparse construction is proved for all n>=1075.
The already proved dense incidence bridge works for n>=166. Outside
the explicit sparse and dense intervals, the same endpoint argument
gives

    (n-7)/(7(n-1)) < p < 12/13.

For n>1001 the lower endpoint exceeds 71/500. Since p^2(1-p)
has only an interior maximum, its minimum on [71/500,12/13]
is at an endpoint. Both endpoint values exceed 173/10000:

    (71/500)^2(429/500)=2162589/125000000
                              >2162500/125000000=173/10000,
    (12/13)^2(1/13)=144/2197 >173/10000.

At n=1800 this gives an exponent greater than
1797*(173/10000)=31.0881. Also log(8/3)<1 and log(1800)<15/2,
so the required right-hand side is less than 31. One entirely
rational check of the latter logarithmic inequality is
e>1957/720 (the Taylor sum through 1/6!), together with
1957^15 > 1800^2 * 720^15. The derivative of
(n-3)*173/10000-4log(n)-log(8/3) is positive for n>=1800.
Consequently the improved probabilistic bound covers all remaining
budgets for every n>=1800, if the sparse premise is independently
established. This does not claim that 1800 is an optimal threshold.

A short floating-point exploratory evaluation of the exact continuous
lower endpoint first passed at n=1782. That numerical observation is
not used in the conservative 1800 proof.

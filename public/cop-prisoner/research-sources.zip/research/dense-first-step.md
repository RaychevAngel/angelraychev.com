# The first step beyond universal delivery

## Result and scope

For every `n>=68`,

`M(n,n(n-3)+1)=2n-3`.

The graph has `2n-1` missing arcs. Exactly two missing pairs fail; every
other missing pair admits a two-move delivery strategy. The lower bound
is an explicit construction. The matching upper bound is the case `r=1`
of the growing-loss theorem in
`research/2026-09-12-final-dense-band.md`.

This construction was derived in the current follow-up analysis prompted
by Angel's proposal to determine the forced losses in the final dense
band. It is not attributed to the original 2023 work. The proof below was
independently checked. The finite structural dependency of the underlying
core at orders below 130 is stated separately; no new Lean theorem is
claimed.

## Four attachment vertices

Let `H` be a four-regular simple undirected graph of girth at least six,
on `k>=64` vertices. Such a graph is supplied at every required order by
the existing all-order high-girth construction.

Choose four distinct vertices `a,b,d,e` such that

- `dist(a,b)>=4` and `dist(d,e)>=4`;
- every distance from `{a,b}` to `{d,e}` is at least two.

Distances between different components are infinite. These choices can
be made greedily. A radius-three ball in a maximum-degree-four graph has
at most `1+4+12+36=53` vertices. Choose `a` arbitrarily, then choose `b`
outside its radius-three ball. Choose `d` outside the union of the two
closed neighborhoods of `a,b`, a set of size at most ten. Finally choose
`e` outside this union and the radius-three ball around `d`. At most
`10+53=63` vertices are excluded, so `k>=64` suffices.

## The missing-edge graph

Orient Euler tours of `H`, obtaining two incoming and two outgoing arcs
at every core vertex. Add four new vertices `c,x,y,z`, and the seven arcs

`c->x; x->y,z; y->a,b; z->d,e`.

Call the resulting orientation `F`, and let `G` be its loopless directed
complement. We have `n=k+4`, and

`|E(F)|=2k+7=2n-1`,

so `|E(G)|=n(n-3)+1`. Every vertex has missing outdegree two except `c`,
whose sole missing outneighbor is `x`. The unique missing predecessors
of `x,y,z` are respectively `c,x,x`.

### Girth check

The new vertices and the four attachment vertices form a tree. The
vertex `c` is a leaf and cannot occur on a cycle. Any new simple cycle
has either one or two maximal segments through the new tree, separated
by paths in the old core.

With one tree segment, endpoints on the same branch (`a,b` or `d,e`)
have tree distance two and core distance at least four. Endpoints on
opposite branches have tree distance four and core distance at least
two. In both cases the cycle has length at least six.

With two tree segments, the only way their interiors can be disjoint is
to use `a-y-b` and `d-z-e`. A cross-branch segment uses both `y,z` and
would intersect every remaining segment. The two possible core segments
then both connect opposite branches, so the total cycle length is at
least `2+2+2+2=8`. No third tree segment is possible with four distinct
attachment vertices. Therefore the full underlying graph of `F` has
girth at least six.

## Delivery and the exact two losses

We use the local form of the existing high-girth argument. For a missing
pair `(s,t)`, set

`B=F+(s) union F-(t)`.

Because `s->t` is an arc of `F`, the underlying graph induced by `B` is
a double star centered at `s,t`, of diameter at most three. Every cop
position `v!=s` has at most one outgoing `F`-neighbor in `B`: an external
vertex with two such neighbors would create a cycle of length at most
five, while the orientations inside the double star give the same
bound for its vertices other than `s`.

Consequently, whenever the initial cop has missing outdegree at least
two, some vertex `u` in `F+(v)\B` is a safe two-move intermediary. The
messenger uses `s->u->t` in `G`; the first step is outside the cop's
closed outgoing neighborhood and the second step immediately delivers.
This argument only needs the cop's missing outdegree to be at least
two. It does not need that bound at every other vertex.

It remains to consider the sole exceptional initial cop position `c`.
Its unique missing outneighbor is `x`. For a missing pair `(s,t)` with
`s!=c` and `s!=x`, we have `x notin B`:

- `x in F+(s)` would force `s=c`, because `c` is its sole predecessor;
- `x in F-(t)` would force `t` to be `y` or `z`. Each has unique
  predecessor `x`, so the missing pair would have `s=x`.

Thus `x` itself is a safe intermediary for every such pair. When the
source is `c`, that cop position is forbidden initially, and the previous
degree-two argument already covers every legal cop.

The only pairs left are `(x,y)` and `(x,z)`. They both fail: the pursuer
may start at `c`, whose closed outgoing neighborhood in `G` is
`V\{x}`. It waits while the messenger stays at `x` and captures every
nonterminal departure. Neither recipient is directly accessible from
`x`, so the messenger cannot deliver. This proves exactly `2n-3`
guaranteed missing pairs and completes the theorem.

## Construction and verification artifacts

`src/dense_first_step.py` constructs a graph at any requested `n>=68`.
For core orders 64 through 129 it replays the existing finite insertion
certificate starting from the explicit 52-vertex graph. For core orders
at least 130 it starts from five explicit 26-vertex blocks and uses the
ordinary far-edge insertion theorem. Thus the statement for `n>=134`
has no finite-bridge dependency; the extension down to 68 uses that
already supplied structural certificate.

The generator verifies the core and full graph's girth, the attachment
distances, all required degrees, and the exact safe-intermediate
condition for every missing pair and initial cop. It checks that the
only failing triples are `(x,y,c)` and `(x,z,c)`; the elementary trapping
argument above proves their actual failure, not merely failure of a
two-move search.

Run:

```sh
python3 src/dense_first_step.py
```

The default receipt `research/dense-first-step-checks.json` records
orders 68, 75, 80, 100, and 164, their missing arcs and attachment choices,
and SHA-256 hashes of the generator and its structural dependencies.
All 105,634 pair/cop checks passed with exactly the asserted exceptions.
These are finite checks of explicit instances; the all-order statement
is established by the proof and construction rule above.

## Consequence: the complete final dense band for n>=75

Proposition 31 in `paper/followup-extrema.md` supplies an additional
functional-block construction when `r>=2`, `k>=1`, `n=r+k`, and
`k<=binom(floor((r-2)/2),2)`. For `n>=75` and `1<=k<=51`, we have
`r=n-k>=24`, so the displayed binomial coefficient is at least 55 and
the condition holds. This handles every remaining small core offset.

Combining that construction with the present first-step theorem, the
large-core join for `k>=52`, and the functional endpoint `k=0` gives

`M(n,n(n-3)+r)=2n-r-ceil(r/2)-1`

for **every** `n>=75` and integer `1<=r<=n`. All attaining constructions
guarantee their counted pairs in two moves. The complete statement and
case partition are Corollary 33 in `paper/dense-first-step.md`.

Together with the existing value at `r=0` and the vanishing theorem
beyond `r=n`, this resolves every joint budget `m>=n(n-3)` for `n>=75`.
The smaller-order classification and the general sparse interval remain
separate questions.

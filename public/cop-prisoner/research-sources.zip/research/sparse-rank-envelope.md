# Bounded sparse-envelope investigation

2026-09-12. This follows the completed routing-theorem audit. Its aim
was to identify a reusable robust augmentation mechanism rather than
run another large graph search. No manuscript or existing theorem
source was changed. All computations below read the saved strategies;
no pursuit-game attractor was recomputed.

## General fixed-certificate rule

Fix a messenger policy and positive integer ranks for a local arena,
with the usual terminal delivery or safe-transfer stopping states.
At every certified nonterminal state (r,c), let z be the policy's
next messenger position and k the state's rank. An extra pursuer
arc c->d preserves this exact certificate if, whenever receipt has
not already occurred at z,

    z != d and 0 <= rank(z,d) < k.

The original immediate-collision and legal-messenger-move checks are
unchanged. Intersecting these permitted head sets over every relevant
state and every local objective gives the maximal arc envelope for
the FIXED policy, ranks and claimed states. All its arcs may be added
simultaneously: each universal pursuer-response obligation is checked
arc by arc. Adding messenger choices is harmless because the policy
continues to use its old moves.

This is an elementary certificate-closure rule, not a new necessary
and sufficient graph-theoretic characterization of universal delivery.
Failure of its test does not prove that the augmented graph loses;
other policies, ranks or additional claimed states may succeed.

## Defect-free uniform patterns: no unused capacity

`src/sparse_rank_envelope.py` extracts the envelope from all seven
saved augmented M4/R8 objectives. It checks30211 nonterminal rank
obligations. Among all246 nonloop uniform arc types
(source_type, column_shift, head_type) with shifts between-3 and3,
the allowed set contains the12 original base patterns and exactly
the8 already used optional patterns. There are no additional ones.

A weaker check drops strict rank decrease and merely requires the
chosen move to survive and remain in a previously certified state.
It still admits exactly those8 extra patterns. Thus simply changing
the numerical ranks cannot recover another uniform pattern while
keeping these policies and this certified region. This is a boundary
of the selected policies, not an impossibility theorem for the graph
family or for other strategies.

## Near deleted columns: only a modest recovery

The same test can replace the blanket exclusion of optional tails
within16 columns of a deletion. For each actual optional arc, check
every translated cop window containing its tail. A window without
deletions uses the augmented certificate. A window with deletions
uses the already proved projection to the old M4/R6 gap-three
certificate. Since jumps remain at most3, exterior returns are
still covered by the existing three Omega reentry layers.

For r=0..5 deletions at0,3,...,3(r-1), the extraction gives deficits
from the nominal8k optional arcs of

    0, 232, 256, 280, 304, 328.

These counts were checked at k=60,80,180. The influence of a cluster
on an optional tail is confined to the interval from16 columns before
its first deletion to16 after its last. This interval has at most45
integer columns; for k>=45, influence intervals of distinct lifted
clusters do not overlap. Hence the finite list of relative local
configurations stabilizes, explaining the constant deficit rather
than inferring it from increasing ring sizes alone.

Allowing all246 local nonloop patterns near the deletions, rather
than only the8 existing patterns, produces the same optional count.
Only36 cropped hole configurations need their envelopes extracted.
All results and input/source hashes are saved in
`research/sparse-rank-envelope.json`.

For r>0 the old blanket count lost240+24r arcs; the extracted count
loses208+24r, a recovery of32. Algebraically the worst residue now
has enough optional arcs to reach3n when k>=162, corresponding to
the candidate sufficient onset n=967 instead of1075. This modest
constant improvement is not proposed as another publication theorem
or as the requested substantive unification. The existing sources
and published bounds remain unchanged. Before promoting it, a new
construction artifact and independent replay of its exact envelope
would be appropriate.

## Consequence for the next approach

The fixed saved policies are already the bottleneck for uniform
augmentation. A materially stronger sparse envelope needs new policy
choices, a larger proved state region, or a different global layout.
Another scan of the same ranks or a larger sample of ring lengths
cannot supply that missing argument. This bounded investigation is
therefore stopped at this checkpoint rather than expanded into a
large search for small improvements.

# Independent whole-implication review: twenty arrows

**PASS:** the ordinary reduction in `research/small-sparse-twenty-upper.md`,
the completed double-defect family exclusion, and the literal53 witness
give **53<=M_E(20)<=57**. No exact maximum is asserted. The independent
finite arithmetic/orbit replay is `src/small_plateau_double_defect_review.py`,
with its adjacent JSON receipt under this note's basename.

## Integer and structural reduction

The independently written support replay recovers exactly the eleven
auxiliary tuples listed in the proposed proof at hypothetical I=58. It
uses the already reviewed zero-row/column bounds, exact nonisolated support
accounting, full eligible-rectangle direct-arrow bound, and maximization
over every possible live row/column dimension. It imports the independent
review module, not the producer's support implementation.

The `(9,10,8)` and `(10,9,8)` cases each force two zero columns or two zero
rows directly in the original directions. Removing those cells from the
count leaves at most72 cells, at least14 direct pairs, and at least6
diagonals, giving52. The `(10,10,9)` case gives80-16-7=57. The two
nested-active-set cases `(9,10,9)` and `(10,9,9)` are precisely the ten-vertex
one-transfer/sink families in `paper/sparse-third.md`; their retained
camping, finite camping-free, and sink-core bounds are all below58. The
full-active `(10,10,10)` case is the separately reviewed regular family
with maximum53.

For `(9,9,6)` and z=0, the eligible count is59-x-y-w, so x+y+w<=1.
A zero eligible row or column loses at least five pairs, beyond the
available one. If x=1, the two sinks need four incoming arrows, while
the unique degree-three source can supply at most two of them and the
outside-active-source budget at most one; a degree-two zero row follows.
The separate indegree argument treats y=1. With x=y=0, an indegree-zero
active source must send its two arrows to the other two source-only
vertices, exhausting all incoming arrows outside B. Similarly two
recipient-only vertices point only to the third, a sink, exhausting
outgoing arrows outside A. In particular w=0. Messenger play starting in
the six-vertex intersection cannot enter the source-only part or leave the
recipient-only part after entering it. Restricting a losing cop strategy
to the induced core is therefore valid. That core has at least18 missing
pairs and at most7 guarantees, forcing eleven failures in the eligible
rectangle. This excludes the case without assuming arbitrary deletion
preserves delivery.

For `(9,9,7)` and z=1, equality forces x=y=w=0 and every eligible missing
pair to win. The `(o,i)=(0,1)` and `(1,0)` alternatives force respectively
a degree-two source with a sink successor, or a degree-two recipient with
an inaccessible predecessor. In the `(1,1)` alternative the outside
arrows have the forced one-way form displayed in the producer proof.
The same original-direction restriction to the seven-vertex intersection
is valid. It has at least28 missing pairs and at most21 guarantees,
contradicting full eligibility. These restrictions concern the cop's
ability to retain a losing core strategy; no graph monotonicity is used.

## Completeness of the remaining family

Only `(q,r,b,z,o,i)=(9,9,7,0,0,0)` remains. Equality forces all active
degrees two, two distinct low-outdegree vertices of outdegree one, two
other low-indegree vertices of indegree one, and no low-out to low-in
arrow. There are exactly58 eligible missing pairs, all of which would
have to win.

The bipartite incidence graph has maximum degree two, so alternating
paths and even cycles split its20 edges into two matchings. Each has
size at most11; after choosing the larger first, sizes are11+9 or10+10.
This correctly includes graphs without a perfect matching.

A first matching of size11 is a derangement permutation. A first matching
of size10 has one missing head and one missing tail. They are distinct:
coincidence would make that original vertex both low-out and low-in,
contrary to the family. Its directed partial-permutation graph therefore
has one path with at least two vertices and directed cycles elsewhere.
All cycle partitions and all path lengths are enumerated.

The low-outdegree normalization under cycle rotations and permutations
of equal cycles is complete. Two low-out vertices on one cycle are
specified by unordered cyclic distance up to half its length; reflection
is not assumed, since swapping the unordered pair and then rotating
already exchanges distances d and length-d. On distinct cycles their
lengths suffice. In the path case its terminal vertex is one low-out
vertex, the path is rigid, and the other low-out vertex is either a
specified earlier path vertex or a cycle representative. All remaining
low-in placements are retained, subject only to disjointness and the
forbidden low-out/low-in arrows.

The independent replay constructs the centralizer generators explicitly,
computes their orbits on every possible low-out subset, and checks that
each orbit meets a retained representative. Its1,070 orbit checks recover
all44 first-factor types and2,802 degree patterns. The second-factor
recursion then enumerates every legal injective assignment with the
prescribed omitted rows and columns. Its completion flags correctly
distinguish the low-degree omissions from completed active neighborhoods.

## Pruning and terminal proof

Camping tests use a complete active source row or recipient predecessor
set against a possibly partial cop neighborhood. A covering neighborhood
can only grow, so these are permanent failures. An eligible row/column
contains several missing pairs, hence the possible cop-equals-source
exception cannot save full eligibility.

The guarded-prefix test deliberately enlarges unfinished messenger rows
to all still-possible second-factor arrows and gives the stationary cop
only its currently fixed arrows. Actual messenger options are a subset;
actual cop neighborhoods are supersets. A future direct source-target
arrow, when possible, is included in the optimistic reachability test.
Consequently a rejected currently missing eligible pair cannot later
become direct or acquire a safe route. Safe internal vertices are separated
from the final target step, so receipt before capture is respected. The
initial cop equals source case is skipped. These checks safely exclude
equality58, but need not preserve graphs whose true score is below58.

Every surviving complete graph receives the usual actual-game least-
attractor evaluation with both waits. The frozen run is complete, covers
all44 first-factor types and2,802 patterns, and evaluates2,432 games after
38,086,388 partial nodes. None reaches58. Its evaluated maximum34 is not
an upper34 for the full family, since the equality-specific prunes can
discard graphs with scores35 through57.

Combined with the retained global upper58, exclusion of equality58 gives
the claimed global upper57. This is an ordinary reduction plus an audited
completed finite enumeration; neither an independent second full-family
enumeration nor a Lean proof is claimed.

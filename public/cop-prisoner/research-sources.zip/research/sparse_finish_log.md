# Coupled nineteen-/twenty-arrow lane

Execution authorized 13 September 2026. Owner: small_case_upper_ideas.
Only sparse_finish_* files in src/research are written by this lane.
No new claim is approved for canonical incorporation until independent review.

## Scope and inherited evidence

The approved comparison host is eleven at twenty arrows, with score53..57.
The regular ten-vertex and directional one-transfer families have complete
exclusions above53. They do not exclude the other profiles. The old eleven-
vertex double-defect run excludes only equality58 in its stated family.

The immediate coupled target is M(10,19): fresh-sink attachment gives an
eleven-vertex twenty-arrow graph with exactly the same score. A54/55 witness
would improve the twenty-arrow lower bound. The value53 is not assumed.

## Work started

- Added sparse_finish_profiles.py: necessary integer inventory retaining
  exact surplus and outside-to-outside arrows, with conditional live-degree
  bounds. No graph enumeration or new extremal upper follows from it alone.
- Planned first finite family: positive-degree ten-vertex nineteen-arrow
  graphs above53. Degree arithmetic forces one low-in and one low-out vertex,
  all other degrees two. Bipartite alternating edge coloring has a perfect
  matching plus a nine-edge matching; every cycle type of the former and
  every residual omitted row/column must be covered.
- Positive-degree eleven-vertex twenty-arrow graphs above53 reduce to all
  degrees one/two with two low-in and two low-out vertices. The proposed
  source/sink SCC exclusion remains an ordinary-proof draft pending review.

## First completed exclusion

- The complete one-defect n10/m19 family rejects every score above53 in
  0.151 seconds:12 factor types,220 degree patterns,607500 partial nodes,
  267 actual-game decisions. Receipt sparse_finish_one_defect_10_19.json.
- The complete integer inventory leaves only two other support10 profiles,
  each a one-arrow source/sink attached to a regular9/18 core; live rows and
  columns force score<=44. Thus the combined proposed upper is M(10,19)<=53.
- Ordinary proof sparse_finish_one_defect_proof.md records the reduction,
  exact camping-loss allowance, complete factor normalization, and proof
  boundary. Independent review and a matching lower remain outstanding.

## Complete proposed twenty-arrow answer

- Positive11/20 degree1/2 family: all three low-degree overlaps completed,
  42 normalized first factors,1640 patterns,59.6 million partial nodes,
  18678 actual-game decisions,18.553 seconds. No score above53.
- Positive10/20 coupled/double-transfer families:11 joint degree-pair
  patterns,940202 partial nodes,341 game decisions,1.373 seconds. No score
  above53. The direct row enumerator assumes no perfect matching.
- Every zero-degree11/20 profile is bounded by deleting a one-arrow source/
  sink to10/19, by forced zero rows/columns, or by deleting a forced degree2
  source/sink and adding at most8 pairs to the eighteen-arrow upper44.
  Every zero-degree10/20 profile similarly gives at most51.
- Full proof sparse_finish_twenty_proof.md records the exhaustive split,
  finite coverage, pruning losses and inherited dependencies. Combined with
  the approved53 witness, the proposed result is M_E20=M(n,20)=53 for n>=10.
- All three new exclusion sources and completed receipts are frozen for
  independent review. No source/ledger/publication claim has been promoted.

## Independent twenty-arrow acceptance and next budget

- Independent review completed in research/finish-sparse-review.md/json and
  src/finish_sparse_review.py. It replayed all267+341+18678 finite leaves
  with a distinct game implementation, checked244 guarded samples and2230
  permanent failures, and accepted the whole implication ME20=53, n>=10.
  It also accepted the separate global nineteen-arrow upper53 argument.
- At21 arrows, the complete positive11-vertex one-defect family is<=56
  with all permitted camping-loss unions retained:40.9M nodes,269146
  actual-game decisions,27.527 seconds. The min-degree2 positive10-vertex
  one-excess family is<=56:20.4M nodes,54708 game decisions,9.997 seconds.
- The12 remaining positive10-vertex degree-pair patterns also complete at
  threshold56 in1.304 seconds, with912 actual-game decisions. This gives
  the proposed joint value M(10,21)=56 using the approved lower witness.
- The first positive11-vertex residual run timed out after60 seconds,
  two of11 patterns started, so it supplies no upper. It found an11/21
  score58 witness. Both solvers and independent full alternating-rank
  review passed2662 obligations; see sparse_finish_twentyone_58_certificate
  and sparse_finish_twentyone_58_review JSON. This is a certified lower.
- Parent supplied the stronger live-column/live-row source/sink deletion
  inequality I<=ME(m-d)+floor((m-d)/2). It makes a proposed global19 upper49
  sufficient to bound every zero-degree21-arrow graph by58.
- Two further complete tiny exclusions (10/19 one-defect and9/19 one-excess,
  threshold49) give that proposed global19 upper49; ordinary proof is
  sparse_finish_nineteen49_proof.md. Independent review remains outstanding.
- Current targets: positive11/21 residuals above58 and positive12/21
  degree1/2 families above58. The original incomplete residual run is
  retained distinctly and cannot certify either upper.

## Complete proposed twenty-one-arrow classification at hosts10 and up

- The positive12-vertex discovery run found a60 graph, replayed by both
  solvers and all3456 independent alternating-rank obligations. It matches
  the ordinary positive12-vertex bound60, so no12-vertex negative enumeration
  is required. This incomplete discovery run supplies only the witness.
- The positive11-vertex residual threshold60 run completed first, then the
  stronger threshold58 run completed all11 patterns:31.55M nodes,89307 game
  decisions,34.988 seconds, no score above58. The frozen proof uses only the
  stronger run, retaining all allowable camping unions.
- Final proposed values: ME21=60, M(10,21)=56, M(11,21)=58, M(n,21)=60 for
  all n>=12. Global ME19<=49 is a required proposed subsidiary improvement.
- Final stronger package is pinned by sparse_finish_twentyone_manifest.json
  (20 files). Main proof sparse_finish_twentyone_proof.md and subsidiary
  sparse_finish_nineteen49_proof.md are ready for independent review. All
  listed upper dependencies complete; no live process remains.

## Eighteen-/nineteen-arrow continuation

- Parent assigned this lane the18/19 classification after freezing21. Main-
  interval agent retains n9,m19..23; this lane owns18 and larger19 hosts.
  Current actual lowers are33 at9/18 and35 at9/19. They are not presumed
  optimal. The14..16 lane is owned by the independent reviewer agent.
- Added sparse_finish_positive_families.cpp: a generic complete inventory
  of positive joint degree pairs, followed by the reviewed direct row and
  camping-loss-union mechanisms. All positive integer degree partitions
  are listed; incoming degrees are assigned canonically only within equal
  outgoing-degree classes. Requested pattern ranges are explicit. The
  only inherited family skips are approved n9/m18 regular and directional
  one-transfer classes, and only for thresholds at least30.
- At n11,m18,target34, there are exactly3 surviving joint degree-pair
  multisets. The first30s run completes patterns1,2 and begins3 with no
  threshold survivor. Pattern3 is resumed separately; the original run
  remains incomplete and supplies no full-family upper by itself.

- The separate third-pattern run completed in19.183 seconds with no score
  above33. Together, the initial completed prefix1..2 and the completed
  singleton range3 cover the three positive11/18 profiles. The first JSON
  remains complete=false overall; only its explicit completed prefix can
  be used in a combined coverage argument. Independent review may replay
  the full set for a single complete receipt.
- All one-, two- and three-arrow deletions and all single-vertex deletions
  from the new12/21 score60 graph were checked as a bounded construction
  probe. Best18/19 scores were24/30, below current33/35 anchors; no new
  lower or upper follows. Literal probe certificates are retained in
  sparse_finish_sixty_deletions.json. This template is not pursued further.
- Next running family is all positive10/18 degree profiles above33.

- SOURCE HYPOTHESIS ERROR: n9/m18 regular/transfer inherited <=30 skips
  were invalid: existing30/29/13 maxima cover camping-free classes only.
  Promotion halted; original n9/m18 receipt cannot establish upper33.
  The n10/n11,m18 and n9/n10,m17 receipts never invoke these skips.
  New positive_full/fullmax sources remove every inherited skip.

- Corrected9/18 full run completes all48 profiles in1.585s, zero inherited
  skips and no score>33. Complete11/18 range1..2 replay finishes in22.866s,
  complementing the old complete range3. The former timed prefix is not a
  final proof dependency. Proposed18 package is frozen in
  sparse_finish_eighteen_manifest.json, conditional on review of the separate
  14..16 package. All listed upper ranges are complete and the33 attainer
  passes1458 independent alternating-state obligations. Next10/19 maximization
  uses dynamic threshold updates only after an actual larger game score.

- Positive10/19 complete maximization raises the lower38:80 initial joint
  degree profiles,40,483,668 nodes,171,182 leaf games,45.847s. The threshold
  changes35 to38 only when the actual game returns38. Every branch is then
  bounded by an attained value, so full completion proves positive10/19<=38.
  Literal graph and independent2,000-state review are saved in
  sparse_finish_nineteen_38_certificate.json and sparse_finish_nineteen_38_review.json.
  The12+ positive support range is already bounded by38 arithmetically; the
  timed12/19 target35 run is abandoned as unnecessary for the new optimum.
  Positive11/19 target38 is now being checked. Parent/main lane retains9/19.

- Positive11/19 bounded target38 search finds I40 before time cap55s;
  completed1 of12 profiles only, so no full upper is claimed. New literal
  sparse_finish_nineteen_40_certificate.json passes2,662 independent alternating
  state obligations. It has45 eligible pairs and exactly5 failures, all in
  target8. It has no elementary source/target camping obstruction; those
  failures arise from stronger game obstructions. At target40, all non-(q,r)=(8,8) positive
  profiles are arithmetically excluded. The remaining four low-in/low-out
  intersection sizes0..3 are being completely checked with a120s cap.

-19 row proposal: positive9 upper35 completes69 profiles in4.53s and its
  exact joint-degree set equals the separately written main-lane inventory.
  Positive11 remaining overlaps1..3 complete under earlier guarded checks
  in85.53s (86,611 leaf games). Overlap0 is already complete in the historical
 120s run, but a clean standalone55s earlyguard replay was too short.
  A clean standard-guard singleton replay is running with a180s cap; the
  failed55s receipt is excluded. Proposed exact row35,38,40 at hosts9,10,11+.
  Source/target deletion is now<=36 using the independently reviewed17<=28
  and18=33, so no zero-degree19 enumeration is necessary. Literal35 copied
  from parent construction bank and all1458 obligations independently checked.

- FINAL19 PRIMARY PACKAGE FROZEN: sparse_finish_nineteen_exact_manifest.json
  pins all4 completed disjoint finite runs (153 joint profiles,291,301 leaf
  games,175,544,361 nodes). The clean original-guard11/19 profile1 completed
  in69.720s with31,887 leaf games. Every timed discovery/pilot is excluded.
  Proposed host row is35,38,40 at9,10,11+, all with full literal certificates.
  Completion-strategy agent is independently replaying the four exact ranges
  and already passed ordinary source/zero-degree coverage review in principle.
  No live producer process remains, and no canonical file was changed.

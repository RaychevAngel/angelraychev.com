# Sparse endpoints and robust intermediate budgets: follow-up checkpoint

## Established new interval

Let H_k be the established five-type two-regular graph. For each column i
and type j, add the candidate arc

    (i,j) -> (i+3,0).

There are exactly 5k distinct new nonloop arcs. Every subset may be added
while retaining guaranteed delivery for every source and recipient, for
every k>=16. Consequently, with n=5k>=80,

    M(n,m)=n(n-1)-m for every 2n<=m<=3n.

This is a uniform theorem, not interpolation from selected finite graphs.
The stronger local game allows ALL new arcs to the pursuer and NONE to
the messenger. Thus any intermediate graph has fewer pursuer choices and
still contains every messenger move used by the strategy.

The independent explicit alternating arena has 35 messenger positions,
66 pursuer positions, and 4,620 turn states. The messenger window is
[-3,3]; the pursuer window is [-6,6] plus an exterior state Omega. Omega
may wait or reenter any type in columns -6,-5,-4,4,5,6. All 325 required
initial states per objective pass. Safe transfer takes at most 8 moves;
the five recipient bounds are 24,16,16,17,18.

Every actual move is represented for k>=16. The thirteen represented
pursuer columns leave at least three exterior columns, so a jump of at
most three cannot pass from one represented boundary across the entire
exterior and into the other boundary in one move. An exterior move back
into the window lands within three columns of a boundary, all of which
Omega permits. The original repeated-transfer proof then applies.

The threshold cannot silently be weakened to k=14 or15: in those rings
a three-column jump can cross the shorter exterior gap directly, a
transition the stated arena would misrepresent as entering Omega.

Independent verifier and complete rank receipt:

- `src/five_type_long_augmented_verify.py`
- `research/five-type-long-augmented-independent-certificates.json`

The earlier smaller augmentation `(i,0)->(i-1,4)` also passed, giving
2n<=m<=11n/5 for n=5k,k>=10. Its independent proof artifacts are
`src/five_type_augmented_verify.py` and
`research/five-type-augmented-independent-certificates.json`.

These are ordinary computer-assisted proofs. Neither augmentation has
been formalized in Lean at this checkpoint.

## Fixed-Hamilton-permutation one-vertex patch

The original failed search rewired both outgoing arcs. A lower-dimensional
search kept the first permutation as the Hamilton cycle, inserting one
new vertex after type4 in column0, and changed only the second permutation
by destination swaps among columns -2..2 and the new vertex. This preserves
both indegree and outdegree two, and a recognizable backbone.

The objective was the corrected, baseline-verified exterior-state game:
messenger window [-11,10], pursuer window [-12,11] plus Omega; safe exit
to column -6 from all sources in [-5,8] and the new vertex; delivery from
column8 to every target in [-8,6] and the new vertex. Both waits and the
intervening pursuer turn are included.

A twenty-second single-core run improved the previous 1,804 missing
delivery states to **939**, with all 8,591 required safe-transfer states
winning. It verified 45,041 of 45,980 required delivery states. A second
twenty-second run from that candidate made no improvement. This is NOT
a universal patch and gives no additional attaining order.

An independent Python calculation in the slightly larger symmetric
messenger window [-11,11] / pursuer window [-12,12] found exactly these
remaining failure groups, again totaling939:

| Recipient | Failed entry states |
|---|---:|
| (-2,4) | 380 |
| (-1,4) | 329 |
| (1,1) | 230 |

Reproducible files:

- `src/sparse_permutation_patch.cpp`
- `research/sparse-permutation-patch-search.json`
- `research/sparse-permutation-patch-search-2.json`
- `research/sparse-permutation-patch-candidate.json` (canonical local arcs)
- `research/sparse-permutation-patch-failures.json`
- `research/sparse-permutation-patch-input.txt` and `...-input-2.txt`

The same failed local conditions survive a larger window; they are not
removed by simply granting more space near the outer boundary.

## Composable finite-block experiments

To avoid treating one extra vertex as mandatory, a different idea was to
splice a finite certified universal block into the backbone. Blocks of
12,13,14,16 vertices would increment all four nonzero residues modulo5.
A one-arc swap creates a campable one-arc entrance, so at least two swaps
are necessary. Swapping arc heads between components preserves both
degrees exactly.

A bounded screen spliced the certified 12-vertex block into the eight-column
backbone. The two-port screen checked 19,680 legal candidates from its
explicit port lists and found none universally winning. A subsequent
screen tried 48,841 legal random splices using three through eight ports,
also finding none. The latter permits old origins in five consecutive
columns, which can be translated to offsets -2..2.

These are finite negative screens, not impossibility theorems for block
composition. They did not produce a candidate on which to attempt the
necessary uniform exterior-state certificate. No induction or preservation
theorem follows from degree preservation alone.

Files:

- `src/sparse_block_splice.cpp`
- `src/sparse_block_multisplice.cpp`
- `research/sparse-block-12-splice-screen.json`
- `research/sparse-block-12-multisplice-screen.json`
- `research/sparse-block-{12,13,14,16}-input.txt`

## Failed naive larger type patterns

Extending the backward spiral 1->2->4->1 by extra types, while keeping
the forward type0 lane and backward type3 lane, preserved the local
left-transfer lemma in the tested q=6,7,8 patterns. Delivery did not
survive: the q=6 version, for example, fails recipient types0 and4 on
eight- and twelve-column rings. Thus larger columns cannot be substituted
on the strength of the transfer property alone.

## Remaining sparse question

Exact sparse attainment at 2n arcs for every sufficiently large n, and at
2n-1 arcs, remains open in this checkpoint. The established 5k family,
its robust budget interval, finite exceptional witnesses, and all-order
3n construction remain distinct results. All bounded searches above have
finished; no background computation is left running by this subagent.

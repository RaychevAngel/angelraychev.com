# Small unrestricted arc budgets: research log

## Result

The exact values at budgets 8, 9, 10 and 11 are respectively 4, 5, 6
and 8. The all-order proof and computational boundary are written in
`paper/small-arcs-resume.md` as Theorem 49. All four values have two
complete independent upper enumerations and both full game algorithms
with direct rank checks for the lower witnesses.

## Structural reduction

Positive weak components require at least four arcs. At budgets at most
eleven, two positive components contribute at most three, using the
already proved maxima through seven arcs. A connected component with
at least as many vertices as arcs is tree-like or unicyclic and has
at most one indirect guarantee. Thus induction on the arc budget
reduces its upper test to a fixed host with exactly `m-1` vertices.
There is no need to enumerate arbitrary graphs on `2m` vertices.

An attempted sharper cyclomatic-number bound suggested that bicyclic
blocks might have at most two guarantees, but that route was not needed
and was not completed. No general bound solely in terms of cycle rank
is asserted. Suppressing paths without checking its effect on the game
would not be a valid shortcut.

## Important counterexample

The six-vertex maximum at eleven arcs is seven. It is not the
unrestricted maximum. A seven-vertex graph found during the sparse
enumeration has eight guarantees; its full two-solver and rank-verified
certificate is `research/small-arcs-eleven-witness.json`. The theorem
uses the corrected value eight. The lower values at the preceding
three budgets happen to remain equal to the six-vertex values.

## Enumeration improvements and failed runs

The previously audited canonical row enumerators completed the eight-
and nine-arc upper tests in under a second. Their naive sparse
specialization generated many unproductive low-degree completions at
ten and eleven arcs. Several explicitly bounded runs stopped at their
3, 5, 8, 10 or 15 second limits; those incomplete runs were not counted
as upper proofs.

The ordinary incidence inequality eliminates whole degree profiles.
A prescribed sink also eliminates any completed degree-two source
pointing to it. Finally, counting the remaining arcs required to raise
targets to indegree two gives a much sharper partial upper bound on
the number of possible recipient columns. This retains every graph
while avoiding many irrelevant completions.

The two final sources derive from the previously independent ascending
prefix and descending suffix implementations. They retain different
graph assignment orders, different camping checks and different exact
game algorithms. Their added remaining-budget bound is implemented
as closed-form zero/one/two costs in the primary source and sorted
individual costs in the independent source.

`src/small_arcs_resume.py` compiles the exact saved sources, executes
both complete tests at every budget, verifies all four lower witnesses,
and saves `research/small-arcs-resume-verification.json`. The completed
full reproduction took approximately 18.15 seconds. No incomplete run
or extrapolation from a fixed vertex table enters the theorem.

## Next budgets remain separate

The literal complete layered graph with three sources, two common
branches and three recipients does not give nine guarantees: a cop
at a different source covers both branches. It must not be used as a
lower witness at twelve arcs. Adding a disjoint arc to the verified
eleven-arc witness does give at least eight at twelve arcs. Further
budgets need their own verified constructions and upper checks.

## Bounded continuation at twelve and thirteen arcs

A subsequent bounded search found genuine seven-vertex witnesses with
9 and 10 guarantees at twelve and thirteen arcs, respectively. Both
original game algorithms and every direct rank check verify them in
`research/small-arcs-twelve-thirteen-witnesses.json`. Thus the current
rigorous lower bounds are `M_E(12)>=9` and `M_E(13)>=10`; the earlier
eight-pair padding lower bound at twelve arcs is superseded.

The complete seven-vertex check excludes ten guarantees at twelve arcs,
but that is not an unrestricted upper bound. The larger twelve-arc
upper test at host order eleven stopped at its twelve-second limit,
after 45,154,304 nodes; it remained incomplete. Short order-eight
searches at both budgets likewise stopped at their three-second limits.
These incomplete checks do not extend Theorem 49 beyond eleven arcs.

After an additional explicitly authorized bounded continuation, a new
experimental source `src/small_arcs_next_independent.cpp` used exact
outgoing totals and the ordinary zero-predecessor obstruction to
strengthen the profile bounds. A ten-second full upper attempt at
n=11,m=12,target10 stopped incomplete after 31,850,496 nodes. A
separate ten-second attempt restricted to profile61 likewise stopped
incomplete after 30,408,704 nodes. Neither produced a counterexample.
These results remain exploratory and do not supply an upper proof;
the saved Theorem49 sources and complete verification receipt were
not changed.

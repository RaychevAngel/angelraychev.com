# A uniform strategy for the five-type two-regular family

12 September 2026. **Computer-assisted theorem; independently verified finite certificates and ordinary simulation proof.** This note provides a uniform construction proof, not a guess from larger finite rings. All ordinary proof details below must be checked together with the fixed local certificates.

## Graph

For k≥4, the vertices are `(i,j)`, with i in Z/kZ and j in `{0,1,2,3,4}`. There are exactly two outgoing arcs at every vertex. The first follows the global Hamilton cycle:

- `(i,j)→(i,j+1)` for j<4;
- `(i,4)→(i+1,0)`.

The second permutation is

```
(i,0) → (i+1,0)
(i,1) → (i−1,2)
(i,2) → (i−1,4)
(i,3) → (i−1,3)
(i,4) → (i−1,1).
```

Every indegree is also two. Waiting remains a separate legal action.

## Theorem

Every source guarantees delivery to every recipient for every k≥4. For k≥10, the strategy below takes at most `8k+16` messenger moves. Thus the 5k-vertex graph has exactly `5k(5k−3)` indirect guaranteed pairs and attains the universal vertex-count upper bound.

The upper time estimate is deliberately loose: optimal delivery time is not needed for the extremal result.

## The fixed stronger local game

First unwrap the column coordinate to the integers, keeping exactly the same arcs.

- Restrict messenger positions to columns −3,…,3 and disallow messenger moves leaving those columns.
- Permit the pursuer at every vertex in columns −4,…,4, and at an extra state Ω.
- Within columns −4,…,4 the pursuer has all its usual moves and its wait. A move leaving that interval leads to Ω.
- From Ω, the pursuer may wait or move to **any** of the ten vertices in the two boundary columns −4 and 4.

Thus the arena has 35 messenger positions and 46 pursuer positions. Ω has more freedom than any single actual outside position; this makes the local pursuit problem harder. Ω can never coincide with a messenger vertex.

There are two kinds of local objective. Their terminal rules must not be conflated:

1. **Safe transfer:** reach column zero at the start of a messenger turn, uncaught. A move into that column counts only after surviving every possible intervening pursuer response.
2. **Delivery:** reach a specified vertex `(0,t)` under the original terminal-receipt rule. A messenger move into the recipient ends play before a collision or pursuer response.

The local certificate checker uses a least finite-rank attractor. For safe transfer, only messenger-turn states in column zero with unequal positions are seeded. There is no unconditional pursuer-turn success at the transfer boundary.

## Two finite local lemmas

The fixed certificates give the following uniform bounds for every possible initial pursuer state, including Ω, except initial collision.

**Safe transfer.** Every starting type in column one can safely transfer to column zero. The bounds by source type 0,…,4 are

```
8, 4, 3, 2, 6.
```

**Local delivery.** From every type in column two, delivery to any specified type t in column zero is guaranteed. The bounds, with rows indexed by recipient type and columns by source type, are

| Recipient type | 0 | 1 | 2 | 3 | 4 |
|---|---:|---:|---:|---:|---:|
| 0 | 24 | 18 | 17 | 16 | 19 |
| 1 | 16 | 15 | 7 | 6 | 9 |
| 2 | 16 | 15 | 9 | 8 | 11 |
| 3 | 17 | 12 | 10 | 5 | 8 |
| 4 | 18 | 12 | 15 | 10 | 14 |

These numbers arise from one fixed finite arena, independent of k. The proof only needs the bounds 8 and 24, not optimality of the table.

## Why the local game applies to every k≥10

Choose any reference column on the ring. The nine columns with offsets −4,…,4 are distinct when k≥10. Map every actual pursuer position in those columns to its exact local vertex, and all remaining positions to Ω.

Every actual pursuer move is represented by a permitted local move:

- inside moves and waits are unchanged;
- moves leaving the nine-column window go to Ω;
- a move from an outside column back into the window can enter only a boundary column, because every graph arc changes the column by at most one; every such entry is allowed from Ω.

This remains valid at k=10, where the outside region is a single column. Its two sides may be adjacent to both window boundaries, both of which Ω already permits. At k=9 the representation fails because there is no outside column and the two boundary columns have direct wraparound adjacencies; those small rings are handled separately.

Every messenger move in the local certificate is a real ring move and remains within offsets −3,…,3. Distinct local messenger and pursuer positions represent distinct physical vertices. A local guarantee against all the enlarged pursuer options therefore supplies a genuine strategy in the ring. This is an explicit simulation argument; it does not assume universality passes to graph covers.

## Global strategy and finite termination

Translate the desired recipient's column to zero. Suppose the current messenger column is d. Repeatedly apply the safe-transfer lemma, translated so that its source column one is the current column. Each phase decreases the messenger's column by one modulo k and finishes **after** the pursuer's intervening turn, so the next phase starts in exactly the required game timing.

After `(d−2) mod k` phases, at most k−1, the messenger is in column two. It then applies the appropriate local-delivery certificate and finishes. This uses at most

\[
8(k-1)+24=8k+16
\]

messenger moves. Encountering the actual recipient during a transfer phase simply ends the game earlier and cannot harm the guarantee.

The six small cases k=4,…,9 can be verified as explicit finite games, with complete legal-move rank certificates. Combining those checks with the uniform simulation proves the theorem for every k≥4.

## Consequences

For every k≥4:

\[
M_V(5k)=5k(5k-3),\qquad M_E(10k)=5k(5k-3).
\]

The first uses the universal vertex bound; the second uses the proved even arc-budget bound. For arbitrary sufficiently large m, choose `k=floor(m/10)` and pad with `m−10k` disjoint one-way arcs. This preserves I and gives

\[
M_E(m)=m^2/4-O(m),
\]

matching the leading coefficient in the universal arc upper bound. This padding argument is genuine and explicit; it does not interpolate graph counts by smoothness.

## Failed simple policies

Always taking the Hamilton-cycle arc whenever immediately safe, using the second arc only when forced, fails already at k=4. With recipient `(0,0)` and a stationary pursuer at `(3,2)`, the messenger can cycle through

```
(2,3) → (1,3) → (1,4) → (2,0) → (2,1) → (2,2) → (2,3).
```

The local certificate uses adaptive choices among multiple safe moves. Shortest-path distance alone also does not capture the global detours forced by some pursuer positions. Neither failed abstraction is needed by the local-transfer proof.


## Reproducible certificate verification

The owning generator/checker is `src/five_type_certificate.py`, with all six explicit local rank tables in `research/five-type-certificates.json`. It directly verifies every selected legal move, every possible pursuer response, collision exclusion, and strict rank decrease. To replay the saved table independently of attractor generation:

```sh
python3 src/five_type_certificate.py --check research/five-type-certificates.json
```

A separately written explicit alternating-state attractor is `src/five_type_local_verify.py`; its independent receipt and ranks are in `research/five-type-independent-local-certificates.json`. It has 3,220 states per local game and seeds only messenger-turn states for safe transfer. All six local claims passed: 225 required initial states per objective. The six small ring parameters k=4,…,9 have complete graph arcs, alternating-state ranks, and moves in `research/five-type-small-ring-certificates.json`, replayed by `src/five_type_small_certificates.py`; translation symmetry reduces recipients to their five types. The broader exploratory range is recorded separately in `research/solver-five-type-family.json`.

This is a computer-assisted ordinary theorem. The modular local-to-ring simulation and the six local certificates have not been added to the Lean development in this checkpoint. Existing formal game semantics and safe-branching results must not be described as a complete Lean proof of this family.

## Attempts to reach every order and odd arc budgets

These are failures or work in progress, not additional theorems.

- Four extra-vertex patches found by optimizing an eight-column ring were all invalid on the next tested ring sizes. Their finite success depended on the size. None is promoted to an infinite family.
- Directly optimizing the stronger fixed Ω arena is the appropriate repair. A candidate can almost complete a local interface and still fail its remaining universal quantifiers. Broader glue must also account for the pursuer's window: modified origin column two lies inside the usual pursuer window for reference column six, so one cannot silently reuse the base transfer from column seven to six.
- All ten translation classes of single-arc deletion from the unmodified five-type graph fail to attain the odd arc-budget bound already at k=10. Their I values, in source-type order and first/second arc order, are `1951,2211,1869,1874,2036,1992,1872,1993,2079,1950`, whereas the upper bound is 2256. Safe-transfer calculations excluded the degree-one source from the endpoints, and delivery goals excluded the degree-one recipient. Even that correctly weakened condition failed. An odd equality construction therefore needs a different patch or family.
- An attempted defect objective using right entry column four and all targets through column three asked for a one-column approach at its right edge. This was already too strong for certain unchanged base-family states. Future search objectives must first be checked on the unmodified family, and their outer margin must accommodate the proved two-column finishing approach.


### Corrected finite-defect interface

For a patch whose modified arc origins lie in columns −2,…,2 and all its destinations lie in columns −3,…,3 or among new vertices, the following interface is sufficient. All new vertices are represented in column zero.

- Safely transfer from every vertex in columns −5,…,8 and every new vertex to column −6.
- From every source type in column 8, deliver to every recipient in columns −8,…,6 and every new vertex.
- Use a fixed messenger window [−11,10] and pursuer window [−12,11], plus Ω. Its 24 pursuer columns plus a nonempty outside region embed into every ring with k≥25. All irregular arcs are deep inside this window, so outside reentry remains restricted to the two boundary columns.

The unchanged local transfer is valid at reference columns h≥7 and h≤−7. Its pursuer window then contains no modified arc origin; an irregular move from outside can enter only at its boundary. Thus ordinary left transfers work from source columns ≥8 or ≤−6. The patch transfer bridges the remaining source band [−5,7], finishing safely at −6. Repeated leftward progress can reach column 8, or any desired approach column outside this skipped band. For recipients outside [−8,6], the usual two-column approach lies outside the skipped band and the ordinary finishing window avoids modified origins. This proves the global gluing statement once every listed local obligation has a certificate.

This interface was checked on the unchanged base family before optimization: all 8,400 required safe-transfer states and all 45,000 required delivery states pass. The earlier one-extra-vertex candidate in `five-type-omega-defect-candidate-2.json` does **not** satisfy it. In the larger symmetric messenger window [−11,11] / pursuer window [−12,12], its failed recipient types and numbers of failing entry states are

| Recipient | Failing entry states |
|---|---:|
| (−5,2) | 472 |
| (−4,1) | 325 |
| (−4,2) | 464 |
| (−4,3) | 394 |
| (−4,4) | 447 |
| (3,4) | 128 |
| (4,0) | 156 |

All other nearby recipient goals pass in that window; the largest successful rank is 49. Safe transfer passes. The asymmetrical corrected interface has 2,386 failed delivery states for this candidate. Enlarging the window removes a spurious failure at recipient (−8,0), but leaves the listed failures; they cannot be dismissed as a boundary artifact. Further patch optimization is research, not a proved extension.

A final bounded optimization on the corrected asymmetric arena improved the one-extra-vertex candidate to all 8,591 safe-transfer states and 44,176 of 45,980 delivery states. The remaining 1,804 failures prevent any universality claim. Search state and exact objective are preserved in `research/five-type-expanded-defect-search.json`, with the fast implementation in `src/five_type_expanded_defect_search.cpp`. The search was stopped at the checkpoint; no background search is required to reproduce the established five-type theorem.

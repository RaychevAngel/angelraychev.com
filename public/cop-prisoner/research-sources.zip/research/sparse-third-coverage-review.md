# Independent review of the third classification integration

**Conclusion: PASS.** The added predicates in `src/classification_extensions.py`,
their use by `src/classification_coverage.py`, and the resulting frozen
`publication/classification-coverage.json` agree with the reviewed theorem and
certificate domains. This is an integration audit. It does not replace the
ordinary proofs, the separately reviewed finite exclusions, or fixed-graph
rank replay, and it introduces no Lean result.

## Numerical regression

The read-only checker `src/sparse_third_coverage_review.py` expands every affine
segment of the current ledger and the preceding ledger at Git commit
`1554c83c53adc249ca3635c702b851efcc6384e9`. The preceding ledger is frozen as
`research/classification-third-baseline.json.gz`; replay needs no Git checkout.
Its embedded old source hashes are historical reference metadata, not current
proof pins. Among all 493,924 admissible cells
of the retained finite box:

- All 431,302 previously exact cells retain exactly their previous values.
- There are 13,266 additional exact cells, for 444,568 exact cells in total.
- Every lower bound is at least its preceding lower bound, and every upper
  bound is at most its preceding upper bound. No lower bound exceeds an upper
  bound.
- The exact status is equivalent to equality of the stored lower and upper
  bounds in every cell.
- There are 49,356 unresolved cells in the box. After the existing support
  reduction removes duplicate large-host representatives, there are exactly
  **48,546 canonical unresolved cells: 254 sparse, 48,271 main, and 21 dense**.
- Every checked cell with `n >= 11, m = 22` has value 79. Every checked cell
  with `n >= 106, m >= 22` is exact. These are finite-box regression statements;
  the unbounded extension still uses the manuscript's parameterized theorems.

The frozen ledger's rows, totals, and canonical representatives were also
compared directly with `tmp/classification-third-candidate.json`; they agree.
The temporary candidate is not needed to replay the durable regression.

## Domain and construction review

### Equal-weight codes and the fixed mixed code

The new loop uses even core parameter `k >= 6` and code size
`3 <= r <= floor(k/2)`. Odd cores remain covered by the existing provider.
The capacity is the sum of independent `r`-sets on the line cycle `C_k` and
independent `r`-sets on the point graph. For even `k`, the latter is the
union of two `C_(k/2)` cycles, giving

`C(k,r) + sum_i C(k/2,i) C(k/2,r-i)`.

Here `C(j,s)` is the number of independent `s`-sets of the cycle, including
`C(j,0)=1` and zero for impossible cardinalities. Since `k >= 6`, both
component cycles have order at least three. The gap recursion lists each
independent set once by its least selected vertex and successive gaps; it
requires no graph search. Every selected code has the same cardinality, so
distinct codes are incomparable. The theorem's optional hub arrows supply
all integer budgets in the advertised interval.

At order 105, `from_codes` independently checks all 85 literal codes against
the underlying incidence restrictions and pairwise incomparability. Their
total size is 268. The base has

`20*17 + 40*85 - 268 = 3472`

arrows, and the ordered optional list has `85*84 = 7140` arrows. Thus its
exact interval is **3472 through 10612**, inclusive. The constructor rebuilds
these counts from the actual code sets; it does not trust the summary counts
in the discovery record. Any prescribed budget uses the corresponding
prefix of the optional list. This is a listed finite construction, not a
claim that an optimization search will eventually find one.

### Finite cyclic sparse interfaces

The registry contains 47 canonical orders and exactly one additional
variant. The canonical orders are

`{60} union [64,66] union [68,72] union [75,78] union [80,90] union [92,114]`.

The independent checker verifies the compressed bundle's size and hash,
each of its 48 compressed member sizes and hashes, and every member's graph
metadata. For each graph, the base and optional arrow lists are simple,
loopless, disjoint, and correctly labeled; their literal lengths reproduce
the registry's minimum and maximum budgets. These checks do not rerun the
large pursuit games. Their complete asymmetric game-rank certificates and
independent replay remain separate premises, with their prior receipts
retained.

The two order-109 records are deliberately distinct:

- The canonical record supplies **218 through 325** arrows.
- `repair109` supplies **218 through 327** arrows.

The ledger applies each record only to its own interval. In particular the
bridge to `3n = 327` uses the repaired adjacency list and its own complete
certificate, not an extrapolation of the canonical list. No finite cyclic
certificate is treated as an infinite theorem.

### Dense extensions

The new root-cycle predicate is precisely `r >= 5`, `k = n-r >= 0`, at
`m = n(n-3)+r`. The proof covers the `k=0` functional endpoint, the singleton
attachment, even cycles, and the odd-cycle-plus-singleton construction.
It does not require `k` to be positive, and it does not accidentally demand
a cycle when the attachment is empty. The arbitrary-duration numerical
formula is preserved, while the separate two-move and three-move proof
boundaries remain in the dense manuscript.

For `2 <= r <= 4`, the only new fixed-core predicate is `n-r=9`. It uses the
literal nine-vertex core with `(n,m,I)=(9,54,18)` and the proved
arbitrary-duration missing-block addition lemma. The three first-step
extensions are restricted to orders 13, 14, and 15. The two additional upper
bounds are restricted to `(7,30)` and `(8,42)`. No generalization of a finite
core or first-step graph is implicit in these predicates.

### Small sparse bounds and padding

The global bounds for budgets 14, 16, 18, 20, and 22 are respectively
22, 32, 44, 58, and 79. Their reviewed proof premises remain individually
stated in `paper/sparse-third.md`. In particular the exact budget-22 result
uses the first support threshold and regular-core exclusion; it does not
depend on completeness of the new degree-transfer search.

The lower-point identities are exactly `(9,18,30)`, `(10,20,50)`, and
`(11,22,79)`. The standalone budget-22 certificate is additionally checked
for `(11,22,79)` and the expected prior full-rank verification fields.
The independent literal replay was run again during this review and passed
all **6,120 alternating states** of these three graphs, without a fresh game
solve or any write.

For unchanged budgets, adding isolates preserves these lower bounds.
For a larger budget, the generic padding rule uses a **separate zero-I
component** on the spare vertices, with the extra arrows specified by its
row-prefix recipe. It does not add arbitrary arrows to the attaining
component. The ledger retains the component order and base budget so these
two operations remain distinguishable and reconstructible. At budget 22,
the global upper bound 79 combines with the fixed lower graph on every host
order at least 11; the point's exact marker is not used to propagate a
stronger upper bound to unrelated cells.

## Interpretation and proof boundary

`known_exact` is a theorem-domain application: it records a proved value
on the supplied interval. Merely observing equal bounds would not validate
an incorrectly supplied theorem predicate. The independent domain checks
above are therefore necessary in addition to the exhaustive arithmetic
regression. No such domain mismatch was found.

These additions have concrete adjacency rules, explicit composition
procedures, or genuinely finite listed graphs. This review does not claim
that an arbitrary existential provider has thereby become explicit, nor
does the finite ledger alone certify the absence of construction gaps over
all orders. The separate explicit-construction audit retains that role.

The durable receipt is `research/sparse-third-coverage-review.json`.
It pins the reviewed sources and fixed inputs only after the parent
confirmed the source freeze. Reproduce its read-only consistency check with:

```
python3 src/sparse_third_coverage_review.py --check
python3 src/sparse_third_replay.py --check
```

Neither command launches a graph search or a new pursuit-game solve.

The final replay was additionally executed in a temporary archive layout
containing only its pinned inputs and saved receipt, with no `.git` directory
and `PATH=/nonexistent`. It passed. The final manuscript spacing correction
was checked against the preceding published research archive: removing
whitespace gives identical `paper/sparse-packed-holes.md` text.

# Positive-degree main-cell exclusions after source/sink deletion

This extends the frozen coupled engine's small-defect proof to patterns with degree-one vertices. The cell receipt supplies its precise target, completed degree inventory, literal leaves and matching lower certificate. No Lean proof or second full graph enumeration is claimed.

## Original-direction deletion boundary for order nine

Deleting a vertex of indegree zero preserves an upper comparison for all pairs between surviving vertices: restrict the cop to the remaining graph, which the messenger cannot leave through the deleted source. Only pairs starting at the deleted vertex can be added. Dually, at a vertex of outdegree zero, a messenger excursion into that sink cannot deliver to a surviving recipient, so the same comparison follows directly in the original direction. This argument does not assume an edge-reversal theorem. If the other degree is `d>=2`, the removed row or column adds at most `n-1-d` missing pairs. If `d=1`, it adds zero by the degree-one obstruction. If `d=0`, deleting the isolate adds zero.

For `n=9` and `m=19,20,21,22`, maximize these bounds over `0<=d<=8` using the completed order-eight values. The needed upper table at budgets11 through22 is respectively

    8,9,11,13,15,19,19,21,22,24,25,28.

Budget11 uses the retained global eight-pair bound; budgets12 and13 use the reviewed tiny bounds; budgets14 through22 use the completed order-eight receipts. The resulting maxima are25,27,28,30. Thus every graph exceeding the retained respective lowers35,36,39,40 has all indegrees and outdegrees positive. This table does not use monotonicity of the fixed-host arrow-budget function.

## Complete positive pattern inventory

A universal outgoing row forces every indirect pair to fail, by placing the cop at that vertex. The positive outgoing degrees can therefore be restricted to `1..n-2`; positive incoming degrees range over `1..n-1`. Both sums equal `m`. Joint degree pairs are sorted descending, with incoming degrees descending inside each equal-outdegree block. The producer-input generator enumerates outgoing partitions and then directly assigns every possible incoming degree sequence with these block-order conditions.

Let `A` be the vertices of outgoing degree at least two, and `B` the vertices of incoming degree at least two; write `q=|A|`, `r=|B|`, `b=|A∩B|`. Every winning indirect pair belongs to `A×B`. Let `lowout` and `lowin` be the sums of outgoing and incoming degrees outside these sets. If `w` counts arrows from outside A to outside B, inclusion-exclusion gives

    e(A,B)=m-lowout-lowin+w,
    I <= q*r-b-m+lowout+lowin-w.

The inventory keeps every pattern whose version of this upper bound with `w=0` reaches the target. It also requires the raw missing-pair counts summed over eligible rows and over eligible columns separately to reach the target. These are necessary inequalities, with no claim that every retained degree pattern is graphical. Independent input review assigns incoming partitions by multiset counts across the equal-outdegree blocks, and compares the exact resulting set with the supplied text and JSON inventory.

## Frozen enumeration and loss pruning

The chronological row enumeration, exact incoming capacities, and future cells keyed by `(outdegree,indegree,assigned predecessor mask)` are exactly the frozen engine proved in `endpoint40_small_joint_proof.md`. Its source file is unchanged. At each prefix `eligible_upper()` subtracts only already fixed low-to-low arrows from the displayed upper bound. Further fixed arrows can only lower this count.

Source-camping losses are counted only for eligible sources and eligible recipients, and recipient-camping losses use full incoming columns. The initial cop/source exception remains explicit. The guarded-path prune uses optimistic outgoing rows containing every possible completion, the known cop closed neighborhood as a forbidden region, safe internal messenger paths, and an unrestricted final delivery exit. It counts only forced missing pairs in `A×B`. The proof from the minimum-degree-two case therefore applies verbatim to each such pair; the more general eligible-rectangle expression replaces the total missing-pair count.

`endpoint40_positive_joint_prune_review.cpp` invokes the actual frozen capacity, camping and guarded functions at every chronological prefix of every positive-degree graph through order four, 600 deterministic random positive-degree graphs of orders five through ten, and admissible saved literals. It uses a separate exact game and a BFS path check. The recorded test run covers2,399 graphs,14,444 prefixes and177,481 specific cop states without a false prune. These tests supplement the ordinary proof, rather than proving full graph coverage by sampling.

Every leaf of each completed case is independently replayed with the producer-free compressed fixed point. The matching lower graph is checked with full alternating-state ranks. A complete inventory exclusion plus this literal attainer proves exactly the value in that cell's receipt.

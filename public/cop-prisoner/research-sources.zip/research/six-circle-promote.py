#!/usr/bin/env python3
"""Bounded neighboring-envelope attempts, preserving explicit finite outputs."""
import json,sys,itertools,time
from pathlib import Path
sys.path.insert(0,'src')
from main_interval_new_independent import source_ranks,bits,replay_ranks
rows=json.load(open('research/six-circle-small-rows.json'))['rows']
def ranks(B,E):
 try:return source_ranks(B,E,0)[0]
 except AssertionError:return None
records=[]
for n,target in [(24,14),(22,13),(23,14),(20,13),(21,13),(19,13)]:
 row=next(x for x in rows if x['n']==n);A=set(row['A']);start=time.monotonic();attempts=0;found=None
 targetbase=len(A)-1
 for extras in itertools.combinations(sorted(set(range(n))-A),target-len(A)):
  AA=A|set(extras);E=[bits((v+d)%n for d in AA if d)for v in range(n)]
  rank=ranks(E,E);attempts+=1
  if rank is None:continue
  C=AA-{0}
  # Every candidate is one of at most300 adjacent envelopes; try the few
  # possible deletions needed to overlap the old exact interval.
  for omit in itertools.combinations(sorted(C),len(C)-targetbase):
   CC=C-set(omit);B=[bits((v+d)%n for d in CC)for v in range(n)]
   rank=ranks(B,E);attempts+=1
   if rank is not None:
    found={'n':n,'A':sorted(AA),'C':sorted(CC),'m_min':n*len(CC),'m_max':n*(len(AA)-1),'rank_t0':rank,'extras':list(extras),'omitted_from_base':list(omit)}
    break
  if found or time.monotonic()-start>15:break
 print(json.dumps({'n':n,'attempts':attempts,'elapsed':time.monotonic()-start,'found':found}),flush=True)
 records.append({'n':n,'attempts':attempts,'elapsed':time.monotonic()-start,'found':found})
Path('research/six-circle-promoted-candidates.json').write_text(json.dumps({'scope':'Finite robust circle candidates; no inference from failed searches','records':records},indent=2)+'\n')

# A six-exception interface for safe navigation on a non-ring quotient

Date: 13 September 2026. This is a new research lemma with an explicit
finite certificate and direct legal-move replay. It is not a theorem of
universal delivery to individual recipients. The quotient projection,
literal transitions, and all finite layers have now passed the independent
review recorded in `composition-interface-navigation-independent-audit.md`.

## Graph and exact statement

Let $X$ be a finite set, with permutations $a,b$. Assume that for every
$x\in X$, the vertices $xw$, for freely reduced words $w$ of length at
most four in $a,a^{-1},b,b^{-1}$, are pairwise distinct. Equivalently, the
undirected labelled quotient has no reduced relation of length at most
eight at any vertex. This follows from girth at least nine for its simple
four-regular underlying graph. Assume the quotient is connected.

Construct ten vertices $(x,0),\ldots,(x,9)$ over each $x$. There are two
outgoing arcs, called $A$ and $B$, at every vertex. The first permutation is

$$
\begin{aligned}
0_x&\to6_x\to2_x\to3_x\to9_x\to5_{xb},\\
5_x&\to1_x\to7_x\to8_x\to4_x\to0_{xa}.
\end{aligned}
$$

The second permutation is

$$
\begin{aligned}
0_x&\to0_{xa},&1_x&\to2_{xa^{-1}},&2_x&\to4_{xa^{-1}},\\
3_x&\to3_{xa^{-1}},&4_x&\to1_{xa^{-1}},\\
5_x&\to5_{xb},&6_x&\to7_{xb^{-1}},&7_x&\to9_{xb^{-1}},\\
8_x&\to8_{xb^{-1}},&9_x&\to6_{xb^{-1}}.
\end{aligned}
$$

Both arc rules are permutations, and their destinations are distinct at
every vertex. The graph is loopless, two-in/two-out regular, with
$10|X|$ vertices and $20|X|$ arcs.

An interface state is an uncaught messenger-turn state satisfying the
following six exclusions. Relative to the messenger's current cell $x$, the
forbidden pairs (messenger type; pursuer cell and type) are

$$
(3;x,9),\quad(3;xb,7),\quad(4;x,0),\quad
(8;x,4),\quad(8;xa,2),\quad(9;x,5).
$$

**Safe-navigation lemma (computer-assisted).** From every initial uncaught
state, the messenger can reach an interface state within one messenger
move. From an interface state over $x$, the messenger can choose either
$xa^{-1}$ or $xb^{-1}$, safely reach that cell within 32 messenger moves,
and finish in an interface state. Finishing includes surviving the last
pursuer response; these are not terminal-receipt moves.

Let $D$ be the directed diameter of the quotient using the two generators
$a^{-1},b^{-1}$. Then from every initial uncaught state the messenger can
safely reach any prescribed cell within $1+32D$ messenger moves. This does
not prescribe its type upon arrival. Since $a,b$ are finite permutations,
connectedness makes this directed quotient strongly connected and $D$ is
finite.

In particular, a quotient family with logarithmic directed diameter would
give logarithmic-time safe navigation to ten-vertex cells while preserving
exactly two incoming and two outgoing arcs. This conditional application
makes no assertion of a currently established logarithmic-time universal
point-delivery family.

## Why a joint-state interface was needed

Demanding the chosen quotient step from every uncaught state fails. With
the above gadget, only three starts fail for each of the two step
objectives in the local arena. Removing whole messenger types loses too
much: excluding types 3 and 8 creates new failures at 4 and 9; excluding
all four creates dozens more failures at other types.

Instead, the six particular messenger/pursuer configurations above form a
stable interface. The interface keeps 1,784 of 1,790 noncollision states
in the radius-two boundary description. This is a property of joint
states, not a restriction to a subset of messenger vertices.

## Ordinary normalization proof

If the state already satisfies the interface, do nothing. At each of the
six excluded states, use the $B$ arc of the messenger. Its new state is,
respectively,

$$
3_{xa^{-1}},\quad3_{xa^{-1}},\quad1_{xa^{-1}},\quad
8_{xb^{-1}},\quad8_{xb^{-1}},\quad6_{xb^{-1}}.
$$

For each case, the pursuer has only its wait and its two displayed arcs.
None causes a collision, and none produces one of the six exclusions
relative to the new cell. Only words of length at most two enter these
comparisons, so the quotient hypothesis prevents accidental
identifications. The full literal three-response checks are also saved
as six cases in the certificate archive; the normalization statement does
not rely on searching over a large graph.

## Finite step certificates and their projection

Work first on the free quotient tree. Keep messenger cells at reduced-word
distance at most two from the reference cell, giving 170 messenger
positions. Keep pursuer cells at distance at most three, giving 530
positions, and add ten exterior states $\Omega_i$, one per pursuer type.

A represented messenger move leaving its window is disallowed. A represented
pursuer move leaving its window goes to the exterior state with its actual
new type. From $\Omega_i$ the pursuer can wait, can apply the type change
of either of its arcs while remaining exterior, and can enter every
represented boundary cell compatible with that arc's generator and head
type. An internal arc changes type but cannot enter from outside. For an
arc labelled $g$, entry at word $z$ is allowed exactly when $zg^{-1}$ is
outside the radius-three ball. Thus exterior positions retain the
pursuer's type, rather than allowing it to choose any boundary type.

The input states are all interface states with messenger cell the reference
cell. All exterior pursuer types are included. For each generator
$g\in\{a^{-1},b^{-1}\}$, seed precisely the uncaught messenger-turn states
in cell $g$ satisfying the interface relative to that cell. An exterior
pursuer cannot be at any excluded relative location at such an endpoint:
those locations have original word distance at most two. It therefore
satisfies the interface automatically.

The finite reachability calculation supplies 33 nested layers, numbered
0 through 32. Layer 0 is exactly the seeded safe endpoint condition. Every
new messenger-turn state in layer $d>0$ has a legal messenger move such
that every pursuer response belongs to layer $d-1$. Waits are included;
all nonterminal collisions are excluded. Induction on $d$ proves safe
termination and the stated move bound.

Both certificates cover all 5,384 required starts in their respective
arenas. A separate direct replay visits each newly claimed state, checks
the selected successor against the actual arc lists, and checks every
legal pursuer response in the preceding layer. It checks 121,340 new
winning states across the two objectives. Full layers and the arena are
stored, rather than only reporting that an attractor computation passed.

The quotient hypothesis identifies all represented cells and every adjacent
cell correctly, through radius four. Every physical pursuer movement has a
permitted image: represented moves are exact or leave into the appropriate
$\Omega_i$; an exterior entry obeys its actual generator and head type;
remaining exterior maps to a permitted exterior transition. Collisions with
the represented messenger are preserved. Thus each local strategy lifts to
every qualifying quotient.

At the endpoint, recenter at its new cell. The interface depends only on
the same cell and one adjacent cell, so the physical state indeed satisfies
its next module's hypotheses. Concatenating the chosen quotient steps is
therefore valid against every legal history-dependent pursuer. Receipt at
the actual recipient during any phase simply terminates the game earlier.

## Evidence and remaining boundary

- `src/composition_interface_free_group.py`: finite arenas.
- `src/composition_interface_invariant.py`: exploratory invariant synthesis.
- `src/composition_interface_certify.py`: explicit six-exception certificates
  and direct per-state legal-move replay.
- `research/composition-interface-navigation-certificates.json.gz`: full
  layers, arena transitions, and literal normalization cases.
- `research/composition-interface-navigation-verification.json`: counts,
  source hashes, and archive hash.

The original direct replay shares the arena generator. A second agent has
also reconstructed the literal transition rules, checked all finite
layers, and audited the quotient projection; see
`composition-interface-navigation-independent-audit.md`. No Lean coverage
is claimed. The terminal step for arbitrary individual recipients is open;
the newer eight-type candidate checkpoint is separate, in
`composition-interface-terminal-checkpoint.md`.

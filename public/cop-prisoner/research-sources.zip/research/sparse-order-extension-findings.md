# Marked one-vertex extensions: finite success and a repeatability obstruction

13 September 2026. Private bounded research. No manuscript, coverage ledger,
website, or Lean claim is changed by this note. The root sparse-stage lane
separately handles finite main-interval coverage.

## Results and exact scope

One fixed double subdivision, with one fixed optional extra arrow, transports
every graph of the literal order-25 sparse stage family through the next
order. A second fixed operation does the same at order26. Complete independent
explicit alternating-game certificates are retained for every resulting graph.
These are finite composition statements, not a uniformly repeatable family.

A separate ordinary obstruction shows that **three successive tip-only double
subdivisions always fail universal delivery on their all-+2 branch**, regardless
of the original core. This includes all16 choices of the two successive
inherited-port updates, not merely repeating the same update. The obstruction
is predecessor domination, so larger strategy windows cannot repair it.

## The two finite marked operations

Freeze the literal 25-vertex seed and its25 ordered extra arcs from
`research/sparse-staged-discovery.json`. The exact seed is embedded in the
certificate files, so their proofs do not depend on future edits to that file.
Let G_j contain the50 base arcs and the first j extra arcs, 0<=j<=25.

For every G_j, replace

    5 -> 10, 18 -> 13

by

    5 -> 25, 18 -> 25, 25 -> 10, 25 -> 13.

Both the result H_j and H_j plus `25 -> 8` are universally winning. They have
52+j and53+j arcs respectively. Thus a single fixed operation supplies every
52..78 budget at order26. No inference from winning endpoints is used: all52
literal graphs are checked separately.

Define the canonical27-graph next family as H_0,...,H_25 and
H_25 plus `25 -> 8`. On every member replace

    5 -> 25, 25 -> 13

by

    5 -> 26, 25 -> 26, 26 -> 25, 26 -> 13.

Both the result and the result plus `26 -> 1` are universally winning.
Their54 literal graphs give every54..81 budget at order27.

The first full screen tested every unordered pair of arcs on each stored base
of orders25..30. The exact numbers of winning double subdivisions were
10,65,97,198,278,9. Thus a generic failure of one-vertex insertion is false.
The old failed12-vertex block-splice screens did not test this operation.

However, only one of the10 successful base25 port pairs transports all26 root
stages. At the next order only two of the22 base port pairs transport the full
canonical family; only the displayed one has a common additional head for the
+3 version. At order27, a primary exhaustive screen of the16 port pairs that
win on the minimal graph finds none that transport every budget in this
particular family. That last result is a primary finite screen, not an
independently certified impossibility theorem for arbitrary marked families.

## Why tip-only repetition must stop

Use the existing predecessor-domination Lemma2 from `paper/main.md`:
if every predecessor of a recipient t lies in the closed outgoing neighborhood
of a cop position c, then every indirect source other than c loses. The cop
waits at c until the messenger first enters a predecessor of t, and catches
it on that reply. Receipt priority is respected because capture occurs before
the messenger's next move to t.

A double subdivision replaces a->b and c->d by
a->x,c->x,x->b,x->d. Suppose the next marked pair consists of one newly created
arrow entering x and one leaving x. Inserting y at those two ports creates
both x->y and y->x. The other incoming and outgoing arrows at y are A->y
and y->B, where A and B are older vertices. They may coincide with each other;
neither equals x or y. There are exactly two incoming and two outgoing arrows
at the fresh y.

Now insist again on using one arrow entering the newest vertex y and one
leaving it, and insert z. There are exactly four possibilities:

| Removed incoming arrow | Removed outgoing arrow | Dominated recipient | Cop position | Recipient predecessors |
| --- | --- | --- | --- | --- |
| A->y | y->x | y | z | {x,z} |
| A->y | y->B | y | y | {x,z} |
| x->y | y->x | z | z | {x,y} |
| x->y | y->B | z | y | {x,y} |

In every row, the displayed cop's closed outgoing neighborhood contains
{x,y,z}. The displayed recipient has no other predecessors. Thus every
original-core vertex loses delivery to that recipient. No property of the
unchanged core can rescue these starts. This proves the obstruction for
arbitrary choices at the previous insertion as well.

The symbolic checker `src/sparse_order_extension_obstruction.py` reconstructs
all16 update words after three insertions and verifies the indicated set
containments. Its data are
`research/sparse-order-extension-ladder-obstructions.json`. The proof above
is ordinary graph arithmetic; it does not depend on solving a finite game.

The all-+2 branch is necessary for an interval extension because it carries
the endpoint2n. Optional +3 arrows can sometimes break predecessor domination,
but cannot establish the absent +2 case. A viable indefinitely repeatable
family must refresh at least one port outside this newly created two-way
chain, or make an additional degree-preserving rewiring. Merely enlarging the
local cop/messenger arena cannot cure the dominated recipient.

## Reproduction and proof artifacts

- `src/sparse_order_extension_screen.cpp`: bounded collapsed-round discovery.
- `src/sparse_order_extension_transport.py`: common-port finite-family screen.
- `src/sparse_order_extension_verify.py`: independent literal adjacency,
  explicit alternating-game generation, and direct saved-rank replay.
- `research/sparse-order-extension-certified.json.gz`:52 order26 graphs.
- `research/sparse-order-extension-second-certified.json.gz`:54 order27 graphs.
- `research/sparse-order-extension-independent.json` and
  `research/sparse-order-extension-second-independent.json`: exact independent
  recipient/state counts, source pins, and certificate hashes.

The first independent proof checks1,352 recipient games and1,827,904 explicit
alternating states. The second checks1,458 recipient games and2,125,764 states.
Winning and losing rank obligations are checked against every actual legal
reply, with waits and receipt-before-capture. Replays:

    python3 src/sparse_order_extension_verify.py --check
    python3 src/sparse_order_extension_verify.py --order 27 --check

No unbounded extension, general preservation of universality under subdivision,
arbitrary-subset envelope for all original25 extras, or new Lean theorem is
claimed. The useful next target is a port refresh rule that avoids the proved
domination obstruction while surviving the full budget family.

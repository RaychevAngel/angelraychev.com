# Stronger-theorem checkpoint: supersession audit

This compares the pre-unification catalogue in result-catalogue-audit.md
with the new mathematics. It does not call unrelated statements one result
merely because they can be written under the same heading.

1. Protected routing54 contains the full-vertex density and exact-budget
   conclusions of25/43/51, including the polynomial deterministic algorithm,
   two-move guarantee and random failure bound. It adds a prescribed routing
   set and arbitrary exterior-arrow robustness over a whole interval of exact
   budgets. The separate classical separating-system lower bound plus its
   construction proves the new q2(n)=Theta(n log n) result55.
2. Sparse stability56 strengthens the even equality shape to a linear loss
   bound. Odd support57 strengthens the odd equality shape and supplies the
   general actual-game induced-core reduction that replaces the bespoke
   ordinary support proof for23arcs. The existing finite23-enumeration is
   still required and has not been relabeled a general proof.
3. Direct dense theorem58 subsumes the old numerical endpoint19 (including
   the26-vertex base), old three-move endpoints at20/25/30/35/40/45/50,
   robust bridge50, firststep32, core-join numerical29, distinct-root31,
   and whole staircase33. The root pool strengthens31 at odd functional
   orders. Every old parameter case remains covered, and two-move and
   arbitrary-subset guarantees are retained or improved. The generic
   high-girth criterion18, block-composition28, functional-complement iff
   statement13 and universal upper27 remain independently useful.
4. Theorem44 is improved in place from1800to1664, using54; Corollary47
   inherits1664. Neither is advertised as universal two-move: the sparse
   portions retain their original longer strategies and finite certificates.

The paper keeps old theorem numbers as short specializations for stable
references, while removing their superseded long construction/counting
proofs. Historical executable constructions remain in the research archive.
It does not claim that this removes every redundant historical paragraph or
that all30previous catalogue entries have become a handful of theorems.

No sparse interval theorem with its stronger time bound, smaller order range,
or arbitrary optional-arrow guarantee has been discarded. The sparse-rank
experiments did not yield a new theorem that dominates that group. The
22-arc one-diamond search did not produce a matching extremizer and its
exclusion result was not promoted without an independent coverage audit.

Independent final audit (proposal_check) found no lost mathematical guarantee
or proof cycle in these replacements. It checked the retained D-dependent
range, smaller dense orders, old ordinary k=5 proof, and unchanged23-family
coverage. Its requested clarification of54 now states the random bound for
arbitrary real density without the exact-budget condition. Current routing,
dense, independent-game, rank-envelope and diamond source hashes match their
receipts; the latter search remains unpromoted research evidence.

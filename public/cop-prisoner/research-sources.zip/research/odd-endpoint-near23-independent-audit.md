# Independent audit of the sharper 23-arc reduction

The ordinary reduction in `research/odd-endpoint-near23-reduction.md`
and the actual source `src/odd_endpoint_near23_exhaustive.cpp` pass
independent review. Together with the three completed receipts, they
give **`M_E(23)<=87`**, without asserting that 87 is attained.
The reduction assumes `I>=88`: although the three finite classes have
no value at least 87, this does not imply the global upper bound 86.

## Degree reduction

The rectangle bound is at most 83 when both active sizes are at most
ten, and at most 82 when either is at most nine. In the `(10,11)`
corner, overlap at least four gives at most 87 directly. Otherwise at
least six active sources have indegree zero, emitting at least twelve
arcs. At least nine enter indegree-two recipients, killing at least
five columns. The directly proved sink argument covers `(11,10)`.

At `(11,11)` with overlap at most seven, at least three zero-indegree
sources kill at least two indegree-two columns. Removing them loses
at most four of the at least 21 direct active pairs, giving upper
bound 82. At overlap eight or nine, one zero column and the retained
diagonal exclusions give 84 or 83. These estimates are sound.

At overlap ten the zero-column and zero-row arguments force the unique
outside incoming arc and outgoing arc to supply the respective distinct
deficient vertices. All other vertices outside their union are isolated.
This gives exactly the two distinct-deficiency support-twelve types,
according as the exceptional arc is absent or present.

At overlap eleven, classify the at most one arc starting and at most
one ending outside the common active set. A disjoint outside arc or
a harmless one-way attachment leaves an eleven-vertex two-regular
core whose losing strategy remains valid. A sink attached to a
degree-two source, or a zero-indegree predecessor of a degree-two
recipient, kills an entire eligible row or column. Only the case where
both crossing arcs use the same outside vertex remains. This is the
third support-twelve type, with one vertex of both degrees one. The
case classification is exhaustive and respects the original game,
without assuming invariance under reversal.

## Factorizations and pruning

The absent-arc type uses the earlier distinguished-cycle factorization.
For a present exceptional arc, add a second copy and split the regular
bipartite multigraph into two matchings, with `A(0)=B(0)=1`. The actual
graph initialization omits `A(0)`, so only the original `B(0)` remains.
The only permitted factor duplicate is correctly restricted to row zero.
For the common deficient vertex, add a dummy loop at zero, put it in
`A`, and partition the other eleven vertices into cycles of length at
least two. The actual graph omits that loop; `B` stays loopless and
disjoint. Both enumerate all graphs of their required type.

Every tested source row or predecessor column is complete. A covering
cop row may be partial because coverage persists as arcs are added.
Each source obstruction kills at least eight eligible pairs and each
target obstruction at least seven, after allowing the cop itself as
an exceptional source. With at most 90 eligible pairs, every rejection
has `I<=83`, safely below the threshold 87.

The terminal game counts failed eligible pairs. Direct and diagonal
pairs cannot fail, so its loop is consistent with the stated potential.
Stopping a leaf when remaining potential is below 87 is sound, although
the returned value then need not be that leaf's exact indirect count.

## Completed evidence and boundary

| Type | Partitions | Nodes | Leaves | Seconds |
|---|---:|---:|---:|---:|
| Distinct, absent | 42 | 164,276,910 | 16,902,091 | 40.94 |
| Distinct, present | 42 | 13,448,216 | 1,125,588 | 2.31 |
| Common vertex | 14 | 49,814,092 | 3,558,672 | 7.83 |

The receipts are `research/odd-endpoint-near23-absent.json`,
`research/odd-endpoint-near23-present.json`, and
`research/odd-endpoint-near23-same.json`. All are complete and reject
every value at least 87 in their class. This auditor independently
reviewed the ordinary proof and source against those receipts; it did
not repeat all three enumerations. No new Lean coverage is claimed.

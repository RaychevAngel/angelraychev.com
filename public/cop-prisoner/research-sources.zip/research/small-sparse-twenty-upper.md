# Twenty arrows: excluding 58 guarantees

Research checkpoint, 13 September 2026. Ordinary reduction and a complete
finite family check; independent audit pending. The conclusion proposed here
is 53 <= M_E(20) <= 57. No exact value is asserted.

## Retained premises and new finite check

The retained theorem in `paper/sparse-third.md` gives M_E(20)<=58. The
complete seven/six-vertex tables give M_V(6)=7 and M_V(7)=21. The same
sparse theorem supplies the necessary sink and one-transfer bounds for a
ten-vertex, twenty-arrow graph. The new complete regular-family check gives
I<=53 for every ten-vertex two-in/two-out graph; its coverage and game
semantics are reviewed in `research/small-plateau-regular-family-review.md`.

The new 53-guarantee literal witness is
`research/small-sparse-regular-10-witness.json`. Both Python game solvers
and every alternating-state rank/losing condition agree. Its lower bound
does not depend on graph enumeration completeness.

Suppose, for contradiction, that I(G)=58. Use the notation and inequalities
of `research/small-sparse-support-proof.md`. The complete integer replay

    python3 src/small_sparse_support.py --m 20 --lower 57 \
      --out research/small-sparse-support-20-threshold57.json

leaves eleven auxiliary tuples, with these active-set possibilities:

* (q,r,b)=(9,9,6), with z=o=i=0;
* (9,9,7), with (o,i,z)=(0,0,0),(0,1,1),(1,0,1),(1,1,1);
* (9,10,8) or (10,9,8), with z=o=i=0;
* (9,10,9) or (10,9,9), with z=o=i=0;
* (10,10,9) or (10,10,10), with z=o=i=0.

These exhaust every original graph at score 58; the replay does not assume
that each surviving integer tuple is realizable.

## Cases already excluded by direct row/column counts

For (q,r,b)=(9,10,8), every arrow ends in B and all its indegrees are two.
A vertex of A minus B has indegree zero and two distinct successors. Both
recipient columns are zero. Removing them from A times B leaves at most
72 pairs, at least 18-4=14 direct pairs, and at least 8-2=6 diagonals.
Thus I<=52. For (10,9,8), prove the same statement in the original
directions: a sink in B minus A has two distinct predecessors of outdegree
two, giving two zero rows and the same count.

For (10,10,9), every arrow runs from A to B, with both indicated degrees
two. An indegree-zero vertex of A minus B gives two distinct zero columns.
The remaining count is at most 80-(20-4)-(9-2)=57.

For (9,10,9), the nonisolated support is exactly ten vertices. All
indegrees are two. The sole vertex outside A has outdegree zero or one.
If it has outdegree one, the remaining pattern is exactly one outdegree
three, all others two. The retained sparse proof bounds this class by 57:
camping loses at least five of its 62 eligible pairs, and the complete
eligible-camping-free enumeration has maximum 32. If the exceptional vertex
is a sink, the same retained proof gives at most 55 when an outdegree-two
predecessor exists; otherwise removing the sink leaves a regular nine-vertex
core, and the bound is at most 44+7=51. These bounds suffice here.
The case (10,9,9) uses the separate incoming-degree argument in that proof:
its camping-free maximum is 50, and the same 57/55/51 upper bounds apply.
No reversal invariance is assumed.

For (10,10,10), the graph is a regular ten-vertex core. The independently
reviewed new complete regular-family bound 53 applies.

## Three unmatched vertices on each side

Now q=r=9, b=6, z=0. Write C=A intersection B, U=A minus B,
V=B minus A, so |C|=6 and |U|=|V|=3. Let x,y be the active outgoing
and incoming surplus, and w the number of arrows from outside A to outside B.
The eligible count is exactly

    59-x-y-w.

Thus x+y+w<=1. A zero eligible row or column would lose at least five
eligible pairs, whereas at most one loss is affordable. None can be zero.

If x=1, at most one arrow starts outside A, so at least two members of V
are sinks. They receive at least four arrows. There is just one higher-
outdegree vertex in A, of outdegree three, and it sends at most two distinct
arrows to these two sinks. Together with the one outside-A arrow, at most
three of the four arrows can avoid an outdegree-two predecessor. Such a
predecessor has a zero row, contradiction. If y=1, at least two vertices
of U have indegree zero. Their four outgoing arrows can use at most two
arrows into the unique higher-indegree recipient and one outside-B arrow;
an indegree-two zero column follows. Hence x=y=0.

At least one vertex a of U has indegree zero. Its two successors cannot
belong to B, because every indegree in B is two. They must therefore be
the other two vertices v,w of U. These arrows exhaust all arrows ending
outside B; v,w each have a as their sole predecessor. Similarly, some
vertex t of V is a sink. Its two predecessors must be the other two
vertices p,q of V, and p,q have t as their sole successor. These exhaust
all arrows starting outside A, and in particular force w=0.

All remaining arrows go from C union {v,w} to C union {p,q}. A messenger
starting in C cannot reach a,v,w; after entering p,q,t it cannot return
to C. Consequently every guaranteed missing pair inside C is guaranteed
in the induced graph H=G[C], by restricting the pursuer to C. The graph H
has at most twelve arrows and hence at least eighteen missing pairs, but
I(H)<=M_V(6)=7. At least eleven of the eligible pairs therefore fail in G,
contradicting I=58.

## Two unmatched vertices and one outside vertex

Let q=r=9, b=7 and z=1. The eligible count is 58-x-y-w, so equality
forces x=y=w=0 and every eligible missing pair guaranteed. Put
U=A minus B and V=B minus A; both have two vertices. All degrees in A
and B are exactly two. Denote the single outside vertex by zeta.

If (o,i)=(0,1), zeta is a sink. Exactly one vertex a of U has indegree
zero. Its two successors must avoid B and are therefore the other vertex
of U and zeta. Its sink successor makes its row zero, contradiction.

If (o,i)=(1,0), zeta has indegree zero. Exactly one vertex t of V is a
sink. Its two predecessors must avoid A and are the other vertex of V and
zeta. The inaccessible predecessor makes the column of t zero.

If (o,i)=(1,1), write U={a,v} with a of indegree zero, and V={p,t}
with t a sink. Avoiding zero columns and rows forces

    a -> v,zeta;   p,zeta -> t.

These exhaust all arrows ending outside B and starting outside A. As
before, messenger play between vertices of C=A intersection B cannot use
the outside parts and return. The induced seven-vertex core has at most
fourteen arrows and thus at least 28 missing pairs, but at most M_V(7)=21
can be guaranteed. Equality of all eligible pairs is impossible.

## The only remaining family and its complete finite exclusion

The only remaining tuple is q=r=9, b=7 and z=o=i=0. There are eleven
nonisolated vertices. Equality at 58 again forces x=y=w=0. Thus there are
two distinct vertices of outdegree one, two other distinct vertices of
indegree one, and all other respective degrees are two. No arrow goes
from either outdegree-one vertex to either indegree-one vertex.

`src/small_sparse_double_defect.cpp` checks exactly this family. A bipartite
graph of maximum degree two is the disjoint union of paths and cycles, so
its arrows split into two matchings. Their sizes sum to twenty and neither
exceeds eleven: they have sizes (11,9) or (10,10). No perfect matching is
assumed. Viewed on the original vertex labels, the larger matching is a
directed partial permutation. It has either cycles only, or one directed
path and cycles. All cycle partitions and all possible path lengths are
enumerated. A path of one vertex would make a vertex have both degrees one,
which this disjoint-exception family forbids.

The first factor is normalized by relabeling. Rotations and permutations
of equally long cycles also normalize the locations of the low-outdegree
vertices. Two on one cycle are specified by their unordered cyclic
distance; two on different cycles by their two cycle lengths. For a
path-containing factor the path vertices remain individually distinguished,
while one representative on each cycle length suffices. The second factor
is then enumerated with every permitted omitted row/column and every
injective legal assignment. These reductions retain at least one labeled
representative of every candidate.

Permanent source and predecessor camping obstructions reject equality.
The additional guarded-path check lets the messenger use the union of all
still-possible arrows at an unfinished row, while the stationary pursuer
uses only already-fixed arrows. If even this optimistic messenger graph
cannot connect an eligible source to a target while avoiding the pursuer's
closed outgoing neighborhood internally, that pair can never be guaranteed.
Initial source and terminal receipt are treated separately; the target may
lie in the guarded neighborhood. All surviving complete graphs are tested
in the actual finite delivery game, with waiting and receipt-before-collision.

The completed replay is `research/small-sparse-double-defect-symmetry11.json`:
44 normalized first factors, 2,802 degree patterns, 38,086,388 partial nodes,
and 2,432 actual games; none attains 58 (the largest evaluated count is 34).
The elapsed time was 9.67 seconds. The rejected graphs are bounded below 58;
34 is not asserted as the maximum of the entire family. Earlier capped
pilots remain historical incomplete attempts and supply no upper bound.

This exhausts every hypothetical score-58 graph. Subject to the pending
independent review of this last family and reduction, M_E(20)<=57. The
literal 53-guarantee graph gives M(n,20)>=53 for every n>=10 by isolates.

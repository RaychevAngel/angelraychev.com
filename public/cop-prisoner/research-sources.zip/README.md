# Guaranteed indirect delivery in directed networks

Research checkpoint, 12 September 2026. **The final dense band is completely determined for every order at least 75; the full extremal classification remains open.**

## Start here

- `HANDOFF.md`: exact game, current theorem map, provenance, and restart priorities.
- `paper/assembled.md`: generated manuscript; the source supplements are listed below.
- `RESEARCH_LOG.md` and the dated files in `research/`: discoveries, failed approaches, independent reviews, and proof boundaries.
- `lean/README.md`: exact formal coverage and portable replay.
- Website: <https://angelraychev.com/cop-prisoner/>, with detailed-proofs, paper/downloads, and Lean child pages. Consult `research/website-deployment.json` for verified deployment state; newly written source is not evidence of deployment.

Alexandra Ignatova developed the original problem and layered construction in 2023 under Angel Raychev's mentorship, retained in a February 2024 manuscript. Their original work also established the upper bound `I(G)≤n(n−3)` and investigated two-in/two-out constructions. New attaining families, corrections, and extensions were developed in September 2026 with Astra 6 through Codex. Publication authorship remains unresolved; no arXiv submission has been made for this project.

## Current research map

1. **Sparse extrema.** The vertex bound is attained at every `n=5k`, `k≥4`; the even arc bound is attained at every `m=10k`. Attainment at all other sufficiently large orders and arbitrary odd budgets remains open. The three-arrow construction gives `M(n,3n)=n(n−4)` at every `n≥25`.
2. **Existence at every budget.** For sufficiently large `n`, every integer budget from `ceil(10n^(3/2)√log n)` through `n(n−3)` attains the missing-pair bound `M(n,m)=n(n−1)−m`. This is an existence theorem, not an explicit moderate-order threshold. Angel's full interval conjecture from `2n` remains open.
3. **Explicit intermediate constructions.** Attainment holds at every `3n≤m≤dn` when `d≥4` and `n>d³+2d`, hence throughout `3n..4n` for `n≥73`. For prime-square orders `n=p²`, `p≥5`, a parabola construction covers `4n..n(√n−1)`; at `p≥11` the intervals combine starting at `3n`. Five-type certificates cover every `2n..11n/5` at `n=5k≥50`, and every `2n..3n` at `n=5k≥80`. Combining the latter with the Sidon interval removes the gap at `3n` for these orders.
4. **Final dense band.** At every `n≥75`, for every `1≤r≤n`, the exact value is `M(n,n(n−3)+r)=2n−r−ceil(r/2)−1`. Above `n(n−2)` the maximum is zero. At `m=n(n−3)` it is `2n` for every `n≥52`. The attaining constructions are explicit, with stated finite structural certificates for some high-girth ingredients.

## Mathematical sources

- `paper/main.md`: definitions, basic bounds, original construction, computation, provenance.
- `paper/dense-extensions.md`: high-girth complements and dense interval, Theorems 18–20.
- `paper/sparse-certificates.md`: infinite two-regular family, Theorem 21 and Corollary 22.
- `paper/small-arcs.md`: arc-only extrema through seven arcs, Propositions 23–24.
- `paper/followup-extrema.md`: probability, dense loss, joins, permutation obstruction, functional extension, Theorems 25–31.
- `paper/dense-first-step.md`: first dense step and complete final band, Theorem 32 and Corollary 33.
- `paper/main-interval-explicit.md`: consecutive sparse budgets, Theorem 34.
- `paper/parabola-family.md`: prime-square orders, Theorem 35.
- `paper/sparse-budget-interval.md`: two certified sparse intervals, Theorems 36–37.

## Reproduce bounded checks

The game and certificate tools use Python's standard library:

```sh
python3 src/five_type_certificate.py
python3 src/five_type_local_verify.py
python3 src/five_type_small_certificates.py
python3 src/extremal_bounds_girth_verify.py
python3 src/dense_functional_extension.py
python3 src/dense_first_step.py
python3 src/sidon_main_interval.py
python3 src/parabola_cayley.py
python3 src/five_type_sparse_interval.py
python3 src/five_type_augmented_verify.py
python3 src/five_type_long_augmented_verify.py
```

Read each script's main function or help for supported arguments. `research/solver-method.md` explains enumeration, independent solvers, and certificate meanings. Saved experiments are not automatically proved conjectures; consult the corresponding proof.

Install the version in `lean/lean-toolchain`, then run `python3 lean/check.py`. Six modules rebuild sequentially with Std only. They cover actual game semantics, the finite 12-vertex certificate, branching/camping, and specified dense counting and gluing implications. General construction existence, modular arithmetic, probability, and graph-to-counting premises remain outside current Lean coverage.

## Manuscript and website build

`src/build_publication.py` assembles the mathematical sources, PDF, web proofs, archives, and hash manifest. It needs Python with `pypandoc_binary`, `pypdf`, and `matplotlib`, a LaTeX installation, and the website checkout at `.site-worktree` with npm dependencies. Local executable paths may need adjustment. `src/check_web_solver.py` compares the website's game implementation with Python.

The standalone manuscript-source download contains `main.tex`, bibliography, and PDF figures. Run `pdflatex main.tex` until references stabilize; its bibliography is already included. Source documents are preserved. A build, a deployment, and a verified live readback are separate facts; use the release receipts for the last two.

# Guaranteed indirect delivery in directed networks

The joint extremal problem is completely classified: for every n>=1 and0<=m<=n(n-1), the exact value M(n,m) is proved and an explicit attaining graph is supplied. M counts guaranteed missing nonloop ordered source-recipient pairs. M_V and M_E are projections of this joint answer.

Both players see both positions and may wait or follow outgoing arrows. The messenger moves first. Receipt at the actual recipient wins before collision; all other collisions and infinite evasion lose. Every legal initial pursuer position other than the source and every pursuer policy are quantified. Opposite arrows and isolated vertices are allowed.

## Results and navigation

- [Combined formula](paper/joint-classification-resume.md): every budget at every order n>=12.
- [Complete finite tables](paper/finite-values.md): every admissible pair through order11.
- [Finite completion proof](paper/finite-completion.md): shared reductions, exact sparse budgets, and finite verification boundaries.
- [Evidence guide](publication/EVIDENCE_GUIDE.md): ordinary proofs, full certificates, complete exclusions, and replay commands.
- [Scope](research/CLASSIFICATION_SCOPE.md), [completion assessment](research/CLASSIFICATION_GAPS.md), and [explicit construction inventory](research/EXPLICIT_CONSTRUCTIONS.md): the two completed obligations and parked questions.
- [Lean coverage](lean/README.md) and [remaining proof roadmap](research/LEAN_ROADMAP.md): exact theorem domains and remaining obligations; full classification is not yet formalized.
- [arXiv upload guide](publication/ARXIV_SUBMISSION.md): approved authors, metadata, source package and submission boundary.
- [Proof simplification](research/proof-slimming-execution.md): the September18 shared upper induction, pair-code overlap, functional attachment identity and sharper odd projection, with their checks and preservation boundaries.

The sparse parity formulas, main missing-pair interval, dense staircase and zero range give the four regimes. At budgets0..23, the arc-only values are0,0,0,0,1,1,2,2,4,5,6,8,9,11,13,15,19,28,33,40,53,60,79,83. All fit on hosts of order12. Smaller hosts use the finite tables. The main formula starts sharply at12; the uniform dense staircase starts sharply at11.

The final independent ledger replay closes all 101 former representatives and all 1,090 previously open audit cells, preserving every earlier equality. All 493,924 cells through order 114 are exact; ordinary parameterized proofs and support reductions establish the infinite tail. A separate recipe audit finds zero construction gaps, without relying on fresh graph search or derandomization. Certified finite graphs are read literally; larger sparse hosts add isolates.

## Proof and publication boundaries

Ordinary arguments and complete finite computational proofs establish the classification. Reviews distinguish independent game replay, independently generated degree inventories, sampled pruning checks, and a second full graph enumeration. Source hashes identify the exact evidence versions. The Lean development proves actual-game equivalence, all dense extrema from order 11, the entire main interval from order 115 and its upper part above 3n from order 25, seventeen smaller complete main intervals, uniform even sparse attainers from support 85 and odd attainers from support 98, sharp unrestricted budgets 0..10, complete joint tables through order 5, and additional certified finite scores and exclusions. It does not yet formalize the complete classification. The exact remaining domains and source-pinned replay boundary are recorded in lean/README.md and research/LEAN_ROADMAP.md.

The original problem and layered construction arose in Alexandra Ignatova's2023 project under Angel Raychev's mentorship, retained in a February2024 manuscript. Their prior work includes the n(n-3) upper bound and two-in/two-out direction. September2026 corrections and extensions were developed with Astra6 through Codex. Approved publication authors are Angel Ivanov Raychev, then Alexandra Ignatova (Eindhoven University of Technology). The contribution statement is approved. This project has not been submitted to arXiv. See publication/ARXIV_SUBMISSION.md for the prepared package and remaining submission decisions.

Delivery-time optimization and classification of all extremizing shapes remain outside the completed objective. The [parked companion](paper/delivery-time-companion.md) preserves the proved timing results and its genuine open problems. Every stronger optional-subset, time or routing conclusion remains attached to its original construction theorem.

## Rebuild and inspect

Edit sources named by [publication/manifest.json](publication/manifest.json), not generated TeX or proof HTML. The builder assembles the paper and website proofs, checks source-pinned evidence, recompiles the standalone LaTeX archive, and prepares the existing download inventory. The numerical and recipe audits are separate. The complete finite table generator also independently checks the assembled classification against every stored cell.

The [public overview](https://angelraychev.com/cop-prisoner/), [proofs](https://angelraychev.com/cop-prisoner/proofs/), [paper/evidence](https://angelraychev.com/cop-prisoner/paper/), [Lean page](https://angelraychev.com/cop-prisoner/lean/), and [timing companion](https://angelraychev.com/cop-prisoner/delivery-time/) share those sources. Current build, PDF visual verification and public deployment are separate claims: consult research/publication-build.json, research/pdf-verification.json, research/pdf-visual-review.json and research/website-deployment.json. The mathematical completion alone does not certify a newer deployment.

Extract research-sources.zip, finite-strategy-certificates.zip and lean-proofs.zip into the same directory for replay. The evidence guide identifies the required scripts and their exact scopes. Research history, failed approaches and prior checkpoints remain in [RESEARCH_LOG.md](RESEARCH_LOG.md), [the pass log](research/finish-pass-log.md), and research/history.

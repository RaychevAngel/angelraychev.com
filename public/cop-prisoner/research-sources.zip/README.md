# Guaranteed indirect delivery in directed networks

Research checkpoint, 12 September 2026. The full extremal classification is open.

## Start here

- `paper/main.md`, `paper/dense-extensions.md`, `paper/sparse-certificates.md`, and `paper/small-arcs.md`: the mathematical manuscript. The publishing script assembles supplements before the computational evidence into `paper/assembled.md`.
- `RESEARCH_LOG.md`: chronology, failures, proof reviews, and the next research targets.
- `HANDOFF.md`: original game definition, source provenance, agreed scope, and current restart status.
- `lean/README.md`: exact formal coverage and portable replay.
- Website: <https://angelraychev.com/cop-prisoner/>; detailed proofs, paper downloads, and Lean coverage have separate child pages.

The original problem and layered construction are Alexandra Ignatova's 2023 work under Angel Raychev's mentorship, retained in a February 2024 manuscript. The September 2026 repairs and extensions were developed with assistance from Astra 6 through Codex. Publication authorship is not assigned by this checkpoint.

## Reproduce the mathematical checks

The Python game and certificate checkers use the standard library. Run from the extracted research archive or project root:

```sh
python3 src/five_type_certificate.py
python3 src/five_type_local_verify.py
python3 src/five_type_small_certificates.py
python3 src/extremal_bounds_girth_verify.py
```

Read each script's command-line help or main function for optional output paths. These bounded checks verify the local infinite-family ingredients, the six finite bases, and the structural bridge from 52 to 130 vertices. `research/solver-method.md` describes exact finite enumeration, independent solvers, and what their certificates prove. Experiments saved as JSON are not automatically proved conjectures: consult the associated proof and log.

For Lean, install the version in `lean/lean-toolchain` and run:

```sh
python3 lean/check.py
```

All five modules rebuild sequentially. No Mathlib is required. The actual game interpretation and the 12-vertex example are formalized; the general extremal and infinite-family theorems are not all Lean theorems.

## Manuscript and website build

The manuscript-source download contains a standalone `main.tex`, bibliography and PDF figures. Run `pdflatex main.tex` until the auxiliary files stabilize, normally two or three passes. The bibliography is already included; BibTeX is unnecessary.

For the full source build, `src/build_publication.py` requires Python with `pypandoc_binary`, `pypdf`, and `matplotlib`, a LaTeX installation, and a checkout of <https://github.com/RaychevAngel/angelraychev.com> at `.site-worktree` with its npm dependencies. Its local executable paths may need adjustment. It generates the PDF, web proof text from the same mathematical source, source archives, and a hash manifest. `src/check_web_solver.py` cross-checks the website's game implementation against Python and requires that website checkout too.

No original manuscript files are overwritten, and no submission to arXiv has been made for this project.

Provenance clarification from Angel, 12 September 2026: he and Alexandra had already established the n(n-3) upper bound and actively investigated two-in/two-out constructions in their original work. Neither that bound nor that research direction should be credited as newly introduced in this run. The explicit attaining families and their current proofs are the new progress.

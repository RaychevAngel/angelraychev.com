# Circle constructions with three-way escape

The following construction gives the messenger several alternative moves.
No pursuer at a different vertex can cover all alternatives. A finite
propagation argument then makes every source winning for every recipient.
The construction tolerates every subset of its optional arrows.

**Theorem (half-density circles and a wraparound gap).** Let $h\ge7$,
$h\equiv3\pmod4$, $2h+2\le n$, and $\gcd(h,n)=1$. In $\mathbb Z/n\mathbb Z$,
take the compulsory offsets
$$C=\{1,h-3,h-2,h,h+2\}.$$
One may use either of the following closed offset sets, whose representatives
are in $\{0,\ldots,n-1\}$:

1. If $4\mid n$, take
   $$A=\{x:x\equiv0,1\pmod4\}\cup\{h\}\setminus\{2h-1\}.$$
2. At any order satisfying the hypotheses, take
   $$A=\{0\le x\le n-h:x\equiv0,1\pmod4\}\cup\{h\}
   \setminus\{2h-1\}.$$

In both formulas the deletion applies to the whole preceding union.
Include all arrows $x\to x+c$ for $c\in C$, and an arbitrary subset of
the arrows $x\to x+a$ for $a\in A\setminus(C\cup\{0\})$.
Every resulting graph has universal delivery and hence attains
$$M(n,m)=n(n-1)-m\qquad\text{for every }5n\le m\le n(|A|-1).$$
For an exact budget, include the first $m-5n$ optional arrows in increasing
lexicographic order of their ordered endpoints.

The first version has $|A|=n/2$. For the second version, put $L=n-h$,
write $L+1=4q+r$ with $0\le r<4$, and put
$$e=\mathbf1_{2h-1\le L}.$$
Then $|A|=2q+\min(r,2)+1-e$. These are explicit adjacency and counting
rules, with no graph search.

**Proof.** All five compulsory offsets are distinct and nonzero. They
belong to either envelope: $h+2\le n-h$, and none equals the deleted
offset. The offset zero is allowed for waiting but is not counted as an
arrow. The cardinalities follow by counting the residue classes and the
one exceptional offset $h$.

We first prove a local escape property. Relative to a messenger at zero,
the following sets of alternative moves cannot all be reached in one move
(including waiting) by any pursuer at $q\ne0$:
$$\{h,1\},\qquad\{h,h-3,h-2\},\qquad\{h,h-2,h+2\}.$$

For a full modulo-four envelope, suppose the pursuer reaches $h$.
A pursuer congruent to one modulo four cannot do so. A pursuer congruent
to zero must be zero, because $h$ is the only envelope element congruent
to three. A pursuer congruent to two reaches no zero-class point and at
most one one-class point. A pursuer congruent to three reaches no
one-class point. Each displayed triple contains $h$ together with either
a zero-class and a one-class point, or two distinct one-class points.
This proves their escape property. For the pair $\{h,1\}$, the only remaining possible pursuer is
$q=1-h$. Reaching $h$ would require the deleted offset $2h-1$, a contradiction.

The second envelope has a gap of $h-1$ consecutive absent offsets at the
end of its representative interval. Every displayed alternative set has
diameter at most $h-1$. If, after subtracting a pursuer position, its
representatives wrapped around zero, their extreme representatives would
differ by at least $n-h+1$. They cannot both lie in $[0,n-h]$. Thus any
putative covering uses a common integer lift of the entire alternative
set. The same residue argument applies to that lift. Its only exceptional
pursuer is the integer zero, which represents the excluded modular
pursuer zero. The pair argument again requires a deleted offset. This
proves the local escape property for every order in the second version.

Fix recipient zero. Call a vertex winning when it guarantees eventual
delivery from every distinct pursuer position. The recipient and all
direct compulsory predecessors are winning. Whenever the compulsory
successors of a vertex contain one of the displayed alternative sets of
already winning vertices, that vertex is winning too: choose a successor
outside the pursuer's full closed envelope. After the pursuer response,
the positions remain distinct and the winning successor strategy applies.
Each use of this rule increases a finite delivery rank, so the conclusion
is delivery in finite time, not merely indefinite evasion.

Let $P(z)=\{z-2,z-1,z,z+2\}$. The pattern $P(-h)$ is winning:
three of its vertices are direct compulsory predecessors; its remaining
vertex $-h-1$ uses offsets $h,1$ to reach predecessors $-1,-h$.
Given $P(z)$, make the following four additions in order:

* $z-h+2$ uses $h,h-3,h-2$, reaching $z+2,z-1,z$;
* $z-h$ uses $h,h-2,h+2$, reaching $z,z-2,z+2$;
* $z-h-1$ uses $h,1$, reaching $z-1,z-h$;
* $z-h-2$ uses $h,1$, reaching $z-2,z-h-1$.

Every successor belongs to the original pattern or an earlier addition.
The resulting set contains $P(z-h)$. Since $\gcd(h,n)=1$, repeated shifts
by $-h$ visit every residue. Modular coincidences only identify vertices
already known to be winning; they do not invalidate this finite induction.
Translating this proof gives every recipient. All moves of the messenger
are compulsory, and the pursuer has throughout been allowed the entire
envelope. Consequently the assertion holds for every optional subset,
including nonsymmetric ones. The arc count and the missing-pair upper
bound give the stated value of $M$. $\square$

**Parameters at every order divisible by four.** The full-envelope version
applies to every $n\ge16$ divisible by four. If $8\mid n$, choose
$h=n/2-1$. Otherwise write $n=4k$ with odd $k\ge5$: choose $h=k+2$ when
$k\equiv1\pmod4$, and $h=k+4$ when $k\equiv3\pmod4$. The relevant gcd
divides eight or sixteen and is odd, so is one. The remaining inequalities
follow directly. Thus the complete direct interval in that subfamily is
$$5n\le m\le n(n/2-1).$$

For other orders, take the smallest admissible $h$, or choose among the
finitely many arithmetic candidates to maximize the explicit envelope
count. This parameter calculation is separate from graph or strategy
search. In particular $h=7$ applies whenever $n\ge16$ and $7\nmid n$,
regardless of the parity of $n$. The second family therefore bridges the
old divisibility restriction while losing only a bounded number of
offsets when $h$ is fixed.

**Relation to the earlier eight-move construction.** The previous
construction had the additional compulsory offsets $5,h-7,h+1$ and
removed both $2h-5$ and $2h-1$, under the stronger assumption $h\ge11$.
Its compulsory graph contains the present one and its envelope is contained
in the present envelope. Thus the present theorem preserves every old
optional-subset guarantee while lowering the compulsory budget from $8n$
to $5n$ and restoring one allowed offset. In particular the earlier interval
$8n\le m\le n(n/2-2)$ at $4\mid n$, $n\ge24$, remains valid.

The direct implementation is `src/main_interval_half_density.py`.
Finite structural replays are recorded separately. `CircleConstruction.lean`
and `CircleGuardedConstruction.lean` also instantiate the full and guarded
five-offset constructions with exact counts and optional prefixes;
`CircleParameters.lean` supplies the displayed divisible-by-four domain.

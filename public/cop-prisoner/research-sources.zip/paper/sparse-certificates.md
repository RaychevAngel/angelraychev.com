# An infinite family attaining the sparse bounds

The five-type graph used in the dense construction also attains the sparse vertex and arc-budget bounds. This requires a different strategy: its messenger may need to travel around a substantial part of the ring. The proof combines fixed local certificates with a simulation valid at every sufficiently large circumference, followed by six finite base cases.

For clarity, define the sparse graph $H_k$ again. Its vertices are
$$ (i,j)\in (\mathbb Z/k\mathbb Z)\times\{0,1,2,3,4\}.$$
The first outgoing arc follows the cycle
$$(i,0)\to(i,1)\to(i,2)\to(i,3)\to(i,4)\to(i+1,0).$$
The second outgoing arc is specified by
$$
\begin{aligned}
(i,0)&\to(i+1,0), & (i,1)&\to(i-1,2),\\
(i,2)&\to(i-1,4), & (i,3)&\to(i-1,3),\\
(i,4)&\to(i-1,1).
\end{aligned}
$$
Both arc maps are permutations, are loopless, and have distinct images at every vertex when $k\ge4$. Hence $H_k$ has $5k$ vertices and $10k$ arcs, with indegree and outdegree two everywhere. Waiting is an additional legal action, as throughout the paper.

![The five station types in consecutive columns. Black arrows follow the long cycle and blue arrows give the second permutation. Identifying columns modulo k closes the strip into the graph H_k.](figures/five-type-strip.pdf)

**Theorem 21 (uniform sparse attainment).** For every integer $k\ge4$, every source–recipient pair in $H_k$ is guaranteed. Consequently
$$
M_V(5k)=5k(5k-3),\qquad
M_E(10k)=5k(5k-3).
$$
For $k\ge10$, a sufficient delivery time is $8k+16$ messenger moves. The theorem is computer-assisted: its finite ingredients are the two local objectives specified below and the six rings $4\le k\le9$.

## The stronger local arena

Unwrap the column coordinate to the integers, retaining the same two arc rules. Confine the messenger to columns $-3,\ldots,3$, disallowing moves out of this interval. Represent the pursuer by its exact vertex in columns $-4,\ldots,4$, together with an exterior state $\Omega$. Thus there are 35 messenger positions and 46 pursuer positions.

Within its nine-column window the pursuer has all its usual moves and its wait; a move leaving the window goes to $\Omega$. From $\Omega$ it may wait or enter any vertex of either boundary column $-4$ or $4$. This grants more freedom than a particular physical pursuer outside the window. The messenger and $\Omega$ can never coincide.

The two objectives have different stopping rules:

- A **safe transfer** ends in column zero at the start of a messenger turn, with the positions distinct. Entering column zero on a messenger move is insufficient: the intervening pursuer response must also be survived.
- A **delivery** ends immediately when the messenger enters a specified vertex $(0,t)$, before collision is checked there, exactly as in the original game.

For each objective, the certificate assigns nonnegative integer ranks to winning states and selects a legal move at every positive-rank messenger state. Every selected move decreases rank, and every legal response at a positive-rank pursuer state also decreases rank. The zero-rank states are precisely the applicable terminal successes. These conditions prove termination by induction on rank. For safe transfer, only noncollision **messenger-turn** states in column zero are seeded as successes; pursuer-turn states there still require all their responses to be safe.

The checked finite bounds are:

| Local objective | Initial column | Initial noncollision states | Maximum messenger moves |
|:--|--:|--:|--:|
| Safe transfer to column zero | 1 | 225 | 8 |
| Delivery to $(0,0)$ | 2 | 225 | 24 |
| Delivery to $(0,1)$ | 2 | 225 | 16 |
| Delivery to $(0,2)$ | 2 | 225 | 16 |
| Delivery to $(0,3)$ | 2 | 225 | 17 |
| Delivery to $(0,4)$ | 2 | 225 | 18 |

Each row covers all five source types and all 46 pursuer states other than the source itself. In particular, it includes an initially exterior pursuer. Only the bounds 8 and 24 are needed below; optimality of these local times is not claimed as a separate result.

## Projection to a ring

Fix $k\ge10$ and any reference column. Its nine offsets $-4,\ldots,4$ represent distinct columns of the ring. Map a physical pursuer in this window to its exact local position and every other pursuer position to $\Omega$.

Every physical pursuer move has a permitted image. A move within the window is unchanged, one leaving it goes to $\Omega$, and a move remaining outside is represented by waiting at $\Omega$. A move from outside into the window can enter only a boundary column, because each arc changes the column by at most one; every such entry is permitted from $\Omega$. At $k=10$ the exterior consists of a single column adjacent to both boundaries, and both entries are already allowed. At $k=9$ the two boundary columns themselves have wraparound adjacencies, so this argument would fail; those rings are deliberately covered by finite checks instead.

Every messenger move permitted by the local certificate is a genuine ring move. Its seven represented columns lie strictly inside the pursuer window. Consequently a physical collision with the messenger is exactly a local collision; an exterior pursuer cannot coincide with it. Following a local winning strategy therefore succeeds against every physical pursuer strategy. This is a simulation of legal moves and collisions, not an assumption that winning strategies pass automatically to graph covers.

## Composition and termination

**Proof of Theorem 21.** Translate the recipient's column to zero, and let the messenger's current column be $d$. Translate the safe-transfer window so that its local column zero is the physical column $d-1$; the messenger then starts in local column one. The certificate reduces its physical column by one modulo $k$ and finishes only after the pursuer's response, so another transfer can begin with the correct turn order. Recenter the window between transfers; each new local certificate is valid for every resulting noncollision pursuer position.

After the least nonnegative residue of $d-2$ modulo $k$ such transfers, at most $k-1$, the messenger is in column two. Apply the delivery certificate for the recipient's type. This takes at most
$$8(k-1)+24=8k+16$$
messenger moves. If a transfer encounters the actual recipient earlier, terminal receipt wins immediately and only shortens the play. Thus the argument guarantees finite delivery, not merely indefinite safe movement.

For $4\le k\le9$, the explicit finite-ring certificates verify every source and pursuer position for each of the five recipient types in column zero. Translating columns gives every recipient. These six checks, together with the uniform argument for $k\ge10$, establish universality for all $k\ge4$.

Finally, a universal graph with $n=5k$ vertices and $2n$ arcs has
$$I(H_k)=n^2-n-2n=n(n-3).$$
The vertex upper bound and the even arc-budget upper bound both equal this number. Hence both asserted extremal equalities follow. $\square$

**Certificate reproduction and scope.** The file `research/five-type-certificates.json` contains the fixed local arena, ranks, and chosen messenger moves, generated and directly checked by `src/five_type_certificate.py`. The independent implementation `src/five_type_local_verify.py` constructs the explicit alternating-state graph from the arc rules and checks every winning rank condition, as well as closure of the losing region. Its full ranks and selected moves are saved in `research/five-type-independent-local-certificates.json`, together with the implementation hash. Both implementations agree on the six local bounds above. The six finite bases are stored in `research/five-type-small-ring-certificates.json`, including complete arc lists, messenger-move layers, and explicit alternating-state rank certificates for the five representative recipient types. The script `src/five_type_small_certificates.py` reproduces those checks using both game solvers and verifies every certificate transition. The ordinary projection and composition proof explains why these finite arrays certify infinitely many rings. This theorem is not currently claimed as a Lean formalization.

**Corollary 22 (sharp arc-budget leading term).** As $m\to\infty$,
$$M_E(m)=\frac{m^2}{4}-O(m).$$
More explicitly, for every $m\ge40$,
$$\frac{m^2}{4}-6m\le M_E(m)\le\left\lfloor\frac m2\right\rfloor^2.$$

**Proof.** Set $k=\lfloor m/10\rfloor\ge4$ and $r=m-10k$, so $0\le r\le9$. Take $H_k$ together with $r$ disjoint one-way arcs. Each added component has no indirect guaranteed pair, and additivity over components preserves $I(H_k)$. This graph has exactly $m$ arcs and
$$
I=25k^2-15k
=\frac{(m-r)^2}{4}-\frac{3(m-r)}2
\ge\frac{m^2}{4}-6m.
$$
The upper bound follows because there are at most $\lfloor m/2\rfloor$ possible sources and at most that many possible recipients of indirect guaranteed pairs. Thus the quadratic coefficient $1/4$ is sharp for arbitrary arc counts, not only the progression $m=10k$. $\square$

Exact equality at arbitrary orders and arc counts remains a separate question. The padding argument establishes the leading term; it does not fill the gaps between the sharp values supplied by Theorem 21.

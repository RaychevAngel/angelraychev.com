# An infinite family attaining the sparse bounds

The five-type graph used in the dense construction also attains the sparse vertex and arc-budget bounds. This requires a different strategy: its messenger may need to travel around a substantial part of the ring. The proof combines fixed local certificates with a simulation valid at every sufficiently large circumference, followed by six finite base cases.

For clarity, define the sparse graph $H_k$ again. Its vertices are
$$ (i,j)\in (\mathbb Z/k\mathbb Z)\times\{0,1,2,3,4\}.$$
The first outgoing arc follows the cycle
$$(i,0)\to(i,1)\to(i,2)\to(i,3)\to(i,4)\to(i+1,0).$$
The second outgoing arc is specified by
$$
\begin{aligned}
(i,0)&\to(i+1,0), & (i,1)&\to(i-1,2),\\
(i,2)&\to(i-1,4), & (i,3)&\to(i-1,3),\\
(i,4)&\to(i-1,1).
\end{aligned}
$$
Both arc maps are permutations, are loopless, and have distinct images at every vertex when $k\ge4$. Hence $H_k$ has $5k$ vertices and $10k$ arcs, with indegree and outdegree two everywhere. Waiting is an additional legal action, as throughout the paper.

![The five station types in consecutive columns. Black arrows follow the long cycle and blue arrows give the second permutation. Identifying columns modulo k closes the strip into the graph H_k.](figures/five-type-strip.pdf)

**Theorem 21 (uniform sparse attainment).** For every integer $k\ge4$, every source–recipient pair in $H_k$ is guaranteed. Consequently
$$
M_V(5k)=5k(5k-3),\qquad
M_E(10k)=5k(5k-3).
$$
For $k\ge10$, a sufficient delivery time is $8k+16$ messenger moves. The theorem is computer-assisted: its finite ingredients are the two local objectives specified below and the six rings $4\le k\le9$.

## The stronger local arena

Unwrap the column coordinate to the integers, retaining the same two arc rules. Confine the messenger to columns $-3,\ldots,3$, disallowing moves out of this interval. Represent the pursuer by its exact vertex in columns $-4,\ldots,4$, together with an exterior state $\Omega$. Thus there are 35 messenger positions and 46 pursuer positions.

Within its nine-column window the pursuer has all its usual moves and its wait; a move leaving the window goes to $\Omega$. From $\Omega$ it may wait or enter any vertex of either boundary column $-4$ or $4$. This grants more freedom than a particular physical pursuer outside the window. The messenger and $\Omega$ can never coincide.

The objectives are safe handoff in column zero and immediate delivery to
$(0,t)$, with the distinct stopping rules of local simulation. The
certificates use strict half-move rank descent, seeding handoff only at
noncollision messenger turns and receipt before collision.

The checked finite bounds are:

| Local objective | Initial column | Initial noncollision states | Maximum messenger moves |
|:--|--:|--:|--:|
| Safe transfer to column zero | 1 | 225 | 8 |
| Delivery to $(0,0)$ | 2 | 225 | 24 |
| Delivery to $(0,1)$ | 2 | 225 | 16 |
| Delivery to $(0,2)$ | 2 | 225 | 16 |
| Delivery to $(0,3)$ | 2 | 225 | 17 |
| Delivery to $(0,4)$ | 2 | 225 | 18 |

Each row covers all five source types and all 46 pursuer states other than the source itself. In particular, it includes an initially exterior pursuer. Only the bounds 8 and 24 are needed below; optimality of these local times is not claimed as a separate result.

## Projection to a ring

Apply the window-projection lemma with $M=3$, $R=4$, $J=1$ and circumference $k\ge10=2R+J+1$. Both arrow rules lift literally, so every selected messenger move is legal. The local-simulation lemma therefore transfers both objectives to every translated window. At $k=9$ the boundary columns have wraparound adjacencies, which is why smaller rings retain separate finite certificates.

## Composition and termination

**Proof of Theorem 21.** Relative to a recipient in column zero, transfers move one column backward and delivery starts in column two. All source types are eligible. Cyclic strategy composition with $L=d=1$, $\tau=8$ and $D=24$ gives the bound
$$8(k-1)+24=8k+16$$
messenger moves.

For $4\le k\le9$, the explicit finite-ring certificates verify every source and pursuer position for each of the five recipient types in column zero. Translating columns gives every recipient. These six checks, together with the uniform argument for $k\ge10$, establish universality for all $k\ge4$.

Finally, a universal graph with $n=5k$ vertices and $2n$ arcs has
$$I(H_k)=n^2-n-2n=n(n-3).$$
The vertex upper bound and the even arc-budget upper bound both equal this number. Hence both asserted extremal equalities follow. $\square$

**Certificate reproduction and scope.** The file `research/five-type-certificates.json` contains the fixed local arena, ranks, and chosen messenger moves, generated and directly checked by `src/five_type_certificate.py`. The independent implementation `src/five_type_local_verify.py` constructs the explicit alternating-state graph from the arc rules and checks every winning rank condition, as well as closure of the losing region. Its full ranks and selected moves are saved in `research/five-type-independent-local-certificates.json`, together with the implementation hash. Both implementations agree on the six local bounds above. The six finite bases are stored in `research/five-type-small-ring-certificates.json`, including complete arc lists, messenger-move layers, and explicit alternating-state rank certificates for the five representative recipient types. The script `src/five_type_small_certificates.py` reproduces those checks using both game solvers and verifies every certificate transition. The ordinary projection and composition proof explains why these finite arrays certify infinitely many rings. This theorem is not currently claimed as a Lean formalization.

**Corollary 22 (sharp arc-budget leading term).** As $m\to\infty$,
$$M_E(m)=\frac{m^2}{4}-O(m).$$
More explicitly, for every $m\ge40$,
$$\frac{m^2}{4}-6m\le M_E(m)\le\left\lfloor\frac m2\right\rfloor^2.$$

**Proof.** Set $k=\lfloor m/10\rfloor\ge4$ and $r=m-10k$, so $0\le r\le9$. Take $H_k$ together with $r$ disjoint one-way arcs. Each added component has no indirect guaranteed pair, and additivity over components preserves $I(H_k)$. This graph has exactly $m$ arcs and
$$
I=25k^2-15k
=\frac{(m-r)^2}{4}-\frac{3(m-r)}2
\ge\frac{m^2}{4}-6m.
$$
The upper bound follows because there are at most $\lfloor m/2\rfloor$ possible sources and at most that many possible recipients of indirect guaranteed pairs. Thus the quadratic coefficient $1/4$ is sharp for arbitrary arc counts, not only the progression $m=10k$. $\square$

Theorem 40 proves exact vertex maxima at every order from twelve and exact even arc maxima from 24 arcs; Corollary 45.1 proves exact odd arc maxima from 25 arcs. The padding argument above is retained as a direct proof of the leading term. The remaining small exceptions are stated in the current result summary.

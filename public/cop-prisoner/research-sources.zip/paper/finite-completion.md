# Completion of the finite sparse budgets

The ordinary source/sink and positive-support lemma supplies one common
reduction. We use the exact smaller budgets in increasing order, followed
by the complete finite exclusions listed below. The game and counted pairs
are unchanged: messenger first, waiting allowed, receipt before capture,
and distinct nonadjacent source--recipient pairs.

**Theorem (finite sparse-budget values).** The budgets twelve through
twenty-one have the following global maxima and least attaining host orders:

| $m$ | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| $M_E(m)$ | 9 | 11 | 13 | 15 | 19 | 28 | 33 | 40 | 53 | 60 |
| Least host $h$ | 7 | 8 | 8 | 8 | 8 | 10 | 9 | 11 | 10 | 12 |

For every $n\ge h$, $M(n,m)=M_E(m)$. The exceptional smaller-host values are
$$M(9,17)=24,\quad M(9,19)=35,\quad M(10,19)=38,$$
$$M(10,21)=56,\qquad M(11,21)=58.$$

## The finite domains, in budget order

Write $A_j=M_E(j)$, $D_m$ for (56.3), and $B_m$ for the positive-support
bound (56.4). The exact values through eleven arrows are already established.
At each following budget, use only the preceding exact values.

**Budgets twelve through sixteen.** In a strict counterexample to the
displayed value, a degree-one source or sink is impossible because
$A_{m-1}$ is smaller. A source or sink of other degree at least three
has score at most
$$A_{m-3}+\lfloor(m-3)/2\rfloor=9,11,13,15,17$$
at the five respective budgets, again at or below the displayed target.
Thus every nonisolated source or sink has other degree exactly two.
Every nonisolated vertex has total degree at least two, so the support
has order at most $m$. This directly justifies the comparison hosts
12 and 13 for their complete exclusions: a smaller support is padded
with isolates. No final least-attaining-host value is used to prove
either comparison.

For budgets fourteen through sixteen, the deleted degree-two row or
column must be live, because otherwise deletion gives the smaller value
$A_{m-2}$. A source-to-sink arrow would contradict its required two
nonsink successors or two positive-indegree predecessors. These observations
also hold at twelve and thirteen, although their full-host exclusions
already cover the permitted graphs.

For completeness, the simultaneous live capacities used by the retained
enumerators follow from the same lemma. Let $S$ be the total outgoing
degree of all indegree-zero vertices and $T$ the total incoming degree
of all sinks. If $R,C$ are the numbers of live rows and columns, then
$$R\le\lfloor(m-T)/2\rfloor,\qquad C\le\lfloor(m-S)/2\rfloor.$$
With active sets of sizes $q,r$ and overlap $b$, the count for $u,v$
actual live rows and columns gives
$$
I\le\max_{\substack{0\le u\le\min(q,R)\\0\le v\le\min(r,C)}}
\{uv-(b-q-r+u+v)_+-(2u+2v-m)_+\}. \tag{F.1}
$$
Routes through nonlive vertices remain available; this counts pairs,
not an induced game on live vertices.

The complete twelve- and thirteen-arrow exclusions have respectively
65 and 88 outgoing-degree profiles. The fourteen- through sixteen-arrow
packages cover all permitted positive and degree-two-zero profiles on
supports nine through $m$, together with the reviewed eight-vertex bounds
13,15,19. The retained seven-vertex bounds at those budgets are 10,11,12.
Consequently every support is covered. The literal attainers give equality,
allowing the induction to continue.

**Budgets seventeen through twenty-one.** Once the preceding exact values
are known, every graph with an actual source or sink is bounded as follows:

| $m$ | 17 | 18 | 19 | 20 | 21 |
|---|---:|---:|---:|---:|---:|
| $D_m$ | 22 | 28 | 36 | 42 | 53 |

All are strictly below the global target. For positive support, (56.4)
leaves the following finite domains; support cannot exceed $m$.

| $m$ | Supports requiring finite exclusions | Larger-support arithmetic bound |
|---|---|---|
| 17 | 9,10 | $B_m\le28$ for $N\ge11$ |
| 18 | 9,10,11 | $B_m\le30$ for $N\ge12$ |
| 19 | 9,10,11 | $B_m\le38$ for $N\ge12$ |
| 20 | 10,11 | $B_m\le48$ for $N\ge12$ |
| 21 | 10,11 | $B_m\le60$ at $N=12$, and $\le50$ for $N\ge13$ |

At seventeen arrows, the retained eight-vertex value 19 excludes every
smaller host by isolate padding. At eighteen use $M_V(8)=32$.
At nineteen, twenty and twenty-one, the missing-pair bounds on the
respective smaller supports are 37,52,51. These are independent of the
global values being proved.

The seventeen- and eighteen-arrow joint-degree exclusions therefore give
the claimed maxima and $M(9,17)=24$. At nineteen arrows the complete
positive-support exclusions give 35,38,40 on orders 9,10,11. The general
source/sink bound 36 suffices at ten and eleven. At nine vertices it
sharpens to 25: degree-one deletion gives $M(8,18)=21$, degree two gives
$M(8,17)+6=25$, and degree at least three gives $A_{16}+5=24$.
An isolate leaves the retained value $M(8,19)=22$. Thus the fixed-host
claims also cover every graph.

At twenty arrows, the positive ten-vertex possibilities above 53 are
the regular family, the two directional single-transfer families, and
eleven joint-degree multisets comprising double transfers or a transfer
in both directions. The existing regular and directional bounds are 53;
the complete eleven-profile exclusion supplies the same bound for the
remainder. On eleven vertices, exceeding 53 requires $q=r=9$:
there are two degree-one vertices in each direction and all other degrees
two. The complete two-defect exclusion retains all overlaps of the low
sets and gives 53. This finishes the global bound without the historical
nineteen-arrow upper 53 or the comparison-host argument.

At twenty-one arrows, the ten-vertex exclusions bound the one-excess
family and the twelve remaining joint-degree multisets by 56. All other
positive degree counts have cap at most 54. At eleven vertices, the
one-low-in/one-low-out family has upper 56; the remaining cases above
58 have $(q,r)=(9,10)$ or $(10,9)$ and are included in the complete
eleven-profile exclusion with upper 58. The five $q=r=9$ profiles in
that inventory already have cap 57. The source/sink bound 53 applies
on both hosts, so their literal values 56 and 58 are exact. The
twelve-vertex literal attains the arithmetic upper 60. No separate
nineteen-arrow upper 49 is needed.

Every lower bound is a saved literal graph with complete winning ranks and
a closed losing region independently checked. Adding isolates preserves
its score. Least attainment at seven and eight follows from $M(6,12)=7$
and $(M(7,13),M(7,14),M(7,15),M(7,16))=(10,10,11,12)$.
The displayed smaller-host values handle budgets 17,19,21; at eighteen
use $M_V(8)=32$, and at twenty a nine-vertex graph has only52 missing
pairs. This proves all assertions. $\square$

The next endpoints use exactly the same reduction: at twenty-two arrows,
$D_{22}=63$, positive supports at least twelve have cap 74, and supports
at most ten have at most 68 missing pairs. Only order eleven remains.
At twenty-three, $D_{23}=79$, positive supports at least thirteen have
cap 76, and supports at most ten have at most 67 missing pairs. The
twenty-two- and twenty-three-arrow sections complete those residual
families, in that order.

## What a complete finite exclusion establishes

Each producer lists every permitted degree profile. Joint profiles assign
incoming degrees to sorted outgoing degrees, sorting only within equal-outdegree
classes. Zero entries are retained whenever the ordinary reduction permits
them. Adjacency rows are assigned completely. Future vertices may be permuted
only when their prescribed degree pairs and already fixed incoming prefixes
agree; these permutations fix every completed row. Choosing every possible
cardinality and a prefix in each such class retains a representative of
every completion. Earlier vertices remain individual choices, loops are
forbidden, and opposite arrows are independent. Matching-based families
retain their separately proved complete factorization and normalization.

Pruning subtracts permanent losses as a union. Source camping requires a
different initial cop; predecessor camping retains the source-equals-cop
exception. A column loss applied to an unfinished row uses a full column,
so a future direct arrow cannot be subtracted twice. Guarded-path tests
grant the messenger every individually possible future arrow and keep
only fixed cop arrows, permitting the initial escape and terminal receipt.
Failure in this easier game is permanent. Every surviving leaf is evaluated
in the actual alternating game. Early exit uses the current count plus
every unprocessed eligible pair as an upper bound. An incumbent rises
only after a literal larger score is evaluated; earlier prunes remain
valid under the larger final bound. Complete traversal therefore excludes
every score above that bound.

## Evidence and computational boundary

The following records, under `research/`, specify the exact completed families,
source hashes, literal graphs, and independent reviews. Counts refer to residual families;
inherited finite results retain their original evidence.

- **Budgets 12–13.** `endpoint40_tiny_live_review.json` supplies complete 65- and 88-profile exclusions, independently counted inventories, and independent checks on 6,651 graphs, 44,376 prefixes and 662,312 specific camping states. It does not claim a second full graph traversal.
- **Budgets 14–16.** `finish_budget_manifest.json` and `finish-budget-ordinary-review.json` supply complete prescribed-degree residual families, with 118,547 leaf games independently replayed, together with the reviewed eight-vertex bounds.
- **Budgets 17–18.** `finish_eighteen_review_manifest.json` and `finish_eighteen_review_seventeen.json` supply exact joint-profile set comparisons, with 73,472 package leaf games and 26,662 stronger seventeen-arrow leaf games independently replayed.
- **Budget 19.** `sparse_finish_nineteen_exact_manifest.json` and `finish_nineteen_review_manifest.json` supply 153 complete joint profiles and 291,301 independently replayed leaf games; the literal host values are 35, 38 and 40.
- **Budget 20.** `finish-sparse-review.json` supplies independent coverage and game review of the new residual families, with 19,286 leaf games. Inherited regular and directional-transfer bounds are explicitly identified.
- **Budget 21.** `sparse_finish_twentyone_manifest.json` and `finish-twentyone-review.json` supply complete matching and joint-degree families, independent alternating-game leaf replays and permanent-loss checks; the literal host values are 56, 58 and 60.

The independent game replays use a separately written alternating-state
attractor. For literal attainers, finite winning ranks and all losing-closure
conditions are checked. Except where a record explicitly supplies a second
generator, replay reuses the independently reviewed producer traversal. These
are ordinary finite proofs with auditable computational premises; they do not
claim new concrete Lean certificates.

The eight-vertex row is now completely classified: the sparse, lower-main and
upper-main receipts are `endpoint40_n8_sparse_receipt.json`,
`endpoint40_n8_low_receipt.json`, and `endpoint40_n8_high_receipt.json`, with
the separate high-budget review in `finish-n8-review.json`; retained formulas
and literal completions cover the intervening and dense ranges. Together with
the other completed nine- and ten-vertex families, these close every finite
exception. The final main-cell values are $M(9,20)=37$, $M(9,21)=39$,
$M(9,22)=40$, $M(9,23)=44$, and
$(M(10,22),M(10,23),M(10,24),M(10,25))=(60,61,61,65)$.
The complete finite tables identify their matching graph records; the approved
small-case registry pins their separate exclusions and independent reviews.

# Complete tables through eleven vertices {#complete-tables-through-eleven-vertices}

These tables and interval rules determine $M(n,m)$ for every admissible pair with $1\le n\le11$. An em dash means $m>n(n-1)$, so no such loopless graph exists. At every order, $M(n,m)=0$ for $m>n(n-2)$; this rule covers any final budgets omitted below.

## Orders one through seven

The three blocks list budgets zero through thirty-five. Together with the zero-tail rule, they cover every admissible budget at these orders.

| $n\backslash m$ | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 0 | — | — | — | — | — | — | — | — | — | — | — |
| 2 | 0 | 0 | 0 | — | — | — | — | — | — | — | — | — |
| 3 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | — | — | — | — | — |
| 4 | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| 5 | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 2 | 4 | 3 | 3 | 3 |
| 6 | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 2 | 4 | 5 | 6 | 7 |
| 7 | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 2 | 4 | 5 | 6 | 8 |

| $n\backslash m$ | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | — | — | — | — | — | — | — | — | — | — | — | — |
| 2 | — | — | — | — | — | — | — | — | — | — | — | — |
| 3 | — | — | — | — | — | — | — | — | — | — | — | — |
| 4 | 0 | — | — | — | — | — | — | — | — | — | — | — |
| 5 | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 | — | — | — |
| 6 | 7 | 6 | 7 | 6 | 6 | 6 | 6 | 4 | 4 | 4 | 4 | 3 |
| 7 | 9 | 10 | 10 | 11 | 12 | 12 | 14 | 15 | 18 | 21 | 14 | 12 |

| $n\backslash m$ | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34 | 35 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | — | — | — | — | — | — | — | — | — | — | — | — |
| 2 | — | — | — | — | — | — | — | — | — | — | — | — |
| 3 | — | — | — | — | — | — | — | — | — | — | — | — |
| 4 | — | — | — | — | — | — | — | — | — | — | — | — |
| 5 | — | — | — | — | — | — | — | — | — | — | — | — |
| 6 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | — | — | — | — | — |
| 7 | 12 | 11 | 10 | 10 | 9 | 8 | 8 | 7 | 6 | 5 | 4 | 2 |

## Orders eight through eleven: the low budgets

The next two blocks list budgets zero through twenty-three. Budget twenty-four appears with the interval data immediately afterward.

| $n\backslash m$ | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 8 | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 2 | 4 | 5 | 6 | 8 |
| 9 | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 2 | 4 | 5 | 6 | 8 |
| 10 | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 2 | 4 | 5 | 6 | 8 |
| 11 | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 2 | 4 | 5 | 6 | 8 |

| $n\backslash m$ | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 8 | 9 | 11 | 13 | 15 | 19 | 19 | 21 | 22 | 24 | 25 | 28 | 29 |
| 9 | 9 | 11 | 13 | 15 | 19 | 24 | 33 | 35 | 37 | 39 | 40 | 44 |
| 10 | 9 | 11 | 13 | 15 | 19 | 28 | 33 | 38 | 53 | 56 | 60 | 61 |
| 11 | 9 | 11 | 13 | 15 | 19 | 28 | 33 | 40 | 53 | 58 | 79 | 78 |

| $n$ | $M(n,24)$ | Interval of budgets $m$ | Value on that interval |
| --- | --- | --- | --- |
| 8 | 32 | $24\le m\le34$ | $56-m$ |
| 9 | 48 | $24\le m\le54$ | $72-m$ |
| 10 | 61 | $25\le m\le70$ | $90-m$ |
| 11 | 79 | $25\le m\le88$ | $110-m$ |

## The remaining eight-vertex middle budgets

| $n\backslash m$ | 35 | 36 | 37 | 38 | 39 | 40 |
| --- | --- | --- | --- | --- | --- | --- |
| 8 | 19 | 18 | 16 | 15 | 14 | 12 |

## The small dense tails

Put $m=n(n-3)+r$. The entries below give $M(n,m)$; the preceding intervals already include $r=0$ at orders nine and ten, and the eight-vertex endpoint $m=40$ appears above.

| $n\backslash r$ | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 8 | 11 | 10 | 9 | 8 | 7 | 6 | 4 | 3 | 0 | 0 |
| 9 | 14 | 12 | 11 | 10 | 9 | 8 | 6 | 5 | 3 | 0 |
| 10 | 16 | 15 | 14 | 12 | 11 | 10 | 8 | 7 | 5 | 4 |

At order eleven the uniform staircase applies throughout the remaining nonzero tail. For $m=88+r$ and $1\le r\le11$,

$$M(11,88+r)=21-r-\lceil r/2\rceil.$$

For $100\le m\le110$, the value is zero.

## The uniform classification from twelve vertices

Every entry of the small-arrow table below has an explicit attainer on at most twelve vertices. Consequently it equals $M(n,m)$ for every $n\ge12$ at that budget, as well as the unrestricted-host maximum $M_E(m)$.

| $m$ | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $M_E(m)$ | 0 | 0 | 0 | 0 | 1 | 1 | 2 | 2 | 4 | 5 | 6 | 8 |

| $m$ | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| $M_E(m)$ | 9 | 11 | 13 | 15 | 19 | 28 | 33 | 40 | 53 | 60 | 79 | 83 |

For $n\ge12$ and $m\ge24$, put $L=n(n-1)$, $k=\lfloor m/2\rfloor$ and, in the dense band, $r=m-n(n-3)$. Then

$$
M(n,m)=\begin{cases}
k(k-3)+2(m\bmod2),&24\le m\le2n,\\
L-m,&2n<m\le n(n-3),\\
2n-r-\lceil r/2\rceil-1,&n(n-3)<m\le n(n-2),\\
0,&n(n-2)<m\le L.
\end{cases}
$$

The sparse formulas have fitting even- and odd-budget cores: $k\le n$ in the even case and $k+1\le n$ in the odd case. The complete main-interval theorem and the staircase theorem from order eleven cover the next two bands. The small-arrow attainers extend by isolated vertices. Conversely, removing isolated vertices leaves at most $2m\le46$ vertices when $1\le m\le23$, so the finite ledger and isolate invariance also establish the unrestricted-host upper bounds in the small-arrow table. At $m=0$ every graph has value zero.

## Provenance and attainment

The values are generated from the complete classification ledger, `publication/classification-coverage.json`, by `src/finite_value_tables.py`, using an independent affine-segment decoder. The generator refuses unresolved cells, checks that the displayed tables and intervals cover all 451 admissible cells through order eleven, and checks the uniform formulas against every stored order from twelve onward. It also requires a fresh explicit-construction audit, `research/explicit-construction-coverage.json`, with zero known-value construction gaps. These paths identify files in the downloadable research-source archive.

The infinite statement uses the ordinary sparse constructions in `paper/sparse-all-orders.md`, the complete main interval in `paper/main-interval-complete.md`, the dense staircase in `paper/dense-third.md`, and the zero regime. The finite exclusions retain their individual source reviews and complete literal winning/losing rank checks in the small-case registry, `research/small-case-results.json`. This table readback adds no graph search and makes no new Lean claim.

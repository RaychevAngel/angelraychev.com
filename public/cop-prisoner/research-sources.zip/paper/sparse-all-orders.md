# Sparse endpoint attainment at every order from twelve

A second periodic construction admits controlled removal of vertices. Unlike a finite modification checked at one circumference, the removal is certified in a fixed local game that applies at every translated position. Separating the removals then provides all residue classes of the vertex count.

**Theorem 40 (with finite certificates).** For every integer $n\ge12$, there is an explicit two-in/two-out-regular universally winning digraph on $n$ vertices. Consequently
$$M_V(n)=M_E(2n)=M(n,2n)=n(n-3).$$
Every source–recipient pair in the construction can be guaranteed within $9\lceil n/6\rceil+18$ messenger moves.

**Proof.** First construct a uniform family for $n\ge85$. Begin with $k$ columns, indexed modulo $k$, containing vertices $(i,j)$ of types $0\le j\le5$. One permutation follows the Hamilton cycle
$$0_i\to1_i\to2_i\to3_i\to4_i\to5_i\to0_{i+1}.$$
The other permutation has arcs
$$
\begin{array}{lll}
0_i\to5_i,&1_i\to4_{i+1},&2_i\to1_{i+1},\\
3_i\to0_{i-1},&4_i\to2_{i+1},&5_i\to3_{i-1}.
\end{array}
$$
Choose columns $S$ whose consecutive cyclic gaps are at least three. At each $h\in S$, remove $4_h$ and smooth its path separately in the two permutations:
$$
3_h\to4_h\to5_h\quad\longmapsto\quad3_h\to5_h,
$$
$$
1_{h-1}\to4_h\to2_{h+1}\quad\longmapsto\quad1_{h-1}\to2_{h+1}.
$$
All remaining arcs stay unchanged. The resulting graph has $6k-|S|$ vertices. Smoothing preserves each permutation's bijectivity. There are no loops or coincident outgoing arcs: the modified first-permutation arc leaves type three for type five, while its other arc ends at type zero; the modified second-permutation arc leaves type one for type two two columns ahead, while its first-permutation arc ends at type two in the same column. Thus the graph remains simple and two-in/two-out regular.

![Remove one type-four vertex and reconnect each color separately. All undisplayed arcs stay unchanged. Spaced removals give every residue class of the total number of vertices; the local certificates prove that delivery remains possible.](figures/six-type-removal.pdf)

We establish a uniform strategy when $k\ge15$. Around an arbitrary reference column zero, restrict the messenger to columns $[-4,4]$ and represent the pursuer in columns $[-6,6]$, together with a state $\Omega$ for all outside positions. Retain both players' waits and graph arcs. Messenger moves leaving its window are disallowed; pursuer moves leaving its window lead to $\Omega$. From $\Omega$ allow waiting and entry at any existing vertex in columns $-6,-5,5,6$.

The removals inside the represented pursuer window form a subset of $\{-6,\ldots,6\}$ with consecutive gaps at least three. There are exactly 189 such subsets. For every one of these patterns, the following finite local claims have complete rank certificates:

| Objective | Initial messenger column | Maximum messenger moves |
|:--|--:|--:|
| Reach column zero safely at the start of a messenger turn | $-1$ | $9$ |
| Deliver to any specified existing vertex in column zero | $-2$ | $27$ |

Each claim covers every existing initial messenger type and every noncolliding initial pursuer position, including $\Omega$. Safe-transfer goals are seeded only at messenger turns, after the preceding pursuer response. Delivery goals instead use immediate receipt before collision. There are 1,287 certificates: seven objectives for each of the 189 patterns, with delivery to $4_0$ omitted in the 36 patterns where that vertex is removed. An independent explicit alternating-state implementation verifies all 560,885 required initial states and all 10,271,740 states of these finite games, including winning rank descent and losing-region closure.

The window-projection lemma applies with $M=4$, $R=6$, $J=2$ and $k\ge15$. It remains to check that selecting a crop neither removes an actual pursuer move nor supplies an illegal messenger move.

A removal outside the represented window does not change any represented-to-represented arc. The only change to an outward arc occurs when removing $4_7$ redirects $1_6\to4_7$ to $1_6\to2_8$; both heads represent $\Omega$. Outside-to-inside changes are already included among its permitted boundary entries. At the messenger boundary, any analogous changed outgoing arc still leaves the allowed messenger window. The local model therefore depends only on the removals inside the pursuer window. Their consecutive gaps are at least three, so it always has one of the 189 certified patterns.

All existing messenger types are covered by each certified crop. Transfers advance one column, and delivery starts two columns before the recipient. Cyclic strategy composition with $L=d=1$, $\tau=9$ and $D=27$ therefore gives
$$9(k-1)+27=9k+18.$$
This proves universal winning for every permitted set $S$.

Finally, given $n\ge85$, put $k=\lceil n/6\rceil$ and $r=6k-n$. Then $k\ge15$ and $0\le r\le5$. Choose
$$S=\{0,3,\ldots,3(r-1)\}$$
when $r>0$, and take $S$ empty when $r=0$. The displayed gaps are three, and the wraparound gap is at least $15-12=3$. The graph has exactly $n$ vertices and $2n$ arcs. Universal winning gives $I=n(n-1)-2n=n(n-3)$, and the vertex and even arc-budget upper bounds give the three stated equalities for $n\ge85$.

The complete primary certificates and their direct checker are `research/sparse-composition-multi-certificates.json.gz` and `src/sparse_composition_multi_certificate.py`. The independently written verifier uses direct arc formulas and an explicit alternating graph: `src/six_type_independent_spacing.py`, with full ranks in `research/six-type-independent-spacing-3-certificates.json.gz` and a summary in `research/six-type-independent-spacing-3-summary.json`. The graph definition, spacing argument and simulation are ordinary proofs; the two bounded local claims depend on the finite certificates. No Lean formalization of this theorem is asserted.

For completeness, the finite range $12\le n\le84$ is supplied by 73 explicit graphs. Each graph has $2n$ distinct nonloop arcs and both incoming and outgoing degrees two. Two independent exact game algorithms agree, and every actual-game rank obligation is checked for every recipient and every allowed initial pursuer. The finite witnesses also satisfy the displayed delivery-time bound. Their arc lists are in `research/sparse-finite-bridge-witnesses.json`, the complete ranks in `research/sparse-finite-bridge-certificates.jsonl.gz`, and the verification receipt in `research/sparse-finite-bridge-verification.json`. The unified generator `src/sparse_finite_bridge_construct.py` returns the corresponding finite witness below 85 and the uniform construction above it. This proves the remaining finite cases of the theorem. $\square$

Together with the complete small-order tables, this settles the vertex maximum at every order. The separate Theorem 45 addresses the odd arc-budget bound. Both its finite bridge and uniform local certificates remain outside the current Lean coverage.

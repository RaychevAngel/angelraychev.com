# The full-vertex specialization

**Proposition 51.** Put $L=n(n-1)$ and $p=m/L$, where $0<m<L$.
If
$$(n-3)p^2(1-p)>4\log n+\log(8/3),$$
there is a deterministic algorithm, polynomial in $n$, constructing
an $n$-vertex graph with exactly $m$ arcs in which every pair is
guaranteed within two messenger moves.

**Proof.** Take $H=V$, $b=n$, and $a=m$ in Theorem 54. The condition
forces $n\ge4$. That theorem proves the stronger statement with a
specified routing set, exact incident budget, arbitrary exterior
arrows, and a random-sampling probability bound. $\square$

The former full-vertex conditioning argument and its $1800$ overlap
are retained in the research history. The counting proof now appears
once in Theorem 54, and Theorem 44 gives the improved $115$ overlap.

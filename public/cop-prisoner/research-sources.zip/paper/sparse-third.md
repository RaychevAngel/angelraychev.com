# Stronger support bounds and the last small even endpoint

The shared deletion and positive-support argument also preserves the stronger
support results. Complete finite regular-core exclusions then supply the
remaining twenty-two-arrow case. The exact smaller budgets are proved in
the finite sparse-budget section before they are used here.

## Two stronger support consequences

**Proposition (strict improvement of the even support cutoff).**
For $k\ge7$, a graph with $2k$ arrows either has a two-in/two-out-regular
nonisolated support of order $k$, or
$$I(G)\le U:=k^2-4k+2.$$

**Proof.** Positive supports are covered by (56.5) and the missing-pair
count. For an actual source or sink of other degree one, deletion gives
$I\le A_{2k-1}\le k^2-5k+6<U$. Other degree at least three gives
$$I\le A_{2k-3}+k-2\le k^2-6k+10<U.$$
For degree two, write $H$ for the deleted graph. The general cap is
$(k-1)(k-3)=U+1$. A score above $U$ must attain this integer cap,
so $I(H)=(k-1)(k-4)$ and the deleted row or column contributes $k-1$.
The even equality statement makes $H$ a regular $(k-1)$-vertex core
plus isolates. A live deleted row needs two nonsink successors; a live
deleted column needs two positive-indegree predecessors. Both neighbors
must therefore be in that core. The two direct pairs leave at most
$k-3$ possible additions, a contradiction. $\square$

**Proposition (original-graph support reduction).** For $k\ge7$, a graph
with $2k$ arrows and $I(G)>V:=k^2-5k+8$ has exactly $k$ nonisolated
vertices, whose degrees need not all be two. Consequently
$$M_E(2k)\le\max\{M(k,2k),k^2-5k+8\}.$$

**Proof.** Positive supports other than $k$ are excluded by (56.5) and
the missing-pair count. Source/sink degrees one or at least three give
the same bounds as above, both below $V$. For other degree two,
$$I(H)\ge I(G)-(k-1)>k^2-6k+9>(k-2)(k-4).$$
Theorem 56 at parameter $k-1$ forces $H$ to have a regular
$(k-1)$-vertex core plus isolates. The deleted row or column must be
live, since otherwise $I(G)\le I(H)\le(k-1)(k-4)<V$. Its two
neighbors therefore lie in the core, as in the preceding proof.
Adjoining the deleted vertex gives exactly $k$ nonisolated vertices
in the original graph. $\square$

At twenty-two arrows, any graph beating74 already fits on eleven
vertices. These implications concern the original graph, not a claim that
arbitrary arrow deletion or contraction preserves delivery. Their earlier
numerical consequences $M_E(14)\le22$ and $M_E(16)\le32$ follow using
$M_V(7)=21,M_V(8)=32$; the finite-budget theorem gives the sharper exact
values 13 and 19.

## Regular cores and their finite exclusions

**Lemma (two-row loss).** In an $N$-vertex two-in/two-out-regular graph,
a source camping obstruction forces at least $2(N-3)$ missing pairs to fail.

**Proof.** Suppose $s\ne c$ and $N^+(s)\subseteq\{c\}\cup N^+(c)$.
If $c\notin N^+(s)$, the two outgoing pairs are equal, and both rows
$s,c$ are zero. Otherwise write $N^+(s)=\{c,x\}$. The arrow $c\to x$
makes $N^-(x)=\{s,c\}$, so row $s$ and column $x$ are both zero by
camping. Their intersection is the direct pair $(s,x)$, so their
$N-3$ missing pairs are disjoint. $\square$

Without source camping, every predecessor-camping cop is outside the
recipient's predecessor set. Otherwise, if $N^-(t)=\{c,x\}$ and $c\to x$,
the row $c$ is covered by the closed neighborhood of $x$, a source
obstruction. Two cops camping the same recipient would have identical
outgoing pairs and likewise create source camping. Thus distinct
predecessor-camping pairs have distinct recipients, and two such pairs
destroy at least $2(N-4)$ missing pairs.

The complete retained finite exclusions for zero or exactly one such pair
give the following bounds. All degrees in this table are two.

| $N$ | Maximum with no camping | Maximum with exactly one predecessor-camping pair | Bound with at least two pairs | Resulting bound |
|---|---:|---:|---:|---:|
| 9 | 30 | 24 | 44 | 44 |
| 10 | 38 | 45 | 58 | 58 |
| 11 | 66 | 71 | 74 | 74 |

Source camping gives the smaller bound $N(N-3)-2(N-3)$. This proves,
in particular, the retained eleven-vertex regular-core upper 74.
The exactly-one-pair enumerations evaluate 1,567,20,658,484,471 leaves
at the three orders, without time or target termination. The eleven-vertex
run covers all 14 derangement cycle types of one permutation factor,
with 7,016,903 partial nodes; an independent scalar solver agrees on482
selected leaves, including every successive maximizing witness.
The source and coverage review and replay are retained in
`research/sparse-third-audit.md` and `research/sparse-third-enumeration.json`.
They are complete source-reviewed exclusions, not second full graph
enumerations or Lean proofs.

A further complete ten-vertex regular enumeration sharpens58 to53.
It covers 12 first-factor cycle types,5,652,419 partial nodes and 289,163
actual-game evaluations. The retained literal attains53. The factorization,
coverage and threshold-dependent camping review is
`research/small-plateau-regular-family-review.md`.
The separate incoming and outgoing single-transfer families on ten vertices
also have upper 53, with complete receipts
`research/small-sparse-transfer-in10-threshold53.json` and
`research/small-sparse-transfer-out10-threshold53.json`.
These three family results are premises of the finite twenty-arrow proof,
independent of its conclusion.

For reference, the more restrictive eligible-camping-free directional
transfer families retain their sharper finite maxima:

| Order | One outgoing degree1 and one outgoing degree3 | One incoming degree1 and one incoming degree3 |
|---|---:|---:|
| 9 | 13 | 29 |
| 10 | 32 | 50 |

All other corresponding degrees, and every degree in the opposite direction,
are two. Hall's condition follows directly from these degree patterns:
source sets emit at least $2|S|-1$ arrows against recipient capacity two,
or at least $2|S|$ against capacity at most $2|T|+1$.
A perfect matching can therefore be normalized by cycle type; the high-degree
vertex uses one representative of each distinct cycle length and the
low-degree vertex is unrestricted. Incoming and outgoing families are
evaluated separately. The complete scopes and audits remain in the
sparse-third-transfer-* evidence. None of the directional statements
assumes graph-reversal invariance.

## Exact attainment at twenty-two arrows

**Theorem (the twenty-two-arrow maximum).** For every $n\ge11$,
$$M(n,22)=M_E(22)=79.$$

**Proof.** The preceding exact budgets give
$D_{22}=\max(A_{21},A_{20}+10)=63$. Positive support at least twelve
has bound 74 from (56.4); support at most ten has at most 68 missing
pairs. At support eleven, a coordinate below eleven gives
$$B_{22}(11,10,11)=79,$$
with all smaller coordinates bounded as in the arithmetic lemma.
If $q=r=11$, every degree is two and the retained regular-core upper 74
applies. This proves the global upper 79 without either stronger support
proposition being a premise.

For attainment, take vertices $0,\ldots,10$ with outgoing pairs
$$(1,8),\ (2,5),\ (0,10),\ (0,4),\ (5,7),\ (0,6),\
(7,9),\ (2,8),\ (4,9),\ (1,10),\ (3,6).$$
Every outdegree is two; vertex 0 has indegree three, vertex 3 indegree one,
and all other indegrees two. The saved full certificate verifies 79
guaranteed indirect pairs. Both independent solvers agree, and the literal
verifier checks every winning and losing condition at all 2,662 alternating
states across the eleven recipients. The adjacency and ranks are in
`research/sparse-third-one-transfer-in-certificate.json`.
Adding isolates supplies every larger host. $\square$

The lower bound uses this literal graph, not completeness of its discovery
search. The upper uses the ordinary kernel and the retained regular-core
exclusions. `SparseWitness11.lean` separately verifies an attaining
eleven-vertex, twenty-two-arrow graph of exact score 79; the unrestricted
twenty-two-arrow upper bound remains outside Lean.

## Additional outside-vertex bounds

**Lemma (outside-vertex refinement).** Put
$$\begin{gathered}
A=\{v:d^+(v)\ge2\},\qquad B=\{v:d^-(v)\ge2\},\\
q=|A|,\quad r=|B|,\quad b=|A\cap B|,\quad a=m-2q,\quad d=m-2r.
\end{gathered}$$
Let $Z$ be the nonisolated vertices outside $A\cup B$, and write
$$z=|Z|,\qquad o=\sum_{v\in Z}d^+(v),\qquad
i=\sum_{v\in Z}d^-(v).$$
Then $0\le o\le a$, $0\le i\le d$, and
$\max(o,i)\le z\le o+i$. The nonisolated support is $q+r-b+z$.
If $R,C$ count the source rows and recipient columns containing at least
one guaranteed indirect pair, then
$$R\le\min\{q,b+a+\lfloor(d-o-z)/2\rfloor\},$$
$$C\le\min\{r,b+d+\lfloor(a-i-z)/2\rfloor\}.$$
Moreover,
$$I\le qr-b-\max\{0,m-\min(a,r-b+o)-\min(d,q-b+i)\},$$
and
$$I\le RC-\max\{0,R+C-q-r+b\}-\max\{0,2R+2C-m\}.$$

**Proof.** Every vertex of $Z$ has indegree and outdegree at most one,
with positive sum, proving the elementary constraints and support count.
Let $x=\sum_{v\in B}(d^-(v)-2)$. Exactly $d-x$ arrows end outside $B$,
of which exactly $i$ end in $Z$. Thus exactly $q-b-d+x+i$ vertices of
$A\setminus B$ have indegree zero; they emit at least twice that many
arrows. The $z-i$ indegree-zero vertices in $Z$ each emit one further
arrow. At most $d-x$ of these arrows end outside $B$, and recipients of
indegree at least three receive at most $3x$ arrows in total. Consequently
at least $\max(0,2q-2b-3d+i+z)$ selected arrows enter indegree-two
recipients. Dividing by their capacity two gives that many distinct
zero columns after taking the ceiling. Such a recipient has an
inaccessible predecessor; a cop waits at its other predecessor. The
cop-source exception is a direct pair and is not counted. Rearranging,
using the common parity of $a,d$, gives the displayed column bound.

For the row bound, use sinks in the original directions. If
$y=\sum_{v\in A}(d^+(v)-2)$, exactly $r-b-a+y+o$ members of
$B\setminus A$ are sinks, and $z-o$ further sinks in $Z$ each receive
one arrow. At most $a-y+3y$ of these incoming arrows can avoid
outdegree-two predecessors. Thus at least
$\max(0,2r-2b-3a+o+z)$ arrows come from degree-two sources with a
sink successor. Each such source has a zero indirect row, since the cop
waits at its other successor. Dividing by two and rearranging proves the
row bound; no reversal invariance of the game is used.

Total outdegree outside $A$ is at most $\min(a,r-b+o)$, and total
indegree outside $B$ is at most $\min(d,q-b+i)$. Subtracting both
from $m$ bounds the arrows in $A\times B$ from below. Its $b$ diagonal
pairs are disjoint from these arrows, giving the first pair bound.
The live row and column sets intersect in at least
$\max(0,R+C-q-r+b)$ vertices. Their total outgoing and incoming degrees
are at least $2R$ and $2C$, forcing at least $\max(0,2R+2C-m)$ direct
pairs in their rectangle. Removing these arrows and diagonals gives the
second bound. $\square$

Dropping the outside-vertex subtractions also gives the simpler bounds
$$R\le\min(q,b+a+\lfloor d/2\rfloor),\qquad
C\le\min(r,b+\lfloor a/2\rfloor+d).$$
The full integer constraints imply that a 20-arrow graph with $I>50$
has at most 13 nonisolated vertices, and an 18-arrow graph with $I>30$
has at most 15. The independent replay retains respectively 22 and 67
triples $(q,r,b)$, not that many graphs or degree sequences. Its source
and complete arithmetic receipt are
`research/small-case-support-review-2026-09-13.py` and the adjacent JSON.
These support bounds do not assert that deleting exceptional vertices
preserves a strategy.


## Consequences for the earlier small-budget comparisons

The exact finite-budget theorem gives $M_E(18)=33$ and $M_E(20)=53$.
It therefore preserves the earlier intermediate conclusions
$M_E(18)\le44$, $M_E(20)\le58$, and $53\le M_E(20)\le57$ without
their former separate optimization arguments. The regular and directional
family exclusions used in the final proof were stated independently above.

**Proposition (comparison host for twenty arrows).** For every $n\ge11$,
$$M(n,20)=M(11,20)=53.$$
Every twenty-arrow graph has an explicit eleven-vertex twenty-arrow
comparison graph with at least as many guarantees.

**Proof.** Pad the retained ten-vertex score 53 literal with one isolate.
The finite-budget theorem bounds every original graph by 53. Further
isolate padding proves the assertion for every larger host. $\square$

The historical stronger task of modifying a hypothetical larger-support
improvement remains documented in `research/small-sparse-twenty-host-compression.md`
and its independent review. It is no longer a dependency of the exact
classification. Its frozen evidence and the earlier intermediate exclusions
are preserved unchanged.

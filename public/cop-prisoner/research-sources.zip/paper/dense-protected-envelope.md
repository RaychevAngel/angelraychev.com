# A quadratic dense interval from three safe intermediaries

The sparse missing graph need not retain large girth while its density
increases. Three designated outgoing missing arcs per vertex suffice,
provided certain differences between their endpoints stay protected.
The resulting construction covers a quadratic interval of missing-arc
counts by a direct modular rule.

**Theorem 48.** For every integer $n\ge19$, put
$$K(n)=\max\left\{3,\left\lceil\frac{n-1}{13}\right\rceil\right\}.$$
At every integer missing-arc count $3n\le h\le nK(n)$, an explicit
graph attains
$$M(n,n(n-1)-h)=h.$$
Every source--recipient pair in the construction is guaranteed within
two messenger moves. Arbitrary intermediate subsets of the specified
optional missing arcs are permitted.

**Proof.** Work in $\mathbb Z/n\mathbb Z$, and put
$$S=\{1,3,7\},\qquad D=\{\pm2,\pm4,\pm6\},
\qquad E=\{\pm3,\pm5,\pm9\}.$$
We shall construct a set $A$ containing $S$, not containing zero, with
the following properties:

1. Each difference in $D$ has exactly its original ordered
   representation between two members of $S$, and no other ordered
   representation between members of $A$.
2. No difference between two members of $A$ belongs to $E$.

For $n\ge19$, these properties hold for $A=S$: its six ordered nonzero
differences are precisely the six distinct members of $D$, and none
belongs to $E$.

Whenever $|A|=k$, adjoin any residue outside
$$\{0\}\cup A\cup(A+D)\cup(A+E).$$
The exclusion of $A+D$ preserves all protected representations, and
the exclusion of $A+E$ preserves the second property; both difference
sets are symmetric. At most $13k+1$ residues are excluded. If
$k<\lceil(n-1)/13\rceil$, this quantity is strictly less than $n$,
so the process continues. Starting with three members, it produces
$|A|=K(n)$; choosing the smallest permissible representative makes
the rule deterministic.

Let $F$ be any loopless digraph satisfying
$$\{(x,x+d):x\in\mathbb Z/n\mathbb Z, d\in S\}
\subseteq E(F)\subseteq
\{(x,x+d):x\in\mathbb Z/n\mathbb Z, d\in A\}.$$
Let $G$ be its directed complement. We prove all missing pairs of
$G$ have safe two-move intermediaries, using only the three designated
missing neighbors of each initial pursuer position.

Fix a missing pair $(s,t)$ and initial pursuer position $c\ne s$.
Translate so $s=0$, and write $a=t-s\in A$ and $z=c-s\ne0$.
The three candidates are the members of $z+S$. A candidate is suitable
if it lies outside
$$A\cup(a-A).$$
Indeed, this ensures both messenger arcs are present in $G$, while
the candidate is a missing outgoing neighbor of $c$ and therefore
cannot be reached on the pursuer's response.

At most one candidate belongs to $A$. Otherwise, for distinct
$u,v\in S$, the difference of $z+u,z+v\in A$ is the protected
difference $u-v$. Its unique representation forces $z+u=u$ and
$z+v=v$, contrary to $z\ne0$.

At most two candidates belong to $a-A$. If the candidates with steps
$u,v$ belong there, the two elements $a-z-u,a-z-v$ of $A$ have
protected difference $v-u$. Its unique representation is $(v,u)$,
so
$$a-z=u+v.$$
If the third candidate, with step $w$, also belonged to $a-A$, the
same argument applied to $u,w$ would give $a-z=u+w$, a contradiction.

If all three candidates were blocked, the remaining candidate $z+w$
would have to belong to $A$, while the other two are in $a-A$.
Setting $b=z+w\in A$, the displayed equality gives
$$b-a=w-u-v.$$
As $w$ runs over $1,3,7$ and $u,v$ are the other two steps, this
difference is respectively $-9,-5,3$. Each belongs to $E$, contradicting
the second property of $A$. Hence a suitable candidate exists.

The suitable candidate differs from $c$ because $0\notin S$. It
differs from both endpoints: $a\in A$ and $0\in a-A$. Thus the
messenger first moves to it, survives every response, and then reaches
$t$; receipt precedes any subsequent interception. This argument uses
only the envelope containments, so no translation symmetry of the
chosen intermediate $F$ is needed.

The compulsory missing graph has $3n$ arcs and the full envelope has
$nK(n)$ arcs. Adding any chosen number of optional missing arcs gives
each integer $h$ in this interval, with all $h$ missing pairs
guaranteed. The missing-pair upper bound proves equality. $\square$

Theorem 58 now subsumes this entire numerical range, including the orders
19 through 21, while preserving two-move delivery and every optional subset.
The proof above is retained as a distinct sufficient condition on arbitrary
protected difference sets. The main numerical catalogue therefore no longer
counts this as an additional dense interval.

The executable construction and bounded checks are in
`src/dense_protected_envelope.py`; their exact finite scope is recorded
in `research/dense-protected-envelope-checks.json`. The ordinary theorem is
independent of those finite pursuit-game checks. No new Lean coverage is
asserted.

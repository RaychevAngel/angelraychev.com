# Exact-budget consequences of protected routing

The full-vertex random and deterministic constructions are specializations
of the protected-routing theorem. Their common counting proof is Theorem 54.

**Theorem 43.** Put $L=n(n-1)$ and $p=m/L$. Under the hypotheses of
Theorem 25, there is a deterministic algorithm, polynomial in $n$,
constructing an $n$-vertex, exactly $m$-arc graph in which every pair
is guaranteed within two messenger moves.

**Proof.** Set $H=V$, $b=n$, and $a=m$ in Theorem 54.
The condition $(n-3)p^2(1-p)>5\log n$ implies the required condition
because $\log n>\log(8/3)$ for $n\ge4$. The restricted completion
counts become exactly the full-vertex counts. $\square$

The algorithm's polynomial bound does not imply a small practical
runtime. `src/exact_budget_derandomize.py` retains the earlier
full-vertex implementation and small exhaustive checks;
`src/routing_unification.py` generalizes those counts to a specified
routing set. Neither receipt claims execution on a large asymptotic
instance.

## An explicit threshold for the entire main interval

**Theorem 44.** For every integer $n\ge106$ and every integer
$$2n\le m\le n(n-3),$$
an explicit polynomial-time construction produces a graph with exactly $n$
vertices and $m$ arcs in which every pair is guaranteed. Consequently
$M(n,m)=n(n-1)-m$ throughout this interval.

**Proof.** First let $106\le n\le114$. The finite cyclic supplement to
Theorem 52 covers every budget $2n\le m\le3n$, using the two specified
restored optional arrows at order 109. The literal protected-circle envelopes
at these nine orders have maximum budget at least $37n-400$. With $k=10$
and code weight three, Theorem 59 supplies 100 codes, more than the required
$q=n-20$, and its interval is
$$37n-400\le m\le n(n-1)-(3n-20).$$
Its upper endpoint overlaps the two-move dense bridge
$n(n-1)-3n\le m\le n(n-3)$. Thus the sparse, circle, code and dense
intervals cover every budget at these nine orders. The explicit circle lists
are recorded in `research/core-code-third-circle-envelopes.json` for 106 through 111
and in `research/core-code-circle-overlap-screen.json` for 112 through 114.
Their six protected differences and all integer overlaps are independently
checked in `research/sparse-interface-third-cross-lane-review.json`.
The executable adjacency recipe is `src/main_interval_composed.py`.
Its finite extension is checked against the sparse certificate graphs,
the circle conditions and the full code/dense witness conditions in
`research/main-interval-composed-third-checks.json`; the earlier outputs
at the listed regression orders are unchanged.

For $n\ge115$, Theorem 52 covers $2n\le m\le3n$.
The separated-pair overlap theorem following Theorem 59 covers
$3n\le m\le n(n-3)$ at every $n\ge79$, hence at each remaining order.
Together these two intervals cover every stated budget.
Each construction lists its base arrows and optional arrows; include the
prescribed number of optional arrows in lexicographic order. All relevant
lists can be constructed in polynomial time. The missing-pair bound gives
the reverse inequality. $\square$

The sufficient order threshold 106 is not asserted to be optimal. This
proof is entirely by explicit combinatorial constructions and finite local
strategy certificates. At $n\ge115$, the sparse part retains its $9\lceil n/6\rceil+21$
move bound; its finite 106--114 supplement uses at most 72 moves. These are
bounds for the sparse part; there is no uniform two-move assertion for the entire interval.
The protected-routing theorem remains independently useful because it
allows a specified routing set and a variable incident density, with an
explicit random success probability and exact-budget derandomization.

# A consecutive interval above the two-regular endpoint

The five-type construction can tolerate a controlled set of additional arcs. The proof gives the pursuer every additional move while restricting the messenger to the original moves. This verifies all intermediate graphs at once, without assuming that winning is monotone under adding arcs.

**Theorem 36 (with finite local certificates).** Let $n=5k$ with $k\ge10$. For every integer
$$2n\le m\le\frac{11n}{5},$$
there is an explicit graph with $n$ vertices and $m$ arcs satisfying
$$M(n,m)=n(n-1)-m.$$
Every pair can be guaranteed within $8k+18$ messenger moves.

**Proof.** Use the five-type graph $H_k$ of Theorem 21 on vertices $(i,j)$, where $i$ is modulo $k$ and $0\le j\le4$. Its two outgoing arcs are
$$
\begin{aligned}
\alpha(i,j)&=(i,j+1) &&(j<4),&\alpha(i,4)&=(i+1,0),\\
\beta(i,0)&=(i+1,0),&\beta(i,1)&=(i-1,2),\\
\beta(i,2)&=(i-1,4),&\beta(i,3)&=(i-1,3),&\beta(i,4)&=(i-1,1).
\end{aligned}
$$
There are $2n$ arcs. Add any chosen subset of the $k$ further arcs
$$ (i,0)\longrightarrow(i-1,4).$$
They are distinct from the original arcs and from each other, so every integer budget in the stated interval is obtained.

We verify the stronger asymmetric game in which the messenger may use only $\alpha,\beta$ and waiting, while the pursuer may also use all $k$ additional arcs. Construct the same local arena as in Theorem 21: messenger columns $-3,\ldots,3$, pursuer columns $-4,\ldots,4$, and a pursuer state $\Omega$ representing the outside. The messenger is constrained to its local columns. The pursuer may leave into $\Omega$, wait there, and re-enter at any vertex in either boundary column $-4$ or $4$. Within its columns it has the two original arcs and the additional arc above whenever its type is zero.

Two independently implemented finite attractor computations verify the following objectives against every legal initial pursuer state, including $\Omega$:

| Objective | Initial messenger column | Maximum messenger moves |
|:--|--:|--:|
| Reach column zero safely at the beginning of a messenger turn | 1 | 8 |
| Deliver to $(0,0)$ | 2 | 26 |
| Deliver to $(0,1)$ | 2 | 19 |
| Deliver to $(0,2)$ | 2 | 17 |
| Deliver to $(0,3)$ | 2 | 17 |
| Deliver to $(0,4)$ | 2 | 18 |

Each row covers all five initial messenger types and all 45 legal pursuer positions per type, for 225 required initial states. The transfer goal is seeded only at a messenger turn after the pursuer response, with unequal positions. Delivery goals use immediate receipt before collision, as required by the game. The rank checks verify every selected messenger move and every permitted pursuer response; these are complete finite certificates for the displayed statements.

For $k\ge10$, the nine represented pursuer columns are distinct on the ring. All moves, including the additional ones, change the column by at most one. Therefore an actual pursuer outside those columns can first enter only a boundary column; its behavior projects into the adversarial $\Omega$ state. The actual messenger can follow every certified original move. The local certificates consequently apply at every translated column of every such ring, independently of which additional arcs the actual graph contains.

Fix a recipient in column zero. Repeatedly translate and apply the safe-transfer certificate to move the messenger one column backward until it reaches column two. This needs at most $k-1$ transfers, each leaving a legal messenger-turn state for the next certificate. Then apply the appropriate delivery certificate. The total is at most
$$8(k-1)+26=8k+18.$$
Thus every pair is guaranteed, and all $n(n-1)-m$ missing pairs are counted. The missing-pair upper bound proves equality. $\square$

The primary generator and full ranks are `src/five_type_sparse_interval.py` and `research/five-type-sparse-interval-certificates.json`. The independent explicit alternating-state implementation is `src/five_type_augmented_verify.py`, with its full certificate in `research/five-type-augmented-independent-certificates.json`. The ring projection and concatenation are ordinary proofs; the bounded local facts depend on these finite certificates. This theorem is not presently formalized in Lean, and it makes no claim for the small rings $k=4,\ldots,9$ or for budgets beyond $11n/5$.

**Theorem 37 (with finite local certificates).** Let $n=5k$ with $k\ge16$. At every integer budget $2n\le m\le3n$, there is an explicit graph attaining
$$M(n,m)=n(n-1)-m.$$
Every pair can be guaranteed within $8k+16$ messenger moves.

**Proof.** Keep the original five-type graph, and add any subset of the $n$ arcs
$$ (i,j)\longrightarrow(i+3,0),\qquad 0\le j\le4.$$
They are pairwise distinct and are not original arcs. It suffices to win with the messenger restricted to the original graph and the pursuer allowed all the additional arcs.

Use messenger columns $[-3,3]$, pursuer columns $[-6,6]$, and the outside state $\Omega$. Give the represented pursuer its original and added moves; moves leaving the interval enter $\Omega$. From $\Omega$ permit waiting and re-entry at every vertex in the six columns $-6,-5,-4,4,5,6$. Independent synchronous and explicit alternating-state certificates verify safe transfer from column one to zero in at most eight moves, and delivery from column two to the five recipient types at zero in at most $24,16,16,17,18$ moves. Each objective covers all 325 legal initial states: five messenger types and 65 pursuer positions per type. The transfer ends on a safe messenger turn, and delivery has immediate terminal priority, exactly as in Theorem 36.

We check the larger-jump projection explicitly. The thirteen represented pursuer columns are distinct when $k\ge16$, and at least three consecutive columns lie outside them. No move, whose column displacement is at most three, can jump over that entire outside gap and land at the opposite represented boundary. Thus a represented move projects either to its represented destination or to $\Omega$. An outside pursuer can enter the represented interval only in one of the six allowed boundary columns. Every actual pursuer behavior is therefore included in the finite arena. This gap condition is why the proof uses $k\ge16$, not merely enough columns to make the represented labels distinct.

At most $k-1$ safe backward transfers reach column two relative to the recipient. The final delivery costs at most 24 further moves, giving $8(k-1)+24=8k+16$. The strategy is available in every intermediate graph, and its pursuer has no more moves than the certified adversary. Hence all pairs are guaranteed at each of the $n+1$ integer budgets. Counting missing pairs proves equality. $\square$

The full primary ranks are `research/five-type-full-sparse-interval-certificates.json`, generated by `src/five_type_sparse_interval.py`. The independent 4620-state implementation and certificate are `src/five_type_long_augmented_verify.py` and `research/five-type-long-augmented-independent-certificates.json`. The statement is a uniform theorem with a finite local proof ingredient, not an extrapolation from tested circumferences. No new Lean coverage is claimed. For orders divisible by five with $n\ge80$, Theorems 34 and 37 combine into a consecutive explicit interval starting at $2n$ and reaching order $n^{4/3}$.

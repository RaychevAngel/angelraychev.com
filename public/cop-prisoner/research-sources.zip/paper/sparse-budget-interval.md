# A consecutive interval above the two-regular endpoint

The five-type construction can tolerate a controlled set of additional arcs. The proof gives the pursuer every additional move while restricting the messenger to the original moves. This verifies all intermediate graphs at once, without assuming that winning is monotone under adding arcs.

**Theorem 36 (with finite local certificates).** Let $n=5k$ with $k\ge10$. For every integer
$$2n\le m\le\frac{11n}{5},$$
there is an explicit graph with $n$ vertices and $m$ arcs satisfying
$$M(n,m)=n(n-1)-m.$$
Every pair can be guaranteed within $8k+18$ messenger moves.

**Proof.** Use the five-type graph $H_k$ of Theorem 21 on vertices $(i,j)$, where $i$ is modulo $k$ and $0\le j\le4$. Its two outgoing arcs are
$$
\begin{aligned}
\alpha(i,j)&=(i,j+1) &&(j<4),&\alpha(i,4)&=(i+1,0),\\
\beta(i,0)&=(i+1,0),&\beta(i,1)&=(i-1,2),\\
\beta(i,2)&=(i-1,4),&\beta(i,3)&=(i-1,3),&\beta(i,4)&=(i-1,1).
\end{aligned}
$$
There are $2n$ arcs. Add any chosen subset of the $k$ further arcs
$$ (i,0)\longrightarrow(i-1,4).$$
They are distinct from the original arcs and from each other, so every integer budget in the stated interval is obtained.

We verify the stronger asymmetric game in which the messenger may use only $\alpha,\beta$ and waiting, while the pursuer may also use all $k$ additional arcs. Construct the same local arena as in Theorem 21: messenger columns $-3,\ldots,3$, pursuer columns $-4,\ldots,4$, and a pursuer state $\Omega$ representing the outside. The messenger is constrained to its local columns. The pursuer may leave into $\Omega$, wait there, and re-enter at any vertex in either boundary column $-4$ or $4$. Within its columns it has the two original arcs and the additional arc above whenever its type is zero.

Two independently implemented finite attractor computations verify the following objectives against every legal initial pursuer state, including $\Omega$:

| Objective | Initial messenger column | Maximum messenger moves |
|:--|--:|--:|
| Reach column zero safely at the beginning of a messenger turn | 1 | 8 |
| Deliver to $(0,0)$ | 2 | 26 |
| Deliver to $(0,1)$ | 2 | 19 |
| Deliver to $(0,2)$ | 2 | 17 |
| Deliver to $(0,3)$ | 2 | 17 |
| Deliver to $(0,4)$ | 2 | 18 |

Each row covers all five messenger types and all 45 legal pursuer positions per type: 225 required initial states. The complete ranks verify every selected move and every pursuer response, with the distinct handoff and receipt rules of local simulation.

The window-projection lemma applies with $M=3$, $R=4$, $J=1$ and $k\ge10$. The messenger uses only original arrows and the local pursuer receives every optional arrow, so local simulation applies to every chosen subset. Cyclic strategy composition, with backward unit transfers and delivery entry column two, gives at most
$$8(k-1)+26=8k+18.$$
Thus every pair is guaranteed, and all $n(n-1)-m$ missing pairs are counted. The missing-pair upper bound proves equality. $\square$

The primary generator and full ranks are `src/five_type_sparse_interval.py` and `research/five-type-sparse-interval-certificates.json`. The independent explicit alternating-state implementation is `src/five_type_augmented_verify.py`, with its full certificate in `research/five-type-augmented-independent-certificates.json`. The ring projection and concatenation are ordinary proofs; the bounded local facts depend on these finite certificates. This theorem is not presently formalized in Lean, and it makes no claim for the small rings $k=4,\ldots,9$ or for budgets beyond $11n/5$.

**Theorem 37 (with finite local certificates).** Let $n=5k$ with $k\ge16$. At every integer budget $2n\le m\le3n$, there is an explicit graph attaining
$$M(n,m)=n(n-1)-m.$$
Every pair can be guaranteed within $8k+16$ messenger moves.

**Proof.** Keep the original five-type graph, and add any subset of the $n$ arcs
$$ (i,j)\longrightarrow(i+3,0),\qquad 0\le j\le4.$$
They are pairwise distinct and are not original arcs. It suffices to win with the messenger restricted to the original graph and the pursuer allowed all the additional arcs.

Use messenger columns $[-3,3]$, pursuer columns $[-6,6]$, and the outside state $\Omega$. Give the represented pursuer its original and added moves; moves leaving the interval enter $\Omega$. From $\Omega$ permit waiting and re-entry at every vertex in the six columns $-6,-5,-4,4,5,6$. Independent synchronous and explicit alternating-state certificates verify safe transfer from column one to zero in at most eight moves, and delivery from column two to the five recipient types at zero in at most $24,16,16,17,18$ moves. Each objective covers all 325 legal initial states: five messenger types and 65 pursuer positions per type. The transfer ends on a safe messenger turn, and delivery has immediate terminal priority, exactly as in Theorem 36.

Now the window-projection parameters are $M=3$, $R=6$, $J=3$, requiring $k\ge2R+J+1=16$. This is the gap condition, not merely distinctness of represented columns. The original messenger moves lift literally and all optional pursuer moves are covered. Cyclic strategy composition with backward unit transfers, delivery entry column two, $\tau=8$ and $D=24$ gives $8(k-1)+24=8k+16$. Local simulation applies to every optional subset, so all pairs are guaranteed at each of the $n+1$ integer budgets. Counting missing pairs proves equality. $\square$

The full primary ranks are `research/five-type-full-sparse-interval-certificates.json`, generated by `src/five_type_sparse_interval.py`. The independent 4620-state implementation and certificate are `src/five_type_long_augmented_verify.py` and `research/five-type-long-augmented-independent-certificates.json`. The statement is a uniform theorem with a finite local proof ingredient, not an extrapolation from tested circumferences. No new Lean coverage is claimed. For orders divisible by five with $n\ge80$, Theorems 34 and 37 combine into a consecutive explicit interval starting at $2n$ and reaching order $n^{4/3}$.

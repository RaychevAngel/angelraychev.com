# A robust dense bridge

**Theorem 50.** For every $n\ge16$ and every integer $2n\le h\le3n$,
there is a deterministic $n$-vertex graph with exactly $h$ missing
arcs in which every pair is guaranteed within two messenger moves.
Consequently
$$M(n,n(n-1)-h)=h.$$

At each allowed order, one compulsory set of $2n$ missing arcs and a
list of $n$ optional missing arcs suffice: **every subset** of the
optional list preserves two-move delivery. The construction takes
polynomial time.

**Proof.** This is the robust envelope in Theorem 58. Its parameterized
modular families and four odd repairs cover every order from 22;
six further explicit optional lists cover $16,\ldots,21$.
The ordinary danger-set arguments and the finite witnesses retain a
compulsory safe intermediary against every pursuer, so any optional
subset is permitted. Selecting
$h-2n$ optional arcs gives the exact prescribed count. $\square$

Theorem 58 further enlarges this same robust dense interval to
$$2n\le h\le H(n)$$
at every $n\ge30$, where $H(n)$ is its explicit cap and
$H(n)=n^2/4-O(n)$ from the parity construction. The statement here
is its uniform initial interval, with its earlier label retained for
references. Theorem 58 gives the common constructions and proofs.
The earlier projective-incidence decomposition is no longer a separate
premise or a separate numerical result. The generic high-girth criterion
of Lemma 18 remains available for other graphs.

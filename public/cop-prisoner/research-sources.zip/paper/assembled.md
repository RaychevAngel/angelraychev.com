---
title: Guaranteed indirect delivery in directed networks
subtitle: Extremal bounds, sparse constructions, and verified finite cases
date: 12 September 2026
documentclass: article
classoption: 11pt
geometry: margin=1in
colorlinks: true
linkcolor: blue
urlcolor: blue
toc: true
toc-depth: 1
numbersections: true
---

# Introduction

A messenger has just obtained a message at a station $s$ of a directed network. A pursuer occupies another station, and both positions are visible. They move alternately, the messenger first, using one directed connection or waiting. The messenger wants to deliver to a designated recipient $t$ before interception. Receipt completes the task immediately, even if the pursuer is at $t$: the pursuer can intercept the messenger but cannot disable the recipient.

A direct connection $s\to t$ makes delivery immediate. We study the additional communication supported by the network: source--recipient pairs without a direct connection for which delivery is nevertheless guaranteed against every allowed initial pursuer position. Write $I(G)$ for their number. The three extremal quantities are

$$
M_V(n)=\max_{|V(G)|=n} I(G),\qquad
M_E(m)=\max_{|E(G)|=m} I(G),\qquad
M(n,m)=\max_{|V(G)|=n,\ |E(G)|=m} I(G).
$$

Isolated vertices are allowed. Removing them preserves $I$, so the arc-only maximum is finite: a graph with $m>0$ arcs has at most $2m$ nonisolated vertices.

The original problem and a layered subset construction arose in Alexandra Ignatova's 2023 project, mentored by Angel Raychev. A public 2023 abstract records that provenance [@ignatova2023]; the retained manuscript is dated February 2024 [@ignatova2024]. This account distinguishes that original construction from its corrected analysis and the September 2026 extensions. The full extremal classification remains open.

## Results and proof boundaries

The main general results established here are the following.

1. For $n\ge3$, $I(G)\le n(n-3)$. For $k\ge5$, the sharper arc-budget bounds are
   $$
   M_E(2k)\le k(k-3),\qquad
   M_E(2k+1)\le k(k-3)+2.
   $$
   We characterize equality in these bounds for $k\ge6$.
2. There are explicit networks with $3n$ arcs in which every pair is guaranteed for every $n\ge25$. In particular,
   $$n(n-4)\le M_V(n)\le n(n-3)\qquad(n\ge25).$$
   Thus the deficit $n^2-M_V(n)$ has linear order.
3. At the dense boundary,
   $$M(n,n(n-2))=\left\lfloor\frac{n-2}{2}\right\rfloor,$$
   and $M(n,m)=0$ for every larger admissible $m$. The minimum value of $I$ is zero at every admissible $(n,m)$.
4. A two-in/two-out-regular repeating construction attains the sparse bounds for every $k\ge4$:
   $$M_V(5k)=M_E(10k)=M(5k,10k)=5k(5k-3).$$
   A finite local certificate and a uniform projection argument prove the infinite family. Consequently $M_E(m)=m^2/4-O(m)$.
5. A noncomplete network in which every pair is guaranteed has at most $n(n-3)$ arcs. High-girth complements attain this density for every $n\ge52$:
   $$M(n,n(n-3))=2n.$$
   More generally an explicit interval of dense arc budgets attains every missing pair, as specified in Theorem 20. A separate elementary construction covers $n=5k$, $k\ge4$.
6. Independent exact solvers certify $M_V(n)=n(n-3)$ for every $12\le n\le24$, complete joint maxima through $n=6$, and equality in the odd arc-budget bound at $m=37,39,\ldots,47$. These finite theorems are additional to the infinite families above.

The general arguments are ordinary mathematical proofs. The accompanying Lean development formalizes the actual alternating game, a certificate-to-strategy theorem, safe branching, camping obstructions, and a complete universally winning 12-vertex example. It does not claim to formalize all the general extremal arguments.

# The game and its elementary structure

Let $G=(V,E)$ be a finite loopless digraph. Opposite arcs are allowed. A legal move from $x$ goes to $x$ or to an outgoing neighbor; write
$$C(x)=\{x\}\cup N^+(x).$$
Fix $s,t\in V$ and $c\ne s$. If $s=t$, receipt has already occurred. Otherwise the messenger moves first. On its turn it chooses $v\in C(s)$. If $v=t$, delivery wins immediately. If $v\ne t$ and $v=c$, it is captured. Otherwise the pursuer chooses $c'\in C(c)$; equality $c'=v$ is capture. The process repeats. Infinite play without delivery is a messenger loss.

Let $W_G(s,t)$ mean that, for every initial $c\ne s$, there exists a messenger strategy guaranteeing delivery against every pursuer strategy. The messenger observes $c$; its strategy may depend on it. Then
$$
I(G)=\#\{(s,t):s\ne t,\ (s,t)\notin E,\ W_G(s,t)\}.
$$
If $w(G)$ counts all guaranteed pairs including the diagonal, then exactly
$$w(G)=n+m+I(G).$$

The terminal rule matters. In the directed diamond $s\to a\to t$, $s\to b\to t$, the messenger chooses the intermediate vertex not occupied by the pursuer and delivers on its next turn. But reaching a vertex that would be safe as a *recipient* does not justify using it as an intermediate stop. The pursuer gets an intervening move before the message can be forwarded again.

![Two routes allow a guaranteed indirect delivery. Adding the arc from a to b lets a pursuer at a block both first moves.](figures/diamond.pdf)

## Camping obstructions

**Lemma 1 (source domination).** If $c\ne s$ and $N^+(s)\subseteq C(c)$, there is no guaranteed indirect pair with source $s$.

**Proof.** The pursuer starts at $c$ and waits while the messenger waits. Every nonterminal departure from $s$ is either an immediate collision or is captured on the following pursuer turn. Waiting forever is not delivery. $\square$

**Lemma 2 (predecessor domination).** Put $D_t=N^-(t)$. If $D_t\subseteq C(c)$, an indirect guaranteed source for $t$ must equal $c$.

**Proof.** For any other source the pursuer may start at $c$. Every indirect delivery must first enter $D_t$, where the pursuer can capture before the next messenger turn. $\square$

In particular, a source counted by $I$ has outdegree at least two, and a recipient counted by $I$ has indegree at least two. An indegree-one recipient is blocked by its unique predecessor. In an undirected network, interpreted as two opposite arcs per edge, the pursuer can start at $t$ and catch the messenger upon its first arrival at a neighbor of $t$. Thus $I=0$ for every such network.

The two degree conditions are necessary, not sufficient. Neither the absence of a one-vertex directed separator nor the existence of two internally disjoint routes characterizes this game. Adding $a\to b$ to the diamond destroys its only indirect guarantee, although both routes remain. Consequently $I$ is not monotone under adding arcs.

**Lemma 3 (two-move criterion).** For an indirect pair $(s,t)$, put $B=N^+(s)\cap N^-(t)$. Delivery is guaranteed within two messenger moves exactly when
$$\text{for every }c\ne s,\qquad B\not\subseteq C(c).$$

**Proof.** Choose an intermediate vertex of $B\setminus C(c)$, survive every pursuer response, and deliver. Conversely, any successful two-move indirect delivery must use such an intermediate. Waiting on the first move cannot reach a nonadjacent recipient on the second. $\square$

## Components, zero minima, and the vertex bound

Removing isolated vertices preserves $I$. More generally,
$$I(G\sqcup H)=I(G)+I(H).$$
There are no cross-component routes; a pursuer in the other component cannot interfere with a route in the messenger's component.

**Proposition 4.** At every admissible $(n,m)$ the minimum of $I$ is zero.

**Proof.** For $n\ge2$, list all nonloop arcs row by row and retain the first $m$. There are full outgoing rows, at most one partial row, and empty rows. Full rows have only direct recipients; empty rows cannot move. If a full row exists, its vertex blocks every indirect attempt from the partial row by Lemma 1. Otherwise successors of the partial row have no outgoing arcs, so no indirect route exists. The empty and one-vertex cases are immediate. $\square$

**Theorem 5.** For every $n\ge3$,
$$I(G)\le n(n-3).$$

**Proof.** A recipient of indegree zero or one has no indirect guaranteed sources. A recipient of indegree $d\ge2$ has at most $n-1-d\le n-3$, after excluding itself and its direct predecessors. Sum over recipients. $\square$

For $n\ge4$, equality forces every recipient to have indegree two and every missing pair to be guaranteed. Every source must then have outdegree at least two; the degree sum forces outdegree exactly two. Conversely, a two-in/two-out-regular graph with every pair guaranteed attains equality. Thus attaining the vertex bound is exactly a sparse universal-delivery construction problem.

# Sharp arc-budget upper bounds

Let $A$ be the vertices of outdegree at least two and $B$ those of indegree at least two. Write $q=|A|$, $r=|B|$, $b=|A\cap B|$, and let $e(A,B)$ count arcs from $A$ to $B$. Every counted pair belongs to $A\times B$, and direct and diagonal pairs are excluded. Hence
$$
I(G)\le qr-b-e(A,B),\qquad
e(A,B)\ge\max\{0,2q+2r-m\}. \tag{1}
$$
The second inequality follows by adding the total outgoing degree in $A$ and incoming degree in $B$: each arc is counted at most once except those in $A\times B$.

We also need two elementary obstructions. If $x$ has indegree zero and $x\to t$ with $t$ of indegree two, then $t$ has no indirect guaranteed sources. Its other predecessor blocks every indirect route: a route from elsewhere cannot reach $x$, while $x\to t$ itself is direct. Dually, if $t$ is a sink, $x\to t$, and $x$ has outdegree two, then $x$ has no indirect guaranteed recipients. Its other successor blocks every potentially successful indirect departure. This dual argument is proved directly and does not assume invariance under reversing the graph.

## Even numbers of arcs

**Theorem 6.** If $m=2k$ and $k\ge5$, then
$$I(G)\le k(k-3).$$

**Proof.** We have $q,r\le k$. Applying (1), with $b\ge0$, gives the bound except possibly when $(q,r)$ is one of
$$ (k,k),\quad(k-1,k),\quad(k,k-1). $$
For completeness, this numerical reduction follows by maximizing the bilinear expression $qr-\max(0,2q+2r-2k)$ on the two regions $q+r\le k$ and $q+r\ge k$: on each horizontal or vertical segment its maximum occurs at an endpoint. Outside the three displayed corners the maximum is at most $k(k-3)$ for $k\ge5$.

If $q=r=k$, every arc starts in $A$ and ends in $B$, and all these outgoing and incoming degrees equal two. If $A=B$, (1) gives $k^2-k-2k$. Otherwise choose $x\in A\setminus B$. It has indegree zero. Its two successors are zero-contribution recipient columns. The other $k-2$ columns each receive two direct arcs from $A$, giving
$$I(G)\le k(k-2)-2(k-2)=(k-2)^2\le k(k-3).$$

If $q=k-1,r=k$, (1) gives $I\le k(k-3)+2-b$, so $b\ge2$ suffices. Otherwise there is an indegree-zero vertex of $A\setminus B$. Its two successor columns contribute zero. The other $k-2$ columns receive $2k-4$ arcs in total; at most two start outside $A$. Therefore
$$I(G)\le(k-1)(k-2)-(2k-6)=k^2-5k+8\le k(k-3).$$
The case $q=k,r=k-1$ uses the sink obstruction to remove two zero source rows and gives the same bound. $\square$

## Odd numbers of arcs

**Theorem 7.** If $m=2k+1$ and $k\ge5$, then
$$I(G)\le k(k-3)+2.$$

**Proof.** Again $q,r\le k$, and (1) suffices outside the same three corners. If $r=k$, the total excess incoming degree in $B$, together with all arcs ending outside $B$, is at most one. Thus at most one vertex outside $B$ has positive indegree. An indegree-zero source in $A$ has an indegree-two successor: either every vertex of $B$ has indegree two and at most one arc ends outside $B$, or one vertex of $B$ has indegree three and every arc ends in $B$. Its at least two distinct successors cannot all be exceptions. This gives a zero recipient column.

Suppose $q=k-1,r=k$. Formula (1) gives $I\le k(k-3)+3-b$, so $b\ge1$ suffices. If $b=0$, choose an indegree-zero member of $A$. Remove a zero recipient column. The other $k-1$ columns receive at least $2k-2$ arcs, at most three of which start outside $A$, giving
$$I\le(k-1)^2-(2k-5)=k^2-4k+6\le k(k-3)+2.$$
The symmetric corner uses the zero-row argument.

Finally let $q=r=k$. Formula (1) suffices when $b\ge k-1$. If $2\le b\le k-2$, there is an indegree-zero source in $A\setminus B$, hence a zero column. The remaining columns contain at least $2k-3$ direct pairs and at least $b-1\ge1$ diagonal pairs. Thus
$$I\le k(k-1)-(2k-3)-1=k(k-3)+2.$$
If $b\le1$, at least $k-2\ge3$ vertices of $A\setminus B$ have indegree zero. Each has an indegree-two successor, and at most two can share any such successor. There are consequently at least two zero columns. The others contain at least $2k-5$ direct pairs, so
$$I\le k(k-2)-(2k-5)=k^2-4k+5\le k(k-3)+2.$$
This completes the proof. $\square$

## Equality structure

**Theorem 8.** For $k\ge6$, equality in Theorem 6 holds exactly when deleting isolated vertices leaves a two-in/two-out-regular graph on $k$ vertices with every pair guaranteed.

**Proof.** The numerical bounds away from the three corners are strict. In the $(k-1,k)$ corner, a member of $A\setminus B$ gives the strict zero-column estimate above; if $A\subseteq B$, then $b=k-1$ gives a strict bound directly. The other corner is analogous. In the $(k,k)$ corner, $A\ne B$ gives the strict bound $(k-2)^2$. Hence $A=B$, all $2k$ arcs lie on these $k$ vertices, and all incoming and outgoing degrees equal two. Equality then says that every eligible missing pair is guaranteed. $\square$

**Theorem 9.** For $k\ge6$, equality in Theorem 7 holds exactly for graphs whose nonisolated support has the following properties: it has $k+1$ vertices; one vertex $u$ has outdegree one and indegree two; a different vertex $v$ has indegree one and outdegree two; all other degrees are two; $u\to v$ is absent; and every missing nonloop pair with source of outdegree two and recipient of indegree two is guaranteed.

**Proof.** Strengthening the strict inequalities in Theorem 7 excludes all cases except $q=r=k$ and $b=k-1$. In the corner $(q,r)=(k-1,k)$, values $b\ge2$ are strict directly. If $b\le1$, at least $k-2$ members of $A$ lie outside $B$, and at most one has positive indegree. The zero-column argument gives $I\le k^2-4k+6<k(k-3)+2$. The dual corner uses the zero-row argument. In the remaining $(k,k)$ corner, for $b=2$ at least three indegree-zero sources give two zero columns; for $3\le b\le k-2$ the one-column argument retains at least two diagonal exclusions. The other excluded cases already have strict bounds for $k\ge6$.

Write $A\setminus B=\{v\}$ and $B\setminus A=\{u\}$. Equality forces $e(A,B)=2k-1$. The outgoing degree sum in $A$ and incoming degree sum in $B$ are each at least $2k$, while their sum is at most $m+e(A,B)=4k$. Thus all these degrees equal two. Exactly one arc starts outside $A$ and one ends outside $B$, and they are distinct. Vertex $v$ cannot have indegree zero: it would give a zero column containing at least $k-3>0$ eligible missing pairs. Hence it receives the unique arc ending outside $B$. Dually $u$ emits the unique arc starting outside $A$. Every vertex outside $A\cup B$ is isolated, and the two exceptional arcs being distinct implies that $u\to v$ is absent. Counting gives the converse. $\square$

Adding the missing arc $u\to v$ in Theorem 9 gives a two-regular digraph. It is not asserted that this completed graph is automatically universally winning.

# Sparse constructions with a linear deficit

## A safe branching principle

**Lemma 10.** Suppose distinct vertices have closed move sets intersecting in at most one vertex. If a vertex $r$ has two distinct outgoing neighbors that each guarantee delivery to $t$, then $r$ guarantees delivery to $t$.

**Proof.** For every pursuer position $c\ne r$, one of the two successors lies outside $C(c)$. Move there. It survives every intervening pursuer response, after which its guaranteed strategy applies. If the chosen vertex is $t$, delivery is already terminal. This is a finite concatenation of actual strategies. $\square$

**Theorem 11.** Let $a\ge3$, $h=2a+1$, $n\ge2h+1$, and $\gcd(n,h)=1$. The digraph on $\mathbb Z/n\mathbb Z$ with outgoing steps $1,a,h$ has every pair guaranteed. It has $3n$ arcs and
$$I(G)=n(n-4).$$

**Proof.** The positive differences in $\{0,1,a,2a+1\}$ are
$$1,\ a-1,\ a,\ a+1,\ 2a,\ 2a+1,$$
all distinct. Since $n>2h$, no positive difference coincides modulo $n$ with a negative one. Distinct closed move sets therefore intersect in at most one vertex.

Translate the recipient to zero. Vertices $0,-1,-a,-h$ are already delivered or have direct arcs to it. Vertex $-a-1$ is guaranteed via its neighbors $-a,-1$. Thus all four vertices
$$Q(z)=\{z,z-1,z-a,z-a-1\}$$
are guaranteed for $z=0$. If $Q(z)$ is guaranteed, apply Lemma 10 in the following order:

| New source | Two guaranteed successors |
|:--|:--|
| $z-h$ | $z-a-1,\ z$ |
| $z-h-1$ | $z-h,\ z-1$ |
| $z-h-a$ | $z-h,\ z-a$ |
| $z-h-a-1$ | $z-h-a,\ z-a-1$ |

This proves $Q(z-h)$. Iterating at most $n-1$ times covers every vertex because $h$ is coprime to $n$. The induction is finite; it supplies terminating strategies, not merely perpetual evasion. Finally subtract the $n$ diagonal pairs and $3n$ arcs from $n^2$. $\square$

![A guaranteed quartet produces the next quartet seven positions earlier in the step-1,3,7 construction.](figures/quartet.pdf)

The choice $a=3$ proves the theorem for every $n\ge15$ not divisible by seven. Adding an isolated vertex gives a linear-deficit construction for the remaining large sizes as well. The next elementary lemma removes that padding and improves the constant.

**Lemma 12.** For every $n\ge25$, there is an odd integer $h$ with $7\le h<n/2$ and $\gcd(n,h)=1$.

The proof and its explicit choices are included in the construction appendix below. Taking $a=(h-1)/2$ gives, for every $n\ge25$,
$$n(n-4)\le M_V(n)\le n(n-3),\qquad 3n\le n^2-M_V(n)\le4n.$$
Neither equality in the lower bound nor equality in the upper bound is asserted for arbitrary $n$.

# The dense boundary

**Theorem 13.** For $n\ge2$,
$$M(n,n(n-2))=\left\lfloor\frac{n-2}{2}\right\rfloor,$$
and $M(n,m)=0$ for every admissible $m>n(n-2)$.

**Proof.** If $(s,t)$ is indirect guaranteed, row $s$ misses $s\to t$. By Lemma 1, every other row $c$ must miss an arc into $N^+(s)$. Thus every row misses at least one nonloop arc, and $m\le n(n-2)$.

Now suppose $m=n(n-2)$. If $I=0$, the upper bound is immediate. Otherwise the preceding argument shows that every row misses exactly one arc; write $f(v)$ for its endpoint. Necessarily $f(v)\ne v$. A possible indirect pair is $(s,f(s))$. Lemma 1 says
$$ f^{-1}(s)=\varnothing,\qquad f^{-1}(f(s))=\{s\}. \tag{2}$$
These conditions suffice: for initial pursuer $c\ne s$, choose the intermediate $f(c)$. It is different from $s,f(s)$, is inaccessible on the pursuer's next move, and has an arc to $f(s)$. This is a two-move guarantee.

Pairs satisfying (2) have disjoint source and target vertices. If there are $j$ pairs, the remaining vertices contain a cycle of the loopless functional graph of $f$ and therefore number at least two. Hence $2j\le n-2$. For attainment use pairs $s_i\to t_i$ in the missing-arc graph, send every $t_i$ to $a$, put $a\leftrightarrow b$, and send any remaining vertex to $a$. Take all nonloop arcs except these missing arcs. $\square$

![The missing arcs at the dense boundary form a functional graph. Each displayed two-vertex branch contributes one guaranteed indirect pair.](figures/dense-boundary.pdf)

**Theorem 14.** A noncomplete graph with every pair guaranteed has at most $n(n-3)$ arcs.

**Proof.** Such a graph has an indirect pair. No row can be complete: its vertex would block every indirect source other than itself and have no indirect target of its own. If a row $c$ missed only $c\to t$, then $N^+(t)\subseteq C(c)$. Vertex $t$ also has an indirect recipient, contradicting Lemma 1. Every row therefore misses at least two arcs. $\square$

The next section gives a uniform construction attaining this density on an infinite set of orders. Its proof is independent of the sparse-game certificate for the complementary graph proved later.

## A periodic family with three-move delivery

Let $n=5k$, $k\ge4$, and write vertices as $5i+j$, with $i$ modulo $k$ and $0\le j\le4$. Put $\alpha(v)=v+1$ and
$$
\begin{aligned}
\beta(5i)&=5(i+1),&\beta(5i+1)&=5(i-1)+2,\\
\beta(5i+2)&=5(i-1)+4,&\beta(5i+3)&=5(i-1)+3,\\
\beta(5i+4)&=5(i-1)+1.
\end{aligned}
$$
Let $H$ have arcs $v\to\alpha(v),v\to\beta(v)$, and let $G$ be its loopless directed complement. Both maps are permutations, without fixed points or coincident images at a vertex; thus $G$ has $n(n-3)$ arcs.

**Theorem 15.** Every pair in $G$ is guaranteed within three messenger moves. Consequently $M(5k,5k(5k-3))=10k$ for every $k\ge4$.

**Proof.** For a missing pair $(s,t)$ and initial pursuer $c\ne s$, a safe two-move intermediate is any member of
$$\{\alpha(c),\beta(c)\}\setminus F(s,t),\qquad
F(s,t)=\{s,t,\alpha(s),\beta(s),\alpha^{-1}(t),\beta^{-1}(t)\}.$$
Its exclusion from $F$ ensures the two required arcs in $G$, while its membership in the displayed pair makes it inaccessible to the pursuer's next move.

Translate the source by a multiple of five so that $0\le s\le4$. A failure requires $c\in F-1$, since $\alpha(c)\in F$. The complete local calculation is:

| $s$ | $t$ | $F(s,t)$ | $(c,\beta(c))$, with $c\in F-1$, $c\ne s$ |
|--:|--:|:--|:--|
| 0 | 1 | $\{0,1,5,9\}$ | $(-1,-9),(4,-4),(8,3)$ |
| 0 | 5 | $\{0,1,4,5\}$ | $(-1,-9),(3,-2),(4,-4)$ |
| 1 | 2 | $\{-3,1,2,6\}$ | $(-4,-8),(0,5),(5,10)$ |
| 1 | $-3$ | $\{-4,-3,1,2\}$ | $(-5,0),(-4,-8),(0,5)$ |
| 2 | 3 | $\{-1,2,3,8\}$ | $(-2,-7),(1,-3),(7,4)$ |
| 2 | $-1$ | $\{-2,-1,2,3\}$ | $(-3,-6),(-2,-7),(1,-3)$ |
| 3 | 4 | $\{-2,3,4,7\}$ | $(-3,-6),(2,-1),(6,2)$ |
| 3 | $-2$ | $\{-3,-2,3,4\}$ | $(-4,-8),(-3,-6),(2,-1)$ |
| 4 | 5 | $\{-4,0,4,5\}$ | $(-5,0),(-1,-9),(3,-2)$ |
| 4 | $-4$ | $\{-5,-4,4,5\}$ | $(-6,-14),(-5,0),(3,-2)$ |

The only candidate with $\beta(c)\in F$ is $(s,t,c)=(4,5,-5)$. Every difference being tested has absolute value at most 19, so no extra equality appears modulo any $5k\ge20$. In that exceptional state move from 4 to 0. This is legal and safe: the pursuer at $-5$ has no arc to 0. Afterwards the pair $(0,5)$ is covered by the nonexceptional second row for every surviving pursuer position, and delivery takes at most two more moves. $\square$

# Correcting the original layered construction

The original graph remains a useful construction, but its printed count is not correct. We give its exact count and separate safe intermediate movement from terminal delivery.

Let $q=2x$, $a=\binom{2x}{x}/2$, and choose a family $\mathcal F$ containing one of each complementary pair of $x$-subsets of $[2x]$, with every coordinate occurring in exactly $a/2$ members. Such a family exists precisely when positive $x$ is not a power of two; a proof follows below.

There are row vertices $A_X,A'_X$ for $X\in\mathcal F$, and coordinate vertices $b_i,b'_i,c_i,c'_i$ for $i\in[q]$. The only arcs are

- $A_X\to b_i,b'_i$ when $i\in X$;
- $b_i\to A'_Y$ when $i\in Y$, and $b'_i\to A'_Y$ when $i\notin Y$;
- $A'_Y\to c_i,c'_i$ when $i\in Y$;
- $c_i\to A_X$ when $i\in X$, and $c'_i\to A_X$ when $i\notin X$.

The order is $N=2a+4q$. The four directed layers are $A$, $B\cup B'$, $A'$, $C\cup C'$.

**Theorem 16.** For the balanced original family,
$$I(G)=2a(N-1-q)+4q.$$
At $x=3$, the 44-vertex graph has exactly 764 indirect guaranteed pairs, rather than the draft's claimed lower bound of 1252.

**Proof.** The rows form an antichain. The $2q$ literal columns, indicating membership or nonmembership of each coordinate, also form an antichain, with size $a/2\ge5$. They cannot coincide: equality on the selected rows would remain true on their complements and hence on every $x$-subset, which is impossible for distinct literals. Every vertex has at least two successors.

From any noncollision state the messenger can safely advance one layer. If both players are in the same layer, use incomparable outgoing neighborhoods to choose a successor inaccessible to the pursuer. If the pursuer is in the next layer, avoid its occupied vertex; it has no within-layer arc. In the other two cases it cannot reach the next layer in one move. This includes waiting responses.

From $A_X$ to a specified $A'_Y$ there is a two-move guarantee. Against a pursuer $A_Z$, choose a coordinate in $X\setminus Z$, then choose its primed or unprimed intermediate according to membership in $Y$. Against a pursuer in the intermediate layer, choose another coordinate of $X$; the other layers cannot interfere. The reverse direction is identical. Safely advancing to the appropriate row layer first therefore gives delivery to any row recipient in at most five moves. There are $2a$ such recipients, each with $N-1-q$ indirect sources.

For target $b_i$ or $b'_i$, its predecessor set is exactly $N^+(c_i)$. Lemma 2 excludes every indirect source except $c_i$. That exceptional source wins in two moves: literal-column incomparability handles a pursuer in its own layer, and the other layer cases are as above. Thus $(c_i,b_i)$ and $(c_i,b'_i)$ both count. Symmetrically $(b_i,c_i)$ and $(b_i,c'_i)$ count, and no other indirect sources do. These give exactly $4q$ further pairs. $\square$

The correction preserves the original $N^2-O(N\log N)$ leading estimate along its constructed orders. The new circulant family supplies the stronger linear-deficit result at every sufficiently large order. The original construction's regular incidence design and the later extremal construction are distinct contributions.

## Balanced complementary halves

**Lemma 17.** For positive $x$, the $x$-subsets of $[2x]$ can be partitioned into two coordinate-balanced families with complementary subsets in opposite families if and only if $x$ is not a power of two.

**Proof.** Put $C=\binom{2x}{x}$. Each coordinate occurs in $C/2$ subsets, so balance requires $4\mid C$. The factorial valuation formula gives
$$v_2\binom{2x}{x}=s_2(x),$$
where $s_2(x)$ is the number of ones in the binary expansion. Thus divisibility by four is equivalent to $x$ not being a power of two.

For sufficiency, distinguish coordinate $2x$ and cyclically rotate the other $L=2x-1$ coordinates. Subsets containing $2x$ correspond to binary circular words with $x-1$ ones and $x$ zeros. Every orbit has length $L$: a proper repetition would have a repetition count dividing both consecutive integers. The number $C/(2L)$ of orbits is even, since $L$ is odd and $4\mid C$.

Choose half of those orbits. In the first family put their subsets, and put the complements of the subsets in the unchosen orbits. Exactly one of each complementary pair is selected. The distinguished coordinate occurs $C/4$ times. Rotation invariance gives a common incidence count $r$ for every other coordinate; counting all incidences yields
$$ (2x-1)r+C/4=xC/2,$$
so $r=C/4$. The other family is balanced as well. $\square$

This proof replaces the draft's incorrect stronger divisibility assertion $4x\mid\binom{2x}{x}$, which already fails at $x=3$.

# High-girth complements and exact dense intervals

The preceding periodic construction attains the largest possible density of a noncomplete all-delivery network on an arithmetic progression. A different construction handles every sufficiently large order and an interval of arc counts. Here the sparse graph specifies the connections to omit from an otherwise complete directed network.

**Lemma 18 (high-girth complement).** Let $F$ be an orientation of a finite simple undirected graph of girth at least six. Suppose every vertex has outdegree at least two in $F$. Let $G$ contain exactly the nonloop arcs absent from $F$. Then every source–recipient pair in $G$ is guaranteed within two messenger moves.

**Proof.** Diagonal and direct pairs need no argument. For a missing pair $(s,t)$ of $G$, the arc $s\to t$ belongs to $F$. Set
$$
B=N_F^+(s)\cup N_F^-(t).
$$
Both $s$ and $t$ belong to $B$. In the underlying undirected graph, the vertices of $B$ form an induced double star: its centers are $s,t$, the other outneighbors of $s$ are leaves at $s$, and the other predecessors of $t$ are leaves at $t$. The two sets of leaves are disjoint, since an overlap would make a triangle. An additional edge inside $B$ would make a triangle or quadrilateral. Thus the distance between any two vertices in this induced tree is at most three.

Fix an initial pursuer vertex $c\ne s$. If $c\notin B$, two neighbors of $c$ in $B$ would form an undirected cycle of length at most five, so $c$ has at most one outgoing $F$-neighbor in $B$. The same bound holds when $c\in B\setminus\{s\}$: a leaf at $s$ has its only incident edge in the tree directed toward it; a leaf at $t$ has only its edge toward $t$; and all tree edges incident with $t$ point into $t$.

Since $c$ has at least two outgoing $F$-neighbors, choose
$$u\in N_F^+(c)\setminus B.$$
Then $u\ne s,t$, and $s\to u$ and $u\to t$ are arcs of $G$. Also $u\ne c$ and $c\to u$ is absent from $G$. The messenger moves to $u$, survives every pursuer response, and delivers to $t$ on its next turn. $\square$

The lemma only requires a lower bound on outgoing degrees. In particular, edges can later be added to the underlying graph and oriented arbitrarily, provided its girth remains at least six.

**Theorem 19 (the densest noncomplete all-delivery networks).** For every $n\ge52$,
$$M(n,n(n-3))=2n.$$
An attaining graph guarantees every pair within two messenger moves. The construction for $n\ge130$ has the ordinary proof below; the extension to $52\le n<130$ uses an explicit finite structural certificate.

**Proof.** We first construct a four-regular undirected graph of girth at least six at each required order. Orient an Euler tour in each of its components. Every vertex then has two incoming and two outgoing arcs. Such tours exist by the elementary closed-trail construction: even degrees prevent an unused-edge trail from stopping away from its starting vertex, and further closed trails can be spliced into the first until all edges of the component have been used. Lemma 18 applies to the resulting orientation $F$. It has $2n$ arcs, so its directed complement has $n(n-3)$ arcs and exactly $2n$ missing pairs, all guaranteed. The missing-pair count is also an upper bound for $I$.

For a building block, take point vertices $p\in\mathbb Z/13\mathbb Z$ and line vertices $\ell\in\mathbb Z/13\mathbb Z$, joining them when
$$p-\ell\in\{0,1,3,9\}.$$
This graph has 26 vertices and is four-regular. The twelve ordered differences between distinct members of $\{0,1,3,9\}$ are precisely the twelve nonzero residues modulo 13. Consequently two distinct points cannot have two common line neighbors: the two common neighbors would give two representations of the same nonzero difference. There is no four-cycle. Bipartiteness excludes odd cycles, so the girth is at least six.

The following operation increases the order by one. Choose edges $ab$ and $cd$ such that every endpoint of the second is at distance at least four from every endpoint of the first. Delete these two edges, add a new vertex $x$, and join $x$ to $a,b,c,d$. The endpoints are distinct and all degrees remain four. Any new cycle uses two of these new edges. If their old endpoints belonged to the same removed edge, the path between them after its removal has length at least five, giving a new cycle of length at least seven. Otherwise their old distance was at least four, giving a new cycle of length at least six. Thus the operation preserves the required girth.

Such an edge pair exists in every four-regular graph with more than 120 vertices. Fix an edge $ab$ and let $S$ consist of the vertices within distance three of $a$ or $b$. The branching bound from the two ends of the edge gives
$$|S|\le2(1+3+9+27)=80.$$
The induced graph on $S$ is connected, hence has at least $|S|-1$ edges. If there were no edge with both endpoints outside $S$, four-regularity would give
$$
4|V\setminus S|=e(S,V\setminus S)
=4|S|-2e(S)
\le2|S|+2.
$$
It would follow that
$$n\le\left\lfloor\frac{3|S|+1}{2}\right\rfloor\le120.$$
Therefore an outside edge exists and can serve as $cd$.

Start with five disjoint copies of the 26-vertex building block. Repeated insertion now gives every order $n\ge130$. For the smaller stated orders, two disjoint building blocks give order 52. The supplied certificate lists 78 admissible insertions, producing every order from 52 through 130. Each insertion satisfies the same distance condition and therefore has the proof of correctness just given. Its finite verification is described below. $\square$

The density $n(n-3)$ is maximal among noncomplete all-delivery graphs, by the earlier dense-boundary theorem. This construction therefore settles the joint extremum at that density for every $n\ge52$; it is not a claim about the arc-only maximum at the same number of arcs.

**Finite-certificate reproduction.** The file `research/extremal-bounds-girth-growth.json` records the two removed edges at every insertion, starting from the explicit 52-vertex graph above. The generator and replayer `src/extremal_bounds_girth_family.py` checks the endpoint distances, all degrees, and the absence of short cycles. A separate implementation, `src/extremal_bounds_girth_verify.py`, rebuilds the incidence graph directly and checks girth by enumerating simple paths and testing whether they close into cycles of lengths three, four, or five. It verifies all 79 graph orders independently of the generator's edge-deleted breadth-first checks. The receipt `research/extremal-bounds-girth-verification.json` records the certificate and verifier hashes. These are finite graph certificates attached to the proved insertion rule, not extrapolation from successful pursuit-game searches. They are executable checks rather than a Lean formalization; omitting this finite certificate leaves the ordinary theorem for every $n\ge130$.

**Theorem 20 (an interval of exact dense extrema).** Fix integers $n\ge52$ and $5\le D\le n-1$, and put
$$
\begin{aligned}
B_D&=1+D\bigl(1+(D-1)+(D-1)^2+(D-1)^3\bigr)\\
   &=D^4-2D^3+2D^2+1,\\
L_D(n)&=\left\lfloor\frac{Dn-(D-4)B_D}{2}\right\rfloor.
\end{aligned}
$$
For every integer $h$ satisfying $2n\le h\le L_D(n)$,
$$M(n,n(n-1)-h)=h.$$
Each equality is attained by an all-delivery graph with a two-move strategy. An empty interval makes no assertion.

**Proof.** Begin with the four-regular girth-six graph from Theorem 19. Repeatedly add an undirected edge between two vertices of current degree less than $D$ whose distance is at least five. Vertices in different components have infinite distance. Each addition preserves simplicity, the degree cap $D$, and girth at least six.

When no further addition is possible, let $U$ be the vertices of degree less than $D$. If $U$ is nonempty, all its vertices lie within distance four of any fixed member of $U$. A graph of maximum degree $D$ has at most $B_D$ vertices in such a ball, so $|U|\le B_D$. This inequality also holds when $U$ is empty. The minimum degree remains at least four. The final edge count is consequently at least
$$
\frac{D(n-|U|)+4|U|}{2}
\ge\frac{Dn-(D-4)B_D}{2}.
$$
Starting from $2n$ edges and adding one edge at a time produces a graph with every edge count through $L_D(n)$.

Orient the initial four-regular graph by Euler tours, and orient each added edge arbitrarily. Each vertex retains its original two outgoing arcs. Applying Lemma 18 at the stage with $h$ edges gives a directed complement with $n(n-1)-h$ arcs and all its $h$ missing pairs guaranteed. No graph with that arc count can have more than $h$ indirect pairs. $\square$

The statement has both order and density as parameters. For example, $B_D\le D^4$ for $D\ge2$. When $n\ge2D^4$, the displayed bound gives
$$L_D(n)\ge n(D/4+1)-1.$$
Thus choosing $D=\lfloor(n/2)^{1/4}\rfloor$ for sufficiently large $n$ yields exact joint extrema for an interval of missing-arc counts extending to a positive constant times $n^{5/4}$. As with Theorem 19, the range $n\ge130$ has an ordinary construction, while the extension down to 52 uses the explicit finite certificate.


# An infinite family attaining the sparse bounds

The five-type graph used in the dense construction also attains the sparse vertex and arc-budget bounds. This requires a different strategy: its messenger may need to travel around a substantial part of the ring. The proof combines fixed local certificates with a simulation valid at every sufficiently large circumference, followed by six finite base cases.

For clarity, define the sparse graph $H_k$ again. Its vertices are
$$ (i,j)\in (\mathbb Z/k\mathbb Z)\times\{0,1,2,3,4\}.$$
The first outgoing arc follows the cycle
$$(i,0)\to(i,1)\to(i,2)\to(i,3)\to(i,4)\to(i+1,0).$$
The second outgoing arc is specified by
$$
\begin{aligned}
(i,0)&\to(i+1,0), & (i,1)&\to(i-1,2),\\
(i,2)&\to(i-1,4), & (i,3)&\to(i-1,3),\\
(i,4)&\to(i-1,1).
\end{aligned}
$$
Both arc maps are permutations, are loopless, and have distinct images at every vertex when $k\ge4$. Hence $H_k$ has $5k$ vertices and $10k$ arcs, with indegree and outdegree two everywhere. Waiting is an additional legal action, as throughout the paper.

![The five station types in consecutive columns. Black arrows follow the long cycle and blue arrows give the second permutation. Identifying columns modulo k closes the strip into the graph H_k.](figures/five-type-strip.pdf)

**Theorem 21 (uniform sparse attainment).** For every integer $k\ge4$, every source–recipient pair in $H_k$ is guaranteed. Consequently
$$
M_V(5k)=5k(5k-3),\qquad
M_E(10k)=5k(5k-3).
$$
For $k\ge10$, a sufficient delivery time is $8k+16$ messenger moves. The theorem is computer-assisted: its finite ingredients are the two local objectives specified below and the six rings $4\le k\le9$.

## The stronger local arena

Unwrap the column coordinate to the integers, retaining the same two arc rules. Confine the messenger to columns $-3,\ldots,3$, disallowing moves out of this interval. Represent the pursuer by its exact vertex in columns $-4,\ldots,4$, together with an exterior state $\Omega$. Thus there are 35 messenger positions and 46 pursuer positions.

Within its nine-column window the pursuer has all its usual moves and its wait; a move leaving the window goes to $\Omega$. From $\Omega$ it may wait or enter any vertex of either boundary column $-4$ or $4$. This grants more freedom than a particular physical pursuer outside the window. The messenger and $\Omega$ can never coincide.

The two objectives have different stopping rules:

- A **safe transfer** ends in column zero at the start of a messenger turn, with the positions distinct. Entering column zero on a messenger move is insufficient: the intervening pursuer response must also be survived.
- A **delivery** ends immediately when the messenger enters a specified vertex $(0,t)$, before collision is checked there, exactly as in the original game.

For each objective, the certificate assigns nonnegative integer ranks to winning states and selects a legal move at every positive-rank messenger state. Every selected move decreases rank, and every legal response at a positive-rank pursuer state also decreases rank. The zero-rank states are precisely the applicable terminal successes. These conditions prove termination by induction on rank. For safe transfer, only noncollision **messenger-turn** states in column zero are seeded as successes; pursuer-turn states there still require all their responses to be safe.

The checked finite bounds are:

| Local objective | Initial column | Initial noncollision states | Maximum messenger moves |
|:--|--:|--:|--:|
| Safe transfer to column zero | 1 | 225 | 8 |
| Delivery to $(0,0)$ | 2 | 225 | 24 |
| Delivery to $(0,1)$ | 2 | 225 | 16 |
| Delivery to $(0,2)$ | 2 | 225 | 16 |
| Delivery to $(0,3)$ | 2 | 225 | 17 |
| Delivery to $(0,4)$ | 2 | 225 | 18 |

Each row covers all five source types and all 46 pursuer states other than the source itself. In particular, it includes an initially exterior pursuer. Only the bounds 8 and 24 are needed below; optimality of these local times is not claimed as a separate result.

## Projection to a ring

Fix $k\ge10$ and any reference column. Its nine offsets $-4,\ldots,4$ represent distinct columns of the ring. Map a physical pursuer in this window to its exact local position and every other pursuer position to $\Omega$.

Every physical pursuer move has a permitted image. A move within the window is unchanged, one leaving it goes to $\Omega$, and a move remaining outside is represented by waiting at $\Omega$. A move from outside into the window can enter only a boundary column, because each arc changes the column by at most one; every such entry is permitted from $\Omega$. At $k=10$ the exterior consists of a single column adjacent to both boundaries, and both entries are already allowed. At $k=9$ the two boundary columns themselves have wraparound adjacencies, so this argument would fail; those rings are deliberately covered by finite checks instead.

Every messenger move permitted by the local certificate is a genuine ring move. Its seven represented columns lie strictly inside the pursuer window. Consequently a physical collision with the messenger is exactly a local collision; an exterior pursuer cannot coincide with it. Following a local winning strategy therefore succeeds against every physical pursuer strategy. This is a simulation of legal moves and collisions, not an assumption that winning strategies pass automatically to graph covers.

## Composition and termination

**Proof of Theorem 21.** Translate the recipient's column to zero, and let the messenger's current column be $d$. Translate the safe-transfer window so that its local column zero is the physical column $d-1$; the messenger then starts in local column one. The certificate reduces its physical column by one modulo $k$ and finishes only after the pursuer's response, so another transfer can begin with the correct turn order. Recenter the window between transfers; each new local certificate is valid for every resulting noncollision pursuer position.

After the least nonnegative residue of $d-2$ modulo $k$ such transfers, at most $k-1$, the messenger is in column two. Apply the delivery certificate for the recipient's type. This takes at most
$$8(k-1)+24=8k+16$$
messenger moves. If a transfer encounters the actual recipient earlier, terminal receipt wins immediately and only shortens the play. Thus the argument guarantees finite delivery, not merely indefinite safe movement.

For $4\le k\le9$, the explicit finite-ring certificates verify every source and pursuer position for each of the five recipient types in column zero. Translating columns gives every recipient. These six checks, together with the uniform argument for $k\ge10$, establish universality for all $k\ge4$.

Finally, a universal graph with $n=5k$ vertices and $2n$ arcs has
$$I(H_k)=n^2-n-2n=n(n-3).$$
The vertex upper bound and the even arc-budget upper bound both equal this number. Hence both asserted extremal equalities follow. $\square$

**Certificate reproduction and scope.** The file `research/five-type-certificates.json` contains the fixed local arena, ranks, and chosen messenger moves, generated and directly checked by `src/five_type_certificate.py`. The independent implementation `src/five_type_local_verify.py` constructs the explicit alternating-state graph from the arc rules and checks every winning rank condition, as well as closure of the losing region. Its full ranks and selected moves are saved in `research/five-type-independent-local-certificates.json`, together with the implementation hash. Both implementations agree on the six local bounds above. The six finite bases are stored in `research/five-type-small-ring-certificates.json`, including complete arc lists, messenger-move layers, and explicit alternating-state rank certificates for the five representative recipient types. The script `src/five_type_small_certificates.py` reproduces those checks using both game solvers and verifies every certificate transition. The ordinary projection and composition proof explains why these finite arrays certify infinitely many rings. This theorem is not currently claimed as a Lean formalization.

**Corollary 22 (sharp arc-budget leading term).** As $m\to\infty$,
$$M_E(m)=\frac{m^2}{4}-O(m).$$
More explicitly, for every $m\ge40$,
$$\frac{m^2}{4}-6m\le M_E(m)\le\left\lfloor\frac m2\right\rfloor^2.$$

**Proof.** Set $k=\lfloor m/10\rfloor\ge4$ and $r=m-10k$, so $0\le r\le9$. Take $H_k$ together with $r$ disjoint one-way arcs. Each added component has no indirect guaranteed pair, and additivity over components preserves $I(H_k)$. This graph has exactly $m$ arcs and
$$
I=25k^2-15k
=\frac{(m-r)^2}{4}-\frac{3(m-r)}2
\ge\frac{m^2}{4}-6m.
$$
The upper bound follows because there are at most $\lfloor m/2\rfloor$ possible sources and at most that many possible recipients of indirect guaranteed pairs. Thus the quadratic coefficient $1/4$ is sharp for arbitrary arc counts, not only the progression $m=10k$. $\square$

Exact equality at arbitrary orders and arc counts remains a separate question. The padding argument establishes the leading term; it does not fill the gaps between the sharp values supplied by Theorem 21.


# Exact extrema with at most seven arcs

**Proposition 23.** Allowing arbitrarily many vertices, including isolated vertices,
$$
\bigl(M_E(0),M_E(1),\ldots,M_E(6)\bigr)
  =(0,0,0,0,1,1,2).
$$

**Proof.** Write $A=\{v:d^+(v)\ge2\}$, $B=\{v:d^-(v)\ge2\}$,
$q=|A|$, $r=|B|$, and $b=|A\cap B|$.
Every counted pair belongs to $A\times B$, excludes the diagonal, and
excludes arcs. Consequently
$$
I(G)\le qr-b-e(A,B),\qquad
e(A,B)\ge\max\{0,2q+2r-m\},\qquad
q,r\le\lfloor m/2\rfloor.                 \tag{23.1}
$$
For completeness, the second inequality follows by counting the arcs leaving
$A$ and those entering $B$: their respective totals are at least $2q$
and $2r$, and their union has at most $m$ arcs.

A counted pair $(s,t)$ requires two arcs leaving $s$ and two entering
$t$. These four arcs are distinct because $s\to t$ is absent. Thus
$I(G)=0$ when $m\le3$.

We will use two elementary camping observations. If $d^-(z)=0$,
$z\to t$, and $d^-(t)=2$, then no indirect pair ending at $t$ is
guaranteed. Indeed, let $p$ be its other predecessor. An indirect source
is neither $z$ nor $p$. A pursuer starting at $p$ can wait there:
the messenger cannot reach $z$, and cannot enter $p$ without being
captured before reaching $t$. Dually, if $d^+(z)=0$, $s\to z$,
and $d^+(s)=2$, then no indirect pair starting at $s$ is guaranteed.
A pursuer waits at the other successor of $s$; the messenger's only
alternative departure reaches a sink different from the indirect recipient.

Suppose first that $m=4$ or $m=5$. Then $q,r\le2$. If either is
zero there is nothing to count, and if both are one the bound is immediate.
When $q=r=2$, (23.1) gives $I(G)\le m-4-b\le1$. When $q=1$
and $r=2$, two counted pairs would have the same source and distinct
recipients. The source's two outgoing arcs are then disjoint from the at
least four arcs entering those recipients, which would require $m\ge6$.
The case $q=2,r=1$ follows by the same count with sources and recipients
interchanged: at least four arcs leave the two counted sources, and the
recipient's two incoming arcs are disjoint from them. Hence $I(G)\le1$.

Now let $m=6$, so that $q,r\le3$. If $q=1$, three counted pairs
would require two outgoing arcs from their common source and six disjoint
arcs entering their three recipients; this is impossible. Thus $I(G)\le2$.
The same argument applies when $r=1$; cases with a zero coordinate are
again immediate. If $q=r=2$, (23.1) gives $I(G)\le2-b\le2$.

Consider $q=2,r=3$. Every arc ends in $B$, and every vertex of $B$
has indegree exactly two. If $A\subseteq B$, then $b=2$ and (23.1)
gives $I(G)\le6-2-4=0$. Otherwise choose $z\in A\setminus B$.
It has indegree zero and at least two distinct successors in $B$.
The first camping observation eliminates both corresponding recipient
columns. At most one column remains, containing at most the two sources
in $A$. Thus $I(G)\le2$.

For $q=3,r=2$, every arc starts in $A$ and every vertex of $A$
has outdegree exactly two. If $B\subseteq A$, the same count gives zero.
Otherwise a vertex $z\in B\setminus A$ has outdegree zero and at least
two predecessors in $A$. The second camping observation eliminates
their two source rows, leaving at most one row and two recipients. Again
$I(G)\le2$.

Finally, if $q=r=3$, all six arcs go from $A$ to $B$, and all
relevant indegrees and outdegrees equal two. If $A=B$, (23.1) gives
$I(G)\le9-3-6=0$. Otherwise a vertex of $A\setminus B$ has indegree
zero and eliminates two recipient columns by the first camping observation.
The remaining column has two distinct predecessors in $A$, so at most
one of the three sources can contribute an indirect pair. This completes
the upper bounds in all cases.

For the lower bounds, the four-arc diamond
$$
E=\{(0,1),(0,2),(1,3),(2,3)\}
$$
guarantees the indirect pair $(0,3)$: the messenger chooses the branch
not occupied by the pursuer and delivers on the next move. Adding a
disjoint arc gives the five-arc example. The six-arc graph
$$
E=\{(0,1),(0,2),(1,3),(1,4),(2,3),(2,4)\}
$$
guarantees both $(0,3)$ and $(0,4)$. If the pursuer starts on one
branch, choose the other; if it starts at either sink, choose either branch.
In each case it cannot reach the selected branch on its next move, and
receipt then occurs on the messenger's second move. Hence $I(G)=2$,
as required. $\square$

These arguments establish the arc-only maximum over every finite vertex
set; no restriction on the number of nonisolated vertices is used.

**Proposition 24 (with a finite exhaustive computation).** We have
$$
M_E(7)=2.
$$

**Proof.** First consider a weakly connected digraph with at most seven
arcs and at least seven vertices. Forget the directions but retain one
undirected edge for each arc, so that opposite arcs become parallel
edges. The resulting connected multigraph has at most as many edges as
vertices. It is therefore a tree or has exactly one cycle; a parallel
pair is allowed as a cycle of length two.

In a tree, any reachable indirect source--recipient pair has an internal
vertex separating its endpoints. A pursuer can start and wait there,
preventing delivery. Thus no indirect pair is guaranteed. In the unicyclic
case, a pair with either endpoint outside the unique cycle likewise has
an internal separating vertex, unless its endpoints are adjacent in the
underlying graph. For adjacent endpoints off the cycle, a directed route
exists only if their connecting arc has the required direction, making
the pair direct. Thus every counted pair must have both endpoints on the
cycle.

There are exactly two simple undirected paths along that cycle between
two distinct cycle vertices. If only one is a directed path from the
source to the recipient, it is either a direct arc or has an internal
vertex where the pursuer can wait. If neither is directed, the recipient
is unreachable. Excursions into attached trees cannot bypass an internal
cycle vertex. Consequently a counted pair requires both cycle paths to
be directed from its source to its recipient. This forces the cycle's
unique divergence at that source and unique convergence at that recipient;
every other cycle vertex has one entering and one leaving cycle edge.
A fixed orientation can therefore support at most one such ordered pair.
A cycle of length two consists of opposite arcs and supports no indirect
pair. We have proved that every weakly connected digraph with at most
seven arcs and at least seven vertices has $I(G)\le1$.

For a general digraph with seven arcs, distinct weak components contribute
additively to $I(G)$. Each component with a positive contribution uses
at least four arcs by Proposition 23, so at most one component contributes.
If that component uses at most six arcs, Proposition 23 bounds its
contribution by two. If it uses seven arcs and has at least seven vertices,
the preceding argument bounds its contribution by one. In the only
remaining case it has at most six vertices. Adding isolated vertices to
make six does not change its indirect guarantee count, and the complete
six-vertex enumeration gives a maximum of two at seven arcs.

This last finite assertion is the computational dependency of the
proposition. It is reproduced by `src/enumerate_small_n6.cpp`; the result
is recorded with `complete: true` in
`research/solver-enumeration-n6.json`. The enumeration covers every
six-vertex digraph up to the degree-ordering reduction described in the
computational section; the witness is also checked by the separate
explicit-turn solver. The structural reduction above is what extends
that finite calculation to unrestricted vertex counts.

Finally, add one disjoint arc to the six-arc, two-recipient construction
in Proposition 23. This preserves its two guarantees and supplies seven
arcs, proving the matching lower bound. $\square$

No exact arc-only maximum for budgets eight through eleven is asserted
here.


# Exact computation and formal verification

For a fixed recipient $t$, let $X_j(r)$ be the set of initial pursuer positions from which delivery can be forced in at most $j$ messenger moves. Start with $X_0(t)=V$ and $X_0(r)=\varnothing$ otherwise. Set
$$
S_j(v)=\{c:C(c)\subseteq X_j(v)\}\quad(v\ne t),\qquad S_j(t)=V,
$$
and update
$$
X_{j+1}(r)=\left(\bigcup_{v\in C(r)}S_j(v)\right)\setminus\{r\}\quad(r\ne t),
\qquad X_{j+1}(t)=V.
$$
The recurrence includes waits and excludes all nonterminal collisions. Its least fixed point enforces eventual delivery. A separate implementation builds the explicit alternating graph of states $(r,c,\text{turn})$ and computes its reachability attractor. This is standard finite reachability-game machinery [@berwanger2009], rather than a new general algorithm for graph games.

The certificate checker independently verifies decreasing ranks on the selected messenger moves and on every pursuer response. Outside the winning region it verifies closure under every messenger move and at least one pursuer response. Thus a negative answer comes with an avoidance strategy, not simply failure of a search. Standard adjacency-list attractor analysis gives an all-recipient time bound $O(n^2m+n^3)$; that bound describes the standard implementation, not a claimed running-time bound for the simpler synchronous reference solver.

## Certified finite extrema

Complete enumeration gives

| $n$ | 1 | 2 | 3 | 4 | 5 | 6 |
|:--|--:|--:|--:|--:|--:|--:|
| $M_V(n)$ | 0 | 0 | 0 | 2 | 4 | 7 |

For $n\le5$ every labeled digraph was enumerated. For $n=6$, sorting the vertex labels by degree reduces the search while retaining at least one representative of every isomorphism class; valid degree bounds prune only candidates unable to improve the current maximum. This certifies extrema, not labeled distributions. Every attaining graph is independently checked by the explicit alternating solver. The complete joint tables, enumeration code, and receipts accompany the paper.

Universal two-regular witnesses attain Theorem 5 for every $12\le n\le24$. Consequently Theorem 6 is attained at $m=24,26,\ldots,48$. Deletion witnesses attain Theorem 7 at $m=37,39,\ldots,47$. Orders 7 through 11 are not asserted to be classified here.

One clean 12-vertex example is a Cayley digraph of $A_4$, with right multiplication by two suitable 3-cycles. Its actual graph and all-recipient finite-rank certificate are included. The Lean theorem checks the explicit 12-vertex graph directly, so correctness does not depend on trusting the group-label interpretation or the search that discovered it.

## Lean coverage

The formal artifact uses Lean 4.33.1 and its standard library. The game implementation checks terminal receipt before collision, permits waiting, and quantifies over arbitrary legal history-dependent pursuer choices. Finite winning trees are proved to generate actual delivering plays; rank certificates generate those winning trees. Safe branching and predecessor camping are connected to the same semantics. A fully kernel-checked 12-vertex certificate proves universal delivery and computes $I=108$.

These are meaningful statements about the physical game. The general degree-counting theorems, arithmetic existence lemma, infinite constructions, and exhaustive-search completeness arguments remain ordinary proofs. The downloadable coverage map lists exact theorem names and source hashes; it does not equate a numerical certificate or assumed interface with a full general formalization.

# Further consequences and open problems

For the random loopless digraph with each arc independently present with a fixed probability $0<p<1$, all distinct pairs are guaranteed with probability tending to one. For fixed distinct $s,t$ and $c\ne s$, each candidate $u\notin\{s,t,c\}$ independently supplies the arcs $s\to u,u\to t$ and the absence of $c\to u$ with probability $p^2(1-p)$. A union bound gives failure probability at most
$$n^3\bigl(1-p^2(1-p)\bigr)^{n-3}.$$
Thus
$$\mathbb E[I(G)]=(1-p)n(n-1)-o(1).$$
The error is absolute $o(1)$ because the probability bound is exponential. This fixed-$p$ observation neither solves the sparse regular construction problem nor transfers unchanged to the fixed-$m$ model.

The main unresolved questions are exact attainment of the vertex and arc-budget upper bounds at arbitrary orders, the joint maximum away from the proved boundaries, and the classification of all maximizing graphs. The five-type theorem below settles the vertex bound at every multiple of five from 20 onward, and the even arc bound at every multiple of ten from 40 onward. Exact attainment at the other large orders and at arbitrary odd arc budgets is still open here. Finite modifications that win at one circumference can fail at all neighboring circumferences; they are not evidence of a uniform extension without an additional argument.

A correct future proof must retain enough information about both players. Simple distance-to-recipient potentials fail: some states at a fixed small distance from the recipient require detours whose length grows with the graph. Nor does safe indefinite motion imply delivery. The finite witnesses and failed conjectures are preserved to make those distinctions reproducible.

# Construction appendix: choosing the circulant parameter

**Proof of Lemma 12.** If $n\equiv0\pmod4$, choose $h=n/2-1$; any common divisor with $n$ divides two and is odd. If $n\equiv2\pmod4$, choose $h=n/2-2$; the same argument uses four. If $n\equiv3\pmod4$, use $h=(n-1)/2$.

It remains to handle $n\equiv1\pmod4$. Write $n-1=2^e d$ with $d$ odd and $e\ge2$. If $d\ge7$, take $h=d$: it divides $n-1$ and is at most $(n-1)/4$. If $d\in\{1,3,5\}$ and $3\nmid n$, use $h=(n-3)/2$.

If $d=1$ and $3\mid n$, take $h=(n-7)/2$. The number $2^e+1$ is not divisible by seven, since powers of two modulo seven are $1,2,4$. The case $d=3$ and $3\mid n$ is impossible. Finally, if $d=5$ and $3\mid n$, then $e$ is even. Use $h=(n-11)/2$. Divisibility of $5\cdot2^e+1$ by eleven would imply $2^e\equiv2\pmod{11}$, whereas even powers have residues $1,3,4,5,9$.

All choices are odd and smaller than $n/2$. Their smallest possible lower estimate is $(n-11)/2\ge7$, valid for $n\ge25$. $\square$

# Provenance and assistance

Alexandra Ignatova's original problem and layered construction, developed under Angel Raychev's mentorship in 2023 and written in the retained February 2024 manuscript, are credited throughout. The September 2026 work repairs the balancing and strategy arguments, corrects the original count, and develops the new extremal bounds, circulant constructions, dense families, computational certificates, and formalization. Astra 6, operating through the Codex harness, assisted with these deductions, counterexample searches, proof writing, programming, and Lean development. The current document is a research checkpoint; it has not been submitted to arXiv and does not assign an unresolved final human author line.

# References

---
title: Guaranteed indirect delivery in directed networks
subtitle: Extremal bounds, sparse constructions, and verified finite cases
date: 12 September 2026
documentclass: article
classoption: 11pt
geometry: margin=1in
colorlinks: true
linkcolor: blue
urlcolor: blue
toc: true
toc-depth: 1
numbersections: true
---

# Introduction

A messenger has just obtained a message at a station $s$ of a directed network. A pursuer occupies another station, and both positions are visible. They move alternately, the messenger first, using one directed connection or waiting. The messenger wants to deliver to a designated recipient $t$ before interception. Receipt completes the task immediately, even if the pursuer is at $t$: the pursuer can intercept the messenger but cannot disable the recipient.

A direct connection $s\to t$ makes delivery immediate. We study the additional communication supported by the network: source--recipient pairs without a direct connection for which delivery is nevertheless guaranteed against every allowed initial pursuer position. Write $I(G)$ for their number. The three extremal quantities are

$$
M_V(n)=\max_{|V(G)|=n} I(G),\qquad
M_E(m)=\max_{|E(G)|=m} I(G),\qquad
M(n,m)=\max_{|V(G)|=n,\ |E(G)|=m} I(G).
$$

Isolated vertices are allowed. Removing them preserves $I$, so the arc-only maximum is finite: a graph with $m>0$ arcs has at most $2m$ nonisolated vertices.

The original problem and a layered subset construction arose in Alexandra Ignatova's 2023 project, mentored by Angel Raychev. A public 2023 abstract records that provenance [@ignatova2023]; the retained manuscript is dated February 2024 [@ignatova2024]. Ignatova and Raychev had already established the upper bound $I(G)\le n(n-3)$ and investigated two-in/two-out-regular constructions. This account reconstructs that bound, distinguishes the original construction from its corrected analysis, and supplies new attaining families among the September 2026 extensions. The full extremal classification remains open.

## Results and proof boundaries

The main general results established here are the following.

1. For $n\ge3$, $I(G)\le n(n-3)$. For $k\ge5$, the sharper arc-budget bounds are
   $$
   M_E(2k)\le k(k-3),\qquad
   M_E(2k+1)\le k(k-3)+2.
   $$
   We characterize equality in these bounds for $k\ge6$.
2. There are explicit networks with $3n$ arcs in which every pair is guaranteed for every $n\ge25$. In particular,
   $$n(n-4)\le M_V(n)\le n(n-3)\qquad(n\ge25).$$
   Thus the deficit $n^2-M_V(n)$ has linear order.
3. At the dense boundary,
   $$M(n,n(n-2))=\left\lfloor\frac{n-2}{2}\right\rfloor,$$
   and $M(n,m)=0$ for every larger admissible $m$. The minimum value of $I$ is zero at every admissible $(n,m)$.
4. A two-in/two-out-regular repeating construction attains the sparse bounds for every $k\ge4$:
   $$M_V(5k)=M_E(10k)=M(5k,10k)=5k(5k-3).$$
   A finite local certificate and a uniform projection argument prove the infinite family. Consequently $M_E(m)=m^2/4-O(m)$.
5. A noncomplete network in which every pair is guaranteed has at most $n(n-3)$ arcs. High-girth complements attain this density for every $n\ge52$:
   $$M(n,n(n-3))=2n.$$
   More generally an explicit interval of dense arc budgets attains every missing pair, as specified in Theorem 20. A separate elementary construction covers $n=5k$, $k\ge4$.
6. Independent exact solvers certify $M_V(n)=n(n-3)$ for every $12\le n\le24$, complete joint maxima through $n=6$, and equality in the odd arc-budget bound at $m=37,39,\ldots,47$. These finite theorems are additional to the infinite families above.
7. For every sufficiently large $n$, every integer budget
   $$\left\lceil10n^{3/2}\sqrt{\log n}\right\rceil\le m\le n(n-3)$$
   attains $M(n,m)=n(n-1)-m$. This is an exact-budget existence theorem, combining a probabilistic argument with explicit dense constructions; its asymptotic onset is not asserted to be small.
8. The final dense band is completely determined for every $n\ge75$:
   $$M\bigl(n,n(n-3)+r\bigr)=2n-r-\left\lceil\frac r2\right\rceil-1,
   \qquad 1\le r\le n.$$
   Explicit constructions attain every budget. Together with the value $2n$ at $r=0$ and zero beyond $r=n$, this classifies all $m\ge n(n-3)$.
9. Explicit constructions also attain every integer budget $3n\le m\le4n$ for every $n\ge73$. A greedy extension of a Sidon move set supplies a larger parametrized interval, without relying on a probabilistic existence argument.
10. On prime-square orders $n=p^2$, $p\ge5$, an algebraic construction attains every integer budget $4n\le m\le n(p-1)$. On orders $n=5k$, $k\ge16$, an asymmetric local certificate attains every integer budget $2n\le m\le3n$. A smaller local certificate gives $2n\le m\le11n/5$ already for $k\ge10$.

The general arguments are ordinary mathematical proofs. The accompanying Lean development formalizes the actual alternating game, a certificate-to-strategy theorem, safe branching, camping obstructions, a complete universally winning 12-vertex example, complementary-block two-move delivery, and the numerical staircase deduction from explicit counting hypotheses. The graph-to-counting bridge and existence of attaining blocks remain ordinary arguments. It does not claim to formalize all the general extremal theorems.

# The game and its elementary structure

Let $G=(V,E)$ be a finite loopless digraph. Opposite arcs are allowed. A legal move from $x$ goes to $x$ or to an outgoing neighbor; write
$$C(x)=\{x\}\cup N^+(x).$$
Fix $s,t\in V$ and $c\ne s$. If $s=t$, receipt has already occurred. Otherwise the messenger moves first. On its turn it chooses $v\in C(s)$. If $v=t$, delivery wins immediately. If $v\ne t$ and $v=c$, it is captured. Otherwise the pursuer chooses $c'\in C(c)$; equality $c'=v$ is capture. The process repeats. Infinite play without delivery is a messenger loss.

Let $W_G(s,t)$ mean that, for every initial $c\ne s$, there exists a messenger strategy guaranteeing delivery against every pursuer strategy. The messenger observes $c$; its strategy may depend on it. Then
$$
I(G)=\#\{(s,t):s\ne t,\ (s,t)\notin E,\ W_G(s,t)\}.
$$
If $w(G)$ counts all guaranteed pairs including the diagonal, then exactly
$$w(G)=n+m+I(G).$$

The terminal rule matters. In the directed diamond $s\to a\to t$, $s\to b\to t$, the messenger chooses the intermediate vertex not occupied by the pursuer and delivers on its next turn. But reaching a vertex that would be safe as a *recipient* does not justify using it as an intermediate stop. The pursuer gets an intervening move before the message can be forwarded again.

![Two routes allow a guaranteed indirect delivery. Adding the arc from a to b lets a pursuer at a block both first moves.](figures/diamond.pdf)

## Camping obstructions

**Lemma 1 (source domination).** If $c\ne s$ and $N^+(s)\subseteq C(c)$, there is no guaranteed indirect pair with source $s$.

**Proof.** The pursuer starts at $c$ and waits while the messenger waits. Every nonterminal departure from $s$ is either an immediate collision or is captured on the following pursuer turn. Waiting forever is not delivery. $\square$

**Lemma 2 (predecessor domination).** Put $D_t=N^-(t)$. If $D_t\subseteq C(c)$, an indirect guaranteed source for $t$ must equal $c$.

**Proof.** For any other source the pursuer may start at $c$. Every indirect delivery must first enter $D_t$, where the pursuer can capture before the next messenger turn. $\square$

In particular, a source counted by $I$ has outdegree at least two, and a recipient counted by $I$ has indegree at least two. An indegree-one recipient is blocked by its unique predecessor. In an undirected network, interpreted as two opposite arcs per edge, the pursuer can start at $t$ and catch the messenger upon its first arrival at a neighbor of $t$. Thus $I=0$ for every such network.

The two degree conditions are necessary, not sufficient. Neither the absence of a one-vertex directed separator nor the existence of two internally disjoint routes characterizes this game. Adding $a\to b$ to the diamond destroys its only indirect guarantee, although both routes remain. Consequently $I$ is not monotone under adding arcs.

**Lemma 3 (two-move criterion).** For an indirect pair $(s,t)$, put $B=N^+(s)\cap N^-(t)$. Delivery is guaranteed within two messenger moves exactly when
$$\text{for every }c\ne s,\qquad B\not\subseteq C(c).$$

**Proof.** Choose an intermediate vertex of $B\setminus C(c)$, survive every pursuer response, and deliver. Conversely, any successful two-move indirect delivery must use such an intermediate. Waiting on the first move cannot reach a nonadjacent recipient on the second. $\square$

## Components, zero minima, and the vertex bound

Removing isolated vertices preserves $I$. More generally,
$$I(G\sqcup H)=I(G)+I(H).$$
There are no cross-component routes; a pursuer in the other component cannot interfere with a route in the messenger's component.

**Proposition 4.** At every admissible $(n,m)$ the minimum of $I$ is zero.

**Proof.** For $n\ge2$, list all nonloop arcs row by row and retain the first $m$. There are full outgoing rows, at most one partial row, and empty rows. Full rows have only direct recipients; empty rows cannot move. If a full row exists, its vertex blocks every indirect attempt from the partial row by Lemma 1. Otherwise successors of the partial row have no outgoing arcs, so no indirect route exists. The empty and one-vertex cases are immediate. $\square$

**Theorem 5 (original upper bound).** For every $n\ge3$,
$$I(G)\le n(n-3).$$

**Proof.** A recipient of indegree zero or one has no indirect guaranteed sources. A recipient of indegree $d\ge2$ has at most $n-1-d\le n-3$, after excluding itself and its direct predecessors. Sum over recipients. $\square$

For $n\ge4$, equality forces every recipient to have indegree two and every missing pair to be guaranteed. Every source must then have outdegree at least two; the degree sum forces outdegree exactly two. Conversely, a two-in/two-out-regular graph with every pair guaranteed attains equality. Thus attaining the vertex bound is exactly a sparse universal-delivery construction problem.

# Sharp arc-budget upper bounds

Let $A$ be the vertices of outdegree at least two and $B$ those of indegree at least two. Write $q=|A|$, $r=|B|$, $b=|A\cap B|$, and let $e(A,B)$ count arcs from $A$ to $B$. Every counted pair belongs to $A\times B$, and direct and diagonal pairs are excluded. Hence
$$
I(G)\le qr-b-e(A,B),\qquad
e(A,B)\ge\max\{0,2q+2r-m\}. \tag{1}
$$
The second inequality follows by adding the total outgoing degree in $A$ and incoming degree in $B$: each arc is counted at most once except those in $A\times B$.

We also need two elementary obstructions. If $x$ has indegree zero and $x\to t$ with $t$ of indegree two, then $t$ has no indirect guaranteed sources. Its other predecessor blocks every indirect route: a route from elsewhere cannot reach $x$, while $x\to t$ itself is direct. Dually, if $t$ is a sink, $x\to t$, and $x$ has outdegree two, then $x$ has no indirect guaranteed recipients. Its other successor blocks every potentially successful indirect departure. This dual argument is proved directly and does not assume invariance under reversing the graph.

## Even numbers of arcs

**Theorem 6.** If $m=2k$ and $k\ge5$, then
$$I(G)\le k(k-3).$$

**Proof.** We have $q,r\le k$. Applying (1), with $b\ge0$, gives the bound except possibly when $(q,r)$ is one of
$$ (k,k),\quad(k-1,k),\quad(k,k-1). $$
For completeness, this numerical reduction follows by maximizing the bilinear expression $qr-\max(0,2q+2r-2k)$ on the two regions $q+r\le k$ and $q+r\ge k$: on each horizontal or vertical segment its maximum occurs at an endpoint. Outside the three displayed corners the maximum is at most $k(k-3)$ for $k\ge5$.

If $q=r=k$, every arc starts in $A$ and ends in $B$, and all these outgoing and incoming degrees equal two. If $A=B$, (1) gives $k^2-k-2k$. Otherwise choose $x\in A\setminus B$. It has indegree zero. Its two successors are zero-contribution recipient columns. The other $k-2$ columns each receive two direct arcs from $A$, giving
$$I(G)\le k(k-2)-2(k-2)=(k-2)^2\le k(k-3).$$

If $q=k-1,r=k$, (1) gives $I\le k(k-3)+2-b$, so $b\ge2$ suffices. Otherwise there is an indegree-zero vertex of $A\setminus B$. Its two successor columns contribute zero. The other $k-2$ columns receive $2k-4$ arcs in total; at most two start outside $A$. Therefore
$$I(G)\le(k-1)(k-2)-(2k-6)=k^2-5k+8\le k(k-3).$$
The case $q=k,r=k-1$ uses the sink obstruction to remove two zero source rows and gives the same bound. $\square$

## Odd numbers of arcs

**Theorem 7.** If $m=2k+1$ and $k\ge5$, then
$$I(G)\le k(k-3)+2.$$

**Proof.** Again $q,r\le k$, and (1) suffices outside the same three corners. If $r=k$, the total excess incoming degree in $B$, together with all arcs ending outside $B$, is at most one. Thus at most one vertex outside $B$ has positive indegree. An indegree-zero source in $A$ has an indegree-two successor: either every vertex of $B$ has indegree two and at most one arc ends outside $B$, or one vertex of $B$ has indegree three and every arc ends in $B$. Its at least two distinct successors cannot all be exceptions. This gives a zero recipient column.

Suppose $q=k-1,r=k$. Formula (1) gives $I\le k(k-3)+3-b$, so $b\ge1$ suffices. If $b=0$, choose an indegree-zero member of $A$. Remove a zero recipient column. The other $k-1$ columns receive at least $2k-2$ arcs, at most three of which start outside $A$, giving
$$I\le(k-1)^2-(2k-5)=k^2-4k+6\le k(k-3)+2.$$
The symmetric corner uses the zero-row argument.

Finally let $q=r=k$. Formula (1) suffices when $b\ge k-1$. If $2\le b\le k-2$, there is an indegree-zero source in $A\setminus B$, hence a zero column. The remaining columns contain at least $2k-3$ direct pairs and at least $b-1\ge1$ diagonal pairs. Thus
$$I\le k(k-1)-(2k-3)-1=k(k-3)+2.$$
If $b\le1$, at least $k-2\ge3$ vertices of $A\setminus B$ have indegree zero. Each has an indegree-two successor, and at most two can share any such successor. There are consequently at least two zero columns. The others contain at least $2k-5$ direct pairs, so
$$I\le k(k-2)-(2k-5)=k^2-4k+5\le k(k-3)+2.$$
This completes the proof. $\square$

## Equality structure

**Theorem 8.** For $k\ge6$, equality in Theorem 6 holds exactly when deleting isolated vertices leaves a two-in/two-out-regular graph on $k$ vertices with every pair guaranteed.

**Proof.** The numerical bounds away from the three corners are strict. In the $(k-1,k)$ corner, a member of $A\setminus B$ gives the strict zero-column estimate above; if $A\subseteq B$, then $b=k-1$ gives a strict bound directly. The other corner is analogous. In the $(k,k)$ corner, $A\ne B$ gives the strict bound $(k-2)^2$. Hence $A=B$, all $2k$ arcs lie on these $k$ vertices, and all incoming and outgoing degrees equal two. Equality then says that every eligible missing pair is guaranteed. $\square$

**Theorem 9.** For $k\ge6$, equality in Theorem 7 holds exactly for graphs whose nonisolated support has the following properties: it has $k+1$ vertices; one vertex $u$ has outdegree one and indegree two; a different vertex $v$ has indegree one and outdegree two; all other degrees are two; $u\to v$ is absent; and every missing nonloop pair with source of outdegree two and recipient of indegree two is guaranteed.

**Proof.** Strengthening the strict inequalities in Theorem 7 excludes all cases except $q=r=k$ and $b=k-1$. In the corner $(q,r)=(k-1,k)$, values $b\ge2$ are strict directly. If $b\le1$, at least $k-2$ members of $A$ lie outside $B$, and at most one has positive indegree. The zero-column argument gives $I\le k^2-4k+6<k(k-3)+2$. The dual corner uses the zero-row argument. In the remaining $(k,k)$ corner, for $b=2$ at least three indegree-zero sources give two zero columns; for $3\le b\le k-2$ the one-column argument retains at least two diagonal exclusions. The other excluded cases already have strict bounds for $k\ge6$.

Write $A\setminus B=\{v\}$ and $B\setminus A=\{u\}$. Equality forces $e(A,B)=2k-1$. The outgoing degree sum in $A$ and incoming degree sum in $B$ are each at least $2k$, while their sum is at most $m+e(A,B)=4k$. Thus all these degrees equal two. Exactly one arc starts outside $A$ and one ends outside $B$, and they are distinct. Vertex $v$ cannot have indegree zero: it would give a zero column containing at least $k-3>0$ eligible missing pairs. Hence it receives the unique arc ending outside $B$. Dually $u$ emits the unique arc starting outside $A$. Every vertex outside $A\cup B$ is isolated, and the two exceptional arcs being distinct implies that $u\to v$ is absent. Counting gives the converse. $\square$

Adding the missing arc $u\to v$ in Theorem 9 gives a two-regular digraph. It is not asserted that this completed graph is automatically universally winning.

# Sparse constructions with a linear deficit

## A safe branching principle

**Lemma 10.** Suppose distinct vertices have closed move sets intersecting in at most one vertex. If a vertex $r$ has two distinct outgoing neighbors that each guarantee delivery to $t$, then $r$ guarantees delivery to $t$.

**Proof.** For every pursuer position $c\ne r$, one of the two successors lies outside $C(c)$. Move there. It survives every intervening pursuer response, after which its guaranteed strategy applies. If the chosen vertex is $t$, delivery is already terminal. This is a finite concatenation of actual strategies. $\square$

**Theorem 11.** Let $a\ge3$, $h=2a+1$, $n\ge2h+1$, and $\gcd(n,h)=1$. The digraph on $\mathbb Z/n\mathbb Z$ with outgoing steps $1,a,h$ has every pair guaranteed. It has $3n$ arcs and
$$I(G)=n(n-4).$$

**Proof.** The positive differences in $\{0,1,a,2a+1\}$ are
$$1,\ a-1,\ a,\ a+1,\ 2a,\ 2a+1,$$
all distinct. Since $n>2h$, no positive difference coincides modulo $n$ with a negative one. Distinct closed move sets therefore intersect in at most one vertex.

Translate the recipient to zero. Vertices $0,-1,-a,-h$ are already delivered or have direct arcs to it. Vertex $-a-1$ is guaranteed via its neighbors $-a,-1$. Thus all four vertices
$$Q(z)=\{z,z-1,z-a,z-a-1\}$$
are guaranteed for $z=0$. If $Q(z)$ is guaranteed, apply Lemma 10 in the following order:

| New source | Two guaranteed successors |
|:--|:--|
| $z-h$ | $z-a-1,\ z$ |
| $z-h-1$ | $z-h,\ z-1$ |
| $z-h-a$ | $z-h,\ z-a$ |
| $z-h-a-1$ | $z-h-a,\ z-a-1$ |

This proves $Q(z-h)$. Iterating at most $n-1$ times covers every vertex because $h$ is coprime to $n$. The induction is finite; it supplies terminating strategies, not merely perpetual evasion. Finally subtract the $n$ diagonal pairs and $3n$ arcs from $n^2$. $\square$

![A guaranteed quartet produces the next quartet seven positions earlier in the step-1,3,7 construction.](figures/quartet.pdf)

The choice $a=3$ proves the theorem for every $n\ge15$ not divisible by seven. Adding an isolated vertex gives a linear-deficit construction for the remaining large sizes as well. The next elementary lemma removes that padding and improves the constant.

**Lemma 12.** For every $n\ge25$, there is an odd integer $h$ with $7\le h<n/2$ and $\gcd(n,h)=1$.

The proof and its explicit choices are included in the construction appendix below. Taking $a=(h-1)/2$ gives, for every $n\ge25$,
$$n(n-4)\le M_V(n)\le n(n-3),\qquad 3n\le n^2-M_V(n)\le4n.$$
Neither equality in the lower bound nor equality in the upper bound is asserted for arbitrary $n$.

# The dense boundary

**Theorem 13.** For $n\ge2$,
$$M(n,n(n-2))=\left\lfloor\frac{n-2}{2}\right\rfloor,$$
and $M(n,m)=0$ for every admissible $m>n(n-2)$.

**Proof.** If $(s,t)$ is indirect guaranteed, row $s$ misses $s\to t$. By Lemma 1, every other row $c$ must miss an arc into $N^+(s)$. Thus every row misses at least one nonloop arc, and $m\le n(n-2)$.

Now suppose $m=n(n-2)$. If $I=0$, the upper bound is immediate. Otherwise the preceding argument shows that every row misses exactly one arc; write $f(v)$ for its endpoint. Necessarily $f(v)\ne v$. A possible indirect pair is $(s,f(s))$. Lemma 1 says
$$ f^{-1}(s)=\varnothing,\qquad f^{-1}(f(s))=\{s\}. \tag{2}$$
These conditions suffice: for initial pursuer $c\ne s$, choose the intermediate $f(c)$. It is different from $s,f(s)$, is inaccessible on the pursuer's next move, and has an arc to $f(s)$. This is a two-move guarantee.

Pairs satisfying (2) have disjoint source and target vertices. If there are $j$ pairs, the remaining vertices contain a cycle of the loopless functional graph of $f$ and therefore number at least two. Hence $2j\le n-2$. For attainment use pairs $s_i\to t_i$ in the missing-arc graph, send every $t_i$ to $a$, put $a\leftrightarrow b$, and send any remaining vertex to $a$. Take all nonloop arcs except these missing arcs. $\square$

![The missing arcs at the dense boundary form a functional graph. Each displayed two-vertex branch contributes one guaranteed indirect pair.](figures/dense-boundary.pdf)

**Theorem 14.** A noncomplete graph with every pair guaranteed has at most $n(n-3)$ arcs.

**Proof.** Such a graph has an indirect pair. No row can be complete: its vertex would block every indirect source other than itself and have no indirect target of its own. If a row $c$ missed only $c\to t$, then $N^+(t)\subseteq C(c)$. Vertex $t$ also has an indirect recipient, contradicting Lemma 1. Every row therefore misses at least two arcs. $\square$

The next section gives a uniform construction attaining this density on an infinite set of orders. Its proof is independent of the sparse-game certificate for the complementary graph proved later.

## A periodic family with three-move delivery

Let $n=5k$, $k\ge4$, and write vertices as $5i+j$, with $i$ modulo $k$ and $0\le j\le4$. Put $\alpha(v)=v+1$ and
$$
\begin{aligned}
\beta(5i)&=5(i+1),&\beta(5i+1)&=5(i-1)+2,\\
\beta(5i+2)&=5(i-1)+4,&\beta(5i+3)&=5(i-1)+3,\\
\beta(5i+4)&=5(i-1)+1.
\end{aligned}
$$
Let $H$ have arcs $v\to\alpha(v),v\to\beta(v)$, and let $G$ be its loopless directed complement. Both maps are permutations, without fixed points or coincident images at a vertex; thus $G$ has $n(n-3)$ arcs.

**Theorem 15.** Every pair in $G$ is guaranteed within three messenger moves. Consequently $M(5k,5k(5k-3))=10k$ for every $k\ge4$.

**Proof.** For a missing pair $(s,t)$ and initial pursuer $c\ne s$, a safe two-move intermediate is any member of
$$\{\alpha(c),\beta(c)\}\setminus F(s,t),\qquad
F(s,t)=\{s,t,\alpha(s),\beta(s),\alpha^{-1}(t),\beta^{-1}(t)\}.$$
Its exclusion from $F$ ensures the two required arcs in $G$, while its membership in the displayed pair makes it inaccessible to the pursuer's next move.

Translate the source by a multiple of five so that $0\le s\le4$. A failure requires $c\in F-1$, since $\alpha(c)\in F$. The complete local calculation is:

| $s$ | $t$ | $F(s,t)$ | $(c,\beta(c))$, with $c\in F-1$, $c\ne s$ |
|--:|--:|:--|:--|
| 0 | 1 | $\{0,1,5,9\}$ | $(-1,-9),(4,-4),(8,3)$ |
| 0 | 5 | $\{0,1,4,5\}$ | $(-1,-9),(3,-2),(4,-4)$ |
| 1 | 2 | $\{-3,1,2,6\}$ | $(-4,-8),(0,5),(5,10)$ |
| 1 | $-3$ | $\{-4,-3,1,2\}$ | $(-5,0),(-4,-8),(0,5)$ |
| 2 | 3 | $\{-1,2,3,8\}$ | $(-2,-7),(1,-3),(7,4)$ |
| 2 | $-1$ | $\{-2,-1,2,3\}$ | $(-3,-6),(-2,-7),(1,-3)$ |
| 3 | 4 | $\{-2,3,4,7\}$ | $(-3,-6),(2,-1),(6,2)$ |
| 3 | $-2$ | $\{-3,-2,3,4\}$ | $(-4,-8),(-3,-6),(2,-1)$ |
| 4 | 5 | $\{-4,0,4,5\}$ | $(-5,0),(-1,-9),(3,-2)$ |
| 4 | $-4$ | $\{-5,-4,4,5\}$ | $(-6,-14),(-5,0),(3,-2)$ |

The only candidate with $\beta(c)\in F$ is $(s,t,c)=(4,5,-5)$. Every difference being tested has absolute value at most 19, so no extra equality appears modulo any $5k\ge20$. In that exceptional state move from 4 to 0. This is legal and safe: the pursuer at $-5$ has no arc to 0. Afterwards the pair $(0,5)$ is covered by the nonexceptional second row for every surviving pursuer position, and delivery takes at most two more moves. $\square$

# Correcting the original layered construction

The original graph remains a useful construction, but its printed count is not correct. We give its exact count and separate safe intermediate movement from terminal delivery.

Let $q=2x$, $a=\binom{2x}{x}/2$, and choose a family $\mathcal F$ containing one of each complementary pair of $x$-subsets of $[2x]$, with every coordinate occurring in exactly $a/2$ members. Such a family exists precisely when positive $x$ is not a power of two; a proof follows below.

There are row vertices $A_X,A'_X$ for $X\in\mathcal F$, and coordinate vertices $b_i,b'_i,c_i,c'_i$ for $i\in[q]$. The only arcs are

- $A_X\to b_i,b'_i$ when $i\in X$;
- $b_i\to A'_Y$ when $i\in Y$, and $b'_i\to A'_Y$ when $i\notin Y$;
- $A'_Y\to c_i,c'_i$ when $i\in Y$;
- $c_i\to A_X$ when $i\in X$, and $c'_i\to A_X$ when $i\notin X$.

The order is $N=2a+4q$. The four directed layers are $A$, $B\cup B'$, $A'$, $C\cup C'$.

**Theorem 16.** For the balanced original family,
$$I(G)=2a(N-1-q)+4q.$$
At $x=3$, the 44-vertex graph has exactly 764 indirect guaranteed pairs, rather than the draft's claimed lower bound of 1252.

**Proof.** The rows form an antichain. The $2q$ literal columns, indicating membership or nonmembership of each coordinate, also form an antichain, with size $a/2\ge5$. They cannot coincide: equality on the selected rows would remain true on their complements and hence on every $x$-subset, which is impossible for distinct literals. Every vertex has at least two successors.

From any noncollision state the messenger can safely advance one layer. If both players are in the same layer, use incomparable outgoing neighborhoods to choose a successor inaccessible to the pursuer. If the pursuer is in the next layer, avoid its occupied vertex; it has no within-layer arc. In the other two cases it cannot reach the next layer in one move. This includes waiting responses.

From $A_X$ to a specified $A'_Y$ there is a two-move guarantee. Against a pursuer $A_Z$, choose a coordinate in $X\setminus Z$, then choose its primed or unprimed intermediate according to membership in $Y$. Against a pursuer in the intermediate layer, choose another coordinate of $X$; the other layers cannot interfere. The reverse direction is identical. Safely advancing to the appropriate row layer first therefore gives delivery to any row recipient in at most five moves. There are $2a$ such recipients, each with $N-1-q$ indirect sources.

For target $b_i$ or $b'_i$, its predecessor set is exactly $N^+(c_i)$. Lemma 2 excludes every indirect source except $c_i$. That exceptional source wins in two moves: literal-column incomparability handles a pursuer in its own layer, and the other layer cases are as above. Thus $(c_i,b_i)$ and $(c_i,b'_i)$ both count. Symmetrically $(b_i,c_i)$ and $(b_i,c'_i)$ count, and no other indirect sources do. These give exactly $4q$ further pairs. $\square$

The correction preserves the original $N^2-O(N\log N)$ leading estimate along its constructed orders. The new circulant family supplies the stronger linear-deficit result at every sufficiently large order. The original construction's regular incidence design and the later extremal construction are distinct contributions.

## Balanced complementary halves

**Lemma 17.** For positive $x$, the $x$-subsets of $[2x]$ can be partitioned into two coordinate-balanced families with complementary subsets in opposite families if and only if $x$ is not a power of two.

**Proof.** Put $C=\binom{2x}{x}$. Each coordinate occurs in $C/2$ subsets, so balance requires $4\mid C$. The factorial valuation formula gives
$$v_2\binom{2x}{x}=s_2(x),$$
where $s_2(x)$ is the number of ones in the binary expansion. Thus divisibility by four is equivalent to $x$ not being a power of two.

For sufficiency, distinguish coordinate $2x$ and cyclically rotate the other $L=2x-1$ coordinates. Subsets containing $2x$ correspond to binary circular words with $x-1$ ones and $x$ zeros. Every orbit has length $L$: a proper repetition would have a repetition count dividing both consecutive integers. The number $C/(2L)$ of orbits is even, since $L$ is odd and $4\mid C$.

Choose half of those orbits. In the first family put their subsets, and put the complements of the subsets in the unchosen orbits. Exactly one of each complementary pair is selected. The distinguished coordinate occurs $C/4$ times. Rotation invariance gives a common incidence count $r$ for every other coordinate; counting all incidences yields
$$ (2x-1)r+C/4=xC/2,$$
so $r=C/4$. The other family is balanced as well. $\square$

This proof replaces the draft's incorrect stronger divisibility assertion $4x\mid\binom{2x}{x}$, which already fails at $x=3$.

# High-girth complements and exact dense intervals

The preceding periodic construction attains the largest possible density of a noncomplete all-delivery network on an arithmetic progression. A different construction handles every sufficiently large order and an interval of arc counts. Here the sparse graph specifies the connections to omit from an otherwise complete directed network.

**Lemma 18 (high-girth complement).** Let $F$ be an orientation of a finite simple undirected graph of girth at least six. Suppose every vertex has outdegree at least two in $F$. Let $G$ contain exactly the nonloop arcs absent from $F$. Then every source–recipient pair in $G$ is guaranteed within two messenger moves.

**Proof.** Diagonal and direct pairs need no argument. For a missing pair $(s,t)$ of $G$, the arc $s\to t$ belongs to $F$. Set
$$
B=N_F^+(s)\cup N_F^-(t).
$$
Both $s$ and $t$ belong to $B$. In the underlying undirected graph, the vertices of $B$ form an induced double star: its centers are $s,t$, the other outneighbors of $s$ are leaves at $s$, and the other predecessors of $t$ are leaves at $t$. The two sets of leaves are disjoint, since an overlap would make a triangle. An additional edge inside $B$ would make a triangle or quadrilateral. Thus the distance between any two vertices in this induced tree is at most three.

Fix an initial pursuer vertex $c\ne s$. If $c\notin B$, two neighbors of $c$ in $B$ would form an undirected cycle of length at most five, so $c$ has at most one outgoing $F$-neighbor in $B$. The same bound holds when $c\in B\setminus\{s\}$: a leaf at $s$ has its only incident edge in the tree directed toward it; a leaf at $t$ has only its edge toward $t$; and all tree edges incident with $t$ point into $t$.

Since $c$ has at least two outgoing $F$-neighbors, choose
$$u\in N_F^+(c)\setminus B.$$
Then $u\ne s,t$, and $s\to u$ and $u\to t$ are arcs of $G$. Also $u\ne c$ and $c\to u$ is absent from $G$. The messenger moves to $u$, survives every pursuer response, and delivers to $t$ on its next turn. $\square$

The lemma only requires a lower bound on outgoing degrees. In particular, edges can later be added to the underlying graph and oriented arbitrarily, provided its girth remains at least six.

**Theorem 19 (the densest noncomplete all-delivery networks).** For every $n\ge52$,
$$M(n,n(n-3))=2n.$$
An attaining graph guarantees every pair within two messenger moves. The construction for $n\ge130$ has the ordinary proof below; the extension to $52\le n<130$ uses an explicit finite structural certificate.

**Proof.** We first construct a four-regular undirected graph of girth at least six at each required order. Orient an Euler tour in each of its components. Every vertex then has two incoming and two outgoing arcs. Such tours exist by the elementary closed-trail construction: even degrees prevent an unused-edge trail from stopping away from its starting vertex, and further closed trails can be spliced into the first until all edges of the component have been used. Lemma 18 applies to the resulting orientation $F$. It has $2n$ arcs, so its directed complement has $n(n-3)$ arcs and exactly $2n$ missing pairs, all guaranteed. The missing-pair count is also an upper bound for $I$.

For a building block, take point vertices $p\in\mathbb Z/13\mathbb Z$ and line vertices $\ell\in\mathbb Z/13\mathbb Z$, joining them when
$$p-\ell\in\{0,1,3,9\}.$$
This graph has 26 vertices and is four-regular. The twelve ordered differences between distinct members of $\{0,1,3,9\}$ are precisely the twelve nonzero residues modulo 13. Consequently two distinct points cannot have two common line neighbors: the two common neighbors would give two representations of the same nonzero difference. There is no four-cycle. Bipartiteness excludes odd cycles, so the girth is at least six.

The following operation increases the order by one. Choose edges $ab$ and $cd$ such that every endpoint of the second is at distance at least four from every endpoint of the first. Delete these two edges, add a new vertex $x$, and join $x$ to $a,b,c,d$. The endpoints are distinct and all degrees remain four. Any new cycle uses two of these new edges. If their old endpoints belonged to the same removed edge, the path between them after its removal has length at least five, giving a new cycle of length at least seven. Otherwise their old distance was at least four, giving a new cycle of length at least six. Thus the operation preserves the required girth.

Such an edge pair exists in every four-regular graph with more than 120 vertices. Fix an edge $ab$ and let $S$ consist of the vertices within distance three of $a$ or $b$. The branching bound from the two ends of the edge gives
$$|S|\le2(1+3+9+27)=80.$$
The induced graph on $S$ is connected, hence has at least $|S|-1$ edges. If there were no edge with both endpoints outside $S$, four-regularity would give
$$
4|V\setminus S|=e(S,V\setminus S)
=4|S|-2e(S)
\le2|S|+2.
$$
It would follow that
$$n\le\left\lfloor\frac{3|S|+1}{2}\right\rfloor\le120.$$
Therefore an outside edge exists and can serve as $cd$.

Start with five disjoint copies of the 26-vertex building block. Repeated insertion now gives every order $n\ge130$. For the smaller stated orders, two disjoint building blocks give order 52. The supplied certificate lists 78 admissible insertions, producing every order from 52 through 130. Each insertion satisfies the same distance condition and therefore has the proof of correctness just given. Its finite verification is described below. $\square$

The density $n(n-3)$ is maximal among noncomplete all-delivery graphs, by the earlier dense-boundary theorem. This construction therefore settles the joint extremum at that density for every $n\ge52$; it is not a claim about the arc-only maximum at the same number of arcs.

**Finite-certificate reproduction.** The file `research/extremal-bounds-girth-growth.json` records the two removed edges at every insertion, starting from the explicit 52-vertex graph above. The generator and replayer `src/extremal_bounds_girth_family.py` checks the endpoint distances, all degrees, and the absence of short cycles. A separate implementation, `src/extremal_bounds_girth_verify.py`, rebuilds the incidence graph directly and checks girth by enumerating simple paths and testing whether they close into cycles of lengths three, four, or five. It verifies all 79 graph orders independently of the generator's edge-deleted breadth-first checks. The receipt `research/extremal-bounds-girth-verification.json` records the certificate and verifier hashes. These are finite graph certificates attached to the proved insertion rule, not extrapolation from successful pursuit-game searches. They are executable checks rather than a Lean formalization; omitting this finite certificate leaves the ordinary theorem for every $n\ge130$.

**Theorem 20 (an interval of exact dense extrema).** Fix integers $n\ge52$ and $5\le D\le n-1$, and put
$$
\begin{aligned}
B_D&=1+D\bigl(1+(D-1)+(D-1)^2+(D-1)^3\bigr)\\
   &=D^4-2D^3+2D^2+1,\\
L_D(n)&=\left\lfloor\frac{Dn-(D-4)B_D}{2}\right\rfloor.
\end{aligned}
$$
For every integer $h$ satisfying $2n\le h\le L_D(n)$,
$$M(n,n(n-1)-h)=h.$$
Each equality is attained by an all-delivery graph with a two-move strategy. An empty interval makes no assertion.

**Proof.** Begin with the four-regular girth-six graph from Theorem 19. Repeatedly add an undirected edge between two vertices of current degree less than $D$ whose distance is at least five. Vertices in different components have infinite distance. Each addition preserves simplicity, the degree cap $D$, and girth at least six.

When no further addition is possible, let $U$ be the vertices of degree less than $D$. If $U$ is nonempty, all its vertices lie within distance four of any fixed member of $U$. A graph of maximum degree $D$ has at most $B_D$ vertices in such a ball, so $|U|\le B_D$. This inequality also holds when $U$ is empty. The minimum degree remains at least four. The final edge count is consequently at least
$$
\frac{D(n-|U|)+4|U|}{2}
\ge\frac{Dn-(D-4)B_D}{2}.
$$
Starting from $2n$ edges and adding one edge at a time produces a graph with every edge count through $L_D(n)$.

Orient the initial four-regular graph by Euler tours, and orient each added edge arbitrarily. Each vertex retains its original two outgoing arcs. Applying Lemma 18 at the stage with $h$ edges gives a directed complement with $n(n-1)-h$ arcs and all its $h$ missing pairs guaranteed. No graph with that arc count can have more than $h$ indirect pairs. $\square$

The statement has both order and density as parameters. For example, $B_D\le D^4$ for $D\ge2$. When $n\ge2D^4$, the displayed bound gives
$$L_D(n)\ge n(D/4+1)-1.$$
Thus choosing $D=\lfloor(n/2)^{1/4}\rfloor$ for sufficiently large $n$ yields exact joint extrema for an interval of missing-arc counts extending to a positive constant times $n^{5/4}$. As with Theorem 19, the range $n\ge130$ has an ordinary construction, while the extension down to 52 uses the explicit finite certificate.


# An infinite family attaining the sparse bounds

The five-type graph used in the dense construction also attains the sparse vertex and arc-budget bounds. This requires a different strategy: its messenger may need to travel around a substantial part of the ring. The proof combines fixed local certificates with a simulation valid at every sufficiently large circumference, followed by six finite base cases.

For clarity, define the sparse graph $H_k$ again. Its vertices are
$$ (i,j)\in (\mathbb Z/k\mathbb Z)\times\{0,1,2,3,4\}.$$
The first outgoing arc follows the cycle
$$(i,0)\to(i,1)\to(i,2)\to(i,3)\to(i,4)\to(i+1,0).$$
The second outgoing arc is specified by
$$
\begin{aligned}
(i,0)&\to(i+1,0), & (i,1)&\to(i-1,2),\\
(i,2)&\to(i-1,4), & (i,3)&\to(i-1,3),\\
(i,4)&\to(i-1,1).
\end{aligned}
$$
Both arc maps are permutations, are loopless, and have distinct images at every vertex when $k\ge4$. Hence $H_k$ has $5k$ vertices and $10k$ arcs, with indegree and outdegree two everywhere. Waiting is an additional legal action, as throughout the paper.

![The five station types in consecutive columns. Black arrows follow the long cycle and blue arrows give the second permutation. Identifying columns modulo k closes the strip into the graph H_k.](figures/five-type-strip.pdf)

**Theorem 21 (uniform sparse attainment).** For every integer $k\ge4$, every source–recipient pair in $H_k$ is guaranteed. Consequently
$$
M_V(5k)=5k(5k-3),\qquad
M_E(10k)=5k(5k-3).
$$
For $k\ge10$, a sufficient delivery time is $8k+16$ messenger moves. The theorem is computer-assisted: its finite ingredients are the two local objectives specified below and the six rings $4\le k\le9$.

## The stronger local arena

Unwrap the column coordinate to the integers, retaining the same two arc rules. Confine the messenger to columns $-3,\ldots,3$, disallowing moves out of this interval. Represent the pursuer by its exact vertex in columns $-4,\ldots,4$, together with an exterior state $\Omega$. Thus there are 35 messenger positions and 46 pursuer positions.

Within its nine-column window the pursuer has all its usual moves and its wait; a move leaving the window goes to $\Omega$. From $\Omega$ it may wait or enter any vertex of either boundary column $-4$ or $4$. This grants more freedom than a particular physical pursuer outside the window. The messenger and $\Omega$ can never coincide.

The two objectives have different stopping rules:

- A **safe transfer** ends in column zero at the start of a messenger turn, with the positions distinct. Entering column zero on a messenger move is insufficient: the intervening pursuer response must also be survived.
- A **delivery** ends immediately when the messenger enters a specified vertex $(0,t)$, before collision is checked there, exactly as in the original game.

For each objective, the certificate assigns nonnegative integer ranks to winning states and selects a legal move at every positive-rank messenger state. Every selected move decreases rank, and every legal response at a positive-rank pursuer state also decreases rank. The zero-rank states are precisely the applicable terminal successes. These conditions prove termination by induction on rank. For safe transfer, only noncollision **messenger-turn** states in column zero are seeded as successes; pursuer-turn states there still require all their responses to be safe.

The checked finite bounds are:

| Local objective | Initial column | Initial noncollision states | Maximum messenger moves |
|:--|--:|--:|--:|
| Safe transfer to column zero | 1 | 225 | 8 |
| Delivery to $(0,0)$ | 2 | 225 | 24 |
| Delivery to $(0,1)$ | 2 | 225 | 16 |
| Delivery to $(0,2)$ | 2 | 225 | 16 |
| Delivery to $(0,3)$ | 2 | 225 | 17 |
| Delivery to $(0,4)$ | 2 | 225 | 18 |

Each row covers all five source types and all 46 pursuer states other than the source itself. In particular, it includes an initially exterior pursuer. Only the bounds 8 and 24 are needed below; optimality of these local times is not claimed as a separate result.

## Projection to a ring

Fix $k\ge10$ and any reference column. Its nine offsets $-4,\ldots,4$ represent distinct columns of the ring. Map a physical pursuer in this window to its exact local position and every other pursuer position to $\Omega$.

Every physical pursuer move has a permitted image. A move within the window is unchanged, one leaving it goes to $\Omega$, and a move remaining outside is represented by waiting at $\Omega$. A move from outside into the window can enter only a boundary column, because each arc changes the column by at most one; every such entry is permitted from $\Omega$. At $k=10$ the exterior consists of a single column adjacent to both boundaries, and both entries are already allowed. At $k=9$ the two boundary columns themselves have wraparound adjacencies, so this argument would fail; those rings are deliberately covered by finite checks instead.

Every messenger move permitted by the local certificate is a genuine ring move. Its seven represented columns lie strictly inside the pursuer window. Consequently a physical collision with the messenger is exactly a local collision; an exterior pursuer cannot coincide with it. Following a local winning strategy therefore succeeds against every physical pursuer strategy. This is a simulation of legal moves and collisions, not an assumption that winning strategies pass automatically to graph covers.

## Composition and termination

**Proof of Theorem 21.** Translate the recipient's column to zero, and let the messenger's current column be $d$. Translate the safe-transfer window so that its local column zero is the physical column $d-1$; the messenger then starts in local column one. The certificate reduces its physical column by one modulo $k$ and finishes only after the pursuer's response, so another transfer can begin with the correct turn order. Recenter the window between transfers; each new local certificate is valid for every resulting noncollision pursuer position.

After the least nonnegative residue of $d-2$ modulo $k$ such transfers, at most $k-1$, the messenger is in column two. Apply the delivery certificate for the recipient's type. This takes at most
$$8(k-1)+24=8k+16$$
messenger moves. If a transfer encounters the actual recipient earlier, terminal receipt wins immediately and only shortens the play. Thus the argument guarantees finite delivery, not merely indefinite safe movement.

For $4\le k\le9$, the explicit finite-ring certificates verify every source and pursuer position for each of the five recipient types in column zero. Translating columns gives every recipient. These six checks, together with the uniform argument for $k\ge10$, establish universality for all $k\ge4$.

Finally, a universal graph with $n=5k$ vertices and $2n$ arcs has
$$I(H_k)=n^2-n-2n=n(n-3).$$
The vertex upper bound and the even arc-budget upper bound both equal this number. Hence both asserted extremal equalities follow. $\square$

**Certificate reproduction and scope.** The file `research/five-type-certificates.json` contains the fixed local arena, ranks, and chosen messenger moves, generated and directly checked by `src/five_type_certificate.py`. The independent implementation `src/five_type_local_verify.py` constructs the explicit alternating-state graph from the arc rules and checks every winning rank condition, as well as closure of the losing region. Its full ranks and selected moves are saved in `research/five-type-independent-local-certificates.json`, together with the implementation hash. Both implementations agree on the six local bounds above. The six finite bases are stored in `research/five-type-small-ring-certificates.json`, including complete arc lists, messenger-move layers, and explicit alternating-state rank certificates for the five representative recipient types. The script `src/five_type_small_certificates.py` reproduces those checks using both game solvers and verifies every certificate transition. The ordinary projection and composition proof explains why these finite arrays certify infinitely many rings. This theorem is not currently claimed as a Lean formalization.

**Corollary 22 (sharp arc-budget leading term).** As $m\to\infty$,
$$M_E(m)=\frac{m^2}{4}-O(m).$$
More explicitly, for every $m\ge40$,
$$\frac{m^2}{4}-6m\le M_E(m)\le\left\lfloor\frac m2\right\rfloor^2.$$

**Proof.** Set $k=\lfloor m/10\rfloor\ge4$ and $r=m-10k$, so $0\le r\le9$. Take $H_k$ together with $r$ disjoint one-way arcs. Each added component has no indirect guaranteed pair, and additivity over components preserves $I(H_k)$. This graph has exactly $m$ arcs and
$$
I=25k^2-15k
=\frac{(m-r)^2}{4}-\frac{3(m-r)}2
\ge\frac{m^2}{4}-6m.
$$
The upper bound follows because there are at most $\lfloor m/2\rfloor$ possible sources and at most that many possible recipients of indirect guaranteed pairs. Thus the quadratic coefficient $1/4$ is sharp for arbitrary arc counts, not only the progression $m=10k$. $\square$

Exact equality at arbitrary orders and arc counts remains a separate question. The padding argument establishes the leading term; it does not fill the gaps between the sharp values supplied by Theorem 21.


# Exact extrema with at most seven arcs

**Proposition 23.** Allowing arbitrarily many vertices, including isolated vertices,
$$
\bigl(M_E(0),M_E(1),\ldots,M_E(6)\bigr)
  =(0,0,0,0,1,1,2).
$$

**Proof.** Write $A=\{v:d^+(v)\ge2\}$, $B=\{v:d^-(v)\ge2\}$,
$q=|A|$, $r=|B|$, and $b=|A\cap B|$.
Every counted pair belongs to $A\times B$, excludes the diagonal, and
excludes arcs. Consequently
$$
I(G)\le qr-b-e(A,B),\qquad
e(A,B)\ge\max\{0,2q+2r-m\},\qquad
q,r\le\lfloor m/2\rfloor.                 \tag{23.1}
$$
For completeness, the second inequality follows by counting the arcs leaving
$A$ and those entering $B$: their respective totals are at least $2q$
and $2r$, and their union has at most $m$ arcs.

A counted pair $(s,t)$ requires two arcs leaving $s$ and two entering
$t$. These four arcs are distinct because $s\to t$ is absent. Thus
$I(G)=0$ when $m\le3$.

We will use two elementary camping observations. If $d^-(z)=0$,
$z\to t$, and $d^-(t)=2$, then no indirect pair ending at $t$ is
guaranteed. Indeed, let $p$ be its other predecessor. An indirect source
is neither $z$ nor $p$. A pursuer starting at $p$ can wait there:
the messenger cannot reach $z$, and cannot enter $p$ without being
captured before reaching $t$. Dually, if $d^+(z)=0$, $s\to z$,
and $d^+(s)=2$, then no indirect pair starting at $s$ is guaranteed.
A pursuer waits at the other successor of $s$; the messenger's only
alternative departure reaches a sink different from the indirect recipient.

Suppose first that $m=4$ or $m=5$. Then $q,r\le2$. If either is
zero there is nothing to count, and if both are one the bound is immediate.
When $q=r=2$, (23.1) gives $I(G)\le m-4-b\le1$. When $q=1$
and $r=2$, two counted pairs would have the same source and distinct
recipients. The source's two outgoing arcs are then disjoint from the at
least four arcs entering those recipients, which would require $m\ge6$.
The case $q=2,r=1$ follows by the same count with sources and recipients
interchanged: at least four arcs leave the two counted sources, and the
recipient's two incoming arcs are disjoint from them. Hence $I(G)\le1$.

Now let $m=6$, so that $q,r\le3$. If $q=1$, three counted pairs
would require two outgoing arcs from their common source and six disjoint
arcs entering their three recipients; this is impossible. Thus $I(G)\le2$.
The same argument applies when $r=1$; cases with a zero coordinate are
again immediate. If $q=r=2$, (23.1) gives $I(G)\le2-b\le2$.

Consider $q=2,r=3$. Every arc ends in $B$, and every vertex of $B$
has indegree exactly two. If $A\subseteq B$, then $b=2$ and (23.1)
gives $I(G)\le6-2-4=0$. Otherwise choose $z\in A\setminus B$.
It has indegree zero and at least two distinct successors in $B$.
The first camping observation eliminates both corresponding recipient
columns. At most one column remains, containing at most the two sources
in $A$. Thus $I(G)\le2$.

For $q=3,r=2$, every arc starts in $A$ and every vertex of $A$
has outdegree exactly two. If $B\subseteq A$, the same count gives zero.
Otherwise a vertex $z\in B\setminus A$ has outdegree zero and at least
two predecessors in $A$. The second camping observation eliminates
their two source rows, leaving at most one row and two recipients. Again
$I(G)\le2$.

Finally, if $q=r=3$, all six arcs go from $A$ to $B$, and all
relevant indegrees and outdegrees equal two. If $A=B$, (23.1) gives
$I(G)\le9-3-6=0$. Otherwise a vertex of $A\setminus B$ has indegree
zero and eliminates two recipient columns by the first camping observation.
The remaining column has two distinct predecessors in $A$, so at most
one of the three sources can contribute an indirect pair. This completes
the upper bounds in all cases.

For the lower bounds, the four-arc diamond
$$
E=\{(0,1),(0,2),(1,3),(2,3)\}
$$
guarantees the indirect pair $(0,3)$: the messenger chooses the branch
not occupied by the pursuer and delivers on the next move. Adding a
disjoint arc gives the five-arc example. The six-arc graph
$$
E=\{(0,1),(0,2),(1,3),(1,4),(2,3),(2,4)\}
$$
guarantees both $(0,3)$ and $(0,4)$. If the pursuer starts on one
branch, choose the other; if it starts at either sink, choose either branch.
In each case it cannot reach the selected branch on its next move, and
receipt then occurs on the messenger's second move. Hence $I(G)=2$,
as required. $\square$

These arguments establish the arc-only maximum over every finite vertex
set; no restriction on the number of nonisolated vertices is used.

**Proposition 24 (with a finite exhaustive computation).** We have
$$
M_E(7)=2.
$$

**Proof.** First consider a weakly connected digraph with at most seven
arcs and at least seven vertices. Forget the directions but retain one
undirected edge for each arc, so that opposite arcs become parallel
edges. The resulting connected multigraph has at most as many edges as
vertices. It is therefore a tree or has exactly one cycle; a parallel
pair is allowed as a cycle of length two.

In a tree, any reachable indirect source--recipient pair has an internal
vertex separating its endpoints. A pursuer can start and wait there,
preventing delivery. Thus no indirect pair is guaranteed. In the unicyclic
case, a pair with either endpoint outside the unique cycle likewise has
an internal separating vertex, unless its endpoints are adjacent in the
underlying graph. For adjacent endpoints off the cycle, a directed route
exists only if their connecting arc has the required direction, making
the pair direct. Thus every counted pair must have both endpoints on the
cycle.

There are exactly two simple undirected paths along that cycle between
two distinct cycle vertices. If only one is a directed path from the
source to the recipient, it is either a direct arc or has an internal
vertex where the pursuer can wait. If neither is directed, the recipient
is unreachable. Excursions into attached trees cannot bypass an internal
cycle vertex. Consequently a counted pair requires both cycle paths to
be directed from its source to its recipient. This forces the cycle's
unique divergence at that source and unique convergence at that recipient;
every other cycle vertex has one entering and one leaving cycle edge.
A fixed orientation can therefore support at most one such ordered pair.
A cycle of length two consists of opposite arcs and supports no indirect
pair. We have proved that every weakly connected digraph with at most
seven arcs and at least seven vertices has $I(G)\le1$.

For a general digraph with seven arcs, distinct weak components contribute
additively to $I(G)$. Each component with a positive contribution uses
at least four arcs by Proposition 23, so at most one component contributes.
If that component uses at most six arcs, Proposition 23 bounds its
contribution by two. If it uses seven arcs and has at least seven vertices,
the preceding argument bounds its contribution by one. In the only
remaining case it has at most six vertices. Adding isolated vertices to
make six does not change its indirect guarantee count, and the complete
six-vertex enumeration gives a maximum of two at seven arcs.

This last finite assertion is the computational dependency of the
proposition. It is reproduced by `src/enumerate_small_n6.cpp`; the result
is recorded with `complete: true` in
`research/solver-enumeration-n6.json`. The enumeration covers every
six-vertex digraph up to the degree-ordering reduction described in the
computational section; the witness is also checked by the separate
explicit-turn solver. The structural reduction above is what extends
that finite calculation to unrestricted vertex counts.

Finally, add one disjoint arc to the six-arc, two-recipient construction
in Proposition 23. This preserves its two guarantees and supplies seven
arcs, proving the matching lower bound. $\square$

No exact arc-only maximum for budgets eight through eleven is asserted
here.


# Attainment across densities and losses near completeness

Angel Raychev proposed that, for every sufficiently large $n$, the missing-pair bound should be attained at **every** integer budget
$$2n\le m\le n(n-3).$$
This remains a conjecture. The next results prove a substantial interval of it and determine the maximum across most of the remaining dense band. Raychev also proposed separating existence from explicit constructions and studying how domination destroys missing pairs as the graph approaches completeness. These distinctions motivate the statements below; their proofs were developed in the September 2026 follow-up investigation.

Write $L=n(n-1)$ and $h=L-m$. Thus $h$ is the number of missing nonloop arcs, and always $I(G)\le h$.

## An exact-budget existence theorem

**Theorem 25.** Let $n\ge4$, let $0<m<L$ be an integer, and put $p=m/L$. If
$$
(n-3)p^2(1-p)>5\log n,
$$
then some graph with exactly $n$ vertices and $m$ arcs guarantees every source--recipient pair within two messenger moves. In particular,
$$M(n,m)=L-m.$$

**Proof.** Choose each nonloop arc independently with probability $p$. Fix distinct vertices $s,t$ and a legal initial pursuer position $c\ne s$. Each $u\notin\{s,t,c\}$ is a safe intermediate vertex when
$$s\to u,\quad u\to t\quad\text{are present, and}\quad c\to u\quad\text{is absent}.$$
These three distinct arcs give probability $p^2(1-p)$, including when $c=t$. Different candidates use disjoint sets of arcs, so their success events are independent. There are at least $n-3$ candidates. The probability that this triple has no safe intermediate is at most
$$\exp\bigl(-(n-3)p^2(1-p)\bigr).$$
There are fewer than $n^3$ triples. The probability that any triple fails is therefore less than $n^{-2}$ under the hypothesis.

It remains to enforce the exact arc count. That count has the binomial distribution with parameters $L,p$, and $m$ is a mode because $p=m/L$. Indeed, the ratio of the probabilities at $j+1$ and $j$ is
$$\frac{(L-j)p}{(j+1)(1-p)},$$
which decreases with $j$, is greater than one at $j=m-1$, and is less than one at $j=m$. Hence the probability of exactly $m$ arcs is at least $1/(L+1)>n^{-2}$. It exceeds the entire failure probability, so at least one graph with exactly $m$ arcs satisfies every safe-intermediate condition.

In that graph the messenger moves to its chosen intermediate vertex. The pursuer neither occupies that vertex nor can reach it on its response. The messenger then reaches the recipient, and receipt precedes any further interception. All $L-m$ missing pairs are consequently guaranteed. $\square$

This is an exact integer-budget existence theorem, rather than a statement about an expected number of arcs. It also gives a finite randomized search: sample graphs with exactly $m$ arcs and check the safe-intermediate condition. No practical running-time bound near the threshold is asserted.

**Corollary 26.** There is an absolute $N$ such that, for every $n\ge N$ and every integer budget
$$
\left\lceil10n^{3/2}\sqrt{\log n}\right\rceil\le m\le n(n-3),
$$
we have $M(n,m)=n(n-1)-m$. Attainment can always be achieved with delivery in at most two moves.

**Proof.** Let $p=m/L$ and $h=L-m$. For $n\ge6$, we have $n-3\ge n/2$. If $p\le1/2$, the lower bound on $m$ gives $p\ge10\sqrt{\log n/n}$ and therefore
$$
(n-3)p^2(1-p)\ge25\log n>5\log n.
$$
If $p\ge1/2$ and $h\ge100n\log n$, then $1-p=h/L\ge100\log n/n$, giving
$$
(n-3)p^2(1-p)\ge\frac{100}{8}\log n>5\log n.
$$
Theorem 25 covers both cases.

For the remaining dense budgets use Theorem 20 with
$$D=\left\lfloor(n/2)^{1/4}\right\rfloor.$$
For all sufficiently large $n$ its hypotheses hold, and its upper endpoint satisfies
$$L_D(n)\ge n(D/4+1)-1.$$
Since $D$ grows as a positive constant times $n^{1/4}$, this endpoint eventually exceeds $100n\log n$. Theorem 20 supplies every integer missing-arc count from $2n$ to $L_D(n)$, and the probabilistic range supplies the rest. The intervals overlap, so no admissible integer budget is omitted. Both proofs give two-move delivery. $\square$

The absolute threshold is not optimized or asserted to be moderate. In particular, this corollary does not establish the full interval at $n=52$. The general sparse interval between $2n$ and order $n^{3/2}\sqrt{\log n}$ remains outside its conclusion.

## A growing loss in the final dense band

Let $F$ be the loopless directed complement of $G$, and write $q(v)=d_F^+(v)$. The number
$$\Delta=h-I(G)$$
counts missing pairs that fail to guarantee delivery.

**Theorem 27.** For $n\ge2$ and every admissible integer $n\le h<2n$,
$$
I(G)\le h-\left\lceil\frac{2n-h}{2}\right\rceil-1.
$$
Equivalently, writing $r=2n-h$, we have
$$
M\bigl(n,n(n-3)+r\bigr)\le2n-r-\lceil r/2\rceil-1
\qquad(1\le r\le n).
$$

**Proof.** If $I(G)=0$, the conclusion holds: the right-hand side is increasing with $h$ and at $h=n$ equals $\lfloor(n-2)/2\rfloor\ge0$. Assume henceforth that $I(G)>0$.

Every $q(v)$ is positive. Otherwise a vertex $c$ with $q(c)=0$ can intercept every nonterminal departure from any other source, while its own source row has no missing pair. Put
$$
S=\{c:q(c)=1\},\qquad \ell=|S|.
$$
Since $h\ge\ell+2(n-\ell)$, we have $\ell\ge2n-h\ge1$. For $c\in S$ let $f(c)$ be its unique missing neighbor; thus $f(c)\ne c$. Set
$$U=f(S),\qquad a=|U\cap S|,\qquad b=|U\setminus S|.$$

Every source $x\in U$ loses all of its $q(x)$ missing pairs. To see this, choose $c\in S$ with $f(c)=x$. The pursuer's closed outgoing neighborhood in $G$ is $V\setminus\{x\}$. It can wait at $c$ while the messenger waits at $x$ and intercept every nonterminal departure. An indirect recipient cannot be reached by a direct departure.

A second obstruction applies when two distinct vertices $c,c'\in S$ have the same image $x$. The missing pair $(c,x)$ loses against a pursuer starting at $c'$, whose closed outgoing neighborhood contains every possible nonterminal intermediate vertex.

Let $R$ be the set of $c\in S\setminus U$ for which $f(c)$ has exactly one preimage in $S$, and put $\rho=|R|$. Every missing edge with tail in $S\setminus R$ loses by one of the two obstructions. The killed rows in $U\setminus S$ have at least two missing edges each, with tails outside $S$. These losses are disjoint, so
$$\Delta\ge\ell-\rho+2b.$$

If $b\ge1$, then $\rho\le\ell-a$ because $R\subseteq S\setminus U$, and $\rho\le a+b$ because its members have distinct images in $U$. Consequently
$$
\Delta\ge\max\{a+2b,\ell-a+b\}
\ge\left\lceil\frac{\ell+3b}{2}\right\rceil
\ge\lceil\ell/2\rceil+1.
$$
If $b=0$, the function $f$ maps $S$ into itself without fixed points. Its finite functional graph has a directed cycle of length at least two. Every cycle vertex belongs to $U$ and already has a preimage in $U$, so it cannot also be the image of a member of $R$: that member is outside $U$ and would give a second preimage. Thus $\rho\le a-2$, as well as $\rho\le\ell-a$. It follows that
$$
\Delta\ge\max\{a,\ell-a+2\}\ge\lceil\ell/2\rceil+1.
$$
Using $\ell\ge2n-h$ proves the bound. $\square$

Thus the forced loss increases as $2,2,3,3,4,4,\ldots$ as the arc budget moves one, two, three, four, five, six, and further steps above $n(n-3)$. At the other endpoint, $h=n$, the bound agrees with Theorem 13.

## Combining two-move constructions

**Lemma 28.** Suppose a missing-edge graph $F$ is a disjoint union of graphs $F_i$, each with positive outgoing degree at every vertex. Let $G_i$ be the complement on its own block. If an indirect pair in $G_i$ can be guaranteed within two messenger moves, then it remains guaranteed in the complement $G$ of the entire $F$.

**Proof.** Let the source and recipient lie in block $i$. If the initial pursuer also lies there, the original two-move strategy chooses an intermediate vertex outside its closed outgoing neighborhood. The same is true in $G$. The pursuer may respond by moving outside the block, but this cannot prevent receipt on the messenger's next move.

If the pursuer starts at $c$ in another block, choose any outgoing $F$-neighbor $u$ of $c$ in that block. The arcs $s\to u$ and $u\to t$ are present in $G$ because they cross blocks, whereas $c\to u$ is absent. Also $u\ne c,s,t$. This gives the required safe two-move delivery. $\square$

The lemma concerns two-move strategies. No preservation theorem for arbitrary longer strategies under this join is assumed.

**Theorem 29.** For every integer $n$ and every $2\le r\le n-52$,
$$
M\bigl(n,n(n-3)+r\bigr)=2n-r-\lceil r/2\rceil-1.
$$
Equivalently, equality in Theorem 27 holds throughout
$$n+52\le h\le2n-2.$$
There is an explicit attaining construction at every such integer budget.

**Proof.** Put $k=n-r\ge52$. On a block of $r$ vertices use the functional missing-edge extremizer from Theorem 13. Explicitly, put $j=\lfloor(r-2)/2\rfloor$ and use vertices $a,b,s_i,t_i$ for $1\le i\le j$, with an additional vertex $z$ when $r$ is odd. Its missing arcs are
$$s_i\to t_i,\qquad t_i\to a,\qquad a\to b,\qquad b\to a,$$
together with $z\to a$ when needed. Every vertex has exactly one missing outgoing arc. Its complement guarantees the $j$ pairs $(s_i,t_i)$ within two moves, by the proof of Theorem 13.

On a disjoint block of $k$ vertices, orient Euler circuits in the four-regular girth-six graph of Theorem 19. This missing-edge graph has two incoming and two outgoing arcs at every vertex. Lemma 18 guarantees all $2k$ missing pairs in its complement within two moves.

Take the disjoint union of these missing-edge graphs and complement it. It has $n=r+k$ vertices and $h=r+2k=2n-r$ missing arcs. Lemma 28 preserves at least
$$
j+2k=\lfloor(r-2)/2\rfloor+2(n-r)
=2n-r-\lceil r/2\rceil-1
$$
guaranteed missing pairs. Theorem 27 supplies the matching upper bound. $\square$

The attaining construction uses the explicit finite girth-growth certificate when $52\le k<130$ and the ordinary all-order growth proof thereafter. The interval is nonempty for $n\ge54$. It leaves $r=1$ and the bounded-offset range $n-51\le r\le n-1$ outside its uniform conclusion; $r=n$ is already covered by Theorem 13. The existing 26-vertex incidence block also gives equality at $r=n-26$ whenever $r\ge2$, by the same join.

## A restriction on permutation constructions

**Proposition 30.** Suppose the two outgoing neighbors of each vertex are $\alpha(v)$ and $\beta(v)$, where $\alpha,\beta$ are commuting permutations, both images differ from $v$, and $\alpha(v)\ne\beta(v)$. Then $I(G)\le n$. In fact all indirect guarantees are decided by a two-move criterion.

**Proof.** Fix a recipient $t$ and put $s_t=\alpha^{-1}\beta^{-1}(t)$. Commutation gives
$$
N^+(s_t)=\{\beta^{-1}(t),\alpha^{-1}(t)\}=N^-(t).
$$
The predecessor camping lemma excludes every indirect source except possibly $s_t$: a pursuer starting at $s_t$ can intercept the messenger when it first reaches a predecessor of $t$. Thus each recipient contributes at most one pair.

When $s_t\ne t$, the pair $(s_t,t)$ is missing because neither predecessor of a loopless recipient equals that recipient. This pair is guaranteed exactly when no $c\ne s_t$ has $N^-(t)\subseteq C(c)$. Necessity is the same camping lemma. For sufficiency, from each legal initial pursuer position choose $u\in N^-(t)\setminus C(c)$. The messenger moves from $s_t$ to this safe predecessor and then delivers. $\square$

The bound is sharp: on $\mathbb Z/7\mathbb Z$, take arcs $x\to x+1$ and $x\to x+3$. For recipient zero the predecessors are $6,4$, and the only closed outgoing neighborhood containing both is that of $3$. The criterion gives $(3,0)$; translation gives exactly the seven pairs $(s,s+4)$. Since $n(n-3)>n$ for $n\ge5$, commuting permutations cannot supply a universal vertex-extremal graph in that range. Noncommutation is necessary, not asserted sufficient.

## An extension that fills the small dense offsets

**Proposition 31.** Let $r\ge2$, $k\ge1$, and $n=r+k$. Put $j=\lfloor(r-2)/2\rfloor$. If
$$k\le\binom j2,$$
then an explicit graph attains
$$
M\bigl(n,n(n-3)+r\bigr)=2n-r-\lceil r/2\rceil-1.
$$
In particular, for every $n\ge75$ this holds at each offset $k=n-r$ with $1\le k\le51$.

**Proof.** Begin with the functional missing-edge graph on $r$ vertices from Theorem 29: its vertices are $a,b,s_i,t_i$ for $1\le i\le j$, with an extra $z$ if $r$ is odd, and its arcs are
$$a\to b,\quad b\to a,\quad s_i\to t_i,\quad t_i\to a,$$
together with $z\to a$ when needed. Add a set $H$ of $k$ vertices. For each $v\in H$ choose a distinct two-element subset $A_v\subseteq\{s_1,\ldots,s_j\}$ and give $v$ precisely those two outgoing missing arcs. Add no other missing arcs. These choices are possible by the assumed inequality. The resulting missing-edge graph $F$ has $n$ vertices and $h=r+2k$ arcs.

We show that its complement guarantees each pair $(v,t)$ with $v\in H$ and $t\in A_v$. If the pursuer starts at a functional vertex $c$, let $u$ be its unique outgoing missing neighbor. This vertex lies among $a,b,t_1,\ldots,t_j$, so $v\to u\to t$ are present arcs of the complement while $c\to u$ is absent. If the pursuer starts at another vertex $c\in H\setminus\{v\}$, distinctness and equal cardinality give an element $u\in A_c\setminus A_v$. Then $v\to u$ is present, and $u\to t$ is present because $u=s_\ell$ has only $t_\ell$ as a missing neighbor, whereas $t$ is one of the $s_i$. Also $u\ne t$ because $t\in A_v$. In each case $u$ is distinct from the pursuer and from both endpoints, and cannot be reached by the pursuer on its next move. This proves all $2k$ of these guarantees in two moves.

Each original pair $(s_i,t_i)$ remains guaranteed as well. Against a functional pursuer $c\ne s_i$, its unique missing neighbor $u$ is neither endpoint: no functional missing arc enters $s_i$, and the only one entering $t_i$ starts at $s_i$. Hence $s_i\to u\to t_i$ are present and safe. Against a pursuer $c\in H$, choose $s_\ell\in A_c$ with $\ell\ne i$, which is possible because $A_c$ has two members. The route $s_i\to s_\ell\to t_i$ is present and safe. Thus at least $j+2k$ missing pairs are guaranteed.

As in Theorem 29,
$$j+2k=2n-r-\lceil r/2\rceil-1,$$
and Theorem 27 supplies the upper bound. Finally, if $n\ge75$ and $1\le k\le51$, then $r=n-k\ge24$, so $j\ge11$ and $\binom j2\ge55\ge k$. $\square$

The construction is generated by `src/dense_functional_extension.py`. Its direct two-move check covers all 51 offsets at $n=75$; five small examples are also checked by both full game solvers and the independent rank-certificate verifier. The receipt is `research/dense-functional-extension-verification.json`. These checks support the ordinary proof; no finite testing is needed to justify the general parameter range. Combining Proposition 31 with Theorem 29 and the functional endpoint proves sharpness for every $2\le r\le n$ when $n\ge75$.

All proofs in this follow-up section are ordinary mathematical arguments. Theorem 25 is probabilistic existence; Theorem 29 is an explicit construction with the previously stated finite structural dependency; Proposition 31 is a direct explicit construction. No new Lean coverage is claimed. The general full-density conjecture remains distinct from the intervals proved here.


# Completing the final dense band

**Theorem 32.** For every $n\ge68$,
$$M\bigl(n,n(n-3)+1\bigr)=2n-3.$$
An explicit attaining graph guarantees all but two of its missing pairs within two messenger moves.

**Proof.** Theorem 27 gives the upper bound. For attainment put $k=n-4\ge64$, and take a four-regular undirected graph $H$ of girth at least six on $k$ vertices, supplied by Theorem 19. Choose four distinct vertices $a,b,d,e$ with
$$
\operatorname{dist}(a,b),\operatorname{dist}(d,e)\ge4,
\qquad
\operatorname{dist}(u,v)\ge2
\quad(u\in\{a,b\},\ v\in\{d,e\}).
$$
Distances between components are infinite. A radius-three ball in a graph of maximum degree four has at most $1+4+12+36=53$ vertices. After choosing $a$, choose $b$ outside that ball. Choose $d$ outside the closed neighborhoods of $a,b$, whose union has size at most ten. Choose $e$ outside this union and the radius-three ball of $d$. At most $63$ vertices are excluded, so all choices exist when $k\ge64$.

Orient Euler tours of $H$. Add four vertices $c,x,y,z$ and the seven missing arcs
$$c\to x,\qquad x\to y,z,\qquad y\to a,b,\qquad z\to d,e.$$
Let $F$ be this missing-edge graph and $G$ its directed complement. Every vertex has outdegree two in $F$ except $c$, whose only outgoing arc is $c\to x$. The unique incoming neighbors of $x,y,z$ in $F$ are respectively $c,x,x$. We have
$$|V(F)|=k+4=n,\qquad |E(F)|=2k+7=2n-1,$$
so $G$ has $n(n-3)+1$ arcs.

The underlying graph of $F$ still has girth at least six. The new edges form a tree attached to the core at $a,b,d,e$, with $c$ a pendant vertex. A new simple cycle with one segment in this tree has either a same-branch segment of length two and a core path of length at least four, or a cross-branch segment of length four and a core path of length at least two. A cycle with two tree segments must use the vertex-disjoint paths $a-y-b$ and $d-z-e$: a cross-branch tree segment would meet any other segment. Its two core paths both join opposite branches and have length at least two, giving total length at least eight. With four attachment vertices there can be no third tree segment. Thus no cycle of length below six is introduced.

For a missing pair $(s,t)$, set
$$B=N_F^+(s)\cup N_F^-(t).$$
The local argument in Lemma 18 shows that every initial cop vertex $v\ne s$ with $d_F^+(v)\ge2$ has an outgoing $F$-neighbor outside $B$. Indeed, the induced double star on $B$ has diameter at most three, and such a cop has at most one outgoing neighbor in it. This is a safe intermediary for a two-move delivery in $G$. The argument only requires the degree bound at that cop vertex; the other degrees need not all satisfy it.

Only initial cop position $c$ remains. Consider a missing pair with $s\ne c,x$. Then $x\notin N_F^+(s)$, since the sole predecessor of $x$ is $c$. Also $x\notin N_F^-(t)$: otherwise $t$ would be $y$ or $z$, whose sole predecessor is $x$, forcing $s=x$. Consequently $x\notin B$, and $x$ gives a safe two-move delivery. When $s=c$, that cop position is not legal initially, so the preceding degree-two argument already covers every legal initial position.

The only remaining missing pairs are $(x,y)$ and $(x,z)$. Neither is guaranteed: a pursuer at $c$ has closed outgoing neighborhood $V\setminus\{x\}$ in $G$, and can intercept every nonterminal departure from source $x$. Waiting never delivers, and neither recipient is directly accessible. Exactly these two pairs fail, leaving $2n-3$ guarantees. $\square$

The generator `src/dense_first_step.py` implements the choices above and verifies the full graph's girth, the relevant degrees, and every safe-intermediate condition. Its receipt `research/dense-first-step-checks.json` records instances at orders 68, 75, 80, 100, and 164, covering 105,634 missing-pair/cop triples with precisely the two asserted exceptions. These checks corroborate the ordinary proof. The construction at $n\ge134$ uses the ordinary high-girth construction starting at core order 130; its extension to $68\le n<134$ uses the already stated finite structural insertion certificate.

**Corollary 33 (the complete final dense band).** For every $n\ge75$ and every integer $1\le r\le n$,
$$
\boxed{
M\bigl(n,n(n-3)+r\bigr)
=2n-r-\left\lceil\frac r2\right\rceil-1.
}
$$
Equivalently, for every integer $n\le h\le2n-1$,
$$
M\bigl(n,n(n-1)-h\bigr)
=h-\left\lceil\frac{2n-h}{2}\right\rceil-1.
$$
There is an explicit attaining graph at every such budget, with a two-move strategy for every counted pair.

**Proof.** The upper bound is Theorem 27. The first step $r=1$ is Theorem 32. For $r\ge2$, put $k=n-r$. If $k\ge52$, use Theorem 29. If $1\le k\le51$, then $r=n-k\ge24$, and Proposition 31 applies because
$$
j=\left\lfloor\frac{r-2}{2}\right\rfloor\ge11,
\qquad
\binom j2\ge55\ge k.
$$
Finally, $k=0$ means $r=n$, which is the functional construction of Theorem 13. These cases exhaust all integer budgets in the band. $\square$

Together with Theorem 19 at $m=n(n-3)$ and Theorem 13 beyond $m=n(n-2)$, this determines the entire joint extremum for $n\ge75$ and $m\ge n(n-3)$. At the boundary $m=n(n-3)$ the value is $2n$; the next step has value $2n-3$, and the subsequent values follow the displayed staircase down to $\lfloor(n-2)/2\rfloor$, after which the value is zero. This result does not resolve the general sparse interval below $n(n-3)$, nor does it assert that every smaller order has the same formula. No new Lean formalization is claimed here.

![The complete final dense band at n=100. The solid curve is the proved exact maximum at every integer budget; the dashed line counts all missing pairs and does not account for forced failures.](figures/dense-staircase.pdf)


# Explicit attainment at every budget in a sparse interval

The circulant construction gives an exact joint extremum, not only a lower bound on the vertex maximum: for every $n\ge25$, Theorem 11 and Lemma 12 already show that $M(n,3n)=n(n-4)$. The next result fills consecutive budgets above $3n$. Its proof controls the extra pursuer moves; arbitrary additions of arcs would not justify that conclusion.

**Theorem 34.** For every $n\ge25$,
$$M(n,3n)=n(n-4).$$
Moreover, if $d\ge4$ and
$$n>d^3+2d,$$
then at every integer budget $3n\le m\le dn$ there is an explicit graph attaining
$$M(n,m)=n(n-1)-m.$$
In particular, this holds throughout $3n\le m\le4n$ for every $n\ge73$. More generally the explicit interval reaches arc counts of order $n^{4/3}$.

**Proof.** Say that a set $A\subseteq\mathbb Z/n\mathbb Z$ has distinct nonzero differences when
$$a-b=a'-b'\ne0,\qquad a,b,a',b'\in A,$$
implies $(a,b)=(a',b')$. For such a set, two distinct translates $x+A$ and $y+A$ intersect in at most one point: two intersections would give two representations of the nonzero difference $y-x$.

Choose $h$ as in Lemma 12 and put $a=(h-1)/2$. The set
$$A_0=\{0,1,a,h\}$$
has distinct nonzero differences by the proof of Theorem 11. The base graph $B$ has steps $1,a,h$. For any larger set $A$ with distinct nonzero differences, let $H_A$ have the nonzero steps in $A$; we will keep $0\in A$ throughout. Every graph $G$ satisfying
$$B\subseteq G\subseteq H_A$$
has distinct closed move sets intersecting in at most one vertex, because $C_G(x)\subseteq x+A$.

The proof of Theorem 11 therefore works inside every such $G$. To make this preservation explicit, fix the recipient zero. Its direct predecessors $-1,-a,-h$ and zero are guaranteed, and $-a-1$ is guaranteed using the two successors $-a,-1$. If
$$Q(z)=\{z,z-1,z-a,z-a-1\}$$
is guaranteed, the following four applications of Lemma 10 establish $Q(z-h)$:

| New source | Two guaranteed successors |
|:--|:--|
| $z-h$ | $z-a-1,\ z$ |
| $z-h-1$ | $z-h,\ z-1$ |
| $z-h-a$ | $z-h,\ z-a$ |
| $z-h-a-1$ | $z-h-a,\ z-a-1$ |

All displayed moves belong to $B$. Coprimality of $h$ and $n$ makes finitely many repetitions cover all sources. The same argument with all coordinates shifted applies to every recipient, even when $G$ itself is not translation invariant. Thus every intermediate graph is universally winning.

It remains to enlarge $A_0$. Suppose $|A|=k$ and its nonzero differences are distinct. To adjoin $x$, exclude the following residues:

1. The $k$ members of $A$ itself.
2. Residues $x=a+b-c$ with $a,b,c\in A$ and $b\ne c$. These exclude every equality between an old nonzero difference and either sign of a new difference. There are at most $k^2(k-1)$ such residues.
3. Solutions of $2x=a+b$ with $a,b\in A$. These exclude an equality $x-a=b-x$ between the two signs of new differences. There are $k(k+1)/2$ unordered pairs with repetition, and each congruence has at most two solutions, hence at most $k(k+1)$ excluded residues.

Within each sign the new differences are already distinct. The three exclusions are therefore sufficient, and together rule out at most
$$k+k^2(k-1)+k(k+1)=k^3+2k$$
residues. Whenever $n>k^3+2k$, at least one admissible residue remains; choose the smallest representative. Under the theorem's hypothesis this process continues from size four to size $d+1$.

The resulting $H_A$ has $dn$ arcs and contains the $3n$ arcs of $B$. For a prescribed integer $m$ in the interval, add exactly $m-3n$ of the remaining arcs in lexicographic order. The intermediate graph is universally winning by the preservation argument, so all $n(n-1)-m$ missing pairs are guaranteed. This matches the elementary upper bound.

For $d=4$ the hypothesis is $n>72$. Taking the largest admissible $d$ gives $d$ of order $n^{1/3}$, and therefore an upper interval endpoint of order $n^{4/3}$. The endpoint $m=3n$ only needs the original $n\ge25$ construction, with no extension. $\square$

This is a deterministic construction at each stated integer budget. The underlying delivery argument may require many moves; it is not a two-move theorem. Its ordinary proof is independent of the finite tests in `src/sidon_main_interval.py`, and no new Lean coverage is asserted. It proves a consecutive part of Raychev's full-density attainment conjecture while leaving the general interval from $2n$ to $3n$, and a gap before the probabilistic range, unresolved.


# An explicit algebraic family at intermediate density

**Theorem 35.** Let $p\ge5$ be a prime. For every integer
$$4p^2\le m\le p^2(p-1),$$
there is an explicit graph attaining
$$
M(p^2,m)=p^2(p^2-1)-m.
$$
In particular, the interval extends to $m=n^{3/2}-n$ at orders $n=p^2$. For primes $p\ge11$, Theorem 34 extends its lower endpoint to $3p^2$.

**Proof.** Put $A=\{(t,t^2):t\in\mathbb F_p\}$, and let $H_A$ be the directed graph with all nonzero moves in $A$. Let $B_0$ be its four-move subgraph with parameters
$$t\in\{1,-1,-2,-3\}.$$
These are distinct and nonzero when $p\ge5$. We prove universal delivery in every graph $G$ satisfying $B_0\subseteq G\subseteq H_A$, including graphs without translation symmetry.

Every closed outgoing neighborhood in $G$ is a subset of the corresponding translate of $A$. Distinct translates of $A$ intersect in at most one point. Indeed, a nonzero difference
$$
(t,t^2)-(s,s^2)=(t-s,(t-s)(t+s))
$$
determines $t,s$ uniquely: if the first coordinate is nonzero, it determines their difference and sum, and division by two is valid; if the first coordinate is zero, the entire difference is zero. Thus every nonzero difference has at most one ordered representation.

This intersection property gives the following safe-branching rule. Fix a recipient. If two distinct outgoing neighbors of a vertex are already universally winning positions for that recipient, the vertex is universally winning as well. Against an initial cop at another vertex, at most one of the two successors lies in the cop's closed outgoing neighborhood. Move to the other, survive the cop's response, and use its winning strategy. The rule concerns the actual game, including the intervening pursuer move.

We first use recipient $0$ and only moves of the uniform core $B_0$. Put
$$u=(1,1),\qquad v=(-2,4),\qquad h=(-3,9)=u+2v,$$
and define
$$Q(z)=\{z,z-u,z-v,z-u-v\}.$$
The vertices $0,-u,-v$ are initially winning, by immediate receipt or a direct final move. The remaining vertex $-u-v$ has winning successors $-u,-v$, so all of $Q(0)$ is winning.

If every vertex of $Q(z)$ is winning, so is every vertex of $Q(z-h)$. Apply the safe-branching rule in the following order; each row lists the new vertex and two already winning successors:
$$
\begin{array}{c|cc}
z-h & z-u-v & z\\
z-h-u & z-h & z-u\\
z-h-v & z-h & z-v\\
z-h-u-v & z-h-v & z-u-v
\end{array}
$$
The corresponding pairs of moves are $(v,h),(u,h),(v,h),(u,h)$, respectively. They are distinct allowed moves.

Repeated propagation makes the entire line $L=\{\lambda h:\lambda\in\mathbb F_p\}$ winning: the nonzero vector $h$ has additive order $p$, so integer multiples cover all the displayed scalars.

Use the fourth core move $w=(-1,1)$. We have
$$w-v=(1,-3)=-h/3\in L,$$
while $v\notin L$ because $\det(h,v)=6\ne0$. If every vertex of a coset $L+z$ is winning, then every vertex of $L+z-v$ has two distinct winning successors, obtained by adding $v$ and $w$. The safe-branching rule therefore fills that entire coset as well. Iterating gives all cosets $L-jv$, which are the $p$ distinct cosets because $v\notin L$. Thus every vertex is winning.

The same proof shifted by the recipient uses only moves of $B_0$ and the global closed-neighborhood intersection bound. It applies to every recipient even if the extra arcs of $G$ are not translation invariant. Hence every intermediate graph is universally winning.

The core has $4p^2$ arcs, and $H_A$ has $p^2(p-1)$ arcs. Add the remaining arcs one at a time in any fixed order until the prescribed integer budget $m$ is reached. All $p^2(p^2-1)-m$ missing nonloop pairs are guaranteed, attaining the elementary upper bound. Finally, when $p\ge11$ we have $p^2\ge73$, so Theorem 34 covers the adjacent interval $3p^2\le m\le4p^2$. $\square$

The proof is finite and constructive: initializing a quartet takes at most two messenger moves, and each quartet propagation increases a bound by at most four. At most $p-1$ such propagations and $p-1$ further coset steps therefore give the uniform, unoptimized bound $5p-3$ messenger moves.

The prime hypothesis is intentional. In an extension field, repeated addition only covers scalars from its prime subfield, so this four-move propagation does not justify the same conclusion for arbitrary prime powers. The construction is checked at $p=5,7,11$ by `src/parabola_cayley.py`; it verifies the full-parabola intersection condition, the four-move core's complete safe-branching closure, and the core/upper-graph inclusions for all 827 consecutive integer budgets in these examples. At $p=5$, both full game solvers and their rank certificates independently verify every recipient. These finite checks supplement the ordinary proof and are recorded in `research/parabola-cayley-checks.json`. No new Lean formalization is claimed.


# A consecutive interval above the two-regular endpoint

The five-type construction can tolerate a controlled set of additional arcs. The proof gives the pursuer every additional move while restricting the messenger to the original moves. This verifies all intermediate graphs at once, without assuming that winning is monotone under adding arcs.

**Theorem 36 (with finite local certificates).** Let $n=5k$ with $k\ge10$. For every integer
$$2n\le m\le\frac{11n}{5},$$
there is an explicit graph with $n$ vertices and $m$ arcs satisfying
$$M(n,m)=n(n-1)-m.$$
Every pair can be guaranteed within $8k+18$ messenger moves.

**Proof.** Use the five-type graph $H_k$ of Theorem 21 on vertices $(i,j)$, where $i$ is modulo $k$ and $0\le j\le4$. Its two outgoing arcs are
$$
\begin{aligned}
\alpha(i,j)&=(i,j+1) &&(j<4),&\alpha(i,4)&=(i+1,0),\\
\beta(i,0)&=(i+1,0),&\beta(i,1)&=(i-1,2),\\
\beta(i,2)&=(i-1,4),&\beta(i,3)&=(i-1,3),&\beta(i,4)&=(i-1,1).
\end{aligned}
$$
There are $2n$ arcs. Add any chosen subset of the $k$ further arcs
$$ (i,0)\longrightarrow(i-1,4).$$
They are distinct from the original arcs and from each other, so every integer budget in the stated interval is obtained.

We verify the stronger asymmetric game in which the messenger may use only $\alpha,\beta$ and waiting, while the pursuer may also use all $k$ additional arcs. Construct the same local arena as in Theorem 21: messenger columns $-3,\ldots,3$, pursuer columns $-4,\ldots,4$, and a pursuer state $\Omega$ representing the outside. The messenger is constrained to its local columns. The pursuer may leave into $\Omega$, wait there, and re-enter at any vertex in either boundary column $-4$ or $4$. Within its columns it has the two original arcs and the additional arc above whenever its type is zero.

Two independently implemented finite attractor computations verify the following objectives against every legal initial pursuer state, including $\Omega$:

| Objective | Initial messenger column | Maximum messenger moves |
|:--|--:|--:|
| Reach column zero safely at the beginning of a messenger turn | 1 | 8 |
| Deliver to $(0,0)$ | 2 | 26 |
| Deliver to $(0,1)$ | 2 | 19 |
| Deliver to $(0,2)$ | 2 | 17 |
| Deliver to $(0,3)$ | 2 | 17 |
| Deliver to $(0,4)$ | 2 | 18 |

Each row covers all five initial messenger types and all 45 legal pursuer positions per type, for 225 required initial states. The transfer goal is seeded only at a messenger turn after the pursuer response, with unequal positions. Delivery goals use immediate receipt before collision, as required by the game. The rank checks verify every selected messenger move and every permitted pursuer response; these are complete finite certificates for the displayed statements.

For $k\ge10$, the nine represented pursuer columns are distinct on the ring. All moves, including the additional ones, change the column by at most one. Therefore an actual pursuer outside those columns can first enter only a boundary column; its behavior projects into the adversarial $\Omega$ state. The actual messenger can follow every certified original move. The local certificates consequently apply at every translated column of every such ring, independently of which additional arcs the actual graph contains.

Fix a recipient in column zero. Repeatedly translate and apply the safe-transfer certificate to move the messenger one column backward until it reaches column two. This needs at most $k-1$ transfers, each leaving a legal messenger-turn state for the next certificate. Then apply the appropriate delivery certificate. The total is at most
$$8(k-1)+26=8k+18.$$
Thus every pair is guaranteed, and all $n(n-1)-m$ missing pairs are counted. The missing-pair upper bound proves equality. $\square$

The primary generator and full ranks are `src/five_type_sparse_interval.py` and `research/five-type-sparse-interval-certificates.json`. The independent explicit alternating-state implementation is `src/five_type_augmented_verify.py`, with its full certificate in `research/five-type-augmented-independent-certificates.json`. The ring projection and concatenation are ordinary proofs; the bounded local facts depend on these finite certificates. This theorem is not presently formalized in Lean, and it makes no claim for the small rings $k=4,\ldots,9$ or for budgets beyond $11n/5$.

**Theorem 37 (with finite local certificates).** Let $n=5k$ with $k\ge16$. At every integer budget $2n\le m\le3n$, there is an explicit graph attaining
$$M(n,m)=n(n-1)-m.$$
Every pair can be guaranteed within $8k+16$ messenger moves.

**Proof.** Keep the original five-type graph, and add any subset of the $n$ arcs
$$ (i,j)\longrightarrow(i+3,0),\qquad 0\le j\le4.$$
They are pairwise distinct and are not original arcs. It suffices to win with the messenger restricted to the original graph and the pursuer allowed all the additional arcs.

Use messenger columns $[-3,3]$, pursuer columns $[-6,6]$, and the outside state $\Omega$. Give the represented pursuer its original and added moves; moves leaving the interval enter $\Omega$. From $\Omega$ permit waiting and re-entry at every vertex in the six columns $-6,-5,-4,4,5,6$. Independent synchronous and explicit alternating-state certificates verify safe transfer from column one to zero in at most eight moves, and delivery from column two to the five recipient types at zero in at most $24,16,16,17,18$ moves. Each objective covers all 325 legal initial states: five messenger types and 65 pursuer positions per type. The transfer ends on a safe messenger turn, and delivery has immediate terminal priority, exactly as in Theorem 36.

We check the larger-jump projection explicitly. The thirteen represented pursuer columns are distinct when $k\ge16$, and at least three consecutive columns lie outside them. No move, whose column displacement is at most three, can jump over that entire outside gap and land at the opposite represented boundary. Thus a represented move projects either to its represented destination or to $\Omega$. An outside pursuer can enter the represented interval only in one of the six allowed boundary columns. Every actual pursuer behavior is therefore included in the finite arena. This gap condition is why the proof uses $k\ge16$, not merely enough columns to make the represented labels distinct.

At most $k-1$ safe backward transfers reach column two relative to the recipient. The final delivery costs at most 24 further moves, giving $8(k-1)+24=8k+16$. The strategy is available in every intermediate graph, and its pursuer has no more moves than the certified adversary. Hence all pairs are guaranteed at each of the $n+1$ integer budgets. Counting missing pairs proves equality. $\square$

The full primary ranks are `research/five-type-full-sparse-interval-certificates.json`, generated by `src/five_type_sparse_interval.py`. The independent 4620-state implementation and certificate are `src/five_type_long_augmented_verify.py` and `research/five-type-long-augmented-independent-certificates.json`. The statement is a uniform theorem with a finite local proof ingredient, not an extrapolation from tested circumferences. No new Lean coverage is claimed. For orders divisible by five with $n\ge80$, Theorems 34 and 37 combine into a consecutive explicit interval starting at $2n$ and reaching order $n^{4/3}$.


# Exact computation and formal verification

For a fixed recipient $t$, let $X_j(r)$ be the set of initial pursuer positions from which delivery can be forced in at most $j$ messenger moves. Start with $X_0(t)=V$ and $X_0(r)=\varnothing$ otherwise. Set
$$
S_j(v)=\{c:C(c)\subseteq X_j(v)\}\quad(v\ne t),\qquad S_j(t)=V,
$$
and update
$$
X_{j+1}(r)=\left(\bigcup_{v\in C(r)}S_j(v)\right)\setminus\{r\}\quad(r\ne t),
\qquad X_{j+1}(t)=V.
$$
The recurrence includes waits and excludes all nonterminal collisions. Its least fixed point enforces eventual delivery. A separate implementation builds the explicit alternating graph of states $(r,c,\text{turn})$ and computes its reachability attractor. This is standard finite reachability-game machinery [@berwanger2009], rather than a new general algorithm for graph games.

The certificate checker independently verifies decreasing ranks on the selected messenger moves and on every pursuer response. Outside the winning region it verifies closure under every messenger move and at least one pursuer response. Thus a negative answer comes with an avoidance strategy, not simply failure of a search. Standard adjacency-list attractor analysis gives an all-recipient time bound $O(n^2m+n^3)$; that bound describes the standard implementation, not a claimed running-time bound for the simpler synchronous reference solver.

## Certified finite extrema

Complete enumeration gives

| $n$ | 1 | 2 | 3 | 4 | 5 | 6 |
|:--|--:|--:|--:|--:|--:|--:|
| $M_V(n)$ | 0 | 0 | 0 | 2 | 4 | 7 |

For $n\le5$ every labeled digraph was enumerated. For $n=6$, sorting the vertex labels by degree reduces the search while retaining at least one representative of every isomorphism class; valid degree bounds prune only candidates unable to improve the current maximum. This certifies extrema, not labeled distributions. Every attaining graph is independently checked by the explicit alternating solver. The complete joint tables, enumeration code, and receipts accompany the paper.

Universal two-regular witnesses attain Theorem 5 for every $12\le n\le24$. Consequently Theorem 6 is attained at $m=24,26,\ldots,48$. Deletion witnesses attain Theorem 7 at $m=37,39,\ldots,47$. Orders 7 through 11 are not asserted to be classified here.

One clean 12-vertex example is a Cayley digraph of $A_4$, with right multiplication by two suitable 3-cycles. Its actual graph and all-recipient finite-rank certificate are included. The Lean theorem checks the explicit 12-vertex graph directly, so correctness does not depend on trusting the group-label interpretation or the search that discovered it.

## Lean coverage

The formal artifact uses Lean 4.33.1 and its standard library. The game implementation checks terminal receipt before collision, permits waiting, and quantifies over arbitrary legal history-dependent pursuer choices. Finite winning trees are proved to generate actual delivering plays; rank certificates generate those winning trees. Safe branching and predecessor camping are connected to the same semantics. A fully kernel-checked 12-vertex certificate proves universal delivery and computes $I=108$.

The dense-counting module additionally proves the staircase arithmetic from its displayed cardinality inequalities, the attaining count identity, and complementary-block gluing as actual two-move delivery against every legal history-dependent pursuer. The counting inequalities themselves are established by the ordinary graph argument, rather than silently asserted as formal theorems. Existence of the blocks is also a separate premise of the formal gluing result.

These are meaningful statements about the physical game. The general graph-to-counting arguments, arithmetic existence lemma, infinite constructions, probabilistic existence results, and exhaustive-search completeness arguments remain ordinary proofs. The downloadable coverage map lists exact theorem names and source hashes; it does not equate a numerical certificate or assumed interface with a full general formalization.

# Further consequences and open problems

For the random loopless digraph with each arc independently present with a fixed probability $0<p<1$, all distinct pairs are guaranteed with probability tending to one. For fixed distinct $s,t$ and $c\ne s$, each candidate $u\notin\{s,t,c\}$ independently supplies the arcs $s\to u,u\to t$ and the absence of $c\to u$ with probability $p^2(1-p)$. A union bound gives failure probability at most
$$n^3\bigl(1-p^2(1-p)\bigr)^{n-3}.$$
Thus
$$\mathbb E[I(G)]=(1-p)n(n-1)-o(1).$$
The error is absolute $o(1)$ because the probability bound is exponential. Theorem 25 supplies a separate conditioning argument for an exact prescribed number of arcs; the expectation alone does not do so.

Angel Raychev proposed the stronger joint conjecture that, for every sufficiently large $n$, every integer $2n\le m\le n(n-3)$ attains the missing-pair bound $M(n,m)=n(n-1)-m$. The explicit and probabilistic interval theorems settle parts of this range. The complete final dense band is now resolved for $n\ge75$, so the main joint construction gap is below $n(n-3)$.

The other central questions are exact attainment of the vertex and arc-budget upper bounds at arbitrary large orders, explicit constructions across the joint interval, and classification of all maximizing graphs. The five-type theorem settles the vertex bound at every multiple of five from 20 onward, and the even arc bound at every multiple of ten from 40 onward. Exact attainment at the other large orders and at arbitrary odd arc budgets is still open here. Finite modifications that win at one circumference can fail at neighboring circumferences; they are not evidence of a uniform extension without an additional argument.

A correct future proof must retain enough information about both players. Simple distance-to-recipient potentials fail: some states at a fixed small distance from the recipient require detours whose length grows with the graph. Nor does safe indefinite motion imply delivery. The finite witnesses and failed conjectures are preserved to make those distinctions reproducible.

# Construction appendix: choosing the circulant parameter

**Proof of Lemma 12.** If $n\equiv0\pmod4$, choose $h=n/2-1$; any common divisor with $n$ divides two and is odd. If $n\equiv2\pmod4$, choose $h=n/2-2$; the same argument uses four. If $n\equiv3\pmod4$, use $h=(n-1)/2$.

It remains to handle $n\equiv1\pmod4$. Write $n-1=2^e d$ with $d$ odd and $e\ge2$. If $d\ge7$, take $h=d$: it divides $n-1$ and is at most $(n-1)/4$. If $d\in\{1,3,5\}$ and $3\nmid n$, use $h=(n-3)/2$.

If $d=1$ and $3\mid n$, take $h=(n-7)/2$. The number $2^e+1$ is not divisible by seven, since powers of two modulo seven are $1,2,4$. The case $d=3$ and $3\mid n$ is impossible. Finally, if $d=5$ and $3\mid n$, then $e$ is even. Use $h=(n-11)/2$. Divisibility of $5\cdot2^e+1$ by eleven would imply $2^e\equiv2\pmod{11}$, whereas even powers have residues $1,3,4,5,9$.

All choices are odd and smaller than $n/2$. Their smallest possible lower estimate is $(n-11)/2\ge7$, valid for $n\ge25$. $\square$

# Provenance and assistance

Alexandra Ignatova's original problem and layered construction, developed under Angel Raychev's mentorship in 2023 and written in the retained February 2024 manuscript, are credited throughout. The upper bound $I(G)\le n(n-3)$ and the investigation of two-in/two-out-regular graphs also belong to Ignatova and Raychev's original work; the present account does not claim that bound or research direction as a new contribution. The September 2026 work repairs the balancing and strategy arguments, corrects the original count, and develops the new extremal bounds, circulant constructions, dense families, computational certificates, and formalization. Astra 6, operating through the Codex harness, assisted with these deductions, counterexample searches, proof writing, programming, and Lean development. The current document is a research checkpoint; it has not been submitted to arXiv and does not assign an unresolved final human author line.

# References

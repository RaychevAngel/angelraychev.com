# Exact arc maxima from eight through eleven

The six-vertex table supplies useful lower bounds, but does not itself
settle an arc budget when the number of vertices is unrestricted.
At eleven arcs the distinction is essential: seven vertices attain
eight guarantees, exceeding the six-vertex maximum of seven.

**Theorem 49 (with finite exhaustive certificates).** Over all finite
vertex sets,
$$\bigl(M_E(8),M_E(9),M_E(10),M_E(11)\bigr)=(4,5,6,8).$$

**Proof of the support reduction.** Indirect guarantees add over weak
components. Every component with a positive contribution has at least
four arcs. At these budgets there can be at most two positive
components. If there are two, each has at most seven arcs; Propositions
23 and 24 give a combined maximum of at most three. This cannot improve
any of the displayed lower bounds.

There is therefore only one relevant positive component. We argue in
increasing order of the budget $m=8,9,10,11$. If this component has
fewer than $m$ arcs, the already established smaller-budget maximum
bounds its contribution by the displayed value at $m$. If it uses all
$m$ arcs and has at least $m$ vertices, the tree-or-unicyclic argument
in Proposition 24 gives at most one indirect guarantee. That argument
only needs a connected underlying multigraph with at most as many
edges as vertices, so applies unchanged at the present budgets.

In the remaining case the component has at most $m-1$ vertices.
Pad it with isolates to exactly $m-1$ vertices; its arc count and
indirect count do not change. Hence each upper bound reduces to the
following one finite counterexample test:

| Arc budget $m$ | Host order | Excluded threshold for $I$ |
|---|---:|---:|
| 8 | 7 | 5 |
| 9 | 8 | 6 |
| 10 | 9 | 7 |
| 11 | 10 | 9 |

**Complete finite upper checks.** Both enumerators list all prescribed
outdegree profiles with total $m$ in sorted order and then all loopless
outgoing rows. As in the canonical reduction of Theorem 46, future
vertices with equal prescribed degree and equal incoming pattern from
completed rows can be permuted while leaving every completed row
unchanged. Choosing the new row's neighbors as a prefix of each such
contiguous cell retains a representative of every graph. The second
implementation instead uses descending degrees and suffixes. Both
reduction arguments fix the current vertex and all completed vertices.

The source and predecessor camping conditions of Theorem 46 supply
necessary local rejections. A completed degree-two source that points
to a prescribed sink also contributes zero, by the earlier sink
obstruction. Otherwise a source of degree $d\ge2$ contributes at most
$n-1-d$. A target of current indegree $d$ contributes at most
$n-1-\max(2,d)$, or zero if its indegree cannot reach two.

One additional numerical bound makes these sparse checks short.
Let $Q$ contain all sources not yet excluded, and put $q=|Q|$.
Every member of $Q$ has prescribed outdegree at least two. If the
eventual number of indegree-at-least-two targets is $r$, the same
degree-incidence count as (1) gives
$$I\le qr-\max(0,q+r-n)-\max(0,2q+2r-m).$$
To bound $r$ at a partial assignment, let $R$ be the number of arcs
still to be assigned. A target currently of indegree $d$ needs at
least $\max(0,2-d)$ of these arcs to reach indegree two. Discard
targets with too few remaining possible predecessors, and select as
many of the others as possible using the smallest such costs first,
with total cost at most $R$. The resulting $r_{\max}$ is an upper
bound: each remaining arc enters only one target. Maximizing the
displayed bound over $0\le r\le r_{\max}$ is therefore a safe
partial rejection. No sufficiency is assumed for these degree or
camping tests.

Every remaining complete graph is evaluated by the original finite
reachability game. The primary implementation uses synchronous
messenger-position masks; the independent implementation uses an
explicit alternating-state queue attractor. Both start with terminal
receipt states and compute the least winning region, including waiting
and all pursuer responses. They reject every candidate at every one
of the four thresholds. The exact enumeration counts are supplied in
the reproduction receipt; both runs report complete enumeration rather
than termination at their time limit. This proves the four upper bounds.

**Lower witnesses.** The witnesses at eight, nine and ten arcs are the
graphs in the six-vertex table. The eleven-arc witness has seven vertices
and the following outgoing neighborhoods:

| Vertex | Outgoing neighbors |
|---|---|
| 0 | 1 |
| 1 | 0 |
| 2 | 3 |
| 3 | 4, 5 |
| 4 | 0, 2 |
| 5 | 3, 6 |
| 6 | 1, 2 |

Its guaranteed indirect pairs are
$$ (3,0),(3,1),(3,2),(4,1),(5,0),(5,1),(5,2),(6,0). $$
Both independent game solvers check each of the four lower witnesses,
and the saved explicit ranks satisfy every legal-move obligation.
They attain the upper bounds and complete the proof. $\square$

The complete reproduction command is `python3 src/small_arcs_resume.py`.
Its two exhaustive sources are `src/small_arcs_sparse_primary.cpp` and
`src/small_arcs_sparse_independent.cpp`; the receipt, source hashes,
complete enumeration summaries and all four lower rank certificates are
in `research/small-arcs-resume-verification.json`. The final full
reproduction took about eighteen seconds. The unrestricted maxima at budgets 8, 9 and 10 are now formalized in
`SmallBudgetEight.lean`, `SmallBudgetNine.lean` and `SmallBudgetTen.lean`.
At budget 11, `SmallSparseWitnesses.lean` formalizes the lower witness,
while the unrestricted upper bound retains its ordinary and finite
computer-assisted proof boundary.

# Direct missing graphs unify the dense constructions

The following direct constructions replace the high-girth existence
arguments for the numerical dense results. Its proof examines the
possible safe intermediaries directly, so no girth hypothesis is needed.
The parameterized families have ordinary proofs; a few small
orders use explicitly listed finite constructions and independently
checked witnesses. All strategies here take at most two messenger moves.
Write $L=n(n-1)$ and $h=L-m$.

For a missing-arc graph $F$, a missing pair $(s,t)$ has a safe
intermediary against pursuer $c\ne s$ precisely when
$$N_F^+(c)\setminus\bigl(N_F^+(s)\cup N_F^-(t)\bigr)\ne\varnothing.$$
We call the union in this expression the danger set. It contains both
endpoints. A vertex outside it supplies both required messenger arcs,
while being a missing outgoing neighbor of the pursuer makes it safe.

There is also a robust version. Suppose $B\subseteq F$ are missing
graphs, and for every arc $(s,t)$ of $F$ and every $c\ne s$,
$$N_B^+(c)\not\subseteq N_F^+(s)\cup N_F^-(t). \tag{R}$$
Then every intermediate missing graph $B\subseteq F'\subseteq F$
guarantees all pairs in two moves: retain the witness from $B$, while
the danger set only shrinks. In particular, optional arcs can be
chosen individually and in arbitrary order.

**Theorem 58 (a unified dense construction).** There are deterministic
polynomial constructions with the following properties.

1. At every $n\ge10$, a graph with $n(n-3)$ arcs has
   all $2n$ missing pairs guaranteed within two moves. Thus
   $M(n,n(n-3))=2n$.
2. At every $n\ge16$, one compulsory set of $2n$ missing arcs and a list
   of $n$ optional missing arcs satisfy (R). Hence every integer
   $2n\le h\le3n$ attains $M(n,L-h)=h$, with two-move delivery.
3. At every $n\ge20$, the entire final dense band is exact:
   $$M\bigl(n,n(n-3)+r\bigr)
   =2n-r-\left\lceil\frac r2\right\rceil-1,
   \qquad1\le r\le n.$$
   Every counted pair in an attaining construction delivers within
   two moves. The first step $r=1$ already holds at every $n\ge16$.
4. For $n=10q+s\ge30$, $0\le s\le9$, put
   $$H_5(n)=10q^2+5q+s^2+s.$$
   A compulsory set of $2n$ missing arcs extends to an envelope with
   $H_5(n)$ missing arcs satisfying (R). For
   $n=4q+s\ge44$, $0\le s\le3$, the same assertion holds with
   $$H_4(n)=4q^2-26q+s^2+s.$$
   Thus every integer $2n\le h\le H(n)$ has $M(n,L-h)=h$, where
   $H(n)=H_5(n)$ for $30\le n<44$ and
   $H(n)=\max\{H_5(n),H_4(n)\}$ for $n\ge44$.
   Every optional subset works, and every missing pair delivers
   within two moves.

These statements determine every missing budget $n\le h\le H(n)$
at every $n\ge30$, and every $n\le h\le3n$ at every $n\ge20$.
The value is the displayed staircase for $h<2n$ and $h$ for $h\ge2n$.
The new cap strictly exceeds the cap of Theorem 48 throughout their
common domain $n\ge30$, preserving its time and arbitrary-subset
guarantees; part 2 also covers all of its smaller orders.
From $n=52$ onward, $H(n)=H_4(n)=n^2/4-O(n)$.

## The two-type core

Use vertices $P_i,L_i$, with $i$ modulo $k$, and the compulsory arcs
$$
P_i\longrightarrow L_i,L_{i-1},\qquad
L_i\longrightarrow P_{i+4},P_{i+6}. \tag{B}
$$
There are exactly two incoming and two outgoing arcs at every vertex.
The two types are disjoint, so no loop occurs. For $k\ge5$, all
pairs in the directed complement are guaranteed in two moves.

To see this, translate the source index to zero. A pursuer $P_i$ is
blocked precisely when the line part of the danger set contains both
$L_i,L_{i-1}$. A pursuer $L_i$ is blocked precisely when its point
part contains both $P_{i+4},P_{i+6}$. Thus line indices are tested
for adjacency, and point indices for a difference of two. The four
possible missing pairs have the following point and line danger sets:

- For $P_0\to L_0$: point indices $\{0,1\}$, line indices
  $\{0,-1\}$.
- For $P_0\to L_{-1}$: point indices $\{-1,0\}$, line indices
  $\{0,-1\}$.
- For $L_0\to P_4$: point indices $\{4,6\}$, line indices
  $\{0,-2\}$.
- For $L_0\to P_6$: point indices $\{4,6\}$, line indices
  $\{0,2\}$.

For $k\ge5$, the only blocked pursuer in each case is the source
itself, which is not a legal initial position. This gives every even
order $n=2k\ge10$.

For odd order $n=2k+1\ge13$, introduce a vertex $w$. Replace the
arcs $P_0\to L_0$ and $P_3\to L_3$ by
$$P_0\to w\to L_0,\qquad P_3\to w\to L_3. \tag{O}
$$
Each degree is still two. We verify the two-move property directly.
For an old missing pair and a pursuer other than $P_0,P_3,w$, its
old witnesses are unchanged: the danger set only gains the new vertex
$w$ and may lose old vertices. The pursuer at $w$ has missing
neighbors $L_0,L_3$, which cannot both occur in any of the four old
line danger sets, whose only nonzero differences are one or two.

A pursuer at $P_a$, $a\in\{0,3\}$, can use $w$ unless the source
is the other modified point or the recipient is $L_0$ or $L_3$.
In those cases $L_{a-1}$ is safe. Explicitly, for source $P_b$ with
$a\ne b$ its remaining old recipient is $L_{b-1}$ and the line
danger set is $\{L_{b-1}\}$. For old recipient $L_b$, the remaining
source is $P_{b+1}$ and the line danger set is
$\{L_b,L_{b+1}\}$. None contains $L_{a-1}$ when $k\ge6$ and
$a,b\in\{0,3\}$.

For a new pair $P_b\to w$, the danger set has point indices
$\{0,3\}$ and the single line index $b-1$, in addition to $w$.
Neither an adjacent line pair nor a point pair of difference two
fits; the other modified point pursuer also retains its different
line neighbor. For a new pair $w\to L_b$, the line indices are
$\{0,3\}$ and the point index is $b+1$, in addition to $w$.
Again all legal pursuers have a safe neighbor.

The remaining order $n=11$ has the following explicit missing rows:

$$\begin{aligned}
0&:\{4,8\},&1&:\{9,10\},&2&:\{8,9\},&3&:\{7,10\},\\
4&:\{0,1\},&5&:\{2,6\},&6&:\{3,5\},&7&:\{3,4\},\\
8&:\{2,7\},&9&:\{0,5\},&10&:\{1,6\}.
\end{aligned}$$

Every incoming and outgoing degree is two. For each source, its two
recipients in the displayed order give the following two danger sets:

$$\begin{array}{c|c|c}
s&D(s,t_1)&D(s,t_2)\\\hline
0&\{0,4,7,8\}&\{0,2,4,8\}\\
1&\{1,2,9,10\}&\{1,3,9,10\}\\
2&\{0,2,8,9\}&\{1,2,8,9\}\\
3&\{3,7,8,10\}&\{1,3,7,10\}\\
4&\{0,1,4,9\}&\{0,1,4,10\}\\
5&\{2,5,6,8\}&\{2,5,6,10\}\\
6&\{3,5,6,7\}&\{3,5,6,9\}\\
7&\{3,4,6,7\}&\{0,3,4,7\}\\
8&\{2,5,7,8\}&\{2,3,7,8\}\\
9&\{0,4,5,9\}&\{0,5,6,9\}\\
10&\{1,4,6,10\}&\{1,5,6,10\}
\end{array}$$

Inspection of the eleven rows shows that each danger set contains
only its source's row. Every legal pursuer therefore has a safe
missing neighbor. This finite set-containment argument proves the
eleven-vertex case and completes part 1. The accompanying certificate
also lists all 220 pair/pursuer witnesses explicitly.

## An envelope with one optional arc per vertex

For even order $n=2k$, retain (B) as $B$ and add the optional arcs
$$P_i\longrightarrow P_{i+6},\qquad
L_i\longrightarrow L_{i+4}. \tag{E}
$$
For $k\ge11$, condition (R) holds for the full envelope $F$.
There are six types of missing pairs. Their point and line danger
indices are respectively:

- $P_0\to L_0$: $\{6,0,1\}$ and $\{0,-1,-4\}$;
- $P_0\to L_{-1}$: $\{6,-1,0\}$ and $\{0,-1,-5\}$;
- $P_0\to P_6$: $\{6,0\}$ and $\{0,-1,2\}$;
- $L_0\to P_4$: $\{4,6,-2\}$ and $\{4,0,-2\}$;
- $L_0\to P_6$: $\{4,6,0\}$ and $\{4,2,0\}$;
- $L_0\to L_4$: $\{4,6,5\}$ and $\{4,0\}$.

Test line adjacency and point differences of two as before. The only
blocked compulsory pair belongs to the source. All index differences
tested have absolute value at most eight; $k\ge11$ introduces no
additional modular adjacency or difference of two. Thus (R) holds.

For odd order $n=2k+1$, with $k\ge16$ or $k=14$, use a different
placement of the new vertex $w$: replace $P_0\to L_0$ and
$P_7\to L_7$ by paths through $w$. Retain every optional arc in
(E), and add the single optional arc $w\to P_2$. The compulsory
graph has $2n$ arcs and the full envelope $3n$ arcs. We check (R).

For an old pair, every unmodified old pursuer retains its old safe
witness because the only new danger vertex is $w$. The compulsory
neighbors of the pursuer at $w$ are $L_0,L_7$. No translated line
danger set in the six-case list contains both: their integer
differences have absolute value at most six, while seven is not
congruent to any such nonzero difference modulo the stated $k$.

The remaining old pursuers are $P_a$, $a\in\{0,7\}$, with
compulsory neighbors $w,L_{a-1}$. If $w$ is in the danger set and
the source differs from $P_a$, only the following cases arise:

- The source is the other modified point $P_b$. Its retained old
  targets are $L_{b-1}$ and $P_{b+6}$. The respective line danger
  sets are $\{b-1,b-5\}$ and $\{b-1,b,b+2\}$.
- The recipient is $L_b$, $b\in\{0,7\}$. The remaining old
  sources are $P_{b+1}$ and $L_{b-4}$. Their line danger sets are
  $\{b+1,b,b-4\}$ and $\{b,b-4\}$.
- The recipient is $P_2$. Its old sources are $L_{-2},L_{-4},P_{-4}$,
  and their line danger sets are contained in
  $\{2,0,-2,-4,-5\}$.

None contains $a-1$ in its applicable case, for $k\ge16$ or
$k=14$. Thus the remaining compulsory neighbor is safe.

It remains to check the new missing pairs. In the following lists,
the danger set also contains $w$:

- For $P_b\to w$, $b\in\{0,7\}$, the point indices are
  $\{0,7,b+6\}$ and the only line index is $b-1$.
- For $w\to L_b$, the point indices are $\{2,b+1\}$ and the
  line indices are $\{0,7,b-4\}$.
- For $w\to P_2$, the point indices are $\{2,-4\}$ and the
  line indices are $\{0,7,-2,-4\}$.

The point sets contain no pair of difference two and the line sets
no adjacent pair at the stated moduli. For example, the largest
relevant point difference is 13, so it cannot become two when
$k\ge16$; modulo 14 it becomes $-1$, which is also harmless.
The line differences have absolute value at most eleven, so they
introduce no modular adjacency. A modified point pursuer, when
legal, retains a line neighbor $L_{-1}$ or $L_6$ outside its danger
set; the pursuer at $w$ is either the source or sees only one of
its two line neighbors in that set. This proves (R) at the stated odd
orders.

Four explicit repairs fill the remaining odd orders. On $2k+1$ vertices,
subdivide $P_0\to L_0$ and $P_j\to L_j$ through $w$ as above, retain
the optional arcs (E), and add $w\to P_z$. Make the following
substitutions in the optional list; every index is modulo $k$:

- At $n=23$, use $(k,j,z)=(11,5,0)$, replacing
  $L_1\to L_5$ by $L_1\to L_7$ and $L_7\to L_0$ by $L_7\to L_2$.
- At $n=25$, use $(k,j,z)=(12,5,2)$, replacing
  $L_1\to L_5$ by $L_1\to P_{10}$.
- At $n=27$, use $(k,j,z)=(13,6,2)$, replacing
  $L_2\to L_6$ by $L_2\to P_{12}$.
- At $n=31$, use $(k,j,z)=(15,5,0)$, replacing
  $L_1\to L_5$ by $L_1\to P_{10}$.

In each case the compulsory set has $2n$ arcs and the optional list
has $n$ distinct additional arcs. These are finite constructions:
`research/dense-phase2-certificates.json` supplies, for every full-envelope
pair and every legal pursuer, a compulsory neighbor outside its danger
set. The direct checker `src/dense_phase2_certificates.py` verifies each
listed witness using literal legal-move sets; an independent check is
recorded in `research/dense-phase2-independent-root-check.json`.
The certificate proves (R), so it covers every optional subset rather
than just the chosen total counts. Together with the parameterized
families, this establishes the bridge at every $n\ge22$.

### Six smaller envelopes

For $n=16,\ldots,21$, use the compulsory core (B), or its odd
modification (O). Identify $P_i=i$, $L_i=k+i$, and, in odd order,
$w=2k$, where $k=\lfloor n/2\rfloor$. The following ordered pairs
are optional missing arcs:

$$\begin{aligned}
O_{16}=\{&(0,12),(1,13),(2,13),(3,15),(4,15),(5,9),(6,10),\\
&(7,10),(8,1),(9,2),(10,3),(11,4),(12,5),(13,6),\\
&(14,7),(15,0)\}
\end{aligned}$$

$$\begin{aligned}
O_{17}=\{&(0,7),(0,11),(1,13),(2,14),(3,14),(4,16),(5,9),\\
&(6,8),(7,10),(8,3),(10,3),(12,5),(13,6),(14,10),\\
&(15,6),(16,1),(16,13)\}
\end{aligned}$$

$$\begin{aligned}
O_{18}=\{&(0,14),(1,14),(2,15),(4,16),(5,17),(6,9),(7,10),\\
&(8,11),(8,13),(10,1),(11,2),(12,3),(12,4),(13,5),\\
&(14,6),(14,9),(15,7),(17,8)\}
\end{aligned}$$

$$\begin{aligned}
O_{19}=\{&(0,3),(0,12),(1,2),(2,15),(3,15),(4,5),(5,9),\\
&(6,10),(6,18),(7,11),(8,11),(8,13),(12,18),(13,4),\\
&(14,6),(15,10),(16,9),(17,8),(17,13)\}
\end{aligned}$$

$$\begin{aligned}
O_{20}=\{&(0,13),(0,16),(1,14),(2,15),(3,18),(4,10),(4,18),\\
&(5,10),(9,12),(9,15),(10,9),(11,17),(12,2),(13,3),\\
&(13,17),(14,5),(15,6),(17,11),(18,14),(19,8)\}
\end{aligned}$$

$$\begin{aligned}
O_{21}=\{&(0,3),(1,14),(1,16),(2,18),(3,18),(6,11),(7,11),\\
&(8,12),(8,14),(9,12),(11,1),(11,15),(12,2),(13,20),\\
&(15,6),(15,19),(17,6),(17,7),(18,8),(18,10),(18,14)\}
\end{aligned}$$

Each list contains exactly $n$ distinct arcs outside the compulsory
set of $2n$ arcs. For every missing pair in the full envelope and
legal initial pursuer, the archived certificate explicitly supplies
$u\in N_B^+(c)$ with $(s,u),(u,t)\notin F$ and
$u\notin\{s,t,c\}$. These are precisely the obligations in (R).
The archives are
`research/routing-defect-phase2-dense-tiny-checks.json` for orders
$16,17,18$ and `research/routing-defect-phase2-dense-small-checks.json`
for $19,20,21$; at order 18 the archived full envelope is larger,
so the displayed subset inherits its witnesses.

Separate literal readback programs, importing neither the producer
nor its graph helpers, check every stored witness and its complete
pair/pursuer coverage. Their receipts are
`research/routing-defect-phase2-dense-tiny-independent.json` and
`research/routing-defect-phase2-dense-small-independent.json`. In addition,
`SmallDenseEnvelopes.lean` checks all six row lists, the base and envelope
arrow counts, and every required safe witness by kernel reduction. The
robust-envelope semantic theorem then proves actual two-move delivery
for every intermediate graph, against arbitrary legal pursuer choices.
This verifies every optional subset, not just a single graph at
$h=3n$. Together with the preceding families, it completes part 2
for every $n\ge16$.

## Quadratic envelopes from a shared danger-set calculation

The interval can be enlarged while keeping just two compulsory missing
neighbors per pursuer. In a core with indices modulo $k$, use
$$P_i\to L_i,L_{i-1},\qquad L_i\to P_{i+\alpha},P_{i+\beta},$$
and optional arcs $P_i\to P_{i+d}$ for $d\in D$ and
$L_i\to L_{i+e}$ for $e\in E$. Translate the source index to zero.
The six full-envelope danger sets have the following point and line
index parts:

$$\begin{array}{c|c|c}
\text{pair}&\text{point indices}&\text{line indices}\\\hline
P_0\to L_0&D\cup\{0,1\}&\{0,-1\}\cup(-E)\\
P_0\to L_{-1}&D\cup\{-1,0\}&\{0,-1\}\cup(-1-E)\\
P_0\to P_d&D\cup(d-D)&\{0,-1,d-\alpha,d-\beta\}\\
L_0\to P_\alpha&\{\alpha,\beta\}\cup(\alpha-D)&E\cup\{0,\alpha-\beta\}\\
L_0\to P_\beta&\{\alpha,\beta\}\cup(\beta-D)&E\cup\{0,\beta-\alpha\}\\
L_0\to L_e&\{\alpha,\beta,e,e+1\}&E\cup(e-E)
\end{array} \tag{T}$$

Condition (R) asks whether the line part contains an adjacent pair, or
the point part contains a compulsory pair of difference $\beta-\alpha$,
belonging to a pursuer other than the source. This single calculation
will establish both caps in part 4.

### A residue-five family at every order from 30

Write $n=10q+s$, where $q\ge3$ and $0\le s\le9$, and put $k=5q$.
Take $(\alpha,\beta)=(4,6)$ and
$$D=\{10,15,\ldots,k-5\},\qquad E=\{5,10,\ldots,k-5\}.$$
Add vertices $x_0,\ldots,x_{s-1}$ with compulsory missing rows
$$N_B^+(x_a)=\{P_a,L_{a+3}\}.$$
There are no missing arcs from the core to these vertices. Permit
every directed nonloop arc between added vertices as an additional
optional missing arc.

First consider only old sources and pursuers. The multiples-of-five
sets in (T) contain neither adjacent indices nor indices of difference
two. In the four compulsory-pair rows of (T), a compulsory cop row
can be contained only when it is the source's own row. For
$P_0\to P_d$, the line set $\{0,-1,d-4,d-6\}$ acquires an
additional adjacent pair only at $d=2,4,5,7$; values $3$ and $6$
merely duplicate the source row. Only $5$ is a multiple of five,
and it is excluded from $D$. For $L_0\to L_e$, the apparent
extra difference-two pair at $e=5$ is just the existing pair
$\{4,6\}$. Thus old legal pursuers always have a witness.
These modular statements hold because $5\mid k$ and $k\ge15$.

An added cop has point/line index difference three. For an optional
$P\to P$ pair, the point danger has the source's residue, while its
line residues differ by $0,1,4$; difference three is absent. For an
optional $L\to L$ pair, the line danger has one residue and the
point residues differ from it by $0,1,4$, again excluding the row.
The four compulsory cases in (T) give the same exclusion except
possibly $(P_{i+1},L_{i-1})$ or $(P_{i+4},L_{i+2})$. Their actual
line-minus-point difference is $-2$, which cannot equal three
modulo $k\ge15$. Hence added cops also retain witnesses.

For a new source $x_a$ targeting $P_a$, the old danger parts are
$$\{P_a\}\cup\{P_{a-d}:d\in D\},\qquad
\{L_{a+3},L_{a-4},L_{a-6}\}.$$
The first lies in one residue class. The second has pairwise
differences $7,9,2$, none congruent to $\pm1$ modulo $k\ge15$.
Neither old row type is blocked. An added row from $x_b$ would require
$b-a$ to be a multiple of five and one of $0,-7,-9$, forcing $b=a$,
the excluded source. For recipient $L_{a+3}$, the old point danger
is $\{P_a,P_{a+3},P_{a+4}\}$, whose differences $1,3,4$ cannot
be $\pm2$; the old line danger has one residue class. An added cop
would require $b-a\in\{0,3,4\}$ to be a multiple of five, again
forcing $b=a$.

Finally, an optional pair $x_a\to x_b$ has old danger exactly
$\{P_a,L_{a+3}\}$. It contains neither an old row nor a distinct
new row. Incoming arrows from added vertices only add new vertices
to other danger sets, whereas every compulsory row lies in the old
core. They cannot spoil any witness. This proves (R).

There are $4k+2s=2n$ compulsory missing arcs,
$k((q-2)+(q-1))$ optional core arcs, and $s(s-1)$ optional added
arcs. Their total is exactly $H_5(n)=10q^2+5q+s^2+s$.

### A parity family with quarter-density cap

Write $n=4q+s$, $q\ge11$, $0\le s\le3$, and put $k=2q$.
Take $(\alpha,\beta)=(4,7)$. Let $D$ consist of all nonzero even
residues except $\pm2,\pm4,\pm6,\pm8$, and let $E$ consist of
all nonzero even residues except $\pm2,\pm4,8,10,12$.
For each $0\le a<s$ add a vertex with compulsory row
$$N_B^+(x_a)=\{P_a,P_{a+5}\},$$
and again permit all nonloop missing arcs between added vertices,
with none from old vertices to new ones.

Both forbidden row differences in (T) are odd: one for a point cop,
three for a line cop. Since $D,E$ contain only even indices, testing
the exceptional even/odd pairs in each row of (T) gives the following
possible offsets for a blocked old cop other than the source:

- $P_0\to L_0$: $4,-2$ in $D$, or $2$ in $E$;
- $P_0\to L_{-1}$: $2,-4$ in $D$, or $-2$ in $E$;
- $P_0\to P_d$: $d=2,8$;
- $L_0\to P_4$: $-6$ in $D$, or $-2,-4$ in $E$;
- $L_0\to P_7$: $6$ in $D$, or $2,4$ in $E$;
- $L_0\to L_e$: $e=0,10$.

All these offsets are excluded. Coincidences that merely reproduce
the source row do not block another cop: adjacent pairs and pairs
of difference three have unique source indices when $k\ge22$.

An added cop has a point pair of difference five. In the same six
point-danger sets, such a pair would require respectively offsets
$6,-4$ in $D$; $4,-6$ in $D$; no possibility in the all-even third
case; $2,-8$ in $D$; $-2,8$ in $D$; or $-2,8,2,12$ in $E$.
Every exception is excluded, so added cops are safe against old pairs.

For a new source $x_a$ targeting $P_a$, its old point danger is
$$\{P_a,P_{a+5}\}\cup\{P_{a-d}:d\in D\},$$
and its old line danger is $\{L_{a-4},L_{a-7}\}$.
The latter is not adjacent. A difference-three point pair would
require $d=-2$ or $-8$, excluded from $D$. For recipient $P_{a+5}$,
the point danger is
$$\{P_a,P_{a+5}\}\cup\{P_{a+5-d}:d\in D\};$$
the same test requires the excluded offsets $2,8$. Its line danger
again has difference three. A distinct added row could be contained
only if $b=a$ or $b=a\pm5$ modulo $k$: one parity occurs just once
in the point danger. The first is the source and the others are
impossible for $a,b\in\{0,1,2\}$ and $k\ge22$.

For a new-to-new pair, the old danger is the source's difference-five
point pair, containing no old row and no distinct added row. As before,
new danger vertices belong to no compulsory row. This proves (R).

The eight exclusions in $D$ and seven in $E$ are distinct because
$k\ge22$, so $|D|=q-9$ and $|E|=q-8$. There are $2n$ compulsory
missing arcs and $k(2q-17)+s(s-1)$ optional ones, totaling
$H_4(n)=4q^2-26q+s^2+s$. Part 4 follows by selecting any desired
number of optional arcs.

### Comparison and proof boundary

The improvement retains the old small-order domains. For $n\ge30$,
$$H_5(n)-3n=5q(2q-5)+(s-1)^2-1\ge14.$$
Also
$$\begin{aligned}
13H_5(n)-n(n+11)
&=30q^2-45q-20qs+12s^2+2s\\
&\ge\frac{260(q-1)^2-261}{12}>0.
\end{aligned}$$
Since $\lceil(n-1)/13\rceil\le(n+11)/13$, this strictly exceeds
the cap $n\max\{3,\lceil(n-1)/13\rceil\}$ of Theorem 48.
For $H_4$, the difference from $3n$ is at least $65$ and
$$13H_4(n)-n(n+11)=36q^2-382q-8qs+12s^2+2s.$$
At $q=11$ its values are $154,80,30,4$, and each increases with $q$.
Thus this family also strictly exceeds the old cap at every $n\ge44$.

The twenty residue classes modulo $20$ show $H_4(n)>H_5(n)$ for
every $n\ge52$. Indeed it holds at $52,\ldots,71$, and if
$n=20t+u$, the difference increases on replacing $n$ by $n+20$ by
$$120t-80+40\bigl(\lfloor u/4\rfloor-\lfloor u/10\rfloor\bigr)>0.$$
For the old orders $n=19,\ldots,29$, that cap is exactly $3n$,
already covered by part 2. Thus the present envelopes subsume its
entire numerical statement, preserving the time, algorithm, and
arbitrary-subset conclusions at every old order. No earlier domain
is lost.

The two cap formulas have ordinary proofs above. The independent review
`research/dense-phase2-uniform-independent-audit.md` checks their modular
exceptions and counts. The primary receipts
`research/dense-phase2-uniform-envelope.json` and
`research/dense-phase2-quarter-envelope.json` additionally check bounded
full-envelope games; those samples are not used to infer the formulas.

## The first forced loss at every order from 16

Use an even core of order $2k\ge12$, or its odd modification (O)
of order $2k+1\ge13$. Add four vertices $c,x,y,z$ and missing arcs
$$c\to x,\quad x\to y,z,\quad
y\to a,b,\quad z\to d,e. \tag{A}
$$
In the even case choose $(a,b,d,e)=(P_0,P_3,P_1,P_4)$. In the
odd case choose $(a,b,d,e)=(P_1,P_4,P_2,P_5)$. The four attachments
are distinct; each branch pair has index difference three, hence
neither one nor two modulo $k\ge6$.

For an old missing pair, old pursuers retain their old safe neighbors,
since the danger set only gains $y$ or $z$. A pursuer at $c$ uses
$x$. A pursuer at $x$ can use $y$ or $z$: no old recipient receives
both branches. The pursuers at $y,z$ have point pairs of difference
three, which cannot fit into the old point danger pairs of difference
one or two. In the odd core there is also the point danger set
$\{P_0,P_3\}$ for a pair ending at $w$; neither chosen branch is
that pair. The other new old-core pairs have at most one point in
their danger set.

For a new pair with source $y$ or $z$ and recipient an attachment
$P_t$, ordinary point pursuers have adjacent line neighbors while
the old incoming line pair of $P_t$ has difference two. Ordinary
line pursuers have point-neighbor difference two while the branch
pair has difference three. In the odd core, the modified point
pursuers use $w$, and the pursuer at $w$ has line neighbors of
difference three, which cannot both lie in the incoming pair of
difference two. The opposite branch is disjoint, $x$ can use that
opposite branch, and $c$ can use $x$. Thus these four pairs win.
The pair $c\to x$ also wins: no missing neighbor enters $c$, and
every other pursuer has two missing neighbors, at least one outside
$\{c,x\}$.

Exactly the pairs $(x,y),(x,z)$ fail. A pursuer at $c$ has closed
move set $V\setminus\{x\}$ in the delivery graph and blocks every
nonterminal departure from $x$. All other initial pursuers have safe
neighbors for those pairs. The construction has $2n-1$ missing arcs,
so $2n-3$ pairs count. This proves the first-step assertion for all
$n\ge16$.

## Functional roots and the rest of the staircase

Use the spare functional vertex when the order is odd. On $r\ge2$ vertices put
$j=\lfloor(r-2)/2\rfloor$, retain the missing chains
$s_i\to t_i\to a$ and the cycle $a\leftrightarrow b$, and, for odd
$r$, put the remaining vertex $z\to a$. The set of vertices with
no missing incoming arc is
$$R=\{s_1,\ldots,s_j\}\quad\hbox{together with $z$ when $r$ is odd}.$$
Consequently $|R|=\lfloor(r-1)/2\rfloor$.

Add $k$ vertices, each with a distinct two-element missing-neighbor
set in $R$. This is possible whenever
$$k\le\binom{\lfloor(r-1)/2\rfloor}{2}. \tag{F}
$$
It guarantees exactly $j+2k$ counted pairs. Against a functional
pursuer, its unique missing neighbor is outside $R$ and outside the
added vertices, so it is safe for every added source and its two
recipients. Against another added pursuer, choose a member of its
two-element set outside the source's set. Any two distinct roots
are joined in the delivery graph. The original pairs $(s_i,t_i)$
also survive: an added pursuer has a root neighbor different from
$s_i$, and that root has a direct delivery arc to $t_i$. This
argument includes the extra root $z$. Theorem 27 gives the matching
upper bound.

Now fix $n\ge20$ and $1\le r\le n$, and put $k=n-r$. The first
step is already proved. For $r\ge2$ and $k\ge10$,
join the functional $r$-vertex graph to the direct $k$-vertex core;
Lemma 28 preserves $j+2k$ guarantees. If $1\le k\le9$ remains,
then $r\ge11$, so (F) holds because
$$\binom{\lfloor(r-1)/2\rfloor}{2}\ge\binom52=10\ge k.$$
Finally $k=0$ is the functional endpoint in Theorem 13. Since
$$j+2k=2n-r-\lceil r/2\rceil-1,$$
this proves part 3. More precisely, the same formula holds whenever
$r\ge2$ and either the core condition or (F) applies, including
smaller orders than 20; the endpoint $r=n$ holds at every $n\ge2$.

All recipes consist of modular arc lists and elementary subset choices,
and therefore take polynomial time. The receipt
`research/dense-unified-core-checks.json` records bounded complete
two-move and robustness checks from `src/dense_unified_core.py`.
The parameterized proofs above do not depend on those finite tests.
The explicitly isolated eleven-vertex core and small optional
envelopes have the finite proofs and certificates described above.
The infinite families and their general existence proofs remain ordinary
arguments. The finite eleven-vertex core and the six small envelopes have
Lean coverage in `ElevenVertexDense.lean` and `SmallDenseEnvelopes.lean`,
as detailed in the formal verification section.

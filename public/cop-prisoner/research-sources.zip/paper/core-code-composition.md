# Composition through incomparable hub sets

The construction below reduces a delivery problem on an arbitrarily large
outside set to a family of subsets of a small core. The subsets specify
which hubs an outside vertex cannot reach. Incomparability makes one outside
vertex's inaccessible hubs available to another vertex. A two-part core
handles the remaining configurations, including recipients inside the core.
This produces an entire robust interval of exact budgets.

**Theorem 59 (antichain composition).** Let $k\ge5$. Take two sets of hubs
$P_i,L_i$, indexed modulo $k$. Their missing arrows are
$$P_i\to L_i,L_{i-1},\qquad L_i\to P_{i+4},P_{i+6};$$
all other distinct hub pairs are arrows. For each of $q$ outside vertices
$x$, choose a set $K_x$ of hubs subject to these conditions:

* $|K_x|\ge2$, and $K_x$ lies entirely in one of the two hub parts;
* a set in the $P$ part contains no two indices differing by $\pm2$;
  a set in the $L$ part contains no adjacent indices;
* a two-element code contains no pair at either cyclic difference $\pm1$ or $\pm2$;
* the sets $K_x$ form an antichain: no one contains another.

Include every hub-to-outside arrow, and include $x\to u$ for precisely the
hubs $u\notin K_x$. Every subset of the arrows between distinct outside
vertices may then be included. Every resulting graph has universal delivery
within two messenger moves.

Writing $n=2k+q$ and $W=\sum_x|K_x|$, this gives every exact budget
$$A\le m\le A+q(q-1),\qquad A=2k(2k-3)+4kq-W.$$
At the upper endpoint the number of missing arrows is $4k+W$. The assertion
holds for every optional subset, not merely a specially chosen subset of
each size.

**Proof.** Let $F$ denote the missing graph inside the hubs. For a missing
pair $(s,t)$ and a pursuer at $c\ne s$, we seek a hub $u$ with arrows
$s\to u\to t$, with $u\ne c$ and no arrow $c\to u$. The messenger can
move to $u$, survive every pursuer response, and then reach $t$. The case
$c=t$ is included.

First suppose all three vertices are hubs. For a missing hub pair, the
set $D=F^+(s)\cup F^-(t)$ contains two points and two lines. If $s=P_i$,
the line indices are $i,i-1$ and the point indices are either $i,i+1$ or
$i-1,i$. A point pursuer has its entire missing row in $D$ only when it
is $s$; a line pursuer's point pair has difference two and cannot fit
inside the adjacent point pair. If $s=L_i$, the point indices are
$i+4,i+6$ and the line indices are either $i,i-2$ or $i,i+2$. The same
argument with the two parts exchanged applies. Thus $F^+(c)$ contains a
hub outside $D$, which is the desired intermediary.

Now consider the other nondirect configurations.

1. **Both endpoints outside.** If the pursuer is outside, choose
   $u\in K_c\setminus K_s$, which exists by incomparability. It is
   reachable from $s$, inaccessible from $c$, and reaches $t$. If the
   pursuer is a hub, its missing row consists of an adjacent line pair
   or a point pair of difference two. The restrictions on $K_s$ prevent
   that entire row from lying in $K_s$. A remaining member works.

2. **Source outside, recipient a hub.** Missingness means $t\in K_s$.
   For an outside pursuer whose code lies in the same part, choose
   $u\in K_c\setminus K_s$; that part is a clique, so $u\to t$.
   For an outside pursuer using the other part, $K_c$ is disjoint from
   $K_s$. Its code cannot fit inside $F^-(t)$: a larger code has at least
   three members, and a pair code has neither of that row's possible
   differences, one and two. Thus a member reaches $t$. For a hub pursuer
   whose missing row lies in the part containing $t$, the code restriction
   leaves a member outside $K_s$, and the clique supplies the last arrow.
   For the other hub pursuer part, both missing neighbors are reachable
   from $s$. Their adjacent or difference-two pair cannot equal the
   opposite kind of pair $F^-(t)$, so at least one reaches $t$.

3. **Both endpoints hubs, pursuer outside.** The set $D$ above contains
   only two members in either part, with cyclic difference one or two.
   A larger code cannot fit in that part, and a pair code excludes both
   differences. Hence $K_c\setminus D$ contains an intermediary.

A hub source reaches an outside recipient directly. All intermediaries
used in the proof are hubs, so optional arrows between outside vertices
cannot invalidate a witness. Counting the compulsory and optional arrows
gives the stated interval. $\square$

![Two incomparable missing-hub sets leave a hub that the source can reach but the pursuer cannot. Every hub reaches the outside recipient, completing a safe two-move delivery. The theorem separately handles recipients and pursuers inside the core.](figures/antichain-routing.pdf){width=90%}

**Corollary (separated pair codes).** For $k\ge6$, there are $k(k-5)$
permitted pair codes. For $0\le q\le k(k-5)$, put $n=2k+q$. Every budget
$$ B\le m\le n(n-3),\qquad B=(4k-2)n-2k(2k+1) $$
has an explicit attainer with two-move delivery and every optional subset.

**Proof.** Each hub index has $k-5$ partners after excluding itself and
differences $\pm1,\pm2$. The two parts supply $k(k-5)$ pairs. Distinct
pairs form an antichain. List the point pairs, then line pairs,
lexicographically, and take the first $q$. Theorem 59 with $W=2q$ gives
base $B$ and terminal missing count $4k+2q=2n$. Take the desired optional
prefix in ordered-endpoint order. The original codes of size at least
three, and the $k=5,q=0$ core, remain unchanged. $\square$

## The main interval above three arrows per vertex

**Theorem (pair-code overlap).** Every $n\ge79$ and
$3n\le m\le n(n-3)$ has an explicit attaining graph.

**Proof.** Choose the least $k\ge6$ with $n\le k(k-3)$. Then $2k\le n$
and the pair corollary supplies $B\le m\le n(n-3)$. Theorem 38 supplies
$3n\le m\le T=n(\lceil n/7\rceil-1)$, with $T\ge5n$.
The five-offset circle with admissible $h$ reaches at least $n(n-h-1)/2$,
starting at $5n$. The following direct parameter rules make the intervals meet.

For $79\le n\le108$, take $h=7$ unless $7\mid n$, then $h=11$.
The $h=7$ lower cap exceeds $B$ on $80\ldots88$ ($k=11$) and
$89\ldots108$ ($k=12$): check each left endpoint and the increasing
quadratic difference. At 79 its exact cap is $2844>B=2812$.
The $h=11$ cases are $84,91,98,105$; their lower cap $n(n-12)/2$ exceeds
$B$, first by 2 at 84 and by $17/2$ at 91, then increasingly.

For $109\le n\le827$, choose the first coprime $h$ in $7,11,15,19$.
Failure requires $7\cdot11\cdot19$ and either 3 or 5 to divide $n$,
forcing $n\ge4389$. All circle hypotheses hold. The cap is at least
$n(n-20)/2$. Here $k\ge13$, and minimality gives $n\ge N=k^2-5k+5$.
The cap minus $B$ increases from $N$; twice its value there, with $u=k-13$,
is
$$k^4-18k^3+67k^2-6k-55=u^4+34u^3+379u^2+1398u+205>0.$$

For $n\ge828$, Theorem 38 alone reaches $B$. Subtracting $B$ from
$n^2/7-n$ gives $f=n^2/7-(4k-1)n+4k^2+2k$. At $k=31,n=828$ and
$k=32,n=869$ it is respectively $18/7$ and $11740/7$, and increases
through both ranges. For $k\ge33$, minimality gives
$n\ge k^2-5k+5\ge28k-7$, so $n^2/7-n\ge(4k-2)n>B$.
All choices use arithmetic and optional prefixes, with no graph search.
$\square$

`src/main_interval_pair_codes.py` implements the direct rules;
`src/main_interval_pair_codes_check.py` independently reconstructs witnesses
and coverage. Its receipt is `research/main-interval-pair-code-checks.json`.
The separated pair-code construction and its overlap from order 79 are also instantiated in `PairCodeConstruction.lean` and `PairCodeOverlap.lean`. The retained larger and mixed codes below keep their separate proof boundaries.
The former classification-overlap proof is preserved in
`research/history/before-slimming-core-code-composition.md`. The following
independent stronger construction results remain part of the paper.

## Retained larger and mixed codes

**Equal-weight codes at every core parity.** For a cycle of length $t\ge3$,
write $C(t,0)=1$, put $C(t,j)=0$ if $j<0$ or $2j>t$, and otherwise put
$$C(t,j)=\frac{t}{t-j}\binom{t-j}{j}.$$
This counts its independent $j$-sets: for $j\ge1$, distinguish a selected
vertex and distribute the unselected vertices among the $j$ nonempty
gaps. Dividing by the $j$ choices of distinguished selected vertex gives
$\frac{t}{j}\binom{t-j-1}{j-1}$, the same expression.

For every $k\ge5$ and $3\le r\le\lfloor k/2\rfloor$, the total number
of permitted size-$r$ codes in the two hub parts is
$$Q(k,r)=C(k,r)+
\begin{cases}
C(k,r),&k\text{ odd},\\
\displaystyle\sum_{j=0}^{r}C(k/2,j)C(k/2,r-j),&k\text{ even}.
\end{cases}$$
Indeed, the forbidden graph in the line part is a $k$-cycle. For odd
$k$, multiplication by two identifies this cycle with the forbidden
difference-two graph in the point part. For even $k$, the even and odd
indices instead form two disjoint cycles of length $k/2$. Choosing $j$
indices in one and $r-j$ in the other gives the displayed convolution.
The two parts have disjoint hub labels, so their counts add. All distinct
size-$r$ codes are incomparable.

Consequently every $q\le Q(k,r)$ supplies the explicit interval in
Theorem 59, with
$$A=(4k-r)n-2k(2k+3-r),\qquad L-A-q(q-1)=2n+(r-2)q.$$
List independent sets by taking increasing indices with at least one
unselected index between consecutive selections and across the cyclic
boundary. For even cores, list the two component choices in increasing
order of $j$ and then in lexicographic order within each component. List
line codes first, then point codes, and take the first $q$. This gives a
concrete rule from $(k,r,q)$ without pursuit-game search. It includes all
previous odd-core ranges. The implementation and independent counting and
asymmetric witness checks are `src/core_code_all_parities.py` and
`src/core_code_all_parities_check.py`; the original odd-core implementation
and its earlier receipts remain available unchanged.

For example, $Q(10,3)=100$, giving
$37n-400\le m\le n(n-1)-(3n-20)$ for $20\le n\le120$.
The fixed mixed list at order 105 contains 85 incomparable $k=10$ codes
of total weight 268, giving every budget $3472\ldots10612$.
At order 116 the saved $k=11$ list has two size-five and 92 size-four
codes, weight 378, giving $4176\ldots12918$: the two larger codes exclude
at most ten of the 110 available size-four codes. The literal lists and
independent witnesses remain in `research/core-code-third-mixed-105.json`
and `research/routing-defect-phase2-mixed-code-checks.json`.
These families retain two-move delivery and every optional subset. Their
stronger two-move sparsity consequences remain in the
[delivery-time companion](https://angelraychev.com/cop-prisoner/delivery-time/#antichain-two-move-sparsity).

## Retained wider protected circles

Here we use the protected differences of Theorem 38 without changing its
strategy. Let $h$ be an allowed odd step, $a=(h-1)/2$, and
$$A_0=\{0,1,a,2a+1\},\qquad
D=\{\pm(a-1),\pm(a+1),\pm2a\}.$$
Put $p=3a-1$ and
$$J=\{jp+t:0\le j<\lfloor n/p\rfloor,\ 0\le t<a-1\}.$$
No difference between two members of $J$ belongs to $D$: within a run it
has magnitude at most $a-2$, while between runs, including the cyclic gap,
the shortest gap is at least $2a+1$. For any translate $J+v$, remove all
members of $A_0\cup(A_0+D)$ and then adjoin $A_0$. Every protected difference
still has exactly its original representation. Thus the result is an
allowed envelope in Theorem 38. The excluded set has at most 19 elements,
by expanding the four translates of the six differences. Averaging over
$v$ gives an envelope of size at least
$$4+\left\lceil\frac{|J|(n-19)}{n}\right\rceil.$$
One may then apply the greedy extension from Theorem 38. In particular the
old guarantee $|A|\ge\lceil n/7\rceil$ is preserved. Searching the $n$
translations is explicit and takes polynomial time.


The literal protected sets at orders $100\ldots111$ remain in
`research/core-code-third-circle-envelopes.json`, supplying every budget
$3n\ldots n(|A|-1)$. At order 117, the explicit envelope
$\{0,1,20\}\cup[41,59]\cup[100,115]$ with $h=41$ has 38 members and
exactly one representation of each protected difference, retaining
$351\ldots4329$. Its independent check and the order-116 mixed codes remain
in `research/routing-defect-phase2-mixed-code-checks.json`. Original
implementations and receipts remain unchanged. `RobustTwoMove.lean` proves
the semantic implication from supplied witnesses, not the combinatorial
construction or the complete classification.

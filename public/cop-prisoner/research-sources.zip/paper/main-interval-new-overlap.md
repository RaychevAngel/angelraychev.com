# The main interval above three arrows per vertex

The circle and guide constructions reduce the order needed for the broad
main interval. The distinction between its first linear segment and its
remaining budgets is now explicit.

**Theorem (expanded main interval).** There are explicit attaining
constructions with
$$M(n,m)=n(n-1)-m$$
throughout both of the following domains:

1. Every $n\ge43$ and $3n\le m\le n(n-3)$.
2. Every $n\ge104$ and $2n\le m\le n(n-3)$.

The thresholds are sufficient, not claimed necessary. Every construction
comes with a concrete adjacency rule and arithmetic parameter selection;
no new graph search or derandomization is required for a given $(n,m)$.
The individual families retain their optional-subset and delivery-time
guarantees. The combined statement imposes no uniform two-move deadline.

**Proof.** For $n\ge106$, the previous complete main-interval theorem
already applies. It remains to cover the finite range $43\le n\le105$.
Here we combine the following proved intervals, taking only parameters
satisfying their stated arithmetic hypotheses:

* The protected three-jump circle, from $3n$ through
  $n(\lceil n/7\rceil-1)$, reaches at least $5n$.
* The new five-jump circle reaches $n(|A|-1)$, using a full modulo-four
  envelope or its guarded version as appropriate.
* The twelve- and fourteen-hub guide constructions provide their displayed
  exact intervals, with $2\le r\le g$ and enough distinct guide subsets.
* The equal-weight antichain construction of Theorem 59 provides its
  explicit interval at each admissible core size and code weight.
* The earlier dense envelopes finish at $n(n-3)$, starting no later than
  $n(n-1)-n\max\{3,\lceil(n-1)/13\rceil\}$.

The finite parameter certificate
`research/main-interval-expanded-checks.json` lists a covering chain at
every order $43,\ldots,105$. Each chain starts at $3n$, or at $2n$ for
orders 104 and 105, and adjacent integer intervals meet without a missing
budget. All parameters are integers checked against the preceding
formulas. The two smaller starting budgets use the already certified
canonical sparse envelopes: order 104 covers 208 through 316, and order
105 covers 210 through 327. Both reach $3n$.

This is a finite certificate of parameters and inequalities for proved
families, rather than a collection of unverified game outcomes. The
selector enumerates only the displayed arithmetic parameters, takes a
covering family in a fixed order, and selects the prescribed number of
optional arrows. The direct constructor
`src/main_interval_expanded.py` implements this rule. Its separate check
constructs graphs at the ends and middle of each selected interval and
checks their exact arrow counts. The original constructor is used
unchanged above order 105. This proves both assertions. $\square$

For example, at order 60 the new circle covers 300 through 1740 and the
twelve-hub guide family covers 1162 through 3042. The preceding sparse,
protected-circle and dense constructions cover the two ends of the main
interval. Their overlap fills every budget from 120 through 3420.

![At order 60, the five-jump circle and guide layer bridge the previously uncovered budgets 841 through 1655. The horizontal bars are exact construction intervals; their overlap provides every integer budget.](figures/main-interval-progress.pdf){width=100%}

Combining the second domain with the previously proved sparse and dense
formulas strengthens Corollary 47 to every $n\ge104$ and $m\ge22$.
Budgets 12 through 21 remain a separate small-support problem. At orders
below 104, the remaining gap inventory distinguishes $2n<m<3n$ from
the uncovered main budgets at orders at most 42. Neither the new domain
nor a successful finite construction implies attainment at an unlisted pair.

The ordinary circle and guide proofs have independent local and actual-game
rank checks. `RobustLayers.lean` proves that supplied strictly decreasing
base/envelope source ranks imply actual delivery, and that safe entry into
a routing region adds one move. The modular identities, guide-code premises,
parameter coverage and extremal counting conclusions remain ordinary proofs;
they are not claimed to have been formalized by that semantic lemma.

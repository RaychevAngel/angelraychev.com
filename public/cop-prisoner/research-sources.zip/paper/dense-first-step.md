# Exact final dense band

**Theorem 32.** For every $n\ge16$,
$$M\bigl(n,n(n-3)+1\bigr)=2n-3.$$
A deterministic attaining graph guarantees all but two of its missing
pairs within two messenger moves.

**Proof.** Use the four-vertex attachment to a direct two-type core in
Theorem 58. The graph has $2n-1$ missing arcs. Exactly the two missing
pairs leaving the attachment's vertex $x$ are blocked by a pursuer at
$c$; every other missing pair has a safe two-move intermediary.
Theorem 27 gives the matching upper bound. $\square$

**Corollary 33 (the complete final dense band).** For every $n\ge20$
and every integer $1\le r\le n$,
$$
\boxed{M\bigl(n,n(n-3)+r\bigr)
=2n-r-\left\lceil\frac r2\right\rceil-1.}
$$
Equivalently, for every integer $n\le h\le2n-1$,
$$M\bigl(n,n(n-1)-h\bigr)
=h-\left\lceil\frac{2n-h}{2}\right\rceil-1.$$
There is a deterministic polynomial attaining construction at every
such budget, with a two-move strategy for every counted pair.

**Proof.** Theorem 27 gives the upper bound. The first step is
Theorem 32. For $r\ge2$, put $k=n-r$. If $k\ge10$,
Theorem 29 applies. Every remaining positive $k$ is at most nine, so
$r\ge11$ and
$$\binom{\lfloor(r-1)/2\rfloor}{2}\ge\binom52=10\ge k.$$
Proposition 31 applies. Finally $k=0$ is the functional endpoint of
Theorem 13. $\square$

Together with Theorem 19 at $m=n(n-3)$ and Theorem 13 above
$m=n(n-2)$, this determines the joint maximum for every $n\ge20$
and $m\ge n(n-3)$. At the boundary the value is $2n$; the next
step has value $2n-3$; the staircase then reaches
$\lfloor(n-2)/2\rfloor$ before becoming zero. The proof does not
assert that 20 is the smallest possible whole-band threshold.

The core and attachment formulas and their complete ordinary proofs
are given together in Theorem 58. The eleven-vertex core is listed explicitly and independently checked;
its two-move guarantee is also formalized in Lean. `DenseFirstStep.lean`
also proves the first-step maximum and explicit attainment from order 16,
and `DenseSharpClassification.lean` supplies the complete dense values
and explicit attainers from order eleven. Supplementary guarantees retain
their separately stated proof boundaries.

![The complete final dense band at n=100. The solid curve is the proved exact maximum at every integer budget; the dashed line counts all missing pairs and does not account for forced failures.](figures/dense-staircase.pdf)

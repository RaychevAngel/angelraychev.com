# Completing the final dense band

**Theorem 32.** For every $n\ge68$,
$$M\bigl(n,n(n-3)+1\bigr)=2n-3.$$
An explicit attaining graph guarantees all but two of its missing pairs within two messenger moves.

**Proof.** Theorem 27 gives the upper bound. For attainment put $k=n-4\ge64$, and take a four-regular undirected graph $H$ of girth at least six on $k$ vertices, supplied by Theorem 19. Choose four distinct vertices $a,b,d,e$ with
$$
\operatorname{dist}(a,b),\operatorname{dist}(d,e)\ge4,
\qquad
\operatorname{dist}(u,v)\ge2
\quad(u\in\{a,b\},\ v\in\{d,e\}).
$$
Distances between components are infinite. A radius-three ball in a graph of maximum degree four has at most $1+4+12+36=53$ vertices. After choosing $a$, choose $b$ outside that ball. Choose $d$ outside the closed neighborhoods of $a,b$, whose union has size at most ten. Choose $e$ outside this union and the radius-three ball of $d$. At most $63$ vertices are excluded, so all choices exist when $k\ge64$.

Orient Euler tours of $H$. Add four vertices $c,x,y,z$ and the seven missing arcs
$$c\to x,\qquad x\to y,z,\qquad y\to a,b,\qquad z\to d,e.$$
Let $F$ be this missing-edge graph and $G$ its directed complement. Every vertex has outdegree two in $F$ except $c$, whose only outgoing arc is $c\to x$. The unique incoming neighbors of $x,y,z$ in $F$ are respectively $c,x,x$. We have
$$|V(F)|=k+4=n,\qquad |E(F)|=2k+7=2n-1,$$
so $G$ has $n(n-3)+1$ arcs.

The underlying graph of $F$ still has girth at least six. The new edges form a tree attached to the core at $a,b,d,e$, with $c$ a pendant vertex. A new simple cycle with one segment in this tree has either a same-branch segment of length two and a core path of length at least four, or a cross-branch segment of length four and a core path of length at least two. A cycle with two tree segments must use the vertex-disjoint paths $a-y-b$ and $d-z-e$: a cross-branch tree segment would meet any other segment. Its two core paths both join opposite branches and have length at least two, giving total length at least eight. With four attachment vertices there can be no third tree segment. Thus no cycle of length below six is introduced.

For a missing pair $(s,t)$, set
$$B=N_F^+(s)\cup N_F^-(t).$$
The local argument in Lemma 18 shows that every initial cop vertex $v\ne s$ with $d_F^+(v)\ge2$ has an outgoing $F$-neighbor outside $B$. Indeed, the induced double star on $B$ has diameter at most three, and such a cop has at most one outgoing neighbor in it. This is a safe intermediary for a two-move delivery in $G$. The argument only requires the degree bound at that cop vertex; the other degrees need not all satisfy it.

Only initial cop position $c$ remains. Consider a missing pair with $s\ne c,x$. Then $x\notin N_F^+(s)$, since the sole predecessor of $x$ is $c$. Also $x\notin N_F^-(t)$: otherwise $t$ would be $y$ or $z$, whose sole predecessor is $x$, forcing $s=x$. Consequently $x\notin B$, and $x$ gives a safe two-move delivery. When $s=c$, that cop position is not legal initially, so the preceding degree-two argument already covers every legal initial position.

The only remaining missing pairs are $(x,y)$ and $(x,z)$. Neither is guaranteed: a pursuer at $c$ has closed outgoing neighborhood $V\setminus\{x\}$ in $G$, and can intercept every nonterminal departure from source $x$. Waiting never delivers, and neither recipient is directly accessible. Exactly these two pairs fail, leaving $2n-3$ guarantees. $\square$

The generator `src/dense_first_step.py` implements the choices above and verifies the full graph's girth, the relevant degrees, and every safe-intermediate condition. Its receipt `research/dense-first-step-checks.json` records instances at orders 68, 75, 80, 100, and 164, covering 105,634 missing-pair/cop triples with precisely the two asserted exceptions. These checks corroborate the ordinary proof. The construction at $n\ge134$ uses the ordinary high-girth construction starting at core order 130; its extension to $68\le n<134$ uses the already stated finite structural insertion certificate.

**Corollary 33 (the complete final dense band).** For every $n\ge75$ and every integer $1\le r\le n$,
$$
\boxed{
M\bigl(n,n(n-3)+r\bigr)
=2n-r-\left\lceil\frac r2\right\rceil-1.
}
$$
Equivalently, for every integer $n\le h\le2n-1$,
$$
M\bigl(n,n(n-1)-h\bigr)
=h-\left\lceil\frac{2n-h}{2}\right\rceil-1.
$$
There is an explicit attaining graph at every such budget, with a two-move strategy for every counted pair.

**Proof.** The upper bound is Theorem 27. The first step $r=1$ is Theorem 32. For $r\ge2$, put $k=n-r$. If $k\ge52$, use Theorem 29. If $1\le k\le51$, then $r=n-k\ge24$, and Proposition 31 applies because
$$
j=\left\lfloor\frac{r-2}{2}\right\rfloor\ge11,
\qquad
\binom j2\ge55\ge k.
$$
Finally, $k=0$ means $r=n$, which is the functional construction of Theorem 13. These cases exhaust all integer budgets in the band. $\square$

Together with Theorem 19 at $m=n(n-3)$ and Theorem 13 beyond $m=n(n-2)$, this determines the entire joint extremum for $n\ge75$ and $m\ge n(n-3)$. At the boundary $m=n(n-3)$ the value is $2n$; the next step has value $2n-3$, and the subsequent values follow the displayed staircase down to $\lfloor(n-2)/2\rfloor$, after which the value is zero. This result does not resolve the general sparse interval below $n(n-3)$, nor does it assert that every smaller order has the same formula. No new Lean formalization is claimed here.

![The complete final dense band at n=100. The solid curve is the proved exact maximum at every integer budget; the dashed line counts all missing pairs and does not account for forced failures.](figures/dense-staircase.pdf)

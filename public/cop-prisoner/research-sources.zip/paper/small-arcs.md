# Exact extrema with at most seven arcs

**Proposition 23.** Allowing arbitrarily many vertices, including isolated vertices,
\[
\bigl(M_E(0),M_E(1),\ldots,M_E(6)\bigr)
  =(0,0,0,0,1,1,2).
\]

**Proof.** Write \(A=\{v:d^+(v)\ge2\}\), \(B=\{v:d^-(v)\ge2\}\),
\(q=|A|\), \(r=|B|\), and \(b=|A\cap B|\).
Every counted pair belongs to \(A\times B\), excludes the diagonal, and
excludes arcs. Consequently
\[
I(G)\le qr-b-e(A,B),\qquad
e(A,B)\ge\max\{0,2q+2r-m\},\qquad
q,r\le\lfloor m/2\rfloor.                 \tag{23.1}
\]
For completeness, the second inequality follows by counting the arcs leaving
\(A\) and those entering \(B\): their respective totals are at least \(2q\)
and \(2r\), and their union has at most \(m\) arcs.

A counted pair \((s,t)\) requires two arcs leaving \(s\) and two entering
\(t\). These four arcs are distinct because \(s\to t\) is absent. Thus
\(I(G)=0\) when \(m\le3\).

We will use two elementary camping observations. If \(d^-(z)=0\),
\(z\to t\), and \(d^-(t)=2\), then no indirect pair ending at \(t\) is
guaranteed. Indeed, let \(p\) be its other predecessor. An indirect source
is neither \(z\) nor \(p\). A pursuer starting at \(p\) can wait there:
the messenger cannot reach \(z\), and cannot enter \(p\) without being
captured before reaching \(t\). Dually, if \(d^+(z)=0\), \(s\to z\),
and \(d^+(s)=2\), then no indirect pair starting at \(s\) is guaranteed.
A pursuer waits at the other successor of \(s\); the messenger's only
alternative departure reaches a sink different from the indirect recipient.

Suppose first that \(m=4\) or \(m=5\). Then \(q,r\le2\). If either is
zero there is nothing to count, and if both are one the bound is immediate.
When \(q=r=2\), (23.1) gives \(I(G)\le m-4-b\le1\). When \(q=1\)
and \(r=2\), two counted pairs would have the same source and distinct
recipients. The source's two outgoing arcs are then disjoint from the at
least four arcs entering those recipients, which would require \(m\ge6\).
The case \(q=2,r=1\) follows by the same count with sources and recipients
interchanged: at least four arcs leave the two counted sources, and the
recipient's two incoming arcs are disjoint from them. Hence \(I(G)\le1\).

Now let \(m=6\), so that \(q,r\le3\). If \(q=1\), three counted pairs
would require two outgoing arcs from their common source and six disjoint
arcs entering their three recipients; this is impossible. Thus \(I(G)\le2\).
The same argument applies when \(r=1\); cases with a zero coordinate are
again immediate. If \(q=r=2\), (23.1) gives \(I(G)\le2-b\le2\).

Consider \(q=2,r=3\). Every arc ends in \(B\), and every vertex of \(B\)
has indegree exactly two. If \(A\subseteq B\), then \(b=2\) and (23.1)
gives \(I(G)\le6-2-4=0\). Otherwise choose \(z\in A\setminus B\).
It has indegree zero and at least two distinct successors in \(B\).
The first camping observation eliminates both corresponding recipient
columns. At most one column remains, containing at most the two sources
in \(A\). Thus \(I(G)\le2\).

For \(q=3,r=2\), every arc starts in \(A\) and every vertex of \(A\)
has outdegree exactly two. If \(B\subseteq A\), the same count gives zero.
Otherwise a vertex \(z\in B\setminus A\) has outdegree zero and at least
two predecessors in \(A\). The second camping observation eliminates
their two source rows, leaving at most one row and two recipients. Again
\(I(G)\le2\).

Finally, if \(q=r=3\), all six arcs go from \(A\) to \(B\), and all
relevant indegrees and outdegrees equal two. If \(A=B\), (23.1) gives
\(I(G)\le9-3-6=0\). Otherwise a vertex of \(A\setminus B\) has indegree
zero and eliminates two recipient columns by the first camping observation.
The remaining column has two distinct predecessors in \(A\), so at most
one of the three sources can contribute an indirect pair. This completes
the upper bounds in all cases.

For the lower bounds, the four-arc diamond
\[
E=\{(0,1),(0,2),(1,3),(2,3)\}
\]
guarantees the indirect pair \((0,3)\): the messenger chooses the branch
not occupied by the pursuer and delivers on the next move. Adding a
disjoint arc gives the five-arc example. The six-arc graph
\[
E=\{(0,1),(0,2),(1,3),(1,4),(2,3),(2,4)\}
\]
guarantees both \((0,3)\) and \((0,4)\). If the pursuer starts on one
branch, choose the other; if it starts at either sink, choose either branch.
In each case it cannot reach the selected branch on its next move, and
receipt then occurs on the messenger's second move. Hence \(I(G)=2\),
as required. \(\square\)

These arguments establish the arc-only maximum over every finite vertex
set; no restriction on the number of nonisolated vertices is used.

**Proposition 24 (with a finite exhaustive computation).** We have
\[
M_E(7)=2.
\]

**Proof.** First consider a weakly connected digraph with at most seven
arcs and at least seven vertices. Forget the directions but retain one
undirected edge for each arc, so that opposite arcs become parallel
edges. The resulting connected multigraph has at most as many edges as
vertices. It is therefore a tree or has exactly one cycle; a parallel
pair is allowed as a cycle of length two.

In a tree, any reachable indirect source--recipient pair has an internal
vertex separating its endpoints. A pursuer can start and wait there,
preventing delivery. Thus no indirect pair is guaranteed. In the unicyclic
case, a pair with either endpoint outside the unique cycle likewise has
an internal separating vertex, unless its endpoints are adjacent in the
underlying graph. For adjacent endpoints off the cycle, a directed route
exists only if their connecting arc has the required direction, making
the pair direct. Thus every counted pair must have both endpoints on the
cycle.

There are exactly two simple undirected paths along that cycle between
two distinct cycle vertices. If only one is a directed path from the
source to the recipient, it is either a direct arc or has an internal
vertex where the pursuer can wait. If neither is directed, the recipient
is unreachable. Excursions into attached trees cannot bypass an internal
cycle vertex. Consequently a counted pair requires both cycle paths to
be directed from its source to its recipient. This forces the cycle's
unique divergence at that source and unique convergence at that recipient;
every other cycle vertex has one entering and one leaving cycle edge.
A fixed orientation can therefore support at most one such ordered pair.
A cycle of length two consists of opposite arcs and supports no indirect
pair. We have proved that every weakly connected digraph with at most
seven arcs and at least seven vertices has \(I(G)\le1\).

For a general digraph with seven arcs, distinct weak components contribute
additively to \(I(G)\). Each component with a positive contribution uses
at least four arcs by Proposition 23, so at most one component contributes.
If that component uses at most six arcs, Proposition 23 bounds its
contribution by two. If it uses seven arcs and has at least seven vertices,
the preceding argument bounds its contribution by one. In the only
remaining case it has at most six vertices. Adding isolated vertices to
make six does not change its indirect guarantee count, and the complete
six-vertex enumeration gives a maximum of two at seven arcs.

This last finite assertion is the computational dependency of the
proposition. It is reproduced by `src/enumerate_small_n6.cpp`; the result
is recorded with `complete: true` in
`research/solver-enumeration-n6.json`. The enumeration covers every
six-vertex digraph up to the degree-ordering reduction described in the
computational section; the witness is also checked by the separate
explicit-turn solver. The structural reduction above is what extends
that finite calculation to unrestricted vertex counts.

Finally, add one disjoint arc to the six-arc, two-recipient construction
in Proposition 23. This preserves its two guarantees and supplies seven
arcs, proving the matching lower bound. \(\square\)

No exact arc-only maximum for budgets eight through eleven is asserted
here.

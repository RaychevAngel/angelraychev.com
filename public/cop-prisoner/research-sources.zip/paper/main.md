---
title: Guaranteed indirect delivery in directed networks
subtitle: The joint extremal function and explicit attaining constructions
author:
  - |
    Angel Ivanov Raychev\
    [angel.ivanov.raychev@gmail.com](mailto:angel.ivanov.raychev@gmail.com)
  - |
    Alexandra Ignatova\
    Eindhoven University of Technology\
    [alex.igntv@proton.me](mailto:alex.igntv@proton.me)
date: 23 October 2026
documentclass: article
classoption: 11pt
geometry: margin=1in
colorlinks: true
linkcolor: blue
urlcolor: blue
toc: true
toc-depth: 1
numbersections: true
abstract: |
  A messenger and a pursuer move alternately on a finite loopless directed
  graph, with complete information and waiting permitted. The messenger
  moves first and wins upon reaching a designated recipient, before
  interception there. We determine the maximum number $M(n,m)$ of ordered
  nonadjacent source--recipient pairs for which delivery is guaranteed
  against every initial pursuer position, among graphs with $n$ vertices
  and $m$ arcs. We give the exact value and an explicit attaining graph for
  every admissible pair $(n,m)$. For $n\ge12$, a piecewise formula describes
  sparse growth, the interval $2n\le m\le n(n-3)$ in which every missing
  pair can be guaranteed, a dense staircase, and the zero range above
  $n(n-2)$. Complete finite tables cover smaller orders. The proofs combine
  degree and support bounds, local strategy composition, protected routing,
  and constructions in the missing-arc graph. Finite exceptional cases use
  explicit strategy certificates and complete computational exclusions.
  Reproducible programs and certificates accompany the paper; a Lean
  development verifies selected semantic results and constructions, with
  its precise coverage stated separately.
---

# Introduction

A messenger has just obtained a message at a station $s$ of a directed network. A pursuer occupies another station, and both positions are visible. They move alternately, the messenger first, using one directed connection or waiting. The messenger wants to deliver to a designated recipient $t$ before interception. Receipt completes the task immediately, even if the pursuer is at $t$: the pursuer can intercept the messenger but cannot disable the recipient.

A direct connection $s\to t$ makes delivery immediate. We study the additional communication supported by the network: source--recipient pairs without a direct connection for which delivery is nevertheless guaranteed against every allowed initial pursuer position and policy. Write $I(G)$ for their number.

We determine
$$M(n,m)=\max_{|V(G)|=n,\ |E(G)|=m} I(G)$$
for **every admissible pair of integers** $n\ge1$ and
$0\le m\le n(n-1)$, and give explicit adjacency rules or a specified composition procedure
attaining each value, with parameters determined from $(n,m)$ and a proof
of guaranteed delivery for its counted pairs.
The vertex-only and arc-only maxima follow by taking the corresponding maxima:
$$
M_V(n)=\max_{0\le m\le n(n-1)}M(n,m),\qquad
M_E(m)=\max_{n\ge1:\,m\le n(n-1)}M(n,m).
$$

Isolated vertices are allowed. Removing them preserves $I$, so the arc-only maximum is finite: a graph with $m>0$ arcs has at most $2m$ nonisolated vertices. Our constructions prescribe adjacency or composition directly from $(n,m)$; finite exceptions are specified by certified lists of arcs. The results also include separate probabilistic and deterministic derandomization statements. Time bounds establish termination and, in several families, stronger guarantees. Optimization of delivery time is a separate problem, discussed in the [companion](https://angelraychev.com/cop-prisoner/delivery-time/).

The original problem and a layered subset construction arose in Alexandra Ignatova's 2023 project, mentored by Angel Raychev. A public 2023 abstract records that provenance [@ignatova2023]; the retained manuscript is dated February 2024 [@ignatova2024]. Ignatova and Raychev had already established the upper bound $I(G)\le n(n-3)$ and investigated two-in/two-out-regular constructions. This account reconstructs that bound, distinguishes the original construction from its corrected analysis, and supplies new attaining families among the September 2026 extensions. The present account completes the joint extremal classification with explicit attaining constructions.

## Relation to pursuit games and reachability

Destination-based pursuit has a classical antecedent in the cat-and-mouse
game. Chandra and Stockmeyer's work on alternation introduced a directed
version [@chandraStockmeyer1976]. Huq gives proofs of P-completeness for
directed and undirected variants and explicitly compares their rules
[@huq2015]. In Huq's formulation the cat moves first, repeated positions
give a draw, and players traverse edges rather than wait. The earlier
variant allows waiting, has the mouse move first, and forbids the cat
from occupying the hole. Here the pursuer may occupy the recipient:
receipt still wins immediately. We quantify over every permitted initial
pursuer position and count guaranteed ordered pairs, rather than decide
the winner of one prescribed initial position. We do not transfer a
complexity classification between these rule sets.

The traditional Cops and Robbers game studies capture or indefinite
evasion; see Bonato and Nowakowski [@bonatoNowakowski2011]. Delivery requires
reaching a specified vertex, so an evasion strategy or a usual cop-win
characterization alone does not resolve our question. Once the recipient
is fixed, the present game is a finite reachability game on positions of
both players and the turn. Its attractor and rank-certificate arguments
are standard finite-game methods [@berwanger2009]. Our extremal question
concerns their simultaneous consequences for all source--recipient pairs
and all graphs with prescribed vertex and arc counts.

The difficulty is not a shortage of paths alone. An additional arc can
provide a route to the messenger while also enabling an interception by
the pursuer. Accordingly, neither $I(G)$ nor the validity of an attaining
construction is monotone under arbitrary addition of arcs. We address
this by proving strategies against a larger permitted pursuer graph
while restricting the messenger to a compulsory subgraph. Every graph
between those two graphs then inherits the same guarantee. The separating
set viewpoint also connects the two-move constructions to earlier work on
separating systems and oriented diameter-two graphs
[@BollobasScott2006]; the directed safety condition remains an additional
requirement in the present game.

## Proof roadmap

The complete formula and finite tables appear first. Source/sink deletion
and live-row/live-column counting provide the sparse upper bounds, while
counting failed pairs in the missing-arc graph gives the dense staircase.
Periodic local strategies attain the sparse endpoints; robust circles and
hub/guide constructions cover the intervening budgets. Missing-arc cores
and functional attachments attain the dense band. Finally, degree-profile
reductions and complete finite exclusions establish the exceptional small
values. The verification section specifies which steps have ordinary
proofs, which use finite computation, and which have Lean verification.

## Results and proof boundaries

**Complete classification.** For every $n\ge1$ and $0\le m\le n(n-1)$,
we determine $M(n,m)$ and supply an explicit attaining graph. The combined
formula below covers every order $n\ge12$; the complete finite tables cover
orders one through eleven. Ordinary parameterized constructions cover the
infinite ranges. Certified listed graphs cover the genuine finite exceptions.

The classification has two ingredients:

1. **A formula at every order from twelve.** Put $A_m=M_E(m)$ for
   $0\le m\le23$. The small-budget table specifies these 24 constants. For
   larger budgets, the sparse parity formulas, missing-pair main interval,
   final dense staircase, and zero range determine every value. The sparse
   graph is padded with isolates; the other cases use the stated circle,
   stage, hub, code, and dense-block recipes. The main formula starts sharply
   at twelve because $M(11,22)=79<88$; the dense staircase starts sharply at
   eleven. The full main interval has no uniform two-move deadline.
2. **Complete small-host values.** The finite sparse-budget theorem settles
   the global values at twelve through twenty-one arrows. Source/sink
   deletion, live-row and live-column capacities, and complete joint-degree
   exclusions resolve the exceptional smaller hosts. The finite tables give
   every remaining value, with literal adjacency and full winning/losing
   certificates. In particular,
   $M_V(7)=21$, $M_V(8)=32$, $M_V(9)=48$, $M_V(10)=65$, and $M_V(11)=85$.
   From twelve onward, $M_V(n)=n(n-3)$.

Both parts include constructions with parameters fixed by $(n,m)$.
Separate reproducibility checks verify the numerical coverage and the
availability of direct adjacency, prescribed composition, or a saved
finite graph for each case. These checks supplement the coverage and
strategy proofs; numerical equality alone is not an explicit construction.

The complete mathematical classification uses ordinary proofs and finite
computer-assisted proofs. Independent reviews check the finite domain
reductions, pruning, and the actual alternating game; their precise replay
scopes are stated with the evidence. The Lean development formalizes selected
structural implications and examples, not this entire classification.

The proof uses a shared source/sink deletion and positive-support induction for the sparse upper bounds, separated pair codes for a shorter main-interval construction, and a functional attachment identity for dense graphs. The following construction and support results retain their full parameter ranges and stronger guarantees:

- **Protected routing (Theorem 54).** For a specified routing set of size $b$, put $Q=b(2n-b-1)$ and $p=a/Q$. If $(b-3)p^2(1-p)>4\log n+\log(8/3)$, exactly $a$ incident arrows can be chosen deterministically so that every assignment of exterior arrows preserves universal two-move delivery. This gives every exact budget $a\le m\le a+(n-b)(n-b-1)$ and subsumes the former full-vertex conditioning theorem, including its random-sampling guarantee.
- **Sparse support (Theorems 56–57).** With $2k$ arrows, $k\ge6$, a graph outside the $k$-vertex two-regular shape has $I\le(k-1)(k-3)$. With $2k+1$ arrows, $k\ge3$, a graph with $I>k^2-4k+6$ reduces to a $k$-vertex induced core with at least the same score, or to three specified $k+1$-vertex degree families. A stronger original-graph reduction shows that, for $k\ge7$, a graph with $2k$ arrows and $I>k^2-5k+8$ already has exactly $k$ nonisolated vertices, allowing arbitrary degrees in that core. These quantitative statements retain the regular equality information and do not assume that deleting arrows preserves strategies.
- **Direct dense construction (Theorem 58).** Its two-move endpoint works at every $n\ge10$. Its arbitrary-subset bridge covers $2n\le h\le3n$ at every $n\ge16$. Two explicit residue constructions enlarge the dense envelope to $n^2/4-O(n)$ missing arrows, preserving two-move delivery and every optional subset. Its first-step two-move domain is $n\ge16$, and its original full-band domain is $n\ge20$. Combining its blocks with root-colored cycles extends the full-band two-move domain to $n\ge16$. Arbitrary-duration block addition and the fixed attachments give the uniform staircase from order eleven; safe-root exclusions and literal graphs determine every smaller dense-band case. The smaller-order delivery bounds remain separate.
- **Antichain composition (Theorem 59).** Incomparable hub subsets attach outside vertices to a fixed two-part core, preserving two-move delivery under every choice of outside arrows. The generalized theorem includes separated two-element codes: for $k\ge6$ and $2k\le n\le k(k-3)$ they give every budget from $(4k-2)n-2k(2k+1)$ through $n(n-3)$. Their overlap with circles covers $3n\ldots n(n-3)$ for every $n\ge79$. The supplied larger and mixed codes retain their independent ranges; the two-move sparsity consequence is retained in the companion.
- **Support concentration (Theorem 60).** With $\eta=m-2\sqrt{I(G)}$, the nonisolated support has at most $m/2+4\eta$ vertices; all but $12\eta$ arrows lie in a core of size between $m/2-3\eta$ and $m/2$. This controls near-extremizers below the earlier exact-support cutoffs without asserting that deleting the exceptional arrows preserves delivery.

The general arguments have ordinary mathematical proofs, with the main-interval finite bridge additionally using complete independently replayed state certificates. The accompanying Lean development verifies actual-game semantics, selected bounds and exact cells, finite certificate interfaces, and strategy implications for routing and envelope constructions. The dense staircase bound and explicit attainers are formalized throughout the dense region from order eleven in `DenseSharpClassification.lean`; dense cells at smaller orders retain their separate proof boundaries. Its precise formal coverage is stated below; the complete classification is not a Lean theorem.

# The game and its elementary structure

Let $G=(V,E)$ be a finite loopless digraph. Opposite arcs are allowed. A legal move from $x$ goes to $x$ or to an outgoing neighbor; write
$$C(x)=\{x\}\cup N^+(x).$$
Fix $s,t\in V$ and $c\ne s$. If $s=t$, receipt has already occurred. Otherwise the messenger moves first. On its turn it chooses $v\in C(s)$. If $v=t$, delivery wins immediately. If $v\ne t$ and $v=c$, it is captured. Otherwise the pursuer chooses $c'\in C(c)$; equality $c'=v$ is capture. The process repeats. Infinite play without delivery is a messenger loss.

Let $W_G(s,t)$ mean that, for every initial $c\ne s$, there exists a messenger strategy guaranteeing delivery against every pursuer strategy. The messenger observes $c$; its strategy may depend on it. Then
$$
I(G)=\#\{(s,t):s\ne t,\ (s,t)\notin E,\ W_G(s,t)\}.
$$
If $w(G)$ counts all guaranteed pairs including the diagonal, then exactly
$$w(G)=n+m+I(G).$$

The terminal rule matters. In the directed diamond $s\to a\to t$, $s\to b\to t$, the messenger chooses the intermediate vertex not occupied by the pursuer and delivers on its next turn. But reaching a vertex that would be safe as a *recipient* does not justify using it as an intermediate stop. The pursuer gets an intervening move before the message can be forwarded again.

![Two routes allow a guaranteed indirect delivery. Adding the arc from a to b lets a pursuer at a block both first moves.](figures/diamond.pdf)

## Camping obstructions

**Lemma 1 (source domination).** If $c\ne s$ and $N^+(s)\subseteq C(c)$, there is no guaranteed indirect pair with source $s$.

**Proof.** The pursuer starts at $c$ and waits while the messenger waits. Every nonterminal departure from $s$ is either an immediate collision or is captured on the following pursuer turn. Waiting forever is not delivery. $\square$

**Lemma 2 (predecessor domination).** Put $D_t=N^-(t)$. If $D_t\subseteq C(c)$, an indirect guaranteed source for $t$ must equal $c$.

**Proof.** For any other source the pursuer may start at $c$. Every indirect delivery must first enter $D_t$, where the pursuer can capture before the next messenger turn. $\square$

In particular, a source counted by $I$ has outdegree at least two, and a recipient counted by $I$ has indegree at least two. An indegree-one recipient is blocked by its unique predecessor. In an undirected network, interpreted as two opposite arcs per edge, the pursuer can start at $t$ and catch the messenger upon its first arrival at a neighbor of $t$. Thus $I=0$ for every such network.

The two degree conditions are necessary, not sufficient. Neither the absence of a one-vertex directed separator nor the existence of two internally disjoint routes characterizes this game. Adding $a\to b$ to the diamond destroys its only indirect guarantee, although both routes remain. Consequently $I$ is not monotone under adding arcs.

**Lemma 3 (two-move criterion).** For an indirect pair $(s,t)$, put $B=N^+(s)\cap N^-(t)$. Delivery is guaranteed within two messenger moves exactly when
$$\text{for every }c\ne s,\qquad B\not\subseteq C(c).$$

**Proof.** Choose an intermediate vertex of $B\setminus C(c)$, survive every pursuer response, and deliver. Conversely, any successful two-move indirect delivery must use such an intermediate. Waiting on the first move cannot reach a nonadjacent recipient on the second. $\square$

## Components, zero minima, and the vertex bound

Removing isolated vertices preserves $I$. More generally,
$$I(G\sqcup H)=I(G)+I(H).$$
There are no cross-component routes; a pursuer in the other component cannot interfere with a route in the messenger's component.

**Proposition 4.** At every admissible $(n,m)$ the minimum of $I$ is zero.

**Proof.** For $n\ge2$, list all nonloop arcs row by row and retain the first $m$. There are full outgoing rows, at most one partial row, and empty rows. Full rows have only direct recipients; empty rows cannot move. If a full row exists, its vertex blocks every indirect attempt from the partial row by Lemma 1. Otherwise successors of the partial row have no outgoing arcs, so no indirect route exists. The empty and one-vertex cases are immediate. $\square$

**Theorem 5 (original upper bound).** For every $n\ge3$,
$$I(G)\le n(n-3).$$

**Proof.** A recipient of indegree zero or one has no indirect guaranteed sources. A recipient of indegree $d\ge2$ has at most $n-1-d\le n-3$, after excluding itself and its direct predecessors. Sum over recipients. $\square$

For $n\ge4$, equality forces every recipient to have indegree two and every missing pair to be guaranteed. Every source must then have outdegree at least two; the degree sum forces outdegree exactly two. Conversely, a two-in/two-out-regular graph with every pair guaranteed attains equality. Thus attaining the vertex bound is exactly a sparse universal-delivery construction problem.

# Sharp arc-budget upper bounds

The source/sink and positive-support lemma below bounds an actual
source/sink graph by preceding arc budgets and a positive-degree graph by
its eligible rectangle. Its ordinary induction proves the following
bounds and equality shapes before deriving the stronger support results.
The induction starts from the elementary results through six arrows;
it uses no finite extremum as a premise.

**Theorem 6.** If $m=2k$ and $k\ge5$, then
$$I(G)\le k(k-3).$$

**Theorem 7.** If $m=2k+1$ and $k\ge5$, then
$$I(G)\le k(k-3)+2.$$

**Proof of Theorems 6 and 7.** Apply the ordinary sparse parity proposition,
whose proof is the increasing-budget induction (56.2)--(56.6). $\square$

**Theorem 8.** For $k\ge6$, equality in Theorem 6 holds exactly when
deleting isolated vertices leaves a two-in/two-out-regular graph on
$k$ vertices with every pair guaranteed.

**Theorem 9.** For $k\ge6$, equality in Theorem 7 holds exactly when
the nonisolated support has $k+1$ vertices; one vertex $u$ has
outdegree one and indegree two; a different vertex $v$ has indegree one
and outdegree two; every other degree is two; $u\to v$ is absent;
and every missing pair from an outdegree-two source to an indegree-two
recipient is guaranteed.

**Proof of Theorems 8 and 9.** The same parity proposition proves the
equality shapes. In even support the number of missing pairs is
$k(k-3)$. In the odd absent-arrow family the eligible count is
$k(k-3)+2$; every other shape has a strictly smaller upper bound.
The stated guarantees therefore characterize equality. $\square$

Adding the absent $u\to v$ in Theorem 9 gives a two-regular digraph.
It does not follow that the completed graph is universally winning.

# Sparse constructions with a linear deficit

## A safe branching principle

**Lemma 10.** Suppose distinct vertices have closed move sets intersecting in at most one vertex. If a vertex $r$ has two distinct outgoing neighbors that each guarantee delivery to $t$, then $r$ guarantees delivery to $t$.

**Proof.** For every pursuer position $c\ne r$, one of the two successors lies outside $C(c)$. Move there. It survives every intervening pursuer response, after which its guaranteed strategy applies. If the chosen vertex is $t$, delivery is already terminal. This is a finite concatenation of actual strategies. $\square$

**Theorem 11.** Let $a\ge3$, $h=2a+1$, $n\ge2h+1$, and $\gcd(n,h)=1$. The digraph on $\mathbb Z/n\mathbb Z$ with outgoing steps $1,a,h$ has every pair guaranteed. It has $3n$ arcs and
$$I(G)=n(n-4).$$

**Proof.** The positive differences in $\{0,1,a,2a+1\}$ are
$$1,\ a-1,\ a,\ a+1,\ 2a,\ 2a+1,$$
all distinct. Since $n>2h$, no positive difference coincides modulo $n$ with a negative one. Distinct closed move sets therefore intersect in at most one vertex.

Translate the recipient to zero. Vertices $0,-1,-a,-h$ are already delivered or have direct arcs to it. Vertex $-a-1$ is guaranteed via its neighbors $-a,-1$. Thus all four vertices
$$Q(z)=\{z,z-1,z-a,z-a-1\}$$
are guaranteed for $z=0$. If $Q(z)$ is guaranteed, apply Lemma 10 in the following order:

| New source | Two guaranteed successors |
|:--|:--|
| $z-h$ | $z-a-1,\ z$ |
| $z-h-1$ | $z-h,\ z-1$ |
| $z-h-a$ | $z-h,\ z-a$ |
| $z-h-a-1$ | $z-h-a,\ z-a-1$ |

This proves $Q(z-h)$. Iterating at most $n-1$ times covers every vertex because $h$ is coprime to $n$. The induction is finite; it supplies terminating strategies, not merely perpetual evasion. Finally subtract the $n$ diagonal pairs and $3n$ arcs from $n^2$. $\square$

![A guaranteed quartet produces the next quartet seven positions earlier in the step-1,3,7 construction.](figures/quartet.pdf)

The choice $a=3$ proves the theorem for every $n\ge15$ not divisible by seven. Adding an isolated vertex gives a linear-deficit construction for the remaining large sizes as well. The next elementary lemma removes that padding and improves the constant.

**Lemma 12.** For every $n\ge25$, there is an odd integer $h$ with $7\le h<n/2$ and $\gcd(n,h)=1$.

The proof and its explicit choices are included in the construction appendix below. Taking $a=(h-1)/2$ gives, for every $n\ge25$,
$$n(n-4)\le M_V(n)\le n(n-3),\qquad 3n\le n^2-M_V(n)\le4n.$$
These estimates motivate the sharper endpoint result: Theorem 40 subsequently proves equality in the upper bound for every $n\ge12$.

# The dense boundary

**Theorem 13.** For $n\ge2$,
$$M(n,n(n-2))=\left\lfloor\frac{n-2}{2}\right\rfloor,$$
and $M(n,m)=0$ for every admissible $m>n(n-2)$.

**Proof.** If $(s,t)$ is indirect guaranteed, row $s$ misses $s\to t$. By Lemma 1, every other row $c$ must miss an arc into $N^+(s)$. Thus every row misses at least one nonloop arc, and $m\le n(n-2)$.

Now suppose $m=n(n-2)$. If $I=0$, the upper bound is immediate. Otherwise the preceding argument shows that every row misses exactly one arc; write $f(v)$ for its endpoint. Necessarily $f(v)\ne v$. A possible indirect pair is $(s,f(s))$. Lemma 1 says
$$ f^{-1}(s)=\varnothing,\qquad f^{-1}(f(s))=\{s\}. \tag{2}$$
These conditions suffice: for initial pursuer $c\ne s$, choose the intermediate $f(c)$. It is different from $s,f(s)$, is inaccessible on the pursuer's next move, and has an arc to $f(s)$. This is a two-move guarantee.

Pairs satisfying (2) have disjoint source and target vertices. If there are $j$ pairs, the remaining vertices contain a cycle of the loopless functional graph of $f$ and therefore number at least two. Hence $2j\le n-2$. For attainment use pairs $s_i\to t_i$ in the missing-arc graph, send every $t_i$ to $a$, put $a\leftrightarrow b$, and send any remaining vertex to $a$. Take all nonloop arcs except these missing arcs. $\square$

![The missing arcs at the dense boundary form a functional graph. Each displayed two-vertex branch contributes one guaranteed indirect pair.](figures/dense-boundary.pdf)

**Theorem 14.** A noncomplete graph with every pair guaranteed has at most $n(n-3)$ arcs.

**Proof.** Such a graph has an indirect pair. No row can be complete: its vertex would block every indirect source other than itself and have no indirect target of its own. If a row $c$ missed only $c\to t$, then $N^+(t)\subseteq C(c)$. Vertex $t$ also has an indirect recipient, contradicting Lemma 1. Every row therefore misses at least two arcs. $\square$

The next section gives a uniform construction attaining this density on an infinite set of orders. Its proof is independent of the sparse-game certificate for the complementary graph proved later.

## A periodic family with three-move delivery

Let $n=5k$, $k\ge4$, and write vertices as $5i+j$, with $i$ modulo $k$ and $0\le j\le4$. Put $\alpha(v)=v+1$ and
$$
\begin{aligned}
\beta(5i)&=5(i+1),&\beta(5i+1)&=5(i-1)+2,\\
\beta(5i+2)&=5(i-1)+4,&\beta(5i+3)&=5(i-1)+3,\\
\beta(5i+4)&=5(i-1)+1.
\end{aligned}
$$
Let $H$ have arcs $v\to\alpha(v),v\to\beta(v)$, and let $G$ be its loopless directed complement. Both maps are permutations, without fixed points or coincident images at a vertex; thus $G$ has $n(n-3)$ arcs.

**Theorem 15.** Every pair in $G$ is guaranteed within three messenger moves. Consequently $M(5k,5k(5k-3))=10k$ for every $k\ge4$.

**Proof.** For a missing pair $(s,t)$ and initial pursuer $c\ne s$, a safe two-move intermediate is any member of
$$\{\alpha(c),\beta(c)\}\setminus F(s,t),\qquad
F(s,t)=\{s,t,\alpha(s),\beta(s),\alpha^{-1}(t),\beta^{-1}(t)\}.$$
Its exclusion from $F$ ensures the two required arcs in $G$, while its membership in the displayed pair makes it inaccessible to the pursuer's next move.

Translate the source by a multiple of five so that $0\le s\le4$. A failure requires $c\in F-1$, since $\alpha(c)\in F$. The complete local calculation is:

| $s$ | $t$ | $F(s,t)$ | $(c,\beta(c))$, with $c\in F-1$, $c\ne s$ |
|--:|--:|:--|:--|
| 0 | 1 | $\{0,1,5,9\}$ | $(-1,-9),(4,-4),(8,3)$ |
| 0 | 5 | $\{0,1,4,5\}$ | $(-1,-9),(3,-2),(4,-4)$ |
| 1 | 2 | $\{-3,1,2,6\}$ | $(-4,-8),(0,5),(5,10)$ |
| 1 | $-3$ | $\{-4,-3,1,2\}$ | $(-5,0),(-4,-8),(0,5)$ |
| 2 | 3 | $\{-1,2,3,8\}$ | $(-2,-7),(1,-3),(7,4)$ |
| 2 | $-1$ | $\{-2,-1,2,3\}$ | $(-3,-6),(-2,-7),(1,-3)$ |
| 3 | 4 | $\{-2,3,4,7\}$ | $(-3,-6),(2,-1),(6,2)$ |
| 3 | $-2$ | $\{-3,-2,3,4\}$ | $(-4,-8),(-3,-6),(2,-1)$ |
| 4 | 5 | $\{-4,0,4,5\}$ | $(-5,0),(-1,-9),(3,-2)$ |
| 4 | $-4$ | $\{-5,-4,4,5\}$ | $(-6,-14),(-5,0),(3,-2)$ |

The only candidate with $\beta(c)\in F$ is $(s,t,c)=(4,5,-5)$. Every difference being tested has absolute value at most 19, so no extra equality appears modulo any $5k\ge20$. In that exceptional state move from 4 to 0. This is legal and safe: the pursuer at $-5$ has no arc to 0. Afterwards the pair $(0,5)$ is covered by the nonexceptional second row for every surviving pursuer position, and delivery takes at most two more moves. $\square$

# Correcting the original layered construction

The original graph remains a useful construction, but its printed count is not correct. We give its exact count and separate safe intermediate movement from terminal delivery.

Let $q=2x$, $a=\binom{2x}{x}/2$, and choose a family $\mathcal F$ containing one of each complementary pair of $x$-subsets of $[2x]$, with every coordinate occurring in exactly $a/2$ members. Such a family exists precisely when positive $x$ is not a power of two; a proof follows below.

There are row vertices $A_X,A'_X$ for $X\in\mathcal F$, and coordinate vertices $b_i,b'_i,c_i,c'_i$ for $i\in[q]$. The only arcs are

- $A_X\to b_i,b'_i$ when $i\in X$;
- $b_i\to A'_Y$ when $i\in Y$, and $b'_i\to A'_Y$ when $i\notin Y$;
- $A'_Y\to c_i,c'_i$ when $i\in Y$;
- $c_i\to A_X$ when $i\in X$, and $c'_i\to A_X$ when $i\notin X$.

The order is $N=2a+4q$. The four directed layers are $A$, $B\cup B'$, $A'$, $C\cup C'$.

**Theorem 16.** For the balanced original family,
$$I(G)=2a(N-1-q)+4q.$$
At $x=3$, the 44-vertex graph has exactly 764 indirect guaranteed pairs, rather than the draft's claimed lower bound of 1252.

**Proof.** The rows form an antichain. The $2q$ literal columns, indicating membership or nonmembership of each coordinate, also form an antichain, with size $a/2\ge5$. They cannot coincide: equality on the selected rows would remain true on their complements and hence on every $x$-subset, which is impossible for distinct literals. Every vertex has at least two successors.

From any noncollision state the messenger can safely advance one layer. If both players are in the same layer, use incomparable outgoing neighborhoods to choose a successor inaccessible to the pursuer. If the pursuer is in the next layer, avoid its occupied vertex; it has no within-layer arc. In the other two cases it cannot reach the next layer in one move. This includes waiting responses.

From $A_X$ to a specified $A'_Y$ there is a two-move guarantee. Against a pursuer $A_Z$, choose a coordinate in $X\setminus Z$, then choose its primed or unprimed intermediate according to membership in $Y$. Against a pursuer in the intermediate layer, choose another coordinate of $X$; the other layers cannot interfere. The reverse direction is identical. Safely advancing to the appropriate row layer first therefore gives delivery to any row recipient in at most five moves. There are $2a$ such recipients, each with $N-1-q$ indirect sources.

For target $b_i$ or $b'_i$, its predecessor set is exactly $N^+(c_i)$. Lemma 2 excludes every indirect source except $c_i$. That exceptional source wins in two moves: literal-column incomparability handles a pursuer in its own layer, and the other layer cases are as above. Thus $(c_i,b_i)$ and $(c_i,b'_i)$ both count. Symmetrically $(b_i,c_i)$ and $(b_i,c'_i)$ count, and no other indirect sources do. These give exactly $4q$ further pairs. $\square$

The correction preserves the original $N^2-O(N\log N)$ leading estimate along its constructed orders. The new circulant family supplies the stronger linear-deficit result at every sufficiently large order. The original construction's regular incidence design and the later extremal construction are distinct contributions.

## Balanced complementary halves

**Lemma 17.** For positive $x$, the $x$-subsets of $[2x]$ can be partitioned into two coordinate-balanced families with complementary subsets in opposite families if and only if $x$ is not a power of two.

**Proof.** Put $C=\binom{2x}{x}$. Each coordinate occurs in $C/2$ subsets, so balance requires $4\mid C$. The factorial valuation formula gives
$$v_2\binom{2x}{x}=s_2(x),$$
where $s_2(x)$ is the number of ones in the binary expansion. Thus divisibility by four is equivalent to $x$ not being a power of two.

For sufficiency, distinguish coordinate $2x$ and cyclically rotate the other $L=2x-1$ coordinates. Subsets containing $2x$ correspond to binary circular words with $x-1$ ones and $x$ zeros. Every orbit has length $L$: a proper repetition would have a repetition count dividing both consecutive integers. The number $C/(2L)$ of orbits is even, since $L$ is odd and $4\mid C$.

Choose half of those orbits. In the first family put their subsets, and put the complements of the subsets in the unchosen orbits. Exactly one of each complementary pair is selected. The distinguished coordinate occurs $C/4$ times. Rotation invariance gives a common incidence count $r$ for every other coordinate; counting all incidences yields
$$ (2x-1)r+C/4=xC/2,$$
so $r=C/4$. The other family is balanced as well. $\square$

This proof replaces the draft's incorrect stronger divisibility assertion $4x\mid\binom{2x}{x}$, which already fails at $x=3$.

# Exact computation and formal verification

For a fixed recipient $t$, let $X_j(r)$ be the set of initial pursuer positions from which delivery can be forced in at most $j$ messenger moves. Start with $X_0(t)=V$ and $X_0(r)=\varnothing$ otherwise. Set
$$
S_j(v)=\{c:C(c)\subseteq X_j(v)\}\quad(v\ne t),\qquad S_j(t)=V,
$$
and update
$$
X_{j+1}(r)=\left(\bigcup_{v\in C(r)}S_j(v)\right)\setminus\{r\}\quad(r\ne t),
\qquad X_{j+1}(t)=V.
$$
The recurrence includes waits and excludes all nonterminal collisions. Its least fixed point enforces eventual delivery. A separate implementation builds the explicit alternating graph of states $(r,c,\text{turn})$ and computes its reachability attractor. This is standard finite reachability-game machinery [@berwanger2009], rather than a new general algorithm for graph games.

The certificate checker independently verifies decreasing ranks on the selected messenger moves and on every pursuer response. Outside the winning region it verifies closure under every messenger move and at least one pursuer response. Thus a negative answer comes with an avoidance strategy, not simply failure of a search. Standard adjacency-list attractor analysis gives an all-recipient time bound $O(n^2m+n^3)$; that bound describes the standard implementation, not a claimed running-time bound for the simpler synchronous reference solver.

## Certified finite extrema

Complete enumeration gives

| $n$ | 1 | 2 | 3 | 4 | 5 | 6 |
|:--|--:|--:|--:|--:|--:|--:|
| $M_V(n)$ | 0 | 0 | 0 | 2 | 4 | 7 |

For $n\le5$ every labeled digraph was enumerated. For $n=6$, sorting the vertex labels by degree reduces the search while retaining at least one representative of every isomorphism class; valid degree bounds prune only candidates unable to improve the current maximum. This certifies extrema, not labeled distributions. Every attaining graph is independently checked by the explicit alternating solver. The complete joint tables, enumeration code, and receipts accompany the paper.

The complete finite sparse endpoint bridge covers every order $12\le n\le84$, joining the uniform family from order 85 in Theorem 40. The sharper projection in Theorem 45 and Corollary 45.1 starts the odd family at support order 98, so its required finite bridge is $13\le n\le97$. The full earlier archive through order 144 remains available unchanged. The graph lists, local ranks, projection proof and direct verification receipts are cited with those results. Theorem 46 supplies the original small-order bounds; the completed finite classification gives $M_V(7),\ldots,M_V(11)=21,32,48,65,85$.

One clean 12-vertex example is a Cayley digraph of $A_4$, with right multiplication by two suitable 3-cycles. Its actual graph and all-recipient finite-rank certificate are included. The Lean theorem checks the explicit 12-vertex graph directly, so correctness does not depend on trusting the group-label interpretation or the search that discovered it.

## Lean coverage

The artifact uses Lean 4.33.1 with Std only. Both players may wait and receipt
precedes collision. `SemanticCompleteness` proves that finite winning trees
are equivalent, on finite graphs, to one fixed legal messenger policy that
succeeds against every permitted initial pursuer and every legal,
history-dependent pursuer policy. Actual play assumes no horizon; the proof
derives a finite bound. The formal score therefore has the intended meaning.

The missing-pair and vertex bounds, source/sink deletion, support counting
and sparse parity bounds hold for arbitrary loopless graphs. In particular,
$I(G)\le k(k-3)$ for $2k$ arrows and $I(G)\le k(k-3)+2$ for $2k+1$ arrows,
when $k\ge5$. These proofs supply the counting and reduction steps, rather
than assuming a finite-search conclusion. Isolate and one-predecessor-sink
padding preserve the exact score, including cops entering the added sink.

**Dense region.** `DenseSharpClassification` proves the exact maximum and
an explicit attainer for every $n\ge11$ and $n(n-3)\le m\le n(n-1)$.
First steps, modular cores, functional attachments, counts and finite
threshold cases are instantiated. `DenseEnvelopeClassification` also proves
the adjacent band $n(n-4)\le m\le n(n-3)$ for $n\ge16$, with arbitrary
optional subsets and two-move delivery. The functional endpoint is proved
at every $n\ge2$; the zero band holds at all orders.

**Main interval.** `LowBandConstruction` proves
$M(n,m)=n(n-1)-m$ for every $n\ge115$ and $2n\le m\le n(n-3)$.
Its 101 local patterns and 696 objectives, projection of every optional cop
reply, safe transfers, terminal delivery and exact optional-prefix counts
are supplied. Its larger envelope endpoint is retained.
`MainUpperInterval` supplies $3n\le m\le n(n-3)$ for every $n\ge25$,
with prescribed circle, hub and separated-code recipes and proved overlaps.
It also covers budgets $95..304$, $100..340$, $126..378$, $110..418$,
$115..460$ and $120..504$ at orders $19,20,21,22,23,24$, respectively.

Complete main intervals are additionally verified at orders $12..18$ and
65, 70, 75, 80, 85, 90, 95, 100, 105 and 110. Thirty retained envelopes supply order
twelve and 145 stages supply thirteen through eighteen. Five-type charts
supply the ten larger orders' lower bands; their short variants also give
$100..110$ at order fifty and $110..121$ at fifty-five. Every optional subset
is checked against all upper-envelope cop replies. Symmetry is used for the
common envelopes and does not assume symmetry of the chosen optional graph.
Separate circle theorems retain their stronger domains: five-offset circles
for $4\mid n$, $n\ge16$, and $5n\le m\le n(n/2-1)$; guarded circles under
their displayed conditions; and protected circles for $n\ge25$ and
$3n\le m\le n(\lceil n/7\rceil-1)$.

**Sparse attainers.** `SixTypeConstruction` proves
$M(n,2s)=s(s-3)$ for $n\ge s\ge85$, including all 81 local patterns and
552 objectives. `OddEndpointConstruction` proves
$M(n,2s-1)=(s-1)(s-4)+2$ for $n\ge s\ge98$, including all 124 patterns and
847 objectives. Actual cyclic geometry, every local and outside cop reply,
safe-transfer composition and exact counts are proved for both families.
The odd residue thresholds also supply supports $88,89,90,94,95,96$.
Retained signed-rank graphs supply odd supports $13..18$; main-interval
endpoints supply even supports $12..18,50,55,65,70,75,80$. All permit padding
to every larger host. Stronger per-pattern delivery bounds are retained.

**Small budgets and finite exclusions.** Unrestricted sharp upper bounds
at budgets $0..10$ are $0,0,0,0,1,1,2,2,4,5,6$. Attainment is verified at
every admissible host for $0..3$, from host four for $4..6$, from five for
$7..8$, and from six for $9..10$. Every admissible budget at every host order
at most five is classified, with explicit attainers. These proofs include
actual support reduction, complete degree-profile coverage and every
surviving row choice. Signed winning and losing certificates additionally
prove the exact scores $8,9,11,13,15,19,28,33,40,53,60,79,83$ of retained
graphs at budgets $11..23$. These are lower witnesses, not unrestricted
upper bounds.

A complete exclusion proves $I(G)\le53$ for every loopless nine-vertex
graph. A sharper exclusion proves exact maximum thirty in the restricted
nine-vertex family having in-degree and out-degree two everywhere; all eight
first-factor cycle types are covered. This does not establish the separate
unrestricted value $M_E(18)=33$. `PositiveFourteen` proves $I(G)\le13$
for fourteen-arrow graphs whose nonisolated support has at least nine
vertices and every supported vertex has positive incoming and outgoing
degree, with arbitrary isolates allowed by `PositiveFourteenIsolates`.
The nine-vertex part checks 160,718 DAG nodes across eleven normalized
profiles; ten-vertex and larger-support arguments complete that stated
domain. Smaller supports and sources/sinks remain separate obligations for
the unrestricted fourteen-arrow maximum.

**Remaining formal obligations.** The main gaps are budgets $38..94$,
$40..99$, $42..125$, $44..109$, $46..114$, $48..119$ at orders $19..24$,
respectively; $111..149$ at fifty; $122..164$ at fifty-five; and
$2n\le m<3n$ at other orders $25..114$, excluding the ten completed orders
listed above. Even sparse supports $19..84$ remain except
$50,55,65,70,75,80$; odd supports $19..97$ remain except
$88,89,90,94,95,96$. Sharp unrestricted upper exclusions at budgets $11..23$,
joint tables at orders $6..11$, and final all-parameter formula/constructor
assembly are unfinished. Some alternative constructions and stronger
supplementary guarantees retain ordinary proof boundaries.

The complete classification is not yet a Lean theorem. Checking an attaining
graph does not exclude all competing graphs; a conditional local strategy
does not discharge its geometry. The source-pinned replay receipt and
`lean/README.md` state exactly what is checked. Every distributed module is
replayed with ordinary kernel reduction; no custom axiom, proof hole or
native proof is admitted. Dependencies are confined to Lean's standard
`propext`, `Classical.choice` and `Quot.sound`. Producers are untrusted and
unnecessary for replaying the literal sources. Module counts are inventories,
not percentages of mathematical completeness.

# Further consequences and open problems

The random statement in Theorem 54, specialized to the full vertex set, implies that for every fixed density $0<p<1$ the random loopless digraph guarantees all pairs with probability tending to one. Its failure probability is at most
$$n(n-1)^2\bigl(1-p^2(1-p)\bigr)^{n-3}.$$
Consequently
$$\mathbb E[I(G)]=(1-p)n(n-1)-o(1).$$
Indeed, the loss from the missing-pair count is at most $n(n-1)$ times the indicator of failure; the probability decays exponentially. This expectation conclusion is separate from the theorem's exact-budget conditioning and deterministic construction.

The exact-count and explicit-construction objective is complete. Corollary 47,
the finite sparse-budget theorem, and the complete small-host tables cover every
admissible pair. Maximizing that joint answer gives $M_V$ and $M_E$; those
projections are consequences rather than substitutes for the joint table.

Further simplification of the finite constructions and proofs remains possible.
It is not an unresolved value or missing attaining graph. Classification of all
extremizing graph shapes, a structural characterization of all guaranteed pairs,
and exact optimization of delivery time lie outside this paper's boundary.
The existing timing results and remaining timing questions are preserved in the
[delivery-time companion](https://angelraychev.com/cop-prisoner/delivery-time/).
The ordinary and finite proofs establish the classification. The accompanying
formal development has the more limited coverage specified above.

A finite construction at one circumference does not prove a uniform family. Here the finite bridge is complete on a bounded range and the retained ordinary constructions supply the infinite tail. A repeatable marked vertex-extension rule remains a possible simplification, not an unproved premise of the main-interval theorem.

A correct future proof must retain enough information about both players. Simple distance-to-recipient potentials fail: some states at a fixed small distance from the recipient require detours whose length grows with the graph. Nor does safe indefinite motion imply delivery. The finite witnesses and failed conjectures are preserved to make those distinctions reproducible.

# Construction appendix: choosing the circulant parameter

**Proof of Lemma 12.** If $n\equiv0\pmod4$, choose $h=n/2-1$; any common divisor with $n$ divides two and is odd. If $n\equiv2\pmod4$, choose $h=n/2-2$; the same argument uses four. If $n\equiv3\pmod4$, use $h=(n-1)/2$.

It remains to handle $n\equiv1\pmod4$. Write $n-1=2^e d$ with $d$ odd and $e\ge2$. If $d\ge7$, take $h=d$: it divides $n-1$ and is at most $(n-1)/4$. If $d\in\{1,3,5\}$ and $3\nmid n$, use $h=(n-3)/2$.

If $d=1$ and $3\mid n$, take $h=(n-7)/2$. The number $2^e+1$ is not divisible by seven, since powers of two modulo seven are $1,2,4$. The case $d=3$ and $3\mid n$ is impossible. Finally, if $d=5$ and $3\mid n$, then $e$ is even. Use $h=(n-11)/2$. Divisibility of $5\cdot2^e+1$ by eleven would imply $2^e\equiv2\pmod{11}$, whereas even powers have residues $1,3,4,5,9$.

All choices are odd and smaller than $n/2$. Their smallest possible lower estimate is $(n-11)/2\ge7$, valid for $n\ge25$. $\square$

# Provenance and assistance

Alexandra Ignatova formulated the original problem and developed the layered
construction in her 2023 project under Angel Raychev's mentorship, recorded
in the retained February 2024 manuscript. Their earlier work includes the
upper bound $I(G)\le n(n-3)$ and the investigation of two-in/two-out-regular
graphs. These results and this research direction are not claimed as new
in the present paper.

The September 2026 development, directed by Angel Raychev, repairs the
balancing and strategy arguments, corrects the original layered count,
and establishes the additional extremal bounds, attaining constructions,
finite computational proofs and formal results reported here. Astra 6,
operating through the Codex harness, made substantial contributions to
mathematical exploration and deductions, counterexample searches, proof
writing, programming, independent implementation and proof checks, and
Lean development. This assistance extended beyond language editing.
The paper distinguishes ordinary proofs, externally checked computational
proofs, and kernel-checked Lean results. The named human authors are
responsible for the submitted account; tool-assisted checks do not
constitute external peer review.
The formal verification was extended in October 2026 with further AI
assistance through Codex; its precise coverage is stated in the verification
section.

# References

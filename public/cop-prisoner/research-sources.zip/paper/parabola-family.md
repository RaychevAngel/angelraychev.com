# An explicit algebraic family at intermediate density

**Theorem 35.** Let $p\ge5$ be a prime. For every integer
$$4p^2\le m\le p^2(p-1),$$
there is an explicit graph attaining
$$
M(p^2,m)=p^2(p^2-1)-m.
$$
In particular, the interval extends to $m=n^{3/2}-n$ at orders $n=p^2$. For primes $p\ge11$, Theorem 34 extends its lower endpoint to $3p^2$.

**Proof.** Put $A=\{(t,t^2):t\in\mathbb F_p\}$, and let $H_A$ be the directed graph with all nonzero moves in $A$. Let $B_0$ be its four-move subgraph with parameters
$$t\in\{1,-1,-2,-3\}.$$
These are distinct and nonzero when $p\ge5$. We prove universal delivery in every graph $G$ satisfying $B_0\subseteq G\subseteq H_A$, including graphs without translation symmetry.

Every closed outgoing neighborhood in $G$ is a subset of the corresponding translate of $A$. Distinct translates of $A$ intersect in at most one point. Indeed, a nonzero difference
$$
(t,t^2)-(s,s^2)=(t-s,(t-s)(t+s))
$$
determines $t,s$ uniquely: if the first coordinate is nonzero, it determines their difference and sum, and division by two is valid; if the first coordinate is zero, the entire difference is zero. Thus every nonzero difference has at most one ordered representation.

This intersection property gives the following safe-branching rule. Fix a recipient. If two distinct outgoing neighbors of a vertex are already universally winning positions for that recipient, the vertex is universally winning as well. Against an initial cop at another vertex, at most one of the two successors lies in the cop's closed outgoing neighborhood. Move to the other, survive the cop's response, and use its winning strategy. The rule concerns the actual game, including the intervening pursuer move.

We first use recipient $0$ and only moves of the uniform core $B_0$. Put
$$u=(1,1),\qquad v=(-2,4),\qquad h=(-3,9)=u+2v,$$
and define
$$Q(z)=\{z,z-u,z-v,z-u-v\}.$$
The vertices $0,-u,-v$ are initially winning, by immediate receipt or a direct final move. The remaining vertex $-u-v$ has winning successors $-u,-v$, so all of $Q(0)$ is winning.

If every vertex of $Q(z)$ is winning, so is every vertex of $Q(z-h)$. Apply the safe-branching rule in the following order; each row lists the new vertex and two already winning successors:
$$
\begin{array}{c|cc}
z-h & z-u-v & z\\
z-h-u & z-h & z-u\\
z-h-v & z-h & z-v\\
z-h-u-v & z-h-v & z-u-v
\end{array}
$$
The corresponding pairs of moves are $(v,h),(u,h),(v,h),(u,h)$, respectively. They are distinct allowed moves.

Repeated propagation makes the entire line $L=\{\lambda h:\lambda\in\mathbb F_p\}$ winning: the nonzero vector $h$ has additive order $p$, so integer multiples cover all the displayed scalars.

Use the fourth core move $w=(-1,1)$. We have
$$w-v=(1,-3)=-h/3\in L,$$
while $v\notin L$ because $\det(h,v)=6\ne0$. If every vertex of a coset $L+z$ is winning, then every vertex of $L+z-v$ has two distinct winning successors, obtained by adding $v$ and $w$. The safe-branching rule therefore fills that entire coset as well. Iterating gives all cosets $L-jv$, which are the $p$ distinct cosets because $v\notin L$. Thus every vertex is winning.

The same proof shifted by the recipient uses only moves of $B_0$ and the global closed-neighborhood intersection bound. It applies to every recipient even if the extra arcs of $G$ are not translation invariant. Hence every intermediate graph is universally winning.

The core has $4p^2$ arcs, and $H_A$ has $p^2(p-1)$ arcs. Add the remaining arcs one at a time in any fixed order until the prescribed integer budget $m$ is reached. All $p^2(p^2-1)-m$ missing nonloop pairs are guaranteed, attaining the elementary upper bound. Finally, when $p\ge11$ we have $p^2\ge73$, so Theorem 34 covers the adjacent interval $3p^2\le m\le4p^2$. $\square$

The proof is finite and constructive: initializing a quartet takes at most two messenger moves, and each quartet propagation increases a bound by at most four. At most $p-1$ such propagations and $p-1$ further coset steps therefore give the uniform, unoptimized bound $5p-3$ messenger moves.

The prime hypothesis is intentional. In an extension field, repeated addition only covers scalars from its prime subfield, so this four-move propagation does not justify the same conclusion for arbitrary prime powers. The construction is checked at $p=5,7,11$ by `src/parabola_cayley.py`; it verifies the full-parabola intersection condition, the four-move core's complete safe-branching closure, and the core/upper-graph inclusions for all 827 consecutive integer budgets in these examples. At $p=5$, both full game solvers and their rank certificates independently verify every recipient. These finite checks supplement the ordinary proof and are recorded in `research/parabola-cayley-checks.json`. No new Lean formalization is claimed.

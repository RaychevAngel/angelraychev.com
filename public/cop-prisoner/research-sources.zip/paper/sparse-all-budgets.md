# The sparse interval as a consequence of the stronger envelope

**Theorem 41.** For every integer $n\ge2419$ and
every $2n\le m\le3n$, an explicit universally winning graph exists,
with delivery within $9\lceil n/6\rceil+26$ messenger moves and arbitrary
subsets of its prescribed optional arrows.

**Proof.** Theorem 52 gives the stronger assertion from $n\ge115$,
through a larger exact budget endpoint, with the better time bound
$9\lceil n/6\rceil+21$. $\square$

The earlier construction separated deletions by seventeen columns and
forbade optional arrows within sixteen columns of a deletion. Its separate
finite strategy certificates remain available. The new theorem replaces
that numerical result and its overlap role; the old proof is retained in
`research/sparse-budget-earlier-proof.md` for reproducibility.

**Corollary 42.** There is an absolute $N$ such that
for every $n\ge N$ and $2n\le m\le n(n-3)$,
$$M(n,m)=n(n-1)-m.$$

**Proof.** Theorem 44 now permits the explicit choice $N=115$, with
combinatorial attaining constructions throughout. $\square$

# Protected routing sets at every exact budget

The random construction can be strengthened by reserving a small set of
routing vertices. Only arrows incident with that set are used to certify
delivery. All arrows outside the set can then be chosen freely, including
adversarially, without invalidating any certified route.

**Theorem 54 (protected routing).** Let $n\ge4$, let $H$ be a specified
set of $b\le n$ vertices, and put
$$
L=n(n-1),\qquad Q=b(2n-b-1).
$$
Choose an integer $0<a<Q$ and write $p=a/Q$. If
$$
(b-3)p^2(1-p)>4\log n+\log(8/3), \tag{R}
$$
there is a deterministic algorithm, polynomial in $n$, choosing exactly
$a$ arrows with at least one endpoint in $H$ such that **every assignment
of the arrows between vertices outside $H$** guarantees every
source--recipient pair within two messenger moves. In particular, at
every integer budget
$$
a\le m\le a+(n-b)(n-b-1),
$$
an explicit algorithm attains $M(n,m)=L-m$.

Separately, for every real $0<p<1$, without condition (R) or an
integer exact-budget requirement, independently including each of the
$Q$ incident arrows with probability $p$ fails to give such a robust
routing set with probability at most
$$
n(n-1)^2\bigl(1-p^2(1-p)\bigr)^{b-3}.
$$
Thus the theorem includes both the deterministic exact-budget and the
random-construction conclusions.

**Proof.** Fix $s\ne t$ and an initial pursuer position $c\ne s$. Each
$u\in H\setminus\{s,t,c\}$ certifies a safe two-move route when
$$
s\to u,\qquad u\to t\quad\hbox{are present},\qquad c\to u
\quad\hbox{is absent}.
$$
The three variables are distinct, even when $c=t$. All are incident
with $H$. For different candidates the sets of three variables are
disjoint: an equality between an incoming-to-candidate variable and
an outgoing-from-candidate variable would force a candidate to equal
one of $s,t,c$, which is excluded.

There are at least $b-3$ candidates, each with probability
$p^2(1-p)$ of success. There are exactly $n(n-1)^2$ legal triples.
The union bound proves the random assertion. If $Z$ counts bad
triples, it also gives
$$
\mathbb E Z\le n(n-1)^2e^{-(b-3)p^2(1-p)}
<\frac{3}{8n}
$$
under (R).

Let $X$ be the number of chosen incident arrows. Then
$X\sim\operatorname{Bin}(Q,a/Q)$ and $a$ is a mode. Since
$\operatorname{Var}(X)\le Q/4$, Chebyshev's inequality gives
$\Pr(|X-a|<\sqrt Q)\ge3/4$. Here $Q\le n(n-1)$, so this interval
contains at most $2n-1$ integers. Modal maximality implies
$$
\Pr(X=a)\ge\frac{3}{4(2n-1)}\ge\frac{3}{8n}.
$$
Therefore $\mathbb E[Z\mid X=a]<1$.

For completeness, the conditional-expectation algorithm remains
exact when restricted to these $Q$ variables. After a partial
assignment, let $\ell$ be the number of undecided incident arrows
and $d$ the number of additional present arrows required. The total
number of completions is $C=\binom{\ell}{d}$. For a fixed legal
triple, each candidate contributes a factor $(1+x)^q$ if its witness
pattern is already contradicted; otherwise its factor is
$(1+x)^q-x^j$, where $q$ variables remain undecided and $j$ of them
require presence. Multiply these factors, multiply by
$(1+x)^{q_0}$ for unused variables, and extract the coefficient of
$x^d$. This counts exactly the completions in which the triple is bad.
Summing over triples gives an integer $B$ with initial $B<C$.

For either decision on the next arrow, child counts satisfy
$B=B_0+B_1$ and $C=C_0+C_1$. Hence some feasible child retains
$B_i<C_i$. At the end $C=1$ and $B=0$. There are $O(n^2)$ decisions
and $O(n^3)$ triples per decision, with polynomial-size polynomial
products and $O(n^2+\log n)$-bit counts. Straightforward exact integer
arithmetic is therefore polynomial in $n$.

For every legal triple a selected candidate differs from the pursuer
and both endpoints. Moving to it is safe, and the pursuer cannot
reach it on its response. The messenger then reaches the recipient;
receipt precedes collision. No outside-$H$ arrow appears in these
conditions, so the same strategies work for every assignment of
those arrows. There are $(n-b)(n-b-1)$ of them. Choosing any prescribed
number proves the entire displayed exact-budget interval. $\square$

Setting $H=V$ gives $Q=L$ and the former exact-budget density theorem
at every original order and budget, with its polynomial algorithm and
two-move guarantee. A smaller routing set adds genuine robustness and
extends the low-density range; it does not merely combine old intervals.

## An explicit interval from oriented routing pairs

::: {#the-scale-of-the-first-universal-two-move-budget}
The separate two-move sparsity question and its bounds are in the
[delivery-time companion](https://angelraychev.com/cop-prisoner/delivery-time/#the-scale-of-the-first-universal-two-move-budget).
The exact-budget routing constructions remain here.
:::

**Orientation specialization.** Fix a routing set $H$ of size $b$, and
let $Q=b(2n-b-1)$. If
$$n(n-1)^2(7/8)^{b-3}<1,$$
there is a deterministic polynomial construction using exactly $Q/2$
incident arrows that preserves universal two-move delivery under every
choice of exterior arrows. Thus all budgets from $Q/2$ to $L-Q/2$ work.
A sharper sufficient condition is
$$n(n-1)(n-2)(7/8)^{b-3}+n(n-1)(3/4)^{b-2}<1.$$

To prove this, independently orient each unordered pair touching $H$,
with its two directions equally likely. The incident count is exactly
$Q/2$ for every outcome. For distinct $s,t,c$, a candidate
$u\in H\setminus\{s,t,c\}$ is a safe intermediary when
$s\to u$, $u\to t$, and $u\to c$, with probability $1/8$.
The last orientation excludes $c\to u$. Different candidates use
independent orientation variables. When $c=t$, only two variables
are needed and the probability is $1/4$. Counting the two kinds of
triples gives the sharper displayed failure bound; the coarser one
also follows. Exterior arrows occur in none of these tests.

For exact derandomization, fix orientations in sequence. For a given
triple and candidate with $j$ free relevant variables, there are $2^j$
bad completions if a fixed variable already prevents the witness,
and $2^j-1$ otherwise. Multiply over candidates, whose variable sets
are disjoint, and account for irrelevant free variables. Summing these
integer counts over triples gives the total number of bad completions,
with multiplicity. Initially it is smaller than the number of all
completions. At each decision choose a branch preserving that strict
inequality; the two child counts sum to their parent counts. At the end
there is one completion and zero failures. There are polynomially many
operations on integers of polynomial bit length. This specialization
replaces coefficient extraction by products, while the full density
and sampling assertions of Theorem 54 remain available.

**Corollary 55.** Set
$$
b_n=\lceil24\log n+4\rceil,\qquad
A_n=\frac{b_n(2n-b_n-1)}2.
$$
Whenever $b_n\le n$, every integer budget $A_n\le m\le L-A_n$
admits universal two-move delivery by a deterministic polynomial
algorithm, with arbitrary exterior-arrow subsets as in Theorem 54.
For every $n\ge4096$, this extends to every integer budget
$$
A_n\le m\le n(n-3).
$$

**Proof of the constructions.** Use the orientation specialization.
Since $(7/8)^x\le e^{-x/8}$ for $x\ge0$,
$$n(n-1)^2(7/8)^{b_n-3}<n^3 e^{-(b_n-3)/8}
\le e^{-1/8}<1.$$
It gives the exact robust interval $[A_n,L-A_n]$.

For $n\ge4096$,
$$
b_n\le24\log n+5\le32\log n+12\le(n-1)/13.
$$
At $4096$, $\log4096=12\log2<9$ makes the left side of the second
inequality less than $300$, while its right side equals $315$.
The difference increases thereafter because $1/13-32/n>0$.
The elementary inequality $\log2<3/4$ follows, for example, from
$1+3/4+(3/4)^2/2>2$.

Consequently $A_n\le nb_n\le n(n-1)/13$. The existing dense
constructions supply every missing budget from $2n$ through
$n\lceil(n-1)/13\rceil$ for $n\ge32$, in two moves (Theorems 48 and 58).
Their interval overlaps $[A_n,L-A_n]$, proving the claimed extension
through $L-2n=n(n-3)$. $\square$

**Verification boundary.** The proofs above are ordinary mathematical
arguments. The restricted exact-count implementation and its independent
finite checks are recorded in research/routing-unification-checks.json;
the independent proof review is research/routing-independent-audit.md.
No large instance of the polynomial conditional-expectation algorithm is
claimed. `ProtectedRouting.lean` verifies preservation of safe routing
witnesses under arbitrary exterior-arrow changes and their implication
for actual terminating delivery. The probability estimates and counting algorithm remain ordinary proofs.

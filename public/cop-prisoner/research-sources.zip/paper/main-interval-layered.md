# Routing through a layer of guides

A small hub-and-guide interface can serve arbitrarily many additional
vertices. The following attachment lemma separates its delivery proof
from the antichain argument that enters it. This gives the three- and
five-move constructions below without repeating their pursuer cases.

**Lemma (guide attachment).** Let $H$ be a set of $h$ hubs with $a$
internal arrows, and let $D$ be $g$ disjoint guide vertices. Guide $j$ reaches precisely
the hubs outside its omitted set $K_j$, and no other guide. Put
$W_K=\sum_j|K_j|$. Include all arrows from $R\subseteq H$ to the guides and no other
hub-to-guide arrows. Choose $S\subseteq U\subseteq H$.

Attach $b$ bulk vertices. Every hub in $R$ reaches every bulk vertex;
each bulk vertex $x$ reaches $S$ and its assigned guide set $J_x$.
These are all compulsory arrows. The distinct sets $J_x$ have size at
least two and form an antichain. Put
$W_J=\sum_x|J_x|$. The optional arrows are all guide-to-bulk arrows,
all distinct bulk-to-bulk arrows, the arrows from a fixed
$C\subseteq H\setminus R$ to every bulk vertex, and the arrows from
each bulk vertex to $U\setminus S$. Assume:

1. Every hub in $R$ has a missing hub successor in $S$; the successor
   must differ from the hub itself.
2. From every hub or guide, delivery takes at most $d$ moves using
   only hubs as nonterminal intermediaries and compulsory final arrows.
   This interface strategy remains valid against a bulk pursuer allowed
   every hub in $U$, every guide, and every bulk vertex.

Then every optional subset gives universal delivery within $d+1$ moves.
Its exact-budget interval is
$$
 A\le m\le A+b\bigl(g+b-1+|C|+|U\setminus S|\bigr),
$$
where
$$
 A=a+(|R|+h)g-W_K+(|R|+|S|)b+W_J.
$$
The interface hypothesis is finite: a recipient outside $H$ is represented
by a terminal outlet reached from $R$, and a bulk pursuer by its permitted
hub set $U$ and unrestricted guide access. Hub moves do not distinguish
other bulk vertices. Receipt at the actual recipient is always terminal,
even if that vertex is occupied by the pursuer.

**Proof.** Let the messenger start at a bulk vertex $x$. If the pursuer
is a hub in $R$, the first hypothesis supplies a safe compulsory move
into $S$. A hub outside $R$ reaches no guide, so any assigned guide is
safe against it. Against a guide pursuer choose an assigned guide other
than the pursuer, possible because $|J_x|\ge2$. Against another bulk
pursuer $c$, choose a guide in $J_x\setminus J_c$; incomparability makes
this difference nonempty, and no optional arrow enters a guide from a
bulk vertex. Each chosen vertex lies in the interface and outside the
pursuer's closed neighborhood in the full envelope. After the cop reply
the interface strategy therefore applies. If the chosen vertex is the
recipient, receipt has already ended play. Interface sources need no
entry move. This proves the time bound against the full envelope and
hence for every optional subset.

Count the $a$ hub arrows, $|R|(g+b)$ outlet arrows, $hg-W_K$
guide-to-hub arrows, and $|S|b+W_J$ bulk arrows to obtain $A$.
The four disjoint optional classes have sizes $gb$, $b(b-1)$,
$|C|b$, and $|U\setminus S|b$. Taking an ordered-endpoint prefix attains
every stated integer budget. $\square$

**Theorem (three-move layered construction).** Choose integers
$2\le r\le g\le14$ and $0\le b\le\binom gr$, and put
$n=14+g+b$. There is a direct construction attaining
$M(n,m)=n(n-1)-m$ for every
$$
 A\le m\le A+b(g+b-1),\qquad A=154+25g+(22+r)b.
$$
It guarantees delivery within three messenger moves. Every subset of the
specified optional arrows is permitted. For pairs of guides, $r=2$,
the compulsory budget is $A=24n-182+g$.

**Construction and proof.** Take fourteen hubs $P_i,L_i$, indexed modulo
seven, with missing arrows
$$P_i\to L_i,L_{i-1},\qquad L_i\to P_{i+4},P_{i+6}.$$
All other distinct hub pairs are arrows, giving $a=154$. Use the first
$g$ omitted guide codes in the ordered list
$$
 \{L_i,L_{i+2},L_{i+4}\}\quad(0\le i<7),\qquad
 \{P_i,P_{i+1},P_{i+4}\}\quad(0\le i<7).
$$
Set $R=H$, $C=\varnothing$, and
$$S=U=\{P_0,P_1,P_4,P_5,L_0,L_2,L_4,L_6\}.$$
Assign the bulk vertices the first $b$ distinct $r$-subsets of the guides
in lexicographic order. The guide attachment lemma prescribes all arrows.
In particular, only guide-to-bulk and distinct bulk-to-bulk arrows are
optional; take their first $m-A$ ordered endpoints for the exact budget.

The displayed guide codes satisfy Theorem 59. Thus hub and guide
sources deliver within two moves against hub and guide pursuers,
using only hub intermediaries. To check a bulk pursuer, put
$$T=H\setminus U=\{P_2,P_3,P_6,L_1,L_3,L_5\}.$$
For a missing hub pair $(s,t)$, its danger set
$F^+(s)\cup F^-(t)$ has only two points and two lines, so it cannot
contain $T$. A hub in the difference is a safe intermediary. A hub
source reaches any outside recipient directly. For a guide source,
the opposite part from its omitted code contains three reachable safe
hubs in $T$. All reach an outside recipient. A missing hub recipient
lies in the code's own part, so at most two fail to reach it. This proves
the two-move interface hypothesis.
Finally, $T$'s point triple contains no difference-two pair and its line
triple contains no adjacent pair, so $S$ meets every hub missing row.
The lemma applies with $d=2$, $W_K=3g$ and $W_J=rb$, giving exactly
the stated count and three-move bound. Every missing pair delivers,
so the missing-pair upper bound is attained. $\square$

For example, $(g,b,r)=(10,36,2)$ gives every budget 1268 through 2888
at order 60; $(11,55,2)$ gives 1749 through 5324 at order 80.
The larger-$r$ formulas remain valid when more bulk vertices are needed.
The direct implementation is `src/main_interval_layered.py`; its checks
replay the two-move interface and safe-entry obligations against the full
optional envelope. They supplement the ordinary all-parameter proof.

## A smaller core with antipodal guide codes

**Theorem (twelve-hub guide construction).** Choose
$2\le r\le g\le8$, $0\le b\le\binom gr$, and put
$n=12+g+b$. Every exact budget
$$
 A\le m\le A+b(g+b-1),\qquad A=106+22g+(19+r)b
$$
has a direct attaining construction with delivery within three messenger
moves. Every optional subset is valid.

**Construction and proof.** Use the same hub missing-arrow formula modulo
six, giving $h=12$ and $a=108$. Use the first $g$ guide codes in
$$
 \{L_0,L_2,L_4\},\quad\{L_1,L_3,L_5\},\quad
 \{P_i,P_{i+3}\}\ (0\le i<3),\quad
 \{L_i,L_{i+3}\}\ (0\le i<3).
$$
Set $R=H$, $C=\varnothing$, and
$$S=U=H\setminus T,\qquad T=\{P_0,P_3,L_0,L_2,L_4\}.$$
Again assign the first $b$ lexicographic $r$-subsets of guides and use
the attachment lemma's adjacency and optional-prefix rule.

All guide codes satisfy generalized Theorem 59, including its separated
pair condition. Its hub-intermediary proof supplies the interface against
hub and guide pursuers. Against a bulk pursuer, a missing hub pair has
a safe intermediary in $T$: its line triple cannot fit in the danger
set's two lines. For a point-code guide source, all three safe lines
are reachable, and at most two fail to reach a missing hub recipient,
which is a point. For a
line-code guide, the two safe points are reachable. A missing hub
recipient is a line, whose missing predecessors are adjacent points;
they cannot contain the antipodal pair $\{P_0,P_3\}$. Either choice
of opposite part also reaches every outside recipient. Hub sources
reach outside recipients directly. This proves the two-move interface.

The safe point pair has difference three and the safe line triple has
no adjacent pair, so $S$ meets every hub missing row. The attachment
lemma now uses $d=2$, $|S|=7$, $W_K=2g+2$ and $W_J=rb$, giving
$108+24g-(2g+2)+(19+r)b=A$ and the claimed optional count. $\square$

For pair guide codes the base is $21n-146+g$. At
$(n,g,b,r)=(40,7,21,2)$ this gives 701 through 1268.
Taking $g=8,r=3$ gives
$$
 22n-158\le m\le22n-158+(n-20)(n-13),\qquad20\le n\le76.
$$
At orders 50 and 60 the intervals are respectively 942 through 2052
and 1162 through 3042. These are all-parameter consequences of the
ordinary proof, not extrapolations from numerical games.

`lean/GuideAttachment.lean` formalizes antichain safe entry followed by a
supplied interface strategy. The concrete hub sets, interface witnesses,
code counts and adjacency instantiations remain ordinary proofs and
independently checked construction data, not claimed Lean coverage.

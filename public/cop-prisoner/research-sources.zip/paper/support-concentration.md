# Quantitative concentration near the sparse optimum

The exact support alternatives in Theorems 56 and 57 apply above specific
cutoffs. The following estimate continues below those cutoffs. It says that
losing only a linear number of pairs from the leading quadratic bound forces
only a bounded number of exceptional vertices and arrows. It makes no claim
that deleting those exceptions preserves a delivery strategy.

**Theorem 60.** Let $G$ have $m$ arrows and $I=I(G)$. Put
$$A=\{v:d^+(v)\ge2\},\qquad B=\{v:d^-(v)\ge2\},$$
$$q=|A|,\quad r=|B|,\quad b=|A\cap B|,\quad a=m-2q,\quad d=m-2r.$$
If $R$ and $C$ count the source rows and recipient columns containing at
least one guaranteed indirect pair, then
$$R\le\min\{q,b+2a+\lfloor d/2\rfloor\},\qquad
C\le\min\{r,b+\lfloor a/2\rfloor+2d\},\qquad I\le RC.$$
Define $\eta=m-2\sqrt I\ge0$. The induced core $K=G[A\cap B]$ satisfies
$$m/2-3\eta\le |V(K)|\le m/2.$$
The graph has at most $m/2+4\eta$ nonisolated vertices, and at most
$12\eta$ arrows have an endpoint outside $K$.

**Proof.** Only vertices in $A$ can supply nonzero indirect source rows,
and only vertices in $B$ can supply nonzero recipient columns. These are
the usual camping obstructions at degree zero or one. In particular
$I\le qr\le m^2/4$.

At most $d$ arrows end outside $B$, so at least
$z=\max(0,q-b-d)$ vertices of $A\setminus B$ have indegree zero. They emit
at least $2z$ arrows. Let $x$ be the total excess indegree above two inside
$B$. At most $d-x$ arrows end outside $B$, and vertices of indegree at least
three have total indegree at most $3x$, since $e\le3(e-2)$ for $e\ge3$.
Thus at most $3d$ of the $2z$ arrows can avoid indegree-two recipients.
At least $z-\lfloor3d/2\rfloor$ distinct indegree-two recipients have an
indegree-zero predecessor.

Each such recipient has a zero indirect column. An indirect source cannot
reach the indegree-zero predecessor and must approach through the other
predecessor, where the pursuer can wait. Therefore
$$C\le r-z+\lfloor3d/2\rfloor
\le r-q+b+d+\lfloor3d/2\rfloor
=b+\lfloor a/2\rfloor+2d.$$
The identity uses $r-q=(a-d)/2$ and the common parity of $a,d$.

For the row bound, use the original arrow directions. At least $r-b-a$
members of $B\setminus A$ are sinks. Their incoming arrows force
outdegree-two predecessors except for at most $3a$ arrows, by the same
surplus count. An outdegree-two source with a sink successor has zero
indirect row: the pursuer camps at the other successor. Repeating the count
gives $R\le b+2a+\lfloor d/2\rfloor$. This is not an appeal to symmetry
under reversing the pursuit game. The displayed minimum bounds and
$I\le RC$ follow.

Put $S=a+d$. Since $q+r=m-S/2$ and $I\le qr$, arithmetic--geometric mean
gives $S\le2m-4\sqrt I=2\eta$. The row and column estimates also imply
$$2\sqrt I\le R+C\le2b+\tfrac52S,$$
so $b\ge\sqrt I-5S/4\ge m/2-3\eta$. Its upper bound is immediate.

Every nonisolated vertex outside $A\cup B$ contributes at least one to its
incoming plus outgoing degree. Outgoing degrees outside $A$ total at most
$a$, and incoming degrees outside $B$ total at most $d$. There are therefore
at most $S$ such vertices. The nonisolated support is at most
$$q+r-b+S=m-b+S/2
\le m-\sqrt I+\tfrac74S\le m/2+4\eta.$$
Finally, the number of arrows with tail outside $A\cap B$ is at most
$2(q-b)+a$, and the analogous incoming count is at most $2(r-b)+d$.
Counting an arrow twice can only increase this estimate. The number of
arrows outside the induced core is thus at most
$$2(q+r-2b)+S=2m-4b\le2m-4\sqrt I+5S\le12\eta.$$
This proves all assertions. $\square$

For example, if $m=2k$ and $I\ge k(k-3)-\Delta$ with $\Delta=O(k)$,
then $\eta=O(1)$. Thus the support has at most $k+O(1)$ vertices and
all but $O(1)$ arrows lie inside a core of at most $k$ vertices. The constants
above are explicit but are not asserted to be optimal. Theorems 56 and 57
retain their sharper conclusions in their stated ranges. In particular,
this concentration estimate does not supply the game restriction
$I(K)\ge I(G)$ that is proved under the more specific hypotheses of
Theorem 57.

The argument was independently reviewed and checked against both game
solvers on all 4,165 labelled loopless digraphs through four vertices and
181 additional graphs. The ordinary proof, finite tests, and exact integer
comparisons are recorded in `research/routing-defect-phase2-support.md` and
its two verification receipts. This theorem is not presently formalized
in Lean.

## A bounded host for every remaining small budget

The refined outside-vertex counts in the small sparse section make a stronger
finite reduction possible. This is a reduction of the whole extremal problem,
not a claim that an arbitrary induced core preserves a strategy.

**Corollary 60.1.** For $12\le m\le21$, define $B_m$ by
$$
(B_{12},B_{13},\ldots,B_{21})
=(12,13,16,18,15,18,15,18,11,15).
$$
Then, for every admissible host order,
$$M(n,m)=M(\min\{n,B_m\},m).$$
An explicit graph attaining the value on $B_m$ vertices supplies an explicit
attainer on every larger host by adding isolated vertices.

**Proof.** The saved lower scores at these ten budgets are, respectively,
$$9,11,10,11,19,19,30,30,53,56.$$
They are attained on respectively $7,8,7,7,8,8,9,11,10,11$ vertices.
The 19-arrow witness is the disjoint union of the nine-vertex, 18-arrow
graph and a single directed arrow. Every listed support is at most $B_m$.

Apply the refined necessary integer-profile bounds to a graph scoring
strictly more than the listed lower score. Complete enumeration of the
integer parameters, independently implemented in two ways, bounds its
nonisolated support by
$$12,13,16,18,15,18,15,18,13,15.$$
This enumerates degree counts, not graphs. Every actual graph has one of
the enumerated tuples; a surviving tuple need not be realizable.

Only the 20-arrow bound needs a further observation. Its sole possible
13-vertex tuple has a nine-vertex core in which every vertex has indegree
and outdegree two, together with two one-arrow sources and two one-arrow
sinks. The eligible source--recipient rectangle has at most 56 pairs.
An arrow from an outside source into the core kills a whole indirect
recipient column: a core source can reach at most the other predecessor,
where the pursuer waits. An arrow from the core to an outside sink kills
the corresponding source row. Each such row or column contains at least
six eligible pairs, leaving at most 50 guarantees. If neither interaction
occurs, the core has 18 arrows and the outside arrows form a separate
zero-count component. Then $I\le M_E(18)\le44$. Neither case can beat 53,
so every improvement has support at most twelve at budget twenty. The
twenty-arrow host-compression proposition in the small sparse section
then replaces its only surviving twelve-vertex form by an eleven-vertex
graph of the same score, using a fresh sink. This gives $B_{20}=11$;
it does not claim that every improving graph already has support eleven.

For $n>B_m$, take any $n$-vertex graph. If its score is no greater than
the saved lower score, the saved witness already matches or improves it on
at most $B_m$ vertices. Otherwise delete only its isolated vertices, using
the proved support bound, using the compression at budget twenty when
needed, and pad to $B_m$ if necessary. This proves
$M(n,m)\le M(B_m,m)$; adding isolates proves the reverse inequality.
For $n\le B_m$ the assertion is an identity. $\square$

The exact arithmetic, literal lower witnesses and independent replays are
indexed in `research/small-case-results.json`. Together with the complete
joint coverage from order eleven, this confines every remaining unknown
numerical value to a host of order at most eighteen. The separate recipe
audit is still required: a numerical reduction alone would not prove that
an infinite known-value domain has explicit constructions.

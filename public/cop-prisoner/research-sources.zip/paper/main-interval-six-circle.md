# Six-offset circles and finite changes of the compulsory moves

The five-offset circle uses a protected pair of escape moves. Its envelope
therefore cannot exceed half density: two translates of that envelope have
at most one common point. Adding a sixth compulsory move replaces the pair
by a triple. The same four-position pattern still propagates, but the
permitted graph may now contain substantially more arrows.

**Theorem (three escape triples).** Work in $\mathbb Z/n\mathbb Z$ and choose
$h$ with $\gcd(h,n)=1$. Require the offsets
$$C=\{1,h-3,h-2,h,h+1,h+2\}$$
to be six distinct nonzero residues. Let $A$ contain $C\cup\{0\}$. Suppose
that, for every nonzero residue $q$, none of
$$S_0=\{h,1,h+1\},\qquad S_1=\{h,h-3,h-2\},\qquad
S_2=\{h,h-2,h+2\}$$
is contained in $q+A$. Include every arrow whose difference belongs to $C$
and any subset of the other arrows whose nonzero difference belongs to $A$.
Every resulting graph has universal delivery. Consequently this is an
explicit attaining construction at every exact budget
$$6n\le m\le n(|A|-1),\qquad M(n,m)=n(n-1)-m.$$

**Proof.** Fix recipient zero and call a source winning when delivery is
guaranteed from every distinct pursuer position. A winning set of vertices
supports an additional source whenever all its successors from one of the
three displayed triples are already winning. The escape condition selects
one successor outside the pursuer's full closed envelope. After every
pursuer response, the messenger remains uncaptured and uses the successor
strategy. Every such addition has a finite strictly decreasing strategy
rank when followed during play.

Put $P(z)=\{z-2,z-1,z,z+2\}$. Every member of $P(-h)$ is a direct compulsory
predecessor of zero; the new offset $h+1$ supplies its previously missing
member. From a winning $P(z)$, add the following four sources in order:

* $z-h+2$ uses $S_1$, reaching $z+2,z-1,z$;
* $z-h$ uses $S_2$, reaching $z,z-2,z+2$;
* $z-h-1$ uses $S_0$, reaching $z-1,z-h,z$;
* $z-h-2$ uses $S_0$, reaching $z-2,z-h-1,z-1$.

This yields $P(z-h)$. Coprimality makes its successive translates cover
every vertex. All additions use previously established finite ranks, even
when some modular vertices coincide. Translating the argument establishes
every recipient. The messenger uses only compulsory arrows and the
pursuer may use the full envelope throughout; therefore every optional
subset is covered, including nonsymmetric subsets. Add the first $m-6n$
optional arrows in lexicographic order of ordered endpoints to obtain the
exact budget. All missing pairs are winning, proving equality in the
missing-pair upper bound. $\square$

**Two periodic recipes.** The escape hypotheses admit direct residue rules.

1. If $4\mid n$, $h\ge7$, $h\equiv3\pmod4$, $2h+2\le n$, and
   $\gcd(h,n)=1$, take
   $$A=\{x:x\equiv0,1\pmod4\}\cup\{h\}.$$
   There are no deleted offsets. This gives $|A|=n/2+1$ and the whole
   interval $6n\le m\le n^2/2$. The parameter rule from the five-offset
   theorem provides such an $h$ at every $4\mid n$, $n\ge16$.

   To check escape, a pursuer of residue one cannot reach $h$. A pursuer
   of residue zero reaches $h$ only when it is zero. A pursuer of residue
   two reaches no zero-class point and at most one one-class point;
   a pursuer of residue three reaches no one-class point. Every required
   triple contains $h$ and either a zero-class and a one-class point or
   two distinct one-class points. None can be covered.

2. If $5\mid n$, $h\ge8$, $h\equiv3\pmod5$, $2h+2\le n$, and
   $\gcd(h,n)=1$, take
   $$A=\bigl(\{x:x\equiv0,1,4\pmod5\}\cup\{h\}\bigr)
       \setminus\{h+3,h-4,2h-1\}.$$
   The three deleted offsets are distinct, lie in the periodic part, and
   avoid $C\cup\{0,h\}$. Thus $|A|=3n/5-2$, giving
   $$6n\le m\le n(3n/5-3).$$
   For every odd multiple of five with $n\ge25$, one may simply take
   $h=8$. The rule also applies to all other displayed arithmetic
   parameters, with no graph search.

   For the escape check, the periodic residue set is three consecutive
   residues modulo five, whereas the residues of each required triple
   are not three consecutive residues. A covering translate must therefore
   use the exceptional envelope point $h$. For $S_0$ this leaves possible
   pursuers $q=0,1-h,1$; for $S_1$ they are $0,-3,-2$; and for $S_2$ they
   are $0,-2,2$. Ignore the forbidden pursuer zero. For $S_0$, $q=1$ would
   require $h-1$, whose residue is absent, and $q=1-h$ requires the deleted
   $2h-1$. For $S_1$, $q=-2$ requires the absent-residue offset $h-1$ and
   $q=-3$ requires the deleted $h+3$. For $S_2$, $q=-2$ requires the
   absent-residue offset $h+4$, and $q=2$ requires the deleted $h-4$.
   These exhaust the possible covers. $\square$

**Finite circle envelopes.** The literal offsets in
`research/six-circle-recipes.json` supply the theorem's escape premises
at every order from 16 through 42. They are finite construction data;
constructing a graph reads those data and performs no optimization.
The direct checker separately verifies every translated triple against
every nonzero pursuer position.

At some small orders, the fixed three-triple test stops short of the next
construction. One can instead enlarge the envelope and make some newly
available offsets compulsory. The messenger can then use the new arrows
to counter the pursuer's new moves. These finitely many promoted envelopes
carry a different certificate: a literal nonnegative source-rank vector
$r$ for recipient zero. It has $r(0)=0$, and every other source either has
a direct compulsory arrow to zero or, against each distinct pursuer, has
a compulsory successor of smaller rank outside the pursuer's closed
envelope. The usual finite-rank induction proves actual delivery.
For recipient $t$, use $r(s-t)$; the checker also replays every target
explicitly. This applies to all optional subsets and does not infer
intermediate-budget success merely from successful endpoints.

For example, at order 24 the six-offset envelope is
$$A_0=\{0,1,4,5,7,8,9,12,13,16,17,20,21\},$$
covering $144\le m\le288$. Add offset three to the envelope and take
every nonzero offset in the enlarged envelope except offset one as
compulsory. The resulting $288\le
m\le312$ family has the rank vector
$$\begin{split}
(&0,3,4,1,1,3,6,1,1,3,6,1,1,5,2,1,1,1,4,1,1,1,4,7).
\end{split}$$
The only optional arrows in this second envelope have difference one.
Thus every budget between 144 and 312 is covered by a direct finite recipe.

In the same way, the six-offset and promoted envelopes together provide
every $6n\le m\le U_n$ for orders 19 through 27, where
$$
(U_{19},U_{20},U_{21},U_{22},U_{23},U_{24},U_{25},U_{26},U_{27})
=(228,240,252,264,299,312,350,364,378).
$$
The supplied source ranks, rather than the three-triple theorem, justify
the promoted portions. This is a finite certificate boundary, not an
assertion that an optimization result proves an infinite family.

The direct constructor is `src/main_interval_six_circle.py`. Its check
replays the escape clauses or supplied ranks, the four propagation
identities, exact arc counts, and every recipient for the promoted rows.
`research/six-circle-checks.json` records the executable checks. `CircularSourceRanks.lean` and `SixCircleFinite.lean` now instantiate
the retained finite source-rank rows and their exact optional-prefix
intervals. The general three-escape-triple theorem retains its ordinary
parameterized proof boundary.

# Local strategies on cyclic graphs

The following lemmas separate the finite strategy certificates from the
ordinary simulation and composition arguments used by the sparse families.

**Lemma (local simulation).** Represent actual delivery-game states by
states of a local alternating arena, preserving the player to move.
A local winning strategy applies to the actual game if:

1. Its selected messenger moves lift to legal actual moves with the
   prescribed represented successors.
2. Every actual pursuer response has a permitted local image, and
   nonterminal collisions are preserved.
3. Local delivery success means actual receipt; local safe handoff means
   a noncollision messenger turn after the pursuer response, satisfying
   the next module's source requirements.

Its messenger-move bound is preserved. Encountering the actual recipient
inside a handoff module instead ends play immediately, before collision.

**Proof.** The first two conditions represent every actual play following
the strategy by a legal local play; the third identifies its success.
Termination follows from the certified nonnegative ranks. Both conventions
used below suffice: strict descent at each nonterminal half-move, or strict
descent at messenger moves and nonincrease at pursuer responses. The latter
strictly decreases rank each round. Rank zero requires the stated success;
nonterminal collision states cannot be winning. In particular, a handoff
is not complete until the pursuer reply has been survived. $\square$

**Lemma (window projection).** Represent a pursuer exactly in columns
$[-R,R]$ of a ring of circumference $q$, and otherwise by $\Omega$.
Confine the messenger to $[-M,M]$, where $M<R$. Suppose actual pursuer
jumps have absolute column displacement at most $J\ge1$, and the local
arena includes their represented moves, sends exits to $\Omega$, and
allows $\Omega$ to wait or enter any existing vertex in either boundary's
$J$ layers. If
$$q\ge2R+J+1,$$
every actual pursuer move projects legally and no collision is concealed.
Selected messenger moves must separately lift legally.

**Proof.** Represented columns are distinct. A wrapped jump between their
opposite ends would need displacement at least $q-2R>J$. Outside moves
project to waiting at $\Omega$ or entry into a permitted boundary layer;
other moves are literal or exits. Every messenger position lies in the
exact pursuer window, so collisions are detected. $\square$

For a single periodically repeated defect, include all changed outgoing
tails, deleted vertices and exceptional source or recipient positions in
its relative support $[a,b]$. A window meets only anchors in
$[-R-b,R-a]$. Hence
$$q\ge2R+b-a+1$$
allows at most one periodic copy to affect the window. Certifying those
anchors and the unchanged arena supplies a module at every center, subject
to the move inclusions above. Several nearby defects instead require a
proved covering list of local crops.

**Theorem (cyclic strategy composition).** Fix a recipient and an orientation
of its $q$ columns. Delivery-entry columns form a consecutive block of
length $1\le L<q$. From every eligible state outside this block, suppose
a simulated transfer uses at most $\tau$ messenger moves and ends at a
safe handoff advancing by some step in $\{1,\ldots,d\}$, with
$1\le d\le L$. From every eligible entry state, suppose simulated delivery
uses at most $D$ moves. Modules cover all noncollision pursuer starts,
and transfers preserve messenger eligibility. Then delivery takes at most
$$\tau(q-L)+D$$
messenger moves.

**Proof.** Outside the entry block, use the forward distance to its first
column as potential; it is at most $q-L$. A transfer either decreases it
or enters the block, since a step of size at most $L$ cannot skip the
whole block. Thus at most $q-L$ phases suffice. Each handoff preserves
turn, eligibility and a pursuer position covered by the next module.
Recenter between modules, then deliver. Earlier receipt only shortens
play, and summing the local bounds gives the estimate. $\square$

Unit transfers therefore need at most $q-1$ phases for one entry column
and $q-2$ for two adjacent entries. Progress of one or two likewise
reaches two adjacent entries within $q-2$ phases; it need not reach one
specified column. Eligibility can exclude particular messenger types or
vertices, as in the odd construction.

For optional arrows, restrict the messenger to compulsory moves and give
the local pursuer every optional move: every intermediate graph then
satisfies the simulation inclusions. Omitting an external defect is sound
only if the selected messenger moves remain legal and all actual pursuer
responses remain represented. The following chapters check these
construction-specific facts and retain every finite certificate premise.

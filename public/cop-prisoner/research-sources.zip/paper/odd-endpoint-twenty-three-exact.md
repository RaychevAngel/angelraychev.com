# The exact 23-arc endpoint

The shared deletion and positive-support bounds reduce the twenty-three-arrow
endpoint to the same three finite families as the odd support theorem.

**Theorem 53 (with finite exhaustive checks).**
$$\boxed{M_E(23)=83.}$$
Moreover, $M(n,23)=83$ for every $n\ge12$.

**Proof.** The retained twelve-vertex literal has 83 guaranteed indirect
pairs. For the upper bound, the preceding exact budgets give
$$D_{23}=\max\{M_E(22),M_E(21)+10\}=79.$$
Thus a graph with $I\ge84$ has positive indegree and outdegree after
isolates are removed. Support at most ten has at most 67 missing pairs;
support at least thirteen has at most 76 by (56.4). The retained
eleven-vertex value $M(11,23)=78$ excludes that order.

At support twelve, $q,r\le11$, and a coordinate at most ten gives
$$B_{23}(12,10,11)=81.$$
Consequently $q=r=11$. Degree sums force one degree-one vertex in
each direction and every other corresponding degree two. The two
exceptional vertices are either distinct, with their connecting arrow
absent or present, or coincide. Their eligible missing-pair counts are
respectively 90,89,89. This proves the full finite domain directly;
neither Theorem 57 nor a historical eleven-vertex upper 81 is required
for this endpoint.

We exhaust these families using their two-permutation descriptions.
For the first, add the missing exceptional arc $u\to v$; for the
second add another copy of the existing arc; for the third add a
dummy loop at the common exceptional vertex. The resulting bipartite
incidence multigraph is two-regular and decomposes into two perfect
matchings. This follows directly by alternating the edges of each
even cycle, including a doubled-edge cycle. Regard the matchings as
permutations $P,Q$, placing the added arc in $P$.

Label the exceptional source 0 and, when distinct, the exceptional
recipient 1. Up to relabeling, enumerate the cycle of $P$ containing
the added arc and the unordered cycle lengths of its remaining
vertices. In the common-exception case, $P$ fixes 0. Every other
cycle has length at least two. Then enumerate every admissible
permutation $Q$, allowing only the prescribed doubled exceptional
arc in the second family, and delete the added $P$ arc before any
game calculation. This covers every graph in the three families.

Partial assignments may be discarded when a stationary pursuer
covers the completed outgoing neighbors of a contributing source,
or the completed predecessors of a contributing recipient. A source
obstruction destroys at least eight eligible pairs. A recipient
obstruction destroys at least seven, after omitting a possible source
coinciding with the pursuer. Since there are at most 90 eligible
pairs, all discarded graphs satisfy $I\le83$. Testing coverage with
a partially assigned pursuer neighborhood is also safe: that
neighborhood can only grow.

Every completed graph surviving these obstructions is evaluated by
the exact least reachability fixed point. Evaluation may stop at a
leaf once its remaining possible score falls below 84. The three
finished enumerations give the following counts; none has $I\ge84$.

| Exceptional configuration | Permutation cases | Partial nodes | Completed graphs surviving camping |
|---|---:|---:|---:|
| Distinct, arc absent | 42 | 164,276,910 | 16,902,091 |
| Distinct, arc present | 42 | 13,448,216 | 1,125,588 |
| Common vertex | 14 | 49,814,092 | 3,558,672 |

This excludes every proposed counterexample and proves $I\le83$.
The verified witness gives equality. Adding isolates preserves its
guaranteed indirect pairs, proving the fixed-order assertion for
every $n\ge12$. $\square$

**Reproducibility and proof boundary.** The new source
`src/odd_endpoint_near23_threshold.cpp` is a separately saved,
parameterized copy of the earlier enumerator; it accepts cutoffs at
least 84. The coverage, game calculation, and pruning are unchanged.
The complete receipts are
`research/odd-endpoint-threshold84-absent.json`,
`research/odd-endpoint-threshold84-present.json`, and
`research/odd-endpoint-threshold84-same.json`. Their cutoff, completion
flags, exact counts, source hash, and dependencies are consolidated
in `research/odd-endpoint-threshold84-summary.json`.
The unchanged dependency on the eleven-vertex enumeration is audited
in `research/odd-endpoint-eleven-enumeration-audit.md`.
The source/sink and positive-support argument above supplies the current
all-host reduction. Its arithmetic is checked separately by
`src/sparse_upper_kernel_check.py`. The earlier specialized
23-arc reduction and the unchanged cutoff-84 pruning are recorded in
`research/odd-endpoint-threshold84-ordinary-audit.md`.
A separate software audit of the coverage, pruning, and evaluation is
`research/odd-endpoint-threshold84-independent-audit.md`.
It also compares 37 leaf-game and early-exit cases across all three
families with an explicit alternating-state solver,
including full rank and losing-closure checks; the receipt is
`research/odd-endpoint-threshold84-independent-tests.json`.
The lower-bound certificate is
`research/odd-endpoint-m23-lower-certificate.json.gz`, checked by two
independently implemented game solvers and every saved rank obligation.
The exhaustive upper-bound computation is reviewed at the source and
mathematical level; it is not a separately implemented second
enumeration or a Lean proof.

# Protecting the moves used by the strategy

The distinct-difference condition in Theorem 34 is stronger than the delivery strategy needs. Its branching steps only compare pairs of the three original outgoing moves. Preserving those comparisons permits a much larger set of additional moves.

**Theorem 38.** For every $n\ge25$ and every integer
$$3n\le m\le n\left(\left\lceil\frac n7\right\rceil-1\right),$$
there is an explicit graph attaining
$$M(n,m)=n(n-1)-m.$$
The strategy uses only three outgoing moves per vertex; the remaining arcs may be added individually up to the stated budget.

**Proof.** Choose $h$ using Lemma 12, put $a=(h-1)/2$, and set
$$S=\{1,a,h\},\qquad A_0=\{0,1,a,h\}\subseteq\mathbb Z/n\mathbb Z.$$
The proof of Theorem 11 shows that $A_0$ has distinct nonzero differences. In particular, each of the six ordered differences
$$D=\{u-v:u,v\in S,\ u\ne v\}=\{\pm(a-1),\pm(a+1),\pm2a\}$$
has just its original ordered representation in $A_0$. We only preserve uniqueness for these six differences.

Starting from $A=A_0$, adjoin any residue outside
$$A\cup(A+D),\qquad A+D=\{x+d:x\in A,\ d\in D\}.$$
No new ordered pair involving the adjoined residue has a difference in $D$, because $D=-D$. Thus the six protected differences retain their original unique representations. When $|A|=k$, at most $7k$ residues are excluded. If $k<\lceil n/7\rceil$, then $7k<n$, so the extension remains possible. Choosing the smallest available representative constructs a set of size at least $\lceil n/7\rceil$. For $25\le n\le28$, the initial set already has that size.

Let $B$ be the uniform three-move graph with steps in $S$, and let $H_A$ have all nonzero steps in $A$. Consider any graph
$$B\subseteq G\subseteq H_A.$$
For a source vertex $r$ and distinct core moves $u,v\in S$, no different cop vertex $c$ can have both $r+u$ and $r+v$ in its closed outgoing neighborhood. Indeed, that neighborhood is contained in $c+A$. If both successors belonged to it, their corresponding elements $x,y\in A$ would satisfy $x-y=u-v\in D$. Protected uniqueness forces $(x,y)=(u,v)$ and therefore $c=r$, a contradiction.

Consequently, whenever two successors obtained using core moves are universally winning for a fixed recipient, their source is universally winning: at least one of those successors is inaccessible to the initial cop and survives its response. This argument does not assert that arbitrary pairs of actual outgoing successors have the same property.

The entire proof of Theorem 11 uses exactly these protected pairs. For recipient zero, the direct predecessors $-1,-a,-h$ are winning, and $-a-1$ uses the core moves $1,a$. If
$$Q(z)=\{z,z-1,z-a,z-a-1\}$$
is winning, the four steps establishing $Q(z-h)$ use the move pairs
$$(a,h),\quad(1,h),\quad(a,h),\quad(1,h),$$
respectively, in the order given in Theorem 34. Hence that quartet propagates in $G$. Since $\gcd(h,n)=1$, its successive translates cover every source. Shifting the proof by the recipient covers every target, regardless of whether the added arcs are translation invariant.

Thus every graph between $B$ and $H_A$ is universally winning. The first has $3n$ arcs and the latter has at least $n(\lceil n/7\rceil-1)$. Add the extra arcs in lexicographic order until the prescribed integer budget is reached. All $n(n-1)-m$ missing pairs are guaranteed, meeting the elementary upper bound. $\square$

The improvement from order $n^{4/3}$ to order $n^2$ comes from preserving only the distinctions actually used by the strategy. Other differences may repeat many times. The graph may also have larger closed-neighborhood intersections; the proof protects its particular pairs of core successors instead of imposing a global intersection bound.

For example, at $n=29$ the construction gives core moves $1,3,7$ and the envelope $A=\{0,1,3,7,8\}$. Its protected differences are $\pm2,\pm4,\pm6$, each still uniquely represented. The unprotected difference $-1$ occurs twice, as $0-1=7-8$. Thus this envelope genuinely fails the full distinct-difference condition, yet every intermediate graph with $87\le m\le116$ is universally winning.

**Corollary 39.** There is an absolute $N$ such that, for every $n\ge N$ and every integer
$$3n\le m\le n(n-3),$$
we have
$$M(n,m)=n(n-1)-m.$$
For every sufficiently large multiple of five $n$, the same formula holds at every integer budget $2n\le m\le n(n-3)$.

**Proof.** The upper endpoint in Theorem 38 satisfies
$$n(\lceil n/7\rceil-1)\ge n^2/7-n.$$
Since $\sqrt{n/\log n}\to\infty$, this endpoint eventually exceeds
$\lceil10n^{3/2}\sqrt{\log n}\rceil$, the lower endpoint in Corollary 26. The two integer intervals overlap. Theorem 38 covers the lower one and Corollary 26 covers all remaining budgets through $n(n-3)$, including its dense end via Theorem 20, now a consequence of the direct dense envelopes in Theorems 48 and 58. Taking a common sufficiently large threshold establishes the first statement.

For multiples of five, Theorem 37 supplies every budget from $2n$ through $3n$ once $n\ge80$. Combining the intervals proves the second statement. $\square$

The later Theorems 44 and 59 replace this eventual overlap by a fully
explicit construction for every $n\ge115$, including the sparse range.
Theorem 38 retains its smaller-order domain, arbitrary-subset guarantee,
and protected-difference strategy. The probabilistic overlap in Corollary
39 is included only as a consequence of its underlying constructions.

The generator `src/main_interval_resume.py` checks protected differences at eight orders from 25 through 1000. It checks every protected source-pair/cop triple at the seven listed orders through 200, and verifies 24 selected recipient games with both independent solvers and the explicit rank-certificate checker. Those tests include intermediate graphs lacking translation symmetry. The receipt `research/main-interval-resume-checks.json` records their exact scope; the parameterized proof above is independent of these finite checks.

# Missing-graph criteria and the dense endpoint

The following criterion applies to arbitrary missing graphs. The numerical
constructions are now supplied by the stronger direct Theorem 58.

**Lemma 18 (high-girth complement).** Let $F$ be an orientation of a finite simple undirected graph of girth at least six. Suppose every vertex has outdegree at least two in $F$. Let $G$ contain exactly the nonloop arcs absent from $F$. Then every source–recipient pair in $G$ is guaranteed within two messenger moves.

**Proof.** Diagonal and direct pairs need no argument. For a missing pair $(s,t)$ of $G$, the arc $s\to t$ belongs to $F$. Set
$$
B=N_F^+(s)\cup N_F^-(t).
$$
Both $s$ and $t$ belong to $B$. In the underlying undirected graph, the vertices of $B$ form an induced double star: its centers are $s,t$, the other outneighbors of $s$ are leaves at $s$, and the other predecessors of $t$ are leaves at $t$. The two sets of leaves are disjoint, since an overlap would make a triangle. An additional edge inside $B$ would make a triangle or quadrilateral. Thus the distance between any two vertices in this induced tree is at most three.

Fix an initial pursuer vertex $c\ne s$. If $c\notin B$, two neighbors of $c$ in $B$ would form an undirected cycle of length at most five, so $c$ has at most one outgoing $F$-neighbor in $B$. The same bound holds when $c\in B\setminus\{s\}$: a leaf at $s$ has its only incident edge in the tree directed toward it; a leaf at $t$ has only its edge toward $t$; and all tree edges incident with $t$ point into $t$.

Since $c$ has at least two outgoing $F$-neighbors, choose
$$u\in N_F^+(c)\setminus B.$$
Then $u\ne s,t$, and $s\to u$ and $u\to t$ are arcs of $G$. Also $u\ne c$ and $c\to u$ is absent from $G$. The messenger moves to $u$, survives every pursuer response, and delivers to $t$ on its next turn. $\square$

The lemma only requires a lower bound on outgoing degrees. In particular, edges can later be added to the underlying graph and oriented arbitrarily, provided its girth remains at least six.

**Theorem 19 (the densest noncomplete all-delivery networks).** At
every $n\ge10$,
$$M(n,n(n-3))=2n.$$
An attaining graph guarantees every pair within two messenger moves.

**Proof.** Use the direct two-type missing graph, with its odd-order
subdivision when needed, and the explicit eleven-vertex core, in Theorem 58. It has exactly $2n$ missing
arcs and a two-move guarantee for every pair. The missing-pair upper
bound proves equality. $\square$

The density $n(n-3)$ is maximal for a noncomplete all-delivery graph
by Theorem 14. The earlier high-girth construction at orders $n\ge52$
is no longer needed for this numerical theorem. Lemma 18 remains useful
as a criterion for arbitrary missing graphs; its structural hypothesis
is stronger than the condition needed by the direct construction.

**Theorem 20 (a retained dense parameterization).** Fix integers
$n\ge52$ and $5\le D\le n-1$, and put
$$
B_D=D^4-2D^3+2D^2+1,\qquad
L_D(n)=\left\lfloor\frac{Dn-(D-4)B_D}{2}\right\rfloor.
$$
Every integer $2n\le h\le L_D(n)$ satisfies
$$M(n,n(n-1)-h)=h,$$
with a deterministic two-move attaining construction. An empty interval
makes no assertion.

**Proof.** A nonempty interval forces $n\ge B_D\ge B_5=426$.
For $D\ge5$, the displayed polynomial gives
$B_D-1\ge13D/2$. Hence
$$
L_D(n)\le\frac{Dn}{2}
\le n\left\lceil\frac{n-1}{13}\right\rceil.
$$
The robust bridge of Theorem 58 and the protected envelope of
Theorem 48 cover every missing budget from $2n$ to the latter
endpoint. Their constructions have two-move delivery. $\square$

This parameterization is a consequence of the stronger dense envelope,
retained for references to its explicit $D$-dependent bound. It introduces
no additional graph search, girth-growth certificate, or separate
construction family.

# High-girth complements and exact dense intervals

The preceding periodic construction attains the largest possible density of a noncomplete all-delivery network on an arithmetic progression. A different construction handles every sufficiently large order and an interval of arc counts. Here the sparse graph specifies the connections to omit from an otherwise complete directed network.

**Lemma 18 (high-girth complement).** Let $F$ be an orientation of a finite simple undirected graph of girth at least six. Suppose every vertex has outdegree at least two in $F$. Let $G$ contain exactly the nonloop arcs absent from $F$. Then every source–recipient pair in $G$ is guaranteed within two messenger moves.

**Proof.** Diagonal and direct pairs need no argument. For a missing pair $(s,t)$ of $G$, the arc $s\to t$ belongs to $F$. Set
$$
B=N_F^+(s)\cup N_F^-(t).
$$
Both $s$ and $t$ belong to $B$. In the underlying undirected graph, the vertices of $B$ form an induced double star: its centers are $s,t$, the other outneighbors of $s$ are leaves at $s$, and the other predecessors of $t$ are leaves at $t$. The two sets of leaves are disjoint, since an overlap would make a triangle. An additional edge inside $B$ would make a triangle or quadrilateral. Thus the distance between any two vertices in this induced tree is at most three.

Fix an initial pursuer vertex $c\ne s$. If $c\notin B$, two neighbors of $c$ in $B$ would form an undirected cycle of length at most five, so $c$ has at most one outgoing $F$-neighbor in $B$. The same bound holds when $c\in B\setminus\{s\}$: a leaf at $s$ has its only incident edge in the tree directed toward it; a leaf at $t$ has only its edge toward $t$; and all tree edges incident with $t$ point into $t$.

Since $c$ has at least two outgoing $F$-neighbors, choose
$$u\in N_F^+(c)\setminus B.$$
Then $u\ne s,t$, and $s\to u$ and $u\to t$ are arcs of $G$. Also $u\ne c$ and $c\to u$ is absent from $G$. The messenger moves to $u$, survives every pursuer response, and delivers to $t$ on its next turn. $\square$

The lemma only requires a lower bound on outgoing degrees. In particular, edges can later be added to the underlying graph and oriented arbitrarily, provided its girth remains at least six.

**Theorem 19 (the densest noncomplete all-delivery networks).** For every $n\ge52$,
$$M(n,n(n-3))=2n.$$
An attaining graph guarantees every pair within two messenger moves. The construction for $n\ge130$ has the ordinary proof below; the extension to $52\le n<130$ uses an explicit finite structural certificate.

**Proof.** We first construct a four-regular undirected graph of girth at least six at each required order. Orient an Euler tour in each of its components. Every vertex then has two incoming and two outgoing arcs. Such tours exist by the elementary closed-trail construction: even degrees prevent an unused-edge trail from stopping away from its starting vertex, and further closed trails can be spliced into the first until all edges of the component have been used. Lemma 18 applies to the resulting orientation $F$. It has $2n$ arcs, so its directed complement has $n(n-3)$ arcs and exactly $2n$ missing pairs, all guaranteed. The missing-pair count is also an upper bound for $I$.

For a building block, take point vertices $p\in\mathbb Z/13\mathbb Z$ and line vertices $\ell\in\mathbb Z/13\mathbb Z$, joining them when
$$p-\ell\in\{0,1,3,9\}.$$
This graph has 26 vertices and is four-regular. The twelve ordered differences between distinct members of $\{0,1,3,9\}$ are precisely the twelve nonzero residues modulo 13. Consequently two distinct points cannot have two common line neighbors: the two common neighbors would give two representations of the same nonzero difference. There is no four-cycle. Bipartiteness excludes odd cycles, so the girth is at least six.

The following operation increases the order by one. Choose edges $ab$ and $cd$ such that every endpoint of the second is at distance at least four from every endpoint of the first. Delete these two edges, add a new vertex $x$, and join $x$ to $a,b,c,d$. The endpoints are distinct and all degrees remain four. Any new cycle uses two of these new edges. If their old endpoints belonged to the same removed edge, the path between them after its removal has length at least five, giving a new cycle of length at least seven. Otherwise their old distance was at least four, giving a new cycle of length at least six. Thus the operation preserves the required girth.

Such an edge pair exists in every four-regular graph with more than 120 vertices. Fix an edge $ab$ and let $S$ consist of the vertices within distance three of $a$ or $b$. The branching bound from the two ends of the edge gives
$$|S|\le2(1+3+9+27)=80.$$
The induced graph on $S$ is connected, hence has at least $|S|-1$ edges. If there were no edge with both endpoints outside $S$, four-regularity would give
$$
4|V\setminus S|=e(S,V\setminus S)
=4|S|-2e(S)
\le2|S|+2.
$$
It would follow that
$$n\le\left\lfloor\frac{3|S|+1}{2}\right\rfloor\le120.$$
Therefore an outside edge exists and can serve as $cd$.

Start with five disjoint copies of the 26-vertex building block. Repeated insertion now gives every order $n\ge130$. For the smaller stated orders, two disjoint building blocks give order 52. The supplied certificate lists 78 admissible insertions, producing every order from 52 through 130. Each insertion satisfies the same distance condition and therefore has the proof of correctness just given. Its finite verification is described below. $\square$

The density $n(n-3)$ is maximal among noncomplete all-delivery graphs, by the earlier dense-boundary theorem. This construction therefore settles the joint extremum at that density for every $n\ge52$; it is not a claim about the arc-only maximum at the same number of arcs.

**Finite-certificate reproduction.** The file `research/extremal-bounds-girth-growth.json` records the two removed edges at every insertion, starting from the explicit 52-vertex graph above. The generator and replayer `src/extremal_bounds_girth_family.py` checks the endpoint distances, all degrees, and the absence of short cycles. A separate implementation, `src/extremal_bounds_girth_verify.py`, rebuilds the incidence graph directly and checks girth by enumerating simple paths and testing whether they close into cycles of lengths three, four, or five. It verifies all 79 graph orders independently of the generator's edge-deleted breadth-first checks. The receipt `research/extremal-bounds-girth-verification.json` records the certificate and verifier hashes. These are finite graph certificates attached to the proved insertion rule, not extrapolation from successful pursuit-game searches. They are executable checks rather than a Lean formalization; omitting this finite certificate leaves the ordinary theorem for every $n\ge130$.

**Theorem 20 (an interval of exact dense extrema).** Fix integers $n\ge52$ and $5\le D\le n-1$, and put
$$
\begin{aligned}
B_D&=1+D\bigl(1+(D-1)+(D-1)^2+(D-1)^3\bigr)\\
   &=D^4-2D^3+2D^2+1,\\
L_D(n)&=\left\lfloor\frac{Dn-(D-4)B_D}{2}\right\rfloor.
\end{aligned}
$$
For every integer $h$ satisfying $2n\le h\le L_D(n)$,
$$M(n,n(n-1)-h)=h.$$
Each equality is attained by an all-delivery graph with a two-move strategy. An empty interval makes no assertion.

**Proof.** Begin with the four-regular girth-six graph from Theorem 19. Repeatedly add an undirected edge between two vertices of current degree less than $D$ whose distance is at least five. Vertices in different components have infinite distance. Each addition preserves simplicity, the degree cap $D$, and girth at least six.

When no further addition is possible, let $U$ be the vertices of degree less than $D$. If $U$ is nonempty, all its vertices lie within distance four of any fixed member of $U$. A graph of maximum degree $D$ has at most $B_D$ vertices in such a ball, so $|U|\le B_D$. This inequality also holds when $U$ is empty. The minimum degree remains at least four. The final edge count is consequently at least
$$
\frac{D(n-|U|)+4|U|}{2}
\ge\frac{Dn-(D-4)B_D}{2}.
$$
Starting from $2n$ edges and adding one edge at a time produces a graph with every edge count through $L_D(n)$.

Orient the initial four-regular graph by Euler tours, and orient each added edge arbitrarily. Each vertex retains its original two outgoing arcs. Applying Lemma 18 at the stage with $h$ edges gives a directed complement with $n(n-1)-h$ arcs and all its $h$ missing pairs guaranteed. No graph with that arc count can have more than $h$ indirect pairs. $\square$

The statement has both order and density as parameters. For example, $B_D\le D^4$ for $D\ge2$. When $n\ge2D^4$, the displayed bound gives
$$L_D(n)\ge n(D/4+1)-1.$$
Thus choosing $D=\lfloor(n/2)^{1/4}\rfloor$ for sufficiently large $n$ yields exact joint extrema for an interval of missing-arc counts extending to a positive constant times $n^{5/4}$. As with Theorem 19, the range $n\ge130$ has an ordinary construction, while the extension down to 52 uses the explicit finite certificate.

# Complete values and explicit constructions {#the-remaining-classification-domain}

Every admissible pair $n\ge1$, $0\le m\le n(n-1)$ is determined, with an
explicit attaining graph. Corollary 47 gives the full formula for $n\ge12$;
the complete finite tables cover $1\le n\le11$. No numerical or
explicit-construction gap remains within the stated objective.

The numerical and construction obligations were checked separately. The
independent closure in `research/finish-ledger-review.json` preserves every
previous exact value and closes all 101 former representatives. All 493,924
admissible cells in the retained audit box through order 114 have matching
bounds. This finite check is supplemented by the ordinary parameterized
construction proofs and host reductions; it is not used to infer an infinite
theorem merely from finite success.

For budgets $m=12,13,\ldots,21$, the least attaining host orders are
$$7,8,8,8,8,10,9,11,10,12.$$
Adding isolates gives every larger host at each corresponding budget. The
remaining smaller-host values are explicitly tabulated. Above those budgets,
the established sparse, main, dense, and zero constructions cover the infinite
ranges. The exact 23-arrow value 83 first fits at order 12.

The separate construction audit finds a concrete adjacency rule, prescribed
composition, or certified listed graph for every value. It needs no generic
graph search or orientation derandomization to instantiate an attainer. Fixed
stages retain every-optional-subset guarantees inside their own envelopes;
other constructions retain their separately proved delivery bounds. Those
stronger properties are not inferred for unrelated graphs of the same score.

Finite upper proofs combine ordinary degree and source/sink arguments with
complete residual graph enumerations. Their reviews distinguish full
independent game replay from a second full graph enumeration and from sampled
pruning tests. The exact dependencies are in the evidence guide and approved
registry. The new concrete classification is not fully instantiated in Lean.

Delivery-time optimization, classification of all maximizing graphs, and a
structural characterization of all guaranteed pairs remain outside this paper's
scope. Further simplification and fuller formalization do not represent unknown
values or absent explicit attainers.

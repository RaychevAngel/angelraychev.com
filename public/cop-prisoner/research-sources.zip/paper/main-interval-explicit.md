# Explicit attainment at every budget in a sparse interval

The circulant construction gives an exact joint extremum, not only a lower bound on the vertex maximum: for every $n\ge25$, Theorem 11 and Lemma 12 already show that $M(n,3n)=n(n-4)$. The next result fills consecutive budgets above $3n$. Its proof controls the extra pursuer moves; arbitrary additions of arcs would not justify that conclusion.

**Theorem 34.** For every $n\ge25$,
$$M(n,3n)=n(n-4).$$
Moreover, if $d\ge4$ and
$$n>d^3+2d,$$
then at every integer budget $3n\le m\le dn$ there is an explicit graph attaining
$$M(n,m)=n(n-1)-m.$$
In particular, this holds throughout $3n\le m\le4n$ for every $n\ge73$. More generally the explicit interval reaches arc counts of order $n^{4/3}$.

**Proof.** Say that a set $A\subseteq\mathbb Z/n\mathbb Z$ has distinct nonzero differences when
$$a-b=a'-b'\ne0,\qquad a,b,a',b'\in A,$$
implies $(a,b)=(a',b')$. For such a set, two distinct translates $x+A$ and $y+A$ intersect in at most one point: two intersections would give two representations of the nonzero difference $y-x$.

Choose $h$ as in Lemma 12 and put $a=(h-1)/2$. The set
$$A_0=\{0,1,a,h\}$$
has distinct nonzero differences by the proof of Theorem 11. The base graph $B$ has steps $1,a,h$. For any larger set $A$ with distinct nonzero differences, let $H_A$ have the nonzero steps in $A$; we will keep $0\in A$ throughout. Every graph $G$ satisfying
$$B\subseteq G\subseteq H_A$$
has distinct closed move sets intersecting in at most one vertex, because $C_G(x)\subseteq x+A$.

The proof of Theorem 11 therefore works inside every such $G$. To make this preservation explicit, fix the recipient zero. Its direct predecessors $-1,-a,-h$ and zero are guaranteed, and $-a-1$ is guaranteed using the two successors $-a,-1$. If
$$Q(z)=\{z,z-1,z-a,z-a-1\}$$
is guaranteed, the following four applications of Lemma 10 establish $Q(z-h)$:

| New source | Two guaranteed successors |
|:--|:--|
| $z-h$ | $z-a-1,\ z$ |
| $z-h-1$ | $z-h,\ z-1$ |
| $z-h-a$ | $z-h,\ z-a$ |
| $z-h-a-1$ | $z-h-a,\ z-a-1$ |

All displayed moves belong to $B$. Coprimality of $h$ and $n$ makes finitely many repetitions cover all sources. The same argument with all coordinates shifted applies to every recipient, even when $G$ itself is not translation invariant. Thus every intermediate graph is universally winning.

It remains to enlarge $A_0$. Suppose $|A|=k$ and its nonzero differences are distinct. To adjoin $x$, exclude the following residues:

1. The $k$ members of $A$ itself.
2. Residues $x=a+b-c$ with $a,b,c\in A$ and $b\ne c$. These exclude every equality between an old nonzero difference and either sign of a new difference. There are at most $k^2(k-1)$ such residues.
3. Solutions of $2x=a+b$ with $a,b\in A$. These exclude an equality $x-a=b-x$ between the two signs of new differences. There are $k(k+1)/2$ unordered pairs with repetition, and each congruence has at most two solutions, hence at most $k(k+1)$ excluded residues.

Within each sign the new differences are already distinct. The three exclusions are therefore sufficient, and together rule out at most
$$k+k^2(k-1)+k(k+1)=k^3+2k$$
residues. Whenever $n>k^3+2k$, at least one admissible residue remains; choose the smallest representative. Under the theorem's hypothesis this process continues from size four to size $d+1$.

The resulting $H_A$ has $dn$ arcs and contains the $3n$ arcs of $B$. For a prescribed integer $m$ in the interval, add exactly $m-3n$ of the remaining arcs in lexicographic order. The intermediate graph is universally winning by the preservation argument, so all $n(n-1)-m$ missing pairs are guaranteed. This matches the elementary upper bound.

For $d=4$ the hypothesis is $n>72$. Taking the largest admissible $d$ gives $d$ of order $n^{1/3}$, and therefore an upper interval endpoint of order $n^{4/3}$. The endpoint $m=3n$ only needs the original $n\ge25$ construction, with no extension. $\square$

This is a deterministic construction at each stated integer budget. The underlying delivery argument may require many moves; it is not a two-move theorem. Its ordinary proof is independent of the finite tests in `src/sidon_main_interval.py`, and no new Lean coverage is asserted. It proves a consecutive part of Raychev's full-density attainment conjecture while leaving the general interval from $2n$ to $3n$, and a gap before the probabilistic range, unresolved.

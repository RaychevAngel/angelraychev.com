# A common upper-bound argument for sparse graphs

The same source/sink deletion and positive-degree count prove the sharp
arc bounds, their equality shapes, and the quantitative support reductions.
All graphs are simple and loopless; opposite arrows are allowed. An induced
subgraph retains every arrow between its vertices.

Put $A=\{d^+\ge2\}$, $B=\{d^-\ge2\}$, $q=|A|$, $r=|B|$,
$b=|A\cap B|$, and $e=e(A,B)$. Camping excludes every counted pair
outside $A\times B$. Direct and diagonal pairs are disjoint, so
$$I(G)\le qr-b-e,\qquad e\ge\max(0,2q+2r-m). \tag{56.1}$$

## Deletion and positive support

**Lemma (source/sink and positive-support bounds).** Write $A_m=M_E(m)$.
An actual source of outgoing degree $d>0$, or an actual sink of incoming
degree $d>0$, satisfies
$$
I(G)\le
\begin{cases}
A_{m-1},&d=1,\\
A_{m-d}+\lfloor(m-d)/2\rfloor,&d\ge2.
\end{cases} \tag{56.2}
$$
On a fixed support of order $N$, the added term may also be replaced by
$N-1-d$. Consequently every graph with a nonisolated source or sink obeys
$$I(G)\le D_m:=\max\{A_{m-1},A_{m-2}+\lfloor(m-2)/2\rfloor\}. \tag{56.3}$$
If every indegree and outdegree is positive, then
$$
q,r\le\min(N,\lfloor m/2\rfloor,m-N),\qquad
I(G)\le B_m(N,q,r):=qr-(q+r-N)_+-(m-2N+q+r)_+.
\tag{56.4}
$$
Here $x_+=\max(0,x)$.

**Proof.** An old-source messenger cannot enter a deleted source. A messenger
delivering to an old recipient cannot enter a deleted sink and subsequently
leave it. Restrict the cop to the remaining graph: every counted pair with
both endpoints surviving therefore remains a guarantee there. Only the
deleted source row or sink column can add pairs.

Every live recipient column needs two predecessors of positive indegree.
An indegree-zero predecessor cannot be reached after the initial position,
and starting there would make the pair direct. If there is only one usable
predecessor, a cop may camp there. Separately, every live source row needs
two nonsink successors: a cop camps at a sole nonsink successor, while
every alternative departure traps the messenger at a sink. Thus the deleted
source's arrows supply none of the first capacity, and the deleted sink's
arrows supply none of the second. At most $\lfloor(m-d)/2\rfloor$ columns
or rows can contribute. For $d=1$ the deleted row or column is empty;
$N-1-d$ simply counts its nonadjacent distinct pairs.

Adding a fresh sink with one incoming arrow preserves $I$. An old winning
strategy works while the cop stays in the old graph; if the cop enters or
starts at the sink, it is trapped and any old route to the recipient suffices.
Old losing pairs retain a cop strategy confined to the old graph, and the
new sink contributes no indirect row or column. Hence $A_m$ is nondecreasing,
which gives (56.3). This is a budget comparison, not arbitrary arrow deletion.

For positive degrees, the vertices outside each active set have the
corresponding degree one. This gives $q,r\le m-N$ and
$$e(A,B)=m-2N+q+r+w,$$
where $w\ge0$ counts arrows from $A$'s complement to $B$'s complement.
Subtract this lower bound and $b\ge(q+r-N)_+$ from the eligible rectangle.
The two deletion arguments used the original arrow directions throughout;
no graph-reversal assumption is needed. $\square$

**Arithmetic lemma.** In positive support the following bounds hold:
$$
\begin{array}{c|c|c}
m&\text{support}&\text{bound on }I\\ \hline
2k,\ k\ge5&N=k,\ (q,r)\ne(k,k)&k^2-4k+2\\
2k,\ k\ge5&N\ge k+1&k^2-5k+8\\
2k+1,\ k\ge5&N=k+1,\ (q,r)\ne(k,k)&k^2-4k+4\\
2k+1,\ k\ge4&N\ge k+2&k^2-5k+10
\end{array} \tag{56.5}
$$
For the odd support reduction, the first odd bound remains valid at
$k=3,4$, and at $N=k$ a coordinate below $k$ gives $k^2-4k+1$.
For $k=3$, positive support $N\ge5$ at seven arrows has $I\le3$.

**Proof.** In (56.4), increasing either coordinate when the other is at least
two cannot decrease the expression: its product increases by at least two,
while the two positive-part subtractions increase by at most two. At the
fixed supports, substitute the largest permitted coordinates. Coordinates
zero or one give $I\le\min(q,r)\max(q,r)$ and are bounded separately.
For $k=3,4$, infeasible small coordinates can be discarded using
$m\le N+q(N-2)$ and its incoming counterpart. At $k=3$, $N=3$ is impossible and
the nonmaximal-coordinate bound at $N=4$ is one. At $k=4$, the
corresponding bounds at $N=4,5$ are one and four. These are the only
small fixed-support cases outside the uniform substitution.

For the large-support cases put $p=m-N$. Then $q,r\le p$ and
$$B_m(N,p,p)=f_m(p):=p^2-(3p-m)_+-(4p-m)_+.$$
If both coordinates are at least two, their maximum is bounded by $f_m(p)$;
otherwise $I\le p$. Moreover
$f_m(p+1)-f_m(p)\ge2p-6$, so $f_m$ is nondecreasing for $p\ge3$.
The values at $p=0,1,2,3$ are immediate. Since $p\le k-1$ in both
large-support cases, substitution at $p=k-1$ gives (56.5); its value
also dominates $p$ in the stated domains. At $k=3,m=7$, the possibilities
$p\le2$ give the separate bound three. $\square$

## Ordinary induction for the parity bounds

**Proposition (sparse parity bounds and equality).** For every $k\ge5$,
$$A_{2k}\le k(k-3),\qquad A_{2k+1}\le k(k-3)+2. \tag{56.6}$$
Even equality forces a two-in/two-out-regular nonisolated support of order
$k$, with every missing pair guaranteed. Odd equality forces support
$k+1$, with distinct vertices $u,v$ of respective degree pairs
$(d^+,d^-)=(1,2),(2,1)$, every other degree two, $u\to v$ absent,
and every eligible missing pair guaranteed. These conditions also suffice.

**Proof.** The elementary ordinary results through six arrows give
$A_5=1,A_6=2$. Applying (56.3)--(56.4) successively gives
$$
\begin{array}{c|rrrrr}
m&7&8&9&10&11\\\hline
D_m\text{ using preceding bounds}&3&5&6&9&10\\
\max B_m\text{ on positive support}&3&4&6&10&12\\
A_m\text{ upper bound}&3&5&6&10&12 .
\end{array}
$$
These small integer maxima require only $2\le N\le m$, $m\le N(N-1)$,
and (56.4); they enumerate no graphs. Thus the seeds at ten and eleven
arrows are ordinary and do not use their sharper finite values.

Induct in the arrow budget. At $m=2k$, (56.3) gives
$D_{2k}\le(k-1)(k-3)<k(k-3)$. Positive support $N<k$ has fewer
than $k(k-3)$ missing pairs; $N\ge k+1$ is bounded by (56.5).
At $N=k$, the missing-pair bound is $k(k-3)$, and a coordinate below
$k$ gives the smaller first bound in (56.5). Hence equality requires
$q=r=k$, which forces every degree two, and all its missing pairs to win.

At $m=2k+1$, the deletion bound is at most
$$\max\{k(k-3),k^2-4k+5\}=k(k-3).$$
Positive $N\le k$ has at most $k(k-3)-1$ missing pairs, and $N\ge k+2$
is bounded by (56.5). At $N=k+1$, a coordinate below $k$ again gives
a strict bound. For $q=r=k$, the degree sums force exactly one
degree-one vertex on each side. If these coincide, $b=k$; otherwise
$b=k-1$. Since $e=2k-1+w$, the eligible count is
$k(k-3)+1-w$ in the first case and $k(k-3)+2-w$ in the second.
Here $w$ is precisely the possible arrow from the low-outdegree vertex
to the low-indegree vertex. This proves the bound and equality statement.
The seed cases $k=5$ have the same strict support and deletion comparisons.
$\square$

## A gap before another even support shape can compete

**Theorem 56 (even sparse stability).** Let $k\ge6$ and let $G$ have
exactly $2k$ arcs. At least one of the following holds:

1. Deleting isolated vertices leaves a graph on exactly $k$ vertices,
   with indegree and outdegree two at every vertex.
2. $I(G)\le(k-1)(k-3)$.

**Proof.** Put $C=(k-1)(k-3)$. The parity induction and (56.3) bound
every source/sink graph by $C$. In positive support, $N<k$ has at most
$(k-1)(k-2)-2k<C$ missing pairs. At $N=k$, every nonregular shape has
$I\le k^2-4k+2<C$; at $N\ge k+1$, (56.5) gives
$k^2-5k+8\le C$. Only the stated regular support remains. $\square$

Thus $I>k(k-3)-(k-3)$ forces that shape; it does not itself assert
universal delivery. The same dichotomy holds at $k=5$ using the finite
value $A_{10}=6\le8$. It fails at $k=4$: the six-vertex, eight-arrow
witness has $I=4>3$. The theorem for $k\ge6$ is entirely ordinary.

**Corollary 56.1.** For $k\ge6$,
$$A_{2k}\le\max\{M(k,2k),(k-1)(k-3)\}.$$
For example the retained finite core bounds give
$A_{12}\le15$, $A_{14}\le24$, $A_{16}\le35$, and $A_{22}\le81$.
These weaker consequences are superseded numerically by the finite-budget
classification, but retain their separate support interpretation.

## Three odd exception families and an induced core

**Theorem 57 (odd sparse support reduction).** Let $k\ge3$, let $G$
have $2k+1$ arcs, and suppose $I(G)>k^2-4k+6$. Then at least one holds:

1. $G$ has an induced $k$-vertex subgraph $H$ with $I(H)\ge I(G)$.
   Either $H$ is two-in/two-out regular with $2k$ arcs, or it has
   $2k+1$ arcs, one outgoing degree three and one incoming degree three,
   and all other corresponding degrees two. The exceptional vertices
   may coincide.
2. Removing isolates leaves $k+1$ vertices, with distinct vertices $u,v$
   of degree pairs $(1,2),(2,1)$ and all other degrees two. The two
   possibilities $u\to v$ absent or present are separate families.
3. Removing isolates leaves $k+1$ vertices, with one vertex of indegree
   and outdegree one and all other degrees two.

**Proof.** Put $T=k^2-4k+6$. A source/sink of other degree at least two
gives $I\le A_{2k-1}+k-1\le k^2-4k+5<T$ for $k\ge5$.
At $k=4,3$ the ordinary seeds give respectively $A_7+3\le6=T$ and
$A_5+2=3=T$. Thus only other degree one is possible. Delete such a
vertex. Its row or column contributes zero, so the remaining graph has
$2k$ arcs and score at least $I(G)>T$. For $k\ge6$, Theorem 56 applies
because $T=(k-1)(k-3)+3$: deleting its isolates leaves a regular
$k$-vertex induced core with at least the original score. It remains
induced in $G$, proving case 1. For $k=3,4,5$, degree-one deletion is
impossible since $A_6\le2$, $A_8\le5$, $A_{10}\le10$, respectively,
are below $T$.

Otherwise all degrees are positive. The missing-pair count excludes
$N<k$, and (56.5) excludes $N\ge k+2$ (including its seven-arrow case).
At $N=k$, a coordinate below $k$ gives $k^2-4k+1<T$, so $q=r=k$
and the one-excess degree pattern in case 1 follows. At $N=k+1$, a
coordinate below $k$ gives $k^2-4k+4<T$. Thus $q=r=k$, and the
degree-one vertices either differ or coincide, giving cases 2 and 3.
These exhaust the graph itself, without reversing arrows or contracting
routing vertices. $\square$

For $k=0,1,2$, the elementary values $A_1=A_3=0,A_5=1$ make the
conditional statement vacuous.

**Corollary 57.1 (odd bound and equality shape).** For $k\ge5$,
$A_{2k+1}\le k(k-3)+2$, with equality exactly in the absent-arrow
distinct-exception family when every eligible missing pair is guaranteed.

**Proof.** This is the already proved parity proposition. Equivalently,
the families in Theorem 57 have respectively at most
$k(k-3)$, $k(k-3)-1$, $k(k-3)+2$, $k(k-3)+1$, and
$k(k-3)+1$ eligible missing pairs. Only the absent-arrow family can
attain the bound. $\square$

The arithmetic checker and its separate audit record verify the finite
substitutions and inequality instances used here. They supplement these
ordinary proofs; they neither enumerate graphs nor supply a new Lean proof.

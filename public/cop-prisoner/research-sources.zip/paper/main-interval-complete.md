# The complete main interval from order twelve

**Theorem (main interval).** For every integer $n\ge12$ and every
$2n\le m\le n(n-3)$,
$$M(n,m)=n(n-1)-m.$$
There is an explicit attaining graph at every pair. Its construction uses
arithmetic families and fixed finite arrow lists; it performs no game search
or derandomization. Finite lists cover a bounded bridge; the circle and
separated-pair constructions cover all budgets above $3n$ from order 79.
The finite-values section treats smaller orders and the other budget ranges.

## Stages with changing compulsory arrows

Let $B\subseteq E$ be two graphs on the same vertices. For each recipient $t$
suppose that every nonterminal, noncollision position $(s,c)$ has a legal
compulsory messenger move $u$, and either $u=t$, or $u\ne c$ and every
legal cop reply $c'$ in $E$ satisfies
$$u\ne c',\qquad 0\le R_t(u,c')<R_t(s,c).$$
Here $R_t$ is a nonnegative integer rank on the noncollision positions.
Receipt takes precedence over collision at $t$, as throughout this paper.
Induction on this rank proves delivery in every graph $B\subseteq G\subseteq E$.
The messenger uses only $B$, while the cop is allowed all of $E$.

One may now replace $B$ between successive budget intervals. In particular,
if $G_0\subseteq\cdots\subseteq G_q$ and each $G_i/G_{i+1}$ pair has such a
certificate, every budget from $|E(G_0)|$ through $|E(G_q)|$ is supplied.
Earlier additions are available to the messenger in subsequent stages.
No strategy is required to survive all final cop arrows using only the
original sparse base. Every optional subset within each certified stage
works; no arbitrary-subset assertion across different stages is inferred.

The same observation works when discovering graphs by deleting arrows from
a dense example. Read the resulting list backwards. Discovery direction is
irrelevant to the proof: every saved certificate is for a literal lower
base and upper envelope, with all intervening budgets obtained by prefixes.

## Finite bridge and explicit recipe

The construction data in `research/sparse-staged-records.json` specify a
base arrow list, an ordered list of additional arrows, and certified prefix
intervals. At budget $m$, take exactly the first $m-|E(B_0)|$ arrows in that
list. A stored stage containing $m$ supplies the delivery proof. The selected
base need not be the same graph as a previously known construction at an
overlapping endpoint; each interval has its own complete certificate.

The finite certificates check both positions, waits, receipt before collision,
and strict descent after every legal cop reply. Only their stated intervals
are used: a stored arrow list can extend beyond its certified stages, and
those extra prefixes are not inferred to work. Combine these domains.

1. For $12\le n\le78$, use the finite stages, protected and five/six-offset
   circles, layered and reduced hub interfaces, and separated pair codes.
   The existing literal dense envelopes at orders 13 and 14 supply the
   remaining budgets $129$ and $147,148,149,151$, respectively. The independent
   integer-interval check covers this entire finite range. No general
   larger-code capacity theorem or dense connector is needed by this cover.
2. For $79\le n\le114$, the pair-code overlap theorem covers every budget
   from $3n$. The retained sparse stages and certified sparse envelopes
   cover $2n$ through $3n$, including the repaired order-109 envelope.
3. For $n\ge115$, Theorem 52 covers $2n$ through $3n$, and the pair-code
   overlap theorem covers the remainder through $n(n-3)$.

`src/main_interval_complete.py` selects these intervals and constructs their
adjacency. `src/main_interval_pair_codes_check.py` independently reconstructs
the finite interval union from formulas and saved stage endpoints, and checks
actual constructor outputs. The current source-pinned receipts are
`research/main-interval-pair-code-checks.json` and
`research/main-interval-pair-complete-checks.json`. Earlier constructors,
certificate files, stronger guarantees, and historical receipts remain intact.

Since every resulting missing nonloop pair is guaranteed, each graph has
$I(G)=n(n-1)-m$, matching the elementary missing-pair upper bound. This proves
the theorem. The finite bridge is computer-assisted; the circle and pair-code
overlap have ordinary proofs. The sparse infinite family retains its stated
finite local certificate ingredient.

## Formal verification and possible simplifications

`lean/StagedEnvelopes.lean` proves the generic asymmetric rank-envelope
implication for every intermediate graph and actual play against arbitrary
legal history-dependent cop policies. It does not instantiate the large
finite lists, their computed ranks, the periodic parameter rules, or the
complete classification in Lean. Those parts retain the ordinary and
independently replayed computer-assisted proof boundaries just described.

A single repeatable small attachment rule remains a possible simplification,
not a missing step in this finite-bridge theorem. Two fixed attachments
transported whole budget families from order 25 to 26 and 26 to 27. Reusing only
the newest vertex's ports subsequently creates a recipient whose predecessors
one cop can cover. That obstruction rules out the proposed repeated tip
attachment; it does not obstruct the explicit constructions above. The
private extension research is retained separately from the main theorem.

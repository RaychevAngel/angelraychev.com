# A packed sparse construction with optional arcs

Deleting a short, specified cluster of vertices from the six-type family
allows an explicit sparse construction at every order at least 115. Near
each deletion, only seven optional arrows must be suppressed. The local
strategies allow both of two adjacent columns as entries for final delivery.

**Theorem 52 (with finite local certificates).** Let $n\ge115$, put
$k=\lceil n/6\rceil$ and $r=6k-n\in\{0,\ldots,5\}$. For every integer
$$2n\le m\le20k-11r,$$
there is an explicit universally winning digraph with $n$ vertices and $m$
arcs. Consequently
$$M(n,m)=n(n-1)-m.$$
The construction has $2n$ compulsory arcs and exactly $8k-9r$ optional arcs;
**every subset** of the optional arcs works. Its range includes every
$2n\le m\le3n$, and every delivery takes at most
$$9\lceil n/6\rceil+21$$
messenger moves.

**Proof.** We specify the graph, prove the exact arc count, describe the
finite strategy certificates and their complete scope, and lift those
strategies to every order in the theorem.

### The base graph and the seven exclusions

Begin with the six-type graph on
$(\mathbb Z/k\mathbb Z)\times\{0,\ldots,5\}$. Write $j_i$ for $(i,j)$.
The first permutation is the Hamilton cycle
$$0_i\to1_i\to2_i\to3_i\to4_i\to5_i\to0_{i+1},$$
and the second permutation has arrows
$$0_i\to5_i,\quad1_i\to4_{i+1},\quad2_i\to1_{i+1},\quad
3_i\to0_{i-1},\quad4_i\to2_{i+1},\quad5_i\to3_{i-1}.$$
Delete $4_h$ in the canonical columns
$$S=\{0,3,\ldots,3(r-1)\},$$
with $S=\varnothing$ when $r=0$. Reconnect each permutation through each
deleted vertex. The changed arrows are
$$3_h\to5_h,\qquad1_{h-1}\to2_{h+1}.$$
There are exactly $n=6k-r$ vertices and $2n$ base arcs. Both indegree and
outdegree remain two. The displayed formulas, $k\ge20$, and the gaps of at
least three between deleted columns show that the two outgoing arrows at
each surviving vertex are distinct and nonloop. In particular the smoothed
type 1 arrow has head of type 2 two columns ahead, distinct from its type 2
head in the same column.

The available optional arrow types $(i,j)\to(i+d,t)$ are
$$
(j,d,t)\in\{(1,-3,5),(3,-3,5),(4,-3,0),(4,3,1),
(2,3,0),(3,3,0),(3,-3,0),(5,-2,0)\}.
$$
Omit arrows whose source was deleted. In addition, for each $h\in S$,
omit precisely the following seven arrows, where a quadruple
$(\delta,j,d,t)$ denotes $(h+\delta,j)\to(h+\delta+d,t)$:
$$
\begin{split}
\mathcal B=\{&(0,1,-3,5),(0,3,-3,5),\\
             &(1,1,-3,5),(1,3,-3,5),(1,3,3,0),\\
             &(2,3,-3,5),(2,4,-3,0)\}.
\end{split}
$$
All column indices in this definition are modulo $k$. These optional arcs
are distinct nonloop arcs outside the base graph, and their target types
are 0, 1, or 5, so their targets always survive.

Originally there are $8k$ optional arrows. Each deletion removes the two
arrows with its absent type 4 source and the seven further arrows in
$\mathcal B$. None of the seven has the deleted source. The source-column
sets $\{h,h+1,h+2\}$ for different holes are disjoint, including across the
cyclic gap, so these losses do not overlap. Thus the optional count is
exactly $8k-9r$. Moreover
$$8k-9r-n=2k-8r\ge0$$
because $k\ge20$ and $r\le5$. The full envelope has
$$2n+(8k-9r)=20k-11r$$
arcs and contains every budget through $3n$.

### The finite local strategy statements

Unwrap a window around a prospective destination column, now called zero.
Retain messenger columns $[-5,5]$ and cop columns $[-8,8]$. Messenger exits
are disallowed. A cop exit enters an outside state $\Omega$; from $\Omega$
the cop may wait or reenter any existing vertex in columns
$-8,-7,-6,6,7,8$.

For a local deletion crop $H\subseteq[-8,8]$, construct the smoothed base
arrows literally. The messenger uses only these base arrows, together
with waiting. The cop receives all surviving optional arrows, except the
seven relative exclusions for each hole in $H$, as well as its base
arrows and waiting. The finite certificates prove the following statements
for every crop that can arise from the canonical construction:

* From every existing vertex in column $-1$, the messenger can reach
  column zero within nine messenger moves and hand off a messenger-turn
  state in which it is distinct from the cop.
* From every existing vertex in column $-3$, the messenger can deliver to
  any specified existing vertex in column zero within 39 messenger moves.
* From every existing vertex in column $-2$, the corresponding delivery
  bound is 38 messenger moves.

Each assertion quantifies over every cop position other than the source,
including $\Omega$. Receipt is terminal before capture; safe transfer
instead requires surviving the cop reply before the handoff.

Here the finite evidence consists of complete ranks and messenger policies,
not just successful simulations. There are 101 crops and 696 objectives:
101 safe-transfer objectives and 595 specified-target delivery objectives.
Every delivery objective checks both entry columns. Ranks use the round
convention of local simulation: the selected messenger move decreases
rank, every cop reply is safe and nonincreasing, and zero messenger ranks
have the required terminal condition. These checked obligations prove the
stated local bounds.

### Why those crops cover every $k\ge20$

Enumerate $k=20,\ldots,29$, $r=0,\ldots,5$, and every choice of center.
Cropping the canonical hole sets to $[-8,8]$ gives exactly 101 distinct
sets. For any $k\ge29$, the gap from the last hole back to the first is
at least
$$k-3(r-1)\ge k-12\ge17.$$
A 17-column crop has span 16, so it cannot contain holes from both sides
of this gap. Its holes form a contiguous portion of one arithmetic
progression of step three, containing at most five terms. Every such
cropped progression already occurs in the $k=29$ enumeration, by taking
the appropriate number of holes and translating the center. No new
local pattern can therefore occur at larger $k$.

This is a statement about the specified canonical cluster. It does not
assert that arbitrary deletion sets with minimum spacing three admit
these local strategies.

### Projection of every actual cop move

Smoothed base arrows have column jumps at most two and optional arrows
at most three. Thus the window-projection lemma applies with $M=5$,
$R=8$, $J=3$ and $k\ge20$. The preceding crop-coverage argument supplies
a certified arena at every center. Its remaining move inclusions require
the following check on omitted holes.

Omitting holes outside the crop is conservative. A hole immediately to
the right may change a represented boundary arrow from an outside head
to another outside head; both project to $\Omega$. No other omitted
hole changes a represented-to-represented base arrow. An omitted hole
to the left can suppress optional arrows through its relative exclusions;
the cropped arena instead permits these extra cop moves. Messenger moves
inside $[-5,5]$ are modeled literally. Consequently the projection neither
grants the messenger an illegal move nor removes an actual cop response,
and it preserves collisions and both terminal conditions.

The certificates grant the cop every permitted optional arrow at once,
while the messenger uses only compulsory arrows. They therefore remain
valid after selecting any subset of the optional arrows.

### Global delivery and the time bound

For a recipient in column $t$, the delivery entries $t-3,t-2$ form a
consecutive block of length two. Every existing source type is covered,
and safe transfer advances one column. Cyclic strategy composition with
$L=2$, $d=1$, $\tau=9$ and $D=39$ bounds the total messenger moves by
$$9(k-2)+39=9k+21.$$
Hence every missing ordered pair is guaranteed. The universal missing-pair
upper bound gives $M(n,m)=n(n-1)-m$, as claimed. $\square$

**Certificate boundary and reproducibility.** The complete finite ranks
and policies are saved in
`research/dense-phase2-sparse-two-entry-certificates.json.gz`.
The checker `src/dense_phase2_sparse_two_entries.py --check` reconstructs
every arena, checks exact coverage of the 101 crops and 696 objectives,
and directly verifies every supplied rank, policy, and required entry
state. The reconstruction spells out all six smoothed source-type maps;
the independent generator uses explicit messenger-turn and cop-turn
states with an AND/OR priority queue, rather than the earlier
collapsed-round solver. The summary is
`research/dense-phase2-sparse-two-entry-check.json`. Literal global graph
and exact optional-count checks are recorded in
`research/dense-phase2-sparse-global-map.json`.

The smaller messenger window $[-4,4]$ does not establish all the new
column $-3$ entry statements. Enlarging it to $[-5,5]$ is part of this
proof, and the failed smaller-window checks are retained in the research
log. The earlier broad exclusion buffers and their projection proofs
remain research history; they are unnecessary for the theorem above.
Negative certificate ranks make no assertion of global impossibility or
optimal delivery time. The graph construction, crop coverage, projection,
and global composition are ordinary proofs using finite rank certificates;
this theorem is not presently formalized in Lean.


## Finite cyclic supplement below order 115

The same adjacency recipe gives a further computer-assisted exact interval at
orders
$$
\mathcal S=\{60\}\cup[64,66]\cup[68,72]\cup[75,78]
\cup[80,90]\cup[92,114],
$$
where the brackets here denote all integers in the displayed range. For every
$n\in\mathcal S$, put $k=\lceil n/6\rceil$ and $r=6k-n$. Every budget
$$2n\le m\le20k-11r$$
has the explicit graph above, and every subset of its $8k-9r$ optional arrows
is universally winning. These 47 finite envelopes have delivery bounds at most 72
messenger moves. In particular, at $n=114$ the full interval is 228 through 380,
with bound 66, and it includes the low-budget interval 229 through 341.

**Proof and finite evidence.** Retain the full cyclic vertex set for both
players; no window or exterior-state abstraction is used. Give the messenger
only the two compulsory permutations and waiting, while giving the cop all
compulsory and optional arrows and waiting. For each recipient, the saved
policy assigns to every nonterminal noncollision messenger state a compulsory
move. It either reaches the recipient immediately, or every cop response is
noncollision and strictly decreases the nonnegative messenger rank. Induction
on that rank proves finite delivery. The policy remains legal in every graph
between the compulsory graph and its full optional envelope, and all possible
cop replies remain covered.

When there are no holes, simultaneous one-column rotation is an automorphism
of both the compulsory and optional arrow sets, so six representative targets
suffice. This identity is checked on both complete arrow sets. Otherwise every
literal recipient is certified. All source/cop positions are checked for every
representative target. The optional count is the same displayed count as above;
the finite records separately check distinctness, absence of loops, and the
complete compulsory and optional lists. Taking the appropriate lexicographic
prefix gives each intermediate integer budget.

The 47 finite canonical certificates are contained in the single bundle
`research/sparse-interface-third-certificates.zip`, indexed by
`research/sparse-interface-third-proof-registry.json`. The producer reconstructs and
smooths the two permutation cycles. The checker
`src/sparse-interface-third-independent.py` imports no project graph builder or
solver: it instead reconstructs each source-type arrow literally and directly
checks the rank after the messenger's chosen move against every actual cop
reply. Its receipt is `research/sparse-interface-third-independent.json`.
Together these are a finite proof of the displayed domain, not an extrapolation
to smaller or larger uncertified rings. Theorem 52 still supplies the ordinary
infinite continuation. Neither this supplement nor its finite graph generation
is presently formalized in Lean.


**The order 109 capacity repair.** At $n=109$ ($k=19,r=5$), additionally permit
$$3_1\to0_4,\qquad3_2\to5_{18}.$$
Both were among the seven suppressed relative arrows near the hole at column
zero. These two fixed additions extend the optional count from 107 to 109 and
therefore the exact budget interval from 218--325 to 218--327, reaching $3n$.
The same full cyclic rank argument was independently replayed for every one
of the 109 recipients, retaining the messenger's compulsory arrows and giving
the cop the entire enlarged optional set. Its maximum rank is 72. The bundle
contains this 48th certificate under the variant name `repair109`; it is a
specific finite extension, not a claim that these two arrows may be restored
at arbitrary orders. Together with the preceding supplement, this gives every
$2n\le m\le3n$ for all $108\le n\le114$.

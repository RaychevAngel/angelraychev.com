# The odd endpoint and completion of its degree defect

The odd arc-budget equality theorem prescribes a particularly small defect:
on $n=k+1$ vertices there is one vertex $u$ of outdegree one, a different
vertex $v$ of indegree one, all other indicated degrees are two, and the arc
$u\to v$ is absent. The candidate extremal value is
$$M_E(2n-1)=(n-2)(n-3).$$
The equality theorem reduces attainment to guaranteeing every missing pair
whose source differs from $u$ and whose recipient differs from $v$. It does
not make arbitrary deletion from, or completion to, a two-regular graph
preserve the relevant guarantees.

## Two necessary structural properties

**Lemma.** Every odd-extremal graph with the preceding degree pattern is
strongly connected. Moreover, for each vertex $c$, the graph with $c$
deleted has a directed path from every $s\notin\{u,c\}$ to every
$t\notin\{v,c\}$.

**Proof.** Each such ordered pair with $s\ne t$ is either a direct arc or
a guaranteed missing pair. Against a pursuer initially at $c$ and waiting
there, any successful delivery path avoids $c$ internally. Since its
endpoints differ from $c$, it gives the asserted path in the deleted graph.

To prove strong connectivity without deleting a vertex, all vertices
different from $u$ already reach all vertices different from $v$. The
unique predecessor $b$ of $v$ is different from $u$, because $u\to v$ is
absent. Thus all vertices other than $u$ reach $v$ by first reaching $b$.
The unique successor $a$ of $u$ differs from $u$, and $u$ reaches every
vertex by first going to $a$. $\square$

These are necessary conditions, not substitutes for the full game: the
pursuer can move, so ordinary connectivity and stationary separators do
not establish an attaining strategy.

## Completing an odd extremizer can fail

**Proposition (finite certified example).** There is a graph $G$ on 19
vertices with 37 arcs attaining $I(G)=272=M_E(37)$ such that adding the
unique degree-completing arc yields a two-in/two-out graph which is not
universally winning. Its completed indirect count is 276, whereas a
universally winning two-regular graph on 19 vertices would have 304.

The example has vertex set $\{0,\ldots,18\}$ and the following outgoing
neighbors:

| Vertex | Outgoing neighbors | Vertex | Outgoing neighbors |
|--:|:--|--:|:--|
| 0 | 5, 12 | 10 | 2, 17 |
| 1 | 15, 10 | 11 | 1, 6 |
| 2 | 7, 0 | 12 | 3, 8 |
| 3 | 1, 18 | 13 | 4, 5 |
| 4 | 15 | 14 | 4, 12 |
| 5 | 11, 9 | 15 | 0, 16 |
| 6 | 8, 13 | 16 | 7, 9 |
| 7 | 13, 17 | 17 | 14, 11 |
| 8 | 10, 16 | 18 | 2, 6 |
| 9 | 3, 14 | | |

Its exceptional vertices are $u=4$ and $v=18$. The finite actual-game
certificate verifies every guarantee required by odd equality and the
count 272. The upper bound follows from Theorem 7 with $k=18$.

There is also a short ordinary obstruction after adding $4\to18$. Fix
recipient zero and start the messenger at 1, the pursuer at 4. Define
$$
S_4=\{1,3,5,6,7,8,9,11,12,13,14,16,17\},\qquad
S_{13}=\{6,11,12,14\}.
$$
The following four classes of messenger-turn states form a pursuer trap:
$$
(s,4)\ (s\in S_4),\qquad (10,18),\qquad (17,6),\qquad
(s,13)\ (s\in S_{13}).
$$
They contain the initial state and exclude every state where the messenger
has reached zero. The pursuer acts as follows, in terms of the messenger's
new vertex $x$:

| Current pursuer | Response |
|--:|:--|
| 4 | If $x=10$, move to 18. If $x=15$ or $18$, capture at $x$. Otherwise wait at 4. |
| 18 | If $x=2$, capture there. If $x=17$, move to 6. If $x=10$, wait. |
| 6 | If $x=11$ or $14$, move to 13. If $x=17$, wait. |
| 13 | If $x\in\{1,3,4,8\}$, move to 4, capturing if $x=4$. Otherwise wait at 13. |

An immediate collision with the current pursuer already loses. Direct
inspection of the outgoing-neighbor table shows that every other possible
move either permits the stated capture or returns to one of the four trap
classes. Waiting is included. Since infinite play without receipt loses,
the messenger cannot deliver to zero. This explicitly identifies how the
new arc helps the pursuer: the transition from cop position 4 to 18 after
the messenger moves from 1 to 10 was unavailable before completion.

`src/odd_endpoint_completion.py` contains the fixed graph and runs both
independent game solvers, checking every winning rank and every losing
closure obligation. `research/odd-endpoint-completion-certificate.json`
stores the complete finite certificates for the original and completed
graphs. The ordinary trap proves nonuniversality without computation;
the original graph's attainment and the completed count 276 use the
verified finite certificates. This example is not presently embedded in
Lean. The subsequent construction settles the odd endpoint at every
sufficiently large budget.

## A useful degree-preserving search operation

Given a two-in/two-out graph, split one vertex $w$ into vertices $v,u$.
Assign one old incoming and one old outgoing arc to each new vertex, then
add $v\to u$. This adds one vertex and one arc, giving exactly the odd
equality degree pattern: $v$ has indegree one and outdegree two, while $u$
has indegree two and outdegree one. The forbidden opposite arc $u\to v$
is absent because the original graph was loopless.

This operation supplies a structured family to investigate, but it is not
a preservation theorem. A split of the 20-vertex five-type graph attains
$M_E(41)=342$, while all twenty canonical splits of its 30-vertex member
fail to attain the corresponding odd bound. Likewise, changing the two
horizontal lane speeds to three produces attaining single-arc deletions
at 40 and 50 vertices but failures at neighboring and larger orders.
These counterchecks prevent promoting isolated success to a uniform
construction. A different six-type family supplies the following uniform
positive result.

## Every sufficiently large odd budget

**Theorem 45 (the odd endpoint).** For every integer $n\ge98$,
$$
M_E(2n-1)=(n-2)(n-3).
$$
Equivalently, for every odd $m\ge195$,
$$
M_E(m)=\frac{(m-3)(m-5)}4.
$$
An explicit attaining graph has $n$ vertices. Every pair required for
attainment has a delivery strategy using at most
$34\lceil n/6\rceil+27$ messenger moves. The construction and its
composition proof are ordinary finite arguments; the bounded local
strategy lemmas are supplied by independently verified finite
certificates.

**Proof.** Put $q=\lceil n/6\rceil$ and $r=6q-n$, so $0\le r\le5$.
The sufficient circumference for each residue is given below. We first describe a graph on the surviving vertices of
$(\mathbb Z/q\mathbb Z)\times\{0,\ldots,5\}$. Its two initial
permutations are
$$
\alpha(i,j)=
\begin{cases}(i,j+1)&j<5,\\(i+1,0)&j=5,\end{cases}
\qquad
\beta(i,j)=(i+e_j,\sigma(j)).
$$
Use the following four choices of $(\sigma,e)$, whose entries are in
type order $0,1,\ldots,5$:

| Pattern | $\sigma$ | $e$ |
|:--|:--|:--|
| $A$ | $(0,2,5,1,4,3)$ | $(-1,-1,1,1,-1,1)$ |
| $B$ | $(0,5,1,4,3,2)$ | $(-1,1,1,-1,-1,1)$ |
| $C$ | $(3,5,0,2,4,1)$ | $(-1,1,-1,-1,-1,0)$ |
| $D$ | $(4,1,5,2,0,3)$ | $(-1,-1,1,1,-1,1)$ |

For a set $H$ of deleted vertices, smooth each permutation separately:
from a surviving vertex, follow that permutation until first reaching
another surviving vertex, and use the resulting arc. Finally delete
one specified arc of the smoothed graph. The complete choices are:

| $r$ | Pattern | Tail $u$ of deleted arc | Which arc | Direction $d$ |
|--:|:--:|:--|:--:|--:|
| 0 | $A$ | $(0,0)$ | $\alpha$ | $1$ |
| 1 | $B$ | $(1,4)$ | $\beta$ | $1$ |
| 2 | $C$ | $(0,5)$ | $\beta$ | $-1$ |
| 3 | $D$ | $(0,1)$ | $\alpha$ | $1$ |
| 4 | $D$ | $(0,1)$ | $\alpha$ | $1$ |
| 5 | $C$ | $(0,5)$ | $\beta$ | $-1$ |

The corresponding deleted vertex sets are:

- $r=0$: $H=\varnothing$.
- $r=1$: $H=\{(0,3)\}$.
- $r=2$: $H=\{(0,0),(0,1)\}$.
- $r=3$: $H=\{(0,2),(0,3),(0,4)\}$.
- $r=4$: $H=\{(-1,4),(0,2),(0,3),(0,4)\}$.
- $r=5$: $H=\{(0,0),(0,1),(1,0),(1,1),(1,5)\}$.

Write $v$ for the head of the final deleted arc. Every type cycle of
each displayed $\sigma$ has a nonzero total displacement $e$ with
$|e|$ no greater than its length $\ell$. Its cyclic lift has length
$\ell q/\gcd(q,e)\ge q$, whereas $\alpha$ is a cycle of length $6q$.
At most five vertices are removed, so no permutation cycle disappears.
The smoothing operation therefore preserves the permutation property
on surviving vertices. Inspection
of these six fixed patterns shows that the two smoothed images at each
surviving vertex are distinct, are not the vertex itself, and change
the column by at most two. The changes to outgoing arcs are confined
to tails in columns $[-2,2]$; removed vertices lie in columns $[-1,1]$.
These are finite checks on the displayed tables, independent of $q$.
The sufficient circumferences are at least 15, so reduction modulo $q$ introduces
neither a coincidence nor a loop. Thus the final graph has $n=6q-r$
vertices, $2n-1$ arcs, precisely one outdegree-one vertex $u$, precisely
one indegree-one vertex $v$, and all other corresponding degrees two.
Moreover $u\ne v$ and $u\to v$ is absent.

Use the retained local certificates with messenger radius $M$, pursuer
radius $R$, and an outside state $\Omega$. Both players may wait;
messenger moves leaving its window are forbidden. A pursuer leaving its
window goes to $\Omega$, which permits waiting and entry into its $J$
boundary layers. Let $[a,b]$ contain every changed outgoing tail, deleted
vertex and degree-exception vertex. The exact parameters are:

| $r$ | $M$ | $R$ | $J$ | $[a,b]$ | Sufficient $q$ | Transfer | Delivery |
|--:|--:|--:|--:|:--:|--:|--:|--:|
| 0 | 4 | 6 | 2 | $[0,0]$ | 15 | 14 | 26 |
| 1 | 4 | 6 | 1 | $[-1,1]$ | 15 | 9 | 22 |
| 2 | 4 | 6 | 2 | $[-1,1]$ | 15 | 17 | 26 |
| 3 | 5 | 7 | 2 | $[-1,1]$ | 17 | 34 | 23 |
| 4 | 5 | 7 | 2 | $[-1,1]$ | 17 | 28 | 27 |
| 5 | 5 | 7 | 2 | $[-1,2]$ | 18 | 9 | 26 |

The table's support is obtained without a search: trace each removed
vertex backwards in each permutation to its first surviving predecessor,
and include the final deleted arc and its two endpoints. Outside those
tails, outgoing arcs are unchanged. All actual column jumps are at most
$J$; in residue zero the allowed entry depth two is conservative.

For every represented defect translation, safe transfer goes from column
$-d$ to column zero on a noncolliding messenger turn, excluding $u$ at
both endpoints. Delivery goes from column $-2d$ to every surviving
recipient of column zero other than $v$, again excluding initial source
$u$. In residue five, transfer may instead end in column zero or $-1$,
and delivery starts in column 2 or 3. Receipt is terminal before collision.
The table lists the maximum certified messenger moves.

The frozen independent archives contain all 847 local objectives:
97 for residue zero and 750 for the nonempty patches. The direct replay
checks all 470,026 required initial states, 8,417,696 alternating states,
and 24,787,015 legal-transition obligations, including losing closure.
For residue zero the anchors are $-6,\ldots,6$; for the others they are
$-10,\ldots,10$, always with an additional unchanged arena. These are
finite local lemmas, not tests extrapolated over ring lengths.

The window-projection lemma and its single-defect condition require
$$q\ge2R+J+1,\qquad q\ge2R+b-a+1.$$
The relevant anchor interval $[-R-b,R-a]$ lies within the certified
anchors in every table row. On represented outgoing tails the selected
one-patch arena agrees with the smoothed arrow formulas; other incoming
effects are covered by the permitted exterior entries. If no patch is
relevant, the unchanged arena applies. Thus local simulation holds at
every center. The displayed circumferences satisfy both inequalities
and cover every $n\ge98$; the last excluded residue representative is
$n=97$.

Fix a source other than $u$ and a recipient other than $v$. Eligibility
means that the messenger avoids $u$ at module starts and handoffs; every
certified transfer preserves it. For $r\le4$, transfers advance one
column in the displayed direction $d$, and delivery starts in the single
column two steps before the recipient. Cyclic strategy composition uses
at most $q-1$ transfers. For $r=5$, transfers advance one or two columns
leftward, and the delivery entries are the two adjacent columns 2 and 3
relative to the recipient. The same theorem, with maximum progress two
and entry-block length two, uses at most $q-2$ transfers. In particular,
the uniform bound $34q+27$ stated above remains valid.

Every missing pair with source different from $u$ and recipient
different from $v$ is therefore guaranteed. Their number is
$(n-1)^2-(n-2)-(2n-3)=(n-2)(n-3)$.
The odd arc-budget upper bound proves equality. $\square$

When $r=0$, the same argument gives the sharper bound $14q+12$ for
all $q\ge15$, retaining the original congruence-family theorem.
The generator is `src/odd_endpoint_all_residues.py`; the unchanged proof
archives are `research/six-type-independent-odd-certificates.json.gz`
and `research/six-type-independent-odd-residues-certificates.json.gz`.
`src/odd_projection_threshold_check.py --check` replays their full ranks,
checks exact defect support and the projection inequalities, and compares
its result with `research/odd-projection-threshold-audit.json`.
The original generation receipts retain their historical threshold 145
and source hashes; no frozen certificate was regenerated or repinned.
The original primary certificates are retained as additional evidence.
This theorem has not been formalized in Lean.

**Corollary 45.1 (the odd endpoint from 25 arcs).** For every $n\ge13$,
$$
M(n,2n-1)=M_E(2n-1)=(n-2)(n-3).
$$
Consequently the exact odd arc-only extremum is
$$M_E(m)=\frac{(m-3)(m-5)}4\qquad(m\ge25\text{ odd}).$$

**Proof.** Theorem 45 covers $n\ge98$. For every one of the remaining
85 integers $13\le n\le97$, the supplementary data give a fixed
simple graph with $2n-1$ arcs, one outdegree-one vertex $u$, one different
indegree-one vertex $v$, all other corresponding degrees two, and
$u\to v$ absent. The displayed six-type residue families supply most
of these graphs. Deleting one arc from independently verified finite
two-regular examples supplies the remaining orders from 19 upward.
Six further fixed witnesses cover orders 13 through 18.

For every recipient other than $v$, the finite certificates specify
an integer rank for every explicit messenger-turn and pursuer-turn
state. Terminal receipt has rank zero, nonterminal collision has rank
$-1$, and every other nonnegative messenger rank has a legal successor
of smaller nonnegative rank. Every legal successor of a nonnegative
pursuer rank has smaller nonnegative rank. The direct checker verifies
these conditions against the original graph, together with the entire
complementary losing closure. Every initial messenger state whose
source differs from $u$ and whose pursuer position differs from the
source has nonnegative rank. Strict rank descent therefore forces
finite delivery from each required state against every pursuer policy.
This proves all required guarantees for each listed graph.

The retained full archive, which also covers the now unnecessary orders
98 through 144, contains 10,236 recipient objectives and 215,967,810
explicit alternating states. The same degree count as in Theorem 45
then gives $(n-2)(n-3)$ guaranteed missing pairs. The arc-only upper
bound applies to all support sizes, and hence also to the fixed support
size $n$. This proves both equalities. $\square$

The 126 graphs at orders 19 through 144 are in
`research/odd-endpoint-finite-bridge-graphs.json`.
Their complete ranks are in the streamable archive
`research/odd-endpoint-finite-bridge-certificates.jsonl.gz`, with source
hashes and a full numerical summary in
`research/odd-endpoint-finite-bridge-verification.json`.
The producer `src/odd_endpoint_finite_certify.cpp` uses an explicit
alternating-game attractor. The separate direct verifier
`src/odd_endpoint_finite_verify.py` checks the original legal moves;
it does not rerun or trust the producer's queue logic. Its accelerated
array checks have an equivalent standard-library scalar mode.
Scalar replay of all objectives at orders 19 through 24 also passes,
and the earlier two independent game algorithms agree with selected
saved certificates at orders 19, 28 and 144. The complete direct rank
checks, rather than these additional sample comparisons, prove the
finite bridge. The six smaller witnesses are fully checked by both
original game algorithms and the direct transition verifier in
`src/odd_endpoint_small_verify.py`; their complete proof data and
summary are `research/odd-endpoint-small-certificates.json.gz` and
`research/odd-endpoint-small-verification.json`. These finite
certificates have not yet been imported into Lean.

**Proposition (small odd exceptions; exhaustive finite check).** For
$6\le k\le11$, the general odd upper bound is not attained:
$$M_E(2k+1)\le k(k-3)+1.$$
In particular, $M_E(23)\le89$.

**Proof.** Equality in the upper bound $k(k-3)+2$ would, by the equality
characterization, have precisely $n=k+1$ nonisolated vertices, one
outdegree-one vertex $u$, one distinct indegree-one vertex $v$, all
other corresponding degrees two, and $u\to v$ absent. Add this missing
arc. The resulting two-in/two-out digraph is a bipartite two-regular
graph when its sources and recipients are represented in separate
parts. Each of its bipartite cycles has even length, so alternating
edge colors decompose it into two permutation factors $A,B$. Choose
$A$ to contain $u\to v$ and label $u=0,v=1$.

Up to relabeling fixing these two vertices, the $A$-cycle through zero
is $(0,1,\ldots,\ell-1)$ for one $\ell\ge2$. Its other cycles are
represented by an integer partition of $n-\ell$ into parts at least
two. For each such choice, enumerating all permutations $B$ with
$B(i)\ne i,A(i)$ covers every candidate graph; remove $0\to1$ before
applying any game test.

Two necessary obstructions safely prune this enumeration. Once the
outgoing neighborhood of an eligible source $s$ is complete, if some
$c\ne s$ has $N^+(s)\subseteq N^+[c]$ and there is an eligible missing
recipient for $s$, the pursuer can wait at $c$ and capture the first
nonwaiting messenger move. Once the incoming neighborhood of an
eligible recipient $t$ is complete, if
$N^-(t)\subseteq N^+[c]$ and there is an eligible source outside
$N^-(t)\cup\{t,c\}$, waiting at $c$ until the messenger first enters
$N^-(t)$ likewise permits capture. In a partial assignment the cop's
outgoing row may be incomplete: coverage already present persists
under later additions. The source or recipient neighborhood used in
the inclusion is always complete. The code checks explicitly that
the required eligible missing partner exists.

All remaining completed graphs are evaluated by the exact finite
reachability game, with receipt priority and finite termination.
Enumeration finishes at every $7\le n\le12$ and finds no attaining
graph. Its counts are:

| $n$ | Distinguished cycle partitions | Partial nodes | Completed graphs surviving local obstructions |
|--:|--:|--:|--:|
| 7 | 7 | 756 | 0 |
| 8 | 11 | 6,338 | 21 |
| 9 | 15 | 59,375 | 2,092 |
| 10 | 22 | 800,507 | 64,992 |
| 11 | 30 | 10,079,292 | 767,210 |
| 12 | 42 | 164,276,910 | 16,902,091 |

These finite exclusions and the equality characterization prove the
claimed strict bounds. $\square$

The complete enumerator is `src/odd_endpoint_exhaustive.cpp`; its
finished receipts are `research/odd-endpoint-small-exhaustive.json`
and `research/odd-endpoint-n12-exhaustive.json`. A known attaining
13-vertex graph passes every partial pruning test as a positive control.
The independent review `research/odd-endpoint-twelve-independent-audit.md`
checks the permutation coverage, both pruning arguments, and the
final game semantics. It is an independent source and proof audit,
not a separately implemented repetition of the enumeration. Neither
this result nor the preceding odd endpoint certificates currently
has Lean coverage. The proposition does not determine the exact
small odd maxima.

The general support reduction in Theorem 57 and the exact finite exclusions
in Theorem 53 supersede the earlier bespoke 23-arc reductions and
intermediate bounds. Their original arguments and receipts are preserved in
`research/history/manuscript-superseded-arguments-2026-09-13.md`.
The following eleven-vertex core lemma underlies the retained small-order exclusions.

**Lemma (eleven-vertex cores).** Every graph on 11 vertices with
22 or 23 arcs satisfies $I(G)\le81$.

**Proof.** A vertex of outdegree at most one leaves at most ten
contributing source rows, each of size at most eight, giving $I\le80$.
A low-indegree vertex gives the same column bound. We may therefore
assume minimum indegree and outdegree two. At 22 arcs all degrees
equal two. At 23 arcs exactly one vertex has outdegree three and
exactly one has indegree three.

If a source camping obstruction occurs, at least eight missing pairs
fail at 22 arcs, and at least seven fail at 23 arcs. If a recipient
camping obstruction occurs at $t$ with pursuer position $c$, every
source outside $N^-(t)\cup\{t,c\}$ fails. This gives at least seven
failed pairs at 22 arcs and at least six at 23 arcs. The total numbers
of missing pairs are 88 and 87, respectively, so every graph with
one of these obstructions has $I\le81$.

It remains to enumerate the graphs with neither obstruction. The
22-arc case uses the two-permutation decomposition already described.
For 23 arcs, the bipartite graph still has a perfect matching: a set
$S$ of source vertices emits at least $2|S|$ edges, whereas a set
of possible heads $T$ can receive at most $2|T|+1$. Thus
$|N(S)|\ge|S|$, which implies a perfect matching by the augmenting-path
criterion. Its removal leaves residual degree one at every source
except the unique degree-three source, where two choices remain;
recipient capacities are analogous.

Fix the matching permutation to each cycle partition with no singleton.
Its cycle rotations and permutations of equal-length cycles allow
the degree-three source to be placed at one representative vertex
for each distinct cycle length. Enumerate all positions of the
degree-three recipient, then every residual row subject to the
prescribed column capacities. This covers every graph in question.
Only complete source rows or recipient columns are used in camping
prunes; a partial cop row suffices because any coverage already
present persists under later additions.

The complete 22-arc enumeration has 120,302 graphs surviving these
prunes, with maximum $I=66$. The complete 23-arc enumeration has
792,080 such graphs, with maximum $I=74$. Both use the exact finite
game recurrence and were freshly recompiled and replayed with all
counts and witnesses matching. Thus the graphs surviving the prunes
also have $I\le81$, proving the lemma. $\square$

The source and mathematical audit, including the matching argument,
symmetry reduction and rollback checks, is
`research/odd-endpoint-eleven-enumeration-audit.md`. The enumerators
are `src/small_exceptional_regular_max.cpp` and
`src/small_exceptional_one_excess.cpp`; matching replay receipts and
hashes are indexed by
`research/odd-endpoint-eleven-enumeration-audit.json`.
The saved maximizing witnesses additionally pass both original game
solvers and all direct rank checks. This is independent review and
re-execution of the same enumeration sources, rather than a second
independently implemented enumeration.

Theorem 53 combines the exact value $M(11,23)=78$, the shared
source/sink and positive-support bounds, and the three finite
exceptional-family exclusions to prove $M_E(23)=83$.
Its verified twelve-vertex witness also proves $M(n,23)=83$ for every
$n\ge12$ after adding isolates.

# The combined joint maximum

The sparse constructions can be placed inside a larger network by adding
isolated vertices. This observation joins the arc-budget extrema to the
two dense regimes and gives a single eventual formula.

**Corollary 47 (complete joint classification).** Let $n\ge12$ and
$0\le m\le n(n-1)$. Put $A_m$ equal to the following listed value:

| $m$ |0|1|2|3|4|5|6|7|8|9|10|11|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| $A_m$ |0|0|0|0|1|1|2|2|4|5|6|8|

| $m$ |12|13|14|15|16|17|18|19|20|21|22|23|
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| $A_m$ |9|11|13|15|19|28|33|40|53|60|79|83|

Then
$$
M(n,m)=
\begin{cases}
A_m,&0\le m\le23,\\
k(k-3),&m=2k,\quad24\le m\le2n,\\
k(k-3)+2,&m=2k+1,\quad25\le m<2n,\\
n(n-1)-m,&2n\le m\le n(n-3),\\
2n-r-\lceil r/2\rceil-1,
&m=n(n-3)+r,\quad1\le r\le n,\\
0,&n(n-2)<m\le n(n-1).
\end{cases}
$$
Every value has an explicit attaining construction. For $1\le n\le11$,
the complete tables in the finite-values section supply every admissible value
and its certified listed graph or specified composition.

The two formulas at $m=2n$ agree. For even $m$, the first formula also
holds for every $24\le m\le2n$ on every host order $n\ge m/2$.

![The positive exact regimes at $n=115$ for $m\ge24$: sparse growth, the main interval, and the final dense band. Separate axis scales show the two narrow endpoint regimes. The dotted continuation in the last panel leads to zero above $n(n-2)$.](figures/joint-regimes.pdf){width=100%}

**Proof.** For $0\le m\le11$, use the complete small-budget theorem and
its listed witnesses. The finite sparse-budget theorem supplies $12\le m\le21$;
its largest least attaining host is twelve. Thus every $A_m$ through21 is
attained at every $n\ge12$ by adding isolates.

The explicit eleven-vertex, 22-arrow extremizer and its matching
arc-only bound give $M(n,22)=79$ after adding isolates. Theorem 53 gives
$M(n,23)=83$ on every host of order at least twelve.

For even $m=2k\ge24$, Theorem 40 constructs an attaining
$k$-vertex graph. If $k\le n$, add $n-k$ isolated vertices. This does
not change $I$: pairs between components have no delivery path; a
pursuer starting at an added isolate stays there and cannot obstruct an
existing delivery strategy. The arc-only upper bound supplies the
matching upper bound for the joint problem.

For odd $m=2k+1\ge25$, Corollary 45.1 constructs an attaining graph on
$k+1=(m+1)/2$ vertices. When $m<2n$, its support has at most $n$
vertices. Add isolates and apply the odd arc-only upper bound. This
gives $k(k-3)+2$.

The complete main-interval theorem supplies the third case from order
twelve, preserving Theorem 44 and all its earlier constructions. The
complete-band corollary in the root-colored cycle section supplies the fourth
from order eleven. Four moves suffice for that whole dense band; its
stronger two-move corollary applies from order sixteen. Finally
Theorem 13 gives zero above $n(n-2)$. The ranges cover every stated
integer budget. The finite-values section and its complete source-pinned
registry cover all smaller orders. $\square$

At order eleven the three initial values are
$$M(11,22)=79,\qquad M(11,23)=78,\qquad M(11,24)=79.$$
For $25\le m\le88$, the saved finite stages give $M(11,m)=110-m$.
The displayed staircase and zero branches then cover all remaining
budgets. Thus every $n\ge11$, $22\le m\le n(n-1)$ has an exact value
and an explicit attaining graph. The special order-eleven values are
proved in the small-order section; they are not obtained by extending
the sparse parity formula below its hypotheses.

The two parts together determine every admissible integer pair, including the
small host exceptions. Stronger optional-subset and delivery-time conclusions
remain attached to the construction theorems that prove them; the classification
does not transfer those properties to every other attainer of the same value.

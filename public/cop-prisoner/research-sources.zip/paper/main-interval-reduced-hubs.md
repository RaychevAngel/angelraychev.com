# A smaller incoming and outgoing hub interface

The guide attachment lemma also permits fewer hub arrows at both ends.
Only its fixed interface proof changes: it now needs four moves, followed
by the same single safe-entry move from a bulk vertex.

**Theorem (reduced twelve-hub interface).** Let $2\le g\le7$. Assign the
$b$ bulk vertices any distinct guide subsets $J_x\subseteq\{0,\ldots,g-1\}$
which have size at least two and form an antichain. Put
$n=12+g+b$ and $W=\sum_x|J_x|$. There is an explicit attaining construction
at every budget
$$
 A\le m\le A+b(g+b+8),\qquad A=106+18g+12b+W.
$$
Every subset of the specified optional arrows is permitted, and delivery
takes at most five messenger moves. In particular, distinct size-$r$ codes
give $A=106+18g+(12+r)b$ whenever
$2\le r\le g\le7$ and $0\le b\le\binom gr$.

**Construction.** Label the hubs $P_i=i$ and $L_i=6+i$, with indices
modulo six. Their missing arrows are
$$P_i\to L_i,L_{i-1},\qquad L_i\to P_{i+4},P_{i+6};$$
all other distinct hub pairs are arrows. Use the first $g$ guide codes
$$
 \{L_0,L_2,L_4\},\quad\{L_1,L_3,L_5\},\quad
 \{P_0,P_3\},\quad\{P_1,P_4\},\quad\{P_2,P_5\},\quad
 \{L_0,L_3\},\quad\{L_1,L_4\}.
$$
The parameters of the guide attachment lemma are
$$
\begin{split}
 R&=\{P_1,P_2,P_3,P_4,L_0,L_1,L_3,L_4\},\\
 S&=\{P_1,P_4,L_1,L_3\},\qquad T=\{P_0,P_2,P_3\},\\
 U&=H\setminus T,\qquad C=H\setminus R.
\end{split}
$$
Thus precisely $R$ reaches every guide compulsorily, each guide reaches
the hubs outside its code, and bulk vertex $x$ reaches $S\cup J_x$.
The optional arrows are all guide-to-bulk and distinct bulk-to-bulk
arrows, all arrows from $H\setminus R$ to bulk vertices, and all arrows
from a bulk vertex to $H\setminus(T\cup S)$. In particular a bulk
pursuer may reach nine hubs, whereas the messenger needs only four.

For equal-size codes, take the first $b$ lexicographic $r$-subsets.
For an exact budget, take the first $m-A$ optional arrows in ordered-endpoint
order. These are direct finite listing rules with no game search.

**Proof.** We verify the attachment lemma's interface hypothesis with
$d=4$, allowing a bulk pursuer every guide and every hub outside $T$.
A hub move is safe against hub $c$ exactly when it belongs to the
missing row $F^+(c)$, against a guide when it belongs to that guide's
code, and against a bulk pursuer whenever it belongs to $T$.
All nonterminal intermediaries below are hubs.

For a hub recipient, Theorem 59 supplies the two-move proof against
hub and guide pursuers; removing hub-to-outside arrows cannot affect
its hub witnesses. Against a bulk pursuer, a missing hub pair's danger
set has only two points, so it misses a member of $T$. For a point-code
guide source, a missing recipient is a point; at least one of $T$'s
three points lies outside its two-element code and reaches the recipient
through the point clique. For a line-code guide, all three safe points
are reachable, and at most two fail to reach a line recipient. Thus
all interface sources reach every hub recipient within two moves.

For an outside recipient, the hubs in $R$ reach it directly. The
following table specifies the further source-rank layers and their
reachable, already winning hub sets, using the numeric hub labels.

| New sources | Delivery bound | Reachable already winning hubs |
|:--|--:|:--|
| $P_0$ | 2 | $\{1,2,3,4,7,9,10\}$ |
| $P_5$ | 2 | $\{1,2,3,4,6,7,9\}$ |
| $L_2$ | 3 | $\{1,3,4,5,6,7,9,10\}$ |
| $L_5$ | 3 | $\{0,1,2,4,6,7,9,10\}$ |
| Point-code guide with code $K$ | 3 | $(H\setminus\{L_2,L_5\})\setminus K$ |
| Remaining guide with code $K$ | 4 | $H\setminus K$ |

Each displayed set meets the missing row of every hub pursuer other
than the source, every other guide code, and $T$. These are exactly
the safe-intermediary tests, with a source's own pursuer position excluded.
We verify the tests explicitly. In the first two rows, the four point
members meet every difference-two pair; the listed lines meet every
adjacent pair except the source's own missing row. Both rows meet the
first guide triple in $L_4$ or $L_0$, respectively, the second in
$L_1,L_3$, all three point codes, and the two retained line-pair codes.
They meet $T$ in $P_2,P_3$.

In the next two rows the only omitted lines form the antipodal pair
$\{L_2,L_5\}$, so every adjacent line pair is met. Their point members
meet every difference-two pair except the source's own row. Directly
reading the seven codes shows that both sets meet each; they meet
$T$ in $P_3$ and in $P_0,P_2$, respectively. For a point-code guide,
removing its antipodal point pair leaves a point in every difference-two
pair. The four retained lines meet every adjacent pair and every line
code; the other point codes are disjoint from its own. At least one
member of $T$ remains. Finally $H\setminus K$ for a remaining guide
meets every hub missing row because $K$ contains neither an adjacent
line pair nor a difference-two point pair. It meets every other guide
code by incomparability, and contains all of $T$, since $K$ is a line
code. This verifies the table.

Every safe hub has smaller delivery rank, independently of the cop's
reply. Rank induction proves the four-move interface, including against
the allowed bulk pursuer. Optional hub-to-bulk arrows do not change
any missing hub row. Finally $S$ meets exactly the eight hub missing
rows indexed by $R$; the four exceptions are $P_0,P_5,L_2,L_5$.
This is the attachment lemma's remaining hypothesis.

Apply that lemma with $h=12$, $a=108$, $|R|=8$, $|S|=4$,
$W_K=2g+2$, $W_J=W$, $|C|=4$, and $|U\setminus S|=5$.
It gives the compulsory count
$$108+20g-(2g+2)+12b+W=A,$$
the optional count $b(g+b+8)$ and the five-move bound.
Every missing pair therefore delivers, attaining the missing-pair upper
bound throughout the interval. $\square$

For pair codes the base is $14n-62+4g$. At $(n,g,b)=(25,5,8)$ the
interval is $308\le m\le476$; at $(27,5,10)$ it is
$336\le m\le566$. These cover, respectively, the earlier outstanding
budgets 326 through 339 and 352 through 375. The optional-subset guarantee
and five-move bound preserve the earlier family's stronger three-move
claim as a separate result.

The eighth code $\{L_2,L_5\}$ is deliberately absent: it misses the
first two safe-intermediary sets. This is an obstruction to that interface,
not to every eight-guide construction or to the game.
The direct constructor is `src/main_interval_reduced_hubs.py`. Its checks
replay the fixed hub ranks, safe-entry premises, full-capacity equal-weight
families, a mixed antichain and the two targeted intervals. `ReducedTwelveHubGraph.lean` and `ReducedTwelveHubCounts.lean` now
instantiate the reduced twelve-hub equal-weight family, with numeric-mask
code selection, exact counts and optional-prefix maxima. Other code
variants and supplementary timing claims retain their stated boundaries.

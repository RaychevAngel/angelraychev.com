# Functional interfaces in the final dense band

All graphs in this section are missing-arrow graphs; the delivery graph is
their loopless directed complement. Put $n=r+k$ and
$j=\lfloor(r-2)/2\rfloor$. The functional graph on $r\ge2$ vertices
has $a\leftrightarrow b$, chains $s_i\to t_i\to a$ for $1\le i\le j$,
and a spare $z\to a$ when $r$ is odd. Its roots $R$ have missing indegree
zero and $|R|=\lfloor(r-1)/2\rfloor$; exactly its $j$ pairs $(s_i,t_i)$
are guaranteed.

**Theorem (root-colored attachment).** The exact value
$$M(n,n(n-3)+r)=j+2k=2n-r-\lceil r/2\rceil-1$$
has a direct attaining construction in the following domains:

- $k=0$; or $r\ge5$ and $k=1$ or even; or $r\ge7$, with two-move delivery;
- $r\ge5$ and arbitrary $k$, with three-move delivery.

**Construction and proof.** For $k=0$ use the functional graph. For
$k=1$ give the new vertex two distinct roots as its missing neighbors.
For $k\ge2$, put a missing cycle on the new vertices, with successor
$\sigma$, and add $x\to\gamma(x)$ for a proper root coloring $\gamma$.
Two alternating roots suffice for even $k$; an odd cycle uses a third root
at its last vertex. Each new row has two missing neighbors.

Fix a new missing pair, from $x$ to either $\gamma(x)$ or $\sigma(x)$.
An old pursuer $c$ has a unique missing neighbor in the old nonroots,
which is a safe intermediary to either recipient. A new pursuer $c\ne x$
with different root color uses $\gamma(c)$. If the colors agree, use
$\sigma(c)$: injectivity gives $\sigma(c)\ne\sigma(x)$, and proper
coloring ensures its delivery arrow to $\gamma(x)$. It also has an arrow
to $\sigma(x)$, since a missing arrow there would force
$\sigma(c)=x$, contradicting the equal colors. For an old counted pair
$(s_i,t_i)$, a new pursuer uses $\sigma(c)$; the source reaches every
new vertex and each new vertex reaches the old nonroot $t_i$.
The $k=1$ case instead uses a root different from the functional source.
These intermediaries prove every claimed two-move guarantee.

Only odd $k\ge3$ with two roots remains. Use an alternating cycle on
$k-1$ vertices and a singleton $p$ whose missing neighbors are the two
roots. A cycle-source pair against pursuer $p$ uses the other root;
an old counted pair uses a root different from its source. Thus all
these pairs retain their two-move guarantees. From $p$ to a root,
an old pursuer again supplies its unique nonroot missing neighbor.
Against a cycle pursuer $c$, move safely to $\sigma(c)$ and either
deliver directly or invoke its already proved two-move strategy.
This takes at most three moves.

The graph has $r+2k$ missing arrows and $j+2k$ guarantees, matching
Theorem 27. The existing fixed-graph certificates check the same
constructions; the displayed argument proves their unbounded domains.
$\square$

**Corollary (the two-move band).** For every $n\ge16$ and $1\le r\le n$,
the staircase value has an attaining construction with two-move delivery.

**Proof.** The first step uses the four-vertex attachment of Theorem 58.
For $2\le r\le6$, the remaining core has $k=n-r\ge10$ vertices, so
functional-block addition to the direct core applies. For $r\ge7$ use
the preceding colored attachment. The case $k=0$ is functional. $\square$

## Exact addition across missing-arrow blocks

**Lemma (arbitrary-duration missing-block addition).** Let $F$ be a
disjoint union of loopless directed graphs $F_1,\ldots,F_b$, every
vertex of which has positive outgoing degree. Let $G_i$ be the loopless
complement of $F_i$ on its own vertex set, and let $G$ be the loopless
complement of $F$. Then
$$I(G)=\sum_{i=1}^b I(G_i).$$
More precisely, a missing pair inside block $i$ is guaranteed in $G$
if and only if it is guaranteed in $G_i$. If its original guarantee
uses at most $D\ge1$ messenger moves, at most $\max\{2,D+1\}$ moves
suffice in $G$.

**Proof.** Every arrow between distinct blocks is present in $G$, so all
missing pairs lie within one block. Fix such a pair $(s,t)$ in block $i$.

Suppose first it is guaranteed in $G_i$. If the pursuer starts outside
block $i$, choose one of its missing neighbors $w$ in its own block.
The source has a delivery arrow to $w$, the pursuer cannot reach $w$ in
its reply, and $w$ has a delivery arrow to $t$. Two moves suffice.
Otherwise follow the original within-block strategy while the pursuer
remains in block $i$. If the pursuer first leaves that block after a
nonterminal messenger move, apply the same two-move escape argument
from the messenger's present vertex. A play in which the pursuer stays
inside follows the original winning strategy. If the strategy has a
bound $D$, any departure occurs after at most $D-1$ messenger moves,
giving at most $D+1$ moves in total. All waits are included in these
strategies. The chosen $w$ is not the pursuer's current vertex, since
$F$ has no loops, so waiting cannot invalidate its safety.

Conversely, suppose the pair is not guaranteed in $G_i$. Choose a
permitted initial pursuer position and its avoiding strategy in that
finite reachability game. Keep the pursuer inside the block and follow
that strategy. If the messenger also stays inside, it cannot guarantee
receipt. If it first leaves, its new vertex is outside the recipient's
block, so receipt has not occurred, and the pursuer immediately captures
it using the complete cross-block arrow. Thus an outside excursion
cannot turn an internal losing pair into a winning one. This proves
the equivalence and summing over missing pairs proves the identity.
$\square$

The two-move version of the original block lemma retains its sharper
two-move time conclusion. The present lemma removes that hypothesis
for the count identity; it does not assert that every copied strategy
continues to use two moves.

**Proposition (a nine-vertex core).** There is an explicit graph with
$n=9$, $m=54$ and $I=18$. Label vertices $0,\ldots,8$ and take all
nonloop delivery arrows except the following missing-neighbor rows:
$$
\begin{array}{c|ccccccccc}
v&0&1&2&3&4&5&6&7&8\\\hline
N_F^+(v)&\{1,3\}&\{4,7\}&\{5,6\}&\{0,2\}&\{6,8\}&
\{2,8\}&\{0,4\}&\{1,5\}&\{3,7\}
\end{array}
$$
Every missing pair is guaranteed within three messenger moves. Four of
the eighteen pairs need more than two moves under the exact two-move
criterion. The literal graph is a permitted finite exception: it is
verified by two independent actual-game solvers and a full replay of
all alternating-state rank certificates, in
`research/dense-third-core-compose-certificates.json`. The missing-pair
upper bound proves $M(9,54)=18$.

## One additional missing arrow supplies every first step

**Lemma (enlarged direct cores).** At every order $N\ge9$ there is an
explicit missing graph with $2N+1$ arrows whose complement guarantees all
of them. Three messenger moves suffice for $N\ge10$; the retained
nine-core uses four.

**Proof.** For even $N=2q\ge10$, use the two-type core (B) of Theorem 58
and add $P_0\to P_1$. Only pairs leaving $P_0$, entering $P_1$, and the
new pair can lose an old safe intermediary. For the new pair the point
and line danger indices are $\{0,1\}$ and $\{0,-1,-3,-5\}$.
For $q\ge7$, the latter contains only the source's adjacent pair
$\{0,-1\}$. The affected old pairs have just one additional blocked
state:
$$(P_0,L_{-1},L_{-5}),$$
where the entries are source, recipient and pursuer. Move safely to
$P_{-1}$, whose missing pair to $L_{-1}$ still has its universal
two-move guarantee. This proves the assertion for $q\ge7$.

For odd $N=2q+1\ge13$, use (O) and add the same $P_0\to P_1$.
For $q\ge8$ the only additional blocked states and safe first moves are
$$(P_0,L_{-1},L_{-5})\longmapsto P_{-1},\qquad
(P_0,w,L_{-3})\longmapsto P_3.$$
Both resulting pairs retain their universal two-move guarantees.
Indeed the new pair has line danger indices $\{-1,-3,-5\}$,
point indices $\{0,1\}$, and vertex $w$. No ordinary cop row fits;
the modified row $\{w,L_2\}$ fits only when $q=7$.
The old pair to $w$ has point danger $\{0,1,3\}$ and the old pair
to $L_{-1}$ has point danger $\{-1,0,1\}$, giving exactly the two
states displayed. Pairs entering $P_1$ introduce no others for $q\ge6$.

The small moduli have the following complete exceptional-state lists;
each safe first move leads to a universally two-move pair:

| Core | Source, recipient, pursuer | Safe first move |
|:--|:--|:--|
| even $q=5$ | $(P_0,L_4,L_0)$; $(L_2,P_1,L_4)$ | $P_4$; $P_0$ |
| even $q=6$ | $(P_0,P_1,P_1)$; $(P_0,L_5,L_1)$ | $L_1$; $P_5$ |
| odd $q=6$ | $(P_0,L_5,L_1)$; $(P_0,w,L_3)$ | $P_5$; $P_3$ |
| odd $q=7$ | $(P_0,P_1,P_3)$; $(P_0,L_6,L_2)$; $(P_0,w,L_4)$ | $L_2$; $P_6$; $P_3$ |

For the eleven-core listed in Theorem 58, add missing arrow $7\to0$.
The five affected danger sets, for pairs $(7,0),(7,3),(7,4),(4,0),(9,0)$,
are respectively
$$\{0,3,4,7,9\},\ \{0,3,4,6,7\},\ \{0,3,4,7\},\
\{0,1,4,7,9\},\ \{0,4,5,7,9\}.$$
Each contains only its source's missing row. Thus every missing pair
still wins in two moves. Finally, the nine-core above with $2\to4$
added is the retained finite all-delivery witness with 19 missing arrows
in `research/small-dense-anchor-certificates.json`.

The modular danger-set proof establishes the unbounded families.
`src/dense_functional_transfer_check.py` independently checks their
exceptional states and safe moves, the five literal eleven-core sets,
and both exact game algorithms on the fixed small graphs. The receipt
`research/dense-functional-transfer-audit.json` records the checks;
no new Lean instantiation is asserted. $\square$

**Corollary (the first dense step).** For every $n\ge11$,
$$M(n,n(n-3)+1)=2n-3.$$

**Proof.** Adjoin a disjoint missing two-cycle to the enlarged core of
order $n-2$. Missing-block addition preserves all $2n-3$ core guarantees;
there are $2n-1$ missing arrows, meeting Theorem 27. Four moves suffice
for $n\ge12$ by the lemma; the retained full certificate gives the
same bound at $n=11$.
The earlier two-move construction remains available for $n\ge16$.
The retained finite attachments at $n=14,15$ additionally retain their
three-move bounds; their full ranks are in
`research/dense-third-core-compose-certificates.json`. $\square$

## Equality in the second dense step

**Proposition (the second step reduces exactly to a smaller dense core).**
Let $n\ge5$ and put $k=n-2$. Then
$$M(n,n(n-3)+2)=2n-4
\quad\Longleftrightarrow\quad M(k,k(k-3))=2k.$$
In particular,
$$M(n,n(n-3)+2)\le
\max\{M(k,k(k-3)),\,2n-5\}.$$
An attaining graph at the left-hand endpoint must have a missing graph
consisting of a two-cycle disjoint from a $k$-vertex missing core whose
outdegree is exactly two everywhere and whose complement guarantees all
$2k$ missing pairs. No missing-indegree-two condition or two-move
assumption is imposed on this core.

**Proof.** Suppose the first maximum is attained at $I=2n-4$. There
are $h=2n-2$ missing arrows, so the failed-pair count is $\Delta=2$.
The proof of Theorem 27 applies because $I>0$. In its notation,
every missing outdegree is positive, the number $\ell$ of vertices
with missing outdegree one satisfies $\ell\ge2$, and
$\Delta\ge\lceil\ell/2\rceil+1$. Therefore $\ell=2$.
The total degree sum then forces all other missing outdegrees to be two.

Write $S$ for the two degree-one vertices and $f$ for their unique
missing-neighbor map. If $b=|f(S)\setminus S|\ge1$, the stronger
inequality in that proof gives
$$\Delta\ge\left\lceil\frac{\ell+3b}{2}\right\rceil\ge3,$$
which is impossible. Thus $f(S)\subseteq S$, and looplessness forces
the two-cycle on $S$. Its two missing pairs already fail, as both
vertices lie in $f(S)$.

Every missing pair with source outside $S$ must consequently be
guaranteed. If such a source $v$ has a missing arrow to $a\in S$,
let $b$ be the other cycle vertex. The pursuer at $b$ has closed
delivery neighborhood $V\setminus\{a\}$. The messenger at $v$
cannot move to $a$, so every legal move, including waiting, is
intercepted unless it is immediate receipt; a missing recipient cannot
be reached immediately. Hence the entire missing source row of $v$
fails, a contradiction. All missing arrows from outside $S$ therefore
stay outside $S$.

The missing graph is the disjoint union of the two-cycle and a
$k$-vertex outdegree-two graph. Exact missing-block addition gives
$I=I(G_k)$, because the complement of the two-cycle has no indirect
guarantees. This yields the right-hand equality.

Conversely, a graph attaining $M(k,k(k-3))=2k$ guarantees every
missing pair. Its missing graph has positive outgoing degree at every
vertex; otherwise the corresponding universal pursuer neighborhood
would force $I=0$. Adjoin a disjoint missing two-cycle. Exact addition
preserves $2k=2n-4$ guarantees, matching the staircase bound. The
maximum inequality follows because any larger integer than $2n-5$
must equal the staircase upper bound $2n-4$, and the equivalence then
forces the smaller-core maximum to have that value. $\square$

The already completed finite joint tables give $M(5,10)=3$ and
$M(6,18)=6$. Hence two of the gaps at that stage had stricter
upper bounds than the eventual staircase:
$$M(7,30)\le9,\qquad M(8,42)\le11.$$
These immediate bounds inherit the existing exhaustive finite table
proofs. The complete small-core checks below strengthen them and also
exclude second-step equality at orders nine and ten. Their completeness,
rather than a failed bounded construction search, supplies the exclusion.

## A safely reached root and the staircase from order eleven

A rooted missing core consists of vertices $K$ and one additional root
$\rho$, with missing rows $F(v)\subseteq(K\setminus\{v\})\cup\{\rho\}$
for $v\in K$. In its restricted delivery game, surviving pursuer positions
are in $K$. Receipt at the actual recipient $\rho$ remains immediate.
For a recipient in $K$, a messenger move to $\rho$ is useful only when
$\rho\in F(c)$ for the current pursuer $c$: otherwise the pursuer can
capture there. After a safe arrival the root delivers directly to the
recipient on the next move. Restricting surviving pursuer positions does
not remove this capture at an unsafe root arrival.

**Lemma (designation and exact functional replacement).** Designating
any vertex of an all-delivery missing core as $\rho$ and forgetting its
own row yields an all-delivery rooted interface. More generally, let every
core row contain a missing neighbor in $K$. Attach any loopless functional
missing graph $H$ at $\rho$, with no missing arrow in $H$ entering $\rho$,
and no other cross missing arrows. Then
$$I(G)=I_{\rm root}(K,\rho)+I(\overline H),$$
where the rooted count includes missing pairs whose recipient is $\rho$.

**Proof.** Designation follows the old strategy until receipt or safe
arrival at $\rho$; in the latter case the strengthened root row delivers
next. Receipt when $\rho$ is the actual recipient is immediate, even if
the pursuer is there.

For a core pair, an $H$ pursuer's unique missing neighbor lies in
$H\setminus\{\rho\}$. It is safely reachable from any core position
and directly delivers to every core recipient and to $\rho$. Thus a
rooted winning strategy extends whenever the pursuer leaves $K$.
A losing pursuer can remain in $K$, capturing every messenger excursion
into $H\setminus\{\rho\}$; visits to $\rho$ obey precisely the rooted
safe-arrival rule. Hence the core guarantees are exactly preserved.

For an $H$ pair the missing recipient differs from $\rho$. Against a
core pursuer choose its missing neighbor in $K$, which is safely reachable
from $H$ and directly delivers to that recipient. This also handles a
pursuer leaving $H$ during an internal winning strategy. Conversely,
a losing pursuer can remain in $H$ and capture every excursion into $K$.
Thus the $H$ guarantees are also exactly preserved. All waits and terminal
receipt are included. $\square$

For a functional missing map $f$, its pair $(s,f(s))$ is guaranteed
exactly when $s$ has missing indegree zero and $f(s)$ has missing indegree
one. Otherwise a predecessor of $s$, or a second predecessor of $f(s)$,
camps and blocks every nonterminal move. If both conditions hold,
$f(c)$ is a safe intermediary against every $c\ne s$. This proves the
functional count used by the attachment lemma directly.

**Proposition (rooted cores).** An all-delivery rooted interface with two
missing neighbors per core vertex exists at every core order $k\ge7$.
At $k=7$, with root 7, its rows are
$$\{2,7\},\ \{4,5\},\ \{0,1\},\ \{4,6\},\
\{0,3\},\ \{6,7\},\ \{2,5\}.$$
Its rooted guarantee has the retained finite actual-game proof in
`research/small-dense-rooted-certificates.json` and
`research/small-dense-rooted-deletion-certificates.json`. At $k=8$,
designate vertex 8 of the nine-core as root; at $k\ge9$ designate a
vertex of the direct core on $k+1$ vertices. Every row has an internal
missing neighbor, so exact functional replacement applies. In particular,
the seven-core with $\rho\to a\leftrightarrow b$ gives the retained
small value $M(10,73)=14$. The audit checks both positive and negative
transfer masks on fixed interfaces; the lemma itself is an ordinary proof.

**Corollary (the complete staircase from order eleven).** For every
$n\ge11$ and $1\le r\le n$,
$$M(n,n(n-3)+r)=2n-r-\lceil r/2\rceil-1.$$
Four messenger moves suffice; at every $n\ge16$ the earlier uniform
two-move construction remains available.

**Proof.** The first step was proved above. For $r=2$ adjoin a disjoint
missing two-cycle to the ordinary core on $n-2\ge9$ vertices.
For $r=3,4$, use the rooted core on $k=n-r\ge7$ vertices and attach
the functional $r$-vertex graph, choosing one of its roots as $\rho$.
The exact replacement identity gives $2k+\lfloor(r-2)/2\rfloor$.
For $r\ge5$ use the root-colored cycle and singleton construction,
including $k=0,1$. Every count meets Theorem 27. The fixed rooted
seven-core and nine-core certificates retain their four-move attached
bounds; larger designated cores have two-move strategies before
replacement and need at most three afterwards. $\square$

## Strict small values in the second through fourth steps

**Theorem.** The following are exact values, with literal attaining graphs:
$$
\begin{array}{c|rrrr}
 &n=7&n=8&n=9&n=10\\\hline
r=2&8&10&12&15\\
r=3&7&9&11&14\\
r=4&6&8&10&12
\end{array}
\qquad(m=n(n-3)+r).
$$
In particular the uniform staircase threshold eleven is sharp:
$M(10,74)=12<13$, the staircase value at that cell.

The ordinary seven- and eight-vertex endpoint cores needed below admit
complete small normal forms. In an all-delivery two-out missing core,
the two members of any row have disjoint missing rows and no missing
arrow between them. Otherwise source or predecessor camping loses a
missing pair. Normalize $F(0)=\{1,2\}$. If either neighbor points back
to 0, the other rows can be labeled
$F(1)=\{0,3\}$ and $F(2)=\{4,5\}$; otherwise they can be labeled
$F(1)=\{3,4\}$ and $F(2)=\{5,6\}$. These exhaust the possibilities,
without imposing any missing-indegree condition. Complete enumeration
of all remaining rows has no survivors at either order. The independent
chronological replay uses 227 and 4,307 prefixes respectively, recorded
in `research/small-dense-endpoint-independent-checks.json`. This is the
finite endpoint exclusion used here, not an assumption about two-move
delivery strategies.

Here are the finite and ordinary components of the proof. Write
$q(v)=d_F^+(v)$, $\Delta=2n-r-I$, $S=\{v:q(v)=1\}$,
$\ell=|S|$, and $e=\sum_v\max\{q(v)-2,0\}$. Positive $I$ implies
$q(v)>0$ everywhere; hence $\ell=r+e$. From the degree-one proof,
$\Delta\ge\lceil\ell/2\rceil+1$. Put $U=f(S)$,
$a=|U\cap S|$, $b=|U\setminus S|$, and let $\rho_0$ count vertices
in $S\setminus U$ whose image has exactly one preimage in $S$.
Its stronger bounds are
$$
\Delta\ge\ell-\rho_0+2b,\qquad
\Delta\ge
\begin{cases}
\max\{a+2b,\ell-a+b\},&b>0,\\
\max\{a,\ell-a+2\},&b=0.
\end{cases}
$$
Every row with source in $U$ is killed. An outside row pointing into $U$
is killed as well by the corresponding degree-one pursuer.

At $r=4$, equality in the staircase would require $\Delta=3$, forcing
$\ell=4,e=0,b=0,a=3,\rho_0=1$. The functional graph on $S$ is therefore
$\rho\to t_0\to a\leftrightarrow b$. Its three killed rows exhaust
the losses, and all other rows avoid $U$. Equality is equivalent to an
all-delivery safe-root two-out core on $n-4$ vertices.

At $r=3$, equality again means $\Delta=3$. For $\ell=4,e=1$ the same
functional path leaves a rooted core on $n-4$ vertices with one degree-three
row and all other degrees two. For $\ell=3,e=0$, the case $b\ge2$ is
excluded. The case $b=1$ would force $a=1,\rho_0\ge2$: the two vertices
outside $U$ would need distinct unique images, but the vertex of $S\cap U$
must also map to the outside image, a contradiction. Thus $b=0$, and $S$
is a three-cycle or a two-cycle with one incoming tail. All three pairs
fail, leaving a rooted two-out core on $n-3$ vertices (with unused root
in the three-cycle case).

Complete safe-root enumeration excludes two-out cores of orders 3 through 6
and one-degree-three cores of orders 3 through 6. The source test is
$F(c)\subseteq F(s)\cup\{s\}$ for distinct core vertices: it kills
row $s$. The predecessor test requires a cop row contained in the core
whose neighbors' completed rows have a common missing recipient. A cop
row using the root is not pruned by this latter test. There is no
missing-indegree restriction. Two-out rows using the root have normalized
initial rows $F(0)=\{1,\rho\}$ and either $F(1)=\{0,2\}$ or
$F(1)=\{2,3\}$. Rows without root use the two ordinary depth-two forms.
A unique degree-three row is normalized to $\{1,2,\rho\}$ or
$\{1,2,3\}$. Every other loopless row is enumerated.

The two-out families have 4, 14, 72, 1,168 prefix nodes at orders 3, 4, 5, 6;
only the last has static leaves, six in total. The one-degree-three
families have 4, 74, 1,442, 29,852 nodes, with twelve static leaves at order 6
only. All eighteen leaves fail in the full actual game after functional
attachment; both winning and losing ranks are checked. These complete
finite exclusions prove the strict third- and fourth-step upper bounds
in the table. The seven-core attachment supplies its exceptional $r=3$
entry at order 10.

For $r=2$, the earlier equivalence and complete ordinary seven/eight-core
exclusions first rule out $\Delta=2$ at orders 7 through 10. At order 10
this gives the claimed upper bound 15. At orders 7, 8, 9 suppose $\Delta=3$.
Then $\ell=2,3,4$. The $\ell=4$ case leaves the four-vertex functional
path and a rooted core of order $n-4$ with excess 2: one degree-four row
or two degree-three rows. All six profiles at orders 3, 4, 5 have zero static
leaves in complete all-row enumeration. Their prefix counts are
1, 3, 8, 69, 396, 4,211. The $\ell=3$ case leaves a rooted core of order
$n-3$ with one degree-three row, already excluded.

When $\ell=2$, all other degrees are two. A closed two-cycle forces
every outside row to avoid it, since an additional killed row would give
four losses. Exact missing-block addition then bounds $I$ by the ordinary
core values at orders 5, 6, 7, all below $2n-5$. Otherwise the only shape
with at most three losses is $c\to d\to x$, with degrees 1, 1, 2.
The rows at $d,x$ exhaust the losses. Put $Y=F(x)$. The degree-one pursuer
at $d$ kills every missing column into $Y$; $d\notin Y$, or the additional
pair $(c,d)$ would fail. Every remaining good row avoids $\{d,x\}\cup Y$,
except $(c,d)$. If $c\in Y$, removing these four special vertices leaves
an ordinary universal two-out core of order $n-4\le5$, impossible by the
small tables. Otherwise it leaves a rooted two-out core of order
$n-5=2,3,4$, root $c$. The order-two case is immediately source-camped;
the other two are among the complete exclusions above. This proves
$\Delta\ge4$ and the strict upper $2n-6$ at orders 7, 8, 9.

For the lower bounds at $r=4$, take a missing two-cycle $0\leftrightarrow1$
and two free roots $2\to0$, $3\to0$. Attach the alternating colored cycle
and, when necessary, singleton on vertices 4 onward, using roots 2, 3.
All four functional pairs fail, while the previous routing proof guarantees
all $2(n-4)$ new pairs in at most three moves. This attains $2n-8$.
At $r=3$, orders 7, 8, 9, add missing arrow $4\to6$ to those respective
graphs. At $r=2$, add also $(5,6)$, $(5,7)$, or $(4,8)$ respectively.
For order 10, $r=2$, add missing arrow $1\to3$ to the seven-core
three-vertex attachment. These finite modifications have full game
certificates, without any assertion that arbitrary additions preserve
their guarantees.

The independent finite review covers every normalized case and degree
profile above, plus all eighteen negative attached graphs, in
`research/small-case-rooted-independent-review.json`. The literal positive
graphs and ranks are in `research/small-dense-two-root-certificates.json`
and `research/small-dense-second-step-certificates.json`. The ordinary
reduction and finite game checks are distinct from the generic Lean
results retained elsewhere in the paper.

## The remaining first steps

**Theorem.** The first dense-step values at orders seven through ten are
$$M(7,29)=8,\quad M(8,41)=11,\quad M(9,55)=14,\quad M(10,71)=16.$$
Together with the preceding results, this determines every dense cell in
the original unresolved list. Together with the existing complete tables
through order 6 and the constructions for $r\ge5$, every admissible
cell of the final dense band is exact and has an explicit attaining graph.
The eventual staircase is exact throughout the final band at every
order at least eleven.

**Proof of the upper bounds.** The seven-vertex value comes from the
independently replayed complete finite table. At the other orders put
$h=2n-1$ and $\Delta=h-I$. The staircase bound gives $\Delta\ge2$.
As above, $\ell=1+e$ and $\Delta\ge\lceil\ell/2\rceil+1$.

Suppose first that $\Delta=2$. If $\ell=2$, the degree-one image count
forces a disjoint missing two-cycle and an ordinary universal core on
$k=n-2$ vertices with $2k+1$ missing arrows. At $n=8$, the six-vertex
maximum excludes this; at $n=9$, the exact value $M(7,27)=10$ excludes
it. At $n=10$, it would be a universal $(8,39)$ core. Such a core has
no missing degree zero or one, so one degree is three and the other seven
are two.
Normalize the unique degree-three row to $F(0)=\{1,2,3\}$. Complete
enumeration of every other loopless degree-two row, using the two camping
predicates, has no survivors. The primary search visits 3,322 prefixes;
the independent chronological replay visits 189,190 prefixes.

If $\ell=1$, all other degrees are two. Write the unique degree-one row
as $c\to x$ and put $Y=F(x)$. The two pairs from $x$ exhaust the losses.
Every missing column into $Y$ fails under the pursuer at $c$, and every
other nonfunctional row pointing to $x$ would be killed. Thus all other
good rows avoid $Y\cup\{x\}$. If $c\in Y$, removing $c,x$ and the
other member of $Y$ leaves an ordinary universal two-out core of order
$n-3=5,6,7$, excluded by the small-order results. Otherwise removing
$\{c,x\}\cup Y$ leaves a safely rooted two-out core of order
$n-4=4,5,6$, root $c$, among the complete exclusions above. Therefore
$\Delta\ge3$ at orders 8, 9, 10, giving respective upper bounds 12, 14, 16.

At order 8 it remains to exclude $\Delta=3$. Here $\ell=1,2,3,4$.
For $\ell=4$, the four-vertex functional path leaves a rooted four-core
with total excess 3. Its degree profiles are $(5,2,2,2)$,
$(4,3,2,2)$, and $(3,3,3,2)$. Complete all-row enumeration gives no
static leaves; degree 5 is an empty row domain. For $\ell=3$, the closed
functional triple leaves a rooted five-core with excess 2, namely the
one-degree-four or two-degree-three profiles already excluded above.

For $\ell=2$, the other degrees are two except for one degree-three row.
A closed two-cycle would reduce the score to a six-vertex core and is
excluded by $M_V(6)=7$. Otherwise only $c\to d\to x$ with
$q(c)=q(d)=1,q(x)=2$ is compatible with three losses; a higher degree
at $x$, two distinct outside images, or a common outside image gives at
least four. The earlier reduction with $Y=F(x)$ leaves either an ordinary
four-core with all degrees at least two, impossible by its known maximum,
or a rooted three-core with all degrees two and at most one degree-three
row. Both rooted profiles were excluded.

For $\ell=1$, normalize $F(0)=\{1\}$. Up to relabeling,
$F(1)=\{0,2\}$ or $F(1)=\{2,3\}$, and all other rows have degree two.
Complete enumeration of all such rows has no completion with at most
three distinct forced losses. The two searches use different row orders:
the primary combined count is 578 prefixes; the independent counts are
12,160 and 9,934. To avoid double counting, each source stores the set of
its marked missing recipients. A source-camping witness marks its entire
row. A predecessor-camping witness at $c$ marks the shared missing
recipient column, except for initial source $c$, where that cop placement
is excluded. The size of the union, not the sum of witness counts, is
the pruning bound. Every pruned prefix therefore forces at least four
different lost pairs in every completion. This completes the upper bound
11 at order 8.

**Literal lower bounds.** The following missing rows, listed in source
order, give the four attaining graphs:
$$
\begin{array}{c|l}
n&F(0),F(1),\ldots,F(n-1)\\\hline
7&1;\ 0;\ 01;\ 0;\ 256;\ 346;\ 23\\
8&1;\ 0;\ 0;\ 0;\ 256;\ 367;\ 247;\ 34\\
9&123;\ 245;\ 06;\ 16;\ 05;\ 46;\ 7;\ 8;\ 7\\
10&27;\ 345;\ 014;\ 46;\ 03;\ 67;\ 25;\ 8;\ 9;\ 8
\end{array}
$$
Each string denotes the set of its digit labels; all labels are single
digits in this table. The order-nine graph is the three-vertex attachment
of a rooted six-core with two degree-three rows; its root is 6.
The literal full graphs have respective exact counts 8, 11, 14, 16 and
delivery bounds 3, 3, 5, 4 from both game solvers and full rank replay.
These finite bounds retain the four-move staircase guarantee from order 11
and the uniform two-move guarantee from 16.

The constructor is `src/small_dense_first_step.py`, with fixed game records
in `research/small-dense-first-step-certificates.json`. The independent
upper-bound replay is
`research/small-case-first-step-independent-review.json`; the literal
game replay is `research/small-case-first-step-literal-review.json`.
These are ordinary reductions and finite certificate proofs, with no
claim that the new small classification has been formalized in Lean.
$\square$

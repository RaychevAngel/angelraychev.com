# Attainment across densities and losses near completeness

Angel Raychev proposed that, for every sufficiently large $n$, the missing-pair bound should be attained at **every** integer budget
$$2n\le m\le n(n-3).$$
Theorem 44 proves this conjecture at every $n\ge115$ using the explicit constructions of Theorems 38, 52, 58, and 59. This section gives the separate exact-budget probability argument and the dense counting and composition principles. Raychev also proposed separating existence from explicit constructions and studying how domination destroys missing pairs as the graph approaches completeness. These distinctions motivate the statements below; their proofs were developed in the September 2026 follow-up investigation.

Write $L=n(n-1)$ and $h=L-m$. Thus $h$ is the number of missing nonloop arcs, and always $I(G)\le h$.

## An exact-budget existence theorem

**Theorem 25.** Let $n\ge4$, let $0<m<L$ be an integer, and put $p=m/L$. If
$$
(n-3)p^2(1-p)>5\log n,
$$
then some graph with exactly $n$ vertices and $m$ arcs guarantees every source--recipient pair within two messenger moves. In particular,
$$M(n,m)=L-m.$$

**Proof.** Apply Theorem 54 with the routing set equal to the entire
vertex set: $H=V$, $b=n$, and $a=m$. Since $n\ge4$,
$$5\log n>4\log n+\log(8/3),$$
the displayed hypothesis implies its condition. Theorem 54 supplies an
exactly $m$-arc graph with a safe two-move intermediary for every legal
source--recipient--pursuer triple, proving the assertion. $\square$

This is an exact integer-budget existence theorem, rather than a statement about an expected number of arcs. It also gives a finite randomized search: sample graphs with exactly $m$ arcs and check the safe-intermediate condition. No practical running-time bound near the threshold is asserted.

**Corollary 26.** There is an absolute $N$ such that, for every $n\ge N$ and every integer budget
$$
\left\lceil10n^{3/2}\sqrt{\log n}\right\rceil\le m\le n(n-3),
$$
we have $M(n,m)=n(n-1)-m$. Attainment can always be achieved with delivery in at most two moves.

**Proof.** Let $p=m/L$ and $h=L-m$. For $n\ge6$, we have $n-3\ge n/2$. If $p\le1/2$, the lower bound on $m$ gives $p\ge10\sqrt{\log n/n}$ and therefore
$$
(n-3)p^2(1-p)\ge25\log n>5\log n.
$$
If $p\ge1/2$ and $h\ge100n\log n$, then $1-p=h/L\ge100\log n/n$, giving
$$
(n-3)p^2(1-p)\ge\frac{100}{8}\log n>5\log n.
$$
Theorem 25 covers both cases.

For the remaining dense budgets use Theorem 20 with
$$D=\left\lfloor(n/2)^{1/4}\right\rfloor.$$
For all sufficiently large $n$ its hypotheses hold, and its upper endpoint satisfies
$$L_D(n)\ge n(D/4+1)-1.$$
Since $D$ grows as a positive constant times $n^{1/4}$, this endpoint eventually exceeds $100n\log n$. Theorem 20 supplies every integer missing-arc count from $2n$ to $L_D(n)$, and the probabilistic range supplies the rest. The intervals overlap, so no admissible integer budget is omitted. Both proofs give two-move delivery. $\square$

The absolute threshold is not optimized or asserted to be moderate. In particular, this corollary does not establish the full interval at $n=52$. The general sparse interval between $2n$ and order $n^{3/2}\sqrt{\log n}$ remains outside its conclusion.

## A growing loss in the final dense band

Let $F$ be the loopless directed complement of $G$, and write $q(v)=d_F^+(v)$. The number
$$\Delta=h-I(G)$$
counts missing pairs that fail to guarantee delivery.

**Theorem 27.** For $n\ge2$ and every admissible integer $n\le h<2n$,
$$
I(G)\le h-\left\lceil\frac{2n-h}{2}\right\rceil-1.
$$
Equivalently, writing $r=2n-h$, we have
$$
M\bigl(n,n(n-3)+r\bigr)\le2n-r-\lceil r/2\rceil-1
\qquad(1\le r\le n).
$$

**Proof.** If $I(G)=0$, the conclusion holds: the right-hand side is increasing with $h$ and at $h=n$ equals $\lfloor(n-2)/2\rfloor\ge0$. Assume henceforth that $I(G)>0$.

Every $q(v)$ is positive. Otherwise a vertex $c$ with $q(c)=0$ can intercept every nonterminal departure from any other source, while its own source row has no missing pair. Put
$$
S=\{c:q(c)=1\},\qquad \ell=|S|.
$$
Since $h\ge\ell+2(n-\ell)$, we have $\ell\ge2n-h\ge1$. For $c\in S$ let $f(c)$ be its unique missing neighbor; thus $f(c)\ne c$. Set
$$U=f(S),\qquad a=|U\cap S|,\qquad b=|U\setminus S|.$$

Every source $x\in U$ loses all of its $q(x)$ missing pairs. To see this, choose $c\in S$ with $f(c)=x$. The pursuer's closed outgoing neighborhood in $G$ is $V\setminus\{x\}$. It can wait at $c$ while the messenger waits at $x$ and intercept every nonterminal departure. An indirect recipient cannot be reached by a direct departure.

A second obstruction applies when two distinct vertices $c,c'\in S$ have the same image $x$. The missing pair $(c,x)$ loses against a pursuer starting at $c'$, whose closed outgoing neighborhood contains every possible nonterminal intermediate vertex.

Let $R$ be the set of $c\in S\setminus U$ for which $f(c)$ has exactly one preimage in $S$, and put $\rho=|R|$. Every missing edge with tail in $S\setminus R$ loses by one of the two obstructions. The killed rows in $U\setminus S$ have at least two missing edges each, with tails outside $S$. These losses are disjoint, so
$$\Delta\ge\ell-\rho+2b.$$

If $b\ge1$, then $\rho\le\ell-a$ because $R\subseteq S\setminus U$, and $\rho\le a+b$ because its members have distinct images in $U$. Consequently
$$
\Delta\ge\max\{a+2b,\ell-a+b\}
\ge\left\lceil\frac{\ell+3b}{2}\right\rceil
\ge\lceil\ell/2\rceil+1.
$$
If $b=0$, the function $f$ maps $S$ into itself without fixed points. Its finite functional graph has a directed cycle of length at least two. Every cycle vertex belongs to $U$ and already has a preimage in $U$, so it cannot also be the image of a member of $R$: that member is outside $U$ and would give a second preimage. Thus $\rho\le a-2$, as well as $\rho\le\ell-a$. It follows that
$$
\Delta\ge\max\{a,\ell-a+2\}\ge\lceil\ell/2\rceil+1.
$$
Using $\ell\ge2n-h$ proves the bound. $\square$

Thus the forced loss increases as $2,2,3,3,4,4,\ldots$ as the arc budget moves one, two, three, four, five, six, and further steps above $n(n-3)$. At the other endpoint, $h=n$, the bound agrees with Theorem 13.

## Combining two-move constructions

**Lemma 28.** Suppose a missing-edge graph $F$ is a disjoint union of graphs $F_i$, each with positive outgoing degree at every vertex. Let $G_i$ be the complement on its own block. If an indirect pair in $G_i$ can be guaranteed within two messenger moves, then it remains guaranteed in the complement $G$ of the entire $F$.

**Proof.** Let the source and recipient lie in block $i$. If the initial pursuer also lies there, the original two-move strategy chooses an intermediate vertex outside its closed outgoing neighborhood. The same is true in $G$. The pursuer may respond by moving outside the block, but this cannot prevent receipt on the messenger's next move.

If the pursuer starts at $c$ in another block, choose any outgoing $F$-neighbor $u$ of $c$ in that block. The arcs $s\to u$ and $u\to t$ are present in $G$ because they cross blocks, whereas $c\to u$ is absent. Also $u\ne c,s,t$. This gives the required safe two-move delivery. $\square$

The lemma concerns two-move strategies. No preservation theorem for arbitrary longer strategies under this join is assumed.

**Theorem 29.** Let $r\ge2$ and $k=n-r$. If $k\ge10$,
then
$$M\bigl(n,n(n-3)+r\bigr)=2n-r-\lceil r/2\rceil-1.$$
An explicit polynomial construction attains this value with every
counted pair delivered within two messenger moves.

**Proof.** Use the functional missing graph on $r$ vertices, with
$j=\lfloor(r-2)/2\rfloor$ guaranteed pairs. On the other $k$
vertices use the direct missing core in Theorem 58, which has $2k$
guaranteed missing pairs. Both blocks have positive missing outdegree,
so Lemma 28 preserves all $j+2k$ guarantees in the complement of their
disjoint union. There are $r+2k=2n-r$ missing arcs, and
$$j+2k=2n-r-\lceil r/2\rceil-1.$$
Theorem 27 gives optimality. $\square$

This includes the former $k\ge52$ range and the separate 26-vertex
block, without any finite girth-growth dependency. In missing-budget
notation the range is $n+10\le h\le2n-2$.

## A restriction on permutation constructions

**Proposition 30.** Suppose the two outgoing neighbors of each vertex are $\alpha(v)$ and $\beta(v)$, where $\alpha,\beta$ are commuting permutations, both images differ from $v$, and $\alpha(v)\ne\beta(v)$. Then $I(G)\le n$. In fact all indirect guarantees are decided by a two-move criterion.

**Proof.** Fix a recipient $t$ and put $s_t=\alpha^{-1}\beta^{-1}(t)$. Commutation gives
$$
N^+(s_t)=\{\beta^{-1}(t),\alpha^{-1}(t)\}=N^-(t).
$$
The predecessor camping lemma excludes every indirect source except possibly $s_t$: a pursuer starting at $s_t$ can intercept the messenger when it first reaches a predecessor of $t$. Thus each recipient contributes at most one pair.

When $s_t\ne t$, the pair $(s_t,t)$ is missing because neither predecessor of a loopless recipient equals that recipient. This pair is guaranteed exactly when no $c\ne s_t$ has $N^-(t)\subseteq C(c)$. Necessity is the same camping lemma. For sufficiency, from each legal initial pursuer position choose $u\in N^-(t)\setminus C(c)$. The messenger moves from $s_t$ to this safe predecessor and then delivers. $\square$

The bound is sharp: on $\mathbb Z/7\mathbb Z$, take arcs $x\to x+1$ and $x\to x+3$. For recipient zero the predecessors are $6,4$, and the only closed outgoing neighborhood containing both is that of $3$. The criterion gives $(3,0)$; translation gives exactly the seven pairs $(s,s+4)$. Since $n(n-3)>n$ for $n\ge5$, commuting permutations cannot supply a universal vertex-extremal graph in that range. Noncommutation is necessary, not asserted sufficient.

## An extension that fills the small dense offsets

**Proposition 31.** Let $r\ge2$, $k\ge1$, and $n=r+k$. If
$$k\le\binom{\lfloor(r-1)/2\rfloor}{2},$$
then a deterministic polynomial construction attains
$$M\bigl(n,n(n-3)+r\bigr)=2n-r-\lceil r/2\rceil-1,$$
with a two-move strategy for every counted pair.

**Proof.** The functional construction has
$j=\lfloor(r-2)/2\rfloor$ guaranteed pairs. Its vertices with no
missing incoming arc are the $j$ branch sources, together with the
spare vertex when $r$ is odd. There are exactly
$q=\lfloor(r-1)/2\rfloor$ such roots. Give each added vertex a
different two-element missing-neighbor set among these roots.
The functional-root argument in Theorem 58 proves all $2k$ new
missing pairs and preserves the original $j$ pairs in two moves.
The identity $j+2k=2n-r-\lceil r/2\rceil-1$ and Theorem 27 prove
equality. $\square$

This strengthens the former bound
$k\le\binom{\lfloor(r-2)/2\rfloor}{2}$ when $r$ is odd and
preserves it when $r$ is even. In particular, all the earlier
$n\ge75$, $1\le n-r\le51$ cases remain covered.

Theorem 58 supplies the common direct construction and complete
proof. The counting bound and binary two-move block-composition principle are
also formalized in `DenseStaircase.lean` and `ComplementarySum.lean`.
The commuting-permutation restriction and supplementary construction
claims retain their separate proof boundaries.

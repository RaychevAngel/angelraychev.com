# Attainment across densities and losses near completeness

Angel Raychev proposed that, for every sufficiently large $n$, the missing-pair bound should be attained at **every** integer budget
$$2n\le m\le n(n-3).$$
This remains a conjecture. The next results prove a substantial interval of it and determine the maximum across most of the remaining dense band. Raychev also proposed separating existence from explicit constructions and studying how domination destroys missing pairs as the graph approaches completeness. These distinctions motivate the statements below; their proofs were developed in the September 2026 follow-up investigation.

Write $L=n(n-1)$ and $h=L-m$. Thus $h$ is the number of missing nonloop arcs, and always $I(G)\le h$.

## An exact-budget existence theorem

**Theorem 25.** Let $n\ge4$, let $0<m<L$ be an integer, and put $p=m/L$. If
$$
(n-3)p^2(1-p)>5\log n,
$$
then some graph with exactly $n$ vertices and $m$ arcs guarantees every source--recipient pair within two messenger moves. In particular,
$$M(n,m)=L-m.$$

**Proof.** Choose each nonloop arc independently with probability $p$. Fix distinct vertices $s,t$ and a legal initial pursuer position $c\ne s$. Each $u\notin\{s,t,c\}$ is a safe intermediate vertex when
$$s\to u,\quad u\to t\quad\text{are present, and}\quad c\to u\quad\text{is absent}.$$
These three distinct arcs give probability $p^2(1-p)$, including when $c=t$. Different candidates use disjoint sets of arcs, so their success events are independent. There are at least $n-3$ candidates. The probability that this triple has no safe intermediate is at most
$$\exp\bigl(-(n-3)p^2(1-p)\bigr).$$
There are fewer than $n^3$ triples. The probability that any triple fails is therefore less than $n^{-2}$ under the hypothesis.

It remains to enforce the exact arc count. That count has the binomial distribution with parameters $L,p$, and $m$ is a mode because $p=m/L$. Indeed, the ratio of the probabilities at $j+1$ and $j$ is
$$\frac{(L-j)p}{(j+1)(1-p)},$$
which decreases with $j$, is greater than one at $j=m-1$, and is less than one at $j=m$. Hence the probability of exactly $m$ arcs is at least $1/(L+1)>n^{-2}$. It exceeds the entire failure probability, so at least one graph with exactly $m$ arcs satisfies every safe-intermediate condition.

In that graph the messenger moves to its chosen intermediate vertex. The pursuer neither occupies that vertex nor can reach it on its response. The messenger then reaches the recipient, and receipt precedes any further interception. All $L-m$ missing pairs are consequently guaranteed. $\square$

This is an exact integer-budget existence theorem, rather than a statement about an expected number of arcs. It also gives a finite randomized search: sample graphs with exactly $m$ arcs and check the safe-intermediate condition. No practical running-time bound near the threshold is asserted.

**Corollary 26.** There is an absolute $N$ such that, for every $n\ge N$ and every integer budget
$$
\left\lceil10n^{3/2}\sqrt{\log n}\right\rceil\le m\le n(n-3),
$$
we have $M(n,m)=n(n-1)-m$. Attainment can always be achieved with delivery in at most two moves.

**Proof.** Let $p=m/L$ and $h=L-m$. For $n\ge6$, we have $n-3\ge n/2$. If $p\le1/2$, the lower bound on $m$ gives $p\ge10\sqrt{\log n/n}$ and therefore
$$
(n-3)p^2(1-p)\ge25\log n>5\log n.
$$
If $p\ge1/2$ and $h\ge100n\log n$, then $1-p=h/L\ge100\log n/n$, giving
$$
(n-3)p^2(1-p)\ge\frac{100}{8}\log n>5\log n.
$$
Theorem 25 covers both cases.

For the remaining dense budgets use Theorem 20 with
$$D=\left\lfloor(n/2)^{1/4}\right\rfloor.$$
For all sufficiently large $n$ its hypotheses hold, and its upper endpoint satisfies
$$L_D(n)\ge n(D/4+1)-1.$$
Since $D$ grows as a positive constant times $n^{1/4}$, this endpoint eventually exceeds $100n\log n$. Theorem 20 supplies every integer missing-arc count from $2n$ to $L_D(n)$, and the probabilistic range supplies the rest. The intervals overlap, so no admissible integer budget is omitted. Both proofs give two-move delivery. $\square$

The absolute threshold is not optimized or asserted to be moderate. In particular, this corollary does not establish the full interval at $n=52$. The general sparse interval between $2n$ and order $n^{3/2}\sqrt{\log n}$ remains outside its conclusion.

## A growing loss in the final dense band

Let $F$ be the loopless directed complement of $G$, and write $q(v)=d_F^+(v)$. The number
$$\Delta=h-I(G)$$
counts missing pairs that fail to guarantee delivery.

**Theorem 27.** For $n\ge2$ and every admissible integer $n\le h<2n$,
$$
I(G)\le h-\left\lceil\frac{2n-h}{2}\right\rceil-1.
$$
Equivalently, writing $r=2n-h$, we have
$$
M\bigl(n,n(n-3)+r\bigr)\le2n-r-\lceil r/2\rceil-1
\qquad(1\le r\le n).
$$

**Proof.** If $I(G)=0$, the conclusion holds: the right-hand side is increasing with $h$ and at $h=n$ equals $\lfloor(n-2)/2\rfloor\ge0$. Assume henceforth that $I(G)>0$.

Every $q(v)$ is positive. Otherwise a vertex $c$ with $q(c)=0$ can intercept every nonterminal departure from any other source, while its own source row has no missing pair. Put
$$
S=\{c:q(c)=1\},\qquad \ell=|S|.
$$
Since $h\ge\ell+2(n-\ell)$, we have $\ell\ge2n-h\ge1$. For $c\in S$ let $f(c)$ be its unique missing neighbor; thus $f(c)\ne c$. Set
$$U=f(S),\qquad a=|U\cap S|,\qquad b=|U\setminus S|.$$

Every source $x\in U$ loses all of its $q(x)$ missing pairs. To see this, choose $c\in S$ with $f(c)=x$. The pursuer's closed outgoing neighborhood in $G$ is $V\setminus\{x\}$. It can wait at $c$ while the messenger waits at $x$ and intercept every nonterminal departure. An indirect recipient cannot be reached by a direct departure.

A second obstruction applies when two distinct vertices $c,c'\in S$ have the same image $x$. The missing pair $(c,x)$ loses against a pursuer starting at $c'$, whose closed outgoing neighborhood contains every possible nonterminal intermediate vertex.

Let $R$ be the set of $c\in S\setminus U$ for which $f(c)$ has exactly one preimage in $S$, and put $\rho=|R|$. Every missing edge with tail in $S\setminus R$ loses by one of the two obstructions. The killed rows in $U\setminus S$ have at least two missing edges each, with tails outside $S$. These losses are disjoint, so
$$\Delta\ge\ell-\rho+2b.$$

If $b\ge1$, then $\rho\le\ell-a$ because $R\subseteq S\setminus U$, and $\rho\le a+b$ because its members have distinct images in $U$. Consequently
$$
\Delta\ge\max\{a+2b,\ell-a+b\}
\ge\left\lceil\frac{\ell+3b}{2}\right\rceil
\ge\lceil\ell/2\rceil+1.
$$
If $b=0$, the function $f$ maps $S$ into itself without fixed points. Its finite functional graph has a directed cycle of length at least two. Every cycle vertex belongs to $U$ and already has a preimage in $U$, so it cannot also be the image of a member of $R$: that member is outside $U$ and would give a second preimage. Thus $\rho\le a-2$, as well as $\rho\le\ell-a$. It follows that
$$
\Delta\ge\max\{a,\ell-a+2\}\ge\lceil\ell/2\rceil+1.
$$
Using $\ell\ge2n-h$ proves the bound. $\square$

Thus the forced loss increases as $2,2,3,3,4,4,\ldots$ as the arc budget moves one, two, three, four, five, six, and further steps above $n(n-3)$. At the other endpoint, $h=n$, the bound agrees with Theorem 13.

## Combining two-move constructions

**Lemma 28.** Suppose a missing-edge graph $F$ is a disjoint union of graphs $F_i$, each with positive outgoing degree at every vertex. Let $G_i$ be the complement on its own block. If an indirect pair in $G_i$ can be guaranteed within two messenger moves, then it remains guaranteed in the complement $G$ of the entire $F$.

**Proof.** Let the source and recipient lie in block $i$. If the initial pursuer also lies there, the original two-move strategy chooses an intermediate vertex outside its closed outgoing neighborhood. The same is true in $G$. The pursuer may respond by moving outside the block, but this cannot prevent receipt on the messenger's next move.

If the pursuer starts at $c$ in another block, choose any outgoing $F$-neighbor $u$ of $c$ in that block. The arcs $s\to u$ and $u\to t$ are present in $G$ because they cross blocks, whereas $c\to u$ is absent. Also $u\ne c,s,t$. This gives the required safe two-move delivery. $\square$

The lemma concerns two-move strategies. No preservation theorem for arbitrary longer strategies under this join is assumed.

**Theorem 29.** For every integer $n$ and every $2\le r\le n-52$,
$$
M\bigl(n,n(n-3)+r\bigr)=2n-r-\lceil r/2\rceil-1.
$$
Equivalently, equality in Theorem 27 holds throughout
$$n+52\le h\le2n-2.$$
There is an explicit attaining construction at every such integer budget.

**Proof.** Put $k=n-r\ge52$. On a block of $r$ vertices use the functional missing-edge extremizer from Theorem 13. Explicitly, put $j=\lfloor(r-2)/2\rfloor$ and use vertices $a,b,s_i,t_i$ for $1\le i\le j$, with an additional vertex $z$ when $r$ is odd. Its missing arcs are
$$s_i\to t_i,\qquad t_i\to a,\qquad a\to b,\qquad b\to a,$$
together with $z\to a$ when needed. Every vertex has exactly one missing outgoing arc. Its complement guarantees the $j$ pairs $(s_i,t_i)$ within two moves, by the proof of Theorem 13.

On a disjoint block of $k$ vertices, orient Euler circuits in the four-regular girth-six graph of Theorem 19. This missing-edge graph has two incoming and two outgoing arcs at every vertex. Lemma 18 guarantees all $2k$ missing pairs in its complement within two moves.

Take the disjoint union of these missing-edge graphs and complement it. It has $n=r+k$ vertices and $h=r+2k=2n-r$ missing arcs. Lemma 28 preserves at least
$$
j+2k=\lfloor(r-2)/2\rfloor+2(n-r)
=2n-r-\lceil r/2\rceil-1
$$
guaranteed missing pairs. Theorem 27 supplies the matching upper bound. $\square$

The attaining construction uses the explicit finite girth-growth certificate when $52\le k<130$ and the ordinary all-order growth proof thereafter. The interval is nonempty for $n\ge54$. It leaves $r=1$ and the bounded-offset range $n-51\le r\le n-1$ outside its uniform conclusion; $r=n$ is already covered by Theorem 13. The existing 26-vertex incidence block also gives equality at $r=n-26$ whenever $r\ge2$, by the same join.

## A restriction on permutation constructions

**Proposition 30.** Suppose the two outgoing neighbors of each vertex are $\alpha(v)$ and $\beta(v)$, where $\alpha,\beta$ are commuting permutations, both images differ from $v$, and $\alpha(v)\ne\beta(v)$. Then $I(G)\le n$. In fact all indirect guarantees are decided by a two-move criterion.

**Proof.** Fix a recipient $t$ and put $s_t=\alpha^{-1}\beta^{-1}(t)$. Commutation gives
$$
N^+(s_t)=\{\beta^{-1}(t),\alpha^{-1}(t)\}=N^-(t).
$$
The predecessor camping lemma excludes every indirect source except possibly $s_t$: a pursuer starting at $s_t$ can intercept the messenger when it first reaches a predecessor of $t$. Thus each recipient contributes at most one pair.

When $s_t\ne t$, the pair $(s_t,t)$ is missing because neither predecessor of a loopless recipient equals that recipient. This pair is guaranteed exactly when no $c\ne s_t$ has $N^-(t)\subseteq C(c)$. Necessity is the same camping lemma. For sufficiency, from each legal initial pursuer position choose $u\in N^-(t)\setminus C(c)$. The messenger moves from $s_t$ to this safe predecessor and then delivers. $\square$

The bound is sharp: on $\mathbb Z/7\mathbb Z$, take arcs $x\to x+1$ and $x\to x+3$. For recipient zero the predecessors are $6,4$, and the only closed outgoing neighborhood containing both is that of $3$. The criterion gives $(3,0)$; translation gives exactly the seven pairs $(s,s+4)$. Since $n(n-3)>n$ for $n\ge5$, commuting permutations cannot supply a universal vertex-extremal graph in that range. Noncommutation is necessary, not asserted sufficient.

## An extension that fills the small dense offsets

**Proposition 31.** Let $r\ge2$, $k\ge1$, and $n=r+k$. Put $j=\lfloor(r-2)/2\rfloor$. If
$$k\le\binom j2,$$
then an explicit graph attains
$$
M\bigl(n,n(n-3)+r\bigr)=2n-r-\lceil r/2\rceil-1.
$$
In particular, for every $n\ge75$ this holds at each offset $k=n-r$ with $1\le k\le51$.

**Proof.** Begin with the functional missing-edge graph on $r$ vertices from Theorem 29: its vertices are $a,b,s_i,t_i$ for $1\le i\le j$, with an extra $z$ if $r$ is odd, and its arcs are
$$a\to b,\quad b\to a,\quad s_i\to t_i,\quad t_i\to a,$$
together with $z\to a$ when needed. Add a set $H$ of $k$ vertices. For each $v\in H$ choose a distinct two-element subset $A_v\subseteq\{s_1,\ldots,s_j\}$ and give $v$ precisely those two outgoing missing arcs. Add no other missing arcs. These choices are possible by the assumed inequality. The resulting missing-edge graph $F$ has $n$ vertices and $h=r+2k$ arcs.

We show that its complement guarantees each pair $(v,t)$ with $v\in H$ and $t\in A_v$. If the pursuer starts at a functional vertex $c$, let $u$ be its unique outgoing missing neighbor. This vertex lies among $a,b,t_1,\ldots,t_j$, so $v\to u\to t$ are present arcs of the complement while $c\to u$ is absent. If the pursuer starts at another vertex $c\in H\setminus\{v\}$, distinctness and equal cardinality give an element $u\in A_c\setminus A_v$. Then $v\to u$ is present, and $u\to t$ is present because $u=s_\ell$ has only $t_\ell$ as a missing neighbor, whereas $t$ is one of the $s_i$. Also $u\ne t$ because $t\in A_v$. In each case $u$ is distinct from the pursuer and from both endpoints, and cannot be reached by the pursuer on its next move. This proves all $2k$ of these guarantees in two moves.

Each original pair $(s_i,t_i)$ remains guaranteed as well. Against a functional pursuer $c\ne s_i$, its unique missing neighbor $u$ is neither endpoint: no functional missing arc enters $s_i$, and the only one entering $t_i$ starts at $s_i$. Hence $s_i\to u\to t_i$ are present and safe. Against a pursuer $c\in H$, choose $s_\ell\in A_c$ with $\ell\ne i$, which is possible because $A_c$ has two members. The route $s_i\to s_\ell\to t_i$ is present and safe. Thus at least $j+2k$ missing pairs are guaranteed.

As in Theorem 29,
$$j+2k=2n-r-\lceil r/2\rceil-1,$$
and Theorem 27 supplies the upper bound. Finally, if $n\ge75$ and $1\le k\le51$, then $r=n-k\ge24$, so $j\ge11$ and $\binom j2\ge55\ge k$. $\square$

The construction is generated by `src/dense_functional_extension.py`. Its direct two-move check covers all 51 offsets at $n=75$; five small examples are also checked by both full game solvers and the independent rank-certificate verifier. The receipt is `research/dense-functional-extension-verification.json`. These checks support the ordinary proof; no finite testing is needed to justify the general parameter range. Combining Proposition 31 with Theorem 29 and the functional endpoint proves sharpness for every $2\le r\le n$ when $n\ge75$.

All proofs in this follow-up section are ordinary mathematical arguments. Theorem 25 is probabilistic existence; Theorem 29 is an explicit construction with the previously stated finite structural dependency; Proposition 31 is a direct explicit construction. No new Lean coverage is claimed. The general full-density conjecture remains distinct from the intervals proved here.

#!/usr/bin/env python3
"""Independent arithmetic inventory for the reviewed twenty-arrow compression."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    found={}
    for q in range(11):
        for r in range(11):
            a,d=20-2*q,20-2*r
            for b in range(min(q,r)+1):
                for o in range(a+1):
                    for i in range(d+1):
                        eligible=q*r-b-max(0,20-min(a,r-b+o)-min(d,q-b+i))
                        if eligible<54:continue
                        for z in range(max(o,i),o+i+1):
                            if q+r-b+z<12:continue
                            R=min(q,b+a+(d-o-z)//2)
                            C=min(r,b+d+(a-i-z)//2)
                            if min(R,C)<0:continue
                            live=[(u,v) for u in range(R+1) for v in range(C+1)
                                  if u*v-max(0,u+v-q-r+b)-max(0,2*u+2*v-20)>=54]
                            if not live:continue
                            assert live==[(9,9)]
                            surpluses=[]
                            for x in range(a+1):
                                for y in range(d+1):
                                    if not (0<=a-x-o<=r-b and 0<=d-y-i<=q-b):continue
                                    if q==9 and 2*(r-b)+2*x+o+z>3*a:continue
                                    if r==9 and 2*(q-b)+2*y+i+z>3*d:continue
                                    surpluses.append([x,y])
                            assert len(surpluses)==1
                            found[(q,r,b,o,i,z)]=surpluses[0]
    path='research/small-sparse-twenty-host-compression.json'
    producer=json.loads((ROOT/path).read_text())
    assert found=={tuple(r['tuple']):r['forced_surpluses'] for r in producer['cases']}
    assert len(found)==16
    paths=[path,'research/small-sparse-twenty-host-compression.md',
           'src/small_case_host_compression_review.py',
           'research/small-case-host-compression-review.md']
    report={'verified':True,'tuples':16,
            'cases':[{'tuple':list(k),'forced_surpluses':v} for k,v in sorted(found.items())],
            'conclusion':'M(n,20)=M(11,20) for n>=11; this is extremizer host compression, not a claim that every improvement has support11.',
            'boundary':'Independent exhaustive necessary-integer inventory plus separately recorded ordinary graph-case review. No new complete graph search or Lean theorem.',
            'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}}
    (ROOT/'research/small-case-host-compression-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'verified':True,'tuples':len(found),'extremizer_host':11}))


if __name__=='__main__':main()

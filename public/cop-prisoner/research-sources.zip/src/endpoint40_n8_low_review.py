#!/usr/bin/env python3
"""Complete n8 low-band profile coverage and every-leaf independent game replay."""
import hashlib,itertools,json,subprocess
from pathlib import Path
from small_case_certificate_review import review
ROOT=Path(__file__).resolve().parents[1]
VALUES={17:19,18:21,19:22,20:24,21:25,22:28,23:29}

def last_record(path):
    with path.open('rb') as stream:
        stream.seek(max(0,path.stat().st_size-8192));lines=stream.read().splitlines()
    return json.loads(lines[-1])

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()

def main():
    all_logs=[];cases=[]
    lowers=json.loads((ROOT/'research/endpoint40_n8_low_lower_certificates.json').read_text())
    for m,value in VALUES.items():
        target=value+1
        if m in (22,23):
            logs=[f'research/endpoint40_n8_m{m}_t{target}.jsonl']
            expected=[p for p in itertools.combinations_with_replacement(range(1,8),8) if sum(p)==56-m]
            with (ROOT/logs[0]).open() as stream:
                records=[json.loads(line) for line in stream if '\"kind\":\"leaf\"' not in line]
            start,end=records[0],records[-1];profiles=[r for r in records if r['kind']=='profile']
            assert start['n']==8 and start['m']==m and start['target_I']==target
            assert start['first_profile']==0 and start['last_profile_exclusive']>=len(expected)
            assert [tuple(r['degrees']) for r in profiles]==expected
            assert [r['profile'] for r in profiles]==list(range(len(expected)))
            assert end['complete_requested_profiles'] and not end['timeout'] and not end['found']
            assert all(r['complete'] and not r['found'] and not r['timeout'] for r in profiles)
            assert sum(r['leaves'] for r in profiles)==end['leaves']
            assert sum(r['nodes'] for r in profiles)==end['nodes']
            summaries=[end];ranges=[[0,len(expected)]]
        else:
            logs=([f'research/endpoint40_n8_live_m20_t25_head118.jsonl',f'research/endpoint40_n8_live_m20_t25_tail118.jsonl']
                  if m==20 else [f'research/endpoint40_n8_live_m{m}_t{target}.jsonl'])
            active=(target+4)//5
            expected=[p for p in itertools.combinations_with_replacement(range(8),8)
                      if sum(p)==m and sum(d>=2 for d in p)>=active]
            summaries=[last_record(ROOT/p) for p in logs];covered=[];ranges=[]
            for r in summaries:
                assert r['n']==8 and r['target_I']==target and r['min_m']==r['max_m']==m
                assert r['complete'] and not r['counterexample_found']
                assert r['total_profiles']==len(expected)
                first=r['first_profile'];last=min(r['last_profile_exclusive'],len(expected))
                assert r['checked_profiles']==last-first
                ranges.append([first,last]);covered+=list(range(first,last))
            assert covered==list(range(len(expected)))
        g=[g for g in lowers if(g['n'],g['m'],g['I'])==(8,m,value)]
        assert len(g)==1;lower=review(g[0])
        cases.append({'n':8,'m':m,'M':value,'target_excluded':target,'profiles':len(expected),
           'complete_disjoint_profile_ranges':ranges,'logs':logs,
           'nodes':sum(r['nodes'] for r in summaries),'producer_seconds':sum(r['seconds'] for r in summaries),
           'lower':lower})
        all_logs+=logs
    # Verify the live source differs from the reviewed source only as documented.
    original=(ROOT/'src/finish_tiny_live.cpp').read_text()
    frozen=(ROOT/'src/endpoint40_n8_live.cpp').read_text()
    frozen=frozen.replace('// Frozen n8 live-prune variant with every evaluated leaf emitted for rank replay.',
      '// Completion-pass variant: adds conservative live row/column capacities.')
    frozen=frozen.replace('if(n!=8||','if(n<3||n>16||')
    before='survivors++;int value=delivery_count();'
    a=frozen.index(before)+len(before);b=frozen.index('if(value>best)',a)
    frozen=frozen[:a]+'\n    '+frozen[b:]
    assert frozen==original
    binary=ROOT/'src/endpoint40_n8_leaf_replay.bin'
    subprocess.run(['c++','-O3','-std=c++17',str(ROOT/'src/endpoint40_n8_leaf_replay.cpp'),'-o',str(binary)],check=True)
    run=subprocess.run([str(binary),*all_logs],cwd=ROOT,text=True,capture_output=True,check=True)
    (ROOT/'research/endpoint40_n8_low_leaf_replay.jsonl').write_text(run.stdout)
    replays=[json.loads(s) for s in run.stdout.splitlines()]
    assert [r['path'] for r in replays]==all_logs
    for case in cases:
        rows=[r for r in replays if r['path'] in case['logs']]
        assert all(r['status']=='passed' and r['m']==case['m'] and r['target_I']==case['target_excluded'] for r in rows)
        case['every_literal_leaf_replayed']=sum(r['all_literal_leaves_replayed'] for r in rows)
        case['independent_leaf_replay_seconds']=sum(r['seconds'] for r in rows)
    files=all_logs+['src/endpoint40_n8_low_review.py','src/endpoint40_n8_capacity.cpp','src/endpoint40_n8_live.cpp',
       'src/endpoint40_n8_leaf_replay.cpp','src/finish_tiny_live.cpp','src/small_case_certificate_review.py',
       'research/endpoint40_n8_low_lower_certificates.json','research/endpoint40_n8_low_leaf_replay.jsonl',
       'research/endpoint40_tiny_live_review.json','research/endpoint40_tiny_live_review.md','research/endpoint40_n8_low_proof.md']
    result={'verified':True,'cases':cases,
      'historical_incomplete_pilot':{'path':'research/endpoint40_n8_live_m20_t25.jsonl','used_for_coverage':False},
      'proof_boundary':'Complete source-reviewed profile enumerations; every emitted literal survivor independently evaluated by a separately written compressed game; full lower ranks. No second complete graph traversal or Lean claim.',
      'source_sha256':{p:sha(ROOT/p) for p in files}}
    (ROOT/'research/endpoint40_n8_low_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(cases,indent=2))
if __name__=='__main__':main()

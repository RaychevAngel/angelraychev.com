#!/usr/bin/env python3
"""Export only the retained nine-arrow witness, ignoring any asserted maximum.

Lean independently checks all partial-region moves and every initial state of
all five counted pairs. Alternating rank values are kept as decreasing naturals.
"""
from pathlib import Path
import argparse,json
ROOT=Path(__file__).resolve().parents[1]
TEMPLATE='import SmallBudgetEightWitness\n\n/-! The retained six-vertex, nine-arrow witness; every winning-region step is\nchecked against the actual graph, including all cop replies. -/\nnamespace Delivery.SmallBudgetNineWitness\nopen FiniteGame Extremal SparseSupport\n\ndef edge (s t : Fin 6) : Prop := (s.val,t.val)∈@@ARCS@@\ninstance (s t : Fin 6) : Decidable (edge s t) := inferInstanceAs (Decidable (_∈_))\ninstance (s t : Fin 6) : Decidable (Legal edge s t) := inferInstanceAs (Decidable (_∨_))\ndef code (t r c : Fin 6) : Nat := @@CODES@@[t.val*36+r.val*6+c.val]?.getD 0\ndef move (t r c : Fin 6) : Fin 6 :=\n  ⟨@@MOVES@@[t.val*36+r.val*6+c.val]?.getD 0 % 6, Nat.mod_lt _ (by decide)⟩\ndef region (t r c : Fin 6) : Prop := 0<code t r c\ninstance (t r c : Fin 6) : Decidable (region t r c) := inferInstanceAs (Decidable (_<_))\ndef rank (t r c : Fin 6) : Nat := code t r c-1\n\ntheorem valid (t r c : Fin 6) (inside : region t r c) (nonterminal : r≠t) (safe : r≠c) :\n    Legal edge r (move t r c) ∧ (move t r c=t ∨\n      (move t r c≠c ∧ ∀d,Legal edge c d →\n        move t r c≠d ∧ region t (move t r c) d ∧ rank t (move t r c) d<rank t r c)) := by\n  revert t r c\n  decide +kernel\n\ndef certificate (t : Fin 6) : WinningRegion edge t :=\n  ⟨region t,rank t,move t,valid t⟩\n\ndef counted (s t : Fin 6) : Prop := (s.val,t.val)∈@@PAIRS@@\ninstance (s t : Fin 6) : Decidable (counted s t) := inferInstanceAs (Decidable (_∈_))\ntheorem starts (s t c : Fin 6) (pair : counted s t) (initial : c≠s) : region t s c := by\n  revert s t c\n  decide +kernel\n\ntheorem five_pairs : 5≤score edge := by\n  have valid (s t : Fin 6) (pair : counted s t) : Indirect edge s t := by\n    have facts : ∀s t : Fin 6,counted s t→s≠t∧¬edge s t := by decide +kernel\n    refine ⟨(facts s t pair).1,(facts s t pair).2,?_⟩\n    intro c initial\n    exact ⟨_,winningRegion_winning (certificate t) s c (starts s t c pair initial) (Ne.symm initial)⟩\n  have bound := arcs_mono valid\n  have count : arcCount counted=5 := by rw [arcCount_eq]; decide +kernel\n  change arcCount counted≤score edge at bound\n  omega\n\ntheorem loopless : Loopless edge := by unfold Loopless; decide +kernel\ntheorem arrows : arcCount edge=9 := by rw [arcCount_eq]; decide +kernel\n#print axioms five_pairs\nend Delivery.SmallBudgetNineWitness\n'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=ROOT/'lean/SmallBudgetNineWitness.lean');args=ap.parse_args()
 d=json.loads((ROOT/'research/small-arcs-resume-verification.json').read_text())
 v=next(c['lower_certificate'] for c in d['cases'] if c['m']==9)
 assert v['n']==6 and len(v['arcs'])==9
 n=6;codes=[];moves=[]
 for t,cert in enumerate(v['certificates']):
  for r in range(n):
   for c in range(n):
    i=2*(r*n+c);codes.append(max(cert['rank'][i]+1,0))
    moves.append(t if r==t else max(cert['messenger_successor'][i],0)//(2*n))
 pairs=lambda xs:'['+','.join(f'({a},{b})'for a,b in xs)+']'
 s=TEMPLATE.replace('@@ARCS@@',pairs(v['arcs'])).replace('@@PAIRS@@',pairs(v['indirect_pairs']))
 s=s.replace('@@CODES@@',str(codes)).replace('@@MOVES@@',str(moves))
 args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(s)
if __name__=='__main__':main()

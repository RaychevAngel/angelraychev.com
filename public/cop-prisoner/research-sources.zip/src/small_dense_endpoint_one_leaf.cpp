// Exactly one degree-one row and one degree-three row, total missing2n.
#define main first_step_main
#include "small_dense_first_step_profiles.cpp"
#undef main

int main(int argc,char**argv){
 n=8;seconds=argc>1?stod(argv[1]):10;defect=3;target=13;
 allv=(1u<<n)-1;started=chrono::steady_clock::now();
 for(int high=1;high<=2;high++){
  rows.fill(0);assigned.fill(false);for(auto&d:domain)d.clear();
  for(int s=0;s<n;s++)for(unsigned row=1;row<=allv;row++)
   if(!(row>>s&1)&&__builtin_popcount(row)==(s==0?1:s==high?3:2))domain[s].push_back(row);
  rows[0]=2;assigned[0]=true;visit(1);if(capped||found)break;
 }
 emit(capped?"incomplete":found?"witness":"complete");
}

"""Publication figures: deterministic vector diagrams, with SVG web copies."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'paper/figures';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,
                    'pdf.fonttype':42,'svg.fonttype':'none'})
BLUE='#21618c';INK='#222222';GRAY='#777777'

def node(ax,p,label,fill='white',radius=.13):
    ax.add_patch(Circle(p,radius,facecolor=fill,edgecolor=INK,lw=1.3,zorder=3))
    ax.text(*p,label,ha='center',va='center',fontsize=11,zorder=4)

def edge(ax,a,b,color=INK,rad=0,style='-'):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=12,
        connectionstyle=f'arc3,rad={rad}',shrinkA=12,shrinkB=12,lw=1.3,
        color=color,linestyle=style,zorder=2))

def save(fig,name):
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight',pad_inches=.12)
    fig.savefig(OUT/(name+'.svg'),bbox_inches='tight',pad_inches=.12)
    plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(6.8,2.5))
pos={'s':(0,0),'a':(1,.55),'b':(1,-.55),'t':(2,0)}
for i,ax in enumerate(axs):
    for a,b in [('s','a'),('s','b'),('a','t'),('b','t')]:edge(ax,pos[a],pos[b])
    if i:edge(ax,pos['a'],pos['b'],BLUE,rad=.08,style='--')
    for v,p in pos.items():node(ax,p,v,fill='#eaf2f8'if v in('s','t')else'white')
    ax.set_title('Two safe alternatives'if i==0 else'An added arc removes the guarantee',fontsize=10)
    ax.set_xlim(-.3,2.3);ax.set_ylim(-.9,.9);ax.set_aspect('equal');ax.axis('off')
save(fig,'diamond')

fig,ax=plt.subplots(figsize=(6.8,2.6))
upper=[0,-1,-3,-4];lower=[-7,-8,-10,-11]
xs={v:5.5+.48*v for v in upper+lower}
for v in upper:node(ax,(xs[v],1),str(v),fill='#eaf2f8',radius=.18)
for v in lower:node(ax,(xs[v],0),str(v),radius=.18)
deps={-7:[-4,0],-8:[-7,-1],-10:[-7,-3],-11:[-10,-4]}
for v,targets in deps.items():
    for t in targets:edge(ax,(xs[v],0),(xs[t],1 if t in upper else 0),color=BLUE,rad=.08 if t in lower else 0)
ax.text(.15,1.42,'Known quartet',fontsize=11)
ax.text(.15,-.48,'Derivation order for the lower quartet: −7, −8, −10, −11.',fontsize=8)
ax.set_xlim(-.2,6);ax.set_ylim(-.7,1.65);ax.axis('off')
save(fig,'quartet')

fig,ax=plt.subplots(figsize=(6.8,2.5))
pos={'s₁':(0,1),'s₂':(0,0),'s₃':(0,-1),'t₁':(1.4,1),'t₂':(1.4,0),'t₃':(1.4,-1),'a':(3,0),'b':(4.5,0)}
for i in ['₁','₂','₃']:
    edge(ax,pos['s'+i],pos['t'+i],BLUE)
    edge(ax,pos['t'+i],pos['a'])
edge(ax,pos['a'],pos['b'],rad=.22);edge(ax,pos['b'],pos['a'],rad=.22)
for v,p in pos.items():node(ax,p,v,radius=.18,fill='#eaf2f8'if v.startswith('s')else'white')
ax.text(2.5,1.2,'Arrows show the missing connections',ha='center',fontsize=10)
ax.set_xlim(-.35,4.9);ax.set_ylim(-1.35,1.55);ax.set_aspect('equal');ax.axis('off')
save(fig,'dense-boundary')

fig,ax=plt.subplots(figsize=(6.8,3.1))
sigma=[0,2,4,3,1];voltage=[1,-1,-1,-1,-1]
for i in range(-1,3):
    for j in range(5):
        p=(i*1.7,4-j)
        q=(i*1.7,3-j)if j<4 else((i+1)*1.7,4)
        if -1<=q[0]/1.7<=2:edge(ax,p,q,INK,rad=.12 if j==4 else 0)
        z=((i+voltage[j])*1.7,4-sigma[j])
        if -1<=i+voltage[j]<=2:edge(ax,p,z,BLUE,rad=.15 if j in(1,2,4) else 0)
        node(ax,p,str(j),radius=.15)
    ax.text(i*1.7,-.6,f'column {i}',ha='center',fontsize=9)
ax.set_xlim(-2.1,3.8);ax.set_ylim(-.9,4.4);ax.axis('off')
save(fig,'five-type-strip')

fig,ax=plt.subplots(figsize=(6.8,3.6))
n=100
r=list(range(n+1))
missing=[2*n-x for x in r]
exact=[2*n]+[2*n-x-(x+1)//2-1 for x in r[1:]]
ax.plot(r,missing,color=GRAY,ls='--',lw=1.5,label='Missing-pair upper bound')
ax.plot(r,exact,color=BLUE,lw=2,label='Exact maximum')
ax.scatter([0,n],[exact[0],exact[-1]],color=BLUE,s=25,zorder=3)
ax.annotate('All missing pairs win',(0,2*n),xytext=(8,2*n-12),fontsize=9)
ax.annotate('49 guarantees remain',(n,exact[-1]),xytext=(53,63),fontsize=9,
            arrowprops={'arrowstyle':'-','color':GRAY,'lw':.8})
ax.set_xlabel(r'Additional arcs beyond $n(n-3)$: $r$')
ax.set_ylabel('Guaranteed indirect pairs')
ax.set_title('The complete final dense band, n = 100',fontsize=11)
ax.set_xlim(-2,n+2);ax.set_ylim(40,210)
ax.spines[['top','right']].set_visible(False)
ax.grid(axis='y',color='#e5e5e5',lw=.6)
ax.legend(frameon=False,loc='upper right',fontsize=9)
fig.tight_layout()
save(fig,'dense-staircase')
print('Wrote five PDF/SVG figures.')

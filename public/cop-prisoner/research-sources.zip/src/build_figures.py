"""Publication figures: deterministic vector diagrams, with SVG web copies."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Circle

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'paper/figures';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,
                    'pdf.fonttype':42,'svg.fonttype':'none',
                    'svg.hashsalt':'cop-prisoner-figures-v1'})
BLUE='#21618c';INK='#222222';GRAY='#777777'

def node(ax,p,label,fill='white',radius=.13,fontsize=11):
    ax.add_patch(Circle(p,radius,facecolor=fill,edgecolor=INK,lw=1.3,zorder=3))
    ax.text(*p,label,ha='center',va='center',fontsize=fontsize,zorder=4)

def edge(ax,a,b,color=INK,rad=0,style='-'):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=12,
        connectionstyle=f'arc3,rad={rad}',shrinkA=12,shrinkB=12,lw=1.3,
        color=color,linestyle=style,zorder=2))

def save(fig,name):
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight',pad_inches=.12,
                metadata={'CreationDate':None,'ModDate':None})
    svg=OUT/(name+'.svg')
    fig.savefig(svg,bbox_inches='tight',pad_inches=.12,metadata={'Date':None})
    svg.write_text('\n'.join(line.rstrip()for line in svg.read_text().splitlines())+'\n')
    plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(6.8,2.5))
pos={'s':(0,0),'a':(1,.55),'b':(1,-.55),'t':(2,0)}
for i,ax in enumerate(axs):
    for a,b in [('s','a'),('s','b'),('a','t'),('b','t')]:edge(ax,pos[a],pos[b])
    if i:edge(ax,pos['a'],pos['b'],BLUE,rad=.08,style='--')
    for v,p in pos.items():node(ax,p,v,fill='#eaf2f8'if v in('s','t')else'white')
    ax.set_title('Two safe alternatives'if i==0 else'An added arc removes the guarantee',fontsize=10)
    ax.set_xlim(-.3,2.3);ax.set_ylim(-.9,.9);ax.set_aspect('equal');ax.axis('off')
save(fig,'diamond')

fig,ax=plt.subplots(figsize=(6.8,2.6))
upper=[0,-1,-3,-4];lower=[-7,-8,-10,-11]
xs={v:5.5+.48*v for v in upper+lower}
for v in upper:node(ax,(xs[v],1),str(v),fill='#eaf2f8',radius=.18)
for v in lower:node(ax,(xs[v],0),str(v),radius=.18)
deps={-7:[-4,0],-8:[-7,-1],-10:[-7,-3],-11:[-10,-4]}
for v,targets in deps.items():
    for t in targets:edge(ax,(xs[v],0),(xs[t],1 if t in upper else 0),color=BLUE,rad=.08 if t in lower else 0)
ax.text(.15,1.42,'Known quartet',fontsize=11)
ax.text(.15,-.48,'Derivation order for the lower quartet: −7, −8, −10, −11.',fontsize=8)
ax.set_xlim(-.2,6);ax.set_ylim(-.7,1.65);ax.axis('off')
save(fig,'quartet')

fig,ax=plt.subplots(figsize=(6.8,2.5))
pos={'s₁':(0,1),'s₂':(0,0),'s₃':(0,-1),'t₁':(1.4,1),'t₂':(1.4,0),'t₃':(1.4,-1),'a':(3,0),'b':(4.5,0)}
for i in ['₁','₂','₃']:
    edge(ax,pos['s'+i],pos['t'+i],BLUE)
    edge(ax,pos['t'+i],pos['a'])
edge(ax,pos['a'],pos['b'],rad=.22);edge(ax,pos['b'],pos['a'],rad=.22)
for v,p in pos.items():node(ax,p,v,radius=.18,fill='#eaf2f8'if v.startswith('s')else'white')
ax.text(2.5,1.2,'Arrows show the missing connections',ha='center',fontsize=10)
ax.set_xlim(-.35,4.9);ax.set_ylim(-1.35,1.55);ax.set_aspect('equal');ax.axis('off')
save(fig,'dense-boundary')

fig,ax=plt.subplots(figsize=(6.8,3.1))
sigma=[0,2,4,3,1];voltage=[1,-1,-1,-1,-1]
for i in range(-1,3):
    for j in range(5):
        p=(i*1.7,4-j)
        q=(i*1.7,3-j)if j<4 else((i+1)*1.7,4)
        if -1<=q[0]/1.7<=2:edge(ax,p,q,INK,rad=.12 if j==4 else 0)
        z=((i+voltage[j])*1.7,4-sigma[j])
        if -1<=i+voltage[j]<=2:edge(ax,p,z,BLUE,rad=.15 if j in(1,2,4) else 0)
        node(ax,p,str(j),radius=.15)
    ax.text(i*1.7,-.6,f'column {i}',ha='center',fontsize=9)
ax.set_xlim(-2.1,3.8);ax.set_ylim(-.9,4.4);ax.axis('off')
save(fig,'five-type-strip')

fig,ax=plt.subplots(figsize=(6.8,3.6))
n=100
r=list(range(n+1))
missing=[2*n-x for x in r]
exact=[2*n]+[2*n-x-(x+1)//2-1 for x in r[1:]]
ax.plot(r,missing,color=GRAY,ls='--',lw=1.5,label='Missing-pair upper bound')
ax.plot(r,exact,color=BLUE,lw=2,label='Exact maximum')
ax.scatter([0,n],[exact[0],exact[-1]],color=BLUE,s=25,zorder=3)
ax.annotate('All missing pairs win',(0,2*n),xytext=(8,2*n-12),fontsize=9)
ax.annotate('49 guarantees remain',(n,exact[-1]),xytext=(53,63),fontsize=9,
            arrowprops={'arrowstyle':'-','color':GRAY,'lw':.8})
ax.set_xlabel(r'Additional arcs beyond $n(n-3)$: $r$')
ax.set_ylabel('Guaranteed indirect pairs')
ax.set_title('The complete final dense band, n = 100',fontsize=11)
ax.set_xlim(-2,n+2);ax.set_ylim(40,210)
ax.spines[['top','right']].set_visible(False)
ax.grid(axis='y',color='#e5e5e5',lw=.6)
ax.legend(frameon=False,loc='upper right',fontsize=9)
fig.tight_layout()
save(fig,'dense-staircase')

fig,axs=plt.subplots(1,2,figsize=(6.8,2.8))
pos={'leftA':(0,1),'leftB':(0,-1),'center':(1.3,0),
     'rightA':(2.6,1),'rightB':(2.6,-1)}
labels={'leftA':r'$3_h$','leftB':r'$1_{h-1}$','center':r'$4_h$',
        'rightA':r'$5_h$','rightB':r'$2_{h+1}$'}
for i,ax in enumerate(axs):
    for suffix,color in [('A',INK),('B',BLUE)]:
        if i:edge(ax,pos['left'+suffix],pos['right'+suffix],color)
        else:
            edge(ax,pos['left'+suffix],pos['center'],color,rad=.06)
            edge(ax,pos['center'],pos['right'+suffix],color,rad=.06)
    for key,p in pos.items():
        if key=='center' and i:continue
        node(ax,p,labels[key],fill='#eaf2f8'if key=='center'else'white',radius=.24,
             fontsize=9 if key in('leftB','rightB')else 11)
    ax.set_title('Before removal'if i==0 else'After removal',fontsize=11)
    ax.set_xlim(-.42,3.02);ax.set_ylim(-1.45,1.55)
    ax.set_aspect('equal');ax.axis('off')
fig.tight_layout()
save(fig,'six-type-removal')

fig,axs=plt.subplots(1,3,figsize=(7.4,2.8))
n=115;L=n*(n-1)
budgets=range(24,2*n+1)
values=[(m//2)*(m//2-3)+(2 if m%2 else 0) for m in budgets]
axs[0].plot([m/n for m in budgets],[v/n**2 for v in values],color=BLUE,lw=1.8)
axs[0].set(title='Sparse budgets',xlabel=r'$m/n$',ylabel=r'$M(n,m)/n^2$')
axs[0].set_xlim(0,2.04);axs[0].set_ylim(0,1.04)
axs[1].plot([2*n/L,n*(n-3)/L],[(n*(n-3))/n**2,2/n],color=BLUE,lw=1.8)
axs[1].set(title='Every missing pair wins',xlabel=r'$m/[n(n-1)]$',ylabel=r'$M(n,m)/n^2$')
axs[1].set_xlim(0,1.02);axs[1].set_ylim(0,1.04)
r=range(n+1)
dense=[2*n]+[2*n-x-(x+1)//2-1 for x in range(1,n+1)]
axs[2].plot([x/n for x in r],[v/n for v in dense],color=BLUE,lw=1.8)
axs[2].plot([1,1+1/n,1.1],[dense[-1]/n,0,0],color=BLUE,lw=1.2,ls=':')
axs[2].set(title='Final dense band',xlabel=r'$[m-n(n-3)]/n$',ylabel=r'$M(n,m)/n$')
axs[2].set_xlim(0,1.1);axs[2].set_ylim(0,2.1)
for ax in axs:
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',color='#e5e5e5',lw=.6)
    ax.tick_params(labelsize=8)
    ax.title.set_fontsize(9)
    ax.xaxis.label.set_fontsize(9);ax.yaxis.label.set_fontsize(9)
fig.tight_layout(w_pad=1.5)
save(fig,'joint-regimes')


# Antichain witness: a cop-inaccessible hub is available to the source.
fig,axs=plt.subplots(2,1,figsize=(6.8,3.6),gridspec_kw={'height_ratios':[1,1.3]})
ax=axs[0]
for j in range(7):
    ax.text(j,.8,f'$P_{j}$',ha='center',fontsize=10)
for y,label,values in [(0.35,r'$K_s$',{0,1,4}),(-.1,r'$K_c$',{0,3,4})]:
    ax.text(-.8,y,label,ha='right',va='center',fontsize=11)
    for j in range(7):
        ax.plot(j,y,'o',ms=13,mec=BLUE if j in values else '#cccccc',
                mfc=BLUE if j in values else 'white',mew=1.1)
ax.text(6.8,.2,'Filled = no outgoing arrow\nto that hub',fontsize=9,va='center')
ax.set_xlim(-1.7,9.5);ax.set_ylim(-.45,1.1);ax.axis('off')
ax=axs[1]
positions={'s':(0,.8),'c':(0,-.7),'u':(2,.8),'t':(4,.8)}
edge(ax,positions['s'],positions['u'],BLUE);edge(ax,positions['u'],positions['t'],BLUE)
ax.plot([.2,1.7],[-.55,.63],ls='--',color='#a94442',lw=1.2)
ax.text(1,.05,'cannot reach',color='#a94442',fontsize=9,rotation=25,ha='center')
for name,label in [('s',r'$s$'),('c',r'$c$'),('u',r'$P_3$'),('t',r'$t$')]:
    node(ax,positions[name],label,radius=.19,fill='#eaf2f8' if name=='u' else 'white')
ax.text(2,1.3,r'$P_3\in K_c\setminus K_s$',ha='center',fontsize=11)
ax.text(4,-.65,'Every hub reaches\nevery outside recipient',fontsize=9,ha='center')
ax.set_xlim(-.5,4.6);ax.set_ylim(-1,1.65);ax.axis('off')
fig.tight_layout(h_pad=.7)
save(fig,'antichain-routing')
# One complete order illustrates the overlap rather than suggesting that
# each construction belongs to only one formula regime.
fig,ax=plt.subplots(figsize=(7.2,3.2))
rows=[('Earlier sparse recipe',120,840,GRAY),
      ('Earlier dense-side recipes',1656,3420,GRAY),
      ('Five-jump circle base',300,1740,BLUE),
      ('Twelve-hub layered graph',1162,3042,'#287d60')]
ax.axvspan(841,1655,color='#f5e8d5',zorder=0)
for y,(label,a,b,color) in enumerate(rows):
    ax.plot([a,b],[y,y],lw=9,color=color,solid_capstyle='butt')
    ax.text(a,y-.23,str(a),fontsize=8,ha='center',color=INK)
    ax.text(b,y-.23,str(b),fontsize=8,ha='center',color=INK)
ax.set_yticks(range(4),[row[0] for row in rows],fontsize=9)
ax.set_xlim(0,3540);ax.set_ylim(3.5,-.7)
ax.set_xticks([120,1000,2000,3000,3420])
ax.set_xlabel('Number of arrows, m (n = 60)',fontsize=10)
ax.set_title('The new recipes fill the former 841–1,655 gap',fontsize=11)
ax.spines[['top','right','left']].set_visible(False)
ax.tick_params(axis='y',length=0,pad=9)
ax.grid(axis='x',color='#e5e5e5',lw=.6,zorder=-1)
fig.tight_layout()
save(fig,'main-interval-progress')
print('Wrote nine PDF/SVG figures.')

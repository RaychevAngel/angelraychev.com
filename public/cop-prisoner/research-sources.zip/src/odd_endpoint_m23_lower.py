#!/usr/bin/env python3
"""Verify the fixed 23-arc lower-bound witness using both game solvers."""
import gzip,hashlib,json
from pathlib import Path
from game_solver import neighborhoods,solve_graph,verify_certificate
ROOT=Path(__file__).resolve().parents[1]
g=json.loads((ROOT/'research/odd-endpoint-small-n12.json').read_text())
r=solve_graph(12,g['arcs'],certificates=True,crosscheck=True)
out,arcs=neighborhoods(12,g['arcs'])
assert len(arcs)==23 and r['I']==83
for c in r['certificates']:assert verify_certificate(12,out,c)
p=ROOT/'research/odd-endpoint-m23-lower-certificate.json.gz'
with gzip.open(p,'wt')as f:json.dump(r,f,separators=(',',':'))
receipt={'status':'both game solvers and every direct rank condition pass','n':12,'m':23,'I':83,'certificate_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_sha256':{s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest()for s in ['src/odd_endpoint_m23_lower.py','src/game_solver.py','research/odd-endpoint-small-n12.json']}}
(ROOT/'research/odd-endpoint-m23-lower-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))

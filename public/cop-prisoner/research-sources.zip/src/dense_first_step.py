#!/usr/bin/env python3
"""Explicit extremizers at m=n(n-3)+1, for every n>=68.

The sparse graph F lists missing arcs of the delivery graph G. Structural
checks and the exact safe-two-move condition suffice; no game search occurs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import extremal_bounds_girth_family as girth_family

ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "research/extremal-bounds-girth-growth.json"


def core_graph(k: int):
    if k < 64:
        raise ValueError("The proved four-attachment selection requires k>=64")
    if k >= 130:
        size, edges = girth_family.base(copies=5)
        dependency = "ordinary five-block base and degree-preserving insertion"
        while size < k:
            pair = girth_family.good_pair(size, edges)
            if pair is None:
                raise AssertionError("Proved far-edge existence failed")
            size, edges = girth_family.insert(size, edges, pair)
    else:
        size, edges = girth_family.base(copies=2)
        bridge = json.loads(BRIDGE.read_text())
        for operation in bridge["operations"]:
            if size == k:
                break
            assert operation["n_before"] == size
            size, edges = girth_family.insert(
                size, edges, tuple(tuple(e) for e in operation["edges"])
            )
        dependency = "existing finite structural insertion certificate from order 52"
    assert size == k
    girth_family.verify(size, edges)
    return edges, dependency


def euler_orientation(n: int, edges):
    remaining = girth_family.adjacency(n, edges)
    arcs = set()
    for start in range(n):
        if not remaining[start]:
            continue
        stack = [start]
        circuit = []
        while stack:
            v = stack[-1]
            if remaining[v]:
                u = min(remaining[v])
                remaining[v].remove(u)
                remaining[u].remove(v)
                stack.append(u)
            else:
                circuit.append(stack.pop())
        circuit.reverse()
        assert circuit[0] == circuit[-1]
        arcs.update(zip(circuit, circuit[1:]))
    assert len(arcs) == len(edges)
    assert {tuple(sorted(e)) for e in arcs} == set(edges)
    assert all(sum(a == v for a, b in arcs) == 2 for v in range(n))
    assert all(sum(b == v for a, b in arcs) == 2 for v in range(n))
    return arcs


def verify_girth_six(n: int, edges):
    adjacency = girth_family.adjacency(n, edges)
    for a, b in edges:
        reached = {a}
        frontier = {a}
        for _ in range(4):
            following = set()
            for v in frontier:
                for u in adjacency[v]:
                    if (v == a and u == b) or (v == b and u == a):
                        continue
                    if u not in reached:
                        following.add(u)
            reached |= following
            frontier = following
        assert b not in reached, ("cycle of length at most five", a, b)


def generate(n: int):
    if n < 68:
        raise ValueError("The uniform theorem requires n>=68")
    k = n - 4
    core_edges, dependency = core_graph(k)
    adjacency = girth_family.adjacency(k, core_edges)
    vertices = set(range(k))
    a = 0
    b = min(vertices - girth_family.ball(adjacency, {a}, 3))
    excluded = girth_family.ball(adjacency, {a, b}, 1)
    d = min(vertices - excluded)
    e = min(vertices - (excluded | girth_family.ball(adjacency, {d}, 3)))
    assert len({a, b, d, e}) == 4
    assert b not in girth_family.ball(adjacency, {a}, 3)
    assert e not in girth_family.ball(adjacency, {d}, 3)
    assert not ({d, e} & excluded)

    c, x, y, z = range(k, n)
    missing = euler_orientation(k, core_edges)
    missing.update(((c, x), (x, y), (x, z), (y, a), (y, b), (z, d), (z, e)))
    assert len(missing) == 2 * n - 1
    assert all(u != v for u, v in missing)
    underlying = {tuple(sorted(arc)) for arc in missing}
    assert len(underlying) == len(missing), "opposite arcs are not an orientation"
    verify_girth_six(n, underlying)

    outgoing = [0] * n
    incoming = [0] * n
    for u, v in missing:
        outgoing[u] |= 1 << v
        incoming[v] |= 1 << u
    assert outgoing[c] == 1 << x
    assert all(outgoing[v].bit_count() == 2 for v in range(n) if v != c)
    assert incoming[x] == 1 << c
    assert incoming[y] == incoming[z] == 1 << x

    # For a missing pair s->t, a safe intermediate is exactly a missing
    # outneighbor of the cop outside F+(s) union F-(t). The union already
    # contains s and t, and looplessness excludes the cop itself.
    failures = []
    checked = 0
    winning_pairs = []
    for s, t in sorted(missing):
        forbidden = outgoing[s] | incoming[t]
        wins = True
        for cop in range(n):
            if cop == s:
                continue
            checked += 1
            if not outgoing[cop] & ~forbidden:
                failures.append([s, t, cop])
                wins = False
        if wins:
            winning_pairs.append([s, t])
    assert failures == [[x, y, c], [x, z, c]]
    assert len(winning_pairs) == 2 * n - 3
    assert checked == (2 * n - 1) * (n - 1)

    return {
        "n": n,
        "m": n * (n - 3) + 1,
        "missing_arcs": [list(arc) for arc in sorted(missing)],
        "core_order": k,
        "core_construction": dependency,
        "attachments": {"a": a, "b": b, "d": d, "e": e},
        "gadget": {"c": c, "x": x, "y": y, "z": z},
        "underlying_girth_at_least_six": True,
        "safe_intermediate_triples_checked": checked,
        "two_move_winning_missing_pairs": len(winning_pairs),
        "failing_two_move_triples": failures,
        "losing_pairs": [[x, y], [x, z]],
        "losing_pair_proof": "Cop c has closed G-neighborhood V\\{x}, so it traps source x.",
        "I": 2 * n - 3,
    }


def sha256(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("orders", nargs="*", type=int, default=[68, 75, 80, 100, 164])
    parser.add_argument("--out", type=Path, default=ROOT / "research/dense-first-step-checks.json")
    args = parser.parse_args()
    checks = [generate(n) for n in args.orders]
    receipt = {
        "verified": True,
        "scope": "Finite structural and all-triple two-move checks of explicit instances; the all-order proof is separate.",
        "generator_sha256": sha256(Path(__file__)),
        "core_generator_sha256": sha256(Path(girth_family.__file__)),
        "finite_bridge_sha256": sha256(BRIDGE),
        "checks": checks,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"verified": True, "orders": args.orders, "receipt": str(args.out),
                      "triples_checked": sum(c["safe_intermediate_triples_checked"] for c in checks)}))


if __name__ == "__main__":
    main()

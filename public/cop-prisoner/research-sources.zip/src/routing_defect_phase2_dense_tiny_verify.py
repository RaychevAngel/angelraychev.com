#!/usr/bin/env python3
"""Independent literal readback of the bounded tiny-envelope archive."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]


def main():
    path=ROOT/'research/routing-defect-phase2-dense-tiny-checks.json'
    raw=json.loads(path.read_text())
    assert raw['source_sha256']==hashlib.sha256((ROOT/'src/routing_defect_phase2_dense_tiny.py').read_bytes()).hexdigest()
    rows=[]
    for row in raw['rows']:
        n=row['n']
        base=set(map(tuple,row['base']))
        optional=set(map(tuple,row['optional']))
        full=base|optional
        assert len(base)==2*n and not base&optional
        assert len(optional)==row['full_optional_cap']
        assert all(0<=s<n and 0<=t<n and s!=t for s,t in full)
        assert all(sum(s==v for s,t in base)==sum(t==v for s,t in base)==2 for v in range(n))
        seen=set()
        for s,t,c,u in row['literal_witnesses']:
            assert (s,t) in full and 0<=c<n and c!=s and 0<=u<n
            assert (s,t,c) not in seen
            seen.add((s,t,c))
            assert len({s,u,t})==3 and u!=c
            assert (s,u) not in full and (u,t) not in full and (c,u) in base
        assert seen=={(s,t,c) for s,t in full for c in range(n) if c!=s}
        selected=row['optional'][:n]
        if n>=16:
            assert len(selected)==n
        rows.append({'n':n,'compulsory':len(base),'full_optional':len(optional),
                     'selected_optional':selected,'checked_witnesses':len(seen),
                     'attains_3n':len(selected)==n})
    assert [r['n'] for r in rows]==list(range(10,19))
    result={'verified':True,'scope':'Independent direct certificate readback; arbitrary subsets. No negative inference from small attained caps.',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rows':rows}
    (ROOT/'research/routing-defect-phase2-dense-tiny-independent.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
    print(json.dumps([{'n':r['n'],'cap':r['full_optional'],'attains_3n':r['attains_3n']} for r in rows]))


if __name__=='__main__':
    main()

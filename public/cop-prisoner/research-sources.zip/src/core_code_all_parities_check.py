#!/usr/bin/env python3
"""Independent counting and asymmetric witness tests for all-parity codes.

Formula checks use cycle independence polynomials and direct subsets.
Strategy checks use literal bitset intermediaries in the full cop envelope.
These finite checks supplement the ordinary composition/counting proof.
"""
from itertools import combinations
from pathlib import Path
import argparse
import hashlib
import json
import core_code_all_parities as recipe

ROOT = Path(__file__).resolve().parents[1]


def path_poly(length):
    a, b = [1], [1, 1]
    if length == 0:
        return a
    for _ in range(1, length):
        c = b+[0]
        for i, v in enumerate(a):
            c[i+1] += v
        a, b = b, c
    return b


def cycle_poly(length):
    a = path_poly(length-1)
    b = [0]+path_poly(length-3)
    return [(a[i] if i < len(a) else 0)+(b[i] if i < len(b) else 0)
            for i in range(max(len(a), len(b)))]


def expected(k, r):
    a = cycle_poly(k)
    value = a[r] if r < len(a) else 0
    if k % 2:
        return 2*value
    b = cycle_poly(k//2)
    return value+sum(b[i]*b[r-i] for i in range(len(b)) if 0 <= r-i < len(b))


def structural_codes(k, r, codes):
    codes = [set(S) for S in codes]
    assert len({tuple(sorted(S)) for S in codes}) == len(codes)
    for S in codes:
        assert len(S) == r
        part = int(min(S) >= k)
        assert all(part*k <= v < (part+1)*k for v in S)
        residues = {v % k for v in S}
        gap = 1 if part else 2
        assert all((v+gap) % k not in residues for v in residues)
    # All codes have the same cardinality; distinctness proves incomparability.


def witnesses(g):
    n = g['n']
    B = set(map(tuple, g['base']))
    E = B | set(map(tuple, g['optional']))
    out, pred, cop = [0]*n, [0]*n, [1 << v for v in range(n)]
    for u, v in B:
        out[u] |= 1 << v
        pred[v] |= 1 << u
    for u, v in E:
        cop[u] |= 1 << v
    count = 0
    for s in range(n):
        for t in range(n):
            if s == t or (s, t) in B:
                continue
            mids = out[s] & pred[t]
            for c in range(n):
                if c != s:
                    assert mids & ~cop[c], (n, s, t, c)
                    count += 1
    return count


def run():
    counts = 0
    for k in range(5, 65):
        for r in range(3, k//2+1):
            assert recipe.capacity(k, r) == expected(k, r), (k, r)
            counts += 1
    listed = 0
    for k in range(5, 17):
        for r in range(3, k//2+1):
            actual = list(recipe.all_codes(k, r))
            structural_codes(k, r, actual)
            brute = []
            for part, gap in [(0, 2), (1, 1)]:
                for pick in combinations(range(k), r):
                    S = set(pick)
                    if all((u+gap) % k not in S for u in S):
                        brute.append(tuple(sorted(part*k+u for u in S)))
            assert {tuple(sorted(S)) for S in actual} == set(brute)
            assert len(actual) == expected(k, r)
            listed += len(actual)
    rows = []
    for k, r, q in [(6, 3, 2), (8, 3, 32), (8, 4, 6), (10, 3, 94),
                    (10, 3, 100), (10, 4, 45), (12, 5, 24), (14, 6, 28),
                    (7, 3, 14), (9, 3, 60)]:
        q = min(q, recipe.capacity(k, r))
        g = recipe.construction(k, r, q)
        structural_codes(k, r, g['K'])
        checked = witnesses(g)
        for added in {0, len(g['optional'])//2, len(g['optional'])}:
            h = recipe.construction(k, r, q, added)
            assert len(h['arcs']) == len(g['base'])+added
            assert set(map(tuple, g['base'])) <= set(map(tuple, h['arcs']))
        rows.append({'k': k, 'r': r, 'q': q, 'n': g['n'],
                     'capacity': recipe.capacity(k, r),
                     'm_interval': recipe.interval(k, r, g['n']),
                     'asymmetric_two_move_witnesses_checked': checked})
    assert recipe.capacity(10, 3) == 100
    assert recipe.interval(10, 3, 114) == (3818, 12560)
    assert 3818 <= 3876+1 and 12560 >= 12540-1
    mixed = json.loads((ROOT/'research/core-code-third-mixed-105.json').read_text())
    g = recipe.from_codes(mixed['k'], mixed['codes'])
    assert g['n'] == 105 and len(g['base']) == 3472 and len(g['optional']) == 7140
    mixed_checks = witnesses(g)
    return {'verified': True, 'formula_recurrence_checks': counts,
            'listed_codes_compared_with_literal_subsets': listed, 'rows': rows,
            'mixed_105': {'n':105,'m_interval':[3472,10612],
                          'asymmetric_two_move_witnesses_checked':mixed_checks},
            'scope': 'Ordinary Theorem59 applies to every listed equal-weight code. Finite counting and full asymmetric witness checks are independent implementation evidence, not an all-parameter Lean proof.',
            'source_sha256': {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in
              ['src/core_code_all_parities.py', 'src/core_code_all_parities_check.py',
               'paper/core-code-composition.md','research/core-code-third-mixed-105.json']}}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--check', action='store_true')
    p.add_argument('--out', type=Path, default=ROOT/'research/core-code-all-parities-checks.json')
    a = p.parse_args()
    result = run()
    if a.check:
        assert json.loads(a.out.read_text()) == result
    else:
        a.out.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'verified': True, 'formula_checks': result['formula_recurrence_checks'],
                      'codes_checked': result['listed_codes_compared_with_literal_subsets'],
                      'witness_checks': sum(r['asymmetric_two_move_witnesses_checked'] for r in result['rows'])}))


if __name__ == '__main__':
    main()

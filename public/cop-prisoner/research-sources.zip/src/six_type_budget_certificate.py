#!/usr/bin/env python3
"""Uniform all-order 2n..3n construction and local proof certificates.

Keep the eight optional arc types away from smoothed vertices. Every local
arena is either the augmented unmodified strip or an unaugmented one-hole
strip. Both use three-layer exterior reentry, covering every actual cop move.
"""
import argparse,gzip,hashlib,json
from pathlib import Path
from six_type_augmentation import extra_arena
from five_type_certificate import solve,verify
from sparse_composition_smoothing import SmoothStrip
from sparse_composition_certificate import SIGMA,VOLTAGE
ROOT=Path(__file__).resolve().parents[1]
EXTRAS=((1,-3,5),(3,-3,5),(4,-3,0),(4,3,1),(2,3,0),(3,3,0),(3,-3,0),(5,-2,0))
M,R=4,8

def local(hole):
    a=extra_arena(EXTRAS if hole is None else [],hole=hole,M=M,R=R)
    cv=a['pursuer_vertices']
    a['pursuer_moves'][-1]=[c for c,v in enumerate(cv)if v is None or abs(v[0])>=6]
    return a

def construction(n,m):
    if n<2419 or not 2*n<=m<=3*n:raise ValueError('Proved range: n>=2419,2n<=m<=3n')
    k=(n+5)//6;r=6*k-n;holes={17*j for j in range(r)}
    # Nearby integer representatives permit direct use of the unwrapped map.
    lifted={h+d*k for h in holes for d in (-1,0,1)}
    strip=SmoothStrip(SIGMA,VOLTAGE,4,lifted)
    vertices=[(i,j)for i in range(k)for j in strip.types(i)]
    index={v:j for j,v in enumerate(vertices)}
    arcs={(index[v],index[(u[0]%k,u[1])])for v in vertices for u in strip.arcs(v)}
    assert len(vertices)==n and len(arcs)==2*n
    assert all(u!=v for u,v in arcs)
    assert all(sum(v==x for u,v in arcs)==2 for x in range(n))
    optional=set()
    permitted=[]
    for i in range(k):
        if any(min((i-h)%k,(h-i)%k)<=16 for h in holes):continue
        permitted.append(i)
        for j,d,t in EXTRAS:optional.add((index[(i,j)],index[((i+d)%k,t)]))
    assert not arcs&optional and all(u!=v for u,v in optional)
    assert len(optional)==8*len(permitted)>=n
    added=sorted(optional)[:m-2*n];arcs.update(added)
    assert len(arcs)==m
    return {'n':n,'m':m,'k':k,'holes':sorted(holes),'optional_arc_count':len(optional),'arcs':sorted(arcs)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true')
    ap.add_argument('--out',type=Path,default=ROOT/'research/six-type-budget-certificates.json.gz');args=ap.parse_args()
    if args.check:
        data=json.loads(gzip.decompress(args.out.read_bytes()));records=data['records']
        required={(h,t)for h in[None]+list(range(-R,R+1))for t in[None]+[j for j in range(6)if not(h==0 and j==4)]}
        assert len(records)==len(required) and {(x['hole'],x['target'])for x in records}==required
        for row in records:
            a=local(row['hole']);cert=row['certificate'];t=row['target']
            assert cert['goal']==[j for j,v in enumerate(a['messenger_vertices'])if v[0]==0 and(t is None or v[1]==t)]
            assert cert['safe_transfer']==(t is None)
            assert verify(a,cert,-1 if t is None else-2)==row['bounds']
        print('All',len(records),'saved local rank certificates replayed.');return
    records=[]
    for h in[None]+list(range(-R,R+1)):
        a=local(h)
        for t in[None]+[j for j in range(6)if not(h==0 and j==4)]:
            goals=[v for v in a['messenger_vertices']if v[0]==0 and(t is None or v[1]==t)]
            cert=solve(a,goals,t is None);bounds=verify(a,cert,-1 if t is None else-2)
            records.append({'hole':h,'target':t,'bounds':bounds,'certificate':cert})
    data={'M':M,'R':R,'extras':EXTRAS,'Omega':'wait or any existing vertex in columns -8,-7,-6,6,7,8',
          'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with args.out.open('wb')as out:
        with gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0)as z:z.write((json.dumps(data,separators=(',',':'))+'\n').encode())
    finite=[]
    for n in range(2419,2425):
        g=construction(n,3*n);finite.append({key:value for key,value in g.items()if key!='arcs'})
    summary={'verified':True,'module_count':len(records),'max_transfer':max(max(x['bounds'])for x in records if x['target']is None),
             'max_delivery':max(max(x['bounds'])for x in records if x['target']is not None),'finite_construction_checks':finite,
             'certificate_sha256':hashlib.sha256(args.out.read_bytes()).hexdigest()}
    (ROOT/'research/six-type-budget-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))

if __name__=='__main__':main()

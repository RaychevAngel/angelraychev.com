// Independent explicit alternating attractor. Receipt precedes collision.
// Works with distinct messenger and cop arrows for optimistic-prune review.
vector<int> independent_wins(const int* messenger,const int* cop,int target){
 const int count=2*n*n;
 vector<int> incoming_m(n),incoming_c(n),degree_c(n),won(count),left(count),queue;
 queue.reserve(count);
 for(int u=0;u<n;u++){
  int mm=messenger[u]|(1<<u),cc=cop[u]|(1<<u);
  degree_c[u]=__builtin_popcount(unsigned(cc));
  for(int v=0;v<n;v++){
   if(mm>>v&1)incoming_m[v]|=1<<u;
   if(cc>>v&1)incoming_c[v]|=1<<u;
  }
 }
 for(int r=0;r<n;r++)for(int c=0;c<n;c++){
  int base=2*(r*n+c);left[base+1]=degree_c[c];
  if(r==target){won[base]=won[base+1]=1;queue.push_back(base);queue.push_back(base+1);}
 }
 for(size_t i=0;i<queue.size();i++){
  int state=queue[i],r=(state/2)/n,c=(state/2)%n;
  if(state&1){
   int predecessors=incoming_m[r];
   while(predecessors){int u=__builtin_ctz(unsigned(predecessors));predecessors&=predecessors-1;
    int parent=2*(u*n+c);
    if(u!=target&&u!=c&&!won[parent]){won[parent]=1;queue.push_back(parent);}
   }
  }else{
   int predecessors=incoming_c[c];
   while(predecessors){int v=__builtin_ctz(unsigned(predecessors));predecessors&=predecessors-1;
    int parent=2*(r*n+v)+1;
    if(r!=target&&r!=v&&!won[parent]&&--left[parent]==0){won[parent]=1;queue.push_back(parent);}
   }
  }
 }
 vector<int> result(n);
 for(int r=0;r<n;r++)for(int c=0;c<n;c++)if(won[2*(r*n+c)])result[r]|=1<<c;
 return result;
}

#!/usr/bin/env python3
"""Import the six retained odd witnesses at support orders thirteen to eighteen.

No graph search or game solving. The accepted nested signed-rank renderer is
reused without changing its kernel obligations. A separate assembly combines
the exact graph scores with the sparse parity upper bound and isolate padding.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path

from export_small_sparse_witnesses_lean import render

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assembly():
    imports = ''.join(f'import SmallOddWitness{n}\n' for n in range(13, 19))
    branches = '\n'.join(
        f'  · exact maximum_of_exact (by decide) order SmallOddWitness{n}.edge\n'
        f'      SmallOddWitness{n}.loopless SmallOddWitness{n}.arrows\n'
        f'      SmallOddWitness{n}.exact_score' for n in range(13, 19))
    return imports + '''import SparseParity
import GraphPadding

/-! The retained six odd witnesses attain the unrestricted sparse parity
bound on their original supports and every larger host by isolated padding. -/
namespace Delivery.SmallOddConstruction
open FiniteGame Extremal

theorem maximum_of_exact {support host : Nat} (large : 6≤support)
    (order : support≤host) (E : Graph (Fin support)) (loops : Loopless E)
    (arrows : arcCount E=2*support-1)
    (value : score E=(support-1)*(support-4)+2) :
    IsMaximum host (2*support-1) ((support-1)*(support-4)+2) := by
  obtain ⟨F,loopF,arrowF,valueF⟩ := GraphPadding.pad_to_order E loops order
  refine ⟨?_,F,loopF,arrowF.trans arrows,valueF.trans value⟩
  intro G loopG budget
  have bound := SparseParity.odd_upper G loopG (k := support-1)
    (by omega) (by omega)
  simpa only [Nat.sub_sub] using bound

theorem maximum_odd {host support : Nat} (low : 13≤support)
    (high : support≤18) (order : support≤host) :
    IsMaximum host (2*support-1) ((support-1)*(support-4)+2) := by
  have cases : support=13 ∨ support=14 ∨ support=15 ∨
      support=16 ∨ support=17 ∨ support=18 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl
''' + branches + '''

#print axioms maximum_of_exact
#print axioms maximum_odd
end Delivery.SmallOddConstruction
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    args = parser.parse_args()
    archive = ROOT/'research/odd-endpoint-small-certificates.json.gz'
    receipt = ROOT/'research/odd-endpoint-small-verification.json'
    historical = json.loads(receipt.read_text())
    assert digest(archive) == historical['certificate_sha256']
    records = json.loads(gzip.decompress(archive.read_bytes()))
    assert sorted(record['n'] for record in records) == list(range(13, 19))
    args.out.mkdir(parents=True, exist_ok=True)
    modules = []
    for record in records:
        item = record['result']
        n, m = record['n'], item['m']
        assert item['n'] == n and m == 2*n-1 and item['I'] == (n-1)*(n-4)+2
        assert len(item['arcs']) == len(set(map(tuple, item['arcs']))) == m
        assert sorted(c['target'] for c in item['certificates']) == list(range(n))
        for cert in item['certificates']:
            assert len(cert['rank']) == len(cert['messenger_successor']) == 2*n*n
        original = json.loads((ROOT/f'research/odd-endpoint-small-n{n}.json').read_text())
        assert sorted(item['arcs']) == sorted(original['arcs'])
        text = render(item).replace(f'Delivery.SmallSparseWitness{m}',
                                    f'Delivery.SmallOddWitness{n}')
        path = args.out/f'SmallOddWitness{n}.lean'
        path.write_text(text)
        modules.append(dict(module=path.stem, order=n, arrows=m, score=item['I'],
                            source_sha256=digest(path)))
    wrapper = args.out/'SmallOddConstruction.lean'
    wrapper.write_text(assembly())
    sources = [archive, receipt, Path(__file__),
               ROOT/'src/export_small_sparse_witnesses_lean.py',
               ROOT/'src/lean_sparse_witness_producer.py']
    sources += [ROOT/f'research/odd-endpoint-small-n{n}.json' for n in range(13, 19)]
    manifest = dict(
        status='exported; kernel replay required',
        scope='Exact retained graph scores and padded unrestricted odd maxima for support13..18, host>=support.',
        proof_boundary='SignedRankCertificate checks all winning/losing obligations; SparseParity supplies the independent unrestricted upper bound; GraphPadding preserves exact scores.',
        source_sha256={str(p.relative_to(ROOT)): digest(p) for p in sources},
        historical_producer_pins=historical['source_sha256'],
        input_alternating_states=sum(2*r['n']**3 for r in records),
        exported_messenger_states=sum(r['n']**3 for r in records),
        modules=modules,
        assembly=dict(module=wrapper.stem, source_sha256=digest(wrapper)))
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps(dict(witnesses=len(modules), alternating_states=manifest['input_alternating_states'],
                          messenger_states=manifest['exported_messenger_states'])))


if __name__ == '__main__':
    main()

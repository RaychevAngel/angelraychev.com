#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
using namespace std;
constexpr int N=11;
using Graph=array<unsigned,N>;
mt19937 rng(930128);
int score(const Graph& g) {
  unsigned in[N]={};
  for(int s=0;s<N;s++)for(int t=0;t<N;t++)if(g[s]>>t&1)in[t]|=1u<<s;
  int ans=0;
  for(int s=0;s<N;s++)for(int t=0;t<N;t++)if(g[s]>>t&1){
    unsigned danger=g[s]|in[t];
    for(int c=0;c<N;c++)if(c!=s && !(g[c]&~danger))ans++;
  }
  return ans;
}
Graph random_graph(){
  Graph g={};
  for(int i=0;i<N;i++)while(__builtin_popcount(g[i])<2){int j=rng()%N;if(j!=i)g[i]|=1u<<j;}
  return g;
}
Graph near_core(){
 Graph g={};
 for(int i=0;i<5;i++){g[i]=(1u<<(5+i))|(1u<<(5+(i+4)%5));g[5+i]=(1u<<((i+4)%5))|(1u<<((i+6)%5));}
 int a=rng()%5,b=(a+1+rng()%4)%5;
 g[a]^=(1u<<(5+a))|(1u<<10);g[b]^=(1u<<(5+b))|(1u<<10);g[10]=(1u<<(5+a))|(1u<<(5+b));
 return g;
}
void dump(const Graph& g,int sc){cout<<"{\"score\":"<<sc<<",\"rows\":[";for(int i=0;i<N;i++)cout<<(i?",":"")<<g[i];cout<<"]}"<<endl;}
int main(int argc,char**argv){
 double seconds=argc>1?stod(argv[1]):30;
 auto start=chrono::steady_clock::now();int best=10000;long long moves=0;
 for(int restart=0;;restart++){
  if(chrono::duration<double>(chrono::steady_clock::now()-start).count()>seconds)break;
  Graph g=(restart%3?near_core():random_graph());int old=score(g);
  for(int step=0;step<20000;step++){
   auto h=g;int s=rng()%N;
   if(rng()%4==0){int t=rng()%N;if(s==t)continue;unsigned a=g[s]&-g[s],b=g[t]&-g[t];if(rng()%2)a=g[s]^a;if(rng()%2)b=g[t]^b;
    if(a==b || (g[s]&b)||(g[t]&a)||(b>>s&1)||(a>>t&1))continue;h[s]^=a|b;h[t]^=a|b;
   }else{unsigned a=g[s]&-g[s];if(rng()%2)a=g[s]^a;int t=rng()%N;if(t==s || (g[s]>>t&1))continue;h[s]^=a|(1u<<t);}
   int now=score(h);moves++;
   double temp=0.08+1.3*pow(1.0-(step%5000)/5000.0,3);
   if(now<=old || uniform_real_distribution<double>(0,1)(rng)<exp((old-now)/temp)){g=h;old=now;}
   if(old<best){best=old;dump(g,best);if(best==0)return 0;}
  }
 }
 cerr<<"moves "<<moves<<" best "<<best<<endl;
}

#!/usr/bin/env python3
"""Replay the new finite-exclusion Lean modules with a pinned ordinary kernel.

The untrusted producer is never required at proof-check time. Historical data
is neither consumed as an axiom nor modified. Every local transitive import is recompiled and its source and object are pinned;
toolchain-owned imports are recorded by name and the compiler binary is hashed.
"""
from __future__ import annotations
import argparse, hashlib, json, os, re, subprocess, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DEFAULT_LEAN=Path('/Users/angel/code/math/polyominoes/.tools/lean-4.33.1-darwin_aarch64/bin/lean')
KEYS=['2x2x2x3','2x2x5','2x3x4','2x7','3x3x3','3x6','4x5','9']
MODULES=['FiniteExclusionKernel','FiniteExclusionScore','FiniteExclusionConjugacy']+['FiniteExclusionNine'+k for k in KEYS]+['FiniteExclusionNine','FiniteExclusionRegularNine','VertexEquality','FiniteExclusionUnrestrictedNine','FiniteExclusionBounds','FiniteExclusionPrefixBounds','FiniteExclusionBitset','FiniteExclusionFastBounds','FiniteExclusionBoundTree','FiniteExclusionBoundTreeRows','FiniteExclusionBoolean','FiniteExclusionRotationBoundTree','FiniteExclusionHamiltonianSharp']
ALLOWED={'propext','Classical.choice','Quot.sound'}

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def dependency_closure(modules):
    """Local imports in build order; toolchain-owned imports remain explicit."""
    ordered=[];seen=set();external=set()
    def visit(module):
        if module in seen: return
        seen.add(module)
        source=ROOT/'lean'/Path(module.replace('.', '/')+'.lean')
        if not source.exists():
            external.add(module);return
        for line in source.read_text().splitlines():
            if line.startswith('import '):
                for dependency in line[7:].split(): visit(dependency)
        ordered.append(module)
    for module in modules: visit(module)
    return ordered,sorted(external)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--lean',type=Path,default=DEFAULT_LEAN);ap.add_argument('--timeout',type=int,default=300);args=ap.parse_args()
    scratch=ROOT/'tmp/lean-oct23/finite';scratch.mkdir(parents=True,exist_ok=True)
    env=dict(os.environ,LEAN_PATH=str(ROOT/'lean'))
    rows=[]; started=time.monotonic()
    version=subprocess.check_output([str(args.lean),'--version'],text=True).strip()
    if '4.33.1' not in version: raise RuntimeError('wrong Lean version: '+version)
    dependencies,external=dependency_closure(MODULES)
    for module in dependencies:
        source=ROOT/'lean'/(module+'.lean');text=source.read_text()
        if module in MODULES and re.search(r'\b(?:sorry|axiom|native_decide)\b',text): raise RuntimeError('forbidden proof escape in '+str(source))
        begin=time.monotonic()
        proc=subprocess.run([str(args.lean),'-j','2','-o',str(source.with_suffix('.olean')),str(source)],env=env,cwd=ROOT,capture_output=True,text=True,timeout=args.timeout)
        output=proc.stdout+proc.stderr;(scratch/('replay-'+module+'.log')).write_text(output)
        if proc.returncode: raise RuntimeError(module+' failed; see scratch log')
        found=[]
        for block in re.findall(r'depends on axioms: \[([^]]*)\]',output):
            axioms={x.strip() for x in block.split(',') if x.strip()}
            if not axioms<=ALLOWED: raise RuntimeError('unexpected axioms: '+repr(axioms))
            found.extend(sorted(axioms))
        row={'module':module,'sha256':sha(source),'olean_sha256':sha(source.with_suffix('.olean')),'seconds':time.monotonic()-begin,'axioms':sorted(set(found))}
        rows.append(row);print(json.dumps(row),flush=True)
    totals={key:0 for key in ['nodes','branches','invalid_children','source_prunes','predecessor_prunes','losing_leaves']}
    for key in KEYS:
        record=json.loads((scratch/('family-'+key+'.json')).read_text())
        if sha(ROOT/record['source'])!=record['sha256']: raise RuntimeError('producer/source pin mismatch: '+key)
        for field in totals: totals[field]+=record['counts'][field]
    receipt={'verified':True,'lean':version,'compiler_sha256':sha(args.lean.resolve()),'compiler_path':str(args.lean.resolve()),'external_imports':external,'seconds':time.monotonic()-started,'modules':rows,'totals':totals,'producer_sha256':sha(ROOT/'src/lean_finite_regular_producer.py'),'boundary':'Every loopless nine-vertex graph has score at most 53. The chain includes degree rigidity, Hall factorization, cycle normalization, and complete finite certificates for all eight first-factor types. The nine-vertex Hamiltonian two-factor family has exact maximum 30, with complete normalized branch coverage and an isomorphic signed-rank witness. This does not prove the sharp bound 30 for the other seven regular first-factor types, the global budget value M_E(18)=33, or the full classification.'}
    (scratch/'lean-finite-replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'verified':True,'totals':totals}),flush=True)
if __name__=='__main__': main()

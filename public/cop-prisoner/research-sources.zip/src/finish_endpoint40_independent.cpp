// Independent exhaustive endpoint review. Delivery rows, fixed-point game,
// and full suffix signature classes rather than adjacent comparisons.
#include <algorithm>
#include <array>
#include <chrono>
#include <iostream>
#include <vector>
using namespace std;
constexpr int N=8, FULL=255;
array<int,N> d{},a{},col{};
vector<array<int,N>> partitions;
unsigned long long visits=0,leaves=0;
int best=-1,profile_count=0; bool found=false;

int loss_bound(int k){
  array<int,N> killed{};
  for(int c=0;c<k;c++){
    const int closed=a[c]|(1<<c);
    int routes=0;
    // An unassigned row could have every outgoing arrow. Including its
    // whole possible row overestimates possible final delivery moves.
    for(int u=0;u<N;u++)if(!(closed>>u&1))
      routes|=u<k?a[u]:(FULL^(1<<u));
    for(int s=0;s<k;s++)if(s!=c){
      const int absent=FULL^(a[s]|(1<<s));
      if(!(a[s]&~closed))killed[s]|=absent;
      killed[s]|=absent&~routes;
    }
  }
  int total=0;for(int x:killed)total+=__builtin_popcount((unsigned)x);
  return total;
}

int value(){
  int answer=0;
  for(int t=0;t<N;t++){
    array<int,N> win{},safe{},next{};win[t]=FULL;
    while(true){
      for(int u=0;u<N;u++){
        safe[u]=u==t?FULL:0;
        if(u!=t)for(int c=0;c<N;c++)
          if(!((a[c]|(1<<c))&~win[u]))safe[u]|=1<<c;
      }
      for(int s=0;s<N;s++){
        next[s]=0;
        for(int u=0;u<N;u++)if(u==s||(a[s]>>u&1))next[s]|=safe[u];
        if(s!=t)next[s]&=~(1<<s);
      }
      if(next==win)break;
      win=next;
    }
    for(int s=0;s<N;s++)if(s!=t&&!(a[s]>>t&1)&&win[s]==(FULL^(1<<s)))answer++;
  }
  return answer;
}

void visit(int k){
  visits++;
  if(loss_bound(k)>3)return;
  if(k==N){
    leaves++;int z=value();best=max(best,z);if(z>=13)found=true;
    cout<<"{\"kind\":\"leaf\",\"I\":"<<z<<",\"arcs\":[";
    bool first=true;
    for(int s=0;s<N;s++)for(int t=0;t<N;t++)if(a[s]>>t&1){
      if(!first)cout<<',';first=false;cout<<'['<<s<<','<<t<<']';
    }
    cout<<"]}\n";return;
  }
  for(int mask=0;mask<=FULL;mask++)if(!(mask>>k&1)&&__builtin_popcount((unsigned)mask)==N-1-d[k]){
    bool ok=true;
    // Equal degrees and equal already-fixed incoming columns permit
    // arbitrary relabeling of a suffix cell. Choose one binary subword.
    for(int u=k+1;u<N&&ok;u++)for(int v=u+1;v<N;v++)
      if(d[u]==d[v]&&col[u]==col[v]&&(mask>>u&1)&&!(mask>>v&1)){ok=false;break;}
    if(!ok)continue;
    a[k]=mask;
    for(int t=0;t<N;t++)if(mask>>t&1)col[t]|=1<<k;
    visit(k+1);
    for(int t=0;t<N;t++)col[t]&=~(1<<k);
    a[k]=0;
  }
}

void partition(int k,int remaining,int low){
  if(k==N){if(!remaining)partitions.push_back(d);return;}
  for(int z=low;z<=7;z++)if(z*(N-k)<=remaining&&remaining-z<=7*(N-k-1)){
    d[k]=z;partition(k+1,remaining-z,z);
  }
}
int main(){
  auto start=chrono::steady_clock::now();partition(0,16,1);
  for(auto p:partitions){d=p;a.fill(0);col.fill(0);visit(0);profile_count++;}
  cout<<"{\"kind\":\"summary\",\"complete\":true,\"profiles\":"<<profile_count
      <<",\"nodes\":"<<visits<<",\"leaves\":"<<leaves<<",\"best\":"<<best
      <<",\"found13\":"<<(found?"true":"false")<<",\"seconds\":"
      <<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
}

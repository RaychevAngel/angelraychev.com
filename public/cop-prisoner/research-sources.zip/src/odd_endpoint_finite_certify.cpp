// Generate explicit alternating-game attractor ranks for fixed odd witnesses.
// Output signed16 ranks, little-endian; the independent Python replay checks
// all original legal moves and both winning/losing conditions directly.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
void emit(int x){uint16_t y=uint16_t(int16_t(x));cout.put(char(y&255));cout.put(char(y>>8));}
int main(){int count;cin>>count;while(count--){int n,u,v;cin>>n>>u>>v;int sz=2*n*n;vector<vector<int>>out(n),in(n);for(int x=0;x<n;x++)out[x].push_back(x);for(int i=0;i<2*n-1;i++){int a,b;cin>>a>>b;out[a].push_back(b);}for(int a=0;a<n;a++)for(int b:out[a])in[b].push_back(a);
 vector<int>rank(sz),rem(sz),largest(sz),q;q.reserve(sz);
 for(int t=0;t<n;t++)if(t!=v){fill(rank.begin(),rank.end(),-1);fill(largest.begin(),largest.end(),0);q.clear();for(int a=0;a<n;a++)for(int c=0;c<n;c++)rem[2*(a*n+c)+1]=out[c].size();
  for(int c=0;c<n;c++)for(int turn=0;turn<2;turn++){int z=2*(t*n+c)+turn;rank[z]=0;q.push_back(z);}
  for(size_t h=0;h<q.size();h++){int z=q[h],turn=z%2,a=z/2/n,c=z/2%n;
   if(turn){for(int p:in[a]){int x=2*(p*n+c);if(p!=c&&rank[x]<0){rank[x]=rank[z]+1;q.push_back(x);}}}
   else{for(int p:in[c]){int x=2*(a*n+p)+1;if(a!=p&&rank[x]<0){largest[x]=max(largest[x],rank[z]);if(--rem[x]==0){rank[x]=largest[x]+1;q.push_back(x);}}}}
  }
  for(int a=0;a<n;a++)if(a!=u)for(int c=0;c<n;c++)if(a!=c)assert(rank[2*(a*n+c)]>=0);
  for(int x:rank){assert(x<32767);emit(x);}
 }
}return 0;}

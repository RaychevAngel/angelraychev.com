#!/usr/bin/env python3
"""Parity construction with max missing budget n²/4−O(n)."""
from dense_unified_core import robust_check
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def envelope(n):
    assert n>=44
    q,s=divmod(n,4);k=2*q
    b={(u,v) for i in range(k) for u,v in
       ((i,k+i),(i,k+(i-1)%k),(k+i,(i+4)%k),(k+i,(i+7)%k))}
    d={v for v in range(2,k,2) if v not in {x%k for x in (2,-2,4,-4,6,-6,8,-8)}}
    e={v for v in range(2,k,2) if v not in {x%k for x in (2,-2,4,-4,8,10,12)}}
    assert len(d)==q-9 and len(e)==q-8
    o={(i,(i+a)%k) for i in range(k) for a in d}
    o|={(k+i,k+(i+a)%k) for i in range(k) for a in e}
    for a in range(s):b.update(((2*k+a,a),(2*k+a,a+5)))
    o|={(2*k+a,2*k+c) for a in range(s) for c in range(s) if a!=c}
    assert len(b)==2*n and b.isdisjoint(o)
    assert len(b|o)==4*q*q-26*q+s*s+s
    return b,o

def main():
    rows=[]
    for n in range(44,161):
        b,o=envelope(n);checked=robust_check(n,b,o)
        rows.append({'n':n,'h':len(b|o),'old_h':n*max(3,(n+11)//13),'triples':checked})
    (ROOT/'research/dense-phase2-quarter-envelope.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('Verified',len(rows),'orders44..160')

if __name__=='__main__':main()

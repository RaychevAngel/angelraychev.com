#!/usr/bin/env python3
"""Independent explicit-state verifier for six-type smoothed-column tiles.

The primary smoothing module and its fixed-point solver are not imported.
This module constructs both turns explicitly, computes an AND/OR attractor,
and independently checks ranks, selected moves, and losing-region closure.
"""
from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
M = 4
R = 6


def vertices(radius, hole):
    return [(i, j) for i in range(-radius, radius + 1) for j in range(6)
            if (i, j) != (hole, 4)]


def outgoing(position, hole):
    i, j = position
    assert position != (hole, 4)
    # Direct formulas for the two independently smoothed permutations.
    first = (i, j + 1) if j < 5 else (i + 1, 0)
    if j == 3 and i == hole:
        first = (i, 5)
    second = ((i, 5), (i + 1, 4), (i + 1, 1),
              (i - 1, 0), (i + 1, 2), (i - 1, 3))[j]
    if j == 1 and i + 1 == hole:
        second = (i + 2, 2)
    assert first != second and position not in (first, second)
    return first, second


def make_arena(hole):
    messenger = vertices(M, hole)
    cops = vertices(R, hole) + [None]
    mi = {p: i for i, p in enumerate(messenger)}
    ci = {p: i for i, p in enumerate(cops)}
    omega = ci[None]
    messenger_moves = []
    for position in messenger:
        messenger_moves.append([mi[p] for p in (position, *outgoing(position, hole)) if p in mi])
    cop_moves = []
    for position in cops:
        if position is None:
            cop_moves.append([omega] + [i for i, p in enumerate(cops)
                                       if p is not None and abs(p[0]) >= R - 1])
        else:
            cop_moves.append(sorted({ci.get(p, omega) for p in (position, *outgoing(position, hole))}))
    return {"hole": hole, "messenger": messenger, "cops": cops,
            "messenger_moves": messenger_moves, "cop_moves": cop_moves}


def game(arena, target):
    messenger, cops = arena["messenger"], arena["cops"]
    nr, nc = len(messenger), len(cops)
    count = 2 * nr * nc
    successors = [[] for _ in range(count)]
    success = [False] * count
    collision = [False] * count
    def sid(r, c, turn):
        return 2 * (r * nc + c) + turn
    for r, position in enumerate(messenger):
        for c, cop in enumerate(cops):
            for turn in (0, 1):
                state = sid(r, c, turn)
                same = position == cop
                if target is None:
                    # Transfer ends after the cop response, on messenger turn.
                    success[state] = turn == 0 and position[0] == 0 and not same
                else:
                    # Receipt has priority even if the cop occupies the target.
                    success[state] = position == (0, target)
                collision[state] = same and not success[state]
                if success[state] or collision[state]:
                    continue
                if turn == 0:
                    successors[state] = [sid(z, c, 1) for z in arena["messenger_moves"][r]]
                else:
                    successors[state] = [sid(r, z, 0) for z in arena["cop_moves"][c]]
    return successors, success, collision


def attractor(successors, success):
    size = len(successors)
    reverse = [[] for _ in range(size)]
    remaining = [len(row) for row in successors]
    rank = [-1] * size
    move = [-1] * size
    maximum_child = [0] * size
    pending = collections.deque()
    for state, row in enumerate(successors):
        for child in row:
            reverse[child].append(state)
        if success[state]:
            rank[state] = 0
            pending.append(state)
    while pending:
        child = pending.popleft()
        for parent in reverse[child]:
            if rank[parent] >= 0:
                continue
            if parent % 2 == 0:
                rank[parent] = rank[child] + 1
                move[parent] = child
                pending.append(parent)
            else:
                remaining[parent] -= 1
                maximum_child[parent] = max(maximum_child[parent], rank[child])
                if remaining[parent] == 0:
                    rank[parent] = maximum_child[parent] + 1
                    pending.append(parent)
    return rank, move


def check_certificate(successors, success, collision, rank, move):
    for state, row in enumerate(successors):
        if success[state]:
            assert rank[state] == 0
        elif collision[state]:
            assert rank[state] == -1
        elif rank[state] >= 0:
            if state % 2 == 0:
                assert move[state] in row
                assert 0 <= rank[move[state]] < rank[state]
            else:
                assert row and all(0 <= rank[child] < rank[state] for child in row)
        elif state % 2 == 0:
            assert all(rank[child] < 0 for child in row)
        else:
            assert any(rank[child] < 0 for child in row)


def certificate(hole, target):
    arena = make_arena(hole)
    successors, success, collision = game(arena, target)
    rank, move = attractor(successors, success)
    check_certificate(successors, success, collision, rank, move)
    nc = len(arena["cops"])
    source_column = -1 if target is None else -2
    starts = []
    for r, position in enumerate(arena["messenger"]):
        if position[0] != source_column:
            continue
        for c, cop in enumerate(arena["cops"]):
            if position != cop:
                starts.append(2 * (r * nc + c))
    assert starts and all(rank[state] >= 0 for state in starts), (hole, target)
    return {"hole_column": hole, "objective": "safe_transfer" if target is None else "delivery",
            "target_type": target, "source_column": source_column,
            "messenger_vertices": arena["messenger"], "cop_vertices": arena["cops"],
            "state_encoding": "2*(messenger_index*number_of_cop_vertices+cop_index)+turn; turn0=messenger",
            "winning_required_starts": len(starts),
            "maximum_required_start_rank": max(rank[state] for state in starts),
            "messenger_moves_upper_bound": (max(rank[state] for state in starts) + 1) // 2,
            "ranks": rank, "chosen_messenger_successors": move}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "research/six-type-independent-certificates.json.gz")
    args = parser.parse_args()
    certificates = []
    for hole in [None, *range(-R, R + 1)]:
        for target in [None, *[j for j in range(6) if (0, j) != (hole, 4)]]:
            certificates.append(certificate(hole, target))
    result = {"verified": True, "messenger_radius": M, "cop_radius": R,
              "omega": "May wait or reenter any existing vertex in columns -6,-5,5,6.",
              "independence": "No primary arena builder or solver imported; explicit two-turn AND/OR attractor and full certificate checker.",
              "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "certificates": certificates}
    payload = (json.dumps(result, separators=(",", ":")) + "\n").encode()
    with args.out.open("wb") as destination:
        with gzip.GzipFile(filename="", fileobj=destination, mode="wb", mtime=0) as stream:
            stream.write(payload)
    summaries = [{k: v for k, v in cert.items() if k not in
                  ("ranks", "chosen_messenger_successors", "messenger_vertices", "cop_vertices")}
                 for cert in certificates]
    summary = {"verified": True, "module_count": len(certificates),
               "required_starts_checked": sum(c["winning_required_starts"] for c in certificates),
               "states_checked": sum(len(c["ranks"]) for c in certificates),
               "max_transfer_moves": max(c["messenger_moves_upper_bound"] for c in certificates if c["objective"] == "safe_transfer"),
               "max_delivery_moves": max(c["messenger_moves_upper_bound"] for c in certificates if c["objective"] == "delivery"),
               "certificate_path": str(args.out.relative_to(ROOT)),
               "certificate_sha256": hashlib.sha256(args.out.read_bytes()).hexdigest(),
               "checker_sha256": result["checker_sha256"], "modules": summaries}
    path = ROOT / "research/six-type-independent-summary.json"
    path.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "modules"}))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Direct circle recipes with a symbolic universal-delivery proof.

Both full modulo-four circles and integer-pattern circles with an empty
wraparound interval are included. Parameter choice scans integers satisfying
the theorem's arithmetic conditions, never graphs or game solutions. The
default check replays the actual local proof obligations for finite orders;
the ordinary all-order proof is paper/main-interval-half-density.md.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def compulsory(h):
    return {1, h-3, h-2, h, h+2}


def safe_sets(h):
    return [(h, 1), (h, h-3, h-2), (h, h-2, h+2)]


def parameters(n, h, variant="gap"):
    if not (h >= 7 and h % 4 == 3 and 2*h+2 <= n and math.gcd(h, n) == 1):
        raise ValueError("circle arithmetic hypotheses do not hold")
    if variant not in {"full", "gap"} or (variant == "full" and n % 4):
        raise ValueError("full circles require n divisible by four")
    end = n-1 if variant == "full" else n-h
    A = ({x for x in range(end+1) if x % 4 in {0, 1}} | {h}) - {2*h-1}
    C = compulsory(h)
    assert len(C) == 5 and 0 not in C and C | {0} <= A
    return {"n": n, "h": h, "variant": variant, "A": sorted(A),
            "C": sorted(C), "minimum_m": 5*n, "maximum_m": n*(len(A)-1)}


def recipes(n):
    """All arithmetic recipes at one order, in a fixed reproducible order."""
    return [parameters(n, h, variant)
            for h in range(7, (n-2)//2+1, 4) if math.gcd(h, n) == 1
            for variant in (["full", "gap"] if n % 4 == 0 else ["gap"])]


def best_recipe(n):
    rows = recipes(n)
    if not rows:
        raise ValueError(f"no stated circle recipe at order {n}")
    return min(rows, key=lambda r: (-r["maximum_m"], r["h"], r["variant"]))


def intervals(n):
    """Coverage API: all recipes share their lower endpoint, so keep the best."""
    if not recipes(n):
        return []
    row = best_recipe(n)
    return [{"n": n, "m_min": row["minimum_m"], "m_max": row["maximum_m"],
             "h": row["h"], "variant": row["variant"]}]


def construct(n, m, *, h=None, variant=None):
    """Return the exact loopless arc list; no discovery or game search."""
    if h is None:
        row = best_recipe(n)
    else:
        row = parameters(n, h, variant or ("full" if n % 4 == 0 else "gap"))
    if not row["minimum_m"] <= m <= row["maximum_m"]:
        raise ValueError("budget outside circle recipe interval")
    C, A = set(row["C"]), set(row["A"])
    arcs = {(u, (u+d) % n) for u in range(n) for d in C}
    optional = sorted((u, (u+d) % n) for u in range(n) for d in A-C-{0})
    arcs.update(optional[:m-len(arcs)])
    assert len(arcs) == m and all(u != v for u, v in arcs)
    return sorted(arcs)


def propagation(h):
    return [(2-h, (h, h-3, h-2)), (-h, (h, h-2, h+2)),
            (-1-h, (h, 1)), (-2-h, (h, 1))]


def verify(row):
    """Replay premises, all cop positions, seed and integer propagation."""
    n, h = row["n"], row["h"]
    assert row == parameters(n, h, row["variant"])
    A, C = set(row["A"]), set(row["C"])
    sets = safe_sets(h)
    for S in sets:
        assert set(S) <= C
        assert max(S)-min(S) <= h-1
        assert all(not all((x-q) % n in A for x in S) for q in range(1, n))
    if row["variant"] == "gap":
        assert max(A) <= n-h
    else:
        assert len(A) == n//2
    P = {-2, -1, 0, 2}
    seed = {x-h for x in P}
    direct = {0} | {-c for c in C}
    assert seed-{-h-1} <= direct
    assert {-h-1+h, -h-1+1} <= direct
    W = set(P)
    for x, S in propagation(h):
        assert S in sets and {x+d for d in S} <= W
        W.add(x)
    assert {x-h for x in P} <= W
    assert math.gcd(h, n) == 1
    assert {(x-h*j) % n for x in P for j in range(n)} == set(range(n))
    return {"safe_cop_obligations": len(sets)*(n-1), "integer_propagation_steps": 4}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--maximum-order", type=int, default=160)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    counts = {"safe_cop_obligations": 0, "integer_propagation_steps": 0}
    rows, count = [], 0
    for n in range(16, args.maximum_order+1):
        rr = recipes(n)
        for row in rr:
            for key, value in verify(row).items():
                counts[key] += value
            count += 1
        if rr:
            row = best_recipe(n)
            for m in {row["minimum_m"], min(row["minimum_m"]+1, row["maximum_m"]), row["maximum_m"]}:
                assert len(construct(n, m)) == m
            rows.append(row)
    result = {"status": "finite structural replay passed; ordinary theorem is separate",
              "recipe_parameters_checked": count, "minimum_order": 16,
              "maximum_order": args.maximum_order, **counts, "best_recipes": rows}
    if args.out:
        args.out.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({k: v for k, v in result.items() if k != "best_recipes"}))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Independent literal graph map and two-turn queue attractor for sparse crops.

No graph generator, arena builder, or solver is imported from the primary lane.
"""
from heapq import heappush,heappop
from pathlib import Path
import json,time
ROOT=Path(__file__).resolve().parents[1]
RULES=((0,1,-3,5),(0,3,-3,5),(1,1,-3,5),(1,3,-3,5),
       (1,3,3,0),(2,3,-3,5),(2,4,-3,0))
EXTRAS=((1,-3,5),(3,-3,5),(4,-3,0),(4,3,1),(2,3,0),
        (3,3,0),(3,-3,0),(5,-2,0))

def arrows(v,holes):
    i,j=v
    if j==0:return ((i,1),(i,5))
    if j==1:return ((i,2),(i+2,2) if i+1 in holes else(i+1,4))
    if j==2:return ((i,3),(i+1,1))
    if j==3:return ((i,5) if i in holes else(i,4),(i-1,0))
    if j==4:return ((i,5),(i+1,2))
    if j==5:return ((i+1,0),(i-1,3))
    raise ValueError(v)

def make_arena(holes,messenger_radius=4,cop_radius=8):
    holes=set(holes)
    vertices=lambda radius:[(i,j) for i in range(-radius,radius+1)
                           for j in range(6) if j!=4 or i not in holes]
    rv=vertices(messenger_radius);cv=vertices(cop_radius)+[None]
    ri={v:i for i,v in enumerate(rv)};ci={v:i for i,v in enumerate(cv)}
    omega=len(cv)-1
    rm=[];cm=[]
    for v in rv:rm.append([ri[u] for u in (v,*arrows(v,holes)) if u in ri])
    for v in cv[:-1]:
        i,j=v;opts={ci.get(u,omega) for u in (v,*arrows(v,holes))}
        for typ,destshift,t in EXTRAS:
            if typ!=j:continue
            if any((i-h,j,destshift,t) in RULES for h in holes):continue
            opts.add(ci.get((i+destshift,t),omega))
        cm.append(sorted(opts))
    cm.append([i for i,v in enumerate(cv) if v is None or abs(v[0])>=cop_radius-2])
    return rv,cv,rm,cm

def solve_two_turns(a,target,start_columns=None,retain_certificate=False):
    rv,cv,rm,cm=a;nr,nc=len(rv),len(cv);count=nr*nc
    goal={r for r,v in enumerate(rv) if v[0]==0 and(target is None or v[1]==target)}
    collision={r*nc+c for r,v in enumerate(rv) for c,w in enumerate(cv) if v==w}
    rmback=[[]for _ in rv];cmback=[[]for _ in cv]
    for r,opts in enumerate(rm):
        for z in opts:rmback[z].append(r)
    for c,opts in enumerate(cm):
        for z in opts:cmback[z].append(c)
    win=bytearray(2*count);remaining=[len(cm[c]) for r in rv for c in range(nc)]
    ranks=[-1]*(2*count);pendingmax=[0]*count;queue=[]
    def add(v,rank):
        if not win[v]:win[v]=1;ranks[v]=rank;heappush(queue,(rank,v))
    for r in goal:
        for c in range(nc):
            state=r*nc+c
            if target is not None:
                add(state,0);add(count+state,0)
            elif state not in collision:add(state,0)
    while queue:
        _,v=heappop(queue);phase=v//count;r,c=divmod(v%count,nc)
        if phase:
            for prev in rmback[r]:
                pred=prev*nc+c
                if pred not in collision:add(pred,ranks[v]+1)
        else:
            for prev in cmback[c]:
                pred=r*nc+prev
                if pred in collision or win[count+pred]:continue
                remaining[pred]-=1
                pendingmax[pred]=max(pendingmax[pred],ranks[v])
                if remaining[pred]==0:add(count+pred,pendingmax[pred])
    starts=set(start_columns if start_columns is not None else[-1 if target is None else-2])
    failures=[];bounds=[];by_column={v:[]for v in starts}
    for r,v in enumerate(rv):
        if v[0] not in starts:continue
        for c,w in enumerate(cv):
            if v==w:continue
            state=r*nc+c
            if not win[state]:failures.append((v,w))
            else:bounds.append(ranks[state]);by_column[v[0]].append(ranks[state])
    result={'target':target,'passed':not failures,'failures':failures[:4],
            'maximum_moves':max(bounds,default=-1),
            'entry_bounds':{str(v):max(vals,default=-1) for v,vals in sorted(by_column.items())}}
    if retain_certificate:
        policy=[-1]*count
        for r in range(nr):
            for c in range(nc):
                state=r*nc+c
                if ranks[state]<=0:continue
                policy[state]=next(z for z in rm[r] if 0<=ranks[count+z*nc+c]<ranks[state])
        result['certificate']={'messenger_ranks':ranks[:count],'cop_ranks':ranks[count:],
                               'policy':policy,'entry_columns':sorted(starts)}
    return result

def patterns():
    result=set()
    for k in range(20,30):
        for r in range(6):
            holes=[3*j for j in range(r)]
            for center in range(k):
                crop=tuple(sorted(h+period*k-center for h in holes for period in(-1,0,1)
                                  if -8<=h+period*k-center<=8))
                result.add(crop)
    return sorted(result)

def main():
    start=time.monotonic();records=[]
    for holes in patterns():
        a=make_arena(holes)
        rows=[solve_two_turns(a,t) for t in [None]+[j for j in range(6) if j!=4 or 0 not in holes]]
        record={'holes':holes,'passed':all(x['passed'] for x in rows),'objectives':rows}
        records.append(record)
        if not record['passed']:
            print('FAIL',record,flush=True);break
    receipt={'method':'literal type-specific arrows; independent explicit messenger/cop turn AND-OR queue',
             'verified':all(x['passed'] for x in records) and len(records)==len(patterns()),
             'patterns':len(patterns()),'checked':len(records),'seconds':time.monotonic()-start,
             'rules':RULES,'records':records}
    (ROOT/'research/dense-phase2-sparse-independent.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print({k:v for k,v in receipt.items() if k not in ('records','rules')})

if __name__=='__main__':main()

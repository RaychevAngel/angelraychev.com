#!/usr/bin/env python3
"""Record bounded independent fixed-budget n7 upper replays."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'src/small_case_n7_independent.cpp'
BINARY=Path('/tmp/cop-small-case-n7-independent')


def main():
    subprocess.run(['c++','-O3','-std=c++17',str(SOURCE),'-o',str(BINARY)],check=True)
    primary_path=ROOT/'research/small-case-n7-primary.json'
    primary=json.loads(primary_path.read_text())
    records=[];new_certificates=[]
    for row in primary['records']:
        m=row['m'];lower=row['lower'];start=time.monotonic();runs=[]
        neighbor=ROOT/f'research/small-case-n7-neighbor-m{m}-certificate.json'
        if neighbor.exists():lower=max(lower,json.loads(neighbor.read_text())['I'])
        exact=False
        while time.monotonic()-start<60:
            remaining=60-(time.monotonic()-start)
            command=[str(BINARY),'7',str(lower+1),str(m),str(m),str(remaining)]
            run=subprocess.run(command,capture_output=True,text=True,check=True)
            result=json.loads(run.stdout);runs.append(result)
            if result['counterexample_found']:
                graph=solve_graph(7,result['arcs'],certificates=True,crosscheck=True)
                assert graph['I']==result['best_I'] and graph['I']>lower
                lower=graph['I'];new_certificates.append(graph)
            elif result['complete']:
                assert result['first_profile']==0
                assert result['checked_profiles']==result['total_profiles']
                exact=True;break
            else:break
        records.append(dict(n=7,m=m,lower=lower,exact_by_independent=exact,runs=runs))
        report=dict(verified=all(r['exact_by_independent'] for r in records),
                    scope='Independent descending-degree/suffix-cell enumeration '
                          'with explicit alternating game and a two-dimensional '
                          'incidence cap. Every complete record covers all its '
                          'degree profiles; incomplete records prove no upper.',
                    source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                    historical_source_sha256=hashlib.sha256((ROOT/'src/small_arcs_sparse_independent.cpp').read_bytes()).hexdigest(),
                    primary_input_sha256=hashlib.sha256(primary_path.read_bytes()).hexdigest(),
                    runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    records=records)
        (ROOT/'research/small-case-n7-independent.json').write_text(json.dumps(report,indent=2)+'\n')
        (ROOT/'research/small-case-n7-independent-new-certificates.json').write_text(json.dumps(new_certificates,separators=(',',':'))+'\n')
        print(json.dumps(dict(m=m,lower=lower,complete=exact,
                              seconds=round(time.monotonic()-start,3),
                              nodes=sum(r['nodes'] for r in runs))),flush=True)


if __name__=='__main__':main()

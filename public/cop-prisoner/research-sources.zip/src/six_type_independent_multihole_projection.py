#!/usr/bin/env python3
"""Independent arena-map and counting checks for the packed-hole bridge.

This reuses the independent explicit six-type successor definition, not
the primary SmoothStrip generator. It checks simulations and construction
counts; it does not rerun the previously certified game attractors.
"""
import hashlib
import itertools
import json
from pathlib import Path

import six_type_independent_spacing as old
from six_type_independent_augmented import EXTRA
from six_type_budget_multihole_certificate import build as primary_build

ROOT = Path(__file__).resolve().parents[1]


def bigger(holes):
    holes = set(holes)
    messenger = [(i, j) for i in range(-4, 5) for j in range(6)
                 if not (i in holes and j == 4)]
    cops = [(i, j) for i in range(-8, 9) for j in range(6)
            if not (i in holes and j == 4)] + [None]
    mi, ci = {v: i for i, v in enumerate(messenger)}, {v: i for i, v in enumerate(cops)}
    mm = [[mi[w] for w in (v, *old.outgoing(v, holes)) if w in mi] for v in messenger]
    cm = []
    for v in cops:
        if v is None:
            cm.append([i for i, w in enumerate(cops) if w is None or abs(w[0]) >= 6])
        else:
            cm.append(sorted({ci.get(w, ci[None]) for w in (v, *old.outgoing(v, holes))}))
    return dict(messenger=messenger, cops=cops, messenger_moves=mm, cop_moves=cm)


def check_pattern(holes):
    a = bigger(holes)
    b = old.arena([i for i in holes if -6 <= i <= 6])
    assert a['messenger'] == b['messenger']
    assert a['messenger_moves'] == b['messenger_moves']
    small_index = {v: i for i, v in enumerate(b['cops'])}
    pi = [small_index.get(v, small_index[None]) for v in a['cops']]
    edges = 0
    for c, destinations in enumerate(a['cop_moves']):
        assert {pi[d] for d in destinations} <= set(b['cop_moves'][pi[c]])
        edges += len(destinations)
    for v in a['messenger']:
        for c, w in enumerate(a['cops']):
            assert (v == w) == (v == b['cops'][pi[c]])
    p = primary_build(holes)
    assert a['messenger'] == p['messenger_vertices']
    assert a['cops'] == p['pursuer_vertices']
    assert a['messenger_moves'] == p['messenger_moves']
    assert a['cop_moves'] == p['pursuer_moves']
    return edges, len(a['messenger']) * len(a['cops'])


def check_ring(n):
    k = (n + 5) // 6
    r = 6*k - n
    holes = {3*j for j in range(r)}
    lifts = {h + d*k for h in holes for d in (-1, 0, 1)}
    vertices = {(i, j) for i in range(k) for j in range(6)
                if not (i in holes and j == 4)}
    base = {(v, (w[0] % k, w[1])) for v in vertices for w in old.outgoing(v, lifts)}
    assert len(vertices) == n and len(base) == 2*n
    indegrees, outdegrees = {v: 0 for v in vertices}, {v: 0 for v in vertices}
    for v, w in base:
        assert v != w and w in vertices
        indegrees[w] += 1
        outdegrees[v] += 1
    assert set(indegrees.values()) == set(outdegrees.values()) == {2}
    allowed = [i for i in range(k)
               if all(min((i-h) % k, (h-i) % k) > 16 for h in holes)]
    optional = {((i, j), ((i+d) % k, t)) for i in allowed for j, d, t in EXTRA}
    assert len(optional) == 8*len(allowed) >= n
    assert not base & optional
    assert all(v in vertices and w in vertices and v != w for v, w in optional)
    for budget in (2*n, 2*n+1, 3*n-1, 3*n):
        assert len(base | set(sorted(optional)[:budget-2*n])) == budget
    return dict(n=n, columns=k, holes=sorted(holes), optional_arcs=len(optional))


def main():
    count, edges, collisions = 0, 0, 0
    cardinalities = []
    for size in range(6):
        at_size = 0
        for holes in itertools.combinations(range(-8, 9), size):
            if any(b-a < 3 for a, b in zip(holes, holes[1:])):
                continue
            e, c = check_pattern(holes)
            edges += e
            collisions += c
            count += 1
            at_size += 1
        cardinalities.append(at_size)
    assert count == 865
    result = dict(verified=True, patterns=count, pattern_counts=cardinalities,
                  projected_cop_edges=edges, collision_equalities=collisions,
                  compared_primary_arenas=count,
                  rings=[check_ring(n) for n in range(1075, 1081)],
                  scope='Independent explicit arena simulations and structural counts; old game certificates reused, no new attractor search',
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  independent_successor_sha256=hashlib.sha256(Path(old.__file__).read_bytes()).hexdigest())
    (ROOT/'research/six-type-independent-multihole-projection.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()

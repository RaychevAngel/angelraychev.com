// Complete normalized depth-two enumeration for missing-outdegree-two cores.
// A time-limited run is explicitly incomplete and supplies no exclusion.
// No missing indegree restriction is imposed.
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
using G=array<unsigned,8>;
int n; unsigned allv; G g{},best_graph{}; array<bool,8> assigned{};
vector<unsigned> candidates[8];
uint64_t nodes=0,leaves=0; int best=-1; bool capped=false,found=false;
double seconds; chrono::steady_clock::time_point started;

bool consistent(){
 for(int v=0;v<n;v++)if(assigned[v]){
  for(int u=0;u<v;u++)if(assigned[u] && g[u]==g[v])return false;
  unsigned bits=g[v]; int x=__builtin_ctz(bits);bits&=bits-1;int y=__builtin_ctz(bits);
  if(assigned[x] && (g[x]>>y&1))return false;
  if(assigned[y] && (g[y]>>x&1))return false;
  if(assigned[x] && assigned[y] && (g[x]&g[y]))return false;
 }
 return true;
}

int score(){
 G out{};for(int s=0;s<n;s++)out[s]=allv^g[s];
 int ans=0;
 for(int target=0;target<n;target++){
  G wins{};wins[target]=allv;
  for(;;){
   G safe{},next{};safe[target]=allv;
   for(int v=0;v<n;v++)if(v!=target)
    for(int c=0;c<n;c++)if(!(out[c]&~wins[v]))safe[v]|=1u<<c;
   for(int s=0;s<n;s++){
    if(s==target){next[s]=allv;continue;}
    for(unsigned options=out[s];options;options&=options-1)
     next[s]|=safe[__builtin_ctz(options)];
    next[s]&=allv^(1u<<s);
   }
   if(next==wins)break;
   wins=next;
  }
  for(int s=0;s<n;s++)if((g[s]>>target&1) && wins[s]==(allv^(1u<<s)))ans++;
 }
 return ans;
}

void dump(const char*kind){
 cout<<"{\"kind\":\""<<kind<<"\",\"n\":"<<n<<",\"nodes\":"<<nodes
     <<",\"leaves\":"<<leaves<<",\"best_I\":"<<best<<",\"missing_masks\":[";
 for(int s=0;s<n;s++)cout<<(s?",":"")<<best_graph[s];
 cout<<"],\"capped\":"<<(capped?"true":"false")
     <<",\"universal_found\":"<<(found?"true":"false")<<"}"<<endl;
}

void visit(int depth){
 if(capped||found)return;
 ++nodes;
 if((nodes&1023)==0 && chrono::duration<double>(chrono::steady_clock::now()-started).count()>seconds){capped=true;return;}
 if(depth==n){
  ++leaves;int value=score();
  if(value>best){best=value;best_graph=g;if(best==2*n)found=true;dump("record");}
  return;
 }
 int chosen=-1;vector<unsigned> allowed;
 for(int v=0;v<n;v++)if(!assigned[v]){
  vector<unsigned> valid;assigned[v]=true;
  for(unsigned row:candidates[v]){g[v]=row;if(consistent())valid.push_back(row);}
  assigned[v]=false;g[v]=0;
  if(valid.empty())return;
  if(chosen<0 || valid.size()<allowed.size()){chosen=v;allowed=move(valid);}
 }
 assigned[chosen]=true;
 for(unsigned row:allowed){g[chosen]=row;visit(depth+1);if(capped||found)break;}
 assigned[chosen]=false;g[chosen]=0;
}

int main(int argc,char**argv){
 n=argc>1?stoi(argv[1]):8;seconds=argc>2?stod(argv[2]):30;
 if(n<7 || n>8)return 2;
 allv=(1u<<n)-1;started=chrono::steady_clock::now();
 for(int s=0;s<n;s++)for(int x=0;x<n;x++)for(int y=x+1;y<n;y++)
  if(x!=s&&y!=s)candidates[s].push_back((1u<<x)|(1u<<y));
 for(int mutual=0;mutual<2;mutual++){
  assigned.fill(false);g.fill(0);assigned[0]=assigned[1]=assigned[2]=true;
  g[0]=(1u<<1)|(1u<<2);
  if(mutual){g[1]=(1u<<0)|(1u<<3);g[2]=(1u<<4)|(1u<<5);}
  else{g[1]=(1u<<3)|(1u<<4);g[2]=(1u<<5)|(1u<<6);}
  if(consistent())visit(3);
  if(capped||found)break;
 }
 dump(capped?"incomplete":found?"witness":"complete");
}

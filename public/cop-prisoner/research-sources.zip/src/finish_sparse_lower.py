#!/usr/bin/env python3
"""Time-bounded exact-score local search; every saved best gets full replay."""
import argparse
import ctypes
import json
import math
from pathlib import Path
import random
import time
from small_plateau_probe import ROOT, LIB, certificate, evaluate, seed_graphs


def search(n,m,seconds,seed):
    rng=random.Random(seed);start=time.monotonic();calls=0
    universe={(s,t) for s in range(n) for t in range(n) if s!=t}
    seeds=[]
    for graph in seed_graphs():
        if graph['n']==n:seeds.append(set(map(tuple,graph['arcs'])))
    if n==11:
        path=ROOT/'research/small-exceptional-one-excess-11-witness-certificate.json'
        graph=json.loads(path.read_text())
        seeds.append(set(map(tuple,graph['arcs'])))
    for path in sorted((ROOT/'research').glob('small-plateau-*-certificate.json')):
        graph=json.loads(path.read_text())
        if graph['n']<=n and abs(graph['m']-m)<=1:
            seeds.append(set(map(tuple,graph['arcs'])))
    sparse_seed=ROOT/'research/small-sparse-regular-10-witness.json'
    if n>=10 and sparse_seed.exists():
        graph=json.loads(sparse_seed.read_text())
        if abs(graph['m']-m)<=1:
            seeds.append(set(map(tuple,graph['arcs'])))
    dense_seeds=ROOT/'research/small-dense-endpoint-certificates.json'
    if dense_seeds.exists():
        for graph in json.loads(dense_seeds.read_text()):
            if graph['n']==n and abs(graph['m']-m)<=1:
                seeds.append(set(map(tuple,graph['arcs'])))
    for name in ['small-case-fixed-certificates.json','finish_constructions_certificates.json']:
        for graph in json.loads((ROOT/'research'/name).read_text()):
            if graph['n']<=n and abs(graph['m']-m)<=1:
                seeds.append(set(map(tuple,graph['arcs'])))
    seeds=list({tuple(sorted(x)):x for x in seeds}.values())
    arrtype=ctypes.c_uint32*n;restype=ctypes.c_uint32*(n*n)
    answer=restype();allv=(1<<n)-1
    cache={}
    def score(arcs):
        nonlocal calls
        key=tuple(sorted(arcs))
        if key in cache:return cache[key]
        rows=[1<<v for v in range(n)]
        for s,t in arcs:rows[s]|=1<<t
        closed=arrtype(*rows)
        states=LIB.small_plateau_eval(n,closed,closed,answer)
        I=sum(answer[t*n+s]==allv^(1<<s)
              for s in range(n) for t in range(n)
              if not (rows[s]>>t&1))
        calls+=1
        value=(I,states)
        if len(cache)>200000:cache.clear()
        cache[key]=value
        return value
    initial=[]
    for arcs in seeds:
        if len(arcs)==m:initial.append(arcs)
        elif len(arcs)==m+1:initial.extend(arcs-{e} for e in sorted(arcs))
        elif len(arcs)==m-1:initial.extend(arcs|{e} for e in sorted(universe-arcs))
    if not initial:
        initial=[set(rng.sample(sorted(universe),m))]
    population=sorted([(score(arcs),arcs) for arcs in initial],
                      key=lambda row:row[0],reverse=True)[:12]
    best_value,best=population[0];best=set(best)
    progress=[dict(seconds=time.monotonic()-start,I=best_value[0],states=best_value[1])]
    current=set(best);current_value=best_value;iterations=0;restarts=0
    maxstates=n*(n-1)*(n-1)
    while time.monotonic()-start<seconds:
        iterations+=1
        if iterations%1200==1:
            restarts+=1
            current=set(population[rng.randrange(len(population))][1])
            for _ in range(rng.randrange(1,6)):
                current.remove(rng.choice(sorted(current)))
                current.add(rng.choice(sorted(universe-current)))
            current_value=score(current)
        move=rng.randrange(4);candidate=set(current)
        e=rng.choice(sorted(current))
        if move==0:
            # A two-switch preserves both degree sequences when nondegenerate.
            f=rng.choice(sorted(current));new={(e[0],f[1]),(f[0],e[1])}
            if e==f or len(new)!=2 or any(s==t for s,t in new) or new&current:continue
            candidate.difference_update([e,f]);candidate.update(new)
        else:
            candidate.remove(e)
            choices=(universe-candidate)
            if move==1:choices={f for f in choices if f[0]==e[0]}
            if move==2:choices={f for f in choices if f[1]==e[1]}
            if not choices:continue
            candidate.add(rng.choice(sorted(choices)))
        value=score(candidate)
        delta=(value[0]-current_value[0])+(value[1]-current_value[1])/maxstates
        temperature=0.65*(1-(iterations%1200)/1200)**2+0.012
        if delta>=0 or rng.random()<math.exp(max(-700,delta/temperature)):
            current=candidate;current_value=value
        if value>best_value:
            best_value=value;best=set(candidate)
            population.append((value,set(candidate)))
            population=sorted(population,key=lambda row:row[0],reverse=True)[:12]
            item=dict(seconds=round(time.monotonic()-start,3),I=value[0],states=value[1],calls=calls)
            progress.append(item);print(json.dumps(dict(n=n,m=m,improvement=item)),flush=True)
    cert=certificate(n,best)
    assert cert['I']==best_value[0]
    tag=f'n{n}-m{m}-seed{seed}'
    path=ROOT/f'research/finish-sparse-lower-{tag}-certificate.json'
    path.write_text(json.dumps(cert,indent=2)+'\n')
    report=dict(n=n,m=m,seed=seed,seconds=time.monotonic()-start,
                exact_game_evaluations=calls,mutation_iterations=iterations,
                restarts=restarts,I=best_value[0],winning_states=best_value[1],
                certificate=str(path),progress=progress,
                scope='Bounded local search only; best graph independently '
                      'crosschecked by both actual-game solvers and complete '
                      'winning/losing rank-certificate replay. No upper bound.')
    (ROOT/f'research/finish-sparse-lower-{tag}.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('n',type=int);parser.add_argument('m',type=int)
    parser.add_argument('--seconds',type=float,default=20)
    parser.add_argument('--seed',type=int,default=20260913)
    args=parser.parse_args()
    search(args.n,args.m,args.seconds,args.seed)

#!/usr/bin/env python3
"""Quadratic missing-arc envelope with three protected intermediaries."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from game_solver import neighborhoods, recipient_explicit, recipient_fast, verify_certificate

ROOT = Path(__file__).resolve().parents[1]
CORE = (1, 3, 7)

def missing_envelope(n):
    if n < 19:
        raise ValueError("Requires n>=19")
    protected = {d % n for d in (-6, -4, -2, 2, 4, 6)}
    excluded = {d % n for d in (-9, -5, -3, 3, 5, 9)}
    assert len(protected) == len(excluded) == 6
    values = set(CORE)
    goal = max(3, (n + 11)//13)
    while len(values) < goal:
        forbidden = {0} | values | {(v+d) % n for v in values for d in protected | excluded}
        assert len(forbidden) <= 13*len(values)+1 < n
        values.add(next(v for v in range(n) if v not in forbidden))
    assert 0 not in values
    for d in protected:
        actual = {(u,v) for u in values for v in values if (u-v) % n == d}
        original = {(u,v) for u in CORE for v in CORE if (u-v) % n == d}
        assert actual == original and len(actual) == 1
    assert not any((u-v) % n in excluded for u in values for v in values)
    return tuple(sorted(values))

def construct(n, h):
    values = missing_envelope(n)
    if not 3*n <= h <= n*len(values):
        raise ValueError("Missing budget is outside the proved envelope interval")
    missing = {(v,(v+d) % n) for v in range(n) for d in CORE}
    extras = sorted((v,(v+d) % n) for v in range(n) for d in values if d not in CORE)
    missing.update(extras[:h-3*n])
    assert len(missing) == h and all(s != t for s,t in missing)
    return missing, values

def safe_intermediaries(n, missing):
    outgoing, incoming = [0]*n, [0]*n
    for s,t in missing:
        outgoing[s] |= 1 << t
        incoming[t] |= 1 << s
    core = [sum(1 << ((c+d) % n) for d in CORE) for c in range(n)]
    checked = 0
    for s,t in missing:
        blocked = outgoing[s] | incoming[t]
        assert blocked & (1 << s) and blocked & (1 << t)
        for c in range(n):
            if c == s:
                continue
            safe = core[c] & ~blocked
            assert safe, (n,s,t,c)
            u = (safe & -safe).bit_length()-1
            assert u not in (s,t,c)
            assert (c,u) in missing and (s,u) not in missing and (u,t) not in missing
            checked += 1
    return checked

def checks():
    envelopes, cases, full = [], [], []
    for n in (19, 29, 40, 41, 53, 75, 100, 200, 1000, 5442):
        values = missing_envelope(n)
        envelopes.append({"n": n, "missing_steps": values, "minimum_h": 3*n, "maximum_h": n*len(values)})
    for n in (19, 29, 41, 53, 75, 100, 200):
        top = n*len(missing_envelope(n))
        budgets = {3*n, (3*n+top)//2, top}
        if 3*n < top:
            budgets.add(3*n+1)
        for h in sorted(budgets):
            missing, _ = construct(n,h)
            count = safe_intermediaries(n,missing)
            cases.append({"n": n, "h": h, "m": n*(n-1)-h,
                          "missing_pair_cop_triples_checked": count, "all_have_safe_core_intermediary": True})
            if n in (19,41,53) and h in {3*n,top}:
                arcs = [(s,t) for s in range(n) for t in range(n) if s != t and (s,t) not in missing]
                out,_ = neighborhoods(n,arcs)
                for target in (0,n-1):
                    fast,_ = recipient_fast(n,out,target)
                    explicit,certificate = recipient_explicit(n,out,target,certificate=True)
                    assert fast == explicit
                    verify_certificate(n,out,certificate)
                    allv = (1 << n)-1
                    assert all((row | (1 << s)) == allv for s,row in enumerate(fast))
                    full.append({"n":n,"h":h,"target":target,"verified":True})
    return envelopes,cases,full

def main():
    envelopes,cases,full = checks()
    receipt = {"verified":True,
               "proof_boundary":"Ordinary arbitrary-order theorem with finite checks only for listed orders, budgets, and recipients; no new Lean coverage.",
               "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "structural_envelopes":envelopes,"two_move_checks":cases,"independent_full_game_checks":full,
               "total_missing_pair_cop_triples":sum(c['missing_pair_cop_triples_checked'] for c in cases)}
    path = ROOT/'research/dense-protected-envelope-checks.json'
    path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({"verified":True,"orders":len(envelopes),"two_move_cases":len(cases),
                      "full_game_recipient_checks":len(full),"triples":receipt['total_missing_pair_cop_triples'],"receipt":str(path)}))

if __name__ == '__main__':
    main()

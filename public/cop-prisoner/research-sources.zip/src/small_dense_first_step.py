#!/usr/bin/env python3
"""Literal first dense-step graphs at orders seven through ten."""
import argparse
import hashlib
import json
from pathlib import Path
from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]
ROWS={
 7:((1,),(0,),(0,1),(0,),(2,5,6),(3,4,6),(2,3)),
 8:((1,),(0,),(0,),(0,),(2,5,6),(3,6,7),(2,4,7),(3,4)),
 9:((1,2,3),(2,4,5),(0,6),(1,6),(0,5),(4,6),(7,),(8,),(7,)),
 10:((2,7),(3,4,5),(0,1,4),(4,6),(0,3),(6,7),(2,5),(8,),(9,),(8,)),
}

def construct(n,m):
    if n not in ROWS or m!=n*(n-3)+1:raise ValueError('outside four fixed first steps')
    return [(s,t)for s in range(n)for t in range(n)if s!=t and t not in ROWS[n][s]]

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check',action='store_true');args=parser.parse_args()
    results=[]
    for n,value in ((7,8),(8,11),(9,14),(10,16)):
        game=solve_graph(n,construct(n,n*(n-3)+1),crosscheck=True,certificates=True)
        assert game['I']==value;results.append(game)
    path=ROOT/'research/small-dense-first-step-certificates.json'
    encoded=json.dumps(results,separators=(',',':'))+'\n'
    if args.check:assert path.read_text()==encoded
    else:path.write_text(encoded)
    report={'status':'verified','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'graphs':[{key:g[key]for key in ('n','m','I','max_state_delivery_moves')}for g in results],
            'certificates':str(path.relative_to(ROOT)),'certificate_sha256':hashlib.sha256(encoded.encode()).hexdigest(),
            'proof_boundary':'Four full actual-game witnesses. Exactness at7 uses the independent complete finite table; at8,9,10 it additionally uses the first-step equality/defect reductions and complete profile checks in the separate proof. No Lean claim.'}
    path=ROOT/'research/small-dense-first-step-checks.json';encoded=json.dumps(report,indent=2)+'\n'
    if args.check:assert path.read_text()==encoded
    else:path.write_text(encoded)
    print(json.dumps(report['graphs']))

if __name__=='__main__':main()

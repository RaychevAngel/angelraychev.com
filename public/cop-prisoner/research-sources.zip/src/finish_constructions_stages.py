#!/usr/bin/env python3
"""Finite selected-pair stage construction from saved literal lower witnesses."""
import collections
import itertools
import json
import time
from pathlib import Path
from small_plateau_probe import ROOT,evaluate,certificate
from small_case_certificate_review import review as review_literal
from finish_constructions_stage_review import review


def mixed_certificate(n,B,E):
    rm=[{s}|{t for u,t in B if u==s} for s in range(n)]
    cm=[{s}|{t for u,t in E if u==s} for s in range(n)]
    certificates=[]; protected=set()
    for t in range(n):
        size=2*n*n; rev=[[] for _ in range(size)]; remaining=[0]*size
        rank=[-1]*size; policy=[-1]*size; maxrank=[0]*size; queue=collections.deque()
        for s in range(n):
            for c in range(n):
                for turn in (0,1):
                    p=2*(s*n+c)+turn
                    if s==t: rank[p]=0;queue.append(p);continue
                    if s==c:continue
                    children=([2*(u*n+c)+1 for u in rm[s]] if turn==0
                              else [2*(s*n+d) for d in cm[c]])
                    remaining[p]=len(children)
                    for q in children:rev[q].append(p)
        while queue:
            q=queue.popleft()
            for p in rev[q]:
                if rank[p]>=0:continue
                if p%2==0:
                    rank[p]=rank[q]+1;policy[p]=q;queue.append(p)
                else:
                    remaining[p]-=1;maxrank[p]=max(maxrank[p],rank[q])
                    if remaining[p]==0:rank[p]=maxrank[p]+1;queue.append(p)
        for s in range(n):
            if s!=t and (s,t) not in B and all(rank[2*(s*n+c)]>=0 for c in range(n) if c!=s):protected.add((s,t))
        certificates.append(dict(target=t,rank=rank,messenger_successor=policy))
    assert protected==evaluate(n,B,E)[2]
    F=E-B;recipe=sorted(F-protected)+sorted(F&protected);safe=len(F-protected)
    result=dict(n=n,m_min=len(B),m_max=len(E),base_arcs=sorted(B),envelope_arcs=sorted(E),
        protected_pairs=sorted(protected),recipe_arrows=recipe,certificates=certificates,
        lower_curve=[dict(m=len(B)+k,I_lower=len(protected)-max(0,k-safe)) for k in range(len(F)+1)])
    review(result)
    return result


def main():
    start=time.monotonic(); graphs=json.loads((ROOT/'research/finish_constructions_certificates.json').read_text())
    best={(g['n'],g['m']):g['I'] for g in graphs}; stages=[]; improved=[]; trials=[]
    for graph in graphs:
        n=graph['n'];m=graph['m']
        if (n==8 and m>=39) or (n==9 and m>=23) or (n==10 and m>=27):continue
        B=set(map(tuple,graph['arcs']));E=set(B);universe=set(itertools.permutations(range(n),2))
        max_m=min(m+4,{8:39,9:23,10:27}[n]);best_stage=None
        for new_m in range(m+1,max_m+1):
            options=[]
            for edge in sorted(universe-E):
                candidate=E|{edge};result=evaluate(n,B,candidate)
                robust=len(result[2]-candidate)
                options.append(((robust,result[1]),edge,candidate,result[2]))
            value,edge,E,P=max(options,key=lambda row:row[0])
            F=E-B;safe=len(F-P)
            curve=[(m+k,len(P)-max(0,k-safe)) for k in range(len(F)+1)]
            matches=[(mm,v) for mm,v in curve if mm>m and v>=best.get((n,mm),10**9)]
            trials.append(dict(n=n,m_min=m,m_max=new_m,lower=curve,matches=matches))
            if matches:best_stage=(set(E),curve)
        if best_stage is None:continue
        stage=mixed_certificate(n,B,best_stage[0]);stages.append(stage)
        current=set(B)
        for edge in stage['recipe_arrows']:
            current.add(tuple(edge));mm=len(current);actual=evaluate(n,current)[0]
            if actual>best.get((n,mm),-1):
                g=certificate(n,current);review_literal(g);improved.append(g);best[(n,mm)]=actual
                print(json.dumps(dict(improvement=(n,mm,actual),source='protected_pair_stage_recipe')),flush=True)
    (ROOT/'research/finish_constructions_stages.json').write_text(json.dumps(stages,indent=2)+'\n')
    (ROOT/'research/finish_constructions_stage_improvements.json').write_text(json.dumps(improved,indent=2)+'\n')
    summary=dict(seconds=time.monotonic()-start,records=[review(g) for g in stages],trials=trials,
                 scope='Finite greedy envelope construction, not global search or upper proof.')
    (ROOT/'research/finish_constructions_stage_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(dict(seconds=summary['seconds'],stages=len(stages),improvements=[(g['n'],g['m'],g['I']) for g in improved])))


if __name__=='__main__':main()

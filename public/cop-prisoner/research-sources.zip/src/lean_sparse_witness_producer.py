#!/usr/bin/env python3
"""Export saved mixed-score rank data; Lean checks every claimed obligation.

No game solving or enumeration. This exporter is outside the trust boundary.
"""
import argparse,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def array(name,typ,values,width):
    rows=[','.join(map(str,values[i:i+width])) for i in range(0,len(values),width)]
    return f'def {name} : Array {typ} := #[\n  '+',\n  '.join(rows)+'\n]'

def nested(name,typ,values,n):
    lines=[f'def {name} (t r c : Nat) : {typ} :=', '  match t with']
    for t in range(n):
        lines += [f'  | {t} => match r with']
        for r in range(n):
            lines += [f'    | {r} => match c with']
            lines += [f'      | {c} => {values[t*n*n+r*n+c]}' for c in range(n)]
            lines += ['      | _ => 0']
        lines += ['    | _ => 0']
    lines += ['  | _ => 0']
    return '\n'.join(lines)

def produce(item):
    n=item['n'];rank=[];move=[]
    certs={c['target']:c for c in item['certificates']}
    for t in range(n):
        cert=certs[t]
        for r in range(n):
            for c in range(n):
                i=2*(r*n+c); rank.append(cert['rank'][i])
                raw=cert['messenger_successor'][i]
                move.append(raw//(2*n) if raw>=0 else r)
    masks=[sum(1<<t for s,t in item['arcs'] if s==r) for r in range(n)]
    text=f'''import SignedRankCertificate

/-! Literal frozen {n}-vertex mixed winning/losing witness, not an extremal upper bound. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.SparseWitness{n}
open FiniteGame Extremal SignedRankCertificate
{array('rowMasks','Nat',masks,n)}
def edge (s t : Fin {n}) : Prop := (rowMasks[s.val]!).testBit t.val = true
instance (s t : Fin {n}) : Decidable (edge s t) := inferInstanceAs (Decidable (_ = _))
instance (s t : Fin {n}) : Decidable (Legal edge s t) :=
  inferInstanceAs (Decidable (s = t ∨ edge s t))
{nested('signedRanks','Int',rank,n)}
{nested('moves','Nat',move,n)}
def data : Data {n} where
  signed t r c := signedRanks t.val r.val c.val
  move t r c := ⟨(moves t.val r.val c.val) % {n}, Nat.mod_lt _ (by decide)⟩

theorem checked : Checked edge data := by
  constructor <;> decide +kernel

def classification := SignedRankCertificate.classification checked

theorem loopless : Loopless edge := by
  unfold Loopless
  decide +kernel

theorem arcs : arcCount edge = {item['m']} := by
  rw [arcCount_eq]
  decide +kernel

theorem exact_score : score edge = {item['I']} := by
  rw [ExactScoreCertificates.exact_score classification]
  decide +kernel

#print axioms checked
#print axioms exact_score
end Delivery.SparseWitness{n}
'''
    p=ROOT/f'lean/SparseWitness{n}.lean';p.write_text(text);print(p.name,len(text.encode()))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--order',type=int,choices=[9,10,11]);args=ap.parse_args()
    for item in json.loads((ROOT/'research/sparse-third-fixed-lower-certificates.json').read_text()):
        if args.order is None or args.order==item['n']:produce(item)

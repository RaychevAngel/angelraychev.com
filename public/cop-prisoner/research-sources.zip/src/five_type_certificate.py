#!/usr/bin/env python3
"""Fixed local certificates for the infinite five-type family.

This is a finite proof certificate generator/checker, not extrapolation from
rings of increasing size. The independent alternating-game implementation is
src/five_type_local_verify.py. Both are outside the Lean proof trust boundary;
the current infinite-family proof is ordinary computer-assisted mathematics.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
SIGMA=(0,2,4,3,1)
SHIFT=(1,-1,-1,-1,-1)


def standard_second(v):
    i,j=v
    return (i+SHIFT[j],SIGMA[j])


def default_cuts(extra):
    return [(0,1)] if extra==1 else [(0,j) for j in range(extra)]


class Strip:
    def __init__(self,extra=0,cuts=None):
        self.extra=extra
        self.cuts=default_cuts(extra) if cuts is None else list(cuts)
        assert len(self.cuts)==extra and len(set(self.cuts))==extra
        assert all(0<=j<5 for i,j in self.cuts)
        self.replacements={v:(0,5+j) for j,v in enumerate(self.cuts)}
    def types(self,column):
        return range(5+(self.extra if column==0 else 0))
    def arcs(self,v):
        i,j=v
        first=(i,j+1) if j+1<len(self.types(i)) else (i+1,0)
        if j>=5:
            second=standard_second(self.cuts[j-5])
        else:
            second=self.replacements.get(v,standard_second(v))
        assert first!=second,(self.extra,self.cuts,v,first)
        return [first,second]



class PatchStrip(Strip):
    """A finite degree-preserving patch on the unwrapped standard strip."""
    def __init__(self,patch):
        self.extra=patch['extra'];self.cuts=[]
        def vertex(v):
            return (0,5+v[1]) if v[0]=='extra' else tuple(v)
        self.removed={(vertex(u),vertex(v)) for u,v in patch['removed_arcs']}
        self.added={}
        for u,v in patch['added_arcs']:
            self.added.setdefault(vertex(u),[]).append(vertex(v))
        self.patch=patch
    def arcs(self,v):
        i,j=v
        baseline=([((i+1,0) if j==4 else (i,j+1)),standard_second(v)] if j<5 else [])
        result=[z for z in baseline if (v,z) not in self.removed]+self.added.get(v,[])
        assert len(result)==2 and len(set(result))==2 and v not in result,(v,result)
        return result


def arena(strip,center=0,messenger_radius=3,pursuer_radius=4):
    M,R=messenger_radius,pursuer_radius
    assert R>M>=2
    rv=[(i,j) for i in range(center-M,center+M+1) for j in strip.types(i)]
    cv=[(i,j) for i in range(center-R,center+R+1) for j in strip.types(i)]+[None]
    ri={v:i for i,v in enumerate(rv)};ci={v:i for i,v in enumerate(cv)}
    rout=[[ri[u] for u in [v]+strip.arcs(v) if u in ri] for v in rv]
    cout=[]
    for v in cv:
        opts=([v]+strip.arcs(v)) if v is not None else ([None]+[
            (i,j) for i in [center-R,center+R] for j in strip.types(i)])
        cout.append(sorted({ci.get(u,len(cv)-1) for u in opts}))
    return dict(messenger_vertices=rv,pursuer_vertices=cv,messenger_moves=rout,
                pursuer_moves=cout,center=center,M=M,R=R,extra=strip.extra,cuts=strip.cuts)


def solve(a,goal,safe_transfer):
    rv,cv=a['messenger_vertices'],a['pursuer_vertices']
    ri={v:i for i,v in enumerate(rv)};ci={v:i for i,v in enumerate(cv)}
    goal={ri[v] for v in goal}
    rout,cout=a['messenger_moves'],a['pursuer_moves']
    nc=len(cv);allc=(1<<nc)-1
    cmasks=[sum(1<<c for c in row) for row in cout]
    W=[allc^(1<<ci[v]) if safe_transfer and r in goal else
       allc if r in goal else 0 for r,v in enumerate(rv)]
    ranks=[[0 if W[r]>>c&1 else -1 for c in range(nc)] for r in range(len(rv))]
    moves=[[-1]*nc for _ in rv]
    for step in range(1,5000):
        safe=[sum(1<<c for c,co in enumerate(cmasks) if co&~W[r]==0) for r in range(len(rv))]
        NW=[]
        for r,v in enumerate(rv):
            if r in goal:NW.append(W[r]);continue
            w=0
            for z in rout[r]:w|=safe[z]
            NW.append(w&~(1<<ci[v]))
        if NW==W:break
        for r in range(len(rv)):
            new=NW[r]&~W[r]
            while new:
                bit=new&-new;c=bit.bit_length()-1
                ranks[r][c]=step
                moves[r][c]=next(z for z in rout[r] if safe[z]>>c&1)
                new-=bit
        W=NW
    else:raise RuntimeError('attractor failed to stabilize')
    return dict(goal=sorted(goal),safe_transfer=safe_transfer,ranks=ranks,moves=moves)


def verify(a,cert,source_column,excluded_sources=()):
    """Check every supplied rank directly, without rerunning the attractor."""
    rv,cv=a['messenger_vertices'],a['pursuer_vertices']
    rank,move=cert['ranks'],cert['moves'];goal=set(cert['goal']);safe=cert['safe_transfer']
    for r,v in enumerate(rv):
        for c,w in enumerate(cv):
            k=rank[r][c]
            if k<0:continue
            if k==0:
                assert r in goal and (not safe or v!=w)
                continue
            assert v!=w and r not in goal
            z=move[r][c]
            assert z in a['messenger_moves'][r]
            if not safe and z in goal:continue # terminal receipt precedes capture
            assert rv[z]!=w # immediate nonterminal collision
            for cp in a['pursuer_moves'][c]:
                assert rv[z]!=cv[cp]
                assert 0<=rank[z][cp]<k,(r,c,z,cp,k,rank[z][cp])
    bounds=[]
    for r,v in enumerate(rv):
        if v[0]!=source_column or v in excluded_sources:continue
        vals=[rank[r][c] for c,w in enumerate(cv) if w!=v]
        assert min(vals)>=0,('unproved source',v)
        bounds.append(max(vals))
    return bounds


def suite(extra=0,centers=(0,),cuts=None,M=3,R=4,retain=True):
    strip=Strip(extra,cuts)
    records=[]
    for center in centers:
        a=arena(strip,center,M,R)
        goals=[(center,j) for j in strip.types(center)]
        cert=solve(a,goals,True)
        try:bounds=verify(a,cert,center+1)
        except AssertionError as e:return dict(passed=False,extra=extra,center=center,kind='transfer',detail=str(e))
        records.append(dict(arena=a,kind='transfer',bounds=bounds,certificate=cert if retain else None))
        for t in strip.types(center):
            cert=solve(a,{(center,t)},False)
            try:bounds=verify(a,cert,center+2)
            except AssertionError as e:return dict(passed=False,extra=extra,center=center,kind='delivery',target=t,detail=str(e))
            records.append(dict(arena=a,kind='delivery',target=t,bounds=bounds,certificate=cert if retain else None))
    return dict(passed=True,extra=extra,cuts=strip.cuts,centers=list(centers),M=M,R=R,records=records)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--extra',type=int,default=0)
    p.add_argument('--check',type=Path,help='independently check all ranks in a saved certificate file')
    p.add_argument('--defect',action='store_true',help='test every local center affected by a defect')
    p.add_argument('--out',type=Path,default=ROOT/'research/five-type-certificates.json')
    args=p.parse_args()
    if args.check:
        stored=json.loads(args.check.read_text())
        for record in stored['records']:
            start=record['arena']['center']+(1 if record['kind']=='transfer' else 2)
            bounds=verify(record['arena'],record['certificate'],start)
            assert bounds==record['bounds']
        print('Every saved rank obligation and required initial state passed.')
        raise SystemExit(0)
    result=suite(args.extra,range(-4,5) if args.defect else (0,))
    args.out.write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
    if result['passed']:
        print('Records',len(result['records']),'largest certified local bound',max(max(r['bounds']) for r in result['records']))
    else:raise SystemExit(1)

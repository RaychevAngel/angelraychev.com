#!/usr/bin/env python3
"""Bounded exact arithmetic: code composition meets translated-run envelopes.

No game search. The ordinary protected-envelope and core-code proofs are
prerequisites; saved rows check the finite numerical overlap, not those proofs.
"""
from math import comb,gcd,log
from pathlib import Path
import hashlib,json


def code_parameters(n):
    dense=n*((n+11)//13)  # n ceil((n-1)/13)
    best=None
    for k in range(7,n//2+1,2):
        q=n-2*k
        if q<0:continue
        for r in range(3,k//2+1):
            cap=2*k*comb(k-r,r)//(k-r)
            if cap<q:continue
            terminal_missing=4*k+r*q
            if terminal_missing>dense:continue
            base=2*k*(2*k-3)+(4*k-r)*q
            row={'k':k,'r':r,'outside':q,'code_capacity':cap,
                 'base':base,'terminal_missing':terminal_missing,
                 'dense_missing_capacity':dense}
            if best is None or base<best['base']:best=row
    return best


def run_parameters(n):
    mask=(1<<n)-1
    best=None
    for h in range(7,(n-1)//2+1,2):
        if gcd(h,n)!=1:continue
        a=(h-1)//2
        seed={0,1,a,h}
        ds={(u-v)%n for u in (1,a,h)for v in (1,a,h)if u!=v}
        forbidden=seed|{(s+d)%n for s in seed for d in ds}
        F=sum(1<<s for s in forbidden)
        I=sum(1<<(j*(3*a-1)+t) for j in range(n//(3*a-1)) for t in range(a-1))
        original=I
        assert all((I&((I<<d)|(I>>(n-d)))&mask)==0 for d in ds)
        for shift in range(n):
            kept=(I&~F).bit_count()
            capacity=n*(3+kept)
            if best is None or capacity>best['capacity']:
                retained=I&~F
                A=retained|sum(1<<s for s in seed)
                # All seed-protected ordered differences occur uniquely.
                aset=[s for s in range(n)if (A>>s)&1]
                for d in ds:
                    assert sum(((x+d)%n) in set(aset)for x in aset)==1
                best={'h':h,'a':a,'shift':shift,'independent_size':original.bit_count(),
                      'forbidden_size':len(forbidden),'retained':kept,
                      'envelope_size':4+kept,'capacity':capacity}
            I=((I<<1)|(I>>(n-1)))&mask
    return best


def main():
    rows=[]
    for n in range(100,392):
        c=code_parameters(n);r=run_parameters(n)
        rows.append({'n':n,'code':c,'run':r,'passes':bool(c and r and c['base']<=r['capacity'])})
    failures=[x['n']for x in rows if not x['passes']]
    result={'verified':True,'range':[100,391],
            'last_failed_order':max(failures),'all_pass_from':max(failures)+1,
            'scope':'Finite exact arithmetic, code-capacity counts, translated-run difference checks; no pursuit-game search and no Lean claim.',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'asymptotic_constant_base2':26*log(2)/log(3125/108),'rows':rows}
    out=Path(__file__).resolve().parents[1]/'research/routing-defect-phase2-code-overlap-checks.json'
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='rows'}))
    for n in (100,110,114,115,116,120,130,140,150,160,175,200,250,300,391):
        print(json.dumps(rows[n-100]))

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Certify explicit six-exception safe-navigation interfaces.
The direct layer checker verifies individual legal actions and all responses;
it does not trust a synthesis fixed point or infer a point-delivery theorem.
"""
from pathlib import Path
import gzip,json,hashlib,time
from composition_interface_free_group import arena
from composition_interface_invariant import attract,mul,inv
ROOT=Path(__file__).resolve().parents[1]
FORBIDDEN={(3,(),9),(3,(2,),7),(4,(),0),(8,(),4),(8,(1,),2),(9,(),5)}
def good(i,w,j):return not(w==() and i==j) and (i,w,j) not in FORBIDDEN

def main():
 ar=arena((0,1,3));M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1
 records=[];start=time.monotonic();verified_new_states=0
 for g in (-1,-2):
  seeds=[]
  for r,(w,i) in enumerate(M):
   mask=0
   if w==(g,):
    for c,(cw,j) in enumerate(C):
     rel=None if cw is None else mul(inv(w),cw)
     if good(i,rel,j):mask|=1<<c
   seeds.append(mask)
  W,rounds,layers=attract(ar,seeds,retain=True)
  assert rounds<=32
  required=[(mi[((),i)],c) for i in range(10) for c,(cw,j) in enumerate(C) if good(i,cw,j)]
  assert all(W[r]>>c&1 for r,c in required)
  # Check the claimed proof one newly entering state at a time.
  assert layers[0]==seeds
  for depth in range(1,len(layers)):
   prev,nxt=layers[depth-1],layers[depth]
   assert all(a&~b==0 for a,b in zip(prev,nxt))
   for r in range(len(M)):
    new=nxt[r]&~prev[r]
    while new:
     bit=new&-new;c=bit.bit_length()-1;new-=bit
     assert M[r]!=C[c]
     witnessed=False
     for v in mo[r]:
      if C[c]==M[v]:continue
      response=co[c]
      okay=True
      while response:
       bb=response&-response;cc=bb.bit_length()-1;response-=bb
       if not(prev[v]>>cc&1):okay=False;break
      if okay:witnessed=True;break
     assert witnessed,(g,depth,M[r],C[c])
     verified_new_states+=1
  records.append({'generator':g,'moves':rounds,'required_starts':len(required),'layers':[[hex(x) for x in layer] for layer in layers]})
 # Independent literal six-case normalization: use the second original arc.
 norm=[]
 for i,cw,j in sorted(FORBIDDEN):
  r=mi[((),i)];c=ci[(cw,j)];v=mo[r][2]
  assert M[v]!=C[c]
  w,typ=M[v];response=co[c];checks=[]
  while response:
   bb=response&-response;cc=bb.bit_length()-1;response-=bb
   ccw,jj=C[cc];assert ccw is not None
   rel=mul(inv(w),ccw);assert good(typ,rel,jj)
   checks.append({'cop_absolute':C[cc],'cop_relative_word':rel})
  norm.append({'initial_messenger_type':i,'initial_cop':[cw,j],'messenger_destination':M[v],'responses':checks})
 artifact={'scope':'six-exception interface, safe transfer only; point delivery not claimed','messenger_positions':M,'pursuer_positions':C,'messenger_successors':mo,'pursuer_successor_masks':[hex(x) for x in co],'forbidden_states':sorted(FORBIDDEN),'normalization_cases':norm,'records':records}
 path=ROOT/'research/composition-interface-navigation-certificates.json.gz'
 with gzip.open(path,'wt') as f:json.dump(artifact,f,separators=(',',':'))
 receipt={'scope':artifact['scope'],'seconds':time.monotonic()-start,'finite_arena_messenger_positions':len(M),'finite_arena_pursuer_positions':len(C),'new_winning_states_directly_checked':verified_new_states,'transfer_records':[{k:v for k,v in d.items() if k!='layers'} for d in records],'normalization_cases':6,'normalization_moves':1,'artifact_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),ROOT/'src/composition_interface_free_group.py',ROOT/'src/composition_interface_invariant.py')}}
 (ROOT/'research/composition-interface-navigation-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
if __name__=='__main__':main()

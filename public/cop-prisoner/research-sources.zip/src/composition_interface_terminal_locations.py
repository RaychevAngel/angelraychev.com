#!/usr/bin/env python3
"""Bounded target-placement diagnostic for the explicit navigation interface.
Positive results are local sufficient games, pending geometry/certificate audit.
"""
import json,time,hashlib
from pathlib import Path
from composition_interface_free_group import arena,ball
from composition_interface_invariant import attract
from composition_interface_certify import good
ROOT=Path(__file__).resolve().parents[1]

def run(mrad=2,crad=3,targets=(1,2,4),limit=35,ports=False):
 ar=arena((0,1,3),mrad,crad);M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1
 if ports:
  required=[(mi[((),i)],c) for i in (4,9) for c,(cw,j) in enumerate(C) if cw!=() or j not in (i,0 if i==4 else 5)]
 else:
  required=[(mi[((),i)],c) for i in range(10) for c,(cw,j) in enumerate(C) if good(i,cw,j)]
 words=sorted(ball(mrad),key=lambda w:(len(w),sum(x>0 for x in w),w))
 records=[];start=time.monotonic()
 for w in words:
  for target in targets:
   tr=mi[(w,target)]
   W,rounds=attract(ar,[allc if r==tr else 0 for r in range(len(M))],{tr})
   bad=[(M[r][1],C[c]) for r,c in required if not(W[r]>>c&1)]
   d={'word':w,'target':target,'failed':len(bad),'rounds':rounds,'first_failure':bad[0] if bad else None}
   records.append(d);print(d,flush=True)
  if time.monotonic()-start>limit:break
 return {'scope':'bounded local terminal location checks, sufficient but not necessary for arbitrary finite quotients','ports_only':ports,'mrad':mrad,'crad':crad,'seconds':time.monotonic()-start,'records':records}

if __name__=='__main__':
 out=run();out['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 (ROOT/'research/composition-interface-terminal-locations.json').write_text(json.dumps(out,indent=2)+'\n')

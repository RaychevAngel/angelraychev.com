"""Cross-language comparison of all web-game states with the Python solver."""
from pathlib import Path
import json,subprocess,random,hashlib
from game_solver import neighborhoods,recipient_fast,bits
root=Path(__file__).resolve().parents[1];site=root/'.site-worktree';tmp=root/'tmp'
tmp.mkdir(exist_ok=True)
graphs=json.loads((site/'public/cop-prisoner/explorer-graphs.json').read_text())
rng=random.Random(12092026)
for n in range(1,5):
    pairs=[(u,v)for u in range(n)for v in range(n)if u!=v]
    for mask in range(1<<len(pairs)):
        graphs.append({'n':n,'arcs':[p for i,p in enumerate(pairs)if mask>>i&1]})
for _ in range(50):
    n=rng.randrange(5,13)
    graphs.append({'n':n,'arcs':[(u,v)for u in range(n)for v in range(n)if u!=v and rng.random()<.35]})
expected=[]
for g in graphs:
    n=g['n'];out,arcs=neighborhoods(n,g['arcs']);rows=[];indirect=0
    for t in range(n):
        wins,layers=recipient_fast(n,out,t,True)
        ranks=[[None]*n for _ in range(n)]
        for k,layer in enumerate(layers):
            for r in range(n):
                for c in bits(layer[r]):
                    if ranks[r][c]is None:ranks[r][c]=k
        for r in range(n):
            if r!=t and (r,t)not in arcs and all(ranks[r][c]is not None for c in range(n)if c!=r):indirect+=1
        rows.append(ranks)
    if'I'in g:assert g['I']==indirect
    expected.append(rows)
(tmp/'web-test-input.json').write_text(json.dumps(graphs))
entry=tmp/'web-test-entry.ts'
entry.write_text('''import{solveDelivery}from"../.site-worktree/src/lib/delivery-game.ts";
import fs from'node:fs';
const graphs=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const result=graphs.map(g=>Array.from({length:g.n},(_,t)=>{
const game=solveDelivery(g.n,g.arcs,t);
for(let r=0;r<g.n;r++)for(let c=0;c<g.n;c++){
 const d=game.rank[r][c];if(!Number.isFinite(d)||d===0)continue;
 const v=game.messenger(r,c);
 if(!game.moves[r].includes(v))throw Error('Illegal messenger move');
 if(v!==t&&(v===c||game.moves[c].some(x=>game.rank[v][x]>=d)))throw Error('Unsafe or nondecreasing policy');
 const p=game.pursuer(v,c);
 if(!game.moves[c].includes(p)||game.rank[v][p]!==Math.max(...game.moves[c].map(x=>game.rank[v][x])))throw Error('Incorrect worst response');
}return game.rank;}));
fs.writeFileSync(process.argv[3],JSON.stringify(result));''')
subprocess.run([str(site/'node_modules/.bin/esbuild'),str(entry),'--bundle','--platform=node',f'--outfile={tmp}/web-test.cjs'],check=True)
subprocess.run(['node',str(tmp/'web-test.cjs'),str(tmp/'web-test-input.json'),str(tmp/'web-test-output.json')],check=True)
actual=json.loads((tmp/'web-test-output.json').read_text());assert actual==expected
receipt={'graphs':len(graphs),'includes':'all loopless digraphs through n=4, 50 seeded random graphs, all explorer examples','all_recipient_states_and_exact_messenger_ranks':True,'selected_moves_safe_and_decreasing':True,'passed':True,'source_sha256':hashlib.sha256((site/'src/lib/delivery-game.ts').read_bytes()).hexdigest()}
(root/'research/web-solver-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

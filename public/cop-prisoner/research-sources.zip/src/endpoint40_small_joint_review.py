#!/usr/bin/env python3
"""Independent joint-pattern generation, literal replay, and lower rank review."""
import argparse,hashlib,itertools,json,subprocess
from pathlib import Path
from game_solver import solve_graph
from small_case_certificate_review import review
ROOT=Path(__file__).resolve().parents[1]

def independent_patterns(n,m):
    result=set()
    # Assign incoming degrees directly, descending within equal-outdegree blocks.
    # This uses neither the producer generator's incoming partitions nor permutations.
    for ascending in itertools.combinations_with_replacement(range(2,n-1),n):
        if sum(ascending)!=m:continue
        outgoing=ascending[::-1]
        def visit(i,remaining,prefix):
            if i==n:
                if remaining==0:result.add(tuple(zip(outgoing,prefix)))
                return
            cap=prefix[-1] if i and outgoing[i]==outgoing[i-1] else n-1
            for value in range(2,cap+1):
                left=remaining-value
                if 2*(n-i-1)<=left<=(n-1)*(n-i-1):visit(i+1,left,prefix+(value,))
        visit(0,m,())
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('n',type=int);p.add_argument('m',type=int);p.add_argument('value',type=int)
    p.add_argument('--witness-run');args=p.parse_args();n,m,value=args.n,args.m,args.value;target=value+1
    assert target>0 and n*(n-1)-m-target<n-2
    stem=f'endpoint40_joint_n{n}_m{m}_t{target}'
    inputs=json.loads((ROOT/'research'/f'{stem}.json').read_text())
    expected=independent_patterns(n,m)
    given=[tuple(tuple(pair) for pair in pat) for pat in inputs['joint_patterns']]
    assert len(set(given))==len(given)==len(expected) and set(given)==expected
    words=list(map(int,(ROOT/'research'/f'{stem}.txt').read_text().split()))
    assert words==[len(given)]+[v for pat in given for pair in pat for v in pair]
    log=f'research/{stem}_run.jsonl'
    rows=[json.loads(line) for line in (ROOT/log).read_text().splitlines()]
    end=rows[-1]
    assert (end['n'],end['m'],end['threshold'],end['mode'])==(n,m,value,0)
    assert end['complete'] and not end['counterexample_found']
    assert end['degree_patterns']==end['total_degree_patterns']==len(expected)
    assert len(rows)-1==end['game_decisions']
    assert all(r['kind']=='leaf' and (r['n'],r['m'])==(n,m) for r in rows[:-1])
    # Source lineage: no change to graph coverage or pruning in the copied engine.
    original=(ROOT/'src/finish_budget_positive.cpp').read_text()
    frozen=(ROOT/'src/endpoint40_small_joint.cpp').read_text()
    frozen=frozen.replace('// Small-main coupled in/out-degree completion with literal leaves.',
                          '// Positive-degree budget completion.')
    frozen=frozen.replace('remaining-=potential; // Keep exact leaf scores for independent literal replay.',
                          'remaining-=potential;if(I+remaining<=threshold){++early_game_rejects;return -1;}')
    first=frozen.index('if(row==n){++leaves;int value=game();')+len('if(row==n){++leaves;int value=game();')
    last=frozen.index('if(value>best)',first)
    frozen=frozen[:first]+frozen[last:]
    assert frozen==original
    replay_binary=ROOT/'src/endpoint40_small_leaf_replay.bin'
    subprocess.run(['c++','-O3','-std=c++17',str(ROOT/'src/endpoint40_small_leaf_replay.cpp'),'-o',str(replay_binary)],check=True)
    replay=subprocess.run([str(replay_binary),log],cwd=ROOT,text=True,capture_output=True,check=True)
    replay_path=f'research/{stem}_leaf_replay.jsonl';(ROOT/replay_path).write_text(replay.stdout)
    replay_record=json.loads(replay.stdout)
    assert replay_record['status']=='passed' and replay_record['all_literal_leaves_replayed']==end['game_decisions']
    if args.witness_run:
        witness=json.loads((ROOT/args.witness_run).read_text().splitlines()[-1])
        lower=solve_graph(n,witness['arcs'],certificates=True,crosscheck=True)
    else:
        lower=next(g for g in json.loads((ROOT/'research/finish_constructions_certificates.json').read_text())
                   if (g['n'],g['m'],g['I'])==(n,m,value))
    assert (lower['n'],lower['m'],lower['I'])==(n,m,value)
    lower_check=review(lower)
    lower_path=f'research/{stem}_lower_certificate.json'
    (ROOT/lower_path).write_text(json.dumps(lower,separators=(',',':'))+'\n')
    tests=json.loads((ROOT/'research/endpoint40_small_joint_prune_review_tests.json').read_text())
    assert tests['status']=='passed'
    files=[log,f'research/{stem}.json',f'research/{stem}.txt',replay_path,lower_path,
           'src/endpoint40_small_joint.cpp','src/endpoint40_small_joint_inputs.py','src/endpoint40_small_joint_review.py',
           'src/endpoint40_small_leaf_replay.cpp','src/endpoint40_small_joint_prune_review.cpp',
           'research/endpoint40_small_joint_prune_review_tests.json','research/endpoint40_small_joint_proof.md',
           'src/finish_budget_positive.cpp','src/game_solver.py','src/small_case_certificate_review.py']
    if args.witness_run:files.append(args.witness_run)
    record={'verified':True,'n':n,'m':m,'M':value,'target_excluded':target,
            'independent_joint_patterns':len(expected),'primary':end,'every_leaf_replay':replay_record,
            'lower':lower_check,'actual_source_prune_tests':tests,
            'boundary':'Reviewed ordinary finite enumeration with independent degree-input coverage, actual-source prune tests, independent replay of every literal leaf, and full lower ranks. No second complete traversal or Lean proof claimed.',
            'sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files}}
    (ROOT/'research'/f'{stem}_receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ('verified','n','m','M','target_excluded','independent_joint_patterns','every_leaf_replay','lower')},indent=2))
if __name__=='__main__':main()

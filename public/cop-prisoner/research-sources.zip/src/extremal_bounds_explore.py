"""Independent small solver for extremal probes; not final verifier."""
from itertools import combinations

def winning(adj):
    n=len(adj); out=[set(a)|{r} for r,a in enumerate(adj)]; winners=[]
    for t in range(n):
        # M messenger to move; P pursuer to move; diagonal capture except t.
        M={(t,c) for c in range(n)}; P=set(M)
        change=True
        while change:
            old=len(M)+len(P)
            for r in range(n):
                for c in range(n):
                    if r==t or r==c:continue
                    if any(v==t or (v!=c and (v,c) in P) for v in out[r]):M.add((r,c))
                    if all(v!=r and (r,v) in M for v in out[c]):P.add((r,c))
            change=old<len(M)+len(P)
        winners.extend((s,t) for s in range(n) if s!=t and t not in adj[s] and all((s,c) in M for c in range(n) if c!=s))
    return winners

def circulant(n,steps):return [{(i+s)%n for s in steps} for i in range(n)]
if __name__=='__main__':
    for n in range(4,17):
        best=[];score=-1
        for steps in combinations(range(1,n),2):
            a=circulant(n,steps);v=len(winning(a))
            if v>score:score=v;best=[steps]
            elif v==score:best.append(steps)
        print(n,score,best,flush=True)

def target_winners(adj,t):
    n=len(adj); out=[set(a)|{r} for r,a in enumerate(adj)]
    M={(t,c) for c in range(n)}; P=set(M)
    while True:
        old=len(M)+len(P)
        for r in range(n):
            for c in range(n):
                if r==t or r==c:continue
                if any(v==t or (v!=c and (v,c) in P) for v in out[r]):M.add((r,c))
                if all(v!=r and (r,v) in M for v in out[c]):P.add((r,c))
        if old==len(M)+len(P):break
    return [s for s in range(n) if s!=t and t not in adj[s] and all((s,c) in M for c in range(n) if c!=s)]

"""Source-pinned gap-closing domains from the September 13 research pass.

Only proof predicates, fixed recipe inputs and receipt identities are read.
No graph search, game solve or certificate regeneration occurs here.
"""
import hashlib
from pathlib import Path
import classification_small_cases as small

ROOT = Path(__file__).resolve().parents[1]


def register(c):
    small.register(c)
    c.READS.add('src/classification_extensions.py')
    c.rule('six_circle', 'Six-offset escape triples and fixed promoted source ranks supply every stated circle interval; all optional subsets.',
           ['paper/main-interval-six-circle.md','src/main_interval_six_circle.py','research/six-circle-recipes.json','research/six-circle-checks.json'])
    c.rule('reduced_hubs', 'A fixed twelve-hub rank interface gives the stated arbitrary-antichain intervals within five moves, for every optional subset.',
           ['paper/main-interval-reduced-hubs.md','src/main_interval_reduced_hubs.py','research/reduced-hubs-checks.json'])
    c.rule('staged_finite', 'Literal finite arrow orderings and asymmetric full-state rank certificates give every stated stage interval; all optional subsets within each stage.',
           ['paper/main-interval-complete.md','src/sparse_staged.py','src/sparse_staged_engine.cpp','src/sparse_staged_replay.cpp','research/sparse-staged-records.json','research/sparse-staged-certificates.zip'],
           'specified finite constructions with independent actual-game rank replay')
    c.rule('circle_half_density',
           'Five compulsory circle moves and protected safe triples give every listed half-density or guarded-circle interval, with all optional subsets permitted.',
           ['paper/main-interval-half-density.md','src/main_interval_half_density.py',
            'research/main-interval-half-density-checks.json'])
    c.rule('layered_guides',
           'A small hub core routes through guides with distinct equal-weight bulk codes; every listed interval attains all missing pairs in at most three moves, for arbitrary optional subsets.',
           ['paper/main-interval-layered.md','src/main_interval_layered.py',
            'research/main-interval-layered-checks.json'])
    c.rule('antichain_all_parities',
           'Theorem59 with Q=C(k,r)+C(k,r) for oddk or C(k,r)+sum C(k/2,i)C(k/2,r-i) for evenk supplies every stated code interval.',
           ['paper/core-code-composition.md','src/core_code_all_parities.py',
            'src/core_code_all_parities_check.py','research/core-code-all-parities-checks.json'])
    c.rule('circle_third', 'The listed protected-difference residue sets give every budget3n..n(|A|-1).',
           ['paper/core-code-composition.md','src/core_code_third_circles.py',
            'research/core-code-third-circle-envelopes.json'])
    c.rule('mixed105', 'At n105 the listed85 incomparable codes have weight268 and give every3472..10612.',
           ['paper/core-code-composition.md','src/core_code_all_parities.py','research/core-code-third-mixed-105.json'])
    c.rule('sparse_cyclic_finite', 'Forty-seven canonical cyclic envelopes and one109repair have complete asymmetric actual-game rank certificates; all prescribed optional subsets.',
           ['paper/sparse-packed-holes.md','research/sparse-interface-third-proof-registry.json',
            'research/sparse-interface-third-independent.json','research/sparse-interface-third-replay.json',
            'research/sparse-interface-third-certificates.zip',
            'src/sparse-interface-third.py','src/sparse-interface-third-independent.py'],
           'explicit finite adjacency recipe and two independent full-rank replays')
    c.rule('dense_root_cycles', 'For r>=5,k=n-r>=0, colored cycles and singleton supply the exact staircase; retain stated two/three-move distinctions.',
           ['paper/dense-third.md','src/dense_third_root_cycles.py','research/dense-third-root-cycle-checks.json'])
    c.rule('dense_nine_core', 'Literal9core has I18 at(9,54); disjoint missing-block addition supplies r>=2,k9.',
           ['paper/dense-third.md','src/dense_third_core_compose.py','research/dense-third-core-compose-checks.json',
            'research/dense-third-core-compose-certificates.json'],
           'ordinary block theorem with finite actual-game core certificate')
    c.rule('dense_first_small', 'The three literal first-step attachments at n13,14,15 attain2n-3.',
           ['paper/dense-third.md','src/dense_third_first_step.py','research/dense-third-first-step-checks.json',
            'research/dense-third-first-step-certificates.json'], 'two independent actual-game solvers and complete finite rank replay')
    c.rule('dense_second_loss', 'The r2 equality reduces to the(n-2)-core dense endpoint; existing exact tables imply M(7,30)<=9 and M(8,42)<=11.',
           ['paper/dense-third.md','src/dense_third_r2_reduction.py','research/dense-third-r2-reduction-checks.json'])
    c.rule('sparse_stronger_upper', 'Reviewed original-graph support and finite core arguments give ME14<=22,ME16<=32,ME18<=44,ME20<=58,ME22<=79.',
           ['paper/sparse-third.md','research/sparse-third-source-audit.json','research/sparse-third-audit.md'],
           'ordinary support reduction plus the individually stated finite exclusion premises')
    c.rule('exact22', 'ME22=M(n,22)=79 for every n>=11; literal11vertex graph and separate global upper79.',
           ['paper/sparse-third.md','research/sparse-third-one-transfer-in-certificate.json'],
           'ordinary support bound with finite regular-core exclusion and fixed attaining rank certificate')
    c.rule('sparse_third_lower', 'Literal graphs give I30 at(9,18), I50 at(10,20), and I79 at(11,22); isolates and separate zero-I components preserve these lower bounds.',
           ['research/sparse-third-fixed-lower-certificates.json','paper/sparse-third.md'],
           'two independent actual-game solvers and complete fixed-graph rank replay')


def bounds(n, m):
    out = small.bounds(n,m)
    if m in {14,16,18,20,22}:
        out.append(({14:22,16:32,18:44,20:58,22:79}[m], 'sparse_stronger_upper'))
    if (n,m) in {(7,30),(8,42)}:
        out.append((9 if n == 7 else 11, 'dense_second_loss'))
    return out


def inputs(c):
    small.inputs(c)
    staged=c.read('research/sparse-staged-records.json')
    bundle=ROOT/'research/sparse-staged-certificates.zip'
    assert bundle.stat().st_size==staged['bundle_bytes']
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()==staged['bundle_sha256']
    for name,expected in staged['source_sha256'].items():
        c.READS.add(name)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,(name,'staged source changed')
    from core_code_third_circles import verify
    circles = c.read('research/core-code-third-circle-envelopes.json')['rows']
    for row in circles:
        verify(row)
    mixed = c.read('research/core-code-third-mixed-105.json')
    from core_code_all_parities import from_codes
    g = from_codes(mixed['k'], mixed['codes'])
    assert g['n'] == 105 and len(g['base']) == 3472 and len(g['optional']) == 7140
    registry = c.read('research/sparse-interface-third-proof-registry.json')
    path = ROOT/registry['bundle']
    assert path.stat().st_size == registry['bundle_bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == registry['bundle_sha256']
    for name, expected in registry['source_sha256'].items():
        c.READS.add(name)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == expected
    expected = {60}|set(range(64,67))|set(range(68,73))|set(range(75,79))|set(range(80,91))|set(range(92,115))
    assert {r['n'] for r in registry['records'] if r['variant'] is None} == expected
    assert len(registry['records']) == 48
    return circles, registry['records']


def points(c):
    x = c.read('research/sparse-third-one-transfer-in-certificate.json')
    assert (x['n'],x['m'],x['I']) == (11,22,79)
    assert x['verification']['both_independent_solvers_agree']
    assert x['verification']['all_winning_and_losing_rank_conditions_checked']
    witnesses = c.read('research/sparse-third-fixed-lower-certificates.json')
    assert {(w['n'],w['m'],w['I']) for w in witnesses} == {(9,18,30),(10,20,50),(11,22,79)}
    return [(w['n'],w['m'],w['I'],'sparse_third_lower',False) for w in witnesses]+[(11,22,79,'exact22',True),(9,54,18,'dense_nine_core',True)]+small.points(c)


def domains(c, row, n, data):
    small.domains(c,row,n)
    from main_interval_six_circle import intervals as six_intervals
    from main_interval_reduced_hubs import intervals as reduced_intervals
    from sparse_staged import intervals as staged_intervals
    for name, intervals in [('six_circle',six_intervals),('reduced_hubs',reduced_intervals),('staged_finite',staged_intervals)]:
        for x in intervals(n):
            c.known_exact(row,n,x['m_min'],x['m_max'],name)
    from main_interval_half_density import intervals as circle_intervals
    from main_interval_layered import intervals as layered_intervals
    for x in circle_intervals(n):
        c.known_exact(row,n,x['m_min'],x['m_max'],'circle_half_density')
    for x in layered_intervals(n):
        c.known_exact(row,n,x['m_min'],x['m_max'],'layered_guides')
    from core_code_all_parities import interval
    for k in range(6,n//2+1,2):
        for r in range(3,k//2+1):
            z = interval(k,r,n)
            if z is not None:
                c.known_exact(row,n,*z,'antichain_all_parities')
    for x in data[0]:
        if x['n'] == n:
            c.known_exact(row,n,x['minimum_m'],x['maximum_m'],'circle_third')
    if n == 105:
        c.known_exact(row,n,3472,10612,'mixed105')
    for x in data[1]:
        if x['n'] == n:
            c.known_exact(row,n,x['m_min'],x['m_max'],'sparse_cyclic_finite')
    for r in range(2,n+1):
        m = n*(n-3)+r
        if r >= 5:
            c.known_exact(row,n,m,m,'dense_root_cycles',c.staircase(n,m))
        elif n-r == 9:
            c.known_exact(row,n,m,m,'dense_nine_core',c.staircase(n,m))
    if n in {13,14,15}:
        m = n*(n-3)+1
        c.known_exact(row,n,m,m,'dense_first_small',2*n-3)

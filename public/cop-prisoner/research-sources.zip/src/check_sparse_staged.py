#!/usr/bin/env python3
"""Read-only release verification of the frozen staged rank certificates.

WARNING: sparse_staged.py --certify is a historical discovery producer
requiring the frozen pre-fifth ledger. It must not be rerun against the
current classification ledger: it selects ledger gaps and replaces the
certificate outputs, which would erase the now-proved catalogue.

Release verification uses: python3 src/check_sparse_staged.py
This checker reads the frozen records/ZIP directly, never runs the discovery
engine, and never rewrites the frozen records or bundle.

By default the report is printed. --out writes only the named new receipt.
Compilation of the independent C++ replay library uses a temporary file.
"""
from __future__ import annotations

import argparse
import array
import ctypes
import hashlib
import json
import sys
import time
import zipfile
from pathlib import Path

from sparse_staged import BUNDLE, RECORD, ROOT, replay_function


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def verify_release():
    started = time.monotonic()
    record_bytes = RECORD.read_bytes()
    bundle_bytes = BUNDLE.read_bytes()
    records = json.loads(record_bytes)
    bundle_hash = sha256_bytes(bundle_bytes)
    assert bundle_hash == records['bundle_sha256'], 'bundle hash mismatch'
    assert len(bundle_bytes) == records['bundle_bytes'], 'bundle byte count mismatch'
    assert records['encoding'] == 'little-endian signedint16 ranks[t,s,c], then actions[t,s,c]'
    for relative, expected in records['source_sha256'].items():
        assert sha256_bytes((ROOT/relative).read_bytes()) == expected, (relative, 'source pin mismatch')

    replay = replay_function()  # Compiles the independent literal replay, not the producer.
    stages = 0
    counts = [0, 0, 0]
    uncompressed_bytes = 0
    checked_members = []
    with zipfile.ZipFile(BUNDLE) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)), 'duplicate archive member'
        manifest = json.loads(archive.read('manifest.json'))
        for key in ['records', 'encoding', 'counts']:
            assert manifest[key] == records[key], (key, 'internal manifest mismatch')

        for row in records['records']:
            n = row['n']
            assert isinstance(n, int) and 1 <= n <= 120
            base = [tuple(e) for e in row['base_arcs']]
            added = [tuple(e) for e in row['added']]
            assert len(set(base+added)) == len(base)+len(added), 'duplicate literal arrow'
            assert all(len(e) == 2 and all(isinstance(x, int) for x in e)
                       and 0 <= e[0] < n and 0 <= e[1] < n and e[0] != e[1]
                       for e in base+added), 'invalid literal arrow'
            base_count = len(base)

            for stage in row['stages']:
                lo, hi = stage['prefix_start'], stage['prefix_end']
                assert 0 <= lo < hi <= len(added)
                assert stage['m_min'] == base_count+lo and stage['m_max'] == base_count+hi
                member = stage['member']
                assert member not in checked_members, 'certificate member reused'
                assert archive.getinfo(member).file_size == 4*n**3, 'wrong certificate layout'
                raw = archive.read(member)
                assert len(raw) == 4*n**3 and sha256_bytes(raw) == stage['sha256']
                words = array.array('h')
                assert words.itemsize == 2
                words.frombytes(raw)
                if sys.byteorder != 'little':
                    words.byteswap()
                state_count = n**3
                storage = ctypes.c_int16*state_count
                ranks = storage.from_buffer_copy(words[:state_count])
                policies = storage.from_buffer_copy(words[state_count:])
                assert max(ranks) == stage['maximum_moves']
                actual = replay(n, base+added[:lo], added[lo:hi], ranks, policies)
                assert actual == stage['counts'], (member, 'replayed count mismatch')
                counts = [a+b for a, b in zip(counts, actual)]
                stages += 1
                uncompressed_bytes += len(raw)
                checked_members.append(member)

        assert set(names) == {'manifest.json'} | set(checked_members), 'unexpected archive member'

    assert counts == records['counts'], 'global replay count mismatch'
    # In addition to never writing these inputs, detect concurrent replacement.
    assert sha256_bytes(RECORD.read_bytes()) == sha256_bytes(record_bytes), 'records changed during replay'
    assert sha256_bytes(BUNDLE.read_bytes()) == bundle_hash, 'bundle changed during replay'
    checker = Path(__file__).resolve()
    return {
        'status': 'complete frozen-certificate replay passed without discovery or catalogue mutation',
        'bundle_sha256': bundle_hash,
        'records_sha256': sha256_bytes(record_bytes),
        'records': len(records['records']),
        'stages': stages,
        'uncompressed_certificate_bytes': uncompressed_bytes,
        'rank_states_checked': counts[0],
        'pursuer_replies_checked': counts[1],
        'direct_terminal_moves_checked': counts[2],
        'frozen_source_sha256': records['source_sha256'],
        'checker_sha256': sha256_bytes(checker.read_bytes()),
        'input_files_unchanged': True,
        'proof_boundary': 'Literal finite ranks are checked by the independent C++ replay. No attractor or discovery is run; no concrete Lean certificate instantiation is claimed.',
        'seconds': time.monotonic()-started,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, help='Write an additional verification receipt.')
    args = parser.parse_args()
    if args.out is not None:
        protected = {RECORD.resolve(), BUNDLE.resolve(), Path(__file__).resolve()}
        protected.update((ROOT/p).resolve() for p in json.loads(RECORD.read_text())['source_sha256'])
        if args.out.resolve() in protected:
            parser.error('--out must not overwrite a frozen input or verifier source')
    result = verify_release()
    text = json.dumps(result, indent=2)+'\n'
    if args.out is not None:
        args.out.write_text(text)
    print(text, end='')


if __name__ == '__main__':
    main()

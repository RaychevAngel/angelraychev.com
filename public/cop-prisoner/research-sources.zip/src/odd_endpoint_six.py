#!/usr/bin/env python3
"""Odd endpoint as one deleted arc in the composable six-type strip.

The local arena excludes the degree-one source from transfer goals/initial
requirements and excludes the degree-one recipient from delivery goals.
Successful rows are finite proof obligations, not circumference evidence.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from five_type_certificate import arena, solve, verify
from sparse_composition_smoothing import SmoothStrip
from sparse_composition_certificate import SIGMA, VOLTAGE


class DeletedStrip(SmoothStrip):
    def __init__(self, column, source_type, edge_type, sigma=SIGMA,voltage=VOLTAGE):
        super().__init__(sigma,voltage)
        self.low_source=(column,source_type)
        self.low_recipient=super().arcs(self.low_source)[edge_type]
    def arcs(self,v):
        return [w for w in super().arcs(v)
                if (v,w)!=(self.low_source,self.low_recipient)]


class PartialHoleStrip(SmoothStrip):
    def __init__(self,column,missing_shortcut,removed_type=4):
        super().__init__(SIGMA,VOLTAGE,removed_type,[column])
        if missing_shortcut==0:
            self.low_source=(column-1,5)if removed_type==0 else(column,removed_type-1)
            self.low_recipient=(column+1,0)if removed_type==5 else(column,removed_type+1)
        else:
            predtype=SIGMA.index(removed_type)
            self.low_source=(column-VOLTAGE[predtype],predtype)
            self.low_recipient=(column+VOLTAGE[removed_type],SIGMA[removed_type])
    def arcs(self,v):
        return [w for w in super().arcs(v)
                if(v,w)!=(self.low_source,self.low_recipient)]


class CombinedPatchStrip(SmoothStrip):
    def __init__(self,column,mask,source_column,source_type,edge_type,sigma,voltage):
        super().__init__(sigma,voltage)
        self.hole_column=column;self.mask=mask
        self.low_source=(column+source_column,source_type)
        self.low_recipient=super().arcs(self.low_source)[edge_type]
    def gone(self,v):return v[0]==self.hole_column and bool(self.mask>>v[1]&1)
    def types(self,i):return[j for j in range(6)if not self.gone((i,j))]
    def arcs(self,v):
        return[w for w in super().arcs(v)if(v,w)!=(self.low_source,self.low_recipient)]


class ExtendedPatchStrip(CombinedPatchStrip):
    def __init__(self,column,mask,extra_mask,source_column,source_type,edge_type,sigma,voltage):
        self.extra_mask=extra_mask
        super().__init__(column,mask,source_column,source_type,edge_type,sigma,voltage)
    def gone(self,v):
        if super().gone(v):return True
        if v[0]==self.hole_column-1:return bool(self.extra_mask>>v[1]&1)
        if v[0]==self.hole_column+1:return bool(self.extra_mask>>(6+v[1])&1)
        return False


def local_check(column,source_type,edge_type,M=4,R=6,retain=False):
    strip=DeletedStrip(column,source_type,edge_type)
    result=check_strip(strip,M,R,retain)
    result.update(column=column,source_type=source_type,edge_type=edge_type)
    return result


def check_strip(strip,M=4,R=6,retain=False,direction=1,max_jump=2,
                broad_transfer=False,delivery_distances=(2,)):
    a=arena(strip,messenger_radius=M,pursuer_radius=R)
    cv=a['pursuer_vertices']
    a['pursuer_moves'][-1]=[i for i,v in enumerate(cv)if v is None or abs(v[0])>=R-max_jump+1]
    rows=[]
    for target in [None]+[(0,j)for j in strip.types(0)if (0,j)!=strip.low_recipient]:
        goal=([(col,j)for col in([0,direction]if broad_transfer else[0])
               for j in strip.types(col)if(col,j)!=strip.low_source]
              if target is None else[target])
        cert=solve(a,goal,target is None)
        source_columns=[-direction]if target is None else[-d*direction for d in delivery_distances]
        failures=sum(rank<0 for r,v in enumerate(a['messenger_vertices'])
                     if v[0]in source_columns and v!=strip.low_source
                     for c,rank in enumerate(cert['ranks'][r])if cv[c]!=v)
        row={'target':target,'failures':failures,'source_columns':source_columns}
        if failures==0:row['bounds']=[b for col in source_columns for b in verify(a,cert,col,(strip.low_source,))]
        if retain:row['certificate']=cert
        rows.append(row)
    result={'low_source':strip.low_source,'low_recipient':strip.low_recipient,
            'failures':sum(r['failures']for r in rows),'records':rows}
    if retain:result['arena']=a
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--all-columns',action='store_true')
    parser.add_argument('--source-type',type=int)
    parser.add_argument('--edge-type',type=int)
    parser.add_argument('--retain',action='store_true')
    parser.add_argument('--out',type=Path,default=Path('research/odd-endpoint-six-local-screen.json'))
    args=parser.parse_args();rows=[]
    for typ in(range(6)if args.source_type is None else[args.source_type]):
        for edge in(range(2)if args.edge_type is None else[args.edge_type]):
            for col in(range(-6,7)if args.all_columns else[0]):
                result=local_check(col,typ,edge,retain=args.retain);rows.append(result)
                print(json.dumps({k:result[k]for k in['column','source_type','edge_type','low_recipient','failures']}),flush=True)
                args.out.write_text(json.dumps(rows,indent=None if args.retain else 2)+'\n')


if __name__=='__main__':main()

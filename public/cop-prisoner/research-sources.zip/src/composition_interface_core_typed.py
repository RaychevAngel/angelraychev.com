#!/usr/bin/env python3
"""Typed exterior tests for A4 cells, with switched or matching port arcs."""
from pathlib import Path
import json,hashlib
from composition_interface_core_ports import core
from composition_interface_invariant import attract
ROOT=Path(__file__).resolve().parents[1]

def arena(flip=True,goaltype=None):
 G,out=core();M=[(cell,i) for cell in (0,1) for i in range(12)];C=M+[(None,i) for i in range(12)];mi={v:i for i,v in enumerate(M)};ci={v:i for i,v in enumerate(C)}
 ports=(0,11);dest={i:11-i if flip else i for i in ports};mo=[];co=[]
 for cell,i in M:
  suc=[mi[cell,i]]+[mi[cell,j] for j in out[i]]
  if cell==0 and i in ports:suc.append(mi[1,dest[i]])
  mo.append(suc)
 for cell,i in C:
  suc={ci[cell,i]}|{ci[cell,j] for j in out[i]}
  if i in ports:
   # Deliberately allow any quotient neighbor, including the other represented
   # cell. The actual graph's possible moves form a subset.
   suc|={ci[c,dest[i]] for c in (0,1,None) if c!=cell}
  co.append(sum(1<<c for c in suc))
 return M,C,mi,ci,mo,co

def run(flip=True,target=None,retain=False):
 ar=arena(flip);M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1
 rec={mi[1,target]} if target is not None else set()
 seeds=[(allc if r in rec else allc^(1<<ci[M[r]])) if (r in rec if target is not None else M[r][0]==1) else 0 for r in range(len(M))]
 W,rounds,layers=attract(ar,seeds,rec,retain=True)
 bad=[(M[r],C[c]) for r in range(12) for c in range(len(C)) if c!=r and not(W[r]>>c&1)]
 d={'flip':flip,'target':target,'rounds':rounds,'failed':len(bad),'first_failure':bad[0] if bad else None}
 if retain:d.update(arena=ar,layers=layers)
 return d

if __name__=='__main__':
 rr=[]
 for flip in (False,True):
  for target in (None,0,1,2,11):
   d=run(flip,target);rr.append(d);print(d)
 out={'scope':'typed cop exterior, two-cell local diagnostic only','records':rr,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'research/composition-interface-core-typed.json').write_text(json.dumps(out,indent=2)+'\n')

#!/usr/bin/env python3
"""Independent checks of the September 13 layered and half-density recipes.

No project constructor, pursuit solver, or certificate checker is imported.
Adjacency is reconstructed from the mathematical descriptions. The checker
computes universally winning source ranks against the full optional cop
envelope, then independently replays every source/cop rank obligation.
These bounded checks supplement the ordinary symbolic proofs; they do not
establish an infinite theorem by finite extrapolation or claim Lean coverage.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
from itertools import combinations
import json
from math import comb, gcd
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[1]


def bits(values):
    out = 0
    for value in values:
        out |= 1 << value
    return out


def members(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def check_rows(base, envelope):
    n = len(base)
    assert len(envelope) == n
    for source in range(n):
        assert not base[source] >> source & 1
        assert not envelope[source] >> source & 1
        assert base[source] & ~envelope[source] == 0
        assert envelope[source] >> n == 0


def source_ranks(base, envelope, target):
    """Synchronous closure, using only base moves and all possible cop moves."""
    n = len(base)
    closed = [row | (1 << c) for c, row in enumerate(envelope)]
    ranks = [-1] * n
    ranks[target] = 0
    for source in range(n):
        if base[source] >> target & 1:
            ranks[source] = 1
    won = bits(v for v in range(n) if ranks[v] >= 0)
    level = 1
    layers = [won.bit_count()]
    while won.bit_count() < n:
        fresh = []
        for source in range(n):
            if ranks[source] >= 0:
                continue
            candidates = base[source] & won
            if candidates and all(c == source or candidates & ~closed[c]
                                  for c in range(n)):
                fresh.append(source)
        assert fresh, ("unproved source positions", n, target,
                       [s for s in range(n) if ranks[s] < 0])
        level += 1
        for source in fresh:
            ranks[source] = level
            won |= 1 << source
        layers.append(len(fresh))
    return ranks, layers


def replay_ranks(base, envelope, target, ranks):
    """Separate replay using explicit set/list witnesses, not closure masks."""
    n = len(base)
    closed_sets = [set(members(row)) | {c} for c, row in enumerate(envelope)]
    assert len(ranks) == n and ranks[target] == 0
    obligations = 0
    for source in range(n):
        assert ranks[source] >= 0
        if source == target:
            continue
        if base[source] >> target & 1:
            assert ranks[source] == 1
            continue  # Receipt is immediate, before any cop interception.
        successors = [v for v in members(base[source])
                      if 0 <= ranks[v] < ranks[source]]
        for cop in range(n):
            if cop == source:
                continue
            forbidden = closed_sets[cop]
            witness = next((v for v in successors if v not in forbidden), None)
            assert witness is not None, (target, source, cop, ranks[source])
            assert base[source] >> witness & 1
            assert witness != cop
            assert not envelope[cop] >> witness & 1
            assert ranks[witness] < ranks[source]
            obligations += 1
    return obligations


def audit_graph(base, envelope, targets, metadata):
    check_rows(base, envelope)
    records = []
    obligations = 0
    for target in targets:
        ranks, layers = source_ranks(base, envelope, target)
        obligations += replay_ranks(base, envelope, target, ranks)
        records.append({"target": target, "max_rank": max(ranks),
                        "layers": layers,
                        "ranks_sha256": sha256(bytes(ranks)).hexdigest()})
    return {**metadata, "n": len(base), "base_arcs": sum(r.bit_count() for r in base),
            "envelope_arcs": sum(r.bit_count() for r in envelope),
            "rank_obligations": obligations, "target_records": records,
            "adjacency_sha256": sha256(json.dumps([base, envelope]).encode()).hexdigest()}


def circle_parameter(n):
    assert n >= 16 and n % 4 == 0
    if n % 8 == 0:
        return n // 2 - 1
    k = n // 4
    return k + (2 if k % 4 == 1 else 4)


def circle_rows(n, h, windowed=False):
    assert h >= 11 and h % 4 == 3 and gcd(h, n) == 1 and n >= 2 * h + 2
    if not windowed:
        assert n % 4 == 0
    end = n - h if windowed else n - 1
    allowed = {x for x in range(end + 1) if x % 4 in (0, 1)}
    allowed.add(h)
    allowed.difference_update({2 * h - 5, 2 * h - 1})
    core = {1, 5, h - 7, h - 3, h - 2, h, h + 1, h + 2}
    assert len(core) == 8 and 0 in allowed and 0 not in core and core <= allowed
    if not windowed:
        assert len(allowed) == n // 2 - 1
    base = [bits((r + d) % n for d in core) for r in range(n)]
    envelope = [bits((r + d) % n for d in allowed if d) for r in range(n)]
    return base, envelope, core, allowed


def safe_sets(h):
    return ((h, 1), (h, 5), (h, h + 1, h + 2),
            (h, h - 2, h + 2), (h, h - 3, h - 2),
            (h, h - 7, h - 2))


def circle_safety(n, h, allowed):
    checked = 0
    for steps in safe_sets(h):
        assert len(set(steps)) == len(steps)
        assert max(steps) - min(steps) <= h - 1
        for cop in range(1, n):
            assert any((step - cop) % n not in allowed for step in steps)
            checked += 1
    return checked


def five_circle_rows(n, h, windowed=False):
    assert h >= 7 and h % 4 == 3 and gcd(h, n) == 1 and n >= 2 * h + 2
    if not windowed:
        assert n % 4 == 0
    end = n - h if windowed else n - 1
    allowed = {x for x in range(end + 1) if x % 4 in (0, 1)} | {h}
    allowed.discard(2 * h - 1)
    core = {1, h - 3, h - 2, h, h + 2}
    assert len(core) == 5 and 0 in allowed and 0 not in core and core <= allowed
    if not windowed:
        assert len(allowed) == n // 2
    base = [bits((r + d) % n for d in core) for r in range(n)]
    envelope = [bits((r + d) % n for d in allowed if d) for r in range(n)]
    safe = ((h, 1), (h, h - 3, h - 2), (h, h - 2, h + 2))
    for steps in safe:
        assert len(set(steps)) == len(steps)
        assert max(steps) - min(steps) <= h - 1
        for cop in range(1, n):
            assert any((step - cop) % n not in allowed for step in steps)
    return base, envelope, 3 * (n - 1)


def symbolic_five_circle():
    def add(u, v):
        return (u[0] + v[0], u[1] + v[1])
    known = {(0, i) for i in (-2, -1, 0, 2)}
    additions = [
        ((-1, 2), ((1, 0), (1, -3), (1, -2))),
        ((-1, 0), ((1, 0), (1, -2), (1, 2))),
        ((-1, -1), ((1, 0), (0, 1))),
        ((-1, -2), ((1, 0), (0, 1))),
    ]
    for source, moves in additions:
        assert all(add(source, move) in known for move in moves)
        known.add(source)
    assert {(-1, j) for j in (-2, -1, 0, 2)} <= known
    core = {(0, 1), (1, -3), (1, -2), (1, 0), (1, 2)}
    immediate = {(-x, -y) for x, y in core} | {(0, 0)}
    seed = {(-1, j) for j in (-2, -1, 0, 2)}
    assert seed - {(-1, -1)} <= immediate
    assert add((-1, -1), (1, 0)) in immediate
    assert add((-1, -1), (0, 1)) in immediate
    return {"affine_propagation_additions": len(additions), "seed_identity": True,
            "formal_scope": "integer affine identities; not a Lean proof"}


def symbolic_circle():
    """Exact affine expressions in h, with no sampled h substitution."""
    def add(u, v):
        return (u[0] + v[0], u[1] + v[1])
    known = {(0, i) for i in (0, 3, 4, 5, 7)}
    additions = [
        ((-1, 3), ((1, 0), (1, 1), (1, 2))),
        ((-1, 5), ((1, 0), (1, -2), (1, 2))),
        ((-1, 7), ((1, 0), (1, -3), (1, -2))),
        ((-2, 5), ((1, 0), (1, -2), (1, 2))),
        ((-1, 0), ((1, 0), (0, 5))),
        ((-1, 4), ((1, 0), (0, 1))),
        ((-2, 0), ((1, 0), (0, 5))),
        ((-2, 3), ((1, 0), (1, 1), (1, 2))),
        ((-2, 4), ((1, 0), (0, 1))),
        ((-2, 7), ((1, 0), (1, -7), (1, -2))),
    ]
    for source, moves in additions:
        assert all(add(source, move) in known for move in moves)
        known.add(source)
    assert {(-2, j) for j in (0, 3, 4, 5, 7)} <= known
    core = {(0, 1), (0, 5), (1, -7), (1, -3), (1, -2),
            (1, 0), (1, 1), (1, 2)}
    immediate = {(-x, -y) for x, y in core} | {(0, 0)}
    seed = {(-1, j - 5) for j in (0, 3, 4, 5, 7)}
    assert seed - {(-1, -5)} <= immediate
    assert add((-1, -5), (1, 0)) in immediate
    assert add((-1, -5), (0, 5)) in immediate
    return {"affine_propagation_additions": len(additions), "seed_identity": True,
            "formal_scope": "integer affine identities; not a Lean proof"}


def layer_rows(g, b, r=2, k=7):
    assert k in (6, 7)
    assert 2 <= r <= g <= (14 if k == 7 else 8) and 0 <= b <= comb(g, r)
    n = 2 * k + g + b
    guides = list(range(2 * k, 2 * k + g))
    bulk = list(range(2 * k + g, n))
    all_hubs = set(range(2 * k))
    if k == 7:
        omitted = [{7 + i, 7 + (i + 2) % 7, 7 + (i + 4) % 7} for i in range(7)]
        omitted += [{i, (i + 1) % 7, (i + 4) % 7} for i in range(7)]
        support = {0, 1, 4, 5, 7, 9, 11, 13}
    else:
        omitted = [{6, 8, 10}, {7, 9, 11}]
        omitted += [{i, i + 3} for i in range(3)]
        omitted += [{6 + i, 9 + i} for i in range(3)]
        support = all_hubs - {0, 3, 6, 8, 10}
    base_sets = [set() for _ in range(n)]
    for i in range(k):
        base_sets[i] = set(range(n)) - {i, k + i, k + (i - 1) % k}
        base_sets[k + i] = set(range(n)) - {k + i, (i + 4) % k, (i + 6) % k}
    for j, guide in enumerate(guides):
        base_sets[guide] = all_hubs - omitted[j]
    for vertex, code in zip(bulk, combinations(guides, r)):
        base_sets[vertex] = support | set(code)
    envelope_sets = [set(row) for row in base_sets]
    for guide in guides:
        envelope_sets[guide].update(bulk)
    for vertex in bulk:
        envelope_sets[vertex].update(set(bulk) - {vertex})
    base = [bits(row) for row in base_sets]
    envelope = [bits(row) for row in envelope_sets]
    if k == 7:
        low = 154 + 25 * g + (22 + r) * b
    else:
        low = 106 + 22 * g + (19 + r) * b
    assert sum(r.bit_count() for r in base) == low
    assert sum(r.bit_count() for r in envelope) == low + b * (g + b - 1)
    return base, envelope


def layer_local_obligations(k):
    """Finite local premises sufficient for arbitrary admissible bulk counts.

    Every bulk cop has the same access to hubs. Every hub reaches every bulk
    target. One representative bulk vertex therefore suffices when the
    intermediate witness is a hub. The finite guide catalogue is checked in
    full; reducing to a prefix only removes possible sources/cops/targets.
    """
    g = 14 if k == 7 else 8
    base, envelope = layer_rows(g, 1, 2, k)
    hubs = set(range(2 * k))
    bulk = 2 * k + g
    n = len(base)
    checked = 0
    for source in range(bulk):
        for target in range(n):
            if source == target or base[source] >> target & 1:
                continue
            candidates = [w for w in hubs
                          if base[source] >> w & 1 and base[w] >> target & 1]
            for cop in range(n):
                if cop == source:
                    continue
                assert any(w != cop and not envelope[cop] >> w & 1
                           for w in candidates), (k, source, target, cop)
                checked += 1
    support = set(members(base[bulk])) & hubs
    for cop in hubs:
        assert any(w != cop and not envelope[cop] >> w & 1 for w in support)
        checked += 1
    # Equal-size distinct subsets supply a guide in J_s minus J_c. This is
    # an elementary cardinality implication, checked exactly below for all
    # possible subset sizes, with no exponentially large vertex game.
    cardinality_identities = []
    for r in range(2, g + 1):
        assert comb(g, r) >= 1
        cardinality_identities.append({"g": g, "r": r, "capacity": comb(g, r)})
    return {"k": k, "local_hub_witness_obligations": checked,
            "bulk_source_rules": ["support meets each hub cop's missing row",
                                  "r >= 2 permits a guide different from a guide cop",
                                  "distinct equal-size guide sets have a nonempty difference"],
            "guide_code_capacities": cardinality_identities}


def audit_layers():
    records = []
    # All recipients: both hub parts, every guide code, every used bulk pair.
    cases = [(7, g, b, 2) for g, b in ((2, 0), (2, 1), (3, 3), (7, 21), (8, 28),
                                      (10, 36), (11, 55), (12, 66), (14, 91))]
    cases += [(7, 6, 20, 3), (7, 8, 70, 4), (7, 14, 25, 7), (7, 4, 1, 4)]
    cases += [(6, 2, 0, 2), (6, 2, 1, 2), (6, 3, 3, 2), (6, 6, 15, 2),
              (6, 7, 21, 2), (6, 8, 28, 2), (6, 8, 30, 3), (6, 8, 70, 4),
              (6, 8, 1, 8), (6, 8, 8, 7)]
    for k, g, b, r in cases:
        base, envelope = layer_rows(g, b, r, k)
        record = audit_graph(base, envelope, range(len(base)),
                             {"family": "layered-guides", "k": k, "g": g, "b": b, "r": r})
        assert all(r["max_rank"] <= 3 for r in record["target_records"])
        for target in range(len(base)):
            ranks, _ = source_ranks(base, envelope, target)
            assert max(ranks[:2 * k + g]) <= 2
        records.append(record)
    return records


def audit_circles():
    records = []
    safety_obligations = 0
    for n in (24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 76,
              88, 100, 104, 108, 112, 132, 220):
        h = circle_parameter(n)
        base, envelope, _, allowed = circle_rows(n, h)
        safety_obligations += circle_safety(n, h, allowed)
        records.append(audit_graph(base, envelope, (0,),
                                   {"family": "full-mod-four-circle", "h": h,
                                    "target_translation": "all targets equivalent in base and envelope"}))
    # Full target replay of the motivating example, also independently used
    # by the earlier informal review. Its h=11 differs from the default rule.
    base, envelope, _, allowed = circle_rows(60, 11)
    records.append(audit_graph(base, envelope, range(60),
                               {"family": "full-mod-four-circle", "h": 11}))
    # Boundary/modulus samples for the general-order gap-protected extension.
    for h in (11, 15, 19, 23):
        choices = [n for n in range(2 * h + 2, 2 * h + 15) if gcd(n, h) == 1]
        for n in choices:
            base, envelope, _, allowed = circle_rows(n, h, windowed=True)
            safety_obligations += circle_safety(n, h, allowed)
            records.append(audit_graph(base, envelope, (0,),
                                       {"family": "windowed-circle", "h": h,
                                        "target_translation": "all targets equivalent in base and envelope"}))
    # Final simplification has five compulsory moves and a four-point pattern.
    for n in (16, 20, 24, 28, 32, 36, 40, 44, 52, 60, 76, 88, 104, 132):
        h = circle_parameter(n)
        base, envelope, count = five_circle_rows(n, h)
        safety_obligations += count
        records.append(audit_graph(base, envelope, (0,),
                                   {"family": "five-move-full-circle", "h": h,
                                    "target_translation": "all targets equivalent in base and envelope"}))
    for h in (7, 11, 15, 19):
        for n in range(2 * h + 2, 2 * h + 15):
            if gcd(n, h) != 1:
                continue
            base, envelope, count = five_circle_rows(n, h, windowed=True)
            safety_obligations += count
            records.append(audit_graph(base, envelope, (0,),
                                       {"family": "five-move-windowed-circle", "h": h,
                                        "target_translation": "all targets equivalent in base and envelope"}))
    return records, safety_obligations


def run():
    started = time.monotonic()
    symbolic = symbolic_circle()
    symbolic_five = symbolic_five_circle()
    layer_local = [layer_local_obligations(k) for k in (6, 7)]
    circles, safety = audit_circles()
    layers = audit_layers()
    records = circles + layers
    reviewed_paths = ("src/main_interval_half_density.py", "src/main_interval_layered.py",
                      "paper/main-interval-half-density.md", "paper/main-interval-layered.md")
    return {"verified": True, "checker": str(Path(__file__).relative_to(ROOT)),
            "checker_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
            "imports_project_constructors_or_solvers": False,
            "scope": "ordinary symbolic review plus bounded independently replayed robust-envelope ranks",
            "lean_claim": False, "symbolic_circle": symbolic,
            "symbolic_five_circle": symbolic_five,
            "layer_local_premises": layer_local,
            "safe_set_cop_obligations": safety,
            "source_cop_rank_obligations": sum(r["rank_obligations"] for r in records),
            "graphs_checked": len(records),
            "targets_checked": sum(len(r["target_records"]) for r in records),
            "source_sha256": {name: sha256((ROOT / name).read_bytes()).hexdigest()
                              for name in reviewed_paths},
            "elapsed_seconds": round(time.monotonic() - started, 3), "records": records}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path,
                        default=ROOT / "research/main-interval-new-independent-checks.json")
    args = parser.parse_args()
    result = run()
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "records"}, indent=2))

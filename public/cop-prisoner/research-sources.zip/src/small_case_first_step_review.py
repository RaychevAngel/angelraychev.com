#!/usr/bin/env python3
"""Independent static exclusions for the final small first-step cases."""
import hashlib
import itertools
import json
from pathlib import Path
from small_case_rooted_review import leaves

ROOT=Path(__file__).resolve().parents[1]


def forced(rows,n):
    lost=set()
    for c,missing in rows.items():
        for s,row in rows.items():
            if s!=c and missing<=row|{s}:
                lost.update((s,t) for t in row)
        if missing<=rows.keys():
            common=set.intersection(*(set(rows[v]) for v in missing))
            lost.update((s,t) for s,row in rows.items() if s!=c for t in common&row)
    return lost


def enumerate_case(n,initial,cap):
    rows={s:frozenset(v) for s,v in initial.items()}
    candidates={s:[frozenset(v) for v in itertools.combinations([t for t in range(n) if t!=s],2)] for s in range(n)}
    nodes=leaves_count=0
    def visit():
        nonlocal nodes,leaves_count
        nodes+=1
        if len(forced(rows,n))>cap:
            return
        if len(rows)==n:
            leaves_count+=1
            return
        s=max((v for v in range(n) if v not in rows),key=lambda v:(sum(v in x for x in rows.values()),v))
        for row in candidates[s]:
            rows[s]=row
            visit()
        del rows[s]
    visit()
    assert leaves_count==0
    return {'n':n,'initial':{s:sorted(v) for s,v in initial.items()},'defect_cap':cap,'nodes':nodes,'leaves':leaves_count,'complete':True}


def main():
    assert len(forced({0:{1,2},1:{2,3}},5))==2
    assert len(forced({0:{2,3},1:{2,3}},5))==4
    cases=[enumerate_case(8,{0:{1,2,3}},0),
           enumerate_case(8,{0:{1},1:{0,2}},3),
           enumerate_case(8,{0:{1},1:{2,3}},3)]
    rooted=[]
    for degrees in ([5,2,2,2],[4,3,2,2],[3,3,3,2]):
        nodes,found=leaves(4,[],degrees=degrees)
        assert not found
        rooted.append({'degrees':degrees,'nodes':nodes,'leaves':0})
    paths=['src/small_case_first_step_review.py','src/small_case_rooted_review.py',
           'research/small-dense-first-step-proof.md','src/small_dense_first_step_profiles.cpp',
           'research/small-dense-first-step-core-eight.jsonl',
           'research/small-dense-first-step-one-leaf-eight.jsonl',
           'research/small-case-n7-independent-review.json',
           'research/small-case-rooted-independent-review.json']
    report={'verified':True,'boundary':'Independent complete static row/profile replay. The ordinary degree-one reduction is reviewed separately; no Lean formalization.',
            'cases':cases,'rooted_profiles':rooted,
            'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}}
    (ROOT/'research/small-case-first-step-independent-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'verified':True,'cases':cases,'rooted':rooted}))


if __name__=='__main__':
    main()

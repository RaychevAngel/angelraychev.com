"""Assemble the current manuscript by topic without changing theorem labels."""
from pathlib import Path
import re


def assemble(root: Path, manifest: dict) -> str:
    main = (root / manifest['main_source']).read_text()
    matches = list(re.finditer(r'^# (.+)$', main, re.M))
    preamble = main[:matches[0].start()]
    sections = {}
    for i, match in enumerate(matches):
        title = match.group(1)
        if title in sections:
            raise ValueError(f'Duplicate main-source section: {title}')
        end = matches[i + 1].start() if i + 1 < len(matches) else len(main)
        sections[title] = main[match.start():end].strip()

    used_main, used_files = set(), set()
    chunks = [preamble.rstrip()]
    for chapter in manifest['chapters']:
        chunks.append('# ' + chapter['title'])
        for part in chapter['parts']:
            if 'main_section' in part:
                key = part['main_section']
                if key in used_main:
                    raise ValueError(f'Repeated main-source section: {key}')
                used_main.add(key)
                text = sections[key]
            else:
                key = part['file']
                if key in used_files:
                    raise ValueError(f'Repeated manuscript source: {key}')
                used_files.add(key)
                text = (root / key).read_text().strip()
            text = re.sub(r'(?<!\\)\\([\[\]()])',
                          lambda m: '$$' if m[1] in '[]' else '$', text)
            # Keep heading text/anchors, but remove skipped levels in the
            # original fragments so section numbers never acquire a zero.
            headings = [(0, 1)]
            def heading(match):
                original = len(match[1])
                while headings[-1][0] >= original:
                    headings.pop()
                level = headings[-1][1] + 1
                headings.append((original, level))
                return '#' * level + ' '
            text = re.sub(r'^(#{1,5}) ', heading, text, flags=re.M)
            chunks.append(text)
    if used_main != sections.keys():
        raise ValueError(f'Unassigned main-source sections: {sections.keys() - used_main}')
    companion_sources = {entry['source'] for entry in manifest.get('companions', [])}
    available = {str(p.relative_to(root)) for p in (root / 'paper').glob('*.md')
                 if p.name not in {'main.md', 'assembled.md'}
                 and str(p.relative_to(root)) not in companion_sources}
    if used_files != available:
        raise ValueError(f'Manuscript files need an explicit role: {available ^ used_files}')
    return '\n\n'.join(chunks) + '\n'

// Bounded structured search: two permutations with fixed omitted arc 0->1.
// Discovery only; any hit is subsequently certified in the original game.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <numeric>
#include <random>
#include <vector>
using namespace std;
int score(const vector<int>&a,const vector<int>&b){int n=a.size(),sz=2*n*n;vector<vector<int>>out(n),in(n);for(int r=0;r<n;r++){out[r]={r,b[r]};if(r)out[r].push_back(a[r]);for(int v:out[r])in[v].push_back(r);}vector<unsigned char>w(sz),rem(sz);vector<int>q;q.reserve(sz);int total=0;
 for(int t=0;t<n;t++)if(t!=1){fill(w.begin(),w.end(),0);q.clear();for(int r=0;r<n;r++)for(int c=0;c<n;c++)rem[2*(r*n+c)+1]=out[c].size();for(int c=0;c<n;c++)for(int turn=0;turn<2;turn++){int z=2*(t*n+c)+turn;w[z]=1;q.push_back(z);}
 for(size_t h=0;h<q.size();h++){int z=q[h],turn=z%2,r=z/2/n,c=z/2%n;if(turn){for(int p:in[r]){int x=2*(p*n+c);if(p!=c&&!w[x]){w[x]=1;q.push_back(x);}}}else{for(int p:in[c]){int x=2*(r*n+p)+1;if(r!=p&&!w[x]&&--rem[x]==0){w[x]=1;q.push_back(x);}}}}
 for(int r=1;r<n;r++)for(int c=0;c<n;c++)if(r!=c)total+=w[2*(r*n+c)];
 }return total;
}
bool valid(const vector<int>&a,const vector<int>&b){int n=a.size();for(int i=0;i<n;i++)if(a[i]==i||b[i]==i||a[i]==b[i])return false;return a[0]==1;}
int main(int argc,char**argv){int n=stoi(argv[1]);double budget=stod(argv[2]);mt19937 rng(238940+n);auto started=chrono::steady_clock::now();int goal=(n-1)*(n-1)*(n-1),best=0,calls=0;vector<int>ba,bb;
 while(chrono::duration<double>(chrono::steady_clock::now()-started).count()<budget){vector<int>a(n),b(n);iota(a.begin(),a.end(),0);iota(b.begin(),b.end(),0);do{shuffle(a.begin(),a.end(),rng);auto it=find(a.begin(),a.end(),1);swap(a[0],*it);shuffle(b.begin(),b.end(),rng);}while(!valid(a,b));int cur=score(a,b);calls++;int stale=0;
 for(int it=0;it<3000&&stale<400;it++){if(chrono::duration<double>(chrono::steady_clock::now()-started).count()>=budget)break;bool first=rng()%2;auto&v=first?a:b;int x=rng()%n,y=rng()%n;if(x==y||(first&&(x==0||y==0)))continue;swap(v[x],v[y]);if(!valid(a,b)){swap(v[x],v[y]);continue;}int s=score(a,b);calls++;if(s>=cur||(double(rng()%100000)/100000<exp((s-cur)/12.0))){if(s>cur)stale=0;else stale++;cur=s;}else{swap(v[x],v[y]);stale++;}if(cur>best){best=cur;ba=a;bb=b;}if(best==goal)break;}
 if(best==goal)break;
 }
 cout<<"{\"n\":"<<n<<",\"goal\":"<<goal<<",\"best\":"<<best<<",\"calls\":"<<calls<<",\"found\":"<<(best==goal?"true":"false")<<",\"arcs\":[";if(!ba.empty())for(int r=0;r<n;r++){if(r)cout<<",";cout<<"["<<r<<","<<bb[r]<<"]";if(r)cout<<",["<<r<<","<<ba[r]<<"]";}cout<<"],\"low_source\":0,\"low_recipient\":1}\n";
}

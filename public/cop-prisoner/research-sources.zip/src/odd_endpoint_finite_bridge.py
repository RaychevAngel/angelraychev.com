#!/usr/bin/env python3
"""Construct and certify finite odd endpoint witnesses below the uniform range."""
from __future__ import annotations
import gzip, hashlib, json, subprocess, sys, time
from pathlib import Path
from odd_endpoint_all_residues import SPECS, patterns
from game_solver import solve_graph, neighborhoods, verify_certificate
ROOT=Path(__file__).resolve().parents[1]


def family_graph(n):
 q=(n+5)//6;r=6*q-n;spec=SPECS[r];sig,vol=patterns()[spec['pattern_index']]
 removed={(0,j)for j in range(6)if spec['mask']>>j&1}
 removed|={(-1,j)for j in range(6)if spec['extra_mask']>>j&1}
 removed|={(1,j)for j in range(6)if spec['extra_mask']>>(6+j)&1}
 gone={(i%q,j)for i,j in removed};vertices=[(i,j)for i in range(q)for j in range(6)if(i,j)not in gone];index={v:i for i,v in enumerate(vertices)}
 def step(v,which):
  i,j=v
  return (((i+(j==5))%q,(j+1)%6)if which==0 else((i+vol[j])%q,sig[j]))
 low=(spec['source_column']%q,spec['source_type']);arcs=[];lowtarget=None
 for v in vertices:
  outs=[]
  for which in range(2):
   w=step(v,which)
   for _ in range(6*q):
    if w not in gone:break
    w=step(w,which)
   assert w not in gone
   if v==low and which==spec['which']:lowtarget=w
   else:outs.append(w)
  if len(set(outs))!=len(outs)or v in outs:return None
  arcs.extend((index[v],index[w])for w in outs)
 u,v=index[low],index[lowtarget]
 if u==v or(u,v)in arcs:return None
 assert len(arcs)==2*n-1
 assert [sum(a==x for a,b in arcs)for x in range(n)]==[1 if x==u else 2 for x in range(n)]
 assert [sum(b==x for a,b in arcs)for x in range(n)]==[1 if x==v else 2 for x in range(n)]
 return dict(n=n,m=2*n-1,q=q,removed=r,arcs=arcs,low_source=u,low_recipient=v,origin='fixed six-type residue family')


def screen():
 rows=[g for n in range(12,145)if(g:=family_graph(n))is not None]
 data=str(len(rows))+'\n'+''.join(f"{g['n']} {g['low_source']} {g['low_recipient']}\n"+''.join(f'{a} {b}\n'for a,b in g['arcs'])for g in rows)
 result=subprocess.run(['/tmp/odd_endpoint_finite_check'],input=data,text=True,capture_output=True,check=True)
 passed=[int(n)for n in result.stdout.split()]
 receipt={'screened':len(rows),'passed':passed,'failed':[g['n']for g in rows if g['n']not in passed],'graphs':[g for g in rows if g['n']in passed]}
 (ROOT/'research/odd-endpoint-finite-family-screen.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items()if k!='graphs'}))


if __name__=='__main__':screen()

#!/usr/bin/env python3
"""Finite typed-exterior interfaces for a tree of degree-two lane gadgets.
Tests sufficient local games only; failure need not mean a finite lift loses.
"""
from pathlib import Path
from itertools import combinations
from collections import deque
import json,time,hashlib,sys
ROOT=Path(__file__).resolve().parents[1]
GEN=(1,-1,2,-2)
def step(w,g):return w[:-1] if w and w[-1]==-g else w+(g,)
def ball(rad):
 seen={()};todo=[()]
 for w in todo:
  if len(w)>=rad:continue
  for g in GEN:
   z=step(w,g)
   if z not in seen:seen.add(z);todo.append(z)
 return todo

def rules(swaps):
 out=[];beta=[0,2,4,3,1];shifts=[1,-1,-1,-1,-1]
 for lane in range(2):
  for j in range(5):
   aa=(0,5*(lane^(j in swaps))+j+1) if j<4 else (lane+1,5*lane)
   bb=((lane+1)*shifts[j],5*lane+beta[j])
   out.append([aa,bb])
 return out

def arena(swaps,mrad=2,crad=3,extras=()):
 rr=rules(swaps)
 for u,v in extras:rr[u].append((0,v))
 mw=ball(mrad);cw=ball(crad)
 M=[(w,i) for w in mw for i in range(10)];C=[(w,i) for w in cw for i in range(10)]+[(None,i) for i in range(10)]
 mi={v:i for i,v in enumerate(M)};ci={v:i for i,v in enumerate(C)}
 mo=[];co=[]
 for w,i in M:
  succ=[mi[(w,i)]]
  for g,j in rr[i]:
   z=w if not g else step(w,g)
   if (z,j) in mi:succ.append(mi[(z,j)])
  mo.append(succ)
 for w,i in C:
  succ={ci[(w,i)]}
  for g,j in rr[i]:
   if w is None:
    succ.add(ci[(None,j)])
    if g:
     for z in cw:
      if len(step(z,-g))>crad:succ.add(ci[(z,j)])
   else:
    z=w if not g else step(w,g)
    succ.add(ci[(z,j)] if (z,j) in ci else ci[(None,j)])
  co.append(sum(1<<v for v in succ))
 return M,C,mi,ci,mo,co

def objective(ar,goalword,deliverytype=None,entrytypes=range(10),goaltypes=range(10),retain=False):
 M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1
 goal={r for r,(w,i) in enumerate(M) if (goalword is None or w==goalword) and i in goaltypes and (deliverytype is None or i==deliverytype)}
 seeds=[(allc if deliverytype is not None else allc^(1<<ci[M[r]])) if r in goal else 0 for r in range(len(M))]
 W=seeds[:];rounds=0
 while True:
  safe=[]
  for r,w in enumerate(W):
   if deliverytype is not None and r in goal:safe.append(allc)
   else:safe.append(sum(1<<c for c,m in enumerate(co) if m&~w==0))
  U=[]
  for r,nb in enumerate(mo):
   u=seeds[r]
   for v in nb:u|=safe[v]
   if not(deliverytype is not None and r in goal):u &= allc^(1<<ci[M[r]])
   U.append(u)
  if U==W:break
  assert all(w&~u==0 for w,u in zip(W,U));W=U;rounds+=1
 bad=[(i,c) for i in entrytypes for c in range(len(C)) if c!=ci[((),i)] and not (W[mi[((),i)]]>>c&1)]
 result={'pass':not bad,'rounds':rounds,'failed_starts':len(bad),'failed_type_counts':{i:sum(j==i for j,c in bad) for i in entrytypes},'first_failure':None if not bad else {'messenger_type':bad[0][0],'pursuer':C[bad[0][1]]}}
 if retain:result.update(winning_masks=W,bad=bad)
 return result

def main():
 start=time.monotonic();records=[]
 for count in (1,2,3,4):
  for ss in combinations(range(4),count):
   ar=arena(ss);d={'swaps':ss,'messenger_states':len(ar[0]),'pursuer_states':len(ar[1]),'tests':[]}
   for g in (-1,-2):
    z=objective(ar,(g,));z['goal_generator']=g;d['tests'].append(z)
    if not z['pass']:break
   records.append(d);print(d,flush=True)
 out={'scope':'sufficient typed exterior arenas on the free quotient tree; no universal template proved','seconds':time.monotonic()-start,'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'research/composition-interface-free-group.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()

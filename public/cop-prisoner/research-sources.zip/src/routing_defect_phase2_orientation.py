#!/usr/bin/env python3
"""Exact-count routing by orienting every pair incident with the hub set.

Every assignment already has exactly Q/2 arrows. This script performs only
bounded coefficient-free counter checks and sampled all-triple witness checks.
No large deterministic conditional-expectation run is claimed.
"""
from itertools import combinations
from pathlib import Path
from fractions import Fraction
from math import ceil, log
import hashlib
import json
import random


def universe(n, hubs):
    hubs = frozenset(hubs)
    assert hubs <= set(range(n))
    return [(i, j) for i in range(n) for j in range(i+1, n)
            if i in hubs or j in hubs]


def triples(n):
    return [(s,t,c) for s in range(n) for t in range(n) if s != t
            for c in range(n) if c != s]


def required_arrows(s,t,c,u):
    """The c=t coincidence removes a repeated requirement, not an edge."""
    result = {}
    for x,y in ((s,u),(u,t),(u,c)):
        assert x != y
        pair = tuple(sorted((x,y)))
        value = int(x < y)
        assert pair not in result or result[pair] == value
        result[pair] = value
    return result


def bad_completions(n,hubs,fixed,triple):
    s,t,c = triple
    assert s != t and c != s
    hubs = frozenset(hubs)
    total = len(hubs)*(2*n-len(hubs)-1)//2
    free = total-len(fixed)
    used = 0
    count = 1
    for u in hubs-{s,t,c}:
        req = required_arrows(s,t,c,u)
        q = sum(e not in fixed for e in req)
        possible = all(e not in fixed or fixed[e] == v for e,v in req.items())
        count *= (1 << q)-int(possible)
        if count == 0:
            return 0
        used += q
    assert used <= free
    return count << (free-used)


def construct(n,hubs,objectives=None):
    hubs = frozenset(hubs)
    arcs = universe(n,hubs)
    objectives = triples(n) if objectives is None else list(objectives)
    fixed = {}
    def counts():
        return (sum(bad_completions(n,hubs,fixed,tr) for tr in objectives),
                1 << (len(arcs)-len(fixed)))
    bad,total = counts()
    if bad >= total:
        raise ValueError('Expected number of bad triples is not below one')
    for e in arcs:
        branches = []
        for v in (0,1):
            fixed[e] = v
            branches.append(counts())
        assert bad == branches[0][0]+branches[1][0]
        assert total == branches[0][1]+branches[1][1]
        v = next(v for v,(bad,total) in enumerate(branches) if bad < total)
        fixed[e] = v
        bad,total = branches[v]
    assert bad == 0 and total == 1
    return {(i,j) if fixed[i,j] else (j,i) for i,j in arcs}


def literal_bad(edges,hubs,triple):
    s,t,c = triple
    return not any((s,u) in edges and (u,t) in edges and (c,u) not in edges
                   for u in hubs-{s,t,c})


def all_triple_check(n,hubs,edges):
    out = [0]*n
    for s,t in edges:
        assert s != t
        out[s] |= 1 << t
    hubmask = sum(1 << u for u in hubs)
    allmask = (1 << n)-1
    for s in range(n):
        for c in range(n):
            if c == s:
                continue
            safe = out[s] & hubmask & ~(out[c] | (1 << c))
            reached = 0
            while safe:
                bit = safe & -safe
                reached |= out[bit.bit_length()-1]
                safe -= bit
            assert not ((allmask ^ (1 << s)) & ~reached), (s,c)


def main():
    rng = random.Random(552061)
    cases = coincident = 0
    for n in range(2,8):
        for b in range(n+1):
            hubs = set(rng.sample(range(n),b))
            universe_ = universe(n,hubs)
            for _ in range(5):
                free = rng.sample(universe_, min(7,len(universe_)))
                fixed = {e:rng.randrange(2) for e in universe_ if e not in free}
                objectives = rng.sample(triples(n),min(8,len(triples(n))))
                for tr in objectives:
                    brute = 0
                    for mask in range(1 << len(free)):
                        whole = fixed | {e:(mask >> i)&1 for i,e in enumerate(free)}
                        edges = {(i,j) if value else (j,i) for (i,j),value in whole.items()}
                        brute += literal_bad(edges,hubs,tr)
                    count = bad_completions(n,hubs,fixed,tr)
                    assert count == brute, (n,b,tr,count,brute)
                    if free:
                        e = free[0]
                        assert count == sum(bad_completions(n,hubs,fixed | {e:v},tr)
                                            for v in (0,1))
                    cases += 1
                    coincident += tr[1] == tr[2]
    restricted = construct(6,{1,2},[(0,4,5)])
    assert len(restricted) == len(universe(6,{1,2}))
    assert not literal_bad(restricted,{1,2},(0,4,5))

    samples = []
    for n in (128,256):
        b = ceil(24*log(n)+4)
        hubs = set(range(b))
        pairs = universe(n,hubs)
        assert b <= n
        rejected = []
        for attempt in range(16):
            seed = 552000+n+1000*attempt
            sample_rng = random.Random(seed)
            edges = {(i,j) if sample_rng.getrandbits(1) else (j,i) for i,j in pairs}
            try:
                all_triple_check(n,hubs,edges)
                break
            except AssertionError as failure:
                rejected.append({'seed':seed,'failing_source_cop':list(failure.args[0])})
        else:
            raise AssertionError('Bounded sampling found no successful orientation')
        outside = [(s,t) for s in range(b,n) for t in range(b,n) if s != t]
        for additional in (outside,outside[::2]):
            all_triple_check(n,hubs,edges | set(additional))
        samples.append({'n':n,'b':b,'incident_arcs':len(edges),
                        'successful_seed':seed,'rejected_samples':rejected,
                        'budget_interval':[len(edges),len(edges)+len(outside)],
                        'all_triples_empty_full_alternating_exterior':True,
                        'sample_sha256':hashlib.sha256(json.dumps(sorted(edges)).encode()).hexdigest()})

    taylor = sum((Fraction(419,60)**j)/factorial(j) for j in range(25))
    assert taylor > 1075
    assert Fraction(1075,50)-Fraction(8,15) > 3*Fraction(419,60)
    receipt = {'verified':True,'exact_counter_checks':cases,'c_equals_t_checks':coincident,
               'restricted_objective_construction':True,'sampled_routing_graphs':samples,
               'exp_419_over_60_taylor_lower':str(taylor),
               'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'scope':'Literal small orientation completions and exact-count sampled routing graphs. '
                       'No large deterministic run, optimality proof, or new Lean result.'}
    path = Path(__file__).resolve().parents[1]/'research/routing-defect-phase2-orientation-checks.json'
    path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))


def factorial(n):
    value = 1
    for i in range(2,n+1):
        value *= i
    return value


if __name__ == '__main__':
    main()

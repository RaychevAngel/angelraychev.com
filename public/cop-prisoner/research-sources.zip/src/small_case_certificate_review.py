#!/usr/bin/env python3
"""Independent literal review of fixed small-case strategy certificates.

No constructor, game solver, or producer verifier is imported. All alternating
state obligations are reconstructed from the literal arrows, including the
closed losing region. This does not prove exhaustive search completeness.
"""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def review(g):
    n = g['n']
    arcs = set(map(tuple,g['arcs']))
    assert len(arcs) == g['m'] == len(g['arcs'])
    assert all(0 <= s < n and 0 <= t < n and s != t for s,t in arcs)
    moves = [{v}|{t for s,t in arcs if s == v} for v in range(n)]
    assert len(g['certificates']) == n
    winning = [[False]*n for _ in range(n)]
    obligations = 0
    for t,cert in enumerate(g['certificates']):
        assert cert['target'] == t
        ranks, choice = cert['rank'], cert['messenger_successor']
        assert len(ranks) == len(choice) == 2*n*n
        for s in range(n):
            for c in range(n):
                for turn in (0,1):
                    p = 2*(s*n+c)+turn
                    rank = ranks[p]
                    assert isinstance(rank,int) and rank >= -1
                    obligations += 1
                    if s == t:
                        assert rank == 0
                    elif s == c:
                        assert rank == -1
                    else:
                        children = ({2*(v*n+c)+1 for v in moves[s]} if turn == 0
                                    else {2*(s*n+v) for v in moves[c]})
                        if rank >= 0:
                            if turn == 0:
                                assert choice[p] in children
                                assert 0 <= ranks[choice[p]] < rank
                            else:
                                assert all(0 <= ranks[q] < rank for q in children)
                        elif turn == 0:
                            assert all(ranks[q] == -1 for q in children)
                        else:
                            assert any(ranks[q] == -1 for q in children)
            winning[s][t] = all(ranks[2*(s*n+c)] >= 0 for c in range(n) if c != s)
    pairs = [(s,t) for s in range(n) for t in range(n)
             if s != t and (s,t) not in arcs and winning[s][t]]
    assert len(pairs) == g['I']
    if 'indirect_pairs' in g:
        assert pairs == list(map(tuple,g['indirect_pairs']))
    return {'n':n,'m':len(arcs),'I':len(pairs),'alternating_state_obligations':obligations,
            'arcs_sha256':hashlib.sha256(json.dumps(sorted(arcs)).encode()).hexdigest()}


def records(data):
    if isinstance(data,list):
        return data
    if 'graphs' in data:
        return data['graphs']
    if 'certificate' in data and 'n' not in data:
        return [data['certificate']]
    return [data]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files',nargs='+')
    parser.add_argument('--out',required=True)
    args = parser.parse_args()
    report = {'status':'passed','boundary':'Fixed graph values only; no complete-enumeration or Lean claim.',
              'reviewer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'sources':{},'graphs':[]}
    for name in args.files:
        path = ROOT/name
        report['sources'][name] = hashlib.sha256(path.read_bytes()).hexdigest()
        for g in records(json.loads(path.read_text())):
            report['graphs'].append({'source':name,**review(g)})
    (ROOT/args.out).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['graphs']))


if __name__ == '__main__':
    main()

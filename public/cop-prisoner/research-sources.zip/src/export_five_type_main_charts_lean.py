#!/usr/bin/env python3
"""Explicit finite charts for nine fixed prescribed five-type rings."""
from pathlib import Path
import hashlib,json
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
parser.add_argument('--out',type=Path)
args=parser.parse_args()
ROOT=args.root.resolve()
OUT=(args.out or ROOT/'tmp/lean-five-type-charts-reproduce').resolve()
OUT.mkdir(parents=True,exist_ok=True)
def seq(x):return '['+','.join(map(str,x))+']'
def tree(v,lo=0,var='r'):
 if len(v)==1:return seq(v[0])if isinstance(v[0],list)else str(v[0])
 mid=len(v)//2;return f'(if {var} < {lo+mid} then {tree(v[:mid],lo,var)} else {tree(v[mid:],lo+mid,var)})'
files={}
for mode,ks in [('Short',[10,11]),('Full',[16,17,18,19,20,21,22])]:
 for k in ks:
  n=5*k;rad=4 if mode=='Short'else 6;nc=5*(2*rad+1)+1;limit=26 if mode=='Short'else 24
  name=f'Five{mode}Ring{k}';an=f'Five{mode}Arena';cn=f'Five{mode}Certificates'
  base=[];upper=[]
  for s in range(n):
   i,j=divmod(s,5);f=(s+1)%n
   g=5*((i+(1 if j==0 else -1))%k)+[0,2,4,3,1][j]
   b=sorted({f,g});assert len(b)==2 and s not in b
   o=[5*((i-1)%k)+4]if mode=='Short'and j==0 else []
   if mode=='Full':o=[5*((i+3)%k)]
   u=sorted(set(b+o));assert len(u)==len(b)+len(o)and s not in u
   base.append(b);upper.append(u)
  embeds=[[5*((a+r//5-3)%k)+r%5 for r in range(35)]for a in range(k)]
  projects=[]
  for a in range(k):
   row=[]
   for c in range(n):
    col,typ=divmod(c,5);offset=(col-a)%k
    val=5*(offset+rad)+typ if offset<=rad else 5*(offset+rad-k)+typ if offset>=k-rad else nc-1
    assert 0<=val<nc;row.append(val)
   projects.append(row)
  et=tree([tree(row)for row in embeds],var='a');pt=tree([tree(row)for row in projects],var='a')
  decodes=[[5*((a+c//5-rad)%k)+c%5 if c<nc-1 else 0 for c in range(nc)]for a in range(k)]
  dt=tree([tree(row)for row in decodes],var='a')
  text=f'''import {cn}
import FiveTypeRetraction
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open FiniteGame Extremal RobustTwoMove FiveTypeWindow {an}
abbrev V := Fin {n}
abbrev K := Fin {k}
def baseBits (r : Nat) : List V := {tree(base)}
def upperBits (r : Nat) : List V := {tree(upper)}
def lower : Graph V := fun s t => t∈baseBits s.val
def upper : Graph V := fun s t => t∈upperBits s.val
instance : DecidableRel lower := fun _ _ => inferInstanceAs (Decidable (_∈_))
instance : DecidableRel upper := fun _ _ => inferInstanceAs (Decidable (_∈_))
instance : DecidableRel (Legal lower) := fun _ _ => inferInstanceAs (Decidable (_∨_))
def embedBits (a r : Nat) : V := {et}
def projectBits (a r : Nat) : C := {pt}
def decodeBits (a r : Nat) : V := {dt}
def decode (a : K) (c : C) : V := decodeBits a.val c.val
def localCop (r : R) : C := ⟨r.val+{5*(rad-3)},by have:=r.isLt;omega⟩
def outside : C := {nc-1}
def embed (a : K) (r : R) : V := embedBits a.val r.val
def project (a : K) (c : V) : C := projectBits a.val c.val
def typ (s : V) : Fin 5 := ⟨s.val%5,Nat.mod_lt _ (by decide)⟩
def transferCenter (s : V) : K := ⟨(s.val/5+{k}-1)%{k},Nat.mod_lt _ (by decide)⟩
def deliveryCenter (t : V) : K := ⟨t.val/5,by have:=t.isLt;omega⟩
def measure (t s : V) : Nat := (s.val/5+{k}-(t.val/5+2)%{k})%{k}
theorem messenger_rows : ∀ a r, (moveRows r.val).all (fun z => decide (Legal lower (embed a r) (embed a z)))=true := by
  decide +kernel
theorem pursuer_rows : ∀ a c, (c::upperBits c.val).all (fun d => decide (arena.pursuer (project a c) (project a d)))=true := by
  decide +kernel
theorem project_embed : ∀ a r, project a (embed a r)=localCop r := by decide +kernel
theorem decode_embed : ∀ a r, decode a (localCop r)=embed a r := by decide +kernel
theorem retraction : ∀ a c, project a c≠outside → decode a (project a c)=c := by decide +kernel
theorem collision_iff : ∀ a r c, arena.collision r (project a c) ↔ embed a r=c := by
  intro a
  apply FiveTypeRetraction.collision_iff arena (embed a) (project a) (decode a) localCop outside
  · intro r c;change c.val=r.val+{5*(rad-3)} ↔ c=localCop r
    exact ⟨fun h => Fin.ext h,fun h => congrArg Fin.val h⟩
  · intro r;intro same
    have values := congrArg Fin.val same
    change r.val+{5*(rad-3)}={nc-1} at values
    have:=r.isLt;omega
  · exact project_embed a
  · exact decode_embed a
  · exact retraction a
theorem transfer_start : ∀ s, embed (transferCenter s) (transferStart (typ s))=s := by
  decide +kernel
theorem delivery_start : ∀ t s, measure t s=0 → embed (deliveryCenter t) (deliveryStart (typ s))=s := by
  decide +kernel
theorem centered : ∀ a r, transferGoal r → (embed a r).val/5=a.val := by
  decide +kernel
theorem progress_columns : ∀ a b : K, 0<(b.val+{k}-(a.val+2)%{k})%{k} →
    ((b.val+{k}-1)%{k}+{k}-(a.val+2)%{k})%{k} < (b.val+{k}-(a.val+2)%{k})%{k} := by
  decide +kernel
theorem recipient : ∀ t r, deliveryGoal (typ t) r → embed (deliveryCenter t) r=t := by
  decide +kernel
def charts : Charts (k:={k}) lower upper arena where
  embed := embed
  project := project
  messenger := by
    intro a r z move
    exact of_decide_eq_true ((List.all_eq_true.mp (messenger_rows a r)) z move)
  pursuer := by
    intro a c d reply
    have member : d∈c::upperBits c.val := by
      rcases reply with same|edge
      · exact List.mem_cons.mpr (Or.inl same.symm)
      · exact List.mem_cons.mpr (Or.inr edge)
    exact of_decide_eq_true ((List.all_eq_true.mp (pursuer_rows a c)) d member)
  collision := collision_iff
  typ := typ
  transferCenter := transferCenter
  deliveryCenter := deliveryCenter
  measure := measure
  transfer_start := transfer_start
  delivery_start := delivery_start
  progress := by
    intro t s r positive goal
    unfold measure
    rw [centered (transferCenter s) r goal]
    exact progress_columns (deliveryCenter t) (deliveryCenter s) positive
  recipient := recipient

theorem subset : Subgraph lower upper := by unfold Subgraph; decide +kernel
theorem noLoops : Loopless upper := by unfold Loopless; decide +kernel
theorem base_count : arcCount lower={2*n} := by rw [arcCount_eq]; decide +kernel
theorem upper_count : arcCount upper={sum(map(len,upper))} := by rw [arcCount_eq]; decide +kernel
theorem delivers : GuaranteedPrefix.Delivers lower upper :=
  FiveTypeWindow.delivers {cn}.certificates charts
theorem winning (G : Graph V) (lo : Subgraph lower G) (hi : Subgraph G upper)
    (t s c : V) (safe : s≠c) : Winning G t (measure t s*8+{limit}) s c :=
  FiveTypeWindow.winning {cn}.certificates charts lo hi t s c safe
theorem maximum {{m : Nat}} (lo : {2*n}≤m) (hi : m≤{sum(map(len,upper))}) :
    IsMaximum {n} m ({n}*({n}-1)-m) :=
  GuaranteedPrefix.maximum lower upper subset noLoops delivers
    (by simpa only [base_count] using lo) (by simpa only [upper_count] using hi)
#print axioms collision_iff
#print axioms winning
#print axioms maximum
end Delivery.{name}
'''
  (OUT/(name+'.lean')).write_text(text);files[name+'.lean']=hashlib.sha256(text.encode()).hexdigest()
(OUT/'charts-manifest.json').write_text(json.dumps(dict(scope='Finite prescribed five-type charts; acceptance requires source-pinned Lean replay.',exporter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),files=files),indent=2)+'\n')
print('generated',len(files),'finite charts')

#!/usr/bin/env python3
"""A five-move twelve-hub interface with arbitrary bulk antichains.

All optional subsets work.  Instantiation lists subsets and arrows only;
it performs no pursuit-game search.  The ordinary proof is in
paper/main-interval-reduced-hubs.md.  --check replays the fixed hub-only
rank premises and separately exercises full-capacity equal-weight families.
"""
from itertools import combinations, islice
from math import comb
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
HUBS = frozenset(range(12))
INCOMING = frozenset((1, 2, 3, 4, 6, 7, 9, 10))
ACCESS = frozenset((1, 4, 7, 9))
COP_SAFE = frozenset((0, 2, 3))
GUIDE_CODES = ((6, 8, 10), (7, 9, 11), (0, 3), (1, 4), (2, 5),
               (6, 9), (7, 10))
MISSING = tuple(frozenset((6+i, 6+(i-1) % 6)) for i in range(6)) + tuple(
    frozenset(((i+4) % 6, (i+6) % 6)) for i in range(6))


def interval(n, g, r=2):
    if not 2 <= r <= g <= 7:
        return None
    b = n-12-g
    if not 0 <= b <= comb(g, r):
        return None
    base = 106+18*g+(12+r)*b
    return base, base+b*(g+b+8)


def intervals(n):
    rows = []
    for g in range(2, 8):
        for r in range(2, g+1):
            bounds = interval(n, g, r)
            if bounds is not None:
                rows.append(dict(n=n, g=g, b=n-12-g, r=r,
                                 m_min=bounds[0], m_max=bounds[1]))
    return sorted(rows, key=lambda row: (row['m_min'], -row['m_max'],
                                        row['g'], row['r']))


def construction(g, b=None, added=0, r=2, bulk_codes=None):
    """Use the first b r-subsets, or a supplied permitted bulk antichain.

    A supplied list is a literal recipe input, not an optimization problem.
    Its members may have different sizes, but each has at least two elements.
    """
    if not 2 <= g <= 7:
        raise ValueError('Require two through seven guides.')
    if bulk_codes is None:
        if not 2 <= r <= g or b is None or not 0 <= b <= comb(g, r):
            raise ValueError('Invalid bulk count or equal code weight.')
        codes = list(islice(combinations(range(g), r), b))
    else:
        codes = [tuple(sorted(code)) for code in bulk_codes]
        if b is not None and b != len(codes):
            raise ValueError('The supplied bulk count disagrees with its codes.')
        b = len(codes)
        if any(len(code) < 2 or len(set(code)) != len(code)
               or any(not 0 <= v < g for v in code) for code in codes):
            raise ValueError('Every bulk code must be a guide subset of size at least two.')
        if any(set(left) <= set(right) for i, left in enumerate(codes)
               for j, right in enumerate(codes) if i != j):
            raise ValueError('The bulk codes must form an antichain.')
    n, top = 12+g+b, 12+g
    guide_codes = list(map(frozenset, GUIDE_CODES[:g]))
    base = {(u, v) for u in HUBS for v in HUBS
            if u != v and v not in MISSING[u]}
    base.update((u, v) for u in INCOMING for v in range(12, n))
    base.update((12+j, u) for j, code in enumerate(guide_codes)
                for u in HUBS-code)
    base.update((top+j, u) for j in range(b) for u in ACCESS)
    base.update((top+j, 12+v) for j, code in enumerate(codes) for v in code)
    optional = {(u, v) for u in range(12, n) for v in range(top, n) if u != v}
    optional.update((u, v) for u in HUBS-INCOMING for v in range(top, n))
    optional.update((u, v) for u in range(top, n) for v in HUBS-COP_SAFE-ACCESS)
    optional = sorted(optional)
    compulsory_count = 106+18*g+12*b+sum(map(len, codes))
    assert len(base) == compulsory_count and base.isdisjoint(optional)
    assert len(optional) == b*(g+b+8)
    if not 0 <= added <= len(optional):
        raise ValueError('Invalid optional arrow count.')
    return dict(n=n, g=g, b=b, r=r if bulk_codes is None else None,
                bulk_codes=[list(code) for code in codes],
                base=sorted(base), optional=optional,
                arcs=sorted(base | set(optional[:added])),
                m=compulsory_count+added,
                m_interval=[compulsory_count, compulsory_count+len(optional)],
                maximum_delivery_moves=5)


def construct(n, m):
    for row in intervals(n):
        if row['m_min'] <= m <= row['m_max']:
            return construction(row['g'], row['b'], m-row['m_min'], row['r'])
    raise ValueError('No equal-weight reduced-hub interval covers this pair.')


def top_rank(g, target, source):
    """Explicit interface rank, with target=12+g denoting a bulk recipient."""
    if source == target:
        return 0
    if target < 12:
        direct = (target not in MISSING[source] if source < 12
                  else target not in GUIDE_CODES[source-12])
        return 1 if direct else 2
    if source < 12:
        return 1 if source in INCOMING else 2 if source in (0, 5) else 3
    return 3 if source in (14, 15, 16) else 4


def check_interface():
    """Replay every small fixed premise using hub witnesses only.

    The extra cop type reaches every hub outside COP_SAFE and every guide;
    this dominates every bulk cop independently of its code and the bulk count.
    """
    records = []
    for g in range(2, 8):
        top = 12+g
        safe_hubs = list(MISSING) + [frozenset(code) for code in GUIDE_CODES[:g]]
        safe_hubs.append(COP_SAFE)
        obligations = 0
        for target in range(top+1):
            ranks = [top_rank(g, target, source) for source in range(top)]
            for source, rank in enumerate(ranks):
                if rank <= 1:
                    continue
                accessible = (HUBS-MISSING[source]-{source} if source < 12
                              else HUBS-set(GUIDE_CODES[source-12]))
                earlier = {u for u in accessible if ranks[u] < rank}
                for cop, safe in enumerate(safe_hubs):
                    if cop != source:
                        assert earlier & safe, (g, target, source, cop)
                        obligations += 1
        # A hub in INCOMING has a missing row meeting ACCESS. Other hubs
        # cannot reach any guide, so bulk entry can use an assigned guide.
        assert all(MISSING[c] & ACCESS for c in INCOMING)
        records.append(dict(g=g, top_vertices=top, maximum_top_rank=4,
                            hub_only_rank_obligations=obligations))
    return records


def verify_graph(graph):
    """Independently replay the displayed ranks on complete arrow lists."""
    n, top = graph['n'], 12+graph['g']
    B, E = set(map(tuple, graph['base'])), set(map(tuple, graph['base']+graph['optional']))
    out = [{v for u, v in B if u == s} for s in range(n)]
    closed = [{c} | {v for u, v in E if u == c} for c in range(n)]
    obligations = 0
    for target in range(n):
        ranks = [0 if source == target else 1 if target in out[source]
                 else top_rank(graph['g'], target, source) if source < top else 5
                 for source in range(n)]
        for source, rank in enumerate(ranks):
            if rank <= 1:
                continue
            earlier = {u for u in out[source] if ranks[u] < rank}
            if source < top:
                earlier &= HUBS  # The stated ordinary interface uses hubs only.
            else:
                earlier &= set(range(top))
            for cop in range(n):
                if cop != source:
                    assert earlier-closed[cop], (n, target, source, cop)
                    obligations += 1
    return obligations


def checks():
    interface = check_interface()
    rows = []
    for g in range(2, 8):
        for r in range(2, g+1):
            graph = construction(g, comb(g, r), r=r)
            rows.append(dict(n=graph['n'], g=g, b=graph['b'], r=r,
                             m_interval=graph['m_interval'],
                             rank_obligations=verify_graph(graph)))
    # A literal mixed antichain: pairs meeting guide6 and triples within0..5.
    mixed = [(i, 6) for i in range(6)] + list(combinations(range(6), 3))
    graph = construction(7, bulk_codes=mixed)
    rows.append(dict(n=graph['n'], g=7, b=len(mixed), mixed=True,
                     m_interval=graph['m_interval'], rank_obligations=verify_graph(graph)))
    targets = []
    for n, start, end in ((25, 326, 339), (27, 352, 375)):
        for m in (start, end):
            graph = construct(n, m)
            assert len(graph['arcs']) == m
            targets.append(dict(n=n, m=m, m_interval=graph['m_interval'],
                                rank_obligations=verify_graph(graph)))
    files = ['src/main_interval_reduced_hubs.py', 'paper/main-interval-reduced-hubs.md']
    return dict(verified=True, scope='Fixed interface and explicit rank replay; ordinary proof is separate; no new Lean claim.',
                interface=interface, full_capacity_families=rows, target_gaps=targets,
                source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('n', nargs='?', type=int)
    parser.add_argument('m', nargs='?', type=int)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = checks() if args.check else construct(args.n, args.m)
    body = json.dumps(result, indent=2)+'\n'
    if args.out:
        args.out.write_text(body)
    else:
        print(body, end='')


if __name__ == '__main__':
    main()

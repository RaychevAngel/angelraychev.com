"""Explicit incidence components for Theorem 50; no pursuit-game search."""
import itertools
import json
import hashlib
from pathlib import Path

from extremal_bounds_girth_family import base, insert, adjacency, verify

ROOT = Path(__file__).resolve().parents[1]


def projective_incidence(p):
    vectors = [v for v in itertools.product(range(p), repeat=3)
               if any(v) and next(x for x in v if x) == 1]
    vcount = len(vectors)
    assert vcount == p*p+p+1
    edges = {(i, vcount+j) for i, v in enumerate(vectors)
             for j, a in enumerate(vectors)
             if sum(x*y for x, y in zip(v, a)) % p == 0}
    return 2*vcount, edges


def four_factor(n, edges):
    left = n//2
    available = set(edges)
    selected = set()
    for _ in range(4):
        match = {}
        def augment(u, seen):
            for v in sorted(v for x, v in available if x == u):
                if v in seen:
                    continue
                seen.add(v)
                if v not in match or augment(match[v], seen):
                    match[v] = u
                    return True
            return False
        assert all(augment(u, set()) for u in range(left))
        found = {(u, v) for v, u in match.items()}
        assert len(found) == left
        selected |= found
        available -= found
    verify(n, selected)
    return selected


def euler_orientation(n, edges):
    rows = adjacency(n, edges)
    arcs = set()
    for start in range(n):
        if not rows[start]:
            continue
        stack = [start]
        while stack:
            u = stack[-1]
            if rows[u]:
                v = min(rows[u])
                rows[u].remove(v)
                rows[v].remove(u)
                arcs.add((u, v))
                stack.append(v)
            else:
                stack.pop()
    assert len(arcs) == len(edges)
    assert all(sum(u == x for u, v in arcs) == 2 for x in range(n))
    return arcs


def residual_graphs():
    n, edges = base()
    graphs = {n: edges}
    receipt = json.loads((ROOT/'research/extremal-bounds-girth-growth.json').read_text())
    for operation in receipt['operations']:
        assert operation['n_before'] == n
        n, edges = insert(n, edges, operation['edges'])
        graphs[n] = edges
        if n == 113:
            break
    return graphs


def girth_check(n, edges):
    rows = adjacency(n, edges)
    # The only newly constructed full graphs are bipartite incidence graphs.
    assert all(u < n//2 <= v for u, v in edges)
    for u in range(n//2):
        for v in range(u+1, n//2):
            assert len(rows[u] & rows[v]) <= 1


def prepare():
    components = {}
    for p in (5, 7):
        n, edges = projective_incidence(p)
        assert all(len(r) == p+1 for r in adjacency(n, edges))
        girth_check(n, edges)
        factor = four_factor(n, edges)
        core = euler_orientation(n, factor)
        components[p] = (n, core, sorted(edges-factor))
    residual = residual_graphs()
    for n, edges in residual.items():
        verify(n, edges)
    return components, residual


def construct(n, h, prepared):
    assert n >= 166 and 2*n <= h <= 3*n
    components, residual = prepared
    k, offset = divmod(n-166, 62)
    r = 52+offset
    arcs = set()
    optional = []
    used = 0
    for p in [7]+[5]*k:
        order, core, extra = components[p]
        arcs |= {(u+used, v+used) for u, v in core}
        optional += [(u+used, v+used) for u, v in extra]
        used += order
    arcs |= {(u+used, v+used) for u, v in euler_orientation(r, residual[r])}
    assert used+r == n and len(arcs) == 2*n
    assert len(optional) >= n+1
    arcs.update(optional[:h-2*n])
    assert len(arcs) == h
    assert all(sum(u == x for u, v in arcs) >= 2 for x in range(n))
    return arcs


if __name__ == '__main__':
    prepared = prepare()
    orders = list(range(166, 228))+[228, 289, 290, 2419]
    tests = 0
    for n in orders:
        for h in sorted({2*n, 2*n+1, (5*n)//2, 3*n-1, 3*n}):
            construct(n, h, prepared)
            tests += 1
    result = {
        'proved_claim': 'All n>=166, every missing budget2n..3n; ordinary incidence and gluing proof',
        'incidence_components': [{'p': p, 'vertices': prepared[0][p][0],
          'edges': len(prepared[0][p][1])+len(prepared[0][p][2]),
          'spanning_four_factor_edges': len(prepared[0][p][1])} for p in (5, 7)],
        'residual_orders_checked': sorted(prepared[1]),
        'boundary_and_large_orders_checked': orders,
        'exact_budget_constructions_checked': tests,
        'checks': 'Bipartition, degree, no4cycles, four perfect matchings, Euler orientation, prior growth operations, all constructed arc counts and minimum outgoing degrees',
        'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (ROOT/'research/dense-incidence-bridge-checks.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))

// Independent full literal-game replay: compressed messenger/pursuer fixed point.
// Reads every emitted leaf; imports no producer, pruning, or game implementation.
#include <array>
#include <cassert>
#include <chrono>
#include <fstream>
#include <iostream>
#include <string>
using namespace std;
int value_of(const string& s,const string& key){
 auto p=s.find("\""+key+"\":");assert(p!=string::npos);p+=key.size()+3;
 return stoi(s.substr(p));
}
array<unsigned,8> rows_of(const string& s,const string& key){
 array<unsigned,8> rows{};auto p=s.find("\""+key+"\":[");assert(p!=string::npos);p+=key.size()+4;
 for(int i=0;i<8;++i){size_t used;rows[i]=stoul(s.substr(p),&used);p+=used;if(i<7){assert(s[p]==',');++p;}}
 assert(s[p]==']');return rows;
}
int independent_score(const array<unsigned,8>& arrows){
 array<unsigned,8> moves{};for(int v=0;v<8;++v)moves[v]=arrows[v]|(1u<<v);
 int result=0;
 for(int t=0;t<8;++t){
  array<unsigned,8> good{};good[t]=255;
  for(;;){
   array<unsigned,8> after{},next{};after[t]=255;
   for(int s=0;s<8;++s)if(s!=t)for(int c=0;c<8;++c)
    if(!(moves[c]&~good[s]))after[s]|=1u<<c;
   for(int s=0;s<8;++s){
    if(s==t){next[s]=255;continue;}
    for(unsigned bits=moves[s];bits;bits&=bits-1)next[s]|=after[__builtin_ctz(bits)];
    next[s]&=255^(1u<<s);
   }
   if(next==good)break;good=next;
  }
  for(int s=0;s<8;++s)if(s!=t&&!(arrows[s]>>t&1)&&good[s]==(255u^(1u<<s)))++result;
 }
 return result;
}
int main(int argc,char**argv){
 for(int i=1;i<argc;++i){
  auto start=chrono::steady_clock::now();ifstream stream(argv[i]);assert(stream);
  string line;uint64_t checked=0;int max_score=-1,budget=-1,target=-1,declared=-1;bool completed=false;
  while(getline(stream,line)){
   if(line.find("\"kind\":\"leaf\"")!=string::npos){
    bool missing=line.find("\"missing_masks\"")!=string::npos;
    auto literal=rows_of(line,missing?"missing_masks":"delivery_masks");array<unsigned,8> arrows{};int m=0;
    for(int s=0;s<8;++s){assert(literal[s]<256&&!(literal[s]>>s&1));arrows[s]=missing?((255u^literal[s])&~(1u<<s)):literal[s];m+=__builtin_popcount(arrows[s]);}
    if(budget<0)budget=m;assert(m==budget);if(!missing)assert(value_of(line,"m")==m);
    int score=independent_score(arrows);assert(score==value_of(line,"I"));
    max_score=max(max_score,score);++checked;
   }
   if(line.find("\"kind\":\"start\"")!=string::npos){budget=value_of(line,"m");target=value_of(line,"target_I");}
   if(line.find("\"kind\":\"summary\"")!=string::npos){
    assert(line.find("\"complete_requested_profiles\":true")!=string::npos);
    assert(line.find("\"found\":false")!=string::npos&&line.find("\"timeout\":false")!=string::npos);
    declared=value_of(line,"leaves");completed=true;
   }else if(line.find("\"target_I\"")!=string::npos&&line.find("\"complete\"")!=string::npos){
    assert(line.find("\"complete\":true")!=string::npos&&line.find("\"counterexample_found\":false")!=string::npos);
    int final_budget=value_of(line,"min_m");assert(budget<0||budget==final_budget);budget=final_budget;assert(budget==value_of(line,"max_m"));target=value_of(line,"target_I");
    declared=value_of(line,"static_survivors");completed=true;
   }
  }
  assert(completed&&declared>=0&&checked==(uint64_t)declared&&max_score<target);
  cout<<"{\"path\":\""<<argv[i]<<"\",\"status\":\"passed\",\"n\":8,\"m\":"<<budget<<",\"target_I\":"<<target
      <<",\"all_literal_leaves_replayed\":"<<checked<<",\"maximum_leaf_I\":"<<max_score<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}"<<endl;
 }
}

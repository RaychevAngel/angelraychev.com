#!/usr/bin/env python3
"""Readback of small dense envelopes, without the producer or graph helpers."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]

def main():
 path=ROOT/'research/routing-defect-phase2-dense-small-checks.json'
 raw=json.loads(path.read_text());rows=[]
 assert raw['source_sha256']==hashlib.sha256((ROOT/'src/routing_defect_phase2_dense_small.py').read_bytes()).hexdigest()
 for r in raw['rows']:
  n=r['n'];base=set(map(tuple,r['base']));opt=set(map(tuple,r['optional']));full=base|opt
  assert n in(19,20,21)and len(base)==2*n and len(opt)==n and not(base&opt)
  assert len(full)==3*n and all(0<=s<n and 0<=t<n and s!=t for s,t in full)
  assert all(sum(s==v for s,t in base)==sum(t==v for s,t in base)==2 for v in range(n))
  seen=set()
  for s,t,c,u in r['literal_witnesses']:
   assert (s,t) in full and c!=s and 0<=c<n and 0<=u<n
   assert(s,t,c)not in seen;seen.add((s,t,c))
   # The messenger's two arrows exist even with every optional missing arc;
   # the cop's arrow stays missing even with none of those optional arcs.
   assert len({s,u,t})==3 and u!=c
   assert(s,u)not in full and(u,t)not in full and(c,u)in base
  assert seen=={(s,t,c)for s,t in full for c in range(n)if c!=s}
  rows.append({'n':n,'compulsory':len(base),'optional':len(opt),'checked_witnesses':len(seen),'guarantee':'every optional subset, two messenger moves'})
 assert {x['n']for x in rows}=={19,20,21}
 result={'verified':True,'scope':'Independent readback of explicit arbitrary-subset certificates; no graph search or asymptotic extrapolation.',
         'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rows':rows}
 (ROOT/'research/routing-defect-phase2-dense-small-independent.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
if __name__=='__main__':main()

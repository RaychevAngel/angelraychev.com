"""Exact implementation of Alexandra Ignatova's layered construction.

Original manuscript: February 2024; Angel Raychev, mentor.
September 2026 audit: corrected balancing, structural hypothesis verification,
and a proved exact count distinct from the original draft's lower count.
"""
from __future__ import annotations
from itertools import combinations
from math import comb


def balanced_family(x: int) -> list[frozenset[int]]:
    """Split complements with balanced incidence using full cyclic orbits.

    Coordinates are zero based. The last coordinate is distinguished.
    Requires x positive and not a power of two.
    """
    if x <= 0 or x & (x - 1) == 0:
        raise ValueError('x must be positive and not a power of two')
    q = 2*x
    universe = frozenset(range(q))
    remaining = {frozenset(c) for c in combinations(range(q-1), x-1)}
    orbits = []
    while remaining:
        seed = min(remaining, key=lambda a: tuple(sorted(a)))
        orbit = {frozenset((i+j) % (q-1) for i in seed) for j in range(q-1)}
        assert len(orbit) == q-1
        remaining.difference_update(orbit)
        orbits.append(sorted(orbit, key=lambda a: tuple(sorted(a))))
    assert len(orbits) % 2 == 0
    family = []
    for j, orbit in enumerate(orbits):
        for row in orbit:
            extended = row | {q-1}
            family.append(extended if j < len(orbits)//2 else universe-extended)
    family.sort(key=lambda a: tuple(sorted(a)))
    assert len(family) == comb(q,x)//2
    assert all(sum(i in row for row in family) == len(family)//2 for i in range(q))
    assert all(universe-row not in family for row in family)
    return family


def verify_family(q: int, family: list[frozenset[int]]) -> None:
    """Check exactly the sufficient incidence conditions used in the audit."""
    rows = [set(row) for row in family]
    if not rows or len({frozenset(row) for row in rows}) != len(rows):
        raise ValueError('Distinct nonempty row family required')
    if any(len(row) < 2 or not row <= set(range(q)) for row in rows):
        raise ValueError('Every row needs at least two valid coordinates')
    if any(a <= b for i,a in enumerate(rows) for j,b in enumerate(rows) if i != j):
        raise ValueError('Rows must form an antichain')
    columns = [{j for j,row in enumerate(rows) if (i in row) == positive}
               for positive in (True,False) for i in range(q)]
    if any(len(col) < 2 for col in columns):
        raise ValueError('Every literal column needs at least two rows')
    if any(a <= b for i,a in enumerate(columns) for j,b in enumerate(columns) if i != j):
        raise ValueError('Literal columns must form an antichain')


def layered_graph(q: int, family: list[frozenset[int]],
                  other_family: list[frozenset[int]] | None = None):
    """Return (vertex count, arcs, names, metadata).

    A_X -> b_i,b'_i iff i in X; b_i -> A'_Y iff i in Y;
    b'_i -> A'_Y iff i not in Y. Copy symmetrically through c_i,c'_i.
    The two row families may differ. The exact count theorem applies when
    verify_family accepts both; no balancing hypothesis is necessary.
    """
    other_family = family if other_family is None else other_family
    verify_family(q, family)
    verify_family(q, other_family)
    a,ap = len(family),len(other_family)
    names = ([f'A:{tuple(sorted(row))}' for row in family]
             + [f"Aprime:{tuple(sorted(row))}" for row in other_family]
             + [f'{letter}{i}' for letter in ('b','bprime','c','cprime') for i in range(q)])
    b,bp,c,cp = a+ap,a+ap+q,a+ap+2*q,a+ap+3*q
    arcs = []
    for j,row in enumerate(family):
        for i in range(q):
            if i in row:
                arcs.extend(((j,b+i),(j,bp+i),(c+i,j)))
            else:
                arcs.append((cp+i,j))
    for j,row in enumerate(other_family,start=a):
        for i in range(q):
            if i in row:
                arcs.extend(((j,c+i),(j,cp+i),(b+i,j)))
            else:
                arcs.append((bp+i,j))
    n = len(names)
    extras = [(c+i,b+i) for i in range(q)] + [(c+i,bp+i) for i in range(q)]
    extras += [(b+i,c+i) for i in range(q)] + [(b+i,cp+i) for i in range(q)]
    metadata = dict(q=q,a=a,aprime=ap, n=n,m=len(arcs),
                    proved_I=(a+ap)*(n-1-q)+4*q,
                    special_indirect_pairs=extras)
    return n,arcs,names,metadata


def original_graph(x: int):
    return layered_graph(2*x, balanced_family(x))


if __name__ == '__main__':
    import argparse,json
    parser = argparse.ArgumentParser()
    parser.add_argument('--x',type=int,default=3)
    parser.add_argument('--solve',action='store_true')
    args=parser.parse_args()
    n,arcs,names,metadata=original_graph(args.x)
    if args.solve:
        from game_solver import solve_graph
        result=solve_graph(n,arcs)
        metadata['computed_I']=result['I']
        assert result['I']==metadata['proved_I']
    print(json.dumps(metadata,indent=2))

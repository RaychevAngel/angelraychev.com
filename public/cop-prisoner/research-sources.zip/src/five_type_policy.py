"""Five-type family and bounded checks of explicit candidate policies."""
from __future__ import annotations
from collections import deque
from game_solver import neighborhoods,bits

SIGMA=(0,2,4,3,1)
VOLTAGE=(1,-1,-1,-1,-1)

def family(k):
    n=5*k
    a=[(u+1)%n for u in range(n)]
    b=[5*((u//5+VOLTAGE[u%5])%k)+SIGMA[u%5] for u in range(n)]
    out,arcs=neighborhoods(n,[(u,v) for u in range(n) for v in (a[u],b[u])])
    return n,a,b,out,arcs

def distances(k,t):
    n,a,b,out,arcs=family(k);rev=[[]for _ in range(n)]
    for u,v in arcs:rev[v].append(u)
    d=[-1]*n;d[t]=0;q=deque([t])
    while q:
        v=q.popleft()
        for u in rev[v]:
            if d[u]<0:d[u]=d[v]+1;q.append(u)
    return d

def policy_certificate(k,t,policy):
    """Exact fixedpoint with messenger action fixed by policy(r,c).

    Returns ranks; -1 means failure against some pursuer. Collisions outside
    the target are losing and no unsafe move is silently replaced.
    """
    n,a,b,out,arcs=family(k);rank=[[-1]*n for _ in range(n)];rank[t]=[0]*n
    chosen=[[-1 if r==c or r==t else policy(r,c) for c in range(n)]for r in range(n)]
    step=0
    while True:
        new=[row[:] for row in rank];changed=False;step+=1
        for r in range(n):
            for c in range(n):
                if rank[r][c]>=0 or r==c:continue
                v=chosen[r][c]
                assert v in (r,a[r],b[r]),(r,c,v)
                if v==t or (v!=c and all(rank[v][cp]>=0 for cp in bits(out[c]))):
                    new[r][c]=step;changed=True
        rank=new
        if not changed:break
    return rank,chosen

def safe_actions(k,t,r,c):
    n,a,b,out,arcs=family(k)
    return [v for v in (r,a[r],b[r]) if v==t or not(out[c]>>v&1)]

def policy_certificate_queue(k,t,policy):
    n,a,b,out,arcs=family(k);count=n*n
    rank=[-1]*count;remaining=[1]*count;maximum=[0]*count
    reverse=[[]for _ in range(count)];queue=deque()
    for r in range(n):
        for c in range(n):
            s=r*n+c
            if r==t:rank[s]=0;queue.append(s);continue
            if r==c:continue
            v=policy(r,c)
            assert v in (r,a[r],b[r])
            if v==t:rank[s]=1;queue.append(s);continue
            if out[c]>>v&1:continue
            children=[v*n+cp for cp in bits(out[c])]
            remaining[s]=len(children)
            for z in children:reverse[z].append(s)
    while queue:
        z=queue.popleft()
        for s in reverse[z]:
            maximum[s]=max(maximum[s],rank[z]);remaining[s]-=1
            if remaining[s]==0:rank[s]=maximum[s]+1;queue.append(s)
    return [rank[r*n:(r+1)*n]for r in range(n)]

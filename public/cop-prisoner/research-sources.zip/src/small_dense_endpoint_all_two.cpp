// All missing degrees two, with at most three distinct camping losses.
#define main first_step_main
#include "small_dense_first_step_profiles.cpp"
#undef main

int main(int argc,char**argv){
 n=8;seconds=argc>1?stod(argv[1]):10;defect=3;target=13;
 allv=(1u<<n)-1;started=chrono::steady_clock::now();
 for(int s=0;s<n;s++)for(unsigned row=1;row<=allv;row++)
  if(!(row>>s&1)&&__builtin_popcount(row)==2)domain[s].push_back(row);
 rows[0]=6;assigned[0]=true;visit(1);
 emit(capped?"incomplete":found?"witness":"complete");
}

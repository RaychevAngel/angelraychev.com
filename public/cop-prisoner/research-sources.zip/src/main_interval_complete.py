#!/usr/bin/env python3
"""Explicit complete main interval for every n>=12; no discovery at construction."""
from functools import lru_cache
from pathlib import Path
import json,hashlib,argparse,math,importlib.util
import main_interval_half_density as half_circle
import main_interval_layered as layer
import main_interval_resume as protected
import main_interval_pair_codes as pairs
import main_interval_six_circle as circle
import main_interval_reduced_hubs as hub
import sparse_staged as stages
import sparse_finite_bridge_construct as endpoint
ROOT=Path(__file__).resolve().parents[1]

@lru_cache(None)
def sparse_envelope():
 spec=importlib.util.spec_from_file_location('retained_sparse_interface',ROOT/'src/sparse-interface-third.py')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 return module.envelope

def small_protected(n):
 choices=[]
 for h in range(7,(n+1)//2,2):
  if math.gcd(n,h)!=1:continue
  C={1,(h-1)//2,h};A={0}|C;D={(u-v)%n for u in C for v in C if u!=v}
  for x in range(n):
   if x not in A and all((x-y)%n not in D for y in A):A.add(x)
  assert len(D)==6 and all(sum((u-d)%n in A for u in A)==1 for d in D)
  choices.append((len(A),h,sorted(A)))
 _,h,A=max(choices)
 return {1,(h-1)//2,h},A

@lru_cache(None)
def families(n):
 if n<12:raise ValueError('The complete main interval requires n>=12.')
 if n>=115:
  k=(n+5)//6;r=6*k-n
  return (dict(branch='sparse',m_min=2*n,m_max=20*k-11*r,variant=None),
          dict(branch='pair_main',m_min=3*n,m_max=n*(n-3)))
 if n>=79:
  rows=[dict(branch='pair_main',m_min=3*n,m_max=n*(n-3))]
  rows += [dict(x,branch='staged') for x in stages.intervals(n)]
 else:
  rows=finite_upper_families(n)
 rows.append(dict(branch='endpoint',m_min=2*n,m_max=2*n))
 if n>=50 and n%5==0:
  rows.append(dict(branch='five',m_min=2*n,m_max=3*n if n>=80 else 11*n//5))
 registry=json.loads((ROOT/'research/sparse-interface-third-proof-registry.json').read_text())
 for x in registry['records']:
  if x['n']==n:rows.append(dict(branch='sparse',m_min=x['m_min'],m_max=x['m_max'],variant=x['variant'],maximum_moves=x['maximum_moves']))
 return tuple(rows)

def finite_upper_families(n):
 rows=[dict(x,branch='six_circle') for x in circle.intervals(n)]
 rows += [dict(x,branch='reduced_hubs') for x in hub.intervals(n)]
 rows += [dict(x,branch='staged') for x in stages.intervals(n)]
 rows += [dict(x,branch='circle') for x in half_circle.intervals(n)]
 rows += [dict(x,branch='layer') for x in layer.intervals(n)]
 low,high=pairs.interval(n)
 rows.append(dict(branch='pair_codes',m_min=low,m_max=high,k=pairs.core_size(n)))
 if n in (13,14):
  tiny=next(r for r in json.loads((ROOT/'research/routing-defect-phase2-dense-tiny-checks.json').read_text())['rows'] if r['n']==n)
  rows.append(dict(branch='dense_tiny',m_min=n*(n-3)-len(tiny['optional']),m_max=n*(n-3)))
 if n>=25:
  if n<=42:
   C,values=small_protected(n)
   rows.append(dict(branch='small_protected',m_min=3*n,m_max=n*(len(values)-1)))
  else:
   _,values,_=protected.move_envelope(n)
   rows.append(dict(branch='protected',m_min=3*n,m_max=n*(len(values)-1)))
 return rows

def plan(n):
 at=2*n;stop=n*(n-3);out=[]
 while at<=stop:
  candidates=[r for r in families(n) if r['m_min']<=at<=r['m_max']]
  if not candidates:raise ValueError(f'Uncovered pair({n},{at})')
  r=max(candidates,key=lambda x:x['m_max']);end=min(r['m_max'],stop)
  out.append(dict(r,used_from=at,used_through=end));at=end+1
 return out

def construct(n,m):
 if n<12 or not 2*n<=m<=n*(n-3):raise ValueError('Require n>=12 and2n<=m<=n(n-3).')
 if n>=79 and m>=3*n:return pairs.construct(n,m)
 row=next((r for r in families(n) if r['m_min']<=m<=r['m_max']),None)
 if row is None:raise ValueError(f'No recipe for({n},{m})')
 b=row['branch']
 if b=='six_circle':arcs=circle.construct(n,m)
 elif b=='reduced_hubs':arcs=hub.construct(n,m)['arcs']
 elif b=='staged':arcs=stages.construct(n,m)['arcs']
 elif b=='endpoint':arcs=endpoint.construct(n)['arcs']
 elif b=='five':
  from five_type_certificate import Strip
  k=n//5;strip=Strip();ix=lambda v:5*(v[0]%k)+v[1]
  base={(5*i+j,ix(w)) for i in range(k) for j in range(5) for w in strip.arcs((i,j))}
  optional=sorted({(5*i+j,5*((i+3)%k)) for i in range(k) for j in range(5)} if n>=80 else {(5*i,5*((i-1)%k)+4) for i in range(k)})
  arcs=base|set(optional[:m-2*n])
 elif b=='pair_codes':return pairs.pair_construct(n,m,row['k'])
 elif b=='dense_tiny':
  tiny=next(r for r in json.loads((ROOT/'research/routing-defect-phase2-dense-tiny-checks.json').read_text())['rows'] if r['n']==n)
  missing=set(map(tuple,tiny['base']+sorted(tiny['optional'])[:n*(n-3)-m]))
  arcs=[(u,v) for u in range(n) for v in range(n) if u!=v and (u,v) not in missing]
 elif b=='protected':arcs=protected.construct(n,m)[0]
 elif b=='small_protected':
  C,A=small_protected(n);base={(u,(u+d)%n) for u in range(n) for d in C}
  optional=sorted((u,(u+d)%n) for u in range(n) for d in set(A)-C-{0})
  arcs=base|set(optional[:m-3*n])
 elif b=='circle':arcs=half_circle.construct(n,m,h=row['h'],variant=row['variant'])
 elif b=='layer':arcs=layer.construction(row['g'],row['b'],m-row['m_min'],row['r'],row['hubs'])['arcs']
 elif b=='sparse':
  _,data=sparse_envelope()(n,variant=row.get('variant'))
  assert (data['m_min'],data['m_max'])==(row['m_min'],row['m_max'])
  arcs=data['base']+data['optional'][:m-data['m_min']]
 else:raise AssertionError(('unsupported construction branch',b))
 arcs=sorted(map(tuple,arcs));assert len(arcs)==len(set(arcs))==m
 assert all(0<=u<n and 0<=v<n and u!=v for u,v in arcs)
 return dict(n=n,m=m,I=n*(n-1)-m,branch=b,parameters=row,arcs=arcs)

def checks():
 plans=[];built=0
 for n in range(12,115):
  p=plan(n)
  for s in p:
   for m in {s['used_from'],s['used_through'],(s['used_from']+s['used_through'])//2}:
    assert construct(n,m)['I']==n*(n-1)-m;built+=1
  plans.append(dict(n=n,segments=p))
 for n in (115,116,117,391,827,828,869,929):
  for m in (2*n,3*n,n*(n-3)):
   graph=construct(n,m);assert len(graph['arcs'])==m;built+=1
 return dict(verified=True,full_main_from=12,finite_upper_bridge=[12,78],finite_low_bridge=[12,114],ordinary_above_three_n_from=79,ordinary_full_from=115,built=built,plans=plans,source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['src/main_interval_complete.py','src/main_interval_pair_codes.py','src/sparse_staged.py','src/main_interval_six_circle.py','src/main_interval_reduced_hubs.py','paper/main-interval-complete.md','paper/core-code-composition.md']})

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('n',nargs='?',type=int);p.add_argument('m',nargs='?',type=int);p.add_argument('--out',type=Path);a=p.parse_args();result=checks() if a.check else construct(a.n,a.m)
 if a.out:a.out.write_text(json.dumps(result,indent=2)+'\n')
 else:print(json.dumps(result,indent=2))

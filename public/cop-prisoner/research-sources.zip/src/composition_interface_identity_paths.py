#!/usr/bin/env python3
"""Exact empty-word reachability for a finite free-group voltage template.
Grammar S -> epsilon | SS | a S a^-1 certifies and exhausts identity words.
"""
from pathlib import Path
import json,hashlib
from composition_interface_free_group import rules
ROOT=Path(__file__).resolve().parents[1]
def closure(extras=()):
 rr=rules((0,1,3))
 for u,v in extras:rr[u].append((0,v))
 R=[[i==j for j in range(10)] for i in range(10)]
 for i,row in enumerate(rr):
  for g,j in row:
   if g==0:R[i][j]=True
 rounds=0
 while True:
  old=[r[:] for r in R]
  for k in range(10):
   for i in range(10):
    for j in range(10):R[i][j]|=R[i][k] and R[k][j]
  for i in range(10):
   for g,k in rr[i]:
    if not g:continue
    for l in range(10):
     if R[k][l]:
      for h,j in rr[l]:
       if h==-g:R[i][j]=True
  rounds+=1
  if old==R:break
 return {'extras':extras,'iterations':rounds,'reachable_pairs':sum(sum(r) for r in R),'rows':[[j for j,x in enumerate(row) if x] for row in R]}
rr=[closure(ex) for ex in ((),((4,0),(9,5)),((4,5),(9,0)),((7,6),(2,1)),((3,6),(8,1)))]
for d in rr:print(d)
json.dump({'scope':'exact directed same-fiber reachability in infinite free-group lift; ignores the pursuer','records':rr,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},open(ROOT/'research/composition-interface-identity-paths.json','w'),indent=2)

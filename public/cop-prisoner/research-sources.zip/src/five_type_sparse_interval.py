#!/usr/bin/env python3
"""Local proof certificates for every budget 2n..11n/5 on five-type rings.

The messenger uses only the original arcs. The pursuer additionally has all
arcs (i,0)->(i-1,4). Thus any subset of these extra actual arcs is covered.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from five_type_certificate import Strip, arena, solve, verify


def asymmetric_arena(M=3, R=4, extra_types=((0, -1, 4),)):
    a = arena(Strip(), messenger_radius=M, pursuer_radius=R)
    positions = a["pursuer_vertices"]
    index = {v: i for i, v in enumerate(positions)}
    outside = index[None]
    for c, v in enumerate(positions):
        if v is None:
            continue
        for source_type, shift, target_type in extra_types:
            if v[1] == source_type:
                destination = index.get((v[0] + shift, target_type), outside)
                a["pursuer_moves"][c] = sorted(set(a["pursuer_moves"][c] + [destination]))
    max_jump = max([1] + [abs(x[1]) for x in extra_types])
    assert R >= max_jump
    a["pursuer_moves"][outside] = [outside] + [
        c for c, v in enumerate(positions)
        if v is not None and abs(v[0]) >= R - max_jump + 1]
    a["pursuer_extra_arc_types"] = [list(x) for x in extra_types]
    a["maximum_column_jump"] = max_jump
    a["minimum_ring_columns_for_projection"] = 2 * R + max_jump + 1
    return a


def suite(M=3, R=4, extra_types=((0, -1, 4),)):
    a = asymmetric_arena(M, R, extra_types)
    records = []
    goals = {(0, t) for t in range(5)}
    cert = solve(a, goals, True)
    bounds = verify(a, cert, 1)
    records.append({"kind": "transfer", "source_column": 1,
                    "bounds": bounds, "certificate": cert})
    for target in range(5):
        cert = solve(a, {(0, target)}, False)
        bounds = verify(a, cert, 2)
        records.append({"kind": "delivery", "target": target,
                        "source_column": 2, "bounds": bounds, "certificate": cert})
    return {"status": "verified", "arena": a, "records": records,
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "scope": f"k>={a['minimum_ring_columns_for_projection']}, messenger restricted to base graph, pursuer has all extra arcs"}


if __name__ == "__main__":
    result = suite()
    path = Path(__file__).resolve().parents[1] / "research/five-type-sparse-interval-certificates.json"
    path.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    print(json.dumps({"status": result["status"], "bounds": [max(r["bounds"]) for r in result["records"]],
                      "receipt": str(path)}))
    full = suite(3, 6, tuple((j, 3, 0) for j in range(5)))
    path = path.with_name("five-type-full-sparse-interval-certificates.json")
    path.write_text(json.dumps(full, separators=(",", ":")) + "\n")
    print(json.dumps({"status": full["status"], "bounds": [max(r["bounds"]) for r in full["records"]],
                      "scope": full["scope"], "receipt": str(path)}))

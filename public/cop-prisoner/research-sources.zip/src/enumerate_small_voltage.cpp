// Search fixed-width two-permutation periodic digraphs. Heuristic family
// discovery: success on finite k lists is not an infinite-family proof.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <vector>
uint64_t out[64],w[64],safe[64],nextw[64];int second[64];
bool universal(int q,int k,const std::vector<int>&sigma,const std::vector<int>&voltage){
  int n=q*k;uint64_t all=(uint64_t(1)<<n)-1;
  for(int x=0;x<k;++x)for(int j=0;j<q;++j){int u=q*x+j,v=q*((x+voltage[j]+k)%k)+sigma[j];
    if(v==u || v==(u+1)%n)return false;second[u]=v;out[u]=(uint64_t(1)<<u)|(uint64_t(1)<<((u+1)%n))|(uint64_t(1)<<v);}
  for(int t=0;t<q;++t){std::fill(w,w+n,0);w[t]=all;bool changed=true;
    while(changed){for(int v=0;v<n;++v){safe[v]=0;if(v==t)safe[v]=all;else for(int c=0;c<n;++c)if(!(out[c]&~w[v]))safe[v]|=uint64_t(1)<<c;}
      changed=false;for(int r=0;r<n;++r){uint64_t z=r==t?all:(safe[r]|safe[(r+1)%n]|safe[second[r]])&~(uint64_t(1)<<r);nextw[r]=z;changed|=z!=w[r];}std::copy(nextw,nextw+n,w);}
    for(int s=0;s<n;++s)if((w[s]|(uint64_t(1)<<s))!=all)return false;
  }return true;
}
int main(int argc,char**argv){int q=argc>1?std::atoi(argv[1]):4;double budget=argc>2?std::atof(argv[2]):10;int parity=argc>3?std::atoi(argv[3]):0;
  if(q<3 || q>6)return 2;std::vector<int>sigma(q),v(q);std::iota(sigma.begin(),sigma.end(),0);
  std::vector<int>ks=parity?std::vector<int>{5,7,9}:std::vector<int>{4,5,7,8};
  auto start=std::chrono::steady_clock::now();auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
  int threeq=1;for(int j=0;j<q;++j)threeq*=3;long long tested=0;bool first=true,complete=true;std::cout<<"{\"q\":"<<q<<",\"odd_k_only\":"<<(parity?"true":"false")<<",\"candidates\":[";
  do{for(int word=0;word<threeq;++word){if(elapsed()>budget){complete=false;goto done;}int x=word;for(int j=0;j<q;++j){v[j]=x%3-1;x/=3;}++tested;bool ok=true;
      for(int k:ks)if(!universal(q,k,sigma,v)){ok=false;break;}
      if(ok){if(!first)std::cout<<",";first=false;std::cout<<"{\"sigma\":[";for(int j=0;j<q;++j){if(j)std::cout<<",";std::cout<<sigma[j];}std::cout<<"],\"voltage\":[";for(int j=0;j<q;++j){if(j)std::cout<<",";std::cout<<v[j];}std::cout<<"]}";}
    }}while(std::next_permutation(sigma.begin(),sigma.end()));
done:std::cout<<"],\"tested\":"<<tested<<",\"complete_search\":"<<(complete?"true":"false")<<",\"seconds\":"<<elapsed()<<"}\n";
}

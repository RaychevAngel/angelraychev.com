#!/usr/bin/env python3
"""Targeted final-type placement scan in the branch-aware arena."""
from pathlib import Path
import json,hashlib,time
from composition_interface_branch_terminal import arena
from composition_interface_free_group import ball
from composition_interface_invariant import attract
from composition_interface_certify import good
ROOT=Path(__file__).resolve().parents[1]
def run(mrad=3,crad=3,branchdepth=2):
 ar=arena(mrad,crad,branchdepth);M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1
 required=[(mi[(),i],c) for i in range(10) for c,(cw,j) in enumerate(C) if good(i,cw,j) and (i,cw,j) not in {(3,(),5),(8,(),0)}]
 records=[];start=time.monotonic()
 for w in ball(2):
  tr=mi[w,2];W,r=attract(ar,[allc if x==tr else 0 for x in range(len(M))],{tr})
  bad=[(M[x][1],C[c]) for x,c in required if not(W[x]>>c&1)]
  d={'word':w,'target':2,'rounds':r,'failed':len(bad),'bad':bad};records.append(d);print({k:v for k,v in d.items() if k!='bad'},flush=True)
  if not bad:break
 return {'scope':'free-tree local modules, finite-girth simulation still required','mrad':mrad,'crad':crad,'branchdepth':branchdepth,'seconds':time.monotonic()-start,'records':records}
if __name__=='__main__':
 out=run();out['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 (ROOT/'research/composition-interface-terminal-two.json').write_text(json.dumps(out,indent=2)+'\n')

"""Independent path-enumeration replay of the explicit girth growth certificate.

Unlike the generator's edge-deleted BFS, girth is checked by enumerating every
simple path with at most five vertices and rejecting any closing edge.
"""
import hashlib,json
from pathlib import Path

def verify_graph(a):
    n=len(a)
    assert all(len(row)==4 for row in a)
    for u,row in enumerate(a):
        assert u not in row
        assert all(0<=v<n and u in a[v]for v in row)
    for root in range(n):
        def extend(path):
            end=path[-1]
            if len(path)>=3:assert root not in a[end],('short cycle',path)
            if len(path)==5:return
            for v in a[end]:
                if v not in path:extend(path+[v])
        extend([root])

def within_three(a,start,end):
    seen={start};stack=[(start,0)]
    while stack:
        u,d=stack.pop()
        if u==end:return True
        if d<3:
            # Store walks rather than permanently marking by depth: a DFS
            # may encounter the same vertex first through a longer route.
            stack.extend((v,d+1)for v in a[u])
    return False

if __name__=='__main__':
    project=Path(__file__).resolve().parents[1]
    path=project/'research/extremal-bounds-girth-growth.json'
    cert=json.loads(path.read_text())
    a=[set()for _ in range(52)]
    for component in range(2):
        for p in range(13):
            for l in range(13):
                if (p-l)%13 in (0,1,3,9):
                    u=26*component+p;v=26*component+13+l
                    a[u].add(v);a[v].add(u)
    verify_graph(a)
    for op in cert['operations']:
        assert op['n_before']==len(a)
        (u,v),(w,z)=op['edges']
        assert len({u,v,w,z})==4
        assert v in a[u] and z in a[w]
        assert all(not within_three(a,b,c) for b in(u,v)for c in(w,z))
        for b,c in((u,v),(w,z)):a[b].remove(c);a[c].remove(b)
        x=len(a);a.append({u,v,w,z})
        for b in(u,v,w,z):a[b].add(x)
        verify_graph(a)
    final_edges=sorted((u,v)for u,row in enumerate(a)for v in row if u<v)
    assert [list(e)for e in final_edges]==cert['final_edges']
    result={'verified':True,'initial_n':52,'final_n':len(a),'graph_orders_verified':len(cert['operations'])+1,'method':'independent simple-path enumeration through length five; direct operation replay','certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    dest=project/'research/extremal-bounds-girth-verification.json'
    dest.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

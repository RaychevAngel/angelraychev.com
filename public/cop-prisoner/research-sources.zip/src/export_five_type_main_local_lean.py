#!/usr/bin/env python3
"""Literal retained five-type certificates; no new search."""
from pathlib import Path
from collections import defaultdict
import hashlib,json
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
parser.add_argument('--out',type=Path)
args=parser.parse_args()
ROOT=args.root.resolve()
OUT=(args.out or ROOT/'tmp/lean-five-type-local-reproduce').resolve()
OUT.mkdir(parents=True,exist_ok=True)
def seq(x):return '['+','.join(map(str,x))+']'
def tree(v,lo=0):
 if len(v)==1:return seq(v[0])if isinstance(v[0],list)else str(v[0])
 mid=len(v)//2;return f'(if r < {lo+mid} then {tree(v[:mid],lo)} else {tree(v[mid:],lo+mid)})'
def write(name,text):
 (OUT/(name+'.lean')).write_text(text);files[name+'.lean']=hashlib.sha256(text.encode()).hexdigest()
files={};sources={};stats=[]
for mode,path,pin in [('Short','five-type-sparse-interval-certificates.json','621c19b8dd558ea938bedad334c65c8cc9c85c5d1ddb317db0a54324a0bb0eb7'),('Full','five-type-full-sparse-interval-certificates.json','5e1aca82d2962cba39581e1ecae8f9d09a4d227732016d2a94ef7fccc9f8c1f0')]:
 raw=(ROOT/'research'/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==pin;sources[path]=pin
 d=json.loads(raw);a=d['arena'];nc=len(a['pursuer_vertices']);delta=5*(a['R']-3);base='Five'+mode+'Arena'
 rm=a['messenger_moves'];cm=a['pursuer_moves'];reply=[sum(1<<i for i in row)for row in cm];collision=[1<<(i+delta)for i in range(35)];required=[((1<<nc)-1)^b for b in collision]
 text=f'''import FiveTypeWindow
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{base}
open LocalArena GroupedArena FiveTypeWindow
abbrev C := Fin {nc}
def moveRows (r : Nat) : List R := {tree(rm)}
def replyRows (r : Nat) : List C := {tree(cm)}
def arena : Arena R C where
  messenger r z := z∈moveRows r.val
  pursuer c d := d∈replyRows c.val
  collision r c := c.val=r.val+{delta}
instance : DecidableRel arena.messenger := fun _ _ => inferInstanceAs (Decidable (_∈_))
instance : DecidableRel arena.pursuer := fun _ _ => inferInstanceAs (Decidable (_∈_))
instance : DecidableRel arena.collision := fun _ _ => inferInstanceAs (Decidable (_=_))
def replyBits (r : Nat) : Nat := {tree(reply)}
def replyMasks (c : C) : Nat := replyBits c.val
def collisionBits (r : Nat) : Nat := {tree(collision)}
def collisionMasks (r : R) : Nat := collisionBits r.val
def requiredBits (r : Nat) : Nat := {tree(required)}
def requiredMasks (r : R) : Nat := requiredBits r.val
theorem replies_checked : ∀ c, (replyRows c.val).all (fun d => (replyMasks c).testBit d.val)=true := by decide +kernel
theorem reply_coverage : ∀ c d, arena.pursuer c d → Has (replyMasks c) d := by
  intro c d mem; exact (List.all_eq_true.mp (replies_checked c)) d mem
theorem collision_coverage : ∀ r c, arena.collision r c → Has (collisionMasks r) c := by
  unfold Has; decide +kernel
theorem required_coverage : ∀ r c, ¬arena.collision r c → Has (requiredMasks r) c := by
  unfold Has; decide +kernel
#print axioms required_coverage
end Delivery.{base}
'''
 write(base,text)
 names=[]
 for rec in d['records']:
  cert=rec['certificate'];target=rec.get('target');safe=target is None;goal=set(cert['goal']);ranks=cert['ranks'];moves=cert['moves'];bound=max(rec['bounds']);start=rec['source_column']+3
  groups=[defaultdict(list)for _ in range(35)];retained=0
  for r in range(35):
   for c in range(nc):
    rank=ranks[r][c]
    if rank<0 or c==r+delta:continue
    z=moves[r][c] if moves[r][c]>=0 else r
    if r not in goal:
     assert rank>0 and z in rm[r]
     if safe or z not in goal:
      assert c!=z+delta
      assert all(cc!=z+delta and 0<=ranks[z][cc]<rank for cc in cm[c])
    groups[r][rank,z].append(c);retained+=1
  encoded=[];bounded=[]
  for row in groups:
   terms=[];mask=0
   for (rank,z),cs in sorted(row.items()):
    bits=sum(1<<c for c in cs);terms.append(f'{{rank:={rank},move:={z},cops:={seq(cs)},mask:={bits}}}')
    if rank<=bound:mask|=bits
   encoded.append(terms);bounded.append(mask)
  for r in range(35):
   if r//5==start:assert required[r]&bounded[r]==required[r]
  name='Five'+mode+('Transfer'if safe else f'Delivery{target}');names.append(name)
  g='transferGoal'if safe else f'deliveryGoal {target}';kind='SafeChecked'if safe else 'DeliveryChecked';checker='safe_checked'if safe else 'delivery_checked'
  text=f'''import {base}
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open LocalArena GroupedArena FiveTypeWindow {base}
noncomputable def groupRows (r : Nat) : List (Group 35 {nc}) := {tree(encoded)}
noncomputable def rows (r : R) : List (Group 35 {nc}) := groupRows r.val
noncomputable def data : Data R C := GroupedArena.data rows
theorem groups_checked : Checked {'false'if safe else 'true'} arena ({g}) replyMasks collisionMasks rows := by
  unfold Checked; decide +kernel
theorem checked : {kind} arena ({g}) data :=
  GroupedArena.{checker} arena ({g}) replyMasks collisionMasks rows reply_coverage collision_coverage groups_checked
def boundBits (r : Nat) : Nat := {tree(bounded)}
def boundMasks (r : R) : Nat := boundBits r.val
theorem bounds_checked : ∀ r, lowerMask (rows r) {bound+1}=boundMasks r := by decide +kernel
theorem entries_checked : ∀ r, r.val/5={start} → requiredMasks r &&& boundMasks r=requiredMasks r := by decide +kernel
theorem entries : ∀ r c, r.val/5={start} → ¬arena.collision r c → data.region r c ∧ data.rank r c≤{bound} := by
  intro r c start safe
  apply GroupedArena.bounded rows r c {bound}
  rw [bounds_checked]
  exact has_subset (entries_checked r start) (required_coverage r c safe)
#print axioms checked
#print axioms entries
end Delivery.{name}
''';write(name,text);stats.append(dict(module=name,groups=sum(map(len,groups)),retained_states=retained,bound=bound))
 name='Five'+mode+'Certificates';limit=26 if mode=='Short' else 24
 text='\n'.join('import '+x for x in names)+f'''
namespace Delivery.{name}
open FiveTypeWindow {base}
noncomputable def delivery (t : Fin 5) : LocalArena.Data R C :=
  if t=0 then {names[1]}.data else if t=1 then {names[2]}.data else
  if t=2 then {names[3]}.data else if t=3 then {names[4]}.data else {names[5]}.data
noncomputable def certificates : Certificates arena {limit} where
  transfer := {names[0]}.data
  transfer_checked := {names[0]}.checked
  transfer_entries := {names[0]}.entries
  delivery := delivery
  delivery_checked := by
    intro t
    have cases : t=0 ∨ t=1 ∨ t=2 ∨ t=3 ∨ t=4 := by omega
    rcases cases with rfl|rfl|rfl|rfl|rfl
'''
 for i in range(5):text+=f'    · simpa [delivery] using {names[i+1]}.checked\n'
 text+='  delivery_entries := by\n    intro t r c entry safe\n    have cases : t=0 ∨ t=1 ∨ t=2 ∨ t=3 ∨ t=4 := by omega\n    rcases cases with rfl|rfl|rfl|rfl|rfl\n'
 for i in range(5):text+=f'    · have result := {names[i+1]}.entries r c entry safe\n      exact ⟨by simpa [delivery] using result.1,by simpa [delivery] using (Nat.le_trans result.2 (by decide : {max(d["records"][i+1]["bounds"])}≤{limit}))⟩\n'
 text+=f'\n#print axioms certificates\nend Delivery.{name}\n';write(name,text)
(OUT/'manifest.json').write_text(json.dumps(dict(scope='Staged literal local objectives only; finite projections separate.',sources=sources,exporter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),files=files,objectives=stats),indent=2)+'\n')
print(json.dumps(stats))

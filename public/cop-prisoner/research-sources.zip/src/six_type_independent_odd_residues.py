#!/usr/bin/env python3
"""Independent explicit certificates for five smoothed odd-endpoint patches.

Graph permutations, smoothing, deficiency exclusions, and widened r=5
interfaces are built here without importing any primary patch or solver.
"""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path

import six_type_independent_verify as independent

ROOT = Path(__file__).resolve().parents[1]
SPECS = [
    {"removed_count": 1, "pattern": 19, "sigma": [0, 5, 1, 4, 3, 2],
     "voltage": [-1, 1, 1, -1, -1, 1], "removed": [(0, 3)],
     "source": (1, 4), "which": 1, "direction": 1, "M": 4, "R": 6, "jump": 1},
    {"removed_count": 2, "pattern": 106, "sigma": [3, 5, 0, 2, 4, 1],
     "voltage": [-1, 1, -1, -1, -1, 0], "removed": [(0, 0), (0, 1)],
     "source": (0, 5), "which": 1, "direction": -1, "M": 4, "R": 6, "jump": 2},
    {"removed_count": 3, "pattern": 135, "sigma": [4, 1, 5, 2, 0, 3],
     "voltage": [-1, -1, 1, 1, -1, 1], "removed": [(0, 2), (0, 3), (0, 4)],
     "source": (0, 1), "which": 0, "direction": 1, "M": 5, "R": 7, "jump": 2},
    {"removed_count": 4, "pattern": 135, "sigma": [4, 1, 5, 2, 0, 3],
     "voltage": [-1, -1, 1, 1, -1, 1], "removed": [(-1, 4), (0, 2), (0, 3), (0, 4)],
     "source": (0, 1), "which": 0, "direction": 1, "M": 5, "R": 7, "jump": 2},
    {"removed_count": 5, "pattern": 106, "sigma": [3, 5, 0, 2, 4, 1],
     "voltage": [-1, 1, -1, -1, -1, 0], "removed": [(0, 0), (0, 1), (1, 0), (1, 1), (1, 5)],
     "source": (0, 5), "which": 1, "direction": -1, "M": 5, "R": 7, "jump": 2,
     "broad_transfer": True},
]


class Patch:
    def __init__(self, spec, shift=0, circumference=None):
        self.spec = spec
        self.shift = shift
        self.circumference = circumference
        self.removed = {self.normalize((i + shift, j)) for i, j in spec["removed"]}
        self.low_source = self.normalize((spec["source"][0] + shift, spec["source"][1]))
        assert self.low_source not in self.removed
        self.low_target = self.smoothed(self.low_source, spec["which"])
        assert self.low_source != self.low_target

    def normalize(self, vertex):
        i, j = vertex
        return (i % self.circumference, j) if self.circumference else vertex

    def raw(self, vertex, which):
        i, j = vertex
        if which == 0:
            result = (i, j + 1) if j < 5 else (i + 1, 0)
        else:
            result = (i + self.spec["voltage"][j], self.spec["sigma"][j])
        return self.normalize(result)

    def smoothed(self, vertex, which):
        nxt = self.raw(vertex, which)
        for _ in range(20):
            if nxt not in self.removed:
                return nxt
            nxt = self.raw(nxt, which)
        raise AssertionError("Unexpected entirely removed permutation cycle")

    def outgoing(self, vertex):
        assert vertex not in self.removed
        out = [self.smoothed(vertex, which) for which in (0, 1)]
        assert len(set(out)) == 2 and vertex not in out
        if vertex == self.low_source:
            out.remove(self.low_target)
        return out


def arena(spec, shift):
    patch = Patch(spec, 1000 if shift is None else shift)
    M, R = spec["M"], spec["R"]
    messenger = [(i, j) for i in range(-M, M + 1) for j in range(6) if (i, j) not in patch.removed]
    cops = [(i, j) for i in range(-R, R + 1) for j in range(6) if (i, j) not in patch.removed] + [None]
    mi = {v: i for i, v in enumerate(messenger)}
    ci = {v: i for i, v in enumerate(cops)}
    omega = ci[None]
    mm = [[mi[v] for v in [p, *patch.outgoing(p)] if v in mi] for p in messenger]
    cm = []
    for p in cops:
        if p is None:
            cm.append([omega] + [i for i, v in enumerate(cops) if v is not None and abs(v[0]) >= R-spec["jump"]+1])
        else:
            cm.append(sorted({ci.get(v, omega) for v in [p, *patch.outgoing(p)]}))
    return {"messenger": messenger, "cops": cops, "messenger_moves": mm, "cop_moves": cm}, patch


def game(a, patch, target):
    nr, nc = len(a["messenger"]), len(a["cops"])
    count = 2 * nr * nc
    successors = [[] for _ in range(count)]
    success = [False] * count
    collision = [False] * count
    goal_columns = {0, -1} if patch.spec.get("broad_transfer") else {0}
    for r, p in enumerate(a["messenger"]):
        for c, cop in enumerate(a["cops"]):
            for turn in (0, 1):
                state = 2 * (r * nc + c) + turn
                if target is None:
                    success[state] = turn == 0 and p[0] in goal_columns and p != patch.low_source and p != cop
                else:
                    success[state] = p == (0, target)
                collision[state] = p == cop and not success[state]
                if success[state] or collision[state]:
                    continue
                if turn == 0:
                    successors[state] = [2 * (u * nc + c) + 1 for u in a["messenger_moves"][r]]
                else:
                    successors[state] = [2 * (r * nc + u) for u in a["cop_moves"][c]]
    return successors, success, collision


def certificates(spec, shift):
    a, patch = arena(spec, shift)
    nc = len(a["cops"])
    targets = [None, *[j for j in range(6) if (0, j) not in patch.removed and (0, j) != patch.low_target]]
    records = []
    for target in targets:
        successors, success, collision = game(a, patch, target)
        rank, move = independent.attractor(successors, success)
        independent.check_certificate(successors, success, collision, rank, move)
        distances = [1] if target is None else ([2, 3] if spec.get("broad_transfer") else [2])
        columns = {-spec["direction"] * d for d in distances}
        starts = [2 * (r * nc + c) for r, p in enumerate(a["messenger"])
                  if p[0] in columns and p != patch.low_source
                  for c, cop in enumerate(a["cops"]) if p != cop]
        failures = [s for s in starts if rank[s] < 0]
        records.append({"removed_count": spec["removed_count"], "patch_shift": shift,
                        "target_type": target, "low_source": patch.low_source, "low_target": patch.low_target,
                        "source_columns": sorted(columns), "required_starts": len(starts),
                        "failed_starts": failures,
                        "messenger_moves_bound": None if failures else (max(rank[s] for s in starts) + 1)//2,
                        "ranks": rank, "chosen_messenger_successors": move})
    return records


def structural_checks(spec):
    patch = Patch(spec)
    changed_tails = []
    max_jump = 0
    for i in range(-20, 21):
        for j in range(6):
            v = (i, j)
            if v in patch.removed:
                continue
            out = patch.outgoing(v)
            if out != [patch.raw(v, which) for which in (0, 1)]:
                changed_tails.append(v)
            max_jump = max(max_jump, *(abs(u[0]-i) for u in out))
    assert max_jump <= spec["jump"]
    assert all(abs(v[0]) <= 2 for v in changed_tails)
    rings = []
    for q in (25, 31):
        cyclic = Patch(spec, circumference=q)
        vertices = [(i,j) for i in range(q) for j in range(6) if (i,j) not in cyclic.removed]
        indegree = dict.fromkeys(vertices, 0)
        for v in vertices:
            out = cyclic.outgoing(v)
            assert len(out) == (1 if v == cyclic.low_source else 2)
            for u in out:
                indegree[u] += 1
        assert all(deg == (1 if v == cyclic.low_target else 2) for v,deg in indegree.items())
        assert len(vertices) == 6*q-spec["removed_count"]
        rings.append({"circumference":q,"n":len(vertices),"m":2*len(vertices)-1,"correct_degree_pattern":True})
    return {"removed_count":spec["removed_count"],"maximum_column_jump":max_jump,
            "changed_tail_positions":changed_tails,"low_source":patch.low_source,"low_target":patch.low_target,
            "finite_ring_structure_checks":rings}


def main():
    structure = [structural_checks(spec) for spec in SPECS]
    records = [record for spec in SPECS for shift in [None,*range(-10,11)]
               for record in certificates(spec,shift)]
    failed = [{k:v for k,v in record.items() if k not in ("ranks","chosen_messenger_successors")}
              for record in records if record["failed_starts"]]
    payload = {"verified":not failed,"specifications":SPECS,
               "state_encoding":"Vertices lexicographic with removed vertices omitted; cop Omega last; 2*(r*nc+c)+turn; turn0 messenger.",
               "checker_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "explicit_solver_sha256":hashlib.sha256(Path(independent.__file__).read_bytes()).hexdigest(),
               "structural_checks":structure,"certificates":records}
    path=ROOT/'research/six-type-independent-odd-residues-certificates.json.gz'
    with path.open('wb')as destination:
        with gzip.GzipFile(filename='',fileobj=destination,mode='wb',mtime=0)as stream:
            stream.write((json.dumps(payload,separators=(',',':'))+'\n').encode())
    summary={"verified":not failed,"modules":len(records),
             "required_starts_checked":sum(r['required_starts']for r in records),
             "states_checked":sum(len(r['ranks'])for r in records),
             "by_removed_count":[{"removed_count":spec['removed_count'],
                                   "modules":sum(r['removed_count']==spec['removed_count']for r in records),
                                   "maximum_transfer_moves":max((r['messenger_moves_bound']or 0)for r in records if r['removed_count']==spec['removed_count']and r['target_type']is None),
                                   "maximum_delivery_moves":max((r['messenger_moves_bound']or 0)for r in records if r['removed_count']==spec['removed_count']and r['target_type']is not None)}for spec in SPECS],
             "failed_modules":failed,"structural_checks":structure,
             "certificate_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
             "checker_sha256":payload['checker_sha256'],"explicit_solver_sha256":payload['explicit_solver_sha256']}
    (ROOT/'research/six-type-independent-odd-residues-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items()if k not in('failed_modules','structural_checks')}|{'failed_modules':len(failed)}))
    if failed:print(json.dumps(failed[:2]))


if __name__=='__main__':main()

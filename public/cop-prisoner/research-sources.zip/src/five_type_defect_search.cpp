// Bounded local degree-preserving patch search. Input: n, core_count, core
// vertices, then two successors per vertex. Only core-origin arcs may change.
// Heuristic discovery only; output requires independent game verification.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <random>
#include <vector>
int n;uint64_t out[64],win[64],safe[64],nextw[64];
int score(const std::vector<std::vector<int>>&a){uint64_t all=(uint64_t(1)<<n)-1;
 for(int r=0;r<n;++r)out[r]=(uint64_t(1)<<r)|(uint64_t(1)<<a[r][0])|(uint64_t(1)<<a[r][1]);int result=0;
 for(int t=0;t<n;++t){std::fill(win,win+n,0);win[t]=all;bool changed=true;
  while(changed){for(int v=0;v<n;++v){safe[v]=0;if(v==t)safe[v]=all;else for(int c=0;c<n;++c)if(!(out[c]&~win[v]))safe[v]|=uint64_t(1)<<c;}
   changed=false;for(int r=0;r<n;++r){uint64_t z=r==t?all:(safe[r]|safe[a[r][0]]|safe[a[r][1]])&~(uint64_t(1)<<r);nextw[r]=z;changed|=z!=win[r];}std::copy(nextw,nextw+n,win);}
  for(int r=0;r<n;++r)if((win[r]|(uint64_t(1)<<r))==all)++result;
 }return result;
}
int main(int argc,char**argv){if(argc<2)return 2;std::ifstream f(argv[1]);int count;f>>n>>count;if(n>60)return 2;std::vector<int>core(count);for(int &x:core)f>>x;
 std::vector<std::vector<int>>a(n,std::vector<int>(2));for(auto &row:a)f>>row[0]>>row[1];
 double budget=argc>2?std::atof(argv[2]):8;std::mt19937 rng(512926+n);std::uniform_real_distribution<double>U(0,1);auto start=std::chrono::steady_clock::now();
 auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
 int current=score(a),best=current;auto ba=a;long long evals=1,step=0;
 while(elapsed()<budget && best<n*n){int u=core[rng()%count],v=core[rng()%count],i=rng()%2,j=rng()%2;if(u==v || a[v][j]==u || a[u][i]==v || a[v][j]==a[u][1-i] || a[u][i]==a[v][1-j])continue;
  std::swap(a[u][i],a[v][j]);int candidate=score(a);++evals;++step;double temp=0.3+8.0*(1.0-(step%1000)/1000.0);
  if(candidate>=current || U(rng)<std::exp((candidate-current)/temp))current=candidate;else std::swap(a[u][i],a[v][j]);
  if(current>best){best=current;ba=a;}if(step%4000==0){a=ba;current=best;}
 }
 std::cout<<"{\"n\":"<<n<<",\"all_pair_score\":"<<best<<",\"universal\":"<<(best==n*n?"true":"false")<<",\"evaluations\":"<<evals<<",\"seconds\":"<<elapsed()<<",\"arcs\":[";
 for(int r=0;r<n;++r){if(r)std::cout<<",";std::cout<<"["<<r<<","<<ba[r][0]<<"],["<<r<<","<<ba[r][1]<<"]";}std::cout<<"]}\n";
}

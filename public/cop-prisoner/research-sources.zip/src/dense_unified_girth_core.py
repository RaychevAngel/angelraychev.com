#!/usr/bin/env python3
"""Uniform girth-six cores and exact dense staircase; ordinary-proof checks.

No pursuit-game enumeration is used. All-pair two-move checks provide
independent finite evidence for the separately written structural proof.
"""
from __future__ import annotations

from collections import deque
from itertools import combinations
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
S4 = (0, 1, 4, 6)
S6 = (0, 1, 4, 10, 12, 17)
S7 = (0, 1, 4, 10, 18, 23, 25)


def incidence(order, steps=S4):
    assert order % 2 == 0
    k = order // 2
    differences = [a-b for a in steps for b in steps if a != b]
    assert len({d % k for d in differences}) == len(differences)
    return {tuple(sorted((p, k+(p-s) % k))) for p in range(k) for s in steps}


def adjacency(n, edges):
    a = [set() for _ in range(n)]
    for x, y in edges:
        assert x != y and 0 <= x < n and 0 <= y < n
        a[x].add(y)
        a[y].add(x)
    return a


def distance(a, start, target):
    queue = deque([(start, 0)])
    seen = {start}
    while queue:
        v, d = queue.popleft()
        if v == target:
            return d
        for w in a[v] - seen:
            seen.add(w)
            queue.append((w, d+1))
    return float('inf')


def core(order):
    if order % 2 == 0:
        assert order >= 26
        return incidence(order)
    assert order >= 41
    k = (order-1)//2
    edges = incidence(order-1)
    # P0--L0 and P13--L7 are steps zero and six.
    first, second = (0, k), (13, k+7)
    assert all(distance(adjacency(order-1, edges), a, b) >= 4
               for a in first for b in second)
    edges.remove(first)
    edges.remove(second)
    for v in first + second:
        edges.add((v, order-1))
    return edges


def girth_check(n, edges, degree=None):
    a = adjacency(n, edges)
    if degree is not None:
        assert all(len(row) == degree for row in a)
    # Deleting any edge leaves no alternate path of length at most four.
    for s, t in edges:
        frontier, seen = {s}, {s}
        for _ in range(4):
            nxt = set()
            for v in frontier:
                for u in a[v]:
                    if {u, v} == {s, t}:
                        continue
                    if u not in seen:
                        nxt.add(u)
            frontier = nxt
            seen |= nxt
        assert t not in seen, (n, s, t, 'short cycle')


def euler(n, edges):
    a = adjacency(n, edges)
    arcs = set()
    for s in range(n):
        if not a[s]:
            continue
        stack, circuit = [s], []
        while stack:
            v = stack[-1]
            if a[v]:
                u = min(a[v])
                a[v].remove(u)
                a[u].remove(v)
                stack.append(u)
            else:
                circuit.append(stack.pop())
        arcs.update(zip(circuit, circuit[1:]))
    assert len(arcs) == len(edges)
    assert {tuple(sorted(e)) for e in arcs} == edges
    assert all(sum(u == v for u, _ in arcs) == 2 for v in range(n))
    assert all(sum(u == v for _, u in arcs) == 2 for v in range(n))
    return arcs


def first_step(n):
    k = n-4
    edges = core(k)
    if k % 2 == 0:
        assert k >= 28
        a, b, d, e = 0, 7, 1, 8
    else:
        a, b, d, e = 1, 8, 2, 9
    adj = adjacency(k, edges)
    assert distance(adj, a, b) >= 4 and distance(adj, d, e) >= 4
    assert all(distance(adj, x, y) >= 2 for x in (a, b) for y in (d, e))
    missing = euler(k, edges)
    c, x, y, z = range(k, n)
    missing.update(((c, x), (x, y), (x, z), (y, a), (y, b), (z, d), (z, e)))
    return missing


def functional(r):
    assert r >= 2
    j = (r-2)//2
    missing = {(0, 1), (1, 0)}
    for i in range(j):
        missing.update(((2+2*i, 3+2*i), (3+2*i, 0)))
    if r % 2:
        missing.add((r-1, 0))
    return missing


def staircase(n, r):
    assert 1 <= r <= n
    if r == 1:
        return first_step(n), 'four attachments'
    k = n-r
    missing = functional(r)
    if k == 0:
        return missing, 'functional endpoint'
    if (k % 2 == 0 and k >= 26) or (k % 2 == 1 and k >= 41):
        missing.update((u+r, v+r) for u, v in euler(k, core(k)))
        return missing, 'functional plus girth core'
    j = (r-2)//2
    assert k <= j*(j-1)//2
    roots = range(2, 2*j+2, 2)
    for v, pair in zip(range(r, n), combinations(roots, 2)):
        missing.update((v, t) for t in pair)
    return missing, 'functional distinct pairs'


def two_move_count(n, missing):
    out, inc = [0]*n, [0]*n
    for s, t in missing:
        assert 0 <= s < n and 0 <= t < n and s != t
        out[s] |= 1 << t
        inc[t] |= 1 << s
    assert sum(x.bit_count() for x in out) == len(missing)
    return sum(all(c == s or out[c] & ~(out[s] | inc[t]) for c in range(n))
               for s, t in missing)


def bridge_envelope(n):
    """Four-regular oriented base plus arbitrary optional missing arcs."""
    if n % 2 == 0:
        assert n >= 70 or n == 62
        steps = S6 if n >= 70 else (0, 1, 3, 8, 12, 18)
        full = incidence(n, steps)
        initial = incidence(n, steps[:4])
    else:
        assert n >= 129
        size = n-27
        full = incidence(26)
        initial = set(full)
        full.update((u+26, v+26) for u, v in incidence(size, S7))
        initial.update((u+26, v+26) for u, v in incidence(size, S7[:4]))
        first, second = (0, 13), (26, 26+size//2)
        for edges in (full, initial):
            edges.remove(first)
            edges.remove(second)
            edges.update((v, n-1) for v in first+second)
    base = euler(n, initial)
    optional = sorted(full-initial)
    assert len(base) == 2*n and len(base)+len(optional) >= 3*n
    return base, optional


def main():
    rows = []
    orders = [n for n in range(26, 102)
              if n % 2 == 0 or n >= 41]
    for n in orders:
        edges = core(n)
        girth_check(n, edges, degree=4)
        arcs = euler(n, edges)
        assert two_move_count(n, arcs) == 2*n
    first = [n for n in range(32, 80)
             if n % 2 == 0 or n >= 45]
    for n in first:
        missing = first_step(n)
        girth_check(n, {tuple(sorted(a)) for a in missing})
        assert two_move_count(n, missing) == 2*n-3
    for n in list(range(61, 76)) + [80, 100, 166]:
        for r in range(1, n+1):
            missing, method = staircase(n, r)
            expected = 2*n-r-(r+1)//2-1
            assert len(missing) == 2*n-r
            assert two_move_count(n, missing) == expected, (n, r, method)
            rows.append({'n': n, 'r': r, 'I': expected, 'method': method})
    bridges = []
    for n in (62, 70, 72, 128, 129, 131, 166):
        base, optional = bridge_envelope(n)
        girth_check(n, {tuple(sorted(a)) for a in base} | set(optional))
        for h in range(2*n, 3*n+1):
            missing = base | set(optional[:h-2*n])
            assert len(missing) == h and two_move_count(n, missing) == h
            bridges.append({'n':n, 'h':h})
    receipt = {
        'status': 'verified',
        'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'proof_boundary': 'Finite structural and complete two-move checks; general proof is ordinary, not inferred from these tests.',
        'core_orders': orders,
        'first_step_orders': first,
        'dense_staircase_instances': rows,
        'dense_staircase_count': len(rows),
        'dense_bridge_instances': bridges,
        'dense_bridge_count': len(bridges),
    }
    path = ROOT / 'research/dense-unified-girth-core-checks.json'
    path.write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'status':'verified', 'cores':len(orders), 'first_steps':len(first),
                      'dense_staircase_count':len(rows), 'receipt':str(path)}))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Export complete seven-arrow profile trees as kernel-checked Lean literals."""
from pathlib import Path
import argparse, json, itertools
from irregular_ten_export import certificate, route, natlist
ROOT=Path(__file__).resolve().parents[1]

def render(node_map,p):
    node=node_map[','.join(map(str,p))]
    if node['kind']=='bound':return '.bound '+certificate(node['certificate'])
    children=' '.join('| '+str(rep)+' => '+render(node_map,p+[rep])for rep in node['representatives'])
    return '.branch '+natlist(node['representatives'])+' '+route(node)+' (fun mask => match mask with '+children+' | _ => .invalid)'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=ROOT/'research/lean-small-budget-seven-trees.json')
    ap.add_argument('--out',type=Path,default=ROOT/'lean');ap.add_argument('--orders',default='4,5,6,7');args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    data=json.loads(args.input.read_text());assert data['arrows']==7 and data['bound']==2
    for n in map(int,args.orders.split(',')):
        cases=[c for c in data['cases']if c['n']==n]
        prefix=f'SmallBudgetSevenOrder{n}'
        s=f'''import SmallRowPrefixBoolean
import SmallDegreeProfiles

/-! Complete row-prefix coverage for every sorted joint-degree profile on
{n} vertices with seven arrows and total degree at least two at each vertex. -/
namespace Delivery.{prefix}
open FiniteGame Extremal RowPrefix SmallDegreeProfiles
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def rows '''+' '.join(chr(97+i)for i in range(n))+f''' : Rows {n} := fun v =>
  match v.val with '''+' '.join(f'| {i} => {chr(97+i)}'for i in range(n-1))+f' | _ => {chr(96+n)}\n\n'
        choices={d:[sum(1<<t for t in ts)for ts in itertools.combinations(range(n),d)]for d in range(n+1)}
        s+='def choices (d : Nat) : List Nat :=\n  match d with\n'
        for d,ms in choices.items():s+=f'  | {d} => '+natlist(ms)+'\n'
        s+='  | _ => []\n\n'
        s+=f'theorem cover (d : Fin {n+1}) : RowCover {n} d.val (choices d.val) := by\n  revert d\n  decide +kernel\n\n'
        for i,c in enumerate(cases):
            labels=natlist(c['labels']);ds=f'(D (n:={n}) '+labels+')';rs=f'(R (n:={n}) '+labels+')'
            declarations=[];counter=[0]
            def proof(p):
                node=c['nodes'][','.join(map(str,p))];idx=counter[0];counter[0]+=1
                name=f'profile{i}_node{idx}';pl=natlist(p)
                if node['kind']=='bound':
                    cn=name+'_cert'
                    declarations.append(f'def {cn} : Bound {n} := '+certificate(node['certificate'])+'\n')
                    declarations.append(f'theorem {name} : Upper {ds} {rs} {pl} 2 :=\n  bound_sound {ds} {rs} {pl} 2 {cn}\n    ((SmallBoolean.boundCheck_true {ds} {rs} {pl} 2 {cn}).mp (by decide +kernel))\n')
                else:
                    reps=node['representatives'];children={v:proof(p+[v])for v in reps}
                    rn=name+'_route';d=c['labels'][len(p)]//8
                    declarations.append(f'def {rn} : Route {n} := '+route(node)+'\n')
                    src=f'theorem {name} : Upper {ds} {rs} {pl} 2 := by\n'
                    src+=f'  apply routed_branch {ds} {rs} {pl} 2 (by decide) (choices {d}) {natlist(reps)} {rn}\n'
                    src+=f'    (by change RowCover {n} {d} (choices {d}); exact cover ⟨{d},by decide⟩)\n'
                    src+=f'    ((SmallBoolean.routesCheck_true {ds} {rs} {pl} (choices {d}) {natlist(reps)} {rn}).mp (by decide +kernel))\n'
                    src+='  intro mask member\n'
                    if reps:
                        src+='  simp only [List.mem_cons,List.not_mem_nil,or_false] at member\n  rcases member with '+' | '.join('rfl'for _ in reps)+'\n'
                        src+=''.join('  · exact '+children[v]+'\n'for v in reps)
                    else:src+='  simp at member\n'
                    declarations.append(src)
                return name
            rootname=proof([])
            s+='\n'.join(declarations)+f'\ntheorem profile{i} : Upper {ds} {rs} [] 2 := {rootname}\n\n'
        s+='def catalogue : List (List Nat) := ['+','.join(natlist(c['labels'])for c in cases)+']\n\n'
        s+=f'theorem catalogue_eq : profiles {n} {n} 0 7 7=catalogue := by decide +kernel\n\n'
        s+=f'''theorem profile_upper (xs : List Nat) (member : xs∈profiles {n} {n} 0 7 7) :
    Upper (n:={n}) (D xs) (R xs) [] 2 := by
  rw [catalogue_eq] at member
  simp only [catalogue,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with '''+' | '.join('rfl'for c in cases)+'\n'
        for i,c in enumerate(cases):
            s+=f'  · exact profile{i}\n'
        s+=f'''theorem upper (E : Graph (Fin {n})) (loops : Loopless E) (budget : arcCount E=7)
    (degree : ∀x,2≤SparseSupport.outdegree E x+SparseSupport.indegree E x) : score E≤2 := by
  have od (x) : SparseSupport.outdegree E x<{n} := by
    have h := SparseDeletion.row_nonadjacent_bound E loops x
    omega
  have idg (x) : SparseSupport.indegree E x<{n} := by
    have h := SparseDeletion.column_nonadjacent_bound E loops x
    omega
  have td : ((List.finRange {n}).map (SparseSupport.outdegree E)).sum=7 := by
    have h := SparseSupport.arc_rows E
    exact h.symm.trans budget
  have te : ((List.finRange {n}).map (SparseSupport.indegree E)).sum=7 := by
    have h := SparseSupport.arc_columns E
    exact h.symm.trans budget
  have member := sorted_member (SparseSupport.outdegree E) (SparseSupport.indegree E)
    (by decide) od idg degree td te
  obtain ⟨F,⟨iso⟩,prescribed⟩ := relabel E loops (fun x => by have := idg x; omega)
  have bound := profile_upper _ member F prescribed (by intro s h; simp at h)
  rw [GraphRelabeling.score_eq iso] at bound
  exact bound

#print axioms upper
end Delivery.{prefix}
'''
        # rows arguments require explicit Nat types.
        s=s.replace('def rows '+' '.join(chr(97+i)for i in range(n))+' :', 'def rows ('+' '.join(chr(97+i)for i in range(n))+' : Nat) :')
        (args.out/f'{prefix}.lean').write_text(s)
        print(prefix,len(cases),len(s))
if __name__=='__main__':main()

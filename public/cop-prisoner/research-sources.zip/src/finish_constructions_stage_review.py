#!/usr/bin/env python3
"""Independent literal replay for selected-pair mixed-game stage certificates.

Imports neither the stage producer nor any game solver.
"""
import argparse
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def review(g):
    n=g['n']; B=set(map(tuple,g['base_arcs'])); E=set(map(tuple,g['envelope_arcs']))
    assert B<=E and len(B)==g['m_min'] and len(E)==g['m_max']
    assert all(0<=u<n and 0<=v<n and u!=v for u,v in E)
    rm=[{u}|{v for s,v in B if s==u} for u in range(n)]
    cm=[{u}|{v for s,v in E if s==u} for u in range(n)]
    pairs=set(); obligations=0
    assert len(g['certificates'])==n
    for t,cert in enumerate(g['certificates']):
        assert cert['target']==t
        ranks=cert['rank']; policy=cert['messenger_successor']
        assert len(ranks)==len(policy)==2*n*n
        for s in range(n):
            for c in range(n):
                for turn in (0,1):
                    p=2*(s*n+c)+turn; rank=ranks[p]; obligations+=1
                    assert isinstance(rank,int) and rank>=-1
                    if s==t: assert rank==0; continue
                    if s==c: assert rank==-1; continue
                    children=({2*(v*n+c)+1 for v in rm[s]} if turn==0
                              else {2*(s*n+v) for v in cm[c]})
                    if rank>=0:
                        if turn==0:
                            assert policy[p] in children
                            assert 0<=ranks[policy[p]]<rank
                        else: assert all(0<=ranks[q]<rank for q in children)
                    elif turn==0: assert all(ranks[q]==-1 for q in children)
                    else: assert any(ranks[q]==-1 for q in children)
            if s!=t and (s,t) not in B and all(ranks[2*(s*n+c)]>=0 for c in range(n) if c!=s):
                pairs.add((s,t))
    assert pairs==set(map(tuple,g['protected_pairs']))
    F=E-B; recipe=list(map(tuple,g['recipe_arrows']))
    assert len(recipe)==len(F) and set(recipe)==F
    assert recipe==sorted(F-pairs)+sorted(F&pairs)
    safe=len(F-pairs)
    curve=[dict(m=len(B)+k,I_lower=len(pairs)-max(0,k-safe)) for k in range(len(F)+1)]
    assert curve==g['lower_curve']
    return dict(n=n,m_min=len(B),m_max=len(E),protected_pairs=len(pairs),
                lower_curve=curve,alternating_state_obligations=obligations)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('--out',required=True);args=p.parse_args()
    path=ROOT/args.input; data=json.loads(path.read_text())
    report=dict(status='passed',source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                reviewer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                records=[review(g) for g in data],
                scope='Every optional subset retains the protected guarantees; the specified budget recipe minimizes conversion of protected pairs into direct arrows. No global upper bound.')
    (ROOT/args.out).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['records']))

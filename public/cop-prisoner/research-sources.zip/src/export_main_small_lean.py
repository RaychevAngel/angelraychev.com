"""Minimal saved-stage cover of orders 13..18, with proved symbolic families.

The interval selection is only a producer convenience. Every selected stage
is checked by Lean, and the final branch cover is proved again by omega.
"""
import argparse
import hashlib
import json
from math import comb
from pathlib import Path
import struct
import zipfile

ROOT = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--out",type=Path,required=True,help="Explicit output directory for reproducible Lean sources")
parser.add_argument("--manifest",type=Path)
args=parser.parse_args()
OUT=args.out.resolve()
OUT.mkdir(parents=True,exist_ok=True)
PINS = {
    "research/sparse-staged-records.json": "2dd3998101a1f5fbc2aeb3e05f0aecfd06545901bff9623ac7c6307286199f06",
    "research/sparse-staged-certificates.zip": "e37ebadb62816223fbba35109886d02dd994e3d09f8fd83104ac3f7925d9d411",
}
for path, expected in PINS.items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected
records = json.loads((ROOT / "research/sparse-staged-records.json").read_text())["records"]


def tree(values, low=0):
    if len(values) == 1:
        value = values[0]
        return "[" + ",".join(map(str, value)) + "]" if isinstance(value, list) else str(value)
    mid = len(values) // 2
    return f"(if x < {low+mid} then {tree(values[:mid],low)} else {tree(values[mid:],low+mid)})"


def candidates(n):
    result = []
    for rid, record in enumerate(records):
        if record["n"] == n:
            for sid, stage in enumerate(record["stages"]):
                result.append((stage["m_min"], stage["m_max"], "stage", (rid, sid)))
    result.append((22*n-156, n*(n-3), "pair", None))
    if n in (13, 14):
        result.append((126 if n == 13 else 147, n*(n-3), "tiny", None))
    if n >= 16:
        result.append((n*(n-4), n*(n-3), "dense", None))
        result.append((5*n, 112 if n == 16 else 6*n, "circle", None))
    for g in range(2, 9):
        b = n-12-g
        for r in range(2, g+1):
            if 0 <= b <= comb(g, r):
                a = 106+22*g+(19+r)*b
                result.append((a, a+b*(g+b-1), "hub", (g,b,r)))
    return result


def cover(n):
    options = candidates(n)
    end = n*(n-3)
    best = {end+1: (0, [])}
    for at in range(end, 2*n-1, -1):
        choices = []
        for item in options:
            lo, hi, kind, _ = item
            if lo <= at <= hi:
                cost, tail = best[min(hi+1,end+1)]
                choices.append((cost+(kind == "stage"), [item]+tail))
        assert choices, (n, at)
        best[at] = min(choices, key=lambda x: (x[0],len(x[1])))
    return best[2*n][1]


manifest = []
with zipfile.ZipFile(ROOT / "research/sparse-staged-certificates.zip") as bundle:
    for n in range(13, 19):
        selected = cover(n)
        branches = []
        imports = ["MainSmallFamilies"]
        for lo,hi,kind,params in selected:
            if kind != "stage":
                branches.append((lo,hi,kind,params,None))
                continue
            rid,sid = params
            record,stage = records[rid],records[rid]["stages"][sid]
            raw = bundle.read(stage["member"])
            assert hashlib.sha256(raw).hexdigest() == stage["sha256"]
            values = struct.unpack("<"+"h"*(len(raw)//2),raw)
            assert len(values) == 2*n**3
            ranks = [max(0,v) for v in values[:n**3]]
            moves = [max(0,v) for v in values[n**3:]]
            assert max(moves) < n
            width = max(1,max(ranks).bit_length())
            mw = (n-1).bit_length()
            def pack(xs,w):
                return [sum(v << (w*c) for c,v in enumerate(xs[r:r+n])) for r in range(0,len(xs),n)]
            base = record["base_arcs"]+record["added"][:stage["prefix_start"]]
            upper = record["base_arcs"]+record["added"][:stage["prefix_end"]]
            assert len(base) == len(set(map(tuple,base))) == lo
            assert len(upper) == len(set(map(tuple,upper))) == hi
            lower_rows = [sum(1<<t for s,t in base if s==r) for r in range(n)]
            upper_rows = [sum(1<<t for s,t in upper if s==r) for r in range(n)]
            replies = [[d for d in range(n) if d==c or upper_rows[c]&(1<<d)] for c in range(n)]
            index = sum(x["n"]==n for x in manifest)
            name = f"MainSmall{n}Stage{index:02}"
            text = f'''import MainStageRows
/- Frozen literal {stage['member']}; SHA256 {stage['sha256']}.
The kernel checks all game rows, adjacency counts, loops, inclusion, and replies.
Negative input values are padded by zero; no claim about those values is trusted. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open FiniteGame Extremal MainStageRows
def lowerRows (x : Nat) : Nat := {tree(lower_rows)}
def upperRows (x : Nat) : Nat := {tree(upper_rows)}
def lower (s t : Fin {n}) : Prop := (lowerRows s.val).testBit t.val=true
def upper (s t : Fin {n}) : Prop := (upperRows s.val).testBit t.val=true
instance (s t : Fin {n}) : Decidable (lower s t) := inferInstanceAs (Decidable (_=true))
instance (s t : Fin {n}) : Decidable (upper s t) := inferInstanceAs (Decidable (_=true))
instance (s t : Fin {n}) : Decidable (Legal upper s t) := inferInstanceAs (Decidable (_ ∨ _))
def rankRows (x : Nat) : Nat := {tree(pack(ranks,width))}
def moveRows (x : Nat) : Nat := {tree(pack(moves,mw))}
def data : Data {n} where
  rank t r c := (rankRows ({n}*t.val+r.val) >>> ({width}*c.val)) &&& {2**width-1}
  move t r c := ⟨((moveRows ({n}*t.val+r.val) >>> ({mw}*c.val)) &&& {2**mw-1})%{n},Nat.mod_lt _ (by decide)⟩
def replyRows (x : Nat) : List (Fin {n}) := {tree(replies)}
def replies (c : Fin {n}) : List (Fin {n}) := replyRows c.val
theorem inclusion : RobustTwoMove.Subgraph lower upper := by unfold RobustTwoMove.Subgraph; decide +kernel
theorem loopless : Loopless upper := by unfold Loopless; decide +kernel
theorem reply_coverage : ∀ c d, Legal upper c d → d∈replies c := by decide +kernel
theorem checked : ∀ t r c, RowGood lower data replies t r c := by decide +kernel
theorem counts : arcCount lower={lo} ∧ arcCount upper={hi} := by
  constructor <;> rw [arcCount_eq] <;> decide +kernel
theorem maximum {{m : Nat}} (low : {lo}≤m) (high : m≤{hi}) : IsMaximum {n} m ({n*(n-1)}-m) :=
  MainStageRows.maximum lower upper data replies inclusion loopless reply_coverage checked
    (counts.1 ▸ low) (counts.2 ▸ high)
#print axioms maximum
end Delivery.{name}
'''
            path = OUT / f"{name}.lean"
            path.write_text(text)
            manifest.append(dict(n=n,module=name,member=stage["member"],member_sha256=stage["sha256"],
                source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),low=lo,high=hi,rows=n**3))
            imports.append(name)
            branches.append((lo,hi,kind,params,name))
        name = f"MainSmall{n}"
        text = "\n".join(f"import {m}" for m in imports)+("\nset_option maxRecDepth 100000" if n>=16 else "")+f'''
namespace Delivery.{name}
open Extremal
theorem maximum {{m : Nat}} (low : {2*n}≤m) (high : m≤{n*(n-3)}) :
    IsMaximum {n} m ({n*(n-1)}-m) := by
'''
        for idx,(lo,hi,kind,params,module) in enumerate(branches):
            text += f"  by_cases h{idx:02} : m≤{hi}\n  · "
            if kind == "stage":
                text += f"exact {module}.maximum (by omega) h{idx:02}\n"
            elif kind == "hub":
                g,b,r = params
                text += f"exact TwelveHubCodes.maximum (g:={g}) (b:={b}) (r:={r}) (by decide) (by decide) (by decide) (by decide) (by omega) (by omega)\n"
            elif kind == "pair":
                text += f"exact PairCodeConstruction.maximum (k:=6) (by decide) (by decide) (by decide) (by omega) (by omega)\n"
            elif kind == "tiny":
                text += f"exact MainTiny{n}.maximum (by omega) h{idx:02}\n"
            elif kind == "circle":
                text += f"exact MainSmallFamilies.circle{n} (by omega) h{idx:02}\n"
            elif kind == "dense":
                text += f"exact SmallDenseEnvelopeMaxima.maximum ⟨{n-16},by decide⟩ m (by change {n*(n-4)}≤m; omega) (by change m≤{n*(n-3)}; omega)\n"
        text += f"  omega\n#print axioms maximum\nend Delivery.{name}\n"
        (OUT / f"{name}.lean").write_text(text)
        print(n, len(imports)-1, "stages",len(branches),"branches")

manifest_path=args.manifest or OUT/"source-manifest.json"
manifest_path.parent.mkdir(parents=True,exist_ok=True)
manifest_path.write_text(json.dumps(dict(inputs=PINS,stages=manifest,exporter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.glob("*.lean"))}),indent=2)+"\n")
print("Total",len(manifest),"stages",sum(x["rows"] for x in manifest),"rows")

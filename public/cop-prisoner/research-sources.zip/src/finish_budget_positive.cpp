// Positive-degree budget completion. Input contains an independently generated
// complete list of joint degree patterns. Source adapted from the reviewed
// coupled-degree prefix enumerator; loss unions preserve initial-source exceptions.
// ADAPTATION: positive residual n11,m21 profiles above56; retain camping losses as a union.
// Complete direct degree-sequence enumeration of residual positive n10/m20
// families above53. No perfect matching is assumed. Future vertices with
// equal degree pair and identical incoming prefix can be permuted freely;
// each outgoing subset therefore chooses a prefix within each such class.
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <map>
#include <set>
#include <tuple>
#include <vector>
using namespace std;
int n,all,budget,mode;
int D[20],E[20],O[20],P[20],used[20],Amask,Bmask,baseeligible,threshold=56;
bool complete=true,found=false;double limit=60;
long long nodes=0,patterns=0,leaves=0,camping_rejects=0,guarded_checks=0,guarded_rejects=0,early_game_rejects=0;
int best=-1,BO[20];
auto started=chrono::steady_clock::now();
double elapsed(){return chrono::duration<double>(chrono::steady_clock::now()-started).count();}
int eligible_upper(){int w=0;for(int s=0;s<n;s++)if(!(Amask>>s&1))w+=__builtin_popcount(unsigned(O[s]&~Bmask));return baseeligible-w;}

bool camping(int row){
 int bad[20]={};
 for(int source=0;source<=row;source++)if(D[source]>=2)
  for(int cop=0;cop<=row;cop++)if(cop!=source&&!(O[source]&~(O[cop]|1<<cop)))bad[source]=all;
 for(int target=0;target<n;target++)if(E[target]>=2&&used[target]==E[target])
  for(int cop=0;cop<=row;cop++)if(!(P[target]&~(O[cop]|1<<cop)))
   for(int source=0;source<n;source++)if(source!=cop)bad[source]|=1<<target;
 int losses=0;
 for(int source=0;source<n;source++)if(Amask>>source&1)
  losses+=__builtin_popcount(unsigned(bad[source]&Bmask&~(O[source]|1<<source)));
 return eligible_upper()-losses>threshold;
}

bool capacities(int row){
 int available=0;
 for(int t=0;t<n;t++){
  int cap=E[t]-used[t];
  if(cap>n-row-(t>=row))return false;
  if(cap>0)available|=1<<t;
 }
 for(int s=row;s<n;s++)if(D[s]>__builtin_popcount(unsigned(available&~(1<<s))))return false;
 return true;
}
bool guarded(int row){
 ++guarded_checks;int optimistic[20],bad[20]={};
 for(int s=0;s<n;s++){
  optimistic[s]=O[s];
  if(s>=row)for(int t=0;t<n;t++)if(used[t]<E[t]&&t!=s&&!(mode==1&&E[s]==0&&D[t]==0))optimistic[s]|=1<<t;
 }
 for(int c=0;c<n;c++){
  int allowed=all&~(O[c]|1<<c),reach[20]={};
  for(int u=0;u<n;u++)if(allowed>>u&1)reach[u]=(optimistic[u]|1<<u)&allowed;
  for(int k=0;k<n;k++)if(allowed>>k&1)for(int u=0;u<n;u++)if(reach[u]>>k&1)reach[u]|=reach[k];
  for(int s=0;s<n;s++)if(s!=c&&(Amask>>s&1)){
   int internal=0,first=optimistic[s]&allowed;
   while(first){int u=__builtin_ctz(first);first&=first-1;internal|=reach[u];}
   int possible=optimistic[s];
   while(internal){int u=__builtin_ctz(internal);internal&=internal-1;possible|=optimistic[u];}
   bad[s]|=Bmask&~(possible|1<<s);
  }
  int losses=0;for(int s=0;s<n;s++)losses+=__builtin_popcount(unsigned(bad[s]));
  if(eligible_upper()-losses<=threshold)return false;
 }
 return true;
}
int game(){
 int I=0,W[20],safe[20],NW[20],remaining=eligible_upper();
 for(int t=0;t<n;t++)if(Bmask>>t&1){
  int potential=0;for(int s=0;s<n;s++)if((Amask>>s&1)&&s!=t&&!(O[s]>>t&1))++potential;
  fill(W,W+n,0);W[t]=all;
  while(true){
   for(int v=0;v<n;v++){safe[v]=0;for(int c=0;c<n;c++)if(!((O[c]|1<<c)&~W[v]))safe[v]|=1<<c;}
   bool diff=false;
   for(int s=0;s<n;s++){int w=0,moves=O[s]|1<<s;while(moves){int v=__builtin_ctz(moves);moves&=moves-1;w|=safe[v];}if(s!=t)w&=~(1<<s);NW[s]=w;diff|=w!=W[s];}
   copy(NW,NW+n,W);if(!diff)break;
  }
  for(int s=0;s<n;s++)if((Amask>>s&1)&&s!=t&&!(O[s]>>t&1)&&(W[s]|1<<s)==all)++I;
  remaining-=potential;if(I+remaining<=threshold){++early_game_rejects;return -1;}
 }
 return I;
}
void dfs(int row);
void choose(int row,const vector<vector<int>>&classes,int k,int remaining,int mask){
 if(!complete||found)return;
 if(!remaining){
  O[row]=mask;for(int t=0;t<n;t++)if(mask>>t&1){++used[t];P[t]|=1<<row;}
  if(camping(row))dfs(row+1);else ++camping_rejects;
  for(int t=0;t<n;t++)if(mask>>t&1){--used[t];P[t]&=~(1<<row);}O[row]=0;
  return;
 }
 if(k==(int)classes.size())return;
 int capacity=0;for(int j=k;j<(int)classes.size();j++)capacity+=classes[j].size();
 if(remaining>capacity)return;
 int partial=0;
 for(int count=0;count<=min(remaining,(int)classes[k].size());count++){
  if(count)partial|=1<<classes[k][count-1];
  choose(row,classes,k+1,remaining-count,mask|partial);
 }
}
void dfs(int row){
 if(!complete||found)return;
 if((++nodes&16383)==0&&elapsed()>limit){complete=false;return;}
 if(!capacities(row))return;
 if(row>=n-4&&!guarded(row)){++guarded_rejects;return;}
 if(row==n){++leaves;int value=game();if(value>best){best=value;copy(O,O+n,BO);if(value>threshold)found=true;}return;}
 vector<vector<int>>classes;
 for(int t=0;t<row;t++)if(used[t]<E[t]&&!(mode==1&&E[row]==0&&D[t]==0))classes.push_back({t});
 map<tuple<int,int,int>,vector<int>>future;
 for(int t=row+1;t<n;t++)if(used[t]<E[t]&&!(mode==1&&E[row]==0&&D[t]==0))future[{D[t],E[t],P[t]}].push_back(t);
 for(auto const&entry:future)classes.push_back(entry.second);
 choose(row,classes,0,D[row],0);
}


int main(int argc,char**argv){
 if(argc!=6)return 2;
 n=atoi(argv[1]);budget=atoi(argv[2]);threshold=atoi(argv[3]);limit=atof(argv[4]);mode=atoi(argv[5]);
 if(n<3||n>18||budget<1||threshold<0||limit<=0||limit>180||mode<0||mode>1)return 2;
 if(mode==1&&!((budget==14&&threshold>=13)||(budget==15&&threshold>=15)||(budget==16&&threshold>=19)))return 2;
 all=(1<<n)-1;int totalpatterns;if(!(cin>>totalpatterns)||totalpatterns<0)return 2;
 for(int k=0;k<totalpatterns;k++){
  int sumD=0,sumE=0,lowout=0,lowin=0;Amask=Bmask=0;
  for(int s=0;s<n;s++){
   if(!(cin>>D[s]>>E[s]))return 2;
   if(D[s]<0||E[s]<0||D[s]>=n||E[s]>=n||D[s]+E[s]<2)return 2;
   if(mode==0&&(D[s]==0||E[s]==0))return 2;
   if(mode==1&&((D[s]==0&&E[s]!=2)||(E[s]==0&&D[s]!=2)))return 2;
   sumD+=D[s];sumE+=E[s];
   if(D[s]>=2)Amask|=1<<s;else lowout+=D[s];
   if(E[s]>=2)Bmask|=1<<s;else lowin+=E[s];
  }
  if(sumD!=budget||sumE!=budget)return 2;
  if(!complete||found)continue;
  ++patterns;int q=__builtin_popcount(unsigned(Amask)),r=__builtin_popcount(unsigned(Bmask)),b=__builtin_popcount(unsigned(Amask&Bmask));
  baseeligible=q*r-b-(budget-lowout-lowin);
  fill(O,O+n,0);fill(P,P+n,0);fill(used,used+n,0);dfs(0);
 }
 cout<<"{\"n\":"<<n<<",\"m\":"<<budget<<",\"mode\":"<<mode<<",\"family\":\"specified complete degree family\",\"complete\":"<<(complete&&!found?"true":"false")
 <<",\"counterexample_found\":"<<(found?"true":"false")<<",\"threshold\":"<<threshold<<",\"degree_patterns\":"<<patterns<<",\"total_degree_patterns\":"<<totalpatterns<<",\"nodes\":"<<nodes
 <<",\"game_decisions\":"<<leaves<<",\"camping_rejects\":"<<camping_rejects<<",\"guarded_checks\":"<<guarded_checks
 <<",\"guarded_rejects\":"<<guarded_rejects<<",\"early_game_rejects\":"<<early_game_rejects<<",\"maximum_threshold_survivor\":"<<best
 <<",\"upper_if_complete\":"<<max(threshold,best)<<",\"seconds\":"<<elapsed()<<",\"arcs\":[";
 bool first=true;if(best>=0)for(int s=0;s<n;s++)for(int t=0;t<n;t++)if(BO[s]>>t&1){if(!first)cout<<",";first=false;cout<<"["<<s<<","<<t<<"]";}
 cout<<"]}\n";return complete?0:1;
}

#!/usr/bin/env python3
"""Translate all immutable low-band ranks into kernel-checked local objectives.

The saved archive has separate messenger/cop-turn ranks. Only messenger ranks
and policy moves are exported: LocalArenaRows checks every listed cop reply
for safety and strict decrease between successive messenger turns. Thus the
collapse is re-proved by the kernel, not trusted as a preprocessing step.
Removed vertices receive empty regions; terminal delivery and safe handoff
retain their distinct checkers. Every pattern's frozen relations are proved
equal to the symbolic LowBandLocal arena before a certificate is exported.
By default, unused states are removed by policy reachability from every
required initial state; the kernel rechecks the restricted policy and region.
"""
import argparse
from collections import deque
import copy
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'research/dense-phase2-sparse-two-entry-certificates.json.gz'
EXPECTED = 'acd744fd1e432ca6ddba473f68e6dcd5205ec3f6e5681da317b1f4ecca19ba8d'


RULES = ((0,1,-3,5),(0,3,-3,5),(1,1,-3,5),(1,3,-3,5),
         (1,3,3,0),(2,3,-3,5),(2,4,-3,0))
EXTRAS = ((1,-3,5),(3,-3,5),(4,-3,0),(4,3,1),(2,3,0),
          (3,3,0),(3,-3,0),(5,-2,0))


def arrows(v, holes):
    i,j = v
    if j == 0: return ((i,1),(i,5))
    if j == 1: return ((i,2),(i+2,2) if i+1 in holes else (i+1,4))
    if j == 2: return ((i,3),(i+1,1))
    if j == 3: return ((i,5) if i in holes else (i,4),(i-1,0))
    if j == 4: return ((i,5),(i+1,2))
    if j == 5: return ((i+1,0),(i-1,3))
    raise ValueError(v)


def make_arena(holes):
    holes = set(holes)
    vertices = lambda radius: [(i,j) for i in range(-radius,radius+1)
                               for j in range(6) if j != 4 or i not in holes]
    rv,cv = vertices(5),vertices(8)+[None]
    ri,ci = {v:i for i,v in enumerate(rv)},{v:i for i,v in enumerate(cv)}
    outside = len(cv)-1
    rm = [[ri[u] for u in (v,*arrows(v,holes)) if u in ri] for v in rv]
    cm = []
    for v in cv[:-1]:
        i,j = v
        opts = {ci.get(u,outside) for u in (v,*arrows(v,holes))}
        for typ,shift,target in EXTRAS:
            if typ != j or any((i-h,j,shift,target) in RULES for h in holes):
                continue
            opts.add(ci.get((i+shift,target),outside))
        cm.append(sorted(opts))
    cm.append([i for i,v in enumerate(cv) if v is None or abs(v[0]) >= 6])
    return dict(messenger_vertices=rv,pursuer_vertices=cv,
                messenger_moves=rm,pursuer_moves=cm)


def seq(xs):
    return '[' + ','.join(map(str, xs)) + ']'


def lookup_tree(values, low=0):
    """Balanced literal lookup avoids repeated linear kernel array access."""
    if len(values) == 1:
        value = values[0]
        return seq(value) if isinstance(value, list) else str(value)
    middle = len(values)//2
    return (f'(if r < {low+middle} then {lookup_tree(values[:middle],low)} '
            f'else {lookup_tree(values[middle:],low+middle)})')


def pack(rows, width):
    encoded = [sum(v << (width*j) for j, v in enumerate(row)) for row in rows]
    for row, value in zip(rows, encoded):
        assert [((value >> (width*j)) & ((1 << width)-1)) for j in range(len(row))] == row
    return encoded


def header(imports, namespace):
    return f'''{imports}
/- Literal translation of frozen low-band records. Source SHA256:
{EXPECTED}. The ordinary producer is untrusted; all obligations are
checked by Lean's kernel. Removed vertices are padded with empty regions. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{namespace}
open LocalArena LocalArenaRows LowBandLocal
'''


def arena_text(index, p, record):
    a = make_arena(record['holes'])
    rm = [(u+5)*6+t for u, t in a['messenger_vertices']]
    cm = [102 if v is None else (v[0]+8)*6+v[1] for v in a['pursuer_vertices']]
    masks = [0]*66
    replies = [[] for _ in range(103)]
    for old, r in enumerate(rm):
        masks[r] = sum(1 << rm[z] for z in a['messenger_moves'][old])
    for old, c in enumerate(cm):
        replies[c] = [cm[z] for z in a['pursuer_moves'][old]]
    # Compare sets in Lean: the generic outside list has a different order.
    ns = f'LowBandPattern{index:03}'
    text = header('import LowBandLocal', ns)
    text += f'''def pattern : List Nat := {seq(p)}
def messengerMasks (r : Nat) : Nat := {lookup_tree(masks)}
def replyRows (r : Nat) : List C := {lookup_tree(replies)}
def frozenReplies (c : C) : List C := replyRows c.val
def frozenArena : Arena R C where
  messenger r z := (messengerMasks r.val).testBit z.val = true
  pursuer c d := d ∈ frozenReplies c
  collision r c := ¬presentR pattern r ∨ rcop r=c
instance (r z : R) : Decidable (frozenArena.messenger r z) :=
  inferInstanceAs (Decidable (_ = true))
instance (c d : C) : Decidable (frozenArena.pursuer c d) :=
  inferInstanceAs (Decidable (_ ∈ _))
instance (r : R) (c : C) : Decidable (frozenArena.collision r c) :=
  inferInstanceAs (Decidable (_ ∨ _))
theorem messenger_agrees : ∀ r z, frozenArena.messenger r z ↔ (arena pattern).messenger r z := by
  decide +kernel
def sameReplies (c : C) : Bool :=
  (frozenReplies c).all (fun d => decide (d ∈ replies pattern c)) &&
  (replies pattern c).all (fun d => decide (d ∈ frozenReplies c))
theorem reply_rows : ∀ c, sameReplies c=true := by
  decide +kernel
theorem pursuer_agrees : ∀ c d, frozenArena.pursuer c d ↔ (arena pattern).pursuer c d := by
  intro c d
  have both := Bool.and_eq_true_iff.mp (reply_rows c)
  exact ⟨fun h => of_decide_eq_true ((List.all_eq_true.mp both.1) d h),
    fun h => of_decide_eq_true ((List.all_eq_true.mp both.2) d h)⟩
theorem arena_eq : frozenArena = arena pattern := by
  have hm : frozenArena.messenger = (arena pattern).messenger :=
    funext fun r => funext fun z => propext (messenger_agrees r z)
  have hp : frozenArena.pursuer = (arena pattern).pursuer :=
    funext fun c => funext fun d => propext (pursuer_agrees c d)
  change Arena.mk frozenArena.messenger frozenArena.pursuer frozenArena.collision =
    Arena.mk (arena pattern).messenger (arena pattern).pursuer (arena pattern).collision
  rw [hm, hp]
  rfl
#print axioms arena_eq
end Delivery.{ns}
'''
    return text, rm, cm


def objective_text(index, record, rm, cm):
    c = record['certificate']
    ranks = [[0]*103 for _ in range(66)]
    moves = [[0]*103 for _ in range(66)]
    for oldr, r in enumerate(rm):
        for oldc, cop in enumerate(cm):
            ranks[r][cop] = max(0, c['messenger_ranks'][oldr*len(cm)+oldc]+1)
            move = c['policy'][oldr*len(cm)+oldc]
            moves[r][cop] = rm[move] if move >= 0 else 0
    rw = max(v for row in ranks for v in row).bit_length()
    mw = 7
    rankdata, movedata = pack(ranks, rw), pack(moves, mw)
    target = record['target']
    kind = 'Transfer' if target is None else f'Delivery{target}'
    ns = f'LowBandObjective{index:03}{kind}'
    pn = f'LowBandPattern{index:03}'
    safe = target is None
    cond = 'SafeRowCondition' if safe else 'DeliveryRowCondition'
    checked = 'SafeChecked' if safe else 'DeliveryChecked'
    bridge = 'safe_checked' if safe else 'delivery_checked'
    goal = 'transferGoal pattern' if safe else f'deliveryGoal pattern {target}'
    text = header(f'import {pn}', ns)
    text += f'''open {pn}
def packedRanks (r : Nat) : Nat := {lookup_tree(rankdata)}
def packedMoves (r : Nat) : Nat := {lookup_tree(movedata)}
def rankCode (r : R) (c : C) : Nat := ((packedRanks r.val) >>> ({rw}*c.val)) &&& {(1<<rw)-1}
def data : Data R C where
  region r c := 0 < rankCode r c
  rank r c := rankCode r c-1
  move r c := ⟨(((packedMoves r.val) >>> ({mw}*c.val)) &&& 127) % 66, Nat.mod_lt _ (by decide)⟩
instance (r : R) (c : C) : Decidable (data.region r c) :=
  inferInstanceAs (Decidable (0 < _))
instance (r : R) (c : C) : Decidable ({cond} frozenArena ({goal}) data frozenReplies r c) :=
  inferInstanceAs (Decidable (_ → _))
theorem rows_checked : ∀ r c, {cond} frozenArena ({goal}) data frozenReplies r c := by
  decide +kernel
theorem checked : {checked} (arena pattern) ({goal}) data := by
  rw [←arena_eq]
  exact {bridge} frozenArena ({goal}) data frozenReplies (fun _ _ h => h) rows_checked
theorem initial_states : ∀ r c, presentR pattern r → {"rcol r=7" if safe else "(rcol r=5 ∨ rcol r=6)"} →
    presentC pattern c → ¬(arena pattern).collision r c →
    data.region r c ∧ data.rank r c≤{"9" if safe else "(if rcol r=5 then 39 else 38)"} := by
  decide +kernel
#print axioms checked
#print axioms initial_states
end Delivery.{ns}
'''
    return ns, text


def reachable_record(record):
    """Discard unused winning states; the ordinary kernel rechecks closure.

    Start from EVERY required entry state and close under the saved messenger
    policy and EVERY arena cop reply. For terminal delivery the next recipient
    receipt finishes immediately; safe transfer still includes the cop reply.
    No reachability assertion is added as a Lean premise.
    """
    a = make_arena(record['holes'])
    rv, cv = a['messenger_vertices'], a['pursuer_vertices']
    width = len(cv)
    certificate = record['certificate']
    ranks, policy = certificate['messenger_ranks'], certificate['policy']
    target = record['target']
    entries = [-1] if target is None else [-3, -2]
    goal = lambda r: rv[r][0] == 0 and (target is None or rv[r][1] == target)
    seen = {(r,c) for r in range(len(rv)) if rv[r][0] in entries
            for c in range(width) if rv[r] != cv[c]}
    todo = deque(sorted(seen))
    while todo:
        r,c = todo.popleft()
        assert ranks[r*width+c] >= 0
        if goal(r):
            continue
        z = policy[r*width+c]
        assert 0 <= z < len(rv) and z in a['messenger_moves'][r]
        if target is not None and goal(z):
            continue
        assert rv[z] != cv[c]
        for d in a['pursuer_moves'][c]:
            assert rv[z] != cv[d]
            assert 0 <= ranks[z*width+d] < ranks[r*width+c]
            if (z,d) not in seen:
                seen.add((z,d))
                todo.append((z,d))
    result = copy.deepcopy(record)
    for field in ('messenger_ranks', 'policy'):
        result['certificate'][field] = [v if (i//width,i%width) in seen else -1
                                      for i,v in enumerate(certificate[field])]
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--patterns', type=int, default=101)
    ap.add_argument('--pilot', action='store_true', help='Only pattern007 and its largest-rank Delivery2 objective')
    ap.add_argument('--out', type=Path, default=ROOT/'lean')
    ap.add_argument('--unpruned', action='store_true', help='Retain all original winning states for comparison')
    args = ap.parse_args()
    assert 1 <= args.patterns <= 101
    assert not args.pilot or args.patterns >= 8
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED
    data = json.loads(gzip.decompress(SOURCE.read_bytes()))
    catalog = (ROOT/'lean/LowBandCropCoverage.lean').read_text().split('def catalog : List (List Nat) := ', 1)[1].split('\n\nset_option', 1)[0]
    patterns = json.loads(catalog)
    lookup = {(tuple(r['holes']), r['target']): r for r in data['records']}
    expected = {(tuple(x-8 for x in p),t) for p in patterns
                for t in [None,0,1,2,3,4,5] if t != 4 or 8 not in p}
    assert len(patterns) == 101 and len(lookup) == len(data['records']) == 696
    assert set(lookup) == expected
    assert (data['M'],data['R']) == (5,8)
    for (_,t),record in lookup.items():
        a = make_arena(record['holes'])
        length = len(a['messenger_vertices'])*len(a['pursuer_vertices'])
        c = record['certificate']
        assert all(len(c[field]) == length for field in ('messenger_ranks','cop_ranks','policy'))
        assert c['entry_columns'] == ([-1] if t is None else [-3,-2])
    args.out.mkdir(parents=True, exist_ok=True)
    names = []
    certificate_modules = []
    before_states = after_states = 0
    for index, p in enumerate(patterns[:args.patterns]):
        if args.pilot and index != 7:
            continue
        key = tuple(x-8 for x in p)
        record = lookup[key, None]
        atext, rm, cm = arena_text(index, p, record)
        (args.out/f'LowBandPattern{index:03}.lean').write_text(atext)
        objective_names = []
        for t in ([2] if args.pilot else [None,0,1,2,3,4,5]):
            if t == 4 and 8 in p:
                continue
            rec = lookup[key, t]
            assert rec['holes'] == record['holes']
            before_states += sum(v >= 0 for v in rec['certificate']['messenger_ranks'])
            if not args.unpruned:
                rec = reachable_record(rec)
            after_states += sum(v >= 0 for v in rec['certificate']['messenger_ranks'])
            name, text = objective_text(index, rec, rm, cm)
            (args.out/f'{name}.lean').write_text(text)
            objective_names.append(name)
        names += objective_names
        if args.pilot:
            continue
        certname = f'LowBandCertificate{index:03}'
        certificate_modules.append(certname)
        pn = f'LowBandPattern{index:03}'
        tn = f'LowBandObjective{index:03}Transfer'
        ctext = header('\n'.join('import '+name for name in objective_names), certname)
        ctext += f'''theorem checked : Certificates {pn}.pattern := by
  constructor
  · exact ⟨{tn}.data, {tn}.checked, {tn}.initial_states⟩
  · intro t present
    rcases t with ⟨t,ht⟩
    have cases : t=0 ∨ t=1 ∨ t=2 ∨ t=3 ∨ t=4 ∨ t=5 := by omega
    rcases cases with h | h | h | h | h | h <;> subst t
'''
        for t in range(6):
            if t == 4 and 8 in p:
                ctext += f'    · simp [{pn}.pattern] at present\n'
            else:
                dn = f'LowBandObjective{index:03}Delivery{t}'
                ctext += f'    · exact ⟨{dn}.data, {dn}.checked, {dn}.initial_states⟩\n'
        ctext += f'#print axioms checked\nend Delivery.{certname}\n'
        (args.out/f'{certname}.lean').write_text(ctext)
    if args.patterns == 101 and not args.pilot:
        combined = header('import LowBandCropCoverage\n'+'\n'.join('import '+x for x in certificate_modules), 'LowBandCertificates')
        combined += '''theorem certificates (p : List Nat) (member : p ∈ LowBandCropCoverage.catalog) :
    LowBandLocal.Certificates p := by
  simp only [LowBandCropCoverage.catalog, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with ''' + ' | '.join('h' for _ in patterns) + '\n'
        for name in certificate_modules:
            combined += f'  · subst p; exact {name}.checked\n'
        combined += '#print axioms certificates\nend Delivery.LowBandCertificates\n'
        (args.out/'LowBandCertificates.lean').write_text(combined)
    print(json.dumps({'patterns':1 if args.pilot else args.patterns,'objectives':len(names),
                      'certificates':len(certificate_modules),'source_sha256':EXPECTED,
                      'reachable_restriction':not args.unpruned,
                      'original_winning_states':before_states,'exported_winning_states':after_states}))


if __name__ == '__main__':
    main()

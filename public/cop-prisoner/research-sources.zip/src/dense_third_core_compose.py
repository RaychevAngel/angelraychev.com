#!/usr/bin/env python3
"""Literal nine-vertex dense core and missing-block composition checks."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from dense_unified_core import functional, two_move_pairs
from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]
CORE9=((1,3),(4,7),(5,6),(0,2),(6,8),(2,8),(0,4),(1,5),(3,7))


def core9():
    return {(s,t) for s,row in enumerate(CORE9) for t in row}


def functional_plus_nine(r):
    assert r>=2
    f,_=functional(r)
    return f|{(s+r,t+r) for s,t in core9()}


def verify(n,f):
    g={(s,t) for s in range(n) for t in range(n)
       if s!=t and(s,t)not in f}
    return solve_graph(n,g,crosscheck=True,certificates=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    results=[verify(9,core9())]
    assert results[0]['I']==18 and results[0]['m']==54
    assert len(two_move_pairs(9,core9()))==14
    assert results[0]['max_state_delivery_moves']==3
    for r in (2,3,4,5,6):
        result=verify(9+r,functional_plus_nine(r))
        assert result['I']==18+(r-2)//2
        assert result['m']==(9+r)*(6+r)+r
        results.append(result)
    certpath=ROOT/'research/dense-third-core-compose-certificates.json'
    certtext=json.dumps(results,separators=(',',':'))+'\n'
    if args.check:assert certpath.read_text()==certtext
    else:certpath.write_text(certtext)
    receipt={
        'status':'verified',
        'proof_boundary':'Literal nine-core checked by two independent actual-game solvers and full alternating-state certificate replay. Arbitrary-duration additivity under disjoint missing blocks is a separate ordinary proof; no Lean claim.',
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'core9_missing_rows':CORE9,
        'core9_I':18,'core9_two_move_pairs':14,'core9_max_state_moves':3,
        'new_cells_beyond_root_cycles':[[9,54,18],[11,90,18],[12,111,18],[13,134,19]],
        'verified_graphs':[[z['n'],z['m'],z['I']] for z in results],
        'certificates':str(certpath.relative_to(ROOT)),
        'certificate_sha256':hashlib.sha256(certpath.read_bytes()).hexdigest(),
        'certificate_states':sum(2*z['n']**3 for z in results)}
    path=ROOT/'research/dense-third-core-compose-checks.json'
    text=json.dumps(receipt,indent=2)+'\n'
    if args.check:assert path.read_text()==text
    else:path.write_text(text)
    print(json.dumps({'verified_graphs':len(results),'new_cells':4,
                      'certificate_states':receipt['certificate_states']}))


if __name__=='__main__':main()

#!/usr/bin/env python3
"""Two archived target-zero main-interval pilots, without graph search.

The producer groups the retained scalar policy by messenger, raw rank + 1,
and move. Lean independently checks every group, initial mask, upper cop
reply, graph count, looplessness, and lower/upper inclusion. This is a
one-recipient benchmark, not a complete stage or classification certificate.
"""
import argparse
from collections import defaultdict
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import struct
import subprocess
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
LEAN = Path('/Users/angel/code/math/polyominoes/.tools/lean-4.33.1-darwin_aarch64/bin/lean')
PINS = {
    'research/sparse-staged-records.json':
        '2dd3998101a1f5fbc2aeb3e05f0aecfd06545901bff9623ac7c6307286199f06',
    'research/sparse-staged-certificates.zip':
        'e37ebadb62816223fbba35109886d02dd994e3d09f8fd83104ac3f7925d9d411',
    'research/sparse-interface-third-certificates.zip':
        '73860c7fdba0996e5b51cb286bcac831d7839d5f8362f5450b86b8baf6346148',
}
MEMBERS = {
    19: ('n19/upward-stage0.i16le',
         '5ffe264ff1e9116ebda17bd73aea4c9175f812903157edd69dce5a701054e4b5'),
    114: ('sparse-interface-third-certified-n114.json.gz',
          'e5ae78c01214385a4d23aa9932d795034eaf480070f5092b167ab0d36c2fe94f'),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def tree(values, low=0):
    if len(values) == 1:
        return str(values[0])
    middle = len(values)//2
    return (f'(if x < {low+middle} then {tree(values[:middle], low)} '
            f'else {tree(values[middle:], low+middle)})')


def read_case(n):
    member, expected = MEMBERS[n]
    if n == 19:
        records = json.loads((ROOT/'research/sparse-staged-records.json').read_text())['records']
        record = next(r for r in records if r['n'] == n and r['direction'] == 'upward')
        stage = next(s for s in record['stages'] if s['member'] == member)
        assert stage['sha256'] == expected
        with zipfile.ZipFile(ROOT/'research/sparse-staged-certificates.zip') as bundle:
            raw = bundle.read(member)
        assert sha(raw) == expected
        values = struct.unpack('<'+'h'*(len(raw)//2), raw)
        assert len(values) == 2*n**3
        ranks = values[:n*n]
        moves = values[n**3:n**3+n*n]
        base = record['base_arcs']+record['added'][:stage['prefix_start']]
        upper = record['base_arcs']+record['added'][:stage['prefix_end']]
        low, high = stage['m_min'], stage['m_max']
    else:
        with zipfile.ZipFile(ROOT/'research/sparse-interface-third-certificates.zip') as bundle:
            raw = bundle.read(member)
        assert sha(raw) == expected
        record = json.loads(gzip.decompress(raw))['graphs'][0]
        graph = record['graph']
        assert graph['n'] == n
        cert = next(r['certificate'] for r in record['records'] if r['target'] == 0)
        ranks, moves = cert['messenger_ranks'], cert['policy']
        assert len(ranks) == len(moves) == n*n
        base = graph['base']
        upper = base+graph['optional']
        low, high = graph['m_min'], graph['m_max']
    assert len(base) == len(set(map(tuple, base))) == low
    assert len(upper) == len(set(map(tuple, upper))) == high
    assert set(map(tuple, base)) <= set(map(tuple, upper))
    assert all(0 <= s < n and 0 <= t < n and s != t for s, t in upper)
    return dict(n=n, target=0, member=member, member_sha256=expected,
                base=base, upper=upper, ranks=list(ranks), moves=list(moves), low=low, high=high)


def groups_for(case):
    n, target = case['n'], case['target']
    groups = [defaultdict(list) for _ in range(n)]
    ranks, moves = case['ranks'], case['moves']
    for r in range(n):
        for c in range(n):
            at = r*n+c
            if r == target or r == c or ranks[at] < 0:
                continue
            assert 0 <= moves[at] < n
            groups[r][ranks[at]+1, moves[at]].append(c)
    return groups


def validate(case, groups):
    """Independent producer sanity check; none of these results is trusted by Lean."""
    n, target = case['n'], case['target']
    lower, upper = set(map(tuple, case['base'])), set(map(tuple, case['upper']))
    replies = [[d for d in range(n) if d == c or (c, d) in upper] for c in range(n)]
    state = {(r, c): (rank, z) for r, row in enumerate(groups)
             for (rank, z), cops in row.items() for c in cops}
    replies_checked = required = 0
    for r, row in enumerate(groups):
        for (rank, z), cops in row.items():
            assert rank > 0 and (r == z or (r, z) in lower)
            assert r not in cops
            if z == target:
                continue
            assert z not in cops
            for c in cops:
                for d in replies[c]:
                    replies_checked += 1
                    assert z != d
                    assert (z, d) in state and state[z, d][0] < rank
    for s in range(n):
        if s == target or (s, target) in lower:
            continue
        for c in range(n):
            if c != s:
                required += 1
                assert (s, c) in state
    return dict(groups=sum(map(len, groups)), retained_states=len(state),
                required_initial_states=required, actual_nonterminal_replies=replies_checked,
                original_scalar_rows=n*n, maximum_group_rank=max(rank for rank, _ in state.values()))


def base_source(case):
    n = case['n']
    name = f'MainGroupedPilot{n}Base'
    lower = [sum(1 << t for s, t in case['base'] if s == r) for r in range(n)]
    upper = [sum(1 << t for s, t in case['upper'] if s == r) for r in range(n)]
    text = f'''import GroupedGraphRanks
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open FiniteGame Extremal GroupedArena
def lowerRows (x : Nat) : Nat := {tree(lower)}
def upperRows (x : Nat) : Nat := {tree(upper)}
def lower (s t : Fin {n}) : Prop := (lowerRows s.val).testBit t.val=true
def upper (s t : Fin {n}) : Prop := (upperRows s.val).testBit t.val=true
instance (s t : Fin {n}) : Decidable (lower s t) := inferInstanceAs (Decidable (_=true))
instance (s t : Fin {n}) : Decidable (upper s t) := inferInstanceAs (Decidable (_=true))
def replyMasks (c : Fin {n}) : Nat := upperRows c.val ||| 2^c.val
theorem reply_coverage : ∀ c d, Legal upper c d → Has (replyMasks c) d := by
  intro c d legal
  rcases legal with same|edge
  · exact (has_or _ _ d).mpr (Or.inr ((has_power c d).mpr same.symm))
  · exact (has_or _ _ d).mpr (Or.inl edge)
theorem inclusion : RobustTwoMove.Subgraph lower upper := by
  unfold RobustTwoMove.Subgraph
  decide +kernel
theorem loopless : Loopless upper := by unfold Loopless; decide +kernel
theorem counts : arcCount lower={case['low']} ∧ arcCount upper={case['high']} := by
  constructor <;> rw [arcCount_eq] <;> decide +kernel
#print axioms reply_coverage
#print axioms inclusion
#print axioms loopless
#print axioms counts
end Delivery.{name}
'''
    return name, text


def objective_source(case, groups, mode):
    n = case['n']
    suffix = 'Literal' if mode == 'literal' else 'Decoded'
    name = f'MainGroupedPilot{n}{suffix}'
    base = f'MainGroupedPilot{n}Base'
    rows = []
    for row in groups:
        terms = []
        for (rank, move), cops in sorted(row.items()):
            mask = sum(1 << c for c in cops)
            cop_list = '['+','.join(map(str, cops))+']' if mode == 'literal' else f'decodeCops {mask}'
            terms.append(f'{{rank:={rank},move:={move},cops:={cop_list},mask:={mask}}}')
        rows.append('['+','.join(terms)+']')
    decoder = '' if mode == 'literal' else f'def decodeCops (mask : Nat) : List (Fin {n}) :=\n  (List.finRange {n}).filter (fun c => mask.testBit c.val)\n'
    text = f'''import {base}
/- Frozen {case['member']}; SHA256 {case['member_sha256']}.
Target zero only. Raw ranks are increased by one, then grouped. No claim
about any other recipient or a complete stage is made by this pilot. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open FiniteGame Extremal GroupedArena GroupedGraphRanks
open {base}
{decoder}noncomputable def groupRows (x : Nat) : List (Group {n} {n}) := {tree(rows)}
noncomputable def rows (r : Fin {n}) : List (Group {n} {n}) := groupRows r.val
theorem groups_checked : GroupedArena.Checked true (arena lower upper) (fun r => r=0)
    replyMasks collisionMasks rows := by
  unfold GroupedArena.Checked
  decide +kernel
theorem entry_subset : ∀ s : Fin {n}, s≠0 → ¬lower s 0 →
    initialMask s &&& activeMask (rows s)=initialMask s := by
  decide +kernel
theorem winning {{G : Graph (Fin {n})}}
    (lowerG : RobustTwoMove.Subgraph lower G) (upperG : RobustTwoMove.Subgraph G upper)
    (r c : Fin {n}) (inside : Active (rows r) c) :
    Winning G 0 ((GroupedArena.data rows).rank r c) r c := by
  exact LocalArena.delivery_projection (simulation lowerG upperG)
    (GroupedArena.delivery_checked (arena lower upper) (fun r => r=0)
      replyMasks collisionMasks rows reply_coverage (collision_covered lower upper) groups_checked)
    (fun _ same => same) r c inside
theorem guaranteed {{G : Graph (Fin {n})}}
    (lowerG : RobustTwoMove.Subgraph lower G) (upperG : RobustTwoMove.Subgraph G upper)
    (s : Fin {n}) : Guaranteed G s 0 := by
  intro c initial
  by_cases terminal : s=0
  · subst s
    exact ⟨0,Winning.delivered⟩
  by_cases direct : lower s 0
  · exact ⟨1,Winning.finish (Ne.symm initial) (Or.inr (lowerG s 0 direct))⟩
  have active := (has_activeMask (rows s) c).mp
    (has_subset (entry_subset s terminal direct) ((has_initialMask s c).mpr initial))
  exact ⟨_,winning lowerG upperG s c active⟩
#print axioms winning
#print axioms guaranteed
end Delivery.{name}
'''
    return name, text


def scalar_source(case):
    n = case['n']
    name, base = f'MainGroupedPilot{n}Scalar', f'MainGroupedPilot{n}Base'
    ranks, moves = ([max(0, v) for v in case[field]] for field in ('ranks', 'moves'))
    rank_width, move_width = max(1, max(ranks).bit_length()), (n-1).bit_length()
    def pack(values, width):
        return [sum(value << (width*c) for c, value in enumerate(values[r:r+n]))
                for r in range(0, n*n, n)]
    edges = set(map(tuple, case['upper']))
    replies = ['['+','.join(str(d) for d in range(n) if d == c or (c, d) in edges)+']'
               for c in range(n)]
    text = f'''import {base}
import MainStageRows
/- Matched scalar target-zero baseline from {case['member']}.
The same archived raw ranks and policy are checked by MainStageRows.RowGood;
the established move bound is raw rank + 1, matching the grouped encoding. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open FiniteGame Extremal MainStageRows StagedEnvelopes
open {base}
instance (c d : Fin {n}) : Decidable (Legal upper c d) :=
  inferInstanceAs (Decidable (_ ∨ _))
def rankRows (x : Nat) : Nat := {tree(pack(ranks, rank_width))}
def moveRows (x : Nat) : Nat := {tree(pack(moves, move_width))}
def data : MainStageRows.Data {n} where
  rank _ r c := (rankRows r.val >>> ({rank_width}*c.val)) &&& {2**rank_width-1}
  move _ r c := ⟨((moveRows r.val >>> ({move_width}*c.val)) &&& {2**move_width-1})%{n},
    Nat.mod_lt _ (by decide)⟩
def replyRows (x : Nat) : List (Fin {n}) := {tree(replies)}
def replies (c : Fin {n}) : List (Fin {n}) := replyRows c.val
theorem reply_coverage : ∀ c d, Legal upper c d → d∈replies c := by decide +kernel
theorem checked : ∀ r c, RowGood lower data replies 0 r c := by decide +kernel
def certificate : RankEnvelope lower upper 0 where
  rank := data.rank 0
  move := data.move 0
  valid := by
    intro r c notTarget distinct
    obtain ⟨move,finish | ⟨safe,future⟩⟩ := checked r c notTarget distinct
    · exact ⟨move,Or.inl finish⟩
    · refine ⟨move,Or.inr ⟨safe,?_⟩⟩
      intro d legal
      exact of_decide_eq_true ((List.all_eq_true.mp future) d (reply_coverage c d legal))
theorem winning {{G : Graph (Fin {n})}}
    (lowerG : RobustTwoMove.Subgraph lower G) (upperG : RobustTwoMove.Subgraph G upper)
    (r c : Fin {n}) (initial : r≠c) : Winning G 0 (data.rank 0 r c+1) r c :=
  envelope_winning certificate lowerG upperG initial
theorem guaranteed {{G : Graph (Fin {n})}}
    (lowerG : RobustTwoMove.Subgraph lower G) (upperG : RobustTwoMove.Subgraph G upper)
    (s : Fin {n}) : Guaranteed G s 0 :=
  fun c initial => ⟨_,winning lowerG upperG s c (Ne.symm initial)⟩
#print axioms winning
#print axioms guaranteed
end Delivery.{name}
'''
    return name, text


def import_pins(source, out):
    result = {}
    for line in source.read_text().splitlines():
        if not line.startswith('import '):
            continue
        for module in line.split()[1:]:
            relative = Path(*module.split('.'))
            directory = next(root for root in (out, ROOT/'lean')
                             if (root/relative).with_suffix('.olean').is_file())
            obj = (directory/relative).with_suffix('.olean')
            src = obj.with_suffix('.lean')
            result[module] = dict(object_path=str(obj.resolve()), object_sha256=sha(obj.read_bytes()),
                                  source_path=str(src.resolve()), source_sha256=sha(src.read_bytes()))
    return result


def replay(out, modules, timeout):
    env = dict(os.environ, LEAN_PATH=f'{out}:{ROOT / "lean"}')
    receipt = dict(scope='Two target-zero pilots only; no whole-stage or classification claim.',
                   compiler_path=str(LEAN), compiler_sha256=sha(LEAN.read_bytes()),
                   compiler_version=subprocess.check_output([str(LEAN), '--version'], text=True).strip(),
                   workers=1, timeout_seconds=timeout, records=[])
    for name in modules:
        source, obj, log = (out/f'{name}.{ext}' for ext in ('lean', 'olean', 'log'))
        source_before = sha(source.read_bytes())
        imports_before = import_pins(source, out)
        before = resource.getrusage(resource.RUSAGE_CHILDREN)
        start = time.perf_counter()
        timed_out = False
        with log.open('w') as stream:
            try:
                result = subprocess.run([str(LEAN), '-j1', '-o', str(obj), str(source)],
                                        cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                        timeout=timeout)
                code = result.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
                code = None
        wall = time.perf_counter()-start
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        output = log.read_text()
        imports_after = import_pins(source, out)
        axiom_lines = re.findall(r'depends on axioms: \[([^]]*)\]', output)
        axioms = sorted({axiom.strip() for line in axiom_lines for axiom in line.split(',') if axiom.strip()})
        allowed_axioms = {'propext', 'Classical.choice', 'Quot.sound'}
        axioms_valid = bool(axiom_lines or 'does not depend on any axioms' in output) and set(axioms) <= allowed_axioms
        frozen = source_before == sha(source.read_bytes()) and imports_before == imports_after
        record = dict(module=name, source_sha256=source_before, direct_imports=imports_before,
                      source_and_direct_imports_unchanged=frozen,
                      axioms=axioms, axioms_valid=axioms_valid,
                      exit_code=code, timed_out=timed_out, wall_seconds=wall,
                      cpu_user_seconds=after.ru_utime-before.ru_utime,
                      cpu_system_seconds=after.ru_stime-before.ru_stime,
                      log_sha256=sha(log.read_bytes()))
        record['pass'] = code == 0 and axioms_valid and frozen and 'error:' not in output
        if code == 0:
            record['object_sha256'] = sha(obj.read_bytes())
        receipt['records'].append(record)
        (out/'replay.json').write_text(json.dumps(receipt, indent=2)+'\n')
        print(json.dumps({key: value for key, value in record.items() if key != 'direct_imports'}), flush=True)
        if not record['pass']:
            print(output[-6000:], flush=True)
            return False
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', choices=('19', '114', 'both'), default='both')
    parser.add_argument('--cop-lists', choices=('literal', 'decoded', 'both'), default='literal')
    parser.add_argument('--scalar-baseline', action='store_true',
                        help='Generate matched scalar objectives instead of grouped objectives')
    parser.add_argument('--out', type=Path, default=ROOT/'tmp/lean-main-grouped-pilot')
    parser.add_argument('--replay', action='store_true')
    parser.add_argument('--timeout', type=float, default=120)
    args = parser.parse_args()
    for path, expected in PINS.items():
        assert sha((ROOT/path).read_bytes()) == expected, path
    args.out.mkdir(parents=True, exist_ok=True)
    pins = dict(PINS)
    for path in ('src/export_main_grouped_pilot.py', 'lean/GroupedArena.lean', 'lean/GroupedGraphRanks.lean'):
        pins[path] = sha((ROOT/path).read_bytes())
    manifest = dict(scope='Two archived recipient-zero pilots; no search and no full-stage theorem.',
                    input_sha256=pins, files={}, cases=[], modules=[])
    cases = (19, 114) if args.case == 'both' else (int(args.case),)
    modes = ('literal', 'decoded') if args.cop_lists == 'both' else (args.cop_lists,)
    for n in cases:
        case = read_case(n)
        groups = groups_for(case)
        stats = validate(case, groups)
        manifest['cases'].append(dict(n=n, target=0, low=case['low'], high=case['high'],
                                      member=case['member'], member_sha256=case['member_sha256'], **stats))
        sources = [base_source(case)]+([scalar_source(case)] if args.scalar_baseline else
                                      [objective_source(case, groups, mode) for mode in modes])
        for name, text in sources:
            path = args.out/f'{name}.lean'
            path.write_text(text)
            manifest['files'][path.name] = sha(text.encode())
            manifest['modules'].append(name)
        print(json.dumps(manifest['cases'][-1]), flush=True)
    (args.out/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    if args.replay:
        if not replay(args.out, manifest['modules'], args.timeout):
            raise SystemExit(1)


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Finite tests of regular directed covers of already universal bases."""
import json,random,time,hashlib
from pathlib import Path
from composition_interface_lifts import test
ROOT=Path(__file__).resolve().parents[1]
rng=random.Random(12533);records=[];start=time.monotonic()
bases=json.loads((ROOT/'research/sparse-finite-bridge-witnesses.json').read_text())[:2]
for base in bases:
 for sheets in (2,3):
  for trial in range(4):
   perms=[];arcs=[]
   for u,v in base['arcs']:
    p=list(range(sheets));rng.shuffle(p);perms.append(p)
    arcs.extend((sheets*u+i,sheets*v+p[i]) for i in range(sheets))
   d=test(sheets*base['n'],arcs,dual=False)
   d.update(base_n=base['n'],sheets=sheets,trial=trial,cover_permutations=perms)
   records.append(d)
   print({k:v for k,v in d.items() if k not in ('arcs','source_camps','checked_targets','cover_permutations')},flush=True)
art={'seconds':time.monotonic()-start,'scope':'finite directed regular-cover tests, no preservation assertion','records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'research/composition-interface-covers.json').write_text(json.dumps(art,indent=2)+'\n')

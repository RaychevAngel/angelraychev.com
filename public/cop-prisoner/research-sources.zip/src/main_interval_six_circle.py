#!/usr/bin/env python3
"""Direct six-offset circles and finite promoted envelopes.

No graph discovery is performed. Literal rows are read from a frozen file;
periodic rows are calculated from arithmetic parameters. Every optional
subset is certified by escape clauses or supplied finite source ranks.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'research/six-circle-recipes.json'


def core(n, h):
    return {x % n for x in (1, h-3, h-2, h, h+1, h+2)}


def safe_sets(n, h):
    return [{x % n for x in S} for S in
            [(h, 1, h+1), (h, h-3, h-2), (h, h-2, h+2)]]


def literal_rows():
    return json.loads(DATA.read_text())['rows']


def periodic(n, h, period):
    if math.gcd(n, h) != 1:
        raise ValueError('coprime propagation step required')
    if period == 4:
        if n % 4 or h < 7 or h % 4 != 3 or n < 2*h+2:
            raise ValueError('modulo-four hypotheses do not hold')
        A = {x for x in range(n) if x % 4 in {0, 1}} | {h}
    elif period == 5:
        if n % 5 or h < 8 or h % 5 != 3 or n < 2*h+2:
            raise ValueError('modulo-five hypotheses do not hold')
        A = ({x for x in range(n) if x % 5 in {0, 1, 4}} | {h}) - {h+3, h-4, 2*h-1}
    else:
        raise ValueError('only the proved periodic recipes are available')
    return {'n': n, 'h': h, 'A': sorted(A), 'C': sorted(core(n, h)),
            'm_min': 6*n, 'm_max': n*(len(A)-1), 'kind': 'six-clause',
            'period': period}


def rows(n):
    result = [r for r in literal_rows() if r['n'] == n]
    for period, minimum in [(4, 7), (5, 8)]:
        if n % period:
            continue
        for h in range(minimum, (n-2)//2+1, period):
            if math.gcd(n, h) == 1:
                result.append(periodic(n, h, period))
                break  # every h in this periodic family has the same count
    return result


def intervals(n):
    return [{'n': n, 'm_min': r['m_min'], 'm_max': r['m_max'],
             'kind': r['kind'], **({'h': r['h']} if 'h' in r else {})}
            for r in rows(n)]


def construct(n, m):
    candidates = [r for r in rows(n) if r['m_min'] <= m <= r['m_max']]
    if not candidates:
        raise ValueError('outside the proved circle intervals')
    r = min(candidates, key=lambda x: (x['m_min'], -x['m_max'], tuple(x['C'])))
    C, A = set(r['C']), set(r['A'])
    arcs = {(u, (u+d) % n) for u in range(n) for d in C}
    optional = sorted((u, (u+d) % n) for u in range(n) for d in A-C-{0})
    arcs.update(optional[:m-len(arcs)])
    assert len(arcs) == m and all(u != v for u, v in arcs)
    return sorted(arcs)


def verify(row, all_targets=True):
    """Independent direct replay of supplied local data, without a solver."""
    n, C, A = row['n'], set(row['C']), set(row['A'])
    assert len(C) == len(row['C']) and len(A) == len(row['A'])
    assert C | {0} <= A <= set(range(n)) and 0 not in C
    assert row['m_min'] == n*len(C) and row['m_max'] == n*(len(A)-1)
    count = 0
    if row['kind'] == 'six-clause':
        h = row['h']
        assert math.gcd(h, n) == 1 and len(C) == 6 and C == core(n, h)
        for S in safe_sets(n, h):
            assert len(S) == 3 and S <= C
            for q in range(1, n):
                assert any((d-q) % n not in A for d in S)
                count += 1
        # Integer identities prove the propagation independently of reduction.
        P = {-2, -1, 0, 2}
        assert {(-h+x) % n for x in P} <= {(-c) % n for c in C}
        known = set(P)
        for x, offsets in [(2-h, (h, h-3, h-2)), (-h, (h, h-2, h+2)),
                           (-h-1, (h, 1, h+1)), (-h-2, (h, 1, h+1))]:
            assert {x+d for d in offsets} <= known
            known.add(x)
        assert {x-h for x in P} <= known
    else:
        assert row['kind'] == 'finite-source-ranks'
        rank = row['rank_t0']
        assert len(rank) == n and rank[0] == 0 and all(isinstance(k, int) and k >= 1 for k in rank[1:])
        for t in (range(n) if all_targets else [0]):
            for s in range(n):
                if s == t:
                    continue
                if (t-s) % n in C:
                    assert rank[(s-t) % n] >= 1
                    continue
                for q in range(n):
                    if q == s:
                        continue
                    assert any(rank[(s+d-t) % n] < rank[(s-t) % n]
                               and (s+d-q) % n not in A for d in C)
                    count += 1
    return count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--out', type=Path, default=ROOT/'research/six-circle-checks.json')
    args = parser.parse_args()
    literals = literal_rows()
    count = sum(verify(r) for r in literals)
    periodic_count = 0
    for n in range(16, 161):
        for p, h0 in [(4, 7), (5, 8)]:
            if n % p:
                continue
            for h in range(h0, (n-2)//2+1, p):
                if math.gcd(n, h) == 1:
                    count += verify(periodic(n, h, p))
                    periodic_count += 1
    built = 0
    for n in sorted({r['n'] for r in literals}):
        for r in rows(n):
            for m in {r['m_min'], (r['m_min']+r['m_max'])//2, r['m_max']}:
                assert len(construct(n, m)) == m
                built += 1
    report = {'status': 'supplied local escape clauses and finite ranks replayed',
              'literal_recipes': len(literals), 'periodic_parameter_checks': periodic_count,
              'escape_and_rank_obligations': count, 'exact_budget_constructions': built,
              'boundaries': 'Ordinary conditional/periodic proofs are distinct from the finite promoted rank certificates. No Lean formalization of these concrete families.'}
    args.out.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()

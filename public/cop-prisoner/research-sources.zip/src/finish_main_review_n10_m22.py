#!/usr/bin/env python3
"""Replay an increasing-incumbent exclusion from its initial bound, with witnesses."""
import hashlib,json,subprocess,tempfile
from pathlib import Path
from finish_eighteen_review import positive_patterns,lower_review
from finish_budget_leaf_review import variant
ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    primary=ROOT/'research/finish-positive-max-n10-m22-from55.json';p=json.loads(primary.read_text())
    assert p['complete'] and p['initial_threshold']==55 and p['threshold']==p['upper_if_complete']==60
    assert p['degree_patterns']==p['total_degree_patterns']==61 and p['maximum_threshold_survivor']==60
    source=ROOT/p['source_file'];profiles=ROOT/p['profile_file']
    assert sha(source)==p['source_sha256'] and sha(profiles)==p['profile_sha256']
    # Exact source was ordinarily reviewed in the preceding n9/m20 audit.
    prior=json.loads((ROOT/'research/finish_main_review_n9_m20.json').read_text())
    assert prior['verified'] and prior['input_hashes'][p['source_file']]==sha(source)
    supplied=json.loads(profiles.read_text())['patterns'];independent=positive_patterns(10,22,55)
    assert independent==set(tuple(map(tuple,row)) for row in supplied) and len(supplied)==61
    generated=variant(source.read_text())
    marker='long long audit_calls=0,audit_samples=0,audit_pairs=0;'
    assert marker in generated
    generated=generated.replace(marker,marker+'\nvector<vector<int>> audit_updates;')
    marker='if(score<=threshold){++early_game_rejects;return -1;}return score;'
    assert marker in generated
    generated=generated.replace(marker,'if(score<=threshold){++early_game_rejects;return -1;}vector<int> update={threshold,score};for(int v=0;v<n;v++)update.push_back(O[v]);audit_updates.push_back(update);return score;')
    marker='cerr<<"AUDIT "'
    assert marker in generated
    generated=generated.replace(marker,'cerr<<"UPDATES [";for(size_t k=0;k<audit_updates.size();k++){if(k)cerr<<",";cerr<<"[";for(size_t j=0;j<audit_updates[k].size();j++){if(j)cerr<<",";cerr<<audit_updates[k][j];}cerr<<"]";}cerr<<"]\\n";'+marker)
    with tempfile.TemporaryDirectory(prefix='finish_main_review_n10_m22_') as tmp:
        tmp=Path(tmp);cpp=tmp/'review.cpp';exe=tmp/'review';cpp.write_text(generated)
        subprocess.run(['c++','-O3','-std=c++17',str(cpp),'-o',str(exe)],check=True)
        data=str(len(supplied))+'\n'+'\n'.join(' '.join(str(v) for pair in row for v in pair) for row in supplied)+'\n'
        args=[str(exe),'10','22','55','90','0']
        run=subprocess.run(args,input=data,text=True,capture_output=True,timeout=100)
        assert run.returncode==0,(run.stdout,run.stderr)
        fresh=json.loads(run.stdout)
        assert fresh['complete'] and fresh['initial_threshold']==55 and fresh['threshold']==fresh['upper_if_complete']==60
        for field in ['nodes','degree_patterns','total_degree_patterns','game_decisions','camping_rejects','guarded_checks','guarded_rejects','early_game_rejects','maximum_threshold_survivor','arcs']:
            assert fresh[field]==p[field],(field,fresh[field],p[field])
        lines=run.stderr.strip().splitlines();assert len(lines)==2 and lines[0].startswith('UPDATES ')
        updates=json.loads(lines[0][8:]);assert len(updates)==2
        incumbent=55
        for item in updates:
            assert item[0]==incumbent and item[1]>incumbent;incumbent=item[1]
            assert sum(row.bit_count() for row in item[2:])==22
            assert all(not(row>>v&1) for v,row in enumerate(item[2:]))
        assert incumbent==60
        audit=lines[1].split();assert len(audit)==4 and audit[0]=='AUDIT'
        fresh.update(independent_maximum=int(audit[1]),guarded_samples=int(audit[2]),sampled_losing_pairs=int(audit[3]),
                     independent_improvement_witnesses=[dict(previous_threshold=r[0],score=r[1],outgoing_masks=r[2:]) for r in updates])
        args[4]='0.000000001';stop=subprocess.run(args,input=data,text=True,capture_output=True,timeout=10)
        stopped=json.loads(stop.stdout);assert stop.returncode==1 and stopped['complete'] is False
        fresh['timeout_control']={'returncode':1,'complete':False,'nodes':stopped['nodes']}
    lower=lower_review(ROOT/p['certificate_file']);assert lower['I']==60
    assert set(map(tuple,json.loads((ROOT/p['certificate_file']).read_text())['arcs']))==set(map(tuple,p['arcs']))
    inputs=[primary,source,profiles,ROOT/p['certificate_file'],ROOT/'research/finish_main_review_n9_m20.json',ROOT/'research/finish_main_review_n9_m20.md',
            ROOT/'src/finish_eighteen_review.py',ROOT/'src/finish_budget_leaf_review.py',ROOT/'src/finish_alternating_review.hpp',
            ROOT/'research/sparse_finish_nineteen49_proof.md']
    result=dict(verified=True,claim='M(10,22)=60',source_sha256=sha(Path(__file__)),independent_joint_degree_patterns=len(independent),
        input_hashes={str(f.relative_to(ROOT)):sha(f) for f in inputs},variant_sha256=hashlib.sha256(generated.encode()).hexdigest(),run=fresh,lower=lower,
        ordinary_zero_degree_upper={'d1':51,'d2':44,'d_at_least3':55,'dependency':'root-approved ME19<=49'},support_at_most9_upper=50,
        threshold_proof='Start at55; only increase to an exact independently solved graph score. Every earlier pruned family remains bounded by that earlier threshold and hence by the final60. Initial omitted degree patterns have eligible upper<=55.',
        scope='Independent exact degree inventory and every reached leaf game, retaining the source-reviewed producer enumeration and pruning. Literal and update witnesses are independently checked; this is not a second independent graph enumeration.')
    (ROOT/'research/finish_main_review_n10_m22.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'verified':True,'claim':result['claim'],'updates':[[r[0],r[1]] for r in updates],'leaf_games':fresh['game_decisions'],'guarded_samples':fresh['guarded_samples'],'losing_pairs':fresh['sampled_losing_pairs'],'seconds':fresh['seconds']}))

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Independent cell-by-cell replay of the completion pass from frozen101 ledger."""
import gzip,hashlib,json
from pathlib import Path
import small_case_ledger_review as independent
ROOT=Path(__file__).resolve().parents[1]
BASE_SHA='2c72e928c8bd36b917269ea5022cd50065f9ea18c41c8d45a3af941ba4fcab6e'

def main():
    blob=gzip.decompress((ROOT/'research/finish-case-baseline.json.gz').read_bytes())
    assert hashlib.sha256(blob).hexdigest()==BASE_SHA
    before=json.loads(blob);after=json.loads((ROOT/'publication/classification-coverage.json').read_text())
    approved=json.loads((ROOT/'research/small-case-results.json').read_text())
    old,old_unknown=independent.expand(before);new,new_unknown=independent.expand(after)
    independent.CAPS={r['m']:r['universal_host_cutoff'] for r in approved['host_cutoffs']}
    replay=independent.replay_new_closure(old,approved)
    assert replay==new,'independent new-input closure differs'
    newly_exact=0
    for n,row in old.items():
        for m,(lo,hi) in enumerate(row):
            low,high=new[n][m];assert low>=lo and high<=hi
            if lo==hi:assert low==high==lo
            else:newly_exact+=low==high
    canonical=[(n,m) for n,m in new_unknown if m and n<=independent.CAPS.get(m,2*m)]
    assert len(canonical)==after['canonical_representatives']['unresolved']
    previous=[(n,m) for n,m in old_unknown if m and n<=int(before['canonical_representatives']['host_cutoffs'].get(str(m),2*m))]
    closed_representatives=[(n,m) for n,m in previous if new[n][m][0]==new[n][m][1]]
    removed_repeats=[(n,m) for n,m in previous if new[n][m][0]!=new[n][m][1] and (n,m) not in canonical]
    assert len(previous)==101 and len(closed_representatives)+len(removed_repeats)+len(canonical)==101
    paths=['src/finish_ledger_review.py','src/small_case_ledger_review.py',
      'research/finish-case-baseline.json.gz','research/small-case-results.json',
      'research/finish-case-approved-bounds.json','publication/classification-coverage.json']
    result={'verified':True,'all_admissible_cells':sum(map(len,new.values())),
      'previous_exact_preserved':before['totals']['exact'],'newly_exact_cells':newly_exact,
      'previous_canonical':101,'numerically_closed_representatives':len(closed_representatives),
      'unknown_host_repetitions_removed':len(removed_repeats),'remaining_canonical':len(canonical),
      'remaining_pairs':canonical,'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}}
    (ROOT/'research/finish-ledger-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('remaining_pairs','source_sha256')}))
if __name__=='__main__':main()

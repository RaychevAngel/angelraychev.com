#!/usr/bin/env python3
"""Direct main-interval recipes from order43 above3n, and order104 above2n.

Only explicit arithmetic parameter rules and already certified finite inputs
are selected. No graph search, game solve, or derandomization is used.
The previous n>=106 constructor remains unchanged and supplies the tail.
"""
from functools import lru_cache
from pathlib import Path
import argparse
import hashlib
import json
import main_interval_composed as previous
import main_interval_half_density as circle
import main_interval_layered as layer
import main_interval_resume as protected
import core_code_all_parities as code

ROOT = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=None)
def families(n):
    if not 43 <= n <= 105:
        raise ValueError('The finite overlap calculation covers orders43 through105.')
    _, values, _ = protected.move_envelope(n)
    out = [dict(branch='protected', m_min=3*n, m_max=n*(len(values)-1))]
    out += [dict(x, branch='circle') for x in circle.intervals(n)]
    out += [dict(x, branch='layer') for x in layer.intervals(n)]
    for k in range(6,n//2+1):
        for r in range(3,k//2+1):
            bounds = code.interval(k,r,n)
            if bounds is not None:
                out.append(dict(branch='code',k=k,r=r,m_min=bounds[0],m_max=bounds[1]))
    L = n*(n-1)
    out.append(dict(branch='dense',m_min=L-n*max(3,(n+11)//13),m_max=L-2*n))
    registry=json.loads((ROOT/'research/sparse-interface-third-proof-registry.json').read_text())
    for record in registry['records']:
        if record['n']==n:
            out.append(dict(branch='sparse',m_min=record['m_min'],m_max=record['m_max'],
                            variant=record['variant'],maximum_moves=record['maximum_moves'],
                            certificate_member=record['member']))
    return tuple(out)


def plan(n, start=None):
    start = (2*n if n>=104 else 3*n) if start is None else start
    stop=n*(n-3); current=start; result=[]
    candidates=families(n)
    while current<=stop:
        covering=[x for x in candidates if x['m_min']<=current<=x['m_max']]
        if not covering:
            raise ValueError(f'Uncovered budget({n},{current}); no theorem claimed there.')
        chosen=max(covering,key=lambda x:x['m_max'])
        end=min(stop,chosen['m_max'])
        result.append(dict(chosen,used_from=current,used_through=end))
        current=end+1
    return result


def construct(n,m):
    if not 2*n<=m<=n*(n-3):
        raise ValueError('Require a budget in the main interval.')
    if n>=106:
        return previous.construct(n,m)
    chosen=next((x for x in families(n) if x['m_min']<=m<=x['m_max']),None)
    if chosen is None:
        raise ValueError('No supplied recipe covers this pair.')
    branch=chosen['branch']
    if branch=='protected': arcs=protected.construct(n,m)[0]
    elif branch=='circle':
        arcs=circle.construct(n,m,h=chosen['h'],variant=chosen['variant'])
    elif branch=='layer':
        arcs=layer.construction(chosen['g'],chosen['b'],m-chosen['m_min'],
                                chosen['r'],chosen['hubs'])['arcs']
    elif branch=='code':
        arcs=code.construction(chosen['k'],chosen['r'],n-2*chosen['k'],
                               m-chosen['m_min'])['arcs']
    elif branch=='dense': arcs=previous.dense_arcs(n,m,{})[0]
    else:
        k=(n+5)//6
        p=dict(sparse_k=k,hole_count=6*k-n,sparse_finite_variant=chosen['variant'],
               sparse_finite_maximum_moves=chosen['maximum_moves'])
        arcs=previous.sparse_arcs(n,m,p)[0]
    arcs=sorted(arcs)
    assert len(set(arcs))==len(arcs)==m and all(0<=u<n and 0<=v<n and u!=v for u,v in arcs)
    return dict(n=n,m=m,I=n*(n-1)-m,branch=branch,parameters=chosen,arcs=arcs)


def checks():
    plans=[]; count=0
    for n in range(43,106):
        segments=plan(n)
        for x in segments:
            for m in sorted({x['used_from'],x['used_through'],(x['used_from']+x['used_through'])//2}):
                graph=construct(n,m)
                assert graph['I']==n*(n-1)-m
                count+=1
        plans.append(dict(n=n,start=segments[0]['used_from'],stop=n*(n-3),segments=segments))
    # The old constructor is called verbatim in the infinite tail.
    for n in (106,115,117,391,700):
        for m in (2*n,3*n,n*(n-3)):
            assert construct(n,m)==previous.construct(n,m)
            count+=1
    sources=['src/main_interval_expanded.py','src/main_interval_half_density.py',
             'src/main_interval_layered.py','src/main_interval_composed.py',
             'src/core_code_all_parities.py','paper/main-interval-new-overlap.md']
    return dict(verified=True,method='Integer interval coverage and direct boundary adjacency; no game search.',
                finite_orders=[43,105],full_interval_from=104,above_three_n_from=43,
                boundary_constructions=count,plans=plans,
                source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('n',nargs='?',type=int);p.add_argument('m',nargs='?',type=int)
    p.add_argument('--check',action='store_true');p.add_argument('--out',type=Path)
    a=p.parse_args()
    result=checks() if a.check else construct(a.n,a.m)
    if a.out:a.out.write_text(json.dumps(result,indent=2)+'\n')
    else:print(json.dumps(result,indent=2))


if __name__=='__main__':main()

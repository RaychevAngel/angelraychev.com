#!/usr/bin/env python3
"""Generate and directly replay every endpoint40 surviving negative game.

Producer uses two established solvers; the literal reviewer imports neither.
This does not independently retraverse the enumeration tree.
"""
import hashlib
import itertools
import json
from pathlib import Path
from game_solver import solve_graph
from small_case_certificate_review import review

ROOT=Path(__file__).resolve().parents[1]
LOG="research/endpoint40_positive.jsonl"
NEGATIVE="research/endpoint40_negative_certificates.json"
LOWER="research/endpoint40_lower12_certificate.json"

def forced_witnesses(masks, count):
    rows=[{t for t in range(8) if masks[s]>>t&1} for s in range(8)]
    witnessed=set()
    for c in range(count):
        for s in range(count):
            if s!=c and rows[c]<=rows[s]|{s}:
                witnessed.update((s,t,c) for t in rows[s])
        for t in range(8):
            if all(v==t or (v<count and t in rows[v]) for v in rows[c]):
                witnessed.update((s,t,c) for s in range(count)
                                 if s!=c and t in rows[s])
    return witnessed

def main():
    records=[json.loads(line) for line in (ROOT/LOG).read_text().splitlines()]
    start,end=records[0],records[-1]
    assert start['kind']=='start' and end['kind']=='summary'
    assert end['complete_requested_profiles'] and not end['found'] and not end['timeout']
    assert start['first_profile']==0 and start['last_profile_exclusive']>=start['profile_count']
    expected=[p for p in itertools.combinations_with_replacement(range(1,8),8) if sum(p)==16]
    completed=[r for r in records if r['kind']=='profile']
    assert len(expected)==len(completed)==start['profile_count']==20
    assert [tuple(r['degrees']) for r in completed]==expected
    assert [r['profile'] for r in completed]==list(range(20))
    assert all(r['complete'] and not r['found'] and not r['timeout'] for r in completed)
    leaves=[r for r in records if r['kind']=='leaf']
    assert len(leaves)==end['leaves']==sum(r['leaves'] for r in completed)==158
    assert len({tuple(r['missing_masks']) for r in leaves})==158
    assert end['nodes']==sum(r['nodes'] for r in completed)
    graphs=[]; negative_checks=[]; prefix_count=witness_count=0
    for j,leaf in enumerate(leaves):
        masks=leaf['missing_masks']
        assert tuple(m.bit_count() for m in masks)==expected[leaf['profile']]
        assert all(not(masks[s]>>s&1) for s in range(8))
        arcs=[(s,t) for s in range(8) for t in range(8) if s!=t and not(masks[s]>>t&1)]
        graph=solve_graph(8,arcs,certificates=True,crosscheck=True)
        assert graph['m']==40 and graph['I']==leaf['I']<13
        graph['enumeration_leaf_index']=j
        graphs.append(graph); negative_checks.append(review(graph))
        for count in range(9):
            pairs=forced_witnesses(masks,count)
            if count==8: assert len({(s,t) for s,t,c in pairs})==leaf['forced_loss_count']
            for s,t,c in pairs:
                assert graph['certificates'][t]['rank'][2*(s*8+c)]==-1
            prefix_count+=1;witness_count+=len(pairs)
    (ROOT/NEGATIVE).write_text(json.dumps(graphs,separators=(',',':'))+'\n')
    saved=json.loads((ROOT/'research/small-case-fixed-certificates.json').read_text())
    lower=[g for g in saved if (g['n'],g['m'],g['I'])==(8,40,12)]
    assert len(lower)==1
    lower=lower[0]
    lower_check=review(lower)
    rerun=solve_graph(8,lower['arcs'],certificates=True,crosscheck=True)
    assert rerun['I']==12 and rerun['indirect_pairs']==lower['indirect_pairs']
    (ROOT/LOWER).write_text(json.dumps(lower,separators=(',',':'))+'\n')
    paths=[LOG,NEGATIVE,LOWER,'src/endpoint40_positive.cpp','src/endpoint40_certify.py',
           'src/game_solver.py','src/small_case_certificate_review.py',
           'research/small-case-fixed-certificates.json']
    receipt={'status':'passed','proposed_claim':'M(8,40)=12',
      'enumeration':'20 complete positive missing-degree profiles; chronological suffix normalization',
      'nodes':end['nodes'],'seconds':end['seconds'],'static_leaves':len(leaves),
      'negative_score_histogram':{str(i):sum(g['I']==i for g in graphs) for i in sorted({g['I'] for g in graphs})},
      'negative_alternating_state_obligations':sum(r['alternating_state_obligations'] for r in negative_checks),
      'prefixes_replayed':prefix_count,'explicit_camping_witnesses_replayed':witness_count,
      'lower12':lower_check,
      'boundary':'Complete producer traversal and direct full-game replay of every saved leaf. No independent traversal, ordinary source review, or Lean proof is claimed here.',
      'sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}}
    (ROOT/'research/endpoint40_literal_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Bounded literal lower-bound discovery. Does not edit any accepted registry."""
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import time

from small_plateau_probe import ROOT, evaluate, certificate
from small_case_certificate_review import review

TAG = 'finish_constructions'
TARGETS = {8: set(range(17,24)) | set(range(27,40)),
           9: set(range(19,24)), 10: set(range(19,28))}
RANGES = {8: (16,40), 9: (18,24), 10: (18,28)}


def save(name, data):
    path = ROOT / 'research' / f'{TAG}_{name}.json'
    path.write_text(json.dumps(data, indent=2)+'\n')
    return str(path.relative_to(ROOT))


def main(seconds, seed):
    start=time.monotonic(); rng=random.Random(seed); calls=0; pool={}; cache={}; events=[]
    universes={n:set(itertools.permutations(range(n),2)) for n in RANGES}
    def score(n, arcs):
        nonlocal calls
        key=(n,tuple(sorted(arcs)))
        if key not in cache:
            result=evaluate(n,arcs)
            cache[key]=result[:2]; calls+=1
        return cache[key]
    def add(n, arcs, why):
        arcs=frozenset(arcs); m=len(arcs)
        if n not in RANGES or not RANGES[n][0]<=m<=RANGES[n][1]: return
        value=score(n,arcs); key=(n,m); rows=pool.setdefault(key,[])
        if any(x['arcs']==arcs for x in rows): return
        previous=rows[0]['value'] if rows else (-1,-1)
        rows.append(dict(arcs=arcs,value=value,why=why))
        rows.sort(key=lambda x:(x['value'],tuple(sorted(x['arcs']))),reverse=True)
        del rows[4:]
        if value[0]>previous[0]:
            event=dict(n=n,m=m,I=value[0],seconds=round(time.monotonic()-start,3),why=why)
            events.append(event)
            if why!='saved_seed': print(json.dumps(event),flush=True)

    seeds=[]
    for name in ['small-exceptional-general-certificates.json',
                 'small-case-support-witnesses.json',
                 'small-dense-endpoint-certificates.json']:
        seeds.extend(json.loads((ROOT/'research'/name).read_text()))
    catalogue=json.loads((ROOT/'research/small-plateau-witness-catalogue.json').read_text())
    for row in catalogue['records']:
        seeds.append(json.loads((ROOT/row['certificate']).read_text()))
    stages=json.loads((ROOT/'research/small-plateau-small-stage-records.json').read_text())
    for row in stages['records']:
        for k in range(len(row['added'])+1):
            seeds.append(dict(n=row['n'],arcs=row['base_arcs']+row['added'][:k]))
    for g in seeds:
        arcs=set(map(tuple,g['arcs']))
        for n in RANGES:
            if g['n']<=n: add(n,arcs,'saved_seed')
    baseline={f'{n},{m}':rows[0]['value'][0] for (n,m),rows in pool.items()}

    # Hand-derived sink lifts are certified before any discovery loop.
    h7=next(g for g in seeds if g['n']==7 and len(g['arcs'])==21)
    h9=next(g for g in seeds if g['n']==9 and len(g['arcs'])==18)
    simple=[]
    for n,h,d,expected in [(8,h7,6,22),(8,h7,7,21),(10,h9,1,30)]:
        arcs=set(map(tuple,h['arcs'])); old=n-1
        if n==8 and d==6:
            s=next(s for s in range(old) if sum(a==s for a,b in arcs)<old-1)
            predecessors=[v for v in range(old) if v!=s]
        else: predecessors=list(range(d))
        new=arcs|{(v,old) for v in predecessors}
        g=certificate(n,new); receipt=review(g)
        assert g['I']==expected
        g['construction']={'kind':'fresh_sink','old_n':old,'predecessors':predecessors}
        simple.append(g); add(n,new,'hand_derived_sink_lift')
    simple_path=save('simple_sink_lifts',simple)
    save('simple_sink_review',dict(status='passed',graphs=[review(g) for g in simple],
             scope='Exact scores of literal graphs; no extremal upper bound.'))
    print(json.dumps(dict(simple_sink_lifts=simple_path,values=[(g['n'],g['m'],g['I']) for g in simple])),flush=True)

    # Every predecessor subset for two fixed cores is a finite family, not a
    # global graph enumeration. New source/sink possibilities use the full game.
    for h in [h7,h9]:
        n=h['n']+1; arcs=set(map(tuple,h['arcs']))
        for mask in range(1<<h['n']):
            add(n,arcs|{(v,n-1) for v in range(n-1) if mask>>v&1},'complete_fixed_core_sink_family')

    def checkpoint(phase):
        graphs=[]; rows=[]
        for (n,m), candidates in sorted(pool.items()):
            if m not in TARGETS.get(n,set()): continue
            best=candidates[0]; g=certificate(n,best['arcs']); rec=review(g)
            assert g['I']==best['value'][0]
            g['discovery']=best['why']; graphs.append(g)
            rows.append(dict(n=n,m=m,I=g['I'],baseline=baseline.get(f'{n},{m}'),
                             why=best['why'],review=rec))
        path=save('certificates',graphs)
        save('summary',dict(phase=phase,elapsed_seconds=time.monotonic()-start,
             exact_evaluations=calls,seed=seed,certificate_path=path,records=rows,
             source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             events=events,scope='Lower witnesses only; every literal graph has full winning and losing state ranks and independent direct replay. No global upper or extremal claim.'))
        print(json.dumps(dict(checkpoint=phase,seconds=round(time.monotonic()-start,2),calls=calls,
              values=[(r['n'],r['m'],r['I']) for r in rows])),flush=True)

    checkpoint('sink_families')
    # Two finite directed sweeps spread useful literals across adjacent budgets.
    for direction in [1,-1]:
        for n in RANGES:
            lo,hi=RANGES[n]
            ms=range(lo,hi) if direction==1 else range(hi,lo,-1)
            for m in ms:
                if time.monotonic()-start>seconds*.45: break
                for row in list(pool.get((n,m),[]))[:2]:
                    arcs=row['arcs']; options=universes[n]-arcs if direction==1 else arcs
                    for e in sorted(options):
                        child=arcs|{e} if direction==1 else arcs-{e}
                        if (n,len(child))==(8,40): continue
                        add(n,child,f'adjacent_literal_{n}_{m}')
    checkpoint('adjacent_sweeps')

    cells=[(n,m) for n,ms in TARGETS.items() for m in sorted(ms) if (n,m) in pool]
    # Fixed per-cell slices, one pass only. Keep degree-preserving mutations
    # alongside ordinary swaps; winning-state count breaks score ties.
    per=max(0,(seconds-(time.monotonic()-start))/max(1,len(cells)))
    for n,m in cells:
        stop=min(start+seconds,time.monotonic()+per); rows=pool[(n,m)]
        current=set(rows[0]['arcs']); cv=score(n,current); iteration=0
        maxstates=n*(n-1)*(n-1)
        while time.monotonic()<stop:
            iteration+=1
            if iteration%750==0:
                current=set(rng.choice(pool[(n,m)])['arcs']); cv=score(n,current)
            candidate=set(current); e=rng.choice(tuple(sorted(candidate))); mode=rng.randrange(4)
            if mode==0:
                f=rng.choice(tuple(sorted(candidate))); new={(e[0],f[1]),(f[0],e[1])}
                if e==f or len(new)!=2 or any(s==t for s,t in new) or new&candidate: continue
                candidate.difference_update([e,f]); candidate.update(new)
            else:
                candidate.remove(e); choices=universes[n]-candidate
                if mode==1: choices={f for f in choices if f[0]==e[0]}
                if mode==2: choices={f for f in choices if f[1]==e[1]}
                if not choices: continue
                candidate.add(rng.choice(tuple(sorted(choices))))
            value=score(n,candidate)
            delta=value[0]-cv[0]+(value[1]-cv[1])/maxstates
            temp=.5*(1-(iteration%750)/750)**2+.015
            if delta>=0 or rng.random()<math.exp(max(-700,delta/temp)):
                current=candidate;cv=value
            if value>pool[(n,m)][-1]['value'] or len(pool[(n,m)])<4:
                add(n,candidate,'one_bounded_local_slice')
        if time.monotonic()>=start+seconds: break
    checkpoint('complete_bounded_pass')


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--seconds',type=float,default=180)
    p.add_argument('--seed',type=int,default=2026091301); args=p.parse_args()
    main(args.seconds,args.seed)

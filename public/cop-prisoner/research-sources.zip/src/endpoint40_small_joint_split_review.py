#!/usr/bin/env python3
"""Review a disjoint complete split of a small-defect coupled-pattern inventory."""
import argparse,hashlib,json,subprocess
from pathlib import Path
from endpoint40_small_joint_review import independent_patterns
from small_case_certificate_review import review
ROOT=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('n',type=int);p.add_argument('m',type=int);p.add_argument('value',type=int)
 p.add_argument('lower');p.add_argument('parts',nargs='+');a=p.parse_args();n,m,v=a.n,a.m,a.value;T=v+1
 assert T>0 and n*(n-1)-m-T<n-2
 stem=f'endpoint40_joint_n{n}_m{m}_t{T}'
 inputfile=f'research/{stem}.json';inputs=json.loads((ROOT/inputfile).read_text())
 pats=[tuple(map(tuple,row)) for row in inputs['joint_patterns']]
 assert len(pats)==len(set(pats)) and set(pats)==independent_patterns(n,m)
 previous=json.loads((ROOT/'research/endpoint40_joint_n9_m23_t45_receipt.json').read_text())
 for f in ('src/endpoint40_small_joint.cpp','src/endpoint40_small_joint_prune_review.cpp',
           'research/endpoint40_small_joint_prune_review_tests.json','research/endpoint40_small_joint_proof.md'):
  assert sha(ROOT/f)==previous['sha256'][f]
 files=[inputfile,'src/endpoint40_small_joint_split_review.py','src/endpoint40_small_joint_review.py',
        'src/endpoint40_small_joint.cpp','src/endpoint40_small_leaf_replay.cpp','src/small_case_certificate_review.py',
        'research/endpoint40_small_joint_proof.md','research/endpoint40_joint_n9_m23_t45_receipt.json',a.lower]
 ranges=[];covered=[];runs=[];logs=[]
 for part in a.parts:
  name=f'research/{stem}_{part}';files.extend([name+'.json',name+'.txt',name+'_run.jsonl'])
  metadata=json.loads((ROOT/(name+'.json')).read_text());first,last=metadata['first'],metadata['last_exclusive']
  assert metadata['parent_pattern_file']==inputfile
  assert [tuple(map(tuple,row)) for row in metadata['joint_patterns']]==pats[first:last]
  text=list(map(int,(ROOT/(name+'.txt')).read_text().split()))
  assert text==[last-first]+[x for row in pats[first:last] for pair in row for x in pair]
  rows=[json.loads(line) for line in (ROOT/(name+'_run.jsonl')).read_text().splitlines()];end=rows[-1]
  assert (end['n'],end['m'],end['threshold'],end['mode'])==(n,m,v,0)
  assert end['complete'] and not end['counterexample_found']
  assert end['degree_patterns']==end['total_degree_patterns']==last-first
  assert end['game_decisions']==len(rows)-1
  covered+=list(range(first,last));ranges.append([first,last]);runs.append(end);logs.append(name+'_run.jsonl')
 assert covered==list(range(len(pats)))
 run=subprocess.run([str(ROOT/'src/endpoint40_small_leaf_replay.bin'),*logs],cwd=ROOT,text=True,capture_output=True,check=True)
 replays=[json.loads(line) for line in run.stdout.splitlines()]
 assert [r['path'] for r in replays]==logs
 assert all(r['status']=='passed' and r['target_I']==T and r['n']==n and r['m']==m for r in replays)
 replayfile=f'research/{stem}_split_leaf_replay.jsonl';(ROOT/replayfile).write_text(run.stdout);files.append(replayfile)
 lower=json.loads((ROOT/a.lower).read_text());assert (lower['n'],lower['m'],lower['I'])==(n,m,v)
 lower_review=review(lower)
 result={'verified':True,'n':n,'m':m,'M':v,'target_excluded':T,'independent_joint_patterns':len(pats),
  'complete_disjoint_pattern_ranges':ranges,'primary_runs':runs,'every_leaf_replays':replays,
  'lower':lower_review,'historical_incomplete_pilot':f'research/{stem}_run.jsonl',
  'boundary':'Complete disjoint joint-pattern inventory with the frozen reviewed ordinary engine; every literal leaf independently replayed and full matching lower ranks. The timed-out pilot is not used. No second complete traversal or Lean claim.',
  'sha256':{f:sha(ROOT/f) for f in files}}
 (ROOT/'research'/f'{stem}_split_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ('verified','n','m','M','independent_joint_patterns','complete_disjoint_pattern_ranges','every_leaf_replays','lower')},indent=2))
if __name__=='__main__':main()

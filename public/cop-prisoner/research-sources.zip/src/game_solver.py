#!/usr/bin/env python3
"""Exact visible messenger/pursuer reachability game, with terminal receipt.

Vertices are 0..n-1. Input arcs are directed, loopless; both players may wait.
The messenger moves first and must deliver in finite time. The pursuer cannot
prevent receipt at the target even when occupying it. Initial c != source.

The fast implementation eliminates pursuer turns by universal quantification.
The independent implementation constructs the explicit alternating game graph.
No third-party dependencies.  This is an executable verifier, not Lean code.
"""
from __future__ import annotations

import argparse
import collections
import json
from pathlib import Path


def neighborhoods(n: int, arcs):
    if n < 0:
        raise ValueError("negative vertex count")
    out = [1 << v for v in range(n)]
    clean = set()
    for u, v in arcs:
        if not 0 <= u < n or not 0 <= v < n or u == v:
            raise ValueError(f"not a loopless arc: {(u,v)}")
        out[u] |= 1 << v
        clean.add((u, v))
    return out, sorted(clean)


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask -= bit


def recipient_fast(n, out, target, retain_layers=False):
    """Win[r] is the mask of winning pursuer positions on messenger turn.

    Layer k permits at most k messenger moves. A nonterminal successor v is
    safe exactly when every legal pursuer successor is in the preceding layer
    at v. Winning r==target states seed the least, not greatest, fixed point.
    """
    allv = (1 << n) - 1
    wins = [0] * n
    wins[target] = allv
    layers = [wins[:]] if retain_layers else None
    while True:
        safe = [0] * n
        for v in range(n):
            if v == target:
                safe[v] = allv
            else:
                w = wins[v]
                safe[v] = sum(1 << c for c in range(n) if out[c] & ~w == 0)
        updated = []
        for r in range(n):
            if r == target:
                updated.append(allv)
                continue
            w = 0
            for v in bits(out[r]):
                w |= safe[v]
            updated.append(w & (allv ^ (1 << r)))
        if updated == wins:
            return wins, layers
        assert all(a & ~b == 0 for a, b in zip(wins, updated))
        wins = updated
        if retain_layers:
            layers.append(wins[:])


def recipient_explicit(n, out, target, certificate=False):
    """Independent explicit alternating-game attractor with positional moves.

    State id = 2*(r*n+c)+turn, turn 0 messenger, 1 pursuer. Success states
    r==target are terminal even on collision; other collisions are failure.
    A messenger state enters on one winning successor; a pursuer state only
    after every legal successor has entered. Infinite residual play loses.
    """
    size = 2*n*n
    reverse = [[] for _ in range(size)]
    remaining = [0]*size
    rank = [-1]*size
    move = [-1]*size
    max_child_rank = [0]*size
    queue = collections.deque()
    def sid(r, c, turn):
        return 2*(r*n+c)+turn
    for r in range(n):
        for c in range(n):
            if r == target:
                for turn in (0, 1):
                    s = sid(r,c,turn)
                    rank[s] = 0
                    queue.append(s)
            elif r != c:
                s = sid(r,c,0)
                for v in bits(out[r]):
                    reverse[sid(v,c,1)].append(s)
                    remaining[s] += 1
                s = sid(r,c,1)
                for v in bits(out[c]):
                    reverse[sid(r,v,0)].append(s)
                    remaining[s] += 1
    while queue:
        child = queue.popleft()
        for parent in reverse[child]:
            if rank[parent] >= 0:
                continue
            if parent % 2 == 0:
                rank[parent] = rank[child]+1
                move[parent] = child
                queue.append(parent)
            else:
                remaining[parent] -= 1
                max_child_rank[parent] = max(max_child_rank[parent], rank[child])
                if remaining[parent] == 0:
                    rank[parent] = max_child_rank[parent]+1
                    queue.append(parent)
    wins = [sum(1 << c for c in range(n) if rank[sid(r,c,0)] >= 0)
            for r in range(n)]
    if not certificate:
        return wins, None
    cert = {"target": target, "rank": rank, "messenger_successor": move}
    verify_certificate(n, out, cert)
    return wins, cert


def verify_certificate(n, out, cert):
    """Check both winning and losing regions directly against legal actions.

    Winning messenger moves decrease rank; all winning pursuer responses
    decrease rank. Every losing messenger action remains losing, and every
    nonterminal losing pursuer state has a losing successor. Thus absence
    of a rank proves a pursuer avoidance strategy, not just solver failure.
    """
    t, rank, move = cert["target"], cert["rank"], cert["messenger_successor"]
    assert len(rank) == len(move) == 2*n*n
    for r in range(n):
        for c in range(n):
            for turn in (0,1):
                s = 2*(r*n+c)+turn
                if r == t:
                    assert rank[s] == 0
                    continue
                if r == c:
                    assert rank[s] == -1
                    continue
                succ = ([2*(v*n+c)+1 for v in bits(out[r])] if turn == 0
                        else [2*(r*n+v) for v in bits(out[c])])
                if rank[s] >= 0:
                    if turn == 0:
                        assert move[s] in succ
                        assert 0 <= rank[move[s]] < rank[s]
                    else:
                        assert all(0 <= rank[z] < rank[s] for z in succ)
                elif turn == 0:
                    assert all(rank[z] < 0 for z in succ)
                else:
                    assert any(rank[z] < 0 for z in succ)
    return True


def solve_graph(n, arcs, method="fast", certificates=False, crosscheck=False):
    out, arcs = neighborhoods(n, arcs)
    recipients, certs, max_moves = [], [], 0
    for t in range(n):
        if method == "fast":
            wins, layers = recipient_fast(n, out, t, retain_layers=True)
            max_moves = max(max_moves, len(layers)-1)
            if crosscheck or certificates:
                other, cert = recipient_explicit(n,out,t,certificate=certificates)
                assert wins == other, (t,wins,other)
        elif method == "explicit":
            wins, cert = recipient_explicit(n,out,t,certificate=certificates)
        else:
            raise ValueError(method)
        recipients.append(wins)
        if certificates:
            certs.append(cert)
    allv = (1 << n)-1
    W = [[recipients[t][s] & (allv ^ (1 << s)) == allv ^ (1 << s)
          for t in range(n)] for s in range(n)]
    indirect = [[s,t] for s in range(n) for t in range(n)
                if s != t and not (out[s] >> t & 1) and W[s][t]]
    result = {"n":n,"m":len(arcs),"arcs":[list(e) for e in arcs],
              "I":len(indirect),"W":W,"indirect_pairs":indirect,
              "winning_pursuer_masks_by_target":recipients,
              "max_state_delivery_moves":max_moves if method == "fast" else None}
    assert sum(map(sum,W)) == n + len(arcs) + len(indirect)
    if certificates:
        result["certificates"] = certs
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph", type=Path, help="JSON containing n and arcs")
    parser.add_argument("--certificates", action="store_true")
    parser.add_argument("--crosscheck", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    graph = json.loads(args.graph.read_text())
    result = solve_graph(graph["n"],graph["arcs"],certificates=args.certificates,
                         crosscheck=args.crosscheck)
    text = json.dumps(result,indent=2)+"\n"
    if args.out:
        args.out.write_text(text)
    else:
        print(text,end="")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Read-only publication audit, independent of the publication builder.

Uses Python's standard library. No solvers, compiler, rendering, archive
extraction, network calls, or receipt writes are performed.

    python3 src/audit_publication_artifacts.py --sources-only
    python3 src/audit_publication_artifacts.py
    python3 src/audit_publication_artifacts.py --public-dir /path/to/staged/cop-prisoner

This checks identities, inventory and specified dependency closure. It does
not re-prove mathematics, replay strategy ranks, or verify a live deployment.
"""
from __future__ import annotations

import argparse
import ast
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile


ROOT = Path(__file__).resolve().parents[1]
HEX = re.compile(r"[0-9a-f]{64}")
BRIDGE_CERTIFICATES = {
    "research/sparse-finite-bridge-certificates.jsonl.gz",
    "research/odd-endpoint-finite-bridge-certificates.jsonl.gz",
}
PATH_LIST_FIELDS = {
    "authority_paths", "proof_paths", "checker_paths", "certificate_paths",
    "receipt_paths", "paths", "current_evidence_paths", "manifest_paths", "finite_certificate_paths",
    "lean_provenance_paths",
}
ARCHIVES = {
    "research-sources.zip", "finite-strategy-certificates.zip",
    "lean-proofs.zip", "manuscript-source.zip", "delivery-time-source.zip",
}
JUNK_PARTS = {".git", "__pycache__", "node_modules", "__MACOSX", ".tools"}
JUNK_SUFFIXES = {".pyc", ".pyo", ".olean", ".o", ".so", ".dylib", ".exe",
                 ".aux", ".log", ".toc", ".out"}
POST_RELEASE_NOTES = {"HANDOFF.md", "RESEARCH_LOG.md"}


class AuditFailure(Exception):
    pass


def need(condition, message):
    if not condition:
        raise AuditFailure(message)


def relative(name):
    need(isinstance(name, str) and bool(name), f"Invalid relative path: {name!r}")
    path = PurePosixPath(name)
    need(not path.is_absolute() and ".." not in path.parts and "\\" not in name,
         f"Unsafe relative path: {name}")
    need(str(path) == name and name != ".", f"Noncanonical relative path: {name}")
    return path


def file_at(root, name):
    relative(name)
    path = root / name
    need(path.is_file() and not path.is_symlink(), f"Missing or symlinked file: {path}")
    return path


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def json_file(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError) as exc:
        raise AuditFailure(f"Cannot read JSON {path}: {exc}") from exc


def indexed_paths(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in PATH_LIST_FIELDS:
                need(isinstance(child, list), f"Index field {key} must be a path list")
                for name in child:
                    relative(name)
                    yield name
            else:
                yield from indexed_paths(child)
    elif isinstance(value, list):
        for child in value:
            yield from indexed_paths(child)


def path_pins(value, field=()):
    """Every SHA256 string keyed by a repository-relative path, at any depth."""
    if isinstance(value, dict):
        for key, child in value.items():
            location = field + (key,)
            if "/" in key and isinstance(child, str) and HEX.fullmatch(child):
                relative(key)
                yield location, key, child
            yield from path_pins(child, location)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            yield from path_pins(child, field + (i,))


def scientific_log_paths(root, index):
    """Allow only explicitly named research logs pinned by named frozen manifests."""
    policy = index.get("scientific_log_archive", {})
    manifests = policy.get("manifest_paths", [])
    declared = policy.get("paths", [])
    need(len(manifests) == len(set(manifests)), "Duplicate scientific-log manifest")
    need(len(declared) == len(set(declared)), "Duplicate scientific-log allowance")
    pins = {}
    for name in manifests:
        relative(name)
        need(name.startswith("research/") and name.endswith(".json"),
             f"Scientific-log manifest is not a research JSON: {name}")
        found = False
        for _, source, expected in path_pins(json_file(file_at(root, name))):
            if PurePosixPath(source).suffix != ".log":
                continue
            found = True
            need(source.startswith("research/") and
                 not set(PurePosixPath(source).parts) & JUNK_PARTS,
                 f"Scientific log is outside the research inventory: {source}")
            need(source not in pins or pins[source] == expected,
                 f"Scientific-log manifests disagree: {source}")
            pins[source] = expected
        need(found, f"Named scientific-log manifest pins no log: {name}")
    need(set(declared) == set(pins),
         "Explicit scientific logs differ from the named manifests' log inventory")
    for name, expected in pins.items():
        need(digest(file_at(root, name)) == expected,
             f"Scientific log differs from its frozen manifest: {name}")
    return set(declared)


def finite_certificate_paths(root, index):
    """Check the explicit archive partition and supported lossless compression."""
    layout = index.get("archive_layout", {})
    names = layout.get("finite_certificate_paths", [])
    need(len(names) == len(set(names)), "Duplicate finite archive path")
    need(BRIDGE_CERTIFICATES <= set(names), "Finite archive omits a retained bridge certificate")
    for name in names:
        relative(name)
        need(name.startswith("research/") and name.endswith(".gz"),
             f"Finite archive path is not a compressed research certificate: {name}")
        file_at(root, name)
    need(layout.get("bzip2_suffixes") == [".json", ".jsonl", ".log"] and
         layout.get("bzip2_minimum_bytes") == 10000,
         "Unreviewed research-text compression policy")
    need(layout.get("maximum_download_bytes") == 100 * 1024 * 1024,
         "Unreviewed hosting file-size limit")
    return set(names)


def lean_provenance_paths(root, index):
    """Retained formal-production evidence, separate from replayed Lean modules."""
    names = index.get("archive_layout", {}).get("lean_provenance_paths", [])
    need(len(names) == len(set(names)), "Duplicate Lean provenance path")
    need(not set(names) & set(index.get("unpublished_research_notes", [])),
         "Private research note included as formal provenance")
    need(not set(names) & set(index.get("archive_layout", {}).get("finite_certificate_paths", [])),
         "Formal provenance overlaps the finite certificate archive")
    for name in names:
        relative(name)
        need(name not in {"research/publication-build.json", "research/website-deployment.json"},
             f"Mutable release metadata cannot be formal provenance: {name}")
        need(name.startswith("research/") and PurePosixPath(name).suffix in {".json", ".md", ".gz", ".txt"},
             f"Unexpected formal provenance file: {name}")
        file_at(root, name)
    return set(names)


def lean_names(root, receipt):
    need(receipt.get("all_passed") is True, "Lean receipt does not report all_passed")
    pins = receipt.get("source_sha256")
    need(isinstance(pins, dict) and bool(pins), "Lean source pins are missing")
    for name, expected in pins.items():
        need("/" not in name, f"Unexpected Lean source pin path: {name}")
        need(isinstance(expected, str) and HEX.fullmatch(expected), f"Invalid Lean hash: {name}")
        need(digest(file_at(root, "lean/" + name)) == expected,
             f"Current Lean source hash mismatch: lean/{name}; no historical exception applies")
    sources = {p.name for p in (root / "lean").glob("*.lean")}
    pinned_modules = {name for name in pins if name.endswith(".lean")}
    need(sources == pinned_modules, "Lean modules and pinned source inventory differ")
    records = receipt.get("modules", [])
    need({r["module"] + ".lean" for r in records} == sources,
         "Lean run records do not cover the current modules")
    need(all(r.get("exit_code") == 0 for r in records), "A Lean module has a failed exit code")
    names = {"lean/" + name for name in pins} | {"lean/verification.json"}
    return names


def audit_sources(root):
    index = json_file(file_at(root, "publication/evidence-index.json"))
    paths = set(indexed_paths(index))
    logs = scientific_log_paths(root, index)
    finite_paths = finite_certificate_paths(root, index)
    lean_provenance_paths(root, index)
    for name in sorted(paths):
        file_at(root, name)
    commands = index.get("commands", [])
    command_ids = set()
    for command in commands:
        command_id = command["id"]
        need(command_id not in command_ids, f"Duplicate command id: {command_id}")
        command_ids.add(command_id)
        argv = command["argv"]
        need(len(argv) >= 2 and argv[0] == "python3", f"Unsupported command form: {command_id}")
        script = file_at(root, argv[1])
        tree = ast.parse(script.read_text(), filename=str(script))
        flags = {
            argument.value
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
            and node.func.attr == "add_argument"
            for argument in node.args
            if isinstance(argument, ast.Constant) and isinstance(argument.value, str)
            and argument.value.startswith("-")
        }
        need(all(arg in flags for arg in argv[2:] if arg.startswith("-")),
             f"Index command contains an unsupported argument: {command_id}")
    for result in index["results"]:
        need(set(result["command_ids"]) <= command_ids,
             f"Unknown command id in result: {result['id']}")

    exceptions = {}
    for entry in index.get("expected_historical_hash_mismatches", []):
        receipt = entry["receipt_path"]
        source = entry["source_path"]
        fields = tuple(entry["field_path"])
        key = (receipt, fields, source)
        need(key not in exceptions, f"Duplicate historical exception: {key}")
        original = json_file(file_at(root, receipt))
        try:
            for part in fields:
                original = original[part]
        except (KeyError, IndexError, TypeError) as exc:
            raise AuditFailure(f"Historical receipt field disappeared: {key}") from exc
        need(original == entry["recorded_sha256"],
             f"Original historical receipt hash was changed: {key}")
        actual = digest(file_at(root, source))
        need(actual == entry["observed_current_sha256"],
             f"Source changed beyond the reviewed historical exception: {source}")
        need(actual != original, f"Historical exception is no longer a mismatch: {key}")
        exceptions[key] = entry

    pin_count = 0
    seen = set()
    for folder in ("research", "lean", "publication"):
        for receipt in sorted((root / folder).rglob("*.json")):
            data = json_file(receipt)
            for fields, source, expected in path_pins(data):
                pin_count += 1
                actual = digest(file_at(root, source))
                if actual == expected:
                    continue
                key = (receipt.relative_to(root).as_posix(), fields, source)
                need(key in exceptions,
                     f"Unclassified SHA256 mismatch: {key[0]} field {fields} -> {source}")
                need(expected == exceptions[key]["recorded_sha256"],
                     f"Historical pin no longer matches its explicit exception: {key}")
                seen.add(key)
    need(seen == set(exceptions), "Historical exceptions do not match the scanned pin set")
    lean = json_file(file_at(root, "lean/verification.json"))
    lean_files = lean_names(root, lean)
    return index, paths, lean_files, {
        "referenced_paths": len(paths),
        "command_forms_checked": len(commands),
        "path_keyed_pins_checked": pin_count,
        "explicit_historical_mismatches": len(seen),
        "lean_source_pins_checked": len(lean["source_sha256"]),
        "manifest_pinned_scientific_logs": len(logs),
        "separate_finite_certificate_files": len(finite_paths),
    }


def zip_digest(archive, name):
    h = hashlib.sha256()
    with archive.open(name) as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def zip_inventory(archive, allowed_scientific_logs=frozenset()):
    names = set()
    for item in archive.infolist():
        name = item.filename.rstrip("/") if item.is_dir() else item.filename
        relative(name)
        need(name not in names, f"Duplicate ZIP entry in {archive.filename}: {name}")
        names.add(name)
        mode = item.external_attr >> 16
        need(not stat.S_ISLNK(mode), f"Symlink in ZIP {archive.filename}: {name}")
        parts = PurePosixPath(name).parts
        need(not set(parts) & JUNK_PARTS and ".DS_Store" not in parts,
             f"Unwanted generated/operational content in ZIP: {name}")
        suffix = PurePosixPath(name).suffix
        need(suffix not in JUNK_SUFFIXES or
             (suffix == ".log" and name in allowed_scientific_logs),
             f"Compiled or build-junk file in source ZIP: {name}")
        need(not name.startswith(("tmp/", "output/")),
             f"Temporary or generated output directory in source ZIP: {name}")
    return {i.filename for i in archive.infolist() if not i.is_dir()}


def figure_names(root):
    text = file_at(root, "paper/assembled.md").read_text()
    paths = set(re.findall(r"!\[[^\]]*\]\((figures/[^\s)]+)", text))
    need(bool(paths), "No manuscript figures found in paper/assembled.md")
    need(all(PurePosixPath(name).suffix == ".pdf" for name in paths),
         "Unexpected manuscript figure format")
    return paths


def check_metadata(name, metadata, path):
    need(isinstance(metadata, dict), f"Missing metadata for asset: {name}")
    need(metadata.get("bytes") == path.stat().st_size, f"Asset size mismatch: {name}")
    need(metadata.get("sha256") == digest(path), f"Asset SHA256 mismatch: {name}")


def audit_release(root, public, index, required_paths, lean_files, staged=False):
    manifest = json_file(file_at(root, "publication/manifest.json"))
    release = json_file(file_at(public, "release.json"))
    downloads = set(manifest["downloads"])
    need(len(downloads) == len(manifest["downloads"]), "Duplicate configured download")
    need(ARCHIVES <= downloads, "Publication manifest omits a required source archive")
    figures = figure_names(root)
    assets = {name[:-4] + ".svg" for name in figures}
    assets |= {name for name in lean_files}
    expected = downloads | assets
    actual = set()
    for path in public.rglob("*"):
        need(not path.is_symlink(), f"Symlink in public artifact tree: {path}")
        if path.is_file():
            actual.add(path.relative_to(public).as_posix())
    need(actual == expected | {"release.json"},
         f"Public inventory mismatch; missing={sorted((expected | {'release.json'}) - actual)}, "
         f"unexpected={sorted(actual - expected - {'release.json'})}")
    for name in index.get("unpublished_research_notes", []):
        relative(name)
        with zipfile.ZipFile(public / "research-sources.zip") as research_zip:
            need(name not in research_zip.namelist(), f"Private working note in release archive: {name}")
    files = release.get("files", {})
    served = release.get("assets", {})
    need(set(files) == downloads, "release.files does not match the configured download inventory")
    need(set(served) == expected, "release.assets must hash every served asset except release.json")
    for name in sorted(expected):
        path = file_at(public, name)
        check_metadata(name, served[name], path)
        if name in downloads:
            check_metadata(name, files[name], path)
    for name, source in manifest.get("static_assets", {}).items():
        need(name in expected, f"Static asset is not in the public inventory: {name}")
        need(digest(file_at(root, source)) == digest(file_at(public, name)),
             f"Static public asset differs from its source: {name}")
    for name in lean_files:
        need(digest(file_at(root, name)) == digest(file_at(public, name)),
             f"Loose Lean asset differs from its source: {name}")
    need(digest(file_at(public, "lean-verification.json")) ==
         digest(file_at(root, "lean/verification.json")), "Public Lean receipt differs")
    for name in figures:
        svg = name[:-4] + ".svg"
        need(digest(file_at(root, "paper/" + svg)) == digest(file_at(public, svg)),
             f"Public figure differs from its source: {svg}")
    need(digest(file_at(public, "references.bib")) ==
         digest(file_at(root, "paper/references.bib")), "Public bibliography differs")
    pdf = file_at(public, "guaranteed-indirect-delivery.pdf")
    verification = json_file(file_at(root, "research/pdf-verification.json"))
    need(verification.get("pdf_sha256") == digest(pdf), "PDF receipt pins a different PDF")
    need(verification.get("pages") == release.get("pages"), "PDF page-count receipts differ")
    need(verification.get("all_figures_present") == len(figures) == release.get("figures"),
         "Figure counts disagree between manuscript and release receipts")
    need(verification.get("standalone_source_recompiled") is True and
         verification.get("text_matches_published_pdf") is True,
         "PDF receipt does not establish the stated standalone-source text replay")
    need(not release.get("pdf_overfull_warnings"), "Release records overfull PDF warnings")
    visual = json_file(file_at(root, "research/pdf-visual-review.json"))
    need(visual.get("all_pages_visually_reviewed") is True and
         visual.get("main", {}).get("pdf_sha256") == digest(pdf) and
         visual.get("main", {}).get("pages") == release.get("pages"),
         "Visual acceptance is missing or belongs to a different main PDF")
    for spec in manifest.get('companions', []):
        companion = release.get('companions', {}).get(spec['id'], {})
        need(companion.get('pdf_sha256') == digest(file_at(public, spec['pdf'])),
             'Companion receipt pins a different PDF')
        need(companion.get('standalone_source_recompiled') is True and
             companion.get('text_matches_published_pdf') is True and
             companion.get('no_overfull_boxes') is True,
             'Companion PDF replay or layout check failed')
        need(companion == json_file(file_at(root, 'research/delivery-time-pdf-verification.json')),
             'Companion PDF verification receipts differ')
    if not staged:
        build = json_file(file_at(root, "research/publication-build.json"))
        need(build == release, "Local publication-build receipt differs from public release.json")

    warnings = []
    with ExitStack() as stack:
        archives = {name: stack.enter_context(zipfile.ZipFile(file_at(public, name)))
                    for name in sorted(ARCHIVES)}
        scientific_logs = scientific_log_paths(root, index)
        finite_paths = finite_certificate_paths(root, index)
        formal_provenance = lean_provenance_paths(root, index)
        for name in manifest["downloads"]:
            need(file_at(public, name).stat().st_size <= index["archive_layout"]["maximum_download_bytes"],
                 f"Download exceeds the hosting file-size limit: {name}")
        inventories = {name: zip_inventory(z, scientific_logs if name == "research-sources.zip"
                                            else frozenset())
                       for name, z in archives.items()}
        research = inventories["research-sources.zip"]
        finite = inventories["finite-strategy-certificates.zip"]
        lean = inventories["lean-proofs.zip"]
        manuscript = inventories["manuscript-source.zip"]
        need(finite == finite_paths, "Finite archive differs from the explicit certificate partition")
        need(not research & finite_paths, "Large finite ranks duplicated in research archive")
        need(lean == lean_files | formal_provenance,
             "Lean ZIP differs from the pinned sources and explicit provenance partition")
        expected_manuscript = {"main.tex", "references.bib"} | figures
        need(manuscript == expected_manuscript,
             "Standalone manuscript ZIP has missing figures or unexpected contents")
        need(inventories['delivery-time-source.zip'] == {'main.tex', 'references.bib'},
             'Companion source ZIP inventory differs')
        need(not ({"research/publication-build.json", "research/website-deployment.json"} & research),
             "Research archive contains mutable/circular release or deployment metadata")
        need(not research & lean, "Lean sources duplicated in research archive")
        need(required_paths <= research | finite | lean,
             f"Evidence index dependencies missing from archives: {sorted(required_paths - research - finite - lean)}")
        need({name for name in research if PurePosixPath(name).suffix == ".log"} == scientific_logs,
             "Research archive must contain exactly the manifest-pinned scientific logs")
        required_publication = {"publication/manifest.json", "publication/evidence-index.json",
                                "publication/EVIDENCE_GUIDE.md", "publication/explorer-graphs.json"}
        need(required_publication <= research, "Research archive omits publication source metadata")
        need("START_HERE.md" in research, "Research archive is missing its START_HERE.md entry guide")
        need({"paper/" + name for name in figures} <= research,
             "Research archive omits manuscript PDF figures")
        need({"paper/" + name[:-4] + ".svg" for name in figures} <= research,
             "Research archive omits manuscript SVG figures")
        source_programs = {p.relative_to(root).as_posix() for p in (root / "src").iterdir()
                           if p.is_file() and p.suffix in {".py", ".cpp", ".hpp"}}
        need(source_programs <= research, "Research archive omits current source programs")
        history = {p.relative_to(root).as_posix() for p in (root / "research/history").rglob("*.md")}
        need(history <= research, "Research archive omits retained historical manuscript arguments")
        aliases = {"START_HERE.md": "publication/EVIDENCE_GUIDE.md"}
        for archive_name, archive in archives.items():
            for name in sorted(inventories[archive_name]):
                item = archive.getinfo(name)
                use_bzip2 = (archive_name == "research-sources.zip" and
                             name.startswith("research/") and
                             PurePosixPath(name).suffix in {".json", ".jsonl", ".log"} and
                             item.file_size >= 10000)
                need(item.compress_type == (zipfile.ZIP_BZIP2 if use_bzip2 else zipfile.ZIP_DEFLATED),
                     f"Archive member uses an unreviewed compression method: {archive_name}:{name}")
                if archive_name == 'delivery-time-source.zip':
                    source_name = 'paper/delivery-time.tex' if name == 'main.tex' else 'paper/' + name
                else:
                    source_name = "paper/" + name if archive_name == "manuscript-source.zip" else aliases.get(name, name)
                source = file_at(root, source_name)
                matches = zip_digest(archive, name) == digest(source)
                if not matches and archive_name == "research-sources.zip" and name in POST_RELEASE_NOTES:
                    archived_note = archive.read(name)
                    need(source.read_bytes().startswith(archived_note),
                         f"Archived note was revised rather than appended: {name}")
                    warnings.append(f"{name} has appended post-archive text; its archived content is an "
                                    "unchanged prefix. The appended text is not part of this release.")
                else:
                    need(matches, f"Archived file differs from current source: {archive_name}:{name}")
        tex = archives["manuscript-source.zip"].read("main.tex").decode()
        includes = re.findall(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}", tex)
        for name in includes:
            candidates = {name, name + ".pdf"}
            need(bool(candidates & manuscript), f"Standalone LaTeX graphic dependency absent: {name}")
        need(len(includes) == len(figures), "Standalone LaTeX figure references disagree with manuscript")
        summary = {name: len(paths) for name, paths in inventories.items()}
    return {"served_files_hashed": len(expected), "archive_entries": summary,
            "warnings": warnings,
            "limits": "Identity/dependency audit only; no solver, PDF rendering, formal replay, or live deployment check."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT, help="Research repository root")
    parser.add_argument("--public-dir", type=Path, help="Staged/cop-prisoner public asset directory")
    parser.add_argument("--staged", action="store_true",
                        help="Before installation, omit comparison to the previous installed build receipt")
    parser.add_argument("--sources-only", action="store_true",
                        help="Check current paths, command forms and source pins without inspecting a release")
    args = parser.parse_args()
    root = args.root.resolve()
    try:
        index, paths, lean_files, result = audit_sources(root)
        result["mode"] = "sources_only" if args.sources_only else "full_artifact_audit"
        if not args.sources_only:
            public = (args.public_dir or root / ".site-worktree/public/cop-prisoner").resolve()
            result["release"] = audit_release(root, public, index, paths, lean_files, staged=args.staged)
        result["passed"] = True
        print(json.dumps(result, indent=2))
        return 0
    except (AuditFailure, OSError, ValueError, KeyError, TypeError, SyntaxError,
            zipfile.BadZipFile, zipfile.LargeZipFile) as exc:
        print(json.dumps({"passed": False, "error": str(exc)}, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

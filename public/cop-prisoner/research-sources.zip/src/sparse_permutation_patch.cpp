// Two-permutation finite-patch search. The first permutation is a fixed
// Hamilton cycle; only second-permutation destination swaps are permitted.
// Adapted from the independent expanded-defect search with the same objective.
// Input matches five_type_defect_search.cpp with backbone k=8 labels. Changes
// are confined to listed core source rows; indegree and outdegree stay two.
// M columns[-11,10], C[-12,11]+Omega. Entry8; exit-6; targets[-8,6].
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <random>
#include <vector>
using U128=__uint128_t;
int extra,nm,nc;U128 all,couts[128],win[128],safe[128],nextw[128];
std::vector<int>mouts[128];int collision[128];
const int sigma[5]={0,2,4,3,1},voltage[5]={1,-1,-1,-1,-1};
int pc(U128 x){return __builtin_popcountll(uint64_t(x))+__builtin_popcountll(uint64_t(x>>64));}
int cm(int x,int j){return (x+11)*5+j;}
int cc(int x,int j){return (x+12)*5+j;}
int global_to_m(int v){if(v>=40)return 110+v-40;int x=v/5;if(x>3)x-=8;return cm(x,v%5);}
int global_to_c(int v){if(v>=40)return 120+v-40;int x=v/5;if(x>3)x-=8;return cc(x,v%5);}
void build(const std::vector<std::vector<int>>&a,const std::vector<int>&core){
 bool changed[64]={};for(int u:core)changed[u]=true;
 for(int x=-12;x<=11;++x)for(int j=0;j<5;++j){int c=cc(x,j),u=((x%8+8)%8)*5+j;couts[c]=U128(1)<<c;
  if(x>=-2&&x<=2&&changed[u]){for(int v:a[u])couts[c]|=U128(1)<<global_to_c(v);}
  else {int xx[2]={x+(j==4),x+voltage[j]},jj[2]={(j+1)%5,sigma[j]};for(int h=0;h<2;++h)couts[c]|=U128(1)<<(xx[h]<-12||xx[h]>11?nc-1:cc(xx[h],jj[h]));}
 }
 for(int i=0;i<extra;++i){int c=120+i;couts[c]=U128(1)<<c;for(int v:a[40+i])couts[c]|=U128(1)<<global_to_c(v);}
 couts[nc-1]=U128(1)<<(nc-1);for(int x:{-12,11})for(int j=0;j<5;++j)couts[nc-1]|=U128(1)<<cc(x,j);
 for(int x=-11;x<=10;++x)for(int j=0;j<5;++j){int r=cm(x,j),u=((x%8+8)%8)*5+j;collision[r]=cc(x,j);mouts[r]={r};
  if(x>=-2&&x<=2&&changed[u]){for(int v:a[u])mouts[r].push_back(global_to_m(v));}
  else {int xx[2]={x+(j==4),x+voltage[j]},jj[2]={(j+1)%5,sigma[j]};for(int h=0;h<2;++h)if(xx[h]>=-11&&xx[h]<=10)mouts[r].push_back(cm(xx[h],jj[h]));}
 }
 for(int i=0;i<extra;++i){int r=110+i;collision[r]=120+i;mouts[r]={r};for(int v:a[40+i])mouts[r].push_back(global_to_m(v));}
}
int game(int target){ // target=-1: safe exit at next M-turn in column -4.
 for(int r=0;r<nm;++r)win[r]=target==r?all:(target<0&&r>=cm(-6,0)&&r<=cm(-6,4)?all^(U128(1)<<collision[r]):0);
 bool changed=true;
 while(changed){for(int v=0;v<nm;++v){safe[v]=0;for(int c=0;c<nc;++c)if(!(couts[c]&~win[v]))safe[v]|=U128(1)<<c;}
  changed=false;for(int r=0;r<nm;++r){U128 w=win[r];for(int v:mouts[r])w|=safe[v];if(r!=target)w&=~(U128(1)<<collision[r]);nextw[r]=w;changed|=w!=win[r];}std::copy(nextw,nextw+nm,win);
 }
 int ans=0;if(target<0){for(int x=-5;x<=8;++x)for(int j=0;j<5;++j)ans+=pc(win[cm(x,j)]);for(int i=0;i<extra;++i)ans+=pc(win[110+i]);}
 else for(int j=0;j<5;++j)ans+=pc(win[cm(8,j)]);return ans;
}
std::pair<int,int>score(const std::vector<std::vector<int>>&a,const std::vector<int>&core,bool deliveries){build(a,core);int ex=game(-1),de=0;if(deliveries){for(int x=-8;x<=6;++x)for(int j=0;j<5;++j)de+=game(cm(x,j));for(int i=0;i<extra;++i)de+=game(110+i);}return {ex,de};}
int main(int argc,char**argv){if(argc<2)return 2;std::ifstream f(argv[1]);int n,count;f>>n>>count;extra=n-40;nm=110+extra;nc=121+extra;if(extra<0||extra>4)return 2;all=(U128(1)<<nc)-1;
 std::vector<int>core(count);for(int &x:core)f>>x;std::vector<std::vector<int>>a(n,std::vector<int>(2));for(auto &row:a)f>>row[0]>>row[1];
 double budget=argc>2?std::atof(argv[2]):15;int seed=argc>3?std::atoi(argv[3]):515926;std::mt19937 rng(seed+extra);std::uniform_real_distribution<double>U(0,1);auto start=std::chrono::steady_clock::now();auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
 int maxex=(70+extra)*(nc-1),maxde=(75+extra)*5*(nc-1);auto cur=score(a,core,false);bool stage=cur.first==maxex;if(stage)cur=score(a,core,true);auto best=cur;auto ba=a;long long evals=1,step=0;
 while(elapsed()<budget && !(best.first==maxex&&best.second==maxde)){int u=core[rng()%count],v=core[rng()%count],i=1,j=1;if(u==v||a[v][j]==u||a[u][i]==v||a[v][j]==a[u][1-i]||a[u][i]==a[v][1-j])continue;
  std::swap(a[u][i],a[v][j]);auto candidate=score(a,core,stage);++evals;++step;double temp=0.2+20.0*(1.0-(step%1000)/1000.0);int delta=stage?candidate.second-cur.second:candidate.first-cur.first;
  bool accept=(!stage||candidate.first==maxex)&&(delta>=0||U(rng)<std::exp(delta/temp));if(accept)cur=candidate;else std::swap(a[u][i],a[v][j]);
  if(cur>best){best=cur;ba=a;}if(!stage&&cur.first==maxex){stage=true;cur=score(a,core,true);best=cur;ba=a;}
  if(step%2000==0){a=ba;cur=best;}
 }
 std::cout<<"{\"extra\":"<<extra<<",\"exit_score\":"<<best.first<<",\"exit_required\":"<<maxex<<",\"delivery_score\":"<<best.second<<",\"delivery_required\":"<<maxde<<",\"success\":"<<(best.first==maxex&&best.second==maxde?"true":"false")<<",\"evaluations\":"<<evals<<",\"seconds\":"<<elapsed()<<",\"arcs\":[";
 for(int r=0;r<n;++r){if(r)std::cout<<",";std::cout<<"["<<r<<","<<ba[r][0]<<"],["<<r<<","<<ba[r][1]<<"]";}std::cout<<"]}\n";
}

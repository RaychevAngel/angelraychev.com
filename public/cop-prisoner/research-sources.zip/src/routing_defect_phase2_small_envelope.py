#!/usr/bin/env python3
"""Bounded run completions and one-to-two independent-set exchanges at n116/117."""
from math import gcd
from pathlib import Path
import hashlib,json


def solve(n):
 best=None
 for h in range(7,(n-1)//2+1,2):
  if gcd(h,n)!=1:continue
  a=(h-1)//2;seed={0,1,a,h};D={(x-y)%n for x in (1,a,h)for y in (1,a,h)if x!=y}
  F=seed|{(x+d)%n for x in seed for d in D};allowed=set(range(n))-F
  I={j*(3*a-1)+t for j in range(n//(3*a-1))for t in range(a-1)}
  adj={x:{(x+d)%n for d in D}for x in allowed}
  for shift in range(n):
   for reverse in [False,True]:
    J={((x+shift)%n)for x in I}-F
    changed=True
    while changed:
     changed=False
     for x in sorted(allowed-J,reverse=reverse):
      if not adj[x]&J:J.add(x);changed=True
     # Replace one current point by two nonadjacent alternatives.
     groups={}
     for x in allowed-J:
      B=adj[x]&J
      if len(B)==1:groups.setdefault(next(iter(B)),[]).append(x)
     found=False
     for b,items in groups.items():
      for i,x in enumerate(items):
       for y in items[i+1:]:
        if y not in adj[x]:J.remove(b);J.update([x,y]);changed=found=True;break
       if found:break
      if found:break
    A=J|seed
    for d in D:assert sum((x+d)%n in A for x in A)==1
    row={'n':n,'h':h,'a':a,'shift':shift,'reverse':reverse,'A':sorted(A),'size':len(A),'capacity':n*(len(A)-1)}
    if best is None or len(A)>best['size']:best=row
 return best


def main():
 rows=[solve(n)for n in [116,117]]
 out={'verified':True,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Only explicit protected-difference envelopes at orders116 and117; finite construction, not impossibility.','rows':rows}
 (Path(__file__).resolve().parents[1]/'research/routing-defect-phase2-small-envelope-checks.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out))
if __name__=='__main__':main()

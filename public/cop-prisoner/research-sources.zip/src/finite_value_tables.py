#!/usr/bin/env python3
"""Render compact exact tables only from a complete, recipe-audited ledger.

This independently decodes the stored affine segments. It imports no classifier,
graph generator, game solver, or enumeration engine. --check performs readback
without writing; --receipt records the independent assembly audit explicitly.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
LEDGER=ROOT/'publication/classification-coverage.json'
RECIPES=ROOT/'research/explicit-construction-coverage.json'
OUTPUT=ROOT/'paper/finite-values.md'
INTERVALS={8:(24,34),9:(24,54),10:(25,70),11:(25,88)}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def require(condition,message):
    if not condition:raise ValueError(message)

def decode_ledger(ledger):
    require(ledger['totals']['unresolved']==0,'The classification ledger still has unresolved cells; no final table was written.')
    require(ledger['canonical_representatives']['unresolved']==0,'Canonical unknowns remain.')
    first,last=ledger['finite_box']['n']
    require(first==1 and last>=12,'The ledger must include every order from one through twelve.')
    require([row['n'] for row in ledger['rows']]==list(range(1,last+1)),'The ledger order coverage has a gap or duplicate.')
    values={};supports={};count=0
    for row in ledger['rows']:
        n=row['n'];limit=n*(n-1);cursor=0;expanded=[];support=[]
        require(row['unresolved']==0 and row['exact']==row['admissible']==limit+1,f'Incomplete row {n}.')
        for segment in row['segments']:
            a,b=segment['m'];lo=segment['lower'];hi=segment['upper']
            require(a==cursor and a<=b<=limit,f'Bad segment cover at order {n}.')
            require(segment['status']=='exact',f'Nonexact segment at order {n}.')
            require(lo[2] in ledger['rules'] and hi[2] in ledger['rules'],'Missing proof-rule provenance.')
            for m in range(a,b+1):
                value=lo[0]+lo[1]*(m-a);upper=hi[0]+hi[1]*(m-a)
                require(value==upper and isinstance(value,int) and 0<=value<=limit-m,f'Invalid exact value at {(n,m)}.')
                require(m<=n*(n-2) or value==0,f'Zero-tail mismatch at {(n,m)}.')
                expanded.append(value);support.append(lo[3]);count+=1
            cursor=b+1
        require(cursor==limit+1,f'Uncovered final segment at order {n}.')
        values[n]=expanded;supports[n]=support
    require(count==ledger['totals']['admissible']==ledger['totals']['exact'],'Ledger totals disagree with the decoded cells.')
    return values,supports,count

def uniform_value(n,m,small_arcs):
    if m<=23:return small_arcs[m]
    if m<=2*n:
        k=m//2
        return k*(k-3)+(2 if m%2 else 0)
    if m<=n*(n-3):return n*(n-1)-m
    if m<=n*(n-2):
        r=m-n*(n-3)
        return 2*n-r-(r+1)//2-1
    return 0

def audit():
    ledger=json.loads(LEDGER.read_text());values,supports,count=decode_ledger(ledger)
    recipes=json.loads(RECIPES.read_text())
    require(recipes['source_sha256'].get('publication/classification-coverage.json')==digest(LEDGER),
            'The construction audit is stale for this ledger; no final table was written.')
    require(recipes['numerically_exact_cells']==count and recipes['numerical_canonical_gaps']==0,
            'The construction inventory does not cover the complete numerical ledger.')
    require(recipes['known_value_explicit_construction_gap_count']==0 and not recipes['known_value_explicit_construction_gaps'],
            'A known-value construction gap remains.')
    small_arcs=values[12][:24]
    require(all(s<=12 for s in supports[12][:24]),'A small-budget attainer does not fit on twelve vertices.')
    small_host_checks=0
    for m,maximum in enumerate(small_arcs):
        for n in range(1,max(12,2*m)+1):
            if m<len(values[n]):
                require(values[n][m]<=maximum,f'Small-budget global maximum mismatch at {(n,m)}.')
                small_host_checks+=1
    checked=0
    for n,row in values.items():
        if n>=12:
            for m,value in enumerate(row):
                require(value==uniform_value(n,m,small_arcs),f'Uniform-regime mismatch at {(n,m)}.')
                checked+=1
    for n,(a,b) in INTERVALS.items():
        require(all(values[n][m]==n*(n-1)-m for m in range(a,b+1)),f'Missing-pair interval mismatch at order {n}.')
    require(all(values[11][88+r]==21-r-(r+1)//2 for r in range(1,12)),
            'The order-eleven staircase disagrees with the ledger.')
    finite_covered=set()
    for n in range(1,8):
        finite_covered.update((n,m) for m in range(min(35,n*(n-1))+1))
    for n in range(8,12):
        finite_covered.update((n,m) for m in range(25))
        a,b=INTERVALS[n];finite_covered.update((n,m) for m in range(a,b+1))
    finite_covered.update((8,m) for m in range(35,41))
    for n in range(8,12):
        finite_covered.update((n,m) for m in range(n*(n-3)+1,n*(n-2)+1))
    for n in range(1,12):
        finite_covered.update((n,m) for m in range(max(0,n*(n-2)+1),n*(n-1)+1))
    expected={(n,m) for n in range(1,12) for m in range(n*(n-1)+1)}
    require(finite_covered==expected,'The compact tables and interval rules omit or invent a finite cell.')
    report={'verified':True,'ledger_exact_cells_independently_decoded':count,
            'finite_cells_covered_by_tables_and_intervals':len(expected),'uniform_regime_cells_checked':checked,
            'small_budget_support_reduction_cells_checked':small_host_checks,
            'ME_0_through_23':small_arcs,'known_value_construction_gaps':0,
            'boundary':'Independent arithmetic ledger/recipe readback. Infinite coverage uses the retained sparse, complete-main, dense-staircase and zero theorems plus small-budget attainers fitting on twelve vertices; finite checks alone do not prove the infinite statement.',
            'source_sha256':{'publication/classification-coverage.json':digest(LEDGER),
                             'research/explicit-construction-coverage.json':digest(RECIPES),
                             'src/finite_value_tables.py':digest(Path(__file__))}}
    return values,small_arcs,report

def table(headers,rows):
    lines=['| '+' | '.join(map(str,headers))+' |','| '+' | '.join(['---']*len(headers))+' |']
    lines.extend('| '+' | '.join(map(str,row))+' |' for row in rows)
    return '\n'.join(lines)+'\n'

def budget_table(values,orders,a,b):
    return table(['$n\\backslash m$',*range(a,b+1)],
                 [[n,*[values[n][m] if m<len(values[n]) else '—' for m in range(a,b+1)]] for n in orders])

def render(values,small_arcs):
    parts=['# Complete tables through eleven vertices {#complete-tables-through-eleven-vertices}',
      'These tables and interval rules determine $M(n,m)$ for every admissible pair with $1\\le n\\le11$. An em dash means $m>n(n-1)$, so no such loopless graph exists. At every order, $M(n,m)=0$ for $m>n(n-2)$; this rule covers any final budgets omitted below.',
      '## Orders one through seven',
      'The three blocks list budgets zero through thirty-five. Together with the zero-tail rule, they cover every admissible budget at these orders.']
    for a in (0,12,24):parts.append(budget_table(values,range(1,8),a,a+11))
    parts+=['## Orders eight through eleven: the low budgets',
            'The next two blocks list budgets zero through twenty-three. Budget twenty-four appears with the interval data immediately afterward.']
    for a in (0,12):parts.append(budget_table(values,range(8,12),a,a+11))
    parts.append(table(['$n$','$M(n,24)$','Interval of budgets $m$','Value on that interval'],
      [[n,values[n][24],f'${a}\\le m\\le{b}$',f'${n*(n-1)}-m$'] for n,(a,b) in INTERVALS.items()]))
    parts+=['## The remaining eight-vertex middle budgets',budget_table(values,[8],35,40),
            '## The small dense tails',
            'Put $m=n(n-3)+r$. The entries below give $M(n,m)$; the preceding intervals already include $r=0$ at orders nine and ten, and the eight-vertex endpoint $m=40$ appears above.',
            table(['$n\\backslash r$',*range(1,11)],[[n,*[values[n][n*(n-3)+r] for r in range(1,11)]] for n in range(8,11)]),
            'At order eleven the uniform staircase applies throughout the remaining nonzero tail. For $m=88+r$ and $1\\le r\\le11$,\n\n$$M(11,88+r)=21-r-\\lceil r/2\\rceil.$$\n\nFor $100\\le m\\le110$, the value is zero.',
            '## The uniform classification from twelve vertices',
            'Every entry of the small-arrow table below has an explicit attainer on at most twelve vertices. Consequently it equals $M(n,m)$ for every $n\\ge12$ at that budget, as well as the unrestricted-host maximum $M_E(m)$.']
    for a in (0,12):parts.append(table(['$m$',*range(a,a+12)],[['$M_E(m)$',*small_arcs[a:a+12]]]))
    parts+=['For $n\\ge12$ and $m\\ge24$, put $L=n(n-1)$, $k=\\lfloor m/2\\rfloor$ and, in the dense band, $r=m-n(n-3)$. Then\n\n$$\nM(n,m)=\\begin{cases}\nk(k-3)+2(m\\bmod2),&24\\le m\\le2n,\\\\\nL-m,&2n<m\\le n(n-3),\\\\\n2n-r-\\lceil r/2\\rceil-1,&n(n-3)<m\\le n(n-2),\\\\\n0,&n(n-2)<m\\le L.\n\\end{cases}\n$$',
      'The sparse formulas have fitting even- and odd-budget cores: $k\\le n$ in the even case and $k+1\\le n$ in the odd case. The complete main-interval theorem and the staircase theorem from order eleven cover the next two bands. The small-arrow attainers extend by isolated vertices. Conversely, removing isolated vertices leaves at most $2m\\le46$ vertices when $1\\le m\\le23$, so the finite ledger and isolate invariance also establish the unrestricted-host upper bounds in the small-arrow table. At $m=0$ every graph has value zero.',
      '## Provenance and attainment',
      'The values are generated from the complete classification ledger, `publication/classification-coverage.json`, by `src/finite_value_tables.py`, using an independent affine-segment decoder. The generator refuses unresolved cells, checks that the displayed tables and intervals cover all 451 admissible cells through order eleven, and checks the uniform formulas against every stored order from twelve onward. It also requires a fresh explicit-construction audit, `research/explicit-construction-coverage.json`, with zero known-value construction gaps. These paths identify files in the downloadable research-source archive.',
      'The infinite statement uses the ordinary sparse constructions in `paper/sparse-all-orders.md`, the complete main interval in `paper/main-interval-complete.md`, the dense staircase in `paper/dense-third.md`, and the zero regime. The finite exclusions retain their individual source reviews and complete literal winning/losing rank checks in the small-case registry, `research/small-case-results.json`. This table readback adds no graph search and makes no new Lean claim.']
    return '\n\n'.join(part.rstrip() for part in parts)+'\n'

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true');parser.add_argument('--audit-only',action='store_true')
    parser.add_argument('--receipt',type=Path);args=parser.parse_args()
    try:
        values,small_arcs,report=audit();text=render(values,small_arcs)
        if args.check:require(OUTPUT.exists() and OUTPUT.read_text()==text,'The finite-values paper differs from the exact ledger rendering.')
        elif not args.audit_only:OUTPUT.write_text(text)
        if args.receipt:
            if OUTPUT.exists():report['source_sha256']['paper/finite-values.md']=digest(OUTPUT)
            args.receipt.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(report,indent=2))
    except ValueError as exc:parser.exit(1,str(exc)+'\n')

if __name__=='__main__':main()

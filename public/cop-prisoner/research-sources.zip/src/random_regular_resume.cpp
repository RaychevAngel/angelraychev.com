// Deterministic, bounded experiment on random two-permutation digraphs.
// Queue attractor for the actual alternating game; never an existence proof.
#include <algorithm>
#include <array>
#include <chrono>
#include <iostream>
#include <fstream>
#include <numeric>
#include <random>
#include <vector>
using namespace std;
struct Result { long long failed_states=0; int failed_pairs=0; };
Result solve(const vector<array<int,3>>& out) {
  int n=out.size(),sz=2*n*n; vector<vector<int>> in(n);
  for(int r=0;r<n;r++)for(int v:out[r])in[v].push_back(r);
  Result ans; vector<unsigned char> win(sz),rem(sz);vector<int> queue;queue.reserve(sz);
  for(int t=0;t<n;t++) {
    fill(win.begin(),win.end(),0);fill(rem.begin(),rem.end(),3);queue.clear();
    for(int c=0;c<n;c++)for(int turn=0;turn<2;turn++) {int id=2*(t*n+c)+turn;win[id]=1;queue.push_back(id);}
    for(size_t head=0;head<queue.size();head++) {
      int id=queue[head],turn=id%2,r=(id/2)/n,c=(id/2)%n;
      if(turn) {
        for(int p:in[r]) {int parent=2*(p*n+c);if(p!=c && !win[parent]) {win[parent]=1;queue.push_back(parent);}}
      } else {
        for(int p:in[c]) {int parent=2*(r*n+p)+1;if(r!=p && !win[parent] && --rem[parent]==0) {win[parent]=1;queue.push_back(parent);}}
      }
    }
    for(int r=0;r<n;r++)if(r!=t) {
      bool fail=false;
      for(int c=0;c<n;c++)if(c!=r && !win[2*(r*n+c)]) {ans.failed_states++;fail=true;}
      ans.failed_pairs+=fail;
    }
  }
  return ans;
}
bool localObstruction(const vector<array<int,3>>& out) {
 int n=out.size();vector<vector<int>> in(n);
 for(int r=0;r<n;r++) for(int j=1;j<3;j++) in[out[r][j]].push_back(r);
 auto has=[&](int c,int x){return find(out[c].begin(),out[c].end(),x)!=out[c].end();};
 for(int r=0;r<n;r++) for(int c=0;c<n;c++) if(c!=r && has(c,out[r][1]) && has(c,out[r][2]))return true;
 for(int t=0;t<n;t++) for(int c=0;c<n;c++) if(has(c,in[t][0]) && has(c,in[t][1]))return true;
 return false;
}
int main(int argc,char**argv) {
 int n=argc>1?atoi(argv[1]):30, samples=argc>2?atoi(argv[2]):20;
 bool condition=argc>3?atoi(argv[3]):false;
 mt19937 rng(120926+n+int(condition));vector<int> p(n),q(n);vector<array<int,3>> out(n);
 int accepted=0,rejected=0,universal=0; long long totalfail=0;int minfail=n*n,maxfail=0;
 auto start=chrono::steady_clock::now();
 for(int it=0;it<samples;it++) {
   do {
     iota(p.begin(),p.end(),0);iota(q.begin(),q.end(),0);shuffle(p.begin(),p.end(),rng);shuffle(q.begin(),q.end(),rng);
     bool valid=true;for(int r=0;r<n;r++){out[r]={r,p[r],q[r]};if(p[r]==r || q[r]==r || p[r]==q[r])valid=false;}
     if(!valid){rejected++;continue;}
     if(condition && localObstruction(out)){rejected++;continue;}break;
   }while(true);
   auto ans=solve(out);accepted++;universal+=ans.failed_pairs==0;totalfail+=ans.failed_pairs;minfail=min(minfail,ans.failed_pairs);maxfail=max(maxfail,ans.failed_pairs);
   if(accepted==1 && argc>4) {ofstream file(argv[4]);file<<"{\"n\":"<<n<<",\"failed_pairs\":"<<ans.failed_pairs<<",\"failed_states\":"<<ans.failed_states<<",\"arcs\":[";for(int r=0;r<n;r++){if(r)file<<",";file<<"["<<r<<","<<p[r]<<"],["<<r<<","<<q[r]<<"]";}file<<"]}\n";}
   if(ans.failed_pairs==0 && accepted==1) {cerr<<"{\"n\":"<<n<<",\"arcs\":[";for(int r=0;r<n;r++){if(r)cerr<<",";cerr<<"["<<r<<","<<p[r]<<"],["<<r<<","<<q[r]<<"]";}cerr<<"]}\n";}
 }
 cout<<"{\"n\":"<<n<<",\"conditioned_on_no_local_obstruction\":"<<(condition?"true":"false")<<",\"accepted\":"<<accepted<<",\"rejected\":"<<rejected<<",\"universal\":"<<universal<<",\"failed_pairs_min\":"<<minfail<<",\"failed_pairs_max\":"<<maxfail<<",\"failed_pairs_total\":"<<totalfail<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
}

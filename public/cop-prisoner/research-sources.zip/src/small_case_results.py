#!/usr/bin/env python3
"""Consolidate reviewed small-case constructions; no discovery search.

The published registry separates literal lower witnesses, asymmetric interval
certificates, proved upper bounds, and support reductions. A lower witness is
never promoted to an exact maximum merely because it is the best one found.
"""
import hashlib
import json
from pathlib import Path
from small_case_certificate_review import review, records

ROOT = Path(__file__).resolve().parents[1]
FIXED_SOURCES = [
    'research/small-dense-rooted-certificates.json',
    'research/small-dense-anchor-certificates.json',
    'research/small-dense-rooted-deletion-certificates.json',
    'research/small-dense-two-root-certificates.json',
    'research/small-dense-final-steps-pilot-certificates.json',
    'research/small-dense-endpoint-certificates.json',
    'research/small-sparse-regular-10-witness.json',
    'research/small-case-n7-certificates.json',
    'research/small-case-support-witnesses.json',
    'research/small-case-n7-neighbor-m22-certificate.json',
    'research/small-case-n7-neighbor-m23-certificate.json',
    'research/small-dense-second-step-certificates.json',
    'research/small-dense-first-step-certificates.json',
    'research/finish_constructions_certificates.json',
    'research/finish-sparse-new-lowers.json',
    'research/sparse_finish_twentyone_56_ten_certificate.json',
    'research/sparse_finish_twentyone_58_certificate.json',
    'research/sparse_finish_twentyone_60_certificate.json',
    'research/endpoint40_joint_n10_m25_local_certificate.json',
    'research/endpoint40_joint_n10_m23_deletion_certificate.json',
    'research/sparse_finish_nineteen_38_certificate.json',
    'research/sparse_finish_nineteen_40_certificate.json',
    'research/endpoint40_joint_n10_m24_discovered61_certificate.json',
    'research/endpoint40_joint_n10_m23_discovered61_certificate.json',
    'research/finish_budget_witness_n9_m20_above36.json',
    'research/finish-positive-max-n10-m22-from55-certificate.json',
]


def digest(path):
    return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()


def fixed():
    catalogue = json.loads((ROOT/'research/small-plateau-witness-catalogue.json').read_text())
    sources = FIXED_SOURCES + [x['certificate'] for x in catalogue['records']]
    best = {}
    hashes = {}
    for path in dict.fromkeys(sources):
        hashes[path] = digest(path)
        for g in records(json.loads((ROOT/path).read_text())):
            key = (g['n'],g['m'])
            if key not in best or g['I'] > best[key][0]['I']:
                best[key] = (g,path)
    report = []
    graphs = []
    for key,(g,path) in sorted(best.items()):
        checked = review(g)
        report.append({**checked,'discovery_source':path,'certificate_index':len(graphs)})
        graphs.append(g)
    output = 'research/small-case-fixed-certificates.json'
    (ROOT/output).write_text(json.dumps(graphs,separators=(',',':'))+'\n')
    return output,report,hashes


def main():
    output,graphs,hashes = fixed()
    stages = json.loads((ROOT/'research/small-case-stage-independent-review.json').read_text())
    assert stages['status'] == 'passed'
    for path,value in stages['sources'].items():
        assert digest(path) == value
    hashes.update(stages['sources'])
    data = {
        'verified':True,
        'scope':'Fixed directed receipt-before-capture game; exact values and direct constructions are distinct obligations.',
        'fixed_certificates':output,
        'fixed_certificates_sha256':digest(output),
        'fixed_graphs':graphs,
        'stage_intervals':stages['records'],
        'stage_inputs':[
            {'records':'research/small-plateau-staged-records.json','bundle':'research/small-plateau-staged-certificates.zip'},
            {'records':'research/small-plateau-small-stage-records.json','bundle':'research/small-plateau-small-stage-certificates.zip'}],
        'upper_bounds':[],
        'host_cutoffs':[],
        'boundaries':[
            'Literal fixed graphs give lower bounds; exactness requires a separately incorporated upper proof.',
            'Every stage is valid for every optional subset between its specified base and envelope, not merely its two endpoints.',
            'Incomplete searches and discovery failures supply no upper bound.',
            'New graph and exclusion certificates are external finite proofs with the stated independent reviews, not full Lean instantiations.'],
        'source_sha256':{**hashes,
            'src/small_case_results.py':digest('src/small_case_results.py'),
            'src/small_case_certificate_review.py':digest('src/small_case_certificate_review.py'),
            'src/small_case_stage_review.py':digest('src/small_case_stage_review.py')},
    }
    # This file is the reviewed upper/reduction inventory, maintained separately
    # from the constructor so that discovery can never promote its own score.
    approvals = ROOT/'research/small-case-approved-bounds.json'
    if approvals.exists():
        a = json.loads(approvals.read_text())
        data['upper_bounds'] = a['upper_bounds']
        data['host_cutoffs'] = a['host_cutoffs']
        data['source_sha256'].update(a['source_sha256'])
        data['source_sha256']['research/small-case-approved-bounds.json'] = digest('research/small-case-approved-bounds.json')
        for path,value in a['source_sha256'].items():
            assert digest(path) == value,(path,'approved source changed')
    (ROOT/'research/small-case-results.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'literal_graphs':len(graphs),'stage_intervals':len(stages['records']),
                      'approved_upper_bounds':len(data['upper_bounds'])}))


if __name__ == '__main__':
    main()

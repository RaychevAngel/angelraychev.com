#!/usr/bin/env python3
"""Complete joint degree-pair multisets for a small-defect main-band target."""
import argparse,itertools,json
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def permutations(counts,length,prefix=()):
 if len(prefix)==length:
  yield prefix;return
 for value in sorted(counts):
  if counts[value]:
   counts[value]-=1;yield from permutations(counts,length,prefix+(value,));counts[value]+=1
def main():
 p=argparse.ArgumentParser();p.add_argument('n',type=int);p.add_argument('m',type=int);p.add_argument('target',type=int);p.add_argument('--out-profile',type=int);args=p.parse_args()
 n,m,T=args.n,args.m,args.target
 assert n*(n-1)-m-T<n-2 and T>0
 qprofiles=[p for p in itertools.combinations_with_replacement(range(1,n-2),n) if sum(p)==n*(n-1)-m]
 outprofiles=[tuple(n-1-q for q in p) for p in qprofiles]
 inprofiles=[p for p in itertools.combinations_with_replacement(range(2,n),n) if sum(p)==m]
 selected=list(range(len(outprofiles))) if args.out_profile is None else [args.out_profile]
 families=set()
 for j in selected:
  out=outprofiles[j]
  for indegrees in inprofiles:
   for incoming in permutations(Counter(indegrees),n):
    families.add(tuple(sorted(zip(out,incoming),reverse=True)))
 patterns=sorted(families,reverse=True)
 stem=f'endpoint40_joint_n{n}_m{m}_t{T}'+('' if args.out_profile is None else f'_out{args.out_profile}')
 text=str(len(patterns))+'\n'+'\n'.join(' '.join(str(v) for pair in pattern for v in pair) for pattern in patterns)+'\n'
 (ROOT/'research'/f'{stem}.txt').write_text(text)
 record={'n':n,'m':m,'target_I':T,'min_in_out_degree':2,'missing_profile_indices':selected,
   'all_missing_outdegree_profiles':qprofiles,'all_in_degree_profiles':inprofiles,
   'joint_patterns':patterns,'joint_pattern_count':len(patterns),
   'boundary':'Complete joint multisets for the selected outgoing profiles; all incoming profiles and every distinct assignment included.'}
 (ROOT/'research'/f'{stem}.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'stem':stem,'out_profiles':len(outprofiles),'selected':selected,'in_profiles':len(inprofiles),'joint_patterns':len(patterns)}))
if __name__=='__main__':main()

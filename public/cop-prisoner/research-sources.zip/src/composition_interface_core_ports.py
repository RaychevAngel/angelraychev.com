#!/usr/bin/env python3
"""Bounded A4-cell terminal robustness tests with explicit external ports.
Messenger stays in the cell. Cop may exit at designated source ports and enter
at designated head ports; its exterior descriptor may wait arbitrarily.
"""
from pathlib import Path
import json,hashlib,time
from itertools import combinations
from composition_interface_invariant import attract
ROOT=Path(__file__).resolve().parents[1]

def core():
 g=(1,2,0,3);h=(1,3,2,0);G=[(0,1,2,3)];idx={G[0]:0};out=[]
 for x in G:
  row=[]
  for a in (g,h):
   y=tuple(x[a[i]] for i in range(4))
   if y not in idx:idx[y]=len(G);G.append(y)
   row.append(idx[y])
  out.append(row)
 return G,out

def test(exits,entries):
 G,out=core();n=len(G);M=[((),i) for i in range(n)];C=M+[(None,0)];mi={v:i for i,v in enumerate(M)};ci={v:i for i,v in enumerate(C)}
 mo=[[r]+row for r,row in enumerate(out)]
 co=[sum(1<<v for v in set([r]+row+([n] if r in exits else []))) for r,row in enumerate(out)]+[sum(1<<v for v in set([n]+list(entries)))]
 ar=(M,C,mi,ci,mo,co);allc=(1<<len(C))-1;bad=[];maxround=0
 for target in range(n):
  W,rounds=attract(ar,[allc if r==target else 0 for r in range(n)],{target});maxround=max(rounds,maxround)
  bad.extend((r,c,target) for r in range(n) for c in range(n+1) if c!=r and not(W[r]>>c&1))
 return {'exits':exits,'entries':entries,'failed':len(bad),'max_rounds':maxround,'first_failure':bad[0] if bad else None}

if __name__=='__main__':
 start=time.monotonic();records=[]
 for second in range(1,12):
  for exits in ((),(0,second)):
   d=test(exits,(0,second));records.append(d);print(d,flush=True)
 out={'scope':'finite terminal robustness only; no inter-cell navigation composition asserted','seconds':time.monotonic()-start,'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'research/composition-interface-core-ports.json').write_text(json.dumps(out,indent=2)+'\n')

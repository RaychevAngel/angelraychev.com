#!/usr/bin/env python3
"""Incorporate only named, independently reviewed completion-pass claims."""
import hashlib,importlib.util,json
from pathlib import Path
from small_case_certificate_review import review
from small_sparse_support import residual_profiles
ROOT=Path(__file__).resolve().parents[1]

def main():
    hashes={}
    def read(path):
        blob=(ROOT/path).read_bytes();hashes[path]=hashlib.sha256(blob).hexdigest()
        return json.loads(blob)
    def dependencies(mapping):
        for p,h in mapping.items():
            assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,(p,'review dependency changed')
            hashes[p]=h
    uppers=[]
    endpoint=read('research/finish-endpoint40-review.json')
    assert endpoint['verified'] and endpoint['exact_I']==12
    dependencies(endpoint['source_sha256'])
    uppers.append(dict(n=8,m=40,value=12,proof='Two complete reviewed endpoint enumerations and literal full-game replay'))
    high=read('research/finish-n8-review.json');assert high['verified']
    dependencies(high['source_sha256'])
    uppers += [dict(n=x['n'],m=x['m'],value=x['value'],proof='Independent complete positive-missing-degree enumerations with literal full-game replay') for x in high['upper_bounds']]
    for name in ('low','sparse'):
        finite=read(f'research/endpoint40_n8_{name}_receipt.json');assert finite['verified']
        dependencies(finite['source_sha256'])
        for x in finite['cases']:
            assert x['n']==8 and x['target_excluded']==x['M']+1
            ranges=x['complete_disjoint_profile_ranges']
            assert ranges[0][0]==0 and ranges[-1][1]==x['profiles']
            assert all(a[1]==b[0] for a,b in zip(ranges,ranges[1:]))
            uppers.append(dict(n=8,m=x['m'],value=x['M'],proof='Complete reviewed degree-profile enumeration; every surviving literal leaf independently replayed'))
    tiny=read('research/endpoint40_tiny_live_review.json');assert tiny['status']=='passed'
    dependencies(tiny['sha256'])
    assert tiny['completed_exclusion']['complete'] and tiny['budget13']['exact_disjoint_coverage']
    uppers += [dict(n=None,m=m,value=v,proof='Reviewed complete live-capacity exclusion at accepted comparison host; explicit lower at smaller host') for m,v in [(12,9),(13,11)]]
    sparse=read('research/finish-sparse-review.json');assert sparse['verified']
    dependencies(sparse['input_hashes']);dependencies(sparse['inherited_receipt_hashes']);dependencies(sparse['ordinary_extension_hashes'])
    uppers += [dict(n=None,m=m,value=v,proof='Reviewed source/sink deletion, complete degree families, and independent all-leaf alternating-game replay') for m,v in [(19,53),(20,53)]]
    budget=read('research/finish-budget-ordinary-review.json');assert budget['verified']
    dependencies(budget['files'])
    uppers += [dict(n=None,m=m,value=v,proof='Reviewed source/sink induction and complete joint-degree families; independent full leaf-game replay') for m,v in [(14,13),(15,15),(16,19)]]
    twentyone=read('research/finish-twentyone-review.json');assert twentyone['verified']
    dependencies(twentyone['input_hashes'])
    uppers += [dict(n=n,m=m,value=v,proof='Reviewed full host split, complete residual families, and independent alternating-game replay') for n,m,v in [(None,19,49),(None,21,60),(10,21,56),(11,21,58)]]
    joint=read('research/endpoint40_joint_n9_m23_t45_receipt.json');assert joint['verified']
    dependencies(joint['sha256'])
    assert joint['primary']['complete'] and joint['primary']['degree_patterns']==joint['independent_joint_patterns']
    uppers.append(dict(n=9,m=23,value=44,proof='Reviewed small-defect degree reduction and complete joint-degree enumeration with independent literal replay'))
    split=read('research/endpoint40_joint_n10_m24_t62_split_receipt.json');assert split['verified']
    dependencies(split['sha256'])
    assert split['complete_disjoint_pattern_ranges']==[[0,103],[103,109]]
    assert all(r['complete'] and r['degree_patterns']==r['total_degree_patterns'] for r in split['primary_runs'])
    uppers.append(dict(n=10,m=24,value=61,proof='Reviewed small-defect reduction; complete disjoint joint-degree ranges and independent replay of every literal leaf'))
    seventeen=read('research/finish-seventeen-approved.json');assert seventeen['verified']
    dependencies(seventeen['source_sha256'])
    uppers += [dict(**x,proof='Reviewed source/sink reduction, complete positive support split, independent degree lists and full leaf-game replay') for x in seventeen['upper_bounds']]
    eighteen=read('research/finish_eighteen_review.json');assert eighteen['verified']
    dependencies(eighteen['input_hashes']);dependencies(eighteen['helper_hashes'])
    eighteen_manifest=read('research/finish_eighteen_review_manifest.json');dependencies(eighteen_manifest['files']);dependencies(eighteen_manifest['inherited_MV8_source'])
    uppers.append(dict(n=None,m=18,value=33,proof='Reviewed complete positive-degree families with corrected full inclusion, independent game replay, and source/sink bounds'))
    main20=read('research/finish_main_review_n9_m20_manifest.json');assert main20['verified']
    dependencies(main20['files']);dependencies(main20['input_hashes'])
    uppers.append(dict(n=9,m=20,value=37,proof='Reviewed complete positive joint-degree maximization with independent all-leaf replay and fixed-host source/sink bounds'))
    main22=read('research/finish_main_review_n10_m22_manifest.json');assert main22['verified']
    dependencies(main22['files']);dependencies(main22['input_hashes'])
    uppers.append(dict(n=10,m=22,value=60,proof='Reviewed monotone-incumbent complete maximization and every-leaf independent replay; ordinary source/sink and smaller-host bounds'))
    for path in ('research/endpoint40_joint_n10_m23_t62_max_receipt.json','research/endpoint40_positive_n9_m21_t40_max_receipt.json','research/endpoint40_positive_n9_m22_t41_fast_receipt.json'):
        result=read(path);assert result['verified'] and result['primary']['complete']
        dependencies(result['sha256'])
        assert result['primary']['degree_patterns']==result['independent_joint_patterns']
        uppers.append(dict(n=result['n'],m=result['m'],value=result['M'],proof='Reviewed complete joint-degree domain and monotone threshold traversal; independent literal leaves and source/sink or small-defect reduction'))
    nineteen=read('research/finish_nineteen_review_manifest.json');assert nineteen['verified']
    dependencies(nineteen['files']);dependencies(nineteen['input_hashes']);dependencies(nineteen['helper_hashes'])
    uppers += [dict(n=n,m=19,value=v,proof='Reviewed source/sink and positive-support reductions, complete degree families and all independent leaf games') for n,v in [(9,35),(10,38),(None,40)]]

    # Constructive comparison witnesses may strengthen a support reduction
    # without implying an exact value. Both integer implementations agree.
    original=read('research/small-case-support-cutoffs.json');dependencies(original['source_sha256'])
    candidates=read('research/small-case-support-witnesses.json')
    candidates += read('research/finish-sparse-new-lowers.json')
    candidates += read('research/finish_constructions_certificates.json')
    for value in ('56_ten','58','60'):
        candidates.append(read(f'research/sparse_finish_twentyone_{value}_certificate.json'))
    for value in (38,40):
        candidates.append(read(f'research/sparse_finish_nineteen_{value}_certificate.json'))
    spec=importlib.util.spec_from_file_location('independent_support',ROOT/'research/small-case-support-review-2026-09-13.py')
    independent=importlib.util.module_from_spec(spec);spec.loader.exec_module(independent)
    caps=[]
    for old in original['rows']:
        m=old['m'];g=max((g for g in candidates if g['m']==m),key=lambda g:(g['I'],-g['n']))
        literal=review(g);a=residual_profiles(m,g['I']);b=independent.review(m,g['I']+1)
        support=a['maximum_nonisolated_support'];assert support==b['maximum_permitted_nonisolated_support']
        cut=min(old['universal_host_cutoff'],max(g['n'],support or 0))
        exact_caps={12:7,13:8,14:8,15:8,16:8,17:10,18:9,19:11,20:10,21:12}
        if m in exact_caps:cut=exact_caps[m]
        caps.append({**old,'lower':g['I'],'witness_order':g['n'],
          'arithmetic_strict_support':support,'universal_host_cutoff':cut,
          'literal_review':literal,'completion_pass':True,
          'comparison_boundary':'For reviewed exact budgets use the explicit minimum attaining host; otherwise use stronger literal against independent necessary support constraints, retaining earlier sharper reductions.'})
    for p in ['src/finish_case_registry.py','research/finish-endpoint40-review.md',
              'research/endpoint40_tiny_live_review.md','research/finish-sparse-review.md',
              'src/finish_sparse_review.py','research/finish_constructions_notes.md',
              'src/finish_budget_ordinary_review.py','src/finish_twentyone_review.py',
              'research/finish-twentyone-review.md','research/endpoint40_small_joint_proof.md']:
        hashes[p]=hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
    result={'verified':True,'upper_bounds':uppers,'host_cutoffs':caps,
      'proof_boundary':'Only explicitly reviewed exclusions are upper bounds. Additional literals change lower and support bounds only. All concrete proofs external, not full Lean.',
      'source_sha256':hashes}
    (ROOT/'research/finish-case-approved-bounds.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'uppers':len(uppers),'cutoffs':[(c['m'],c['universal_host_cutoff']) for c in caps]}))

if __name__=='__main__':main()

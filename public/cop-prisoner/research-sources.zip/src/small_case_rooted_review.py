#!/usr/bin/env python3
"""Independent coverage replay of the finite safe-root normal forms.

The ordinary proof establishes the normal forms and the two camping rules.
This replay independently expands every row choice, compares all surviving
literal graphs, and checks full-game negative ranks without a game solver.
"""
import hashlib
import itertools
import json
from pathlib import Path
from small_case_certificate_review import review

ROOT = Path(__file__).resolve().parents[1]


def leaves(k, initial, no_root=False, degrees=None):
    universe = set(range(k+1))
    rows = {int(s):frozenset(v) for s,v in initial}
    degrees = degrees or [2]*k
    choices = {s:list(map(frozenset,itertools.combinations(
        sorted(universe-{s}-({k} if no_root else set())),degrees[s]))) for s in range(k)}
    found = []
    nodes = 0
    def visit():
        nonlocal nodes
        nodes += 1
        for c,missing in rows.items():
            for s,other in rows.items():
                if c != s and not missing-other-{s}:
                    return
            if k not in missing and missing <= rows.keys():
                targets = set.intersection(*(set(rows[v]) for v in missing))
                if targets:
                    return
        if len(rows) == k:
            found.append(tuple(tuple(sorted(rows[v])) for v in range(k)))
            return
        s = max((v for v in range(k) if v not in rows),
                key=lambda v:(sum(v in x for x in rows.values()),v))
        for missing in choices[s]:
            rows[s] = missing
            visit()
        rows.pop(s,None)
    visit()
    return nodes, sorted(found)


def main():
    source = 'research/small-dense-rooted-small-enumeration.json'
    negatives = 'research/small-dense-rooted-small-negative-certificates.json'
    data = json.loads((ROOT/source).read_text())
    expected = []
    results = []
    for family in data['families']:
        assert family['complete'] and not family['survivors']
        for case in family['cases']:
            nodes, found = leaves(family['k'],case['initial'],case['no_root'])
            stored = sorted(tuple(tuple(sorted(r)) for r in graph)
                            for graph in case['complete_rows'])
            assert found == stored
            expected.extend(found)
            results.append({'k':family['k'],'one_three_out':family['one_three_out'],
                            'initial':case['initial'],'nodes':nodes,'leaves':len(found)})
    negative_data = json.loads((ROOT/negatives).read_text())
    actual = [tuple(tuple(sorted(r)) for r in x['missing_rows']) for x in negative_data]
    assert sorted(actual) == sorted(expected)
    extra_source = 'research/small-dense-r23-six-enumeration.json'
    extra = json.loads((ROOT/extra_source).read_text())
    for case in extra['cases']:
        nodes,found = leaves(6,case['initial'],case['no_root'])
        stored = sorted(tuple(tuple(sorted(r)) for r in graph)
                        for graph in case['complete_rows'])
        assert found == stored
        results.append({'k':6,'one_three_out':True,'initial':case['initial'],
                        'nodes':nodes,'leaves':len(found)})
    profile_source = 'research/small-dense-r2-rooted-profiles.json'
    for p in json.loads((ROOT/profile_source).read_text()):
        assert p['complete'] and not p['leaves']
        nodes,found = leaves(len(p['degrees']),[],degrees=p['degrees'])
        assert not found
        results.append({'degrees':p['degrees'],'nodes':nodes,'leaves':0})
    extra_negatives = 'research/small-dense-r2-profile-certificates.json'
    extra_negative_data = json.loads((ROOT/extra_negatives).read_text())
    assert sorted(tuple(tuple(sorted(r)) for r in x['missing_rows']) for x in extra_negative_data) == sorted(
        tuple(tuple(sorted(r)) for r in graph) for case in extra['cases'] for graph in case['complete_rows'])
    negative_data.extend(extra_negative_data)
    values = []
    for x in negative_data:
        g = x['full_game']; k = len(x['missing_rows'])
        values.append(review(g))
        arcs = set(map(tuple,g['arcs']))
        for s in range(k):
            assert {v for v in range(g['n']) if s != v and (s,v) not in arcs} == set(x['missing_rows'][s])
        won = sum(s < k for s,t in g['indirect_pairs'])
        assert won < sum(map(len,x['missing_rows']))
    sources = [source,negatives,extra_source,profile_source,extra_negatives,
               'research/small-dense-second-step-proof.md','src/small_case_rooted_review.py',
               'src/small_case_certificate_review.py',
               'research/small-dense-rooted-equality-proof.md',
               'research/small-dense-root-designation-proof.md']
    report = {'verified':True,'boundary':'Independent finite coverage and full negative ranks; normal-form coverage uses the separately reviewed ordinary proof. No Lean theorem.',
              'cases':results,'negative_graphs':values,
              'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources}}
    (ROOT/'research/small-case-rooted-independent-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'verified':True,'cases':len(results),'negative_graphs':len(values)}))


if __name__ == '__main__':
    main()

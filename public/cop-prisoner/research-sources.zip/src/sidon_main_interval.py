#!/usr/bin/env python3
"""Deterministic exact-budget universal digraphs from an extended move set.

Theorem 34 supplies the uniform proof. This file constructs the graphs,
checks the distinct-difference invariant, and verifies sample actual games.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from pathlib import Path


def distinct_differences(n, values):
    differences = [(a - b) % n for a in values for b in values if a != b]
    return len(differences) == len(set(differences))


def extend_moves(n: int, d: int):
    if n < 25 or d < 3 or (d > 3 and n <= d**3 + 2*d):
        raise ValueError("requires n>=25, d>=3, and n>d^3+2d when d>3")
    h = next(h for h in range(7, (n + 1) // 2, 2) if math.gcd(n, h) == 1)
    base = (0, 1, (h - 1) // 2, h)
    values = set(base)
    assert h < n / 2 and distinct_differences(n, values)
    while len(values) < d + 1:
        k = len(values)
        forbidden = set(values)
        forbidden.update((a+b-c) % n for a in values for b in values
                         for c in values if b != c)
        for a, b in itertools.combinations_with_replacement(sorted(values), 2):
            residue = (a + b) % n
            if n % 2:
                forbidden.add(residue * ((n+1)//2) % n)
            elif residue % 2 == 0:
                forbidden.add(residue // 2)
                forbidden.add(residue // 2 + n // 2)
        assert len(forbidden) <= k**3 + 2*k < n
        values.add(next(x for x in range(n) if x not in forbidden))
        assert distinct_differences(n, values)
    return base, tuple(sorted(values))


def construct(n: int, m: int, d: int | None = None):
    if d is None:
        d = max(3, (m + n - 1) // n)
    if not 3*n <= m <= d*n:
        raise ValueError("requires 3n<=m<=dn")
    base, values = extend_moves(n, d)
    base_steps = set(base) - {0}
    arcs = {(v, (v + step) % n) for v in range(n) for step in base_steps}
    extra_steps = set(values) - set(base)
    extras = sorted((v, (v + step) % n) for v in range(n) for step in extra_steps)
    arcs.update(extras[:m-3*n])
    assert len(arcs) == m
    return sorted(arcs), base, values


def main():
    from game_solver import neighborhoods, recipient_explicit, recipient_fast, verify_certificate
    n, d = 73, 4
    counts = []
    for m in range(3*n, d*n + 1):
        arcs, base, values = construct(n, m, d)
        out, _ = neighborhoods(n, arcs)
        assert all((out[x] & out[y]).bit_count() <= 1
                   for x in range(n) for y in range(x))
        assert all((v, (v + step) % n) in set(arcs)
                   for v in range(n) for step in base if step)
        counts.append(m)

    game_checks = []
    for m in (3*n, 3*n + 1, d*n):
        arcs, _, _ = construct(n, m, d)
        out, _ = neighborhoods(n, arcs)
        for target in (0, n-1):
            fast, _ = recipient_fast(n, out, target)
            explicit, cert = recipient_explicit(n, out, target, certificate=True)
            assert fast == explicit
            assert verify_certificate(n, out, cert)
            allv = (1 << n) - 1
            assert all((w | (1 << s)) == allv for s, w in enumerate(fast))
            game_checks.append({"n": n, "m": m, "target": target,
                                "all_sources_and_legal_cops": True})
    larger = []
    for size, degree in [(25, 3), (1000, 9), (5000, 17)]:
        base, values = extend_moves(size, degree)
        larger.append({"n": size, "d": degree, "base": base,
                       "closed_move_set": values, "distinct_differences": True})
    receipt = {"status": "verified", "source_sha256": hashlib.sha256(
        Path(__file__).read_bytes()).hexdigest(),
        "every_budget_structural_check": {"n": n, "minimum_m": counts[0],
            "maximum_m": counts[-1], "number_of_budgets": len(counts)},
        "independent_game_checks": game_checks, "larger_move_sets": larger,
        "proof_boundary": "Uniform ordinary proof; game checks cover the listed targets only."}
    path = Path(__file__).resolve().parents[1] / "research/sidon-main-interval-verification.json"
    path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "verified", "budgets": len(counts),
                      "game_checks": len(game_checks), "receipt": str(path)}))


if __name__ == "__main__":
    main()

"""Independent finite checks of the protected dense-envelope argument.

No imports from its constructor or game solver. Directly verifies a safe
two-move intermediary against every translated missing pair and cop.
"""
from pathlib import Path
import json

CORE = (1, 3, 7)


def check(n, reverse=False):
    protected = { (a-b) % n for a in CORE for b in CORE if a != b }
    forbidden = {v % n for v in (3, -3, 5, -5, 9, -9)}
    envelope = set(CORE)
    while True:
        unavailable = {0}
        for a in envelope:
            unavailable.add(a)
            unavailable.update((a+d) % n for d in protected | forbidden)
        choices = set(range(n)) - unavailable
        if not choices:
            break
        envelope.add(max(choices) if reverse else min(choices))
    assert len(envelope) >= (n-1+12)//13
    for d in protected:
        assert sum((a-b) % n == d for a in envelope for b in envelope) == 1
    assert all((a-b) % n not in forbidden for a in envelope for b in envelope)
    states = 0
    # By translation, fix the source at zero. For every possible missing
    # target and cop, an element of the fixed three-edge missing core
    # supplies an intermediary safe in EVERY permitted intermediate graph.
    for t in envelope:
        for c in range(1,n):
            candidates = [(c+d) % n for d in CORE]
            safe = [u for u in candidates if u not in (0,t,c)
                    and u not in envelope and (t-u) % n not in envelope]
            assert safe, (n, t, c, sorted(envelope))
            states += 1
    return {'n':n,'reverse_greedy':reverse,'envelope_size':len(envelope),
            'pair_cop_checks':states}


if __name__ == '__main__':
    rows = [check(n, reverse) for n in list(range(19,121))+[211,503,997]
            for reverse in (False,True)]
    result = {'all_passed':True,'orders':105,'envelopes':len(rows),
              'pair_cop_checks':sum(r['pair_cop_checks'] for r in rows),
              'method':'Independent direct intermediary checks; no solver or constructor imports',
              'rows':rows}
    path=Path(__file__).resolve().parents[1]/'research/dense-envelope-independent-checks.json'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items()if k!='rows'})

#!/usr/bin/env python3
"""Direct finite audit of dense functional transfer and one-arrow cores.

The paper contains the unbounded proofs.  These checks inspect all safe-move
obligations on specified graphs and replay independent complete small games.
No discovery catalogue or frozen certificate is modified.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]
NINE=[{1,3},{4,7},{5,6},{0,2},{6,8},{2,8},{0,4},{1,5},{3,7}]
ELEVEN=[{4,8},{9,10},{8,9},{7,10},{0,1},{2,6},{3,5},{3,4},{2,7},{0,5},{1,6}]
ROOTED_SEVEN=[{2,7},{4,5},{0,1},{4,6},{0,3},{6,7},{2,5}]


def core(k,odd=False,extra=True):
    rows=[set() for _ in range(2*k+int(odd))]
    for i in range(k):
        rows[i]={k+i,k+(i-1)%k}
        rows[k+i]={(i+4)%k,(i+6)%k}
    if odd:
        for a in (0,3):rows[a].remove(k+a);rows[a].add(2*k)
        rows[2*k]={k,k+3}
    if extra:rows[0].add(1)
    return rows


def two_move_audit(rows):
    n=len(rows);incoming=[{s for s in range(n) if t in rows[s]} for t in range(n)]
    bad=[]; win=set();obligations=0
    for s,row in enumerate(rows):
        for t in row:
            failed=[]
            for c in range(n):
                if c==s:continue
                obligations+=1
                if not rows[c]-(row|incoming[t]):failed.append((s,t,c))
            if failed:bad.extend(failed)
            else:win.add((s,t))
    fallback=[]
    for s,t,c in bad:
        choices=sorted(w for w in rows[c] if w!=s and w not in rows[s] and (w,t) in win)
        assert choices,(s,t,c)
        fallback.append(dict(source=s,target=t,pursuer=c,safe_intermediaries=choices))
    return bad,fallback,obligations


def expected_bad(k,odd):
    if not odd and k==5:return {(0,9,5),(7,1,9)}
    if not odd and k==6:return {(0,1,1),(0,11,7)}
    result={(0,k+(k-1)%k,k+(k-5)%k)}
    if odd:
        result.add((0,2*k,k+(k-3)%k))
        if k==7:result.add((0,1,3))
    return result


def exact_pairs(rows,rooted=False):
    """Fresh finite messenger-turn fixed point, with explicit unsafe root loss."""
    k=len(rows);n=k+int(rooted);rho=k if rooted else None
    missing=rows+[set()] if rooted else rows
    moves=[{v}|(set(range(n))-{v}-missing[v]) for v in range(n)]
    copmoves=[moves[c]&set(range(k)) for c in range(k)]
    pairs=set()
    for target in range(n):
        wins={(target,c) for c in range(k)}
        while True:
            new=set(wins)
            for s in range(n):
                for c in range(k):
                    if s==c or (s,c) in wins:continue
                    for w in moves[s]:
                        if w==target:
                            new.add((s,c));break
                        if rooted and w==rho and rho not in missing[c]:continue
                        if all((w,d) in wins for d in copmoves[c]):
                            new.add((s,c));break
            if new==wins:break
            wins=new
        for s in range(k):
            if target in rows[s] and all((s,c) in wins for c in range(k) if c!=s):pairs.add((s,target))
    return pairs


def functional(size):
    assert size>=3
    # rho=0 is a root, with a winning length-two tail when size>=4.
    rows=[{1} for _ in range(size)]
    rows[1]={2};rows[2]={1}
    if size>=4:rows[0]={3};rows[3]={1}
    for v in range(4,size,2):
        if v+1<size:rows[v]={v+1};rows[v+1]={1}
        else:rows[v]={1}
    return rows


def joined(rooted,tail):
    k=len(rooted)
    assert all(row & set(range(k)) for row in rooted)
    assert all(0 not in row for row in tail)
    return [set(row) for row in rooted]+[{k+w for w in row} for row in tail]


def literal_game(rows):
    n=len(rows);arcs=[(s,t) for s in range(n) for t in range(n) if s!=t and t not in rows[s]]
    result=solve_graph(n,arcs,crosscheck=True)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true',help='Replay and compare the saved audit without writing any file')
    args=parser.parse_args()
    families=[]
    for odd in (False,True):
        for k in range(6 if odd else 5,21):
            rows=core(k,odd)
            bad,fallback,obligations=two_move_audit(rows)
            assert set(bad)==expected_bad(k,odd)
            families.append(dict(k=k,odd=odd,n=len(rows),safe_intermediary_obligations=obligations,exceptional_states=fallback))
    enlarged11=[set(r) for r in ELEVEN];enlarged11[7].add(0)
    bad,_,obligations=two_move_audit(enlarged11)
    assert not bad
    affected=[]
    for s,t in ((7,0),(7,3),(7,4),(4,0),(9,0)):
        danger=enlarged11[s]|{c for c in range(11) if t in enlarged11[c]}
        assert [c for c in range(11) if enlarged11[c]<=danger]==[s]
        affected.append(dict(source=s,target=t,danger=sorted(danger)))
    transfer=[]
    # Include interfaces with losing pairs, so the exact identity's reverse
    # direction is exercised, as well as the all-delivery seven/eight cores.
    interfaces=[([{1},{0}], 'two-cycle interface'),([{1,2},{0}], 'mixed two-vertex interface'),
                (ROOTED_SEVEN,'seven-core'),(NINE[:-1],'designated nine-core')]
    for interface,name in interfaces:
        k=len(interface);rootpairs=exact_pairs(interface,True)
        for size in range(3,8):
            tail=functional(size);tailpairs=exact_pairs(tail)
            incoming=[sum(v in row for row in tail) for v in range(size)]
            predicted={(s,next(iter(row))) for s,row in enumerate(tail) if incoming[s]==0 and incoming[next(iter(row))]==1}
            assert tailpairs==predicted
            full=joined(interface,tail);actual=exact_pairs(full)
            expected=rootpairs|{(k+s,k+t) for s,t in tailpairs}
            assert actual==expected
            verified=literal_game(full)
            assert verified['I']==len(actual)
            assert {tuple(pair) for pair in verified['indirect_pairs']}==actual
            if k in (7,8) and size in (3,4):
                assert verified['max_state_delivery_moves']<=4
            transfer.append(dict(interface=name,core_size=k,tail_size=size,rooted_pairs=len(rootpairs),functional_pairs=len(tailpairs),combined_pairs=len(actual),complete_game_move_bound=verified['max_state_delivery_moves']))
    enlarged9=[set(r) for r in NINE];enlarged9[2].add(4)
    full_games=[]
    for rows in [enlarged9,core(5),core(6),enlarged11,core(6,True),core(7,True)]:
        n=len(rows);result=literal_game(rows)
        assert result['I']==sum(map(len,rows))==2*n+1
        assert result['max_state_delivery_moves'] <= (4 if n==9 else 3)
        combined=[set(r) for r in rows]+[{n+1},{n}]
        larger=literal_game(combined)
        assert larger['I']==2*n+1
        assert larger['max_state_delivery_moves']<=4
        full_games.append(dict(core_order=n,core_count=result['I'],core_move_bound=result['max_state_delivery_moves'],attached_order=n+2,attached_count=larger['I'],attached_move_bound=larger['max_state_delivery_moves']))
    sources=['src/dense_functional_transfer_check.py','src/game_solver.py','paper/dense-third.md','paper/dense-unified-core.md']
    output=dict(status='passed',proof_boundary='Parameterized claims use ordinary danger-set and functional-transfer proofs. Bounded graph audits are verification, not extrapolation. Existing two-move families remain available.',
                source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources},
                core_families=families,eleven_core_safe_intermediary_obligations=obligations,eleven_core_affected_danger_sets=affected,
                functional_transfer_cases=transfer,full_game_crosschecks=full_games,
                checks='Every two-move obstruction and listed three-move fallback; both exact game algorithms on fixed complete graphs; exact positive and negative transfer masks.')
    destination=ROOT/'research/dense-functional-transfer-audit.json'
    if args.check:
        assert json.loads(destination.read_text())==output, 'Saved dense audit differs from fresh replay'
    else:
        destination.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(dict(status='passed',parameterized_graphs_checked=len(families),functional_transfer_cases=len(transfer),full_game_crosschecks=len(full_games))))


if __name__=='__main__':main()

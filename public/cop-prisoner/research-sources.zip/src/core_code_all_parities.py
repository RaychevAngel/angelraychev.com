#!/usr/bin/env python3
"""Direct equal-weight hub codes for every core parity (Theorem 59).

Cycles are listed by a gap recursion, not by search over pursuit graphs.
The old odd-core constructor is retained unchanged for receipt replay.
"""
from functools import lru_cache
from itertools import islice
from math import comb
import argparse
import json


@lru_cache(maxsize=None)
def cycle_count(k, r):
    assert k >= 3
    if r == 0:
        return 1
    if r < 0 or 2*r > k:
        return 0
    return k*comb(k-r, r)//(k-r)


@lru_cache(maxsize=None)
def capacity(k, r):
    assert k >= 5 and r >= 3
    lines = cycle_count(k, r)
    points = lines if k % 2 else sum(
        cycle_count(k//2, i)*cycle_count(k//2, r-i) for i in range(r+1))
    return points + lines


def cycle_sets(k, r):
    """List independent r-sets of C_k, with no failed terminal candidates."""
    if r == 0:
        yield ()
        return
    if r < 0 or 2*r > k:
        return

    def extend(prefix, start, stop, left):
        if not left:
            yield tuple(prefix)
            return
        for v in range(start, stop-2*(left-1)):
            yield from extend(prefix+[v], v+2, stop, left-1)

    for first in range(k):
        stop = k-1 if first == 0 else k
        yield from extend([first], first+2, stop, r-1)


def all_codes(k, r):
    for code in cycle_sets(k, r):
        yield frozenset(k+i for i in code)
    if k % 2:
        for code in cycle_sets(k, r):
            yield frozenset(2*i % k for i in code)
    else:
        for a in range(r+1):
            for even in cycle_sets(k//2, a):
                for odd in cycle_sets(k//2, r-a):
                    yield frozenset([2*i for i in even]+[2*i+1 for i in odd])


def codes(k, r, count):
    assert 0 <= count <= capacity(k, r)
    result = list(islice(all_codes(k, r), count))
    assert len(result) == count
    return result


def interval(k, r, n):
    q = n-2*k
    if q < 0 or q > capacity(k, r):
        return None
    a = 2*k*(2*k-3)+(4*k-r)*q
    return a, a+q*(q-1)


def parameters(n, m):
    for k in range(5, n//2+1):
        for r in range(k//2, 2, -1):
            bounds = interval(k, r, n)
            if bounds is not None and bounds[0] <= m <= bounds[1]:
                return k, r, n-2*k, m-bounds[0]
    raise ValueError('No equal-weight code parameters cover this pair.')


def construction(k, r, q, added=0):
    K = codes(k, r, q)
    graph = from_codes(k, K, added)
    graph['r'] = r
    return graph


def from_codes(k, K, added=0):
    assert k >= 5
    K = [frozenset(S) for S in K]
    q = len(K)
    n = 2*k+q
    for S in K:
        assert len(S) >= 3 and all(0 <= u < 2*k for u in S)
        point = all(u < k for u in S)
        assert point or all(u >= k for u in S)
        inds = {u % k for u in S}
        gap = 2 if point else 1
        assert all((u+gap) % k not in inds for u in inds)
    assert all(not a <= b for i, a in enumerate(K) for j, b in enumerate(K) if i != j)
    missing = {(u, v) for i in range(k) for u, v in (
        (i, k+i), (i, k+(i-1) % k),
        (k+i, (i+4) % k), (k+i, (i+6) % k))}
    base = {(u, v) for u in range(2*k) for v in range(2*k)
            if u != v and (u, v) not in missing}
    base |= {(u, x) for u in range(2*k) for x in range(2*k, n)}
    base |= {(2*k+j, u) for j, S in enumerate(K) for u in range(2*k) if u not in S}
    optional = [(u, v) for u in range(2*k, n) for v in range(2*k, n) if u != v]
    assert len(base) == 2*k*(2*k-3)+4*k*q-sum(map(len, K))
    assert 0 <= added <= len(optional)
    return {'n': n, 'k': k, 'q': q, 'K': [sorted(S) for S in K],
            'base': sorted(base), 'optional': optional,
            'arcs': sorted(base | set(optional[:added]))}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('n', type=int)
    p.add_argument('m', type=int)
    p.add_argument('--out')
    a = p.parse_args()
    graph = construction(*parameters(a.n, a.m))
    body = json.dumps(graph, separators=(',', ':'))+'\n'
    if a.out:
        from pathlib import Path
        Path(a.out).write_text(body)
    else:
        print(body, end='')


if __name__ == '__main__':
    main()

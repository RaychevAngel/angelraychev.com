#!/usr/bin/env python3
"""Independent source-difference and finite-coverage review of tiny budgets."""
import hashlib
import json
from pathlib import Path
from small_case_certificate_review import review

ROOT=Path(__file__).resolve().parents[1]


def main():
    old=(ROOT/'src/small_case_n7_independent.cpp').read_text().splitlines()[2:]
    new=(ROOT/'src/small_plateau_tiny_budget.cpp').read_text().splitlines()[2:]
    expected='\n'.join(old).replace('[12]','[20]').replace('n!=7||T<1','n<3||n>16||T<1')
    assert expected=='\n'.join(new)
    checkpoint=json.loads((ROOT/'research/small-plateau-tiny-budget-checkpoint.json').read_text())
    for path,value in checkpoint['sha256'].items():
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==value
    completed=[]
    for r in checkpoint['runs']:
        if not r['complete']:
            assert r['counterexample_found'];continue
        assert not r['counterexample_found'] and r['first_profile']==0
        assert r['total_profiles']==r['checked_profiles']
        n,m,T=r['n'],r['min_m'],r['target_I']
        assert n in (8,9) and m==r['max_m'] and m in (12,13)
        minimum_rows=(T+n-4)//(n-3)
        def count(prefix,last,remaining):
            if len(prefix)==n:
                return int(remaining==0 and sum(x>=2 for x in prefix)>=minimum_rows)
            return sum(count(prefix+[x],x,remaining-x) for x in range(min(last,remaining)+1))
        assert count([],n-1,m)==r['total_profiles']
        completed.append({'n':n,'m':m,'upper':T-1,'profiles':r['total_profiles'],'nodes':r['nodes']})
    assert len(completed)==3
    literal=review(json.loads((ROOT/'research/small-plateau-tiny-m13-witness.json').read_text()))
    paths=['src/small_case_tiny_review.py','research/small-case-tiny-review.md',
           'research/small-plateau-tiny-budget-checkpoint.json','research/small-case-n7-independent-review.md']
    report={'verified':True,'fixed_uppers':completed,'literal_review':literal,
            'boundary':'Independent ordinary source/coverage audit and literal positive ranks, not a second full enumeration of the three fixed hosts.',
            'source_sha256':{**checkpoint['sha256'],**{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}}}
    (ROOT/'research/small-case-tiny-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'verified':True,'fixed_uppers':completed}))


if __name__=='__main__':main()

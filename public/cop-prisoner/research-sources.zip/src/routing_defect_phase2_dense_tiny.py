#!/usr/bin/env python3
"""At most five greedy orders per fixed compulsory core, orders10 through18."""
from pathlib import Path
import json,hashlib,time
from dense_unified_core import core
from routing_defect_phase2_dense_small import grow,literal
ROOT=Path(__file__).resolve().parents[1]


def main():
    start=time.monotonic()
    rows=[]
    for n in range(10,19):
        base=core(n)
        best=[]
        trials=[]
        for i in range(5):
            seed=556000+100*n+i
            optional=grow(n,base,seed)
            trials.append({'seed':seed,'optional_count':len(optional)})
            if len(optional)>len(best):
                best=optional
            if len(best)>=n:
                break
        witnesses=literal(n,base,best)
        row={'n':n,'attained_3n':len(best)>=n,'full_optional_cap':len(best),
             'trials':trials,'base':sorted(base),'optional':best,'literal_witnesses':witnesses}
        rows.append(row)
        print(json.dumps({k:v for k,v in row.items() if k not in ('base','optional','literal_witnesses')}),flush=True)
    result={'scope':'At most five randomized greedy orders per specified fixed core. Every saved full envelope directly verified; failure to reach n optional arcs is not impossibility.',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'dependencies_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ('src/dense_unified_core.py','src/routing_defect_phase2_dense_small.py')},
            'seconds':time.monotonic()-start,'rows':rows}
    (ROOT/'research/routing-defect-phase2-dense-tiny-checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'seconds':result['seconds'],'attained':[r['n'] for r in rows if r['attained_3n']]}))


if __name__=='__main__':
    main()

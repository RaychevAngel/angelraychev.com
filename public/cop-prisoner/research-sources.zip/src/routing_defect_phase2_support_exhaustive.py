#!/usr/bin/env python3
"""Additional bounded attack: every labelled digraph on up to four vertices."""
from pathlib import Path
import hashlib,json,time
from routing_defect_phase2_support_check import inspect


def main():
 start=time.monotonic();rows=[]
 for n in range(1,5):
  U=[(s,t)for s in range(n)for t in range(n)if s!=t]
  tested=positive=0
  for mask in range(1<<len(U)):
   arcs=[e for i,e in enumerate(U)if mask>>i&1]
   I=inspect(n,arcs);tested+=1;positive+=I>0
  rows.append({'n':n,'graphs':tested,'positive_count_graphs':positive})
 root=Path(__file__).resolve().parents[1]
 result={'verified':True,'rows':rows,'seconds':time.monotonic()-start,
         'both_original_game_solvers':True,
         'scope':'Complete bounded check on all labelled loopless simple directed graphs through4 vertices. Supports but does not replace the ordinary all-order argument; not an independent third game solver.',
         'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'inspector_sha256':hashlib.sha256((root/'src/routing_defect_phase2_support_check.py').read_bytes()).hexdigest(),
         'solver_sha256':hashlib.sha256((root/'src/game_solver.py').read_bytes()).hexdigest()}
 (root/'research/routing-defect-phase2-support-exhaustive-checks.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
if __name__=='__main__':main()

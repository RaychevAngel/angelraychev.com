#!/usr/bin/env python3
"""Fixed protected-circle recipes for a finite main-interval bridge.

Default/--check only reads and verifies literal residue sets. --discover is
the bounded historical greedy packing experiment, never needed to construct
or verify an output graph. Strategy is the ordinary protected-circle theorem.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import random

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'research/core-code-third-circle-envelopes.json'


def verify(row):
    n, h = row['n'], row['h']
    core = {1, (h-1)//2, h}
    A = set(row['A'])
    assert h >= 7 and h % 2 and 2*h+1 <= n and math.gcd(h, n) == 1
    assert len(A) == len(row['A']) and {0}|core <= A <= set(range(n))
    D = {(u-v) % n for u in core for v in core if u != v}
    assert len(D) == 6
    for d in D:
        assert {(u,v) for u in A for v in A if (u-v) % n == d} == {
            (u,v) for u in core for v in core if (u-v) % n == d}
    assert row['minimum_m'] == 3*n and row['maximum_m'] == n*(len(A)-1)
    return 6


def rows():
    data = json.loads(DATA.read_text())['rows']
    assert len({r['n'] for r in data}) == len(data)
    for r in data:
        verify(r)
    return data


def construct(n, m):
    row = next(r for r in rows() if r['n'] == n)
    assert row['minimum_m'] <= m <= row['maximum_m']
    core = {1, (row['h']-1)//2, row['h']}
    B = {(u, (u+d) % n) for u in range(n) for d in core}
    optional = sorted((u, (u+d) % n) for u in range(n) for d in set(row['A'])-{0}-core)
    return sorted(B | set(optional[:m-3*n]))


def discover():
    # At most 100 deterministic greedy orders for each admissible step on
    # each of six named orders. No pursuit game or global optimality claim.
    old = {r['n']: r for r in rows()}
    attempts = 0
    for n in range(100, 106):
        best = old.get(n)
        for h in range(7, (n+1)//2, 2):
            if math.gcd(n, h) != 1:
                continue
            core = {1, (h-1)//2, h}
            initial = {0}|core
            D = {(u-v) % n for u in core for v in core if u != v}
            vertices = set(range(n))-(initial | {(v+d) % n for v in initial for d in D})
            for seed in range(100):
                priority = list(range(n))
                random.Random(n*100000+h*1000+seed).shuffle(priority)
                rank = {v:i for i,v in enumerate(priority)}
                left, A = set(vertices), set(initial)
                while left:
                    v = min(left, key=lambda v: (sum((v+d) % n in left for d in D), rank[v]))
                    A.add(v)
                    left -= {v}|{(v+d) % n for d in D}
                attempts += 1
                if best is None or len(A) > len(best['A']):
                    best = {'n':n, 'h':h, 'core':sorted(core), 'A':sorted(A),
                            'minimum_m':3*n, 'maximum_m':n*(len(A)-1)}
        verify(best)
        old[n] = best
        print(json.dumps({'n':n, 'envelope_size':len(best['A']), 'maximum_m':best['maximum_m']}), flush=True)
    DATA.write_text(json.dumps({'purpose':'Literal finite protected-difference recipes. Discovery used bounded seeded greedy packing; construction reads the saved sets and checks the ordinary theorem premises.',
                               'rows':sorted(old.values(), key=lambda r:r['n'])}, indent=2)+'\n')
    return attempts


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--check', action='store_true')
    p.add_argument('--discover', action='store_true')
    a = p.parse_args()
    if a.discover:
        print(json.dumps({'discovery_attempts':discover()}))
    data = rows()
    for r in data:
        for m in {r['minimum_m'], r['minimum_m']+1, r['maximum_m']}:
            assert len(construct(r['n'], m)) == m
    print(json.dumps({'verified':True, 'orders':[r['n'] for r in data],
                      'protected_differences_checked':6*len(data),
                      'data_sha256':hashlib.sha256(DATA.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()

from pathlib import Path
import json,importlib.util,itertools
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('renderer',ROOT/'src/irregular_ten_export.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
data=json.loads((ROOT/'research/lean-small-budget-five-seven-tree.json').read_text());nodes=data['nodes']
def tree(p):
 node=nodes[','.join(map(str,p))]
 if node['kind']=='bound':return '.bound '+e.certificate(node['certificate'])
 children=' '.join('| '+str(rep)+' => '+tree(p+[rep])for rep in node['representatives'])
 return '.branch '+e.natlist(node['representatives'])+' '+e.route(node)+' (fun mask => match mask with '+children+' | _ => .invalid)'
choices={d:[sum(1<<t for t in xs)for xs in itertools.combinations(range(5),d)]for d in [1,2]}
s='''import RowPrefixTree
import IrregularFiveSevenProfile

/-! Complete finite exclusion for the sole possible positive five-vertex,
seven-arrow profile above two guarantees. Every row choice, symmetry route
and optimistic losing region is checked; the producer supplies only data. -/
namespace Delivery.IrregularFiveSeven
open FiniteGame Extremal RowPrefix
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def D (s : Fin 5) : Nat := if s.val<2 then 2 else 1
def R (t : Fin 5) : Nat := if 2≤t.val ∧ t.val<4 then 2 else 1

def rows (a b c d e : Nat) : Rows 5 := fun v =>
  match v.val with
  | 0 => a | 1 => b | 2 => c | 3 => d | _ => e

'''
s+='def choices (d : Nat) : List Nat := if d=2 then '+e.natlist(choices[2])+' else '+e.natlist(choices[1])+'\n'
s+='''theorem cover_one : RowCover 5 1 (choices 1) := by decide +kernel
theorem cover_two : RowCover 5 2 (choices 2) := by decide +kernel
theorem complete (s : Fin 5) : RowCover 5 (D s) (choices (D s)) := by
  unfold D
  split
  · exact cover_two
  · exact cover_one

'''
s+='def tree : Tree 5 := '+tree([])+'\n\n'
s+='''theorem checked : tree.check D R choices 2 []=true := by decide +kernel

theorem canonical_upper : Upper D R [] 2 := Tree.sound D R choices complete 2 [] tree checked

/-- The upper bound applies to every actual positive-degree five-vertex graph
with seven arrows, including graphs not already in the literal labels. -/
theorem positive_upper (E : Graph (Fin 5)) (loopless : Loopless E)
    (budget : arcCount E=7)
    (positiveOut : ∀ x, 1≤SparseSupport.outdegree E x)
    (positiveIn : ∀ x, 1≤SparseSupport.indegree E x) : score E≤2 := by
  by_cases small : score E≤2
  · exact small
  · obtain ⟨F,⟨iso⟩,loops,outDegrees,inDegrees⟩ :=
      IrregularFiveSevenProfile.normalize E loopless budget positiveOut positiveIn (by omega)
    have prescribed : Prescribed D R F := ⟨loops,outDegrees,inDegrees⟩
    have bound := canonical_upper F prescribed (by intro s h; simp at h)
    rw [GraphRelabeling.score_eq iso]
    exact bound

#print axioms canonical_upper
#print axioms positive_upper
end Delivery.IrregularFiveSeven
'''
(ROOT/'lean/IrregularFiveSeven.lean').write_text(s)

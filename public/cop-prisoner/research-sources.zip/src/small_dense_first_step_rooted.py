#!/usr/bin/env python3
"""Complete remaining tiny safe-root profiles for first-step defect three."""
import json
from pathlib import Path
from small_dense_r2_gap import profile
from small_dense_rooted import verify

ROOT=Path(__file__).resolve().parents[1]

def main():
    results=[];certificates=[]
    profiles=[[4,2,2,2,2,2],[3,3,2,2,2,2]]
    for k in (4,):
        profiles.extend([[5]+[2]*(k-1),[4,3]+[2]*(k-2),[3,3,3]+[2]*(k-3)])
    for degrees in profiles:
        result=profile(degrees);results.append(result)
        print(json.dumps({'degrees':degrees,'nodes':result['nodes'],'leaves':len(result['leaves']),
                          'universal':len(result['survivors'])}),flush=True)
        checked=result['survivors'][:1] if result['survivors'] else result['leaves']
        for leaf in checked:
            interface,game=verify(leaf['missing_rows'],3 if len(degrees)==6 else 4)
            assert interface['I_core']==leaf['I_core']
            certificates.append({'degrees':degrees,'missing_rows':leaf['missing_rows'],
                                 'interface':interface,'full_game':game})
    (ROOT/'research/small-dense-first-step-rooted-profiles.json').write_text(json.dumps(results,separators=(',',':'))+'\n')
    (ROOT/'research/small-dense-first-step-rooted-certificates.json').write_text(json.dumps(certificates,separators=(',',':'))+'\n')

if __name__=='__main__':main()

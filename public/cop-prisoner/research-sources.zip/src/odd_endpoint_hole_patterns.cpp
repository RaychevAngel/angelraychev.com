// Finite screen of smoothed subsets within one six-type column.
// Surviving patterns still require a uniform local proof.
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using U=uint64_t;U adj[64],W[64],safe[64],NW[64];
bool recipient(int n,int t){U all=(U(1)<<n)-1;std::fill(W,W+n,0);W[t]=all;
 while(true){for(int v=0;v<n;++v){safe[v]=0;for(int c=0;c<n;++c)if(!(adj[c]&~W[v]))safe[v]|=U(1)<<c;}
 bool change=false;for(int r=0;r<n;++r){U w=0,nb=adj[r];while(nb){int v=__builtin_ctzll(nb);nb&=nb-1;w|=safe[v];}if(r!=t)w&=~(U(1)<<r);NW[r]=w;change|=w!=W[r];}std::copy(NW,NW+n,W);if(!change)break;}
 for(int r=0;r<n;++r)if((W[r]|(U(1)<<r))!=all)return false;return true;}
bool test(int k,int mask,const std::vector<int>&sig,const std::vector<int>&vol){
 int n=6*k,N=0;std::vector<int> p(n),q(n),index(n,-1);auto gone=[&](int v){return v<6&&(mask>>v&1);};
 for(int u=0;u<n;++u){p[u]=(u+1)%n;q[u]=6*((u/6+vol[u%6]+k)%k)+sig[u%6];if(!gone(u))index[u]=N++;}
 for(int u=0;u<n;++u)if(!gone(u)){
  int a=p[u],b=q[u];while(gone(a))a=p[a];while(gone(b))b=q[b];
  int r=index[u];a=index[a];b=index[b];if(a==r||b==r||a==b)return false;adj[r]=(U(1)<<r)|(U(1)<<a)|(U(1)<<b);
 }
 for(int t=0;t<N;++t)if(!recipient(N,t))return false;return true;
}
int main(int argc,char**argv){std::ifstream f(argv[1]);int count;f>>count;std::cout<<"[";bool first=true;
 for(int i=0;i<count;++i){int original;f>>original;std::vector<int>s(6),v(6);for(int&x:s)f>>x;for(int&x:v)f>>x;
 for(int mask=1;mask<63;++mask)if(test(8,mask,s,v)&&test(10,mask,s,v)){
  if(!first)std::cout<<",";first=false;std::cout<<"{\"pattern_index\":"<<original<<",\"mask\":"<<mask<<",\"removed\":"<<__builtin_popcount(unsigned(mask))<<"}"<<std::flush;
 }}std::cout<<"]\n";}

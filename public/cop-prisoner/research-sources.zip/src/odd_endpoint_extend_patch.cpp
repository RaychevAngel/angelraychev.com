// Extend proved small odd patches by smoothing additional nearby vertices.
// Discovery screen only; fixed local certificates are still required.
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using U=uint64_t;U adj[64],W[64],safe[64],NW[64];int low_source,low_target;
bool recipient(int n,int t){U all=(U(1)<<n)-1;std::fill(W,W+n,0);W[t]=all;
 while(true){for(int v=0;v<n;++v){safe[v]=0;for(int c=0;c<n;++c)if(!(adj[c]&~W[v]))safe[v]|=U(1)<<c;}
 bool change=false;for(int r=0;r<n;++r){U w=0,nb=adj[r];while(nb){int v=__builtin_ctzll(nb);nb&=nb-1;w|=safe[v];}if(r!=t)w&=~(U(1)<<r);NW[r]=w;change|=w!=W[r];}std::copy(NW,NW+n,W);if(!change)break;}
 for(int r=0;r<n;++r)if(r!=low_source&&(W[r]|(U(1)<<r))!=all)return false;return true;}
bool test(int k,int mask0,int extra,int col,int typ,int which,const std::vector<int>&sig,const std::vector<int>&vol){
 int n=6*k,N=0;std::vector<int>p(n),q(n),index(n,-1);
 auto gone=[&](int v){if(v/6==0)return bool(mask0>>(v%6)&1);if(v/6==k-1)return bool(extra>>(v%6)&1);if(v/6==1)return bool(extra>>(6+v%6)&1);return false;};
 for(int u=0;u<n;++u){p[u]=(u+1)%n;q[u]=6*((u/6+vol[u%6]+k)%k)+sig[u%6];if(!gone(u))index[u]=N++;}
 int origin=6*((col+k)%k)+typ;if(gone(origin))return false;
 for(int u=0;u<n;++u)if(!gone(u)){
  int a=p[u],b=q[u];while(gone(a))a=p[a];while(gone(b))b=q[b];int r=index[u];a=index[a];b=index[b];if(a==r||b==r||a==b)return false;adj[r]=(U(1)<<r)|(U(1)<<a)|(U(1)<<b);if(u==origin){low_source=r;low_target=which?b:a;}
 }
 adj[low_source]&=~(U(1)<<low_target);for(int t=0;t<N;++t)if(t!=low_target&&!recipient(N,t))return false;return true;
}
int main(int argc,char**argv){std::ifstream f(argv[1]);int count;f>>count;std::vector<std::vector<int>> ss(count,std::vector<int>(6)),vv=ss;for(int i=0;i<count;++i){for(int&x:ss[i])f>>x;for(int&x:vv[i])f>>x;}
 std::cout<<"[";bool first=true;
 for(auto spec:std::vector<std::vector<int>>{{19,8,1,4,1},{19,16,0,3,1},{106,3,0,5,1},{135,28,0,1,0}}){
  int idx=spec[0],mask=spec[1],col=spec[2],typ=spec[3],edge=spec[4];
  for(int extra=1;extra<4096;++extra){int removed=__builtin_popcount(unsigned(mask))+__builtin_popcount(unsigned(extra));if(removed!=4&&removed!=5)continue;
   if(test(8,mask,extra,col,typ,edge,ss[idx],vv[idx])&&test(10,mask,extra,col,typ,edge,ss[idx],vv[idx])){
    if(!first)std::cout<<",";first=false;std::cout<<"{\"pattern_index\":"<<idx<<",\"mask\":"<<mask<<",\"extra_mask\":"<<extra<<",\"removed\":"<<removed<<",\"source_column\":"<<col<<",\"source_type\":"<<typ<<",\"which\":"<<edge<<"}"<<std::flush;
   }
  }
 }std::cout<<"]\n";
}

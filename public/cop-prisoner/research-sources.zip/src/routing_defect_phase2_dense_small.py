#!/usr/bin/env python3
"""Bounded random-order greedy robust missing envelopes at n19,20,21."""
from pathlib import Path
import json,random,time,hashlib
from dense_unified_core import core
ROOT=Path(__file__).resolve().parents[1]


def grow(n,B,seed):
 rng=random.Random(seed);F=set(B);O=[]
 bo=[0]*n;fo=[0]*n;fi=[0]*n
 for s,t in B:bo[s]|=1<<t;fo[s]|=1<<t;fi[t]|=1<<s
 choices=[(s,t)for s in range(n)for t in range(n)if s!=t and(s,t)not in B]
 rng.shuffle(choices)
 for s,t in choices:
  fo[s]|=1<<t;fi[t]|=1<<s
  affected={(s,t)}|{(s,u)for u in range(n)if fo[s]>>u&1}|{(u,t)for u in range(n)if fi[t]>>u&1}
  if all(c==u or bo[c]&~(fo[u]|fi[v])for u,v in affected for c in range(n)):
   F.add((s,t));O.append((s,t))
  else:fo[s]^=1<<t;fi[t]^=1<<s
 assert all(c==s or bo[c]&~(fo[s]|fi[t])for s,t in F for c in range(n))
 return O


def literal(n,B,O):
 F=B|set(O);U=set(range(n));missing_out={s:{t for u,t in F if u==s}for s in range(n)}
 actual={s:U-{s}-missing_out[s]for s in range(n)}
 protected={s:{t for u,t in B if u==s}for s in range(n)}
 witnesses=[]
 for s,t in sorted(F):
  for c in range(n):
   if c==s:continue
   choices=[u for u in protected[c]if u in actual[s]and t in actual[u]and u!=c and u not in actual[c]]
   assert choices,(s,t,c)
   witnesses.append([s,t,c,min(choices)])
 return witnesses


def main():
 started=time.monotonic();rows=[]
 for n in [19,20,21]:
  B=core(n);trials=[];best=[];bestseed=None
  for i in range(20):
   seed=551900+100*n+i;O=grow(n,B,seed);trials.append({'seed':seed,'optional':len(O)})
   if len(O)>len(best):best,bestseed=O,seed
   if len(best)>=n:break
  chosen=best[:n]if len(best)>=n else best
  W=literal(n,B,chosen)
  row={'n':n,'attained':len(chosen)>=n,'trials':trials,'best_seed':bestseed,
       'base':sorted(B),'optional':chosen,'optional_count':len(chosen),
       'literal_witnesses':W}
  rows.append(row)
  print(json.dumps({k:v for k,v in row.items()if k not in ['base','optional','literal_witnesses']}),flush=True)
 out={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'scope':'At most20 greedy orders per order, on the specified fixed compulsory core. Successful robust envelopes have complete literal witnesses. Failures are not impossibility results.',
      'seconds':time.monotonic()-started,'rows':rows}
 (ROOT/'research/routing-defect-phase2-dense-small-checks.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({'seconds':out['seconds'],'attained':[r['n']for r in rows if r['attained']]}))
if __name__=='__main__':main()

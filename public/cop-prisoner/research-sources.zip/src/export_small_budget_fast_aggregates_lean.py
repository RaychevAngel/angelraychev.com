#!/usr/bin/env python3
"""Rewrite selected, unchecked small-budget aggregates to the complete fast catalogue.

First reproduce the original split unit with export_small_budget_degree_profiles_lean.py.
This deterministic follow-up retains every finite branch and its literal catalogue,
changing only the complete enumeration used to reach those branches. It does not
search graphs, assert equality with the old recursion, or modify input files.
"""
from pathlib import Path
import argparse,hashlib,json,re

def transform(text,n,budget,bound,zero_two):
    assert f'namespace Delivery.SmallBudget' in text
    assert 'import SmallBudgetProfilesFast' not in text
    text='import SmallBudgetProfilesFast\n'+text
    for name in ['hardProfiles','profiles','upper_of_hard','sorted_member']:
        text=re.sub(r'(?<![\w.])'+name+r'\b','SmallBudgetProfilesFast.'+name,text)
    alphabet=[a for a in range(16*n)if a%16<n and a//16+a%16>=2 and
              ((a//16>0 and a%16>0)or(zero_two and a//16+a%16==2))]
    flag='true'if zero_two else'false'
    old=f'theorem catalogue_eq : SmallBudgetProfilesFast.hardProfiles {n} {budget} {bound} {flag}=catalogue := by decide +kernel'
    new=f'''theorem catalogue_eq : SmallBudgetProfilesFast.hardProfiles {n} {budget} {bound} {flag}=catalogue := by
  unfold SmallBudgetProfilesFast.hardProfiles SmallBudgetProfilesFast.profiles
  have letters : alphabet {n} {flag}={str(alphabet).replace(' ','')} := by decide +kernel
  rw [letters]
  decide +kernel'''
    assert old in text
    return text.replace(old,new)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--prefix',default='SmallBudgetTenFinite');p.add_argument('--budget',type=int,default=10)
    p.add_argument('--bound',type=int,default=6);p.add_argument('--orders',type=int,nargs='+',default=[7,8,9,10])
    p.add_argument('--no-zero-two',action='store_true');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    assert a.input_dir.resolve()!=a.out.resolve(),'Write into a separate directory.'
    files={};inputs={}
    for n in a.orders:
        source=a.input_dir/f'{a.prefix}{n}.lean';data=source.read_bytes();inputs[source.name]=hashlib.sha256(data).hexdigest()
        result=a.out/source.name;result.write_text(transform(data.decode(),n,a.budget,a.bound,not a.no_zero_two));files[result.name]=hashlib.sha256(result.read_bytes()).hexdigest()
    manifest=dict(scope='Deterministic fast-catalogue aggregate export; no kernel acceptance asserted.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=inputs,files=files)
    (a.out/'fast-aggregate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'aggregates':len(files),'out':str(a.out)}))
if __name__=='__main__':main()

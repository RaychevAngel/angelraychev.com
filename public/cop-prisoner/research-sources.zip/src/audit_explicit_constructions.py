#!/usr/bin/env python3
"""Audit existing coverage with derandomization removed; no graph searches.

This is numerical coverage readback plus a source-audited recipe registry,
not a new proof of graph strategies. Default writes the receipt; --check
recomputes without writing. Source audits state the infinite recipe domains.
"""
from pathlib import Path
import argparse
import hashlib
import json
import classification_coverage as coverage

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'research/explicit-construction-coverage.json'
DIRECT_RULES={
    'zero','antichain59','arc_even','arc_odd','arc_small','circle11',
    'circle_runs','circle_saved','dense58_bridge','dense58_endpoint',
    'dense58_staircase','dense_tiny','dense_zero','enumerated_n4',
    'enumerated_n5','enumerated_n6','exact23','five36','five37',
    'odd-endpoint-completion-certificate','root-small-structured-9-certificate',
    'small-exceptional-general-certificates','small-exceptional-structured-11-certificate',
    'antichain_all_parities','circle_third','mixed105','sparse_cyclic_finite',
    'dense_root_cycles','dense_nine_core','dense_first_small','exact22','sparse_third_lower',
    'circle_half_density','layered_guides','six_circle','reduced_hubs','staged_finite',
    'small_case_literal','small_case_stages','small12_13_lower',
}
AUDITS=['research/EXPLICIT_CONSTRUCTIONS.md','research/explicit-construction-main-audit.md',
        'research/explicit-construction-sparse-audit.md','research/explicit-construction-dense-audit.md']
RECIPE_SOURCES=[
 'paper/local-strategy-composition.md','paper/main-interval-layered.md',
 'paper/main-interval-reduced-hubs.md','research/guide-attachment-verification.json',
 'src/main_interval_pair_codes.py','src/main_interval_pair_codes_check.py',
 'research/main-interval-pair-code-checks.json','research/main-interval-pair-complete-checks.json',
 'src/odd_projection_threshold_check.py','research/odd-projection-threshold-audit.json',
 'src/dense_functional_transfer_check.py','research/dense-functional-transfer-audit.json',
 'src/main_interval_complete.py','src/main_interval_six_circle.py','src/main_interval_reduced_hubs.py','src/sparse_staged.py','paper/main-interval-complete.md','research/sparse-staged-records.json',
 'src/main_interval_expanded.py','paper/main-interval-new-overlap.md','src/main_interval_composed.py','src/core_code_composition.py','src/main_interval_resume.py',
 'src/dense_unified_core.py','src/dense_phase2_uniform_envelope.py','src/dense_phase2_quarter_envelope.py',
 'src/dense_protected_envelope.py','src/sparse_finite_bridge_construct.py',
 'research/main-interval-composed-checks.json','research/core-code-circle-overlap-screen.json',
 'research/routing-defect-phase2-mixed-code-checks.json',
 'src/core_code_all_parities.py','src/core_code_third_circles.py',
 'src/dense_third_root_cycles.py','src/dense_third_core_compose.py',
 'src/dense_third_first_step.py','research/sparse-interface-third-proof-registry.json',
 'src/main_interval_half_density.py','src/main_interval_layered.py',
 'src/classification_small_cases.py','src/small_case_results.py',
 'research/small-case-results.json','research/small-case-fixed-certificates.json',
 'research/small-case-stage-independent-review.json','src/small_case_stage_review.py',
 'src/small_case_certificate_review.py','paper/small-orders-resume.md',
 'paper/support-concentration.md','paper/sparse-third.md','paper/dense-third.md',
]

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def calculate():
    full=coverage.calculate()
    source_paths=set(coverage.READS)
    exact_rules={c[2] for row in full.values() for c in row if c[0]==c[1]}
    assert exact_rules<=DIRECT_RULES|{'orientation'},('Unaudited exact provider',exact_rules-DIRECT_RULES)
    current=json.loads((ROOT/'publication/classification-coverage.json').read_text())
    encoded=[coverage.encode_row(n,row) for n,row in full.items()]
    assert encoded==current['rows'],'Numerical ledger is stale'
    previous=coverage.known_exact
    def omit_derandomization(row,n,a,b,source,value=None):
        if source!='orientation':previous(row,n,a,b,source,value)
    coverage.known_exact=omit_derandomization
    try:direct=coverage.calculate()
    finally:coverage.known_exact=previous
    gaps=[];lower_changes=0;providers=set()
    for n,row in full.items():
        missing=[]
        for m,c in enumerate(row):
            d=direct[n][m]
            assert d[0]<=c[0],(n,m)
            lower_changes+=d[0]!=c[0]
            if c[0]==c[1]:
                if d[0]<c[0]:missing.append(m)
                else:
                    providers.add(d[2]);assert d[2]in DIRECT_RULES,(n,m,d[2])
        if missing:gaps.append({'n':n,'m_ranges':coverage.ranges(missing),'count':len(missing)})
    source_paths.update(AUDITS+RECIPE_SOURCES+['src/audit_explicit_constructions.py','publication/classification-coverage.json'])
    return {
      'scope':'Separate explicit-construction inventory for the currently indexed numerical coverage.',
      'method':'Read existing proof/data sources and recompute integer coverage after omitting orientation conditional expectation. No new graph search, game solve, parameter search or mathematical case.',
      'finite_box_n':[1,114],
      'admissible_cells':sum(map(len,full.values())),
      'numerically_exact_cells':sum(c[0]==c[1] for row in full.values()for c in row),
      'numerical_canonical_gaps':current['canonical_representatives']['unresolved'],
      'known_value_explicit_construction_gaps':gaps,
      'known_value_explicit_construction_gap_count':sum(g['count']for g in gaps),
      'lower_bounds_changed_without_orientation':lower_changes,
      'exact_lower_providers_audited':sorted(providers),
      'infinite_coverage_source_audit':{
        'direct_tail':'n>=11 and22<=m<=n(n-1); order11 has the stated exceptional values at22,23,24 and a certified staged interval25..88. The uniform complete main interval holds fromn12. Sparse, main, dense staircase and zero ranges each have direct recipes or listed finite graphs.',
        'other_direct_infinite_domains':'The listed sparse endpoint/isolate, circle, antichain, dense and finite-component padding domains in EXPLICIT_CONSTRUCTIONS.md',
        'small_budget_tail':'For 0<m<=21,n>B_m, copy the explicit graph at host B_m and add isolates whenever that value is known. For m=12..21 the reviewed caps are12,13,16,18,15,18,15,18,11,15; other budgets retain B_m=2m. The20-arrow cap also uses the proved fresh-sink replacement. At m=0 use the empty graph.',
        'boundary':'These infinite recipe claims are source audits of existing ordinary proofs and formulas, not inferred from finite computation or the numerical order threshold alone.'},
      'classification_rule':'A numerical equality does not automatically close an explicit-construction gap. Future exact providers outside the reviewed registry require a new recipe audit.',
      'limits':'Coverage identity/recipe-source audit only; the ordinary strategy proofs, full finite certificate validity and precise Lean boundary remain those of the retained sources. A unified executable is optional, not a missing mathematical theorem.',
      'source_sha256':{s:digest(ROOT/s)for s in sorted(source_paths)},
    }

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check',action='store_true');a=p.parse_args()
    data=calculate()
    if a.check:assert json.loads(OUT.read_text())==data,'Construction audit receipt differs from recomputation'
    else:OUT.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'checked'if a.check else'written':True,'exact_cells':data['numerically_exact_cells'],'construction_only_gaps':data['known_value_explicit_construction_gap_count'],'lower_bound_changes_without_orientation':data['lower_bounds_changed_without_orientation']}))
if __name__=='__main__':main()

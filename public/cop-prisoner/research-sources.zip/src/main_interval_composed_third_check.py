#!/usr/bin/env python3
"""Read-only replay of the fixed n106..114 dispatcher extension.

Checks exact family boundaries, literal sparse B/E certificate identity,
protected differences, full asymmetric code witnesses, and robust dense
witnesses. It also replays the retained pre-extension outputs at old orders.
This is not a new game search or a Lean proof.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import zipfile

import main_interval_composed as dispatcher
import core_code_all_parities as code_recipe
from core_code_all_parities_check import witnesses
from dense_unified_core import envelope, robust_check

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT/'research/main-interval-composed-third-checks.json'
ORDERS = tuple(range(106,115))
OLD_ORDERS = tuple(range(115,391))+(391,480,481,699,700,701)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_hash(data):
    return digest(json.dumps(data,sort_keys=True,separators=(',',':')).encode())


def baseline_from_original(path):
    original=json.loads(path.read_text())
    return {'source_sha256':original['source_sha256'],
            'parameters':{n:json_hash(p) for n,p in original['parameters'].items()},
            'graphs':original['graphs']}


def run(baseline):
    assert set(map(int,baseline['parameters']))==set(OLD_ORDERS)
    assert len(baseline['graphs'])==24
    assert {x['n'] for x in baseline['graphs']}=={115,116,117}
    for n in OLD_ORDERS:
        assert json_hash(dispatcher.parameters(n))==baseline['parameters'][str(n)],n
    for row in baseline['graphs']:
        assert json_hash(dispatcher.construct(row['n'],row['m']))==row['sha256'],row
    registry=json.loads((ROOT/'research/sparse-interface-third-proof-registry.json').read_text())
    bundle=ROOT/registry['bundle']
    assert digest(bundle.read_bytes())==registry['bundle_sha256']
    selected={r['n']:r for r in registry['records'] if r['n'] in ORDERS
              and r['variant']==('repair109' if r['n']==109 else None)}
    assert set(selected)==set(ORDERS)
    rows=[];boundaries=[];branches=set()
    with zipfile.ZipFile(bundle) as z:
        for n in ORDERS:
            p=dispatcher.parameters(n);r=selected[n]
            data=z.read(r['member']);assert digest(data)==r['sha256']
            member=json.loads(gzip.decompress(data))
            assert len(member['graphs'])==1
            sparse=member['graphs'][0]['graph']
            B=set(map(tuple,sparse['base']));O=set(map(tuple,sparse['optional']));E=B|O
            assert len(B)==2*n and len(E)==p['sparse_max']==r['m_max']
            assert dispatcher.sparse_arcs(n,2*n,p)[0]==B
            assert dispatcher.sparse_arcs(n,p['sparse_max'],p)[0]==E
            assert dispatcher.sparse_arcs(n,2*n,p)[1]['maximum_delivery_moves']==r['maximum_moves']
            if n==109:
                assert {(8,22),(14,108)}<=O and p['sparse_max']==327
            core=set(p['circle_core']);values=set(p['circle_values'])
            dispatcher.verify_circle(n,tuple(p['circle_core']),values)
            CB={(v,(v+d)%n) for v in range(n) for d in core}
            CE={(v,(v+d)%n) for v in range(n) for d in values-{0}}
            assert dispatcher.circle_arcs(n,3*n,p)[0]==CB
            assert dispatcher.circle_arcs(n,p['circle_max'],p)[0]==CE
            codes=code_recipe.construction(10,3,n-20)
            KB=set(map(tuple,codes['base']));KE=KB|set(map(tuple,codes['optional']))
            assert len(KB)==37*n-400==p['code_base']
            assert len(KE)==n*(n-1)-(3*n-20)==p['code_max']
            assert dispatcher.code_arcs(n,p['code_base'],p)[0]==KB
            assert dispatcher.code_arcs(n,p['code_max'],p)[0]==KE
            witness_count=witnesses(codes)
            DB,DO=envelope(n)
            dense_checks=robust_check(n,DB,DO)
            assert p['sparse_max']>=3*n and p['circle_max']>=p['code_base']
            assert p['code_max']>=n*(n-1)-3*n
            last=n*(n-3);split=n*(n-1)-3*n
            points={2*n,2*n+1,3*n,last,split-1,split,split+1}
            for edge in (p['sparse_max'],p['circle_max'],p['code_base'],p['code_max']):
                points.update((edge-1,edge,edge+1))
            if n==109:points.update((325,326,327))
            for m in sorted(x for x in points if 2*n<=x<=last):
                g=dispatcher.construct(n,m);A=set(map(tuple,g['arcs']));branch=g['branch']
                assert len(A)==len(g['arcs'])==m and g['I']==n*(n-1)-m
                assert all(0<=u<n and 0<=v<n and u!=v for u,v in A)
                if branch=='sparse_packed':assert B<=A<=E
                elif branch=='protected_circle':assert CB<=A<=CE
                elif branch=='core_antichain':assert KB<=A<=KE
                elif branch=='dense_direct':
                    F={(u,v) for u in range(n) for v in range(n) if u!=v and (u,v) not in A}
                    assert DB<=F<=DB|DO
                else:raise AssertionError(branch)
                branches.add(branch)
                boundaries.append({'n':n,'m':m,'branch':branch,'sha256':json_hash(g)})
            rows.append({'n':n,'sparse_max':len(E),'sparse_maximum_moves':r['maximum_moves'],
                         'sparse_certificate_member':r['member'],
                         'circle_max':len(CE),'code_interval':[len(KB),len(KE)],
                         'dense_start':split,'asymmetric_code_witnesses':witness_count,
                         'robust_dense_witnesses':dense_checks})
    assert branches=={'sparse_packed','protected_circle','core_antichain','dense_direct'}
    for n,m in ((105,210),(106,211),(106,106*103+1)):
        try:dispatcher.construct(n,m)
        except ValueError:pass
        else:raise AssertionError((n,m))
    pins=['src/main_interval_composed.py','src/main_interval_composed_third_check.py',
          'src/core_code_all_parities.py','src/core_code_all_parities_check.py',
          'src/dense_unified_core.py','research/core-code-third-circle-envelopes.json',
          'research/core-code-circle-overlap-screen.json',
          'research/sparse-interface-third-proof-registry.json']
    return {'verified':True,'orders':list(ORDERS),'boundary_constructions':len(boundaries),
            'rows':rows,'constructions':boundaries,'old_regression':baseline,
            'old_parameter_orders_replayed':len(OLD_ORDERS),'old_graphs_replayed':24,
            'sparse_bundle_sha256':registry['bundle_sha256'],
            'source_sha256':{p:digest((ROOT/p).read_bytes()) for p in pins},
            'scope':'Fixed orders106..114. Each selected sparse B/E is identical to its previously independently replayed rank certificate; ranks are not recomputed by this checker. Circles pass all six protected-difference tests. Every code and dense envelope receives all asymmetric/robust two-move witness checks. Exact boundaries and all old outputs listed in the regression are replayed. The infinite n>=115 proof and all Lean boundaries remain unchanged.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true')
    parser.add_argument('--out',type=Path,default=DEFAULT)
    parser.add_argument('--baseline',type=Path)
    args=parser.parse_args()
    if args.baseline:
        assert not args.check
        baseline=baseline_from_original(args.baseline)
    else:baseline=json.loads(args.out.read_text())['old_regression']
    result=run(baseline)
    if args.check:assert json.loads(args.out.read_text())==result
    else:args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'verified':True,'orders':len(ORDERS),
                      'boundary_constructions':result['boundary_constructions'],
                      'old_parameter_orders_replayed':len(OLD_ORDERS),'old_graphs_replayed':24,
                      'code_witnesses':sum(r['asymmetric_code_witnesses'] for r in result['rows']),
                      'dense_witnesses':sum(r['robust_dense_witnesses'] for r in result['rows'])}))


if __name__=='__main__':main()

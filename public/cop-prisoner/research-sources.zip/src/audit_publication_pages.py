"""Check local website links and retained proof labels for this publication."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse, unquote
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / '.site-worktree/dist'


class Page(HTMLParser):
    def __init__(self, text):
        super().__init__()
        self.ids = set()
        self.links = []
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.add(attrs['id'])
        key = 'href' if tag == 'a' else 'src' if tag in ('img', 'script') else None
        if key and attrs.get(key):
            self.links.append(attrs[key])


routes = ['', 'proofs/', 'paper/', 'lean/', 'delivery-time/']
pages = {route: Page((DIST / 'cop-prisoner' / route / 'index.html').read_text()) for route in routes}
page_cache = {DIST / 'cop-prisoner' / route / 'index.html': page for route, page in pages.items()}
checked = 0
for route, page in pages.items():
    for link in page.links:
        parsed = urlparse(link)
        if parsed.scheme and parsed.netloc != 'angelraychev.com':
            continue
        if not parsed.path or parsed.path.startswith('/cop-prisoner/'):
            path = parsed.path or '/cop-prisoner/' + route
            target = DIST / path.lstrip('/')
            if path.endswith('/'):
                target = target / 'index.html'
            assert target.is_file(), (route, link, 'missing target')
            if parsed.fragment:
                if target not in page_cache:
                    page_cache[target] = Page(target.read_text())
                assert unquote(parsed.fragment) in page_cache[target].ids, (route, link, 'missing anchor')
            checked += 1
old = subprocess.check_output(['git', 'show', '44b10d90993a246c6b8d930313e890763fe00ce1:paper/assembled.md'], cwd=ROOT, text=True)
new = (ROOT / 'paper/assembled.md').read_text()
labels = lambda text: set(re.findall(r'\*\*(?:Theorem|Lemma|Corollary|Proposition)\s+(\d+(?:\.\d+)?)', text))
assert labels(old) <= labels(new), ('lost numbered labels', labels(old) - labels(new))
assert 'the-scale-of-the-first-universal-two-move-budget' in pages['proofs/'].ids
assert 'the-scale-of-the-first-universal-two-move-budget' in pages['delivery-time/'].ids
print(json.dumps({'routes': len(routes), 'links_and_assets_checked': checked,
                  'broken_links': 0, 'numbered_labels_preserved': len(labels(old)),
                  'moved_two_move_anchor_preserved': True}, indent=2))

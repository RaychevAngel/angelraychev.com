// Small-arc specialization: add the proved degree-incidence bound (1).
// Independent descending-degree/suffix-cell enumeration and explicit game.
// Use [first,last) profile intervals to keep each audit batch bounded.
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
int n,T,lo,hi,begin_profile,end_profile,deg[12],rowmask[12],pred[12],all;vector<int>opts[12][12];long long nodes=0,leaves=0,survivors=0;int profile=0,checked_profiles=0,best=0;bool complete=true,found=false;double limit;auto began=chrono::steady_clock::now();
int delivery_count(){int ans=0,size=2*n*n;vector<vector<int>>prev(n);for(int u=0;u<n;u++){prev[u].push_back(u);for(int v=0;v<n;v++)if(rowmask[u]>>v&1)prev[v].push_back(u);}vector<unsigned char>W(size);vector<int>rem(size),queue;for(int t=0;t<n;t++){fill(W.begin(),W.end(),0);queue.clear();for(int r=0;r<n;r++)for(int c=0;c<n;c++)rem[2*(r*n+c)+1]=deg[c]+1;for(int c=0;c<n;c++)for(int turn=0;turn<2;turn++){int z=2*(t*n+c)+turn;W[z]=1;queue.push_back(z);}for(size_t h=0;h<queue.size();h++){int z=queue[h],r=z/(2*n),c=z/2%n;if(z%2){for(int s:prev[r]){int q=2*(s*n+c);if(s!=c&&!W[q]){W[q]=1;queue.push_back(q);}}}else for(int p:prev[c]){int q=2*(r*n+p)+1;if(r!=p&&!W[q]&&--rem[q]==0){W[q]=1;queue.push_back(q);}}}for(int s=0;s<n;s++)if(s!=t&&!(rowmask[s]>>t&1)){bool guaranteed=true;for(int c=0;c<n;c++)if(c!=s&&!W[2*(s*n+c)])guaranteed=false;ans+=guaranteed;}}return ans;}
bool source_blocked(int s,int assigned){if(deg[s]==2)for(int z=0;z<n;z++)if(deg[z]==0&&(rowmask[s]>>z&1))return true;for(int c=0;c<assigned;c++)if(c!=s){if((rowmask[s] & ~(rowmask[c] | (1<<c))) == 0)return true;}return false;}
bool possible(int row){
 int sumrows=0,q=0;
 for(int s=0;s<n;s++)if(deg[s]>=2&&(s>=row||!source_blocked(s,row))){sumrows+=n-1-deg[s];q++;}
 if(sumrows<T)return false;
 vector<int>cost;int column=0,budget_left=0;
 for(int s=row;s<n;s++)budget_left+=deg[s];
 for(int t=0;t<n;t++){
  int d=__builtin_popcount((unsigned)pred[t]);
  if(d+n-row-(t>=row)>=2){column+=n-1-max(2,d);cost.push_back(max(0,2-d));}
 }
 if(column<T)return false;
 sort(cost.begin(),cost.end());int rmax=0;
 for(int k:cost){if(k>budget_left)break;budget_left-=k;rmax++;}
 for(int r=0;r<=rmax;r++)if(q*r-max(0,q+r-n)-max(0,2*q+2*r-hi)>=T)return true;
 return false;
}
void recurse(int row){if(!complete||found)return;if((++nodes%65536)==0&&chrono::duration<double>(chrono::steady_clock::now()-began).count()>limit){complete=false;return;}if(!possible(row))return;if(row==n){leaves++;int bound=0;for(int s=0;s<n;s++)if(deg[s]>=2&&!source_blocked(s,n))for(int t=0;t<n;t++)if(t!=s&&!(rowmask[s]>>t&1)&&__builtin_popcount((unsigned)pred[t])>=2){bool blocked=false;for(int c=0;c<n;c++)if(c!=s){if((pred[t] & ~(rowmask[c] | (1<<c))) == 0){blocked=true;break;}}bound+=!blocked;}if(bound<T)return;survivors++;int v=delivery_count();best=max(best,v);found|=v>=T;return;}
for(int mask:opts[row][deg[row]]){bool ok=true;for(int v=row+2;v<n;v++)if(deg[v-1]==deg[v]&&pred[v-1]==pred[v]&&(mask>>(v-1)&1)&&!(mask>>v&1)){ok=false;break;}if(!ok)continue;rowmask[row]=mask;for(int v=0;v<n;v++)if(mask>>v&1)pred[v]|=1<<row;recurse(row+1);for(int v=0;v<n;v++)pred[v]&=~(1<<row);if(!complete||found)return;}}
void profiles(int row,int largest,int total){if(!complete||found)return;if(row==n){if(total<lo||total>hi)return;int id=profile++;if(id>=begin_profile&&id<end_profile){checked_profiles++;recurse(0);}return;}int active=(T+n-4)/(n-3);for(int d=largest;d>=0;d--){if(row<active&&d<2)break;if(total+d>hi)continue;if(total+d*(n-row)<lo)break;deg[row]=d;profiles(row+1,d,total+d);}}
int main(int argc,char**argv){n=atoi(argv[1]);T=atoi(argv[2]);lo=atoi(argv[3]);hi=atoi(argv[4]);limit=atof(argv[5]);begin_profile=argc>6?atoi(argv[6]):0;end_profile=argc>7?atoi(argv[7]):100000;all=(1<<n)-1;for(int u=0;u<n;u++)for(int m=all;m>=0;m--)if(!(m>>u&1))opts[u][__builtin_popcount((unsigned)m)].push_back(m);profiles(0,n-1,0);cout<<"{\"n\":"<<n<<",\"target_I\":"<<T<<",\"complete\":"<<(complete&&!found?"true":"false")<<",\"counterexample_found\":"<<(found?"true":"false")<<",\"first_profile\":"<<begin_profile<<",\"last_profile_exclusive\":"<<end_profile<<",\"total_profiles\":"<<profile<<",\"checked_profiles\":"<<checked_profiles<<",\"nodes\":"<<nodes<<",\"leaves\":"<<leaves<<",\"static_survivors\":"<<survivors<<",\"best_I\":"<<best<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-began).count()<<"}\n";}

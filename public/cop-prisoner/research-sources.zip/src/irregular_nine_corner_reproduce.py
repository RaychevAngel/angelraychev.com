#!/usr/bin/env python3
"""Reproduce the mixed nine-profile source corpus from preserved public inputs.

This is an untrusted source transformer, not a proof checker.  It reads the
archived original Lean literals and a small degree-profile manifest; neither
the private replay cache nor the temporary producer DAGs are required.  Every
output is compared with the immutable migration audit before it is written.
The repository's pinned Lean replay must still check the resulting proofs.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import tarfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "research/lean-irregular-nine-corner-reproduction-2026-10-23.json"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checked_file(entry: dict) -> bytes:
    data = (ROOT / entry["path"]).read_bytes()
    if digest(data) != entry["sha256"]:
        raise ValueError(f"input hash mismatch: {entry['path']}")
    return data


def transform(old: bytes, profile: dict, expected_leaves: int) -> tuple[bytes, dict]:
    """Recover prefixes/pair lists from the original source, not producer data."""
    text = old.decode("utf-8")
    pid = profile["profile_id"]
    degrees_out, degrees_in = profile["outdegrees"], profile["indegrees"]
    pair_lists = {}
    for match in re.finditer(r"^def b(\d+) : PairBound 9 := (.*)$", text, re.M):
        pairs = re.search(r"\bpairs := (\[[^\]]*\])", match[2])
        if pairs is None:
            raise ValueError("missing literal pair list")
        pair_lists[int(match[1])] = ast.literal_eval(pairs[1])
    pattern = re.compile(
        rf"(theorem u(\d+) : Upper \(D {pid}\) \(R {pid}\) "
        r"(\[[0-9,]*\]) 13 :=\n)"
        rf"  PairNine.sound _ _ _ _ \(leftConstant {pid}\) 14 b(\d+)\n"
    )
    histogram: dict[int, int] = {}

    def replace(match: re.Match) -> str:
        index = int(match[2])
        if index != int(match[4]) or index not in pair_lists:
            raise ValueError("leaf identity mismatch")
        prefix = ast.literal_eval(match[3])
        pairs = pair_lists[index]
        if len(prefix) > 9 or any(type(m) is not int or not 0 <= m < 512 for m in prefix):
            raise ValueError("invalid literal prefix")
        if len(pairs) != len(set(pairs)):
            raise ValueError("duplicate losing pair")
        needed = max(0, profile["left_constant"] - 13 - 14 - len(pairs))
        corners = [(s, t) for s, mask in enumerate(prefix) if degrees_out[s] < 2
                   for t in range(9) if degrees_in[t] < 2 and (mask >> t) & 1][:needed]
        if len(corners) != needed:
            raise ValueError("insufficient literal corner witnesses")
        literal = "[" + ",".join(f"({s},{t})" for s, t in corners) + "]"
        histogram[needed] = histogram.get(needed, 0) + 1
        return (match[1] + "  CornerWitnessNine.sound _ _ _ _ "
                f"(leftConstant {pid}) 14 b{index} {literal}\n")

    changed, count = pattern.subn(replace, text)
    if count != expected_leaves or count != len(pair_lists) or "PairNine.sound" in changed:
        raise ValueError("incomplete source transformation")
    return ("import RowPrefixCornerWitness\n" + changed).encode(), histogram


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=DEFAULT)
    parser.add_argument("--output", type=Path, required=True,
                        help="new dedicated output directory; existing paths are rejected")
    parser.add_argument("--verify-current", action="store_true",
                        help="also compare all reproduced sources with this checkout")
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("output must be a new directory")
    manifest = json.loads(args.manifest.read_text())
    if digest(Path(__file__).read_bytes()) != manifest["reproducer_sha256"]:
        raise ValueError("reproducer source hash mismatch")
    audit = json.loads(checked_file(manifest["migration_audit"]))
    checked_file(manifest["original_migration_exporter"])
    kernel = checked_file(manifest["kernel"])
    if digest(kernel) != audit["kernel_sha256"]:
        raise ValueError("kernel does not match migration")
    archive = ROOT / audit["legacy_archive"]
    if digest(archive.read_bytes()) != audit["legacy_archive_sha256"]:
        raise ValueError("legacy archive hash mismatch")
    profiles = {p["profile_id"]: p for p in manifest["profiles"]}
    if set(profiles) != set(range(11)):
        raise ValueError("incomplete degree-profile manifest")
    for profile in profiles.values():
        source = profile["producer_input"]
        if source["sha256"] != audit["input_sha256"][source["path"]]:
            raise ValueError("degree-profile provenance mismatch")
        if not (len(profile["outdegrees"]) == len(profile["indegrees"]) == 9):
            raise ValueError("incorrect profile size")
    updates = {u["module"]: u for u in audit["updates"]}
    outputs: dict[str, bytes] = {}
    seen_updates = set()
    histogram: dict[int, int] = {}
    # Archive bytes retain their historical member names. Current manifests
    # name durable extraction paths; aliases are explicit historical metadata.
    aliases = audit.get("legacy_archive_member_aliases", {})
    if not set(aliases) <= set(audit["legacy_file_hashes"]) or len(set(aliases.values())) != len(aliases):
        raise ValueError("invalid archive member aliases")
    current_names = {old: current for current, old in aliases.items()}
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar:
            output_name = current_names.get(member.name, member.name)
            path = PurePosixPath(output_name)
            archived_path = PurePosixPath(member.name)
            if any(p.is_absolute() or ".." in p.parts for p in (path, archived_path)) or not member.isfile() or output_name in outputs:
                raise ValueError("unsafe or duplicate archive member")
            old = tar.extractfile(member).read()
            if digest(old) != audit["legacy_file_hashes"].get(output_name):
                raise ValueError(f"legacy member hash mismatch: {member.name}")
            new = old
            module = path.stem
            if path.suffix == ".lean" and module in updates:
                update = updates[module]
                if digest(old) != update["old_source_sha256"]:
                    raise ValueError("old source pin mismatch")
                match = re.fullmatch(r"IrregularNine14P(\d{2})C\d{4}", module)
                if match is None:
                    raise ValueError("unexpected transformed module")
                new, counts = transform(old, profiles[int(match[1])], update["changed_leaves"])
                if digest(new) != update["new_source_sha256"]:
                    raise ValueError(f"reproduced source mismatch: {module}")
                seen_updates.add(module)
                for size, count in counts.items():
                    histogram[size] = histogram.get(size, 0) + count
            outputs[output_name] = new
    if set(outputs) != set(audit["legacy_file_hashes"]) or seen_updates != set(updates):
        raise ValueError("incomplete archived corpus or migration coverage")
    if histogram != {int(k): v for k, v in audit["corner_lengths"].items()}:
        raise ValueError("corner witness histogram mismatch")
    outputs[manifest["kernel"]["path"]] = kernel
    if args.verify_current:
        for path, data in outputs.items():
            if (ROOT / path).read_bytes() != data:
                raise ValueError(f"current checkout differs: {path}")
    args.output.mkdir(parents=True)
    for path, data in outputs.items():
        target = args.output / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    result = {
        "scope": "Source reproduction only; no Lean proof acceptance is asserted.",
        "legacy_metadata": "Archived original manifests describe pre-migration sources; the pinned migration audit describes the mixed output.",
        "manifest_sha256": digest(args.manifest.read_bytes()),
        "files": len(outputs), "changed_chunks": len(updates),
        "changed_leaves": sum(u["changed_leaves"] for u in updates.values()),
        "corner_lengths": histogram, "verified_current": args.verify_current,
        "output_sha256": {path: digest(data) for path, data in sorted(outputs.items())},
    }
    (args.output / "REPRODUCTION.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "output_sha256"}))


if __name__ == "__main__":
    main()

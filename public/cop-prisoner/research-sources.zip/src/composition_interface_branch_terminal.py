#!/usr/bin/env python3
"""Retain exterior tree-branch provenance for local terminal modules.
This arena is sound on the infinite free tree. A finite-quotient claim requires
a separate bounded-time/no-shortcut proof and a sufficiently large girth.
"""
import json,time,hashlib
from pathlib import Path
from composition_interface_free_group import rules,ball,step,GEN
from composition_interface_invariant import attract
from composition_interface_certify import good
ROOT=Path(__file__).resolve().parents[1]

def arena(mrad=2,crad=3,branchdepth=1,swaps=(0,1,3),extras=()):
 rr=rules(swaps)
 for u,v in extras:rr[u].append((0,v))
 mw=ball(mrad);cw=ball(crad);branches=[w for w in ball(branchdepth) if len(w)==branchdepth]
 M=[(w,i) for w in mw for i in range(10)];C=[(w,i) for w in cw for i in range(10)]+[(None,(b,i)) for b in branches for i in range(10)]
 mi={v:i for i,v in enumerate(M)};ci={v:i for i,v in enumerate(C)};mo=[];co=[]
 for w,i in M:
  suc={mi[w,i]}
  for g,j in rr[i]:
   z=step(w,g) if g else w
   if (z,j) in mi:suc.add(mi[z,j])
  mo.append(sorted(suc))
 for w,desc in C:
  suc={ci[w,desc]}
  if w is not None:
   for g,j in rr[desc]:
    z=step(w,g) if g else w
    suc.add(ci[z,j] if len(z)<=crad else ci[None,(z[:branchdepth],j)])
  else:
   branch,i=desc
   for g,j in rr[i]:
    suc.add(ci[None,(branch,j)])
    if g:
     for z in cw:
      prior=step(z,-g)
      if prior[:branchdepth]==branch and len(prior)>crad:suc.add(ci[z,j])
  co.append(sum(1<<c for c in suc))
 return M,C,mi,ci,mo,co

def run(mrad=2,crad=3,branchdepth=1,limit=20):
 ar=arena(mrad,crad,branchdepth);M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1;records=[];start=time.monotonic()
 required=[(mi[(),i],c) for i in range(10) for c,(cw,j) in enumerate(C) if good(i,cw,j)]
 for w in ((),(-1,),(-1,-1),(1,),(2,)):
  for target in (1,2,4):
   tr=mi[w,target];W,rounds=attract(ar,[allc if r==tr else 0 for r in range(len(M))],{tr})
   bad=[(M[r][1],C[c]) for r,c in required if not(W[r]>>c&1)]
   d={'word':w,'target':target,'failed':len(bad),'rounds':rounds,'first_failure':bad[0] if bad else None};records.append(d);print(d,flush=True)
  if time.monotonic()-start>limit:break
 return {'scope':'free-tree branch provenance diagnostic; finite-quotient simulation not yet supplied','mrad':mrad,'crad':crad,'branchdepth':branchdepth,'seconds':time.monotonic()-start,'records':records}

if __name__=='__main__':
 out=run();out['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 (ROOT/'research/composition-interface-branch-terminal.json').write_text(json.dumps(out,indent=2)+'\n')

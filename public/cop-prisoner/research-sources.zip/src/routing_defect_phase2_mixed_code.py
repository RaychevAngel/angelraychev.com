#!/usr/bin/env python3
"""Explicit mixed-size antichain at n116, independent safe-witness verifier."""
from itertools import combinations
from pathlib import Path
import hashlib,json


def cycle_codes(k,r):
 out=[]
 for S in combinations(range(k),r):
  if any(b-a==1 for a,b in zip(S,S[1:]))or(S[0]==0 and S[-1]==k-1):continue
  out.append(frozenset((2*j)%k for j in S))
  out.append(frozenset(k+j for j in S))
 return out


def main():
 k=11;n=116;q=n-2*k
 five=cycle_codes(k,5)[:2]
 fours=[S for S in cycle_codes(k,4)if not any(S<T for T in five)]
 codes=five+fours[:q-2]
 assert len(codes)==q and sum(map(len,codes))==378
 assert all(not S<=T for i,S in enumerate(codes)for j,T in enumerate(codes)if i!=j)
 F={(i,k+i)for i in range(k)}|{(i,k+(i-1)%k)for i in range(k)}
 F|={(k+i,(i+4)%k)for i in range(k)}|{(k+i,(i+6)%k)for i in range(k)}
 B={(s,t)for s in range(2*k)for t in range(2*k)if s!=t and(s,t)not in F}
 B|={(s,t)for s in range(2*k)for t in range(2*k,n)}
 B|={(2*k+j,t)for j,S in enumerate(codes)for t in range(2*k)if t not in S}
 O={(s,t)for s in range(2*k,n)for t in range(2*k,n)if s!=t}
 assert len(B)==4176
 out=[0]*n;pred=[0]*n;cop=[1<<c for c in range(n)]
 for s,t in B:out[s]|=1<<t;pred[t]|=1<<s;cop[s]|=1<<t
 for s,t in O:cop[s]|=1<<t
 checked=0
 for s in range(n):
  for t in range(n):
   if s==t or(s,t)in B:continue
   mids=out[s]&pred[t]
   for c in range(n):
    if c==s:continue
    assert mids&~cop[c],(s,t,c)
    checked+=1
 A={0,1,20}|set(range(41,60))|set(range(100,116));nn=117;h=41;a=20
 D={(x-y)%nn for x in (1,a,h)for y in (1,a,h)if x!=y}
 assert len(A)==38
 for d in D:assert sum((x+d)%nn in A for x in A)==1
 result={'verified':True,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'scope':'Explicit mixed-antichain construction at116 with all asymmetric safe two-move witnesses; explicit protected envelope at117. No negative or infinite game-search inference.',
         'mixed116':{'n':n,'k':k,'codes':[sorted(S)for S in codes],
                     'size4_available_after_removal':len(fours),'total_code_weight':378,
                     'base_arcs':len(B),'optional_arcs':len(O),
                     'terminal_missing':n*(n-1)-len(B)-len(O),
                     'asymmetric_checks':checked},
         'envelope117':{'n':117,'a':20,'h':41,'A':sorted(A),'capacity':117*37}}
 (Path(__file__).resolve().parents[1]/'research/routing-defect-phase2-mixed-code-checks.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k not in ['mixed116','envelope117']}))
 print(json.dumps({k:v for k,v in result['mixed116'].items()if k!='codes'}))
 print(json.dumps(result['envelope117']))
if __name__=='__main__':main()

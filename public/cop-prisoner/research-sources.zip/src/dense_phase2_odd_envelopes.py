#!/usr/bin/env python3
"""Bounded search for finite odd robust envelopes; separate from public generators."""
from dense_unified_core import even_core, masks, robust_check
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def candidate(n,j,z):
    k=(n-1)//2; w=n-1
    b=even_core(k)
    for p in (0,j):
        b.remove((p,k+p)); b.update(((p,w),(w,k+p)))
    o={(i,(i+6)%k) for i in range(k)}
    o|={(k+i,k+(i+4)%k) for i in range(k)}
    o.add((w,z))
    return b,o

def bad(n,b,o):
    bo,_=masks(n,b); fo,fi=masks(n,b|o)
    return [(s,t,c) for s,t in b|o for c in range(n)
            if c!=s and not bo[c]&~(fo[s]|fi[t])]

def improve(n,b,o):
    current=bad(n,b,o)
    changes=[]
    for depth in range(5):
        if not current: return o,changes
        best=(len(current),None)
        # Only optional arcs incident to a failed source or destination can
        # alter that failure. Changing source also changes which tests exist.
        choices={a for a in o if any(a[0]==s or a[1]==t or a==(s,t)
                                   for s,t,c in current)}
        for old in sorted(choices):
            for t in range(n):
                new=(old[0],t)
                if t==old[0] or new in b|o: continue
                oo=(o-{old})|{new}
                score=len(bad(n,b,oo))
                if score < best[0]:
                    best=(score,(old,new,oo))
        if best[1] is None: return None,changes
        old,new,o=best[1]; changes.append((old,new)); current=bad(n,b,o)
    return (o if not current else None),changes

def main():
    result=[]
    for n in (23,25,27,31):
        k=(n-1)//2
        candidates=[]
        for j in range(3,k-2):
            for z in range(n-1):
                b,o=candidate(n,j,z)
                candidates.append((len(bad(n,b,o)),j,z,b,o))
        candidates.sort(key=lambda x:x[:3])
        found=None
        for score,j,z,b,o in candidates[:12]:
            oo,changes=improve(n,b,o)
            if oo is not None:
                robust_check(n,b,oo)
                found={'n':n,'j':j,'z':z,'initial_bad':score,
                       'changes':changes,'base':sorted(b),'optional':sorted(oo)}
                break
        result.append(found or {'n':n,'failed':True,'best_initial':candidates[0][:3]})
        print(json.dumps({k:v for k,v in result[-1].items() if k not in ('base','optional')}),flush=True)
    (ROOT/'research/dense-phase2-odd-envelopes.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__': main()

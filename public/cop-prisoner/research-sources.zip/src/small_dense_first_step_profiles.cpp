// Bounded complete row-profile search for the remaining first dense steps.
// Completion is recorded explicitly; interrupted runs are not exclusions.
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
using Rows=array<unsigned,10>;
Rows rows{}; array<bool,10> assigned{}; vector<unsigned> domain[10];
int n,defect,target; unsigned allv; uint64_t nodes=0,leaves=0;
int best=-1; bool capped=false,found=false;
double seconds; chrono::steady_clock::time_point started;

int forced(){
 Rows lost{};
 for(int s=0;s<n;s++)if(assigned[s])
  for(int c=0;c<n;c++)if(c!=s&&assigned[c]&&!(rows[c]&~(rows[s]|(1u<<s))))lost[s]|=rows[s];
 for(int c=0;c<n;c++)if(assigned[c]){
  unsigned common=allv;bool ready=true;
  for(unsigned b=rows[c];b;b&=b-1){int v=__builtin_ctz(b);if(!assigned[v]){ready=false;break;}common&=rows[v];}
  if(ready)for(int s=0;s<n;s++)if(s!=c&&assigned[s])lost[s]|=rows[s]&common;
 }
 int count=0;for(int s=0;s<n;s++)count+=__builtin_popcount(lost[s]);return count;
}

int score(){
 Rows out{};for(int s=0;s<n;s++)out[s]=allv^rows[s];int count=0;
 for(int t=0;t<n;t++){
  Rows wins{};wins[t]=allv;
  for(;;){
   Rows safe{},next{};safe[t]=allv;
   for(int v=0;v<n;v++)if(v!=t)for(int c=0;c<n;c++)if(!(out[c]&~wins[v]))safe[v]|=1u<<c;
   for(int s=0;s<n;s++){
    if(s==t){next[s]=allv;continue;}
    for(unsigned b=out[s];b;b&=b-1)next[s]|=safe[__builtin_ctz(b)];
    next[s]&=allv^(1u<<s);
   }
   if(next==wins)break;wins=next;
  }
  for(int s=0;s<n;s++)if((rows[s]>>t&1)&&wins[s]==(allv^(1u<<s)))count++;
 }
 return count;
}

void emit(const char*kind,int value=-1){
 cout<<"{\"kind\":\""<<kind<<"\",\"n\":"<<n<<",\"defect_cap\":"<<defect
     <<",\"nodes\":"<<nodes<<",\"leaves\":"<<leaves<<",\"I\":"<<value
     <<",\"best_I\":"<<best<<",\"capped\":"<<(capped?"true":"false")<<",\"missing_masks\":[";
 for(int s=0;s<n;s++)cout<<(s?",":"")<<rows[s];cout<<"]}"<<endl;
}

void visit(int depth){
 if(capped||found)return;++nodes;
 if((nodes&1023)==0&&chrono::duration<double>(chrono::steady_clock::now()-started).count()>seconds){capped=true;return;}
 if(depth==n){++leaves;int value=score();best=max(best,value);emit("leaf",value);if(value>=target)found=true;return;}
 int chosen=-1;vector<unsigned> allowed;
 for(int s=0;s<n;s++)if(!assigned[s]){
  vector<unsigned> valid;assigned[s]=true;
  for(unsigned row:domain[s]){rows[s]=row;if(forced()<=defect)valid.push_back(row);}
  assigned[s]=false;rows[s]=0;if(valid.empty())return;
  if(chosen<0||valid.size()<allowed.size()){chosen=s;allowed=move(valid);}
 }
 assigned[chosen]=true;for(unsigned row:allowed){rows[chosen]=row;visit(depth+1);if(capped||found)break;}
 assigned[chosen]=false;rows[chosen]=0;
}

int main(int argc,char**argv){
 string mode=argc>1?argv[1]:"core";n=argc>2?stoi(argv[2]):8;seconds=argc>3?stod(argv[3]):10;
 if(n<5||n>10)return 2;allv=(1u<<n)-1;started=chrono::steady_clock::now();
 bool core=mode=="core";defect=core?0:3;target=core?2*n+1:2*n-4;
 for(int s=0;s<n;s++)for(unsigned row=1;row<=allv;row++)
  if(!(row>>s&1)&&__builtin_popcount(row)==(s==0?(core?3:1):2))domain[s].push_back(row);
 rows[0]=core?14:2;assigned[0]=true;
 if(core)visit(1);
 else for(unsigned row:{5u,12u}){
  rows[1]=row;assigned[1]=true;if(forced()<=defect)visit(2);
  if(capped||found)break;
 }
 emit(capped?"incomplete":found?"witness":"complete");
}

#!/usr/bin/env python3
"""Synthesize joint messenger/pursuer boundary invariants for local modules."""
from pathlib import Path
import json,time,hashlib
from composition_interface_free_group import arena,ball
ROOT=Path(__file__).resolve().parents[1]

def mul(a,b):
 out=list(a)
 for x in b:
  if out and out[-1]==-x:out.pop()
  else:out.append(x)
 return tuple(out)
def inv(w):return tuple(-x for x in reversed(w))

def attract(ar,seeds,receipt=frozenset(),retain=False):
 M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1;W=seeds[:];rounds=0;layers=[W[:]] if retain else None
 while True:
  safe=[allc if r in receipt else sum(1<<c for c,m in enumerate(co) if m&~w==0) for r,w in enumerate(W)]
  U=[]
  for r,nb in enumerate(mo):
   u=seeds[r]
   for v in nb:u|=safe[v]
   U.append(u if r in receipt else u & (allc^(1<<ci[M[r]])))
  if U==W:return (W,rounds,layers) if retain else (W,rounds)
  assert all(w&~u==0 for w,u in zip(W,U));W=U;rounds+=1
  if retain:layers.append(W[:])

def synth(swaps,max_rounds=15,extras=()):
 ar=arena(swaps,extras=extras);M,C,mi,ci,mo,co=ar
 iw=ball(2);IC=[(w,i) for w in iw for i in range(10)]+[(None,i) for i in range(10)];ii={v:i for i,v in enumerate(IC)}
 # Map precise cop states to possible interface descriptions after recentering.
 maps=[]
 for w,rtype in M:
  row=[]
  for cw,ctype in C:
   if cw is None:
    poss=[ii[(None,ctype)]]+[ii[(v,ctype)] for v in iw if len(mul(w,v))>3]
   else:
    v=mul(inv(w),cw);poss=[ii[(v,ctype)] if len(v)<=2 else ii[(None,ctype)]]
   row.append(sum(1<<x for x in poss))
  maps.append(row)
 I=[((1<<len(IC))-1)^(1<<ii[((),i)]) for i in range(10)]
 records=[];lastWs=[]
 for iteration in range(max_rounds):
  J=I[:];lastWs=[]
  for g in (-1,-2):
   seeds=[sum(1<<c for c,poss in enumerate(maps[r]) if poss&~I[typ]==0) if w==(g,) else 0 for r,(w,typ) in enumerate(M)]
   W,rounds=attract(ar,seeds);lastWs.append(W)
   for typ in range(10):
    root=mi[((),typ)]
    for c,poss in enumerate(maps[root]):
     if not (W[root]>>c&1):J[typ]&=~poss
   records.append({'iteration':iteration,'generator':g,'attractor_rounds':rounds})
  lost=sum((a&~b).bit_count() for a,b in zip(I,J));remaining=sum(x.bit_count() for x in J)
  print(swaps,iteration,'lost',lost,'remaining',remaining,flush=True)
  if J==I:
   # Can every initial state safely normalize into this interface somewhere?
   seeds=[sum(1<<c for c,poss in enumerate(maps[r]) if poss&~I[typ]==0) for r,(w,typ) in enumerate(M)]
   W,rounds=attract(ar,seeds)
   bad=[(i,c) for i in range(10) for c in range(len(C)) if c!=ci[((),i)] and not(W[mi[((),i)]]>>c&1)]
   return {'swaps':swaps,'fixed':True,'remaining':remaining,'initial_interface':1790,'normalization_failed':len(bad),'normalization_rounds':rounds,'trace':records,'interface_masks':I,'interface_cop_states':IC}
  I=J
 return {'swaps':swaps,'fixed':False,'remaining':sum(x.bit_count() for x in I),'trace':records}

def main():
 start=time.monotonic();rr=[]
 for swaps in ((0,1,3),(1,2,3)):
  rr.append(synth(swaps));print({k:v for k,v in rr[-1].items() if k not in ('trace','interface_masks','interface_cop_states')},flush=True)
 out={'scope':'local interface synthesis; simulation and game certificates not independently audited','seconds':time.monotonic()-start,'records':rr,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'research/composition-interface-invariant.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()

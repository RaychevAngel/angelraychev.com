#!/usr/bin/env python3
"""Bounded cycle-of-ports template search. Finite lower evidence only."""
from pathlib import Path
import json,random,sys,time,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
from game_solver import neighborhoods,recipient_fast
ROOT=Path(__file__).resolve().parents[1]

def gadget(q,ell,perms,beta,colors):
    arcs=[]
    for x in range(q):
        for i in range(ell):
            arcs += [(x*ell+i,x*ell+(i+1)%ell),
                     (x*ell+i,perms[colors[i]][x]*ell+beta[i])]
    return q*ell,arcs

def check(n,arcs,targets):
    out,_=neighborhoods(n,arcs);allv=(1<<n)-1
    if any(len({v for u,v in arcs if u==s})!=2 for s in range(n)):return False,0,'degree'
    if any((out[s]^(1<<s))&~out[c]==0 for s in range(n) for c in range(n) if c!=s):return False,0,'camp'
    worst=0
    for t in targets:
        wins,layers=recipient_fast(n,out,t,True);worst=max(worst,len(layers)-1)
        if any(wins[r]|(1<<r)!=allv for r in range(n)):return False,worst,'game'
    return True,worst,'pass'

def main():
    seconds=float(sys.argv[1]) if len(sys.argv)>1 else 8
    rng=random.Random(9201226)
    start=time.monotonic();tried=0;passes=[];counts={}
    while time.monotonic()-start<seconds and sum(x['q11_noncircular_pass'] for x in passes)<3:
        ell=rng.choice((6,7,8,9,10,12));q=5
        beta=list(range(ell));rng.shuffle(beta);colors=[rng.randrange(2) for i in range(ell)]
        if len(set(colors))<2:continue
        perms=[[(i+1)%q for i in range(q)],[(i+2)%q for i in range(q)]]
        n,arcs=gadget(q,ell,perms,beta,colors)
        good,worst,reason=check(n,arcs,range(ell));tried+=1;counts[reason]=counts.get(reason,0)+1
        if good:
            # All targets via quotient cyclic translations for this first test.
            q2=11;p=list(range(1,q2))+[0]
            while True:
                r=list(range(q2));rng.shuffle(r)
                oo=[{p[i],r[i]} for i in range(q2)]
                if all(i not in oo[i] and len(oo[i])==2 and all(i not in oo[j] for j in oo[i]) for i in range(q2)):break
            N,ee=gadget(q2,ell,[p,r],beta,colors)
            ok,tm,why=check(N,ee,range(N))
            passes.append({'ell':ell,'beta':beta,'colors':colors,'q5_time':worst,'q11_noncircular_pass':ok,'q11_time':tm,'q11_failure':why,'quotient_permutations':[p,r]})
            print(passes[-1],flush=True)
    out={'scope':'bounded template screen, not a proof for arbitrary quotients','seconds':time.monotonic()-start,'attempts':tried,'counts':counts,'passing_first_quotient':passes,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'research/composition-interface-gadget-screen.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items() if k not in ('source_sha256','passing_first_quotient')})
if __name__=='__main__':main()

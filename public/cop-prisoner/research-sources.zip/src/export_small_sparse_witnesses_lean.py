#!/usr/bin/env python3
"""Translate retained sparse witnesses into exact signed-rank Lean checks.

No graph search or game solving. Every move, losing-region closure and exact
graph score is checked by Lean. This supplies lower witnesses, not upper
bounds over competing graphs. The existing twenty-two-arrow proof is reused.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path

from lean_sparse_witness_producer import array, nested

ROOT = Path(__file__).resolve().parents[1]
VALUES = dict(zip(range(11, 24), [8, 9, 11, 13, 15, 19, 28, 33, 40, 53, 60, 79, 83]))


def render(item):
    n, m = item['n'], item['m']
    rank, move = [], []
    certs = {c['target']: c for c in item['certificates']}
    for t in range(n):
        for r in range(n):
            for c in range(n):
                state = 2*(r*n+c)
                rank.append(certs[t]['rank'][state])
                raw = certs[t]['messenger_successor'][state]
                move.append(raw//(2*n) if raw >= 0 else r)
    masks = [sum(1 << t for s, t in item['arcs'] if s == r) for r in range(n)]
    return f'''import SignedRankCertificate

/-! Retained {n}-vertex, {m}-arrow witness. Exact graph score, not an
upper bound over competing graphs. All signed ranks are kernel checked. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.SmallSparseWitness{m}
open FiniteGame Extremal SignedRankCertificate
{array('rowMasks', 'Nat', masks, n)}
def edge (s t : Fin {n}) : Prop := (rowMasks[s.val]!).testBit t.val = true
instance (s t : Fin {n}) : Decidable (edge s t) := inferInstanceAs (Decidable (_ = _))
instance (s t : Fin {n}) : Decidable (Legal edge s t) :=
  inferInstanceAs (Decidable (s = t ∨ edge s t))
{nested('signedRanks', 'Int', rank, n)}
{nested('moves', 'Nat', move, n)}
def data : Data {n} where
  signed t r c := signedRanks t.val r.val c.val
  move t r c := ⟨moves t.val r.val c.val % {n}, Nat.mod_lt _ (by decide)⟩

theorem checked : Checked edge data := by
  constructor <;> decide +kernel
def classification := SignedRankCertificate.classification checked
theorem loopless : Loopless edge := by unfold Loopless; decide +kernel
theorem arrows : arcCount edge = {m} := by rw [arcCount_eq]; decide +kernel
theorem exact_score : score edge = {item['I']} := by
  rw [ExactScoreCertificates.exact_score classification]
  decide +kernel
#print axioms checked
#print axioms exact_score
end Delivery.SmallSparseWitness{m}
'''


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--manifest', type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    source_paths = [ROOT/'research/small-case-fixed-certificates.json',
                    ROOT/'research/small-arcs-eleven-witness.json',
                    ROOT/'research/odd-endpoint-m23-lower-certificate.json.gz']
    candidates = json.loads(source_paths[0].read_text())
    candidates += [json.loads(source_paths[1].read_text()),
                   json.loads(gzip.decompress(source_paths[2].read_bytes()))]
    records = []
    for m, score in VALUES.items():
        if m == 22:
            continue
        item = min((r for r in candidates if r['m'] == m and r['I'] == score),
                   key=lambda r: r['n'])
        path = args.out/f'SmallSparseWitness{m}.lean'
        path.write_text(render(item))
        records.append(dict(module=path.stem, order=item['n'], arrows=m,
                            score=score, source_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    inputs = source_paths+[Path(__file__), ROOT/'src/lean_sparse_witness_producer.py']
    data = dict(scope='Twelve retained exact graph scores, requiring Lean replay; no extremal upper claims.',
                source_sha256={p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in inputs}, modules=records,
                reused_twenty_two='lean/SparseWitness11.lean')
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps(data, indent=2)+'\n')
    print(json.dumps({'modules': len(records), 'states': sum(r['order']**3 for r in records)}))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Untrusted, bounded certificates for the single positive 10/14 profile.

Only literal data is produced. Lean separately checks complete row coverage,
every symmetry route, and each optimistic losing region. Historical receipts
are neither assumptions nor modified inputs.
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, time
from pathlib import Path

N = 10
ALL = (1 << N) - 1
D = [2]*4 + [1]*6
R = [1]*4 + [2]*4 + [1]*2
ROOT = Path(__file__).resolve().parents[1]
CHOICES = {d: [sum(1 << t for t in ts) for ts in itertools.combinations(range(N), d)] for d in (1, 2)}


def prefix_ok(p):
    k = len(p)
    if any(mask.bit_count() != D[s] or mask >> s & 1 for s, mask in enumerate(p)):
        return False
    used = [sum(mask >> t & 1 for mask in p) for t in range(N)]
    return all(used[t] <= R[t] <= used[t] + N-k-int(t >= k) for t in range(N))


def envelope(p):
    k = len(p)
    used = [sum(mask >> t & 1 for mask in p) for t in range(N)]
    available = sum(1 << t for t in range(N) if used[t] < R[t])
    lower = [(p[s] if s < k else 0) | 1 << s for s in range(N)]
    upper = [lower[s] if s < k else available | 1 << s for s in range(N)]
    return upper, lower


def losing_region(upper, lower, target):
    winning = [ALL if r == target else 0 for r in range(N)]
    while True:
        safe = [sum(1 << c for c in range(N) if lower[c] & ~winning[z] == 0) for z in range(N)]
        new = []
        for r in range(N):
            win = 0
            mask = upper[r]
            while mask:
                b = mask & -mask
                mask -= b
                win |= safe[b.bit_length()-1]
            new.append(win if r == target else win & ~(1 << r))
        if new == winning:
            break
        winning = new
    region = [ALL ^ w for w in winning]
    good = [sum(1 << z for z in range(N) if z != target and
                (z == c or lower[c] & ((1 << z) | region[z]))) for c in range(N)]
    assert region[target] == 0
    for r in range(N):
        for c in range(N):
            if r != c and region[r] >> c & 1:
                assert upper[r] & good[c] == upper[r]
    return region, good


def bound_certificate(p):
    upper, lower = envelope(p)
    allowed = [sum(1 << t for t in range(4, 8) if not ((p[s] if s < len(p) else 0) >> t & 1))
               if s < 4 else 0 for s in range(N)]
    losses = []
    if sum(mask.bit_count() for mask in allowed) > 13 and len(p) >= 4:
        for t in range(4, 8):
            region, good = losing_region(upper, lower, t)
            lost_sources = [s for s in range(4) if allowed[s] >> t & 1 and region[s] & ~(1 << s)]
            if not lost_sources:
                continue
            losses.append(dict(target=t, region=region, good=good))
            for s in lost_sources:
                allowed[s] &= ~(1 << t)
            if sum(mask.bit_count() for mask in allowed) <= 13:
                break
    if sum(mask.bit_count() for mask in allowed) > 13:
        return None
    return dict(allowed=allowed, upper=upper, lower=lower, losses=losses)


def route(p, mask):
    """An explicit involution, fixing every completed row including this one."""
    row = len(p)
    incoming = [sum(1 << s for s, bits in enumerate(p) if bits >> t & 1) for t in range(N)]
    classes = {}
    for t in range(row+1, N):
        classes.setdefault((D[t], R[t], incoming[t]), []).append(t)
    permutation = list(range(N))
    representative = mask
    for group in classes.values():
        chosen = [t for t in group if mask >> t & 1]
        desired = group[:len(chosen)]
        outgoing = sorted(set(chosen) - set(desired))
        incoming_selected = sorted(set(desired) - set(chosen))
        for a, b in zip(outgoing, incoming_selected):
            permutation[a] = b
            permutation[b] = a
            representative ^= (1 << a) | (1 << b)
    q = p + [representative]
    assert all(permutation[permutation[x]] == x and D[permutation[x]] == D[x]
               and R[permutation[x]] == R[x] for x in range(N))
    assert all(permutation[s] == s for s in range(len(q)))
    for s, bits in enumerate(p+[mask]):
        for t in range(N):
            assert (bits >> t & 1) == (q[s] >> permutation[t] & 1)
    assert prefix_ok(q)
    return representative, permutation


def produce(seconds):
    started = time.monotonic()
    nodes = {}
    counts = dict(nodes=0, branches=0, bounds=0, masks=0, raw_rows=0, invalid_rows=0, symmetry_routes=0)
    def dfs(p):
        if time.monotonic()-started > seconds:
            raise TimeoutError('bounded exact-family production exceeded its time cap')
        key = ','.join(map(str, p))
        assert key not in nodes and prefix_ok(p)
        counts['nodes'] += 1
        cert = bound_certificate(p)
        if cert is not None:
            counts['bounds'] += 1
            counts['masks'] += len(cert['losses'])
            nodes[key] = dict(kind='bound', prefix=p, certificate=cert)
            return
        assert len(p) < N, ('unexcluded actual graph', p)
        counts['branches'] += 1
        routes, representatives = {}, set()
        for mask in CHOICES[D[len(p)]]:
            counts['raw_rows'] += 1
            if not prefix_ok(p+[mask]):
                counts['invalid_rows'] += 1
                continue
            rep, permutation = route(p, mask)
            routes[str(mask)] = dict(representative=rep, permutation=permutation)
            representatives.add(rep)
            counts['symmetry_routes'] += int(rep != mask)
        reps = sorted(representatives)
        nodes[key] = dict(kind='branch', prefix=p, representatives=reps, routes=routes)
        for rep in reps:
            dfs(p+[rep])
    dfs([])
    return dict(scope='untrusted complete tree data for canonical positive 10/14 profile; not a Lean theorem',
                n=N, arrows=14, bound=13, outdegrees=D, indegrees=R,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                seconds=time.monotonic()-started, counts=counts, nodes=nodes)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seconds', type=float, default=60)
    parser.add_argument('--output', type=Path, default=ROOT/'tmp/lean-irregular/producer-tree.json')
    args = parser.parse_args()
    if not 0 < args.seconds <= 60:
        raise ValueError('only a bounded run up to sixty seconds is supported')
    result = produce(args.seconds)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, separators=(',', ':'))+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'nodes'}))


if __name__ == '__main__':
    main()

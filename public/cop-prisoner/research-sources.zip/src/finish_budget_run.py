#!/usr/bin/env python3
"""Complete positive joint-degree inventories and bounded family decisions."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
from small_plateau_probe import certificate
from small_case_certificate_review import review

ROOT=Path(__file__).resolve().parents[1]


def partitions(total,n,ceiling,minimum=1):
    if n==0:
        if total==0:yield ()
        return
    for value in range(min(ceiling,total-minimum*(n-1)),minimum-1,-1):
        if total-value>(n-1)*value:break
        for rest in partitions(total-value,n-1,value,minimum):yield (value,)+rest


def patterns(n,m,threshold,zero_two=False):
    result=[]
    for D in partitions(m,n,n-1,0 if zero_two else 1):
        q=sum(d>=2 for d in D);lowout=sum(d for d in D if d<2)
        def incoming(j,left,E):
            if j==n:
                if left:return
                if zero_two and min(D+E)>0:return
                r=sum(e>=2 for e in E);lowin=sum(e for e in E if e<2)
                b=sum(d>=2 and e>=2 for d,e in zip(D,E))
                eligible=q*r-b-(m-lowout-lowin)
                if zero_two:
                    source_arrows=sum(d for d,e in zip(D,E) if e==0)
                    sink_arrows=sum(e for d,e in zip(D,E) if d==0)
                    live_rows=min(q,(m-sink_arrows)//2)
                    live_columns=min(r,(m-source_arrows)//2)
                    core_upper={14:9,15:11,16:13}[m]
                    if source_arrows and core_upper+live_columns<=threshold:return
                    if sink_arrows and core_upper+live_rows<=threshold:return
                    rectangle=max(u*v-max(0,b-q-r+u+v)-max(0,2*u+2*v-m)
                                  for u in range(live_rows+1) for v in range(live_columns+1))
                    if rectangle<=threshold:return
                if eligible>threshold:result.append(tuple(zip(D,E)))
                return
            minimum=0 if zero_two and D[j]==2 else (2 if zero_two and D[j]==0 else 1)
            future_min=sum(0 if zero_two and d==2 else (2 if zero_two and d==0 else 1) for d in D[j+1:])
            high=min(n-1,left-future_min)
            if zero_two and D[j]==0:high=min(high,2)
            if j and D[j]==D[j-1]:high=min(high,E[-1])
            for value in range(high,minimum-1,-1):
                if left-value>(n-j-1)*(n-1):continue
                incoming(j+1,left-value,E+(value,))
        incoming(0,m,())
    assert len(result)==len(set(result))
    return result


def main(n,m,threshold,seconds,zero_two=False):
    runner_digest=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    family=patterns(n,m,threshold,zero_two)
    tag=f'n{n}_m{m}_above{threshold}'+('_zero_two' if zero_two else '')
    profile=dict(n=n,m=m,threshold=threshold,positive_degrees=not zero_two,zero_degrees_have_other_degree_two=zero_two,patterns=family,
        scope='Complete joint degree multisets under the stated positivity or degree-two source/sink condition, eligible rectangle, and in zero mode the proved live-capacity/deletion bounds. No graph realization is assumed.')
    path=ROOT/f'research/finish_budget_profiles_{tag}.json';path.write_text(json.dumps(profile,indent=2)+'\n')
    text=str(len(family))+'\n'+'\n'.join(' '.join(f'{d} {e}' for d,e in p) for p in family)+'\n'
    source=ROOT/('src/finish_budget_zero.cpp' if zero_two else 'src/finish_budget_positive.cpp');digest=hashlib.sha256(source.read_bytes()).hexdigest()
    exe=Path(tempfile.gettempdir())/f'finish_budget_{digest[:16]}'
    if not exe.exists():subprocess.run(['c++','-O3','-std=c++17',str(source),'-o',str(exe)],check=True)
    proc=subprocess.run([str(exe),str(n),str(m),str(threshold),str(seconds),str(int(zero_two))],input=text,text=True,capture_output=True,timeout=seconds+15)
    if proc.returncode not in (0,1):raise RuntimeError((proc.returncode,proc.stdout,proc.stderr))
    result=json.loads(proc.stdout);result.update(source_sha256=digest,profile_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        profile_file=str(path.relative_to(ROOT)),source_file=str(source.relative_to(ROOT)),runner_source_sha256=runner_digest)
    if result['counterexample_found']:
        graph=certificate(n,result['arcs']);assert graph['I']==result['maximum_threshold_survivor']
        result['literal_review']=review(graph)
        dest=ROOT/f'research/finish_budget_witness_{tag}.json';dest.write_text(json.dumps(graph,indent=2)+'\n')
        result['witness_file']=str(dest.relative_to(ROOT))
    (ROOT/f'research/finish_budget_positive_{tag}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('n',type=int);p.add_argument('m',type=int);p.add_argument('threshold',type=int)
    p.add_argument('--seconds',type=float,default=30);p.add_argument('--zero-two',action='store_true');a=p.parse_args();main(a.n,a.m,a.threshold,a.seconds,a.zero_two)

"""Source-pinned incorporation of the reviewed finite small-case pass."""
from functools import lru_cache
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


@lru_cache(None)
def data():
    return json.loads((ROOT/'research/small-case-results.json').read_text())


def host_cutoff(m):
    return next((x['universal_host_cutoff'] for x in data()['host_cutoffs'] if x['m']==m),2*m)


def register(c):
    c.READS.add('src/classification_small_cases.py')
    common=['research/small-case-results.json','research/small-case-approved-bounds.json',
            'research/small-case-fixed-certificates.json']
    c.rule('small_case_literal','Consolidated literal finite graphs with independent complete winning and losing rank replay; exact only with a matching upper bound.',
           common+['src/small_case_certificate_review.py'],'independently replayed fixed graph certificate')
    c.rule('small_case_upper','Individually reviewed small-case exclusions and structural upper bounds in the approved registry.',
           common,'ordinary proof with the separately identified complete finite exclusions and independent reviews')
    c.rule('small_case_stages','Literal stages at n8..11 certify every optional subset throughout their stated intervals.',
           common+['src/small_case_stage_review.py','research/small-case-stage-independent-review.json',
                   'research/small-plateau-staged-records.json','research/small-plateau-staged-certificates.zip',
                   'research/small-plateau-small-stage-records.json','research/small-plateau-small-stage-certificates.zip'],
           'independent actual-game asymmetric rank replay')
    c.rule('small_case_support','For12<=m<=21, M(n,m)=M(min(n,B_m),m), with the individually reviewed budget-specific cutoffs in the current registry; attainers lift by isolates.',
           ['paper/support-concentration.md','research/small-case-support-cutoffs.json',
            'src/small_case_support_caps.py','research/small-case-results.json'],
           'ordinary comparison-witness argument and two independent necessary-integer replays')


def inputs(c):
    d=c.read('research/small-case-results.json')
    assert d['verified']
    for path,value in d['source_sha256'].items():
        c.READS.add(path)
        actual=hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
        if actual!=value and path=='paper/odd-endpoint-resume.md':
            # The current proof has the stronger threshold98. These frozen
            # small-case deductions still use the original threshold145 proof;
            # verify its retained bytes instead of changing the old receipt.
            historical='research/history/before-slimming-odd-endpoint-resume.md'
            c.READS.add(historical)
            actual=hashlib.sha256((ROOT/historical).read_bytes()).hexdigest()
        if actual!=value and path=='paper/small-orders-resume.md':
            # Publication changes only the stale 'current bounds' label to
            # 'intermediate bounds'; preserve this receipt's original proof.
            historical='research/history/before-arxiv-preparation-small-orders-resume.md'
            c.READS.add(historical)
            actual=hashlib.sha256((ROOT/historical).read_bytes()).hexdigest()
        assert actual==value,(path,'small-case source changed')
    graphs=c.read(d['fixed_certificates'])
    assert hashlib.sha256((ROOT/d['fixed_certificates']).read_bytes()).hexdigest()==d['fixed_certificates_sha256']
    assert len(graphs)==len(d['fixed_graphs'])
    for r,g in zip(d['fixed_graphs'],graphs):
        assert all(r[key]==g[key] for key in ('n','m','I'))
        assert len(g['arcs'])==g['m'] and len(g['certificates'])==g['n']


def bounds(n,m):
    return [(x['value'],'small_case_upper') for x in data()['upper_bounds']
            if (x['n'] is None or x['n']==n) and (x['m'] is None or x['m']==m)]


def points(c):
    return [(r['n'],r['m'],r['I'],'small_case_literal',False) for r in data()['fixed_graphs']]


def domains(c,row,n):
    for x in data()['stage_intervals']:
        if x['n']==n:
            c.known_exact(row,n,x['m_min'],x['m_max'],'small_case_stages')


def construct(n,m):
    """Read concrete saved adjacency, or take a specified literal stage prefix.

    Fixed records may be lower-only: the registry/ledger supplies exactness.
    This performs no graph search, game solve or conditional expectation.
    """
    d=data()
    for item in d['stage_inputs']:
        record=json.loads((ROOT/item['records']).read_text())
        for r in record.get('records',[record]):
            if r['n']==n and r['m_min']<=m<=r['m_max']:
                return r['base_arcs']+r['added'][:m-r['m_min']]
    for index,r in enumerate(d['fixed_graphs']):
        if (r['n'],r['m'])==(n,m):
            return json.loads((ROOT/d['fixed_certificates']).read_text())[index]['arcs']
    raise ValueError('This finite registry has no recipe at the requested pair')

#!/usr/bin/env python3
"""Full literal replay for the complete n8 upper-band exclusions."""
import hashlib,itertools,json
from pathlib import Path
from game_solver import solve_graph
from small_case_certificate_review import review
from endpoint40_certify import forced_witnesses
ROOT=Path(__file__).resolve().parents[1]
CASES=[(35,19),(36,18),(37,16),(38,15)]
def main():
    source='research/finish_constructions_certificates.json'
    lowers=json.loads((ROOT/source).read_text())
    results=[];negatives=[];selected_lowers=[];sources=[source,'src/endpoint40_n8_profiles.cpp',
      'src/endpoint40_n8_high_certify.py','src/endpoint40_certify.py','src/game_solver.py','src/small_case_certificate_review.py']
    for m,value in CASES:
        log=f'research/endpoint40_n8_m{m}_t{value+1}.jsonl';sources.append(log)
        records=[json.loads(s) for s in (ROOT/log).read_text().splitlines()]
        start,end=records[0],records[-1];profiles=[r for r in records if r['kind']=='profile']
        expected=[p for p in itertools.combinations_with_replacement(range(1,8),8) if sum(p)==56-m]
        assert start['m']==m and start['target_I']==value+1
        assert start['first_profile']==0 and start['last_profile_exclusive']>=len(expected)
        assert len(profiles)==len(expected)==start['profile_count']
        assert [tuple(r['degrees']) for r in profiles]==expected
        assert [r['profile'] for r in profiles]==list(range(len(profiles)))
        assert end['complete_requested_profiles'] and not end['found'] and not end['timeout']
        assert all(r['complete'] and not r['found'] and not r['timeout'] for r in profiles)
        leaves=[r for r in records if r['kind']=='leaf']
        assert len(leaves)==end['leaves']==sum(r['leaves'] for r in profiles)
        assert end['nodes']==sum(r['nodes'] for r in profiles)
        assert len({tuple(r['missing_masks']) for r in leaves})==len(leaves)
        checks=[];witness_count=0
        for index,leaf in enumerate(leaves):
            masks=leaf['missing_masks']
            assert all(not(masks[s]>>s&1) for s in range(8))
            assert tuple(v.bit_count() for v in masks)==expected[leaf['profile']]
            arcs=[(s,t) for s in range(8) for t in range(8) if s!=t and not(masks[s]>>t&1)]
            g=solve_graph(8,arcs,crosscheck=True,certificates=True)
            assert g['m']==m and g['I']==leaf['I']<=value
            g['enumeration_leaf_index']=index;checks.append(review(g));negatives.append(g)
            for count in range(9):
                witnesses=forced_witnesses(masks,count)
                for s,t,c in witnesses:assert g['certificates'][t]['rank'][2*(s*8+c)]==-1
                witness_count+=len(witnesses)
        lower=[g for g in lowers if (g['n'],g['m'],g['I'])==(8,m,value)]
        assert len(lower)==1
        selected_lowers.append(lower[0]);lower_check=review(lower[0])
        results.append({'n':8,'m':m,'M':value,'target_excluded':value+1,
          'profiles':len(profiles),'nodes':end['nodes'],'seconds':end['seconds'],
          'static_leaves':len(leaves),'negative_state_obligations':sum(c['alternating_state_obligations'] for c in checks),
          'explicit_camping_witnesses_replayed':witness_count,'lower':lower_check})
    for name,data in [('research/endpoint40_n8_high_negative_certificates.json',negatives),
                      ('research/endpoint40_n8_high_lower_certificates.json',selected_lowers)]:
        (ROOT/name).write_text(json.dumps(data,separators=(',',':'))+'\n');sources.append(name)
    result={'status':'passed','cases':results,
      'boundary':'Complete producer decisions and full literal leaf/lower replay. Independent source/coverage review pending.',
      'sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources}}
    (ROOT/'research/endpoint40_n8_high_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()

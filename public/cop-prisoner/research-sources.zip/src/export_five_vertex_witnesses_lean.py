#!/usr/bin/env python3
"""Translate retained five-vertex attainers into checked finite strategies.

Only the seven fixed graphs are evaluated; no graph search is performed.
Lean checks every move, cop reply, initial state and counted missing pair.
The source catalogue's asserted maxima are not used as proof premises.
"""
import argparse
import hashlib
import json
from pathlib import Path

from export_small_budget_nine_witness_lean import TEMPLATE
from game_solver import solve_graph

ROOT = Path(__file__).resolve().parents[1]
VALUES = {8: 4, 9: 3, 10: 3, 11: 3, 12: 2, 13: 2, 14: 2}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--manifest', type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    source = ROOT/'research/solver-enumeration-n5.json'
    entries = json.loads(source.read_text())['by_m']
    records = []
    for budget, value in VALUES.items():
        graph = next(row for row in entries if row['m'] == budget)
        solved = solve_graph(5, graph['witness_arcs'], certificates=True, crosscheck=True)
        assert solved['I'] == value
        codes, moves = [], []
        for target, cert in enumerate(solved['certificates']):
            for messenger in range(5):
                for cop in range(5):
                    state = 2*(messenger*5+cop)
                    codes.append(max(cert['rank'][state]+1, 0))
                    moves.append(target if messenger == target else
                                 max(cert['messenger_successor'][state], 0)//10)
        name = f'FiveVertexWitness{budget:02}'
        pairs = lambda xs: '['+','.join(f'({a},{b})' for a,b in xs)+']'
        text = TEMPLATE.replace('SmallBudgetNineWitness', name)
        text = text.replace('six-vertex, nine-arrow', f'five-vertex, {budget}-arrow')
        text = text.replace('all five counted pairs', f'all {value} counted pairs')
        text = text.replace('Fin 6', 'Fin 5').replace('*36', '*25').replace('*6', '*5').replace('% 6', '% 5')
        text = text.replace('five_pairs', 'lower').replace('5≤score', f'{value}≤score')
        text = text.replace('counted=5', f'counted={value}').replace('edge=9', f'edge={budget}')
        text = text.replace('@@ARCS@@', pairs(solved['arcs'])).replace('@@PAIRS@@', pairs(solved['indirect_pairs']))
        text = text.replace('@@CODES@@', str(codes)).replace('@@MOVES@@', str(moves))
        path = args.out/(name+'.lean')
        path.write_text(text)
        records.append(dict(module=name, arrows=budget, lower=value, source_sha256=sha(path)))
    inputs = [source, Path(__file__), ROOT/'src/game_solver.py',
              ROOT/'src/export_small_budget_nine_witness_lean.py']
    result = dict(scope='Seven retained graphs; each literal strategy requires Lean replay.',
                  inputs={p.relative_to(ROOT).as_posix(): sha(p) for p in inputs},
                  modules=records)
    if args.manifest:
        args.manifest.parent.mkdir(parents=True, exist_ok=True)
        args.manifest.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'modules': len(records), 'total_counted_pairs': sum(VALUES.values())}))


if __name__ == '__main__':
    main()

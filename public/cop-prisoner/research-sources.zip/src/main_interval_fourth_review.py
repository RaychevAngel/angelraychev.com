#!/usr/bin/env python3
"""Independent arithmetic regression for the fourth main-interval checkpoint.

Reads the frozen previous ledger and the current ledger. It does not import
the coverage generator or any construction module, and does not edit either
ledger. The new family ranges are recalculated from the ordinary formulas.
"""
from __future__ import annotations

import argparse
from collections import Counter
from functools import lru_cache
import gzip
from hashlib import sha256
import json
from math import comb, gcd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "research/main-interval-fourth-baseline.json.gz"
CURRENT = ROOT / "publication/classification-coverage.json"
SPARSE = "sparse_m_le_2n"
MAIN = "main_2n_lt_m_le_n_n_minus3"
DENSE = "dense_m_gt_max_2n_n_n_minus3"
NEW_RULES = {"circle_half_density", "layered_guides"}


def region(n, m):
    if m <= 2 * n:
        return SPARSE
    return MAIN if m <= n * (n - 3) else DENSE


def compress(values):
    bands = []
    for value in sorted(values):
        if bands and value == bands[-1][1] + 1:
            bands[-1][1] = value
        else:
            bands.append([value, value])
    return bands


def expand(row):
    expected = 0
    for segment in row["segments"]:
        start, end = segment["m"]
        assert start == expected and end >= start
        lower, upper = segment["lower"], segment["upper"]
        for m in range(start, end + 1):
            lo = lower[0] + (m - start) * lower[1]
            hi = upper[0] + (m - start) * upper[1]
            assert 0 <= lo <= hi
            assert (segment["status"] == "exact") == (lo == hi)
            yield m, lo, hi, lower
        expected = end + 1
    assert expected == row["n"] * (row["n"] - 1) + 1


@lru_cache(maxsize=None)
def circle_ranges(n):
    ranges = []
    for h in range(7, (n - 2) // 2 + 1, 4):
        if gcd(h, n) != 1:
            continue
        # Count the allowed regular residues directly, independently of the
        # producer's closed-cardinality formula and parameter dispatcher.
        for variant in (("full", "gap") if n % 4 == 0 else ("gap",)):
            end = n - 1 if variant == "full" else n - h
            regular = sum(x % 4 in (0, 1) for x in range(end + 1))
            allowed_count = regular + 1 - int(2 * h - 1 <= end)
            ranges.append((5 * n, n * (allowed_count - 1),
                           {"h": h, "variant": variant}))
    return tuple(ranges)


@lru_cache(maxsize=None)
def layer_ranges(n):
    ranges = []
    for hubs, maximum_guides in ((12, 8), (14, 14)):
        for g in range(2, maximum_guides + 1):
            b = n - hubs - g
            if b < 0:
                continue
            for r in range(2, g + 1):
                if b > comb(g, r):
                    continue
                # Count each distinct compulsory arrow class.
                core = hubs * (hubs - 3)
                hub_outside = hubs * (g + b)
                guide_hub = (hubs * g - (2 * g + 2) if hubs == 12 else 11 * g)
                bulk_outgoing = ((7 if hubs == 12 else 8) + r) * b
                lo = core + hub_outside + guide_hub + bulk_outgoing
                hi = lo + g * b + b * (b - 1)
                ranges.append((lo, hi, {"hubs": hubs, "g": g, "b": b, "r": r}))
    return tuple(ranges)


def source_valid(n, m, value, lower):
    rule, base_n, fixed_m = lower[2:5]
    assert rule in NEW_RULES and 1 <= base_n <= n
    base_m = m if fixed_m is None else fixed_m
    assert 0 <= base_m <= m
    assert m - base_m <= (n - base_n) * (n - base_n - 1)
    ranges = circle_ranges(base_n) if rule == "circle_half_density" else layer_ranges(base_n)
    assert any(lo <= base_m <= hi for lo, hi, _ in ranges), (n, m, value, lower)
    assert value == base_n * (base_n - 1) - base_m, (n, m, value, lower)


def review_dispatch_plans():
    path = ROOT / "research/main-interval-expanded-checks.json"
    if not path.exists():
        return {"available": False}
    receipt = json.loads(path.read_bytes())
    assert receipt["verified"] and receipt["above_three_n_from"] == 43
    assert receipt["full_interval_from"] == 104
    assert [row["n"] for row in receipt["plans"]] == list(range(43, 106))
    registry = json.loads((ROOT / "research/sparse-interface-third-proof-registry.json").read_bytes())
    def independent_cycle_count(t, r):
        if r == 0:
            return 1
        if r < 0 or 2 * r > t:
            return 0
        return t * comb(t - r, r) // (t - r)
    checked = Counter()
    for row in receipt["plans"]:
        n = row["n"]
        cursor = 2 * n if n >= 104 else 3 * n
        assert row["start"] == cursor and row["stop"] == n * (n - 3)
        for segment in row["segments"]:
            branch = segment["branch"]
            lo, hi = segment["m_min"], segment["m_max"]
            assert segment["used_from"] == cursor
            assert lo <= cursor <= segment["used_through"] <= hi
            if branch == "circle":
                candidates = circle_ranges(n)
                assert any((lo, hi) == (a, b) and segment["h"] == p["h"]
                           and segment["variant"] == p["variant"] for a, b, p in candidates)
            elif branch == "layer":
                assert any((lo, hi) == (a, b) and all(segment[k] == p[k] for k in p)
                           for a, b, p in layer_ranges(n))
            elif branch == "protected":
                assert (lo, hi) == (3 * n, n * ((n + 6) // 7 - 1))
            elif branch == "dense":
                assert (lo, hi) == (n * (n - 1) - n * max(3, (n + 11) // 13), n * (n - 3))
            elif branch == "sparse":
                records = [x for x in registry["records"] if x["n"] == n
                           and x["variant"] == segment["variant"]]
                assert len(records) == 1
                saved = records[0]
                assert (lo, hi) == (saved["m_min"], saved["m_max"])
                assert segment["certificate_member"] == saved["member"]
                assert segment["maximum_moves"] == saved["maximum_moves"]
            elif branch == "code":
                k, r = segment["k"], segment["r"]
                assert k >= 6 and 3 <= r <= k // 2
                lines = independent_cycle_count(k, r)
                points = lines if k % 2 else sum(
                    independent_cycle_count(k // 2, i) * independent_cycle_count(k // 2, r - i)
                    for i in range(r + 1))
                outside = n - 2 * k
                assert 0 <= outside <= lines + points
                base = 2 * k * (2 * k - 3) + (4 * k - r) * outside
                assert (lo, hi) == (base, base + outside * (outside - 1))
            else:
                raise AssertionError(("unreviewed dispatcher branch", branch))
            cursor = segment["used_through"] + 1
            checked[branch] += 1
        assert cursor == n * (n - 3) + 1
    assert all(sha256((ROOT / name).read_bytes()).hexdigest() == value
               for name, value in receipt["source_sha256"].items())
    return {"available": True, "verified": True, "orders_checked": 63,
            "segments_by_branch": dict(checked),
            "boundary_constructions_in_producer_receipt": receipt["boundary_constructions"],
            "proof_boundary": "independent interval/parameter replay; graph and unchanged-tail tests recorded separately in producer receipt"}


def run():
    old = json.loads(gzip.decompress(BASELINE.read_bytes()))
    current = json.loads(CURRENT.read_bytes())
    assert old["finite_box"] == current["finite_box"] == {"n": [1, 114], "m": "0..n(n-1)"}
    assert old["canonical_representatives"]["unresolved"] == 48546
    assert len(old["rows"]) == len(current["rows"]) == 114
    new_exact = Counter()
    improved_bounds = Counter()
    region_counts = Counter({SPARSE: 0, MAIN: 0, DENSE: 0})
    canonical_regions = Counter({SPARSE: 0, MAIN: 0, DENSE: 0})
    remaining_rows = []
    remaining_main = []
    exact_total = unresolved_total = checked_total = checked_new_sources = 0
    previous_exact_preserved = 0
    new_domain_cells = 0
    for old_row, new_row in zip(old["rows"], current["rows"]):
        n = old_row["n"]
        assert new_row["n"] == n
        unknown = []
        canonical_unknown = []
        main_unknown = []
        expanded_old, expanded_new = list(expand(old_row)), list(expand(new_row))
        assert len(expanded_old) == len(expanded_new)
        for before, after in zip(expanded_old, expanded_new):
            m, lo, hi, lower = after
            old_m, old_lo, old_hi, _ = before
            assert m == old_m
            assert lo >= old_lo, ("lower-bound regression", n, m, old_lo, lo)
            assert hi <= old_hi, ("upper-bound regression", n, m, old_hi, hi)
            if old_lo == old_hi:
                assert lo == hi == old_lo
                previous_exact_preserved += 1
            if lo > old_lo:
                improved_bounds[lower[2]] += 1
            if lower[2] in NEW_RULES:
                source_valid(n, m, lo, lower)
                checked_new_sources += 1
            if old_lo < old_hi and lo == hi:
                assert lower[2] in NEW_RULES, ("unreviewed new exact source", n, m, lower)
                assert lower[3] == n and lower[4] is None
                assert lo == n * (n - 1) - m
                new_exact[lower[2]] += 1
            checked_total += 1
            if lo == hi:
                exact_total += 1
                continue
            unresolved_total += 1
            unknown.append(m)
            key = region(n, m)
            region_counts[key] += 1
            if m > 0 and n <= 2 * m:
                canonical_unknown.append(m)
                canonical_regions[key] += 1
            if key == MAIN:
                main_unknown.append(m)
                if n >= 43:
                    assert m < 3 * n, ("unresolved upper-main cell", n, m)
        assert compress(unknown) == new_row["unresolved_m_ranges"]
        assert len(unknown) == new_row["unresolved"]
        assert new_row["exact"] + len(unknown) == len(expanded_new)
        canonical = current["canonical_representatives"]["unresolved_by_n"][n - 1]
        assert canonical == {"n": n, "m_ranges": compress(canonical_unknown)}
        if canonical_unknown:
            remaining_rows.append({"n": n, "m_ranges": compress(canonical_unknown)})
        if main_unknown:
            remaining_main.append({"n": n, "m_ranges": compress(main_unknown)})
        # Every direct interval independently implied by either new theorem
        # must be fully incorporated with the elementary exact value.
        for lo, hi, _ in circle_ranges(n) + layer_ranges(n):
            assert 0 <= lo <= hi <= n * (n - 1)
            for m in range(lo, hi + 1):
                _, lower, upper, _ = expanded_new[m]
                assert lower == upper == n * (n - 1) - m, ("omitted domain", n, m)
                new_domain_cells += 1
        if n >= 104:
            for m in range(2 * n, n * (n - 3) + 1):
                _, lower, upper, _ = expanded_new[m]
                assert lower == upper == n * (n - 1) - m
    assert dict(region_counts) == current["regions"]
    assert dict(canonical_regions) == current["canonical_representatives"]["regions"]
    assert sum(canonical_regions.values()) == current["canonical_representatives"]["unresolved"]
    assert current["totals"] == {"admissible": checked_total, "exact": exact_total,
                                  "unresolved": unresolved_total}
    assert canonical_regions == {SPARSE: 254, MAIN: 6141, DENSE: 21}
    assert sum(new_exact.values()) == 42130
    assert previous_exact_preserved == 444568
    watched = [BASELINE, CURRENT, ROOT / "src/classification_coverage.py",
               ROOT / "src/main_interval_half_density.py", ROOT / "src/main_interval_layered.py"]
    dispatcher = ROOT / "src/main_interval_expanded.py"
    if dispatcher.exists():
        watched.append(dispatcher)
    overlap_receipt = ROOT / "research/main-interval-expanded-checks.json"
    if overlap_receipt.exists():
        watched.extend([overlap_receipt, ROOT / "paper/main-interval-new-overlap.md"])
    return {"verified": True, "imports_coverage_or_construction_modules": False,
            "checker_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
            "source_sha256": {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest() for p in watched},
            "finite_box_cells_checked": checked_total,
            "previous_exact_cells_preserved": previous_exact_preserved,
            "previous_bound_regressions": 0,
            "new_exact_cells": sum(new_exact.values()), "new_exact_by_rule": dict(new_exact),
            "lower_bound_improvements_by_rule": dict(improved_bounds),
            "new_family_source_cells_checked_including_padding": checked_new_sources,
            "new_direct_interval_cells_checked_with_repetitions": new_domain_cells,
            "canonical_unresolved": sum(canonical_regions.values()),
            "canonical_regions": dict(canonical_regions),
            "finite_box_unresolved": unresolved_total,
            "canonical_remaining_rows": remaining_rows,
            "main_remaining_rows": remaining_main,
            "all_remaining_main_at_n_ge_43_have_m_lt_3n": True,
            "full_main_verified_orders": [104, 114],
            "infinite_tail_boundary": "finite arithmetic here; combine old proved n>=106 dispatcher for the infinite tail",
            "dispatch_plan_review": review_dispatch_plans(),
            "lean_claim": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "research/main-interval-fourth-review.json")
    args = parser.parse_args()
    result = run()
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in {"canonical_remaining_rows", "main_remaining_rows", "source_sha256"}}, indent=2))

// Bounded construction search, not an upper-bound proof.
// Enumerate two permutation factors of an eleven-vertex 2-in/2-out graph.
// Permit exactly one directed diamond, no source camping, and no other
// predecessor camping. Stop at I>=81 or the wall-clock budget.
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
constexpr int n=11;
int A[n],B[n],out[n],pred[n],inv[n];
bool assigned[n],used[n],running=true,found=false;
long long nodes=0,leaves=0,parts_started=0;
int best=-1,best_t=-1,best_c=-1;
vector<int>wa,wb;
vector<vector<int>>parts;
double budget=30.0;
auto started=chrono::steady_clock::now();
double elapsed(){return chrono::duration<double>(chrono::steady_clock::now()-started).count();}

int game(){
 int answer=0,all=(1<<n)-1,W[n],safe[n],next[n];
 for(int t=0;t<n;t++){
  fill(W,W+n,0);W[t]=all;
  while(true){
   for(int v=0;v<n;v++){
    safe[v]=0;
    for(int c=0;c<n;c++)if(!((out[c]|(1<<c))&~W[v]))safe[v]|=1<<c;
   }
   bool change=false;
   for(int r=0;r<n;r++){
    int w=0,x=out[r]|(1<<r);
    while(x){int v=__builtin_ctz(x);x&=x-1;w|=safe[v];}
    if(r!=t)w&=~(1<<r);
    next[r]=w;change|=w!=W[r];
   }
   copy(next,next+n,W);if(!change)break;
  }
  for(int r=0;r<n;r++)if(r!=t&&!(out[r]>>t&1)&&(W[r]|(1<<r))==all)answer++;
 }
 return answer;
}

bool admissible(){
 for(int s=0;s<n;s++)if(assigned[s])
  for(int c=0;c<n;c++)if(c!=s && !(out[s]&~(out[c]|(1<<c))))return false;
 int target=-1,cop=-1;
 for(int t=0;t<n;t++)if(inv[t]>=0)
  for(int c=0;c<n;c++)if(!(pred[t]&~(out[c]|(1<<c)))){
   if(pred[t]&(1<<c))return false;
   if(target>=0 && (target!=t||cop!=c))return false;
   target=t;cop=c;
  }
 return true;
}

void dfs(int row){
 if(!running)return;
 if((++nodes&4095)==0&&elapsed()>=budget){running=false;return;}
 if(row==n){
  int t=-1,c=-1;
  for(int j=0;j<n;j++)for(int i=0;i<n;i++)if(out[i]==pred[j]){t=j;c=i;}
  if(t<0)return;
  ++leaves;
  int value=game();
  if(value>best){best=value;wa.assign(A,A+n);wb.assign(B,B+n);best_t=t;best_c=c;}
  if(value>=81){found=true;running=false;}
  return;
 }
 for(int v=0;v<n;v++)if(!used[v]&&v!=row&&v!=A[row]){
  B[row]=v;used[v]=assigned[row]=true;inv[v]=row;
  out[row]|=1<<v;pred[v]|=1<<row;
  if(admissible())dfs(row+1);
  out[row]&=~(1<<v);pred[v]&=~(1<<row);
  inv[v]=-1;used[v]=assigned[row]=false;
  if(!running)return;
 }
}

void partitions(int rem,int lo,vector<int>&p){
 if(!rem){parts.push_back(p);return;}
 for(int l=lo;l<=rem;l++){p.push_back(l);partitions(rem-l,l,p);p.pop_back();}
}

int main(int argc,char**argv){
 if(argc>1)budget=min(30.0,max(0.1,atof(argv[1])));
 vector<int>p;partitions(n,2,p);
 stable_sort(parts.begin(),parts.end(),[](const auto&a,const auto&b){
  if(a.size()!=b.size())return a.size()<b.size();return a>b;
 });
 for(const auto&pt:parts){
  if(!running)break;++parts_started;
  int off=0;for(int len:pt){for(int j=0;j<len;j++)A[off+j]=off+(j+1)%len;off+=len;}
  fill(pred,pred+n,0);fill(assigned,assigned+n,false);
  fill(used,used+n,false);fill(inv,inv+n,-1);
  for(int i=0;i<n;i++){out[i]=1<<A[i];pred[A[i]]|=1<<i;}
  dfs(0);
 }
 cout<<"{\"purpose\":\"bounded construction search only\",\"n\":11,\"m\":22,\"target_I\":81,"
     <<"\"target_found\":"<<(found?"true":"false")<<",\"search_finished\":"<<(running?"true":"false")
     <<",\"seconds\":"<<elapsed()<<",\"permutation_types_started\":"<<parts_started
     <<",\"permutation_types_total\":"<<parts.size()<<",\"partial_nodes\":"<<nodes
     <<",\"one_diamond_games\":"<<leaves<<",\"candidate_best_I\":"<<best
     <<",\"candidate_diamond_target\":"<<best_t<<",\"candidate_diamond_source\":"<<best_c
     <<",\"arcs\":[";
 for(int i=0;i<int(wa.size());i++){if(i)cout<<",";cout<<"["<<i<<","<<wa[i]<<"],["<<i<<","<<wb[i]<<"]";}
 cout<<"]}\n";
}

#!/usr/bin/env python3
"""Source, full degree inventory, and independent leaf review for M(9,20)."""
import hashlib,json,subprocess,tempfile
from pathlib import Path
from finish_eighteen_review import positive_patterns,lower_review
from finish_budget_leaf_review import variant
ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    primary=ROOT/'research/finish-positive-max-n9-m20-from37.json';p=json.loads(primary.read_text())
    assert p['complete'] and p['initial_threshold']==p['threshold']==p['upper_if_complete']==37
    assert p['degree_patterns']==p['total_degree_patterns']==303 and p['maximum_threshold_survivor']==-1
    source=ROOT/p['source_file'];profiles=ROOT/p['profile_file']
    assert sha(source)==p['source_sha256'] and sha(profiles)==p['profile_sha256']
    supplied=json.loads(profiles.read_text())['patterns'];independent=positive_patterns(9,20,37)
    assert independent==set(tuple(map(tuple,row)) for row in supplied) and len(supplied)==303
    old=(ROOT/'src/finish_budget_positive.cpp').read_text();new=source.read_text()
    # Verify the exact bounded adaptation of the previously reviewed source.
    expected='// Complete positive-family maximization: raise a verified lower threshold only after an exact game witness. No early exit on improvement.\n'+old
    changes=[('int n,all,budget,mode;','int n,all,budget,mode,initial_threshold;'),
       ('if(value>threshold)found=true;','if(value>threshold)threshold=value;'),
       ('if(mode==1&&!((budget==14&&threshold>=13)||(budget==15&&threshold>=15)||(budget==16&&threshold>=19)))return 2;','if(mode!=0)return 2;'),
       ('all=(1<<n)-1;int totalpatterns;','initial_threshold=threshold;all=(1<<n)-1;int totalpatterns;'),
       ('<<",\\"counterexample_found\\":"','<<",\\"initial_threshold\\":"<<initial_threshold<<",\\"counterexample_found\\":"')]
    for before,after in changes:
        assert expected.count(before)==1,before;expected=expected.replace(before,after)
    assert expected==new
    generated=variant(new)
    with tempfile.TemporaryDirectory(prefix='finish_main_review_n9_m20_') as tmp:
        tmp=Path(tmp);cpp=tmp/'review.cpp';exe=tmp/'review';cpp.write_text(generated)
        subprocess.run(['c++','-O3','-std=c++17',str(cpp),'-o',str(exe)],check=True)
        data=str(len(supplied))+'\n'+'\n'.join(' '.join(str(v) for pair in row for v in pair) for row in supplied)+'\n'
        args=[str(exe),'9','20','37','90','0']
        run=subprocess.run(args,input=data,text=True,capture_output=True,timeout=100)
        assert run.returncode==0,(run.stdout,run.stderr)
        fresh=json.loads(run.stdout)
        assert fresh['complete'] and fresh['initial_threshold']==fresh['threshold']==fresh['upper_if_complete']==37
        for field in ['nodes','degree_patterns','total_degree_patterns','game_decisions','camping_rejects','guarded_checks','guarded_rejects','early_game_rejects','maximum_threshold_survivor']:
            assert fresh[field]==p[field],(field,fresh[field],p[field])
        audit=run.stderr.strip().split();assert len(audit)==4 and audit[0]=='AUDIT'
        fresh.update(independent_maximum=int(audit[1]),guarded_samples=int(audit[2]),sampled_losing_pairs=int(audit[3]))
        args[4]='0.000000001';stop=subprocess.run(args,input=data,text=True,capture_output=True,timeout=10)
        stopped=json.loads(stop.stdout);assert stop.returncode==1 and stopped['complete'] is False
        fresh['timeout_control']={'returncode':1,'complete':False,'nodes':stopped['nodes']}
    lower=lower_review(ROOT/'research/finish_budget_witness_n9_m20_above36.json');assert lower['I']==37
    n8path=ROOT/'research/endpoint40_n8_low_receipt.json';n8=json.loads(n8path.read_text())
    actual={r['m']:r['M'] for r in n8['cases']};assert (actual[18],actual[19],actual[20])==(21,22,24)
    inputs=[primary,source,profiles,ROOT/'src/finish_budget_positive.cpp',ROOT/'src/finish_budget_leaf_review.py',
            ROOT/'src/finish_eighteen_review.py',ROOT/'src/finish_alternating_review.hpp',n8path,
            ROOT/'research/finish_budget_witness_n9_m20_above36.json',ROOT/'research/finish_eighteen_review_seventeen.json']
    result=dict(verified=True,claim='M(9,20)=37',source_sha256=sha(Path(__file__)),
        independent_joint_degree_patterns=len(independent),exact_source_adaptation_checked=True,
        input_hashes={str(f.relative_to(ROOT)):sha(f) for f in inputs},variant_sha256=hashlib.sha256(generated.encode()).hexdigest(),
        run=fresh,lower=lower,
        zero_degree_upper={'d1':22,'d2':27,'d_at_least3':33,'dependency':'approved ME17<=28'},
        support_at_most8_upper=24,
        scope='Ordinary/source coverage review and independent exact degree-set regeneration. Every reached leaf is independently solved; graph enumeration and pruning are the reviewed producer traversal, not a second independent graph enumeration.')
    (ROOT/'research/finish_main_review_n9_m20.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'verified':True,'claim':result['claim'],'leaf_games':fresh['game_decisions'],'guarded_samples':fresh['guarded_samples'],'losing_pairs':fresh['sampled_losing_pairs'],'seconds':fresh['seconds']}))

if __name__=='__main__':main()

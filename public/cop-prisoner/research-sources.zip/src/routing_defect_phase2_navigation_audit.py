#!/usr/bin/env python3
"""Independent replay of saved navigation layers from literal graph rules.

No imports of the primary arena, invariant synthesis, or attractor routine.
"""
from pathlib import Path
import gzip,hashlib,json,time

ROOT=Path(__file__).resolve().parents[1]
A=[(0,6),(0,7),(0,3),(0,9),(1,0),(0,1),(0,2),(0,8),(0,4),(2,5)]
B=[(1,0),(-1,2),(-1,4),(-1,3),(-1,1),(2,5),(-2,7),(-2,9),(-2,8),(-2,6)]
FORB={(3,(),9),(3,(2,),7),(4,(),0),(8,(),4),(8,(1,),2),(9,(),5)}


def reduced(word):
 result=[]
 for g in word:
  if result and result[-1]==-g:result.pop()
  else:result.append(g)
 return tuple(result)


def words(radius):
 result={()};front={()}
 for _ in range(radius):
  front={reduced(w+(g,))for w in front for g in (1,-1,2,-2)}
  result|=front
 return result


def good(mt,mw,ct,cw):
 if cw is None:return True
 rel=reduced(tuple(-g for g in reversed(mw))+cw)
 return not (rel==() and mt==ct) and (mt,rel,ct)not in FORB


def main():
 start=time.monotonic()
 archive=ROOT/'research/composition-interface-navigation-certificates.json.gz'
 with gzip.open(archive,'rt')as f:raw=json.load(f)
 old=json.loads((ROOT/'research/composition-interface-navigation-verification.json').read_text())
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==old['artifact_sha256']
 for p,h in old['source_sha256'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h
 M=[(tuple(w),t)for w,t in raw['messenger_positions']]
 C=[(None if w is None else tuple(w),t)for w,t in raw['pursuer_positions']]
 assert len(M)==170 and set(M)=={(w,t)for w in words(2)for t in range(10)}
 assert len(C)==540 and set(C)=={(w,t)for w in words(3)for t in range(10)}|{(None,t)for t in range(10)}
 assert len(set(M))==len(M)and len(set(C))==len(C)
 mi={v:i for i,v in enumerate(M)};ci={v:i for i,v in enumerate(C)}
 moves=[];responses=[]
 for w,t in M:
  nxt={(w,t)}
  for g,j in [A[t],B[t]]:
   z=reduced(w+(g,))if g else w
   if len(z)<=2:nxt.add((z,j))
  moves.append({mi[v]for v in nxt})
 for w,t in C:
  nxt={(w,t)}
  for g,j in [A[t],B[t]]:
   if w is None:
    nxt.add((None,j))
    if g:
     for z in words(3):
      if len(reduced(z+(-g,)))>3:nxt.add((z,j))
   else:
    z=reduced(w+(g,))if g else w
    nxt.add((z,j)if len(z)<=3 else(None,j))
  responses.append({ci[v]for v in nxt})
 assert all(set(a)==b for a,b in zip(raw['messenger_successors'],moves))
 assert [int(x,16)for x in raw['pursuer_successor_masks']]==[sum(1<<v for v in s)for s in responses]
 forbidden={(i,tuple(w),j)for i,w,j in raw['forbidden_states']}
 assert forbidden==FORB
 total=0;records=[]
 for item in raw['records']:
  g=item['generator'];assert g in(-1,-2)
  layers=[[int(v,16)for v in row]for row in item['layers']]
  assert len(layers)==33 and all(len(row)==len(M)for row in layers)
  expected=[sum(1<<c for c,(cw,ct)in enumerate(C)if good(mt,mw,ct,cw)) if mw==(g,) else 0 for mw,mt in M]
  assert layers[0]==expected
  required=[(r,c)for r,(mw,mt)in enumerate(M)if mw==()for c,(cw,ct)in enumerate(C)if good(mt,mw,ct,cw)]
  assert len(required)==5384 and all(layers[-1][r]>>c&1 for r,c in required)
  new_count=0
  for d in range(1,len(layers)):
   prev,nxt=layers[d-1],layers[d]
   for r,(rw,rt)in enumerate(M):
    assert prev[r]&~nxt[r]==0
    assert nxt[r]>>(len(C))==0
    assert not(nxt[r]>>ci[(rw,rt)]&1)
    bits=nxt[r]&~prev[r]
    while bits:
     bit=bits&-bits;bits-=bit;c=bit.bit_length()-1
     assert any(C[c]!=M[v] and all(prev[v]>>cc&1 for cc in responses[c])for v in moves[r]),(g,d,r,c)
     new_count+=1
  total+=new_count;records.append({'generator':g,'new_states':new_count,'required_starts':len(required),'moves':32})
 assert len(records)==2 and {x['generator']for x in records}=={-1,-2}
 norm=0
 for mt,cw,ct in FORB:
  g,j=B[mt];mw=reduced((g,))if g else()
  assert (mw,j)!=(cw,ct)
  for cc in responses[ci[(cw,ct)]]:
   cww,ctt=C[cc]
   assert good(j,mw,ctt,cww)
  norm+=1
 assert total==121340 and norm==6
 receipt={'verified':True,'scope':'Independent literal-rule arena reconstruction and complete saved-layer replay; separate ordinary radius-four projection audit. No universal point-delivery claim.',
          'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'original_source_hashes_match':True,'records':records,'normalization_cases':norm,'seconds':time.monotonic()-start}
 (ROOT/'research/composition-interface-navigation-independent-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt))
if __name__=='__main__':main()

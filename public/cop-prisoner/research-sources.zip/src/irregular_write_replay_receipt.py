#!/usr/bin/env python3
"""Revalidate an accepted target closure and save its public campaign receipt.

This does not compile Lean or turn producer output into proof evidence. Every
record must match the current compiler, source, transitive dependency and object
pins using the strict replay coordinator's unchanged acceptance predicate.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('replay', ROOT/'src/replay_lean_checkpoint.py')
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--target', required=True)
    ap.add_argument('--cache', type=Path, required=True)
    ap.add_argument('--log', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--scope', required=True)
    ap.add_argument('--claim', action='append', default=[])
    ap.add_argument('--pin', action='append', default=[])
    args = ap.parse_args()
    assert not args.output.exists(), 'Never overwrite a published receipt.'
    cache_bytes = args.cache.read_bytes()
    cache = json.loads(cache_bytes)
    log_bytes = args.log.read_bytes()
    assert log_bytes.rstrip().endswith(b'Requested kernel replay completed.')
    compiler = replay.sha(replay.LEAN)
    version = subprocess.check_output([str(replay.LEAN), '--version'], text=True).strip()
    assert 'version 4.33.1' in version
    inventory = {p.stem: p for p in replay.HERE.glob('*.lean')}
    sources = replay.target_sources(inventory, [args.target])
    order, external = replay.checker.build_order(list(sources.values()))
    assert all(x == 'Std' or x.startswith(('Std.', 'Init.')) for x in external)
    source_hashes = {n: replay.sha(p) for n, p in sources.items()}
    object_hashes = {n: replay.sha(replay.HERE/f'{n}.olean') for n in order}
    fingerprints, records = {}, []
    for n in order:
        code = replay.checker.without_comments(sources[n].read_text())
        imports = [x for line in code.splitlines() if line.startswith('import ')
                   for x in line[7:].split()]
        deps = [x for x in imports if x in sources]
        fingerprints[n] = hashlib.sha256(json.dumps(
            [compiler, source_hashes[n], [(x, fingerprints[x]) for x in deps]],
            sort_keys=True).encode()).hexdigest()
        pins = {x: object_hashes[x] for x in deps}
        assert replay.reusable_record(cache.get(n), n, fingerprints[n],
            source_hashes[n], object_hashes[n], pins), ('invalid_record', n)
        records.append(cache[n])
    assert source_hashes == {n: replay.sha(p) for n, p in sources.items()}
    assert object_hashes == {n: replay.sha(replay.HERE/f'{n}.olean') for n in order}
    assert cache_bytes == args.cache.read_bytes(), 'Cache changed during validation.'
    assert compiler == replay.sha(replay.LEAN), 'Compiler changed during validation.'
    pins = {}
    for name in args.pin:
        p = (ROOT/name).resolve()
        relative = str(p.relative_to(ROOT))
        pins[relative] = replay.sha(p)
    data = {
        'scope': args.scope,
        'claims': args.claim,
        'verified_at': datetime.now(timezone.utc).isoformat(),
        'target': args.target,
        'compiler_version': version,
        'compiler_sha256': compiler,
        'record_validation_coordinator_sha256': replay.sha(ROOT/'src/replay_lean_checkpoint.py'),
        'validation_tools_sha256': {
            'src/irregular_write_replay_receipt.py': replay.sha(Path(__file__)),
            'lean/check.py': replay.sha(replay.HERE/'check.py')},
        'external_imports': external,
        'source_sha256': {str(sources[n].relative_to(ROOT)): source_hashes[n] for n in order},
        'provenance_sha256': pins,
        'records': records,
        'cache_sha256': hashlib.sha256(cache_bytes).hexdigest(),
        'log_sha256': hashlib.sha256(log_bytes).hexdigest(),
        'all_passed': True,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2)+'\n')
    print(json.dumps({'target': args.target, 'modules': len(order),
                      'receipt': str(args.output), 'sha256': replay.sha(args.output)}))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Boolean-array local attractor, cross-checked against the integer version.
This is an exploratory speed optimization, not an independent proof audit.
"""
import numpy as np
def attract(ar,seeds,receipt=frozenset()):
 M,C,mi,ci,mo,co=ar;nr,nc=len(M),len(C)
 seed=np.array([[(x>>c)&1 for c in range(nc)] for x in seeds],dtype=np.bool_)
 W=seed.copy();rec=np.array(sorted(receipt),dtype=np.intp);ridx=np.arange(nr);diag=np.array([ci[v] for v in M],dtype=np.intp)
 cop_lists=[]
 for mask in co:
  row=[]
  while mask:
   bit=mask&-mask;mask-=bit;row.append(bit.bit_length()-1)
  cop_lists.append(row)
 cop=np.array([row+[row[0]]*(max(map(len,cop_lists))-len(row)) for row in cop_lists],dtype=np.intp).T
 msg=np.array([row+[row[0]]*(max(map(len,mo))-len(row)) for row in mo],dtype=np.intp).T
 rounds=0
 while True:
  safe=W[:,cop[0]].copy()
  for dest in cop[1:]:safe &= W[:,dest]
  safe[rec,:]=True
  U=seed.copy()
  for dest in msg:U |= safe[dest,:]
  U[ridx,diag]=False
  U[rec,:]=True
  if np.array_equal(U,W):return W,rounds
  assert not np.any(W & ~U)
  W=U;rounds+=1

if __name__=='__main__':
 from composition_interface_branch_terminal import arena
 from composition_interface_invariant import attract as slow
 for ar in (arena(2,3,1),arena(3,3,2)):
  M,C,mi,ci,mo,co=ar;tr=mi[(-1,),4];seeds=[(1<<len(C))-1 if r==tr else 0 for r in range(len(M))]
  U,d=slow(ar,seeds,{tr});V,e=attract(ar,seeds,{tr})
  assert d==e
  assert all(np.array_equal(V[r],np.array([(u>>c)&1 for c in range(len(C))],dtype=np.bool_)) for r,u in enumerate(U))
  print('cross-check passed',len(M),len(C),d)

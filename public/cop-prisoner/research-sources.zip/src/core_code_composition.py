#!/usr/bin/env python3
"""Explicit antichain composition over a two-type universal delivery core.

Discovery/verification tool. The parameterized theorem has an ordinary
case proof; samples here are not extrapolated to infinite orders.
"""
from __future__ import annotations
from itertools import combinations
from math import comb
import argparse,json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def capacity(k,r):
    assert k%2==1 and k>=7 and 3<=r<=k//2
    return k*comb(k-r,r)//(k-r)


def codes(k,r,count):
    # First choose nonadjacent vertices in cyclic order; multiplication by
    # two identifies that cycle with the forbidden-difference-2 point graph.
    assert 0<=count<=2*capacity(k,r)
    if count==0:return []
    result=[]
    for pick in combinations(range(k),r):
        if any(b-a==1 for a,b in zip(pick,pick[1:])):continue
        if pick[0]==0 and pick[-1]==k-1:continue
        result.append(frozenset((2*j)%k for j in pick))
        if len(result)==count:break
        result.append(frozenset(k+j for j in pick))
        if len(result)==count:break
    assert len(result)==count
    return result


def construction(k,r,q,added=0):
    n=2*k+q; K=codes(k,r,q)
    F={(i,k+i)for i in range(k)}|{(i,k+(i-1)%k)for i in range(k)}
    F|={(k+i,(i+4)%k)for i in range(k)}|{(k+i,(i+6)%k)for i in range(k)}
    H={(u,v)for u in range(2*k)for v in range(2*k)if u!=v and(u,v)not in F}
    B=H|{(u,x)for u in range(2*k)for x in range(2*k,n)}
    B|={(2*k+j,u)for j,S in enumerate(K)for u in range(2*k)if u not in S}
    O={(x,y)for x in range(2*k,n)for y in range(2*k,n)if x!=y}
    assert len(B)==2*k*(2*k-3)+(4*k-r)*q
    assert not B&O and len(O)==q*(q-1)
    assert 0<=added<=len(O)
    return {'n':n,'k':k,'r':r,'q':q,'K':[sorted(S)for S in K],
            'base':sorted(B),'optional':sorted(O),'arcs':sorted(B|set(sorted(O)[:added]))}


def robust_check(graph):
    """Check asymmetric safe two-move witnesses for all mandatory-missing pairs.

    The messenger uses B and the pursuer receives E=B union O. The terminal
    pair may be made direct by optional arrows, which only makes it easier.
    """
    n=graph['n'];B=set(map(tuple,graph['base']));E=B|set(map(tuple,graph['optional']))
    out=[set()for _ in range(n)];pred=[set()for _ in range(n)];cop=[{c}for c in range(n)]
    for s,t in B:out[s].add(t);pred[t].add(s)
    for s,t in E:cop[s].add(t)
    checked=0
    for s in range(n):
        for t in range(n):
            if s==t or(s,t)in B:continue
            mids=out[s]&pred[t]
            for c in range(n):
                if c==s:continue
                assert mids-cop[c],(n,s,t,c)
                checked+=1
    return checked


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,
        default=ROOT/'research/core-code-composition-checks.json')
    args=ap.parse_args();rows=[]
    for k,r,qs in [(7,3,[1,3,7,14]),(9,3,[1,8,30,60]),(11,3,[12,40,93]),
                   (13,4,[25,80]),(15,4,[100])]:
        for q in qs:
            g=construction(k,r,q);checked=robust_check(g)
            row={'k':k,'r':r,'q':q,'n':g['n'],'capacity':2*capacity(k,r),
                 'base_arcs':len(g['base']),'optional_arcs':len(g['optional']),
                 'asymmetric_two_move_checks':checked}
            rows.append(row);print(json.dumps(row),flush=True)
    args.out.write_text(json.dumps({'verified':True,'rows':rows},indent=2)+'\n')

if __name__=='__main__':main()

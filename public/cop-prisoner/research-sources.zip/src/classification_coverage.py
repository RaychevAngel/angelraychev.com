#!/usr/bin/env python3
"""Compute the complement of incorporated proved classification domains.

Only arithmetic and reads of existing certificates are used: no game search,
attractor solve, graph enumeration or conditional-witness search is performed.
Default writes publication/classification-coverage.json; --check recomputes and
compares without writing. --cell N M reports bounds for a single arbitrary input.
"""
from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import sys
import classification_extensions as extensions
from classification_small_cases import host_cutoff

ROOT = Path(__file__).resolve().parents[1]
LIMIT = 114
SMALL_ARC = (0,0,0,0,1,1,2,2,4,5,6,8)
RULES = {}
READS = set()


def rule(name, statement, sources, maturity="ordinary theorem"):
    RULES[name] = {"statement":statement,"sources":sources,"maturity":maturity}
    READS.update(sources)
    return name


def read(name):
    READS.add(name)
    return json.loads((ROOT/name).read_text())


def setup():
    RULES.clear(); READS.clear()
    rule("zero", "0 is attained at every admissible budget by the row-prefix construction.", ["paper/main.md"])
    rule("elementary", "I<=min(n(n-1)-m,max(0,n(n-3)),floor(m/2)^2).", ["paper/main.md"])
    rule("arc_even", "For m=2k,k>=5, I<=k(k-3); equality construction for k>=12 on k vertices.", ["paper/main.md","paper/sparse-all-orders.md"])
    rule("arc_odd", "For m=2k+1,k>=5, I<=k(k-3)+2; equality construction for k>=12 on k+1 vertices.", ["paper/main.md","paper/odd-endpoint-resume.md"])
    rule("arc_small", "M_E(0..11)=(0,0,0,0,1,1,2,2,4,5,6,8). Joint equality requires a fitting witness.", ["paper/small-arcs.md","paper/small-arcs-resume.md","research/small-arcs-resume-verification.json"], "ordinary reduction and completed finite enumeration")
    rule("small_vertex", "M_V(7)<=21, M_V(8)<=32, M_V(9)<=53, M_V(10)<=69, M_V(11)<=87.", ["paper/small-orders-resume.md","research/small-exceptional-verification.json"], "completed finite exclusions")
    rule("small_even_support", "M_E(12)<=15, M_E(14)<=24, M_E(16)<=35, M_E(18)<=53, M_E(20)<=69, M_E(22)<=81.", ["paper/sparse-stability.md","paper/small-orders-resume.md","paper/odd-endpoint-resume.md"], "ordinary support reduction with existing finite upper bounds")
    rule("small_odd_exclusion", "For 6<=k<=11, M_E(2k+1)<=k(k-3)+1.", ["paper/odd-endpoint-resume.md","research/odd-endpoint-small-exhaustive.json","research/odd-endpoint-n12-exhaustive.json"], "completed exhaustive exclusion plus equality characterization")
    rule("exact23", "M_E(23)=83, attained on 12 vertices; at n=11,m=23 the retained core upper bound is81.", ["paper/odd-endpoint-twenty-three-exact.md","paper/odd-endpoint-resume.md"])
    rule("isolate", "Adding isolates preserves I; for m>0, M(n,m)=M(min(n,2m),m).", ["paper/main.md"], "ordinary support bound and isolate invariance")
    rule("dense_zero", "M(n,n(n-2))=floor((n-2)/2); above n(n-2), M=0.", ["paper/main.md"])
    rule("dense_upper", "For 1<=r<=n, M(n,n(n-3)+r)<=2n-r-ceil(r/2)-1.", ["paper/followup-extrema.md"])
    rule("dense58_endpoint", "For n>=10, M(n,n(n-3))=2n.", ["paper/dense-unified-core.md"])
    rule("dense58_bridge", "For n>=16 and2n<=h<=3n, M(n,L-h)=h; every optional subset.", ["paper/dense-unified-core.md"])
    rule("dense58_staircase", "At m=n(n-3)+r the upper bound is attained if r=n, or r=1 and n>=16, or r>=2 and k=n-r>=1 with k>=10 or k<=binom(floor((r-1)/2),2). In particular all r for n>=20.", ["paper/dense-unified-core.md"])
    rule("dense58_caps", "H5=10q²+5q+s²+s, n=10q+s>=30; H4=4q²-26q+s²+s,n=4q+s>=44; 2n<=h<=max applicable H is exact.", ["paper/dense-unified-core.md"])
    rule("dense48", "For n>=19, 3n<=h<=n max(3,ceil((n-1)/13)) is exact.", ["paper/dense-protected-envelope.md"])
    rule("circle11", "For odd h>=7,2h+1<=n,gcd(h,n)=1, budget3n attains L-3n.", ["paper/main.md"])
    rule("circle38", "For n>=25, all3n..n(ceil(n/7)-1) attain L-m.", ["paper/main-interval-resume.md"])
    rule("circle_runs", "The explicit run averaging bound after59 gives |A|>=max(4,ceil(n/7),4+ceil(|J|(n-19)/n)); checked admissible h supplies every3n..n(|A|-1).", ["paper/core-code-composition.md","paper/main-interval-resume.md"])
    rule("circle_saved", "A stored protected envelope with its six differences verified supplies every budget3n..n(|A|-1).", ["paper/main-interval-resume.md","research/core-code-circle-overlap-screen.json","research/main-interval-resume-checks.json"], "existing explicit structural certificate plus ordinary strategy")
    rule("sidon34", "If d>=4,n>d³+2d, every3n..dn is exact; numerical domain is subsumed by38 here.", ["paper/main-interval-explicit.md"])
    rule("five36", "n divisible by5,n>=50: every2n..11n/5 is exact.", ["paper/sparse-budget-interval.md"])
    rule("five37", "n divisible by5,n>=80: every2n..3n is exact.", ["paper/sparse-budget-interval.md"])
    rule("parabola35", "n=p²,p>=5 prime: every4n..n(p-1) is exact.", ["paper/parabola-family.md"])
    rule("antichain59", "For odd k>=7,3<=r<=floor(k/2),q=n-2k>=0,q<=2k*binom(k-r,r)/(k-r), allA..A+q(q-1) exact, A=2k(2k-3)+(4k-r)q.", ["paper/core-code-composition.md"])
    rule("routing54", "Theorem54 exact-budget inequality is inapplicable for n<=114: (b-3)p²(1-p)<=4(n-3)/27<4ln(n)+ln(8/3).", ["paper/routing-unification.md"])
    rule("orientation", "If n(n-1)(n-2)(7/8)^(b-3)+n(n-1)(3/4)^(b-2)<1, allQ/2..L-Q/2 exact; checked with integers.", ["paper/routing-unification.md"])
    rule("main115", "For n>=115 andm>=23, existing sparse/main/staircase/zero results give the exact value; m23 uses its separate theorem.", ["paper/joint-classification-resume.md","paper/odd-endpoint-twenty-three-exact.md"])
    rule("main106", "For n>=106 andm>=22, sparse/main/staircase/zero results give the exact value; m22 andm23 use separate exceptional theorems.", ["paper/joint-classification-resume.md","paper/sparse-third.md","paper/dense-third.md","src/main_interval_composed.py"])
    rule("main12", "For every n>=12 the full main interval2n..n(n-3) has valueL-m and direct constructions; together with retained sparse/dense results every n>=13,m>=22 is exact.", ["paper/main-interval-complete.md","src/main_interval_complete.py","src/main_interval_pair_codes.py","research/main-interval-pair-complete-checks.json","research/main-interval-pair-code-checks.json"])
    rule("main104", "For n>=104 andm>=22, the expanded main construction and unchanged sparse/dense formulas give the exact value. Every3n..n(n-3) is exact already for n>=43.", ["paper/main-interval-new-overlap.md","src/main_interval_expanded.py","paper/joint-classification-resume.md"])
    rule("sparse52", "n=6k-r>=115,k=ceil(n/6), every2n..20k-11r is exact. Adds no cells in the residual n<=114 box.", ["paper/sparse-packed-holes.md"])
    rule("component_padding", "A certified component can be combined with a row-prefix zero-I component on remaining vertices at any feasible remaining arc budget.", ["paper/main.md"])
    extensions.register(sys.modules[__name__])


def staircase(n,m):
    r=m-n*(n-3)
    return 2*n-r-(r+1)//2-1


def boundary_upper(n,m):
    values=[(min(n*(n-1)-m,max(0,n*(n-3)),(m//2)**2),"elementary")]
    values.extend(extensions.bounds(n,m))
    if m<=11:values.append((SMALL_ARC[m],"arc_small"))
    if m>=10:
        k=m//2;values.append((k*(k-3)+(2 if m%2 else 0),"arc_odd" if m%2 else "arc_even"))
    if n in {7,8,9,10,11}:values.append(({7:21,8:32,9:53,10:69,11:87}[n],"small_vertex"))
    if m in {12,14,16,18,20,22}:values.append(({12:15,14:24,16:35,18:53,20:69,22:81}[m],"small_even_support"))
    if m%2 and 13<=m<=23:
        k=m//2;values.append((k*(k-3)+1,"small_odd_exclusion"))
    if m==23:values.append((81 if n==11 else 83,"exact23"))
    if n>=2 and n*(n-3)<m<=n*(n-2):values.append((staircase(n,m),"dense_upper"))
    if n>=2 and m>n*(n-2):values.append((0,"dense_zero"))
    return min(values,key=lambda x:x[0])


def known_exact(row,n,a,b,source,value=None):
    a=max(0,a);b=min(len(row)-1,b)
    for m in range(a,b+1):
        v=n*(n-1)-m if value is None else value(m) if callable(value) else value
        add_lower(row,m,v,source,n)
        if v<row[m][1]:row[m][1]=v;row[m][3]=source


def add_lower(row,m,value,source,support,base_m=None):
    if 0<=m<len(row) and value>row[m][0]:
        row[m][0]=value;row[m][2]=source;row[m][4]=support;row[m][5]=base_m


def certified_points():
    points=[]
    for n in range(1,7):
        name=f"research/solver-enumeration-n{n}.json";data=read(name)
        if n==6:assert data["complete"]
        rid=rule(f"enumerated_n{n}",f"Complete joint maximum table at n={n}.",[name,"research/solver-enumeration-receipt.json"],"completed enumeration; witness game replay recorded")
        for x in data["by_m"]:points.append((n,x["m"],x["maximum_I"],rid,True))
    data=read("research/small-arcs-resume-verification.json");assert data["verified"]
    for case in data["cases"]:
        w=case["lower_certificate"];points.append((w["n"],w["m"],w["I"],"arc_small",True))
    name="research/small-arcs-twelve-thirteen-witnesses.json"; data=read(name); assert data["verified"]
    rid=rule("small12_13_lower","Existing complete rank certificates at budgets12/13; explicitly lower-only because upper runs were incomplete.",[name],"previously verified complete finite rank certificate")
    for case in data["cases"]:
        w=case["certificate"]; assert len(w["certificates"])==w["n"] and len(w["arcs"])==w["m"]
        points.append((w["n"],w["m"],w["I"],rid,False))
    name="research/classification-fixed-witnesses.json"; data=read(name)
    assert all(data["verification"][key] for key in ["two_solvers_agree","saved_rank_replay_passed","literal_replay_passed"])
    for path,digest in data["source_sha256"].items():
        READS.add(path); assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest
    rid=rule("fixed71_lower","The retained contraction graph at n11,m22 has I71, checked by both game solvers and direct winning/losing rank replay. Lower bound only.",[name,"src/game_solver.py","research/small-exceptional-contractions.json"],"fixed-graph two-solver validation and independent literal rank replay; no graph search or upper exclusion")
    for record in data["records"]:
        w=record["result"]; assert len(w["certificates"])==record["n"] and len(record["arcs"])==record["m"] and w["I"]==record["I"]
        points.append((record["n"],record["m"],record["I"],rid,False))
    rid=rule("layered16","The balanced original family x=3 has n44,m240,I764; x5 already exceeds the residual order box.",["paper/main.md"],"ordinary exact evaluation of a particular construction, lower bound for M")
    points.append((44,240,764,rid,False))
    names=["research/small-exceptional-general-certificates.json","research/root-small-structured-9-certificate.json","research/small-exceptional-structured-11-certificate.json","research/small-exceptional-one-excess-11-witness-certificate.json","research/small-exceptional-regular-max-11-witness-certificate.json","research/odd-endpoint-completion-certificate.json"]
    for name in names:
        data=read(name)
        entries=data if isinstance(data,list) else data["results"] if "results"in data else[data]
        rid=rule(Path(name).stem,"Existing complete actual-game certificate; used only as a lower bound unless it matches an incorporated upper bound.",[name],"previously verified finite rank certificate; no new game solve")
        for w in entries:
            assert len(w["certificates"])==w["n"] and len(w["arcs"])==w["m"]
            points.append((w["n"],w["m"],w["I"],rid,False))
    return points


def saved_circles():
    result={}
    records=read("research/core-code-circle-overlap-screen.json")["rows"]
    for r in records:
        n=r["n"]
        if n>LIMIT:continue
        h=r["h"];core={1,(h-1)//2,h};A=set(r["Aset"])
        assert n>=2*h+1 and h>=7 and h%2 and math.gcd(h,n)==1
        assert {0}|core<=A and A<=set(range(n))
        D={(u-v)%n for u in core for v in core if u!=v};assert len(D)==6
        assert all(sum((u-d)%n in A for u in A)==1 for d in D)
        result[n]=max(result.get(n,0),n*(len(A)-1))
    for r in read("research/main-interval-resume-checks.json")["structural_checks"]:
        if r["n"]<=LIMIT:
            n=r["n"]; A=set(r["closed_envelope"]); core=set(r["core"])
            D={(u-v)%n for u in core for v in core if u!=v}
            h=max(core)
            assert core=={1,(h-1)//2,h} and h>=7 and h%2 and n>=2*h+1 and math.gcd(h,n)==1
            assert len(core)==3 and len(D)==6 and {0}|core<=A and A<=set(range(n))
            assert all(sum((u-d)%n in A for u in A)==1 for d in D)
            assert r["maximum_m"]==n*(len(A)-1)
            result[n]=max(result.get(n,0),r["maximum_m"])
    return result


def saved_dense_tiny():
    name="research/routing-defect-phase2-dense-tiny-checks.json"
    receipt=read("research/routing-defect-phase2-dense-tiny-independent.json")
    verifier="src/routing_defect_phase2_dense_tiny_verify.py"
    assert receipt["verified"]
    assert receipt["archive_sha256"]==hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    assert receipt["source_sha256"]==hashlib.sha256((ROOT/verifier).read_bytes()).hexdigest()
    rule("dense_tiny","Existing full robust envelopes n=10..18 give every h=2n..2n+full_optional_cap. Complete literal witness coverage is checked here; n18's full21 exceeds the theorem's selected18.",[name,"research/routing-defect-phase2-dense-tiny-independent.json",verifier,"paper/dense-unified-core.md"],"literal structural certificate replay plus ordinary envelope lemma; broader full cap is external, not the selected Lean cap")
    result={}
    for r in read(name)["rows"]:
        n=r["n"]; B=set(map(tuple,r["base"])); E=set(map(tuple,r["optional"])); F=B|E
        assert len(B)==2*n and not B&E and len(E)==r["full_optional_cap"]
        assert all(0<=s<n and 0<=t<n and s!=t for s,t in F)
        assert all(sum(s==v for s,t in B)==sum(t==v for s,t in B)==2 for v in range(n))
        seen=set()
        for s,t,c,u in r["literal_witnesses"]:
            assert (s,t) in F and 0<=c<n and c!=s and 0<=u<n and (s,t,c) not in seen
            seen.add((s,t,c))
            assert len({s,u,t})==3 and u!=c and (s,u) not in F and (u,t) not in F and (c,u) in B
        assert seen=={(s,t,c) for s,t in F for c in range(n) if c!=s}
        result[n]=len(E)
    return result


def explicit_domains(row,n,circles,dense_tiny):
    L=n*(n-1)
    for h in range(7,(n-1)//2+1,2):
        if math.gcd(n,h)!=1:continue
        known_exact(row,n,3*n,3*n,"circle11")
        a=(h-1)//2;p=3*a-1;j=(n//p)*(a-1)
        size=max(4,(n+6)//7,4+(j*(n-19)+n-1)//n)
        if n>=25:known_exact(row,n,3*n,n*(size-1),"circle_runs")
    if n>=25:known_exact(row,n,3*n,n*((n+6)//7-1),"circle38")
    if n in circles:known_exact(row,n,3*n,circles[n],"circle_saved")
    for d in range(4,n):
        if n>d**3+2*d:known_exact(row,n,3*n,d*n,"sidon34")
        else:break
    if n>=50 and n%5==0:known_exact(row,n,2*n,11*n//5,"five36")
    if n>=80 and n%5==0:known_exact(row,n,2*n,3*n,"five37")
    p=math.isqrt(n)
    if p*p==n and p>=5 and all(p%d for d in range(2,math.isqrt(p)+1)):
        known_exact(row,n,4*n,n*(p-1),"parabola35")
    for k in range(7,n//2+1,2):
        q=n-2*k
        for r in range(3,k//2+1):
            cap=2*k*math.comb(k-r,r)//(k-r)
            if q<=cap:
                A=2*k*(2*k-3)+(4*k-r)*q
                known_exact(row,n,A,A+q*(q-1),"antichain59")
    for b in range(3,n+1):
        # Common positive denominator 8^(b-3)*4^(b-2).
        numerator=n*(n-1)*(n-2)*7**(b-3)*4**(b-2)+n*(n-1)*3**(b-2)*8**(b-3)
        if numerator<8**(b-3)*4**(b-2):
            A=b*(2*n-b-1)//2
            known_exact(row,n,A,L-A,"orientation")
    if n>=10:known_exact(row,n,L-2*n,L-2*n,"dense58_endpoint")
    if n>=16:known_exact(row,n,L-3*n,L-2*n,"dense58_bridge")
    if n>=19:known_exact(row,n,L-n*max(3,(n+11)//13),L-3*n,"dense48")
    if n>=30:
        q,s=divmod(n,10);H=10*q*q+5*q+s*s+s
        if n>=44:
            q,s=divmod(n,4);H=max(H,4*q*q-26*q+s*s+s)
        known_exact(row,n,L-H,L-2*n,"dense58_caps")
    for r in range(1,n+1):
        k=n-r
        if (r==1 and n>=16) or (r>=2 and k>=1 and (k>=10 or k<=math.comb((r-1)//2,2))):
            m=n*(n-3)+r
            known_exact(row,n,m,m,"dense58_staircase",staircase(n,m))
    if n in dense_tiny:
        known_exact(row,n,L-2*n-dense_tiny[n],L-2*n,"dense_tiny")
    if n>=2:
        known_exact(row,n,n*(n-2),n*(n-2),"dense_zero",(n-2)//2)
        known_exact(row,n,n*(n-2)+1,L,"dense_zero",0)


def calculate():
    setup(); READS.add("src/classification_coverage.py")
    points=certified_points()+extensions.points(sys.modules[__name__]);circles=saved_circles();dense_tiny=saved_dense_tiny();rows={}
    extension_inputs=extensions.inputs(sys.modules[__name__])
    for n in range(1,LIMIT+1):
        row=[]
        for m in range(n*(n-1)+1):
            upper,source=boundary_upper(n,m)
            row.append([0,upper,"zero",source,n,None])
        explicit_domains(row,n,circles,dense_tiny)
        extensions.domains(sys.modules[__name__],row,n,extension_inputs)
        for order,m,value,source,exact in points:
            if order==n:
                if exact:known_exact(row,n,m,m,source,value)
                else:add_lower(row,m,value,source,n)
        for m in range(24,min(2*n,len(row)-1)+1):
            k=m//2
            if k>=12 and (m%2==0 or k+1<=n):
                known_exact(row,n,m,m,"arc_odd" if m%2 else"arc_even",k*(k-3)+(2 if m%2 else 0))
        if n>=12:known_exact(row,n,23,23,"exact23",83)
        if n>1:
            for m,old in enumerate(rows[n-1]):
                add_lower(row,m,old[0],old[2],old[4],old[5])
                if m>0 and n>host_cutoff(m):
                    assert old[1]<=row[m][1]
                    row[m][1]=old[1];row[m][3]=old[3]
        # Existing certified components plus a zero-I component, never arbitrary edge additions.
        for order,m,value,source,_ in points:
            if order>=n or value<=0:continue
            spare=n-order
            for budget in range(m,min(len(row)-1,m+spare*(spare-1))+1):
                add_lower(row,budget,value,source,order,m)
        for m,cell in enumerate(row):
            assert 0<=cell[0]<=cell[1],(n,m,cell)
        rows[n]=row
    return rows


def ranges(values):
    out=[]
    for value in values:
        if out and value==out[-1][1]+1:out[-1][1]=value
        else:out.append([value,value])
    return out


def encode_row(n,row):
    segments=[];a=0
    while a<len(row):
        x=row[a];end=a;dl=du=0
        if a+1<len(row) and row[a+1][2:]==x[2:] and (row[a+1][0]==row[a+1][1])==(x[0]==x[1]):
            dl=row[a+1][0]-x[0];du=row[a+1][1]-x[1];end=a+1
            while end+1<len(row):
                y=row[end+1]
                if y[2:]!=x[2:] or (y[0]==y[1])!=(x[0]==x[1]) or y[0]!=x[0]+dl*(end+1-a) or y[1]!=x[1]+du*(end+1-a):break
                end+=1
        segments.append({"m":[a,end],"status":"exact" if x[0]==x[1] else"unresolved",
                         "lower":[x[0],dl,x[2],x[4],x[5]],"upper":[x[1],du,x[3]]})
        a=end+1
    unknown=[m for m,x in enumerate(row)if x[0]<x[1]]
    return {"n":n,"admissible":len(row),"exact":len(row)-len(unknown),"unresolved":len(unknown),
            "unresolved_m_ranges":ranges(unknown),"segments":segments}


def payload(rows):
    records=[encode_row(n,row) for n,row in rows.items()]
    return {"schema_version":1,"scope":"Numerical coverage of exact M(n,m) in the fixed game; n>=1,0<=m<=n(n-1). Explicit-construction coverage is audited separately.",
            "claim_boundary":"Exact complement of the explicitly incorporated proved domains and certified data below; not an assertion that no unindexed source theorem or further deduction can settle another cell.",
            "finite_box":{"n":[1,LIMIT],"m":"0..n(n-1)"},
            "canonical_representatives":{"condition":"m>0 and n<=B_m, with B_m=2m except the approved stronger12..21 cutoffs; m=0 is exact",
                "host_cutoffs":{str(m):host_cutoff(m) for m in range(12,22)},
                "unresolved":sum(1 for n,row in rows.items() for m,c in enumerate(row) if m>0 and n<=host_cutoff(m) and c[0]<c[1]),
                "regions":{name:sum(1 for n,row in rows.items() for m,c in enumerate(row) if m>0 and n<=host_cutoff(m) and c[0]<c[1] and test(n,m)) for name,test in [("sparse_m_le_2n",lambda n,m:m<=2*n),("main_2n_lt_m_le_n_n_minus3",lambda n,m:2*n<m<=n*(n-3)),("dense_m_gt_max_2n_n_n_minus3",lambda n,m:m>max(2*n,n*(n-3)))]},
                "unresolved_by_n":[{"n":n,"m_ranges":ranges([m for m,c in enumerate(row) if m>0 and n<=host_cutoff(m) and c[0]<c[1]])} for n,row in rows.items()]},
            "reduction":"Every n>=11,m>=22 is classified explicitly, with the three stated order11 boundary exceptions. For12<=m<=21, the comparison-witness support lemma gives M(n,m)=M(min(n,B_m),m) with B=(12,13,16,18,15,18,15,18,11,15), and attainers lift by isolates. The final approved finite exclusions and literal graphs close every formerly unknown representative. The separate construction audit also finds no gap; numerical equality and explicitness are verified separately. The audited box retains n<=114 for historical comparison.",
            "encoding":"For segment m=[a,b], lower=[v,d,rule,base_component_order,base_m] means v+d*(m-a), upper=[v,d,rule] likewise. An exact cell has equal lower/upper; the lower rule supplies an attainment proof or witness; its explicitness is a separate audited property. Null base_m means the witness has the queried budget, with isolates if base_component_order<n. Non-null base_m identifies a stored component at (base_component_order,base_m) plus a disjoint zero-I row-prefix component for the remaining arcs on the remaining vertices. Rule formulas remain authoritative.",
            "regions":{name:sum(1 for n,row in rows.items() for m,c in enumerate(row) if c[0]<c[1] and test(n,m)) for name,test in [("sparse_m_le_2n",lambda n,m:m<=2*n),("main_2n_lt_m_le_n_n_minus3",lambda n,m:2*n<m<=n*(n-3)),("dense_m_gt_max_2n_n_n_minus3",lambda n,m:m>max(2*n,n*(n-3)))]},
            "totals":{"admissible":sum(x["admissible"]for x in records),"exact":sum(x["exact"]for x in records),"unresolved":sum(x["unresolved"]for x in records)},
            "rules":RULES,"source_sha256":{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()for name in sorted(READS)},
            "rows":records,
            "conditional_not_automatically_subtracted":[
                "Arbitrary mixed-size antichains: no unprovided code family is assumed. All-parity equal-weight capacity and listed mixed-size inputs are incorporated.",
                "Arbitrary protected-difference sets: only the published guaranteed run/greedy bounds and saved structurally checked envelopes are incorporated.",
                "Arbitrary high-girth, block-composition or functional-complement criteria require a proved family or explicit certified premise; a conditional statement alone does not mark a cell exact.",
                "Heuristic search scores, incomplete exclusions and negative local tests do not establish an exact extremum."],
            "execution":"Arithmetic coverage calculation and saved-data inspection only; no new game solves or exhaustive graph searches."}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--check",action="store_true");p.add_argument("--cell",nargs=2,type=int,metavar=("N","M"))
    p.add_argument("--out",type=Path,default=ROOT/"publication/classification-coverage.json")
    args=p.parse_args();rows=calculate();data=payload(rows)
    if args.cell:
        n,m=args.cell
        if not(n>=1 and 0<=m<=n*(n-1)):p.error("Require n>=1 and 0<=m<=n(n-1)")
        if m==0:result={"n":n,"m":m,"exact":0,"source":"zero"}
        elif n<=LIMIT:result={"n":n,"m":m,"cell":rows[n][m]}
        elif m<=21:result={"n":n,"m":m,"representative_n":host_cutoff(m),"cell":rows[host_cutoff(m)][m]}
        else:
            if m==22:v=79
            elif m==23:v=83
            elif m<=2*n:
                k=m//2;v=k*(k-3)+(2 if m%2 else 0)
            elif m<=n*(n-3):v=n*(n-1)-m
            elif m<=n*(n-2):v=staircase(n,m)
            else:v=0
            result={"n":n,"m":m,"exact":v,"source":"main104"}
        print(json.dumps(result,indent=2));return
    if args.check:
        assert read_output(args.out)==data,"Coverage file differs from recomputed source-pinned rule closure"
        # Independently expand each affine segment back to every computed cell.
        for record in data["rows"]:
            expanded=[]
            for s in record["segments"]:
                a,b=s["m"];lo,dl,ls,order,base_m=s["lower"];hi,dh,hs=s["upper"]
                expanded.extend([[lo+dl*i,hi+dh*i,ls,hs,order,base_m]for i in range(b-a+1)])
            assert expanded==rows[record["n"]]
        print(json.dumps({"checked":True,**data["totals"]}));return
    args.out.write_text(json.dumps(data,separators=(",",":"))+"\n")
    print(json.dumps({"written":str(args.out),**data["totals"]}))


def read_output(path):
    return json.loads(path.read_text())


if __name__=="__main__":main()

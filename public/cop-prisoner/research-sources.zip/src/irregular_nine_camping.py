#!/usr/bin/env python3
"""Re-encode existing complete DAG leaves with compact stationary-cop regions.
No graph search or coverage modification: the original branch DAG is retained.
"""
from __future__ import annotations
import argparse,json,hashlib,time
from pathlib import Path
from irregular_nine_producer import Producer,N,ALL

def compact(producer,p,old):
    upper,lower=old['upper'],old['lower']
    corner=sum((mask>>t)&1 for s,mask in enumerate(p) if producer.D[s]<2 for t in range(N) if producer.R[t]<2)
    cap=sum(s!=t for s in producer.sources for t in producer.targets)+sum(d for d in producer.D if d<2)+sum(d for d in producer.R if d<2)-14-corner
    needed=max(0,cap-13);lost=[0]*N;camps=[];losses=[]
    if needed:
        candidates=[]
        for c in range(N):
            grouped={}
            for t in producer.targets:
                region=ALL^(1<<t)
                while True:
                    new=region
                    for r in range(N):
                        if r!=c and region>>r&1 and (upper[r]>>t&1 or upper[r]&~(lower[c]|region)):
                            new&=~(1<<r)
                    if new==region:break
                    region=new
                covered={(s,t) for s in producer.sources if s!=t and s!=c and region>>s&1}
                if not covered:continue
                if region not in grouped:grouped[region]=[0,set()]
                grouped[region][0]|=1<<t;grouped[region][1]|=covered
            for region,(targets,covered) in grouped.items():
                assert region&targets==0
                assert all(r==c or not(region>>r&1) or not(upper[r]&targets or upper[r]&~(lower[c]|region)) for r in range(N))
                candidates.append((dict(cop=c,region=region,targets=targets),covered))
        counted=set()
        while len(counted)<needed and candidates:
            index=max(range(len(candidates)),key=lambda j:len(candidates[j][1]-counted))
            cert,pairs=candidates.pop(index);fresh=pairs-counted
            if not fresh:break
            camps.append(cert);counted.update(sorted(fresh)[:needed-len(counted)])
        if len(counted)<needed:
            for cert in old['losses']:
                t=cert['target'];pairs={(s,t) for s in producer.sources if s!=t and cert['region'][s]&~(1<<s)}
                fresh=pairs-counted
                if not fresh:continue
                losses.append(cert);counted.update(sorted(fresh)[:needed-len(counted)])
                if len(counted)>=needed:break
        assert len(counted)>=needed
        # Retain only states reachable from the actual certified initial pairs.
        seeds=[0]*len(camps);target_masks=[0]*len(camps)
        for s,t in counted:
            lost[s]|=1<<t
            for i,camp in enumerate(camps):
                if s!=camp['cop'] and camp['region']>>s&1 and camp['targets']>>t&1:
                    seeds[i]|=1<<s;target_masks[i]|=1<<t
                    break
        trimmed=[]
        for camp,seed,targets in zip(camps,seeds,target_masks):
            if not seed:continue
            c=camp['cop'];region=seed
            while True:
                new=region
                for r in range(N):
                    if region>>r&1:new|=upper[r]&~lower[c]
                if new==region:break
                region=new
            assert region&~camp['region']==0
            assert region&targets==0
            assert all(not(region>>r&1) or not(upper[r]&targets or upper[r]&~(lower[c]|region)) for r in range(N))
            trimmed.append(dict(cop=c,region=region,targets=targets))
        camps=trimmed
    used=[sum(mask>>t&1 for mask in p) for t in range(N)]
    available=sum(1<<t for t in range(N) if used[t]<producer.R[t])
    return dict(lost=lost,upper=upper,lower=lower,available=available,camps=camps,losses=losses)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    data=json.loads(a.input.read_text());producer=Producer(data['profile_id']);stats=dict(bounds=0,camps=0,game_regions=0,no_regions=0)
    for node in data['nodes'].values():
        if node['kind']!='bound':continue
        node['certificate']=compact(producer,node['prefix'],node['certificate']);c=node['certificate']
        stats['bounds']+=1;stats['camps']+=len(c['camps']);stats['game_regions']+=len(c['losses']);stats['no_regions']+=not(c['camps'] or c['losses'])
    data['compact_from_sha256']=hashlib.sha256(a.input.read_bytes()).hexdigest();data['compactor_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();data['compact_counts']=stats
    a.output.write_text(json.dumps(data,separators=(',',':'))+'\n');print(json.dumps(stats))
if __name__=='__main__':main()

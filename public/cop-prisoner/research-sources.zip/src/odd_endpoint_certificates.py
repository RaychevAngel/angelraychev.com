#!/usr/bin/env python3
"""Uniform odd-endpoint certificate: six-type family with one arc deleted."""
from __future__ import annotations
import gzip
import hashlib
import json
from pathlib import Path
from odd_endpoint_six import DeletedStrip,check_strip

ROOT=Path(__file__).resolve().parents[1]
SIGMA=[0,2,5,1,4,3]
VOLTAGE=[-1,-1,1,1,-1,1]
SOURCE_TYPE=0
EDGE_TYPE=0


def generate():
    records=[]
    for h in [None]+list(range(-6,7)):
        # An exceptional arc outside the arena gives the unchanged base.
        strip=DeletedStrip(1000 if h is None else h,SOURCE_TYPE,EDGE_TYPE,SIGMA,VOLTAGE)
        record=check_strip(strip,retain=True)
        assert record['failures']==0,(h,record['failures'])
        record['defect_column']=h
        records.append(record)
    sources=['src/odd_endpoint_certificates.py','src/odd_endpoint_six.py',
             'src/five_type_certificate.py','src/sparse_composition_smoothing.py']
    result={'status':'verified','family':{'sigma':SIGMA,'voltage':VOLTAGE},
            'deleted_arc':[[0,0],[0,1]],'M':4,'R':6,
            'Omega':'wait or any vertex in columns -6,-5,5,6',
            'transfer':'source column -1 except low-out vertex, goal column0 except low-out vertex, safe messenger turn',
            'delivery':'source column -2 except low-out vertex, all target types at0 except low-in vertex',
            'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()for p in sources},
            'records':records}
    target=ROOT/'research/odd-endpoint-uniform-certificates.json.gz'
    with gzip.open(target,'wt')as f:json.dump(result,f,separators=(',',':'))
    print(json.dumps({'status':'verified','records':sum(len(r['records'])for r in records),
                      'transfer_max':max(max(row['bounds'])for r in records for row in r['records']if row['target']is None),
                      'delivery_max':max(max(row['bounds'])for r in records for row in r['records']if row['target']is not None),
                      'path':str(target)}))
    return result


if __name__=='__main__':generate()

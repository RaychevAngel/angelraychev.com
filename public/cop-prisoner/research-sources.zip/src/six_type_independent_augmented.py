#!/usr/bin/env python3
"""Independent certificates for the eight-extra-pattern six-type bridge."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path

import six_type_independent_verify as independent

ROOT = Path(__file__).resolve().parents[1]
EXTRA = ((1, -3, 5), (3, -3, 5), (4, -3, 0), (4, 3, 1),
         (2, 3, 0), (3, 3, 0), (3, -3, 0), (5, -2, 0))


def arena(hole, augmented):
    assert not augmented or hole is None
    messenger = independent.vertices(4, hole)
    cops = independent.vertices(8, hole) + [None]
    mi = {v: i for i, v in enumerate(messenger)}
    ci = {v: i for i, v in enumerate(cops)}
    omega = ci[None]
    mm = [[mi[v] for v in (p, *independent.outgoing(p, hole)) if v in mi] for p in messenger]
    cm = []
    for p in cops:
        if p is None:
            cm.append([omega] + [i for i, v in enumerate(cops) if v is not None and abs(v[0]) >= 6])
        else:
            destinations = {p, *independent.outgoing(p, hole)}
            if augmented:
                destinations.update((p[0] + shift, target) for source, shift, target in EXTRA if p[1] == source)
            cm.append(sorted({ci.get(v, omega) for v in destinations}))
    return {"messenger": messenger, "cops": cops, "messenger_moves": mm, "cop_moves": cm}


def certificates(hole, augmented):
    a = arena(hole, augmented)
    nc = len(a["cops"])
    out = []
    for target in [None, *[j for j in range(6) if (0, j) != (hole, 4)]]:
        successors, success, collision = independent.game(a, target)
        rank, move = independent.attractor(successors, success)
        independent.check_certificate(successors, success, collision, rank, move)
        col = -1 if target is None else -2
        starts = [2 * (r * nc + c) for r, p in enumerate(a["messenger"]) if p[0] == col
                  for c, cop in enumerate(a["cops"]) if p != cop]
        failures = [state for state in starts if rank[state] < 0]
        out.append({"hole": hole, "augmented_cop": augmented, "target_type": target,
                    "required_starts": len(starts), "failed_starts": failures,
                    "messenger_moves_bound": None if failures else (max(rank[s] for s in starts) + 1) // 2,
                    "ranks": rank, "chosen_messenger_successors": move})
    return out


def main():
    modules = certificates(None, True)
    for hole in range(-8, 9):
        modules.extend(certificates(hole, False))
    failed = [{k: v for k, v in c.items() if k not in ("ranks", "chosen_messenger_successors")}
              for c in modules if c["failed_starts"]]
    payload = {"verified": not failed,
               "arena": "Messenger +/-4 using base moves; cop +/-8 with Omega wait/reentry to any existing vertex at +/-6,+/-7,+/-8.",
               "optional_arcs": EXTRA,
               "state_encoding": "Vertices lexicographic; omit deleted type4; cop Omega last. State 2*(r*nc+c)+turn; turn0 messenger.",
               "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "explicit_solver_sha256": hashlib.sha256(Path(independent.__file__).read_bytes()).hexdigest(),
               "certificates": modules}
    path = ROOT / "research/six-type-independent-augmented-certificates.json.gz"
    with path.open("wb") as destination:
        with gzip.GzipFile(filename="", fileobj=destination, mode="wb", mtime=0) as stream:
            stream.write((json.dumps(payload, separators=(",", ":")) + "\n").encode())
    summary = {"verified": not failed, "module_count": len(modules),
               "required_starts_checked": sum(c["required_starts"] for c in modules),
               "states_checked": sum(len(c["ranks"]) for c in modules),
               "max_transfer_moves": max((c["messenger_moves_bound"] or 0) for c in modules if c["target_type"] is None),
               "max_delivery_moves": max((c["messenger_moves_bound"] or 0) for c in modules if c["target_type"] is not None),
               "failed_modules": failed,
               "certificate_path": str(path.relative_to(ROOT)),
               "certificate_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
               "checker_sha256": payload["checker_sha256"],
               "explicit_solver_sha256": payload["explicit_solver_sha256"]}
    (ROOT / "research/six-type-independent-augmented-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "failed_modules"} | {"failed_modules": len(failed)}))
    if failed:
        print(json.dumps(failed[:3]))


if __name__ == "__main__":
    main()

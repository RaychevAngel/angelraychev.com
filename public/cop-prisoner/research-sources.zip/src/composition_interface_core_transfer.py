#!/usr/bin/env python3
"""A4 two-port cell: safe transfer under adversarial exterior reentry.
All exterior edges terminate at ports 0/11. The exterior can enter either
represented cell at either port; this intentionally forgets quotient geometry.
"""
from pathlib import Path
import json,hashlib,time
from composition_interface_core_ports import core
from composition_interface_invariant import attract
ROOT=Path(__file__).resolve().parents[1]

def arena(reverse=False,omega=True):
 G,out=core();M=[(cell,i) for cell in (0,1) for i in range(12)];C=M+[(None,0)];mi={v:i for i,v in enumerate(M)};ci={v:i for i,v in enumerate(C)}
 mo=[];co=[]
 for cell,i in M:
  suc=[mi[cell,i]]+[mi[cell,j] for j in out[i]]
  if cell==0 and i in (0,11):suc.append(mi[1,i])
  mo.append(suc)
  cops=suc[:]
  if i in (0,11):
   if omega:cops.append(24)
   if cell==1 and reverse:cops.append(ci[0,i])
  co.append(sum(1<<c for c in set(cops)))
 co.append(sum(1<<v for v in (24,0,11,12,23)))
 return M,C,mi,ci,mo,co

def run(reverse=False,omega=True,retain=False):
 ar=arena(reverse,omega);M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1
 seeds=[allc^(1<<ci[M[r]]) if M[r][0]==1 else 0 for r in range(len(M))]
 W,rounds,layers=attract(ar,seeds,retain=True)
 bad=[(M[r],C[c]) for r in range(12) for c in range(len(C)) if c!=r and not(W[r]>>c&1)]
 d={'reverse_crossings':reverse,'exterior_escape':omega,'rounds':rounds,'failed':len(bad),'first_failure':bad[0] if bad else None}
 if retain:d.update(arena=ar,layers=layers)
 return d

if __name__=='__main__':
 rr=[]
 for reverse in (False,True):
  for omega in (False,True):
   d=run(reverse,omega);rr.append(d);print(d)
 out={'scope':'finite safe-cell transfer with two A4 ports; no composition proof asserted by this diagnostic','records':rr,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'research/composition-interface-core-transfer.json').write_text(json.dumps(out,indent=2)+'\n')

#!/usr/bin/env python3
"""Lift existing gap-three strategy certificates to the wider sparse-budget arena.

This checks winning ranks, not closure or optimality of the negative-rank states.
The graph construction and the ordinary projection are Theorem 52.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import itertools
import json
from pathlib import Path
import time

from five_type_certificate import arena, verify
from sparse_composition_multi_certificate import build as old_build
from sparse_composition_smoothing import SmoothStrip
from sparse_composition_spacing import SIGMA, VOLTAGE
from six_type_budget_certificate import EXTRAS

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / 'research/sparse-composition-multi-certificates.json.gz'
OUT = ROOT / 'research/six-type-budget-multihole-certificates.json.gz'


def patterns():
    for size in range(6):
        for holes in itertools.combinations(range(-8, 9), size):
            if all(b-a >= 3 for a, b in zip(holes, holes[1:])):
                yield holes


def build(holes):
    a = arena(SmoothStrip(SIGMA, VOLTAGE, 4, holes),
              messenger_radius=4, pursuer_radius=8)
    cv = a['pursuer_vertices']
    a['pursuer_moves'][-1] = [i for i, v in enumerate(cv)
                              if v is None or abs(v[0]) >= 6]
    return a


def projection(a, b):
    """Map a's wider cop window to b; messenger states and moves are identical."""
    assert a['messenger_vertices'] == b['messenger_vertices']
    assert a['messenger_moves'] == b['messenger_moves']
    ci = {v: i for i, v in enumerate(b['pursuer_vertices'])}
    pi = [ci.get(v, ci[None]) for v in a['pursuer_vertices']]
    for c, successors in enumerate(a['pursuer_moves']):
        assert {pi[d] for d in successors} <= set(b['pursuer_moves'][pi[c]])
    for v in a['messenger_vertices']:
        for c, w in enumerate(a['pursuer_vertices']):
            assert (v == w) == (v == b['pursuer_vertices'][pi[c]])
    return pi


def lift(cert, pi):
    return dict(goal=cert['goal'], safe_transfer=cert['safe_transfer'],
                ranks=[[row[c] for c in pi] for row in cert['ranks']],
                moves=[[row[c] for c in pi] for row in cert['moves']])


def construction(n, m):
    assert n >= 1075 and 2*n <= m <= 3*n
    k = (n+5)//6
    r = 6*k-n
    holes = [3*j for j in range(r)]
    strip = SmoothStrip(SIGMA, VOLTAGE, 4,
                        [h+d*k for h in holes for d in (-1, 0, 1)])
    vertices = [(i, j) for i in range(k) for j in strip.types(i)]
    index = {v: i for i, v in enumerate(vertices)}
    base = {(index[v], index[(w[0] % k, w[1])])
            for v in vertices for w in strip.arcs(v)}
    assert len(vertices) == n and len(base) == 2*n
    ins, outs = [0]*n, [0]*n
    for u, v in base:
        assert u != v
        outs[u] += 1
        ins[v] += 1
    assert set(ins) == set(outs) == {2}
    optional = set()
    for i in range(k):
        if any(min((i-h) % k, (h-i) % k) <= 16 for h in holes):
            continue
        for j, d, t in EXTRAS:
            optional.add((index[(i, j)], index[((i+d) % k, t)]))
    assert len(optional) >= n and base.isdisjoint(optional)
    assert all(u != v for u, v in optional)
    edges = base | set(sorted(optional)[:m-2*n])
    assert len(edges) == m
    return dict(n=n, m=m, columns=k, holes=holes,
                vertices=vertices, arcs=sorted(edges), optional_count=len(optional))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--check', action='store_true')
    p.add_argument('--projection-only', action='store_true')
    p.add_argument('--out', type=Path, default=OUT)
    args = p.parse_args()
    start = time.monotonic()
    if args.projection_only:
        count = 0
        for holes in patterns():
            projection(build(holes), old_build([h for h in holes if -6 <= h <= 6]))
            count += 1
        print(json.dumps(dict(patterns=count, all_projections_valid=True,
                              seconds=time.monotonic()-start)))
        return
    if args.check:
        with gzip.open(args.out, 'rt') as f:
            data = json.load(f)
        assert data['source_certificate_sha256'] == hashlib.sha256(OLD.read_bytes()).hexdigest()
        required = {(h, t) for h in patterns() for t in [None, 0, 1, 2, 3, 4, 5]
                    if not (t == 4 and 0 in h)}
        assert {(tuple(r['holes']), r['target_type']) for r in data['records']} == required
        assert len(data['records']) == len(required)
        for r in data['records']:
            holes, t = r['holes'], r['target_type']
            a = build(holes)
            pi = projection(a, old_build([h for h in holes if -6 <= h <= 6]))
            assert pi == r['cop_projection']
            assert json.loads(json.dumps(a)) == r['arena']
            c = r['certificate']
            assert c['safe_transfer'] == (t is None)
            assert c['goal'] == [i for i, v in enumerate(a['messenger_vertices'])
                                 if v[0] == 0 and (t is None or v[1] == t)]
            assert verify(a, c, -1 if t is None else -2) == r['bounds']
        print(json.dumps(dict(saved_objectives=len(required), all_ranks_valid=True,
                              seconds=time.monotonic()-start)))
        return
    with gzip.open(OLD, 'rt') as f:
        old = json.load(f)
    lookup = {(tuple(r['holes']), r['target_type']): r for r in old['records']}
    records = []
    required_starts = 0
    for holes in patterns():
        cropped = tuple(h for h in holes if -6 <= h <= 6)
        a, b = build(holes), old_build(cropped)
        pi = projection(a, b)
        for t in [None, 0, 1, 2, 3, 4, 5]:
            if t == 4 and 0 in holes:
                continue
            previous = lookup[cropped, t]
            assert json.loads(json.dumps(b)) == previous['arena']
            cert = lift(previous['certificate'], pi)
            bounds = verify(a, cert, -1 if t is None else -2)
            required_starts += len(bounds) * (len(a['pursuer_vertices'])-1)
            records.append(dict(holes=holes, target_type=t, cop_projection=pi,
                                arena=a, certificate=cert, bounds=bounds))
    source_files = [Path(__file__), ROOT/'src/five_type_certificate.py',
                    ROOT/'src/sparse_composition_multi_certificate.py',
                    ROOT/'src/sparse_composition_smoothing.py',
                    ROOT/'src/sparse_composition_spacing.py',
                    ROOT/'src/six_type_budget_certificate.py']
    sources = {str(f.relative_to(ROOT)): hashlib.sha256(f.read_bytes()).hexdigest()
               for f in source_files}
    data = dict(minimum_hole_gap=3, maximum_holes=5, M=4, R=8,
                certificate_kind='winning strategy ranks; negative entries unclaimed',
                source_certificate=str(OLD.relative_to(ROOT)),
                source_certificate_sha256=hashlib.sha256(OLD.read_bytes()).hexdigest(),
                source_sha256=sources, records=records)
    with gzip.open(args.out, 'wt') as f:
        json.dump(data, f, separators=(',', ':'))
    witnesses = [construction(n, 3*n) for n in range(1075, 1081)]
    summary = dict(patterns=sum(1 for _ in patterns()), objectives=len(records),
                   required_starts=required_starts,
                   maximum_transfer=max(max(r['bounds']) for r in records if r['target_type'] is None),
                   maximum_delivery=max(max(r['bounds']) for r in records if r['target_type'] is not None),
                   artifact=str(args.out.relative_to(ROOT)),
                   artifact_sha256=hashlib.sha256(args.out.read_bytes()).hexdigest(),
                   source_sha256=sources,
                   source_certificate_sha256=data['source_certificate_sha256'],
                   construction_checks=[{k:w[k] for k in ('n','m','columns','holes','optional_count')}
                                        for w in witnesses],
                   seconds=time.monotonic()-start)
    (ROOT/'research/six-type-budget-multihole-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()

// Independent queue-attractor discovery screen for finite odd endpoints.
#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;
bool oddwin(const vector<vector<int>>&out,int low,int targetlow){
 int n=out.size(),sz=2*n*n;vector<vector<int>>in(n);for(int r=0;r<n;r++)for(int v:out[r])in[v].push_back(r);
 vector<unsigned char>win(sz),rem(sz);vector<int>q;q.reserve(sz);
 for(int t=0;t<n;t++)if(t!=targetlow){
  fill(win.begin(),win.end(),0);q.clear();for(int r=0;r<n;r++)for(int c=0;c<n;c++)rem[2*(r*n+c)+1]=out[c].size();
  for(int c=0;c<n;c++)for(int turn=0;turn<2;turn++){int z=2*(t*n+c)+turn;win[z]=1;q.push_back(z);}
  for(size_t h=0;h<q.size();h++){int z=q[h],turn=z%2,r=z/2/n,c=z/2%n;
   if(turn){for(int p:in[r]){int a=2*(p*n+c);if(p!=c&&!win[a]){win[a]=1;q.push_back(a);}}}
   else{for(int p:in[c]){int a=2*(r*n+p)+1;if(r!=p&&!win[a]&&--rem[a]==0){win[a]=1;q.push_back(a);}}}
  }
  for(int r=0;r<n;r++)if(r!=low)for(int c=0;c<n;c++)if(r!=c&&!win[2*(r*n+c)])return false;
 }
 return true;
}
int main(){int count;cin>>count;while(count--){int n,u,v;cin>>n>>u>>v;vector<vector<int>>out(n);for(int r=0;r<n;r++)out[r].push_back(r);for(int i=0;i<2*n-1;i++){int a,b;cin>>a>>b;out[a].push_back(b);}if(oddwin(out,u,v))cout<<n<<" ";}cout<<"\n";}

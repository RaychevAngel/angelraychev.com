#!/usr/bin/env python3
"""Translate frozen six-type certificates; Lean, not this exporter, proves them."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'research/sparse-composition-multi-certificates.json.gz'
EXPECTED = '53daceac01e67909c70c9a06d6390e0858950212d29d66bae70b70d15342fd65'


def seq(xs):
    return '[' + ','.join(map(str, xs)) + ']'


def arr(xs):
    return '#' + seq(xs)


def lookup_tree(values, low=0):
    """Balanced literal lookup avoids repeated linear kernel array access."""
    if len(values) == 1:
        value = values[0]
        return seq(value) if isinstance(value, list) else str(value)
    middle = len(values)//2
    return (f'(if r < {low+middle} then {lookup_tree(values[:middle],low)} '
            f'else {lookup_tree(values[middle:],low+middle)})')


def pack(rows, width):
    encoded = [sum(v << (width*j) for j, v in enumerate(row)) for row in rows]
    for row, value in zip(rows, encoded):
        assert [((value >> (width*j)) & ((1 << width)-1)) for j in range(len(row))] == row
    return encoded


def header(imports, namespace):
    return f'''{imports}
/- Literal translation of frozen six-type records. Source SHA256:
{EXPECTED}. The ordinary producer is untrusted; all obligations are
checked by Lean's kernel. Removed vertices are padded with empty regions. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{namespace}
open LocalArena LocalArenaRows SixTypeLocal
'''


def arena_text(index, p, record):
    a = record['arena']
    rm = [(u+4)*6+t for u, t in a['messenger_vertices']]
    cm = [78 if v is None else (v[0]+6)*6+v[1] for v in a['pursuer_vertices']]
    masks = [0]*54
    replies = [[] for _ in range(79)]
    for old, r in enumerate(rm):
        masks[r] = sum(1 << rm[z] for z in a['messenger_moves'][old])
    for old, c in enumerate(cm):
        replies[c] = [cm[z] for z in a['pursuer_moves'][old]]
    # Compare sets in Lean: the generic outside list has a different order.
    ns = f'SixTypePattern{index:02}'
    text = header('import SixTypeLocal', ns)
    text += f'''def pattern : List Nat := {seq(p)}
def messengerMasks (r : Nat) : Nat := {lookup_tree(masks)}
def replyRows (r : Nat) : List C := {lookup_tree(replies)}
def frozenReplies (c : C) : List C := replyRows c.val
def frozenArena : Arena R C where
  messenger r z := (messengerMasks r.val).testBit z.val = true
  pursuer c d := d ∈ frozenReplies c
  collision r c := ¬presentR pattern r ∨ rcop r=c
instance (r z : R) : Decidable (frozenArena.messenger r z) :=
  inferInstanceAs (Decidable (_ = true))
instance (c d : C) : Decidable (frozenArena.pursuer c d) :=
  inferInstanceAs (Decidable (_ ∈ _))
instance (r : R) (c : C) : Decidable (frozenArena.collision r c) :=
  inferInstanceAs (Decidable (_ ∨ _))
theorem messenger_agrees : ∀ r z, frozenArena.messenger r z ↔ (arena pattern).messenger r z := by
  decide +kernel
theorem pursuer_agrees : ∀ c d, frozenArena.pursuer c d ↔ (arena pattern).pursuer c d := by
  decide +kernel
theorem arena_eq : frozenArena = arena pattern := by
  have hm : frozenArena.messenger = (arena pattern).messenger :=
    funext fun r => funext fun z => propext (messenger_agrees r z)
  have hp : frozenArena.pursuer = (arena pattern).pursuer :=
    funext fun c => funext fun d => propext (pursuer_agrees c d)
  change Arena.mk frozenArena.messenger frozenArena.pursuer frozenArena.collision =
    Arena.mk (arena pattern).messenger (arena pattern).pursuer (arena pattern).collision
  rw [hm, hp]
  rfl
#print axioms arena_eq
end Delivery.{ns}
'''
    return text, rm, cm


def objective_text(index, record, rm, cm):
    c = record['certificate']
    ranks = [[0]*79 for _ in range(54)]
    moves = [[0]*79 for _ in range(54)]
    for oldr, r in enumerate(rm):
        for oldc, cop in enumerate(cm):
            ranks[r][cop] = max(0, c['ranks'][oldr][oldc]+1)
            move = c['moves'][oldr][oldc]
            moves[r][cop] = rm[move] if move >= 0 else 0
    rw = max(v for row in ranks for v in row).bit_length()
    mw = 6
    rankdata, movedata = pack(ranks, rw), pack(moves, mw)
    target = record['target_type']
    kind = 'Transfer' if target is None else f'Delivery{target}'
    ns = f'SixTypeObjective{index:02}{kind}'
    pn = f'SixTypePattern{index:02}'
    safe = target is None
    cond = 'SafeRowCondition' if safe else 'DeliveryRowCondition'
    checked = 'SafeChecked' if safe else 'DeliveryChecked'
    bridge = 'safe_checked' if safe else 'delivery_checked'
    goal = 'transferGoal pattern' if safe else f'deliveryGoal pattern {target}'
    text = header(f'import {pn}', ns)
    text += f'''open {pn}
def packedRanks (r : Nat) : Nat := {lookup_tree(rankdata)}
def packedMoves (r : Nat) : Nat := {lookup_tree(movedata)}
def rankCode (r : R) (c : C) : Nat := ((packedRanks r.val) >>> ({rw}*c.val)) &&& {(1<<rw)-1}
def data : Data R C where
  region r c := 0 < rankCode r c
  rank r c := rankCode r c-1
  move r c := ⟨(((packedMoves r.val) >>> ({mw}*c.val)) &&& 63) % 54, Nat.mod_lt _ (by decide)⟩
instance (r : R) (c : C) : Decidable (data.region r c) :=
  inferInstanceAs (Decidable (0 < _))
instance (r : R) (c : C) : Decidable ({cond} frozenArena ({goal}) data frozenReplies r c) :=
  inferInstanceAs (Decidable (_ → _))
theorem rows_checked : ∀ r c, {cond} frozenArena ({goal}) data frozenReplies r c := by
  decide +kernel
theorem checked : {checked} (arena pattern) ({goal}) data := by
  rw [←arena_eq]
  exact {bridge} frozenArena ({goal}) data frozenReplies (fun _ _ h => h) rows_checked
theorem initial_states : ∀ r c, presentR pattern r → rcol r={5 if safe else 4} →
    presentC pattern c → ¬(arena pattern).collision r c →
    data.region r c ∧ data.rank r c≤{9 if safe else 27} := by
  decide +kernel
#print axioms checked
#print axioms initial_states
end Delivery.{ns}
'''
    return ns, text


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--patterns', type=int, default=81)
    ap.add_argument('--out', type=Path, default=ROOT/'lean')
    args = ap.parse_args()
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED
    data = json.loads(gzip.decompress(SOURCE.read_bytes()))
    catalog = (ROOT/'lean/SparseCropCoverage.lean').read_text().split('def catalog : List (List Nat) := ', 1)[1].split('\n\nset_option', 1)[0]
    patterns = json.loads(catalog)
    lookup = {(tuple(r['holes']), r['target_type']): r for r in data['records']}
    args.out.mkdir(parents=True, exist_ok=True)
    names = []
    certificate_modules = []
    for index, p in enumerate(patterns[:args.patterns]):
        key = tuple(x-6 for x in p)
        record = lookup[key, None]
        atext, rm, cm = arena_text(index, p, record)
        (args.out/f'SixTypePattern{index:02}.lean').write_text(atext)
        objective_names = []
        for t in [None,0,1,2,3,4,5]:
            if t == 4 and 6 in p:
                continue
            rec = lookup[key, t]
            assert rec['arena'] == record['arena']
            name, text = objective_text(index, rec, rm, cm)
            (args.out/f'{name}.lean').write_text(text)
            objective_names.append(name)
        names += objective_names
        certname = f'SixTypeCertificate{index:02}'
        certificate_modules.append(certname)
        pn = f'SixTypePattern{index:02}'
        tn = f'SixTypeObjective{index:02}Transfer'
        ctext = header('\n'.join('import '+name for name in objective_names), certname)
        ctext += f'''theorem checked : Certificates {pn}.pattern := by
  constructor
  · exact ⟨{tn}.data, {tn}.checked, {tn}.initial_states⟩
  · intro t present
    rcases t with ⟨t,ht⟩
    have cases : t=0 ∨ t=1 ∨ t=2 ∨ t=3 ∨ t=4 ∨ t=5 := by omega
    rcases cases with h | h | h | h | h | h <;> subst t
'''
        for t in range(6):
            if t == 4 and 6 in p:
                ctext += f'    · simp [{pn}.pattern] at present\n'
            else:
                dn = f'SixTypeObjective{index:02}Delivery{t}'
                ctext += f'    · exact ⟨{dn}.data, {dn}.checked, {dn}.initial_states⟩\n'
        ctext += f'#print axioms checked\nend Delivery.{certname}\n'
        (args.out/f'{certname}.lean').write_text(ctext)
    if args.patterns == 81:
        combined = header('import SparseCropCoverage\n'+'\n'.join('import '+x for x in certificate_modules), 'SixTypeCertificates')
        combined += '''theorem certificates (p : List Nat) (member : p ∈ SparseCropCoverage.catalog) :
    SixTypeLocal.Certificates p := by
  simp only [SparseCropCoverage.catalog, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with ''' + ' | '.join('h' for _ in patterns) + '\n'
        for name in certificate_modules:
            combined += f'  · subst p; exact {name}.checked\n'
        combined += '#print axioms certificates\nend Delivery.SixTypeCertificates\n'
        (args.out/'SixTypeCertificates.lean').write_text(combined)
    print(json.dumps({'patterns':args.patterns,'objectives':len(names),'source_sha256':EXPECTED}))


if __name__ == '__main__':
    main()

"""Translate only frozen order-12 stages; Lean checks every game obligation."""
import hashlib
import json
from pathlib import Path
import struct
import zipfile

HERE = Path(__file__).resolve()
ROOT = HERE.parents[1] if HERE.parent.name == 'src' else HERE.parents[2]
import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, default=ROOT / 'lean')
parser.add_argument('--manifest', type=Path,
                    default=ROOT / 'research/lean-main-twelve-stage-manifest.json')
args = parser.parse_args()
OUT = args.output
OUT.mkdir(parents=True, exist_ok=True)
PINS = {
    'research/sparse-staged-records.json': '2dd3998101a1f5fbc2aeb3e05f0aecfd06545901bff9623ac7c6307286199f06',
    'research/sparse-staged-certificates.zip': 'e37ebadb62816223fbba35109886d02dd994e3d09f8fd83104ac3f7925d9d411',
}
for path, expected in PINS.items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected

def tree(values, low=0):
    if len(values) == 1:
        value = values[0]
        return '[' + ','.join(map(str, value)) + ']' if isinstance(value, list) else str(value)
    mid = len(values) // 2
    return f'(if x < {low+mid} then {tree(values[:mid],low)} else {tree(values[mid:],low+mid)})'

def packed_rows(values, width):
    return [sum(v << (width*c) for c,v in enumerate(values[r:r+12]))
            for r in range(0, len(values), 12)]

manifest = []
records = json.loads((ROOT / 'research/sparse-staged-records.json').read_text())['records']
with zipfile.ZipFile(ROOT / 'research/sparse-staged-certificates.zip') as bundle:
    for record in records:
        if record['n'] != 12:
            continue
        for stage in record['stages']:
            raw = bundle.read(stage['member'])
            assert hashlib.sha256(raw).hexdigest() == stage['sha256']
            values = struct.unpack('<' + 'h'*(len(raw)//2), raw)
            assert len(values) == 2*12**3
            ranks = [max(0, v) for v in values[:12**3]]
            moves = [max(0, v) for v in values[12**3:]]
            assert max(moves) < 12
            width = max(ranks).bit_length()
            rank_rows = packed_rows(ranks, width)
            move_rows = packed_rows(moves, 4)
            base = record['base_arcs'] + record['added'][:stage['prefix_start']]
            envelope = record['base_arcs'] + record['added'][:stage['prefix_end']]
            assert len(base) == len(set(map(tuple, base))) == stage['m_min']
            assert len(envelope) == len(set(map(tuple, envelope))) == stage['m_max']
            lower = [sum(1 << t for s,t in base if s == r) for r in range(12)]
            upper = [sum(1 << t for s,t in envelope if s == r) for r in range(12)]
            replies = [[d for d in range(12) if d == c or upper[c] & (1 << d)] for c in range(12)]
            index = len(manifest)
            name = f'MainTwelveStage{index:02}'
            lo, hi = stage['m_min'], stage['m_max']
            text = f'''import MainStageRows
/- Frozen literal {stage['member']}.
Source member SHA256: {stage['sha256']}.
Exporter correctness is not assumed: the kernel checks adjacency counts,
all initial states, every selected action, and every upper-envelope reply. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open FiniteGame Extremal MainStageRows
def lowerRows (x : Nat) : Nat := {tree(lower)}
def upperRows (x : Nat) : Nat := {tree(upper)}
def lower (s t : Fin 12) : Prop := (lowerRows s.val).testBit t.val=true
def upper (s t : Fin 12) : Prop := (upperRows s.val).testBit t.val=true
instance (s t : Fin 12) : Decidable (lower s t) := inferInstanceAs (Decidable (_=true))
instance (s t : Fin 12) : Decidable (upper s t) := inferInstanceAs (Decidable (_=true))
instance (s t : Fin 12) : Decidable (Legal upper s t) := inferInstanceAs (Decidable (_ ∨ _))
def rankRows (x : Nat) : Nat := {tree(rank_rows)}
def moveRows (x : Nat) : Nat := {tree(move_rows)}
def data : Data 12 where
  rank t r c := (rankRows (12*t.val+r.val) >>> ({width}*c.val)) &&& {2**width-1}
  move t r c := ⟨((moveRows (12*t.val+r.val) >>> (4*c.val)) &&& 15)%12,Nat.mod_lt _ (by decide)⟩
def replyRows (x : Nat) : List (Fin 12) := {tree(replies)}
def replies (c : Fin 12) : List (Fin 12) := replyRows c.val
theorem inclusion : RobustTwoMove.Subgraph lower upper := by
  unfold RobustTwoMove.Subgraph
  decide +kernel
theorem loopless : Loopless upper := by
  unfold Loopless
  decide +kernel
theorem reply_coverage : ∀ c d, Legal upper c d → d∈replies c := by decide +kernel
theorem checked : ∀ t r c, RowGood lower data replies t r c := by decide +kernel
theorem counts : arcCount lower={lo} ∧ arcCount upper={hi} := by
  constructor <;> rw [Extremal.arcCount_eq] <;> decide +kernel
theorem maximum {{m : Nat}} (low : {lo}≤m) (high : m≤{hi}) : IsMaximum 12 m (132-m) := by
  exact MainStageRows.maximum lower upper data replies inclusion loopless reply_coverage checked
    (counts.1 ▸ low) (counts.2 ▸ high)
#print axioms maximum
end Delivery.{name}
'''
            (OUT / f'{name}.lean').write_text(text)
            manifest.append(dict(module=name, member=stage['member'], sha256=stage['sha256'], low=lo, high=hi))
args.manifest.write_text(json.dumps(dict(inputs=PINS, stages=manifest), indent=2) + '\n')
print(f'Wrote {len(manifest)} frozen stages; no solver called.')

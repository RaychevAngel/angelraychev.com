"""Render the complete numerical classification and separate recipe audit."""
import json
from pathlib import Path

def render(root: Path):
 data=json.loads((root/'publication/classification-coverage.json').read_text())
 recipe=json.loads((root/'research/explicit-construction-coverage.json').read_text())
 assert data['canonical_representatives']['unresolved']==data['totals']['unresolved']==0
 assert recipe['numerical_canonical_gaps']==recipe['known_value_explicit_construction_gap_count']==0
 assert data['totals']['admissible']==data['totals']['exact']
 text=r'''# Complete values and explicit constructions {#the-remaining-classification-domain}

Every admissible pair $n\ge1$, $0\le m\le n(n-1)$ is determined, with an
explicit attaining graph. Corollary 47 gives the full formula for $n\ge12$;
the complete finite tables cover $1\le n\le11$. No numerical or
explicit-construction gap remains within the stated objective.

The numerical and construction obligations were checked separately. The
independent closure in `research/finish-ledger-review.json` preserves every
previous exact value and closes all 101 former representatives. All 493,924
admissible cells in the retained audit box through order 114 have matching
bounds. This finite check is supplemented by the ordinary parameterized
construction proofs and host reductions; it is not used to infer an infinite
theorem merely from finite success.

For budgets $m=12,13,\ldots,21$, the least attaining host orders are
$$7,8,8,8,8,10,9,11,10,12.$$
Adding isolates gives every larger host at each corresponding budget. The
remaining smaller-host values are explicitly tabulated. Above those budgets,
the established sparse, main, dense, and zero constructions cover the infinite
ranges. The exact 23-arrow value 83 first fits at order 12.

The separate construction audit finds a concrete adjacency rule, prescribed
composition, or certified listed graph for every value. It needs no generic
graph search or orientation derandomization to instantiate an attainer. Fixed
stages retain every-optional-subset guarantees inside their own envelopes;
other constructions retain their separately proved delivery bounds. Those
stronger properties are not inferred for unrelated graphs of the same score.

Finite upper proofs combine ordinary degree and source/sink arguments with
complete residual graph enumerations. Their reviews distinguish full
independent game replay from a second full graph enumeration and from sampled
pruning tests. The exact dependencies are in the evidence guide and approved
registry. The new concrete classification is not fully instantiated in Lean.

Delivery-time optimization, classification of all maximizing graphs, and a
structural characterization of all guaranteed pairs remain outside this paper's
scope. Further simplification and fuller formalization do not represent unknown
values or absent explicit attainers.
'''
 (root/'paper/classification-status.md').write_text(text)
 body='''<section id="coverage-ledger"><h3>Complete classification</h3>
<p><strong>Zero unresolved values.</strong> Every admissible pair has a proved exact maximum. The formula covers every order from twelve; the finite tables cover orders one through eleven.</p>
<p>The independent closure checked all 493,924 cells in the retained audit box, preserved every earlier exact value, and closed all 101 formerly unresolved representatives. Ordinary infinite-family proofs and support reductions supply the unbounded coverage.</p>
<p><a href="/cop-prisoner/proofs/#complete-tables-through-eleven-vertices">Complete finite tables</a> · <a href="/cop-prisoner/proofs/#the-combined-joint-maximum">General formula</a> · <a href="/cop-prisoner/paper/#evidence-guide">Proof and replay evidence</a></p></section>
<section id="explicit-constructions"><h3>Explicit constructions at every pair</h3>
<p><strong>Zero construction gaps.</strong> A separate source audit verifies concrete adjacency rules, prescribed composition, or certified listed finite graphs for every exact value. Parameters are determined from <i>(n,m)</i>; instantiation requires no fresh graph search or derandomization.</p>
<p>For budgets 12 through 21, the least attaining hosts are respectively 7, 8, 8, 8, 8, 10, 9, 11, 10 and 12. Add isolates for larger hosts. Fixed finite tables handle smaller hosts; sparse, circle, stage, hub, code, and dense-block recipes cover the infinite ranges.</p>
<p>Optional-subset and delivery-time guarantees remain attached to their own proved families. The finite computational proofs have independent reviews; <a href="/cop-prisoner/lean/">Lean coverage remains partial</a>.</p></section>'''
 return body,dict(representatives=0,small_budget=0,main=0,dense=0)

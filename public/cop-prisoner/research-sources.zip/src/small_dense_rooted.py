#!/usr/bin/env python3
"""Safe-root interfaces and literal dense constructions; no graph search.

The root is an immediate recipient only when it is the actual target.
For another target, entering the root must survive the cop's reply.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from game_solver import solve_graph

ROOT = Path(__file__).resolve().parents[1]
CORE9 = ((1,3),(4,7),(5,6),(0,2),(6,8),(2,8),(0,4),(1,5),(3,7))


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length()-1
        mask -= bit


def rooted_game(rows):
    """Return all abstract winning masks, with the corrected root capture.

    Core vertices are 0..k-1; root=k. Nonterminal cop positions stay in
    the core. A cop can nevertheless capture an unsafe arrival at root.
    Every other cop departure is harmless under the functional gadget.
    Winning at a safely reached root means one direct move remains when
    the recipient is in the core. No delivery-time claim uses these layers.
    """
    k = len(rows)
    root = k
    all_core, all_vertices = (1 << k)-1, (1 << (k+1))-1
    missing = [sum(1 << t for t in row) for row in rows]
    assert all(len(set(row)) == len(row) and s not in row and
               all(0 <= t <= k for t in row) for s,row in enumerate(rows))
    messenger = [all_vertices ^ mask for mask in missing] + [all_vertices]
    cop = [all_core & ~mask for mask in missing]  # includes waiting
    safe_root = sum(1 << c for c in range(k) if root in rows[c])
    recipients = []
    layers = []
    for target in range(k+1):
        wins = [0]*(k+1)
        wins[target] = all_core
        wins[root] = all_core
        depth = 0
        while True:
            safe = [sum(1 << c for c in range(k)
                        if cop[c] & ~wins[v] == 0)
                    for v in range(k+1)]
            safe[target] = all_core
            safe[root] = all_core if target == root else safe_root
            updated = [all_core]*(k+1)
            for s in range(k):
                if s == target:
                    continue
                updated[s] = 0
                for v in bits(messenger[s]):
                    updated[s] |= safe[v]
                updated[s] &= all_core ^ (1 << s)
            if updated == wins:
                break
            assert all(a & ~b == 0 for a,b in zip(wins,updated))
            wins = updated
            depth += 1
        recipients.append(wins)
        layers.append(depth)
    counted = [(s,t) for s,row in enumerate(rows) for t in row
               if recipients[t][s] == all_core ^ (1 << s)]
    return {'k':k, 'missing_rows':[list(row) for row in rows],
            'I_core':len(counted), 'missing_core':sum(map(len,rows)),
            'all_core_pairs':len(counted) == sum(map(len,rows)),
            'winning_cop_masks_by_target':recipients,
            'abstract_layers':layers}


def designate_root(rows, root):
    """Relabel a selected old vertex last; forget only its missing row."""
    old_core = [v for v in range(len(rows)) if v != root]
    order = old_core + [root]
    relabel = {v:i for i,v in enumerate(order)}
    return [sorted(relabel[t] for t in rows[s]) for s in old_core]


def attach(rows, r):
    """Complement of the three-/four-vertex functional root gadget."""
    k = len(rows)
    assert r in (3,4) and all(len(row) >= 2 for row in rows)
    n = k+r
    missing = {(s,t) for s,row in enumerate(rows) for t in row}
    if r == 3:
        missing |= {(k,k+1),(k+1,k+2),(k+2,k+1)}
    else:
        missing |= {(k,k+1),(k+1,k+2),(k+2,k+3),(k+3,k+2)}
    arcs = [(s,t) for s in range(n) for t in range(n)
            if s != t and (s,t) not in missing]
    return n, arcs


def verify(rows, r, certificates=True):
    interface = rooted_game(rows)
    n, arcs = attach(rows,r)
    game = solve_graph(n,arcs,crosscheck=True,certificates=certificates)
    k, mask = len(rows), (1 << len(rows))-1
    for t in range(k+1):
        for s in range(k):
            assert (game['winning_pursuer_masks_by_target'][t][s] & mask
                    == interface['winning_cop_masks_by_target'][t][s]), (s,t)
    assert game['I'] == interface['I_core'] + (r == 4)
    return interface, game


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='replay frozen files')
    args = parser.parse_args()
    # A root reachable by every cop cannot rescue an indirect core pair.
    danger = rooted_game([(1,2),(0,2),(0,1)])
    assert danger['I_core'] == 0
    # Delivery to the actual root still takes priority over capture.
    assert danger['winning_cop_masks_by_target'][3][:3] == [6,5,3]
    rows = designate_root(CORE9,8)
    results = []
    for r in (3,4):
        interface, game = verify(rows,r)
        assert interface['all_core_pairs']
        assert game['I'] == 2*len(rows)+(r == 4)
        results.append(game)
    payload = {'schema_version':1, 'interface':interface, 'graphs':results}
    certpath = ROOT/'research/small-dense-rooted-certificates.json'
    encoded = json.dumps(payload,separators=(',',':'))+'\n'
    if args.check:
        assert certpath.read_text() == encoded
    else:
        certpath.write_text(encoded)
    report = {'status':'verified', 'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'semantics':'Core target: entering root wins only after safe arrival; actual root target: receipt precedes collision.',
              'proof_boundary':'Ordinary root-designation and functional-gadget proofs use the previously certified nine-core. Concrete full graphs additionally pass two solvers and all winning/losing rank obligations. No Lean claim.',
              'source_core':{'n':9,'designated_root':8,'missing_rows':CORE9},
              'core_rows':rows, 'graphs':[{key:g[key] for key in ('n','m','I','max_state_delivery_moves')} for g in results],
              'certificates':str(certpath.relative_to(ROOT)),
              'certificate_sha256':hashlib.sha256(encoded.encode()).hexdigest(),
              'alternating_states':sum(2*g['n']**3 for g in results)}
    out = ROOT/'research/small-dense-rooted-checks.json'
    text = json.dumps(report,indent=2)+'\n'
    if args.check:
        assert out.read_text() == text
    else:
        out.write_text(text)
    print(json.dumps(report['graphs']))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Emit certificate data for the proved Boolean tree checker.

This is an untrusted serializer of the already-generated trace, not an
additional search or a proof assumption. Its output is checked by Lean.
"""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--partition', default='9')
    parser.add_argument('--split-depth', type=int, default=3)
    args = parser.parse_args()
    scratch = ROOT / 'tmp/lean-oct23/finite'
    record = json.loads((scratch / f'family-{args.partition}.json').read_text())
    nodes = {tuple(x['prefix']): x for x in record['tree']}
    a = record['primary']
    def valid(prefix):
        return len(set(prefix)) == len(prefix) and all(v != i and v != a[i] for i,v in enumerate(prefix))
    def emit(prefix):
        node = nodes.get(tuple(prefix))
        if node is None:
            if not valid(prefix):
                return '.invalid'
            if len(prefix) == 9:
                raise ValueError('Missing complete valid leaf: '+repr(prefix))
            node = {'kind':'branch'}
        kind = node['kind']
        if kind == 'source':
            return '(.source ' + ' '.join(map(str,node['witness'])) + ')'
        if kind == 'predecessor':
            return '(.predecessor ' + ' '.join(map(str,node['witness'])) + ')'
        if kind == 'losing':
            return '(.losing ' + ' '.join(map(str,node['witness'])) + ' ' + str(node['mask']) + ')'
        if kind != 'branch':
            raise ValueError(kind)
        return '(.branch fun v => match v.val with\n' + ''.join(
            '  | ' + str(v) + ' => ' + emit(prefix+[v]) + '\n'
            for v in range(9) if valid(prefix+[v])
        ) + '  | _ => .invalid)'
    # Trace files list the pruning leaves, while branch prefixes are inferred
    # from their ancestor chains. Completeness itself is checked by Lean.
    for prefix in list(nodes):
        for depth in range(len(prefix)):
            nodes.setdefault(prefix[:depth], {'kind':'branch'})
    source = 'import FiniteTreeKernel\n\nset_option maxRecDepth 65536\nset_option maxHeartbeats 200000000\n\n'
    source += 'namespace Delivery.FiniteExclusion.ReflectedBenchmark\nopen TreeKernel\n\n'
    source += 'def a (x : Fin 9) : Fin 9 := match x.val with\n'
    source += ''.join(f'  | {i} => {v}\n' for i,v in enumerate(a)) + '  | _ => 0\n\n'
    def pl(prefix):
        return '['+','.join(map(str,prefix))+']'
    pieces = []
    def prove(prefix):
        name = 'piece_' + ('root' if not prefix else '_'.join(map(str,prefix)))
        node = nodes.get(tuple(prefix), {'kind':'branch'})
        if not valid(prefix):
            return f'(invalid_excluded a {pl(prefix)} (by decide +kernel))'
        if len(prefix) >= args.split_depth or node['kind'] != 'branch':
            pieces.append(f'def {name}_data : Tree :=\n'+emit(prefix)+'\n\n')
            pieces.append(f'theorem {name} : Excluded a {pl(prefix)} :=\n'
                f'  sound a {pl(prefix)} {name}_data (by decide +kernel)\n\n')
        else:
            children = [prove(prefix+[v]) for v in range(9)]
            pieces.append(f'theorem {name} : Excluded a {pl(prefix)} :=\n'
                f'  branch_excluded a {pl(prefix)} (by decide) (fin9_cases _\n    '
                +'\n    '.join(children)+')\n\n')
        return name
    top = prove([])
    source += ''.join(pieces)
    source += 'theorem blocked (b : Assignment 9) (valid : Valid a b) : Blocked a b :=\n'
    source += f'  {top} b valid (by intro i h; simp at h)\n\n'
    source += '#print axioms blocked\nend Delivery.FiniteExclusion.ReflectedBenchmark\n'
    destination = scratch / f'FiniteTreeNine{args.partition}Depth{args.split_depth}.lean'
    destination.write_text(source)
    print(json.dumps({'source':str(destination),'bytes':len(source),'nodes':len(nodes)}))

if __name__ == '__main__':
    main()

// Exhaustive labeled loopless digraph enumeration. One process, no threads.
// Bitmask arc index is lexicographic (u,v), skipping u==v.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>

int main(int argc, char **argv) {
  int n = argc > 1 ? std::atoi(argv[1]) : 5;
  if (n < 1 || n > 5) return 2;
  int E = n*(n-1), all=(1<<n)-1;
  uint64_t total=uint64_t(1)<<E;
  std::vector<std::vector<uint64_t>> distribution(E+1,std::vector<uint64_t>(n*n+1));
  std::vector<int> maximum(E+1,-1);
  std::vector<uint64_t> witness(E+1);
  auto start=std::chrono::steady_clock::now();
  for (uint64_t graph=0;graph<total;++graph) {
    int out[5], win[5], safe[5], next[5], pos=0, m=__builtin_popcountll(graph), I=0;
    for (int u=0;u<n;++u) {
      out[u]=1<<u;
      for (int v=0;v<n;++v) if (u!=v) out[u]|=((graph>>(pos++))&1)<<v;
    }
    for (int t=0;t<n;++t) {
      std::fill(win,win+n,0); win[t]=all;
      bool changed=true;
      while (changed) {
        for (int v=0;v<n;++v) {
          safe[v]=0;
          if (v==t) safe[v]=all;
          else for (int c=0;c<n;++c) if ((out[c]&~win[v])==0) safe[v]|=1<<c;
        }
        changed=false;
        for (int r=0;r<n;++r) {
          int w=0;
          if (r==t) w=all;
          else {
            int options=out[r];
            while (options) {int v=__builtin_ctz(options);options&=options-1;w|=safe[v];}
            w&=all^(1<<r);
          }
          next[r]=w; changed|=w!=win[r];
        }
        std::copy(next,next+n,win);
      }
      for (int s=0;s<n;++s)
        if (s!=t && !(out[s]&(1<<t)) && (win[s]|(1<<s))==all) ++I;
    }
    ++distribution[m][I];
    if (I>maximum[m]) { maximum[m]=I;witness[m]=graph; }
  }
  double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  std::cout<<"{\"n\":"<<n<<",\"graphs\":"<<total<<",\"seconds\":"<<seconds<<",\"by_m\":[";
  for (int m=0;m<=E;++m) {
    if(m)std::cout<<",";
    std::cout<<"{\"m\":"<<m<<",\"maximum_I\":"<<maximum[m]<<",\"witness_mask\":"<<witness[m]<<",\"distribution\":{";
    bool first=true;
    for(int i=0;i<=n*n;++i) if(distribution[m][i]) {
      if(!first)std::cout<<",";first=false;
      std::cout<<"\""<<i<<"\":"<<distribution[m][i];
    }
    std::cout<<"}}";
  }
  std::cout<<"]}\n";
}

#!/usr/bin/env python3
"""General additive offset criterion and bounded residue-class verification."""
from dense_unified_core import even_core,robust_check
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def additive(k,vals,p):
    return all((a-b)%k not in (p,k-p) for a in vals for b in vals) and all(
        (a+b-c)%k not in (p,k-p) for a in vals for b in vals for c in vals)

def conditions(k,d,e):
    fd={x%k for x in (0,1,-1,2,-2,3,-3,4,-4,5,7)}
    fe={x%k for x in (0,1,-1,2,-2,3,-3,7,8)}
    return k>=5 and not(fd&d or fe&e) and additive(k,d,2) and additive(k,e,1)

def offsets(k):
    def choose(p,forbidden):
        allowed=[a for a in range(5) if a not in {p%5,(-p)%5,(k+p)%5,(k-p)%5}]
        choices=[{v for v in range(1,k) if v%5==a and v not in forbidden} for a in allowed]
        return max(choices,key=lambda s:(len(s),tuple(sorted(s))))
    d=choose(2,{x%k for x in (0,1,-1,2,-2,3,-3,4,-4,5,7)})
    e=choose(1,{x%k for x in (0,1,-1,2,-2,3,-3,7,8)})
    assert conditions(k,d,e),(k,d,e)
    return d,e

def even_envelope(k):
    d,e=offsets(k);b=even_core(k)
    o={(i,(i+x)%k) for i in range(k) for x in d}
    o|={(k+i,k+(i+x)%k) for i in range(k) for x in e}
    return b,o

def odd_envelope(n):
    assert n>=45 and n%2
    # A fixed22-vertex block preserves the established small robust envelope.
    k1=11;k2=(n-23)//2
    from dense_unified_core import envelope
    b1,o1=envelope(22);b2,o2=even_envelope(k2)
    b=b1|{(s+22,t+22) for s,t in b2}
    o=o1|{(s+22,t+22) for s,t in o2}
    w=n-1
    for p,l in ((0,11),(22,22+k2)):
        b.remove((p,l));b.update(((p,w),(w,l)))
    o.add((w,2))
    return b,o

def main():
    rows=[]
    for k in range(5,101):
        b,o=even_envelope(k);robust_check(2*k,b,o)
        d,e=offsets(k)
        rows.append({'n':2*k,'h':len(b|o),'D':sorted(d),'E':sorted(e)})
    odd=[]
    for n in range(45,202,2):
        b,o=odd_envelope(n);robust_check(n,b,o)
        odd.append({'n':n,'h':len(b|o)})
    (ROOT/'research/dense-phase2-modular-offsets.json').write_text(json.dumps({'even':rows,'odd':odd},indent=2)+'\n')
    print('verified',len(rows),'even and',len(odd),'odd envelopes')
    for parity,items in [('even',rows),('odd',odd)]:
        wins=[x for x in items if x['h']>=x['n']*max(3,(x['n']+11)//13)]
        losses=[x for x in items if x['h']<x['n']*max(3,(x['n']+11)//13)]
        print(parity,'last old-bound miss',losses[-1] if losses else None,'first beat',wins[0] if wins else None)

if __name__=='__main__':main()

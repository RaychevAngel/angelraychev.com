#!/usr/bin/env python3
"""Bounded deletion/repair witnesses at the seven/eight-vertex dense endpoint."""
from __future__ import annotations
import itertools
import json
import time
from pathlib import Path
from game_solver import solve_graph
from small_dense_rooted import CORE9

ROOT = Path(__file__).resolve().parents[1]


def deletions(rows):
    for deleted in range(len(rows)):
        order = [v for v in range(len(rows)) if v != deleted]
        index = {v:i for i,v in enumerate(order)}
        partial = [sorted(index[t] for t in rows[s] if t != deleted) for s in order]
        holes = [s for s,row in enumerate(partial) if len(row)==1]
        options = [[t for t in range(len(order)) if t!=s and t not in partial[s]] for s in holes]
        for filling in itertools.product(*options):
            result = [row[:] for row in partial]
            for s,t in zip(holes,filling):result[s]=sorted(result[s]+[t])
            yield result


def main():
    started = time.monotonic();seeds=[CORE9];levels=[];certificates=[]
    for n in (8,7):
        seen=set();best=-1;best_rows=[];best_game=None
        for seed in seeds:
            for rows in deletions(seed):
                key=tuple(map(tuple,rows))
                if key in seen:continue
                seen.add(key)
                arcs=[(s,t)for s in range(n)for t in range(n)if s!=t and t not in rows[s]]
                game=solve_graph(n,arcs)
                if game['I']>best:best=game['I'];best_rows=[rows];best_game=game
                elif game['I']==best and len(best_rows)<12:best_rows.append(rows)
        assert best_game is not None
        checked=solve_graph(n,best_game['arcs'],crosscheck=True,certificates=True)
        certificates.append(checked)
        levels.append({'n':n,'tested':len(seen),'best_I':best,'best_missing_rows':best_rows})
        print(json.dumps({k:levels[-1][k]for k in ('n','tested','best_I')}),flush=True)
        seeds=best_rows
    report={'scope':'All one-row repairs after vertex deletion from the listed seeds only; failures are not upper bounds.',
            'elapsed_seconds':time.monotonic()-started,'levels':levels}
    (ROOT/'research/small-dense-endpoint-deletion-pilot.json').write_text(json.dumps(report,indent=2)+'\n')
    (ROOT/'research/small-dense-endpoint-certificates.json').write_text(json.dumps(certificates,separators=(',',':'))+'\n')


if __name__ == '__main__':main()

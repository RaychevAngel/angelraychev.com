#!/usr/bin/env python3
"""Screen robust additional cop arcs on the six-type smoothing family.

This is a finite local screen. Uniform conclusions require the explicit
projection with suitably separated holes, as in the associated proof.
"""
import argparse,json,time
from pathlib import Path
from sparse_composition_certificate import SIGMA,VOLTAGE
from sparse_composition_smoothing import SmoothStrip
from five_type_certificate import arena,solve,verify

def extra_arena(extras,hole=None,M=4,R=8):
    strip=SmoothStrip(SIGMA,VOLTAGE,4,[]if hole is None else[hole])
    a=arena(strip,messenger_radius=M,pursuer_radius=R)
    cv=a['pursuer_vertices'];index={v:i for i,v in enumerate(cv)};omega=index[None]
    for c,v in enumerate(cv):
        if v is None:continue
        for j,d,t in extras:
            u=(v[0]+d,t)
            if v[1]==j and not strip.gone(u):
                a['pursuer_moves'][c]=sorted(set(a['pursuer_moves'][c]+[index.get(u,omega)]))
    jump=max([2]+[abs(d) for j,d,t in extras])
    a['pursuer_moves'][omega]=[c for c,v in enumerate(cv)if v is None or abs(v[0])>=R-jump+1]
    a['pursuer_extra_arc_types']=extras
    return a

def test(extras,hole=None,M=4,R=8,retain=False):
    a=extra_arena(extras,hole,M,R);rows=[]
    for t in [None]+[j for j in range(6)if not(hole==0 and j==4)]:
        goals=[v for v in a['messenger_vertices']if v[0]==0 and(t is None or v[1]==t)]
        cert=solve(a,goals,t is None)
        try:bounds=verify(a,cert,-1 if t is None else-2)
        except AssertionError:return None
        row={'target':t,'bounds':bounds}
        if retain:row['certificate']=cert
        rows.append(row)
    return {'arena':a,'records':rows}if retain else[max(r['bounds'])for r in rows]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--radius',type=int,default=8)
    ap.add_argument('--out',type=Path,default=Path('research/six-type-individual-augmentation-screen.json'))
    args=ap.parse_args();start=time.monotonic();rows=[];base=SmoothStrip(SIGMA,VOLTAGE)
    for j in range(6):
        for d in range(-3,4):
            for t in range(6):
                if (d,t)==(0,j) or (d,t)in base.arcs((0,j)):continue
                e=(j,d,t);bounds=test([e],R=args.radius)
                if bounds is not None:
                    row={'extra':e,'bounds':bounds};rows.append(row);print(row,flush=True)
    args.out.write_text(json.dumps({'M':4,'R':args.radius,'base_only':True,'passed':rows,'seconds':time.monotonic()-start},indent=2)+'\n')
    print('passed',len(rows),'seconds',time.monotonic()-start,flush=True)

if __name__=='__main__':main()

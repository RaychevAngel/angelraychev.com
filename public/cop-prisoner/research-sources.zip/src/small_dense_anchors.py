#!/usr/bin/env python3
"""Two literal near-endpoint cores and their missing-two-cycle joins."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

from game_solver import solve_graph
from small_dense_rooted import CORE9

ROOT = Path(__file__).resolve().parents[1]


def missing_core(n):
    if n == 9:
        return {(s,t) for s,row in enumerate(CORE9) for t in row} | {(2,4)}
    if n == 10:
        return {(s,t) for i in range(5) for s,t in
                ((i,5+i),(i,5+(i-1)%5),(5+i,(i+4)%5),(5+i,(i+6)%5))} | {(0,1)}
    raise ValueError('only the two fixed cores are supplied')


def construct(n, m):
    choices = {(9,53):(9,False),(10,69):(10,False),
               (11,89):(9,True),(12,109):(10,True)}
    k, join = choices[n,m]
    missing = missing_core(k)
    if join:
        missing |= {(k,k+1),(k+1,k)}
    arcs = [(s,t) for s in range(n) for t in range(n)
            if s != t and (s,t) not in missing]
    assert len(arcs) == m
    return arcs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    results = []
    for n,m,value in [(9,53,19),(10,69,21),(11,89,19),(12,109,21)]:
        r = solve_graph(n,construct(n,m),crosscheck=True,certificates=True)
        assert r['I'] == value
        results.append(r)
    certpath = ROOT/'research/small-dense-anchor-certificates.json'
    encoded = json.dumps(results,separators=(',',':'))+'\n'
    if args.check:
        assert certpath.read_text() == encoded
    else:
        certpath.write_text(encoded)
    report = {'status':'verified','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'rooted_source_sha256':hashlib.sha256((ROOT/'src/small_dense_rooted.py').read_bytes()).hexdigest(),
              'proof_boundary':'The literal near-endpoint cores have finite full-game proofs. Their missing-two-cycle joins also follow from the existing arbitrary-duration missing-block addition lemma. No Lean claim.',
              'graphs':[{key:r[key] for key in ('n','m','I','max_state_delivery_moves')} for r in results],
              'certificates':str(certpath.relative_to(ROOT)),
              'certificate_sha256':hashlib.sha256(encoded.encode()).hexdigest(),
              'alternating_states':sum(2*r['n']**3 for r in results)}
    out = ROOT/'research/small-dense-anchor-checks.json'
    text = json.dumps(report,indent=2)+'\n'
    if args.check:
        assert out.read_text() == text
    else:
        out.write_text(text)
    print(json.dumps(report['graphs']))


if __name__ == '__main__':
    main()

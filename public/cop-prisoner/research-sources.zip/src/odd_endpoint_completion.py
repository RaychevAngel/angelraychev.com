#!/usr/bin/env python3
"""Independently certify that odd extremality need not survive completion.

The fixed example is explicit; its discovery search is not part of the proof.
Both actual-game solvers and every winning/losing rank condition are checked.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from game_solver import neighborhoods, solve_graph, verify_certificate

ARCS = [(0,5),(0,12),(1,15),(1,10),(2,7),(2,0),(3,1),(3,18),
        (4,15),(5,11),(5,9),(6,8),(6,13),(7,13),(7,17),(8,10),
        (8,16),(9,3),(9,14),(10,2),(10,17),(11,1),(11,6),(12,3),
        (12,8),(13,4),(13,5),(14,4),(14,12),(15,0),(15,16),
        (16,7),(16,9),(17,14),(17,11),(18,2),(18,6)]
N, U, V = 19, 4, 18


def main():
    assert len(ARCS) == 2*N-1 and len(set(ARCS)) == len(ARCS)
    assert (U,V) not in ARCS
    assert [sum(s==x for s,t in ARCS) for x in range(N)] == [1 if x==U else 2 for x in range(N)]
    assert [sum(t==x for s,t in ARCS) for x in range(N)] == [1 if x==V else 2 for x in range(N)]
    results = []
    for name, arcs, count in [('odd',ARCS,(N-2)*(N-3)),
                              ('completion',ARCS+[(U,V)],276)]:
        result=solve_graph(N,arcs,certificates=True,crosscheck=True)
        out,_=neighborhoods(N,arcs)
        for cert in result['certificates']:
            assert verify_certificate(N,out,cert)
        assert result['I']==count
        result['name']=name
        result['verified_by_both_solvers_and_transition_checks']=True
        results.append(result)
    assert all(results[0]['W'][s][t] for s in range(N) for t in range(N)
               if s!=U and t!=V)
    assert not results[1]['W'][1][0]
    receipt={'status':'verified','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'n':N,'low_outdegree_vertex':U,'low_indegree_vertex':V,
             'odd_I':results[0]['I'],'completed_I':results[1]['I'],
             'universal_two_regular_I':N*(N-3),'results':results,
             'proof_boundary':'Computer-assisted finite theorem; current certificate semantics have an ordinary verified implementation and separate general Lean interface, but this graph is not embedded in Lean.'}
    path=Path(__file__).resolve().parents[1]/'research/odd-endpoint-completion-certificate.json'
    path.write_text(json.dumps(receipt,separators=(',',':'))+'\n')
    print(json.dumps({k:receipt[k] for k in ['status','n','odd_I','completed_I','universal_two_regular_I']}))


if __name__=='__main__':main()

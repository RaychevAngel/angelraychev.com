#!/usr/bin/env python3
"""Bounded adversarial checks of quantitative support inequalities."""
from pathlib import Path
import hashlib,json,random
from game_solver import solve_graph


def inspect(n,arcs):
    arcs=set(map(tuple,arcs));m=len(arcs)
    out=[set() for _ in range(n)];inc=[set() for _ in range(n)]
    for s,t in arcs:out[s].add(t);inc[t].add(s)
    result=solve_graph(n,arcs,crosscheck=True)
    pairs=result['indirect_pairs'];I=len(pairs)
    A={v for v in range(n) if len(out[v])>=2}
    B={v for v in range(n) if len(inc[v])>=2}
    q,r,b=len(A),len(B),len(A&B)
    a,d=m-2*q,m-2*r
    rows={s for s,t in pairs};cols={t for s,t in pairs}
    assert len(rows)<=min(q,b+2*a+d//2)
    assert len(cols)<=min(r,b+a//2+2*d)
    support=sum(bool(out[v] or inc[v]) for v in range(n))
    external=sum(s not in A&B or t not in A&B for s,t in arcs)
    # Squared forms of the three real inequalities, without floating point.
    assert 144*I <= (2*b+5*m)**2
    assert 9*m-2*support>=0 and 256*I <= (9*m-2*support)**2
    assert 12*m-external>=0 and 576*I <= (12*m-external)**2
    return I


def main():
    root=Path(__file__).resolve().parents[1]
    rng=random.Random(552062)
    tested=positive=0
    for n in range(2,12):
        universe=[(s,t) for s in range(n) for t in range(n) if s!=t]
        for _ in range(15):
            budget=rng.randrange(len(universe)+1)
            I=inspect(n,rng.sample(universe,budget))
            tested+=1;positive+=I>0
    old=json.loads((root/'research/solver-enumeration-n6.json').read_text())
    for row in old['by_m']:
        I=inspect(6,row['witness_arcs'])
        assert I==row['maximum_I']
        tested+=1;positive+=I>0
    receipt={'verified':True,'graphs':tested,'positive_count_graphs':positive,
             'both_original_game_solvers':True,
             'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'solver_sha256':hashlib.sha256((root/'src/game_solver.py').read_bytes()).hexdigest(),
             'scope':'Bounded graph sanity checks only. The unbounded quantitative '
                     'support theorem depends on its ordinary degree and camping proof.'}
    (root/'research/routing-defect-phase2-support-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))


if __name__=='__main__':main()

#!/usr/bin/env python3
"""Separated hub pairs and the ordinary main-interval overlap from order 79.

Construction only: exact integer parameter rules and ordered optional prefixes.
The independent checker is main_interval_pair_codes_check.py. Older code
families and their saved certificates are intentionally unchanged.
"""
from itertools import combinations, islice
from math import gcd, isqrt
import argparse
import json


def capacity(k):
    if k < 6:
        raise ValueError('Pair codes require k>=6.')
    return k*(k-5)


def core_size(n):
    if n < 12:
        raise ValueError('The pair construction requires n>=12.')
    k = max(6, (3+isqrt(9+4*n))//2)
    if k*(k-3) < n:
        k += 1
    assert 2*k <= n <= k*(k-3)
    assert k == 6 or (k-1)*(k-4) < n
    return k


def codes(k, q):
    if not 0 <= q <= capacity(k):
        raise ValueError('Too many pair codes.')
    candidates = ((part*k+i, part*k+j) for part in range(2)
                  for i, j in combinations(range(k), 2)
                  if j-i not in {1, 2, k-1, k-2})
    result = list(islice(candidates, q))
    assert len(result) == q
    return result


def validate_codes(k, code_sets):
    """The extended Theorem 59 hypotheses, including all previous codes."""
    if k < 5:
        raise ValueError('The hub core requires k>=5.')
    sets = [frozenset(s) for s in code_sets]
    for s in sets:
        if len(s) < 2 or not all(0 <= v < 2*k for v in s):
            raise ValueError('Invalid hub code.')
        point = all(v < k for v in s)
        if not point and not all(v >= k for v in s):
            raise ValueError('A code must lie in one hub part.')
        indices = {v % k for v in s}
        gap = 2 if point else 1
        if any((v+gap) % k in indices for v in indices):
            raise ValueError('A code contains a forbidden missing hub row.')
        if len(s) == 2:
            a, b = sorted(indices)
            if b-a in {1, 2, k-1, k-2}:
                raise ValueError('Pair codes must avoid distances one and two.')
    if any(a <= b for i, a in enumerate(sets)
           for j, b in enumerate(sets) if i != j):
        raise ValueError('The hub codes must form an antichain.')
    return sets


def from_codes(k, code_sets, added=0):
    K = validate_codes(k, code_sets)
    q = len(K)
    n = 2*k+q
    if not 0 <= added <= q*(q-1):
        raise ValueError('Optional arrow count is outside the envelope.')
    missing = {(i, k+i) for i in range(k)}
    missing |= {(i, k+(i-1) % k) for i in range(k)}
    missing |= {(k+i, (i+d) % k) for i in range(k) for d in (4, 6)}
    arcs = {(s, t) for s in range(2*k) for t in range(2*k)
            if s != t and (s, t) not in missing}
    arcs |= {(s, t) for s in range(2*k) for t in range(2*k, n)}
    arcs |= {(2*k+j, t) for j, code in enumerate(K)
             for t in range(2*k) if t not in code}
    base = 2*k*(2*k-3)+4*k*q-sum(map(len, K))
    assert len(arcs) == base
    optional = ((s, t) for s in range(2*k, n)
                for t in range(2*k, n) if s != t)
    arcs.update(islice(optional, added))
    assert len(arcs) == base+added
    return dict(n=n, k=k, q=q, K=[sorted(s) for s in K],
                m=base+added, m_min=base, m_max=base+q*(q-1),
                maximum_delivery_moves=2, arcs=sorted(arcs))


def interval(n, k=None):
    k = core_size(n) if k is None else k
    q = n-2*k
    if k < 6 or not 0 <= q <= capacity(k):
        raise ValueError('The pair core does not fit this order.')
    return (4*k-2)*n-2*k*(2*k+1), n*(n-3)


def pair_construct(n, m, k=None):
    k = core_size(n) if k is None else k
    low, high = interval(n, k)
    if not low <= m <= high:
        raise ValueError('Budget outside the pair-code interval.')
    result = from_codes(k, codes(k, n-2*k), m-low)
    assert (result['m_min'], result['m_max']) == (low, high)
    return dict(n=n, m=m, I=n*(n-1)-m, branch='pair_codes',
                parameters=dict(k=k, q=n-2*k, maximum_delivery_moves=2),
                arcs=result['arcs'])


def parameters(n):
    if n < 79:
        raise ValueError('The ordinary overlap requires n>=79.')
    k = core_size(n)
    low, high = interval(n, k)
    protected_max = n*((n+6)//7-1)
    h = None
    circle_max = None
    if n <= 827:
        h = (7 if n % 7 else 11) if n <= 108 else next(
            h for h in (7, 11, 15, 19) if gcd(h, n) == 1)
        assert h % 4 == 3 and gcd(h, n) == 1 and 2*h+2 <= n
        a, b = divmod(n-h+1, 4)
        circle_max = n*(2*a+min(b, 2)-(2*h-1 <= n-h))
        assert protected_max >= 5*n and circle_max >= low
    else:
        assert protected_max >= low
    return dict(n=n, k=k, pair_min=low, m_max=high,
                protected_max=protected_max, circle_h=h, circle_max=circle_max)


def construct(n, m):
    """Every 3n<=m<=n(n-3), n>=79, with explicit direct recipes."""
    p = parameters(n)
    if not 3*n <= m <= p['m_max']:
        raise ValueError('Requires 3n<=m<=n(n-3).')
    if m >= p['pair_min']:
        return pair_construct(n, m, p['k'])
    if m <= p['protected_max']:
        from main_interval_resume import construct as protected
        arcs = protected(n, m)[0]
        branch = 'pair_protected_circle'
    else:
        from main_interval_half_density import construct as circle
        assert p['circle_h'] is not None and 5*n <= m <= p['circle_max']
        arcs = circle(n, m, h=p['circle_h'], variant='gap')
        branch = 'pair_five_circle'
    return dict(n=n, m=m, I=n*(n-1)-m, branch=branch,
                parameters=p, arcs=sorted(arcs))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('n', type=int)
    parser.add_argument('m', type=int)
    parser.add_argument('--pair-only', action='store_true')
    parser.add_argument('--out')
    args = parser.parse_args()
    result = (pair_construct if args.pair_only else construct)(args.n, args.m)
    body = json.dumps(result, indent=2)+'\n'
    if args.out:
        from pathlib import Path
        Path(args.out).write_text(body)
    else:
        print(body, end='')

#!/usr/bin/env python3
"""Retain actual-game certificates once per exact normalized row orbit."""
import itertools
import json
from pathlib import Path
from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]

def transformed(rows,p):
    image=[0]*len(rows)
    for s,row in enumerate(rows):
        image[p[s]]=sum(1<<p[t]for t in range(len(rows))if row>>t&1)
    return tuple(image)

def main():
    source=ROOT/'research/small-dense-near-endpoint-eight-defect-two.jsonl'
    records=[json.loads(line)for line in source.read_text().splitlines()]
    assert records[-1]['kind']=='complete' and not records[-1]['capped']
    leaves=[r for r in records if r['kind']=='leaf']
    group=[(0,)+a+b for a in itertools.permutations((1,2,3))for b in itertools.permutations((4,5,6,7))]
    seen={};representatives=[];certificates=[];assignment=[]
    for leaf in leaves:
        rows=tuple(leaf['missing_masks'])
        if rows not in seen:
            index=len(representatives);representatives.append(rows)
            for permutation in group:seen[transformed(rows,permutation)]=index
            arcs=[(s,t)for s in range(8)for t in range(8)if s!=t and not(rows[s]>>t&1)]
            game=solve_graph(8,arcs,crosscheck=True,certificates=True)
            assert game['I']==leaf['I']<15
            certificates.append(game)
        assignment.append(seen[rows])
    result={'complete_leaf_count':len(leaves),'group':'All permutations fixing0 and preserving{1,2,3} and{4,5,6,7}; order144.',
            'representative_masks':representatives,'leaf_representative_indices':assignment,
            'representative_count':len(representatives),'maximum_I':max(g['I']for g in certificates)}
    (ROOT/'research/small-dense-near-endpoint-orbits.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
    (ROOT/'research/small-dense-near-endpoint-negative-certificates.json').write_text(json.dumps(certificates,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in ('representative_masks','leaf_representative_indices')}))

if __name__=='__main__':main()

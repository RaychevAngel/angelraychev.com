#!/usr/bin/env python3
"""Export complete eight-arrow profile trees as kernel-checked Lean literals."""
from pathlib import Path
import argparse, json, itertools
from irregular_ten_export import certificate, route, natlist
ROOT=Path(__file__).resolve().parents[1]

def render(node_map,p):
    node=node_map[','.join(map(str,p))]
    if node['kind']=='bound':return '.bound '+certificate(node['certificate'])
    children=' '.join('| '+str(rep)+' => '+render(node_map,p+[rep])for rep in node['representatives'])
    return '.branch '+natlist(node['representatives'])+' '+route(node)+' (fun mask => match mask with '+children+' | _ => .invalid)'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('budget',type=int,choices=[8,9,10,11,12,13]);ap.add_argument('--input',type=Path)
    ap.add_argument('--out',type=Path,default=ROOT/'lean');ap.add_argument('--orders');args=ap.parse_args()
    budget=args.budget;bound={8:4,9:5,10:6,11:8,12:9,13:11}[budget];word={8:'Eight',9:'Nine',10:'Ten',11:'Eleven',12:'Twelve',13:'Thirteen'}[budget];zero='false' if budget==9 else 'true'
    args.input=args.input or ROOT/f'research/lean-small-budget-{budget}-profiles.json';args.orders=args.orders or ','.join(map(str,range(5,budget+1)))
    args.out.mkdir(parents=True,exist_ok=True)
    data=json.loads(args.input.read_text());assert data['arrows']==budget and data['bound']==bound
    for n in map(int,args.orders.split(',')):
        cases=[c for c in data['cases']if c['n']==n]
        prefix=f'SmallBudget{word}Finite{n}'
        s=f'''import SmallRowPrefixCut
import SmallBudgetProfiles

/-! Complete row-prefix coverage for every sorted joint-degree profile on
{n} vertices with {budget} arrows and the stated degree restriction. -/
namespace Delivery.{prefix}
open FiniteGame Extremal RowPrefix SmallBudgetProfiles
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def rows '''+' '.join(chr(97+i)for i in range(n))+f''' : Rows {n} := fun v =>
  match v.val with '''+' '.join(f'| {i} => {chr(97+i)}'for i in range(n-1))+f' | _ => {chr(96+n)}\n\n'
        choices={d:[sum(1<<t for t in ts)for ts in itertools.combinations(range(n),d)]for d in range(n+1)}
        s+='def choices (d : Nat) : List Nat :=\n  match d with\n'
        for d,ms in choices.items():s+=f'  | {d} => '+natlist(ms)+'\n'
        s+='  | _ => []\n\n'
        s+=f'theorem cover (d : Fin {n+1}) : RowCover {n} d.val (choices d.val) := by\n  revert d\n  decide +kernel\n\n'
        for i,c in enumerate(cases):
            labels=natlist(list(reversed(c['labels'])));ds=f'(D (n:={n}) '+labels+')';rs=f'(R (n:={n}) '+labels+')'
            declarations=[];counter=[0]
            def proof(p):
                node=c['nodes'][','.join(map(str,p))];idx=counter[0];counter[0]+=1
                name=f'profile{i}_node{idx}';pl=natlist(p)
                if node['kind']=='bound':
                    cn=name+'_cert'
                    mode=node['certificate']['mode'];typ='CutBound' if mode=='cut' else 'Bound';sound='cut_bound_sound' if mode=='cut' else 'bound_sound';check='SmallCut.boundCheck_true' if mode=='cut' else 'SmallBoolean.boundCheck_true'
                    cert=node['certificate'];body=certificate(cert) if mode=='plain' else certificate(dict(cert,allowed=cert['lost'])).replace('allowed :=','lost :=')
                    declarations.append(f'def {cn} : {typ} {n} := '+body+'\n')
                    declarations.append(f'theorem {name} : Upper {ds} {rs} {pl} {bound} :=\n  {sound} {ds} {rs} {pl} {bound} {cn}\n    (({check} {ds} {rs} {pl} {bound} {cn}).mp (by decide +kernel))\n')
                else:
                    reps=node['representatives'];children={v:proof(p+[v])for v in reps}
                    rn=name+'_route';d=c['outdegrees'][len(p)]
                    declarations.append(f'def {rn} : Route {n} := '+route(node)+'\n')
                    src=f'theorem {name} : Upper {ds} {rs} {pl} {bound} := by\n'
                    src+=f'  apply routed_branch {ds} {rs} {pl} {bound} (by decide) (choices {d}) {natlist(reps)} {rn}\n'
                    src+=f'    (by change RowCover {n} {d} (choices {d}); exact cover ⟨{d},by decide⟩)\n'
                    src+=f'    ((SmallBoolean.routesCheck_true {ds} {rs} {pl} (choices {d}) {natlist(reps)} {rn}).mp (by decide +kernel))\n'
                    src+='  intro mask member\n'
                    if reps:
                        src+='  simp only [List.mem_cons,List.not_mem_nil,or_false] at member\n  rcases member with '+' | '.join('rfl'for _ in reps)+'\n'
                        src+=''.join('  · exact '+children[v]+'\n'for v in reps)
                    else:src+='  simp at member\n'
                    declarations.append(src)
                return name
            rootname=proof([])
            s+='\n'.join(declarations)+f'\ntheorem profile{i} : Upper {ds} {rs} [] {bound} := {rootname}\n\n'
        s+='def catalogue : List (List Nat) := ['+','.join(natlist(c['labels'])for c in cases)+']\n\n'
        s+=f'theorem catalogue_eq : hardProfiles {n} {budget} {bound} {zero}=catalogue := by decide +kernel\n\n'
        s+=f'''theorem hard_upper (xs : List Nat) (member : xs∈hardProfiles {n} {budget} {bound} {zero}) :
    Upper (n:={n}) (D xs.reverse) (R xs.reverse) [] {bound} := by
  rw [catalogue_eq] at member
  simp only [catalogue,List.mem_cons,List.not_mem_nil,or_false] at member
'''+('  rcases member with '+' | '.join('rfl'for c in cases)+'\n' if cases else '')
        for i,c in enumerate(cases):
            s+=f'  · exact profile{i}\n'
        s+=f'''theorem profile_upper (xs : List Nat) (member : xs∈profiles {n} {zero} {n} 0 {budget} {budget}) :
    Upper (n:={n}) (D xs.reverse) (R xs.reverse) [] {bound} :=
  upper_of_hard hard_upper xs member

theorem upper (E : Graph (Fin {n})) (loops : Loopless E) (budget : arcCount E={budget})
    (degree : ∀x,2≤SparseSupport.outdegree E x+SparseSupport.indegree E x)
    (regularity : ∀x,(0<SparseSupport.outdegree E x ∧ 0<SparseSupport.indegree E x) ∨
      ({zero}=true ∧ SparseSupport.outdegree E x+SparseSupport.indegree E x=2)) : score E≤{bound} := by
  have od (x) : SparseSupport.outdegree E x<{n} := by
    have h := SparseDeletion.row_nonadjacent_bound E loops x
    omega
  have idg (x) : SparseSupport.indegree E x<{n} := by
    have h := SparseDeletion.column_nonadjacent_bound E loops x
    omega
  have td : ((List.finRange {n}).map (SparseSupport.outdegree E)).sum={budget} := by
    have h := SparseSupport.arc_rows E
    exact h.symm.trans budget
  have te : ((List.finRange {n}).map (SparseSupport.indegree E)).sum={budget} := by
    have h := SparseSupport.arc_columns E
    exact h.symm.trans budget
  have member := sorted_member (SparseSupport.outdegree E) (SparseSupport.indegree E)
    {zero} (by decide) od idg degree regularity td te
  obtain ⟨F,⟨iso⟩,prescribed⟩ := relabel_reversed E loops (fun x => by have := idg x; omega)
  have bound := profile_upper _ member F prescribed (by intro s h; simp at h)
  rw [GraphRelabeling.score_eq iso] at bound
  exact bound

#print axioms upper
end Delivery.{prefix}
'''
        # rows arguments require explicit Nat types.
        s=s.replace('def rows '+' '.join(chr(97+i)for i in range(n))+' :', 'def rows ('+' '.join(chr(97+i)for i in range(n))+' : Nat) :')
        (args.out/f'{prefix}.lean').write_text(s)
        print(prefix,len(cases),len(s))
if __name__=='__main__':main()

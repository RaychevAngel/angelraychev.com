// Screen two-port splices of a finite universal block into the five-type ring.
// Finite success is candidate discovery only; a fixed exterior-state certificate
// is required before any assertion about infinitely many ring sizes.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <vector>
using U=uint64_t;
U adj[64],W[64],safe[64],NW[64];
bool recipient(int n,int t){
 U all=(U(1)<<n)-1;std::fill(W,W+n,0);W[t]=all;
 while(true){for(int v=0;v<n;++v){safe[v]=0;for(int c=0;c<n;++c)if(!(adj[c]&~W[v]))safe[v]|=U(1)<<c;}
 bool change=false;for(int r=0;r<n;++r){U w=0,nb=adj[r];while(nb){int v=__builtin_ctzll(nb);nb&=nb-1;w|=safe[v];}if(r!=t)w&=~(U(1)<<r);NW[r]=w;change|=w!=W[r];}std::copy(NW,NW+n,W);if(!change)break;}
 for(int r=0;r<n;++r)if((W[r]|(U(1)<<r))!=all)return false;return true;
}
int main(int argc,char**argv){std::ifstream f(argv[1]);int q;f>>q;int n=40+q;if(n>63)return 2;
 std::vector<std::pair<int,int>>A;int sig[5]={0,2,4,3,1},shift[5]={1,-1,-1,-1,-1};for(int u=0;u<40;++u){A.push_back({u,(u+1)%40});A.push_back({u,5*((u/5+shift[u%5]+8)%8)+sig[u%5]});}
 for(int i=0;i<2*q;++i){int u,v;f>>u>>v;A.push_back({40+u,40+v});}
 double limit=argc>2?std::atof(argv[2]):10;auto begin=std::chrono::steady_clock::now();auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();};
 int evaluated=0,found=0;std::cout<<"{\"q\":"<<q<<",\"candidates\":[";
 for(int ga:{8,6,2,0,14,18})for(int gb:{7,3,9,1,11,19})for(int ha=80;ha<80+2*q;++ha)for(int hb=80;hb<80+2*q;++hb){if(elapsed()>limit||found>=8)goto done;if(ga==gb||ha==hb)continue;
 auto a=A;std::swap(a[ga].second,a[ha].second);std::swap(a[gb].second,a[hb].second);
 for(int r=0;r<n;++r)adj[r]=U(1)<<r;bool good=true;for(auto [u,v]:a){if(u==v||(adj[u]>>v&1)){good=false;break;}adj[u]|=U(1)<<v;}if(!good)continue;++evaluated;
 for(int t:{40,0,5,41})if(!recipient(n,t)){good=false;break;}if(!good)continue;
 for(int t=0;t<n;++t)if(!recipient(n,t)){good=false;break;}if(!good)continue;
 if(found++)std::cout<<",";std::cout<<"{\"swaps\":[["<<ga<<","<<ha<<"],["<<gb<<","<<hb<<"]],\"arcs\":[";for(int i=0;i<int(a.size());++i){if(i)std::cout<<",";std::cout<<"["<<a[i].first<<","<<a[i].second<<"]";}std::cout<<"]}";
 }
 done:std::cout<<"],\"evaluated\":"<<evaluated<<",\"seconds\":"<<elapsed()<<"}\n";
}

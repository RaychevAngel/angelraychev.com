#!/usr/bin/env python3
"""Direct two-type missing graphs, robust envelopes, and dense staircase.

Ordinary proofs are in paper/dense-unified-core.md. These finite checks
use the exact two-move criterion, without invoking either game solver.
"""
from __future__ import annotations

from itertools import combinations
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def even_core(k):
    assert k >= 5
    return {(s, t) for i in range(k) for s, t in
            ((i, k+i), (i, k+(i-1) % k),
             (k+i, (i+4) % k), (k+i, (i+6) % k))}


def core(n):
    """Return exactly2n compulsory missing arcs, all pairs safe in2 moves."""
    if n == 11:
        rows = ((4,8),(9,10),(8,9),(7,10),(0,1),(2,6),(3,5),(3,4),(2,7),(0,5),(1,6))
        return {(i,t) for i,row in enumerate(rows) for t in row}
    if n % 2 == 0:
        return even_core(n//2)
    assert n >= 13
    k = (n-1)//2
    result = even_core(k)
    x = n-1
    for p in (0, 3):
        result.remove((p, k+p))
        result.update(((p, x), (x, k+p)))
    return result


def envelope(n):
    """Exactly 2n compulsory and n freely optional missing arrows, n>=16."""
    assert n >= 16
    if n < 22:
        name = 'routing-defect-phase2-dense-tiny-checks.json' if n < 19 else 'routing-defect-phase2-dense-small-checks.json'
        row = next(x for x in json.loads((ROOT/'research'/name).read_text())['rows'] if x['n']==n)
        base = core(n)
        assert base == set(map(tuple,row['base']))
        return base,set(map(tuple,sorted(row['optional'])[:n]))
    repairs = {
        23: (5,0,[((12,16),(12,18)),((18,11),(18,13))]),
        25: (5,2,[((13,17),(13,10))]),
        27: (6,2,[((15,19),(15,12))]),
        31: (5,0,[((16,20),(16,10))]),
    }
    k = n//2
    base = even_core(k)
    optional = {(i,(i+6)%k) for i in range(k)}
    optional |= {(k+i,k+(i+4)%k) for i in range(k)}
    if n%2:
        j,z,changes = repairs.get(n,(7,2,[]))
        x = n-1
        for p in (0,j):
            base.remove((p,k+p))
            base.update(((p,x),(x,k+p)))
        optional.add((x,z))
        for old,new in changes:
            optional.remove(old);optional.add(new)
    assert len(base)==2*n and len(optional)==n and base.isdisjoint(optional)
    assert all(s!=t for s,t in base|optional)
    return base,optional


def masks(n, arcs):
    out, inc = [0]*n, [0]*n
    for s, t in arcs:
        assert 0 <= s < n and 0 <= t < n and s != t
        out[s] |= 1 << t
        inc[t] |= 1 << s
    assert sum(x.bit_count() for x in out) == len(arcs)
    return out, inc


def robust_check(n, base, optional):
    """The full envelope's every missing pair has a compulsory safe witness."""
    bo, _ = masks(n, base)
    fo, fi = masks(n, base | optional)
    assert all(bo[c] & ~(fo[s] | fi[t])
               for s, t in base | optional for c in range(n) if c != s)
    return len(base | optional)*(n-1)


def two_move_pairs(n, missing):
    out, inc = masks(n, missing)
    return {(s,t) for s,t in missing
            if all(c == s or out[c] & ~(out[s] | inc[t]) for c in range(n))}


def first_step(n):
    assert n >= 16
    k = n-4
    missing = core(k)
    attachments = (0, 3, 1, 4) if k % 2 == 0 else (1, 4, 2, 5)
    a, b, d, e = attachments
    c, x, y, z = range(k, n)
    missing.update(((c,x), (x,y), (x,z), (y,a), (y,b), (z,d), (z,e)))
    return missing, {(x,y), (x,z)}


def functional(r):
    assert r >= 2
    j = (r-2)//2
    missing = {(0,1), (1,0)}
    roots = [2+2*i for i in range(j)]
    for s in roots:
        missing.update(((s,s+1), (s+1,0)))
    if r % 2:
        missing.add((r-1,0))
        roots.append(r-1)
    return missing, roots


def staircase(n,r):
    assert 1 <= r <= n
    if r == 1:
        return first_step(n)[0], 'four-vertex attachment'
    k = n-r
    missing, roots = functional(r)
    if k == 0:
        return missing, 'functional endpoint'
    if k >= 10:
        missing.update((s+r,t+r) for s,t in core(k))
        return missing, 'functional plus direct core'
    assert k <= len(roots)*(len(roots)-1)//2
    for v, pair in zip(range(r,n),combinations(roots,2)):
        missing.update((v,t) for t in pair)
    return missing, 'distinct functional roots'


def main():
    cores = [10]+list(range(12,121))
    for n in cores:
        missing = core(n)
        out, inc = masks(n,missing)
        assert len(missing) == 2*n
        assert all(x.bit_count() == 2 for x in out+inc)
        assert len(two_move_pairs(n,missing)) == 2*n
    first_steps = list(range(16,91))
    for n in first_steps:
        missing, failures = first_step(n)
        assert missing-two_move_pairs(n,missing) == failures
    envelopes = [n for n in range(22,131)
                 if n % 2 == 0 or n >= 33 or n == 29]
    robust_triples = 0
    for n in envelopes:
        base, optional = envelope(n)
        robust_triples += robust_check(n,base,optional)
    budgets = []
    for n in (22,24,29,32,33,61,100):
        base, optional = envelope(n)
        ordered = sorted(optional)
        for h in range(2*n,3*n+1):
            missing = base | set(ordered[:h-2*n])
            assert len(two_move_pairs(n,missing)) == h
            budgets.append({'n':n,'h':h})
    rows = []
    for n in list(range(24,61))+[75,100]:
        for r in range(1,n+1):
            missing, method = staircase(n,r)
            expected = 2*n-r-(r+1)//2-1
            assert len(missing) == 2*n-r
            assert len(two_move_pairs(n,missing)) == expected, (n,r,method)
            rows.append({'n':n,'r':r,'I':expected,'method':method})
    receipt = {
        'status':'verified',
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'proof_boundary':'Finite exact two-move/robustness checks support the separate ordinary proofs; no new Lean or full-game enumeration claim.',
        'core_orders':cores,
        'first_step_orders':first_steps,
        'robust_envelope_orders':envelopes,
        'robust_triples_checked':robust_triples,
        'envelope_budget_checks':budgets,
        'dense_staircase_instances':rows,
    }
    path = ROOT/'research/dense-unified-core-checks.json'
    path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':'verified','core_orders':len(cores),
                      'first_steps':len(first_steps),'envelopes':len(envelopes),
                      'robust_triples':robust_triples,'dense_instances':len(rows),
                      'receipt':str(path)}))


if __name__ == '__main__':
    main()

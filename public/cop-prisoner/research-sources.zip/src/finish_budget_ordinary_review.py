#!/usr/bin/env python3
"""Pin root's independent ordinary review and completed14–16 leaf evidence."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def main():
 mf='research/finish_budget_manifest.json';d=json.loads((ROOT/mf).read_text())
 for p,h in d['files'].items():assert digest(p)==h,p
 for p,h in d['inherited_inputs'].items():assert digest(p)==h,p
 leaf=json.loads((ROOT/'research/finish_budget_leaf_review.json').read_text());assert leaf['verified']
 expected={14:13,15:15,16:19}
 for r in d['rows']:
  assert r['threshold']==expected[r['m']]
  run=next(x for x in leaf['runs'] if (x['n'],x['m'],x['mode'])==(r['n'],r['m'],r['mode']))
  assert run['complete'] and not run['counterexample_found']
  assert run['degree_patterns']==run['total_degree_patterns']==r['degree_patterns']
  assert run['nodes']==r['nodes'] and run['game_decisions']==r['game_decisions']
 for m,start,upper in ((14,11,13),(15,11,15),(16,12,19)):
  for n in range(start,m+1):
   vals=[q*r-max(0,q+r-n)-max(0,2*q+2*r-m) for q in range(min(n,m-n,m//2)+1) for r in range(min(n,m-n,m//2)+1)]
   assert max(vals)<=upper,(m,n,max(vals))
 result=dict(verified=True,claims=d['claims'],files={**d['files'],**d['inherited_inputs'],mf:digest(mf)},
  reviewer_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  ordinary_review='Root separately checked source/sink deletion, two live predecessors/successors, all-source/sink capacities, degree-two restriction, complete support and joint-degree inventories, future-prefix symmetry, unioned camping/guarded failures, and dynamic deletion potentials. No arbitrary vertex deletion or reversal assumption.',
  boundary='Complete source-reviewed coverage, independent full leaf games, sampled prune checks; no second full graph generator or concrete Lean instantiation.',totals=d['totals'])
 (ROOT/'research/finish-budget-ordinary-review.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(dict(verified=True,claims=d['claims'],totals=d['totals'])))
if __name__=='__main__':main()

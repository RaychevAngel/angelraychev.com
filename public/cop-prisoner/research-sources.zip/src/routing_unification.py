#!/usr/bin/env python3
"""Protected routing: exact conditional counts and independent finite checks.

Only arrows incident with H are decisions. Arrows outside H are deliberately
absent from every witness condition. No asymptotic-size derandomization is run.
"""
from itertools import combinations
from math import ceil, comb, log
from pathlib import Path
import hashlib
import json
import random


def universe(n, hubs):
    hubs = frozenset(hubs)
    assert hubs <= set(range(n))
    return [(s, t) for s in range(n) for t in range(n)
            if s != t and (s in hubs or t in hubs)]


def choose(n, k):
    return comb(n, k) if 0 <= k <= n else 0


def triples(n):
    return [(s, t, c) for s in range(n) for t in range(n)
            if s != t for c in range(n) if c != s]


def bad_completions(n, hubs, a, fixed, triple):
    s, t, c = triple
    assert s != t and c != s
    hubs = frozenset(hubs)
    total_variables = len(hubs) * (2*n-len(hubs)-1)
    free = total_variables-len(fixed)
    remaining = a-sum(fixed.values())
    if not 0 <= remaining <= free:
        return 0
    polynomial = [1]
    used = 0
    for u in sorted(hubs - {s, t, c}):
        requirements = (((s, u), 1), ((u, t), 1), ((c, u), 0))
        available = all(e not in fixed or fixed[e] == v
                        for e, v in requirements)
        q = sum(e not in fixed for e, v in requirements)
        j = sum(e not in fixed and v == 1 for e, v in requirements)
        factor = [comb(q, i) for i in range(q+1)]
        if available:
            factor[j] -= 1
        if not any(factor):
            return 0
        product = [0] * (len(polynomial)+q)
        for i, x in enumerate(polynomial):
            for j, y in enumerate(factor):
                product[i+j] += x*y
        polynomial = product
        used += q
    return sum(x*choose(free-used, remaining-j)
               for j, x in enumerate(polynomial))


def counts(n, hubs, a, fixed, objectives=None):
    objectives = triples(n) if objectives is None else objectives
    Q = len(hubs)*(2*n-len(hubs)-1)
    return (sum(bad_completions(n, hubs, a, fixed, tr) for tr in objectives),
            choose(Q-len(fixed), a-sum(fixed.values())))


def construct(n, hubs, a, fixed=None, objectives=None):
    """Exact polynomial algorithm; objectives=None means every legal triple."""
    available = universe(n, hubs)
    fixed = {} if fixed is None else dict(fixed)
    assert set(fixed) <= set(available)
    assert set(fixed.values()) <= {0, 1}
    assert 0 <= a <= len(available)
    bad, total = counts(n, hubs, a, fixed, objectives)
    if not bad < total:
        raise ValueError("Initial conditional expectation is not below one")
    trace = []
    for arc in available:
        if arc in fixed:
            continue
        branches = []
        for value in (0, 1):
            fixed[arc] = value
            branches.append(counts(n, hubs, a, fixed, objectives))
        assert bad == sum(x for x, y in branches)
        assert total == sum(y for x, y in branches)
        value = next(v for v, (x, y) in enumerate(branches) if x < y)
        fixed[arc] = value
        bad, total = branches[value]
        trace.append([list(arc), value, bad, total])
    assert bad == 0 and total == 1 and sum(fixed.values()) == a
    return [e for e in available if fixed[e]], trace


def literal_bad(edges, hubs, triple):
    s, t, c = triple
    return not any((s, u) in edges and (u, t) in edges and (c, u) not in edges
                   for u in hubs if u not in {s, t, c})


def route_check(n, hubs, edges):
    """Batch all recipients by unions; insists on witnesses even for direct pairs."""
    rows = [0] * n
    for s, t in edges:
        rows[s] |= 1 << t
    hub_mask = sum(1 << u for u in hubs)
    all_vertices = (1 << n)-1
    failures = []
    for s in range(n):
        for c in range(n):
            if c == s:
                continue
            safe = rows[s] & hub_mask & ~(rows[c] | (1 << c))
            recipients = 0
            while safe:
                bit = safe & -safe
                recipients |= rows[bit.bit_length()-1]
                safe -= bit
            missing = (all_vertices ^ (1 << s)) & ~recipients
            if missing:
                failures.append([s, c, missing])
    return failures


def check():
    rng = random.Random(541209)
    exact_cases = 0
    legacy_cases = 0
    membership_patterns = set()
    import exact_budget_derandomize as legacy
    for n in range(3, 7):
        for b in range(1, n+1):
            for trial in range(12):
                hubs = set(rng.sample(range(n), b))
                arcs = universe(n, hubs)
                shuffled = arcs[:]
                rng.shuffle(shuffled)
                free = shuffled[:min(8, len(shuffled))]
                fixed = {e: rng.randrange(2) for e in shuffled[len(free):]}
                a = sum(fixed.values())+rng.randrange(len(free)+1)
                tr = rng.choice(triples(n))
                membership_patterns.add(tuple(v in hubs for v in tr)+(tr[1] == tr[2],))
                brute = sum(literal_bad({e for e, v in fixed.items() if v} | set(take),
                                        hubs, tr)
                            for take in combinations(free, a-sum(fixed.values())))
                exact = bad_completions(n, hubs, a, fixed, tr)
                assert exact == brute, (n, hubs, a, tr, exact, brute)
                edge = free[0]
                assert exact == sum(bad_completions(n, hubs, a, {**fixed, edge: v}, tr)
                                    for v in (0, 1))
                if b == n:
                    assert exact == legacy.bad_completions(n, a, fixed, tr)
                    legacy_cases += 1
                exact_cases += 1
    # Complete a nontrivial restricted decision process for two specified triples.
    n, hubs, a = 5, {1, 2}, 6
    objectives = [(0, 4, 4), (3, 4, 4)]
    fixed = {(0, 1): 1, (1, 4): 1, (3, 1): 1, (4, 1): 0}
    result, trace = construct(n, hubs, a, fixed, objectives)
    assert len(result) == a
    assert all(not literal_bad(set(result), hubs, tr) for tr in objectives)

    # Cross-check the batched all-triple witness checker against literal tests.
    checker_cases = 0
    for n in range(3, 9):
        for trial in range(12):
            hubs = set(rng.sample(range(n), rng.randrange(1, n+1)))
            edges = {e for e in universe(n, hubs) if rng.getrandbits(1)}
            batch = {(s, t, c) for s, c, mask in route_check(n, hubs, edges)
                     for t in range(n) if mask >> t & 1}
            direct = {tr for tr in triples(n) if literal_bad(edges, hubs, tr)}
            assert batch == direct
            checker_cases += 1

    # Exact-size sampled cores corroborate the theorem; these are not outputs
    # of the deterministic conditional-expectation algorithm.
    sampled = []
    for n in (256, 320, 512):
        b = ceil(32*log(n)+11)
        hubs = set(range(b))
        possible = universe(n, hubs)
        assert len(possible) == b*(2*n-b-1) and len(possible) % 2 == 0
        a = len(possible)//2
        margin = (b-3)/8-4*log(n)-log(8/3)
        assert b <= n and margin > 0
        sample_rng = random.Random(540000+n)
        edges = set(sample_rng.sample(possible, a))
        assert not route_check(n, hubs, edges)
        outside = [(s, t) for s in range(b, n) for t in range(b, n) if s != t]
        for extras in (outside, outside[::2]):
            assert not route_check(n, hubs, edges | set(extras))
        digest = hashlib.sha256(json.dumps(sorted(edges)).encode()).hexdigest()
        sampled.append({"n": n, "b": b, "incident_arcs": a,
                        "every_exact_budget_from": a,
                        "every_exact_budget_to": a+len(outside),
                        "floating_condition_margin": margin,
                        "legal_source_pursuer_starts_checked": n*(n-1),
                        "incident_arc_sha256": digest, "seed": 540000+n,
                        "empty_full_alternating_exteriors_passed": True})

    root = Path(__file__).resolve().parents[1]
    receipt = {"verified": True, "exact_brute_force_comparisons": exact_cases,
               "same_universe_legacy_comparisons": legacy_cases,
               "endpoint_hub_membership_patterns": len(membership_patterns),
               "batched_literal_comparisons": checker_cases,
               "restricted_objective_decision_test": {
                   "n": 5, "hubs": [1, 2], "a": 6,
                   "objectives": objectives, "arcs": result, "trace": trace},
               "exact_size_sampled_routing_cores": sampled,
               "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "scope": "Exact coefficient tests use exhaustive small completions. "
                        "Large cores are exact-size random samples verified for every "
                        "triple using routing intermediaries; no large deterministic "
                        "conditional-expectation run and no Lean proof."}
    (root/"research/routing-unification-checks.json").write_text(
        json.dumps(receipt, indent=2)+"\n")
    print(json.dumps({k: v for k, v in receipt.items() if k not in
                      {"restricted_objective_decision_test", "scope"}}))


if __name__ == "__main__":
    check()

#!/usr/bin/env python3
"""Untrusted bounded complete row-prefix data for positive nine-vertex/14-arrow graphs.

The eleven literal degree profiles are retained inputs. Their coverage is a
separate Lean theorem, never an assumption supplied by this producer.
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILE_FILE = ROOT/'research/finish_budget_profiles_n9_m14_above13.json'
N = 9
ALL = (1 << N)-1
CHOICES = {d: [sum(1 << t for t in ts) for ts in itertools.combinations(range(N), d)] for d in (1,2,3)}
PROFILES = json.loads(PROFILE_FILE.read_text())['patterns']

class Producer:
    def __init__(self, profile):
        self.profile = profile
        self.D,self.R = map(list,zip(*PROFILES[profile]))
        assert len(self.D)==N and sum(self.D)==sum(self.R)==14
        self.sources=[s for s in range(N) if self.D[s]>=2]
        self.targets=[t for t in range(N) if self.R[t]>=2]
        self.groups=[list(g) for _,g in itertools.groupby(range(N),key=lambda i:(self.D[i],self.R[i]))]
        self.prefix_perms=[]
        for k in range(N+1):
            groups=[[i for i in group if i<k] for group in self.groups]
            perms=[]
            for picked in itertools.product(*(itertools.permutations(g) for g in groups)):
                f=list(range(N))
                for group,values in zip(groups,picked):
                    for i,v in zip(group,values):f[i]=v
                perms.append(f)
            self.prefix_perms.append(perms)
        self.canon_cache={}


    def prefix_ok(self,p):
        k=len(p)
        if any(mask.bit_count()!=self.D[s] or mask>>s&1 for s,mask in enumerate(p)):
            return False
        used=[sum(mask>>t&1 for mask in p) for t in range(N)]
        return all(used[t]<=self.R[t]<=used[t]+N-k-int(t>=k) for t in range(N))

    def envelope(self,p):
        k=len(p)
        used=[sum(mask>>t&1 for mask in p) for t in range(N)]
        available=sum(1<<t for t in range(N) if used[t]<self.R[t])
        lower=[(p[s] if s<k else 0)|1<<s for s in range(N)]
        upper=[lower[s] if s<k else available|1<<s for s in range(N)]
        return upper,lower

    @staticmethod
    def losing_region(upper,lower,target):
        winning=[ALL if r==target else 0 for r in range(N)]
        while True:
            safe=[sum(1<<c for c in range(N) if lower[c]&~winning[z]==0) for z in range(N)]
            new=[]
            for r in range(N):
                win=0;mask=upper[r]
                while mask:
                    bit=mask&-mask;mask-=bit
                    win|=safe[bit.bit_length()-1]
                new.append(win if r==target else win&~(1<<r))
            if new==winning:break
            winning=new
        region=[ALL^w for w in winning]
        good=[sum(1<<z for z in range(N) if z!=target and
                  (z==c or lower[c]&((1<<z)|region[z]))) for c in range(N)]
        assert region[target]==0
        for r in range(N):
            for c in range(N):
                if r!=c and region[r]>>c&1:assert upper[r]&good[c]==upper[r]
        return region,good

    def bound_certificate(self,p):
        upper,lower=self.envelope(p)
        lost=[0]*N
        eligible=sum(s!=t for s in self.sources for t in self.targets)
        lowout=sum(d for d in self.D if d<2)
        lowin=sum(d for d in self.R if d<2)
        corner=sum((mask>>t)&1 for s,mask in enumerate(p) if self.D[s]<2
                   for t in range(N) if self.R[t]<2)
        cap=eligible+lowout+lowin-14-corner
        losses=[]
        if cap>13 and len(p)>=2:
            for t in self.targets:
                region,good=self.losing_region(upper,lower,t)
                omitted=[s for s in self.sources if s!=t and region[s]&~(1<<s)]
                if not omitted:continue
                losses.append(dict(target=t,region=region,good=good))
                for s in omitted:
                    assert s>=len(p) or not(p[s]>>t&1)
                    lost[s]|=1<<t
                if cap-sum(mask.bit_count() for mask in lost)<=13:break
        if cap-sum(mask.bit_count() for mask in lost)>13:return None
        return dict(lost=lost,upper=upper,lower=lower,losses=losses)

    def route(self,p,mask):
        row=len(p)
        incoming=[sum(1<<s for s,bits in enumerate(p) if bits>>t&1) for t in range(N)]
        classes={}
        for t in range(row+1,N):classes.setdefault((self.D[t],self.R[t],incoming[t]),[]).append(t)
        perm=list(range(N));rep=mask
        for group in classes.values():
            selected=[t for t in group if mask>>t&1];desired=group[:len(selected)]
            for a,b in zip(sorted(set(selected)-set(desired)),sorted(set(desired)-set(selected))):
                perm[a]=b;perm[b]=a;rep^=(1<<a)|(1<<b)
        q=p+[rep]
        assert all(perm[perm[x]]==x and self.D[perm[x]]==self.D[x] and self.R[perm[x]]==self.R[x] for x in range(N))
        assert all(perm[s]==s for s in range(len(q)))
        assert all((bits>>t&1)==(q[s]>>perm[t]&1) for s,bits in enumerate(p+[mask]) for t in range(N))
        assert self.prefix_ok(q)
        return rep,perm

    def canonical(self,p):
        key=tuple(p)
        if key in self.canon_cache:return self.canon_cache[key]
        k=len(p);best=None;bestf=None
        for base in self.prefix_perms[k]:
            f=base.copy()
            for group in self.groups:
                future=[i for i in group if i>=k]
                ordered=sorted(future,key=lambda t:tuple((p[f[s]]>>t)&1 for s in range(k)),reverse=True)
                for i,v in zip(future,ordered):f[i]=v
            g=[0]*N
            for i,v in enumerate(f):g[v]=i
            q=tuple(sum(1<<g[t] for t in range(N) if p[f[s]]>>t&1) for s in range(k))
            if best is None or q<best:best,bestf=q,f
        inverse=[0]*N
        for i,v in enumerate(bestf):inverse[v]=i
        assert self.prefix_ok(best)
        assert all((p[bestf[s]]>>bestf[t]&1)==(best[s]>>t&1) for s in range(k) for t in range(N))
        result=(list(best),bestf,inverse)
        self.canon_cache[key]=result
        return result

    def produce(self,seconds):
        started=time.monotonic();nodes={}
        counts=dict(nodes=0,branches=0,bounds=0,masks=0,raw_rows=0,invalid_rows=0,symmetry_routes=0,edges=0,cache_hits=0)
        def dfs(p):
            if time.monotonic()-started>seconds:raise TimeoutError(('bounded production exceeded cap',counts))
            key=','.join(map(str,p))
            if key in nodes:
                counts['cache_hits']+=1
                return
            assert self.prefix_ok(p)
            counts['nodes']+=1
            cert=self.bound_certificate(p)
            if cert is not None:
                counts['bounds']+=1;counts['masks']+=len(cert['losses'])
                nodes[key]=dict(kind='bound',prefix=p,certificate=cert);return
            assert len(p)<N,('unexcluded actual graph',self.profile,p)
            counts['branches']+=1;routes={};reps=set()
            for mask in CHOICES[self.D[len(p)]]:
                counts['raw_rows']+=1
                if not self.prefix_ok(p+[mask]):counts['invalid_rows']+=1;continue
                rep,perm=self.route(p,mask)
                routes[str(mask)]=dict(representative=rep,permutation=perm)
                reps.add(rep);counts['symmetry_routes']+=int(rep!=mask)
            reps=sorted(reps);children={}
            nodes[key]=dict(kind='branch',prefix=p,representatives=reps,routes=routes,children=children)
            for rep in reps:
                q,f,g=self.canonical(p+[rep]);counts['edges']+=1
                children[str(rep)]=dict(prefix=q,forward=f,inverse=g)
                dfs(q)
        dfs([])
        assert counts['raw_rows']-counts['invalid_rows']==counts['edges']+counts['symmetry_routes']
        assert counts['edges']==counts['nodes']-1+counts['cache_hits']
        return dict(scope='untrusted complete prescribed-degree DAG; Lean profile coverage and replay required',
                    n=N,arrows=14,bound=13,profile_id=self.profile,outdegrees=self.D,indegrees=self.R,
                    profile_source_sha256=hashlib.sha256(PROFILE_FILE.read_bytes()).hexdigest(),
                    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    seconds=time.monotonic()-started,counts=counts,nodes=nodes)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--profile',type=int,required=True,choices=range(11))
    ap.add_argument('--seconds',type=float,default=60);ap.add_argument('--output',type=Path)
    a=ap.parse_args()
    if not 0<a.seconds<=60:raise ValueError('at most sixty seconds per complete profile')
    result=Producer(a.profile).produce(a.seconds)
    output=a.output or ROOT/f'tmp/lean-irregular-nine/profile{a.profile:02d}.json'
    output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(result,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='nodes'}))

if __name__=='__main__':main()

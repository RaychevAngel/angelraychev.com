#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
// Bounded construction search only. A failure is not an upper bound.
// Full alternating game is eliminated by existential messenger and universal
// pursuer quantifiers, preserving finite receipt; Python independently checks
// every promoted graph.
using namespace std;
#ifndef DENSE_ORDER
#define DENSE_ORDER 9
#endif
constexpr int N=DENSE_ORDER;
using Graph=array<unsigned,N>;
constexpr unsigned ALL=(1u<<N)-1;
mt19937 rng(931314);
int score(const Graph& missing) {
  Graph out;
  for(int i=0;i<N;i++)out[i]=ALL^missing[i];
  int ans=0;
  for(int target=0;target<N;target++){
    Graph wins={}; wins[target]=ALL;
    for(;;){
      Graph safe={},next={};safe[target]=ALL;
      for(int v=0;v<N;v++)if(v!=target)
        for(int c=0;c<N;c++)if(!(out[c]&~wins[v]))safe[v]|=1u<<c;
      for(int s=0;s<N;s++){
        if(s==target){next[s]=ALL;continue;}
        unsigned z=out[s];
        while(z){int v=__builtin_ctz(z);z&=z-1;next[s]|=safe[v];}
        next[s]&=ALL^(1u<<s);
      }
      if(next==wins)break;
      wins=next;
    }
    for(int s=0;s<N;s++)if((missing[s]>>target&1) &&
      wins[s]==(ALL^(1u<<s)))ans++;
  }
  return ans;
}
Graph random_graph(){
  Graph g={};
  for(int s=0;s<N;s++)while(__builtin_popcount(g[s])<2){int t=rng()%N;if(s!=t)g[s]|=1u<<t;}
  return g;
}
void dump(const Graph& g,int value){
 cout<<"{\"n\":"<<N<<",\"h\":"<<2*N<<",\"I\":"<<value<<",\"missing_rows\":[";
 for(int i=0;i<N;i++)cout<<(i?",":"")<<g[i];cout<<"]}"<<endl;
}
int main(int argc,char**argv){
 double seconds=argc>1?stod(argv[1]):20;
 auto start=chrono::steady_clock::now();int best=-1;long long moves=0;
 for(int restart=0;;restart++){
  if(chrono::duration<double>(chrono::steady_clock::now()-start).count()>seconds)break;
  Graph g=random_graph();int old=score(g);
  for(int step=0;step<2000;step++){
   if(step%100==0 && chrono::duration<double>(chrono::steady_clock::now()-start).count()>seconds)break;
   auto h=g;int s=rng()%N;unsigned a=g[s]&-g[s];if(rng()%2)a=g[s]^a;
   int t=rng()%N;if(t==s || (g[s]>>t&1))continue;h[s]^=a|(1u<<t);
   int now=score(h);moves++;
   double temp=0.1+0.9*pow(1.0-(step%500)/500.0,3);
   if(now>=old || uniform_real_distribution<double>(0,1)(rng)<exp((now-old)/temp)){g=h;old=now;}
   if(old>best){best=old;dump(g,best);if(best==2*N)return 0;}
  }
 }
 cerr<<"moves "<<moves<<" best "<<best<<endl;
}

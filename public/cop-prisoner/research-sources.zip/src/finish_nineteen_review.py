#!/usr/bin/env python3
"""Independent complete nineteen-arrow review; all final ranges, no partial pilots."""
import hashlib,json,subprocess,tempfile
from pathlib import Path
from finish_eighteen_review import positive_patterns,lower_review
from finish_budget_leaf_review import variant
ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
CASES=[('sparse_finish_positive_fullmax_n9_m19_t35.json','sparse_finish_positive_fullmax.cpp'),
       ('sparse_finish_positive_fullmax_n10_m19_t35.json','sparse_finish_positive_fullmax.cpp'),
       ('sparse_finish_positive_fullmax_n11_m19_t40_p1_complete.json','sparse_finish_positive_fullmax.cpp'),
       ('sparse_finish_positive_fullmax_earlyguard_n11_m19_t40_p2_4.json','sparse_finish_positive_fullmax_earlyguard.cpp')]


def audit_source(text):
    generated=variant(text)
    marker='long long audit_calls=0,audit_samples=0,audit_pairs=0;'
    assert marker in generated;generated=generated.replace(marker,marker+'\nvector<vector<int>> audit_updates;')
    marker='if(score<=threshold){++early_game_rejects;return -1;}return score;'
    assert marker in generated
    generated=generated.replace(marker,'if(score<=threshold){++early_game_rejects;return -1;}vector<int> update={threshold,score};for(int v=0;v<n;v++)update.push_back(O[v]);audit_updates.push_back(update);return score;')
    marker='cerr<<"AUDIT "';assert marker in generated
    generated=generated.replace(marker,'cerr<<"UPDATES [";for(size_t k=0;k<audit_updates.size();k++){if(k)cerr<<",";cerr<<"[";for(size_t j=0;j<audit_updates[k].size();j++){if(j)cerr<<",";cerr<<audit_updates[k][j];}cerr<<"]";}cerr<<"]\\n";'+marker)
    return generated


def main():
    source=ROOT/'src/sparse_finish_positive_fullmax.cpp';early=ROOT/'src/sparse_finish_positive_fullmax_earlyguard.cpp'
    prior=json.loads((ROOT/'research/finish_eighteen_review.json').read_text())
    assert sha(source)==prior['input_hashes']['src/sparse_finish_positive_fullmax.cpp']
    expected=source.read_text().replace('row>=n-4&&!guarded(row)','row>=n-5&&!guarded(row)')
    expected=expected.replace('dfs(0);if(complete)++completed_patterns;',
        'dfs(0);if(complete){++completed_patterns;cerr<<"completed profile "<<patterns<<" at "<<elapsed()<<"s\\n";}')
    assert expected==early.read_text()
    frozen={str(p.relative_to(ROOT)):sha(p) for pair in CASES for p in (ROOT/'research'/pair[0],ROOT/'src'/pair[1])}
    arithmetic=[];runs=[]
    with tempfile.TemporaryDirectory(prefix='finish_nineteen_review_') as tmp:
        tmp=Path(tmp)
        dump=source.read_text();marker='long long inherited_skips=0;'
        emit='cout<<"[";bool comma=false;for(auto const&p:families){if(comma)cout<<",";comma=true;cout<<"[";for(int j=0;j<n;j++){if(j)cout<<",";cout<<"["<<p[j].first<<","<<p[j].second<<"]";}cout<<"]";}cout<<"]\\n";return 0;'
        assert dump.count(marker)==1;dump=dump.replace(marker,emit+marker)
        dp=tmp/'profiles.cpp';de=tmp/'profiles';dp.write_text(dump)
        subprocess.run(['c++','-O3','-std=c++17',str(dp),'-o',str(de)],check=True)
        inventories={}
        for n,L in ((9,35),(10,35),(11,40)):
            produced=json.loads(subprocess.check_output([str(de),str(n),'19',str(L),'1'],text=True))
            own=positive_patterns(n,19,L)
            assert own==set(tuple(map(tuple,row)) for row in produced) and len(own)==len(produced)
            inventories[n]=produced
            arithmetic.append(dict(n=n,m=19,threshold=L,patterns=len(own),ordered_patterns=produced))
        assert [r['patterns'] for r in arithmetic]==[69,80,4]
        overlaps=[]
        for p in inventories[11]:
            assert sorted(d for d,e in p)==[1]*3+[2]*8
            assert sorted(e for d,e in p)==[1]*3+[2]*8
            overlaps.append(sum(d==e==1 for d,e in p))
        assert overlaps==[0,1,2,3]
        exes={}
        for receipt,src in CASES:
            path=ROOT/'research'/receipt;p=json.loads(path.read_text());original=ROOT/'src'/src
            assert p['complete'] and p['inherited_n9_m18_skips']==0
            assert p['total_degree_patterns']==len(inventories[p['n']])
            assert p['completed_patterns']==p['last_pattern']-p['first_pattern']+1
            if src not in exes:
                changed=audit_source(original.read_text());cpp=tmp/(original.stem+'.cpp');exe=tmp/original.stem;cpp.write_text(changed)
                subprocess.run(['c++','-O3','-std=c++17',str(cpp),'-o',str(exe)],check=True)
                exes[src]=exe,sha(cpp)
            exe,variant_hash=exes[src]
            args=[str(exe),str(p['n']),'19',str(p['initial_threshold']),'180',str(p['first_pattern']),str(p['last_pattern'])]
            proc=subprocess.run(args,text=True,capture_output=True,timeout=195)
            assert proc.returncode==0,(receipt,proc.stdout,proc.stderr)
            fresh=json.loads(proc.stdout)
            assert fresh['complete']
            for key in ('initial_threshold','threshold','degree_partitions','degree_patterns','total_degree_patterns','completed_patterns','inherited_n9_m18_skips',
                        'nodes','game_decisions','camping_rejects','guarded_checks','guarded_rejects','early_game_rejects','maximum_threshold_survivor','upper_if_complete','arcs'):
                assert fresh[key]==p[key],(receipt,key,fresh[key],p[key])
            lines=proc.stderr.splitlines();updates=[x for x in lines if x.startswith('UPDATES ')];audits=[x for x in lines if x.startswith('AUDIT ')]
            assert len(updates)==len(audits)==1
            updates=json.loads(updates[0][8:]);incumbent=p['initial_threshold']
            for u in updates:
                assert u[0]==incumbent and u[1]>incumbent;incumbent=u[1]
                assert len(u)==p['n']+2 and sum(row.bit_count() for row in u[2:])==19
                assert all(not(row>>s&1) for s,row in enumerate(u[2:]))
            assert incumbent==p['threshold']
            assert [[u[0],u[1]] for u in updates]==([[35,38]] if p['n']==10 else [])
            a=audits[0].split();assert len(a)==4
            fresh.update(primary_file=str(path.relative_to(ROOT)),primary_sha256=sha(path),source_file=str(original.relative_to(ROOT)),source_sha256=sha(original),variant_sha256=variant_hash,
                independent_maximum=int(a[1]),guarded_samples=int(a[2]),sampled_loss_pairs=int(a[3]),
                independent_updates=[dict(previous_threshold=u[0],score=u[1],outgoing_masks=u[2:]) for u in updates])
            args[4]='0.000000001';stop=subprocess.run(args,text=True,capture_output=True,timeout=10);stopped=json.loads(stop.stdout)
            assert stop.returncode==1 and stopped['complete'] is False
            fresh['timeout_control']=dict(returncode=1,complete=False,nodes=stopped['nodes'])
            runs.append(fresh)
            (ROOT/'research/finish_nineteen_review_partial.json').write_text(json.dumps(dict(complete=False,runs=runs),indent=2)+'\n')
            print(json.dumps({k:fresh[k] for k in ('n','first_pattern','last_pattern','threshold','game_decisions','seconds','independent_maximum')}),flush=True)
    lower=[lower_review(ROOT/f'research/sparse_finish_nineteen_{v}_certificate.json') for v in (35,38,40)]
    assert [(r['n'],r['I']) for r in lower]==[(9,35),(10,38),(11,40)]
    large=[]
    for N in range(12,20):
        cap=min(9,19-N)
        bound=max(q*r-max(0,q+r-N)-max(0,19-2*N+q+r) for q in range(cap+1) for r in range(cap+1))
        large.append(dict(support=N,upper=bound));assert bound<40
    assert large[0]['upper']==38 and max(r['upper'] for r in large[1:])==31
    for p,h in frozen.items():assert sha(ROOT/p)==h,p
    manifest_path=ROOT/'research/sparse_finish_nineteen_exact_manifest.json'
    assert manifest_path.exists(),'Final frozen manifest required'
    manifest=json.loads(manifest_path.read_text())
    for p,h in manifest['files'].items():assert sha(ROOT/p)==h,p
    report=dict(verified=True,claims=['M(9,19)=35','M(10,19)=38','M(n,19)=M_E(19)=40 for n>=11','minimum global attaining host11'],
        source_sha256=sha(Path(__file__)),input_manifest_sha256=sha(manifest_path),input_hashes=manifest['files'],
        helper_hashes={p:sha(ROOT/p) for p in ('src/finish_eighteen_review.py','src/finish_budget_leaf_review.py','src/finish_alternating_review.hpp')},
        independent_degree_sets=arithmetic,large_positive_support_bounds=large,lower=lower,runs=runs,
        all_leaf_games=sum(r['game_decisions'] for r in runs),guarded_samples=sum(r['guarded_samples'] for r in runs),sampled_loss_pairs=sum(r['sampled_loss_pairs'] for r in runs),
        boundary='Independent ordinary and source/coverage review, entire joint-degree set regeneration, and all finite leaf games independently solved. The graph enumeration and pruning traversal is retained, not a second complete graph enumeration; guarded losses are sampled separately.')
    (ROOT/'research/finish_nineteen_review.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()

// Finite counterexample screen of structured six-type patterns, not a proof
// of any infinite family. A full local proof is required for survivors.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using U=__uint128_t;
U adj[128],W[128],safe[128],NW[128];
int tail,head;
int bit(U a){return uint64_t(a)?__builtin_ctzll(uint64_t(a)):64+__builtin_ctzll(uint64_t(a>>64));}
bool recipient(int n,int t){
 U all=(U(1)<<n)-1;std::fill(W,W+n,0);W[t]=all;
 while(true){
  for(int v=0;v<n;++v){safe[v]=0;for(int c=0;c<n;++c)if(!(adj[c]&~W[v]))safe[v]|=U(1)<<c;}
  bool change=false;
  for(int r=0;r<n;++r){U w=0,nb=adj[r];while(nb){int v=bit(nb);nb&=nb-1;w|=safe[v];}if(r!=t)w&=~(U(1)<<r);NW[r]=w;change|=w!=W[r];}
  std::copy(NW,NW+n,W);if(!change)break;
 }
 for(int r=0;r<n;++r)if(r!=tail&&(W[r]|(U(1)<<r))!=all)return false;
 return true;
}
bool test(int k,int source,int which,const std::vector<int>&sig,const std::vector<int>&vol){
 int n=6*k;tail=source;
 for(int u=0;u<n;++u){int p=(u+1)%n,q=6*((u/6+vol[u%6]+k)%k)+sig[u%6];if(p==u||q==u||p==q)return false;adj[u]=(U(1)<<u)|(U(1)<<p)|(U(1)<<q);}
 head=which?6*((vol[source]+k)%k)+sig[source]:(source+1)%n;
 adj[tail]&=~(U(1)<<head);
 // Put nearby target types first, but cover all recipients eventually.
 for(int t=0;t<n;++t)if(t!=head&&!recipient(n,t))return false;
 return true;
}
int main(int argc,char**argv){
 std::ifstream f(argv[1]);int count;f>>count;std::cout<<"[";bool first=true;
 for(int idx=0;idx<count;++idx){
  std::vector<int>s(6),v(6);for(int&x:s)f>>x;for(int&x:v)f>>x;
  for(int x=0;x<6;++x)for(int edge=0;edge<2;++edge){
   if(!test(8,x,edge,s,v))continue;
   bool k10=test(10,x,edge,s,v),k12=k10&&test(12,x,edge,s,v);
   if(!first)std::cout<<",";first=false;
   std::cout<<"{\"pattern_index\":"<<idx<<",\"source_type\":"<<x<<",\"edge_type\":"<<edge<<",\"k8\":true,\"k10\":"<<(k10?"true":"false")<<",\"k12\":"<<(k12?"true":"false")<<"}"<<std::flush;
  }
 }
 std::cout<<"]\n";
}

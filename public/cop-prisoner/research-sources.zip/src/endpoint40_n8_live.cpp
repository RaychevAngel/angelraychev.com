// Frozen n8 live-prune variant with every evaluated leaf emitted for rank replay.
// Historical sources are unchanged; general host order, conservative q/r cap.
// The incidence cap explicitly maximizes over BOTH live dimensions.
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
int n,T,lo,hi,begin_profile,end_profile,deg[20],rowmask[20],pred[20],all;
int incidence[20][20],best_rows[20];
vector<int> opts[20][20];
long long nodes=0,leaves=0,survivors=0;
int profile=0,checked_profiles=0,best=0;
bool complete=true,found=false;
double limit;
auto began=chrono::steady_clock::now();

int delivery_count(){
  int ans=0,size=2*n*n;
  vector<vector<int>> prev(n);
  for(int u=0;u<n;u++){
    prev[u].push_back(u);
    for(int v=0;v<n;v++)if(rowmask[u]>>v&1)prev[v].push_back(u);
  }
  vector<unsigned char> W(size);
  vector<int> rem(size),queue;
  for(int t=0;t<n;t++){
    fill(W.begin(),W.end(),0);queue.clear();
    for(int r=0;r<n;r++)for(int c=0;c<n;c++)rem[2*(r*n+c)+1]=deg[c]+1;
    for(int c=0;c<n;c++)for(int turn=0;turn<2;turn++){
      int z=2*(t*n+c)+turn;W[z]=1;queue.push_back(z);
    }
    for(size_t h=0;h<queue.size();h++){
      int z=queue[h],r=z/(2*n),c=z/2%n;
      if(z%2){
        for(int s:prev[r]){
          int q=2*(s*n+c);
          if(s!=c&&!W[q]){W[q]=1;queue.push_back(q);}
        }
      }else{
        for(int p:prev[c]){
          int q=2*(r*n+p)+1;
          if(r!=p&&!W[q]&&--rem[q]==0){W[q]=1;queue.push_back(q);}
        }
      }
    }
    for(int s=0;s<n;s++)if(s!=t&&!(rowmask[s]>>t&1)){
      bool guaranteed=true;
      for(int c=0;c<n;c++)if(c!=s&&!W[2*(s*n+c)])guaranteed=false;
      ans+=guaranteed;
    }
  }
  return ans;
}

bool source_blocked(int s,int assigned){
  int nonsinks=0;for(int z=0;z<n;z++)if(deg[z]>0&&(rowmask[s]>>z&1))nonsinks++;
  if(nonsinks<2)return true;
  for(int c=0;c<assigned;c++)if(c!=s)
    if((rowmask[s]&~(rowmask[c]|(1<<c)))==0)return true;
  return false;
}

bool live_possible(int row){
  int future=0,positive=0;
  for(int u=0;u<n;u++)if(deg[u]>0){positive|=1<<u;if(u>=row)future|=1<<u;}
  int incoming_possible=0;
  for(int u=0;u<n;u++)if(pred[u]||(future&~(1<<u)))incoming_possible|=1<<u;
  int viable[20],columns=0,blocked[20]{};
  for(int t=0;t<n;t++){
    viable[t]=(pred[t]|(future&~(1<<t)))&incoming_possible;
    if(__builtin_popcount((unsigned)viable[t])>=2)columns|=1<<t;
  }
  for(int c=0;c<row;c++)for(int t=0;t<n;t++)if(columns>>t&1)
    if(!(viable[t]&~(rowmask[c]|(1<<c))))blocked[c]|=1<<t;
  int total=0;
  for(int s=0;s<n;s++)if(deg[s]>=2){
    if(s<row&&source_blocked(s,row))continue;
    if(__builtin_popcount((unsigned)(positive&~(1<<s)))<2)continue;
    int candidates=columns&~(1<<s);
    if(s<row)candidates&=~rowmask[s];
    for(int c=0;c<row;c++)if(c!=s)candidates&=~blocked[c];
    total+=min(n-1-deg[s],__builtin_popcount((unsigned)candidates));
  }
  return total>=T;
}

bool possible(int row){
  int sumrows=0,qcap=0;
  for(int s=0;s<n;s++)if(deg[s]>=2&&(s>=row||!source_blocked(s,row))){
    sumrows+=n-1-deg[s];qcap++;
  }
  if(sumrows<T)return false;
  int cost[20],cost_count=0,column=0,budget_left=0;
  for(int s=row;s<n;s++)budget_left+=deg[s];
  for(int t=0;t<n;t++){
    int d=__builtin_popcount((unsigned)pred[t]);
    if(d+n-row-(t>=row)>=2){
      column+=n-1-max(2,d);cost[cost_count++]=max(0,2-d);
    }
  }
  if(column<T)return false;
  sort(cost,cost+cost_count);
  int rcap=0;
  for(int j=0;j<cost_count;j++){
    if(cost[j]>budget_left)break;
    budget_left-=cost[j];rcap++;
  }
  return incidence[qcap][rcap]>=T && live_possible(row);
}

void recurse(int row){
  if(!complete||found)return;
  if((++nodes%65536)==0&&chrono::duration<double>(chrono::steady_clock::now()-began).count()>limit){complete=false;return;}
  if(!possible(row))return;
  if(row==n){
    leaves++;int bound=0;
    for(int s=0;s<n;s++)if(deg[s]>=2&&!source_blocked(s,n))
      for(int t=0;t<n;t++)if(t!=s&&!(rowmask[s]>>t&1)&&__builtin_popcount((unsigned)pred[t])>=2){
        bool blocked=false;
        for(int c=0;c<n;c++)if(c!=s)
          if((pred[t]&~(rowmask[c]|(1<<c)))==0){blocked=true;break;}
        bound+=!blocked;
      }
    if(bound<T)return;
    survivors++;int value=delivery_count();
    cout<<"{\"kind\":\"leaf\",\"n\":"<<n<<",\"m\":"<<lo<<",\"I\":"<<value<<",\"delivery_masks\":[";
    for(int u=0;u<n;u++)cout<<(u?",":"")<<rowmask[u];cout<<"]}\n";
    if(value>best){best=value;copy(rowmask,rowmask+n,best_rows);}
    found|=value>=T;return;
  }
  for(int mask:opts[row][deg[row]]){
    bool ok=true;
    for(int v=row+2;v<n;v++)
      if(deg[v-1]==deg[v]&&pred[v-1]==pred[v]&&(mask>>(v-1)&1)&&!(mask>>v&1)){ok=false;break;}
    if(!ok)continue;
    rowmask[row]=mask;
    for(int v=0;v<n;v++)if(mask>>v&1)pred[v]|=1<<row;
    recurse(row+1);
    for(int v=0;v<n;v++)pred[v]&=~(1<<row);
    if(!complete||found)return;
  }
}

void profiles(int row,int largest,int total){
  if(!complete||found)return;
  if(row==n){
    if(total<lo||total>hi)return;
    int id=profile++;
    if(id>=begin_profile&&id<end_profile){checked_profiles++;recurse(0);}
    return;
  }
  int active=(T+n-4)/(n-3);
  for(int d=largest;d>=0;d--){
    if(row<active&&d<2)break;
    if(total+d>hi)continue;
    if(total+d*(n-row)<lo)break;
    deg[row]=d;profiles(row+1,d,total+d);
  }
}

int main(int argc,char**argv){
  if(argc<6||argc>8)return 2;
  n=atoi(argv[1]);T=atoi(argv[2]);lo=atoi(argv[3]);hi=atoi(argv[4]);limit=atof(argv[5]);
  begin_profile=argc>6?atoi(argv[6]):0;end_profile=argc>7?atoi(argv[7]):100000;
  if(n!=8||T<1||lo<0||hi<lo||hi>n*(n-1)||limit<=0||limit>60||begin_profile<0||end_profile<begin_profile)return 2;
  all=(1<<n)-1;
  for(int q=0;q<=n;q++)for(int r=0;r<=n;r++){
    int value=q*r-max(0,q+r-n)-max(0,2*q+2*r-hi);
    if(q)value=max(value,incidence[q-1][r]);
    if(r)value=max(value,incidence[q][r-1]);
    incidence[q][r]=value;
  }
  for(int u=0;u<n;u++)for(int mask=all;mask>=0;mask--)
    if(!(mask>>u&1))opts[u][__builtin_popcount((unsigned)mask)].push_back(mask);
  profiles(0,n-1,0);
  cout<<"{\"n\":"<<n<<",\"target_I\":"<<T<<",\"min_m\":"<<lo<<",\"max_m\":"<<hi
      <<",\"incidence_cap\":\"maximum over both live dimensions\",\"complete\":"<<(complete&&!found?"true":"false")
      <<",\"counterexample_found\":"<<(found?"true":"false")<<",\"first_profile\":"<<begin_profile
      <<",\"last_profile_exclusive\":"<<end_profile<<",\"total_profiles\":"<<profile
      <<",\"checked_profiles\":"<<checked_profiles<<",\"nodes\":"<<nodes<<",\"leaves\":"<<leaves
      <<",\"static_survivors\":"<<survivors<<",\"best_I\":"<<best
      <<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-began).count()<<",\"arcs\":[";
  bool first=true;
  if(best)for(int s=0;s<n;s++)for(int t=0;t<n;t++)if(best_rows[s]>>t&1){
    if(!first)cout<<",";first=false;cout<<"["<<s<<","<<t<<"]";
  }
  cout<<"]}\n";
}

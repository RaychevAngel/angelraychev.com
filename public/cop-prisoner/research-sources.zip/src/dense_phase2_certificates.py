#!/usr/bin/env python3
"""Literal independent finite verification of phase2 dense witnesses."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
ROWS=((4,8),(9,10),(8,9),(7,10),(0,1),(2,6),(3,5),(3,4),(2,7),(0,5),(1,6))

def check(n,base,optional):
    """Set operations and actual legal moves, no imported bit-mask verifier."""
    full=set(base)|set(optional)
    assert len(set(base))==2*n
    assert not(set(base)&set(optional))
    assert all(0<=s<n and 0<=t<n and s!=t for s,t in full)
    bo=[{t for a,t in base if a==s} for s in range(n)]
    legal=[{v for v in range(n) if (s,v) not in full} for s in range(n)]
    witness=[]
    for s,t in sorted(full):
        for c in range(n):
            if c==s:continue
            options={u for u in bo[c] if u in legal[s] and t in legal[u]}
            assert options,(n,s,t,c)
            u=min(options)
            assert u!=c and u not in legal[c]
            assert all(d!=u and t in legal[u] for d in legal[c])
            witness.append((s,t,c,u))
    return witness

def main():
    core={(s,t) for s,row in enumerate(ROWS) for t in row}
    cw=check(11,core,set())
    danger=[]
    for s,t in sorted(core):
        d=set(ROWS[s])|{a for a,b in core if b==t}
        blocked=[c for c,row in enumerate(ROWS) if set(row)<=d]
        assert blocked==[s]
        danger.append({'s':s,'t':t,'danger':sorted(d),'blocked_rows':blocked})
    receipt={'core':{'n':11,'arcs':sorted(core),'witnesses':cw,'danger_checks':danger},'odd_envelopes':[]}
    for x in json.loads((ROOT/'research/dense-phase2-odd-envelopes.json').read_text()):
        b={tuple(a) for a in x['base']};o={tuple(a) for a in x['optional']}
        assert len(o)==x['n']
        w=check(x['n'],b,o)
        receipt['odd_envelopes'].append({'n':x['n'],'witnesses':w})
    (ROOT/'research/dense-phase2-certificates.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('Verified11-core and4 odd robust envelopes by literal legal-move sets.')

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Export retained finite circles using one-recipient source ranks.

Six-clause ranks are produced by the published four-update propagation,
not a graph/game search. Every exported rank and exact count is kernel checked.
"""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'research/six-circle-recipes.json'

def ranks(row):
    n,C=row['n'],set(row['C'])
    if row['kind']=='finite-source-ranks':return row['rank_t0']
    h=row['h']; rank={0:0,**{(-d)%n:1 for d in C}}
    for j in range(n):
        w=-(j+1)*h
        for x,ds in [(2-h,(h,h-3,h-2)),(-h,(h,h-2,h+2)),(-h-1,(h,1,h+1)),(-h-2,(h,1,h+1))]:
            children=[(w+x+d)%n for d in ds]
            level=1+max(rank[z] for z in children)
            s=(w+x)%n
            rank[s]=min(rank.get(s,level),level)
    assert len(rank)==n
    return [rank[s] for s in range(n)]

def tree(values,lo=0):
    if len(values)==1:return str(values[0])
    mid=len(values)//2
    return f'(if s.val < {lo+mid} then {tree(values[:mid],lo)} else {tree(values[mid:],lo+mid)})'

def export():
    sha=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    modules=[];records=[]
    for i,row in enumerate(json.loads(SOURCE.read_text())['rows']):
        n=row['n']
        if n<19:continue
        C,A=row['C'],row['A'];R=ranks(row)
        for s in range(1,n):
            if (-s)%n in C:assert R[s]>=1;continue
            for c in range(n):
                if c!=s:assert any(R[(s+d)%n]<R[s] and (s+d-c)%n not in A for d in C),(i,s,c)
        name=f'SixCircleFinite{i:02d}';modules.append(name)
        text=f'''import CircularSourceRanks
/- Retained row {i} of research/six-circle-recipes.json.
Source SHA256: {sha}.
Ranks are supplied data, checked against every cop location at recipient zero;
CircularSourceRanks.rotate_ranks proves all recipients by rotation. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open CircularSourceRanks RobustLayers Extremal FiniteGame
 def core : List Nat := {str(C).replace(' ', '')}
 def envelope : List Nat := {str(A).replace(' ', '')}
 def rank (s : Fin {n}) : Nat := {tree(R)}
 theorem subset : ∀ d∈core, d∈envelope := by decide +kernel
 theorem local_checked : Checked (n:={n}) (by decide) core envelope rank := by
   unfold Checked
   decide +kernel
 theorem checked : SourceRanks (arc core) (arc envelope) (⟨0,by decide⟩ : Fin {n}) rank :=
   checked_ranks (by decide) core envelope rank local_checked
 theorem counts : arcCount (arc (n:={n}) core)={row['m_min']} ∧
     arcCount (arc (n:={n}) envelope)={row['m_max']} := by
   constructor <;> rw [arcCount_eq] <;> decide +kernel
 theorem maximum {{m : Nat}} (low : {row['m_min']}≤m) (high : m≤{row['m_max']}) :
     IsMaximum {n} m ({n*(n-1)}-m) :=
   CircularSourceRanks.maximum (by decide) core envelope rank subset checked
     (counts.1 ▸ low) (counts.2 ▸ high)
 #print axioms maximum
end Delivery.{name}
'''
        (ROOT/'lean'/f'{name}.lean').write_text(text)
        records.append(dict(module=name,n=n,lo=row['m_min'],hi=row['m_max'],ranks=R))
    (ROOT/'lean/SixCircleFinite.lean').write_text('\n'.join('import '+m for m in modules)+'\n')
    (ROOT/'tmp/lean-continuation/six-circle-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
    print(f'{len(modules)} finite circle recipes, {sum(r["n"] for r in records)} source ranks')
if __name__=='__main__':export()

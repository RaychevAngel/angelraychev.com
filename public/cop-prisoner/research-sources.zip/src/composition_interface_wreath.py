#!/usr/bin/env python3
"""A4-lamp wreath candidates: test whether internal noncommutativity helps."""
from pathlib import Path
import json,time,hashlib
from composition_interface_lifts import test
ROOT=Path(__file__).resolve().parents[1]
def group():
 g=(1,2,0,3);h=(1,3,2,0);G=[tuple(range(4))];ii={G[0]:0};aa=[];bb=[]
 for x in G:
  for gen,out in ((g,aa),(h,bb)):
   y=tuple(x[gen[i]] for i in range(4))
   if y not in ii:ii[y]=len(G);G.append(y)
   out.append(ii[y])
 return aa,bb
A,B=group()
def graph(k,mode):
 states=[(0,(0,)*k)];ii={states[0]:0};arcs=[]
 for c,lamps in states:
  for gen in range(2):
   ll=list(lamps);ll[c]=(A if gen==0 else B)[ll[c]]
   cc=(c+(gen==1 if mode=='one_rotates' else 1))%k;y=(cc,tuple(ll))
   if y not in ii:ii[y]=len(states);states.append(y)
   arcs.append((ii[(c,lamps)],ii[y]))
 return len(states),arcs
rr=[];start=time.monotonic()
for mode in ('one_rotates','both_rotate'):
 n,arcs=graph(2,mode);d=test(n,arcs,targets=[0]);d.update(mode=mode,k=2);rr.append(d);print({k:v for k,v in d.items() if k not in ('arcs','source_camps','checked_targets')},flush=True)
json.dump({'scope':'finite A4-lamp tests; no general preservation theorem','seconds':time.monotonic()-start,'records':rr,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},open(ROOT/'research/composition-interface-wreath.json','w'),indent=2)

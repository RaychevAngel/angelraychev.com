#!/usr/bin/env python3
"""Independent literal arena reconstruction and seven terminal/interface replays."""
from pathlib import Path
import gzip,json,hashlib,time
from routing_defect_phase2_navigation_audit import A,B,reduced,words
ROOT=Path(__file__).resolve().parents[1]
FORBIDDEN={(3,(),5),(3,(),9),(3,(2,),7),(3,(-2,),5),(3,(-2,),9),(4,(),0),
           (8,(),0),(8,(),4),(8,(1,),2),(8,(-1,),0),(8,(-1,),4),(9,(),5)}


def mirror(g):
    return {0:0,1:2,2:1,-1:-2,-2:-1}[g]


def good(mt,mw,cop):
    cw,ct,prefix=cop
    if cw is None:
        return True
    relative=reduced(tuple(-g for g in reversed(mw))+cw)
    return not (relative==() and mt==ct) and (mt,relative,ct) not in FORBIDDEN


def reconstruct(raw,branch_depth):
    M=[(tuple(w),t) for w,t in raw['messenger_positions']]
    C=[]
    for w,d in raw['cop_positions']:
        if w is not None:
            C.append((tuple(w),d,None))
        elif branch_depth:
            p,t=d
            C.append((None,t,tuple(p)))
        else:
            C.append((None,d,None))
    radius=max(len(w) for w,t in M)
    assert radius in (2,3)
    assert set(M)=={(w,t) for w in words(radius) for t in range(10)}
    prefixes=[p for p in words(2) if len(p)==2] if branch_depth else [None]
    assert set(C)=={(w,t,None) for w in words(3) for t in range(10)}|{(None,t,p) for p in prefixes for t in range(10)}
    assert len(M)==len(set(M)) and len(C)==len(set(C))
    mi={v:i for i,v in enumerate(M)}
    ci={v:i for i,v in enumerate(C)}
    moves=[]
    responses=[]
    for w,t in M:
        following={(w,t)}
        for g,j in [A[t],B[t]]:
            z=reduced(w+(g,)) if g else w
            if len(z)<=radius:
                following.add((z,j))
        moves.append({mi[v] for v in following})
    for w,t,prefix in C:
        following={(w,t,prefix)}
        for g,j in [A[t],B[t]]:
            if w is None:
                following.add((None,j,prefix))
                if g:
                    for z in words(3):
                        prior=reduced(z+(-g,))
                        if len(prior)>3 and (not branch_depth or prior[:2]==prefix):
                            following.add((z,j,None))
            else:
                z=reduced(w+(g,)) if g else w
                following.add((z,j,None) if len(z)<=3 else (None,j,z[:2] if branch_depth else None))
        responses.append(sum(1<<ci[v] for v in following))
    assert all(set(saved)==actual for saved,actual in zip(raw['messenger_moves'],moves))
    assert len(raw['messenger_moves'])==len(moves)
    assert [int(x,16) for x in raw['cop_masks']]==responses
    return M,C,mi,ci,moves,responses


def main():
    started=time.monotonic()
    archive=ROOT/'research/composition-interface-terminal-checkpoint-certificates.json.gz'
    receipt=json.loads((ROOT/'research/composition-interface-terminal-checkpoint-verification.json').read_text())
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt['archive_sha256']
    for path,h in receipt['source_sha256'].items():
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==h
    with gzip.open(archive,'rt') as f:
        raw=json.load(f)
    assert {(i,tuple(w),j) for i,w,j in raw['forbidden']}==FORBIDDEN
    for rule in [A,B]:
        for t,(g,j) in enumerate(rule):
            assert rule[(t+5)%10]==(mirror(g),(j+5)%10)
    assert {((i+5)%10,tuple(mirror(g) for g in w),(j+5)%10) for i,w,j in FORBIDDEN}==FORBIDDEN
    arenas={name:reconstruct(data,2 if name.startswith('branch2') else 0) for name,data in raw['arenas'].items()}
    specifications={
        'navigation_-1':('ordinary2',32,(-1,),None),
        'navigation_-2':('ordinary2',32,(-2,),None),
        'normalization':('ordinary2',2,None,None),
        'terminal_0':('branch0_m2',39,(1,),0),
        'terminal_1':('branch2_m3',62,(-1,),1),
        'terminal_3':('branch0_m3',35,(-1,-1),3),
        'terminal_4':('branch2_m3',38,(-1,),4),
    }
    results=[]
    for item in raw['records']:
        name=item['name']
        arena_name,bound,goalword,targettype=specifications[name]
        assert item['arena']==arena_name and item['moves']==bound
        M,C,mi,ci,moves,responses=arenas[arena_name]
        allc=(1<<len(C))-1
        terminal={mi[(goalword,targettype)]} if targettype is not None else set()
        seeds=[]
        for r,(mw,mt) in enumerate(M):
            if terminal:
                seed=allc if r in terminal else 0
            else:
                allowed_cell=(goalword is None or mw==goalword)
                seed=sum(1<<c for c,cop in enumerate(C) if good(mt,mw,cop)) if allowed_cell else 0
            seeds.append(seed)
        layers=[[int(x,16) for x in layer] for layer in item['layers']]
        assert len(layers)==bound+1 and all(len(row)==len(M) for row in layers)
        assert layers[0]==seeds
        required=[]
        for r,(mw,mt) in enumerate(M):
            if mw!=():
                continue
            for c,cop in enumerate(C):
                okay=(cop!=((),mt,None)) if name=='normalization' else good(mt,mw,cop)
                if okay:
                    required.append((r,c))
        assert len(required)==item['required_starts']
        assert all(layers[-1][r]>>c&1 for r,c in required)
        checked=0
        for previous,current in zip(layers,layers[1:]):
            for r,(mw,mt) in enumerate(M):
                assert previous[r]&~current[r]==0 and current[r]&~allc==0
                if r not in terminal:
                    assert not (current[r]>>ci[(mw,mt,None)]&1)
                new=current[r]&~previous[r]
                while new:
                    bit=new&-new
                    new-=bit
                    c=bit.bit_length()-1
                    assert any(v in terminal or (C[c]!=(M[v][0],M[v][1],None) and responses[c]&~previous[v]==0) for v in moves[r]),(name,r,c)
                    checked+=1
        assert checked==item['new_states_directly_checked']
        results.append({'name':name,'moves':bound,'required_starts':len(required),'new_states':checked})
    assert len(results)==7 and {r['name'] for r in results}==set(specifications)
    output={'verified':True,'scope':'Independent literal reconstruction of all ordinary/branch arenas; all seven complete saved-layer replays; exact lane-rule and interface symmetry. Finite-quotient projection audited separately; types2/7 not proved.',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'helper_sha256':hashlib.sha256((ROOT/'src/routing_defect_phase2_navigation_audit.py').read_bytes()).hexdigest(),
            'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'original_hashes_match':True,'seconds':time.monotonic()-started,'records':results,
            'new_states_total':sum(r['new_states'] for r in results)}
    (ROOT/'research/composition-interface-terminal-independent-audit.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output))


if __name__=='__main__':
    main()

#!/usr/bin/env python3
"""All-order robust dense envelope from a ten-divisible core and mixed rows."""
from dense_unified_core import even_core,robust_check
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def envelope(n):
    assert n>=30
    q,s=divmod(n,10);k=5*q
    b=even_core(k)
    d=set(range(10,k,5));e=set(range(5,k,5))
    o={(i,(i+a)%k) for i in range(k) for a in d}
    o|={(k+i,k+(i+a)%k) for i in range(k) for a in e}
    for a in range(s):b.update(((2*k+a,a),(2*k+a,k+(a+3)%k)))
    o|={(2*k+a,2*k+c) for a in range(s) for c in range(s) if a!=c}
    assert len(b)==2*n and b.isdisjoint(o)
    assert len(b|o)==10*q*q+5*q+s*s+s
    return b,o

def main():
    rows=[]
    for n in range(30,201):
        b,o=envelope(n);checked=robust_check(n,b,o)
        old=n*max(3,(n+11)//13)
        assert len(b|o)>=old,(n,len(b|o),old)
        rows.append({'n':n,'h':len(b|o),'old_h':old,'triples':checked})
    receipt={'rows':rows,'status':'verified finite check; ordinary proof separate'}
    (ROOT/'research/dense-phase2-uniform-envelope.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('verified',len(rows),'orders30..200, all dominate old protected dense cap')

if __name__=='__main__':main()

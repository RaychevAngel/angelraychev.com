#!/usr/bin/env python3
"""Independent complete prefix exclusion using explicit camping witnesses.

No game solver or primary-enumerator imports. Every rejected partial graph
records either a killed two-pair source row or two killed recipient pairs.
"""
from __future__ import annotations
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def obstruction(rows, n):
    for s,row in enumerate(rows):
        for c,other in enumerate(rows):
            if c != s and set(other) <= set(row) | {s}:
                return {'kind':'source_camping','source':s,'cop':c,
                        'failed_pairs':[[s,t] for t in row]}
    for c,row in enumerate(rows):
        for target in range(n):
            if all(u < len(rows) and target in rows[u] for u in row):
                # Both u->target pairs are missing and u != c.
                return {'kind':'recipient_camping','recipient':target,'cop':c,
                        'failed_pairs':[[u,target] for u in row]}
    return None


def enumerate_order(n):
    candidates = [list(itertools.combinations([v for v in range(n) if v != s],2))
                  for s in range(n)]
    cases = []
    for mutual,initial in [(False,[(1,2),(3,4),(5,6)]),
                           (True,[(1,2),(0,3),(4,5)])]:
        nodes = 0
        rejected = []
        surviving = []
        def visit(rows):
            nonlocal nodes
            nodes += 1
            reason = obstruction(rows,n)
            if reason is not None:
                rejected.append({'rows':rows,'witness':reason})
                return
            if len(rows) == n:
                surviving.append(rows)
                return
            for row in candidates[len(rows)]:
                visit(rows+[row])
        visit(initial)
        cases.append({'mutual_at_zero':mutual,'prefix_nodes':nodes,
                      'rejected_prefixes':rejected,'surviving_graphs':surviving})
    return {'n':n,'cases':cases,'complete':True,
            'survivors':sum(len(case['surviving_graphs']) for case in cases)}


def main():
    # Independent literal positive control: the known nine-core satisfies
    # every necessary condition; the filter does not exclude actual cores.
    core = [(1,3),(4,7),(5,6),(0,2),(6,8),(2,8),(0,4),(1,5),(3,7)]
    assert obstruction(core,9) is None
    order = [0,3,1,2,4,7,5,6,8]
    index = {v:i for i,v in enumerate(order)}
    normalized = [tuple(sorted(index[t] for t in core[s])) for s in order]
    assert normalized[:3] == [(1,2),(0,3),(4,5)]
    assert all(obstruction(normalized[:length],9) is None for length in range(3,10))
    results = [enumerate_order(n) for n in (7,8)]
    assert all(row['survivors'] == 0 for row in results)
    proof = {'schema_version':1,'scope':'Complete normalized two-out missing graphs at orders 7 and 8. Each rejected prefix has two distinct failed missing pairs from an ordinary camping argument.',
             'positive_control':normalized,'orders':results}
    path = ROOT/'research/small-dense-endpoint-independent-tree.json'
    text = json.dumps(proof,separators=(',',':'))+'\n'
    path.write_text(text)
    report = {'status':'complete','orders':[{'n':r['n'],'survivors':r['survivors'],
                  'prefix_nodes':sum(c['prefix_nodes'] for c in r['cases']),
                  'rejected_prefixes':sum(len(c['rejected_prefixes']) for c in r['cases'])}for r in results],
              'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'primary_source_sha256':hashlib.sha256((ROOT/'src/small_dense_endpoint_enumeration.cpp').read_bytes()).hexdigest(),
              'tree':str(path.relative_to(ROOT)),'tree_sha256':hashlib.sha256(text.encode()).hexdigest(),
              'upper_bounds':[[7,28,12],[8,40,14]],
              'boundary':'Degree-one missing rows force at least two losses; otherwise missing budget 2n forces outdegree exactly two. The complete tree excludes every two-out graph without two camping losses. No game enumeration or indegree assumption is used.'}
    (ROOT/'research/small-dense-endpoint-independent-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['orders']))


if __name__ == '__main__':main()

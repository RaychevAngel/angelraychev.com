"""Instantiate saved finite two-regular defects in the cyclic five-type graph."""
from pathlib import Path
import json
from five_type_policy import family

ROOT=Path(__file__).resolve().parents[1]

def graph(k,extra):
    n,a,b,out,base=family(k)
    if extra==0:return n,base
    patch=next(p for p in json.loads((ROOT/'research/five-type-local-defect-patches.json').read_text())['patches']if p['extra']==extra)
    def vertex(v):return n+v[1]if v[0]=='extra'else 5*(v[0]%k)+v[1]
    removed={(vertex(u),vertex(v))for u,v in patch['removed_arcs']}
    added={(vertex(u),vertex(v))for u,v in patch['added_arcs']}
    assert removed<=set(base)
    arcs=sorted((set(base)-removed)|added)
    assert all(u!=v for u,v in arcs)
    assert len(arcs)==2*(n+extra)
    assert all(sum(u==x for u,v in arcs)==2 and sum(v==x for u,v in arcs)==2 for x in range(n+extra))
    return n+extra,arcs

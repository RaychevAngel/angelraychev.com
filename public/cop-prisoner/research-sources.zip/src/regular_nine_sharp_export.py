#!/usr/bin/env python3
"""Render complete regular-nine DAGs as ordinary kernel-checked Lean proofs."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from lean_finite_regular_producer import function, literal

def tuples(xs): return '['+','.join('('+','.join(map(str,x))+')' for x in xs)+']'
def table(v): return '⟨'+','.join(str((v>>(9*i))&511) for i in range(9))+'⟩'

def export(source,out,size):
    data=json.loads(source.read_text()); parts=data['partition']; a=data['a']; nodes=data['nodes']
    key='x'.join(map(str,parts)); prefix='RegularNineSharp'+key
    ns='Delivery.FiniteExclusion.Sharp'+key
    out.mkdir(parents=True,exist_ok=True)
    auts=sorted({int(tr) for node in nodes if node['kind']=='branch'
                 for idx,tr in node['children'].values() if tr!=data['identity']})
    base='import FiniteExclusionBoolean\nimport FiniteExclusionPrefixConjugacy\n'
    base+='set_option maxRecDepth 65536\nset_option maxHeartbeats 20000000\n'
    base+=f'namespace {ns}\nopen Bounds BoundTreeRows Extremal\n'+function('a',a)
    for i in auts:
        f,g=data['automorphisms'][i]; base+=function(f'f{i}',f)+function(f'g{i}',g)
        base+=f'def aut{i} : Conjugacy a a where\n  toFun := f{i}\n  invFun := g{i}\n'
        base+='  left_inv := by decide +kernel\n  right_inv := by decide +kernel\n  commute := by decide +kernel\n\n'
    base+=f'end {ns}\n'
    (out/f'{prefix}Base.lean').write_text(base)
    files=[f'{prefix}Base.lean']
    for offset in range(0,len(nodes),size):
        chunk=nodes[offset:offset+size]; number=offset//size
        deps=sorted({int(idx)//size for node in chunk if node['kind']=='branch'
                     for idx,tr in node['children'].values() if int(idx)//size<number})
        s=f'import {prefix}Base\n'+''.join(f'import {prefix}C{j:03d}\n' for j in deps)
        s+='set_option maxRecDepth 65536\nset_option maxHeartbeats 20000000\n'
        s+=f'namespace {ns}\nopen Bounds BoundTreeRows Extremal\n'
        for node in chunk:
            idx=node['id']; p=node['prefix']; pl=literal(p); kind=node['kind']
            if kind in ('camp','leaf'):
                fields=[table(node['allowed']),tuples(node['sources']),tuples(node['recipients'])]
                if kind=='leaf':
                    fields += [table(node['upper']),table(node['lower']),
                               '['+','.join('⟨'+str(t)+','+str(mask)+','+table(good)+'⟩'
                                            for t,mask,good in node['losses'])+']']
                typ='Local' if kind=='camp' else 'Leaf'
                s+=f'def cert{idx} : {typ} := ⟨'+','.join(fields)+'⟩\n'
                sound='local_sound' if kind=='camp' else 'Boolean.leaf_sound'
                proof=f'{sound} a {pl} 30 cert{idx} (by decide +kernel)'
            else:
                terms=[]
                for v in range(9):
                    raw=p+[v]; rl=literal(raw)
                    if str(v) not in node['children']:
                        terms.append(f'(invalid_upper a {rl} 30 (by decide +kernel))')
                    else:
                        child,tr=node['children'][str(v)]; q=nodes[child]['prefix']
                        assert child<idx
                        if tr==data['identity']:
                            assert raw==q; terms.append(f'node{child}')
                        else:
                            terms.append(f'(PrefixConjugacy.upper aut{tr} {rl} {literal(q)} 30 (by decide +kernel) node{child})')
                proof=f'branch_upper a {pl} 30 (by decide) (fin9_cases _\n  '+'\n  '.join(terms)+')'
            s+=f'theorem node{idx} : UpperPrefix a {pl} 30 :=\n  {proof}\n\n'
        s+=f'#print axioms node{chunk[-1]["id"]}\nend {ns}\n'
        name=f'{prefix}C{number:03d}.lean'; (out/name).write_text(s); files.append(name)
    final=f'import {prefix}C{(len(nodes)-1)//size:03d}\nnamespace {ns}\nopen Extremal\n'
    final+=f'theorem upper (b : Assignment 9) (valid : Valid a b) : score (edgeOf a b)≤30 :=\n'
    final+=f'  node{data["root"]} b valid (by intro i h; simp at h)\n'
    final+=f'#print axioms upper\nend {ns}\n'
    name=f'{prefix}.lean'; (out/name).write_text(final); files.append(name)
    manifest=dict(input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  exporter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  partition=parts,counts=data['counts'],automorphisms=len(auts),
                  modules={f:hashlib.sha256((out/f).read_bytes()).hexdigest() for f in files})
    (out/f'{prefix}.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({k:v for k,v in manifest.items() if k!='modules'}|{'modules':len(files)}))

def main():
    p=argparse.ArgumentParser(); p.add_argument('source',type=Path)
    p.add_argument('--out',type=Path,required=True); p.add_argument('--chunk-size',type=int,default=48)
    args=p.parse_args(); export(args.source,args.out,args.chunk_size)

if __name__=='__main__': main()

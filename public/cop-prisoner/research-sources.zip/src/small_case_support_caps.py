#!/usr/bin/env python3
"""Replay finite support cutoffs and their literal comparison witnesses.

Two independent integer implementations are compared. The additional
20-arrow support13 exclusion is an ordinary argument in Corollary60.1.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
from game_solver import solve_graph
from small_case_certificate_review import review
from small_sparse_support import residual_profiles

ROOT = Path(__file__).resolve().parents[1]
INDEPENDENT = 'research/small-case-support-review-2026-09-13.py'


def main():
    spec = importlib.util.spec_from_file_location('independent_support',ROOT/INDEPENDENT)
    independent = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(independent)
    sources = ['src/small_sparse_support.py',INDEPENDENT,
               'src/small_case_support_caps.py','src/small_case_certificate_review.py',
               'paper/support-concentration.md','research/small-case-support-review-2026-09-13.md',
               'research/small-arcs-twelve-thirteen-witnesses.json',
               'research/sparse-third-fixed-lower-certificates.json',
               'research/small-plateau-witness-catalogue.json',
               'research/small-sparse-regular-10-witness.json',
               'research/small-plateau-tiny-m13-witness.json',
               'research/small-case-host-compression-review.json',
               'research/small-sparse-twenty-host-compression.md']
    witnesses = {x['m']:x['certificate'] for x in json.loads((ROOT/'research/small-arcs-twelve-thirteen-witnesses.json').read_text())['cases']}
    witnesses[13] = json.loads((ROOT/'research/small-plateau-tiny-m13-witness.json').read_text())
    old = json.loads((ROOT/'research/sparse-third-fixed-lower-certificates.json').read_text())
    witnesses[18] = next(g for g in old if g['m']==18)
    witnesses[19] = solve_graph(11,witnesses[18]['arcs']+[[9,10]],crosscheck=True,certificates=True)
    witnesses[20] = json.loads((ROOT/'research/small-sparse-regular-10-witness.json').read_text())
    catalogue = json.loads((ROOT/'research/small-plateau-witness-catalogue.json').read_text())
    for m,n in [(14,7),(15,7),(16,8),(17,8),(21,11)]:
        record = next(x for x in catalogue['records'] if (x['n'],x['m'])==(n,m))
        sources.append(record['certificate'])
        witnesses[m] = json.loads((ROOT/record['certificate']).read_text())
    rows = []
    for m,g in sorted(witnesses.items()):
        literal = review(g)
        primary = residual_profiles(m,g['I'])
        other = independent.review(m,g['I']+1)
        support = primary['maximum_nonisolated_support']
        assert support == other['maximum_permitted_nonisolated_support']
        assert primary['surviving_active_profiles'] == other['surviving_q_r_b_profiles']
        sharpened = support
        if m==20:
            assert support==13 and len(primary['maximum_support_profiles'])==1
            p=primary['maximum_support_profiles'][0]
            assert [p[k] for k in ('q','r','b','z','o','i')]==[9,9,9,4,2,2]
            sharpened=12
        cutoff=max(g['n'],sharpened)
        if m==20:
            compression=json.loads((ROOT/'research/small-case-host-compression-review.json').read_text())
            assert compression['verified'] and compression['tuples']==16
            cutoff=11
        rows.append({'m':m,'lower':g['I'],'witness_order':g['n'],
                     'arithmetic_strict_support':support,'strict_support':sharpened,
                     'universal_host_cutoff':cutoff,
                     'active_profiles':primary['surviving_active_profiles'],
                     'literal_review':literal})
    assert [r['universal_host_cutoff'] for r in rows]==[12,13,16,18,15,18,15,18,11,15]
    output = 'research/small-case-support-witnesses.json'
    (ROOT/output).write_text(json.dumps([witnesses[m] for m in sorted(witnesses)],separators=(',',':'))+'\n')
    sources.append(output)
    report = {'verified':True,'scope':'M(n,m)=M(min(n,B_m),m) with isolate lifting of attainers; compare actual saved lower witnesses against strict-improvement support.',
              'boundary':'Independent necessary-integer replays and ordinary support13 exclusion, not a complete extremal graph enumeration or Lean formalization.',
              'rows':rows,'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources}}
    (ROOT/'research/small-case-support-cutoffs.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'verified':True,'cutoffs':[(r['m'],r['universal_host_cutoff']) for r in rows]}))


if __name__=='__main__':
    main()

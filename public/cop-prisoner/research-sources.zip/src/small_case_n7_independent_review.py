#!/usr/bin/env python3
"""Check the complete n7 replay receipt and its numerical incidence bounds."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    primary = json.loads((ROOT / 'research/small-case-n7-primary.json').read_text())
    replay = json.loads((ROOT / 'research/small-case-n7-independent.json').read_text())
    assert replay['verified'] and len(replay['records']) == len(primary['records']) == 20
    assert [r['m'] for r in replay['records']] == [r['m'] for r in primary['records']]
    primary_complete = 0
    for old, new in zip(primary['records'], replay['records']):
        assert new['n'] == 7 and new['exact_by_independent']
        final = new['runs'][-1]
        assert final['complete'] and not final['counterexample_found']
        assert final['target_I'] == new['lower'] + 1
        assert final['min_m'] == final['max_m'] == new['m']
        assert final['first_profile'] == 0
        assert final['checked_profiles'] == final['total_profiles']
        # A complete primary target exclusion is present only for eighteen cells.
        completed = old.get('exact', old.get('exact_by_primary', False))
        if completed:
            assert old['lower'] == new['lower']
            primary_complete += 1
    assert primary_complete == 18

    table_checks = 0
    for m in range(43):
        f = lambda q, r: q*r-max(0, q+r-7)-max(0, 2*q+2*r-m)
        table = [[0]*8 for _ in range(8)]
        for q in range(8):
            for r in range(8):
                table[q][r] = max(f(q, r), table[q-1][r] if q else f(q,r),
                                  table[q][r-1] if r else f(q,r))
                assert table[q][r] == max(f(i,j) for i in range(q+1) for j in range(r+1))
                table_checks += 1
        for r in range(3,8):
            assert all(f(q+1,r) >= f(q,r) for q in range(7))
        if m >= 18:
            for r in range(3):
                assert all(f(q+1,r) >= f(q,r) for q in range(7))

    paths = ['src/small_case_n7_independent.cpp',
             'src/small_arcs_sparse_independent.cpp',
             'src/small_case_n7_independent_run.py',
             'src/small_case_n7_independent_review.py',
             'research/small-case-n7-primary.json',
             'research/small-case-n7-independent.json',
             'research/small-case-n7-independent-review.md',
             'research/small-case-n7-neighbor-m22-certificate.json',
             'research/small-case-n7-neighbor-m23-certificate.json']
    hashes = {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
    assert hashes[paths[0]] == replay['source_sha256']
    assert hashes[paths[1]] == replay['historical_source_sha256']
    assert hashes[paths[2]] == replay['runner_sha256']
    assert hashes[paths[4]] == replay['primary_input_sha256']
    report = dict(verified=True, complete_budget_count=20,
                  matched_complete_primary_budget_count=primary_complete,
                  incidence_prefix_max_checks=table_checks,
                  search_nodes=sum(s['nodes'] for r in replay['records'] for s in r['runs']),
                  search_seconds=sum(s['seconds'] for r in replay['records'] for s in r['runs']),
                  uppers={str(r['m']): r['lower'] for r in replay['records']},
                  scope='Complete independent n7 target exclusions; ordinary source and symmetry audit in the paired note. Lower witnesses require their separate game-certificate replay.',
                  sha256=hashes)
    path = ROOT/'research/small-case-n7-independent-review.json'
    path.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='sha256'}, indent=2))


if __name__ == '__main__':
    main()

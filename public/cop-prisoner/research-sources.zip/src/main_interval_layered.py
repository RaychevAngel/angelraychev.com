#!/usr/bin/env python3
"""Direct three-move routing through twelve or fourteen hubs and guides.

Every exact budget in interval(n,g,r) has a concrete graph.  Distinct
equal-size subsets of guides encode the bulk vertices.  Optional arcs are
selected in lexicographic order; no game search is used by the constructor.
The ordinary proof is paper/main-interval-layered.md.  --check independently
checks the full asymmetric envelope, with base-only messenger moves.
"""
from functools import lru_cache
from itertools import combinations, islice
from math import comb
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
ACCESS = frozenset((0, 1, 4, 5, 7, 9, 11, 13))


def guide_codes(g, hubs=14):
    if hubs == 12:
        if not 2 <= g <= 8:
            raise ValueError('The twelve-hub core permits two through eight guides.')
        all_codes = [frozenset((6,8,10)),frozenset((7,9,11))]
        all_codes += [frozenset((i,i+3)) for i in range(3)]
        all_codes += [frozenset((6+i,9+i)) for i in range(3)]
        return all_codes[:g]
    if hubs != 14 or not 2 <= g <= 14:
        raise ValueError('The fourteen-hub core permits two through fourteen guides.')
    all_codes = [frozenset(7+(i+d) % 7 for d in (0, 2, 4)) for i in range(7)]
    all_codes += [frozenset((i+d) % 7 for d in (0, 1, 4)) for i in range(7)]
    return all_codes[:g]


def interval(n, g, r=2, hubs=14):
    if hubs not in (12,14) or not 2 <= r <= g <= (8 if hubs == 12 else 14):
        return None
    b = n-hubs-g
    if not 0 <= b <= comb(g,r):
        return None
    base = (106+22*g+(19+r)*b if hubs == 12
            else 154+25*g+(22+r)*b)
    return base, base+b*(g+b-1)


@lru_cache(maxsize=None)
def intervals(n):
    """All explicit parameter intervals, sorted by compulsory budget."""
    rows = []
    for hubs in (12,14):
        for g in range(2, 9 if hubs == 12 else 15):
            for r in range(2, g+1):
                bounds = interval(n, g, r, hubs)
                if bounds is not None:
                    rows.append({'n':n, 'hubs':hubs, 'g':g, 'r':r, 'b':n-hubs-g,
                                 'm_min':bounds[0], 'm_max':bounds[1]})
    return tuple(sorted(rows, key=lambda x:(x['m_min'], -x['m_max'], x['g'], x['r'])))


def parameters(n, m):
    for row in intervals(n):
        if row['m_min'] <= m <= row['m_max']:
            return row['g'], row['b'], m-row['m_min'], row['r'], row['hubs']
    raise ValueError('No layered-hub parameter interval covers this pair.')


def construction(g, b, added=0, r=2, hubs=14):
    n = hubs+g+b
    bounds = interval(n, g, r, hubs)
    if bounds is None or not 0 <= added <= bounds[1]-bounds[0]:
        raise ValueError('Invalid guide, bulk, weight, or optional-arrow count.')
    codes = guide_codes(g,hubs)
    k = hubs//2
    access = ACCESS if hubs == 14 else frozenset(set(range(12))-{0,3,6,8,10})
    guide_sets = list(islice(combinations(range(g),r),b))
    missing = {(u,v) for i in range(k) for u,v in (
        (i, k+i), (i, k+(i-1) % k),
        (k+i, (i+4) % k), (k+i, (i+6) % k))}
    base = {(u,v) for u in range(hubs) for v in range(hubs)
            if u != v and (u,v) not in missing}
    base.update((u,x) for u in range(hubs) for x in range(hubs,n))
    base.update((hubs+j,u) for j,K in enumerate(codes) for u in range(hubs) if u not in K)
    for j, chosen in enumerate(guide_sets):
        x = hubs+g+j
        base.update((x,u) for u in access)
        base.update((x,hubs+q) for q in chosen)
    optional = [(u,v) for u in range(hubs,n) for v in range(hubs+g,n) if u != v]
    assert len(base) == bounds[0]
    assert len(optional) == bounds[1]-bounds[0] and base.isdisjoint(optional)
    return {'n':n, 'hubs':hubs, 'g':g, 'b':b, 'r':r, 'm':bounds[0]+added,
            'm_interval':list(bounds), 'K':[sorted(S) for S in codes],
            'bulk_guide_sets':[list(S) for S in guide_sets],
            'bulk_hub_access':sorted(access), 'base':sorted(base),
            'optional':optional, 'arcs':sorted(base | set(optional[:added])),
            'maximum_delivery_moves':3}


def construct(n, m):
    return construction(*parameters(n,m))


def verify_envelope(graph):
    """Check the two-stage proof obligations directly from the arrow lists.

    All witnesses use base arrows, and avoid the cop's FULL optional
    closed neighborhood.  Hub/guide sources finish in two moves; bulk
    sources safely enter that layer and finish in one further stage.
    """
    n, g, hubs = graph['n'], graph['g'], graph['hubs']
    B = set(map(tuple, graph['base']))
    E = B | set(map(tuple, graph['optional']))
    out, pred, cop = [0]*n, [0]*n, [1<<v for v in range(n)]
    for u,v in B:
        out[u] |= 1<<v
        pred[v] |= 1<<u
    for u,v in E:
        cop[u] |= 1<<v
    top = (1<<(hubs+g))-1
    top_obligations, entry_obligations = 0, 0
    for s in range(hubs+g):
        for t in range(n):
            if s == t or (s,t) in B:
                continue
            mids = out[s] & pred[t]
            for c in range(n):
                if c == s:
                    continue
                assert mids & ~cop[c], (n,g,graph['r'],'two-move',s,t,c)
                top_obligations += 1
    for s in range(hubs+g,n):
        for c in range(n):
            if c == s:
                continue
            assert out[s] & top & ~cop[c], (n,g,graph['r'],'entry',s,c)
            entry_obligations += 1
    return {'two_move_obligations':top_obligations,
            'safe_entry_obligations':entry_obligations}


def run_checks():
    rows = []
    # Every guide count at full pair capacity exercises every guide pair.
    # Additional higher weights check the general equal-weight extension.
    examples = [(g,comb(g,2),2,14) for g in range(2,15)]
    examples += [(7,35,3,14),(8,20,4,14),(10,36,2,14),(11,55,2,14),(14,12,7,14)]
    examples += [(g,comb(g,r),r,12) for g in range(2,9) for r in range(2,g+1)]
    for g,b,r,hubs in examples:
        graph = construction(g,b,r=r,hubs=hubs)
        row = {'n':graph['n'],'hubs':hubs,'g':g,'b':b,'r':r,'m_interval':graph['m_interval']}
        row.update(verify_envelope(graph))
        for added in {0,len(graph['optional'])//2,len(graph['optional'])}:
            selected = construction(g,b,added,r,hubs)
            assert len(selected['arcs']) == selected['m']
        rows.append(row)
    assert interval(60,10) == (1268,2888)
    assert interval(80,11) == (1749,5324)
    assert interval(40,7,2,12) == (701,1268)
    assert interval(50,8,3,12) == (942,2052)
    files = ['src/main_interval_layered.py','paper/main-interval-layered.md']
    return {'verified':True,'rows':rows,
            'scope':'Independent direct arrow-list checks of the full asymmetric envelope. The ordinary proof covers every parameter; no new Lean claim.',
            'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files}}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('n',nargs='?',type=int)
    p.add_argument('m',nargs='?',type=int)
    p.add_argument('--check',action='store_true')
    p.add_argument('--out',type=Path)
    a = p.parse_args()
    result = run_checks() if a.check else construct(a.n,a.m)
    body = json.dumps(result,indent=2)+'\n'
    if a.out:
        a.out.write_text(body)
    else:
        print(body,end='')


if __name__ == '__main__':
    main()

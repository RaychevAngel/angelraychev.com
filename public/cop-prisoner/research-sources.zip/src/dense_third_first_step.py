#!/usr/bin/env python3
"""Bounded four-vertex first-step attachment search; fixed output only.

Does not assume that the base core or its extended strategies use two moves.
Its search output is a candidate list until both solvers/certificates replay.
"""
from __future__ import annotations
import itertools,json,time,argparse,hashlib
from pathlib import Path
from dense_third_core_compose import core9
from dense_unified_core import core
from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]
ATTACHMENTS={13:((1,2),(3,4)),14:((0,7),(1,8)),15:((0,3),(1,5))}


def extend(base,k,left,right):
    c,x,y,z=range(k,k+4)
    return base|{(c,x),(x,y),(x,z)}|{(y,t) for t in left}|{(z,t) for t in right}


def search():
    started=time.monotonic();results=[]
    for k in (9,10,11):
        n=k+4;base=core9() if k==9 else core(k)
        rows={tuple(sorted(t for s,t in base if s==v)) for v in range(k)}
        options=[p for p in itertools.combinations(range(k),2) if p not in rows]
        best=-1;trials=0;found=None
        for left,right in itertools.combinations(options,2):
            if time.monotonic()-started>20:break
            f=extend(base,k,left,right)
            g={(s,t) for s in range(n) for t in range(n) if s!=t and(s,t)not in f}
            result=solve_graph(n,g)
            trials+=1
            if result['I']>best:
                best=result['I'];print(n,trials,best,left,right,flush=True)
            if result['I']==2*n-3:
                result=solve_graph(n,g,crosscheck=True,certificates=True)
                found={'n':n,'m':n*(n-3)+1,'I':result['I'],
                       'attachment_rows':[left,right],'missing_arcs':sorted(f),
                       'game':result}
                break
        results.append({'n':n,'trials':trials,'best':best,'found':found})
    path=ROOT/'research/dense-third-first-step-search.json'
    path.write_text(json.dumps({'elapsed_seconds':time.monotonic()-started,
                               'scope':'Finite attachment search, no upper exclusion from failed templates',
                               'results':results},separators=(',',':'))+'\n')


def first_step(n):
    assert n in ATTACHMENTS
    k=n-4
    return extend(core9() if k==9 else core(k),k,*ATTACHMENTS[n])


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--search',action='store_true')
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    if args.search:
        assert not args.check
        search();return
    results=[]
    for n in ATTACHMENTS:
        f=first_step(n)
        g={(s,t) for s in range(n) for t in range(n) if s!=t and(s,t)not in f}
        result=solve_graph(n,g,crosscheck=True,certificates=True)
        assert len(f)==2*n-1
        assert result['I']==2*n-3
        results.append(result)
    certpath=ROOT/'research/dense-third-first-step-certificates.json'
    certtext=json.dumps(results,separators=(',',':'))+'\n'
    if args.check:assert certpath.read_text()==certtext
    else:certpath.write_text(certtext)
    receipt={'status':'verified',
             'proof_boundary':'Three fixed literal attachments checked by two independent actual-game solvers and complete alternating-state certificate replay. Not an exhaustive exclusion or a Lean theorem.',
             'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'attachment_rows':ATTACHMENTS,
             'verified_graphs':[[z['n'],z['m'],z['I'],z['max_state_delivery_moves']] for z in results],
             'certificates':str(certpath.relative_to(ROOT)),
             'certificate_sha256':hashlib.sha256(certpath.read_bytes()).hexdigest(),
             'certificate_states':sum(2*z['n']**3 for z in results)}
    path=ROOT/'research/dense-third-first-step-checks.json'
    text=json.dumps(receipt,indent=2)+'\n'
    if args.check:assert path.read_text()==text
    else:path.write_text(text)
    print(json.dumps({'graphs':len(results),'certificate_states':receipt['certificate_states']}))


if __name__=='__main__':main()

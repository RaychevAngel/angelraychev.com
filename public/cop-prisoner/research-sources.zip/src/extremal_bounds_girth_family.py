"""Explicit 4-regular girth-six graphs and degree-preserving vertex insertion.

The output is an independently replayable list of elementary operations. No
pursuit-game solver is needed for its structural certificate.
"""
import collections,json
from pathlib import Path

def base(copies=2):
    E=set()
    for h in range(copies):
        o=26*h
        for p in range(13):
            for d in (0,1,3,9):E.add((o+p,o+13+(p-d)%13))
    return 26*copies,E

def adjacency(n,E):
    a=[set() for _ in range(n)]
    for u,v in E:a[u].add(v);a[v].add(u)
    return a

def ball(a,seeds,radius):
    out=set(seeds);front=out.copy()
    for _ in range(radius):
        front=set.union(*(a[v] for v in front))-out if front else set()
        out|=front
    return out

def good_pair(n,E):
    a=adjacency(n,E)
    for e in sorted(E):
        near=ball(a,e,3)
        for f in sorted(E):
            if not(set(f)&near):return e,f
    return None

def insert(n,E,pair):
    e,f=pair;a,b=e;c,d=f
    assert len({a,b,c,d})==4
    a_old=adjacency(n,E)
    assert not(set(f)&ball(a_old,e,3))
    E=E-{tuple(sorted(e)),tuple(sorted(f))}|{tuple(sorted((v,n)))for v in(a,b,c,d)}
    return n+1,E

def verify(n,E):
    a=adjacency(n,E)
    assert all(len(row)==4 for row in a)
    assert len(E)==2*n
    # Every original edge must have no alternate path of length <=4;
    # equivalently no undirected cycle of length <=5 exists.
    for u,v in E:
        seen={u};front={u}
        for depth in range(4):
            nxt=set()
            for w in front:
                for z in a[w]:
                    if {w,z}=={u,v}:continue
                    if z not in seen:nxt.add(z)
            seen|=nxt;front=nxt
        assert v not in seen,(n,u,v)
    return True

if __name__=='__main__':
    n,E=base();verify(n,E);ops=[]
    while n<130:
        p=good_pair(n,E)
        if p is None:raise RuntimeError(('no valid insertion',n))
        ops.append({'n_before':n,'edges':[list(x)for x in p]})
        n,E=insert(n,E,p);verify(n,E)
    result={'base':'two disjoint copies of bipartite difference graph D={0,1,3,9} mod13','initial_n':52,'final_n':n,'operations':ops,'verification':'Every insertion independently checks cross-endpoint distances>=4, degree4, and absence of cycles of lengths<=5.','final_edges':[list(e)for e in sorted(E)]}
    path=Path(__file__).resolve().parents[1]/'research/extremal-bounds-girth-growth.json'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print({'n':n,'operations':len(ops),'certificate':str(path)})

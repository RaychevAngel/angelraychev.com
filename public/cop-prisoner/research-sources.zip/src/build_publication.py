"""Build the shared-source manuscript, proof page and reproducible downloads.

No deployment or submission is performed. Use the project publishing Python
with pypandoc_binary, matplotlib and pypdf installed.
"""
from pathlib import Path
import subprocess,json,re,hashlib,zipfile,shutil,html,sys
from datetime import datetime,timezone
import pypandoc
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1];PAPER=ROOT/'paper'
SITE=ROOT/'.site-worktree';PUBLIC=SITE/'public/cop-prisoner'
TMP=ROOT/'tmp';TMP.mkdir(exist_ok=True);PUBLIC.mkdir(parents=True,exist_ok=True)
PANDOC=pypandoc.get_pandoc_path()
TEX='/Users/angel/Library/TinyTeX/bin/universal-darwin/pdflatex'

def run(args,cwd=ROOT):
    p=subprocess.run([str(x)for x in args],cwd=cwd,text=True,capture_output=True)
    if p.returncode:raise RuntimeError(p.stdout+'\n'+p.stderr)
    return p.stdout

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

run([sys.executable,ROOT/'src/build_figures.py'])
source=(PAPER/'main.md').read_text()
# Supplements are inserted before the computational evidence, leaving one source
# text for the PDF and complete proof page.
for part in ['dense-extensions.md','sparse-certificates.md','small-arcs.md']:
    p=PAPER/part
    if p.exists():
        part_source=p.read_text().replace('\\[','$$').replace('\\]','$$').replace('\\(','$').replace('\\)','$')
        source=source.replace('# Exact computation and formal verification',part_source+'\n\n# Exact computation and formal verification')
(PAPER/'assembled.md').write_text(source)
run([PANDOC,'assembled.md','--standalone','--citeproc','--bibliography=references.bib',
     '--number-sections','--variable=fontfamily:lmodern','--to=latex','-o','main.tex'],PAPER)
tex=(PAPER/'main.tex').read_text()
tex=tex.replace('\\begin{document}','\\usepackage{needspace}\n\\begin{document}')
tex=tex.replace('\\tableofcontents\n}', '\\tableofcontents\n}\n\\clearpage')
def keep_table(match):
    table=match.group(0);rows=table.count('\\\\')
    return '\\Needspace{'+str(min(rows+3,22))+'\\baselineskip}\n'+table
tex=re.sub(r'\\begin\{longtable\}.*?\\end\{longtable\}',keep_table,tex,flags=re.S)
(PAPER/'main.tex').write_text(tex)
previous=None
for _ in range(4):
    run([TEX,'-interaction=nonstopmode','-halt-on-error','main.tex'],PAPER)
    signature=tuple((PAPER/f'main.{ext}').read_bytes() if (PAPER/f'main.{ext}').exists() else b'' for ext in ['aux','toc','out'])
    if signature==previous:break
    previous=signature
else:raise RuntimeError('LaTeX cross references did not stabilize')
log=(PAPER/'main.log').read_text()
if re.search(r'undefined references|undefined citations|Citation .* undefined',log):raise RuntimeError('Unresolved PDF references')
warnings=re.findall(r'^Overfull.*$',log,re.M)
out=ROOT/'output/pdf';out.mkdir(parents=True,exist_ok=True)
pdf=out/'guaranteed-indirect-delivery.pdf';shutil.copy2(PAPER/'main.pdf',pdf)
shutil.copy2(pdf,PUBLIC/pdf.name)
(PUBLIC/'figures').mkdir(exist_ok=True)
for p in (PAPER/'figures').glob('*.svg'):shutil.copy2(p,PUBLIC/'figures'/p.name)

ast=json.loads(run([PANDOC,'assembled.md','--citeproc','--bibliography=references.bib','--to=json'],PAPER))
maths=[];toc=[]
def text_of(nodes):
    return ''.join(n.get('c','')if n['t']=='Str'else' 'if n['t']in('Space','SoftBreak')else''for n in nodes)
def walk(x):
    if isinstance(x,list):return[walk(z)for z in x]
    if not isinstance(x,dict):return x
    t=x.get('t');c=x.get('c')
    if t=='Header':
        if c[0]==1:toc.append((c[1][0],text_of(c[2])))
        c[0]=min(c[0]+1,6)
    if t=='Image'and c[2][0].startswith('figures/'):
        c[2][0]='/cop-prisoner/'+c[2][0].replace('.pdf','.svg')
    if t=='Math':
        i=len(maths);maths.append({'source':c[1],'display':c[0]['t']=='DisplayMath'})
        return{'t':'RawInline','c':['html',f'DELIVERYMATH{i}END']}
    if'c'in x:x['c']=walk(c)
    return x
ast['blocks']=walk(ast['blocks'])
(TMP/'web-ast.json').write_text(json.dumps(ast));(TMP/'maths.json').write_text(json.dumps(maths))
(TMP/'render-math.cjs').write_text('''const fs=require('fs');const{createRequire}=require('module');
const req=createRequire(process.argv[2]+'/package.json');const k=req('katex');
const rows=JSON.parse(fs.readFileSync(process.argv[3]));
fs.writeFileSync(process.argv[4],JSON.stringify(rows.map(x=>k.renderToString(x.source,{displayMode:x.display,throwOnError:true,strict:'error'}))));''')
run(['node',TMP/'render-math.cjs',SITE,TMP/'maths.json',TMP/'rendered.json'])
rendered=json.loads((TMP/'rendered.json').read_text())
body=run([PANDOC,TMP/'web-ast.json','--from=json','--to=html5','--wrap=none'])
for i,m in enumerate(rendered):body=body.replace(f'DELIVERYMATH{i}END',m)
body=re.sub(r'(<table(?:\s[^>]*)?>)',r'<div class="tablewrap">\1',body).replace('</table>','</table></div>')
nav='<nav aria-label="Proof contents"><ol>'+''.join(f'<li><a href="#{html.escape(k)}">{html.escape(t)}</a></li>'for k,t in toc)+'</ol></nav>'
dest=SITE/'src/content/generated/cop-prisoner-proofs.html';dest.parent.mkdir(parents=True,exist_ok=True)
dest.write_text(nav+'\n'+body)

def archive(path,files,base):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(set(files)):z.write(p,p.relative_to(base))

leanfiles=list((ROOT/'lean').glob('*.lean'))+list((ROOT/'lean').glob('*.py'))+[ROOT/'lean/lean-toolchain',ROOT/'lean/README.md',ROOT/'lean/verification.json']
receipt=json.loads((ROOT/'lean/verification.json').read_text())
assert receipt['all_passed']
for name,digest in receipt['source_sha256'].items():
    assert sha(ROOT/'lean'/name)==digest, f'Stale Lean verification: {name}'
shutil.copy2(ROOT/'lean/verification.json',PUBLIC/'lean-verification.json')
(PUBLIC/'lean').mkdir(exist_ok=True)
for p in leanfiles:
    if p.exists():shutil.copy2(p,PUBLIC/'lean'/p.name)
archive(PUBLIC/'lean-proofs.zip',[p for p in leanfiles if p.exists()],ROOT)
archive(PUBLIC/'manuscript-source.zip',[PAPER/'main.tex',PAPER/'references.bib']+list((PAPER/'figures').glob('*.pdf')),PAPER)
replay=TMP/'archive-source-replay';replay.mkdir(exist_ok=True)
with zipfile.ZipFile(PUBLIC/'manuscript-source.zip')as z:z.extractall(replay)
for _ in range(3):run([TEX,'-interaction=nonstopmode','-halt-on-error','main.tex'],replay)
expected_text=[p.extract_text()for p in PdfReader(pdf).pages]
assert [p.extract_text()for p in PdfReader(replay/'main.pdf').pages]==expected_text
assert all('Figure '+str(i)+':' in '\n'.join(expected_text)for i in range(1,5))
(ROOT/'research/pdf-verification.json').write_text(json.dumps({'standalone_source_recompiled':True,'pages':len(expected_text),'text_matches_published_pdf':True,'all_four_figures':True,'no_overfull_boxes':not warnings,'pdf_sha256':sha(pdf)},indent=2)+'\n')
metadata_files={'publication-build.json','website-deployment.json'}
mathfiles=list((ROOT/'src').glob('*.py'))+list((ROOT/'src').glob('*.cpp'))+[p for p in(ROOT/'research').glob('*.json')if p.name not in metadata_files]+list((ROOT/'research').glob('*.md'))
archive(PUBLIC/'research-sources.zip',mathfiles+[p for p in leanfiles if p.exists()]+list(PAPER.glob('*.md'))+[PAPER/'references.bib',ROOT/'README.md'],ROOT)
shutil.copy2(PAPER/'references.bib',PUBLIC/'references.bib')
release={'prepared_at_utc':datetime.now(timezone.utc).isoformat(),'status':'Research checkpoint; not submitted to arXiv',
    'pages':len(PdfReader(pdf).pages),'figures':4,'math_formulas':len(maths),'pdf_overfull_warnings':warnings,
    'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}for p in PUBLIC.iterdir()if p.is_file()and p.name!='release.json'}}
(PUBLIC/'release.json').write_text(json.dumps(release,indent=2)+'\n')
(ROOT/'research/publication-build.json').write_text(json.dumps(release,indent=2)+'\n')
print(json.dumps(release,indent=2))

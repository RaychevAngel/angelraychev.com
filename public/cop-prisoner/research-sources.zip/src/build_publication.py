"""Build the shared-source manuscript, proof page and reproducible downloads.

No deployment or submission is performed. Use the project publishing Python
with pypandoc_binary, matplotlib and pypdf installed.
"""
from pathlib import Path
import subprocess,json,re,hashlib,zipfile,shutil,html,sys,tempfile,os,argparse
from datetime import datetime,timezone
import pypandoc
from pypdf import PdfReader
from publication_layout import assemble
from build_delivery_time_companion import build as build_companion
from render_classification_status import render as render_classification

ROOT=Path(__file__).resolve().parents[1];PAPER=ROOT/'paper'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pdf-only',action='store_true',help='Render PDFs for visual review; skip release audits, archives and public writes.')
args=parser.parse_args()
SITE=ROOT/'.site-worktree';PUBLIC_DEST=SITE/'public/cop-prisoner'
TMP=ROOT/'tmp';TMP.mkdir(exist_ok=True)
staging=tempfile.TemporaryDirectory(prefix='publication-stage-',dir=TMP)
PUBLIC=Path(staging.name)
manifest=json.loads((ROOT/'publication/manifest.json').read_text())
# Make PDF metadata stable across rebuilds of the same publication date.
os.environ['SOURCE_DATE_EPOCH']=str(int(datetime.fromisoformat(manifest['publication_date']).replace(tzinfo=timezone.utc).timestamp()))
os.environ['FORCE_SOURCE_DATE']='1'
PANDOC=pypandoc.get_pandoc_path()
TEX='/Users/angel/Library/TinyTeX/bin/universal-darwin/pdflatex'

def run(args,cwd=ROOT):
    p=subprocess.run([str(x)for x in args],cwd=cwd,text=True,capture_output=True)
    if p.returncode:raise RuntimeError(p.stdout+'\n'+p.stderr)
    return p.stdout

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

if not args.pdf_only:
    classification_html,classification_summary=render_classification(ROOT)
    run([sys.executable,ROOT/'src/classification_coverage.py','--check'])
    run([sys.executable,ROOT/'src/audit_explicit_constructions.py','--check'])
    run([sys.executable,ROOT/'src/audit_publication_artifacts.py','--sources-only'])
run([sys.executable,ROOT/'src/build_figures.py'])
source=assemble(ROOT,manifest)
figure_paths=sorted({PAPER/p for p in re.findall(r'\]\((figures/[^)]+\.pdf)\)',source)})
assert figure_paths, 'No manuscript figures found'
(PAPER/'assembled.md').write_text(source)
run([PANDOC,'assembled.md','--standalone','--citeproc','--bibliography=references.bib',
     '--number-sections','--variable=fontfamily:lmodern','--to=latex','-o','main.tex'],PAPER)
tex=(PAPER/'main.tex').read_text()
tex=tex.replace('\\begin{document}','\\usepackage{needspace}\n\\begin{document}')
tex=tex.replace('\\tableofcontents\n}',
    '\\small\n\\makeatletter\n'
    '\\renewcommand{\\l@section}{\\@dottedtocline{1}{0em}{2.3em}}\n'
    '\\makeatother\n\\tableofcontents\n}\n\\clearpage')
def wrap_code(match):
    body=match.group(1)
    for token in ['/',r'\_','-','.']:
        body=body.replace(token,token+r'\allowbreak{}')
    return r'\texttt{'+body+'}'
tex=re.sub(r'\\texttt\{([^{}]*)\}',wrap_code,tex)
def keep_table(match):
    table=match.group(0);rows=table.count('\\\\')
    return '\\Needspace{'+str(min(rows+3,22))+'\\baselineskip}\n'+table
tex=re.sub(r'\\begin\{longtable\}.*?\\end\{longtable\}',keep_table,tex,flags=re.S)
(PAPER/'main.tex').write_text(tex)
previous=None
for _ in range(4):
    run([TEX,'-interaction=nonstopmode','-halt-on-error','main.tex'],PAPER)
    signature=tuple((PAPER/f'main.{ext}').read_bytes() if (PAPER/f'main.{ext}').exists() else b'' for ext in ['aux','toc','out'])
    if signature==previous:break
    previous=signature
else:raise RuntimeError('LaTeX cross references did not stabilize')
log=(PAPER/'main.log').read_text()
if re.search(r'undefined references|undefined citations|Citation .* undefined',log):raise RuntimeError('Unresolved PDF references')
warnings=re.findall(r'^Overfull.*$',log,re.M)
out=ROOT/'output/pdf';out.mkdir(parents=True,exist_ok=True)
pdf=out/'guaranteed-indirect-delivery.pdf';shutil.copy2(PAPER/'main.pdf',pdf)
shutil.copy2(pdf,PUBLIC/pdf.name)
(PUBLIC/'figures').mkdir(exist_ok=True)
for p in figure_paths:shutil.copy2(p.with_suffix('.svg'),PUBLIC/'figures'/p.with_suffix('.svg').name)

ast=json.loads(run([PANDOC,'assembled.md','--citeproc','--bibliography=references.bib','--to=json'],PAPER))
maths=[];toc=[]
def text_of(nodes):
    return ''.join(n.get('c','')if n['t']=='Str'else' 'if n['t']in('Space','SoftBreak')else''for n in nodes)
def walk(x):
    if isinstance(x,list):return[walk(z)for z in x]
    if not isinstance(x,dict):return x
    t=x.get('t');c=x.get('c')
    if t=='Header':
        if c[0]in(1,2):toc.append((c[0],c[1][0],text_of(c[2])))
        c[0]=min(c[0]+1,6)
    if t=='Image'and c[2][0].startswith('figures/'):
        c[2][0]='/cop-prisoner/'+c[2][0].replace('.pdf','.svg')
    if t=='Math':
        i=len(maths);maths.append({'source':c[1],'display':c[0]['t']=='DisplayMath'})
        return{'t':'RawInline','c':['html',f'DELIVERYMATH{i}END']}
    if'c'in x:x['c']=walk(c)
    return x
ast['blocks']=walk(ast['blocks'])
(TMP/'web-ast.json').write_text(json.dumps(ast));(TMP/'maths.json').write_text(json.dumps(maths))
(TMP/'render-math.cjs').write_text('''const fs=require('fs');const{createRequire}=require('module');
const req=createRequire(process.argv[2]+'/package.json');const k=req('katex');
const rows=JSON.parse(fs.readFileSync(process.argv[3]));
fs.writeFileSync(process.argv[4],JSON.stringify(rows.map(x=>k.renderToString(x.source,{displayMode:x.display,throwOnError:true,strict:'error'}))));''')
run(['node',TMP/'render-math.cjs',SITE,TMP/'maths.json',TMP/'rendered.json'])
rendered=json.loads((TMP/'rendered.json').read_text())
body=run([PANDOC,TMP/'web-ast.json','--from=json','--to=html5','--wrap=none'])
for i,m in enumerate(rendered):body=body.replace(f'DELIVERYMATH{i}END',m)
body=re.sub(r'(<table(?:\s[^>]*)?>)',r'<div class="tablewrap">\1',body).replace('</table>','</table></div>')
chapters=[]
for level,key,title in toc:
    if level==1:chapters.append({'key':key,'title':title,'sections':[]})
    else:chapters[-1]['sections'].append((key,title))
nav='<nav aria-label="Proof contents"><ol>'
for chapter in chapters:
    nav+=f'<li><a href="#{html.escape(chapter["key"])}">{html.escape(chapter["title"])}</a>'
    sections=chapter['sections']
    nav+=f'<details><summary>Proof sections ({len(sections)})</summary><ol>'
    nav+=''.join(f'<li><a href="#{html.escape(k)}">{html.escape(t)}</a></li>'for k,t in sections)
    nav+='</ol></details></li>'
nav+='</ol></nav>'
dest=SITE/'src/content/generated/cop-prisoner-proofs.html';dest.parent.mkdir(parents=True,exist_ok=True)
proof_html=nav+'\n'+body
evidence_html=run([PANDOC,ROOT/'publication/EVIDENCE_GUIDE.md','--to=html5','--wrap=none','--shift-heading-level-by=1'])
companion_results = [build_companion(ROOT,PUBLIC,spec,run,PANDOC,TEX,sha,preview_only=args.pdf_only)
                     for spec in manifest.get('companions',[])]

if args.pdf_only:
    print(json.dumps({'preview_only':True,'main_pdf':str(pdf),'pages':len(PdfReader(pdf).pages),
                      'companions':companion_results,
                      'boundary':'PDF rendering only; no release validation, archives or public writes.'},indent=2))
    sys.exit(0)
# Reject an unreviewed rendering before the expensive evidence packaging.
# The full artifact auditor still checks every visual acceptance field later.
visual=json.loads((ROOT/'research/pdf-visual-review.json').read_text())
assert visual['main']['pdf_sha256']==sha(pdf), 'PDF needs visual review: use --pdf-only, review, then update the visual receipt.'
assert visual['main']['pages']==len(PdfReader(pdf).pages), 'Visual review page count is stale'

archive_index=json.loads((ROOT/'publication/evidence-index.json').read_text())
archive_layout=archive_index['archive_layout']

def archive(path,files,base,research_text=False):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(set(files)):
            name=p.relative_to(base).as_posix()
            use_bzip2=(research_text and name.startswith('research/') and
                       p.suffix in archive_layout['bzip2_suffixes'] and
                       p.stat().st_size>=archive_layout['bzip2_minimum_bytes'])
            z.write(p,name,compress_type=zipfile.ZIP_BZIP2 if use_bzip2 else zipfile.ZIP_DEFLATED)

leanfiles=list((ROOT/'lean').glob('*.lean'))+list((ROOT/'lean').glob('*.py'))+[ROOT/'lean/lean-toolchain',ROOT/'lean/README.md',ROOT/'lean/verification.json']
receipt=json.loads((ROOT/'lean/verification.json').read_text())
assert receipt['all_passed']
for name,digest in receipt['source_sha256'].items():
    assert sha(ROOT/'lean'/name)==digest, f'Stale Lean verification: {name}'
shutil.copy2(ROOT/'lean/verification.json',PUBLIC/'lean-verification.json')
(PUBLIC/'lean').mkdir(exist_ok=True)
for p in leanfiles:
    if p.exists():shutil.copy2(p,PUBLIC/'lean'/p.name)
formal_provenance=[ROOT/name for name in archive_layout.get('lean_provenance_paths',[])]
archive(PUBLIC/'lean-proofs.zip',[p for p in leanfiles if p.exists()]+formal_provenance,ROOT)
archive(PUBLIC/'manuscript-source.zip',[PAPER/'main.tex',PAPER/'references.bib']+figure_paths,PAPER)
expected_text=[p.extract_text()for p in PdfReader(pdf).pages]
with tempfile.TemporaryDirectory(prefix='archive-source-replay-',dir=TMP)as replay_dir:
    replay=Path(replay_dir)
    with zipfile.ZipFile(PUBLIC/'manuscript-source.zip')as z:z.extractall(replay)
    for _ in range(3):run([TEX,'-interaction=nonstopmode','-halt-on-error','main.tex'],replay)
    assert [p.extract_text()for p in PdfReader(replay/'main.pdf').pages]==expected_text
figure_count=len(re.findall(r'^!\[',source,re.M))
assert all('Figure '+str(i)+':' in '\n'.join(expected_text)for i in range(1,figure_count+1))
(ROOT/'research/pdf-verification.json').write_text(json.dumps({'standalone_source_recompiled':True,'source_replay_used_fresh_directory':True,'pages':len(expected_text),'text_matches_published_pdf':True,'all_figures_present':figure_count,'no_overfull_boxes':not warnings,'pdf_sha256':sha(pdf)},indent=2)+'\n')
metadata_files={'publication-build.json','website-deployment.json'}
large_certificates=[ROOT/name for name in archive_layout['finite_certificate_paths']]
mathfiles=list((ROOT/'src').glob('*.py'))+list((ROOT/'src').glob('*.cpp'))+list((ROOT/'src').glob('*.hpp'))+[p for p in(ROOT/'research').glob('*.json')if p.name not in metadata_files]+list((ROOT/'research').glob('*.md'))+list((ROOT/'research').glob('*.txt'))+[p for p in(ROOT/'research').glob('*.gz')if p not in large_certificates]
# Working proposals and the private journal discussion are not release evidence.
private_notes=set(archive_index.get('unpublished_research_notes',[]))
mathfiles=[p for p in mathfiles if p.relative_to(ROOT).as_posix() not in private_notes
           and p not in formal_provenance]
# Scientific run logs are source evidence only when explicitly listed and pinned
# by the named frozen manifests validated in the sources-only audit above.
# Do not glob *.log: compiler, TeX and operational logs remain excluded.
scientific_logs=archive_index.get('scientific_log_archive',{}).get('paths',[])
mathfiles+=[ROOT/name for name in scientific_logs]
mathfiles+=list((ROOT/'research').glob('*.py'))
mathfiles+=list((ROOT/'research').glob('*.cpp'))+list((ROOT/'research').glob('*.jsonl'))
mathfiles+=list((ROOT/'research/history').glob('*.md'))
# This finite supplement is already consolidated and compressed; preserve the
# literal bundle rather than publishing48 loose rank files.
mathfiles.append(ROOT/'research/sparse-interface-third-certificates.zip')
mathfiles.append(ROOT/'research/sparse-staged-certificates.zip')
mathfiles.append(ROOT/'research/small-plateau-staged-certificates.zip')
mathfiles.append(ROOT/'research/small-plateau-small-stage-certificates.zip')
mathfiles+=list((ROOT/'research/history').glob('*.json'))
archive(PUBLIC/'research-sources.zip',mathfiles+list(PAPER.glob('*.md'))+figure_paths+[p.with_suffix('.svg')for p in figure_paths]+list((ROOT/'publication').glob('*'))+[PAPER/'references.bib',ROOT/'README.md',ROOT/'HANDOFF.md',ROOT/'RESEARCH_LOG.md'],ROOT,research_text=True)
with zipfile.ZipFile(PUBLIC/'research-sources.zip','a',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    z.write(ROOT/'publication/EVIDENCE_GUIDE.md','START_HERE.md')
archive(PUBLIC/'finite-strategy-certificates.zip',[p for p in large_certificates if p.exists()],ROOT)
shutil.copy2(PAPER/'references.bib',PUBLIC/'references.bib')
for name,path in manifest['static_assets'].items():shutil.copy2(ROOT/path,PUBLIC/name)
for name in manifest['downloads']:
    assert (PUBLIC/name).stat().st_size<=archive_layout['maximum_download_bytes'], f'Download exceeds hosting file limit: {name}'
expected=set(manifest['downloads'])|{'figures/'+p.with_suffix('.svg').name for p in figure_paths}|{'lean/'+p.name for p in leanfiles if p.exists()}
actual={str(p.relative_to(PUBLIC))for p in PUBLIC.rglob('*')if p.is_file()}
assert expected==actual,f'Public output differs from manifest: {expected ^ actual}'
existing={str(p.relative_to(PUBLIC_DEST))for p in PUBLIC_DEST.rglob('*')if p.is_file()}
unexpected=existing-expected-{'release.json'}-set(manifest['retired_assets'])
assert not unexpected,f'Unclassified public leftovers: {sorted(unexpected)}'
release={'prepared_at_utc':datetime.now(timezone.utc).isoformat(),'status':manifest.get('status','Research checkpoint; not submitted to arXiv'),
    'publication_date':manifest['publication_date'],'chapters':len(chapters),'source_parts':sum(len(c['parts'])for c in manifest['chapters']),
    'pages':len(PdfReader(pdf).pages),'figures':figure_count,'math_formulas':len(maths),'pdf_overfull_warnings':warnings,
    'companions':{spec['id']:result[0] for spec,result in zip(manifest.get('companions',[]),companion_results)},
    'classification_coverage':classification_summary,
    'explicit_construction_coverage':{'known_value_gaps':json.loads((ROOT/'research/explicit-construction-coverage.json').read_text())['known_value_explicit_construction_gap_count'],'scope':'Separate source audit of direct recipes and certified finite exceptions'},
    'files':{name:{'bytes':(PUBLIC/name).stat().st_size,'sha256':sha(PUBLIC/name)}for name in manifest['downloads']},
    'assets':{name:{'bytes':(PUBLIC/name).stat().st_size,'sha256':sha(PUBLIC/name)}for name in sorted(actual)}}
(PUBLIC/'release.json').write_text(json.dumps(release,indent=2)+'\n')
audit=json.loads(run([sys.executable,ROOT/'src/audit_publication_artifacts.py','--public-dir',PUBLIC,'--staged']))
assert audit['passed'], 'Independent publication audit failed'
# Only complete, checked outputs enter the served tree. Unknown pre-existing
# paths fail above; intentional retirements must be recorded in the manifest.
for name in actual|{'release.json'}:
    target=PUBLIC_DEST/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(PUBLIC/name,target)
for name in set(manifest['retired_assets'])-expected:
    target=PUBLIC_DEST/name
    if target.is_file():target.unlink()
dest.write_text(proof_html)
(dest.parent/'cop-prisoner-evidence.html').write_text(evidence_html)
(dest.parent/'cop-prisoner-classification-status.html').write_text(classification_html)
for spec,result in zip(manifest.get('companions',[]),companion_results):
    (dest.parent/spec['generated_html']).write_text(result[1])
(ROOT/'research/publication-build.json').write_text(json.dumps(release,indent=2)+'\n')
print(json.dumps(release,indent=2))

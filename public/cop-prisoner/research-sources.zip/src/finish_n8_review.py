#!/usr/bin/env python3
"""Review independently enumerated eight-vertex upper-band decisions."""
import hashlib,itertools,json
from pathlib import Path
from game_solver import solve_graph
from small_case_certificate_review import review
ROOT=Path(__file__).resolve().parents[1]

def main():
    cases=[(35,19),(36,18),(37,16),(38,15)]
    lowers=json.loads((ROOT/'research/endpoint40_n8_high_lower_certificates.json').read_text())
    if isinstance(lowers,dict):lowers=lowers['graphs']
    outputs=[];sources=['src/finish_n8_independent.cpp','src/finish_n8_review.py',
      'src/endpoint40_n8_profiles.cpp','research/endpoint40_n8_high_receipt.json',
      'research/endpoint40_n8_high_lower_certificates.json',
      'research/endpoint40_n8_high_negative_certificates.json',
      'research/finish-endpoint40-review.md','src/game_solver.py','src/small_case_certificate_review.py']
    for m,value in cases:
        first=f'research/endpoint40_n8_m{m}_t{value+1}.jsonl'
        second=f'research/finish-n8-m{m}-independent.jsonl';sources += [first,second]
        p=[json.loads(x) for x in (ROOT/first).read_text().splitlines()]
        q=[json.loads(x) for x in (ROOT/second).read_text().splitlines()]
        profiles=[x for x in p if x['kind']=='profile']
        expected=[list(x) for x in itertools.combinations_with_replacement(range(1,8),8) if sum(x)==56-m]
        assert [x['degrees'] for x in profiles]==expected
        assert all(x['complete'] and not x['found'] and not x['timeout'] for x in profiles)
        final=q[-1];assert final['complete'] and not final['target_found'] and final['profiles']==len(expected)
        obligations=0
        leaves=[x for x in q if x['kind']=='leaf']
        assert len(leaves)==final['leaves']
        for x in leaves:
            g=solve_graph(8,x['arcs'],certificates=True,crosscheck=True)
            assert g['m']==m and g['I']==x['I']<=value
            obligations+=review(g)['alternating_state_obligations']
        g=next(x for x in lowers if x['m']==m)
        assert g['I']==value;obligations+=review(g)['alternating_state_obligations']
        outputs.append({'n':8,'m':m,'value':value,'independent_profiles':len(expected),
          'independent_leaves':len(leaves),'literal_obligations':obligations})
    result={'verified':True,'upper_bounds':outputs,
      'proof_boundary':'Same independently reviewed prefix-camping and suffix-class coverage argument as endpoint40, with arbitrary positive profile sum and explicit loss allowance; two complete traversals plus full literal ranks, not Lean.',
      'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources}}
    (ROOT/'research/finish-n8-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(outputs))
if __name__=='__main__':main()

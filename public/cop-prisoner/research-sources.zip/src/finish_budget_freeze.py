#!/usr/bin/env python3
"""Pin the completed 14--16 producer and leaf-replay package."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

files=['src/finish_budget_run.py','src/finish_budget_positive.cpp','src/finish_budget_zero.cpp',
       'src/finish_budget_leaf_review.py','src/finish_budget_freeze.py','src/finish_alternating_review.hpp',
       'research/finish_budget_proof.md','research/finish_budget_final_run.log','research/finish_budget_16_run.log',
       'research/finish_budget_leaf_review.json','research/finish_budget_leaf_review.log','research/finish_budget_leaf_review_reuse.log']
inherited=['research/endpoint40_n8_sparse_receipt.json','research/endpoint40_n8_sparse_lower_certificates.json',
           'research/endpoint40_tiny_live_review.md','research/endpoint40_tiny_live_review.json',
           'research/small-case-n7-independent.json','research/small-case-n7-independent-review.json',
           'research/finish-tiny-live-n12-m12-t10.json','research/finish-tiny-live-n13-m13-t12-head85.json',
           'research/finish-tiny-live-n13-m13-t12-tail85.json']
rows=[]
for m,L,positive in ((14,13,(9,10)),(15,15,(9,10)),(16,19,(9,10,11))):
 for mode,hosts in ((0,positive),(1,range(9,m+1))):
  for n in hosts:
   tag=f'n{n}_m{m}_above{L}'+('_zero_two' if mode else '')
   p=ROOT/f'research/finish_budget_positive_{tag}.json';r=json.loads(p.read_text())
   assert (r['n'],r['m'],r['threshold'],r['mode'])==(n,m,L,mode)
   assert r['complete'] and not r['counterexample_found'] and r['degree_patterns']==r['total_degree_patterns']
   assert r['upper_if_complete']==L and r['maximum_threshold_survivor']==-1
   assert sha(ROOT/r['source_file'])==r['source_sha256']
   assert sha(ROOT/r['profile_file'])==r['profile_sha256']
   assert sha(ROOT/'src/finish_budget_run.py')==r['runner_source_sha256']
   files.extend([str(p.relative_to(ROOT)),r['profile_file']])
   rows.append({k:r[k] for k in ('n','m','mode','threshold','degree_patterns','nodes','game_decisions','seconds')})
review=json.loads((ROOT/'research/finish_budget_leaf_review.json').read_text())
assert review['verified'] and len(review['runs'])==len(rows)==28
assert review['all_leaf_games']==sum(r['game_decisions'] for r in rows)==118547
assert review['reviewer_source_sha256']==sha(ROOT/'src/finish_budget_leaf_review.py')
assert review['alternating_source_sha256']==sha(ROOT/'src/finish_alternating_review.hpp')
for r in review['runs']:
 assert sha(ROOT/r['primary_file'])==r['primary_sha256']
result=dict(status='primary exclusions and independent leaf replay complete; ordinary review by root pending',
 claims=['M_E(14)=13','M_E(15)=15','M_E(16)=19',
         'M(n,14)=13, M(n,15)=15, M(n,16)=19 for every n>=8',
         'The minimum attaining host for each of budgets 14,15,16 is eight'],
 dependency_order=[14,15,16],rows=rows,
 totals=dict(degree_patterns=sum(r['degree_patterns'] for r in rows),nodes=sum(r['nodes'] for r in rows),
             independent_leaf_games=review['all_leaf_games'],
             sampled_guarded_states=sum(r['guarded_samples'] for r in review['runs']),
             sampled_guarded_losing_pairs=sum(r['sampled_loss_pairs'] for r in review['runs'])),
 files={p:sha(ROOT/p) for p in sorted(set(files))},inherited_inputs={p:sha(ROOT/p) for p in inherited},
 boundary='Every surviving leaf was independently solved. Enumeration and pruning require ordinary source/coverage review; no second independent full graph traversal is claimed. Only budgets14--16 are claimed. Earlier incomplete pilot logs are not upper evidence.')
(ROOT/'research/finish_budget_manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['totals']))

// Exact endpoint-aware enumeration of deficient two-regular graphs.
// Add missing 0->1, factor the resulting regular bipartite graph into two
// permutations, and distinguish the cycle of A containing A[0]=1.
// Only necessary stationary-camping obstructions prune partial B factors.
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
constexpr int CAP=16;
int mode=0,low_target=1,best_I=0,minwanted=87;int n,all,A[CAP],B[CAP],out[CAP],pred[CAP],binv[CAP];bool assigned[CAP],used[CAP],complete=true,found=false;long long nodes=0,leaves=0,partitions=0;vector<int>wa,wb;double budget;auto started=chrono::steady_clock::now();
bool source_block(int s,int c){if(s==0||s==c)return false;int recipients=all&~(out[s]|(1<<s)|(1<<low_target));return recipients&&!(out[s]&~(out[c]|(1<<c)));}
bool target_block(int t,int c){if(t==low_target)return false;int sources=all&~(pred[t]|(1<<0)|(1<<t)|(1<<c));return sources&&!(pred[t]&~(out[c]|(1<<c)));}
bool admissible(int u,int v){for(int c=0;c<n;c++){
 if(source_block(u,c))return false;
 if(assigned[c]&&source_block(c,u))return false;
 if(target_block(v,c))return false;
 if(binv[c]>=0&&target_block(c,u))return false;
}return true;}
int game(){int potential=(n-2)*(n-3)-(mode!=0),loss=0;int W[CAP],safe[CAP],NW[CAP];for(int t=0;t<n;t++)if(t!=low_target){fill(W,W+n,0);W[t]=all;while(true){for(int x=0;x<n;x++){safe[x]=0;for(int c=0;c<n;c++)if(!((out[c]|(1<<c))&~W[x]))safe[x]|=1<<c;}bool change=false;for(int r=0;r<n;r++){int w=0,nb=out[r]|(1<<r);while(nb){int x=__builtin_ctz((unsigned)nb);nb&=nb-1;w|=safe[x];}if(r!=t)w&=~(1<<r);NW[r]=w;change|=w!=W[r];}copy(NW,NW+n,W);if(!change)break;}for(int r=1;r<n;r++)if((W[r]|(1<<r))!=all){loss++;if(potential-loss<minwanted)return potential-loss;}}return potential-loss;}
void dfs(int row){if(!complete||found)return;if((++nodes&65535)==0&&chrono::duration<double>(chrono::steady_clock::now()-started).count()>budget){complete=false;return;}if(row==n){++leaves;int value=game();if(value>=minwanted&&value>best_I){best_I=value;wa.assign(A,A+n);wb.assign(B,B+n);if(value>=89)found=true;}return;}
 for(int v=0;v<n;v++)if(!used[v]&&v!=row&&(v!=A[row]||(mode==1&&row==0))&&(mode!=1||row!=0||v==1)){B[row]=v;used[v]=assigned[row]=true;binv[v]=row;out[row]|=1<<v;pred[v]|=1<<row;if(admissible(row,v))dfs(row+1);pred[v]&=~(1<<row);out[row]&=~(1<<v);binv[v]=-1;used[v]=assigned[row]=false;if(!complete||found)return;}}
void initialize(){fill(pred,pred+n,0);fill(assigned,assigned+n,false);fill(used,used+n,false);fill(binv,binv+n,-1);for(int u=0;u<n;u++){out[u]=u?1<<A[u]:0;if(u)pred[A[u]]|=1<<u;}}
void solve(int distinguished,const vector<int>&parts){partitions++;for(int j=0;j<distinguished;j++)A[j]=(j+1)%distinguished;int off=distinguished;for(int l:parts){for(int j=0;j<l;j++)A[off+j]=off+(j+1)%l;off+=l;}initialize();dfs(0);}
void partition(int distinguished,int rem,int low,vector<int>&p){if(!complete||found)return;if(!rem){solve(distinguished,p);return;}for(int l=low;l<=rem;l++){p.push_back(l);partition(distinguished,rem-l,l,p);p.pop_back();}}
int main(int argc,char**argv){n=12;mode=atoi(argv[1]);budget=argc>2?atof(argv[2]):90;low_target=mode==2?0:1;all=(1<<n)-1;
 if(mode==2){vector<int>p;partition(1,n-1,2,p);}else for(int len=2;len<=n&&complete&&!found;len++){vector<int>p;partition(len,n-len,2,p);}
 cout<<"{\"n\":"<<n<<",\"m\":"<<2*n-1<<",\"mode\":"<<mode<<",\"complete\":"<<(complete&&!found?"true":"false")<<",\"attained_global_upper89\":"<<(found?"true":"false")<<",\"threshold_checked\":"<<minwanted<<",\"best_I_at_least_threshold\":"<<best_I<<",\"partitions\":"<<partitions<<",\"nodes\":"<<nodes<<",\"local_obstruction_free_leaves\":"<<leaves<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<",\"arcs\":[";for(int i=0;i<int(wa.size());i++){if(i)cout<<",";cout<<"["<<i<<","<<wb[i]<<"]";if(i)cout<<",["<<i<<","<<wa[i]<<"]";}cout<<"],\"low_source\":0,\"low_recipient\":"<<low_target<<"}\n";
}

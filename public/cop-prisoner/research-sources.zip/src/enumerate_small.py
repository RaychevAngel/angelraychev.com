#!/usr/bin/env python3
"""Reproduce exhaustive n<=5 tables and independent n<=4 semantic checks.

Runs one compiled enumeration worker at a time. n5 has 2^20 graphs, not an
unbounded search. All n<=4 graphs are also solved by the explicit alternating
state implementation, whose ranks certify winning and losing regions.
"""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tempfile
import time
from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]

def decode(n,mask):
    return [(u,v) for j,(u,v) in enumerate((u,v) for u in range(n)
            for v in range(n) if u!=v) if mask>>j&1]

def main():
    p=argparse.ArgumentParser();p.add_argument('--max-n',type=int,default=5)
    args=p.parse_args()
    assert 1<=args.max_n<=5
    start=time.time(); rows=[]; total_crosschecked=0
    with tempfile.TemporaryDirectory(prefix='cop-prisoner-') as tmp:
        executable=Path(tmp)/'enumerate'
        subprocess.run(['c++','-O3','-std=c++17',str(ROOT/'src/enumerate_small.cpp'),
                        '-o',str(executable)],check=True)
        for n in range(1,args.max_n+1):
            data=json.loads(subprocess.check_output([str(executable),str(n)],text=True))
            assert data['graphs']==1<<(n*(n-1))
            for row in data['by_m']:
                assert sum(row['distribution'].values())==math.comb(n*(n-1),row['m'])
                arcs=decode(n,row['witness_mask'])
                result=solve_graph(n,arcs,crosscheck=True,certificates=True)
                assert result['I']==row['maximum_I']
                row['witness_arcs']=result['arcs']
                row['witness_indirect_pairs']=result['indirect_pairs']
            if n<=4:
                distributions=[collections.Counter() for _ in data['by_m']]
                for mask in range(data['graphs']):
                    arcs=decode(n,mask)
                    result=solve_graph(n,arcs,crosscheck=True,certificates=True)
                    distributions[len(arcs)][str(result['I'])]+=1
                    total_crosschecked+=1
                for row,counter in zip(data['by_m'],distributions):
                    assert row['distribution']==dict(counter)
                data['independent_explicit_solver']='every labeled graph and every target'
            else:
                data['independent_explicit_solver']='all maximizing witnesses, not every graph'
            (ROOT/f'research/solver-enumeration-n{n}.json').write_text(json.dumps(data,indent=2)+'\n')
            rows.append({'n':n,'maximum_I':max(r['maximum_I'] for r in data['by_m']),
                         'graphs':data['graphs'],'enumeration_seconds':data['seconds']})
            print(rows[-1],flush=True)
    receipt={'summary':rows,'independent_graphs':total_crosschecked,
             'seconds':time.time()-start,'source_sha256':{
                 name:hashlib.sha256((ROOT/'src'/name).read_bytes()).hexdigest()
                 for name in ('game_solver.py','enumerate_small.cpp','enumerate_small.py')}}
    (ROOT/'research/solver-enumeration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':main()

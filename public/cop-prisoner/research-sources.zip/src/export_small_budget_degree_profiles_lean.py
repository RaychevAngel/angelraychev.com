#!/usr/bin/env python3
"""Export complete eight-arrow profile trees as kernel-checked Lean literals."""
from pathlib import Path
import argparse, json, itertools, re
from irregular_ten_export import certificate, route, natlist
ROOT=Path(__file__).resolve().parents[1]

def render(node_map,p):
    node=node_map[','.join(map(str,p))]
    if node['kind']=='bound':return '.bound '+certificate(node['certificate'])
    children=' '.join('| '+str(rep)+' => '+render(node_map,p+[rep])for rep in node['representatives'])
    return '.branch '+natlist(node['representatives'])+' '+route(node)+' (fun mask => match mask with '+children+' | _ => .invalid)'

def split_source(source,prefix,out,cases):
    if not cases:
        (out/f'{prefix}.lean').write_text(source);return
    namespace='Delivery.'+prefix
    nsstart=source.index('namespace '+namespace)
    leadend=source.index('set_option maxHeartbeats 0')+len('set_option maxHeartbeats 0')
    lead=source[nsstart:leadend]+'\n\n'
    starts=[]
    for i in range(len(cases)):
        starts.append(re.search(rf'^def profile{i}_node',source,re.M).start())
    tail=source.index('def catalogue :')
    common=prefix+'Common'
    (out/f'{common}.lean').write_text(source[:starts[0]]+'#print axioms cover\nend '+namespace+'\n')
    roots=[]
    for i,start in enumerate(starts):
        body=source[start:(starts[i+1]if i+1<len(starts)else tail)]
        nodes=[];last=None
        for m in re.finditer(r'^(?:def|theorem) (profile\d+_node\d+)',body,re.M):
            if m[1]!=last:nodes.append((m.start(),m[1]));last=m[1]
        chunks=[nodes[j:j+128]for j in range(0,len(nodes),128)];previous=common
        for j,chunk in enumerate(chunks):
            name=prefix+f'Profile{i:03d}Part{j:03d}'
            begin=chunk[0][0];end=chunks[j+1][0][0]if j+1<len(chunks)else len(body)
            checked=f'profile{i}'if j+1==len(chunks)else chunk[-1][1]
            text='import '+previous+'\n\n'+lead+body[begin:end]+'\n#print axioms '+checked+'\nend '+namespace+'\n'
            (out/f'{name}.lean').write_text(text);previous=name
        roots.append(previous)
    (out/f'{prefix}.lean').write_text(''.join('import '+name+'\n'for name in roots)+'\n'+lead+source[tail:])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('budget',type=int,choices=[8,9,10,11,12,13]);ap.add_argument('--input',type=Path)
    ap.add_argument('--out',type=Path,default=ROOT/'lean');ap.add_argument('--orders');ap.add_argument('--split',action='store_true');args=ap.parse_args()
    budget=args.budget;bound={8:4,9:5,10:6,11:8,12:9,13:11}[budget];word={8:'Eight',9:'Nine',10:'Ten',11:'Eleven',12:'Twelve',13:'Thirteen'}[budget];zero='false' if budget==9 else 'true'
    args.input=args.input or ROOT/f'research/lean-small-budget-{budget}-profiles.json';args.orders=args.orders or ','.join(map(str,range(5,budget+1)))
    args.out.mkdir(parents=True,exist_ok=True)
    data=json.loads(args.input.read_text());assert data['arrows']==budget and data['bound']==bound and data['degree_envelope']
    for n in map(int,args.orders.split(',')):
        cases=[c for c in data['cases']if c['n']==n]
        prefix=f'SmallBudget{word}Finite{n}'
        s=f'''import SmallRowPrefixDegreeCheck
import SmallRowPrefixFastRouting
import SmallBudgetProfiles

/-! Complete row-prefix coverage for every sorted joint-degree profile on
{n} vertices with {budget} arrows and the stated degree restriction. -/
namespace Delivery.{prefix}
open FiniteGame Extremal RowPrefix SmallBudgetProfiles
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def rows '''+' '.join(chr(97+i)for i in range(n))+f''' : Rows {n} := fun v =>
  match v.val with '''+' '.join(f'| {i} => {chr(97+i)}'for i in range(n-1))+f' | _ => {chr(96+n)}\n\n'
        choices={d:[sum(1<<t for t in ts)for ts in itertools.combinations(range(n),d)]for d in range(n+1)}
        s+='def choices (d : Nat) : List Nat :=\n  match d with\n'
        for d,ms in choices.items():s+=f'  | {d} => '+natlist(ms)+'\n'
        s+='  | _ => []\n\n'
        s+=f'theorem cover (d : Fin {n+1}) : RowCover {n} d.val (choices d.val) := by\n  revert d\n  decide +kernel\n\n'
        for i,c in enumerate(cases):
            labels=natlist(list(reversed(c['labels'])));ds=f'(D (n:={n}) '+labels+')';rs=f'(R (n:={n}) '+labels+')'
            declarations=[];counter=[0]
            def proof(p):
                node=c['nodes'][','.join(map(str,p))];idx=counter[0];counter[0]+=1
                name=f'profile{i}_node{idx}';pl=natlist(p)
                if node['kind']=='bound':
                    cn=name+'_cert'
                    available=sum(1<<t for t in range(n)if sum(mask>>t&1 for mask in p)<c['indegrees'][t])
                    mode=node['certificate']['mode'];typ='CutBound' if mode=='cut' else 'Bound';sound='DegreeLoss.cut_bound_sound' if mode=='cut' else 'DegreeLoss.bound_sound';check='DegreeLoss.cutCheck_true' if mode=='cut' else 'DegreeLoss.boundCheck_true'
                    cert=node['certificate'];body=certificate(cert) if mode=='plain' else certificate(dict(cert,allowed=cert['lost'])).replace('allowed :=','lost :=')
                    declarations.append(f'def {cn} : {typ} {n} := '+body+'\n')
                    declarations.append(f'theorem {name} : Upper {ds} {rs} {pl} {bound} :=\n  {sound} {ds} {rs} {pl} {bound} {available} {cn}\n    (({check} {ds} {rs} {pl} {bound} {available} {cn}).mp (by decide +kernel))\n')
                else:
                    reps=node['representatives'];children={v:proof(p+[v])for v in reps}
                    rn=name+'_route';d=c['outdegrees'][len(p)]
                    invalid_columns={}
                    for mask in choices[d]:
                        if str(mask) in node['routes']:continue
                        q=p+[mask];k=len(q)
                        if mask>>len(p)&1:continue
                        used=[sum(row>>t&1 for row in q)for t in range(n)]
                        invalid_columns[mask]=next(t for t in range(n)if not used[t]<=c['indegrees'][t]<=used[t]+n-k-int(t>=k))
                    col=name+'_column'
                    declarations.append(f'def {col} : Nat → Fin {n} := fun mask => match mask with '+''.join(f'| {mask} => {t} 'for mask,t in invalid_columns.items())+'| _ => 0\n')
                    declarations.append(f'def {rn} : Route {n} := '+route(node)+'\n')
                    src=f'theorem {name} : Upper {ds} {rs} {pl} {bound} := by\n'
                    src+=f'  apply SmallFastRouting.sound {ds} {rs} {pl} {bound} (by decide) (choices {d}) {natlist(reps)} {rn} {col}\n'
                    src+=f'    (by change RowCover {n} {d} (choices {d}); exact cover ⟨{d},by decide⟩)\n'
                    src+=f'    (by decide +kernel)\n'
                    src+='  intro mask member\n'
                    if reps:
                        src+='  simp only [List.mem_cons,List.not_mem_nil,or_false] at member\n  rcases member with '+' | '.join('rfl'for _ in reps)+'\n'
                        src+=''.join('  · exact '+children[v]+'\n'for v in reps)
                    else:src+='  simp at member\n'
                    declarations.append(src)
                return name
            rootname=proof([])
            s+='\n'.join(declarations)+f'\ntheorem profile{i} : Upper {ds} {rs} [] {bound} := {rootname}\n\n'
        s+='def catalogue : List (List Nat) := ['+','.join(natlist(c['labels'])for c in cases)+']\n\n'
        s+=f'theorem catalogue_eq : hardProfiles {n} {budget} {bound} {zero}=catalogue := by decide +kernel\n\n'
        s+=f'''theorem hard_upper (xs : List Nat) (member : xs∈hardProfiles {n} {budget} {bound} {zero}) :
    Upper (n:={n}) (D xs.reverse) (R xs.reverse) [] {bound} := by
  rw [catalogue_eq] at member
  simp only [catalogue,List.mem_cons,List.not_mem_nil,or_false] at member
'''+('  rcases member with '+' | '.join('rfl'for c in cases)+'\n' if cases else '')
        for i,c in enumerate(cases):
            s+=f'  · exact profile{i}\n'
        s+=f'''theorem profile_upper (xs : List Nat) (member : xs∈profiles {n} {zero} {n} 0 {budget} {budget}) :
    Upper (n:={n}) (D xs.reverse) (R xs.reverse) [] {bound} :=
  upper_of_hard hard_upper xs member

theorem upper (E : Graph (Fin {n})) (loops : Loopless E) (budget : arcCount E={budget})
    (degree : ∀x,2≤SparseSupport.outdegree E x+SparseSupport.indegree E x)
    (regularity : ∀x,(0<SparseSupport.outdegree E x ∧ 0<SparseSupport.indegree E x) ∨
      ({zero}=true ∧ SparseSupport.outdegree E x+SparseSupport.indegree E x=2)) : score E≤{bound} := by
  have od (x) : SparseSupport.outdegree E x<{n} := by
    have h := SparseDeletion.row_nonadjacent_bound E loops x
    omega
  have idg (x) : SparseSupport.indegree E x<{n} := by
    have h := SparseDeletion.column_nonadjacent_bound E loops x
    omega
  have td : ((List.finRange {n}).map (SparseSupport.outdegree E)).sum={budget} := by
    have h := SparseSupport.arc_rows E
    exact h.symm.trans budget
  have te : ((List.finRange {n}).map (SparseSupport.indegree E)).sum={budget} := by
    have h := SparseSupport.arc_columns E
    exact h.symm.trans budget
  have member := sorted_member (SparseSupport.outdegree E) (SparseSupport.indegree E)
    {zero} (by decide) od idg degree regularity td te
  obtain ⟨F,⟨iso⟩,prescribed⟩ := relabel_reversed E loops (fun x => by have := idg x; omega)
  have bound := profile_upper _ member F prescribed (by intro s h; simp at h)
  rw [GraphRelabeling.score_eq iso] at bound
  exact bound

#print axioms upper
end Delivery.{prefix}
'''
        # rows arguments require explicit Nat types.
        s=s.replace('def rows '+' '.join(chr(97+i)for i in range(n))+' :', 'def rows ('+' '.join(chr(97+i)for i in range(n))+' : Nat) :')
        if args.split:split_source(s,prefix,args.out,cases)
        else:(args.out/f'{prefix}.lean').write_text(s)
        print(prefix,len(cases),len(s))
if __name__=='__main__':main()

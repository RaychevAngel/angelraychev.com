#!/usr/bin/env python3
"""Bounded untrusted producer for complete threshold-30 prefix certificates.

The compiled Lean checker, not the producer, validates coverage, exclusions,
closure, and counts. Historical artifacts are never overwritten.
"""
from __future__ import annotations
import argparse,hashlib,json,time
from pathlib import Path
from lean_finite_regular_producer import primary,PARTITIONS,function,literal
from lean_finite_prefix_probe import optimistic
from lean_finite_threshold_prototype import eligible
ROOT=Path(__file__).resolve().parents[1];N=9;ALL=511

def packed(rows):return sum(value<<(9*i) for i,value in enumerate(rows))
def tuples(xs):return '['+','.join('('+','.join(map(str,x))+')' for x in xs)+']'
def local_data(a,p):
    out=[(1<<a[r])|((1<<p[r]) if r<len(p) else 0) for r in range(N)]
    low=[out[r]|(1<<r) for r in range(N)]
    pred=[sum(1<<s for s in range(N) if a[s]==t) for t in range(N)]
    sources=[];recipients=[]
    for u,t in enumerate(p):pred[t]|=1<<u
    for s in range(len(p)):
        for c in range(N):
            if c!=s and not(out[s]&~low[c]):sources.append((s,c));break
    for u,t in enumerate(p):
        cops=[c for c in range(N) if not(pred[t]&~low[c])]
        recipients.extend((t,u,c) for c in cops[:2])
    return sources,recipients,low

def produce(parts,node_limit,seconds,split_depth,benchmark_chunks,reuse_data=False,row_tables=False,root_prefix=(),boolean=False,minimum=False):
    a=primary(parts);key='x'.join(map(str,parts));start=time.monotonic();nodes={}
    mode='-minimum' if minimum else ''
    if minimum:
        assert parts==(9,)
        row_tables=True;boolean=True
    counts=dict(nodes=0,branches=0,local=0,robust=0,masks=0,normalization=0)
    def valid(p):return len(set(p))==len(p) and all(v!=i and v!=a[i] for i,v in enumerate(p))
    def walk(p):
        counts['nodes']+=1
        if counts['nodes']>node_limit or time.monotonic()-start>seconds:raise TimeoutError('bounded producer cap')
        if minimum and p and any((p[i]-i)%9 < p[0] for i in range(len(p))):
            nodes[tuple(p)]={'kind':'minimum'};counts['normalization']+=1;return
        local=eligible(a,p);score=sum(v.bit_count() for v in local)
        if score<=30:
            sources,recipients,_=local_data(a,p)
            node={'kind':'camp','allowed':packed(local),'sources':sources,'recipients':recipients};counts['local']+=1
        else:
            upper,masks=optimistic(a,p) if len(p)>=4 else (55,[])
            if upper<=30:
                sources,recipients,low=local_data(a,p);remain=list(local);chosen=[]
                def gain(tm):
                    t,mask=tm
                    return sum(bool(remain[s]>>t&1) and bool(((mask>>(9*s))&ALL)&~(1<<s)) for s in range(N))
                while sum(v.bit_count() for v in remain)>30:
                    tm=max(masks,key=gain);masks.remove(tm);chosen.append(tm);t,mask=tm
                    for s in range(N):
                        if ((mask>>(9*s))&ALL)&~(1<<s):remain[s]&=~(1<<t)
                used=sum(1<<v for v in p)
                high=[low[r] if r<len(p) else low[r]|(ALL&~(used|(1<<r)|(1<<a[r]))) for r in range(N)]
                losses=[]
                for t,mask in chosen:
                    good=[sum(1<<z for z in range(N) if z!=t and (z==c or low[c]&((1<<z)|((mask>>(9*z))&ALL)))) for c in range(N)]
                    losses.append((t,mask,packed(good)))
                node={'kind':'leaf','allowed':packed(remain),'sources':sources,'recipients':recipients,'upper':packed(high),'lower':packed(low),'losses':losses}
                counts['robust']+=1;counts['masks']+=len(losses)
            else:
                if len(p)==9:raise AssertionError(('threshold violation',p,upper))
                node={'kind':'branch'};counts['branches']+=1
                for v in range(N):
                    if valid(p+[v]):walk(p+[v])
        nodes[tuple(p)]=node
    scratch=ROOT/'tmp/lean-oct23/finite';scratch.mkdir(exist_ok=True,parents=True)
    if reuse_data:
        data=json.loads((scratch/f'bound-tree-{key}{mode}.json').read_text())
        assert data['a']==a
        nodes={tuple(x['prefix']):{k:v for k,v in x.items() if k!='prefix'} for x in data['nodes']}
        counts=data['counts']
    else:
        walk([])
        data={'partition':parts,'a':a,'counts':counts,'seconds':time.monotonic()-start,'nodes':[dict(prefix=p,**node) for p,node in nodes.items()]}
        (scratch/f'bound-tree-{key}{mode}.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
    def table(value):
        if not row_tables:return str(value)
        return '⟨'+','.join(str((value>>(9*i))&511) for i in range(9))+'⟩'
    suffix='Minimum' if minimum else ('Boolean' if boolean else ('Rows' if row_tables else ''))
    if boolean:row_tables=True
    ns='Thirty'+key+('Minimum' if minimum else '')+('P'+'_'.join(map(str,root_prefix)) if root_prefix else '')
    def emit(p):
        if not valid(p):return '.invalid'
        node=nodes[tuple(p)];kind=node['kind']
        if kind=='minimum':return '.minimum'
        if kind in ['camp','leaf']:
            fields=[table(node['allowed']),tuples(node['sources']),tuples(node['recipients'])]
            if kind=='leaf':
                fields += [table(node['upper']),table(node['lower']),'['+','.join('⟨'+str(t)+','+str(mask)+','+table(good)+'⟩' for t,mask,good in node['losses'])+']']
            return '(.'+kind+' ⟨'+','.join(fields)+'⟩)'
        return '(.branch fun v => match v.val with\n'+''.join(f'  | {v} => {emit(p+[v])}\n' for v in range(N) if valid(p+[v]))+'  | _ => .invalid)'
    module='FiniteExclusionRotationBoundTree' if minimum else ('FiniteExclusionBoolean' if boolean else 'FiniteExclusionBoundTree'+suffix)
    header='import '+module+('\nimport HamiltonianNormalization' if minimum else '')+'\nset_option maxRecDepth 65536\nset_option maxHeartbeats 200000000\nnamespace Delivery.FiniteExclusion.'+ns+'\nopen '+('RotationBounds' if minimum else 'Bounds '+('BoundTreeRows' if row_tables else 'BoundTree'))+' Extremal\n'+function('a',a)
    chunks=[];aggregates=[]
    def prove(p):
        if not valid(p):return f'(invalid_upper a {literal(p)} 30 (by decide +kernel))'
        name='piece_'+('_'.join(map(str,p)) if p else 'root')
        node=nodes[tuple(p)]
        if len(p)>=split_depth or node['kind']!='branch':
            chunk=f'def {name}_data : Tree :=\n{emit(p)}\n\n'
            sound_name='Boolean.sound' if boolean and not minimum else 'sound'
            chunk+=f'theorem {name} : UpperPrefix a {literal(p)} 30 :=\n  {sound_name} a {literal(p)} 30 {name}_data (by decide +kernel)\n\n'
            chunks.append((p,chunk))
        else:
            children=[prove(p+[v]) for v in range(N)]
            aggregates.append(f'theorem {name} : UpperPrefix a {literal(p)} 30 :=\n  branch_upper a {literal(p)} 30 (by decide) (fin9_cases _\n    '+'\n    '.join(children)+')\n\n')
        return name
    top=prove(list(root_prefix))
    tail=f'theorem prefix_upper : UpperPrefix a {literal(root_prefix)} 30 := {top}\n#print axioms prefix_upper\n'
    if minimum and not root_prefix:
        tail += '''theorem upper (b : Assignment 9) (valid : Valid a b) : score (edgeOf a b) ≤ 30 := by
  obtain ⟨b',valid',minimum,same⟩ := HamiltonianNormalization.normalized_cover a b
    (by decide +kernel) valid
  rw [←same]
  exact prefix_upper b' valid' minimum (by intro i h; simp at h)
#print axioms upper
'''
    tail+=f'end Delivery.FiniteExclusion.{ns}\n'
    tag=('P'+'_'.join(map(str,root_prefix))) if root_prefix else f'Depth{split_depth}'
    out=scratch/f'FiniteExclusionThirtyNine{key}{tag}{suffix}.lean'
    out.write_text(header+''.join(s for _,s in chunks)+''.join(aggregates)+tail)
    bench=scratch/f'FiniteExclusionThirtyNine{key}Benchmark{suffix}.lean'
    bench.write_text(header+''.join(s for _,s in chunks[:benchmark_chunks])+'\n#print axioms piece_'+('_'.join(map(str,chunks[min(benchmark_chunks,len(chunks))-1][0])))+f'\nend Delivery.FiniteExclusion.{ns}\n')
    summary={k:v for k,v in data.items() if k not in ['nodes','a']}
    summary.update(source=str(out),bytes=out.stat().st_size,chunks=len(chunks),benchmark=str(bench),benchmark_chunks=min(benchmark_chunks,len(chunks)),sha256=hashlib.sha256(out.read_bytes()).hexdigest())
    (scratch/f'bound-tree-{key}-summary{suffix}.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--partition',default='9');ap.add_argument('--node-limit',type=int,default=200000);ap.add_argument('--seconds',type=float,default=45);ap.add_argument('--split-depth',type=int,default=4);ap.add_argument('--benchmark-chunks',type=int,default=3);ap.add_argument('--reuse-data',action='store_true');ap.add_argument('--row-tables',action='store_true');ap.add_argument('--root-prefix',default='');ap.add_argument('--boolean',action='store_true');ap.add_argument('--minimum',action='store_true');args=ap.parse_args()
    parts=tuple(map(int,args.partition.split(',')));assert parts in PARTITIONS
    produce(parts,args.node_limit,args.seconds,args.split_depth,args.benchmark_chunks,args.reuse_data,args.row_tables,tuple(map(int,args.root_prefix.split(','))) if args.root_prefix else (),args.boolean,args.minimum)
if __name__=='__main__':main()

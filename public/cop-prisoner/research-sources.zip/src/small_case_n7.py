#!/usr/bin/env python3
"""Bounded fixed-budget n7 exclusions, preserving incomplete runs explicitly."""
import json
import subprocess
import sys
import time
from pathlib import Path
from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]
ledger=json.loads((ROOT/'publication/classification-coverage.json').read_text())
row=next(r for r in ledger['rows'] if r['n']==7)
known={}
for s in row['segments']:
    for m in range(s['m'][0],s['m'][1]+1):known[m]=s['lower'][0]+s['lower'][1]*(m-s['m'][0])
for p in (ROOT/'research').glob('small-*-certificate*.json'):
    data=json.loads(p.read_text())
    entries=data if isinstance(data,list) else data.get('graphs',[data])
    for g in entries:
        if isinstance(g,dict) and g.get('n')==7 and all(k in g for k in ('m','I','arcs')):
            known[g['m']]=max(known.get(g['m'],0),g['I'])
results=[];certificates=[]
for m in list(range(12,21))+list(range(22,33)):
    start=time.monotonic();runs=[];lower=known[m];exact=False
    while time.monotonic()-start<8:
        remaining=8-(time.monotonic()-start)
        r=subprocess.run(['/tmp/cop-small-arcs-primary','7',str(lower+1),str(m),str(m),str(remaining)],capture_output=True,text=True,check=True)
        data=json.loads(r.stdout);runs.append(data)
        if data['counterexample_found']:
            g=solve_graph(7,data['arcs'],crosscheck=True,certificates=True)
            assert g['I']==data['best_I']>lower
            lower=g['I'];certificates.append(g)
        elif data['complete']:
            exact=True;break
        else:break
    results.append({'n':7,'m':m,'lower':lower,'exact_by_primary':exact,'runs':runs})
    (ROOT/'research/small-case-n7-primary.json').write_text(json.dumps({'records':results},indent=2)+'\n')
    (ROOT/'research/small-case-n7-certificates.json').write_text(json.dumps(certificates,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in results[-1].items() if k!='runs'}),flush=True)

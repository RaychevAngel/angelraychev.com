#!/usr/bin/env python3
"""Independent arithmetic and alternating-game audit of frozen sparse proofs.

Never imports a producer, game solver, or support helper. Generated C++ variants
retain the reviewed graph coverage/prunes but replace every complete-leaf game
with an explicit reverse-edge alternating attractor. Their generated source
lives in a temporary directory, and all hashes are retained in the receipt.
"""
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[1]


def rectangle(m,q,r,b,R,C):
    answer=0
    for u in range(R+1):
        for v in range(C+1):
            intersection=max(0,b-(q-u)-(r-v))
            direct=max(0,m-(m-2*u)-(m-2*v))
            answer=max(answer,u*v-intersection-direct)
    return answer


def independent_profiles(m,n):
    rows=[]
    for q in range(m//2+1):
        for r in range(m//2+1):
            a=m-2*q;d=m-2*r
            for b in range(max(0,q+r-n),min(q,r)+1):
                z=n-q-r+b
                if q*r-b-max(0,2*q+2*r-m)<=53:continue
                allrows=rectangle(m,q,r,b,q-1,r)<=53
                allcols=rectangle(m,q,r,b,q,r-1)<=53
                for o in range(min(z,a)+1):
                    for i in range(min(z,d)+1):
                        if o+i<z:continue
                        R=min(q,b+a+(d-o-z)//2)
                        C=min(r,b+d+(a-i-z)//2)
                        if min(R,C)<0:continue
                        upper=rectangle(m,q,r,b,R,C)
                        if upper<=53:continue
                        for x in range(a+1):
                            lowout=a-x-o
                            if not 0<=lowout<=r-b:continue
                            if allrows and 2*(r-b)+2*x+o+z>3*a:continue
                            for y in range(d+1):
                                lowin=d-y-i
                                if not 0<=lowin<=q-b:continue
                                if allcols and 2*(q-b)+2*y+i+z>3*d:continue
                                for w in range(min(a-x,d-y)+1):
                                    direct=2*q+2*r-m+x+y+w
                                    eligible=q*r-b-direct
                                    if direct<0 or min(upper,eligible)<=53:continue
                                    sinks=(r-b-lowout)+(z-o)
                                    sources=(q-b-lowin)+(z-i)
                                    rows.append(dict(q=q,r=r,b=b,o=o,i=i,z=z,x=x,y=y,w=w,
                                        eligible_upper=eligible,all_rows_live=allrows,
                                        all_columns_live=allcols,indegree_zero=sources,
                                        outdegree_zero=sinks,positive_degrees=not(sources or sinks)))
    return sorted(rows,key=lambda r:json.dumps(r,sort_keys=True))


def partitions(total,least=2):
    if total==0:yield ()
    for k in range(least,total+1):
        for rest in partitions(total-k,k):yield (k,)+rest


def family_arithmetic():
    one=list(partitions(10))
    onepatterns=sum(len(set(p))*10 for p in one)
    two=[(path,p) for path in range(1,12) for p in partitions(11-path)]
    twopatterns=sum((path-1+len(set(p)))*10 for path,p in two)
    # All joint degree multisets independently generated from full permutations
    # of incoming high/low labels, and the four directional double transfers.
    patterns=set()
    def add(d,e):patterns.add(tuple(sorted(zip(d,e),reverse=True)))
    regular=[2]*10
    for highshape in ([4,2,2,2,2,2,2,2,1,1],[3,3,2,2,2,2,2,2,1,1]):
        add(highshape,regular);add(regular,highshape)
    d=[3]+[2]*8+[1]
    for high,low in itertools.permutations(range(10),2):
        e=[2]*10;e[high]=3;e[low]=1;add(d,e)
    assert (len(one),onepatterns,len(two),twopatterns,len(patterns))==(12,220,42,1640,11)
    return dict(one_factor_types=len(one),one_patterns=onepatterns,
                two_factor_types=len(two),two_patterns=twopatterns,
                coupled_degree_patterns=len(patterns),joint_degree_multisets=sorted(patterns))


def small_factor_controls():
    reports=[]
    for n in range(3,6):
        edges=list(itertools.permutations(range(n),2));position={e:k for k,e in enumerate(edges)}
        def mask(arcs):return sum(1<<position[e] for e in arcs)
        perfect=[mask(enumerate(p)) for p in itertools.permutations(range(n))
                 if all(s!=p[s] for s in range(n))]
        partial=[]
        for omittedrow in range(n):
            rows=[s for s in range(n) if s!=omittedrow]
            for omittedcol in range(n):
                columns=[t for t in range(n) if t!=omittedcol]
                for targets in itertools.permutations(columns):
                    if all(s!=t for s,t in zip(rows,targets)):partial.append(mask(zip(rows,targets)))
        def valid(bitmask):
            out=[0]*n;inc=[0]*n
            for k,(s,t) in enumerate(edges):
                if bitmask>>k&1:out[s]+=1;inc[t]+=1
            return all(1<=d<=2 for d in out+inc)
        for deficit in (1,2):
            m=2*n-deficit
            expected={sum(1<<k for k in subset) for subset in itertools.combinations(range(len(edges)),m)
                      if valid(sum(1<<k for k in subset))}
            first=perfect if deficit==1 else partial
            actual={a|b for a in first for b in partial if not(a&b) and valid(a|b)}
            assert actual==expected,(n,deficit,len(actual),len(expected))
            reports.append(dict(n=n,m=m,labelled_positive_max_degree_two_graphs=len(expected),
                                complete_matching_union_coverage=True))
    return reports


def small_prefix_control():
    n=4;edges=list(itertools.permutations(range(n),2));pos={e:k for k,e in enumerate(edges)}
    maps=[[pos[(p[s],p[t])] for s,t in edges] for p in itertools.permutations(range(n))]
    def canonical(arcs):
        indices=[pos[e] for e in arcs]
        return min(sum(1<<mapping[k] for k in indices) for mapping in maps)
    expected=set();patterns=set()
    for m in (6,7,8):
        for arcs in itertools.combinations(edges,m):
            out=[sum(s==v for s,t in arcs) for v in range(n)]
            inc=[sum(t==v for s,t in arcs) for v in range(n)]
            if min(out+inc)==0:continue
            expected.add(canonical(arcs));patterns.add(tuple(sorted(zip(out,inc),reverse=True)))
    actual=set();generated=0
    for pattern in patterns:
        D,E=zip(*pattern);incoming=[0]*n;used=[0]*n;arcs=[]
        def visit(row):
            nonlocal generated
            if row==n:
                if tuple(used)==E:actual.add(canonical(arcs));generated+=1
                return
            classes=[[t] for t in range(row) if used[t]<E[t]]
            future={}
            for t in range(row+1,n):
                if used[t]<E[t]:future.setdefault((D[t],E[t],incoming[t]),[]).append(t)
            classes+=list(future.values())
            for counts in itertools.product(*(range(len(group)+1) for group in classes)):
                if sum(counts)!=D[row]:continue
                targets=[t for group,count in zip(classes,counts) for t in group[:count]]
                for t in targets:used[t]+=1;incoming[t]|=1<<row;arcs.append((row,t))
                visit(row+1)
                for t in targets:used[t]-=1;incoming[t]&=~(1<<row);arcs.pop()
        visit(0)
    assert actual==expected,(len(actual),len(expected))
    return dict(n=n,budgets=[6,7,8],joint_degree_patterns=len(patterns),
                labelled_positive_graph_orbits=len(expected),generated_leaves=generated,
                canonical_prefix_coverage=True)


def review_lower_witness():
    path=ROOT/'research/small-sparse-regular-10-witness.json';g=json.loads(path.read_text())
    n=g['n'];arcs=set(map(tuple,g['arcs']));moves=[{s}|{t for u,t in arcs if u==s} for s in range(n)]
    indirect=[];states=0
    assert (n,len(arcs),g['I'])==(10,20,53)
    for t,cert in enumerate(g['certificates']):
        rank=cert['rank'];choice=cert['messenger_successor'];assert cert['target']==t
        for r,c,turn in itertools.product(range(n),range(n),range(2)):
            p=2*(r*n+c)+turn;states+=1
            if r==t:assert rank[p]==0;continue
            if r==c:assert rank[p]==-1;continue
            children=([2*(u*n+c)+1 for u in moves[r]] if turn==0 else [2*(r*n+d) for d in moves[c]])
            if rank[p]>=0:
                if turn==0:assert choice[p] in children and 0<=rank[choice[p]]<rank[p]
                else:assert all(0<=rank[q]<rank[p] for q in children)
            elif turn==0:assert all(rank[q]==-1 for q in children)
            else:assert any(rank[q]==-1 for q in children)
        for s in range(n):
            if s!=t and (s,t) not in arcs and all(rank[2*(s*n+c)]>=0 for c in range(n) if c!=s):indirect.append((s,t))
    assert len(indirect)==53 and set(indirect)==set(map(tuple,g['indirect_pairs']))
    return dict(n=n,m=20,I=53,alternating_states_checked=states,
                source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())


INDEPENDENT = r'''
// Explicit alternating-state implementation, written for this audit.
long long audit_guard_calls=0,audit_guard_samples=0,audit_guard_pairs=0;
int audit_maximum=-1;
vector<int> independent_wins(const int* messenger,const int* cop,int target){
 const int size=2*n*n;
 vector<vector<int>> reverse(size);
 vector<int> remaining(size,0),wins(size,0),queue;
 queue.reserve(size);
 for(int r=0;r<n;r++)for(int c=0;c<n;c++)for(int turn=0;turn<2;turn++){
  int state=2*(r*n+c)+turn;
  if(r==target){wins[state]=1;queue.push_back(state);continue;}
  if(r==c)continue;
  int mask=(turn==0?messenger[r]|(1<<r):cop[c]|(1<<c));
  for(int v=0;v<n;v++)if(mask>>v&1){
   int child=turn==0?2*(v*n+c)+1:2*(r*n+v);
   reverse[child].push_back(state);remaining[state]++;
  }
 }
 for(size_t j=0;j<queue.size();j++){
  int child=queue[j];
  for(int parent:reverse[child])if(!wins[parent]){
   if(parent%2==0||--remaining[parent]==0){wins[parent]=1;queue.push_back(parent);}
  }
 }
 vector<int> answer(n,0);
 for(int r=0;r<n;r++)for(int c=0;c<n;c++)if(wins[2*(r*n+c)])answer[r]|=1<<c;
 return answer;
}
void independent_guard_check(const int* optimistic,const int* bad){
 ++audit_guard_calls;
 int stride=n==11?200003:10003;
 if(audit_guard_calls>10&&audit_guard_calls%stride!=0)return;
 ++audit_guard_samples;
 for(int s=0;s<n;s++)if(optimistic[s]&bad[s])abort();
 for(int t=0;t<n;t++){
  bool needed=false;for(int s=0;s<n;s++)if(bad[s]>>t&1)needed=true;
  if(!needed)continue;
  auto wins=independent_wins(optimistic,O,t);
  for(int s=0;s<n;s++)if(bad[s]>>t&1){
   ++audit_guard_pairs;
   if((wins[s]|1<<s)==all)abort();
  }
 }
}
int independent_game(){
 int score=0;
 for(int t=0;t<n;t++){
  auto wins=independent_wins(O,O,t);
  for(int s=0;s<n;s++)if(s!=t&&!(O[s]>>t&1)&&(wins[s]|1<<s)==all)score++;
 }
 audit_maximum=max(audit_maximum,score);
 if(score<=threshold){++early_game_rejects;return -1;}
 return score;
}
'''


def replace_function(source,name,replacement):
    begin=source.index(name+'{')
    brace=source.index('{',begin);depth=1;end=brace+1
    while depth:
        if source[end]=='{':depth+=1
        if source[end]=='}':depth-=1
        end+=1
    return source[:begin]+replacement+source[end:]


def audited_variant(source):
    point=source.index('bool camping(')
    source=source[:point]+INDEPENDENT+'\n'+source[point:]
    source=replace_function(source,'int game()', 'int game(){return independent_game();}')
    original='if(eligible-losses<=threshold)return false;'
    dynamic='if(eligible_upper()-losses<=threshold)return false;'
    if original in source:
        source=source.replace(original,'if(eligible-losses<=threshold){independent_guard_check(optimistic,bad);return false;}')
    else:
        assert dynamic in source
        source=source.replace(dynamic,'if(eligible_upper()-losses<=threshold){independent_guard_check(optimistic,bad);return false;}')
    ending='return complete?0:1;'
    assert source.count(ending)==1
    source=source.replace(ending,'cerr<<"AUDIT "<<audit_maximum<<" "<<audit_guard_samples<<" "<<audit_guard_pairs<<"\\n";'+ending)
    return source


def main():
    manifest=json.loads((ROOT/'research/sparse_finish_twenty_manifest.json').read_text())
    for path,digest in manifest['files'].items():
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest,path
    supplied=json.loads((ROOT/'research/sparse_finish_profiles.json').read_text())
    arithmetic=[]
    for record in supplied['records']:
        fresh=independent_profiles(record['m'],record['n'])
        original=sorted(record['profiles'],key=lambda r:json.dumps(r,sort_keys=True))
        assert fresh==original,(record['n'],record['m'])
        arithmetic.append(dict(n=record['n'],m=record['m'],profiles=len(fresh),
                               positive_profiles=sum(p['positive_degrees'] for p in fresh)))
    families=family_arithmetic();factor_controls=small_factor_controls();prefix_control=small_prefix_control()
    lower=review_lower_witness();runs=[]
    prior_path=ROOT/'research/finish-sparse-review.json'
    prior=json.loads(prior_path.read_text()) if prior_path.exists() else {}
    with tempfile.TemporaryDirectory(prefix='finish_sparse_review_') as temp:
        temp=Path(temp)
        for stem,receipt in [('one_defect','one_defect_10_19'),
                             ('coupled_degrees','coupled_degrees_10_20'),
                             ('two_defect','two_defect_11_20')]:
            original=(ROOT/f'src/sparse_finish_{stem}.cpp').read_text()
            generated=audited_variant(original)
            variant_digest=hashlib.sha256(generated.encode()).hexdigest()
            reusable=next((r for r in prior.get('variant_runs',[]) if r.get('variant_sha256')==variant_digest
                           and r.get('complete') and r.get('upper_if_complete')==53),None)
            if reusable is not None:
                runs.append(reusable)
                print(json.dumps(dict(reused_identical_audited_variant=stem,variant_sha256=variant_digest)),flush=True)
                continue
            path=temp/f'{stem}.cpp';exe=temp/stem;path.write_text(generated)
            subprocess.run(['c++','-O3','-std=c++17',str(path),'-o',str(exe)],check=True)
            frozen=json.loads((ROOT/f'research/sparse_finish_{receipt}.json').read_text())
            proc=subprocess.run([str(exe),'180'],capture_output=True,text=True,timeout=190)
            assert proc.returncode==0,(stem,proc.stdout,proc.stderr)
            data=json.loads(proc.stdout)
            assert data['complete'] and data['upper_if_complete']==53 and data['maximum_threshold_survivor']==-1
            for field in ['nodes','game_decisions','camping_rejects','guarded_checks','guarded_rejects','degree_patterns']:
                assert data[field]==frozen[field],(stem,field,data[field],frozen[field])
            audit=proc.stderr.strip().split()
            assert audit[0]=='AUDIT' and len(audit)==4
            data.update(independent_leaf_maximum=int(audit[1]),guarded_samples=int(audit[2]),
                        sampled_permanent_losing_pairs=int(audit[3]),
                        source_sha256=hashlib.sha256(original.encode()).hexdigest(),
                        variant_sha256=hashlib.sha256(generated.encode()).hexdigest())
            stopped=subprocess.run([str(exe),'0.000000001'],capture_output=True,text=True,timeout=10)
            stop=json.loads(stopped.stdout)
            assert stopped.returncode==1 and stop['complete'] is False
            data['timeout_control']=dict(returncode=stopped.returncode,complete=stop['complete'],nodes=stop['nodes'])
            runs.append(data)
            print(json.dumps(dict(family=stem,seconds=data['seconds'],leaf_decisions=data['game_decisions'],
                                  independent_leaf_maximum=data['independent_leaf_maximum'],guarded_samples=data['guarded_samples'])),flush=True)
    extensions=['research/sparse_finish_nineteen_global.md','paper/odd-endpoint-resume.md']
    report=dict(status='passed',verified=True,
        reviewed_claims=['M(10,19)<=53','M_E(20)=53','M(n,20)=53 for every n>=10','M_E(19)<=53'],
        exact_nineteen_value_claimed=False,
        reviewer_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        frozen_manifest_sha256=hashlib.sha256((ROOT/'research/sparse_finish_twenty_manifest.json').read_bytes()).hexdigest(),
        input_hashes=manifest['files'],independent_profiles=arithmetic,factor_and_degree_arithmetic=families,
        exhaustive_small_matching_controls=factor_controls,exhaustive_small_prefix_control=prefix_control,
        independently_replayed_lower_witness=lower,
        inherited_receipt_hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in manifest['inherited_receipts']},
        ordinary_extension_hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in extensions},
        variant_runs=runs,
        boundary='Independent ordinary coverage/pruning review plus complete replays with a distinct alternating leaf-game implementation. Graph generation and pruning traversal are inherited from the reviewed frozen producers, not a second independent graph enumeration. Guarded-prune validation samples are explicitly counted.')
    (ROOT/'research/finish-sparse-review.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':main()

// Near-endpoint specialization of the frozen first-step engine.
// Kept separate so its completed first-step evidence remains immutable.
#define main first_step_main
#include "small_dense_first_step_profiles.cpp"
#undef main

int main(int argc,char**argv){
 n=8;seconds=argc>1?stod(argv[1]):10;defect=argc>2?stoi(argv[2]):2;
 target=17-defect;allv=(1u<<n)-1;started=chrono::steady_clock::now();
 for(int s=0;s<n;s++)for(unsigned row=1;row<=allv;row++)
  if(!(row>>s&1)&&__builtin_popcount(row)==(s==0?3:2))domain[s].push_back(row);
 rows[0]=14;assigned[0]=true;visit(1);
 emit(capped?"incomplete":found?"witness":"complete");
}

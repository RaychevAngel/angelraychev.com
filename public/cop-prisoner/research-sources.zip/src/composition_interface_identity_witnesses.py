#!/usr/bin/env python3
"""Construct shortest known identity-voltage paths via grammar relaxation.
Weights are positive, and fixed-point closure gives exact shortest lengths.
This ignores pursuit and is only a diagnostic for window selection.
"""
import json,hashlib
from pathlib import Path
from composition_interface_free_group import rules,step
ROOT=Path(__file__).resolve().parents[1]
rr=rules((0,1,3));P={(i,i):() for i in range(10)}
for i,row in enumerate(rr):
 for g,j in row:
  if not g:P[i,j]=((i,g,j),)
rounds=0
while True:
 old={k:len(v) for k,v in P.items()}
 for k in range(10):
  for i in range(10):
   for j in range(10):
    if (i,k) not in P or (k,j) not in P:continue
    p=P[i,k]+P[k,j]
    if (i,j) not in P or len(p)<len(P[i,j]):P[i,j]=p
 for i,row in enumerate(rr):
  for g,k in row:
   if not g:continue
   for l in range(10):
    if (k,l) not in P:continue
    for h,j in rr[l]:
     if h!=-g:continue
     p=((i,g,k),)+P[k,l]+((l,h,j),)
     if (i,j) not in P or len(p)<len(P[i,j]):P[i,j]=p
 rounds+=1
 if old=={k:len(v) for k,v in P.items()}:break
records=[]
for (i,j),p in sorted(P.items()):
 w=();positions=[(w,i)]
 for u,g,v in p:
  w=step(w,g) if g else w;positions.append((w,v))
 assert w==()
 records.append({'source':i,'target':j,'moves':len(p),'max_depth':max(len(w) for w,t in positions),'positions':positions})
out={'scope':'pursuer-free reachability only','iterations':rounds,'maximum_length':max(len(p) for p in P.values()),'maximum_depth':max(d['max_depth'] for d in records),'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'research/composition-interface-identity-witnesses.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k!='records'})
for d in records:
 if d['source']==0:print(d)

#!/usr/bin/env python3
"""Literal ten/eleven-arrow witnesses from the retained alternating rank archive."""
from pathlib import Path
import argparse,json
from export_small_budget_nine_witness_lean import TEMPLATE
ROOT=Path(__file__).resolve().parents[1]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('budget',type=int,choices=[10,11]);ap.add_argument('--out',type=Path);args=ap.parse_args()
 budget=args.budget;word={10:'Ten',11:'Eleven'}[budget];value={10:6,11:8}[budget]
 d=json.loads((ROOT/'research/small-arcs-resume-verification.json').read_text())
 v=next(c['lower_certificate']for c in d['cases']if c['m']==budget);n=v['n'];codes=[];moves=[]
 for t,cert in enumerate(v['certificates']):
  for r in range(n):
   for c in range(n):
    i=2*(r*n+c);codes.append(max(cert['rank'][i]+1,0))
    moves.append(t if r==t else max(cert['messenger_successor'][i],0)//(2*n))
 pairs=lambda xs:'['+','.join(f'({a},{b})'for a,b in xs)+']'
 s=TEMPLATE.replace('SmallBudgetNineWitness',f'SmallBudget{word}Witness').replace('nine-arrow',f'{budget}-arrow').replace('six-vertex',f'{n}-vertex')
 s=s.replace('Fin 6',f'Fin {n}').replace('*36',f'*{n*n}').replace('*6',f'*{n}').replace('% 6',f'% {n}')
 s=s.replace('five_pairs','counted_pairs').replace('5≤score',f'{value}≤score').replace('counted=5',f'counted={value}').replace('edge=9',f'edge={budget}')
 s=s.replace('@@ARCS@@',pairs(v['arcs'])).replace('@@PAIRS@@',pairs(v['indirect_pairs'])).replace('@@CODES@@',str(codes)).replace('@@MOVES@@',str(moves))
 out=args.out or ROOT/f'lean/SmallBudget{word}Witness.lean';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
if __name__=='__main__':main()

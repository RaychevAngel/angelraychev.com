#!/usr/bin/env python3
"""Independent full-rank verification of all separated-hole local patterns."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import itertools
import json
from pathlib import Path

import six_type_independent_verify as independent

ROOT = Path(__file__).resolve().parents[1]


def outgoing(position, holes):
    i, j = position
    assert not (i in holes and j == 4)
    first = (i, j + 1) if j < 5 else (i + 1, 0)
    if j == 3 and i in holes:
        first = (i, 5)
    second = ((i, 5), (i + 1, 4), (i + 1, 1),
              (i - 1, 0), (i + 1, 2), (i - 1, 3))[j]
    if j == 1 and i + 1 in holes:
        second = (i + 2, 2)
    assert first != second and position not in (first, second)
    return first, second


def arena(holes):
    holes = set(holes)
    messenger = [(i, j) for i in range(-4, 5) for j in range(6) if not (i in holes and j == 4)]
    cops = [(i, j) for i in range(-6, 7) for j in range(6) if not (i in holes and j == 4)] + [None]
    mi = {v: i for i, v in enumerate(messenger)}
    ci = {v: i for i, v in enumerate(cops)}
    omega = ci[None]
    mm = [[mi[v] for v in (position, *outgoing(position, holes)) if v in mi] for position in messenger]
    cm = []
    for position in cops:
        if position is None:
            cm.append([omega] + [i for i, v in enumerate(cops) if v is not None and abs(v[0]) >= 5])
        else:
            cm.append(sorted({ci.get(v, omega) for v in (position, *outgoing(position, holes))}))
    return {"messenger": messenger, "cops": cops, "messenger_moves": mm, "cop_moves": cm}


def patterns(spacing):
    columns = tuple(range(-6, 7))
    for count in range(14):
        for subset in itertools.combinations(columns, count):
            if all(b - a >= spacing for a, b in zip(subset, subset[1:])):
                yield subset


def verify_pattern(holes):
    a = arena(holes)
    nc = len(a["cops"])
    certificates = []
    for target in [None, *[j for j in range(6) if not (0 in holes and j == 4)]]:
        successors, success, collision = independent.game(a, target)
        rank, move = independent.attractor(successors, success)
        independent.check_certificate(successors, success, collision, rank, move)
        source_column = -1 if target is None else -2
        starts = [2 * (r * nc + c) for r, v in enumerate(a["messenger"]) if v[0] == source_column
                  for c, cop in enumerate(a["cops"]) if v != cop]
        failures = [state for state in starts if rank[state] < 0]
        certificates.append({"holes": holes, "target_type": target,
                             "required_starts": len(starts), "failed_starts": failures,
                             "messenger_moves_bound": None if failures else (max(rank[s] for s in starts) + 1) // 2,
                             "ranks": rank, "chosen_messenger_successors": move})
    return certificates


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spacing", type=int, default=3)
    args = parser.parse_args()
    all_patterns = list(patterns(args.spacing))
    certificates = [cert for holes in all_patterns for cert in verify_pattern(holes)]
    failed = [{k: v for k, v in cert.items() if k not in ("ranks", "chosen_messenger_successors")}
              for cert in certificates if cert["failed_starts"]]
    payload = {"verified": not failed, "spacing": args.spacing,
               "arena": "Messenger columns -4..4; cop -6..6 plus Omega; Omega reentry -6,-5,5,6.",
               "state_encoding": "Vertices ordered lexicographically, removed holes omitted; cop Omega last. State 2*(r*nc+c)+turn; turn0 messenger.",
               "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "explicit_solver_sha256": hashlib.sha256(Path(independent.__file__).read_bytes()).hexdigest(),
               "certificates": certificates}
    path = ROOT / f"research/six-type-independent-spacing-{args.spacing}-certificates.json.gz"
    with path.open("wb") as destination:
        with gzip.GzipFile(filename="", fileobj=destination, mode="wb", mtime=0) as stream:
            stream.write((json.dumps(payload, separators=(",", ":")) + "\n").encode())
    summary = {"verified": not failed, "spacing": args.spacing,
               "patterns": len(all_patterns), "modules": len(certificates),
               "required_starts_checked": sum(c["required_starts"] for c in certificates),
               "states_checked": sum(len(c["ranks"]) for c in certificates),
               "max_transfer_moves": max((c["messenger_moves_bound"] or 0) for c in certificates if c["target_type"] is None),
               "max_delivery_moves": max((c["messenger_moves_bound"] or 0) for c in certificates if c["target_type"] is not None),
               "failed_modules": failed,
               "certificate_path": str(path.relative_to(ROOT)),
               "certificate_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
               "checker_sha256": payload["checker_sha256"],
               "explicit_solver_sha256": payload["explicit_solver_sha256"]}
    (ROOT / f"research/six-type-independent-spacing-{args.spacing}-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "failed_modules"} | {"failed_modules": len(failed)}))
    if failed:
        print(json.dumps(failed[:3]))


if __name__ == "__main__":
    main()

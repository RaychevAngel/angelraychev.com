#!/usr/bin/env python3
"""Independent whole-implication review of the frozen21-arrow package.
Graph coverage is source-reviewed; every surviving leaf uses a distinct
explicit alternating-state attractor, with sampled optimistic prune replay.
"""
import hashlib,itertools,json,subprocess,tempfile
from pathlib import Path
from finish_sparse_review import INDEPENDENT,replace_function,partitions
from small_case_certificate_review import review
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'research/finish-twentyone-review.json'

def arithmetic():
    cases=[]
    for m in (19,21):
        for n in range(9,m+1):
            vals=[]
            for q in range(min(n,m//2,m-n)+1):
                for r in range(min(n,m//2,m-n)+1):
                    b=max(0,q+r-n)
                    val=q*r-b-max(0,q+r+m-2*n)
                    vals.append((val,q,r))
            cases.append(dict(m=m,n=n,max=max(v[0] for v in vals),above49=[v for v in vals if v[0]>49],above56=[v for v in vals if v[0]>56],above58=[v for v in vals if v[0]>58]))
    for c in cases:
        m,n=c['m'],c['n']
        if m==19:
            if n>=11:assert c['max']<=49
            else:assert all((q,r)==(n if n==9 else 9,)*2 for _,q,r in c['above49'])
        elif n>=12:assert c['max']<=60
        elif n==11:assert all((q,r) in ((10,10),(9,10),(10,9)) for _,q,r in c['above58'])
        else:assert all((q,r) in ((10,10),(9,10),(10,9)) for _,q,r in c['above56'])
    return cases

def variant(original,excess):
    source=original
    independent=INDEPENDENT
    if excess:
        # This family's bitmask is local in the producer; provide an audit-only constant.
        independent='constexpr int audit_all=(1<<n)-1;\n'+independent.replace('==all','==audit_all')
        independent=independent.replace('++audit_guard_calls;', 'int filtered[n];for(int s=0;s<n;s++)filtered[s]=bad[s]&~(optimistic[s]|1<<s);bad=filtered;++audit_guard_calls;')
        point=source.index('int game()')
    else:point=source.index('bool camping(')
    source=source[:point]+independent+'\n'+source[point:]
    source=replace_function(source,'int game()','int game(){return independent_game();}')
    if excess:
        # Only the guarded function has an optimistic adjacency; inspect its losses there.
        point=source.index('bool guarded_possible(')
        head,tail=source[:point],source[point:]
        tail=tail.replace('if(upper_from_bad(bad)<=threshold)return false;','if(upper_from_bad(bad)<=threshold){independent_guard_check(optimistic,bad);return false;}')
        source=head+tail
        source=source.replace('limit>60','limit>600')
        source=source.replace('cout<<"]}\\n";}','cout<<"]}\\n";cerr<<"AUDIT "<<audit_maximum<<" "<<audit_guard_samples<<" "<<audit_guard_pairs<<"\\n";}')
    else:
        for text in ('eligible-losses','eligible_upper()-losses'):
            source=source.replace(f'if({text}<=threshold)return false;',f'if({text}<=threshold){{independent_guard_check(optimistic,bad);return false;}}')
        source=source.replace('return complete?0:1;','cerr<<"AUDIT "<<audit_maximum<<" "<<audit_guard_samples<<" "<<audit_guard_pairs<<"\\n";return complete?0:1;')
    assert 'cerr<<"AUDIT "' in source
    return source

def main():
    mf='research/sparse_finish_twentyone_manifest.json';manifest=json.loads((ROOT/mf).read_text())
    for p,h in manifest['files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
    old=json.loads(OUT.read_text()) if OUT.exists() else {};runs=[]
    jobs=[('nineteen49_one_defect','nineteen49_one_defect_10_19',False,49,[]),
      ('nineteen49_one_excess','nineteen49_one_excess_9_19',True,49,['9']),
      ('twentyone_one_defect_loss','twentyone_one_defect_loss_11_21',False,56,[]),
      ('twentyone_one_excess','twentyone_one_excess_10_21',True,56,['10']),
      ('twentyone_ten_residual','twentyone_ten_residual_10_21',False,56,[]),
      ('twentyone_residual_ranges','twentyone_residual_11_21_threshold58',False,58,[])]
    report=dict(verified=False,input_hashes=manifest['files'],manifest_sha256=hashlib.sha256((ROOT/mf).read_bytes()).hexdigest(),arithmetic=arithmetic(),variant_runs=runs)
    with tempfile.TemporaryDirectory(prefix='finish21_review_') as temp:
        temp=Path(temp)
        for stem,receipt,excess,threshold,args in jobs:
            original=(ROOT/f'src/sparse_finish_{stem}.cpp').read_text();generated=variant(original,excess)
            digest=hashlib.sha256(generated.encode()).hexdigest()
            reused=next((r for r in old.get('variant_runs',[]) if r.get('variant_sha256')==digest and r['complete']),None)
            if reused:runs.append(reused);continue
            path=temp/f'{stem}.cpp';exe=temp/stem;path.write_text(generated)
            subprocess.run(['c++','-O3','-std=c++17',str(path),'-o',str(exe)],check=True)
            proc=subprocess.run([str(exe),*args,'600'],capture_output=True,text=True,timeout=620)
            assert proc.returncode==0,(stem,proc.stdout,proc.stderr)
            data=json.loads(proc.stdout);frozen=json.loads((ROOT/f'research/sparse_finish_{receipt}.json').read_text())
            assert data['complete'] and data['upper_if_complete']==threshold,(stem,data)
            for key in ('nodes','game_decisions','evaluated_threshold_survivors','camping_rejects','guarded_checks','guarded_rejects','degree_patterns','excess_patterns','completed_patterns','completed_partitions'):
                if key in frozen:assert data[key]==frozen[key],(stem,key,data[key],frozen[key])
            audit=proc.stderr.strip().split();assert audit[0]=='AUDIT' and len(audit)==4
            data.update(family=stem,independent_leaf_maximum=int(audit[1]),guarded_samples=int(audit[2]),sampled_losing_pairs=int(audit[3]),variant_sha256=digest,source_sha256=hashlib.sha256(original.encode()).hexdigest())
            runs.append(data);OUT.write_text(json.dumps(report,indent=2)+'\n')
            print(json.dumps(dict(family=stem,complete=True,seconds=data['seconds'],leaf_max=data['independent_leaf_maximum'])),flush=True)
    literals=[]
    for name in ('56_ten','58','60'):
        p=f'research/sparse_finish_twentyone_{name}_certificate.json';g=json.loads((ROOT/p).read_text());literals.append(dict(path=p,review=review(g),n=g['n'],I=g['I']))
    report.update(verified=True,status='passed',claims=['M_E(19)<=49','M_E(21)=60','M(10,21)=56','M(11,21)=58','M(n,21)=60 for every n>=12'],literal_reviews=literals,
      reviewer_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      boundary='Ordinary reductions and finite coverage reviewed independently. All surviving leaves replayed by explicit alternating attractor. Graph generators and prunes inherited from frozen source, not a separately implemented full graph enumeration. Concrete Lean instantiation not claimed.')
    OUT.write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Construct an attaining graph for every n>=106, 2n<=m<=n(n-3).

This dispatches the proved overlapping families in Theorems52,38,59,48,58.
Finite parameters are read from their checked source artifacts;116 uses its
mixed antichain and117 its separate protected envelope. Orders106..114 use
fixed certified sparse envelopes, protected circles, and the even20-vertex
core with weight-three codes. No game search or
floating-point parameter selection is used. Output vertices are0,...,n-1.

Usage: python3 src/main_interval_composed.py N M --out graph.json
       python3 src/main_interval_composed.py --check

The checks are bounded structural and two-move checks, not a new Lean claim.
"""
from __future__ import annotations
from functools import lru_cache
from itertools import islice
from math import gcd
from pathlib import Path
import argparse,hashlib,json,time

ROOT=Path(__file__).resolve().parents[1]
EXTRAS=((1,-3,5),(3,-3,5),(4,-3,0),(4,3,1),(2,3,0),
        (3,3,0),(3,-3,0),(5,-2,0))
BLOCKED=((0,1,-3,5),(0,3,-3,5),(1,1,-3,5),(1,3,-3,5),
         (1,3,3,0),(2,3,-3,5),(2,4,-3,0))

def integer_cube_ceiling(value):
    """Least integer t with t³>=value, using only exact integer operations."""
    if value<0:raise ValueError('The cube-root argument must be nonnegative.')
    if value==0:return 0
    lo,hi=0,1<<((value.bit_length()+2)//3)
    while lo+1<hi:
        mid=(lo+hi)//2
        if mid**3>=value:hi=mid
        else:lo=mid
    assert (hi-1)**3<value<=hi**3
    return hi

@lru_cache(maxsize=1)
def finite_data():
    raw=json.loads((ROOT/'research/core-code-circle-overlap-screen.json').read_text())
    rows={x['n']:x for x in raw['rows']}
    mixed=json.loads((ROOT/'research/routing-defect-phase2-mixed-code-checks.json').read_text())
    assert all(n in rows for n in range(115,391)) and mixed['verified']
    return rows,mixed

@lru_cache(maxsize=1)
def third_finite_data():
    raw=json.loads((ROOT/'research/core-code-third-circle-envelopes.json').read_text())
    circles={x['n']:x for x in raw['rows']}
    registry=json.loads((ROOT/'research/sparse-interface-third-proof-registry.json').read_text())
    sparse={x['n']:x for x in registry['records']
            if 106<=x['n']<=114 and x['variant']==('repair109' if x['n']==109 else None)}
    assert all(n in circles for n in range(106,112))
    assert set(sparse)==set(range(106,115))
    return circles,sparse

def verify_circle(n,core,values):
    core=tuple(core);values=set(values)
    assert len(core)==3 and 0 in values and set(core)<=values
    assert all(0<=v<n for v in values)
    h=core[2]
    assert core==(1,(h-1)//2,h) and h>=7 and h%2 and gcd(h,n)==1
    assert 2*h<=n-1
    differences={(u-v)%n for u in core for v in core if u!=v}
    assert len(differences)==6
    for d in differences:
        actual={(u,(u-d)%n) for u in values if (u-d)%n in values}
        expected={(u,v)for u in core for v in core if(u-v)%n==d}
        assert actual==expected and len(expected)==1
    return tuple(sorted(differences))

@lru_cache(maxsize=64)
def parameters(n):
    if n<106:raise ValueError('The proved complete main interval requires n>=106.')
    if n<115:
        circles,sparse=third_finite_data()
        row=circles[n] if n<=111 else finite_data()[0][n]
        h=row['h'];values=tuple(row['A'] if n<=111 else row['Aset'])
        core=(1,(h-1)//2,h)
        k,weight=10,3
    elif n<=390:
        rows,mixed=finite_data();row=rows[n]
        h=row['h'];values=tuple(row['Aset'])
        if n==117:
            special=mixed['envelope117'];h=special['h'];values=tuple(special['A'])
        core=(1,(h-1)//2,h)
        k,weight=row['k'],row['r']
    else:
        from main_interval_resume import move_envelope
        core,values,_=move_envelope(n)
        if n<=480:k,weight=15,4
        elif n<=699:k,weight=17,5
        else:
            k=integer_cube_ceiling(6*n)+5
            if k%2==0:k+=1
            weight=3
            assert (k-5)**3>=6*n and (k-7)**3<6*n
    differences=verify_circle(n,core,values)
    outside=n-2*k
    if n<115:
        from core_code_all_parities import capacity
        assert k==10 and weight==3 and 0<=outside<=capacity(k,weight)==100
    else:
        from core_code_composition import capacity
        assert k>=7 and k%2 and outside>=0 and outside<=2*capacity(k,weight)
    W=weight*outside
    if n==116:
        W=sum(map(len,finite_data()[1]['mixed116']['codes']))
        assert W==378
    code_base=2*k*(2*k-3)+4*k*outside-W
    code_max=code_base+outside*(outside-1)
    terminal_missing=4*k+W
    circle_max=n*(len(values)-1)
    sparse_k=(n+5)//6;holes=6*sparse_k-n
    sparse_max=20*sparse_k-11*holes
    if n<115:
        record=sparse[n]
        assert record['m_min']==2*n
        assert record['m_max']==sparse_max+(2 if n==109 else 0)
        sparse_max=record['m_max']
    dense_max=n*max(3,(n+11)//13)
    assert sparse_max>=3*n and circle_max>=code_base
    assert code_max==n*(n-1)-terminal_missing
    assert 2*n<=terminal_missing<=dense_max
    assert circle_max>=3*n and code_max>=code_base
    result={'n':n,'sparse_k':sparse_k,'hole_count':holes,'sparse_max':sparse_max,
            'circle_core':tuple(core),'circle_values':tuple(values),
            'protected_differences':differences,'circle_max':circle_max,
            'code_k':k,'code_weight':weight,'code_outside':outside,
            'code_total_weight':W,'code_base':code_base,'code_max':code_max,
            'code_terminal_missing':terminal_missing,'dense_missing_max':dense_max}
    if n<115:
        result.update(sparse_finite_variant=record['variant'],
                      sparse_finite_maximum_moves=record['maximum_moves'],
                      sparse_certificate_member=record['member'])
    return result

def sparse_arcs(n,m,p):
    k=p['sparse_k'];r=p['hole_count'];holes={3*j for j in range(r)}
    vertices=[(i,j)for i in range(k)for j in range(6)if j!=4 or i not in holes]
    index={v:a for a,v in enumerate(vertices)}
    def arrows(i,j):
        if j==0:return ((i,1),(i,5))
        if j==1:return ((i,2),(i+2,2)if(i+1)%k in holes else(i+1,4))
        if j==2:return ((i,3),(i+1,1))
        if j==3:return ((i,5)if i in holes else(i,4),(i-1,0))
        if j==4:return ((i,5),(i+1,2))
        if j==5:return ((i+1,0),(i-1,3))
        raise AssertionError(j)
    base={(index[(i,j)],index[(u%k,t)])for i,j in vertices for u,t in arrows(i,j)}
    optional=set()
    for i,j in vertices:
        for typ,d,t in EXTRAS:
            if j==typ and not any(((i-h)%k,j,d,t)in BLOCKED for h in holes):
                optional.add((index[(i,j)],index[((i+d)%k,t)]))
    assert len(vertices)==n and len(base)==2*n and len(optional)==8*k-9*r
    if p.get('sparse_finite_variant')=='repair109':
        assert n==109
        restored={(index[(1,3)],index[(4,0)]),(index[(2,3)],index[(18,5)])}
        assert restored=={(8,22),(14,108)} and restored.isdisjoint(base|optional)
        optional|=restored
    assert base.isdisjoint(optional) and 2*n<=m<=len(base)+len(optional)
    base.update(islice(iter(sorted(optional)),m-2*n))
    return base,{'k':k,'holes':sorted(holes),'optional_count':len(optional),
                 'maximum_delivery_moves':p.get('sparse_finite_maximum_moves',9*k+21)}

def circle_arcs(n,m,p):
    core=p['circle_core'];values=p['circle_values']
    base={(v,(v+d)%n)for v in range(n)for d in core}
    extras=((v,(v+d)%n)for v in range(n)for d in sorted(set(values)-{0,*core}))
    assert 3*n<=m<=p['circle_max']
    base.update(islice(extras,m-3*n))
    return base,{'core_steps':core,'closed_envelope':values,
                 'protected_differences':p['protected_differences']}

def validate_codes(k,codes):
    masks=[];sizes=[]
    for S in codes:
        assert len(S)>=3 and all(0<=u<2*k for u in S)
        point=all(u<k for u in S);line=all(u>=k for u in S)
        assert point or line
        inds={u%k for u in S};gap=2 if point else 1
        assert all((u+gap)%k not in inds for u in inds)
        masks.append(sum(1<<u for u in S));sizes.append(len(S))
    assert len(set(masks))==len(masks)
    # Equal-sized distinct sets are automatically incomparable.
    for i,a in enumerate(masks):
        for j,b in enumerate(masks):
            if sizes[i]<sizes[j]:assert a&b!=a

def code_arcs(n,m,p):
    k=p['code_k'];outside=p['code_outside'];weight=p['code_weight']
    if n==116:codes=[frozenset(S)for S in finite_data()[1]['mixed116']['codes']]
    elif n<115:
        from core_code_all_parities import codes as equal_codes
        codes=equal_codes(k,weight,outside)
    else:
        from core_code_composition import codes as equal_codes
        codes=equal_codes(k,weight,outside)
    assert len(codes)==outside and sum(map(len,codes))==p['code_total_weight']
    validate_codes(k,codes)
    missing={(u,v)for i in range(k)for u,v in
             ((i,k+i),(i,k+(i-1)%k),(k+i,(i+4)%k),(k+i,(i+6)%k))}
    base={(s,t)for s in range(2*k)for t in range(2*k)if s!=t and(s,t)not in missing}
    base|={(s,t)for s in range(2*k)for t in range(2*k,n)}
    base|={(2*k+j,t)for j,S in enumerate(codes)for t in range(2*k)if t not in S}
    assert len(base)==p['code_base'] and p['code_base']<=m<=p['code_max']
    optional=((s,t)for s in range(2*k,n)for t in range(2*k,n)if s!=t)
    base.update(islice(optional,m-p['code_base']))
    return base,{'k':k,'outside':outside,'code_sizes':sorted(set(map(len,codes))),
                 'total_code_weight':p['code_total_weight'],'codes':[sorted(S)for S in codes],
                 'maximum_delivery_moves':2}

def dense_arcs(n,m,p):
    h=n*(n-1)-m
    if h>=3*n:
        from dense_protected_envelope import construct as protected_missing
        missing,values=protected_missing(n,h)
        branch='dense_protected';detail={'missing_offsets':values}
    else:
        from dense_unified_core import envelope
        base,optional=envelope(n)
        assert 2*n<=h<=3*n and len(base)==2*n
        missing=base|set(islice(iter(sorted(optional)),h-2*n))
        branch='dense_direct';detail={}
    assert len(missing)==h
    arcs={(s,t)for s in range(n)for t in range(n)if s!=t and(s,t)not in missing}
    return arcs,branch,{'missing_count':h,'maximum_delivery_moves':2,**detail}

def construct(n,m):
    if n<106 or not 2*n<=m<=n*(n-3):
        raise ValueError('Requires n>=106 and2n<=m<=n(n−3).')
    p=parameters(n)
    if m<=p['sparse_max']:
        arcs,detail=sparse_arcs(n,m,p);branch='sparse_packed'
    elif m<=p['circle_max']:
        arcs,detail=circle_arcs(n,m,p);branch='protected_circle'
    elif m<=p['code_max']:
        arcs,detail=code_arcs(n,m,p);branch='core_antichain'
    else:arcs,branch,detail=dense_arcs(n,m,p)
    assert len(arcs)==m and all(0<=s<n and 0<=t<n and s!=t for s,t in arcs)
    return {'n':n,'m':m,'I':n*(n-1)-m,'branch':branch,'parameters':detail,
            'arcs':sorted(arcs)}

def independent_two_move_check(graph):
    """Check actual nonedges with independently rebuilt bit-set neighborhoods."""
    n=graph['n'];rows=[0]*n;incoming=[0]*n;full=(1<<n)-1
    for s,t in graph['arcs']:rows[s]|=1<<t;incoming[t]|=1<<s
    closed=[row|(1<<c)for c,row in enumerate(rows)]
    checks=0
    for s in range(n):
        absent=full&~closed[s]
        while absent:
            bit=absent&-absent;t=bit.bit_length()-1;absent-=bit
            mids=rows[s]&incoming[t]
            for c in range(n):
                if c!=s:assert mids&~closed[c],(n,graph['m'],s,t,c)
            checks+=n-1
    return checks

def run_checks():
    start=time.monotonic();rows=[];witnesses=[];branches=set()
    orders=tuple(range(106,115))+(115,116,117,118,120,390,391,480,481,699,700,701)
    for n in orders:
        p=parameters(n);last=n*(n-3);split=n*(n-1)-3*n
        points={2*n,2*n+1,3*n,last,split-1,split,split+1}
        for edge in(p['sparse_max'],p['circle_max'],p['code_base'],p['code_max']):
            points.update((edge-1,edge,edge+1))
        seen_at_order=set()
        for m in sorted(x for x in points if 2*n<=x<=last):
            graph=construct(n,m);arcs=graph['arcs'];branch=graph['branch'];branches.add(branch)
            assert len(arcs)==len(set(map(tuple,arcs)))==m
            assert all(s!=t and 0<=s<n and 0<=t<n for s,t in arcs)
            if n<=117 and branch in('core_antichain','dense_protected','dense_direct') and branch not in seen_at_order:
                witnesses.append({'n':n,'m':m,'branch':branch,'triples':independent_two_move_check(graph)})
            seen_at_order.add(branch)
            rows.append({'n':n,'m':m,'branch':branch})
    # Parameter-only checks include the complete finite range and all rule boundaries.
    for n in range(106,391):parameters(n)
    for n in(391,480,481,699,700,701,999,1000,10**6,10**12):
        if n>=700:
            k=integer_cube_ceiling(6*n)+5;k+=not(k%2)
            assert(k-5)**3>=6*n and(k-7)**3<6*n and 2*k<=n
    assert branches=={'sparse_packed','protected_circle','core_antichain','dense_protected','dense_direct'}
    return {'verified':True,'boundary_constructions':len(rows),'orders':orders,
            'branches':sorted(branches),'independent_two_move_checks':witnesses,
            'finite_parameter_orders':285,'seconds':time.monotonic()-start,
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'scope':'Exact counts and structural overlap at stated orders; actual two-move witnesses only for listed small graphs; no new full sparse/circle game search or Lean claim.',
            'constructions':rows}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('n',type=int,nargs='?');ap.add_argument('m',type=int,nargs='?')
    ap.add_argument('--out',type=Path);ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    if args.check:data=run_checks()
    else:
        if args.n is None or args.m is None:ap.error('Provide both N and M, or use --check.')
        data=construct(args.n,args.m)
    text=json.dumps(data,indent=2)+'\n'
    if args.out:
        args.out.write_text(text)
        print(json.dumps({k:v for k,v in data.items()if k not in('arcs','constructions')}))
    else:print(text,end='')

if __name__=='__main__':main()

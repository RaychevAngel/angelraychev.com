#!/usr/bin/env python3
"""Recipient-specific interface synthesis, with explicit bounded scope."""
import json,time,hashlib
from pathlib import Path
from composition_interface_free_group import arena,ball
from composition_interface_invariant import attract,mul,inv
ROOT=Path(__file__).resolve().parents[1]

def main():
 ar=arena((0,1,3));M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1
 iw=ball(2);IC=[(w,i) for w in iw for i in range(10)]+[(None,i) for i in range(10)];ii={v:i for i,v in enumerate(IC)}
 maps=[]
 for w,rtype in M:
  row=[]
  for cw,ctype in C:
   if cw is None:poss=[ii[(None,ctype)]]+[ii[(v,ctype)] for v in iw if len(mul(w,v))>3]
   else:
    v=mul(inv(w),cw);poss=[ii[(v,ctype)] if len(v)<=2 else ii[(None,ctype)]]
   row.append(sum(1<<x for x in poss))
  maps.append(row)
 records=[];start=time.monotonic()
 for target in (0,6,2,3,9):
  I=[((1<<len(IC))-1)^(1<<ii[((),i)]) for i in range(10)]
  tr=mi[((1,),target)];W,terminal_rounds=attract(ar,[allc if r==tr else 0 for r in range(len(M))],{tr})
  for typ in range(10):
   for c,poss in enumerate(maps[mi[((),typ)]]):
    if not (W[mi[((),typ)]]>>c&1):I[typ]&=~poss
  initial=sum(x.bit_count() for x in I);trace=[];fixed=False
  print('target',target,'initial',initial,'terminal_rounds',terminal_rounds,flush=True)
  for iteration in range(12):
   J=I[:]
   for g in (-1,-2):
    seeds=[sum(1<<c for c,poss in enumerate(maps[r]) if poss&~I[typ]==0) if w==(g,) else 0 for r,(w,typ) in enumerate(M)]
    W,rounds=attract(ar,seeds)
    for typ in range(10):
     root=mi[((),typ)]
     for c,poss in enumerate(maps[root]):
      if not (W[root]>>c&1):J[typ]&=~poss
    trace.append({'iteration':iteration,'generator':g,'rounds':rounds})
   print('iteration',iteration,'remaining',sum(x.bit_count() for x in J),flush=True)
   if J==I:fixed=True;break
   I=J
  seeds=[sum(1<<c for c,poss in enumerate(maps[r]) if poss&~I[typ]==0) for r,(w,typ) in enumerate(M)]
  W,norm_rounds=attract(ar,seeds)
  bad=[(i,c) for i in range(10) for c in range(len(C)) if c!=ci[((),i)] and not (W[mi[((),i)]]>>c&1)]
  rec={'target':target,'target_word':[1],'initial_interface_states':initial,'remaining':sum(x.bit_count() for x in I),'fixed':fixed,'normalization_failed':len(bad),'normalization_rounds':norm_rounds,'terminal_rounds':terminal_rounds,'trace':trace,'interface_masks':I};records.append(rec)
  print({k:v for k,v in rec.items() if k not in ('interface_masks','trace')},flush=True)
 out={'scope':'finite target-specific local interfaces; no infinite universality claim without simulation audit','seconds':time.monotonic()-start,'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'research/composition-interface-target-invariant.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Phase-two exploration: resynthesize policies near sparse smoothing defects.

The asymmetric arena retains base messenger arrows while granting selected
optional arrows to the pursuer. Successful checks are finite local claims;
an infinite construction additionally needs a projection and coverage proof.
"""
from __future__ import annotations
import argparse
import json
import time
from pathlib import Path
from five_type_certificate import arena, solve, verify
from sparse_composition_smoothing import SmoothStrip
from sparse_composition_spacing import SIGMA, VOLTAGE
from six_type_budget_certificate import EXTRAS

ROOT = Path(__file__).resolve().parents[1]


def typed_hub_arena(holes=(), M=4, R=8, hub_type=0):
    """Permit arbitrary long cop jumps to one type, except static traps.

    This is exploratory. The outside state may reenter every hub vertex,
    as well as the two boundary layers used by the smoothed base graph.
    """
    strip = SmoothStrip(SIGMA, VOLTAGE, 4, holes)
    a = arena(strip,messenger_radius=M,pursuer_radius=R)
    cv=a['pursuer_vertices']; ci={v:i for i,v in enumerate(cv)}
    omega=len(cv)-1
    local=[(i,j)for i in range(-R-5,R+6)for j in strip.types(i)]
    pairs=[(v,set(strip.arcs(v)))for v in local]
    pred={}
    for v,p in pairs:
        for z in p: pred.setdefault(z,set()).add(v)
    pp=[p for v,p in pred.items() if abs(v[0])<=R+2 and len(p)==2]
    for c,v in enumerate(cv[:-1]):
        base={v,*strip.arcs(v)}
        allowed=[]
        for u in cv[:-1]:
            if u[1]!=hub_type or u==v:continue
            closed=base|{u}
            if any(s!=v and p<=closed for s,p in pairs):continue
            if any(p<=closed for p in pp):continue
            allowed.append(ci[u])
        a['pursuer_moves'][c]=sorted(set(a['pursuer_moves'][c]+allowed+[omega]))
    a['pursuer_moves'][-1]=[c for c,v in enumerate(cv) if v is None or
                          v[1]==hub_type or abs(v[0])>=R-1]
    return a


def build(holes=(), M=4, R=8, excluded=(), exclude_radius=-1, extras=EXTRAS,
          blocked_rules=()):
    strip = SmoothStrip(SIGMA, VOLTAGE, 4, holes)
    a = arena(strip, messenger_radius=M, pursuer_radius=R)
    cv = a['pursuer_vertices']
    ci = {v: i for i, v in enumerate(cv)}
    excluded = set(excluded)
    blocked_rules = set(blocked_rules)
    for c, v in enumerate(cv[:-1]):
        i, j = v
        if any(abs(i-h) <= exclude_radius for h in holes):
            continue
        for typ, delta, target in extras:
            if (typ == j and (i, typ, delta, target) not in excluded
                and not any((i-h,typ,delta,target) in blocked_rules for h in holes)):
                a['pursuer_moves'][c].append(ci.get((i+delta, target), len(cv)-1))
        a['pursuer_moves'][c] = sorted(set(a['pursuer_moves'][c]))
    a['pursuer_moves'][-1] = [c for c,v in enumerate(cv)
                              if v is None or abs(v[0]) >= R-2]
    return a


def check(holes=(), M=4, R=8, excluded=(), exclude_radius=-1,
          extras=EXTRAS, stop_early=False, blocked_rules=()):
    a = build(holes, M, R, excluded, exclude_radius, extras, blocked_rules)
    rv, cv = a['messenger_vertices'], a['pursuer_vertices']
    rows = []
    for target in [None] + [j for j in range(6) if not (0 in holes and j == 4)]:
        goal = [v for v in rv if v[0] == 0 and (target is None or v[1] == target)]
        cert = solve(a, goal, target is None)
        source = -1 if target is None else -2
        failures = [(v,w) for r,v in enumerate(rv) if v[0] == source
                    for c,w in enumerate(cv) if v != w and cert['ranks'][r][c] < 0]
        row = {'target':target, 'failures':len(failures), 'first':failures[:4]}
        if not failures:
            row['max_moves'] = max(verify(a,cert,source))
        rows.append(row)
        if failures and stop_early:
            break
    return {'holes':list(holes), 'M':M, 'R':R, 'exclude_radius':exclude_radius,
            'passed':all(not row['failures'] for row in rows), 'objectives':rows}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--holes', default='0')
    ap.add_argument('--M',type=int, default=4)
    ap.add_argument('--R',type=int, default=8)
    ap.add_argument('--exclude-radius',type=int,default=-1)
    ap.add_argument('--stop-early',action='store_true')
    ap.add_argument('--out',type=Path,default=ROOT/'research/composition-budget-phase2-first-screen.json')
    args = ap.parse_args()
    start = time.monotonic()
    holes = [] if not args.holes else list(map(int,args.holes.split(',')))
    result = check(holes,args.M,args.R,exclude_radius=args.exclude_radius,
                   stop_early=args.stop_early)
    result['seconds'] = time.monotonic()-start
    args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()

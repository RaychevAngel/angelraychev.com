#!/usr/bin/env python3
"""Independent explicit rank audit of the six-type deleted-arc odd family."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path

import six_type_independent_verify as independent

ROOT = Path(__file__).resolve().parents[1]


def outgoing(position, defect):
    i, j = position
    first = (i, j + 1) if j < 5 else (i + 1, 0)
    second = ((i - 1, 0), (i - 1, 2), (i + 1, 5),
              (i + 1, 1), (i - 1, 4), (i + 1, 3))[j]
    return [second] if position == (defect, 0) else [first, second]


def arena(defect):
    messenger = [(i, j) for i in range(-4, 5) for j in range(6)]
    cops = [(i, j) for i in range(-6, 7) for j in range(6)] + [None]
    mi = {v: i for i, v in enumerate(messenger)}
    ci = {v: i for i, v in enumerate(cops)}
    omega = ci[None]
    mm = [[mi[v] for v in [p, *outgoing(p, defect)] if v in mi] for p in messenger]
    cm = []
    for p in cops:
        if p is None:
            cm.append([omega] + [i for i, v in enumerate(cops) if v is not None and abs(v[0]) >= 5])
        else:
            cm.append(sorted({ci.get(v, omega) for v in [p, *outgoing(p, defect)]}))
    return {"messenger": messenger, "cops": cops, "messenger_moves": mm, "cop_moves": cm}


def game(a, defect, target):
    nr, nc = len(a["messenger"]), len(a["cops"])
    count = 2 * nr * nc
    successors = [[] for _ in range(count)]
    success = [False] * count
    collision = [False] * count
    low_source = (defect, 0)
    for r, p in enumerate(a["messenger"]):
        for c, cop in enumerate(a["cops"]):
            for turn in (0, 1):
                state = 2 * (r * nc + c) + turn
                if target is None:
                    success[state] = turn == 0 and p[0] == 0 and p != low_source and p != cop
                else:
                    success[state] = p == (0, target)
                collision[state] = p == cop and not success[state]
                if success[state] or collision[state]:
                    continue
                if turn == 0:
                    successors[state] = [2 * (u * nc + c) + 1 for u in a["messenger_moves"][r]]
                else:
                    successors[state] = [2 * (r * nc + u) for u in a["cop_moves"][c]]
    return successors, success, collision


def certificates(defect):
    a = arena(defect)
    nc = len(a["cops"])
    modules = []
    for target in [None, *[j for j in range(6) if (0, j) != (defect, 1)]]:
        successors, success, collision = game(a, defect, target)
        rank, move = independent.attractor(successors, success)
        independent.check_certificate(successors, success, collision, rank, move)
        column = -1 if target is None else -2
        starts = [2 * (r * nc + c) for r, p in enumerate(a["messenger"])
                  if p[0] == column and p != (defect, 0)
                  for c, cop in enumerate(a["cops"]) if cop != p]
        failures = [s for s in starts if rank[s] < 0]
        modules.append({"defect_column": defect, "target_type": target,
                        "required_starts": len(starts), "failed_starts": failures,
                        "messenger_moves_bound": None if failures else (max(rank[s] for s in starts) + 1) // 2,
                        "ranks": rank, "chosen_messenger_successors": move})
    return modules


def main():
    modules = [c for defect in [None, *range(-6, 7)] for c in certificates(defect)]
    failures = [{k: v for k, v in c.items() if k not in ("ranks", "chosen_messenger_successors")}
                for c in modules if c["failed_starts"]]
    payload = {"verified": not failures,
               "family": {"second_type_permutation": [0, 2, 5, 1, 4, 3], "second_column_shifts": [-1, -1, 1, 1, -1, 1]},
               "deleted_arc": [[0, 0], [0, 1]],
               "arena": "Messenger +/-4; cop +/-6 with Omega wait/reentry +/-5,+/-6; safe transfer excludes low-out source at start and goal, delivery excludes low-in target.",
               "state_encoding": "Vertices lexicographic; cop Omega last. State 2*(r*nc+c)+turn; turn0 messenger.",
               "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "explicit_solver_sha256": hashlib.sha256(Path(independent.__file__).read_bytes()).hexdigest(),
               "certificates": modules}
    path = ROOT / "research/six-type-independent-odd-certificates.json.gz"
    with path.open("wb") as destination:
        with gzip.GzipFile(filename="", fileobj=destination, mode="wb", mtime=0) as stream:
            stream.write((json.dumps(payload, separators=(",", ":")) + "\n").encode())
    summary = {"verified": not failures, "modules": len(modules),
               "required_starts_checked": sum(c["required_starts"] for c in modules),
               "states_checked": sum(len(c["ranks"]) for c in modules),
               "max_transfer_moves": max((c["messenger_moves_bound"] or 0) for c in modules if c["target_type"] is None),
               "max_delivery_moves": max((c["messenger_moves_bound"] or 0) for c in modules if c["target_type"] is not None),
               "failed_modules": failures,
               "certificate_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
               "checker_sha256": payload["checker_sha256"],
               "explicit_solver_sha256": payload["explicit_solver_sha256"]}
    (ROOT / "research/six-type-independent-odd-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "failed_modules"} | {"failed_modules": len(failures)}))


if __name__ == "__main__":
    main()

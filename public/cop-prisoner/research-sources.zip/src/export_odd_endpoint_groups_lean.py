#!/usr/bin/env python3
"""Export the two strong frozen odd archives to the concrete padded Lean arena.

No graph or policy search is performed. Every required initial cop is retained;
policy reachability includes every legal cop reply. Kernel proofs recheck the
literal arena, all group obligations, and original entry bounds independently.
"""
from __future__ import annotations
import argparse
from collections import defaultdict, deque
import gzip
import hashlib
import json
from pathlib import Path

from odd_projection_threshold_check import SPECS, arena
from export_low_band_lean import seq, lookup_tree

ROOT = Path(__file__).resolve().parents[1]
SOURCES = {
    'research/six-type-independent-odd-certificates.json.gz':
        '55fd90051afbcee7d7bea7a5bdf8a97c69056c0562ed97d331e20553bba5324f',
    'research/six-type-independent-odd-residues-certificates.json.gz':
        '95c5c40124b6109fb1e48acdff6a864fd9e35cc3f22d542432242aba67715b76',
}
TRANSFER = [14, 9, 17, 34, 28, 9]
DELIVERY = [26, 22, 26, 23, 27, 26]


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def header(imports, name):
    return f'''{imports}
/- Translation of immutable odd-endpoint local strategies; see the export
manifest for exact archive and record pins. The exporter is untrusted.
All finite game and entry obligations below are checked by the Lean kernel. -/
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open LocalArena OddEndpointLocal OddEndpointCertificatesSpec GroupedArena
'''


def pattern_text(index, residue, anchor):
    patch, mv, cv, mm, cm = arena(SPECS[residue], anchor)
    rm = [(x+5)*6+j for x,j in mv]
    cp = [90 if v is None else (v[0]+7)*6+v[1] for v in cv]
    replies = [[] for _ in range(91)]
    for i,c in enumerate(cp):
        replies[c] = [cp[d] for d in cm[i]]
    reply_masks = [sum(1 << d for d in row) for row in replies]
    present = set(rm)
    collision_masks = [1 << (x+12) if x in present else (1 << 91)-1 for x in range(66)]
    valid = sum(1 << c for c in cp)
    required_masks = [valid & ~collision_masks[x] if x in present else 0 for x in range(66)]
    name = f'OddEndpointPattern{index:03}'
    literal_anchor = 'none' if anchor is None else f'some ({anchor})'
    text = header('import OddEndpointCertificatesSpec\nimport GroupedInitialMasks', name)
    text += f'''def residue : OddEndpointGraph.Case := {residue}
def patchAnchor : Option Int := {literal_anchor}
def frozenArena : Arena R C := arena residue patchAnchor
instance (x z : R) : Decidable (frozenArena.messenger x z) :=
  inferInstanceAs (Decidable ((arena residue patchAnchor).messenger x z))
instance (c d : C) : Decidable (frozenArena.pursuer c d) :=
  inferInstanceAs (Decidable ((arena residue patchAnchor).pursuer c d))
instance (x : R) (c : C) : Decidable (frozenArena.collision x c) :=
  inferInstanceAs (Decidable ((arena residue patchAnchor).collision x c))
theorem arena_eq : frozenArena=arena residue patchAnchor := rfl
def replyBits (r : Nat) : Nat := {lookup_tree(reply_masks)}
def replyMasks (c : C) : Nat := replyBits c.val
def collisionBits (r : Nat) : Nat := {lookup_tree(collision_masks)}
def collisionMasks (x : R) : Nat := collisionBits x.val
def requiredBits (r : Nat) : Nat := {lookup_tree(required_masks)}
def requiredMasks (x : R) : Nat := requiredBits x.val
def validMask : Nat := {valid}
theorem reply_cases : ∀ c, presentC residue patchAnchor c →
    if c=outside then ∀ d, presentC residue patchAnchor d →
      (d=outside ∨ boundary residue d) → Has (replyMasks c) d
    else Has (replyMasks c) c ∧ ∀ b : Bool, permitted residue patchAnchor (cvertex c) b →
      Has (replyMasks c) (pack residue (next residue patchAnchor b (cvertex c))) := by
  unfold Has
  decide +kernel
theorem reply_coverage : ∀ c d, frozenArena.pursuer c d → Has (replyMasks c) d := by
  intro c d move
  obtain ⟨pc,pd,step⟩ := move
  have covered := reply_cases c pc
  by_cases out : c=outside
  · rw [if_pos out] at step covered
    exact covered d pd step
  · rw [if_neg out] at step covered
    rcases step with wait|⟨b,allowed,same⟩
    · simpa only [wait] using covered.1
    · rw [same]
      exact covered.2 b allowed
theorem collision_rows : ∀ x,
    (presentR residue patchAnchor x → Has (collisionMasks x) (pack residue (rvertex x))) ∧
    (¬presentR residue patchAnchor x → collisionMasks x=2^91-1) := by
  unfold Has
  decide +kernel
theorem collision_coverage : ∀ x c, frozenArena.collision x c → Has (collisionMasks x) c :=
  GroupedInitialMasks.collision_coverage (presentR residue patchAnchor)
    (fun x => pack residue (rvertex x)) collisionMasks collision_rows
theorem valid_bits : ∀ c, presentC residue patchAnchor c → Has validMask c := by
  unfold Has
  decide +kernel
theorem required_rows : ∀ x, presentR residue patchAnchor x →
    requiredMasks x=validMask ^^^ 2^(pack residue (rvertex x)).val := by
  decide +kernel
theorem required_coverage : ∀ x c, presentR residue patchAnchor x → presentC residue patchAnchor c →
    ¬(arena residue patchAnchor).collision x c → Has (requiredMasks x) c :=
  GroupedInitialMasks.required_coverage (presentR residue patchAnchor) (presentC residue patchAnchor)
    (fun x => pack residue (rvertex x)) validMask requiredMasks valid_bits required_rows
#print axioms arena_eq
#print axioms required_coverage
end Delivery.{name}
'''
    return name, text, (patch,mv,cv,mm,cm,rm,cp)


def reachable_groups(residue, record, model):
    patch,mv,cv,mm,cm,rm,cp = model
    nc = len(cv)
    ranks = record['ranks']
    chosen = record['chosen_messenger_successors']
    target = record['target_type']
    assert len(ranks) == len(chosen) == 2*len(mv)*nc
    columns = {-SPECS[residue]['direction']} if target is None else {
        -SPECS[residue]['direction']*d for d in ((2,3) if residue==5 else (2,))}
    starts = {(x,c) for x,v in enumerate(mv) if v[0] in columns and v!=patch.source
              for c,cop in enumerate(cv) if v!=cop}
    assert len(starts)==record['required_starts'] and not record['failed_starts']
    if target is not None:
        assert (0,target) not in patch.removed and (0,target)!=patch.target
    groups = [defaultdict(list) for _ in range(66)]
    seen = set(starts)
    queue = deque(sorted(starts))
    reply_edges = 0
    while queue:
        x,c = queue.popleft()
        sid = 2*(x*nc+c)
        rank = ranks[sid]
        assert rank>=0 and mv[x]!=cv[c]
        goal = (mv[x][0] in ({0,-1} if residue==5 else {0}) and mv[x]!=patch.source
                if target is None else mv[x]==(0,target))
        if goal:
            z=x
            assert rank==0
        else:
            child=chosen[sid]
            assert child%2==1 and child//2%nc==c
            z=child//2//nc
            assert z in mm[x] and rank>0
            if target is None or mv[z]!=(0,target):
                assert mv[z]!=cv[c]
                for d in cm[c]:
                    reply_edges += 1
                    nr=ranks[2*(z*nc+d)]
                    assert nr>=0 and (nr+1)//2<(rank+1)//2 and mv[z]!=cv[d]
                    if (z,d) not in seen:
                        seen.add((z,d));queue.append((z,d))
        groups[rm[x]][(rank+1)//2,rm[z]].append(cp[c])
    bound=max((ranks[2*(x*nc+c)]+1)//2 for x,c in starts)
    assert bound==record['messenger_moves_bound']
    return groups,dict(states=len(seen),groups=sum(map(len,groups)),cop_reply_edges=reply_edges,
        required_starts=len(starts),original_entry_bound=bound,full_alternating_states=len(ranks))


def objective_text(index, residue, record, model):
    target=record['target_type']
    groups,stats=reachable_groups(residue,record,model)
    uniform_bound=TRANSFER[residue] if target is None else DELIVERY[residue]
    bound=stats['original_entry_bound']
    assert bound<=uniform_bound
    encoded=[];bounded=[]
    for row in groups:
        terms=[];mask=0
        for (rank,z),cops in sorted(row.items()):
            cops.sort();bits=sum(1 << c for c in cops)
            assert len(cops)==len(set(cops))
            terms.append(f'{{rank:={rank},move:={z},cops:={seq(cops)},mask:={bits}}}')
            if rank<=bound:mask|=bits
        encoded.append(terms);bounded.append(mask)
    kind='Transfer' if target is None else f'Delivery{target}'
    name=f'OddEndpointObjective{index:03}{kind}'
    pattern=f'OddEndpointPattern{index:03}'
    goal='safeGoal residue patchAnchor' if target is None else f'deliveryGoal residue patchAnchor {target}'
    start='transferEntry' if target is None else 'deliveryEntry'
    bname='transferBound' if target is None else 'deliveryBound'
    mode='false' if target is None else 'true'
    check='safe_checked' if target is None else 'delivery_checked'
    checked='SafeChecked' if target is None else 'DeliveryChecked'
    spec='Transfer residue patchAnchor' if target is None else f'OddEndpointCertificatesSpec.Delivery residue patchAnchor {target}'
    text=header(f'import {pattern}',name)
    text+=f'''open {pattern}
noncomputable def groupRows (r : Nat) : List (Group 66 91) := {lookup_tree(encoded)}
noncomputable def rows (x : R) : List (Group 66 91) := groupRows x.val
noncomputable def data : LocalArena.Data R C := GroupedArena.data rows
theorem groups_checked : Checked {mode} frozenArena ({goal}) replyMasks collisionMasks rows := by
  unfold Checked
  decide +kernel
theorem checked : {checked} (arena residue patchAnchor) ({goal}) data := by
  rw [←arena_eq]
  exact GroupedArena.{check} frozenArena ({goal}) replyMasks collisionMasks rows
    reply_coverage collision_coverage groups_checked
def entryBits (r : Nat) : Nat := {lookup_tree(bounded)}
def boundedMasks (x : R) : Nat := entryBits x.val
def originalBound : Nat := {bound}
theorem bounded_agrees : ∀ x, lowerMask (rows x) (originalBound+1)=boundedMasks x := by
  decide +kernel
theorem entry_subset : ∀ x, {start} residue patchAnchor x →
    requiredMasks x &&& boundedMasks x=requiredMasks x := by
  decide +kernel
theorem initial_states : ∀ x c, {start} residue patchAnchor x → presentC residue patchAnchor c →
    ¬(arena residue patchAnchor).collision x c →
    data.region x c ∧ data.rank x c≤originalBound := by
  intro x c entry pc safe
  apply GroupedArena.bounded rows x c originalBound
  rw [bounded_agrees]
  exact has_subset (entry_subset x entry) (required_coverage x c entry.1 pc safe)
noncomputable def certificate : {spec} where
  data := data
  checked := checked
  starts := by
    intro x c entry pc safe
    obtain ⟨inside,bound⟩ := initial_states x c entry pc safe
    exact ⟨inside,Nat.le_trans bound (by decide : originalBound≤{bname} residue)⟩
#print axioms certificate
end Delivery.{name}
'''
    return name,text,stats


def bundle_text(index, targets):
    objectives=[f'OddEndpointObjective{index:03}'+('Transfer' if t is None else f'Delivery{t}') for t in targets]
    name=f'OddEndpointCertificate{index:03}'
    pattern=f'OddEndpointPattern{index:03}'
    text=header('\n'.join('import '+x for x in objectives),name)
    text+=f'''open {pattern}
noncomputable def certificates : Certificates residue patchAnchor where
  transfer := OddEndpointObjective{index:03}Transfer.certificate
  delivery := by
    intro j allowed
    apply Classical.choice
    have cases : j=0 ∨ j=1 ∨ j=2 ∨ j=3 ∨ j=4 ∨ j=5 := by
      have finite : ∀ j : Fin 6, j=0 ∨ j=1 ∨ j=2 ∨ j=3 ∨ j=4 ∨ j=5 := by decide +kernel
      exact finite j
    rcases cases with rfl|rfl|rfl|rfl|rfl|rfl
'''
    for j in range(6):
        if j in targets:
            text+=f'    · exact ⟨OddEndpointObjective{index:03}Delivery{j}.certificate⟩\n'
        else:
            text+=f'    · exact False.elim ((by decide : ¬targetAllowed residue patchAnchor {j}) allowed)\n'
    text+=f'#print axioms certificates\nend Delivery.{name}\n'
    return name,text


def aggregate_text(patterns):
    name='OddEndpointSavedCertificates'
    text=header('\n'.join(f'import OddEndpointCertificate{p["index"]:03}' for p in patterns),name)
    text+='''noncomputable def certificates (r : OddEndpointGraph.Case) (a : Option Int)
    (allowed : Catalogued r a) : Certificates r a := by
  apply Classical.choice
  have cases : r=0 ∨ r=1 ∨ r=2 ∨ r=3 ∨ r=4 ∨ r=5 := by
    have finite : ∀ r : Fin 6, r=0 ∨ r=1 ∨ r=2 ∨ r=3 ∨ r=4 ∨ r=5 := by decide +kernel
    exact finite r
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl
'''
    for r in range(6):
        selected=[p for p in patterns if p['residue']==r]
        none=next(p for p in selected if p['anchor'] is None)
        anchors=[p for p in selected if p['anchor'] is not None]
        alternatives=' ∨ '.join(f'h=({p["anchor"]})' for p in anchors)
        text+=f'''  · cases a with
    | none => exact ⟨OddEndpointCertificate{none['index']:03}.certificates⟩
    | some h =>
      have cases : {alternatives} := by
        change -{6 if r==0 else 10}≤h ∧ h≤{6 if r==0 else 10} at allowed
        omega
      rcases cases with {'|'.join('rfl' for _ in anchors)}
'''
        for p in anchors:text+=f'      · exact ⟨OddEndpointCertificate{p["index"]:03}.certificates⟩\n'
    text+=f'#print axioms certificates\nend Delivery.{name}\n'
    return name,text


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=ROOT/'tmp/lean-odd-endpoint-groups')
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    records={};rawpins={}
    for path,expected in SOURCES.items():
        raw=(ROOT/path).read_bytes();assert digest(raw)==expected
        data=json.loads(gzip.decompress(raw))
        for rowindex,row in enumerate(data['certificates']):
            residue=row.get('removed_count',0)
            anchor=row.get('defect_column',row.get('patch_shift'))
            key=(residue,anchor,row['target_type']);assert key not in records
            records[key]=row
            rawpins[key]=dict(archive=path,record_index=rowindex,
                record_sha256=digest(json.dumps(row,sort_keys=True,separators=(',',':')).encode()))
    assert len(records)==847
    files={};patterns=[];objectives=[]
    def save(name,text):
        (args.out/f'{name}.lean').write_text(text)
        files[name+'.lean']=digest(text.encode())
    index=0
    for residue in range(6):
        limit=6 if residue==0 else 10
        for anchor in [None,*range(-limit,limit+1)]:
            name,text,model=pattern_text(index,residue,anchor);save(name,text)
            patch=model[0]
            targets=[None,*[j for j in range(6) if (0,j) not in patch.removed and (0,j)!=patch.target]]
            expected={(residue,anchor,t) for t in targets}
            actual={key for key in records if key[:2]==(residue,anchor)}
            assert expected==actual
            patterns.append(dict(index=index,residue=residue,anchor=anchor,targets=targets,module=name,
                messenger_radius=SPECS[residue]['M'],cop_radius=SPECS[residue]['R'],jump=SPECS[residue]['J']))
            for target in targets:
                key=residue,anchor,target
                name,text,stats=objective_text(index,residue,records[key],model);save(name,text)
                objectives.append(dict(module=name,pattern=index,residue=residue,anchor=anchor,target=target,
                    **rawpins[key],**stats))
            name,text=bundle_text(index,targets);save(name,text)
            index+=1
    assert len(patterns)==124 and len(objectives)==847
    name,text=aggregate_text(patterns);save(name,text)
    dependencies=['lean/OddEndpointLocal.lean','lean/OddEndpointCertificatesSpec.lean','lean/GroupedArena.lean','lean/GroupedInitialMasks.lean',
        'src/odd_projection_threshold_check.py','src/export_low_band_lean.py']
    manifest=dict(archive_pins=SOURCES,exporter_sha256=digest(Path(__file__).read_bytes()),
        dependency_pins={p:digest((ROOT/p).read_bytes()) for p in dependencies},
        proof_boundary='Generated finite obligations only; no Lean replay or global odd theorem claimed.',
        patterns=patterns,objectives=objectives,files=files)
    (args.out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(dict(patterns=len(patterns),objectives=len(objectives),
        states=sum(x['states'] for x in objectives),groups=sum(x['groups'] for x in objectives))))


if __name__=='__main__':
    main()

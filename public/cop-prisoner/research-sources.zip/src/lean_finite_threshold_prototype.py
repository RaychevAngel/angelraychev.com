#!/usr/bin/env python3
"""Untrusted bounded prototype for union-counted sharp finite upper leaves.

This does not enumerate or certify the full threshold-30 family. It constructs
one closed-region upper certificate for the frozen regular score-30 witness.
"""
from __future__ import annotations
import json, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
N=9
ALL=(1<<N)-1

def function(name, vals):
    return f'def {name} (x : Fin 9) : Fin 9 :=\n  match x.val with\n'+''.join(f'  | {i} => {v}\n' for i,v in enumerate(vals))+'  | _ => 0\n\n'
def literal(p): return '['+','.join(map(str,p))+']'

def eligible(a,p):
    out=[1<<a[s] | ((1<<p[s]) if s<len(p) else 0) for s in range(N)]
    legal=[out[c]|(1<<c) for c in range(N)]
    pred=[sum(1<<s for s in range(N) if a[s]==t) for t in range(N)]
    for u,t in enumerate(p): pred[t]|=1<<u
    bad=[0]*N
    for s in range(len(p)):
        if any(c!=s and not(out[s]&~legal[c]) for c in range(N)): bad[s]=ALL
    for t in p:
        for c in range(N):
            if not(pred[t]&~legal[c]):
                for s in range(N):
                    if s!=c: bad[s]|=1<<t
    return [(ALL&~(bad[s]|out[s]|(1<<s))) for s in range(N)]

def regions(a,b):
    out=[{r,a[r],b[r]} for r in range(N)]
    result=[]
    for t in range(N):
        win=[[r==t for c in range(N)] for r in range(N)]
        while True:
            nxt=[[r==t or (r!=c and any(z==t or (z!=c and all(z!=d and win[z][d] for d in out[c])) for z in out[r])) for c in range(N)] for r in range(N)]
            if nxt==win:break
            win=nxt
        mask=sum(1<<(r*N+c) for r in range(N) for c in range(N) if not win[r][c])
        lost=sum(1<<s for s in range(N) if any(c!=s and not win[s][c] for c in range(N)))
        for r in range(N):
            for c in range(N):
                if win[r][c]:continue
                assert r!=t
                if r==c:continue
                for z in out[r]:
                    assert z!=t and (z==c or any(z==d or not win[z][d] for d in out[c]))
        result.append((t,mask,lost))
    return result

def main():
    start=time.monotonic()
    frozen=json.loads((ROOT/'research/small-sparse-regular-9-threshold30.json').read_text())
    a=[frozen['arcs'][2*s][1] for s in range(N)]
    b=[frozen['arcs'][2*s+1][1] for s in range(N)]
    remain=eligible(a,b); before=sum(v.bit_count() for v in remain)
    candidates=regions(a,b);selected=[]
    while sum(v.bit_count() for v in remain)>30:
        best=max(candidates,key=lambda v:sum(bool(remain[s]>>v[0]&1) and bool(v[2]>>s&1) for s in range(N)))
        candidates.remove(best);t,mask,lost=best;selected.append((t,mask))
        for s in range(N):
            if lost>>s&1:remain[s]&=~(1<<t)
    masks='['+','.join(f'({t},{mask})' for t,mask in selected)+']'
    content='import FiniteExclusionBounds\n\nset_option maxRecDepth 4096\nset_option maxHeartbeats 20000000\n\nnamespace Delivery.FiniteExclusion.ThresholdPrototype\nopen Bounds Extremal FiniteGame\n\n'
    content+=function('a',a)+function('b',b)
    content+=f'def masks : List (Fin 9 × Nat) := {masks}\n\n'
    content+=f'theorem masks_closed : ∀ tm, tm ∈ masks → RegionOK a b tm.1 tm.2 := by decide +kernel\n\n'
    content+=f'theorem refined_count : refinedCount a {literal(b)} masks ≤ 30 := by decide +kernel\n\n'
    content+=f'theorem prefix_upper : UpperPrefix a {literal(b)} 30 :=\n  full_upper a {literal(b)} 30 (by decide) b (by decide +kernel) masks masks_closed refined_count\n\n'
    content+=f'theorem graph_upper : score (edgeOf a b) ≤ 30 :=\n  prefix_upper b (by unfold Valid; decide +kernel) (by unfold Agrees; decide +kernel)\n\n'
    content+='#print axioms graph_upper\nend Delivery.FiniteExclusion.ThresholdPrototype\n'
    out=ROOT/'tmp/lean-oct23/finite/threshold-prototype.lean';out.write_text(content)
    print(json.dumps({'file':str(out),'initial_eligible':before,'selected_targets':[x[0] for x in selected],'final_eligible':sum(v.bit_count() for v in remain),'seconds':time.monotonic()-start}))
if __name__=='__main__':main()

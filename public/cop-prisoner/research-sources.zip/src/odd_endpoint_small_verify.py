#!/usr/bin/env python3
"""Full two-solver proof of finite odd endpoint witnesses at n=13..18."""
from __future__ import annotations
import gzip,hashlib,json
from pathlib import Path
from game_solver import solve_graph,neighborhoods,verify_certificate
ROOT=Path(__file__).resolve().parents[1]

def main():
 records=[]
 for n in range(13,19):
  g=json.loads((ROOT/f'research/odd-endpoint-small-n{n}.json').read_text());assert g['found']
  arcs=g['arcs'];u,v=g['low_source'],g['low_recipient'];out,clean=neighborhoods(n,arcs)
  assert len(arcs)==len(clean)==2*n-1 and u!=v and(u,v)not in clean
  assert all(out[x].bit_count()==(2 if x==u else 3)for x in range(n))
  assert all(sum(b==x for a,b in arcs)==(1 if x==v else 2)for x in range(n))
  result=solve_graph(n,arcs,certificates=True,crosscheck=True)
  assert result['I']==(n-2)*(n-3)
  assert all(result['W'][s][t]for s in range(n)if s!=u for t in range(n)if t!=v)
  for cert in result['certificates']:assert verify_certificate(n,out,cert)
  records.append(dict(n=n,low_source=u,low_recipient=v,result=result))
 path=ROOT/'research/odd-endpoint-small-certificates.json.gz'
 with gzip.open(path,'wt')as f:json.dump(records,f,separators=(',',':'))
 receipt={'status':'all six graphs passed both game solvers and every direct transition check','orders':list(range(13,19)),'minimum_odd_m':25,'objective_count':sum(r['n']for r in records),'states_checked':sum(2*r['n']**3 for r in records),'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()for p in['src/odd_endpoint_small_verify.py','src/game_solver.py']},'graphs':[{'n':r['n'],'I':r['result']['I'],'arcs':r['result']['arcs']}for r in records]}
 (ROOT/'research/odd-endpoint-small-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items()if k not in('graphs','source_sha256')}))

if __name__=='__main__':main()

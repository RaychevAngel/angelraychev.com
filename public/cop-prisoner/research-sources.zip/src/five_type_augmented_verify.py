#!/usr/bin/env python3
"""Independent explicit alternating-state audit with an augmented pursuer.

Only the pursuer gains the arc (i,0)->(i-1,4), in every column. The
messenger remains on the original two outgoing arcs.

Messenger is confined to columns -3..3. Pursuer has columns -4..4 plus
OMEGA, which can wait or enter ANY vertex in either boundary column ±4.
This is a more powerful pursuer than on every cyclic five-type graph k>=10.

Transfer is safe only at the next MESSENGER turn after the pursuer has acted:
only messenger-turn, noncollision states in column zero are seeded. Delivery
at a designated recipient instead has priority over collision as required.
"""
from __future__ import annotations
from collections import deque
from pathlib import Path
import json
import hashlib

SIGMA=(0,2,4,3,1)
VOLTAGE=(1,-1,-1,-1,-1)

def outgoing(vertex):
    x,j=vertex
    return [vertex,(x,j+1) if j<4 else (x+1,0),(x+VOLTAGE[j],SIGMA[j])]

def solve(goal_type=None):
    messenger=[(x,j) for x in range(-3,4) for j in range(5)]
    pursuer=[(x,j) for x in range(-4,5) for j in range(5)]+[None]
    mi={v:i for i,v in enumerate(messenger)};ci={v:i for i,v in enumerate(pursuer)}
    nr,nc=len(messenger),len(pursuer);count=2*nr*nc
    mout=[[mi[v]for v in outgoing(r)if v in mi]for r in messenger]
    cout=[[ci.get(v,ci[None])for v in outgoing(c)+([(c[0]-1,4)] if c[1]==0 else [])]if c is not None
          else [ci[None]]+[ci[(x,j)]for x in (-4,4)for j in range(5)]for c in pursuer]
    rank=[-1]*count;remaining=[0]*count;best=[-1]*count;mx=[0]*count
    reverse=[[]for _ in range(count)];successors=[[]for _ in range(count)];queue=deque()
    def state(r,c,turn):return 2*(r*nc+c)+turn
    for r,rpos in enumerate(messenger):
        for c,cpos in enumerate(pursuer):
            for turn in (0,1):
                s=state(r,c,turn)
                terminal_delivery=goal_type is not None and rpos==(0,goal_type)
                if terminal_delivery:
                    rank[s]=0;queue.append(s);continue
                if rpos==cpos:continue
                terminal_transfer=goal_type is None and rpos[0]==0 and turn==0
                if terminal_transfer:
                    rank[s]=0;queue.append(s);continue
                succ=([state(v,c,1)for v in mout[r]]if turn==0
                      else [state(r,v,0)for v in cout[c]])
                successors[s]=succ;remaining[s]=len(succ)
                for z in succ:reverse[z].append(s)
    while queue:
        z=queue.popleft()
        for s in reverse[z]:
            if rank[s]>=0:continue
            if s%2==0:rank[s]=rank[z]+1;best[s]=z;queue.append(s)
            else:
                remaining[s]-=1;mx[s]=max(mx[s],rank[z])
                if remaining[s]==0:rank[s]=mx[s]+1;queue.append(s)
    # Independent local certificate conditions, including losing region.
    for r,rpos in enumerate(messenger):
        for c,cpos in enumerate(pursuer):
            for turn in (0,1):
                s=state(r,c,turn)
                if goal_type is not None and rpos==(0,goal_type):assert rank[s]==0;continue
                if rpos==cpos:assert rank[s]==-1;continue
                if goal_type is None and rpos[0]==0 and turn==0:assert rank[s]==0;continue
                succ=successors[s]
                if rank[s]>=0:
                    if turn==0:assert best[s] in succ and 0<=rank[best[s]]<rank[s]
                    else:assert all(0<=rank[z]<rank[s]for z in succ)
                elif turn==0:assert all(rank[z]<0 for z in succ)
                else:assert any(rank[z]<0 for z in succ)
    initial_column=1 if goal_type is None else 2
    initial=[state(r,c,0)for r,rpos in enumerate(messenger)if rpos[0]==initial_column
             for c,cpos in enumerate(pursuer)if cpos!=rpos]
    assert len(initial)==225
    winning=sum(rank[s]>=0 for s in initial);maximum=max(rank[s]for s in initial)
    return {'goal':'safe_column_transfer'if goal_type is None else 'terminal_delivery',
            'target_type':goal_type,'initial_column':initial_column,'initial_states':len(initial),
            'winning_initial_states':winning,'maximum_half_turn_rank':maximum,
            'maximum_messenger_moves':(maximum+1)//2,
            'messenger_vertices':messenger,'pursuer_vertices':pursuer,
            'state_index':'2*(messenger_index*46+pursuer_index)+turn, turn0=messenger',
            'ranks':rank,'winning_messenger_successor_state':best}

def main():
    records=[solve()]+[solve(t)for t in range(5)]
    for r in records:
        assert r['winning_initial_states']==r['initial_states']
        print(r['goal'],r['target_type'],r['winning_initial_states'],r['maximum_messenger_moves'])
    root=Path(__file__).resolve().parents[1]
    result={'method':'independent explicit alternating graph, with verified winning and losing rank conditions',
            'augmentation':'Pursuer only: (i,0)->(i-1,4) for every integer column i',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'records':records}
    (root/'research/five-type-augmented-independent-certificates.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()

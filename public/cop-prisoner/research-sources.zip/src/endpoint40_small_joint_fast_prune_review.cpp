// Independent fixed-point and BFS-prefix tests of actual positive-degree joint capacities/camping/guarded prunes.
// Imports the producer only to call its pruning functions, not its game solver.
#define main joint_producer_main
#include "endpoint40_small_joint_fast.cpp"
#undef main
#include <array>
#include <cassert>
#include <cstdint>
#include <random>
bool original_camping(int row){
 int bad[20]={};
 for(int source=0;source<=row;source++)if(D[source]>=2)
  for(int cop=0;cop<=row;cop++)if(cop!=source&&!(O[source]&~(O[cop]|1<<cop)))bad[source]=all;
 for(int target=0;target<n;target++)if(E[target]>=2&&used[target]==E[target])
  for(int cop=0;cop<=row;cop++)if(!(P[target]&~(O[cop]|1<<cop)))
   for(int source=0;source<n;source++)if(source!=cop)bad[source]|=1<<target;
 int losses=0;
 for(int source=0;source<n;source++)if(Amask>>source&1)
  losses+=__builtin_popcount(unsigned(bad[source]&Bmask&~(O[source]|1<<source)));
 return eligible_upper()-losses>threshold;
}

uint64_t comparisons=0;
uint64_t graphs_checked=0,prefixes_checked=0,positive_graphs=0,cop_witnesses=0;

void check_graph(int order,const vector<int>& actual){
 n=order;all=(1<<n)-1;
 vector<vector<int>> wins_by_target(n,vector<int>(n));vector<int> score_by_source(n);
 int actual_score=0;
 for(int t=0;t<n;++t){
  vector<int> wins(n);wins[t]=all;
  for(;;){
   vector<int> safe(n),next(n);safe[t]=all;
   for(int s=0;s<n;++s)if(s!=t)for(int c=0;c<n;++c)
    if(!((actual[c]|(1<<c))&~wins[s]))safe[s]|=1<<c;
   for(int s=0;s<n;++s){
    if(s==t){next[s]=all;continue;}
    for(int bits=actual[s]|(1<<s);bits;bits&=bits-1)next[s]|=safe[__builtin_ctz((unsigned)bits)];
    next[s]&=all^(1<<s);
   }
   if(next==wins)break;wins=next;
  }
  wins_by_target[t]=wins;
  for(int s=0;s<n;++s)if(s!=t&&!(actual[s]>>t&1)&&wins[s]==(all^(1<<s))){++actual_score;++score_by_source[s];}
 }
 ++graphs_checked;positive_graphs+=actual_score>0;
 for(int u=0;u<n;++u){D[u]=__builtin_popcount((unsigned)actual[u]);E[u]=0;}
 for(int u=0;u<n;++u)for(int v=0;v<n;++v)if(actual[u]>>v&1)++E[v];
 for(int u=0;u<n;++u)assert(D[u]>=1&&E[u]>=1);
 budget=0;Amask=Bmask=0;int lowout=0,lowin=0;
 for(int u=0;u<n;++u){budget+=D[u];if(D[u]>=2)Amask|=1<<u;else lowout+=D[u];if(E[u]>=2)Bmask|=1<<u;else lowin+=E[u];}
 baseeligible=__builtin_popcount((unsigned)Amask)*__builtin_popcount((unsigned)Bmask)-__builtin_popcount((unsigned)(Amask&Bmask))-budget+lowout+lowin;mode=0;threshold=actual_score-1;
 for(int row=0;row<=n;++row){
  for(int u=0;u<n;++u){O[u]=u<row?actual[u]:0;P[u]=used[u]=0;}
  for(int u=0;u<row;++u)for(int v=0;v<n;++v)if(actual[u]>>v&1){P[v]|=1<<u;++used[v];}
  int old_threshold=threshold;
  for(threshold=-1;threshold<=n*(n-1);++threshold){assert(camping(row-1)==original_camping(row-1));++comparisons;}
  threshold=old_threshold;
  if(!capacities(row)||!camping(row-1)||!guarded(row)){
   cerr<<"false joint prune n="<<n<<" prefix="<<row<<" actual_I="<<actual_score<<endl;abort();
  }
  vector<int> optimistic(n);
  for(int u=0;u<n;++u){
   optimistic[u]=O[u];
   if(u>=row)for(int v=0;v<n;++v)if(u!=v&&used[v]<E[v])optimistic[u]|=1<<v;
  }
  for(int c=0;c<n;++c){
   int allowed=all&~(O[c]|(1<<c));
   for(int s=0;s<n;++s)if(s!=c){
    int reached=optimistic[s]&allowed,front=reached;
    while(front){
     int u=__builtin_ctz((unsigned)front);front&=front-1;
     int fresh=optimistic[u]&allowed&~reached;reached|=fresh;front|=fresh;
    }
    int recipients=optimistic[s];
    for(int u=0;u<n;++u)if(reached>>u&1)recipients|=optimistic[u];
    for(int t=0;t<n;++t)if(t!=s&&!(recipients>>t&1)){
     assert(!(actual[s]>>t&1));
     if(wins_by_target[t][s]>>c&1){cerr<<"false guarded pair n="<<n<<" prefix="<<row<<" s,t,c="<<s<<","<<t<<","<<c<<endl;abort();}
     ++cop_witnesses;
    }
   }
  }
  ++prefixes_checked;
 }
}
int main(){
 auto start=chrono::steady_clock::now();
 for(int order=1;order<=4;++order){
  vector<pair<int,int>> arcs;for(int s=0;s<order;++s)for(int t=0;t<order;++t)if(s!=t)arcs.push_back({s,t});
  for(uint64_t bits=0;bits<(1ULL<<arcs.size());++bits){
   vector<int> actual(order);for(size_t j=0;j<arcs.size();++j)if(bits>>j&1)actual[arcs[j].first]|=1<<arcs[j].second;
   bool admissible=true;
   for(int u=0;u<order;++u){int incoming=0;for(int v=0;v<order;++v)incoming+=actual[v]>>u&1;
    if(__builtin_popcount((unsigned)actual[u])<1||incoming<1)admissible=false;}
   if(admissible)check_graph(order,actual);
  }
 }
 mt19937 rng(13092026);
 for(int order=5;order<=10;++order)for(int trial=0;trial<100;++trial){
  vector<int> actual(order);int numerator=1+trial%9;
  for(int s=0;s<order;++s)for(int t=0;t<order;++t)if(s!=t&&(int)(rng()%10)<numerator)actual[s]|=1<<t;
  for(int u=0;u<order;++u)actual[u]|=(1<<((u+1)%order));
  check_graph(order,actual);
 }
 // Literal high-score graphs are appended by the review preparation step.
 vector<vector<int>> literals={{0,4,3,20,40,80,35},{64,40,80,3,7,16,44},{42,36,48,65,5,12,18},{24,68,11,96,33,12,50},{14,68,33,50,14,72,17},{50,5,98,65,12,25,26},{72,81,33,38,13,26,52},{72,81,97,38,13,26,52},{106,81,97,38,13,26,52},{14,37,81,50,70,75,57},{24,44,82,99,101,23,15},{26,41,73,86,99,85,54},{14,21,105,101,106,27,39},{86,85,35,54,106,89,45},{116,89,43,54,106,85,23},{124,124,120,118,11,7,51},{124,124,122,118,11,7,51},{124,124,122,118,11,71,51},{124,124,122,118,75,71,51},{224,192,34,20,9,16,2,0},{144,96,160,18,12,3,132,72},{144,96,160,18,13,3,132,72},{136,96,160,18,13,3,148,72},{48,192,160,98,12,11,5,25},{48,88,224,97,12,6,5,25},{148,28,80,192,138,70,11,33},{44,84,145,194,65,3,164,50},{88,69,130,164,11,82,176,41},{182,205,248,86,109,211,174,59},{182,205,248,87,109,211,174,59},{252,252,250,246,139,23,43,103},{252,252,250,246,139,23,59,103},{252,252,250,246,139,151,59,103},{252,252,250,246,203,151,59,103},{6,65,264,20,160,18,136,257,96},{500,365,395,498,175,219,430,349,119},{496,457,442,437,462,399,319,127,127},{508,508,506,502,139,407,315,359,243},{508,508,506,502,395,407,315,359,243},{508,508,506,502,459,407,315,359,243},{10,132,33,80,34,320,640,257,528,12},{476,925,827,631,239,973,954,885,747,502},{890,965,1000,935,998,799,923,639,255,255},{890,965,1016,935,998,799,923,639,255,255},{890,973,1016,935,998,799,923,639,255,255},{1020,1020,1018,1014,971,919,827,631,251,487},{6,65,264,20,160,18,136,257,96,1024,0},{10,132,33,80,34,320,640,257,528,13,0},{258,36,1025,49,160,65,640,260,528,1026,72},{642,20,264,80,33,66,1152,258,672,1032,5},{642,36,264,1056,65,82,1280,258,704,24,5},{2036,1901,1931,2034,1711,1755,1966,1885,1655,511,511},{2036,1901,1947,2034,1711,1755,1966,1885,1279,511,511},{1914,1997,2040,1959,2022,1823,1947,1663,1279,511,511},{3548,3997,3899,3703,3311,4045,4026,3957,3819,3574,1023,1023},{4084,3949,3995,4082,3759,3803,4014,3933,3327,2559,1023,1023},{130,96,160,18,5,67,148,72},{48,192,162,98,140,11,5,25},{148,28,81,192,130,70,11,41},{88,69,130,164,13,82,176,41},{44,84,152,194,105,11,165,51},{44,84,153,194,105,11,165,51},{176,212,153,195,105,14,165,35},{60,116,208,195,104,15,166,27},{92,116,154,194,105,139,165,51},{240,116,153,195,106,15,165,30},{60,101,216,195,43,214,170,23},{60,244,217,195,106,15,165,27},{60,244,217,195,106,15,181,27},{60,213,240,211,106,15,173,55},{108,181,242,211,106,15,173,59},{60,244,217,211,107,15,173,55},{186,205,248,86,109,211,174,55},{6,65,264,20,160,26,136,257,96},{6,65,264,52,129,26,136,257,96},{12,33,385,194,68,18,152,36,96},{12,33,385,194,68,274,152,36,96},{12,49,385,194,68,274,152,36,96},{6,65,264,20,160,26,136,257,96,0},{10,132,33,80,34,320,640,257,528,13},{10,132,33,80,34,320,640,259,528,13},{10,133,544,80,34,320,648,257,528,13},{26,132,33,80,34,320,648,258,529,13},{26,132,608,80,34,769,136,259,536,5},{88,272,10,577,100,192,264,549,130,38},{88,276,130,528,352,192,269,513,161,42}};
 int literal_tested=0;
 for(auto& graph:literals){
  int k=graph.size();bool admissible=true;
  for(int u=0;u<k;++u){int incoming=0;for(int v=0;v<k;++v)incoming+=graph[v]>>u&1;
   if(__builtin_popcount((unsigned)graph[u])<1||incoming<1)admissible=false;}
  if(admissible){check_graph(k,graph);++literal_tested;}
 }
 cout<<"{\"status\":\"passed\",\"all_positive_degree_graphs_through_n\":4,\"random_graphs_n5_through10\":600,\"literal_graphs_available\":"<<literals.size()<<",\"literal_graphs_tested\":"<<literal_tested
 <<",\"all_cutoff_equivalence_checks\":"<<comparisons<<",\"graphs_checked\":"<<graphs_checked<<",\"positive_score_graphs\":"<<positive_graphs<<",\"prefixes_checked\":"<<prefixes_checked
 <<",\"specific_camping_states_checked\":"<<cop_witnesses<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}"<<endl;
}

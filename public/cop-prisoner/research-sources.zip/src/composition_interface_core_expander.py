#!/usr/bin/env python3
"""Bounded matching-core tests for arbitrary undirected quotient networks.
Each cell is the directed A4 core. Across an undirected quotient edge every
core type i crosses to p(i), for an involution p. Cop's exterior keeps its type.
Successful local modules still require an ordinary simulation proof.
"""
from pathlib import Path
import json,hashlib,random,time
from composition_interface_core_ports import core
from composition_interface_invariant import attract
ROOT=Path(__file__).resolve().parents[1]

def arena(p):
 G,out=core();M=[(cell,i) for cell in (0,1) for i in range(12)];C=M+[(None,i) for i in range(12)];mi={v:i for i,v in enumerate(M)};ci={v:i for i,v in enumerate(C)}
 mo=[];co=[]
 for cell,i in M:mo.append([mi[cell,i]]+[mi[cell,j] for j in out[i]]+[mi[1-cell,p[i]]])
 for cell,i in C:
  suc={ci[cell,i]}|{ci[cell,j] for j in out[i]}|{ci[c,p[i]] for c in (0,1,None) if c!=cell}
  # An exterior edge may have both endpoints outside the window.
  if cell is None:suc.add(ci[None,p[i]])
  co.append(sum(1<<c for c in suc))
 return M,C,mi,ci,mo,co

def test(p):
 ar=arena(p);M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1;records=[]
 for target in (None,)+tuple(range(12)):
  rec={mi[0,target]} if target is not None else set()
  seeds=[allc if r in rec else (allc^(1<<ci[M[r]]) if target is None and M[r][0]==1 else 0) for r in range(len(M))]
  W,rounds=attract(ar,seeds,rec)
  bad=[(M[r],C[c]) for r in range(12) for c in range(len(C)) if c!=r and not(W[r]>>c&1)]
  records.append({'target':target,'rounds':rounds,'failed':len(bad),'first_failure':bad[0] if bad else None})
  if bad:break
 return {'p':p,'pass':len(records)==13 and not records[-1]['failed'],'records':records}

if __name__=='__main__':
 rng=random.Random(13092026);start=time.monotonic();records=[]
 for attempt in range(80):
  order=list(range(12));rng.shuffle(order);p=list(range(12))
  for x,y in zip(order[::2],order[1::2]):p[x]=y;p[y]=x
  d=test(p);records.append(d)
  if d['pass'] or len(d['records'])>1:print(d,flush=True)
  if d['pass'] or time.monotonic()-start>20:break
 out={'scope':'finite local matching-cell modules, not yet a composition theorem','seconds':time.monotonic()-start,'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'research/composition-interface-core-expander.json').write_text(json.dumps(out,indent=2)+'\n')
 print('finished',len(records),'best checks',max(len(d['records']) for d in records),time.monotonic()-start)

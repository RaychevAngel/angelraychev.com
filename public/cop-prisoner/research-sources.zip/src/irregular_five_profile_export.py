#!/usr/bin/env python3
"""Export complete positive-degree order-five certificates as Lean source.

The input remains untrusted. Kernel-checked catalogues cover all profiles;
each tree checks all row choices, maps, and optimistic losing regions.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
from irregular_ten_export import certificate, route, natlist

ROOT = Path(__file__).resolve().parents[1]


def profile_source(case, index, bound):
    labels = natlist(list(reversed(case["labels"])))
    ds, rs = f"(D (n:=5) {labels})", f"(R (n:=5) {labels})"
    declarations = []
    next_index = 0

    def proof(prefix):
        nonlocal next_index
        node = case["nodes"][",".join(map(str, prefix))]
        ni = next_index
        next_index += 1
        name, pl = f"profile{index}_node{ni}", natlist(prefix)
        if node["kind"] == "bound":
            cert = node["certificate"]
            if cert["mode"] == "plain":
                typ, sound, check, body = "Bound", "bound_sound", "SmallBoolean.boundCheck_true", certificate(cert)
            elif cert["mode"] == "cut":
                typ, sound, check = "CutBound", "cut_bound_sound", "SmallCut.boundCheck_true"
                body = certificate(dict(cert, allowed=cert["lost"])).replace("allowed :=", "lost :=")
            else:
                raise ValueError("unknown certificate kind")
            declarations.append(f"def {name}_cert : {typ} 5 := {body}\n")
            declarations.append(f"theorem {name} : Upper {ds} {rs} {pl} {bound} :=\n"
                f"  {sound} {ds} {rs} {pl} {bound} {name}_cert\n"
                f"    (({check} {ds} {rs} {pl} {bound} {name}_cert).mp (by decide +kernel))\n")
        elif node["kind"] == "branch":
            reps = node["representatives"]
            children = {v: proof(prefix + [v]) for v in reps}
            d = case["outdegrees"][len(prefix)]
            declarations.append(f"def {name}_route : Route 5 := {route(node)}\n")
            source = (f"theorem {name} : Upper {ds} {rs} {pl} {bound} := by\n"
                f"  apply routed_branch {ds} {rs} {pl} {bound} (by decide) (choices {d}) {natlist(reps)} {name}_route\n"
                f"    (by change RowCover 5 {d} (choices {d}); exact cover ⟨{d},by decide⟩)\n"
                f"    ((SmallBoolean.routesCheck_true {ds} {rs} {pl} (choices {d}) {natlist(reps)} {name}_route).mp (by decide +kernel))\n"
                "  intro mask member\n")
            if reps:
                source += "  simp only [List.mem_cons,List.not_mem_nil,or_false] at member\n"
                source += "  rcases member with " + " | ".join("rfl" for _ in reps) + "\n"
                source += "".join(f"  · exact {children[v]}\n" for v in reps)
            else:
                source += "  simp at member\n"
            declarations.append(source)
        else:
            raise ValueError("unknown tree node")
        return name

    root = proof([])
    if next_index != len(case["nodes"]):
        raise ValueError("tree contains omitted or duplicate nodes")
    return "\n".join(declarations) + f"\ntheorem profile{index} : Upper {ds} {rs} [] {bound} := {root}\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--chunk-nodes", type=int, default=180)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("preserve existing generated units")
    data = json.loads(args.input.read_text())
    if data["n"] != 5 or [b["arrows"] for b in data["budgets"]] != list(range(9, 15)):
        raise ValueError("incorrect complete input family")
    for path, expected in data["source_sha256"].items():
        if hashlib.sha256((ROOT / path).read_bytes()).hexdigest() != expected:
            raise ValueError(f"producer provenance mismatch: {path}")
    args.out.mkdir(parents=True)
    generated = []

    def save(name, source):
        path = args.out / f"{name}.lean"
        path.write_text(source)
        generated.append(dict(module=name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))

    base = """import SmallRowPrefixCut
import SmallBudgetProfiles

namespace Delivery.FiveVertexPositiveBase
open FiniteGame Extremal RowPrefix SmallBudgetProfiles
def rows (a b c d e : Nat) : Rows 5 := fun v =>
  match v.val with | 0 => a | 1 => b | 2 => c | 3 => d | _ => e
def choices (d : Nat) : List Nat :=
  match d with
"""
    for degree in range(6):
        masks = [sum(1 << t for t in ts) for ts in itertools.combinations(range(5), degree)]
        base += f"  | {degree} => {natlist(masks)}\n"
    base += """  | _ => []
theorem cover (d : Fin 6) : RowCover 5 d.val (choices d.val) := by
  revert d
  decide +kernel
#print axioms cover
end Delivery.FiveVertexPositiveBase
"""
    save("FiveVertexPositiveBase", base)
    budget_names = []
    for entry in data["budgets"]:
        m, bound, cases = entry["arrows"], entry["bound"], entry["cases"]
        if bound != (3 if m <= 11 else 2) or entry["zero_two"]:
            raise ValueError("incorrect target bound or degree restriction")
        name = f"FiveVertexPositive{m:02}"
        budget_names.append(name)
        header = (f"namespace Delivery.{name}\n"
            "open FiniteGame Extremal RowPrefix SmallBudgetProfiles FiveVertexPositiveBase\n"
            "set_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n")
        chunks, group, size = [], [], 0
        for index, case in enumerate(cases):
            count = len(case["nodes"])
            if group and size + count > args.chunk_nodes:
                chunks.append(group)
                group, size = [], 0
            group.append((index, case))
            size += count
        if group:
            chunks.append(group)
        imports = []
        for ci, group in enumerate(chunks):
            chunk_name = f"{name}C{ci:03}"
            imports.append(chunk_name)
            body = "\n".join(profile_source(c, i, bound) for i, c in group)
            save(chunk_name, "import FiveVertexPositiveBase\n\n" + header + body +
                 f"\n#print axioms profile{group[-1][0]}\nend Delivery.{name}\n")
        source = "\n".join(f"import {n}" for n in imports) + "\n\n" + header
        source += "def catalogue : List (List Nat) := [" + ",".join(natlist(c["labels"]) for c in cases) + "]\n\n"
        source += f"theorem catalogue_eq : hardProfiles 5 {m} {bound} false=catalogue := by decide +kernel\n\n"
        source += f"""theorem hard_upper (xs : List Nat) (member : xs∈hardProfiles 5 {m} {bound} false) :
    Upper (n:=5) (D xs.reverse) (R xs.reverse) [] {bound} := by
  rw [catalogue_eq] at member
  simp only [catalogue,List.mem_cons,List.not_mem_nil,or_false] at member
"""
        if cases:
            source += "  rcases member with " + " | ".join("rfl" for _ in cases) + "\n"
            source += "".join(f"  · exact profile{i}\n" for i in range(len(cases)))
        source += f"""theorem profile_upper (xs : List Nat) (member : xs∈profiles 5 false 5 0 {m} {m}) :
    Upper (n:=5) (D xs.reverse) (R xs.reverse) [] {bound} :=
  upper_of_hard hard_upper xs member

theorem upper (E : Graph (Fin 5)) (loops : Loopless E) (budget : arcCount E={m})
    (positiveOut : ∀x,1≤SparseSupport.outdegree E x)
    (positiveIn : ∀x,1≤SparseSupport.indegree E x) : score E≤{bound} := by
  have od (x) : SparseSupport.outdegree E x<5 := by
    have h := SparseDeletion.row_nonadjacent_bound E loops x
    omega
  have idg (x) : SparseSupport.indegree E x<5 := by
    have h := SparseDeletion.column_nonadjacent_bound E loops x
    omega
  have td : ((List.finRange 5).map (SparseSupport.outdegree E)).sum={m} := by
    exact (SparseSupport.arc_rows E).symm.trans budget
  have te : ((List.finRange 5).map (SparseSupport.indegree E)).sum={m} := by
    exact (SparseSupport.arc_columns E).symm.trans budget
  have member := sorted_member (SparseSupport.outdegree E) (SparseSupport.indegree E)
    false (by decide) od idg (fun x => by have := positiveOut x; have := positiveIn x; omega)
    (fun x => Or.inl ⟨by have := positiveOut x; omega,by have := positiveIn x; omega⟩) td te
  obtain ⟨F,⟨iso⟩,prescribed⟩ := relabel_reversed E loops (fun x => by have := idg x; omega)
  have bound := profile_upper _ member F prescribed (by intro s h; simp at h)
  rw [GraphRelabeling.score_eq iso] at bound
  exact bound

#print axioms upper
end Delivery.{name}
"""
        save(name, source)
    source = "\n".join(f"import {name}" for name in budget_names) + """

namespace Delivery.FiveVertexPositive
open FiniteGame Extremal SparseSupport
theorem upper (E : Graph (Fin 5)) (loopless : Loopless E)
    (budget : 9≤arcCount E ∧ arcCount E≤14)
    (positiveOut : ∀x,1≤outdegree E x) (positiveIn : ∀x,1≤indegree E x) :
    score E≤if arcCount E≤11 then 3 else 2 := by
  have cases : arcCount E=9 ∨ arcCount E=10 ∨ arcCount E=11 ∨
      arcCount E=12 ∨ arcCount E=13 ∨ arcCount E=14 := by omega
  rcases cases with h|h|h|h|h|h
"""
    for m in range(9, 15):
        source += f"  · simpa [h] using FiveVertexPositive{m:02}.upper E loopless h positiveOut positiveIn\n"
    source += "#print axioms upper\nend Delivery.FiveVertexPositive\n"
    save("FiveVertexPositive", source)
    manifest = dict(scope="Untrusted source export; strict Lean replay is still required.",
                    input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                    exporter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    rendering_helper_sha256=hashlib.sha256((ROOT / "src/irregular_ten_export.py").read_bytes()).hexdigest(),
                    chunk_nodes=args.chunk_nodes, modules=generated)
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(dict(modules=len(generated), bytes=sum((args.out / f"{m['module']}.lean").stat().st_size for m in generated))))


if __name__ == "__main__":
    main()

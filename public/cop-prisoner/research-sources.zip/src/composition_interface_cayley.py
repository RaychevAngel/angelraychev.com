#!/usr/bin/env python3
"""Bounded finite Cayley tests for noncommutative fast-routing candidates."""
from pathlib import Path
import json,time,hashlib
from composition_interface_lifts import test
ROOT=Path(__file__).resolve().parents[1]
def cycle(n,seq):
 p=list(range(n))
 for a,b in zip(seq,seq[1:]+seq[:1]):p[a]=b
 return tuple(p)
def cayley(g,h):
 identity=tuple(range(len(g)));G=[identity];idx={identity:0};arcs=[]
 for x in G:
  for a in (g,h):
   y=tuple(x[a[i]] for i in range(len(x)))
   if y not in idx:idx[y]=len(G);G.append(y)
   arcs.append((idx[x],idx[y]))
 return len(G),arcs
start=time.monotonic();rr=[]
for name,g,h in [('a4tri',cycle(4,[0,1,2]),cycle(4,[0,1,3])),('a5long',cycle(5,list(range(5))),cycle(5,[0,1,2])),('a5tri',cycle(5,[0,1,2]),cycle(5,[2,3,4])),('s4',cycle(4,[0,1,2,3]),cycle(4,[0,1])),('a6',cycle(6,[0,1,2,3,4]),cycle(6,[0,1,5]))]:
 n,arcs=cayley(g,h);d=test(n,arcs,targets=[0],dual=n<=100);d.update(name=name,g=g,h=h,target_scope='identity target; left group translations cover all targets');rr.append(d)
 print({k:v for k,v in d.items() if k not in ('arcs','source_camps','checked_targets')},flush=True)
out={'scope':'finite Cayley examples; no infinite-family claim','seconds':time.monotonic()-start,'records':rr,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'research/composition-interface-cayley.json').write_text(json.dumps(out,indent=2)+'\n')

#!/usr/bin/env python3
"""Protected core differences give a quadratic exact-budget interval.

Only the three differences between original outgoing moves must remain
unique. All other repeated differences are permitted.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

from game_solver import neighborhoods, recipient_explicit, recipient_fast, verify_certificate

ROOT = Path(__file__).resolve().parents[1]


def move_envelope(n):
    if n < 25:
        raise ValueError("The ordinary coprime-step lemma requires n>=25")
    h = next(h for h in range(7, (n + 1) // 2, 2) if math.gcd(n, h) == 1)
    a = (h - 1) // 2
    core = (1, a, h)
    values = {0, *core}
    protected = {(u - v) % n for u in core for v in core if u != v}
    assert len(protected) == 6
    def check():
        for delta in protected:
            pairs = [(u, v) for u in values for v in values if (u - v) % n == delta]
            original = [(u, v) for u in core for v in core if (u - v) % n == delta]
            assert pairs == original
    check()
    goal = (n + 6) // 7
    while len(values) < goal:
        forbidden = values | {(v + delta) % n for v in values for delta in protected}
        assert len(forbidden) <= 7 * len(values) < n
        values.add(next(x for x in range(n) if x not in forbidden))
    check()
    return core, tuple(sorted(values)), tuple(sorted(protected))


def construct(n, m):
    core, values, protected = move_envelope(n)
    maximum = n * (len(values) - 1)
    if not 3*n <= m <= maximum:
        raise ValueError(f"Requires {3*n}<=m<={maximum}")
    arcs = {(v, (v + step) % n) for v in range(n) for step in core}
    extras = sorted((v, (v + step) % n) for v in range(n)
                    for step in values if step and step not in core)
    arcs.update(extras[:m - 3*n])
    assert len(arcs) == m
    return sorted(arcs), core, values, protected


def verify_core_protection(n, core, values):
    envelopes = [sum(1 << ((v + step) % n) for step in values) for v in range(n)]
    for source in range(n):
        for left, right in itertools.combinations(core, 2):
            pair = (1 << ((source + left) % n)) | (1 << ((source + right) % n))
            assert all(cop == source or (envelopes[cop] & pair) != pair for cop in range(n))
    return n * (n - 1) * 3


def run_checks():
    structural = []
    for n in (25, 29, 35, 49, 75, 100, 200, 1000):
        core, values, protected = move_envelope(n)
        checked = verify_core_protection(n, core, values) if n <= 200 else None
        structural.append({"n": n, "core": core, "closed_envelope": values,
                           "protected_differences": protected,
                           "minimum_m": 3*n, "maximum_m": n*(len(values)-1),
                           "protected_source_pair_cop_triples_checked": checked})
    games = []
    for n in (29, 35, 49):
        core, values, _ = move_envelope(n)
        top = n * (len(values) - 1)
        for m in sorted({3*n, 3*n+1, (3*n+top)//2, top}):
            arcs, _, _, _ = construct(n, m)
            out, _ = neighborhoods(n, arcs)
            for target in sorted({0, n-1}):
                fast, _ = recipient_fast(n, out, target)
                explicit, certificate = recipient_explicit(n, out, target, certificate=True)
                assert fast == explicit
                verify_certificate(n, out, certificate)
                allv = (1 << n) - 1
                assert all((row | (1 << source)) == allv for source, row in enumerate(fast))
                games.append({"n": n, "m": m, "target": target, "verified": True})
    return structural, games


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "research/main-interval-resume-checks.json")
    args = parser.parse_args()
    structural, games = run_checks()
    example_core, example_values, example_protected = move_envelope(29)
    assert example_values == (0, 1, 3, 7, 8)
    assert (0 - 1) % 29 == (7 - 8) % 29 == 28
    assert 28 not in example_protected
    receipt = {"verified": True,
               "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "proof_boundary": "Uniform ordinary proof; finite game checks cover exactly the listed orders, budgets, and recipients.",
               "structural_checks": structural, "independent_game_checks": games,
               "full_distinct_differences_not_required": {
                   "n": 29, "core": example_core, "closed_envelope": example_values,
                   "repeated_unprotected_difference": 28,
                   "two_ordered_representations": [[0, 1], [7, 8]],
                   "protected_differences": example_protected}}
    args.out.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"verified": True, "structural_orders": len(structural),
                      "independent_game_checks": len(games), "receipt": str(args.out)}))


if __name__ == "__main__":
    main()

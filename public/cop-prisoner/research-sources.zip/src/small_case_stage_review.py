#!/usr/bin/env python3
"""Independent saved-stage replay, using literal sets and decreasing ranks.

No solver, stage producer, or C++ replay library is imported.
"""
import hashlib
import json
import struct
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def check(record,archive):
    n=record['n'];base=list(map(tuple,record['base_arcs']));added=list(map(tuple,record['added']))
    assert len(set(base+added))==len(base)+len(added)
    assert all(0<=s<n and 0<=t<n and s!=t for s,t in base+added)
    intervals=[];states=responses=0
    for stage in record['stages']:
        start,end=stage['prefix_start'],stage['prefix_end']
        assert 0<=start<=end<=len(added)
        B=set(base+added[:start]);E=set(base+added[:end]);size=n**3
        raw=archive.read(stage['member']);assert hashlib.sha256(raw).hexdigest()==stage['sha256']
        assert len(raw)==4*size
        values=struct.unpack('<'+'h'*(2*size),raw);rank=values[:size];action=values[size:]
        rm=[{s}|{t for u,t in B if u==s} for s in range(n)]
        cm=[{c}|{t for u,t in E if u==c} for c in range(n)]
        def index(t,s,c):return (t*n+s)*n+c
        for t in range(n):
            for s in range(n):
                for c in range(n):
                    p=index(t,s,c);states+=1
                    if s==t:assert rank[p]==0;continue
                    if s==c:assert rank[p]<0;continue
                    assert rank[p]>0
                    u=action[p];assert u in rm[s]
                    if u==t:continue
                    assert u!=c
                    for d in cm[c]:
                        responses+=1
                        assert 0<=rank[index(t,u,d)]<rank[p]
        assert (len(B),len(E))==(stage['m_min'],stage['m_max'])
        intervals.append((len(B),len(E)))
    a,b=record['m_min'],record['m_max']
    assert a==len(base) and b==len(base)+len(added)
    covered={m for low,high in intervals for m in range(low,high+1)}
    assert covered==set(range(a,b+1))
    return {'n':n,'m_min':a,'m_max':b,'stages':len(intervals),'states':states,'cop_responses':responses}


def main():
    report={'status':'passed','boundary':'Every graph between each literal base/envelope has finite delivery; no endpoint-only inference or Lean instantiation.',
            'reviewer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sources':{},'records':[]}
    for stem in ('small-plateau-staged','small-plateau-small-stage'):
        path=ROOT/f'research/{stem}-records.json';bundle=ROOT/f'research/{stem}-certificates.zip'
        data=json.loads(path.read_text())
        assert hashlib.sha256(bundle.read_bytes()).hexdigest()==data['bundle_sha256']
        for p in (path,bundle):report['sources'][str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
        records=data.get('records',[data])
        with zipfile.ZipFile(bundle) as z:
            for r in records:report['records'].append(check(r,z))
    (ROOT/'research/small-case-stage-independent-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['records']))


if __name__=='__main__':main()

#!/usr/bin/env python3
"""Structured five-type lane-speed families and single-arc defects.

Finite tests are counterexample screens only. The intended proof goal is a
fixed local defect certificate with all parameter-independent interfaces.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from game_solver import solve_graph


def family(k, positive=1, negative=1):
    sigma = [0, 2, 4, 3, 1]
    shift = [positive, -1, -1, -negative, -1]
    arcs = []
    for i in range(k):
        for j in range(5):
            arcs.extend([(5*i+j, (5*i+j+1) % (5*k)),
                         (5*i+j, 5*((i+shift[j]) % k)+sigma[j])])
    assert len(set(arcs)) == 10*k and all(s != t for s,t in arcs)
    return arcs


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--k',type=int,default=8)
    parser.add_argument('--maximum-speed',type=int,default=3)
    parser.add_argument('--out',type=Path,default=Path('research/odd-endpoint-voltage-screen.json'))
    args=parser.parse_args();n=5*args.k;target=(n-2)*(n-3);rows=[]
    for pos in range(1,args.maximum_speed+1):
        for neg in range(1,args.maximum_speed+1):
            base=family(args.k,pos,neg)
            score=solve_graph(n,base)['I']
            row={'positive':pos,'negative':neg,'n':n,'base_I':score,'base_universal':score==n*(n-3),'deletions':[]}
            if row['base_universal']:
                for edge in base[:10]:
                    a=base.copy();a.remove(edge);result=solve_graph(n,a)
                    row['deletions'].append({'removed':edge,'I':result['I'],'loss':target-result['I']})
            rows.append(row)
            print(json.dumps({k:v for k,v in row.items() if k!='deletions'}|{'best_loss':min((v['loss'] for v in row['deletions']),default=None)}),flush=True)
            args.out.write_text(json.dumps(rows,indent=2)+'\n')


if __name__=='__main__':main()

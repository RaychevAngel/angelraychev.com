#!/usr/bin/env python3
"""Bounded parallel kernel replay with source/dependency-pinned continuation.

The cache is made by this campaign's actual compiler invocations. A record is
reusable only with identical compiler, source, transitive local dependencies,
and compiled object bytes. The public default lean/check.py remains a fresh
sequential replay; this coordinator avoids repeating large unchanged batches
when a final assembly module is added.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT/'lean'
LEAN = ROOT.parent/'polyominoes/.tools/lean-4.33.1-darwin_aarch64/bin/lean'
spec = importlib.util.spec_from_file_location('formal_checker', HERE/'check.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
# Closure discovery, escape checks and dependency fingerprints read identical
# immutable source strings. Reuse only that pure preprocessing result; changed
# source text is a different key, and all file/object pin checks stay unchanged.
checker.without_comments = lru_cache(maxsize=None)(checker.without_comments)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reported_axioms(output):
    axioms = set()
    for block in re.findall(r'depends on axioms:\s*\[([^]]*)\]', output):
        axioms.update(x.strip() for x in block.split(',') if x.strip())
    return axioms


def successful_output(exit_code, output):
    return (type(exit_code) is int and exit_code == 0 and isinstance(output, str)
            and reported_axioms(output) <= checker.ALLOWED_AXIOMS
            and 'sorryAx' not in output and 'declaration uses `sorry`' not in output)


def reusable_record(record, name, fingerprint, source_hash, object_hash, dependency_objects):
    """Reject malformed or unsuccessful records before considering their pins."""
    if not isinstance(record, dict) or not successful_output(
            record.get('exit_code'), record.get('output')):
        return False
    axioms = record.get('axioms')
    if not isinstance(axioms, list) or not all(isinstance(x, str) for x in axioms):
        return False
    return (set(axioms) == reported_axioms(record['output'])
            and record.get('module') == name
            and record.get('fingerprint') == fingerprint
            and record.get('source_sha256') == source_hash
            and record.get('object_sha256') == object_hash
            and record.get('dependency_objects') == dependency_objects)


def dependency_pins(name, dependencies, cache):
    """Read current imports and require the exact objects previously verified."""
    current = {d: sha(HERE/f'{d}.olean') for d in dependencies[name]}
    expected = {d: cache[d]['object_sha256'] for d in dependencies[name]}
    assert current == expected, ('dependency_pin_changed', name)
    return current


def target_sources(inventory, targets):
    """Select import closures from one inventory, ignoring later unrelated files.

    Unknown imports remain visible to build_order's external-import check.
    In particular this does not silently trust an object outside the closure.
    """
    selected = set()

    def visit(name):
        if name in selected:
            return
        if name not in inventory:
            raise ValueError('Unknown target module: '+name)
        selected.add(name)
        code = checker.without_comments(inventory[name].read_text())
        for line in code.splitlines():
            if line.startswith('import '):
                for dep in line[7:].split():
                    if dep in inventory:
                        visit(dep)

    for target in targets:
        visit(target)
    return {name: inventory[name] for name in sorted(selected)}


def available_slots(maximum, control_file, running):
    """Change concurrency only between jobs; never interrupt a proof check."""
    limit = maximum if control_file is None else int(control_file.read_text().strip())
    if not 1 <= limit <= maximum:
        raise ValueError(f'Worker limit must be in 1..{maximum}: {limit}')
    return max(0, limit-running)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--jobs', type=int, default=3)
    p.add_argument('--jobs-file', type=Path,
                   help='Optional live worker limit (1..jobs); running checks always finish.')
    p.add_argument('--exclude', default='')
    p.add_argument('--target', action='append', default=[],
                   help='Replay this module and its complete local import closure; repeatable.')
    p.add_argument('--cache', type=Path, default=ROOT/'tmp/lean-checkpoint/kernel-records.json')
    p.add_argument('--finalize', action='store_true')
    args = p.parse_args()
    available_slots(args.jobs, args.jobs_file, 0)
    compiler = sha(LEAN)
    version = subprocess.check_output([str(LEAN),'--version'],text=True).strip()
    assert 'version 4.33.1' in version
    excluded = set(filter(None,args.exclude.split(',')))
    assert not (args.finalize and (excluded or args.target)), 'Finalization must cover every module.'
    assert not (excluded and args.target), 'Choose targets or exclusions, not both.'
    sources = {f.stem:f for f in HERE.glob('*.lean') if f.stem not in excluded}
    if args.target:
        sources = target_sources(sources, args.target)
    source_hashes = {n:sha(f) for n,f in sources.items()}
    receipt_files = sorted(HERE.glob('*.lean'))+sorted(HERE.glob('*.py'))+[HERE/'lean-toolchain',HERE/'README.md']
    receipt_pins = {f.name:sha(f) for f in receipt_files}
    coordinator_pin = sha(Path(__file__))
    order, external = checker.build_order(list(sources.values()))
    assert all(x=='Std' or x.startswith(('Std.','Init.')) for x in external), external
    assert source_hashes=={n:sha(f) for n,f in sources.items()}, 'Sources changed during dependency analysis.'
    dependencies = {}
    fingerprints = {}
    for name in order:
        code = checker.without_comments(sources[name].read_text())
        imports = [x for line in code.splitlines() if line.startswith('import ') for x in line[7:].split()]
        dependencies[name] = [x for x in imports if x in sources]
        fingerprints[name] = hashlib.sha256(json.dumps([compiler,source_hashes[name],
            [(x,fingerprints[x]) for x in dependencies[name]]],sort_keys=True).encode()).hexdigest()
    cache = json.loads(args.cache.read_text()) if args.cache.exists() else {}
    assert isinstance(cache, dict), 'Cache must be an object keyed by module name.'
    done = set()
    # Require each import to have passed first, including its exact object pin.
    for n in order:
        obj = HERE/f'{n}.olean'
        if any(d not in done for d in dependencies[n]) or not obj.exists():
            continue
        imports = dependency_pins(n, dependencies, cache)
        if reusable_record(cache.get(n), n, fingerprints[n], source_hashes[n], sha(obj), imports):
            done.add(n)
    pending = set(order)-done
    env = dict(os.environ,LEAN_PATH=str(HERE))
    print(json.dumps({'modules':len(order),'reused_this_campaign':len(done),'fresh':len(pending),'jobs':args.jobs}),flush=True)

    def run(name):
        before = dependency_pins(name, dependencies, cache)
        assert sha(sources[name])==source_hashes[name], ('source_changed',name)
        t = time.monotonic()
        r = subprocess.run([str(LEAN),'-j','1','-o',str(HERE/f'{name}.olean'),str(sources[name])],
            cwd=HERE,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=1800)
        axioms = reported_axioms(r.stdout)
        if not successful_output(r.returncode, r.stdout):
            raise RuntimeError(name+'\n'+r.stdout)
        assert sha(sources[name])==source_hashes[name], ('source_changed',name)
        assert before=={d:sha(HERE/f'{d}.olean') for d in dependencies[name]}, ('dependency_changed',name)
        return dict(module=name,seconds=round(time.monotonic()-t,3),exit_code=0,output=r.stdout,
            axioms=sorted(axioms),fingerprint=fingerprints[name],source_sha256=source_hashes[name],
            dependency_objects=before,object_sha256=sha(HERE/f'{name}.olean'),
            verified_at=datetime.now(timezone.utc).isoformat())

    def save():
        args.cache.parent.mkdir(parents=True,exist_ok=True)
        temp=args.cache.with_suffix('.tmp')
        temp.write_text(json.dumps(cache,indent=2)+'\n');temp.replace(args.cache)

    # Prioritize the requested milestones and their prerequisites, not just
    # modules with matching names. This prevents unrelated old finite trees
    # from delaying the whole local-certificate batch behind a shared import.
    ranks = {n:2 for n in order}
    def promote(n, rank):
        if ranks[n] <= rank:
            return
        ranks[n] = rank
        for dep in dependencies[n]:
            promote(dep, rank)
    for name in order:
        if name.startswith('SixType'):
            promote(name, 0)
        elif name.startswith(('RowPrefix', 'Irregular')):
            promote(name, 1)
    def priority(n):
        return (ranks[n], order.index(n))

    running={}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        while pending or running:
            ready=sorted([n for n in pending if all(d in done for d in dependencies[n])],key=priority)
            for n in ready[:available_slots(args.jobs, args.jobs_file, len(running))]:
                pending.remove(n);running[pool.submit(run,n)]=n
            if not running: raise RuntimeError('No dependency-ready module: '+repr(pending))
            finished,_=wait(running,return_when=FIRST_COMPLETED)
            for future in finished:
                name=running.pop(future)
                try: record=future.result()
                except Exception:
                    save()
                    for task in running: task.cancel()
                    raise
                cache[name]=record;done.add(name);save()
                print(f'{len(done)}/{len(order)} {name} {record["seconds"]}s',flush=True)
    # Recheck the entire finished object graph, including reused modules, after
    # all compiler processes have ended and before any successful receipt.
    for n in order:
        imports = dependency_pins(n, dependencies, cache)
        assert reusable_record(cache[n], n, fingerprints[n], source_hashes[n],
                               sha(HERE/f'{n}.olean'), imports), ('final_object_pin_changed', n)
    assert source_hashes=={n:sha(f) for n,f in sources.items()}, 'Source snapshot changed.'
    assert compiler==sha(LEAN), 'Compiler changed.'
    if args.finalize:
        assert set(sources)=={f.stem for f in HERE.glob('*.lean')}, 'Module inventory changed.'
        files=sorted(HERE.glob('*.lean'))+sorted(HERE.glob('*.py'))+[HERE/'lean-toolchain',HERE/'README.md']
        assert receipt_files==files and receipt_pins=={f.name:sha(f) for f in files}, 'Receipt snapshot changed.'
        assert coordinator_pin==sha(Path(__file__)), 'Replay coordinator changed.'
        records=[{k:cache[n][k] for k in ('module','seconds','exit_code','output','axioms')} for n in order]
        receipt=dict(verified_at=datetime.now(timezone.utc).isoformat(),toolchain=version,
            compiler_sha256=compiler,external_imports=external,
            source_sha256=receipt_pins,modules=records,all_passed=True,
            note='Every distributed module rebuilt in this campaign with bounded parallelism. '
                 'Continuation records pin source, transitive dependencies, compiler and object bytes. '
                 'All proofs kernel checked; no full-classification claim follows from module count.',
            replay_coordinator_sha256=coordinator_pin)
        temp=HERE/'verification.json.tmp';temp.write_text(json.dumps(receipt,indent=2)+'\n')
        temp.replace(HERE/'verification.json')
    print('Requested kernel replay completed.',flush=True)


if __name__=='__main__':
    main()

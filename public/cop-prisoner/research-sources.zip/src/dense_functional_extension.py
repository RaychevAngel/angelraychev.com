#!/usr/bin/env python3
"""Explicit sharp final-band complements from distinct pairs of functional roots.

The proof is ordinary; this generator provides reproducible examples and a
direct two-move check. Small examples also run both full game solvers.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path


def construct(r: int, k: int):
    """Return the missing arcs on n=r+k vertices, with h=r+2k."""
    j = (r - 2) // 2
    if r < 2 or k < 1 or k > j * (j - 1) // 2:
        raise ValueError("requires r>=2 and 1<=k<=binomial(floor((r-2)/2),2)")
    roots = [2 + 2 * i for i in range(j)]
    missing = {(0, 1), (1, 0)}
    for s in roots:
        missing.add((s, s + 1))
        missing.add((s + 1, 0))
    if r % 2:
        missing.add((r - 1, 0))
    for v, pair in zip(range(r, r + k), itertools.combinations(roots, 2)):
        for t in pair:
            missing.add((v, t))
    return r + k, sorted(missing), j + 2 * k


def check_two_move(n: int, missing):
    """Check all missing pairs against every initial pursuer, directly."""
    out = [0] * n
    incoming = [0] * n
    for s, t in missing:
        assert 0 <= s < n and 0 <= t < n and s != t
        out[s] |= 1 << t
        incoming[t] |= 1 << s
    assert sum(x.bit_count() for x in out) == len(missing)
    winners = []
    for s, t in missing:
        # The actual G-arcs s->u->t require u outside this union. Since
        # s->t is missing, it already contains both endpoints s and t.
        forbidden = out[s] | incoming[t]
        if all(c == s or out[c] & ~forbidden for c in range(n)):
            winners.append([s, t])
    return winners


def main():
    rows = []
    for k in range(1, 52):
        r = 75 - k
        n, missing, expected = construct(r, k)
        winners = check_two_move(n, missing)
        assert len(winners) == expected
        assert expected == 2 * n - r - (r + 1) // 2 - 1
        rows.append({"n": n, "r": r, "k": k, "h": len(missing),
                     "two_move_pairs": len(winners), "missing_arcs": missing})

    from game_solver import neighborhoods, solve_graph, verify_certificate
    small = []
    for r, k in [(6, 1), (7, 1), (8, 2), (8, 3), (9, 3)]:
        n, missing, expected = construct(r, k)
        missing_set = set(map(tuple, missing))
        arcs = [(s, t) for s in range(n) for t in range(n)
                if s != t and (s, t) not in missing_set]
        result = solve_graph(n, arcs, certificates=True, crosscheck=True)
        out, _ = neighborhoods(n, arcs)
        for certificate in result["certificates"]:
            verify_certificate(n, out, certificate)
        assert result["I"] == expected
        small.append({"n": n, "r": r, "k": k, "I": expected,
                      "two_solvers_and_certificates": True})
    receipt = {"status": "verified", "source_sha256": hashlib.sha256(
        Path(__file__).read_bytes()).hexdigest(), "n75_all_offsets": rows,
        "small_independent_checks": small,
        "proof_boundary": "Ordinary uniform proof; these finite tests are supporting evidence."}
    destination = Path(__file__).resolve().parents[1] / "research/dense-functional-extension-verification.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "verified", "n75_offsets": len(rows),
                      "small_independent_checks": small, "receipt": str(destination)}))


if __name__ == "__main__":
    main()

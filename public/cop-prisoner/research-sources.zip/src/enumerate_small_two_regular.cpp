// Bounded heuristic search only: two permutations, degree-preserving switches.
// Exact game objective, deterministic seed, one worker, user-selected time cap.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <random>
#include <vector>

int n;
uint64_t out[64],win[64],safe[64],nextw[64];
int score(const std::vector<int>&p,const std::vector<int>&q) {
  uint64_t all=(uint64_t(1)<<n)-1;
  for(int u=0;u<n;++u)out[u]=(uint64_t(1)<<u)|(uint64_t(1)<<p[u])|(uint64_t(1)<<q[u]);
  int I=0;
  for(int t=0;t<n;++t) {
    std::fill(win,win+n,0);win[t]=all;bool changed=true;
    while(changed) {
      for(int v=0;v<n;++v) {
        safe[v]=0;
        if(v==t)safe[v]=all;
        else for(int c=0;c<n;++c)if(!(out[c]&~win[v]))safe[v]|=uint64_t(1)<<c;
      }
      changed=false;
      for(int r=0;r<n;++r) {
        uint64_t w=(r==t)?all:(safe[r]|safe[p[r]]|safe[q[r]])&~(uint64_t(1)<<r);
        nextw[r]=w;changed|=w!=win[r];
      }
      std::copy(nextw,nextw+n,win);
    }
    for(int s=0;s<n;++s)if(s!=t && p[s]!=t && q[s]!=t && (win[s]|(uint64_t(1)<<s))==all)++I;
  }
  return I;
}

int main(int argc,char**argv) {
  n=argc>1?std::atoi(argv[1]):16;double budget=argc>2?std::atof(argv[2]):5;
  if(n<4 || n>60)return 2;
  std::mt19937 rng(120926+n);std::uniform_real_distribution<double> U(0,1);
  std::vector<int>p(n),q(n),bp,bq;int best=-1;long long evaluations=0;
  auto start=std::chrono::steady_clock::now();
  auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
  while(elapsed()<budget && best<n*(n-3)) {
    do {
      std::iota(p.begin(),p.end(),0);std::iota(q.begin(),q.end(),0);
      std::shuffle(p.begin(),p.end(),rng);std::shuffle(q.begin(),q.end(),rng);
    }while([&](){for(int i=0;i<n;++i)if(p[i]==i || q[i]==i || p[i]==q[i])return true;return false;}());
    int current=score(p,q);++evaluations;
    for(int step=0;step<3000 && elapsed()<budget;++step) {
      bool which=rng()%2;auto &a=which?p:q;auto &b=which?q:p;
      int u=rng()%n,v=rng()%n;if(u==v || a[v]==u || a[u]==v || a[v]==b[u] || a[u]==b[v])continue;
      std::swap(a[u],a[v]);int candidate=score(p,q);++evaluations;
      double temperature=0.3+3.0*(1.0-(step%500)/500.0);
      if(candidate>=current || U(rng)<std::exp((candidate-current)/temperature))current=candidate;
      else std::swap(a[u],a[v]);
      if(current>best){best=current;bp=p;bq=q;if(best==n*(n-3))break;}
    }
  }
  std::cout<<"{\"n\":"<<n<<",\"m\":"<<2*n<<",\"seed\":"<<120926+n<<",\"evaluations\":"<<evaluations
    <<",\"seconds\":"<<elapsed()<<",\"I\":"<<best<<",\"upper_bound\":"<<n*(n-3)<<",\"arcs\":[";
  for(int u=0;u<n;++u){if(u)std::cout<<",";std::cout<<"["<<u<<","<<bp[u]<<"],["<<u<<","<<bq[u]<<"]";}
  std::cout<<"]}\n";
}

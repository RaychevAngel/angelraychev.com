#!/usr/bin/env python3
"""Split the complete Hamiltonian certificate without changing its proof terms.

The input is an untrusted generated Lean source. Each split module is still
checked by Lean; this transformation grants no mathematical premise.
"""
from __future__ import annotations
import argparse,hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE='FiniteExclusionThirtyNineHamiltonian'
NAMESPACE='Delivery.FiniteExclusion.Thirty9Minimum'

def split(source):
    begin=source.index('def piece_')
    root=source.index('theorem piece_root')
    result={BASE+'Base':source[:begin]+f'end {NAMESPACE}\n'}
    buckets={};top=[]
    blocks=re.split(r'(?=^(?:def|theorem) piece_)',source[begin:root],flags=re.M)
    for block in blocks:
        if not block.strip():continue
        match=re.match(r'(?:def|theorem) piece_(\d+)(?:_(\d+))?',block)
        if match is None:raise ValueError('unexpected declaration: '+block[:100])
        if match[2] is None:top.append(block)
        else:buckets.setdefault((int(match[1]),int(match[2])),[]).append(block)
    header=f'import {BASE}Base\nset_option maxRecDepth 65536\nset_option maxHeartbeats 200000000\nnamespace {NAMESPACE}\nopen RotationBounds Extremal\n'
    for (x,y),parts in buckets.items():result[f'{BASE}{x}x{y}']=header+''.join(parts)+f'end {NAMESPACE}\n'
    result[BASE]=''.join(f'import {BASE}{x}x{y}\n' for x,y in buckets)+f'namespace {NAMESPACE}\nopen RotationBounds Extremal\n'+''.join(top)+source[root:]
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=ROOT/'tmp/lean-oct23/finite/FiniteExclusionThirtyNine9Depth4Minimum.lean');ap.add_argument('--check',action='store_true');args=ap.parse_args()
    contents=split(args.source.read_text());records=[]
    for name,content in contents.items():
        path=ROOT/'lean'/(name+'.lean')
        if args.check:
            if not path.exists() or path.read_text()!=content:raise RuntimeError('split source differs: '+str(path))
        else:path.write_text(content)
        records.append(dict(module=name,bytes=len(content.encode()),sha256=hashlib.sha256(content.encode()).hexdigest()))
    print(json.dumps(dict(checked=args.check,modules=records),indent=2))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Bounded exact arithmetic for the parent's independent-run envelope idea.

No graph or pursuit-game search. Each saved entry verifies the explicit
formula and compares integer routing/envelope capacities.
"""
from math import gcd
from pathlib import Path
import hashlib,json


def main():
    rows=[]
    for n in range(200,1075):
        exponent=1
        while n*(n-1)**2*7**exponent >= 8**exponent:
            exponent+=1
        b=exponent+3
        budget=b*(2*n-b-1)//2
        best=None
        for h in range(7,min(63,(n-1)//2)+1,2):
            if gcd(h,n)!=1:
                continue
            a=(h-1)//2
            period=3*a-1
            size=(a-1)*(n//period)
            seed={0,1,a,h}
            differences={(u-v)%n for u in (1,a,h) for v in (1,a,h) if u!=v}
            forbidden=seed|{(x+d)%n for x in seed for d in differences}
            assert len(forbidden)<=19
            retained=(size*(n-len(forbidden))+n-1)//n
            capacity=n*(3+retained)
            record={'n':n,'b':b,'routing_budget':budget,'h':h,'a':a,
                    'independent_size':size,'forbidden_size':len(forbidden),
                    'guaranteed_envelope_size':4+retained,
                    'capacity':capacity,'passes':budget<=capacity}
            if best is None or capacity>best['capacity']:
                best=record
        rows.append(best)
    failures=[r['n'] for r in rows if not r['passes']]
    receipt={'verified':True,'range':[200,1074],
             'last_failed_order':max(failures),'all_pass_from':max(failures)+1,
             'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'scope':'Finite integer formula comparisons only. The independent-run '
                     'spacing proof and orientation theorem are ordinary prerequisites. '
                     'No graph search or Lean claim.', 'rows':rows}
    path=Path(__file__).resolve().parents[1]/'research/routing-defect-phase2-overlap-checks.json'
    path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='rows'}))


if __name__=='__main__':main()

#!/usr/bin/env python3
"""Independently certify one failed strongly connected regular cover."""
from pathlib import Path
import json,hashlib
from game_solver import neighborhoods,recipient_fast,recipient_explicit,verify_certificate,bits
ROOT=Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'research/composition-interface-covers.json').read_text())['records'][0]
n=d['n'];out,arcs=neighborhoods(n,d['arcs']);t=d['failed_target']
w,_=recipient_fast(n,out,t,True);other,cert=recipient_explicit(n,out,t,True)
assert w==other and verify_certificate(n,out,cert)
reach=[]
for s in range(n):
 seen={s};todo=[s]
 while todo:
  u=todo.pop()
  for v in bits(out[u]):
   if v not in seen:seen.add(v);todo.append(v)
 reach.append(len(seen))
assert set(reach)=={n}
bad=[(r,c) for r in range(n) for c in range(n) if r!=c and not (w[r]>>c&1)]
art={'claim':'A strongly connected two-sheet directed cover of a certified universal 12-vertex graph is not universal.','base_n':12,'n':n,'arcs':arcs,'cover_permutations':d['cover_permutations'],'failed_target':t,'failed_starts':bad,'failed_with_distinct_base_projections':sum(r//2!=c//2 for r,c in bad),'strongly_connected':True,'source_camping_obstructions':d['source_camps'],'independent_full_game_certificate':cert,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'research/composition-interface-cover-counterexample.json').write_text(json.dumps(art,indent=2)+'\n')
print({k:v for k,v in art.items() if k not in ('arcs','cover_permutations','independent_full_game_certificate','source_sha256','failed_starts')})

#!/usr/bin/env python3
"""Bounded structural literal families at nineteen and twenty arrows."""
import itertools
import json
import time
from pathlib import Path
from small_plateau_probe import ROOT,evaluate,certificate
from small_case_certificate_review import review


def main(seconds=60):
    start=time.monotonic(); calls=0; best={}; events=[]; families=[]
    seeds=json.loads((ROOT/'research/finish_constructions_certificates.json').read_text())
    seeds.extend(json.loads((ROOT/'research/small-case-support-witnesses.json').read_text()))
    seeds.extend(json.loads((ROOT/'research/small-exceptional-general-certificates.json').read_text()))
    for name in ['sparse-third-one-transfer-in-certificate.json',
                 'small-exceptional-one-excess-11-witness-certificate.json']:
        seeds.append(json.loads((ROOT/'research'/name).read_text()))
    def test(n,arcs,family):
        nonlocal calls
        m=len(arcs)
        if (m!=19 or n not in (9,10)) and (n,m)!=(11,20):return
        value=evaluate(n,arcs)[:2];calls+=1;key=(n,m)
        if value>best.get(key,((-1,-1),None,None))[0]:
            previous=best.get(key,((-1,-1),None,None))[0][0]
            best[key]=(value,set(arcs),family)
            if value[0]>previous:
                event=dict(n=n,m=m,I=value[0],family=family,seconds=round(time.monotonic()-start,3));events.append(event);print(json.dumps(event),flush=True)
    for g in seeds:
        arcs=set(map(tuple,g['arcs']))
        if len(arcs)==19 and g['n']<=10:
            for n in (9,10):
                if g['n']<=n:test(n,arcs,'existing_literal_or_isolates')
        if len(arcs)==20 and g['n']<=11:test(11,arcs,'existing_literal_or_isolates')
    # Delete one old vertex, preserving every remaining original arrow.
    for g in seeds:
        if g['n'] not in (10,11):continue
        arcs=set(map(tuple,g['arcs']))
        for v in range(g['n']):
            remaining={(a-(a>v),b-(b>v)) for a,b in arcs if v not in (a,b)}
            if len(remaining)==19:test(g['n']-1,remaining,'single_vertex_deletion')
            elif 19<len(remaining)<=21:
                for deleted in itertools.combinations(sorted(remaining),len(remaining)-19):
                    test(g['n']-1,remaining-set(deleted),'single_vertex_then_at_most_two_arrows')
    # A finite class of two-arrow edits after introducing a new relay vertex.
    for g in seeds:
        if g['n']==9 and len(g['arcs'])==18:
            arcs=set(map(tuple,g['arcs']))
            for u,v in arcs:test(10,(arcs-{(u,v)})|{(u,9),(9,v)},'single_subdivision_of_9_18')
        if g['n']==10 and len(g['arcs'])==20:
            arcs=set(map(tuple,g['arcs']))
            for u,v in arcs:
                expanded=(arcs-{(u,v)})|{(u,10),(10,v)}
                for e in arcs-{(u,v)}:test(11,expanded-{e},'subdivision_and_one_deletion')
    # Descend once from each saved high-value core, exact bounded subsets.
    cores={}
    for g in seeds:
        n=g['n'];m=len(g['arcs'])
        if n in (9,10) and 20<=m<=24:
            key=(n,m)
            if key not in cores or g.get('I',-1)>cores[key].get('I',-1):cores[key]=g
    for (n,m),g in sorted(cores.items(),key=lambda item:(item[0][1],item[0][0])):
        count=0;complete=True;arcs=set(map(tuple,g['arcs']))
        for deleted in itertools.combinations(sorted(arcs),m-19):
            if time.monotonic()-start>seconds:complete=False;break
            candidate=arcs-set(deleted);test(n,candidate,f'delete_{m-19}_from_saved_{n}_{m}');count+=1
        families.append(dict(n=n,start_m=m,target_m=19,candidates=count,complete=complete))
        if not complete:break
    graphs=[];receipts=[]
    for (n,m),(value,arcs,family) in sorted(best.items()):
        g=certificate(n,arcs);assert g['I']==value[0];g['construction_family']=family
        graphs.append(g);receipts.append(review(g))
    (ROOT/'research/finish_constructions_nineteen_certificates.json').write_text(json.dumps(graphs,indent=2)+'\n')
    result=dict(seconds=time.monotonic()-start,calls=calls,events=events,families=families,review=receipts,
                scope='Literal lower constructions only. Complete finite descendant families do not constitute global upper bounds.')
    (ROOT/'research/finish_constructions_nineteen_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__=='__main__':main()

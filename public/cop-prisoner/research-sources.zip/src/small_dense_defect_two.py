#!/usr/bin/env python3
"""Complete two-out endpoint class with at most one killed size-two column.

This is only one degree class. Its failure alone does not improve the
general two-loss bound: degree-one missing rows require a separate proof.
"""
from __future__ import annotations
import itertools
import json
import time
from pathlib import Path
from game_solver import solve_graph

ROOT = Path(__file__).resolve().parents[1]


def allowed(rows,n):
    for s,row in rows.items():
        for c,other in rows.items():
            if c!=s and set(other)<=set(row)|{s}:return False
    for c,row in rows.items():
        if all(u in rows for u in row):
            common=set(rows[row[0]])&set(rows[row[1]])
            if common-{0}:return False
    return True


def enumerate_order(n):
    cases=[{0:(1,2),1:(0,3),2:(0,4)},
           {1:(0,3),2:(0,4),3:(1,2)},
           {1:(0,4),2:(0,5),3:(1,2)}]
    results=[];best_graph=None;best=-1
    candidates={s:[row for row in itertools.combinations([t for t in range(n)if t!=s],2)
                   if (0 in row)==(s in (1,2))]for s in range(n)}
    for number,initial in enumerate(cases):
        nodes=leaves=0
        def visit(rows):
            nonlocal nodes,leaves,best,best_graph
            nodes+=1
            if not allowed(rows,n):return
            if len(rows)==n:
                leaves+=1
                arcs=[(s,t)for s in range(n)for t in range(n)if s!=t and t not in rows[s]]
                game=solve_graph(n,arcs)
                if game['I']>best:best=game['I'];best_graph=game
                return
            v=min(s for s in range(n)if s not in rows)
            for row in candidates[v]:visit(rows|{v:row})
        visit(initial)
        results.append({'normal_form':number,'nodes':nodes,'leaves':leaves})
    return {'n':n,'complete':True,'cases':results,'best_I':best},best_graph


def one_killed_row(n,seconds=20):
    start=time.monotonic();nodes=leaves=0;best=-1;best_graph=None;capped=False
    # The sole killed row is1, dominated by0 through the transitive triple.
    # Row1's other neighbor cannot be0, which would also kill row0.
    initial={0:(1,2),1:(2,3)}
    candidates={s:[row for row in itertools.combinations([t for t in range(n)if t!=s],2)
                   if 2 not in row]for s in range(2,n)}
    def valid(rows):
        for s,row in rows.items():
            if s==1:continue
            for c,other in rows.items():
                if c!=s and set(other)<=set(row)|{s}:return False
        for c,row in rows.items():
            for t in range(n):
                blockers=set(row)-{t}
                if all(u in rows and t in rows[u] for u in blockers):
                    if any(w not in (1,c) and t in wr for w,wr in rows.items()):return False
        return True
    def visit(rows):
        nonlocal nodes,leaves,best,best_graph,capped
        nodes+=1
        if nodes%1024==0 and time.monotonic()-start>seconds:capped=True
        if capped or not valid(rows):return
        if len(rows)==n:
            leaves+=1
            arcs=[(s,t)for s in range(n)for t in range(n)if s!=t and t not in rows[s]]
            game=solve_graph(n,arcs)
            if game['I']>best:best=game['I'];best_graph=game
            return
        s=min(v for v in range(n)if v not in rows)
        for row in candidates[s]:
            visit(rows|{s:row})
            if capped:break
    visit(initial)
    return {'n':n,'family':'one killed source row','complete':not capped,'nodes':nodes,
            'leaves':leaves,'best_I':best,'elapsed_seconds':time.monotonic()-start},best_graph


def main():
    started=time.monotonic();report=[];certificates=[]
    for n in (7,8):
        row,game=enumerate_order(n);report.append(row)
        if game is not None:certificates.append(solve_graph(n,game['arcs'],crosscheck=True,certificates=True))
        print(json.dumps(row),flush=True)
    for n in (7,8):
        row,game=one_killed_row(n);report.append(row)
        if game is not None:certificates.append(solve_graph(n,game['arcs'],crosscheck=True,certificates=True))
        print(json.dumps(row),flush=True)
    (ROOT/'research/small-dense-defect-two-columns.json').write_text(json.dumps({'scope':__doc__,'elapsed_seconds':time.monotonic()-started,'orders':report},indent=2)+'\n')
    (ROOT/'research/small-dense-defect-two-column-certificates.json').write_text(json.dumps(certificates,separators=(',',':'))+'\n')


if __name__ == '__main__':main()

// Bounded successor experiment for total defect three; a witness is not an exclusion.
// No graph solver. No pair is counted twice. Covers the four normalized
// two-out missing-degree families needed for a putative total defect two.
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
int n;array<unsigned,8> rows{};array<bool,8> known{};
array<vector<unsigned>,8> candidates;
uint64_t nodes,leaves; int best=-1; bool found=false;

int losses(){
 array<unsigned,8> lost{};
 for(int s=0;s<n;s++)if(known[s])
  for(int c=0;c<n;c++)if(known[c]&&c!=s && !(rows[c]&~(rows[s]|(1u<<s))))
   lost[s]|=rows[s];
 for(int c=0;c<n;c++)if(known[c])for(int t=0;t<n;t++){
  bool covered=true;
  for(unsigned bits=rows[c]&~(1u<<t);bits;bits&=bits-1){
   int u=__builtin_ctz(bits);
   if(!known[u] || !(rows[u]>>t&1)){covered=false;break;}
  }
  if(covered)for(int s=0;s<n;s++)if(known[s]&&s!=c&&(rows[s]>>t&1))lost[s]|=1u<<t;
 }
 int total=0;for(int s=0;s<n;s++)total+=__builtin_popcount(lost[s]);return total;
}


int game_score(){
 unsigned all=(1u<<n)-1;array<unsigned,8> out{};
 for(int s=0;s<n;s++)out[s]=all^rows[s];
 int score=0;
 for(int t=0;t<n;t++){
  array<unsigned,8>w{};w[t]=all;
  for(;;){
   array<unsigned,8>safe{},next{};safe[t]=all;
   for(int v=0;v<n;v++)if(v!=t)for(int c=0;c<n;c++)if(!(out[c]&~w[v]))safe[v]|=1u<<c;
   for(int s=0;s<n;s++){
    if(s==t){next[s]=all;continue;}
    for(unsigned b=out[s];b;b&=b-1)next[s]|=safe[__builtin_ctz(b)];
    next[s]&=all^(1u<<s);
   }
   if(next==w)break;w=next;
  }
  for(int s=0;s<n;s++)if((rows[s]>>t&1)&&w[s]==(all^(1u<<s)))score++;
 }
 return score;
}

void visit(int assigned){
 if(found)return;
 ++nodes;if(losses()>3)return;
 if(assigned==n){
  ++leaves;int value=game_score();
  if(value>best){best=value;cout<<"{\"kind\":\"record\",\"n\":"<<n<<",\"I\":"<<best<<",\"missing_masks\":[";for(int s=0;s<n;s++)cout<<(s?",":"")<<rows[s];cout<<"]}"<<endl;}
  if(best==2*n-3)found=true;return;
 }
 int selected=-1;vector<unsigned> options;
 for(int s=0;s<n;s++)if(!known[s]){
  vector<unsigned> valid;known[s]=true;
  for(unsigned row:candidates[s]){rows[s]=row;if(losses()<=3)valid.push_back(row);}
  known[s]=false;rows[s]=0;
  if(valid.empty())return;
  if(selected<0||valid.size()<options.size()){selected=s;options=valid;}
 }
 known[selected]=true;
 for(unsigned row:options){rows[selected]=row;visit(assigned+1);}
 known[selected]=false;rows[selected]=0;
}

int main(){
 n=5;known.fill(false);rows.fill(0);known[0]=known[1]=true;
 rows[0]=(1u<<1)|(1u<<2);rows[1]=(1u<<2)|(1u<<3);
 assert(losses()==2); // row/column overlap is counted once, with cop exception.
 rows[0]=rows[1]=(1u<<2)|(1u<<3);assert(losses()==4);
 for(n=7;n<=8;n++)for(int form=0;form<4;form++){
  if(form==0){found=false;best=-1;}
  if(found)continue;
  known.fill(false);rows.fill(0);nodes=leaves=0;
  for(int s=0;s<n;s++){
   candidates[s].clear();
   for(int a=0;a<n;a++)for(int b=a+1;b<n;b++)if(a!=s&&b!=s){
    unsigned mask=(1u<<a)|(1u<<b);
    bool incoming=form==3 ? bool(mask>>2&1)==(s==0||s==1)
                         : bool(mask&1)==(s==1||s==2);
    candidates[s].push_back(mask);
   }
  }
  auto fix=[](int s,int a,int b){known[s]=true;rows[s]=(1u<<a)|(1u<<b);};
  int assigned=3;
  if(form==0){fix(0,1,2);fix(1,0,3);fix(2,0,4);}
  if(form==1){fix(1,0,3);fix(2,0,4);fix(3,1,2);}
  if(form==2){fix(1,0,4);fix(2,0,5);fix(3,1,2);}
  if(form==3){fix(0,1,2);fix(1,2,3);assigned=2;}
  visit(assigned);
  cout<<"{\"n\":"<<n<<",\"normal_form\":"<<form<<",\"nodes\":"<<nodes
      <<",\"leaves\":"<<leaves<<",\"complete\":true}"<<endl;

 }
}

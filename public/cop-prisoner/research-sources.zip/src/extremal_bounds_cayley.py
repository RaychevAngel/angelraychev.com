from itertools import permutations
from extremal_bounds_explore import target_winners

def permprod(p,q):return tuple(p[q[i]] for i in range(len(p)))
def cayley(k,generators):
    ident=tuple(range(k)); group=[ident];seen={ident}
    for p in group:
        for g in generators:
            q=permprod(p,g)
            if q not in seen:seen.add(q);group.append(q)
    ix={p:i for i,p in enumerate(group)}
    return [{ix[permprod(p,g)] for g in generators} for p in group]
if __name__=='__main__':
    for k in range(3,5):
        a=tuple(range(1,k))+(0,);b=(1,0)+tuple(range(2,k))
        adj=cayley(k,[a,b]);ws=target_winners(adj,0)
        print(k,len(adj),len(ws),ws,flush=True)

#!/usr/bin/env python3
"""Restrict arrival types before closing the navigation interface."""
import json,time,hashlib
from pathlib import Path
from composition_interface_free_group import arena,ball
from composition_interface_invariant import attract,mul,inv
ROOT=Path(__file__).resolve().parents[1]

def run(types,extras=(),maxrounds=12):
 ar=arena((0,1,3),extras=extras);M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1
 iw=ball(2);IC=[(w,i) for w in iw for i in range(10)]+[(None,i) for i in range(10)];ii={v:i for i,v in enumerate(IC)}
 maps=[]
 for w,rtype in M:
  row=[]
  for cw,ctype in C:
   if cw is None:poss=[ii[(None,ctype)]]+[ii[(v,ctype)] for v in iw if len(mul(w,v))>3]
   else:
    v=mul(inv(w),cw);poss=[ii[(v,ctype)] if len(v)<=2 else ii[(None,ctype)]]
   row.append(sum(1<<x for x in poss))
  maps.append(row)
 I=[(((1<<len(IC))-1)^(1<<ii[((),i)])) if i in types else 0 for i in range(10)];trace=[];fixed=False
 for iteration in range(maxrounds):
  J=I[:]
  for g in (-1,-2):
   seeds=[sum(1<<c for c,poss in enumerate(maps[r]) if poss&~I[typ]==0) if w==(g,) else 0 for r,(w,typ) in enumerate(M)]
   W,rounds=attract(ar,seeds)
   for typ in types:
    for c,poss in enumerate(maps[mi[((),typ)]]):
     if not(W[mi[((),typ)]]>>c&1):J[typ]&=~poss
   trace.append({'iteration':iteration,'generator':g,'rounds':rounds})
  if J==I:fixed=True;break
  I=J
 seeds=[sum(1<<c for c,poss in enumerate(maps[r]) if poss&~I[typ]==0) for r,(w,typ) in enumerate(M)]
 W,rounds=attract(ar,seeds)
 bad=[(i,c) for i in range(10) for c in range(len(C)) if c!=ci[((),i)] and not(W[mi[((),i)]]>>c&1)]
 return {'types':types,'extras':extras,'remaining':sum(x.bit_count() for x in I),'fixed':fixed,'normalization_failed':len(bad),'normalization_rounds':rounds,'trace':trace,'interface_masks':I}

if __name__=='__main__':
 records=[];start=time.monotonic()
 for ts in ((0,5),(1,6),(2,7),(3,8),(4,9),(0,3,5,8),(1,2,4,6,7,9)):
  d=run(ts);records.append(d);print({k:v for k,v in d.items() if k not in ('trace','interface_masks')},flush=True)
 out={'scope':'restricted type-interface diagnostic, not a universal quotient theorem','seconds':time.monotonic()-start,'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (ROOT/'research/composition-interface-port-invariant.json').write_text(json.dumps(out,indent=2)+'\n')

// Complete target-I=13 endpoint (n=8,m=40) decision, 2026-09-13.
// New standalone file. Chronological ascending degrees and suffix cells;
// literal union of source/predecessor camping losses; explicit reachability.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
constexpr int N=8, ALL=255, TARGET=13, CAP=3;
array<int,N> degree{}, missing{}, incoming{};
array<array<vector<int>,N>,N> options;
vector<array<int,N>> profiles;
uint64_t nodes=0, leaves=0, total_nodes=0,total_leaves=0;
int best=-1, selected=-1; bool timeout=false, found=false;
double seconds; auto began=chrono::steady_clock::now();

int forced(int count){
 array<int,N> lost{};
 for(int s=0;s<count;++s)for(int c=0;c<count;++c)
  if(c!=s && !(missing[c]&~(missing[s]|(1<<s))))lost[s]|=missing[s];
 for(int c=0;c<count;++c){
  int common=ALL;
  for(int bits=missing[c];bits;bits&=bits-1){
   int v=__builtin_ctz((unsigned)bits);
   common &= (v<count ? missing[v] : 0)|(1<<v);
  }
  for(int s=0;s<count;++s)if(s!=c)lost[s]|=missing[s]&common;
 }
 int result=0;for(int x:lost)result+=__builtin_popcount((unsigned)x);return result;
}

int score(){
 constexpr int SIZE=2*N*N;
 array<vector<int>,N> previous;
 for(int u=0;u<N;++u)for(int v=0;v<N;++v)
  if(!(missing[u]>>v&1))previous[v].push_back(u); // includes wait exactly once
 array<unsigned char,SIZE> won{};array<int,SIZE> remaining{};vector<int> queue;
 int result=0;
 for(int target=0;target<N;++target){
  won.fill(0);queue.clear();
  for(int s=0;s<N;++s)for(int c=0;c<N;++c)remaining[2*(s*N+c)+1]=N-degree[c];
  for(int c=0;c<N;++c)for(int turn=0;turn<2;++turn){int z=2*(target*N+c)+turn;won[z]=1;queue.push_back(z);}
  for(size_t h=0;h<queue.size();++h){
   int z=queue[h],s=z/(2*N),c=z/2%N;
   if(z%2){for(int p:previous[s]){int q=2*(p*N+c);if(p!=c&&!won[q]){won[q]=1;queue.push_back(q);}}}
   else {for(int p:previous[c]){int q=2*(s*N+p)+1;if(s!=p&&!won[q]&&--remaining[q]==0){won[q]=1;queue.push_back(q);}}}
  }
  for(int s=0;s<N;++s)if(missing[s]>>target&1){
   bool yes=true;for(int c=0;c<N;++c)if(c!=s&&!won[2*(s*N+c)])yes=false;
   result+=yes;
  }
 }
 return result;
}

void row_json(const array<int,N>& data){cout<<'[';for(int s=0;s<N;++s)cout<<(s?",":"")<<data[s];cout<<']';}
void recurse(int row){
 if(timeout||found)return;
 ++nodes;
 if((nodes&4095)==0 && chrono::duration<double>(chrono::steady_clock::now()-began).count()>seconds){timeout=true;return;}
 if(forced(row)>CAP)return;
 if(row==N){
  ++leaves;int value=score();best=max(best,value);
  cout<<"{\"kind\":\"leaf\",\"profile\":"<<selected<<",\"missing_masks\":";row_json(missing);
  cout<<",\"I\":"<<value<<",\"forced_loss_count\":"<<forced(N)<<"}\n";
  if(value>=TARGET){found=true;cout.flush();}return;
 }
 for(int mask:options[row][degree[row]]){
  bool canonical=true;
  for(int v=row+2;v<N;++v)
   if(degree[v-1]==degree[v]&&incoming[v-1]==incoming[v]&&(mask>>(v-1)&1)&&!(mask>>v&1)){canonical=false;break;}
  if(!canonical)continue;
  missing[row]=mask;
  for(int v=0;v<N;++v)if(mask>>v&1)incoming[v]|=1<<row;
  recurse(row+1);
  for(int v=0;v<N;++v)incoming[v]&=~(1<<row);
  missing[row]=0;
  if(timeout||found)return;
 }
}
void make_profiles(int row,int minimum,int total,int ones){
 if(row==N){if(total==16&&ones<=4)profiles.push_back(degree);return;}
 for(int d=minimum;d<N;++d){
  if(total+d*(N-row)>16)break;
  if(total+d+(N-row-1)*(N-1)<16)continue;
  int nextones=ones+(d==1);if(nextones>4)continue;
  degree[row]=d;make_profiles(row+1,d,total+d,nextones);
 }
}
int main(int argc,char**argv){
 seconds=argc>1?atof(argv[1]):60;
 int first=argc>2?atoi(argv[2]):0,last=argc>3?atoi(argv[3]):999;
 if(seconds<=0||first<0||last<first)return 2;
 for(int s=0;s<N;++s)for(int mask=ALL;mask>=1;--mask)
  if(!(mask>>s&1))options[s][__builtin_popcount((unsigned)mask)].push_back(mask);
 make_profiles(0,1,0,0);began=chrono::steady_clock::now();
 cout<<"{\"kind\":\"start\",\"n\":8,\"m\":40,\"target_I\":13,\"defect_cap\":3,\"profile_count\":"<<profiles.size()<<",\"seconds_cap\":"<<seconds<<",\"first_profile\":"<<first<<",\"last_profile_exclusive\":"<<last<<"}"<<endl;
 for(selected=0;selected<(int)profiles.size();++selected){
  if(selected<first||selected>=last)continue;
  degree=profiles[selected];nodes=leaves=0;missing.fill(0);incoming.fill(0);
  auto profile_began=chrono::steady_clock::now();
  recurse(0);total_nodes+=nodes;total_leaves+=leaves;
  cout<<"{\"kind\":\"profile\",\"profile\":"<<selected<<",\"degrees\":";row_json(degree);
  cout<<",\"nodes\":"<<nodes<<",\"leaves\":"<<leaves<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-profile_began).count()<<",\"complete\":"<<(!timeout&&!found?"true":"false")<<",\"found\":"<<(found?"true":"false")<<",\"timeout\":"<<(timeout?"true":"false")<<"}"<<endl;
  if(timeout||found)break;
 }
 cout<<"{\"kind\":\"summary\",\"complete_requested_profiles\":"<<(!timeout&&!found?"true":"false")<<",\"found\":"<<(found?"true":"false")<<",\"timeout\":"<<(timeout?"true":"false")<<",\"nodes\":"<<total_nodes<<",\"leaves\":"<<total_leaves<<",\"best_evaluated_I\":"<<best<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-began).count()<<"}"<<endl;
}

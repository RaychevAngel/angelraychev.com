#!/usr/bin/env python3
"""Save and independently verify the six finite cyclic bases k=4..9."""
from pathlib import Path
import hashlib,json
from five_type_policy import family
from game_solver import recipient_fast,recipient_explicit,verify_certificate

def main():
    root=Path(__file__).resolve().parents[1];records=[]
    for k in range(4,10):
        n,a,b,out,arcs=family(k);targets=[]
        for t in range(5):
            fast,layers=recipient_fast(n,out,t,True)
            explicit,certificate=recipient_explicit(n,out,t,True)
            assert fast==explicit
            assert all(fast[r]|(1<<r)==(1<<n)-1 for r in range(n))
            assert verify_certificate(n,out,certificate)
            targets.append({'target':t,'messenger_move_layers':layers,
                            'explicit_alternating_certificate':certificate})
        records.append({'k':k,'n':n,'arcs':arcs,'targets':targets})
        print('verified k=',k,'all five target types',flush=True)
    artifact={'scope':'k=4..9, targets (0,j) for j=0..4; column translations preserve arcs and cover all recipients',
              'methods':'synchronous messenger-move layers and independent explicit alternating attractor; all strategy ranks checked',
              'records':records,'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in (Path(__file__),root/'src/five_type_policy.py',root/'src/game_solver.py')}}
    (root/'research/five-type-small-ring-certificates.json').write_text(json.dumps(artifact,indent=2)+'\n')

if __name__=='__main__':main()

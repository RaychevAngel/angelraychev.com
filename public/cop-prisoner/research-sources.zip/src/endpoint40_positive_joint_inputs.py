#!/usr/bin/env python3
"""Complete positive-degree inputs for a main cell, with only explicit pair upper bounds."""
import argparse,itertools,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def patterns(n,m,target):
 result=[]
 for ascending in itertools.combinations_with_replacement(range(1,n-1),n):
  if sum(ascending)!=m:continue
  D=ascending[::-1];q=sum(d>=2 for d in D);lowout=n-q
  if sum(n-1-d for d in D if d>=2)<target:continue
  def incoming(i,left,E):
   if i==n:
    if left:return
    r=sum(e>=2 for e in E);lowin=n-r
    if sum(n-1-e for e in E if e>=2)<target:return
    overlap=sum(d>=2 and e>=2 for d,e in zip(D,E))
    eligible=q*r-overlap-m+lowout+lowin
    if eligible>=target:result.append(tuple(zip(D,E)))
    return
   high=min(n-1,left-(n-i-1))
   if i and D[i]==D[i-1]:high=min(high,E[-1])
   for e in range(high,0,-1):
    if left-e>(n-i-1)*(n-1):continue
    incoming(i+1,left-e,E+(e,))
  incoming(0,m,())
 assert len(result)==len(set(result))
 return result
def main():
 p=argparse.ArgumentParser();p.add_argument('n',type=int);p.add_argument('m',type=int);p.add_argument('target',type=int)
 a=p.parse_args();family=patterns(a.n,a.m,a.target);stem=f'endpoint40_positive_n{a.n}_m{a.m}_t{a.target}'
 (ROOT/'research'/f'{stem}.json').write_text(json.dumps({'n':a.n,'m':a.m,'target_I':a.target,'joint_patterns':family,
  'joint_pattern_count':len(family),'scope':'All positive degrees, excluding universal outgoing rows (I=0), with row/column candidate counts and the active-rectangle eligible upper at least target.'},indent=2)+'\n')
 (ROOT/'research'/f'{stem}.txt').write_text(str(len(family))+'\n'+'\n'.join(' '.join(str(x) for pair in pat for x in pair) for pat in family)+'\n')
 print(json.dumps({'n':a.n,'m':a.m,'target_I':a.target,'joint_patterns':len(family)}))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Explicit root-colored cycle attachments for the dense staircase.

This is a construction and fixed-graph verifier, not a graph search.
The uniform ordinary proof is paper/dense-third.md.
"""
from __future__ import annotations
import hashlib
import json
import argparse
from pathlib import Path
from dense_unified_core import functional, two_move_pairs
from game_solver import solve_graph

ROOT = Path(__file__).resolve().parents[1]

# Frozen pre-pass unresolved cells. Verification must not depend on whether a
# later coverage rebuild has incorporated this theorem.
BASELINE_DENSE_CELLS = [(7,m) for m in range(29,34)] + \
    [(8,m) for m in range(41,47)] + [(9,m) for m in range(55,61)] + \
    [(10,m) for m in range(71,77)] + [(11,m) for m in range(89,96)] + \
    [(12,m) for m in [109,*range(111,117)]] + \
    [(13,m) for m in [131,*range(134,139)]] + \
    [(14,m) for m in [155,*range(159,163)]] + \
    [(15,m) for m in [181,*range(186,189)]] + \
    [(16,m) for m in range(215,218)] + [(17,m) for m in range(246,249)] + \
    [(18,m) for m in range(279,281)] + [(19,314)]


def missing_graph(r: int, k: int):
    """Return F; delivery adjacency is all nonloops outside F."""
    assert r >= 2 and k >= 0
    missing, roots = functional(r)
    if k == 0:
        return missing
    if k == 1:
        assert len(roots) >= 2
        return missing | {(r, roots[0]), (r, roots[1])}
    if k % 2 and len(roots) == 2:
        last = r+k-1
        missing |= {(r+i, roots[i % 2]) for i in range(k-1)}
        missing |= {(r+i, r+(i+1) % (k-1)) for i in range(k-1)}
        missing |= {(last, roots[0]), (last, roots[1])}
        return missing
    colors = [i % 2 for i in range(k)]
    if k % 2:
        colors[-1] = 2
    assert len(roots) >= max(colors) + 1
    assert all(colors[i] != colors[(i+1) % k] for i in range(k))
    missing |= {(r+i, roots[colors[i]]) for i in range(k)}
    missing |= {(r+i, r+(i+1) % k) for i in range(k)}
    return missing


def applies(r: int, k: int):
    return r >= 2 and k >= 0 and (k == 0 or r >= 5)


def two_move_applies(r: int, k: int):
    return applies(r,k) and (k <= 1 or k % 2 == 0 or r >= 7)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    checks = []
    for r in range(2, 41):
        for k in range(61):
            if not two_move_applies(r, k):
                continue
            n = r+k
            f = missing_graph(r, k)
            expected = 2*n-r-(r+1)//2-1
            assert len(f) == 2*n-r
            assert len(two_move_pairs(n, f)) == expected
            checks.append([r, k, expected])
    gaps = []
    certificates = []
    for n,m in BASELINE_DENSE_CELLS:
        r = m-n*(n-3)
        k = n-r
        if not applies(r, k):
            continue
        f = missing_graph(r, k)
        g = {(s,t) for s in range(n) for t in range(n)
             if s != t and (s,t) not in f}
        result = solve_graph(n, g, certificates=True, crosscheck=True)
        expected = 2*n-r-(r+1)//2-1
        assert result['m'] == m and result['I'] == expected
        gaps.append({'n':n, 'm':m, 'r':r, 'k':k, 'I':expected,
                     'guaranteed_move_bound':2 if two_move_applies(r,k) else 3,
                     'missing_arcs':sorted(f)})
        certificates.append(result)
    cert_path = ROOT/'research/dense-third-root-cycle-certificates.json'
    cert_text = json.dumps(certificates, separators=(',',':'))+'\n'
    if args.check:
        assert cert_path.read_text() == cert_text
    else:
        cert_path.write_text(cert_text)
    receipt = {'status':'verified',
               'proof_boundary':'The uniform ordinary proof is separate. Fixed examples checked by two independent actual-game solvers and full alternating-state certificate replay; no Lean claim.',
               'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'checked_instances':len(checks),
               'parameter_rectangle':{'r':[2,40], 'k':[0,60]},
               'new_exact_dense_cells':gaps,
               'certificates':str(cert_path.relative_to(ROOT)),
               'certificate_sha256':hashlib.sha256(cert_path.read_bytes()).hexdigest(),
               'certificate_states':sum(2*z['n']**3 for z in certificates)}
    path = ROOT/'research/dense-third-root-cycle-checks.json'
    receipt_text = json.dumps(receipt,indent=2)+'\n'
    if args.check:
        assert path.read_text() == receipt_text
    else:
        path.write_text(receipt_text)
    print(json.dumps({'checked_instances':len(checks), 'new_exact_dense_cells':len(gaps),
                      'certificate_states':receipt['certificate_states'], 'receipt':str(path)}))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Strengthen the navigation interface for the branch-aware terminal modules."""
from pathlib import Path
import json,hashlib,time
from composition_interface_free_group import arena,ball
from composition_interface_invariant import attract,mul,inv
from composition_interface_certify import good
ROOT=Path(__file__).resolve().parents[1]

def run(maxrounds=12,extra_forbidden=((3,(),5),(8,(),0))):
 ar=arena((0,1,3));M,C,mi,ci,mo,co=ar;iw=ball(2);IC=[(w,i) for w in iw for i in range(10)]+[(None,i) for i in range(10)];ii={v:i for i,v in enumerate(IC)};maps=[]
 for w,rtype in M:
  row=[]
  for cw,ctype in C:
   if cw is None:poss=[ii[None,ctype]]+[ii[v,ctype] for v in iw if len(mul(w,v))>3]
   else:
    v=mul(inv(w),cw);poss=[ii[v,ctype] if len(v)<=2 else ii[None,ctype]]
   row.append(sum(1<<x for x in poss))
  maps.append(row)
 I=[sum(1<<c for c,(w,j) in enumerate(IC) if good(i,w,j) and (i,w,j) not in set(extra_forbidden)) for i in range(10)];trace=[];fixed=False
 for iteration in range(maxrounds):
  J=I[:]
  for g in (-1,-2):
   seeds=[sum(1<<c for c,poss in enumerate(maps[r]) if poss&~I[typ]==0) if w==(g,) else 0 for r,(w,typ) in enumerate(M)]
   W,rounds=attract(ar,seeds)
   for typ in range(10):
    for c,poss in enumerate(maps[mi[(),typ]]):
     if not(W[mi[(),typ]]>>c&1):J[typ]&=~poss
   trace.append({'iteration':iteration,'generator':g,'rounds':rounds})
  print('iteration',iteration,'remaining',sum(x.bit_count() for x in J),flush=True)
  if J==I:fixed=True;break
  I=J
 seeds=[sum(1<<c for c,poss in enumerate(maps[r]) if poss&~I[typ]==0) for r,(w,typ) in enumerate(M)]
 W,rounds=attract(ar,seeds);bad=[(i,C[c]) for i in range(10) for c in range(len(C)) if c!=ci[(),i] and not(W[mi[(),i]]>>c&1)]
 forbidden=[(i,w,j) for i in range(10) for c,(w,j) in enumerate(IC) if not (w==() and i==j) and not(I[i]>>c&1)]
 return {'fixed':fixed,'remaining':sum(x.bit_count() for x in I),'normalization_rounds':rounds,'normalization_failed':len(bad),'bad':bad,'forbidden':forbidden,'trace':trace,'interface_masks':I,'interface_cop_states':IC}

if __name__=='__main__':
 start=time.monotonic();out=run();out.update(seconds=time.monotonic()-start,scope='strengthened navigation synthesis; no terminal certificate asserted',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
 (ROOT/'research/composition-interface-branch-closed.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ('interface_masks','interface_cop_states','trace')})

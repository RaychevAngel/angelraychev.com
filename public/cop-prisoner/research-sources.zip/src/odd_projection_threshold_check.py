#!/usr/bin/env python3
"""Read-only rank replay and exact-support audit for the odd threshold 98.

Frozen certificate bytes are never rewritten.  The unbounded conclusion uses
the displayed projection inequalities, not the bounded cyclic sanity checks.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPECS = [
    dict(r=0, sigma=[0,2,5,1,4,3], voltage=[-1,-1,1,1,-1,1], removed=[], source=(0,0), which=0, M=4, R=6, J=2, direction=1),
    dict(r=1, sigma=[0,5,1,4,3,2], voltage=[-1,1,1,-1,-1,1], removed=[(0,3)], source=(1,4), which=1, M=4, R=6, J=1, direction=1),
    dict(r=2, sigma=[3,5,0,2,4,1], voltage=[-1,1,-1,-1,-1,0], removed=[(0,0),(0,1)], source=(0,5), which=1, M=4, R=6, J=2, direction=-1),
    dict(r=3, sigma=[4,1,5,2,0,3], voltage=[-1,-1,1,1,-1,1], removed=[(0,2),(0,3),(0,4)], source=(0,1), which=0, M=5, R=7, J=2, direction=1),
    dict(r=4, sigma=[4,1,5,2,0,3], voltage=[-1,-1,1,1,-1,1], removed=[(-1,4),(0,2),(0,3),(0,4)], source=(0,1), which=0, M=5, R=7, J=2, direction=1),
    dict(r=5, sigma=[3,5,0,2,4,1], voltage=[-1,1,-1,-1,-1,0], removed=[(0,0),(0,1),(1,0),(1,1),(1,5)], source=(0,5), which=1, M=5, R=7, J=2, direction=-1),
]


class Patch:
    def __init__(self, spec, shift=0, q=None):
        self.spec, self.q = spec, q
        self.removed = {self.norm((i+shift,j)) for i,j in spec['removed']}
        self.source = self.norm((spec['source'][0]+shift,spec['source'][1]))
        self.target = self.smooth(self.source,spec['which'])

    def norm(self,v):
        return (v[0]%self.q,v[1]) if self.q else v

    def raw(self,v,which,backwards=False):
        i,j = v
        if which == 0:
            w = ((i,j-1) if j else (i-1,5)) if backwards else ((i,j+1) if j<5 else (i+1,0))
        elif backwards:
            a = self.spec['sigma'].index(j)
            w = i-self.spec['voltage'][a],a
        else:
            w = i+self.spec['voltage'][j],self.spec['sigma'][j]
        return self.norm(w)

    def smooth(self,v,which,backwards=False):
        w = self.raw(v,which,backwards)
        seen = set()
        while w in self.removed:
            assert w not in seen, 'An entire permutation cycle was removed'
            seen.add(w)
            w = self.raw(w,which,backwards)
        return w

    def outgoing(self,v):
        assert v not in self.removed
        row = [self.smooth(v,z) for z in (0,1)]
        assert len(set(row)) == 2 and v not in row
        if v == self.source:
            row.remove(self.target)
        return row


def support_check(spec):
    patch = Patch(spec)
    # Every changed tail is the first surviving predecessor of a removed
    # vertex in one permutation, or the tail of the final deleted arc.
    tails = {patch.source}
    for v in patch.removed:
        tails.update(patch.smooth(v,z,True) for z in (0,1))
    changed = {v for v in tails if patch.outgoing(v) != [patch.raw(v,z) for z in (0,1)]}
    support = changed | patch.removed | {patch.source,patch.target}
    a,b = min(v[0] for v in support),max(v[0] for v in support)
    jump = max(1,*(abs(w[0]-v[0]) for v in changed for w in patch.outgoing(v)))
    assert jump <= spec['J']
    q = max(2*spec['R']+spec['J']+1,2*spec['R']+b-a+1)
    anchors = [-spec['R']-b,spec['R']-a]
    allowed = [-6,6] if spec['r']==0 else [-10,10]
    assert allowed[0] <= anchors[0] <= anchors[1] <= allowed[1]
    # The permutation-cycle argument is uniform: every beta type-cycle has
    # nonzero total voltage, |voltage|<=cycle length, hence lifted length>=q.
    unseen = set(range(6))
    cycles = []
    while unseen:
        v = next(iter(unseen)); cycle = []
        while v in unseen:
            unseen.remove(v);cycle.append(v);v=spec['sigma'][v]
        total = sum(spec['voltage'][v] for v in cycle)
        assert 0 < abs(total) <= len(cycle)
        cycles.append(dict(types=cycle,voltage=total))
    assert q > len(patch.removed)
    return dict(residue=spec['r'],R=spec['R'],allowed_entry_depth=spec['J'],maximum_actual_jump=jump,
                support_span=[a,b],changed_tails=[list(v) for v in sorted(changed)],relevant_anchor_interval=anchors,
                minimum_q=q,first_order=6*q-spec['r'],beta_cycles=cycles)


def arena(spec,anchor):
    patch = Patch(spec,1000 if anchor is None else anchor)
    mv = [(i,j) for i in range(-spec['M'],spec['M']+1) for j in range(6) if (i,j) not in patch.removed]
    cv = [(i,j) for i in range(-spec['R'],spec['R']+1) for j in range(6) if (i,j) not in patch.removed]+[None]
    mi,ci = {v:i for i,v in enumerate(mv)},{v:i for i,v in enumerate(cv)}
    mm = [[mi[w] for w in [v,*patch.outgoing(v)] if w in mi] for v in mv]
    cm = [sorted({ci.get(w,len(cv)-1) for w in [v,*patch.outgoing(v)]}) if v is not None else
          [len(cv)-1]+[i for i,w in enumerate(cv) if w is not None and abs(w[0])>=spec['R']-spec['J']+1]
          for v in cv]
    return patch,mv,cv,mm,cm


def replay_record(spec,record):
    anchor = record['defect_column'] if spec['r']==0 else record['patch_shift']
    patch,mv,cv,mm,cm = arena(spec,anchor)
    ranks,chosen = record['ranks'],record['chosen_messenger_successors']
    target = record['target_type']; nc=len(cv)
    assert len(ranks)==len(chosen)==2*len(mv)*nc
    assert target is None or ((0,target) not in patch.removed and (0,target)!=patch.target)
    required=[]; obligations=0
    for r,p in enumerate(mv):
        for c,cop in enumerate(cv):
            for turn in (0,1):
                sid=2*(r*nc+c)+turn
                success = (turn==0 and p[0] in ({0,-1} if spec['r']==5 else {0}) and p!=patch.source and p!=cop) if target is None else p==(0,target)
                if success:
                    assert ranks[sid]==0
                    continue
                if p==cop:
                    assert ranks[sid]==-1
                    continue
                children = [2*(w*nc+c)+1 for w in mm[r]] if turn==0 else [2*(r*nc+w) for w in cm[c]]
                obligations += len(children)
                if ranks[sid]>=0:
                    if turn==0:
                        assert chosen[sid] in children and 0<=ranks[chosen[sid]]<ranks[sid]
                    else:
                        assert children and all(0<=ranks[w]<ranks[sid] for w in children)
                elif turn==0:
                    assert all(ranks[w]<0 for w in children)
                else:
                    assert any(ranks[w]<0 for w in children)
            columns = {-spec['direction']} if target is None else {(-spec['direction'])*d for d in ((2,3) if spec['r']==5 else (2,))}
            if p[0] in columns and p!=patch.source and p!=cop:
                required.append(2*(r*nc+c))
    assert all(ranks[s]>=0 for s in required)
    assert len(required)==record['required_starts'] and not record['failed_starts']
    bound=(max(ranks[s] for s in required)+1)//2
    assert bound==record['messenger_moves_bound']
    return dict(states=len(ranks),required_starts=len(required),legal_transition_obligations=obligations,bound=bound)


def projection_check(spec,structure):
    q=structure['minimum_q']; ring=Patch(spec,q=q);R=spec['R'];J=spec['J']
    vertices=[(i,j) for i in range(q) for j in range(6) if (i,j) not in ring.removed]
    incoming=dict.fromkeys(vertices,0)
    for v in vertices:
        for w in ring.outgoing(v):incoming[w]+=1
    assert all(d==(1 if v==ring.target else 2) for v,d in incoming.items())
    checks=0
    for center in range(q):
        lo,hi=structure['relevant_anchor_interval']
        anchors=[-center+t*q for t in range(-2,3) if lo<=-center+t*q<=hi]
        assert len(anchors)<=1
        local=Patch(spec,anchors[0] if anchors else 1000)
        projected={((i+center)%q,j):(i,j) for i in range(-R,R+1) for j in range(6)}
        for i in range(-R,R+1):
            for j in range(6):
                v=(i,j); actual=((i+center)%q,j)
                assert (v in local.removed)==(actual in ring.removed)
                if v in local.removed:continue
                assert {projected.get(w) for w in ring.outgoing(actual)}=={w if abs(w[0])<=R else None for w in local.outgoing(v)}
                checks+=1
        for v in vertices:
            if v in projected:continue
            for w in ring.outgoing(v):
                z=projected.get(w)
                assert z is None or abs(z[0])>=R-J+1
    return dict(q=q,n=len(vertices),represented_vertex_checks=checks)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true',help='Replay and compare the saved audit without writing any file')
    args=parser.parse_args()
    paths=['research/six-type-independent-odd-certificates.json.gz','research/six-type-independent-odd-residues-certificates.json.gz']
    hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
    with gzip.open(ROOT/paths[0],'rt') as stream:zero=json.load(stream)
    with gzip.open(ROOT/paths[1],'rt') as stream:nonzero=json.load(stream)
    all_records=[(0,r) for r in zero['certificates']]+[(r['removed_count'],r) for r in nonzero['certificates']]
    expected=set()
    for spec in SPECS:
        for anchor in [None,*range(-6,7)] if spec['r']==0 else [None,*range(-10,11)]:
            patch=Patch(spec,1000 if anchor is None else anchor)
            for target in [None,*[j for j in range(6) if (0,j) not in patch.removed and (0,j)!=patch.target]]:
                expected.add((spec['r'],anchor,target))
    observed=[(r,row['defect_column'] if r==0 else row['patch_shift'],row['target_type']) for r,row in all_records]
    assert len(observed)==len(set(observed)) and set(observed)==expected
    replay=[]
    for r,row in all_records:replay.append(replay_record(SPECS[r],row))
    structure=[support_check(s) for s in SPECS]
    assert [s['minimum_q'] for s in structure]==[15,15,15,17,17,18]
    assert max(6*(s['minimum_q']-1)-s['residue'] for s in structure)+1==98
    projections=[projection_check(s,t) for s,t in zip(SPECS,structure)]
    from odd_endpoint_all_residues import graph
    constructor_checks=[]
    for n in range(98,104):
        actual=graph(n);spec=SPECS[actual['removed']];patch=Patch(spec,q=actual['q'])
        vertices=[tuple(v) for v in actual['vertices']]
        expected={(v,w) for v in vertices for w in patch.outgoing(v)}
        assert {(vertices[a],vertices[b]) for a,b in actual['arcs']}==expected
        assert vertices[actual['low_source']]==patch.source and vertices[actual['low_recipient']]==patch.target
        constructor_checks.append(dict(n=n,q=actual['q'],missing_vertex_residue=spec['r'],arcs=len(expected)))
    try:
        graph(97)
    except ValueError:
        pass
    else:
        raise AssertionError('Constructor accepted an order below its asserted uniform threshold')
    assert hashes=={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
    sources=['src/odd_projection_threshold_check.py','src/odd_endpoint_all_residues.py','paper/odd-endpoint-resume.md']
    result=dict(status='passed',minimum_uniform_order=98,finite_bridge_orders=[13,97],finite_graph_dependencies_removed=47,
                proof_boundary='Unbounded projection follows the stated support and jump inequalities plus frozen local rank lemmas; cyclic checks are bounded sanity checks, not extrapolation.',
                frozen_certificate_sha256=hashes,source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources},
                local_modules=len(replay),local_states=sum(r['states'] for r in replay),required_starts=sum(r['required_starts'] for r in replay),
                legal_transition_obligations=sum(r['legal_transition_obligations'] for r in replay),residue_parameters=structure,projection_sanity_checks=projections,canonical_constructor_checks=constructor_checks,
                historical_provenance='Original generation receipts retain their old thresholds and source pins; no frozen proof bytes were regenerated or repinned.')
    destination=ROOT/'research/odd-projection-threshold-audit.json'
    if args.check:
        assert json.loads(destination.read_text())==result, 'Saved threshold audit differs from fresh replay'
    else:
        destination.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','minimum_uniform_order','local_modules','local_states','required_starts','legal_transition_obligations')}))


if __name__=='__main__':main()

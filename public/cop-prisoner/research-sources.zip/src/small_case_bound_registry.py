#!/usr/bin/env python3
"""Freeze the individually reviewed upper/reduction inventory.

This is an explicit theorem list, not inference from best search scores.
Changing the list requires ordinary review of the new proof dependency.
"""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    sources = ['src/small_case_bound_registry.py',
        'research/small-case-n7-independent-review.md','research/small-case-n7-independent-review.json',
        'research/small-case-n7-independent.json','src/small_case_n7_independent.cpp',
        'src/small_case_n7_independent_review.py','src/small_case_n7_independent_run.py',
        'research/small-plateau-camped80-review.md','research/small-plateau-camped80-review.json',
        'research/small-plateau-n11-upper-review.md','research/small-plateau-n11-upper-review.json',
        'research/small-loss-n11-m24-camping-free-80.json','research/small-loss-n11-m24-camped80.json',
        'src/small_loss_profiles.cpp','src/small_loss_camped_profiles.cpp',
        'research/small-plateau-double-defect-review.md','research/small-plateau-double-defect-review.json',
        'research/small-sparse-twenty-upper.md','research/small-sparse-twenty-checkpoint.json',
        'src/small_sparse_double_defect.cpp','src/small_sparse_regular.cpp','src/small_sparse_transfer.cpp',
        'research/small-case-dense-review.md','research/small-case-rooted-independent-review.json',
        'src/small_case_rooted_review.py','research/small-dense-root-designation-proof.md',
        'research/small-dense-rooted-equality-proof.md','research/small-dense-second-step-proof.md',
        'research/small-dense-endpoint-independent-checks.json','src/small_dense_endpoint_independent.py',
        'research/small-case-support-cutoffs.json','paper/support-concentration.md',
        'research/small-case-first-step-independent-review.json','src/small_case_first_step_review.py',
        'research/small-dense-first-step-proof.md','research/small-case-first-step-literal-review.json',
        'research/small-plateau-one-excess-review.md','research/small-plateau-one-excess-review.json',
        'src/small_plateau_one_excess_review.py','research/small-sparse-eleven23-proof.md',
        'research/small-sparse-eleven23-checkpoint.json','src/small_sparse_one_excess.cpp',
        'research/small-case-tiny-review.md','research/small-case-tiny-review.json',
        'src/small_case_tiny_review.py','research/small-sparse-eight39-review.md',
        'research/small-sparse-eight39-review.json','src/small_sparse_eight39_review.py',
        'research/small-case-host-compression-review.md','research/small-case-host-compression-review.json',
        'src/small_case_host_compression_review.py',
        'research/small-case-defect-two-review.md','research/small-case-defect-two-review.json',
        'research/small-dense-endpoint-three-loss-proof.md',
        'src/small_dense_defect_two.py','src/small_dense_defect_two_independent.cpp',
        'research/small-dense-defect-two-columns.json','research/small-dense-defect-two-independent.jsonl']
    n7=json.loads((ROOT/'research/small-case-n7-independent-review.json').read_text())
    assert n7['verified'] and n7['complete_budget_count']==20
    bounds=[{'n':7,'m':int(m),'value':value,'proof':'complete independent order7 exclusion'}
            for m,value in n7['uppers'].items()]
    bounds += [
        {'n':11,'m':None,'value':85,'proof':'reviewed vertex maximum using25-arrow witness and24-arrow exclusion'},
        {'n':11,'m':24,'value':79,'proof':'reviewed complete camping-free and43 camped classes'},
        {'n':11,'m':23,'value':78,'proof':'reviewed complete14-type one-excess exclusion with330 degree patterns'},
        {'n':None,'m':20,'value':57,'proof':'reviewed support profiles and complete regular/transfer/double-defect exclusions'},
    ]
    bounds += [{'n':n,'m':m,'value':v,'proof':'reviewed complete fixed-host tiny-budget enumeration'}
               for n,m,v in [(8,12,9),(9,12,9),(8,13,11)]]
    dense=[(8,39,14),(8,40,13),(8,41,11),(9,55,14),(10,71,16),(8,42,10),(9,56,12),(10,72,15),
           (8,43,9),(9,57,11),(8,44,8),(9,58,10),(10,74,12)]
    bounds += [{'n':n,'m':m,'value':v,'proof':'reviewed dense defect split and independent rooted-family replay'} for n,m,v in dense]
    caps=json.loads((ROOT/'research/small-case-support-cutoffs.json').read_text())
    assert caps['verified']
    source_hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources}
    for path,value in caps['source_sha256'].items():
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==value
        source_hashes[path]=value
    host_rows=caps['rows']
    completion=ROOT/'research/finish-case-approved-bounds.json'
    if completion.exists():
        extra=json.loads(completion.read_text());assert extra['verified']
        for path,value in extra['source_sha256'].items():
            assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==value,(path,'completion review changed')
            source_hashes[path]=value
        bounds.extend(extra['upper_bounds'])
        host_rows=extra['host_cutoffs']
        source_hashes['research/finish-case-approved-bounds.json']=hashlib.sha256(completion.read_bytes()).hexdigest()
    data={'scope':'Individually accepted ordinary proofs and complete finite exclusions; no bound is inferred from unsuccessful discovery.',
          'upper_bounds':bounds,'host_cutoffs':host_rows,'source_sha256':source_hashes}
    (ROOT/'research/small-case-approved-bounds.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'approved_upper_bounds':len(bounds),'host_cutoffs':len(caps['rows'])}))


if __name__=='__main__':
    main()

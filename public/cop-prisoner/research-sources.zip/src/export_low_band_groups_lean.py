#!/usr/bin/env python3
"""Group the frozen local policies by messenger position, rank, and move.

This only changes the finite proof encoding. Original ranks, every required
entry cop state, and every policy successor under every cop reply are retained.
The generic Lean group kernel checks all group masks and strategy obligations.
"""
import argparse
from collections import defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import export_low_band_lean as original

ROOT=Path(__file__).resolve().parents[1]


def pattern_text(index,p,record):
    arena=original.make_arena(record['holes'])
    rm=[(u+5)*6+t for u,t in arena['messenger_vertices']]
    cm=[102 if v is None else (v[0]+8)*6+v[1] for v in arena['pursuer_vertices']]
    reply_masks=[0]*103
    for c,row in enumerate(arena['pursuer_moves']):
        reply_masks[cm[c]]=sum(1<<cm[d] for d in row)
    present=set(rm)
    collision_masks=[1<<(r+18) if r in present else (1<<103)-1 for r in range(66)]
    valid=sum(1<<c for c in cm)
    required_masks=[valid & ~collision_masks[r] if r in present else 0 for r in range(66)]
    old=f'LowBandPattern{index:03}';name=f'LowBandGroupedPattern{index:03}'
    text=original.header(f'import {old}\nimport GroupedArena',name)
    text+=f'''open {old} GroupedArena
def replyBits (r : Nat) : Nat := {original.lookup_tree(reply_masks)}
def collisionBits (r : Nat) : Nat := {original.lookup_tree(collision_masks)}
def replyMasks (c : C) : Nat := replyBits c.val
def collisionMasks (r : R) : Nat := collisionBits r.val
def requiredBits (r : Nat) : Nat := {original.lookup_tree(required_masks)}
def requiredMasks (r : R) : Nat := requiredBits r.val
theorem reply_rows_covered : ∀ c, (frozenReplies c).all (fun d => (replyMasks c).testBit d.val)=true := by
  decide +kernel
theorem reply_coverage : ∀ c d, frozenArena.pursuer c d → (replyMasks c).testBit d.val=true := by
  intro c d member
  exact (List.all_eq_true.mp (reply_rows_covered c)) d member
theorem collision_coverage : ∀ r c, frozenArena.collision r c → (collisionMasks r).testBit c.val=true := by
  decide +kernel
theorem required_coverage : ∀ r c, presentR pattern r → presentC pattern c →
    ¬(arena pattern).collision r c → Has (requiredMasks r) c := by
  unfold Has
  decide +kernel
#print axioms required_coverage
#print axioms reply_coverage
#print axioms collision_coverage
end Delivery.{name}
'''
    return name,text,rm,cm


def objective_text(index,record,rm,cm):
    c=record['certificate'];width=len(cm);target=record['target']
    groups=[defaultdict(list) for _ in range(66)]
    for rr,r in enumerate(rm):
        for cc,cop in enumerate(cm):
            at=rr*width+cc;rank=c['messenger_ranks'][at]
            if rank<0:continue
            move=c['policy'][at];z=rm[move] if move>=0 else 0
            groups[r][rank,z].append(cop)
    encoded=[];bounded=[]
    for r,row in enumerate(groups):
        terms=[];mask=0
        bound=9 if target is None else (39 if r//6+3==5 else 38)
        for (rank,z),cops in sorted(row.items()):
            bits=sum(1<<cop for cop in cops)
            terms.append(f'{{rank:={rank},move:={z},cops:={original.seq(cops)},mask:={bits}}}')
            if rank<=bound:mask|=bits
        encoded.append(terms);bounded.append(mask)
    kind='Transfer' if target is None else f'Delivery{target}'
    name=f'LowBandGroupedObjective{index:03}{kind}'
    pn=f'LowBandPattern{index:03}';gn=f'LowBandGroupedPattern{index:03}'
    goal='transferGoal pattern' if target is None else f'deliveryGoal pattern {target}'
    mode='false' if target is None else 'true'
    check='safe_checked' if target is None else 'delivery_checked'
    checked='SafeChecked' if target is None else 'DeliveryChecked'
    text=original.header(f'import {gn}',name)
    text+=f'''open {pn} {gn} GroupedArena
noncomputable def groupRows (r : Nat) : List (Group 66 103) := {original.lookup_tree(encoded)}
noncomputable def rows (r : R) : List (Group 66 103) := groupRows r.val
noncomputable def data : LocalArena.Data R C := GroupedArena.data rows
theorem groups_checked : Checked {mode} frozenArena ({goal}) replyMasks collisionMasks rows := by
  unfold Checked
  decide +kernel
theorem checked : {checked} (arena pattern) ({goal}) data := by
  rw [←arena_eq]
  exact GroupedArena.{check} frozenArena ({goal}) replyMasks collisionMasks rows
    reply_coverage collision_coverage groups_checked
def entryBound (r : R) : Nat := {"9" if target is None else "if rcol r=5 then 39 else 38"}
def entryBits (r : Nat) : Nat := {original.lookup_tree(bounded)}
def boundedMasks (r : R) : Nat := entryBits r.val
theorem bounded_agrees : ∀ r, lowerMask (rows r) (entryBound r+1)=boundedMasks r := by
  decide +kernel
theorem entry_subset : ∀ r, {"rcol r=7" if target is None else "(rcol r=5 ∨ rcol r=6)"} →
    requiredMasks r &&& boundedMasks r=requiredMasks r := by
  decide +kernel
theorem entry_bits : ∀ r c, presentR pattern r → {"rcol r=7" if target is None else "(rcol r=5 ∨ rcol r=6)"} →
    presentC pattern c → ¬(arena pattern).collision r c → (boundedMasks r).testBit c.val=true := by
  intro r c pr entry pc safe
  exact GroupedArena.has_subset (entry_subset r entry) (required_coverage r c pr pc safe)
theorem initial_states : ∀ r c, presentR pattern r → {"rcol r=7" if target is None else "(rcol r=5 ∨ rcol r=6)"} →
    presentC pattern c → ¬(arena pattern).collision r c →
    data.region r c ∧ data.rank r c≤{ "9" if target is None else "(if rcol r=5 then 39 else 38)"} := by
  intro r c pr entry pc safe
  apply GroupedArena.bounded rows r c (entryBound r)
  rw [bounded_agrees]
  exact entry_bits r c pr entry pc safe
#print axioms checked
#print axioms initial_states
end Delivery.{name}
'''
    return name,text,dict(groups=sum(len(x) for x in groups),states=sum(len(cops) for x in groups for cops in x.values()))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=ROOT/'tmp/lean-low-band-groups')
    ap.add_argument('--patterns',type=int,default=1,help='Exclusive upper pattern index')
    ap.add_argument('--from-pattern',type=int,default=0)
    ap.add_argument('--canonical-objectives',action='store_true')
    ap.add_argument('--target',type=int,default=2,help='-1 for transfer; -2 for all objectives')
    args=ap.parse_args();assert 0<=args.from_pattern<args.patterns<=101 and -2<=args.target<=5
    assert hashlib.sha256(original.SOURCE.read_bytes()).hexdigest()==original.EXPECTED
    data=json.loads(gzip.decompress(original.SOURCE.read_bytes()))
    lookup={(tuple(r['holes']),r['target']):r for r in data['records']}
    source=(ROOT/'lean/LowBandCropCoverage.lean').read_text()
    patterns=json.loads(source.split('def catalog : List (List Nat) := ',1)[1].split('\n\nset_option',1)[0])
    records=[];files={};args.out.mkdir(parents=True,exist_ok=True)
    for index in range(args.from_pattern,args.patterns):
        p=patterns[index]
        key=tuple(x-8 for x in p)
        name,text,rm,cm=pattern_text(index,p,lookup[key,None])
        (args.out/f'{name}.lean').write_text(text)
        files[name+'.lean']=hashlib.sha256(text.encode()).hexdigest()
        for target in ([None,0,1,2,3,4,5] if args.target==-2 else [None if args.target==-1 else args.target]):
            if target==4 and 8 in p:continue
            record=original.reachable_record(lookup[key,target])
            name,text,stats=objective_text(index,record,rm,cm)
            if args.canonical_objectives:
                canonical=name.replace('LowBandGroupedObjective','LowBandObjective')
                text=text.replace(name,canonical)
                name=canonical
            (args.out/f'{name}.lean').write_text(text)
            files[name+'.lean']=hashlib.sha256(text.encode()).hexdigest()
            records.append(dict(module=name,**stats))
    (args.out/'low-band-grouped-manifest.json').write_text(json.dumps(dict(source_sha256=original.EXPECTED,exporter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scalar_exporter_sha256=hashlib.sha256(Path(original.__file__).read_bytes()).hexdigest(),files=files,from_pattern=args.from_pattern,patterns=args.patterns,canonical_objectives=args.canonical_objectives,records=records),indent=2)+'\n')
    print(json.dumps(dict(objectives=len(records),states=sum(x['states'] for x in records),groups=sum(x['groups'] for x in records))))

if __name__=='__main__':main()

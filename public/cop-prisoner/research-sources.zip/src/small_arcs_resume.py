#!/usr/bin/env python3
"""Reproduce the all-order arc maxima at budgets eight through eleven.

The ordinary weak-component reduction is in paper/small-arcs-resume.md.
Two canonically ordered exhaustive implementations certify the remaining
fixed-host upper bounds. Both original game solvers verify lower witnesses.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import time
from game_solver import solve_graph

ROOT=Path(__file__).resolve().parents[1]
CASES=((8,4),(9,5),(10,6),(11,8))

def main():
 start=time.monotonic();rows=[];sources=['src/small_arcs_sparse_primary.cpp','src/small_arcs_sparse_independent.cpp','src/small_arcs_resume.py','src/game_solver.py']
 old=json.loads((ROOT/'research/solver-enumeration-n6.json').read_text())['by_m']
 with tempfile.TemporaryDirectory(prefix='cop-small-arcs-')as directory:
  binaries=[]
  for name in ('primary','independent'):
   binary=Path(directory)/name
   subprocess.run(['clang++','-O3','-std=c++17',str(ROOT/f'src/small_arcs_sparse_{name}.cpp'),'-o',str(binary)],check=True)
   binaries.append(binary)
  for m,value in CASES:
   records=[]
   for name,binary in zip(('primary','independent'),binaries):
    command=[str(binary),str(m-1),str(value+1),str(m),str(m),'30']
    r=json.loads(subprocess.run(command,check=True,capture_output=True,text=True,timeout=40).stdout)
    assert r['complete']and not r['counterexample_found'],r
    records.append({'implementation':name,**r})
   if m<11:
    arcs=next(r['witness_arcs']for r in old if r['m']==m);n=6
   else:
    arcs=[(0,1),(1,0),(2,3),(3,4),(3,5),(4,0),(4,2),(5,3),(5,6),(6,1),(6,2)];n=7
   witness=solve_graph(n,arcs,certificates=True,crosscheck=True)
   assert witness['I']==value
   rows.append({'m':m,'maximum_I':value,'upper_enumerations':records,'lower_certificate':witness})
   print(json.dumps({'m':m,'maximum_I':value,'upper_seconds':[r['seconds']for r in records],'both_complete':True}),flush=True)
 receipt={'verified':True,'scope':'All graph orders, using the ordinary connected-component reduction and the complete fixed-host enumerations; no new Lean coverage.',
          'maxima':{str(m):v for m,v in CASES},'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()for p in sources},
          'seconds':time.monotonic()-start,'cases':rows}
 path=ROOT/'research/small-arcs-resume-verification.json';path.write_text(json.dumps(receipt,separators=(',',':'))+'\n')
 print(json.dumps({'verified':True,'seconds':receipt['seconds'],'receipt':str(path)}))

if __name__=='__main__':main()

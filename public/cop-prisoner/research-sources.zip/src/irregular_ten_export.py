#!/usr/bin/env python3
"""Render untrusted exact-family tree data as ordinary Lean literals."""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def natlist(xs):
    return '['+','.join(map(str,xs))+']'


def rows(xs):
    return '(rows '+' '.join(map(str,xs))+')'


def route(node):
    cases=[]
    for raw,entry in node['routes'].items():
        if int(raw)==entry['representative']:
            continue
        changes=[(i,j) for i,j in enumerate(entry['permutation']) if i!=j]
        perm='(fun i => match i.val with '+' '.join(f'| {i} => {j}' for i,j in changes)+' | _ => i)'
        cases.append(f'| {raw} => ({entry["representative"]},{perm})')
    if not cases:
        return '(fun mask => (mask,id))'
    return '(fun mask => match mask with '+' '.join(cases)+' | _ => (mask,id))'


def certificate(cert):
    losses=['{ target := '+str(loss['target'])+', region := '+rows(loss['region'])+
            ', good := '+rows(loss['good'])+' }' for loss in cert['losses']]
    return '{ allowed := '+rows(cert['allowed'])+', upper := '+rows(cert['upper'])+\
        ', lower := '+rows(cert['lower'])+', losses := ['+','.join(losses)+'] }'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--input',type=Path,default=ROOT/'tmp/lean-irregular/producer-tree.json')
    args=parser.parse_args()
    data=json.loads(args.input.read_text())
    assert data['n']==10 and data['arrows']==14 and data['bound']==13
    nodes=data['nodes'];generated=[]
    def save(name,source):
        path=ROOT/'lean'/f'{name}.lean'
        path.write_text(source)
        generated.append(dict(module=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    base='''import RowPrefixBoolean

namespace Delivery.IrregularTen14
open FiniteGame Extremal RowPrefix

def D (s : Fin 10) : Nat := if s.val < 4 then 2 else 1
def R (t : Fin 10) : Nat := if 4 ≤ t.val ∧ t.val < 8 then 2 else 1

def rows (a b c d e f g h i j : Nat) : Rows 10 := fun v =>
  match v.val with
  | 0 => a | 1 => b | 2 => c | 3 => d | 4 => e
  | 5 => f | 6 => g | 7 => h | 8 => i | _ => j

set_option maxRecDepth 100000
set_option maxHeartbeats 0

'''
    from irregular_ten_producer import CHOICES
    base+='def choices (d : Nat) : List Nat :=\n  if d = 2 then '+natlist(CHOICES[2])+' else '+natlist(CHOICES[1])+'\n\n'
    base+='theorem cover_one : RowCover 10 1 (choices 1) := by decide +kernel\n'
    base+='theorem cover_two : RowCover 10 2 (choices 2) := by decide +kernel\n'
    base+='''theorem complete (s : Fin 10) : RowCover 10 (D s) (choices (D s)) := by
  unfold D
  split
  · exact cover_two
  · exact cover_one

#print axioms complete
end Delivery.IrregularTen14
'''
    save('IrregularTen14Base',base)
    prefixes=sorted((v['prefix'] for v in nodes.values() if len(v['prefix'])==2))
    pieces={tuple(p):f'Case{index:02d}' for index,p in enumerate(prefixes)}
    def tree(p,indent=''):
        node=nodes[','.join(map(str,p))]
        if node['kind']=='bound':
            return '.bound '+certificate(node['certificate'])
        children=' '.join('| '+str(rep)+' => '+tree(p+[rep],indent+'  ') for rep in node['representatives'])
        return '.branch '+natlist(node['representatives'])+' '+route(node)+' (fun mask => match mask with '+children+' | _ => .invalid)'
    for p in prefixes:
        case=pieces[tuple(p)]
        src='import IrregularTen14Base\n\nnamespace Delivery.IrregularTen14.'+case+'\nopen RowPrefix\n'
        src+='set_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n'
        declarations=[]
        counter=[0]
        def proof(q):
            node=nodes[','.join(map(str,q))]
            index=counter[0];counter[0]+=1
            name='upper_'+str(index)
            if node['kind']=='bound':
                certname='bound_'+str(index)
                declarations.append('def '+certname+' : Bound 10 := '+certificate(node['certificate'])+'\n')
                declarations.append('theorem '+name+' : Upper D R '+natlist(q)+' 13 :=\n  bound_sound D R '+natlist(q)+' 13 '+certname+'\n    ((Boolean.boundCheck_true D R '+natlist(q)+' 13 '+certname+').mp (by decide +kernel))\n')
            else:
                reps=node['representatives'];children={rep:proof(q+[rep]) for rep in reps}
                d=data['outdegrees'][len(q)]
                rname='route_'+str(index)
                declarations.append('def '+rname+' : Route 10 := '+route(node)+'\n')
                text='theorem '+name+' : Upper D R '+natlist(q)+' 13 := by\n'
                text+='  apply routed_branch D R '+natlist(q)+' 13 (by decide) (choices '+str(d)+') '+natlist(reps)+' '+rname+'\n'
                text+='    (by exact cover_'+('two' if d==2 else 'one')+')\n'
                text+='    ((Boolean.routesCheck_true D R '+natlist(q)+' (choices '+str(d)+') '+natlist(reps)+' '+rname+').mp (by decide +kernel))\n'
                text+='  intro mask member\n'
                if reps:
                    text+='  simp only [List.mem_cons, List.not_mem_nil, or_false] at member\n'
                    text+='  rcases member with '+' | '.join('rfl' for _ in reps)+'\n'
                    text+=''.join('  · exact '+children[rep]+'\n' for rep in reps)
                else:text+='  simp at member\n'
                declarations.append(text)
            return name
        rootname=proof(p)
        src+='\n'.join(declarations)+'\n'
        src+='theorem upper : Upper D R '+natlist(p)+' 13 := '+rootname+'\n\n'
        src+='#print axioms upper\nend Delivery.IrregularTen14.'+case+'\n'
        save('IrregularTen14'+case,src)
    imports='\n'.join('import IrregularTen14'+case for case in pieces.values())
    final=imports+'\nimport IrregularTenProfile\n\nnamespace Delivery.IrregularTen14\n'
    final+='open FiniteGame Extremal RowPrefix\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n'
    def branch_proof(p,name,child_names):
        node=nodes[','.join(map(str,p))];reps=node['representatives']
        out='theorem '+name+' : Upper D R '+natlist(p)+' 13 := by\n'
        out+='  apply routed_branch D R '+natlist(p)+' 13 (by decide) (choices 2) '+natlist(reps)+'\n    '+route(node)+'\n'
        out+='    (by exact cover_two) (by decide +kernel)\n'
        out+='  intro mask member\n  simp only [List.mem_cons, List.not_mem_nil, or_false] at member\n'
        out+='  rcases member with '+' | '.join('rfl' for _ in reps)+'\n'
        out+=''.join('  · exact '+child_names[rep]+'\n' for rep in reps)
        return out+'\n'
    root=nodes['']
    for rep in root['representatives']:
        first=nodes[str(rep)]
        child_names={v:pieces[(rep,v)]+'.upper' for v in first['representatives']}
        final+=branch_proof([rep],f'row_{rep}',child_names)
    final+=branch_proof([],'canonical_upper',{rep:f'row_{rep}' for rep in root['representatives']})
    final+='''/-- Unconditional upper bound for the full positive-degree ten-vertex,
fourteen-arrow family. Degree-profile coverage and all search branches are checked. -/
theorem positive_upper (E : Graph (Fin 10)) (loopless : Loopless E)
    (budget : arcCount E = 14)
    (positiveOut : ∀ x, 1 ≤ SparseSupport.outdegree E x)
    (positiveIn : ∀ x, 1 ≤ SparseSupport.indegree E x) : score E ≤ 13 := by
  by_cases small : score E ≤ 13
  · exact small
  · obtain ⟨F,⟨iso⟩,loops,outDegrees,inDegrees⟩ :=
      IrregularTenProfile.normalize E loopless budget positiveOut positiveIn (by omega)
    have prescribed : Prescribed D R F := ⟨loops,outDegrees,inDegrees⟩
    have bound := canonical_upper F prescribed (by intro s h; simp at h)
    rw [GraphRelabeling.score_eq iso]
    exact bound

#print axioms canonical_upper
#print axioms positive_upper
end Delivery.IrregularTen14
'''
    save('IrregularTenFourteen',final)
    manifest=dict(input_sha256=hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  producer_sha256=data['source_sha256'],exporter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  counts=data['counts'],modules=generated,boundary='Literal certificate data only until source-pinned Lean replay succeeds.')
    (ROOT/'tmp/lean-irregular/export-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(dict(modules=len(generated),bytes=sum((ROOT/'lean'/f'{m["module"]}.lean').stat().st_size for m in generated))))


if __name__=='__main__':main()

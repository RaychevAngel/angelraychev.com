#!/usr/bin/env python3
"""Independent full rank certificates for the adjacent delivery-entry columns."""
from dense_phase2_sparse_independent import make_arena,patterns,solve_two_turns,ROOT
from pathlib import Path
import argparse,gzip,hashlib,json,time

def replay(a,target,cert):
    rv,cv,rm,cm=a;nc=len(cv)
    mr=cert['messenger_ranks'];cr=cert['cop_ranks'];policy=cert['policy']
    assert len(mr)==len(cr)==len(policy)==len(rv)*nc
    goals={r for r,v in enumerate(rv) if v[0]==0 and(target is None or v[1]==target)}
    for r,v in enumerate(rv):
        for c,w in enumerate(cv):
            state=r*nc+c;mrank=mr[state];crank=cr[state]
            if mrank>=0:
                if mrank==0:assert r in goals and(target is not None or v!=w)
                else:
                    assert v!=w and r not in goals
                    z=policy[state];assert z in rm[r]
                    assert 0<=cr[z*nc+c]<mrank
                    if not(target is not None and z in goals):assert rv[z]!=w
            if crank>=0 and not(target is not None and r in goals):
                assert v!=w
                for cp in cm[c]:
                    assert v!=cv[cp]
                    assert 0<=mr[r*nc+cp]<=crank
    bounds={}
    for col in cert['entry_columns']:
        values=[mr[r*nc+c] for r,v in enumerate(rv) if v[0]==col
                for c,w in enumerate(cv) if v!=w]
        assert values and min(values)>=0
        bounds[str(col)]=max(values)
    return bounds

def check_saved(path):
    saved=json.loads(gzip.decompress(path.read_bytes()))
    assert(saved['M'],saved['R'])==(5,8)
    expected={(holes,t) for holes in patterns()
              for t in[None]+[j for j in range(6)if j!=4 or 0 not in holes]}
    keys=[(tuple(row['holes']),row['target'])for row in saved['records']]
    assert len(keys)==len(expected) and set(keys)==expected
    maxima={'-1':0,'-3':0,'-2':0}
    for row in saved['records']:
        assert row['certificate']['entry_columns']==([-1]if row['target']is None else[-3,-2])
        bounds=replay(make_arena(row['holes'],5,8),row['target'],row['certificate'])
        for col,value in bounds.items():maxima[col]=max(maxima[col],value)
    return maxima

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');args=ap.parse_args()
    out=ROOT/'research/dense-phase2-sparse-two-entry-certificates.json.gz'
    if args.check:
        print('All saved obligations and required patterns passed:',check_saved(out));return
    start=time.monotonic();records=[];summary=[]
    for holes in patterns():
        a=make_arena(holes,messenger_radius=5,cop_radius=8)
        for target in [None]+[j for j in range(6) if j!=4 or 0 not in holes]:
            starts=[-1] if target is None else[-3,-2]
            row=solve_two_turns(a,target,starts,True)
            if not row['passed']:
                print('FAIL',holes,row['target'],row['failures'],flush=True)
                raise AssertionError('missing required entry state')
            cert=row.pop('certificate')
            assert replay(a,target,cert)==row['entry_bounds']
            records.append({'holes':holes,'target':target,'certificate':cert})
            summary.append({'holes':holes,**row})
    data={'method':'independent explicit two-turn attractor and direct rank replay',
          'M':5,'R':8,
          'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'records':records}
    with out.open('wb')as f:
        with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0)as gz:
            gz.write(json.dumps(data,separators=(',',':')).encode())
    # Re-read exactly the persisted certificates; verify against rebuilt arenas.
    readback_maxima=check_saved(out)
    maxima={col:max(row['entry_bounds'][col] for row in summary if col in row['entry_bounds'])
            for col in('-1','-3','-2')}
    assert maxima==readback_maxima
    receipt={'verified':True,'M':5,'R':8,'patterns':len(patterns()),'objectives':len(summary),
             'maximum_moves_by_entry_column':maxima,'persisted_certificate_bytes':out.stat().st_size,
             'seconds':time.monotonic()-start,'records':summary}
    (ROOT/'research/dense-phase2-sparse-two-entry-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print({k:v for k,v in receipt.items()if k!='records'})

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Bounded structurally chosen internal chord attempts for terminal modules."""
from pathlib import Path
import json,time,hashlib
from composition_interface_invariant import synth,attract
from composition_interface_free_group import arena
ROOT=Path(__file__).resolve().parents[1]

def run(ex):
 ar=arena((0,1,3),extras=ex);M,C,mi,ci,mo,co=ar
 camps=[]
 for i in range(10):
  r=mi[((),i)];mask=sum(1<<ci[M[v]] for v in mo[r] if v!=r)
  for c in range(len(C)):
   if c!=ci[((),i)] and mask&~co[c]==0:camps.append((i,C[c]))
 if camps:return {'extras':ex,'source_camps':camps}
 d=synth((0,1,3),extras=ex);d['extras']=ex
 if not d['fixed'] or d['normalization_failed']:return d
 allc=(1<<len(C))-1;IC=[(None if w is None else tuple(w),i) for w,i in d['interface_cop_states']];ii={v:i for i,v in enumerate(IC)};I=d['interface_masks'];tt=[]
 for target in range(5):
  t=mi[((),target)];W,rounds=attract(ar,[allc if r==t else 0 for r in range(len(M))],{t});bad=0
  for i in range(10):
   for c,(w,j) in enumerate(C):
    desc=(w,j) if w is not None and len(w)<=2 else (None,j)
    if I[i]>>ii[desc]&1 and not(W[mi[((),i)]]>>c&1):bad+=1
  tt.append({'target':target,'rounds':rounds,'failed':bad})
 d['terminals']=tt;return d
start=time.monotonic();rr=[]
for chord in (((7,6),(2,1)),((3,6),(8,1)),((1,6),(6,1)),((7,0),(2,5))):
 for withcycle in (False,True):
  ex=chord+(((4,0),(9,5)) if withcycle else ())
  d=run(ex);rr.append(d);print({k:v for k,v in d.items() if k not in ('trace','interface_masks','interface_cop_states')},flush=True)
  if time.monotonic()-start>20:break
 if time.monotonic()-start>20:break
out={'scope':'at most8 targeted chord designs, stopping after20 seconds between cases; no universal theorem inferred','seconds':time.monotonic()-start,'records':rr,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'research/composition-interface-terminal-chords.json').write_text(json.dumps(out,indent=2)+'\n')

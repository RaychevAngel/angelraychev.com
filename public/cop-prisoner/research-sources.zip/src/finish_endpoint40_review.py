#!/usr/bin/env python3
"""Independent-source endpoint review receipt and literal replay."""
import hashlib
import itertools
import json
from pathlib import Path
from game_solver import solve_graph
from small_case_certificate_review import review

ROOT = Path(__file__).resolve().parents[1]

def main():
    primary = [json.loads(s) for s in (ROOT/'research/endpoint40_positive.jsonl').read_text().splitlines()]
    secondary = [json.loads(s) for s in (ROOT/'research/finish-endpoint40-independent.jsonl').read_text().splitlines()]
    expected = [list(p) for p in itertools.combinations_with_replacement(range(1,8),8) if sum(p)==16]
    profiles = [r for r in primary if r['kind']=='profile']
    assert len(expected)==20 and [r['degrees'] for r in profiles]==expected
    assert all(r['complete'] and not r['found'] and not r['timeout'] for r in profiles)
    end = secondary[-1]
    assert end['complete'] and end['profiles']==20 and not end['found13']
    leaves = [r for r in secondary if r['kind']=='leaf']
    assert len(leaves)==end['leaves']==34
    checks=[]
    for leaf in leaves:
        g=solve_graph(8,leaf['arcs'],certificates=True,crosscheck=True)
        assert g['I']==leaf['I']==7
        checks.append(review(g))
    lower=json.loads((ROOT/'research/endpoint40_lower12_certificate.json').read_text())
    assert lower['n']==8 and lower['m']==40 and lower['I']==12
    checks.append(review(lower))
    paths=['src/endpoint40_positive.cpp','src/endpoint40_certify.py',
           'research/endpoint40_positive.jsonl','research/endpoint40_literal_receipt.json',
           'research/endpoint40_exact_proof.md','src/finish_endpoint40_independent.cpp',
           'research/finish-endpoint40-independent.jsonl',
           'src/finish_endpoint40_review.py','research/finish-endpoint40-review.md',
           'src/game_solver.py','src/small_case_certificate_review.py',
           'research/endpoint40_negative_certificates.json',
           'research/endpoint40_lower12_certificate.json']
    result={'verified':True,'n':8,'m':40,'exact_I':12,
            'proof_boundary':'Ordinary coverage/pruning review, two independently written complete enumerations, and literal actual-game rank checks; not Lean.',
            'degree_profiles':20,'independent_enumeration':end,
            'independent_literal_obligations':sum(x['alternating_state_obligations'] for x in checks),
            'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}}
    (ROOT/'research/finish-endpoint40-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'}))

if __name__=='__main__':main()

#!/usr/bin/env python3
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
from finish_budget_run import patterns
from small_plateau_probe import certificate
from small_case_certificate_review import review
ROOT=Path(__file__).resolve().parents[1]
n,m,threshold=map(int,sys.argv[1:4]);seconds=float(sys.argv[4]);family=patterns(n,m,threshold)
stem=f'finish-positive-max-n{n}-m{m}-from{threshold}';profile=ROOT/f'research/{stem}-patterns.json'
profile.write_text(json.dumps(dict(n=n,m=m,initial_threshold=threshold,patterns=family),indent=2)+'\n')
text=str(len(family))+'\n'+'\n'.join(' '.join(f'{d} {e}' for d,e in p) for p in family)+'\n'
source=ROOT/'src/finish_positive_maximize.cpp';h=hashlib.sha256(source.read_bytes()).hexdigest();exe=Path(tempfile.gettempdir())/f'finish_positive_max_{h[:16]}'
if not exe.exists():subprocess.run(['c++','-O3','-std=c++17',str(source),'-o',str(exe)],check=True)
p=subprocess.run([str(exe),str(n),str(m),str(threshold),str(seconds),'0'],input=text,text=True,capture_output=True,timeout=seconds+10)
assert p.returncode in (0,1),(p.returncode,p.stdout,p.stderr)
d=json.loads(p.stdout);d.update(source_file=str(source.relative_to(ROOT)),source_sha256=h,profile_file=str(profile.relative_to(ROOT)),profile_sha256=hashlib.sha256(profile.read_bytes()).hexdigest())
if d['arcs']:
 g=certificate(n,d['arcs']);assert g['I']==d['maximum_threshold_survivor'];d['literal_review']=review(g)
 output=ROOT/f'research/{stem}-certificate.json';output.write_text(json.dumps(g,indent=2)+'\n');d['certificate_file']=str(output.relative_to(ROOT))
(ROOT/f'research/{stem}.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

"""Five-lane periodic family and bounded local complement checks."""
from game_solver import solve_graph

def periodic(k):
    sigma=[0,2,4,3,1];offset=[1,-1,-1,-1,-1]
    return {(5*i+j,(5*i+j+1)%(5*k)) for i in range(k) for j in range(5)}|{(5*i+j,5*((i+offset[j])%k)+sigma[j]) for i in range(k) for j in range(5)}

def complement_two_move_failures(k):
    n=5*k;H=periodic(k);out=[set()for _ in range(n)];inn=[set()for _ in range(n)]
    for u,v in H:out[u].add(v);inn[v].add(u)
    bad=[]
    # Translation invariance: all missing pairs have source in column0.
    for s in range(5):
        for t in out[s]:
            for c in range(n):
                if c==s:continue
                # A safe intermediate is an H-outneighbor of cop c, but
                # is neither source nor target nor an H-outneighbor of s
                # nor an H-predecessor of target t.
                safe=out[c]-({s,t}|out[s]|inn[t])
                if not safe:bad.append((s,t,c))
    return bad
if __name__=='__main__':
    for k in range(4,15):print(k,complement_two_move_failures(k),flush=True)

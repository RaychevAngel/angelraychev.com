#!/usr/bin/env python3
"""Tiny rooted profiles needed for the second dense step's one-gap cases."""
from __future__ import annotations
import itertools
import json
from pathlib import Path
from small_dense_rooted import rooted_game,verify
from small_dense_rooted_exclusion import obstruction

ROOT=Path(__file__).resolve().parents[1]


def profile(degrees):
    k=len(degrees);nodes=0;leaves=[];rejected=[]
    def visit(rows):
        nonlocal nodes
        nodes+=1
        why=obstruction(rows,k)
        if why:
            rejected.append({'rows':sorted(rows.items()),'witness':why});return
        if len(rows)==k:
            complete=[list(rows[s])for s in range(k)]
            outcome=rooted_game(complete)
            leaves.append({'missing_rows':complete,'I_core':outcome['I_core']})
            return
        s=len(rows)
        for row in itertools.combinations([v for v in range(k+1)if v!=s],degrees[s]):
            visit(rows|{s:row})
    visit({})
    return {'degrees':degrees,'complete':True,'nodes':nodes,'rejected_prefixes':rejected,
            'leaves':leaves,'survivors':[x for x in leaves if x['I_core']==sum(degrees)]}


def main():
    report=[];certificates=[]
    for k in (3,4,5):
        for degrees in ([4]+[2]*(k-1),[3,3]+[2]*(k-2)):
            row=profile(degrees);report.append(row)
            print(json.dumps({'degrees':degrees,'nodes':row['nodes'],'leaves':len(row['leaves']),
                              'survivors':len(row['survivors'])}),flush=True)
            for leaf in row['leaves']:
                interface,game=verify(leaf['missing_rows'],4)
                assert interface['I_core']==leaf['I_core']
                certificates.append({'degrees':degrees,'missing_rows':leaf['missing_rows'],'interface':interface,'full_game':game})
    extra=json.loads((ROOT/'research/small-dense-r23-six-enumeration.json').read_text())
    for case in extra['cases']:
        for rows in case['complete_rows']:
            interface,game=verify(rows,3)
            certificates.append({'degrees':[len(r)for r in rows],'missing_rows':rows,'interface':interface,'full_game':game})
    (ROOT/'research/small-dense-r2-rooted-profiles.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
    (ROOT/'research/small-dense-r2-profile-certificates.json').write_text(json.dumps(certificates,separators=(',',':'))+'\n')


if __name__=='__main__':main()

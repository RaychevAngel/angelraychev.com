#!/usr/bin/env python3
"""Prepare grouped certificates for literal five-type recipes; no graph search.
The output is staged proof input, not a Lean acceptance receipt.
"""
from pathlib import Path
from collections import defaultdict
import argparse,json,hashlib,sys,time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from export_main_grouped_pilot import validate,tree


def graph(n,full=True):
    assert n%5==0
    k=n//5;base=set();optional=set()
    for s in range(n):
        i,j=divmod(s,5)
        base.add((s,(s+1)%n))
        base.add((s,5*((i+(1 if j==0 else -1))%k)+[0,2,4,3,1][j]))
        if full:optional.add((s,5*((i+3)%k)))
        elif j==0:optional.add((s,5*((i-1)%k)+4))
    assert len(base)==2*n and not base&optional
    assert all(s!=t for s,t in base|optional)
    return sorted(base),sorted(base|optional)


def strategy(n,target,base,upper):
    lower=[[r]+[t for s,t in base if s==r]for r in range(n)]
    replies=[sum(1<<d for d in set([c]+[t for s,t in upper if s==c]))for c in range(n)]
    allbits=(1<<n)-1;winning=[0]*n;winning[target]=allbits
    groups=[defaultdict(list)for _ in range(n)];rounds=0
    while True:
        rounds+=1
        safe=[sum(1<<c for c in range(n) if c!=z and not(replies[c]&~winning[z]))for z in range(n)]
        nextwins=winning[:];changed=False
        for r in range(n):
            if r==target:continue
            for z in lower[r]:
                eligible=allbits if z==target else safe[z]
                fresh=eligible&~nextwins[r]&~(1<<r)
                nextwins[r]|=fresh
                while fresh:
                    bit=fresh&-fresh;fresh-=bit;c=bit.bit_length()-1
                    groups[r][rounds,z].append(c);changed=True
        winning=nextwins
        if not changed:break
    for r in range(n):assert r==target or winning[r]==(allbits&~(1<<r)),(n,target,r)
    for row in groups:
        for cops in row.values():cops.sort()
    case=dict(n=n,target=target,base=base,upper=upper)
    stats=validate(case,groups)
    return groups,stats


def base_source(n,base,upper):
    name=f'FiveFinite{n}Base'
    def rowtext(edges):return tree(['['+','.join(str(t)for s,t in edges if s==r)+']'for r in range(n)])
    return name,f'''import GroupedGraphRanks
import EnvelopeRowSymmetry
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open FiniteGame Extremal GroupedArena
/- Literal five-type recipe; local window geometry is not assumed here. -/
def lowerRow (x : Nat) : List (Fin {n}) := {rowtext(base)}
def upperRow (x : Nat) : List (Fin {n}) := {rowtext(upper)}
def lowerRows (s : Fin {n}) := lowerRow s.val
def upperRows (s : Fin {n}) := upperRow s.val
def lower := EnvelopeRowSymmetry.edge lowerRows
def upper := EnvelopeRowSymmetry.edge upperRows
instance (s t : Fin {n}) : Decidable (lower s t) := inferInstanceAs (Decidable (t∈lowerRows s))
instance (s t : Fin {n}) : Decidable (upper s t) := inferInstanceAs (Decidable (t∈upperRows s))
def replyMasks (c : Fin {n}) : Nat := maskOf (c::upperRows c)
theorem reply_coverage : ∀ c d, Legal upper c d → Has (replyMasks c) d := by
  intro c d legal
  apply (has_maskOf _ _).mpr
  rcases legal with same|edge
  · exact List.mem_cons.mpr (Or.inl same.symm)
  · exact List.mem_cons.mpr (Or.inr edge)
theorem inclusion : RobustTwoMove.Subgraph lower upper := by
  unfold RobustTwoMove.Subgraph; decide +kernel
theorem loopless : Loopless upper := by unfold Loopless; decide +kernel
theorem counts : arcCount lower={len(base)} ∧ arcCount upper={len(upper)} := by
  constructor <;> rw [arcCount_eq] <;> decide +kernel

def rotate (t x : Fin {n}) : Fin {n} := ⟨(x.val+5*(t.val/5))%{n},Nat.mod_lt _ (by decide)⟩
def unrotate (t x : Fin {n}) : Fin {n} := ⟨(x.val+{n}-5*(t.val/5))%{n},Nat.mod_lt _ (by decide)⟩
theorem inverses : ∀t x, unrotate t (rotate t x)=x ∧ rotate t (unrotate t x)=x := by decide +kernel
theorem lower_forward : ∀t s, (lowerRows s).all (fun d => decide (rotate t d∈lowerRows (rotate t s)))=true := by decide +kernel
theorem lower_backward : ∀t s, (lowerRows (rotate t s)).all (fun d => decide (unrotate t d∈lowerRows s))=true := by decide +kernel
theorem upper_forward : ∀t s, (upperRows s).all (fun d => decide (rotate t d∈upperRows (rotate t s)))=true := by decide +kernel
theorem upper_backward : ∀t s, (upperRows (rotate t s)).all (fun d => decide (unrotate t d∈upperRows s))=true := by decide +kernel
noncomputable def rotation (t : Fin {n}) : GraphRelabeling.Iso lower lower :=
  EnvelopeRowSymmetry.iso_of_rows lowerRows (rotate t) (unrotate t)
    (fun x => (inverses t x).1) (fun x => (inverses t x).2)
    (fun s d member => of_decide_eq_true ((List.all_eq_true.mp (lower_forward t s)) d member))
    (fun s d member => of_decide_eq_true ((List.all_eq_true.mp (lower_backward t s)) d member))
theorem upper_invariant (t : Fin {n}) : ∀s d,upper s d ↔ upper ((rotation t).toFun s) ((rotation t).toFun d) := by
  exact EnvelopeRowSymmetry.invariant_of_rows upperRows (rotate t) (unrotate t)
    (fun x => (inverses t x).1)
    (fun s d member => of_decide_eq_true ((List.all_eq_true.mp (upper_forward t s)) d member))
    (fun s d member => of_decide_eq_true ((List.all_eq_true.mp (upper_backward t s)) d member))
def representative (t : Fin {n}) : Fin {n} := ⟨t.val%5,by omega⟩
theorem representative_small (t : Fin {n}) : (representative t).val<5 := Nat.mod_lt _ (by decide)
theorem target_cover : ∀t,rotate t (representative t)=t := by decide +kernel
#print axioms counts
#print axioms upper_invariant
end Delivery.{name}
'''


def objective_source(n,target,groups):
    name=f'FiveFinite{n}Target{target}';base=f'FiveFinite{n}Base';rows=[]
    for row in groups:
        terms=[]
        for (rank,move),cops in sorted(row.items()):
            terms.append('{rank:='+str(rank)+',move:='+str(move)+',cops:=['+','.join(map(str,cops))+'],mask:='+str(sum(1<<c for c in cops))+'}')
        rows.append('['+','.join(terms)+']')
    return name,f'''import {base}
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Delivery.{name}
open FiniteGame Extremal GroupedArena GroupedGraphRanks {base}
noncomputable def groupRows (x : Nat) : List (Group {n} {n}) := {tree(rows)}
noncomputable def rows (r : Fin {n}) : List (Group {n} {n}) := groupRows r.val
theorem groups_checked : GroupedArena.Checked true (arena lower upper) (fun r => r={target})
    replyMasks collisionMasks rows := by
  unfold GroupedArena.Checked; decide +kernel
theorem entry_subset : ∀ s : Fin {n}, s≠{target} → ¬lower s {target} →
    initialMask s &&& activeMask (rows s)=initialMask s := by decide +kernel
theorem winning {{G : Graph (Fin {n})}}
    (low : RobustTwoMove.Subgraph lower G) (high : RobustTwoMove.Subgraph G upper)
    (r c : Fin {n}) (inside : Active (rows r) c) :
    Winning G {target} ((GroupedArena.data rows).rank r c) r c := by
  exact LocalArena.delivery_projection (simulation low high)
    (GroupedArena.delivery_checked (arena lower upper) (fun r => r={target})
      replyMasks collisionMasks rows reply_coverage (collision_covered lower upper) groups_checked)
    (fun _ same => same) r c inside
theorem guaranteed {{G : Graph (Fin {n})}}
    (low : RobustTwoMove.Subgraph lower G) (high : RobustTwoMove.Subgraph G upper)
    (s : Fin {n}) : Guaranteed G s {target} := by
  intro c initial
  by_cases terminal : s={target}
  · subst s; exact ⟨0,Winning.delivered⟩
  by_cases direct : lower s {target}
  · exact ⟨1,Winning.finish (Ne.symm initial) (Or.inr (low s {target} direct))⟩
  have active := (has_activeMask (rows s) c).mp
    (has_subset (entry_subset s terminal direct) ((has_initialMask s c).mpr initial))
  exact ⟨_,winning low high s c active⟩
#print axioms winning
#print axioms guaranteed
end Delivery.{name}
'''


def aggregate_source(n,low,high):
    name=f'FiveFinite{n}'
    imports='\n'.join(f'import FiveFinite{n}Target{t}'for t in range(5))
    cases='\n'.join(f'  · exact FiveFinite{n}Target{t}.guaranteed low high s'for t in range(5))
    return name,f'''{imports}
namespace Delivery.{name}
open FiniteGame Extremal FiveFinite{n}Base

theorem representatives (t : Fin {n}) (small : t.val<5) (G : Graph (Fin {n}))
    (low : RobustTwoMove.Subgraph lower G) (high : RobustTwoMove.Subgraph G upper)
    (s : Fin {n}) : Guaranteed G s t := by
  have cases : t=0 ∨ t=1 ∨ t=2 ∨ t=3 ∨ t=4 := by
    have values : t.val=0 ∨ t.val=1 ∨ t.val=2 ∨ t.val=3 ∨ t.val=4 := by omega
    rcases values with h|h|h|h|h
    · exact Or.inl (Fin.ext h)
    · exact Or.inr (Or.inl (Fin.ext h))
    · exact Or.inr (Or.inr (Or.inl (Fin.ext h)))
    · exact Or.inr (Or.inr (Or.inr (Or.inl (Fin.ext h))))
    · exact Or.inr (Or.inr (Or.inr (Or.inr (Fin.ext h))))
  rcases cases with rfl|rfl|rfl|rfl|rfl
{cases}
theorem delivers : GuaranteedPrefix.Delivers lower upper := by
  apply EnvelopeSymmetry.delivers lower upper (fun t => t.val<5) representatives
  intro t
  exact ⟨representative t,representative_small t,rotation t,upper_invariant t,target_cover t⟩
theorem maximum {{m : Nat}} (low : {low}≤m) (high : m≤{high}) :
    IsMaximum {n} m ({n}*({n}-1)-m) :=
  GuaranteedPrefix.maximum lower upper inclusion loopless delivers
    (by rw [counts.1];exact low) (by rw [counts.2];exact high)
#print axioms delivers
#print axioms maximum
end Delivery.{name}
'''


def main():
    p=argparse.ArgumentParser();p.add_argument('--orders',nargs='+',type=int,default=[65,70,75]);p.add_argument('--short',action='store_true');p.add_argument('--out',type=Path,default=ROOT/'tmp/lean-five-type-finite-main');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    started=time.monotonic();records=[];files={}
    for n in a.orders:
        base,upper=graph(n,not a.short);record=dict(n=n,low=len(base),high=len(upper),base=base,upper=upper,targets=[])
        pieces=[base_source(n,base,upper)]
        for target in range(5):
            groups,stats=strategy(n,target,base,upper);record['targets'].append(dict(target=target,**stats));pieces.append(objective_source(n,target,groups))
        pieces.append(aggregate_source(n,len(base),len(upper)))
        for name,source in pieces:
            q=a.out/(name+'.lean');q.write_text(source);files[q.name]=hashlib.sha256(q.read_bytes()).hexdigest()
        records.append(record)
    manifest=dict(scope='Staged deterministic certificates of prescribed five-type recipes; independently validated in producer, not yet Lean replayed.',generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),shared_adapter_sha256=hashlib.sha256((ROOT/'src/export_main_grouped_pilot.py').read_bytes()).hexdigest(),seconds=time.monotonic()-started,records=records,files=files)
    (a.out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'seconds':manifest['seconds'],'modules':len(files),'orders':a.orders,'groups':sum(t['groups']for r in records for t in r['targets']),'retained_states':sum(t['retained_states']for r in records for t in r['targets'])}))
if __name__=='__main__':main()

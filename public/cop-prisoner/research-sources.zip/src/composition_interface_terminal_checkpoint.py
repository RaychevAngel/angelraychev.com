#!/usr/bin/env python3
"""Certify the common twelve-exception interface and eight terminal types.
Finite layers are directly replayed. Independent branch-projection/rank audit
is still required before promoting the eight-type finite-quotient statement.
"""
import gzip,json,time,hashlib
from pathlib import Path
from composition_interface_free_group import arena as ordinary_arena
from composition_interface_branch_terminal import arena as branch_arena
from composition_interface_invariant import attract,mul,inv
from composition_interface_certify import FORBIDDEN
ROOT=Path(__file__).resolve().parents[1]
F=FORBIDDEN|{(3,(),5),(3,(-2,),5),(3,(-2,),9),(8,(),0),(8,(-1,),0),(8,(-1,),4)}
def good(i,w,j):return not(w==() and i==j) and (i,w,j) not in F

def certify(ar,seeds,receipt,required):
 M,C,mi,ci,mo,co=ar;W,depth,layers=attract(ar,seeds,receipt,retain=True)
 assert all(W[r]>>c&1 for r,c in required)
 checked=0
 for d in range(1,len(layers)):
  prev,nxt=layers[d-1],layers[d]
  assert all(a&~b==0 for a,b in zip(prev,nxt))
  for r in range(len(M)):
   new=nxt[r]&~prev[r]
   while new:
    bit=new&-new;c=bit.bit_length()-1;new-=bit
    assert M[r]!=C[c]
    legal=False
    for v in mo[r]:
     if v in receipt:legal=True;break
     if M[v]!=C[c] and not(co[c]&~prev[v]):legal=True;break
    assert legal,(d,M[r],C[c]);checked+=1
 return {'moves':depth,'required_starts':len(required),'new_states_directly_checked':checked,'layers':[[hex(x) for x in layer] for layer in layers]},W

def encode_arena(ar):
 M,C,mi,ci,mo,co=ar
 return {'messenger_positions':M,'cop_positions':C,'messenger_moves':mo,'cop_masks':[hex(x) for x in co]}

def main():
 start=time.monotonic();records=[];arenas={}
 ar=ordinary_arena((0,1,3));M,C,mi,ci,mo,co=ar;arenas['ordinary2']=encode_arena(ar)
 req=[(mi[(),i],c) for i in range(10) for c,(cw,j) in enumerate(C) if good(i,cw,j)]
 for g in (-1,-2):
  seeds=[sum(1<<c for c,(cw,j) in enumerate(C) if good(i,None if cw is None else mul(inv(w),cw),j)) if w==(g,) else 0 for w,i in M]
  d,W=certify(ar,seeds,set(),req);assert d['moves']==32
  d.update(name=f'navigation_{g}',arena='ordinary2',goal_word=(g,),kind='safe interface');records.append(d)
 seeds=[sum(1<<c for c,(cw,j) in enumerate(C) if good(i,None if cw is None else mul(inv(w),cw),j)) for w,i in M]
 reqall=[(mi[(),i],c) for i in range(10) for c in range(len(C)) if C[c]!=((),i)]
 d,W=certify(ar,seeds,set(),reqall);assert d['moves']==2
 d.update(name='normalization',arena='ordinary2',kind='safe interface');records.append(d)
 for typ,word,mrad,branches in ((0,(1,),2,0),(1,(-1,),3,2),(3,(-1,-1),3,0),(4,(-1,),3,2)):
  ar=branch_arena(mrad,3,branches) if branches else ordinary_arena((0,1,3),mrad,3)
  name=f'branch{branches}_m{mrad}';arenas[name]=encode_arena(ar);M,C,mi,ci,mo,co=ar;allc=(1<<len(C))-1;tr=mi[word,typ]
  req=[(mi[(),i],c) for i in range(10) for c,(cw,j) in enumerate(C) if good(i,cw,j)]
  seeds=[allc if r==tr else 0 for r in range(len(M))];d,W=certify(ar,seeds,{tr},req)
  d.update(name=f'terminal_{typ}',arena=name,kind='terminal receipt',target_type=typ,target_word=word,branch_prefix_depth=branches)
  records.append(d);print({k:v for k,v in d.items() if k!='layers'},flush=True)
 archive={'scope':'finite certificates for common interface and eight target types; branch finite-quotient projection not independently audited','forbidden':sorted(F),'arenas':arenas,'records':records}
 path=ROOT/'research/composition-interface-terminal-checkpoint-certificates.json.gz'
 with gzip.open(path,'wt') as f:json.dump(archive,f,separators=(',',':'))
 receipt={'scope':archive['scope'],'seconds':time.monotonic()-start,'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'archive_bytes':path.stat().st_size,'records':[{k:v for k,v in d.items() if k!='layers'} for d in records],'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),ROOT/'src/composition_interface_free_group.py',ROOT/'src/composition_interface_branch_terminal.py',ROOT/'src/composition_interface_invariant.py')}}
 (ROOT/'research/composition-interface-terminal-checkpoint-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print('saved',receipt['archive_bytes'],'bytes',receipt['seconds'],'seconds')
if __name__=='__main__':main()

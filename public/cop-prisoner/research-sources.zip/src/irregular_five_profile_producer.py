#!/usr/bin/env python3
"""Bounded untrusted complete positive-degree order-five profile certificates.

The actual source/sink reduction and profile coverage are proved in Lean.
No historical receipt or solver score is an assumption of the resulting proof.
"""
from pathlib import Path
import argparse
import hashlib
import json
import time
import small_budget_extended_profile_producer as producer

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=float, default=60)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not 0 < args.seconds <= 60:
        raise ValueError("complete production is capped at sixty seconds")
    if args.output.exists():
        raise ValueError("preserve existing certificate data")
    start = time.monotonic()
    budgets = []
    for budget in range(9, 15):
        bound = 3 if budget <= 11 else 2
        cases = []
        inventory = producer.profiles(5, 5, 0, budget, budget, False)
        for labels in inventory:
            producer.bind(5, labels, budget, bound)
            d, r = producer.core.D, producer.core.R
            eligible = sum(d[s] >= 2 and r[t] >= 2 and s != t
                           for s in range(5) for t in range(5))
            static = eligible + sum(x for x in d if x < 2) + sum(x for x in r if x < 2)
            if eligible <= bound or static <= budget + bound:
                continue
            remaining = args.seconds - (time.monotonic() - start)
            if remaining <= 0:
                raise TimeoutError("whole order-five catalogue time cap")
            result = producer.core.produce(remaining)
            cases.append(dict(n=5, labels=labels, outdegrees=d, indegrees=r,
                              counts=result["counts"], nodes=result["nodes"]))
        budgets.append(dict(arrows=budget, bound=bound, zero_two=False,
                            profile_count=len(inventory), cases=cases))
    paths = ["src/irregular_five_profile_producer.py",
             "src/small_budget_extended_profile_producer.py",
             "src/small_budget_five_seven_producer.py"]
    result = dict(
        scope="Untrusted full positive-degree profile tree data; Lean must check all profile, row, symmetry, and loss coverage.",
        n=5, source_sha256={p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths},
        seconds=time.monotonic() - start, budgets=budgets)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    print(json.dumps(dict(seconds=result["seconds"], budgets=[dict(
        arrows=b["arrows"], profiles=b["profile_count"], hard_profiles=len(b["cases"]),
        nodes=sum(c["counts"]["nodes"] for c in b["cases"])) for b in budgets])))


if __name__ == "__main__":
    main()

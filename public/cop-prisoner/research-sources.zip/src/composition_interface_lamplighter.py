#!/usr/bin/env python3
"""Directed logarithmic-diameter lamplighter candidates, finite tests."""
from pathlib import Path
import json,hashlib,time
from composition_interface_lifts import test
ROOT=Path(__file__).resolve().parents[1]

def graph(k,q,gstep,hstep):
 size=q**k;arcs=[]
 for c in range(k):
  for lamps in range(size):
   digit=(lamps//q**c)%q;toggle=lamps+q**c*(1 if digit<q-1 else 1-q)
   arcs += [(c*size+lamps,((c+gstep)%k)*size+lamps),
            (c*size+lamps,((c+hstep)%k)*size+toggle)]
 return k*size,arcs
start=time.monotonic();records=[]
for k,q,g,h in ((3,3,1,-1),(4,3,1,-1),(3,2,1,-1),(4,2,1,-1),(3,5,1,-1)):
 d=test(*graph(k,q,g,h),targets=[0],dual=k*q**k<=100)
 d.update(k=k,q=q,gstep=g,hstep=h);records.append(d)
 print({x:y for x,y in d.items() if x not in ('arcs','source_camps','checked_targets')},flush=True)
out={'scope':'target0 finite candidate checks, not a universal theorem','seconds':time.monotonic()-start,'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'research/composition-interface-lamplighter.json').write_text(json.dumps(out,indent=2)+'\n')

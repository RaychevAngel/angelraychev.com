#!/usr/bin/env python3
"""Untrusted sharp regular-nine prefix DAG producer with explicit relabelings.

Every valid second-factor row branches. Automorphisms of the fixed first
factor only share proofs; Lean checks the actual conjugacies and prefix maps.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import time
from pathlib import Path
from lean_finite_regular_producer import primary, PARTITIONS
from lean_finite_bound_tree_producer import local_data, packed
from lean_finite_prefix_probe import optimistic
from lean_finite_threshold_prototype import eligible

ROOT = Path(__file__).resolve().parents[1]
N = 9
ALL = 511

def automorphisms(parts):
    blocks=[]
    for k in parts:
        s=sum(map(len,blocks)); blocks.append(list(range(s,s+k)))
    result=[]
    def walk(i,used,f):
        if i==len(blocks):
            g=[f.index(v) for v in range(N)]
            result.append((tuple(f),tuple(g))); return
        for j,other in enumerate(blocks):
            if j in used or len(other)!=len(blocks[i]): continue
            for offset in range(len(other)):
                nxt=list(f)
                for x,v in enumerate(blocks[i]): nxt[v]=other[(x+offset)%len(other)]
                walk(i+1,used|{j},nxt)
    walk(0,set(),[0]*N)
    return sorted(result)

def produce(parts,seconds,node_limit,out):
    started=time.monotonic(); a=primary(parts); autos=automorphisms(parts)
    stable={k:[j for j,(f,g) in enumerate(autos) if all(f[v]<k for v in range(k))]
            for k in range(N+1)}
    identity=next(i for i,(f,g) in enumerate(autos) if list(f)==list(range(N)))
    cache={}; nodes=[]
    counts=dict(nodes=0,branches=0,local=0,robust=0,masks=0,shared=0)
    def valid(p):
        return len(set(p))==len(p) and all(v!=i and v!=a[i] for i,v in enumerate(p))
    def canonical(p):
        best=tuple(p); choice=identity
        for j in stable[len(p)]:
            f,g=autos[j]; q=tuple(f[p[g[i]]] for i in range(len(p)))
            if q<best: best=q; choice=j
        return best,choice
    def visit(raw):
        p,trans=canonical(raw)
        if p in cache:
            counts['shared']+=1; return cache[p],trans
        counts['nodes']+=1
        if counts['nodes']>node_limit or time.monotonic()-started>seconds:
            raise TimeoutError('bounded producer cap')
        local=eligible(a,p)
        if sum(x.bit_count() for x in local)<=30:
            sources,recipients,_=local_data(a,p)
            node=dict(kind='camp',allowed=packed(local),sources=sources,recipients=recipients)
            counts['local']+=1
        else:
            upper,masks=optimistic(a,p) if len(p)>=4 else (55,[])
            if upper<=30:
                sources,recipients,low=local_data(a,p); remain=list(local); chosen=[]
                def gain(tm):
                    t,mask=tm
                    return sum(bool(remain[s]>>t&1) and bool(((mask>>(9*s))&ALL)&~(1<<s)) for s in range(N))
                while sum(v.bit_count() for v in remain)>30:
                    tm=max(masks,key=gain); masks.remove(tm); chosen.append(tm); t,mask=tm
                    for s in range(N):
                        if ((mask>>(9*s))&ALL)&~(1<<s): remain[s]&=~(1<<t)
                used=sum(1<<v for v in p)
                high=[low[r] if r<len(p) else low[r]|(ALL&~(used|(1<<r)|(1<<a[r]))) for r in range(N)]
                losses=[]
                for t,mask in chosen:
                    good=[sum(1<<z for z in range(N) if z!=t and
                              (z==c or low[c]&((1<<z)|((mask>>(9*z))&ALL)))) for c in range(N)]
                    losses.append((t,mask,packed(good)))
                node=dict(kind='leaf',allowed=packed(remain),sources=sources,recipients=recipients,
                          upper=packed(high),lower=packed(low),losses=losses)
                counts['robust']+=1; counts['masks']+=len(losses)
            else:
                assert len(p)<N, ('threshold violation',p,upper)
                children={v:visit(p+(v,)) for v in range(N) if valid(p+(v,))}
                node=dict(kind='branch',children=children); counts['branches']+=1
        idx=len(nodes); node.update(prefix=list(p),id=idx); nodes.append(node); cache[p]=idx
        return idx,trans
    root,trans=visit(())
    assert trans==identity and root==len(nodes)-1
    data=dict(schema=1,partition=parts,a=a,automorphisms=autos,identity=identity,
              nodes=nodes,root=root,counts=counts,seconds=time.monotonic()-started,
              producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              boundary='Untrusted proof data. All choices, conjugacies, losses, and counts require Lean replay.')
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(data,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in data.items() if k not in ('nodes','automorphisms')}),flush=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--partition',default='2,2,2,3')
    ap.add_argument('--seconds',type=float,default=60); ap.add_argument('--node-limit',type=int,default=60000)
    ap.add_argument('--output',type=Path,required=True); args=ap.parse_args()
    parts=tuple(map(int,args.partition.split(','))); assert parts in PARTITIONS
    produce(parts,args.seconds,args.node_limit,args.output)

if __name__=='__main__': main()

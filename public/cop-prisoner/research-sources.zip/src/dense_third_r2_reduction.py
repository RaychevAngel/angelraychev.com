#!/usr/bin/env python3
"""Read existing finite premises for the ordinary second-step reduction."""
import argparse,hashlib,json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true')
    args=parser.parse_args();premises=[]
    for k,m,want,n,bound in [(5,10,3,7,9),(6,18,6,8,11)]:
        path=ROOT/f'research/solver-enumeration-n{k}.json'
        data=json.loads(path.read_text())
        row=next(z for z in data['by_m'] if z['m']==m)
        assert row['maximum_I']==want
        assert max(want,2*n-5)==bound
        premises.append({'core_n':k,'core_m':m,'core_exact_I':want,
                         'n':n,'m':n*(n-3)+2,'upper':bound,
                         'finite_table':str(path.relative_to(ROOT)),
                         'finite_table_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    result={'status':'verified existing numerical premises',
            'proof_boundary':'The ordinary equality reduction is in paper/dense-third.md. This readback does not rerun or strengthen the existing exhaustive finite table proof.',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'premises':premises}
    path=ROOT/'research/dense-third-r2-reduction-checks.json'
    text=json.dumps(result,indent=2)+'\n'
    if args.check:assert path.read_text()==text
    else:path.write_text(text)
    print(json.dumps({'upper_improvements':len(premises)}))


if __name__=='__main__':main()

#!/usr/bin/env python3
"""Complete leaf replay using the root-authored independent alternating solver.

Graph traversal is retained; this is not a second graph enumeration. Guarded
loss assertions are sampled and reported separately. Every reached full graph
is solved completely without the producer's target-column early exit.
"""
import hashlib,json,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def replace_function(source,name,replacement):
    begin=source.index(name+'{')
    brace=source.index('{',begin);depth=1;end=brace+1
    while depth:
        if source[end]=='{':depth+=1
        if source[end]=='}':depth-=1
        end+=1
    return source[:begin]+replacement+source[end:]


def variant(source):
    helper=(ROOT/'src/finish_alternating_review.hpp').read_text()
    extra=r'''
long long audit_calls=0,audit_samples=0,audit_pairs=0;
int audit_maximum=-1;
void audit_guard(const int* optimistic,const int* bad){
 ++audit_calls;if(audit_calls>10&&audit_calls%100003!=0)return;
 ++audit_samples;
 for(int t=0;t<n;t++){
  bool needed=false;for(int s=0;s<n;s++)if(bad[s]>>t&1)needed=true;
  if(!needed)continue;
  auto wins=independent_wins(optimistic,O,t);
  for(int s=0;s<n;s++)if(bad[s]>>t&1){
   ++audit_pairs;if((wins[s]|1<<s)==all)abort();
  }
 }
}
int audited_game(){
 int score=0;
 for(int t=0;t<n;t++){
  auto wins=independent_wins(O,O,t);
  for(int s=0;s<n;s++)if(s!=t&&!(O[s]>>t&1)&&(wins[s]|1<<s)==all)score++;
 }
 audit_maximum=max(audit_maximum,score);
 if(score<=threshold){++early_game_rejects;return -1;}return score;
}
'''
    point=source.index('bool camping(')
    source=source[:point]+helper+extra+source[point:]
    source=replace_function(source,'int game()','int game(){return audited_game();}')
    for condition in ('eligible_upper()-losses<=threshold','eligible_upper()-losses<=threshold||!zero_deletion_possible(bad)'):
        old='if('+condition+')return false;'
        if old in source:source=source.replace(old,'if('+condition+'){audit_guard(optimistic,bad);return false;}')
    source=source.replace('return complete?0:1;','cerr<<"AUDIT "<<audit_maximum<<" "<<audit_samples<<" "<<audit_pairs<<"\\n";return complete?0:1;')
    return source

def main():
    runs=[]
    reports=sorted((ROOT/'research').glob('finish_budget_positive_n*_m*_above*.json'))
    reports=[p for p in reports if json.loads(p.read_text())['m'] in (14,15,16)]
    prior_path=ROOT/'research/finish_budget_leaf_review.json'
    prior=json.loads(prior_path.read_text()).get('runs',[]) if prior_path.exists() else []
    with tempfile.TemporaryDirectory(prefix='finish_budget_leaf_review_') as tmp:
        temp=Path(tmp);executables={}
        for path in reports:
            original=json.loads(path.read_text())
            assert original['complete'] and not original['counterexample_found'],path
            source=ROOT/original['source_file'];assert digest(source)==original['source_sha256']
            if str(source) not in executables:
                changed=variant(source.read_text());target=temp/(source.stem+'.cpp');exe=temp/source.stem
                target.write_text(changed);subprocess.run(['c++','-O3','-std=c++17',str(target),'-o',str(exe)],check=True)
                executables[str(source)]=(exe,digest(target))
            exe,variant_hash=executables[str(source)]
            profiles=ROOT/original['profile_file'];assert digest(profiles)==original['profile_sha256']
            reusable=next((r for r in prior if r.get('primary_sha256')==digest(path)
                           and r.get('source_sha256')==digest(source)
                           and r.get('profile_sha256')==digest(profiles)
                           and r.get('variant_sha256')==variant_hash
                           and r.get('complete') and not r.get('counterexample_found')),None)
            if reusable is not None:
                runs.append(reusable)
                print(json.dumps(dict(reused_identical_replay=str(path.relative_to(ROOT)))),flush=True)
                continue
            patterns=json.loads(profiles.read_text())['patterns']
            data=str(len(patterns))+'\n'+'\n'.join(' '.join(str(v) for pair in row for v in pair) for row in patterns)+'\n'
            args=[str(exe),str(original['n']),str(original['m']),str(original['threshold']),'120',str(original['mode'])]
            proc=subprocess.run(args,input=data,text=True,capture_output=True,timeout=130)
            assert proc.returncode==0,(path,proc.stdout,proc.stderr)
            fresh=json.loads(proc.stdout);assert fresh['complete'] and not fresh['counterexample_found']
            for field in ('nodes','degree_patterns','total_degree_patterns','game_decisions','camping_rejects','guarded_checks','guarded_rejects'):
                assert fresh[field]==original[field],(path,field)
            audit=proc.stderr.strip().split();assert len(audit)==4 and audit[0]=='AUDIT',proc.stderr
            fresh.update(independent_maximum=int(audit[1]),guarded_samples=int(audit[2]),sampled_loss_pairs=int(audit[3]),
                source_file=original['source_file'],source_sha256=digest(source),variant_sha256=variant_hash,
                primary_file=str(path.relative_to(ROOT)),primary_sha256=digest(path),profile_file=original['profile_file'],profile_sha256=digest(profiles))
            runs.append(fresh)
            print(json.dumps({k:fresh[k] for k in ('n','m','mode','game_decisions','seconds','independent_maximum','guarded_samples')}),flush=True)
    result=dict(verified=True,reviewer_source_sha256=digest(Path(__file__)),alternating_source_sha256=digest(ROOT/'src/finish_alternating_review.hpp'),
                runs=runs,all_leaf_games=sum(r['game_decisions'] for r in runs),
                scope='Complete independent alternating-game replay of every reached leaf, retaining source-reviewed enumeration and pruning; sampled guarded losses are explicitly counted.')
    (ROOT/'research/finish_budget_leaf_review.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()

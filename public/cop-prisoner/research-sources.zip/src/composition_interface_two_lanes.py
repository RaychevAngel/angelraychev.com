#!/usr/bin/env python3
"""Two degree-two highways with degree-preserving cross-lane swaps."""
from pathlib import Path
import itertools,json,time,hashlib
from composition_interface_lifts import test
ROOT=Path(__file__).resolve().parents[1]

def graph(q,perms,swaps):
 ell=10;arcs=[];beta=[0,2,4,3,1];shifts=[1,-1,-1,-1,-1]
 inv=[]
 for p in perms:
  pp=[0]*q
  for i,j in enumerate(p):pp[j]=i
  inv.append(pp)
 for x in range(q):
  for lane in range(2):
   for j in range(5):
    s=ell*x+5*lane+j
    aa=ell*x+5*(lane^(j in swaps))+j+1 if j<4 else ell*perms[lane][x]+5*lane
    yy=perms[lane][x] if shifts[j]>0 else inv[lane][x]
    arcs += [(s,aa),(s,ell*yy+5*lane+beta[j])]
 return ell*q,arcs

start=time.monotonic();records=[]
for size in (1,2,3,4):
 for swaps in itertools.combinations(range(4),size):
  d=test(*graph(5,[[1,2,3,4,0],[2,3,4,0,1]],swaps),targets=range(10))
  d.update(swaps=swaps,quotient=5,scope='all types at column0; other columns via translations')
  records.append(d)
  print(swaps,d['universal'],d['max_moves'],d.get('failed_target'),flush=True)
  if d['universal']:
   p=list(range(1,11))+[0];r=[5,7,10,6,8,1,4,9,2,0,3]
   e=test(*graph(11,[p,r],swaps))
   e.update(swaps=swaps,quotient=11,quotient_permutations=[p,r]);records.append(e)
   print('noncircular',e['universal'],e['max_moves'],e.get('failed_target'),flush=True)
artifact={'seconds':time.monotonic()-start,'scope':'bounded two-lane composition screen, no parametric result','records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'research/composition-interface-two-lanes.json').write_text(json.dumps(artifact,indent=2)+'\n')

#!/usr/bin/env python3
"""Untrusted literals for the complete eleven-profile row-prefix DAG.
Every raw row is covered; sharing uses a separately checked vertex bijection.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from irregular_ten_export import natlist,rows,route
ROOT=Path(__file__).resolve().parents[1]

def perm(f):
    if f==list(range(9)):return 'id'
    return '(fun i => match i.val with '+' '.join(f'| {i} => {v}' for i,v in enumerate(f[:-1]))+f' | _ => {f[-1]})'

def certificate(cert, pair_list=False):
    losses=['{ target := '+str(x['target'])+', region := '+rows(x['region'])+', good := '+rows(x['good'])+' }' for x in cert['losses']]
    camps=['{ cop := '+str(x['cop'])+', region := '+str(x['region'])+', targets := '+str(x['targets'])+' }' for x in cert['camps']]
    pairs=[(s,t) for s,bits in enumerate(cert['lost']) for t in range(9) if bits>>t&1]
    lossfield=('pairs := ['+','.join(f'({s},{t})' for s,t in pairs)+']') if pair_list else ('lost := '+rows(cert['lost']))
    return '{ available := '+str(cert['available'])+', camps := ['+','.join(camps)+'], '+lossfield+', upper := '+rows(cert['upper'])+', lower := '+rows(cert['lower'])+', losses := ['+','.join(losses)+'] }'

def rejected_columns(data,p):
    from irregular_nine_producer import CHOICES,N
    bad=[]
    for mask in CHOICES[data['outdegrees'][len(p)]]:
        if mask>>len(p)&1:continue
        q=p+[mask];k=len(q)
        for t in range(N):
            used=sum(row>>t&1 for row in q)
            if not used<=data['indegrees'][t]<=used+N-k-int(t>=k):
                if t:bad.append((mask,t))
                break
    return '(fun mask => match mask with '+' '.join(f'| {m} => {t}' for m,t in bad)+' | _ => 0)' if bad else '(fun _ => 0)'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--chunk',type=int,default=60);ap.add_argument('--pair-list',action='store_true')
    ap.add_argument('--output',type=Path,default=ROOT/'tmp/lean-irregular-nine/stage');a=ap.parse_args()
    data=json.loads(a.input.read_text());profile=data['profile_id'];assert data['n']==9 and data['bound']==13
    nodes=sorted(data['nodes'].values(),key=lambda x:(-len(x['prefix']),x['prefix']))
    stem=f'IrregularNine14P{profile:02d}';space=f'Delivery.IrregularNine14.P{profile:02d}'
    modules=[];where={};a.output.mkdir(parents=True,exist_ok=True)
    for start in range(0,len(nodes),a.chunk):
        chunk=nodes[start:start+a.chunk];module=f'{stem}C{start//a.chunk:04d}'
        dependencies=set();decl=[]
        for offset,node in enumerate(chunk):
            index=start+offset;name=f'u{index}';p=node['prefix'];pstr=natlist(p);d=data['outdegrees'][len(p)] if len(p)<9 else None
            if node['kind']=='bound':
                cert=f'b{index}';kind='PairBound' if a.pair_list else 'MixedBound';decl.append(f'def {cert} : {kind} 9 := '+certificate(node['certificate'],a.pair_list)+'\n')
                if a.pair_list:
                    decl.append(f'theorem {name} : Upper (D {profile}) (R {profile}) {pstr} 13 :=\n  PairNine.sound _ _ _ _ (leftConstant {profile}) 14 {cert}\n    (constants {profile}).1 (constants {profile}).2 (by decide +kernel)\n')
                else:
                    decl.append(f'theorem {name} : Upper (D {profile}) (R {profile}) {pstr} 13 :=\n  CampingNine.reduced_sound _ _ _ _ (leftConstant {profile}) 14 {cert}\n    (constants {profile}).1 (constants {profile}).2 (by decide +kernel)\n')
            else:
                reps=node['representatives'];refs={}
                for rep in reps:
                    entry=node['children'][str(rep)];q=entry['prefix'];childmodule,childname=where[tuple(q)]
                    if childmodule!=module:dependencies.add(childmodule)
                    if q==p+[rep] and entry['forward']==list(range(9)):
                        refs[rep]=childname
                    else:
                        rname=f'm{index}_{rep}'
                        text=f'theorem {rname} : Upper (D {profile}) (R {profile}) {natlist(p+[rep])} 13 :=\n'
                        text+=f'  permutation_upper _ _ _ {natlist(q)} {perm(entry["forward"])} {perm(entry["inverse"])} 13\n'
                        text+='    ((PermutationNine.check_true _ _ _ _ _ _).mp (by decide +kernel)) '+childname+'\n'
                        decl.append(text);refs[rep]=rname
                rname=f'r{index}';decl.append(f'def {rname} : Route 9 := '+route(node)+'\n')
                colname=f'c{index}';decl.append(f'def {colname} : Nat → Fin 9 := '+rejected_columns(data,p)+'\n')
                text=f'theorem {name} : Upper (D {profile}) (R {profile}) {pstr} 13 := by\n'
                text+=f'  apply FastRouting.sound _ _ {pstr} 13 (by decide) (choices {d}) {natlist(reps)} {rname} {colname}\n'
                text+='    (by exact cover_'+{1:'one',2:'two',3:'three'}[d]+')\n'
                text+='    (by decide +kernel)\n'
                text+='  intro mask member\n'
                if reps:
                    text+='  simp only [List.mem_cons,List.not_mem_nil,or_false] at member\n'
                    text+='  rcases member with '+' | '.join('rfl' for _ in reps)+'\n'
                    text+=''.join('  · exact '+refs[rep]+'\n' for rep in reps)
                else:text+='  simp at member\n'
                decl.append(text)
            where[tuple(p)]=(module,name)
        src=('import RowPrefixPairLoss\n' if a.pair_list else '')+'import IrregularNine14Constants\nimport RowPrefixCampingNine\nimport RowPrefixPermutationNine\nimport RowPrefixFastRouting\n'
        src+=''.join('import '+d+'\n' for d in sorted(dependencies))
        src+=f'\nnamespace {space}\nopen RowPrefix\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n'
        src+='\n'.join(decl)+f'\n#print axioms u{start+len(chunk)-1}\nend {space}\n'
        path=a.output/f'{module}.lean';path.write_text(src)
        modules.append(dict(module=module,nodes=len(chunk),bytes=path.stat().st_size,dependencies=sorted(dependencies),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    rootmodule,rootname=where[()]
    src=f'import {rootmodule}\n\nnamespace {space}\nopen RowPrefix\ntheorem canonical_upper : Upper (D {profile}) (R {profile}) [] 13 := {rootname}\n#print axioms canonical_upper\nend {space}\n'
    final=a.output/f'{stem}.lean';final.write_text(src)
    modules.append(dict(module=stem,nodes=0,bytes=final.stat().st_size,dependencies=[rootmodule],sha256=hashlib.sha256(final.read_bytes()).hexdigest()))
    result=dict(input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),counts=data['counts'],exporter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),modules=modules)
    (a.output/f'{stem}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(profile=profile,modules=len(modules),bytes=sum(m['bytes'] for m in modules))))
if __name__=='__main__':main()

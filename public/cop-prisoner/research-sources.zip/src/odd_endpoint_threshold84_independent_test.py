#!/usr/bin/env python3
"""Bounded independent checks of the cutoff84 leaf-game routine.

No enumeration is rerun. The C++ leaf routine is compared with the
independent alternating game on fixed examples of all three degree types.
The cutoff-zero harness calls game() directly and disables no search prune,
because it does not call the search at all.
"""
import gzip
import hashlib
import json
import random
import subprocess
import tempfile
from pathlib import Path

from game_solver import solve_graph

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'src/odd_endpoint_near23_threshold.cpp'


def sample(mode, rng):
    a = list(range(1, 12)) + [0]
    if mode == 2:
        a = [0] + list(range(2, 12)) + [1]
    while True:
        if mode == 1:
            remaining = [i for i in range(12) if i != 1]
            rng.shuffle(remaining)
            b = [1] + remaining
        else:
            b = list(range(12))
            rng.shuffle(b)
        if all(b[u] != u and (b[u] != a[u] or (mode == 1 and u == 0)) for u in range(12)):
            break
    return sorted({(u, a[u]) for u in range(1, 12)} | {(u, b[u]) for u in range(12)})


def main():
    rng = random.Random(230084)
    tests = [dict(mode=mode, arcs=sample(mode, rng), kind='fixed-seed degree-type sample')
             for mode in range(3) for _ in range(12)]
    lower_path = ROOT/'research/odd-endpoint-m23-lower-certificate.json.gz'
    lower = json.loads(gzip.decompress(lower_path.read_bytes()))
    tests.append(dict(mode=0, arcs=lower['arcs'], kind='previously certified83-pair lower witness'))
    inputs = []
    for test in tests:
        arcs = test['arcs']
        assert len(arcs) == len(set(map(tuple, arcs))) == 23
        indeg, outdeg = [0]*12, [0]*12
        masks = [0]*12
        for u, v in arcs:
            assert u != v
            indeg[v] += 1
            outdeg[u] += 1
            masks[u] |= 1 << v
        low_t = 0 if test['mode'] == 2 else 1
        assert outdeg == [1]+[2]*11
        assert indeg == [1 if v == low_t else 2 for v in range(12)]
        result = solve_graph(12, arcs, method='explicit', certificates=True)
        test['independent_I'] = result['I']
        for cutoff in (0, 84):
            inputs.append(' '.join(map(str, [test['mode'], cutoff, *masks])))
    harness = '#define main archived_enumerator_main\n#include "'+str(SOURCE)+'"\n#undef main\n'
    harness += '''int main(int argc,char**argv){
      if(argc>1)return archived_enumerator_main(argc,argv);
      n=12;all=(1<<n)-1;
      while(cin>>mode>>minwanted){low_target=mode==2?0:1;
        for(int i=0;i<n;i++)cin>>out[i];cout<<game()<<"\\n";}
    }\n'''
    with tempfile.TemporaryDirectory(prefix='cop-cutoff84-audit-') as temporary:
        folder = Path(temporary)
        (folder/'audit.cpp').write_text(harness)
        binary = folder/'audit'
        subprocess.run(['c++','-O2','-std=c++17',str(folder/'audit.cpp'),'-o',str(binary)], check=True)
        process = subprocess.run([str(binary)], input='\n'.join(inputs)+'\n', text=True,
                                 capture_output=True, check=True)
        scores = list(map(int, process.stdout.split()))
        assert len(scores) == 2*len(tests)
        for i, test in enumerate(tests):
            full, cutoff = scores[2*i:2*i+2]
            assert full == test['independent_I']
            assert cutoff == max(full, 83)
            test['cpp_full_leaf_I'] = full
            test['cpp_cutoff84_remaining_potential'] = cutoff
        invalid = subprocess.run([str(binary),'0','0','83'], capture_output=True)
        assert invalid.returncode == 2
    summary_path = ROOT/'research/odd-endpoint-threshold84-summary.json'
    summary = json.loads(summary_path.read_text())
    for relative, digest in summary['source_and_receipt_sha256'].items():
        assert hashlib.sha256((ROOT/relative).read_bytes()).hexdigest() == digest
    for record in summary['records']:
        assert record['complete'] and record['threshold_checked'] == 84
        assert record['best_I_at_least_threshold'] == 0
    receipt = dict(verified=True, cases=len(tests), modes=[0,1,2],
                   independent_game='Explicit alternating game with every winning-rank and losing-closure check',
                   scope='Leaf-game/early-exit checks and saved-receipt hashes; exhaustive searches not repeated',
                   invalid_cutoff83_rejected=True, summary_hashes_valid=True,
                   tests=tests,
                   source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                   checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   summary_sha256=hashlib.sha256(summary_path.read_bytes()).hexdigest())
    (ROOT/'research/odd-endpoint-threshold84-independent-tests.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({key:value for key,value in receipt.items() if key!='tests'}))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Independent affine, regression and incremental-closure audit; no producer import."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE_REVISION = '9bc812f4f9b0422918904d9036631968214646ae'
BASE_SHA256 = 'f83cd50669d06c0cb5d1f6e04280f910416c24f15611d0cef09da9b792cf0273'
CAPS = dict(zip(range(12,22),(12,13,16,18,15,18,15,18,11,15)))
REGIONS = ('sparse_m_le_2n','main_2n_lt_m_le_n_n_minus3',
           'dense_m_gt_max_2n_n_n_minus3')


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def intervals(values):
    result=[]
    for x in sorted(values):
        if result and result[-1][1]+1==x:result[-1][1]=x
        else:result.append([x,x])
    return result


def region(n,m):
    if m<=2*n:return REGIONS[0]
    if m<=n*(n-3):return REGIONS[1]
    return REGIONS[2]


def expand(document):
    """Decode each affine segment independently and check its entire domain."""
    rows={};totals=Counter();unknown_regions=Counter();unknown=[]
    first,last=document['finite_box']['n']
    assert [r['n'] for r in document['rows']]==list(range(first,last+1))
    for record in document['rows']:
        n=record['n'];L=n*(n-1);cells=[];next_m=0
        for segment in record['segments']:
            a,b=segment['m'];assert a==next_m and a<=b<=L
            lo,dl,lo_rule,support,base_m=segment['lower']
            hi,dh,hi_rule=segment['upper']
            assert lo_rule in document['rules'] and hi_rule in document['rules']
            assert 1<=support<=n
            for m in range(a,b+1):
                lower,upper=lo+dl*(m-a),hi+dh*(m-a)
                assert 0<=lower<=upper<=L-m,(n,m,lower,upper)
                assert segment['status']==('exact' if lower==upper else 'unresolved')
                if base_m is None:
                    assert m<=support*(support-1),(n,m,'isolate support',support)
                else:
                    assert 0<=base_m<=support*(support-1)
                    assert 0<=m-base_m<=(n-support)*(n-support-1),(n,m,'padding',support,base_m)
                cells.append((lower,upper))
            next_m=b+1
        assert next_m==L+1
        missing=[m for m,(lo,hi) in enumerate(cells) if lo<hi]
        assert record['admissible']==len(cells)
        assert record['unresolved']==len(missing)
        assert record['exact']==len(cells)-len(missing)
        assert record['unresolved_m_ranges']==intervals(missing)
        for m in missing:unknown.append((n,m));unknown_regions[region(n,m)]+=1
        totals.update(admissible=len(cells),exact=len(cells)-len(missing),unresolved=len(missing))
        rows[n]=cells
    assert dict(totals)==document['totals']
    assert {r:unknown_regions[r] for r in REGIONS}==document['regions']
    return rows,unknown


def replay_new_closure(baseline,approved):
    """Independently add only the new mathematical inputs to frozen old bounds.

    Existing family and point consequences are already in the baseline. New
    literals are lower bounds only. New stage intervals use their proved
    missing-pair equality. New upper claims stay upper bounds. Host reduction
    transports an upper bound downward from the already processed host.
    """
    answer={}
    for n,old in baseline.items():
        row=[list(pair) for pair in old];L=n*(n-1)
        for item in approved['upper_bounds']:
            if item['n'] is not None and item['n']!=n:continue
            budgets=range(L+1) if item['m'] is None else [item['m']]
            for m in budgets:
                if m<=L:row[m][1]=min(row[m][1],item['value'])
        for stage in approved['stage_intervals']:
            if stage['n']==n:
                for m in range(stage['m_min'],stage['m_max']+1):
                    row[m][0]=max(row[m][0],L-m)
                    row[m][1]=min(row[m][1],L-m)
        # A direct placement of a saved literal, with separate disjoint padding.
        for graph in approved['fixed_graphs']:
            size,arrows,value=graph['n'],graph['m'],graph['I']
            if size>n:continue
            spare=n-size
            for m in range(arrows,min(L,arrows+spare*(spare-1))+1):
                row[m][0]=max(row[m][0],value)
        # Isolate propagation also carries new interval witnesses to larger hosts.
        if n-1 in answer:
            for m,(lower,upper) in enumerate(answer[n-1]):
                row[m][0]=max(row[m][0],lower)
                if m and n>CAPS.get(m,2*m):row[m][1]=min(row[m][1],upper)
        assert all(lo<=hi for lo,hi in row),(n,'inconsistent replay inputs')
        answer[n]=list(map(tuple,row))
    return answer


def expected_tail(n,m):
    if n==11 and m in (22,23,24):return {22:79,23:78,24:79}[m]
    if m==22:return 79
    if m==23:return 83
    if m<=2*n:
        k=m//2;return k*(k-3)+2*(m%2)
    if m<=n*(n-3):return n*(n-1)-m
    if m<=n*(n-2):
        r=m-n*(n-3);return 2*n-r-(r+1)//2-1
    return 0


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preview',action='store_true',help='Do not pin files or write the final receipt.')
    args=parser.parse_args()
    baseline_blob=gzip.decompress((ROOT/'research/small-case-baseline.json.gz').read_bytes())
    assert digest(baseline_blob)==BASE_SHA256
    baseline_doc=json.loads(baseline_blob)
    ledger_path=ROOT/'publication/classification-coverage.json'
    ledger_blob=ledger_path.read_bytes();ledger=json.loads(ledger_blob)
    approved=json.loads((ROOT/'research/small-case-results.json').read_text())
    assert approved['verified']
    approval=json.loads((ROOT/'research/small-case-approved-bounds.json').read_text())
    assert approved['upper_bounds']==approval['upper_bounds']
    assert approved['host_cutoffs']==approval['host_cutoffs']
    baseline,old_unknown=expand(baseline_doc)
    current,new_unknown=expand(ledger)
    assert baseline.keys()==current.keys()
    assert {x['m']:x['universal_host_cutoff'] for x in approved['host_cutoffs']}==CAPS
    assert {int(k):v for k,v in ledger['canonical_representatives']['host_cutoffs'].items()}==CAPS
    for n,row in replay_new_closure(baseline,approved).items():
        for m,pair in enumerate(row):assert pair==current[n][m],(n,m,'new-rule closure mismatch',pair,current[n][m])

    improved_lower=improved_upper=unchanged_exact=0;new_exact=[]
    for n,row in current.items():
        for m,(lo,hi) in enumerate(row):
            old_lo,old_hi=baseline[n][m]
            assert lo>=old_lo and hi<=old_hi,(n,m,'bound regression')
            if old_lo==old_hi:
                assert (lo,hi)==(old_lo,old_hi),(n,m,'old exact changed')
                unchanged_exact+=1
            elif lo==hi:new_exact.append((n,m))
            improved_lower+=lo>old_lo;improved_upper+=hi<old_hi

    canonical=[];canonical_regions=Counter();mapping_checks=0
    for n,m in new_unknown:
        cap=CAPS.get(m,2*m);host=min(n,cap)
        assert m and current[n][m]==current[host][m],(n,m,'host bounds disagree',host)
        mapping_checks+=1
        if host==n:canonical.append((n,m));canonical_regions[region(n,m)]+=1
    expected_rows=[{'n':n,'m_ranges':intervals(m for order,m in canonical if order==n)} for n in current]
    meta=ledger['canonical_representatives']
    assert meta['unresolved']==len(canonical)==101
    assert meta['regions']=={r:canonical_regions[r] for r in REGIONS}
    assert meta['unresolved_by_n']==expected_rows
    assert max(n for n,m in canonical)==18
    assert all(n in (8,9,10) for n,m in canonical if region(n,m)==REGIONS[1])
    # Also validate the complete larger-host bound plateaus, not just unknowns.
    plateau_checks=0
    for n,row in current.items():
        for m,pair in enumerate(row):
            if m and n>CAPS.get(m,2*m):
                assert pair==current[CAPS.get(m,2*m)][m]
                plateau_checks+=1

    n7_checks=dense_checks=tail_checks=0
    for n,row in current.items():
        if n<=7:
            assert all(lo==hi for lo,hi in row)
            if n==7:n7_checks=len(row)
        for m,(lo,hi) in enumerate(row):
            if m>n*(n-3):assert lo==hi;dense_checks+=1
            if n>=11 and m>=22:
                assert lo==hi==expected_tail(n,m),(n,m,'uniform tail mismatch')
                tail_checks+=1
    assert current[11][22]==(79,79) and current[11][23]==(78,78) and current[11][24]==(79,79)
    assert current[8][12]==current[9][12]==(9,9) and current[8][13]==(11,11)
    assert current[8][39]==(14,14)
    if not args.preview:assert current[8][40]==(12,13),'Wait for final8,40 upper13 ledger'
    vertex_marginals={n:(max(lo for lo,hi in current[n]),max(hi for lo,hi in current[n]))
                      for n in (8,9,10,11)}
    assert vertex_marginals=={8:(32,32),9:(48,53),10:(62,69),11:(85,85)}
    arc20=(max(row[20][0] for row in current.values() if len(row)>20),
           max(row[20][1] for row in current.values() if len(row)>20))
    assert arc20==(53,57) and current[11][20]==arc20

    old_canonical={(n,m) for n,m in old_unknown if m and n<=2*m}
    newly_solved_old_canonical=old_canonical-set(new_unknown)
    compressed_still_unknown=(old_canonical & set(new_unknown))-set(canonical)
    assert old_canonical==set(canonical)|newly_solved_old_canonical|compressed_still_unknown
    assert len(new_exact)==ledger['totals']['exact']-baseline_doc['totals']['exact']==174
    report=dict(verified=True,baseline_revision=BASE_REVISION,
                baseline_blob_sha256=BASE_SHA256,
                cells_compared=sum(map(len,current.values())),
                old_exact_cells_preserved=unchanged_exact,
                improved_lower_cells=improved_lower,improved_upper_cells=improved_upper,
                new_exact_cells=len(new_exact),new_exact_by_n=dict(sorted(Counter(n for n,m in new_exact).items())),
                new_exact_ranges=[{'n':n,'m_ranges':intervals(m for order,m in new_exact if order==n)}
                                  for n in current if any(order==n for order,m in new_exact)],
                old_canonical_unknowns=len(old_canonical),new_canonical_unknowns=len(canonical),
                canonical_regions={r:canonical_regions[r] for r in REGIONS},
                newly_exact_old_canonical=len(newly_solved_old_canonical),
                removed_still_unknown_representatives=len(compressed_still_unknown),
                raw_unknowns=len(new_unknown),repeated_unknown_hosts=len(new_unknown)-len(canonical),
                current_totals=ledger['totals'],host_cutoffs=CAPS,
                unknown_host_mapping_checks=mapping_checks,full_bound_plateau_checks=plateau_checks,
                order7_exact_cells=n7_checks,all_dense_exact_cells=dense_checks,
                uniform_n11_m22_tail_checks=tail_checks,
                vertex_marginals=vertex_marginals,arc20_marginal=arc20,
                unresolved_by_n=[r for r in expected_rows if r['m_ranges']],
                selected_cell_8_40=current[8][40],
                scope='Independent affine decoding, complete baseline regression, full incremental closure from approved new literals/stages/uppers/host reductions, canonical expansion and domain checks. No coverage.calculate import, game solve, graph search or new proof of the input theorems. Explicit recipe coverage is a separate audit.')
    if not args.preview:
        paths=['research/small-case-baseline.json.gz','publication/classification-coverage.json',
               'research/small-case-results.json','research/small-case-approved-bounds.json',
               'src/classification_coverage.py','src/classification_extensions.py',
               'src/classification_small_cases.py','src/small_case_ledger_review.py',
               'research/small-case-ledger-review.md']
        for path,want in ledger['source_sha256'].items():
            assert digest((ROOT/path).read_bytes())==want,(path,'ledger source drift')
        report['ledger_source_pins_checked']=len(ledger['source_sha256'])
        report['sha256']={path:digest((ROOT/path).read_bytes()) for path in paths}
        assert ledger_path.read_bytes()==ledger_blob,'Ledger changed during audit'
        (ROOT/'research/small-case-ledger-review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('sha256','new_exact_ranges','unresolved_by_n')},indent=2))


if __name__=='__main__':main()

// Exact joint maxima for n=6. Restrict to lexicographically nondecreasing
// (outdegree,indegree) vertex labels: every digraph has such a relabeling.
// No counts of labeled graphs are inferred from this symmetry reduction.
// One worker, hard wall-clock budget; complete=false means no exhaustive claim.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>

constexpr int n=6, all=63;
int out[n], degrees[n], maximum[31];
uint64_t witness[31], leaves=0, solved=0, canonical=0;
std::vector<int> options[6][6];
auto started=std::chrono::steady_clock::now();
double budget=50;
bool finished=true;

void leaf(int m) {
  ++leaves;
  if ((leaves&65535)==0 && std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()>budget) {
    finished=false;return;
  }
  int indeg[n]={};
  for(int u=0;u<n;++u) for(int v=0;v<n;++v) if(u!=v && (out[u]&(1<<v)))++indeg[v];
  for(int u=1;u<n;++u) if(degrees[u]==degrees[u-1] && indeg[u]<indeg[u-1])return;
  ++canonical;
  int bound=0;
  for(int s=0;s<n;++s)for(int t=0;t<n;++t)
    if(s!=t && degrees[s]>=2 && indeg[t]>=2 && !(out[s]&(1<<t)))++bound;
  if(bound<=maximum[m])return;
  ++solved;
  int I=0,win[n],safe[n],next[n];
  for(int t=0;t<n;++t) {
    if(indeg[t]<2)continue;
    std::fill(win,win+n,0);win[t]=all;
    bool changed=true;
    while(changed) {
      for(int v=0;v<n;++v) {
        safe[v]=0;
        if(v==t)safe[v]=all;
        else for(int c=0;c<n;++c)if((out[c]&~win[v])==0)safe[v]|=1<<c;
      }
      changed=false;
      for(int r=0;r<n;++r) {
        int w=0;
        if(r==t)w=all;
        else {int x=out[r];while(x){int v=__builtin_ctz(x);x&=x-1;w|=safe[v];}w&=all^(1<<r);}
        next[r]=w;changed|=w!=win[r];
      }
      std::copy(next,next+n,win);
    }
    for(int s=0;s<n;++s)if(s!=t && !(out[s]&(1<<t)) && (win[s]|(1<<s))==all)++I;
  }
  if(I>maximum[m]) {
    maximum[m]=I;uint64_t mask=0;int pos=0;
    for(int u=0;u<n;++u)for(int v=0;v<n;++v)if(u!=v)mask|=uint64_t((out[u]>>v)&1)<<(pos++);
    witness[m]=mask;
  }
}

void visit(int row,int lower,int m) {
  if(!finished)return;
  if(row==n){leaf(m);return;}
  for(int d=lower;d<n;++d)for(int mask:options[row][d]) {
    out[row]=mask|(1<<row);degrees[row]=d;visit(row+1,d,m+d);
    if(!finished)return;
  }
}

int main(int argc,char**argv) {
  if(argc>1)budget=std::atof(argv[1]);
  std::fill(maximum,maximum+31,-1);
  for(int u=0;u<n;++u)for(int x=0;x<=all;++x)if(!(x&(1<<u)))options[u][__builtin_popcount(x)].push_back(x);
  visit(0,0,0);
  double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
  std::cout<<"{\"n\":6,\"complete\":"<<(finished?"true":"false")<<",\"degree_sorted_candidates\":"<<leaves
    <<",\"degree_pair_sorted_candidates\":"<<canonical<<",\"solved\":"<<solved<<",\"seconds\":"<<seconds<<",\"by_m\":[";
  for(int m=0;m<=30;++m) {
    if(m)std::cout<<",";
    std::cout<<"{\"m\":"<<m<<",\"maximum_I\":"<<maximum[m]<<",\"witness_mask\":"<<witness[m]<<"}";
  }
  std::cout<<"]}\n";
}

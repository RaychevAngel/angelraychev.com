#!/usr/bin/env python3
"""Migrate only unchecked nine-profile chunks to checked corner witnesses.

This is an untrusted literal exporter. It preserves the complete prefix DAG,
all losing-pair certificates, all theorem statements and every accepted file.
The new kernel checks the distinct listed arrows and the complete old losses.
"""
from __future__ import annotations
import argparse, hashlib, json, re, tarfile
from pathlib import Path
from irregular_nine_export import certificate

ROOT = Path(__file__).resolve().parents[1]
LEFT = [28,28,29,28,28,29,30,31,28,32,29]

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--cache',type=Path,required=True)
    ap.add_argument('--archive',type=Path,required=True)
    ap.add_argument('--audit',type=Path,required=True)
    args=ap.parse_args()
    assert not args.archive.exists(), 'Preserve the existing archive; choose a fresh destination.'
    assert not args.audit.exists(), 'Preserve the existing migration audit.'
    cache=json.loads(args.cache.read_text())
    files=sorted((ROOT/'lean').glob('IrregularNine14P*.lean'))
    files += [ROOT/'src/irregular_nine_export.py', ROOT/'lean/IrregularNine14Constants.lean',
              ROOT/'lean/IrregularNineFourteen.lean']
    files += sorted((ROOT/'tmp/lean-irregular-nine').glob('IrregularNine14P*.json'))
    before={str(f.relative_to(ROOT)):sha(f) for f in files}
    accepted={f.stem:cache[f.stem] for f in files if f.suffix=='.lean' and f.stem in cache}
    for name,record in accepted.items():
        assert sha(ROOT/'lean'/(name+'.lean'))==record['source_sha256'], name
        assert sha(ROOT/'lean'/(name+'.olean'))==record['object_sha256'], name
    args.archive.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(args.archive,'w:gz',compresslevel=1) as tar:
        for f in files:tar.add(f,arcname=str(f.relative_to(ROOT)),recursive=False)
    with tarfile.open(args.archive,'r:gz') as tar:
        archived={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}
    assert archived==before
    updates=[];unchanged=[];inputs={};histogram={}
    for profile in range(11):
        source=ROOT/f'tmp/lean-irregular-nine/trim{profile:02}.json'
        inputs[str(source.relative_to(ROOT))]=sha(source)
        data=json.loads(source.read_text())
        assert data['profile_id']==profile and data['n']==9 and data['bound']==13
        nodes=sorted(data['nodes'].values(),key=lambda node:(-len(node['prefix']),node['prefix']))
        for start in range(0,len(nodes),60):
            name=f'IrregularNine14P{profile:02}C{start//60:04}'
            path=ROOT/'lean'/(name+'.lean')
            if name in accepted:
                unchanged.append(name);continue
            old=path.read_text();new=old;count=0
            for index,node in enumerate(nodes[start:start+60],start):
                if node['kind']!='bound':continue
                cert=node['certificate'];p=node['prefix']
                expected=f'def b{index} : PairBound 9 := '+certificate(cert,True)
                assert expected in old,(name,index,'certificate mismatch')
                lost=sum(mask.bit_count() for mask in cert['lost'])
                needed=max(0,LEFT[profile]-13-14-lost)
                corners=[(s,t) for s,mask in enumerate(p) if data['outdegrees'][s]<2
                         for t in range(9) if data['indegrees'][t]<2 and mask>>t&1][:needed]
                assert len(corners)==needed,(name,index,'insufficient witness')
                literal='['+','.join(f'({s},{t})' for s,t in corners)+']'
                oldcall=f'PairNine.sound _ _ _ _ (leftConstant {profile}) 14 b{index}\n'
                newcall=f'CornerWitnessNine.sound _ _ _ _ (leftConstant {profile}) 14 b{index} {literal}\n'
                assert new.count(oldcall)==1,(name,index,'call mismatch')
                new=new.replace(oldcall,newcall)
                count+=1;histogram[needed]=histogram.get(needed,0)+1
            if not count:
                unchanged.append(name);continue
            assert 'PairNine.sound' not in new,name
            new='import RowPrefixCornerWitness\n'+new
            oldhash=sha(path)
            assert oldhash==before[str(path.relative_to(ROOT))]
            path.write_text(new)
            updates.append(dict(module=name,old_source_sha256=oldhash,new_source_sha256=sha(path),
                                changed_leaves=count))
    for name,record in accepted.items():
        assert sha(ROOT/'lean'/(name+'.lean'))==record['source_sha256'],name
        assert sha(ROOT/'lean'/(name+'.olean'))==record['object_sha256'],name
    audit=dict(scope='Unchecked literal chunks only; no proof acceptance claimed by this exporter.',
        legacy_archive=str(args.archive),legacy_archive_sha256=sha(args.archive),
        legacy_file_hashes=before,input_sha256=inputs,exporter_sha256=sha(Path(__file__)),
        kernel_sha256=sha(ROOT/'lean/RowPrefixCornerWitness.lean'),
        preserved_accepted_modules=sorted(accepted),unchanged_chunks=unchanged,
        corner_lengths=histogram,updates=updates)
    args.audit.write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps(dict(changed_chunks=len(updates),changed_leaves=sum(x['changed_leaves'] for x in updates),
        accepted_files_preserved=len(accepted),corner_lengths=histogram,archive_sha256=audit['legacy_archive_sha256'])))

if __name__=='__main__':main()

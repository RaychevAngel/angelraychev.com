#!/usr/bin/env python3
"""Untrusted, bounded proof producer for the nine-vertex regular exclusions.

Every possible second-permutation value is a branch. The emitted Lean proof
checks invalid prefixes, camping prunes and complete losing leaf closures.
No historical receipt is read as a premise or overwritten.
"""
from __future__ import annotations
import argparse, hashlib, json, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
N=9
PARTITIONS=[(2,2,2,3),(2,2,5),(2,3,4),(2,7),(3,3,3),(3,6),(4,5),(9,)]

def function(name, vals):
    return f'def {name} (x : Fin 9) : Fin 9 :=\n  match x.val with\n'+''.join(f'  | {i} => {v}\n' for i,v in enumerate(vals))+'  | _ => 0\n\n'
def literal(p): return '['+','.join(map(str,p))+']'
def primary(parts):
    a=[]
    for k in parts:
        start=len(a); a.extend(start+(j+1)%k for j in range(k))
    return a

def lose_certificate(a,b):
    out=[{r,a[r],b[r]} for r in range(N)]
    for t in range(N):
        win=[[r==t for c in range(N)] for r in range(N)]
        while True:
            nxt=[[r==t or (r!=c and any(z==t or (z!=c and all(z!=d and win[z][d] for d in out[c])) for z in out[r])) for c in range(N)] for r in range(N)]
            if nxt==win: break
            win=nxt
        for s in range(N):
            if t in out[s]: continue
            for c in range(N):
                if c!=s and not win[s][c]:
                    mask=sum(1<<(r*N+d) for r in range(N) for d in range(N) if not win[r][d])
                    # Independent local replay of the generated closure.
                    for r in range(N):
                        for d in range(N):
                            if win[r][d]: continue
                            assert r!=t
                            if r==d: continue
                            for z in out[r]:
                                assert z!=t
                                assert z==d or any(z==e or not win[z][e] for e in out[d])
                    return s,t,c,mask
    raise AssertionError('universal graph found')

def produce(parts, node_limit=500000):
    a=primary(parts); inv=[a.index(i) for i in range(N)]
    key='x'.join(map(str,parts)); namespace='Cycle'+key
    lines=['import FiniteExclusionKernel\n\nset_option maxRecDepth 4096\nset_option maxHeartbeats 20000000\n\nnamespace Delivery.FiniteExclusion.'+namespace+'\nopen FiniteGame Extremal\n\n',function('a',a)]
    counts={'nodes':0,'branches':0,'invalid_children':0,'source_prunes':0,'predecessor_prunes':0,'losing_leaves':0}
    leaves=[]; trace=[]
    def source_prune(p):
        lowers=[{c,a[c]}|({p[c]} if c<len(p) else set()) for c in range(N)]
        for s in range(len(p)):
            for c in range(N):
                if c!=s and {a[s],p[s]}<=lowers[c]:
                    t=next(t for t in range(N) if t not in {s,a[s],p[s]})
                    return s,t,c
        return None
    def pred_prune(p):
        lowers=[{c,a[c]}|({p[c]} if c<len(p) else set()) for c in range(N)]
        for u,t in enumerate(p):
            for c in range(N):
                if {inv[t],u}<=lowers[c]:
                    s=next(s for s in range(N) if s not in {t,inv[t],u,c})
                    return s,t,c,u
        return None
    def walk(p):
        counts['nodes']+=1
        if counts['nodes']>node_limit: raise RuntimeError('bounded node limit reached')
        idx=counts['nodes']; name=f'node_{idx}'; pl=literal(p)
        source=source_prune(p); pred=None if source else pred_prune(p)
        if source:
            counts['source_prunes']+=1; s,t,c=source
            proof=f'source_excluded a {pl} {s} {t} {c} (by decide) (by decide +kernel)'
            trace.append({'prefix':p,'kind':'source','witness':source})
        elif pred:
            counts['predecessor_prunes']+=1; s,t,c,u=pred
            proof=f'predecessor_excluded a {pl} {s} {t} {c} {u} (by decide) (by decide +kernel)'
            trace.append({'prefix':p,'kind':'predecessor','witness':pred})
        elif len(p)==N:
            counts['losing_leaves']+=1; s,t,c,mask=lose_certificate(a,p)
            bn=f'b_{idx}'; cn=f'cert_{idx}'
            lines.append(function(bn,p))
            lines.append(f'def {cn} : LosingRegion (edgeOf a {bn}) {t} :=\n  losingMask a {bn} {t} {mask}\n    (by decide +kernel) (by decide +kernel)\n\n')
            proof=f'losing_excluded a {pl} (by decide) {bn} (by decide +kernel) {s} {t} {c} {cn} (by change {s} ≠ {t} ∧ ¬ edgeOf a {bn} {s} {t} ∧ {c} ≠ {s} ∧ maskRegion {mask} {s} {c}; decide +kernel)'
            leaves.append({'prefix':p,'s':s,'t':t,'c':c,'losing_mask':mask})
            trace.append({'prefix':p,'kind':'losing','witness':[s,t,c],'mask':mask})
        else:
            counts['branches']+=1; children=[]; k=len(p)
            for v in range(N):
                nxt=p+[v]
                if v in p or v==k or v==a[k]:
                    counts['invalid_children']+=1
                    children.append(f'(invalid_excluded a {literal(nxt)} (by decide +kernel))')
                else: children.append(walk(nxt))
            proof=f'branch_excluded a {pl} (by decide)\n    (fin9_cases _\n      '+'\n      '.join(children)+')'
        lines.append(f'theorem {name} : Excluded a {pl} :=\n  {proof}\n\n')
        return name
    started=time.monotonic(); top=walk([])
    lines.append(f'theorem every_second_factor_blocked (b : Assignment 9) (valid : Valid a b) : Blocked a b :=\n  {top} b valid (by intro i h; simp at h)\n\n')
    lines.append('theorem primary_loopless : ∀ i : Fin 9, a i ≠ i := by decide +kernel\n\n')
    lines.append('#print axioms every_second_factor_blocked\nend Delivery.FiniteExclusion.'+namespace+'\n')
    out=ROOT/'lean'/f'FiniteExclusionNine{key}.lean'; content=''.join(lines)
    if not out.exists() or out.read_text()!=content: out.write_text(content)
    scratch=ROOT/'tmp/lean-oct23/finite'; scratch.mkdir(parents=True,exist_ok=True)
    receipt={'partition':parts,'primary':a,'counts':counts,'seconds':time.monotonic()-started,'source':str(out.relative_to(ROOT)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'boundary':'Full branch coverage of every valid second permutation for this fixed first factor; normalization of arbitrary regular graphs is a separate theorem.','leaves':leaves,'tree':trace}
    (scratch/f'family-{key}.json').write_text(json.dumps(receipt,separators=(',',':'))+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k not in ('tree','leaves')}),flush=True)
    return receipt

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--partition',default='9');ap.add_argument('--all',action='store_true');ap.add_argument('--node-limit',type=int,default=500000); args=ap.parse_args()
    selected=PARTITIONS if args.all else [tuple(map(int,args.partition.split(',')))]
    assert all(p in PARTITIONS for p in selected)
    for parts in selected: produce(parts,args.node_limit)
if __name__=='__main__': main()

#!/usr/bin/env python3
"""Exact conditional counts for a deterministic two-move construction.

The sufficient expectation test is polynomial but expensive. Tests use
small exact enumerations; they do not pretend to execute a huge asymptotic
instance. Partial assignments are maps from nonloop arcs to0 or1.
"""
from itertools import combinations,product
from math import comb
from pathlib import Path
import hashlib,json,random

def choose(n,k):return comb(n,k)if 0<=k<=n else 0

def bad_completions(n,m,assignment,triple):
    s,t,c=triple
    assert s!=t and c!=s
    free=n*(n-1)-len(assignment);budget=m-sum(assignment.values())
    if not 0<=budget<=free:return 0
    polynomial=[1];used=0
    for u in range(n):
        if u in triple:continue
        requirements=(((s,u),1),((u,t),1),((c,u),0))
        possible=all(e not in assignment or assignment[e]==v for e,v in requirements)
        q=sum(e not in assignment for e,v in requirements)
        a=sum(e not in assignment and v==1 for e,v in requirements)
        factor=[comb(q,j)for j in range(q+1)]
        if possible:factor[a]-=1
        if not any(factor):return 0
        following=[0]*(len(polynomial)+q)
        for i,x in enumerate(polynomial):
            for j,y in enumerate(factor):following[i+j]+=x*y
        polynomial=following;used+=q
    return sum(x*choose(free-used,budget-j)for j,x in enumerate(polynomial))

def all_triples(n):
    return [(s,t,c)for s in range(n)for t in range(n)if s!=t for c in range(n)if c!=s]

def expectation_counts(n,m,assignment,triples=None):
    triples=all_triples(n)if triples is None else triples
    total=choose(n*(n-1)-len(assignment),m-sum(assignment.values()))
    bad=sum(bad_completions(n,m,assignment,triple)for triple in triples)
    return bad,total

def construct(n,m,assignment=None,triples=None):
    fixed={}if assignment is None else dict(assignment)
    B,C=expectation_counts(n,m,fixed,triples)
    if not B<C:raise ValueError('The initial exact conditional expectation must be below one')
    trace=[]
    for e in [(u,v)for u in range(n)for v in range(n)if u!=v and(u,v)not in fixed]:
        branches=[]
        for value in (0,1):
            fixed[e]=value;branches.append(expectation_counts(n,m,fixed,triples))
        assert B==sum(b for b,c in branches) and C==sum(c for b,c in branches)
        value=next(v for v,(b,c)in enumerate(branches)if b<c)
        fixed[e]=value;B,C=branches[value]
        trace.append({'arc':e,'chosen':value,'bad_completion_sum':B,'completion_count':C})
    assert C==1 and B==0 and sum(fixed.values())==m
    return [e for e,v in fixed.items()if v],trace

def direct_bad(arcs,triple,n):
    s,t,c=triple
    return not any((s,u)in arcs and(u,t)in arcs and(c,u)not in arcs
                   for u in range(n)if u not in triple)

def check():
    rng=random.Random(120913);cases=0;identities=0
    for n in (3,4,5):
        universe=[(u,v)for u in range(n)for v in range(n)if u!=v]
        for trial in range(40):
            # At most eight undecided arcs keeps brute-force comparison small.
            shuffled=universe[:];rng.shuffle(shuffled);free=shuffled[:min(8,len(universe))]
            fixed={e:rng.randrange(2)for e in shuffled[len(free):]}
            m=sum(fixed.values())+rng.randrange(len(free)+1)
            triple=rng.choice(all_triples(n));brute=0
            for selected in combinations(free,m-sum(fixed.values())):
                arcs={e for e,v in fixed.items()if v}|set(selected)
                brute+=direct_bad(arcs,triple,n)
            exact=bad_completions(n,m,fixed,triple);assert exact==brute
            e=free[0]
            children=[bad_completions(n,m,{**fixed,e:value},triple)for value in (0,1)]
            assert exact==sum(children);cases+=1;identities+=1
    # A nontrivial complete decision sequence for one chosen delivery triple.
    # This tests the selection algorithm, not universal delivery at n=4.
    triple=(0,3,3)
    initial={(0,1):1,(1,3):1,(0,2):1,(2,3):1}
    assert expectation_counts(4,6,initial,[triple])==(1,28)
    arcs,trace=construct(4,6,initial,triples=[triple])
    assert len(arcs)==6 and not direct_bad(set(arcs),triple,4)
    result={'verified':True,'brute_force_count_cases':cases,'branch_additivity_checks':identities,
            'decision_sequence_test':{'n':4,'m':6,'objectives':[triple],'initial_fixed_arcs':[[*e,v]for e,v in initial.items()],'arcs':arcs,'trace':trace},
            'scope':'Exact counting and branch choice verified on listed small cases; no large all-triple construction run.',
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    path=Path(__file__).resolve().parents[1]/'research/exact-budget-derandomization-checks.json'
    path.write_text(json.dumps(result,indent=2)+'\n');print({'verified':True,'count_cases':cases,'decision_steps':len(trace)})

if __name__=='__main__':check()

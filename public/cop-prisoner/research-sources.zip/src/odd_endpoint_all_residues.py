#!/usr/bin/env python3
"""Complete local proof data for every sufficiently large odd arc budget.

Six explicit periodic cores and single finite defects cover n modulo six.
Only the last defect requires transfer by one or two columns.
"""
from __future__ import annotations
import gzip
import hashlib
import json
from pathlib import Path
from odd_endpoint_six import DeletedStrip,CombinedPatchStrip,ExtendedPatchStrip,check_strip

ROOT=Path(__file__).resolve().parents[1]
SPECS=[
    dict(removed=0,pattern_index=0,mask=0,extra_mask=0,source_column=0,source_type=0,which=0,direction=1,broad=False),
    dict(removed=1,pattern_index=19,mask=8,extra_mask=0,source_column=1,source_type=4,which=1,direction=1,broad=False),
    dict(removed=2,pattern_index=106,mask=3,extra_mask=0,source_column=0,source_type=5,which=1,direction=-1,broad=False),
    dict(removed=3,pattern_index=135,mask=28,extra_mask=0,source_column=0,source_type=1,which=0,direction=1,broad=False),
    dict(removed=4,pattern_index=135,mask=28,extra_mask=16,source_column=0,source_type=1,which=0,direction=1,broad=False),
    dict(removed=5,pattern_index=106,mask=3,extra_mask=2240,source_column=0,source_type=5,which=1,direction=-1,broad=True),
]
PATTERNS={
    0:([0,2,5,1,4,3],[-1,-1,1,1,-1,1]),
    # These entries are checked against the original catalogue on generation.
}


def patterns():
    values=[list(map(int,l.split()))for l in (ROOT/'research/sparse-composition-q6-input.txt').read_text().splitlines()[1:]]
    return {i:(values[i][:6],values[i][6:])for i in {s['pattern_index']for s in SPECS}}


def make_strip(spec,column=0):
    sig,vol=patterns()[spec['pattern_index']]
    if spec['removed']==0:return DeletedStrip(column,spec['source_type'],spec['which'],sig,vol)
    return ExtendedPatchStrip(column,spec['mask'],spec['extra_mask'],spec['source_column'],spec['source_type'],spec['which'],sig,vol)


def graph(n):
    q=(n+5)//6;r=6*q-n
    # The frozen generator below retains its historical threshold.  The
    # read-only odd_projection_threshold_check.py replays its independent
    # local premises and proves the sharper support bounds used here.
    if n<98:raise ValueError('uniform theorem requires n>=98')
    spec=SPECS[r];sig,vol=patterns()[spec['pattern_index']]
    removed={(0,j)for j in range(6)if spec['mask']>>j&1}
    removed|={(-1,j)for j in range(6)if spec['extra_mask']>>j&1}
    removed|={(1,j)for j in range(6)if spec['extra_mask']>>(6+j)&1}
    gone={(i%q,j)for i,j in removed}
    vertices=[(i,j)for i in range(q)for j in range(6)if(i,j)not in gone]
    index={v:i for i,v in enumerate(vertices)}
    def step(v,which):
        i,j=v
        return (((i+(j==5))%q,(j+1)%6)if which==0 else((i+vol[j])%q,sig[j]))
    low=(spec['source_column']%q,spec['source_type']);arcs=[];lowtarget=None
    for v in vertices:
        outs=[]
        for which in range(2):
            w=step(v,which)
            while w in gone:w=step(w,which)
            if v==low and which==spec['which']:lowtarget=w
            else:outs.append(w)
        assert len(set(outs))==len(outs)and v not in outs
        arcs.extend((index[v],index[w])for w in outs)
    assert len(vertices)==n and len(arcs)==2*n-1
    u,v=index[low],index[lowtarget]
    assert u!=v and(u,v)not in arcs
    assert [sum(a==x for a,b in arcs)for x in range(n)]==[1 if x==u else 2 for x in range(n)]
    assert [sum(b==x for a,b in arcs)for x in range(n)]==[1 if x==v else 2 for x in range(n)]
    return dict(n=n,q=q,removed=r,vertices=vertices,arcs=arcs,low_source=u,low_recipient=v)


def generate():
    output=[]
    for spec in SPECS:
        records=[]
        for h in[None]+list(range(-10,11)):
            strip=make_strip(spec,1000 if h is None else h)
            row=check_strip(strip,M=5,R=7,retain=True,direction=spec['direction'],max_jump=2,
                            broad_transfer=spec['broad'],delivery_distances=(2,3)if spec['broad']else(2,))
            assert row['failures']==0,(spec,h,row['failures'])
            row['anchor']=h;records.append(row)
        sig,vol=patterns()[spec['pattern_index']]
        actual=make_strip(spec)
        part=dict(spec=spec,sigma=sig,voltage=vol,deleted_arc=[actual.low_source,actual.low_recipient],records=records)
        output.append(part)
        print(json.dumps({'removed':spec['removed'],'status':'passed','objectives':sum(len(r['records'])for r in records),
                          'transfer_max':max(max(c['bounds'])for r in records for c in r['records']if c['target']is None),
                          'delivery_max':max(max(c['bounds'])for r in records for c in r['records']if c['target']is not None)}),flush=True)
    sources=['src/odd_endpoint_all_residues.py','src/odd_endpoint_six.py','src/five_type_certificate.py','src/sparse_composition_smoothing.py','research/sparse-composition-q6-input.txt']
    receipt={'status':'primary verified','M':5,'R':7,'max_jump':2,'anchor_range':[-10,10],
             'minimum_q':25,'minimum_n':145,'cases':output,
             'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()for p in sources}}
    target=ROOT/'research/odd-endpoint-all-residues-certificates.json.gz'
    with gzip.open(target,'wt')as f:json.dump(receipt,f,separators=(',',':'))
    # Validate graph arithmetic at the first representative of each residue.
    checks=[graph(n)for n in range(145,151)]
    (ROOT/'research/odd-endpoint-all-residues-graphs.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps({'status':'complete','path':str(target),'cases':len(output)}))
    return receipt


if __name__=='__main__':generate()

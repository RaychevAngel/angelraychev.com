#!/usr/bin/env python3
"""Bounded exploration of non-ring degree-two lifts; no infinite claim."""
from pathlib import Path
import hashlib, json, random, sys, time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from game_solver import neighborhoods,recipient_fast,recipient_explicit,verify_certificate
ROOT=Path(__file__).resolve().parents[1]

def six_lift(k,p,q):
    pi=[0]*k
    for i,x in enumerate(p):pi[x]=i
    arcs=[]
    for i in range(k):
        for j in range(6):
            arcs.append((6*i+j,6*i+j+1 if j<5 else 6*p[i]))
        arcs += [(6*i,6*i+5),(6*i+1,6*q[i]+4),(6*i+2,6*q[i]+1),
                 (6*i+3,6*pi[i]),(6*i+4,6*q[i]+2),(6*i+5,6*pi[i]+3)]
    return 6*k,arcs

def lamplighter(k,q=3):
    # Position (cursor, lamp configuration). Each move advances the cursor;
    # choose whether to add one to the lamp at the departing cursor.
    size=q**k; arcs=[]
    for cursor in range(k):
        for lamps in range(size):
            s=cursor*size+lamps
            nxt=(cursor+1)%k
            digit=(lamps//(q**cursor))%q
            toggled=lamps+q**cursor*(1 if digit<q-1 else 1-q)
            arcs += [(s,nxt*size+lamps),(s,nxt*size+toggled)]
    return k*size,arcs

def test(n,arcs,targets=None,dual=False):
    out,arcs=neighborhoods(n,arcs)
    indeg=[0]*n
    for u,v in arcs:indeg[v]+=1
    assert len(arcs)==2*n and all(x.bit_count()==3 for x in out) and set(indeg)=={2}
    source_camps=[(s,c) for s in range(n) for c in range(n) if c!=s and (out[s]^(1<<s))&~out[c]==0]
    data={'n':n,'source_camps':source_camps,'universal':True,'max_moves':0,'checked_targets':[]}
    for t in (range(n) if targets is None else targets):
        wins,layers=recipient_fast(n,out,t,True)
        data['checked_targets'].append(t);data['max_moves']=max(data['max_moves'],len(layers)-1)
        bad=[(r,c) for r in range(n) for c in range(n) if r!=c and not (wins[r]>>c&1)]
        if dual:
            other,cert=recipient_explicit(n,out,t,True)
            assert other==wins and verify_certificate(n,out,cert)
        if bad:
            data.update(universal=False,failed_target=t,failed_starts=len(bad),first_failed_start=bad[0]);break
    data['arcs']=arcs
    return data

def main():
    begin=time.monotonic();records=[];rng=random.Random(912206)
    for k in (4,6,8):
        p=list(range(1,k))+[0]
        for mode in ('ring','inverse','random0','random1','random2','random3'):
            q=p[:] if mode=='ring' else [k-1]+list(range(k-1))
            if mode.startswith('random'):q=list(range(k));rng.shuffle(q)
            n,arcs=six_lift(k,p,q)
            d=test(n,arcs,dual=n<=24);d.update(family='six_lift',k=k,p=p,q=q,mode=mode)
            records.append(d);print({x:y for x,y in d.items() if x not in ('arcs','source_camps','checked_targets','p','q')},flush=True)
    for k in (2,3):
        n,arcs=lamplighter(k)
        # The group action makes this graph vertex transitive; only target0.
        d=test(n,arcs,targets=[0],dual=True);d.update(family='ternary_lamplighter',k=k,target_scope='target 0; Cayley transitivity requires written verification')
        records.append(d);print({x:y for x,y in d.items() if x not in ('arcs','source_camps','checked_targets')},flush=True)
    artifact={'scope':'finite exploration; no general universality claim','seconds':time.monotonic()-begin,'records':records,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'research/composition-interface-lifts.json').write_text(json.dumps(artifact,indent=2)+'\n')

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Bounded untrusted probe: optimistic prefix games, no theorem is emitted."""
import argparse,json,time
from lean_finite_threshold_prototype import eligible
from lean_finite_regular_producer import primary
N=9;ALL=511

def optimistic(a,p):
    used=sum(1<<v for v in p)
    low=[(1<<r)|(1<<a[r])|((1<<p[r]) if r<len(p) else 0) for r in range(N)]
    high=[low[r] if r<len(p) else low[r]|(ALL&~(used|(1<<r)|(1<<a[r]))) for r in range(N)]
    choices=[[z for z in range(N) if high[r]>>z&1] for r in range(N)]
    possible=eligible(a,p);masks=[]
    for t in range(N):
        if not any(row>>t&1 for row in possible):continue
        W=[ALL if r==t else 0 for r in range(N)]
        while True:
            safe=[ALL if z==t else sum(1<<c for c in range(N) if not(low[c]>>z&1) and not(low[c]&~W[z])) for z in range(N)]
            nxt=[]
            for r in range(N):
                if r==t:nxt.append(ALL);continue
                w=0
                for z in choices[r]:w|=safe[z]
                nxt.append(w&~(1<<r))
            if nxt==W:break
            W=nxt
        for s in range(N):
            if (W[s]|(1<<s))!=ALL:possible[s]&=~(1<<t)
        masks.append((t,sum((ALL&~W[r])<<(9*r) for r in range(N))))
    return sum(row.bit_count() for row in possible),masks

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--partition',default='9');ap.add_argument('--nodes',type=int,default=5000);ap.add_argument('--seconds',type=float,default=25);ap.add_argument('--min-depth',type=int,default=5);ap.add_argument('--min-displacement',action='store_true');ap.add_argument('--displacement-window',type=int,default=1);args=ap.parse_args()
    a=primary(tuple(map(int,args.partition.split(','))));start=time.monotonic()
    counts=dict(nodes=0,local=0,optimistic=0,complete=0,branches=0,selected_masks=0,normalization=0);depths={};examples=[];mask_hist={}
    def dfs(p):
        counts['nodes']+=1
        if counts['nodes']>args.nodes or time.monotonic()-start>args.seconds:raise TimeoutError
        if args.min_displacement and p:
            displaced=[(v-i)%9 for i,v in enumerate(p)]
            violation=False
            for r in range(len(p)):
                width=0
                while width<args.displacement_window and width<len(p) and (r+width)%9<len(p):width+=1
                if displaced[:width]>[displaced[(r+j)%9] for j in range(width)]:violation=True;break
            if violation:counts['normalization']+=1;return
        local=sum(v.bit_count() for v in eligible(a,p))
        if local<=30:counts['local']+=1;return
        if len(p)>=args.min_depth:
            upper,masks=optimistic(a,p)
            if upper<=30:
                counts['optimistic']+=1;depths[len(p)]=depths.get(len(p),0)+1
                remain=eligible(a,p);selected=[]
                candidates=list(masks)
                def gain(tm):
                    t,mask=tm
                    return sum(bool(remain[s]>>t&1) and bool(((mask>>(9*s))&ALL)&~(1<<s)) for s in range(N))
                while sum(row.bit_count() for row in remain)>30:
                    tm=max(candidates,key=gain);candidates.remove(tm);selected.append(tm);t,mask=tm
                    for s in range(N):
                        if ((mask>>(9*s))&ALL)&~(1<<s):remain[s]&=~(1<<t)
                masks=selected;counts['selected_masks']+=len(masks);mask_hist[len(masks)]=mask_hist.get(len(masks),0)+1
                if len(examples)<3:examples.append(dict(prefix=p,local=local,upper=upper,masks=masks))
                return
        if len(p)==9:counts['complete']+=1;raise AssertionError(('counterexample',p))
        counts['branches']+=1;k=len(p)
        for v in range(N):
            if v not in p and v!=k and v!=a[k]:dfs(p+[v])
    complete=True
    try:dfs([])
    except TimeoutError:complete=False
    print(json.dumps(dict(partition=args.partition,complete=complete,counts=counts,depths=depths,mask_hist=mask_hist,seconds=time.monotonic()-start,examples=examples)))
if __name__=='__main__':main()

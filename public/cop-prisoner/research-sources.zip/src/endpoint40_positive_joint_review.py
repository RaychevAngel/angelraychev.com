#!/usr/bin/env python3
"""Independent positive joint inventory, boundary arithmetic, and every-leaf replay."""
import argparse,itertools,json,hashlib,subprocess
from collections import Counter
from pathlib import Path
from small_case_certificate_review import review
ROOT=Path(__file__).resolve().parents[1]
def expected_patterns(n,m,T):
 result=set()
 incoming=[p for p in itertools.combinations_with_replacement(range(1,n),n) if sum(p)==m]
 for out in itertools.combinations_with_replacement(range(1,n-1),n):
  if sum(out)!=m:continue
  out=out[::-1];q=sum(d>=2 for d in out);lowout=n-q
  if sum(n-1-d for d in out if d>=2)<T:continue
  blocks=[(d,len(list(g))) for d,g in itertools.groupby(out)]
  for inside in incoming:
   r=sum(e>=2 for e in inside);lowin=n-r
   if sum(n-1-e for e in inside if e>=2)<T:continue
   counts=Counter(inside)
   def assign(block,prefix):
    if block==len(blocks):
     b=sum(d>=2 and e>=2 for d,e in prefix)
     if q*r-b-m+lowout+lowin>=T:result.add(prefix)
     return
    d,size=blocks[block];available=tuple(k for k,v in counts.items() if v)
    for group in itertools.combinations_with_replacement(available,size):
     used=Counter(group)
     if any(v>counts[k] for k,v in used.items()):continue
     counts.subtract(used);assign(block+1,prefix+tuple((d,e) for e in sorted(group,reverse=True)));counts.update(used)
   assign(0,())
 return result
def main():
 p=argparse.ArgumentParser();p.add_argument('n',type=int);p.add_argument('m',type=int);p.add_argument('value',type=int);a=p.parse_args()
 n,m,v=a.n,a.m,a.value;T=v+1;assert n==9 and m in range(19,23)
 stem=f'endpoint40_positive_n{n}_m{m}_t{T}';j=json.loads((ROOT/'research'/f'{stem}.json').read_text())
 given=[tuple(map(tuple,row)) for row in j['joint_patterns']];expected=expected_patterns(n,m,T)
 assert len(given)==len(set(given))==len(expected) and set(given)==expected
 words=list(map(int,(ROOT/'research'/f'{stem}.txt').read_text().split()))
 assert words==[len(given)]+[x for row in given for pair in row for x in pair]
 log=f'research/{stem}_run.jsonl';rows=[json.loads(s) for s in (ROOT/log).read_text().splitlines()];end=rows[-1]
 assert (end['n'],end['m'],end['threshold'],end['mode'])==(n,m,v,0)
 assert end['complete'] and not end['counterexample_found'] and end['degree_patterns']==end['total_degree_patterns']==len(expected)
 assert len(rows)-1==end['game_decisions']
 prior=json.loads((ROOT/'research/endpoint40_joint_n9_m23_t45_receipt.json').read_text())
 assert hashlib.sha256((ROOT/'src/endpoint40_small_joint.cpp').read_bytes()).hexdigest()==prior['sha256']['src/endpoint40_small_joint.cpp']
 table=dict(zip(range(11,23),[8,9,11,13,15,19,19,21,22,24,25,28]))
 boundary=[table[m-d]+(n-1-d if d>=2 else 0) for d in range(n)]
 assert max(boundary)<=v
 run=subprocess.run([str(ROOT/'src/endpoint40_small_leaf_replay.bin'),log],cwd=ROOT,text=True,capture_output=True,check=True)
 replay=json.loads(run.stdout);assert replay['all_literal_leaves_replayed']==end['game_decisions']
 replayfile=f'research/{stem}_leaf_replay.jsonl';(ROOT/replayfile).write_text(run.stdout)
 lower=next(g for g in json.loads((ROOT/'research/finish_constructions_certificates.json').read_text()) if(g['n'],g['m'],g['I'])==(n,m,v))
 lowerfile=f'research/{stem}_lower_certificate.json';(ROOT/lowerfile).write_text(json.dumps(lower,separators=(',',':'))+'\n');lower_review=review(lower)
 tests=json.loads((ROOT/'research/endpoint40_positive_joint_prune_review_tests.json').read_text());assert tests['status']=='passed'
 files=[log,f'research/{stem}.json',f'research/{stem}.txt',replayfile,lowerfile,
  'src/endpoint40_positive_joint_review.py','src/endpoint40_positive_joint_inputs.py','src/endpoint40_small_joint.cpp',
  'src/endpoint40_positive_joint_prune_review.cpp','research/endpoint40_positive_joint_prune_review_tests.json',
  'src/endpoint40_small_leaf_replay.cpp','src/small_case_certificate_review.py','research/endpoint40_positive_joint_proof.md',
  'research/endpoint40_small_joint_proof.md','research/endpoint40_joint_n9_m23_t45_receipt.json',
  'research/endpoint40_n8_sparse_receipt.json','research/endpoint40_n8_low_receipt.json','research/endpoint40_tiny_live_review.json',
  'paper/small-arcs-resume.md']
 result={'verified':True,'n':n,'m':m,'M':v,'target_excluded':T,'independent_joint_patterns':len(expected),
  'zero_degree_boundary_by_other_degree':boundary,'zero_degree_upper':max(boundary),'primary':end,'every_leaf_replay':replay,
  'lower':lower_review,'actual_source_prune_tests':tests,
  'boundary':'Ordinary source/sink reduction to positive degrees and a complete frozen coupled traversal, independent exact input coverage, every-leaf independent game replay, and full lower ranks. No second complete traversal or Lean claim.',
  'sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files}}
 (ROOT/'research'/f'{stem}_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ('verified','n','m','M','independent_joint_patterns','zero_degree_upper','every_leaf_replay','lower')},indent=2))
if __name__=='__main__':main()

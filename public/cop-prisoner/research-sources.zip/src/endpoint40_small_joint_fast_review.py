#!/usr/bin/env python3
"""Review the equivalent incremental-loss maximum and every literal game leaf."""
import argparse,hashlib,json,subprocess
from pathlib import Path
from endpoint40_small_joint_review import independent_patterns
from endpoint40_positive_joint_review import expected_patterns
from game_solver import solve_graph
from small_case_certificate_review import review
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('n',type=int);p.add_argument('m',type=int);p.add_argument('initial',type=int);p.add_argument('lower');p.add_argument('--positive',action='store_true');a=p.parse_args()
 n,m,initial=a.n,a.m,a.initial;T=initial+1
 if a.positive:
  assert n==9 and m in range(19,23)
  stem=f'endpoint40_positive_n{n}_m{m}_t{T}';expected=expected_patterns(n,m,T)
  table=dict(zip(range(11,23),[8,9,11,13,15,19,19,21,22,24,25,28]))
  boundary=[table[m-d]+(n-1-d if d>=2 else 0) for d in range(n)];assert max(boundary)<=initial
 else:
  assert n*(n-1)-m-T<n-2
  stem=f'endpoint40_joint_n{n}_m{m}_t{T}';expected=independent_patterns(n,m);boundary=None
 inputfile=f'research/{stem}.json';given=[tuple(map(tuple,row)) for row in json.loads((ROOT/inputfile).read_text())['joint_patterns']]
 assert len(given)==len(set(given))==len(expected) and set(given)==expected
 words=list(map(int,(ROOT/'research'/f'{stem}.txt').read_text().split()))
 assert words==[len(given)]+[x for row in given for pair in row for x in pair]
 source=(ROOT/'src/endpoint40_small_joint.cpp').read_text()
 expected_source=source.replace('// Small-main coupled in/out-degree completion with literal leaves.', '// Small-main complete maximum with a monotone incumbent and literal leaves.')
 expected_source=expected_source.replace('int n,all,budget,mode;','int n,all,budget,mode,initial_threshold;')
 expected_source=expected_source.replace('if(value>threshold)found=true;','if(value>threshold)threshold=value;')
 expected_source=expected_source.replace('all=(1<<n)-1;int totalpatterns;','initial_threshold=threshold;all=(1<<n)-1;int totalpatterns;')
 expected_source=expected_source.replace('<<",\\\"counterexample_found\\\":','<<",\\\"initial_threshold\\\":"<<initial_threshold<<",\\\"counterexample_found\\\":')
 assert expected_source==(ROOT/'src/endpoint40_small_joint_max.cpp').read_text()
 first=expected_source.index('bool camping(int row){');last=expected_source.index('\nbool capacities',first)
 expected_source=expected_source[:first]+(ROOT/'research/endpoint40_small_joint_fast_camping.txt').read_text()+expected_source[last:]
 assert expected_source==(ROOT/'src/endpoint40_small_joint_fast.cpp').read_text()
 equivalence=json.loads((ROOT/'research/endpoint40_small_joint_fast_prune_review_tests.json').read_text());assert equivalence['status']=='passed'
 log=f'research/{stem}_fast_run.jsonl';rows=[json.loads(line) for line in (ROOT/log).read_text().splitlines()];end=rows[-1]
 assert end['complete'] and not end['counterexample_found']
 assert (end['n'],end['m'],end['initial_threshold'],end['mode'])==(n,m,initial,0)
 assert end['degree_patterns']==end['total_degree_patterns']==len(expected)
 assert end['game_decisions']==len(rows)-1
 value=end['threshold'];assert value==max(initial,end['maximum_threshold_survivor'])
 assert max([r['I'] for r in rows[:-1]],default=-1)==end['maximum_threshold_survivor']
 lower=json.loads((ROOT/a.lower).read_text());assert (lower['n'],lower['m'],lower['I'])==(n,m,initial);initial_review=review(lower)
 if value>initial:lower=solve_graph(n,end['arcs'],certificates=True,crosscheck=True)
 assert (lower['n'],lower['m'],lower['I'])==(n,m,value);lower_review=review(lower)
 lowerfile=f'research/{stem}_fast_lower_certificate.json';(ROOT/lowerfile).write_text(json.dumps(lower,separators=(',',':'))+'\n')
 run=subprocess.run([str(ROOT/'src/endpoint40_small_leaf_replay.bin'),log],cwd=ROOT,text=True,capture_output=True,check=True)
 replay=json.loads(run.stdout);assert replay['all_literal_leaves_replayed']==end['game_decisions'] and replay['target_I']==value+1
 replayfile=f'research/{stem}_fast_leaf_replay.jsonl';(ROOT/replayfile).write_text(run.stdout)
 files=[inputfile,f'research/{stem}.txt',log,lowerfile,replayfile,a.lower,'src/endpoint40_small_joint_fast_review.py','src/endpoint40_small_joint_max_review.py','src/endpoint40_small_joint_fast.cpp',
  'research/endpoint40_small_joint_fast_camping.txt','src/endpoint40_small_joint_fast_prune_review.cpp',
  'research/endpoint40_small_joint_fast_prune_review_tests.json','research/endpoint40_small_joint_fast_proof.md',
  'src/endpoint40_small_joint.cpp','src/endpoint40_small_joint_max.cpp','src/endpoint40_small_leaf_replay.cpp',
  'src/endpoint40_small_joint_review.py','src/endpoint40_positive_joint_review.py','src/game_solver.py','src/small_case_certificate_review.py',
  'research/endpoint40_small_joint_proof.md','research/endpoint40_small_joint_max_proof.md','research/endpoint40_small_joint_prune_review_tests.json']
 if a.positive:files+=['research/endpoint40_positive_joint_proof.md','research/endpoint40_positive_joint_prune_review_tests.json',
  'src/endpoint40_positive_joint_prune_review.cpp','research/endpoint40_n8_sparse_receipt.json','research/endpoint40_n8_low_receipt.json',
  'research/endpoint40_tiny_live_review.json','paper/small-arcs-resume.md']
 result={'verified':True,'n':n,'m':m,'M':value,'initial_lower':initial,'independent_joint_patterns':len(expected),
  'loss_count_equivalence_tests':equivalence,'zero_degree_boundary_by_other_degree':boundary,'primary':end,'every_leaf_replay':replay,'initial_lower_review':initial_review,'lower':lower_review,
  'boundary':'Complete monotone-incumbent traversal with an equivalent incremental camping-loss counter; independent input coverage, every-leaf independent game replay and full final lower ranks. No second full graph traversal or Lean claim.',
  'sha256':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files}}
 (ROOT/'research'/f'{stem}_fast_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ('verified','n','m','M','independent_joint_patterns','primary','every_leaf_replay','lower')},indent=2))
if __name__=='__main__':main()

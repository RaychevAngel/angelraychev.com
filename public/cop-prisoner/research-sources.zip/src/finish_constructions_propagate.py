#!/usr/bin/env python3
"""Finite adjacent and subset families from the new literal anchors."""
import itertools
import json
import time
from small_plateau_probe import ROOT,evaluate,certificate
from small_case_certificate_review import review


def main(seconds=90):
    start=time.monotonic();pool={};calls=0;events=[];families=[]
    ranges={8:(17,39),9:(19,24),10:(19,28)}
    universe={n:set(itertools.permutations(range(n),2)) for n in ranges}
    def test(n,arcs,why):
        nonlocal calls
        m=len(arcs)
        if n not in ranges or not ranges[n][0]<=m<=ranges[n][1]:return
        arcs=frozenset(arcs);key=(n,m);rows=pool.setdefault(key,[])
        if any(x['arcs']==arcs for x in rows):return
        value=evaluate(n,arcs)[:2];calls+=1
        old=rows[0]['value'][0] if rows else -1
        rows.append(dict(arcs=arcs,value=value,why=why));rows.sort(key=lambda r:r['value'],reverse=True);del rows[3:]
        if value[0]>old and why!='seed':
            event=dict(n=n,m=m,I=value[0],why=why,seconds=round(time.monotonic()-start,3));events.append(event);print(json.dumps(event),flush=True)
    seeds=json.loads((ROOT/'research/finish_constructions_certificates.json').read_text())
    general=json.loads((ROOT/'research/small-exceptional-general-certificates.json').read_text())
    seeds.extend(general)
    stagebase=json.loads((ROOT/'research/small-plateau-small-stage-records.json').read_text())['records']
    seeds.extend(dict(n=g['n'],m=len(g['base_arcs'])+k,arcs=g['base_arcs']+g['added'][:k])
                 for g in stagebase for k in range(len(g['added'])+1))
    for g in seeds:test(g['n'],set(map(tuple,g['arcs'])),'seed')
    baseline={f'{n},{m}':rows[0]['value'][0] for (n,m),rows in pool.items()}
    def sweep():
        for direction in [1,-1]:
            for n,(lo,hi) in ranges.items():
                ms=range(lo,hi) if direction==1 else range(hi,lo,-1)
                for m in ms:
                    for row in list(pool.get((n,m),[])):
                        arcs=row['arcs'];options=universe[n]-arcs if direction==1 else arcs
                        for edge in sorted(options):test(n,arcs|{edge} if direction==1 else arcs-{edge},'finite_adjacent_sweep')
    sweep()
    jobs=[]
    for n,m,lo,hi in [(8,34,35,38),(8,33,35,38),(8,32,35,38),
                      (10,26,21,25),(9,24,19,23),(8,24,17,23)]:
        if (n,m) not in pool:continue
        arcs=set(pool[(n,m)][0]['arcs']);jobs.append((n,m,lo,hi,arcs))
    for n,m,lo,hi,arcs in jobs:
        for target in range(hi,lo-1,-1) if hi<m else range(lo,hi+1):
            options=sorted(arcs if target<m else universe[n]-arcs); k=abs(target-m);count=0;complete=True
            for subset in itertools.combinations(options,k):
                if time.monotonic()-start>seconds:complete=False;break
                candidate=arcs-set(subset) if target<m else arcs|set(subset)
                test(n,candidate,f'fixed_anchor_{n}_{m}_to_{target}');count+=1
            families.append(dict(n=n,anchor_m=m,target_m=target,candidates=count,complete=complete))
            if not complete:break
        if time.monotonic()-start>seconds:break
    sweep()
    graphs=[];receipts=[]
    for (n,m),rows in sorted(pool.items()):
        row=rows[0]
        if row['value'][0]<=baseline[f'{n},{m}']:continue
        g=certificate(n,row['arcs']);g['discovery']=row['why'];assert g['I']==row['value'][0]
        graphs.append(g);receipts.append(review(g))
    (ROOT/'research/finish_constructions_propagated_certificates.json').write_text(json.dumps(graphs,indent=2)+'\n')
    result=dict(seconds=time.monotonic()-start,calls=calls,events=events,families=families,records=receipts,
                baseline=baseline,scope='Improved lower witnesses only. Subset-family completeness is not global graph completeness.')
    (ROOT/'research/finish_constructions_propagated_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__=='__main__':main()

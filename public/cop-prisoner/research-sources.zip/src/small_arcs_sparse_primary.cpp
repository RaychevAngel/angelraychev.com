// Small-arc specialization: add the proved degree-incidence bound (1).
// Complete fixed-degree row-splitting enumeration, bounded by wall time.
// Unassigned vertices with equal prescribed degree and equal incoming pattern
// from assigned rows are exchangeable. The new row takes a prefix of each
// such cell. This is symmetry reduction, not a local mathematical obstruction.
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;int n,target,minm,maxm,all,D[12],O[12],incoming[12],best=0,BO[12];vector<int> masks[12][12];long long nodes=0,leaves=0,statics=0,profiles=0;bool complete=true,found=false;double limit;auto began=chrono::steady_clock::now();
int game(){int I=0,W[12],safe[12],NW[12];for(int t=0;t<n;t++){fill(W,W+n,0);W[t]=all;while(true){for(int v=0;v<n;v++){safe[v]=0;for(int c=0;c<n;c++)if(!((O[c]|1<<c)&~W[v]))safe[v]|=1<<c;}bool diff=false;for(int r=0;r<n;r++){int w=0,x=O[r]|1<<r;while(x){int v=__builtin_ctz(x);x&=x-1;w|=safe[v];}if(r!=t)w&=~(1<<r);NW[r]=w;diff|=w!=W[r];}copy(NW,NW+n,W);if(!diff)break;}for(int r=0;r<n;r++)if(r!=t&&!(O[r]>>t&1)&&(W[r]|1<<r)==all)I++;}return I;}
bool possible(int row){
 int source_cap=0,qcap=0;
 for(int s=0;s<n;s++)if(D[s]>=2){
  bool killed=false;
  if(s<row){
   if(D[s]==2)for(int z=0;z<n;z++)if(D[z]==0&&(O[s]>>z&1))killed=true;
   for(int c=0;c<row;c++)if(c!=s&&(O[s]&~(O[c]|1<<c))==0)killed=true;
  }
  if(!killed){source_cap+=n-1-D[s];qcap++;}
 }
 if(source_cap<target)return false;
 int column_cap=0,already=0,cost_one=0,cost_two=0,remaining=0;
 for(int s=row;s<n;s++)remaining+=D[s];
 for(int t=0;t<n;t++){
  int d=__builtin_popcount((unsigned)incoming[t]);
  if(d+n-row-(t>=row)<2)continue;
  column_cap+=n-1-max(2,d);
  if(d>=2)already++;else if(d==1)cost_one++;else cost_two++;
 }
 if(column_cap<target)return false;
 int one=min(cost_one,remaining),rmax=already+one+min(cost_two,(remaining-one)/2);
 int numerical=0;
 for(int r=0;r<=rmax;r++)numerical=max(numerical,qcap*r-max(0,qcap+r-n)-max(0,2*qcap+2*r-maxm));
 return numerical>=target;
}
void visit(int row){if(!complete||found)return;if((++nodes%65536)==0&&chrono::duration<double>(chrono::steady_clock::now()-began).count()>limit){complete=false;return;}if(!possible(row))return;if(row==n){leaves++;int upper=0;for(int s=0;s<n;s++)if(D[s]>=2){bool blocked=false;if(D[s]==2)for(int z=0;z<n;z++)if(D[z]==0&&(O[s]>>z&1))blocked=true;for(int c=0;c<n;c++)if(c!=s&&(O[s]&~(O[c]|1<<c))==0){blocked=true;break;}if(blocked)continue;for(int t=0;t<n;t++)if(s!=t&&!(O[s]>>t&1)&&__builtin_popcount((unsigned)incoming[t])>=2){bool b=false;for(int c=0;c<n;c++)if(c!=s&&(incoming[t]&~(O[c]|1<<c))==0){b=true;break;}upper+=!b;}}if(upper<target)return;statics++;int I=game();if(I>best){best=I;copy(O,O+n,BO);}if(I>=target)found=true;return;}
for(int mask:masks[row][D[row]]){bool canonical=true;for(int v=row+2;v<n;v++)if(D[v]==D[v-1]&&incoming[v]==incoming[v-1]&&(mask>>v&1)&&!(mask>>(v-1)&1)){canonical=false;break;}if(!canonical)continue;O[row]=mask;for(int b=mask;b;b&=b-1)incoming[__builtin_ctz((unsigned)b)]|=1<<row;visit(row+1);for(int b=mask;b;b&=b-1)incoming[__builtin_ctz((unsigned)b)]&=~(1<<row);if(!complete||found)return;}}
void degrees(int i,int lower,int total){if(!complete||found)return;if(i==n){if(total<minm||total>maxm)return;profiles++;visit(0);return;}int minactive=(target+n-4)/(n-3),inactive=n-minactive;for(int d=max(lower,i<inactive?0:2);d<n;d++){if(total+d*(n-i)>maxm)break;if(total+d+(n-i-1)*(n-1)<minm)continue;D[i]=d;degrees(i+1,d,total+d);}}
int main(int argc,char**argv){n=atoi(argv[1]);target=atoi(argv[2]);minm=atoi(argv[3]);maxm=atoi(argv[4]);limit=atof(argv[5]);all=(1<<n)-1;for(int u=0;u<n;u++)for(int mask=0;mask<=all;mask++)if(!(mask>>u&1))masks[u][__builtin_popcount((unsigned)mask)].push_back(mask);degrees(0,0,0);cout<<"{\"n\":"<<n<<",\"target_I\":"<<target<<",\"min_m\":"<<minm<<",\"max_m\":"<<maxm<<",\"complete\":"<<(complete&&!found?"true":"false")<<",\"counterexample_found\":"<<(found?"true":"false")<<",\"profiles\":"<<profiles<<",\"nodes\":"<<nodes<<",\"leaves\":"<<leaves<<",\"static_survivors\":"<<statics<<",\"best_I\":"<<best<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-began).count()<<",\"arcs\":[";bool first=true;if(best)for(int u=0;u<n;u++)for(int v=0;v<n;v++)if(BO[u]>>v&1){if(!first)cout<<",";first=false;cout<<"["<<u<<","<<v<<"]";}cout<<"]}\n";}

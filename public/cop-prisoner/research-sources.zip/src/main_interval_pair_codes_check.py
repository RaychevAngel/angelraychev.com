#!/usr/bin/env python3
"""Independent pair witnesses, arithmetic coverage, and output comparisons.

Proof obligations and the finite interval union are rebuilt from the written
formulas and literal data. Producer imports are used only in compare_outputs
and in explicit API-preservation comparisons, never to establish the witness
or coverage claims. No game solver or graph discovery is used.
"""
from fractions import Fraction
from itertools import combinations
from math import comb, gcd
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
INPUTS = ['research/six-circle-recipes.json', 'research/sparse-staged-records.json',
          'research/sparse-interface-third-proof-registry.json',
          'research/routing-defect-phase2-dense-tiny-checks.json']
RETAINED_SOURCES = [
    'src/main_interval_half_density.py', 'src/main_interval_resume.py',
    'src/main_interval_layered.py', 'src/main_interval_six_circle.py',
    'src/main_interval_reduced_hubs.py', 'src/sparse_staged.py',
    'src/sparse_finite_bridge_construct.py', 'src/sparse-interface-third.py',
    'src/five_type_certificate.py', 'src/core_code_all_parities.py',
    'research/sparse-finite-bridge-witnesses.json',
]


def load(path):
    return json.loads((ROOT/path).read_text())


def least_core(n):
    k = 6
    while k*(k-3) < n:
        k += 1
    return k


def pair_base(n):
    k = least_core(n)
    return (4*k-2)*n-2*k*(2*k+1)


def pair_list(k):
    return [set((i+part*k, j+part*k)) for part in (0, 1)
            for i in range(k) for j in range(i+1, k)
            if min(j-i, k-j+i) >= 3]


def witness_check(k, K):
    """Build adjacency by rows and check every full-envelope cop position."""
    n = 2*k+len(K)
    base = []
    for s in range(n):
        if s < k:
            excluded = {s, k+s, k+(s-1) % k}
            row = set(range(n))-excluded
        elif s < 2*k:
            i = s-k
            excluded = {s, (i+4) % k, (i+6) % k}
            row = set(range(n))-excluded
        else:
            row = set(range(2*k))-K[s-2*k]
        base.append(row)
    closed = [row | {s} | (set(range(2*k, n)) if s >= 2*k else set())
              for s, row in enumerate(base)]
    incoming = [{s for s in range(n) if t in base[s]} for t in range(n)]
    masks = [sum(1 << v for v in row) for row in closed]
    obligations = 0
    for s in range(n):
        for t in range(n):
            if s == t or t in base[s]:
                continue
            mids = sum(1 << v for v in base[s] & incoming[t])
            for c in range(n):
                if c != s:
                    assert mids & ~masks[c], (k, K, s, t, c)
                    obligations += 1
    low = sum(map(len, base))
    high = sum(len(row)-1 for row in closed)
    expected = 2*k*(2*k-3)+4*k*len(K)-sum(map(len, K))
    assert low == expected and high-low == len(K)*(len(K)-1)
    return dict(k=k, n=n, codes=len(K), m_min=low, m_max=high,
                obligations=obligations)


def pair_checks():
    result = [witness_check(5, [])]
    for k in range(6, 15):
        K = pair_list(k)
        assert len(K) == k*(k-5)
        for q in sorted({0, 1, len(K)//2, len(K)}):
            row = witness_check(k, K[:q])
            assert row['m_max'] == row['n']*(row['n']-3)
            result.append(row)
    # Mixed pair/triple antichains exercise both sides of the generalized
    # theorem. Equal-size larger codes remain covered without alteration.
    for k in (6, 7, 8, 9):
        triples = [set(part*k+i for i in triple) for part in (0, 1)
                   for triple in combinations(range(k), 3)
                   if all((i+(2 if part == 0 else 1)) % k not in triple
                          for i in triple)]
        result.append(witness_check(k, triples[:12]))
        pair = pair_list(k)[0]
        mixed = [pair]+[s for s in triples if not pair <= s][:10]
        result.append(witness_check(k, mixed))
    return result


def arithmetic_checks():
    # These are the exact boundary constants in the ordinary proof.
    assert Fraction(828**2, 7)-123*828+3906 == Fraction(18, 7)
    assert Fraction(869**2, 7)-127*869+4160 == Fraction(11740, 7)
    assert 84*(84-12)//2-pair_base(84) == 2
    assert Fraction(91*(91-12), 2)-pair_base(91) == Fraction(17, 2)
    rows = []
    for n in range(79, 10001):
        k = least_core(n)
        assert 2*k <= n <= k*(k-3)
        low = pair_base(n)
        protected = n*((n+6)//7-1)
        if n <= 827:
            h = (7 if n % 7 else 11) if n <= 108 else next(
                h for h in (7, 11, 15, 19) if gcd(n, h) == 1)
            assert h >= 7 and h % 4 == 3 and gcd(h, n) == 1 and 2*h+2 <= n
            # Count literal representatives instead of the producer's formula.
            values = {v for v in range(n-h+1) if v % 4 < 2} | {h}
            values.discard(2*h-1)
            cap = n*(len(values)-1)
            assert protected >= 5*n and cap >= low
            if n >= 109:
                u = k-13
                N = k*k-5*k+5
                polynomial = u**4+34*u**3+379*u*u+1398*u+205
                assert N*N-(8*k+16)*N+8*k*k+4*k == polynomial > 0
                assert n >= N and N-4*k-8 > 0
            if n in (79, 84, 89, 91, 98, 105, 108, 109, 827):
                rows.append(dict(n=n, k=k, h=h, pair_min=low, circle_max=cap))
        else:
            assert protected >= low
            if k >= 33:
                assert n >= k*k-5*k+5 >= 28*k-7
    return dict(orders=[79, 10000], boundary_rows=rows,
                proof='Ordinary all-order inequalities are stated in the manuscript; the finite sweep checks their implementation.')


def finite_intervals(n, data):
    """Rebuild retained finite families directly; no dispatcher imports."""
    out = [(2*n, 2*n, 'endpoint')]
    for record in data[1]['records']:
        if record['n'] == n:
            base = len(record['base_arcs'])
            for stage in record['stages']:
                assert stage['m_min'] == base+stage['prefix_start']
                assert stage['m_max'] == base+stage['prefix_end']
                assert 0 <= stage['prefix_start'] < stage['prefix_end'] <= len(record['added'])
                out.append((stage['m_min'], stage['m_max'], 'staged'))
    for row in data[2]['records']:
        if row['n'] == n:
            out.append((row['m_min'], row['m_max'], 'sparse'))
    if n >= 50 and n % 5 == 0:
        out.append((2*n, 3*n if n >= 80 else 11*n//5, 'five'))
    if n >= 79:
        return out+[(3*n, n*(n-3), 'pair_main')]
    out.append((pair_base(n), n*(n-3), 'pair_codes'))
    for row in data[0]['rows']:
        if row['n'] == n:
            out.append((row['m_min'], row['m_max'], 'six_circle'))
    for period, minimum in ((4, 7), (5, 8)):
        if n % period == 0 and any(gcd(n, h) == 1 for h in range(minimum, (n-2)//2+1, period)):
            out.append((6*n, n*n//2 if period == 4 else n*(3*n//5-3), 'six_circle'))
    for h in range(7, (n-2)//2+1, 4):
        if gcd(n, h) == 1:
            A = ({v for v in range(n-h+1) if v % 4 < 2} | {h})-{2*h-1}
            out.append((5*n, n*(len(A)-1), 'circle'))
            if n % 4 == 0:
                out.append((5*n, n*(n//2-1), 'circle'))
    for hubs, maxg in ((12, 8), (14, 14)):
        for g in range(2, maxg+1):
            b = n-hubs-g
            for r in range(2, g+1):
                if 0 <= b <= comb(g, r):
                    A = 106+22*g+(19+r)*b if hubs == 12 else 154+25*g+(22+r)*b
                    out.append((A, A+b*(g+b-1), 'layer'))
    for g in range(2, 8):
        b = n-12-g
        for r in range(2, g+1):
            if 0 <= b <= comb(g, r):
                A = 106+18*g+(12+r)*b
                out.append((A, A+b*(g+b+8), 'reduced_hubs'))
    if n in (13, 14):
        row = next(r for r in data[3]['rows'] if r['n'] == n)
        out.append((n*(n-3)-len(row['optional']), n*(n-3), 'dense_tiny'))
    if 25 <= n <= 42:
        for h in range(7, (n+1)//2, 2):
            if gcd(n, h) != 1:
                continue
            C = {1, (h-1)//2, h}
            differences = {(a-b) % n for a in C for b in C if a != b}
            A = C | {0}
            for v in range(n):
                if v not in A and not any((v-a) % n in differences for a in A):
                    A.add(v)
            out.append((3*n, n*(len(A)-1), 'small_protected'))
    elif n >= 43:
        out.append((3*n, n*((n+6)//7-1), 'protected'))
    return out


def coverage_checks():
    data = [load(path) for path in INPUTS]
    all_rows, points, cells = [], {}, 0
    for n in range(12, 115):
        rows = finite_intervals(n, data)
        at = 2*n
        for low, high, _ in sorted(rows):
            if low <= at:
                at = max(at, high+1)
        assert at > n*(n-3), (n, at)
        # Every interval endpoint partitions possible constructor branch changes.
        boundaries = {2*n, n*(n-3)+1}
        for low, high, _ in rows:
            if 2*n <= low <= n*(n-3): boundaries.add(low)
            if 2*n <= high+1 <= n*(n-3): boundaries.add(high+1)
        ordered = sorted(boundaries)
        points[n] = sorted({m for a, b in zip(ordered, ordered[1:])
                            for m in (a, b-1, (a+b-1)//2)})
        cells += n*(n-3)-2*n+1
        all_rows.append(dict(n=n, intervals=rows))
    return dict(orders=[12, 114], covered_cells=cells, plans=all_rows), points


def compare_outputs(points):
    import main_interval_complete as complete
    import main_interval_pair_codes as producer
    results, branches = [], set()
    for n, budgets in points.items():
        for m in budgets:
            graph = complete.construct(n, m)
            arcs = set(map(tuple, graph['arcs']))
            assert len(arcs) == len(graph['arcs']) == m
            assert all(0 <= a < n and 0 <= b < n and a != b for a, b in arcs)
            assert graph['I'] == n*(n-1)-m
            branches.add(graph['branch'])
        results.append(dict(n=n, constructions=len(budgets)))
    # Compare independently specified pair adjacency at base, interior and top.
    pair_graphs = 0
    for k in range(6, 11):
        K = pair_list(k)
        for q in sorted({0, 1, len(K)//2, len(K)}):
            n = 2*k+q
            chosen = K[:q]
            low = (4*k-2)*n-2*k*(2*k+1)
            missing = {(i, k+i) for i in range(k)} | {(i, k+(i-1) % k) for i in range(k)}
            missing |= {(k+i, (i+d) % k) for i in range(k) for d in (4, 6)}
            B = {(a, b) for a in range(n) for b in range(n) if a != b and
                 ((a < 2*k and (b >= 2*k or (a, b) not in missing)) or
                  (a >= 2*k and b < 2*k and b not in chosen[a-2*k]))}
            optional = [(a, b) for a in range(2*k, n) for b in range(2*k, n) if a != b]
            for added in {0, len(optional)//2, len(optional)}:
                actual = producer.pair_construct(n, low+added, k)
                assert set(map(tuple, actual['arcs'])) == B | set(optional[:added])
                pair_graphs += 1
    # Generalized validator accepts old codes and rejects the new forbidden pairs.
    import core_code_all_parities as old_codes
    for k in range(6, 13):
        K = old_codes.codes(k, 3, min(12, old_codes.capacity(k, 3)))
        assert producer.validate_codes(k, K) == K
        for invalid in ({0, 1}, {0, 2}, {k, k+1}, {k, k+2}):
            try: producer.validate_codes(k, [invalid])
            except ValueError: pass
            else: raise AssertionError(('invalid pair accepted', k, invalid))
    for n in (115, 116, 117, 827, 828, 868, 869, 928, 929):
        p = producer.parameters(n)
        budgets = {2*n, 3*n, p['pair_min']-1, p['pair_min'], n*(n-3)}
        for m in budgets:
            g = complete.construct(n, m)
            assert len(g['arcs']) == len(set(map(tuple, g['arcs']))) == m
            branches.add(g['branch'])
        results.append(dict(n=n, constructions=len(budgets)))
    return dict(rows=results, actual_constructions=sum(r['constructions'] for r in results),
                exact_pair_edge_comparisons=pair_graphs, branches=sorted(branches))


def run():
    witnesses = pair_checks()
    arithmetic = arithmetic_checks()
    coverage, points = coverage_checks()
    output = compare_outputs(points)
    sources = INPUTS+RETAINED_SOURCES+['src/main_interval_pair_codes.py', 'src/main_interval_pair_codes_check.py',
                     'src/main_interval_complete.py', 'paper/core-code-composition.md',
                     'paper/main-interval-complete.md']
    return dict(verified=True,
                proof_boundary='Independent direct two-move witnesses and interval arithmetic; existing finite game certificates are retained, not rerun or newly formalized.',
                pair_witnesses=witnesses,
                asymmetric_two_move_obligations=sum(r['obligations'] for r in witnesses),
                arithmetic=arithmetic, finite_coverage=coverage, output_comparisons=output,
                source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--out', type=Path, help='Write an explicitly requested fresh receipt.')
    mode.add_argument('--check', action='store_true',
                      help='Read-only exact comparison with the saved current receipt.')
    args = parser.parse_args()
    result = run()
    body = json.dumps(result, indent=2)+'\n'
    if args.out:
        args.out.write_text(body)
    if args.check:
        saved = ROOT/'research/main-interval-pair-code-checks.json'
        assert saved.read_text() == body, 'Current pair-code receipt differs; no files were written.'
    print(json.dumps({k:result[k] for k in ('verified', 'asymmetric_two_move_obligations')} |
                     {'covered_cells':result['finite_coverage']['covered_cells'],
                      'actual_constructions':result['output_comparisons']['actual_constructions']}))

"""Render the parked delivery-time companion from its single Markdown source."""
from pathlib import Path
import json
import re
import shutil
import tempfile
import zipfile

from pypdf import PdfReader


def build(root, public, spec, run, pandoc, tex, sha, preview_only=False):
    paper = root / 'paper'
    source = root / spec['source']
    text = source.read_text()
    assert not re.search(r'!\[', text), 'Add companion figures to the explicit inventory first'
    tex_path = paper / 'delivery-time.tex'
    run([pandoc, source.name, '--standalone', '--citeproc',
         '--bibliography=references.bib', '--number-sections',
         '--variable=fontfamily:lmodern', '--to=latex', '-o', tex_path.name], paper)
    latex = tex_path.read_text()
    def wrap_code(match):
        body = match.group(1)
        for token in ['/', r'\_', '-', '.']:
            body = body.replace(token, token + r'\allowbreak{}')
        return r'\texttt{' + body + '}'
    tex_path.write_text(re.sub(r'\\texttt\{([^{}]*)\}', wrap_code, latex))
    previous = None
    for _ in range(4):
        run([tex, '-interaction=nonstopmode', '-halt-on-error', tex_path.name], paper)
        signature = tuple((paper / ('delivery-time.' + ext)).read_bytes()
                          if (paper / ('delivery-time.' + ext)).exists() else b''
                          for ext in ['aux', 'toc', 'out'])
        if signature == previous:
            break
        previous = signature
    else:
        raise RuntimeError('Companion cross references did not stabilize')
    log = (paper / 'delivery-time.log').read_text()
    assert not re.search(r'undefined references|undefined citations|Citation .* undefined', log)
    warnings = re.findall(r'^Overfull.*$', log, re.M)
    assert not warnings, warnings
    pdf = root / 'output/pdf' / spec['pdf']
    shutil.copy2(paper / 'delivery-time.pdf', pdf)
    shutil.copy2(pdf, public / spec['pdf'])
    if preview_only:
        return {'preview_only': True, 'pdf': str(pdf),
                'pages': len(PdfReader(pdf).pages), 'pdf_sha256': sha(pdf)}, ''
    with zipfile.ZipFile(public / spec['source_zip'], 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.write(tex_path, 'main.tex')
        archive.write(paper / 'references.bib', 'references.bib')
    expected = [page.extract_text() for page in PdfReader(pdf).pages]
    with tempfile.TemporaryDirectory(prefix='companion-source-replay-', dir=root / 'tmp') as folder:
        replay = Path(folder)
        with zipfile.ZipFile(public / spec['source_zip']) as archive:
            archive.extractall(replay)
        for _ in range(3):
            run([tex, '-interaction=nonstopmode', '-halt-on-error', 'main.tex'], replay)
        assert [page.extract_text() for page in PdfReader(replay / 'main.pdf').pages] == expected
    ast = json.loads(run([pandoc, source.name, '--citeproc', '--bibliography=references.bib', '--to=json'], paper))
    maths = []
    def walk(value):
        if isinstance(value, list):
            return [walk(item) for item in value]
        if not isinstance(value, dict):
            return value
        if value.get('t') == 'Header':
            value['c'][0] = min(value['c'][0] + 1, 6)
        if value.get('t') == 'Math':
            i = len(maths)
            maths.append({'source': value['c'][1], 'display': value['c'][0]['t'] == 'DisplayMath'})
            return {'t': 'RawInline', 'c': ['html', f'COMPANIONMATH{i}END']}
        if 'c' in value:
            value['c'] = walk(value['c'])
        return value
    ast['blocks'] = walk(ast['blocks'])
    scratch = root / 'tmp'
    (scratch / 'companion-ast.json').write_text(json.dumps(ast))
    (scratch / 'companion-maths.json').write_text(json.dumps(maths))
    run(['node', scratch / 'render-math.cjs', root / '.site-worktree',
         scratch / 'companion-maths.json', scratch / 'companion-rendered.json'])
    body = run([pandoc, scratch / 'companion-ast.json', '--from=json', '--to=html5', '--wrap=none'])
    for i, rendered in enumerate(json.loads((scratch / 'companion-rendered.json').read_text())):
        body = body.replace(f'COMPANIONMATH{i}END', rendered)
    receipt = {'source': spec['source'], 'pdf': spec['pdf'], 'source_zip': spec['source_zip'],
               'pages': len(expected), 'math_formulas': len(maths), 'pdf_sha256': sha(pdf),
               'standalone_source_recompiled': True, 'text_matches_published_pdf': True,
               'no_overfull_boxes': True, 'status': 'Parked research companion; partial results explicitly identified'}
    (root / 'research/delivery-time-pdf-verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return receipt, body

#!/usr/bin/env python3
"""Finite checks of the four-move prime-field parabola construction.

Check the full parabola intersection bound, the four-move core closure, and
every integer budget obtained by inserting remaining parabola arcs. At p=5,
both full game solvers and all rank certificates also run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from game_solver import solve_graph

ROOT = Path(__file__).resolve().parents[1]


def prime(p):
    return p >= 2 and all(p % d for d in range(2, int(p ** 0.5) + 1))


def build(p, parameters=None):
    if p < 5 or not prime(p):
        raise ValueError("This proof and checker require a prime p>=5")
    n = p * p
    if parameters is None:
        parameters = (1, p - 1, p - 2, p - 3)
    parameters = tuple(parameters)
    arcs = []
    for x in range(p):
        for y in range(p):
            u = p * x + y
            for t in parameters:
                arcs.append((u, p * ((x + t) % p) + (y + t * t) % p))
    assert len(set(arcs)) == n * len(parameters)
    return n, arcs


def verify(p):
    n, arcs = build(p)
    _, full_arcs = build(p, range(1, p))
    successors = [set() for _ in range(n)]
    closed = [1 << v for v in range(n)]
    for a, b in arcs:
        assert a != b
        successors[a].add(b)
    for a, b in full_arcs:
        closed[a] |= 1 << b
    maximum_overlap = 0
    for a in range(n):
        for b in range(a):
            overlap = (closed[a] & closed[b]).bit_count()
            maximum_overlap = max(maximum_overlap, overlap)
            assert overlap <= 1

    ranks = [-1] * n
    ranks[0] = 0
    layers = [[0]]
    direct = sorted(v for v in range(1, n) if 0 in successors[v])
    assert len(direct) == 4
    for v in direct:
        ranks[v] = 1
    layers.append(direct)
    known = {0, *direct}
    while len(known) < n:
        fresh = [v for v in range(n) if v not in known and len(successors[v] & known) >= 2]
        assert fresh, "Safe-branching closure failed to cover the group"
        for v in fresh:
            ranks[v] = len(layers)
        known.update(fresh)
        layers.append(fresh)
    for v in range(1, n):
        if ranks[v] == 1:
            assert 0 in successors[v]
        else:
            assert sum(0 <= ranks[u] < ranks[v] for u in successors[v]) >= 2
    assert max(ranks) <= 5 * p - 3

    # Insert all remaining arcs in a fixed order. These intermediate graphs
    # generally do not have translation symmetry. The translated CORE rank
    # proof still applies at every target, and each cop neighborhood remains
    # a subset of its full translated parabola neighborhood.
    extras = sorted(set(full_arcs) - set(arcs))
    actual = set(arcs)
    core_arcs = set(arcs)
    full_set = set(full_arcs)
    budgets_checked = 0
    for added in range(len(extras) + 1):
        if added:
            actual.add(extras[added - 1])
        assert core_arcs <= actual <= full_set
        assert len(actual) == 4 * n + added
        budgets_checked += 1

    result = {
        "p": p,
        "n": n,
        "minimum_m": len(arcs),
        "maximum_m": len(full_arcs),
        "I_at_minimum_m": n * (n - 5),
        "I_at_maximum_m": p ** 3 * (p - 1),
        "consecutive_integer_budgets_checked": budgets_checked,
        "intermediate_graph_check": "Every core-plus-prefix graph contains the uniform four-move core and is contained in the full parabola graph.",
        "vertex_encoding": "(x,y) maps to p*x+y, with x,y in 0..p-1",
        "max_closed_neighborhood_overlap": maximum_overlap,
        "bootstrap_layer_sizes": [len(layer) for layer in layers],
        "bootstrap_ranks_for_target_zero": ranks,
        "all_vertices_in_safe_branching_closure": True,
        "largest_bootstrap_delivery_bound": max(ranks),
        "other_targets": "Translate the uniform core rank certificate; extra arcs need not be translation invariant. The full-parabola intersection bound applies to every actual cop neighborhood.",
    }
    if p == 5:
        exact = solve_graph(n, arcs, certificates=True, crosscheck=True)
        assert all(all(row) for row in exact["W"])
        assert exact["I"] == result["I_at_minimum_m"]
        result["full_game_check"] = {
            "verified": True,
            "methods": "both independent solvers and every explicit rank certificate",
            "recipients_checked": n,
            "I": exact["I"],
        }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("primes", nargs="*", type=int, default=[5, 7, 11])
    parser.add_argument("--out", type=Path, default=ROOT / "research/parabola-cayley-checks.json")
    args = parser.parse_args()
    receipt = {
        "verified": True,
        "scope": "Finite checks of explicit prime-field instances; the all-prime theorem is proved separately.",
        "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "game_solver_sha256": hashlib.sha256((ROOT / "src/game_solver.py").read_bytes()).hexdigest(),
        "checks": [verify(p) for p in args.primes],
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"verified": True, "primes": args.primes,
                      "orders": [c["n"] for c in receipt["checks"]],
                      "layer_bounds": [c["largest_bootstrap_delivery_bound"] for c in receipt["checks"]],
                      "integer_budgets_checked": sum(c["consecutive_integer_budgets_checked"] for c in receipt["checks"]),
                      "receipt": str(args.out)}))


if __name__ == "__main__":
    main()

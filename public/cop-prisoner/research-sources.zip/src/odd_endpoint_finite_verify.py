#!/usr/bin/env python3
"""Replay fixed finite odd endpoint ranks against all legal game moves.

The C++ producer finds ranks by queue propagation. This verifier uses only
local strict-rank and losing-closure tests, independently of that algorithm.
NumPy speeds the identical scalar checks; --scalar uses only the stdlib.
Records encode little-endian signed16 ranks at 2*(messenger*n+cop)+turn.
No predecessor lists, queues, or certificate claims are trusted on replay.
"""
from __future__ import annotations
import argparse, array, base64, gzip, hashlib, json, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'research/odd-endpoint-finite-bridge-certificates.jsonl.gz'
GRAPHS=ROOT/'research/odd-endpoint-finite-bridge-graphs.json'
try:import numpy as np
except ImportError:np=None


def get_graphs():
 rows={g['n']:g for g in json.loads((ROOT/'research/odd-endpoint-finite-family-screen.json').read_text())['graphs']}
 for g in json.loads((ROOT/'research/odd-endpoint-finite-deletion-screen.json').read_text()):rows[g['n']]=g
 assert all(n in rows for n in range(19,145))
 result=[rows[n]for n in range(19,145)]
 GRAPHS.write_text(json.dumps(result,indent=2)+'\n')
 return result


def neighbors(g):
 n=g['n'];u,v=g['low_source'],g['low_recipient'];arcs=[tuple(a)for a in g['arcs']]
 assert len(arcs)==len(set(arcs))==2*n-1 and u!=v and(u,v)not in arcs
 out=[[x]for x in range(n)];indegree=[0]*n
 for a,b in arcs:
  assert 0<=a<n and 0<=b<n and a!=b
  out[a].append(b);indegree[b]+=1
 assert all(len(out[x])==(2 if x==u else 3)for x in range(n))
 assert all(indegree[x]==(1 if x==v else 2)for x in range(n))
 return out


def check(g,target,data,scalar=False):
 n=g['n'];out=neighbors(g);assert target!=g['low_recipient'];assert len(data)==4*n*n
 if np is not None and not scalar:
  rank=np.frombuffer(data,dtype='<i2').reshape(n,n,2)
  assert np.all(rank>=-1)and np.all(rank[target,:,:]==0)
  active=np.ones((n,n),dtype=bool);active[target,:]=False
  diagonal=np.arange(n);collision=diagonal[diagonal!=target]
  assert np.all(rank[collision,collision,:]==-1)
  active[diagonal,diagonal]=False
  m,p=rank[:,:,0],rank[:,:,1]
  mgood=np.zeros((n,n),dtype=bool);mbad=np.ones((n,n),dtype=bool)
  pgood=np.ones((n,n),dtype=bool);pbad=np.zeros((n,n),dtype=bool)
  padded=np.array([o+[o[0]]*(3-len(o))for o in out])
  for j in range(3):
   ms=p[padded[:,j],:];ps=m[:,padded[:,j]]
   mgood|=(ms>=0)&(ms<m);mbad&=ms<0
   pgood&=(ps>=0)&(ps<p);pbad|=ps<0
  assert np.all(mgood[active&(m>=0)])and np.all(mbad[active&(m<0)])
  assert np.all(pgood[active&(p>=0)])and np.all(pbad[active&(p<0)])
  required=np.ones((n,n),dtype=bool);required[g['low_source'],:]=False;required[diagonal,diagonal]=False
  assert np.all(m[required]>=0)
  return int(np.max(m[required])+1)//2,int(np.count_nonzero(rank>=0))
 rank=array.array('h');rank.frombytes(data)
 if sys.byteorder!='little':rank.byteswap()
 assert len(rank)==2*n*n and all(x>=-1 for x in rank)
 for a in range(n):
  for c in range(n):
   z=2*(a*n+c)
   if a==target:assert rank[z]==rank[z+1]==0;continue
   if a==c:assert rank[z]==rank[z+1]==-1;continue
   ms=[rank[2*(b*n+c)+1]for b in out[a]]
   ps=[rank[2*(a*n+b)]for b in out[c]]
   if rank[z]>=0:assert any(0<=s<rank[z]for s in ms)
   else:assert all(s<0 for s in ms)
   if rank[z+1]>=0:assert all(0<=s<rank[z+1]for s in ps)
   else:assert any(s<0 for s in ps)
   if a!=g['low_source']:assert rank[z]>=0
 return (max(rank[2*(a*n+c)]for a in range(n)if a!=g['low_source']for c in range(n)if a!=c)+1)//2,sum(x>=0 for x in rank)


def main():
 parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true');parser.add_argument('--scalar',action='store_true');parser.add_argument('--limit',type=int);args=parser.parse_args();start=time.monotonic()
 graphs=json.loads(GRAPHS.read_text())if args.check else get_graphs();lookup={g['n']:g for g in graphs};rows=[];totalstates=0;modules=0
 if args.check:
  seen=set()
  with gzip.open(DEST,'rt')as f:
   for line in f:
    r=json.loads(line);n,t=r['n'],r['target']
    if args.limit is not None and n>args.limit:continue
    assert(n,t)not in seen;seen.add((n,t));check(lookup[n],t,base64.b64decode(r['rank_int16_le']),args.scalar);modules+=1
  expected={(g['n'],t)for g in graphs if args.limit is None or g['n']<=args.limit for t in range(g['n'])if t!=g['low_recipient']}
  assert seen==expected
  print(json.dumps({'status':'saved certificates replay passed','objectives':modules,'seconds':time.monotonic()-start,'scalar':args.scalar}));return
 data=str(len(graphs))+'\n'+''.join(f"{g['n']} {g['low_source']} {g['low_recipient']}\n"+''.join(f'{a} {b}\n'for a,b in g['arcs'])for g in graphs)
 # Use a file for stdin so output cannot block while the fixed graph input
 # is still being written into a pipe.
 inp=ROOT/'research/odd-endpoint-finite-bridge-input.txt';inp.write_text(data)
 with inp.open('rb')as source,gzip.open(DEST,'wt',compresslevel=6)as dest:
  proc=subprocess.Popen(['/tmp/odd_endpoint_finite_certify'],stdin=source,stdout=subprocess.PIPE)
  for g in graphs:
   n=g['n'];begin=time.monotonic();bound=0;states=0
   for t in range(n):
    if t==g['low_recipient']:continue
    length=4*n*n;chunks=[]
    while length:
     chunk=proc.stdout.read(length);assert chunk,'truncated producer ranks';chunks.append(chunk);length-=len(chunk)
    raw=b''.join(chunks);b,w=check(g,t,raw,args.scalar);bound=max(bound,b);states+=2*n*n;modules+=1
    dest.write(json.dumps({'n':n,'target':t,'rank_int16_le':base64.b64encode(raw).decode()},separators=(',',':'))+'\n')
   totalstates+=states;row={'n':n,'m':2*n-1,'I':(n-2)*(n-3),'objectives':n-1,'states_checked':states,'max_delivery_moves':bound,'seconds':round(time.monotonic()-begin,3)};rows.append(row)
   print(n,'PASS',row['seconds'],'seconds',flush=True)
  assert proc.stdout.read()==b'' and proc.wait()==0
 sources=['src/odd_endpoint_finite_verify.py','src/odd_endpoint_finite_certify.cpp','research/odd-endpoint-finite-bridge-graphs.json']
 receipt={'status':'all finite certificates independently verified','minimum_n':19,'maximum_n':144,'minimum_odd_m':37,'graphs':len(graphs),'objectives':modules,'states_checked':totalstates,'seconds':time.monotonic()-start,'numpy_version':None if np is None else np.__version__,'certificate_format':'JSON lines containing n,target,base64 little-endian signed16 ranks at 2*(messenger*n+cop)+turn. Turn0 messenger; -1 losing.','source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()for p in sources},'certificate_sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),'rows':rows}
 (ROOT/'research/odd-endpoint-finite-bridge-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items()if k not in('rows','source_sha256')}))


if __name__=='__main__':main()

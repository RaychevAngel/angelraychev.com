# Guaranteed indirect delivery: research log

## 12 September 2026: authorized restart

Angel authorized a full extremal investigation, with consolidation and website/artifact updates at 10% remaining account usage. The account began this continuation at 47% remaining. Exact maxima with vertices fixed, arcs fixed, and both fixed remain the priority. The handoff's earlier no-execution instruction described its original side conversation and is superseded by this authorization.

Original source: Alexandra Ignatova's Bulgarian manuscript, dated February 2024, from work mentored by Angel Raychev (SRS 2023). Original sources are unchanged. Publication author metadata is not yet settled. September 2026 deductions and repairs are recorded separately.

### Baseline and independent work

The graph is loopless and directed. Both players may wait, messenger moves first, target receipt has priority over collision, and infinite avoidance is not success. Guarantees quantify over every observed initial pursuer position other than the source. No invisible-search results from Princess are transferred.

Three independent assignments: original construction audit; extremal bounds; exact game solver. The lead investigates new vertex-extremal constructions. Reproducible files replace the handoff's ephemeral computations.

### First deductions and failed approaches

- Outgoing-neighborhood domination prevents an entire source row from having indirect guarantees. Identical-source blowups therefore do not automatically multiply winning pairs.
- A recipient whose predecessor set is contained in one vertex's closed outgoing neighborhood can have no indirect guaranteed source except possibly that vertex. This invalidates several recipient classes in the original construction. The construction auditor is deriving its exact count.
- Directed tori of dimension three with positive coordinate steps do not give universally guaranteed delivery: finite tests on 27 and 64 vertices found only 4n indirect pairs. Perpetual safe evasion is insufficient.
- A conjecture that an indegree-two recipient has at most one indirect guaranteed source is false, already on five vertices. An appended two-predecessor sink on a universal-delivery graph provides larger counterexamples. No per-recipient upper bound of n-4 has been established.

### New circulant construction: ordinary proof pending independent review

For every n >= 15 with 7 not dividing n, the circulant with outgoing steps 1, 3, 7 has universally guaranteed delivery, hence exactly I=n(n-4), using 3n arcs. The proof uses a Sidon closed move set and a four-vertex bootstrap pattern translated by seven; see research/circulant-construction.md. This is an all-size argument on its stated congruence domain, not an extrapolation from computation.

The independent solver found the same universality through n=150, with multiples of seven failing for this specific construction. Removing the divisibility restriction, extending the lower bound to every size with linear overhead, and finding a matching universal upper bound remain active targets. In particular n(n-4) is not yet an extremal formula.

### Literature boundary

Initial primary-source searches locate standard directed pursuit and finite reachability games, but not a priority result for this exact all-source/all-recipient invariant. Related games often permit teleporting cops or merely indefinite evasion. No novelty claim is made from this initial search.

### Reviewed general theorems and construction audit

- The independent construction audit confirms the safe Sidon branching and quartet propagation proof. A number-theoretic parameter choice now supplies a 3n-arc universal graph for **every n>=25**, not only the step-1,3,7 congruence classes. Hence n(n-4)<=M_V(n)<=n(n-3) on that entire domain.
- General arc bounds proved and independently attacked: for k>=5, M_E(2k)<=k(k-3) and M_E(2k+1)<=k(k-3)+2. Equality structure is characterized for k>=6. The proof uses active source/recipient sets and zero-row/zero-column obstructions. It does not assume reversal invariance of the game.
- The original balanced layered graph has exact count I=2a(N-1-q)+4q, where q=2x, a=binom(2x,x)/2 and N=2a+4q. At x=3 this is **764**, not the draft's claimed lower bound 1252. Predecessor camping invalidates the other counted recipient classes. The safe layer strategy and correct endpoint classes are now proved; the original N²-O(N log N) leading estimate survives.
- The complementary-half balancing lemma holds exactly when x is not a power of two. The proof uses cyclic orbits of subsets containing a distinguished element; all orbit lengths are 2x-1. The original divisibility assertion fails already at x=3.
- For n>=2, M(n,n(n-2))=floor((n-2)/2); above that density I is always zero. All minima at admissible (n,m) are zero. A functional missing-arc graph describes equality at the dense boundary.

### Finite exact work and invalid conjectures

- Two independent solvers implement the actual alternating game. Their checks include waits, target-priority collision handling, rank-decreasing winning moves, all pursuer replies, and closure of losing states.
- Complete maxima through n=6 are 0,0,0,2,4,7. Joint tables are saved in research/solver-enumeration-n*.json. The n=6 search sorts labels by degree to retain an isomorphism representative; it does not count every labeled graph.
- Universally winning two-regular examples certify M_V(n)=n(n-3) for n=12..24. The odd arc bound is attained by certified examples at m=37,39,...,47. No extrapolation from these finite cases is made.
- Both a conjectured global bound n(n-4) and a conjectured upper bound of one indirect source at an indegree-two target are false. Arbitrary two-edge splitting does not preserve universality. Simple finite cyclic voltage guesses and distance-only strategies failed. Adding arcs is nonmonotone; the diamond plus one extra arc is a minimal illustration.

### Infinite sparse breakthrough

The five-type two-regular ring H_k is now **proved universally winning for every k>=4**. Thus M_V(5k)=M_E(10k)=5k(5k-3), and padding at most nine disjoint arcs gives M_E(m)=m²/4-O(m) for arbitrary m.

The decisive abstraction is a stronger local game: messenger columns -3..3, pursuer columns -4..4 plus an exterior state Ω that may re-enter any boundary vertex. A safe transfer moves the messenger from column 1 to column 0 in at most eight moves and ends only on a messenger turn, after the pursuer response. Five delivery certificates move from column 2 to a selected type in column 0 in at most 24 moves. Two independently written solvers check all 3220 alternating states per local objective. A separately reviewed projection argument applies these certificates to every k>=10, including k=10's single exterior column. Full finite certificates cover k=4..9. The uniform delivery bound is 8k+16 for k>=10.

This resolves the finite-to-infinite proof gap. It remains an ordinary computer-assisted theorem; it is not silently promoted to full Lean coverage.

### Dense infinite family and joint interval

The directed complement of an oriented undirected graph of girth at least six and minimum outgoing degree at least two guarantees every pair in two moves. An induced double-star argument supplies the safe intermediate station. Four-regular high-girth graphs therefore yield M(n,n(n-3))=2n.

A 26-vertex incidence graph and a degree-preserving edge-pair insertion give all orders n>=130 by an ordinary proof. A separately verified 78-insertion certificate bridges from 52 through 130, establishing the stated result for every n>=52. Adding distant edges under a degree cap D extends exact joint extrema to the interval in Theorem 20, reaching a constant times n^(5/4) missing arcs. This is an interval of joint values, not a full classification of M(n,m).

### Failed attempts to fill the remaining sparse residues

Random local patches with one to four additional vertices were universal at one ring size, k=8, but failed at k=9..12 and at smaller sizes. These candidates were rejected immediately after independent tests. Ten single-arc deletions from the unmodified five-type family also fail the odd-budget equality condition. Current search therefore targets the actual stronger local safe-transfer and delivery objectives, rather than a single finite circumference. A near-complete score is not a proof. A too-short one-column delivery entry was identified and corrected before further optimization.

### Formalization and presentation checkpoint

Five Lean modules prove the exact game, certificate-to-actual-play semantics, safe branching, predecessor camping, and a universally winning 12-vertex/24-arc graph with I=108. Kernel reduction checks the certificate. Source hashes and axiom reports are in lean/verification.json. General extremal counting and infinite constructions remain outside Lean.

The website follows the existing Post layout: overview with a game explorer, detailed proofs, paper/downloads, and Lean coverage. The PDF and web proof text share one manuscript source. The TypeScript explorer was checked against Python on all graphs through four vertices, its three examples, and 50 seeded graphs (4218 graphs total), including exact move ranks and safe selected policies. Browser checks exercised the successful diamond, blocked modified diamond, and complete four-move route in the 12-vertex example.

### Consolidation at the requested usage threshold

The account reached 90% used (10% remaining) after all research subprocesses and agents had stopped. No unresolved construction was promoted. The final manuscript has 23 pages and four figures, with 788 rendered mathematical expressions in the companion proof page. All pages were rendered and visually reviewed; LaTeX reports no overfull boxes, references stabilize, and the standalone source archive reproduces the exact PDF text. Fresh Lean replay passed all five modules. Local link checks found no broken targets across the four website routes.

Publication uses an isolated website worktree and preserves the concurrently updated Princess material by rebasing onto the new origin/main before deployment. The full source checkpoint remains under this project; live deployment and hash readback are recorded separately in research/website-deployment.json.

Published successfully: https://angelraychev.com/cop-prisoner/ . Website commit e1d2368ff1d970c6bcd9afa59933a94b72c92469, GitHub Actions run34690844065. Four live routes and all download hashes verified; the live explorer initializes correctly in the browser. No arXiv submission or outreach occurred.

### Follow-up discussion: provenance and structural directions

Angel clarified that he and Alexandra had already proved the n(n-3) upper bound and pursued two-in/two-out graphs. The manuscript and site attribution have been corrected accordingly. Their original direction is distinct from the new explicit attaining families.

Angel proposed using a two-element-valued map, composable constructions, odd-degree defects, terminal cliques, and target-dependent domination. A bounded independent audit verifies the terminal-clique count and strengthens it to every intermediate budget. It also verifies exact single-sink padding, corrects the odd row/column count, and identifies an existing counterexample to monotonicity of the joint maximum. A new elementary lemma shows that two commuting outgoing permutations force I<=n, ruling out all two-generator abelian Cayley constructions for the large extremum. Full proofs and credit are in research/2026-09-12-strategy-discussion.md. This is a discussion follow-up, not a resumed unbounded computation campaign.

The discussion audit also proves a target-specific stationary-separator bound and gives an elementary five-vertex counterexample showing why moving-pursuer obstructions cannot be replaced by stationary separators alone. The new discussion lemmas have ordinary independently reviewed proofs, not Lean coverage. Attribution correction was rebuilt into the 23-page PDF, standalone source archive, web proof page, and overview; changed PDF pages were visually checked and the site build passed. Deployment 7ef0fb1a7297a2470447e098e65cbd893ff99152 / run 34720915736 succeeded; all four public routes and seven download hashes were verified.

### Large-order interval conjecture and new deductions

Angel proposed M(n,m)=n(n-1)-m for every sufficiently large n and all 2n<=m<=n(n-3), and correctly distinguished this from small-order nonmonotonicity. Construction-based attainment is the priority. A bounded discussion established an exact-budget probabilistic lemma: p=m/[n(n-1)] and (n-3)p²(1-p)>5log n suffice for all pairs to be delivered within two moves. Conditioning on the binomial mode ensures exactly m arcs. Combining this with the existing high-girth complement interval proves exact attainment for every integer m from ceil(10n^(3/2)sqrt(log n)) through n(n-3), for every sufficiently large n. The asymptotic onset is unspecified and may be large. The sparse gap remains open.

In the final dense band, write h=n(n-1)-m and q(v) for missing outgoing degree. If I>0, all q>=1 and at least 2n-h vertices have q=1. A vertex whose sole missing neighbor is x eliminates every indirect source pair from x. Distinct affected source rows give I<=h-sum(q(x)); in particular I<=h-2 for n<=h<2n. This is not claimed sharp. Both deductions were independently checked; complete ordinary proofs are in research/2026-09-12-full-density-conjecture.md. No large computation, new Lean formalization, or website/PDF release was performed for this discussion.

### Sharp staircase in the final dense band

In response to Angel's four-track research plan, a bounded ordinary proof replaces the constant-two loss with ceil(r/2)+1, where m=n(n-3)+r and 1<=r<=n. Count singleton missing-outdegree tails, their image source rows, and duplicate-image recipient obstructions; a functional cycle supplies the extra loss. An independently checked complementary-block construction attains this bound for every 2<=r<=n-52: a functional missing-edge extremizer on r vertices plus the existing two-regular high-girth missing-edge block on n-r vertices. Both component complements have two-move strategies, which survive joining with all cross-block arcs. Hence M(n,n(n-3)+r)=2n-r-ceil(r/2)-1 throughout that interval. The first step and a fixed-width endpoint band remain outside the uniform result; r=n was already exact, and some smaller core orders give additional offsets. Full proofs and scope: research/2026-09-12-final-dense-band.md. No heavy computation or additional publication run was performed.

### Continued execution after the usage-rule override

Angel explicitly lifted the earlier 10% stopping rule in this run. Research continued beyond it. The first dense step is now exact for n>=68, via a four-vertex missing-edge gadget attached to a four-regular high-girth core. The remaining small-core offsets are handled by assigning distinct pairs of functional source vertices to new degree-two missing rows. Together these prove the entire final dense band for n>=75: M(n,n(n-3)+r)=2n-r-ceil(r/2)-1 for every 1<=r<=n, with explicit constructions. Both arguments were independently checked; generators record actual finite graphs and two-move witnesses.

The main interval also advanced constructively. The existing three-arrow proof already attains M(n,3n). A greedy Sidon extension preserves the proof under arbitrary subsets of added arrows, giving every 3n<=m<=dn when n>d³+2d, d>=4; in particular 3n..4n for all n>=73. A parabola construction gives every 4n<=m<=n(sqrt(n)-1) at n=p² for prime p>=5; when p>=11 the intervals join down to 3n. This is not asserted for arbitrary prime powers. Asymmetric finite-window certificates prove every 2n<=m<=3n on the five-type family n=5k, k>=16. The strengthened pursuer arena uses columns -6..6 and all re-entry columns at distance four, five, or six. The initially tempting threshold k>=14 was rejected: a length-three jump can cross a too-short outside gap. The corrected k>=16 proof and independent 4620-state certificates avoid this gap.

Lean now has six modules. DenseCounting proves the numerical staircase deduction from explicit cardinality premises and complementary-block gluing in actual play; it does not claim the graph-to-cardinality proof or block existence. The general new families remain ordinary proofs or explicitly indicated independently checked certificates.

The sparse endpoints at arbitrary orders remain unresolved. Permutation-constrained patch search reduced the best +1 candidate from 1804 to 939 failed deliveries, while preserving every safe transfer. Two-port and multiport block-splicing searches examined 19,680 and 48,841 candidates respectively without obtaining a universal construction. These are failed approaches, preserved in research/sparse-endpoints-followup.md and the associated receipts, not evidence of a proved extension.

The completed publication build has 38 pages, five figures, and 1384 mathematical expressions in the web proof text. All manuscript pages were visually reviewed; the contents were compacted to eliminate a nearly empty second page, and the revised opening pages were checked again. There are no overfull boxes. The standalone LaTeX archive reproduces the PDF text, all six Lean modules pass, and all four local website routes have no math-rendering errors or horizontal page overflow. The website deployment and public download readback are recorded separately in research/website-deployment.json. Research subprocesses have stopped.

Published the continuation successfully: website commit 02aa5f28fcd8232b9b821979ff67bb5f80eadc3a, deployment run 34726622464. All four live routes and all seven download hashes match the release; the browser confirms the new dense and sparse interval statements. The user then explicitly requested resuming research.

### Resumption: all-order sparse endpoints and the full main interval

After the user requested resumption, the protected-difference proof reduced the required Sidon condition to the six signed differences between the three core moves. Greedy extension now gives explicit attainment for every 3n<=m<=n(ceil(n/7)-1), for all n>=25. This overlaps the probabilistic/dense interval eventually, proving the entire main interval from3n for all sufficiently large orders.

A new six-type construction supports type4 vertex removal by smoothing both permutation paths. Initial isolated-hole certificates gave every n>=385; independently checked local patterns with minimum hole gap3 reduce this to every n>=85. All1287 local certificates, including560885 required starts and10271740 alternating states, pass independent full rank/losing-closure checks. Thus M_V(n)=M_E(2n)=M(n,2n)=n(n-3) for every n>=85. This is a computer-assisted theorem with an ordinary all-ring projection, not full Lean verification.

Root found eight optional extra-arc types robust on the unmodified six-type strip. They failed near deleted vertices. The successful repair suppresses optional arcs whose tails lie within16 columns of any deletion. With up tofive holes atspacing17, atmost101columns are suppressed, leaving at least8k-808 optional arcs. Atk>=404 this supplies at leastn extras. The two local arena classes (augmented no-hole, unaugmented one-hole), with three boundary layers of exterior reentry, pass125 independent certificates. This proves every2n<=m<=3n for every n>=2419. Consequently the full conjectured main interval2n<=m<=n(n-3) is now established for every sufficiently large n. Its combined threshold remains asymptotic;2419 is only the sparse-bridge threshold.

An odd-extremal37-arc graph on19 vertices disproves a tempting completion implication: adding its unique degree-completing arc gives a two-regular graph that is not universally winning. A short four-cop-position trap explains the failure. New odd constructions remain under investigation.

Random two-permutation screens at n12,20,30,50,100,200 found no universally winning graph in40 samples per order, even after excluding simple source and target camping obstructions. These failures do not prove a probabilistic obstruction. A26-vertex girth-six orientation supplied a separately verified universal example; high undirected girth alone did not guarantee success across orientations.

### Resumption: sparse finite bridge, odd endpoint, and eventual joint formula

The finite bridge is complete:73 explicit two-in/two-out graphs at n12..84 pass both independent exact solvers and every actual-game rank obligation. Together with the uniform n≥85 theorem, this proves M_V(n)=M_E(2n)=M(n,2n)=n(n−3) for every n≥12. The saved full certificates occupy about29MB compressed; the unified constructor uses these finite arc lists below85 and the uniform formula thereafter.

The exact-budget probabilistic theorem was derandomized by maintaining B<C for the uniform prescribed-size completion space. Disjoint candidate arc triples produce explicit generating polynomials; coefficient extraction imposes the budget jointly. Two branch counts add to the parent, so one branch preserves the strict inequality, ending at integer B=0. Independent review and120 small exact conditional-count comparisons passed. An ordinary overlap calculation gives n≥10^12 as a conservative sufficient threshold for the ENTIRE2n..n(n−3) interval. This is an effective theorem, not an estimate of the true onset or a run of a trillion-vertex computation.

All six odd residue classes now have attaining constructions. A fixed six-type permutation family, smoothing a bounded set of vertices, then deleting one arc produces the required degree pattern. Several patterns failed under an exact-column safe-transfer objective. In residue5, allowing advances by either1or2columns and delivery from BOTHnearbycolumns2and3 succeeds. The recipient-distance process cannot skip the two-column target band; at most one wrap is needed. All750 nonzero-residue local modules independently pass complete rank and losing-closure checks, plus the separate97-module zero-residue certificate. The ordinary projection works at q≥25, hence every odd m≥289 attains the arc upper bound. No new Lean coverage is asserted.

Padding sparse extremizers with isolates now combines the exact even/odd arc formulas, main interval, final staircase, and zero into a full joint formula for every n≥10^12 and every m≥289. The ordinary deduction and all interval endpoints were independently reviewed. Finite arc thresholds and moderate host orders remain genuine gaps, not counterexamples to this eventual theorem.

An independent exhaustive two-permutation search proves that no two-in/two-out universal graph exists at n7..11; it matches a separate enumeration with different pruning and an explicit alternating solver. Both use factorization into two permutations and canonical cycle types, not an assumption that one factor is Hamiltonian. A known12-vertex positive control survives every pruning stage. Universal graphs with more than2n arcs DO exist at orders7..11, so the nonattainment result concerns equality in the vertex bound, not existence of any universal graph. Exact small maxima are being investigated separately.

### Protected dense envelopes close the main interval already at5442

A direct dense construction now uses missing core steps S={1,3,7}. Preserve the six ordered differences±2,±4,±6 uniquely and forbid±3,±5,±9 in an envelopeA. The three cop-missing successors intersect s+A in at mostone and t−A in at mosttwo; a complete obstruction would force a forbidden difference. Thus one remains a safe intermediary. Greedy growth excludes atmost13|A|+1 residues and reaches ceil((n−1)/13), giving every missing budget3n..nceil((n−1)/13). Arbitrary subsets of the optional missing arcs are allowed. The full ordinary argument was independently attacked, and root's separate min/maxgreedy implementation checked735000 pair/cop conditions on210envelopes.

At D7 the existing high-girth endpoint interval reaches3n for n≥5442. The remaining middle densities lie between1/8and12/13, where p²(1−p)≥7/512 and the exact-budget probability/derandomization condition holds. This lowers the COMPLETE main-interval sufficient order from10^12 to5442. It is a new elementary dense construction, not merely a tighter numerical estimate.

All odd budgets≥25 are now attained. Six small n13..18 witnesses pass both game solvers/full ranks;126finite n19..144 graphs pass all 10143saved objectives and215921496 alternating-state checks, including an independently rerun verifier. The uniform n≥145 theorem completes the range. Corollary47 therefore determines EVERY joint budgetm≥24 atEVERYhostn≥5442.

Small vertex maxima now include exact M_V(7)=21 and M_V(8)=32. The second proof uses a complete canonical row-cell enumeration, an independently proved relabeling/completeness argument, and a second descending/suffix enumeration with an explicit alternating game. The latter covers all178profiles in two clean completed intervals. Root's bounded15-second multi-hole smoothing search found a universal9-vertex24-arc graph withI48; both solvers and full ranks verify it. A similar10-vertex screen did not improve62. The11-vertex lower bound improved to84 through structured smoothing/repair. These lower bounds are not claimed exact.


### Incidence components remove the dense order bottleneck

Theorem50 gives every missing-arc budget2n..3n at every n≥166. Represent n=114+62k+r,52≤r≤113. Use the degree-eight projective incidence graph over F7, k degree-six incidence graphs over F5, and the previously verified degree-four girth-six graph on r vertices. Four perfect matchings in each bipartite component give an Euler-oriented outdegree-two core. Adding the remaining edges, oriented arbitrarily, supplies up to3n+(114−r)missing arcs while preserving girth-six and outdegree≥2. Thus the earlier two-move complement lemma applies at every intermediate budget. This is an ordinary algebraic/combinatorial proof, independently attacked; the executable checks also verify all62residual orders and330exact-budget constructions.

Combining this with the protected dense envelope eliminates the previous5442 order requirement. Outside the explicit ranges, density p lies between7/50and12/13, so p²(1−p)>1/60. At n2419 the probability condition follows from(n−3)/60>40>5logn and remains true by differentiation. The COMPLETE joint formula now holds for all n≥2419 and all m≥24. The sufficient threshold is not claimed sharp.

Theorem49 settles arc budgets8..11 exactly as4,5,6,8 using two complete independent sparse enumerations and an ordinary all-order support reduction. The11-arc witness uses7vertices. Verified12and13arc witnesses give lower bounds9and10; their unrestricted upper searches remain incomplete. A tempting three-layer shared-branch construction failed: a pursuer at another source can cover both common branches. No conclusion was taken from that invalid proposal.

Complete structured enumeration at n11 with22and23arcs, followed by independent recompilation/replay and direct witness rank verification, gives the unconditional boundI≤81 at both budgets. Combining this with the three near-equality support12 families sharpens the23-arc range to83≤M_E(23)≤86. The upper search is exhaustive in each reduced family; it does not settle the exact optimum. A separate15-second fixed23-arc n9 construction search found only44guarantees and did not improve the existing48-pair24-arc witness.


### Packed holes and modal conditioning: full main interval from1800

Theorem52 packs the deleted columns at0,3,..12 rather than spacing17apart. Their16-neighborhood excludes only45columns, leaving8(k−45)≥n optional arcs at k≥180. A new arena proof maps the wider R8 cop window withthree exterior reentry layers to the old proved R6 arena withtwo reentry layers: cop states outside[-6,6]collapse toΩ. Messenger moves, collisions, receipt, andsafe transfer are preserved. All865patterns/5886objectives passed directwinningrank checks, followed by full savedartifact readback. A separate explicit successor implementation independently checked286414cop transitions and4496692collisionequivalences. Arbitrary optional subsets remain valid because the messenger strategies use basearcs only. Thus every2n..3n budget is attained for alln≥1075, withdelivery≤9ceil(n/6)+26.

Proposition51 improves binomial conditioning. For L=n(n−1),T~Bin(L,m/L), Chebyshev places at least3/4mass in fewer than2n integer positions. Since m is the mode, P(T=m)≥3/(8n). Hence the exact-budget sufficient condition becomes(n−3)p²(1−p)>4logn+log(8/3), with unchanged deterministic completioncount algorithm. The independent ordinary audit foundno needfor independence between the bad-triple count andT.

Outside the explicit intervals and for n≥1800, 71/500<p<12/13 andp²(1−p)>173/10000. At1800 the exponentbound31.0881 exceeds31, which bounds4log1800+log(8/3) fromabove. An exactfiniteTaylor inequality verifieslog1800<7.5; derivatives handle larger n. Theorem44 andCorollary47 now hold at the current sufficientthreshold1800, for every admissiblem≥24. The threshold is not asserted sharp.

Final small-case search batch remained incomplete: centralizer-reduced n11,m24 counterexample search ran50seconds, completed3of42partialmatchingtypes, enteredthefourth, and foundnoI≥85 witness among2035323leaves. This does not strengthen anyupper bound. Exactpublic vertexbounds remain9:[48,53],10:[62,69],11:[84,87]. No searchprocesses are left running.


### The23-arc gap closes: exact maximum83

After the1800website checkpoint was deployed, a final focused extension of the already audited three-family search completed at cutoff84. No family reaches84: the absent-exceptional-arc class completes164276910nodes/16902091leaves in45.49s; presentarc andcommonvertex classes also complete. Campingprunes remain sound because they remove at least7eligiblepairs from at most90, so rejectedgraphs have at most83. The parameterized source explicitly rejects cutoffs below84.

A stronger ordinary active-set reduction at I≥84 handles the former gaps. In the(10,11)corner a forcedzero column gives84−b for1≤b≤7, whileb0forcesmanyzerocolumns. In the(11,11)corner b8 yields BOTH azero row andzero column, hence≤77. All otherpatterns reduce to the completed11vertexcorebound≤81 or the three12vertexfamilies. Independent ordinary andsource audits attack each boundary. Combinedwiththe existing dual-solver/fullrank83witness, this proves M_E(23)=83 and M(n,23)=83 for every n≥12. Exact remainingarc budgetsare12..22; no unknownvalue is filledbytheeventualformula.

### Result-catalogue audit after the 74-page release

The user requested an exact, nonredundant inventory rather than vague regional
summaries. Three independent read-only source passes and the root review
separated formula cases from construction domains. The retained domains,
stronger time guarantees, structural results, and superseded statements are
recorded in `research/result-catalogue-audit.md`. This task did not rerun
proofs or publish edits. Newly noticed candidate refinements to small even
arc bounds remain explicitly unaudited in that record.

## 2026-09-12/13: stronger-theorem research checkpoint

Executed priorities1and4 first, with independent proof attacks, while
pursuing sparse-envelope and dense-construction lanes. New ordinary results:
protected routing54 with exact incident count, arbitrary exterior subsets,
deterministic polynomial construction and explicit random bound; sharp
q2(n)=Theta(n log n) scale55 via a classical separator inequality and a new
game-to-separator reduction; even stability56 and odd support57; direct
dense cores/envelopes/attachments58. The general final staircase now starts
at24(previously75), the robust dense bridge at32(previously166), and the
all-delivery dense endpoint at10and everyorder≥12(previously52plus isolated
families). Firststep works≥16. General main/joint threshold improved in
place1800→1664; the sparse part is not being claimed two-move.

The dense lane initially obtained girth-based thresholds61/128, then found
the explicit two-type missing graph and superseded those new drafts before
publication. Prior girth/S6S7 notes remain research history. Root independently
rebuilt direct constructions, used literal witness tests and both actual-game
solvers:25cores,17envelopes,20firststeps,130staircaseinstances pass. Agent's
separate receipt records110cores,105envelopes,75firststeps,1,729staircaseinstances,
2,179,416robustness triples and308prefix checks. General proofs are symbolic,
not extrapolated from these finite tests.

Protected routing received independent ordinary proof review and literal
conditional-completion comparisons, including c=t. Core sample checks are
explicitly distinct from running the large derandomization algorithm.
Sparse stability received separate ordinary proof review and1,217,795bounded
arithmetic-case checks (notgraph enumeration). The bounded priority5 search
at22arcs found no81witness; source/coverage has not received sufficient
independent audit to promote a sharper exclusion. Best finite value is not
newly settled. Existing sparse rank policies preserve their eight optional
arc types but did not produce a dominating new construction; the potential
constant-only improvement is logged, not added to the theorem list.

ProtectedRouting.lean now proves preservation and actual two-move delivery
from explicit protected witnesses. Full7module pinned Lean rebuild passed.
Existence/probability/counting/near-extremizer reductions and direct infinite
dense constructions remain ordinary proofs. Author/mentor credit unchanged.
See research/unification-dominance-audit.md for exact supersession boundaries.

## 2026-09-13: genuine composition and concentration phase

The new antichain/core composition theorem replaces probabilistic middle
coverage for the numerical main-interval onset. With resynthesized sparse
policies and explicit protected-circle parameter certificates, the main
interval now starts at115. Root's generic antichain proof received a separate
case-by-case attack; mixed116 has1,053,860 literal asymmetric witness checks.
Both finite arena implementations cover all 101 canonical sparse crop
patterns, with an ordinary coverage/projection proof. Arbitrary gap3 hole
sets fail: recorded crop[-3,1], target4. More messenger room alone does not
improve the worst local terminal rank38. A multi-entry-column refinement is
being checked before changing the advertised time bound.

Dense11core and oddbridge23/25/27/31 independently checked, closing those
small gaps. New modular dense envelopes have full ordinary drafts and finite
checks; independent ordinary audit pending. Support concentration survives
independent algebraic review and4165 exhaustive smallgame comparisons;
a second count improves the initial supportconstant6eta to4eta. No game
monotonicity under core restriction is inferred from that count.

Fastcomposition tests reject naive quotient/cover transfer; one connected
24-vertex doublecover has119 losing starts for target2, including115 whose
base projections are distinct. A ten-type two-generator safe-navigation
interface is promising, but terminal delivery is incomplete. No fastsparse
infinitefamily has been promoted. See research/phase2-checkpoint.md and the
phase2/composition-interface notes for exact files and proof boundaries.

### Final phase-two refinements before publication

The M5 two-entry repair passes both independently written localgame solvers
on all 101 crops/696 objectives. It improves sparse52 to9ceil(n/6)+21 moves,
not merely a lower order threshold. A complete executable main-interval
constructor now selects the proved family and exact arrows at every n≥115;
223 boundary examples, all276 finite overlap parameters, and3,412,797 actual
two-move witness triples pass.

The dense greedy attachment check immediately closes19..21, then16..18;
all six explicit lists and full asymmetricwitness receipts pass independent
readback and root literal checks. The robust dense bridge now starts16.
Both quadratic densecap proofs passed independent ordinary audit, so58
subsumes the entire numerical domain of old48. Fixedcores10..15 only yielded
partial caps; these are research evidence, not nonexistence proofs.

Lean now has10 passing pinned modules, including robusttwo-move envelope
semantics and the explicit11vertex88arc22guarantee core. Full59/60and the
infinite constructions remain ordinary. SmallDenseEnvelopes also kernel-checks
all six16..21 row lists, counts, and robust actual-delivery statements. The old41proof is archived outside
the main text because52strictly improves all its numerical/time/subset
claims. The honest catalogue delta is30−1+2=31: numericaldensefragmentation
shrinks, while antichain composition and supportconcentration add new
structural content. See phase2-dominance-audit.md.

The final fast-composition audit independently rebuilt all finite transitions
and replayed825843 rank obligations. The common twelve-exclusion interface
normalizes in2, navigates in32, and completes eight recipienttypes within62.
The shrinking-cone projection works at quotientgirth133, giving32D+64
for those eighttypes. Types2/7 remain open: the infinite-tree camping
obstruction requires global finite-quotient bypass information or a new
gadget; the2.2n-arrow repair failed. This partial theorem does not assert
universal delivery or a logarithmic directed-diameter family.

Publication complete: researchcommit e70cb4c, sitecommit427472a, successful
GitHub Pages run34745653181. The88page/8figure manuscript was fully rendered
and visually reviewed; sourcearchive recompilation matches its text, and
all10 Lean modules pass with pinned source hashes. The research archive
contains600 checked source/evidence files. Public readback verifies all
eight download hashes and all four routes; live browser review confirms
current thresholds, partial-fast-result scope, zero matherrors and no
horizontal overflow. The full extremal classification remains open.


## 2026-09-13 — Website and publication artifact audit

Audited the live-facing pages, manuscript structure, archive contents and
source-hash receipts before editing. The prior eight published download
hashes were consistent. Found stale date/status sentences, two redundant
argument bodies, a flat 38-section proof catalogue, and historical evidence
mixed with current dependencies without an entry guide. Three source pins
refer to earlier versions; their exact hashes and scope are now classified
in the evidence index. The tiny dense receipt's literal witness data remains
current evidence despite its historical producer pin. No mathematical
counterexample or new theorem resulted from this editorial audit.

The source manifest now assigns every main section and supplement to one of
eight chapters, retaining all theorem labels and independent guarantees. The
redundant 23-arc reduction and full-vertex probability proof were replaced by
precise references to their stronger theorems; removed text is preserved in
research/history. The evidence guide identifies current proofs, certificate
replay, regeneration, and historical records. Website dates use the release
manifest, and downloads retain their existing URLs and four-page structure.

Build safeguards now stage the served output, reject unclassified files,
hash all loose figures/Lean files as well as root downloads, and replay the
standalone TeX package in a fresh temporary directory. Research archives
include their guide, machine-readable index, chapter manifest and figure
sources. Validation and deployment outcomes are recorded separately after
the rebuild; the preceding deployment entry remains a historical receipt.


### Artifact-audit release verification

Published source commit212fa69/site4d10f2a via successful Pages run34746687576.
The87page/eightfigure PDF was rendered on all pages, visually inspected,
and recompiled from a fresh extracted source archive. A repeat build produced
identical PDF bytes. All63 numbered labels and79 prior proof heading anchors
remain;135 local links/assets have no missing targets. The independent
audit passed all31 served assets and all four archives (624research,
15Lean,10manuscript,2finite entries), with179 source pins and exactly the
three classified historical exceptions. A deliberately added stale file was
rejected. Live HTTPS readback matched all31 hashes and all four routes;
browser proof-page review showed eight chapters, current date, zero formula
errors and no horizontal overflow. No new theorem or full formalization is
claimed. The original10 Lean modules were unchanged and their pinned hashes
were checked; this turn did not repeat the Lean compiler or game searches.

## 13 September 2026: fix the scope and audit the remaining classification

Angel authorized artifact reorganization before further research. The active objective is now explicit: exact M(n,m), with a proved attaining construction, for every n>=1 and admissible m. Vertex-only and arrow-only maxima are consequences. Specialized delivery-time optimization and the broader structural D(G) programme are parked; count-relevant safe routing and natural termination bounds stay in the main proof.

The manuscript introduction, website overview, README and HANDOFF were rewritten around this objective. The two-move sparsity results and complete conditional eight-type fast checkpoint were extracted into a separate companion, with their ordinary proofs, finite certificate boundary, failure examples and provenance preserved. The main proof retains all 63 numbered labels; the moved budget-section anchor points to the companion. The builder now recompiles both standalone source archives and audits both artifact sets.

The source-based coverage ledger lists the remaining representative pairs and records lower/upper rules, certificate roles and isolate-padding provenance. All unresolved values have a representative at n<=114. Exact per-order intervals are exposed on the website and in the private gap assessment; the containing box is not confused with the unknown set. The ledger states exactly which conditional constructions were instantiated and which require further deduction. Dated prior checkpoints retain their historical status and original receipts.

The assessment separates unknown numerical values from proof maturity, reviews failed hole patterns, finite interpolation, odd completion and contraction shortcuts, and proposes concrete next investigations. One priority is to instantiate the even-core part of the existing antichain theorem by counting independent sets on its two difference-two cycles; this is a proposed next investigation, not a new theorem claimed in this release. The sparse local interface and the remaining small-budget and dense exceptions stay inside the same objective. The unfinished fast eight-type programme is not a classification prerequisite.

This turn performs source organization and evidence auditing, not a new extremal search. No new Lean theorem or full formal classification is claimed; current Lean source identities are checked against the existing verified receipt. Build, visual inspection and deployment completion are recorded separately in their dedicated receipts and the subsequent release entry.


## 13 September 2026: scoped classification artifacts deployed

The reorganized checkpoint is live at https://angelraychev.com/cop-prisoner/. Website commit `65df9f4b4a9405d6c6463ef45f8ff7ead9fd7b10` was deployed by successful GitHub Actions run `34750333023`; research source commit is `49b6ea367b0dd614c75e283a95b01abe93e1584d`. The prior Princess-only site update was preserved.

The main manuscript has 86 pages and eight figures; the separate parked delivery-time companion has eight pages. Both standalone TeX archives were recompiled and matched their respective published PDF text. All 94 final PDF pages were visually inspected. All 63 numbered main-result labels and the moved two-move anchor are preserved. The local five-route check covered 154 links/assets with no broken targets. Live HTTPS readback matched all five built pages byte for byte and all 33 served-asset hashes. Browser checks found no formula errors or horizontal overflow.

The independently audited numerical coverage leaves 61,742 canonical representatives outside the explicitly incorporated proved domains: 288 sparse, 61,393 main-interval, and 61 dense. The containing order bound is 114. This is an inventory of current source coverage, not a claim that every consequence of the conditional theorems has been extracted. The fixed `(11,22,71)` witness was reverified as a lower bound. No new extremal search or full Lean classification is claimed. Current Lean source pins match the existing receipt; the Lean compiler was not rerun in this editorial/audit checkpoint.

Current scope: `research/CLASSIFICATION_SCOPE.md`. Exact ranges, attempts and prioritized next investigations: `research/CLASSIFICATION_GAPS.md`. Independent coverage review: `research/classification-coverage-review.md`. Actual live verification: `research/website-deployment.json`. The source package was frozen before this appended deployment note; no archived source was overwritten to retrofit a receipt.


## 13 September 2026: explicit-construction scope correction

Angel clarified that the objective requires concrete adjacency rules or specified composition procedures with parameters from(n,m), separately from the exact value. Generic search, existence, and derandomization alone are insufficient; certified listed finite exceptions qualify. The numerical reduction to order114 is now explicitly separated from the construction audit. No new gap-solving or graph searches were launched.

Three source audits checked main, sparse and dense families. They found direct recipes or fixed certified graphs for every provider of a currently recorded exact value. The complete main interval at n>=115 already has a nonderandomized sparse/circle/antichain/dense procedure. Removing orientation's conditional-expectation contribution leaves all finite-box bounds unchanged. This supports an empty known-value construction-only list for the current indexed coverage without relabelling probabilistic/conditional-expectation results or transferring their stronger properties to replacement graphs. All numerical values and61,742canonical unknown-value representatives remain unchanged.

The new central inventory is research/EXPLICIT_CONSTRUCTIONS.md, with component source audits and a separately reproducible construction-coverage receipt. Scope, gaps, handoff, manuscript and website summaries now require both obligations at every pair. A unified executable is optional usability work; finite explicit parameter selection and greedy/code procedures with proved conditions already qualify. Original theorem statements, certificates and the precise Lean boundary are preserved. Build and deployment verification are recorded separately after the corrected sources are frozen.


## 13 September 2026: explicit-construction scope correction deployed

The corrected scope and construction inventory are live at https://angelraychev.com/cop-prisoner/#explicit-constructions. Research source commit `391877a3a1a6c1980b48e8bcc0df5ac464721a64` and website commit `5611b654a49ed77511ff6fee154999faefa92914` identify the release. GitHub Actions run `34753363908` succeeded. Live readback matched all five built pages byte for byte and all 33 served-asset hashes. Browser inspection confirmed the separate construction requirement, the audited zero known-value construction-only gaps, the 87-page manuscript link, no formula errors and no horizontal overflow.

The main manuscript has 87 pages and eight figures; all pages were rendered and visually reviewed. Its standalone source archive recompiles to matching PDF text. The eight-page delivery-time companion PDF is byte-for-byte unchanged, retains its prior visual review, and its source archive was freshly recompiled. All 63 numbered main-result labels remain. The local five-route check covered 160 links/assets without broken targets. The artifact audit passed 157 referenced paths, 289 source pins, the three classified historical exceptions, and all archive contents. Lean source hashes remain unchanged; the compiler was not rerun.

No numerical result or remaining interval changed. The normalized numerical rows retain SHA-256 `c067c951ccd496f6f9642292af03680f85a5acc43fd2669dd7a37b7ecc4a40ad`. The source audit independently found a direct recipe or certified listed finite graph for every currently indexed exact value. All 61,742 canonical unresolved numerical representatives still require both their exact-value proof and an explicit attaining construction. Conditional-expectation results retain their methods and stronger properties; alternative count-attaining graphs do not inherit those properties automatically. No new extremal search or mathematical gap-solving was performed.

See `research/EXPLICIT_CONSTRUCTIONS.md`, `research/CLASSIFICATION_SCOPE.md`, and `research/CLASSIFICATION_GAPS.md` for the operative boundary and exact family domains. `research/website-deployment.json` records the live verification. This post-release note is appended after freezing the source archive; the archived prefix is unchanged.


## 13 September 2026: bounded classification research after the scope audit

Angel authorized execution of the five named priorities, including explicit recipes. This pass stayed within joint extrema and their constructions. Specialized time optimization and classification of all extremizers remain parked. No outreach or submission occurred.

The all-parity code calculation resolves the even-core omission: its forbidden point graph is two cycles, giving a convolution of independent-set counts. This is an ordinary counting proof, not a numerical extrapolation. Literal circles at100..111, a saved mixed105 code family of weight268, and47 finite sparse envelopes plus a repaired109 envelope connect the full main interval from106. The old115+ ordinary proof and its stronger component guarantees remain. The new dispatcher passed171 finite boundary constructions,8,179,380 asymmetric code witnesses,323,910 dense witnesses, and an unchanged-output regression for the prior domain. The direct constructor never runs the discovery searches.

Exact22-arrow attainment is79 on11vertices, hence on all larger hosts by isolates. The upper proof combines original-graph support bounds with reviewed complete regular-core exclusions; the new fixed lower graph has both solvers and complete rank checks. New14/16upper bounds are22/32;18/20now have certified intervals30..44 and50..58. Independent attack found a gap in an initial stronger support proof's surplus/sink equality case. The repaired argument uses two outer diamonds and a restricted inner game; it does not assume that deleting exceptional arrows preserves delivery. Complete transfer-family enumeration is a stated premise for18/20; review checked its Hall normalization, pruning and directions, without claiming a second full enumeration or Lean proof.

Dense colored cycles and singleton attachments remove the old root-capacity restriction for r>=5. Exact missing-block additivity admits a9vertexcore requiring up to3moves. With three fixed first-step attachments, the whole dense band is explicit from13within4moves, and from16within2moves. The r2equality theorem reduces attainment to the(n-2)-vertex dense endpoint, giving strict upper bounds9 at(7,30) and11 at(8,42), still unclosed. Independent review rechecked the finite ranks and the strategy argument.

Bounded failures are retained: selected greedy circle trials did not reach every target size at100..105; the mixed-code optimization supplies a feasible list, not an extremal theorem for M; a short8core probe reached12 of16missingpairs without an exclusion. The known bad arbitrary gap-three crop remains a barrier to an unrestricted sparse interface theorem. No finite successful circumference is extrapolated to an infinite family.

Coverage now has48,546 canonical unresolved pairs (254sparse,48,271main,21dense),13,196 fewer than61,742. The audit still covers the same493,924 cells throughorder114;444,568 areexact. Every unknown representative hasorder<=105, while smallbudgets 12..21reduce tosupport<=42. At105only3466..3471remain. The exact per-order gaps and proposed next directions are in CLASSIFICATION_GAPS.md. The construction inventory remains separate: direct alternatives must be audited rather than inferred from numerical equality.

Proof sources: paper/core-code-composition.md, paper/sparse-packed-holes.md, paper/sparse-third.md and paper/dense-third.md. New finite evidence is indexed in publication/evidence-index.json. No new Lean result is claimed; the existing formal source/receipt boundary is preserved. Artifact builds and deployment are recorded separately after their actual completion.


## 13 September 2026: stronger classification checkpoint deployed

The updated site is live at https://angelraychev.com/cop-prisoner/. Website commit `ea97ba9d64366a46daf0c8fe605c3555d066d17a` deployed successfully in GitHub Actions run `34756071574`. The research source commit is `0f61bfc7af983aa5ce89ca4557fb80119cd773d8`. The preceding Princess site changes were preserved.

Live readback matched all five routes and all 33 served asset hashes against the local build. The main manuscript is 101 pages with eight figures. All pages passed visual review; its standalone source recompiled with matching text and no overfull boxes. The unchanged eight-page delivery-time companion retains its separate review. All 168 checked website links and anchors resolve, and 63 existing numbered statement labels remain. The consolidated sparse certificate bundle is included in the research archive.

The checkpoint closes 13,196 canonical unknown pairs. The remaining 48,546 split into 254 sparse, 48,271 main-interval and 21 dense cases. Every incorporated exact value still has a separately audited direct recipe or certified finite graph. Exact22=79, the full main interval from106, the full dense band from13, and the reviewed sparse bounds are recorded above and in the gap inventory. Full classification remains open. New results are ordinary or computer-assisted proofs; no new Lean compilation or formalization is claimed. Existing formal source hashes match their retained receipt.

## 13 September 2026, 05:37 PDT: main-interval brainstorming and two new constructions

Angel requested substantive ideas for attacking the broad middle gap, not a new publication pass. Read-only source review and bounded independent mathematical work produced the two constructions below. These have ordinary proofs independently attacked by another agent; the root also independently checked the stated order-60 examples against the full optional pursuer envelope. This entry preserves the deductions without launching a full coverage computation or artifact rebuild. The manuscript, website, Lean files, and numerical ledger have NOT yet incorporated them. Their old gap counts now describe the preceding published checkpoint, not the full consequences of this entry.

### A. A cheaper second routing layer

Use the existing fourteen-hub core, P_i,L_i indexed modulo7, with missing arrows P_i→L_i,L_(i−1) and L_i→P_(i+4),P_(i+6). Its154 other nonloop arrows are present. Choose2≤g≤14 guides. Their distinct omitted hub triples are the first g of the14 triples

    {L_i,L_(i+2),L_(i+4)}, i=0,...,6;
    {P_i,P_(i+1),P_(i+4)}, i=0,...,6.

All are admissible codes in Theorem59. Add b bulk vertices, 0≤b≤binom(g,2), so n=14+g+b. Assign the bulk vertices distinct guide pairs, taken in lexicographic order. Every bulk vertex reaches the same hub set

    S={P_0,P_1,P_4,P_5,L_0,L_2,L_4,L_6}

and its assigned guide pair. Every guide reaches the11 hubs outside its omitted triple. Every hub reaches every outside vertex. No guide-to-guide arrows are included. Guide-to-bulk and bulk-to-bulk arrows are independently optional; no other arrows are optional.

The compulsory budget and full interval are

    A=154+14(g+b)+11g+10b=24n−182+g,
    A ≤ m ≤ A+b(g+b−1).

All missing pairs deliver in at most three messenger moves, for every optional subset. First establish two-move delivery from every hub or guide, against EVERY pursuer including bulk vertices. Against hub/guide pursuers, reuse Theorem59's hub witnesses. Against a bulk pursuer, H\S has three vertices in each hub part. A missing hub pair's danger set has only two in each part. A guide source has a code in one part, so all three safe hubs in the opposite part are reachable; they all reach an outside target, and at most two fail to reach a hub target. This also checks the delicate guide-source/hub-recipient/bulk-pursuer case.

A bulk source first safely enters the already winning hub/guide layer. Against a hub cop, S meets its missing row. Against a guide cop, choose one of the source's two guides other than that cop; guide-to-guide arrows are absent. Against another bulk cop, use a guide in the difference of their distinct equally sized guide pairs. After the cop's response the two-move strategy applies. All witnesses avoid the full optional cop envelope, so there is no unjustified edge-monotonicity assumption.

At n60,g10,b36 this gives1268..2888. At n80,g11,b55 it gives1749..5324, overlapping the old circle endpoint1760 and the old upper construction. A fixed g12 gives A=24n−170 on26≤n≤92. Preliminary overlap arithmetic places its base below the existing circle endpoints at77..92; this has not yet been incorporated in or used to recompute the ledger. Separate low-budget gaps still exist in that order range.

Independent evidence: the root constructed the n60 base and full envelope without project solver imports, found universal-source ranks≤3 for all60 recipients, and checked134,048 nonterminal source/cop rank obligations. Hub and guide source ranks are≤2. An independent agent checked every ordinary proof case, including all new bulk-cop configurations. No Lean claim is made.

### B. Half-density circles using three-way branching

For every n≥24 divisible by4 there is a direct robust attaining family at

    8n ≤ m ≤ n(n/2−2).

Choose h≡3 mod4 with h≥11, 2h+2≤n and gcd(h,n)=1. A parameter rule providing such h at every stated n is:

* If8 divides n, set h=n/2−1.
* Otherwise n=4k with odd k≥7: use h=k+2 when k≡1 mod4 and h=k+4 when k≡3 mod4.

In the last two cases the gcd with4k divides8 or16 and is odd, hence is1. The size and congruence conditions follow directly.

In Z/nZ set

    A={x:x mod4 is0 or1} ∪ {h} \ {2h−5,2h−1},
    C={1,5,h−7,h−3,h−2,h,h+1,h+2}.

A is the closed-move envelope (0 included); C consists of eight distinct nonzero compulsory moves, all in A. Its size is n/2−1. Let B have every translated C-arrow and E every translated nonzero A-arrow. We prove every B⊆G⊆E universally winning. Taking the first m−8n optional arrows in row order supplies exact budgets.

Safe branching claims, relative to source0: no cop q≠0 covers either pair {h,1}, {h,5}, or a triple {h,u,v} where the other two entries are either one0-mod4 and one1-mod4 move, or two distinct1-mod4 moves. For a cop covering h, residue q=1 is impossible. Residue q=0 forces q=0, since h is the only3-mod4 envelope point. Residue q=2 reaches no0-mod4 point and at most one1-mod4 point; residue q=3 reaches no1-mod4 point. This proves the triples. To cover a protected pair, q must be1−h or5−h respectively; reaching h then requires the removed offset2h−1 or2h−5. Thus those pairs are also safe.

A source is universally winning once one of its safe pairs/triples consists of already universally winning vertices. This uses only compulsory messenger moves and excludes the full closed cop envelope, so survives arbitrary optional subsets.

For recipient0 put P(z)={z,z+3,z+4,z+5,z+7}. P(−h−5) is seeded by four direct predecessors, with its first vertex using moves h,5 to the direct predecessors−5,−h. Starting from P(z), the following ordered additions give P(z−2h). Each line lists the new source relative to z, followed by its safe move offsets:

    3−h:  h,h+1,h+2
    5−h:  h,h−2,h+2
    7−h:  h,h−3,h−2
    5−2h: h,h−2,h+2
    −h:   h,5
    4−h:  h,1
    −2h:  h,5
    3−2h: h,h+1,h+2
    4−2h: h,1
    7−2h: h,h−7,h−2

Every successor occurs in the original P(z) or earlier in this list. The desired offsets−2h,3−2h,4−2h,5−2h,7−2h are all obtained. Since gcd(2h,n)=2 and P has both parities, repeated shifts cover every vertex. Translation gives every recipient even for nonsymmetric optional subsets. Modular coincidences merely identify already winning vertices and do not invalidate the induction.

The earlier three-protected-difference circle ceiling |A|≤ceil(n/3) remains valid for that OLD template: its three translates intersect pairwise only at0, so3|A|−2≤n. This new family drops one protected pair, pays for extra compulsory moves, and uses three-way branching instead; it does not contradict that ceiling.

At n60 a valid choice is h11, giving

    A={0,1,4,5,8,9,11,12,13,16,20,24,25,28,29,32,33,36,37,40,41,44,45,48,49,52,53,56,57},
    C={1,4,5,8,9,11,12,13}.

Its interval480..1680 contains the entire formerly unknown order60 middle interval841..1655. Combined with the preceding checkpoint's other recipes, the order60 main interval120..3420 is therefore covered. Root replayed all targets independently:180,540 nonterminal source/cop obligations, maximum computed source rank17; successive universal-source layer sizes9,4,3,4,3,3,4,4,4,4,4,3,3,2,2,2,2. A separate agent independently audited the entire symbolic general-h argument, including the minimum order, wraparound, parameter choice and termination. No finite experiment is extrapolated to prove the infinite family.

### Remaining ideas and failure boundaries

1. Generalize the circle pattern to orders not divisible by4, with a proved boundary interface; adding/deleting vertices blindly is not valid. Also seek a smaller compulsory move set with a finite seed and a parameterized propagation proof. The current circle only starts at8n.
2. Consider further routing layers with a strict layer decrease. The two-layer construction works because all opponent locations are handled at entry; this is not permission to clone guides or stack arbitrary modules. The old gate-camping and double-cover failures remain relevant.
3. A cheaper two-move architecture could use distinct source-access sets S_x and target-access sets T_x. For outside source s, recipient t and cop c it needs S_s∩T_t\S_c nonempty (unless delivery is already direct). Complementary choices T_x=H\S_x reduce incident edge cost but require S_s\(S_c∪S_t) nonempty for distinct s,c,t and also separate hub cases. A tempting three-element set family can force the hub core empty under the strongest robust condition, after which hub-to-hub delivery fails against an outside cop. Code counting alone is insufficient; core and routing must be designed jointly.
4. Structured additions could be required to occur in bundles rather than all subsets. A destroyed old witness can then be replaced using one of the same bundle's new messenger moves. Any claim still needs finite decreasing ranks for every cop reply and exact-budget residue handling. Neither of the two new constructions above sacrifices arbitrary-subset robustness.

No graph search, coverage update, website deployment, manuscript expansion or formalization campaign was launched for these speculative directions. The next execution pass should integrate and independently recompute the consequences of A/B before selecting further unresolved domains.


## 13 September 2026: main-interval constructions integrated and independently reviewed

The execution pass strengthens the previous eight-move circle idea to five compulsory offsets, restores the formerly excluded h-2 move, and proves guarded intervals for further orders. For every4|n,n>=16, a concrete cop envelope gives every5n<=m<=n(n/2-1). Its cyclic rank proof uses a four-source pattern and gcd(h,n)=1; it does not assume that indefinite safe travel reaches the recipient. The old eight-offset family remains a valid subfamily.

The layered proof now has both a14hub version and a cheaper12hub version. The latter uses two weight-three and six antipodal-pair guide codes; applying the old size-three antichain theorem directly would have been unjustified. A separate local proof checks the pair-code cases. Equal-size bulk guide sets are concrete lexicographic subsets, and optional guide-to-bulk and bulk-to-bulk arrows remain arbitrary. Safe entry plus two further moves proves delivery within three moves. A mixed-code extension was explored privately but did not close further current numerical gaps and was parked.

Independent proof reconstruction (no producer imports) checks145 envelopes,1,238 recipients and4,416,069 rank obligations. Separate source review checked the final wraparound, seed and four propagation steps, and the Lean bridge. The general proof is ordinary; finite checks support rather than replace it. All11 Lean modules pass; RobustLayers proves generic source-rank and safe-entry envelope composition. Concrete residues, guide codes, formula counts and overlap are not claimed Lean-formalized.

The new direct recipes and previous ones cover3n..n(n-3) at every n>=43, and2n..n(n-3) at every n>=104. Exact finite parameter chains43..105 join the preserved106+ constructor. The independent arithmetic review corrected sparse endpoint typos at104/105 to316/327, then verified63 chains,274 intervals and837 constructed boundary/tail graphs. These endpoints both reach3n; the theorem is unaffected.

Compared with the frozen preceding ledger, all444,568 old exact values and all bounds are preserved;42,130 new pairs become exact. Remaining canonical numerical gaps:6,416=254sparse+6,141main+21dense. Main gaps split2,248below3n and3,893at/above3n, the latter all at n<=42. The former extend to103, where306..308 remain. The old raw audit box1..114 is retained so comparisons stay meaningful. Zero known-value explicit-construction gaps are recorded by the separate source audit, which must be rerun after source freeze.

Next research priority: prove wider sparse optional envelopes closing the2n..3n band; next seek cheaper/more flexible hub or circle recipes at orders<=42. Small sparse and dense extremal exceptions remain unchanged. No new investigation beyond this checkpoint is launched during artifact integration. The main and companion publication scopes remain separate. Public build and deployment completion are recorded only after their checks pass.


### Fourth main-interval checkpoint: final build verification

The107-page main manuscript and nine figures are built. All107 pages were rendered and reviewed; the final wording/figure rebuild changed only pages3,6,60, which were reinspected, and104 other page renders are identical. The eight-page companion PDF is unchanged. Standalone source replay has matching text and no overfull boxes. All eleven Lean modules pass, with the generic RobustLayers boundary stated above. The final artifact audit checks35 served files,231 referenced paths and475 source pins, with six explicitly historical source-pin mismatches retained unchanged in their original receipts. Five local routes have176 checked links/assets and no broken targets; all63 earlier numbered result labels remain. This entry records build verification. Consult research/website-deployment.json for the separate live deployment/readback result.


### Fourth main-interval checkpoint: live publication verified

Website commit eed8def30ed5badd8a7b287b193737ce12b18842 is live; GitHub Pages run34759149978 succeeded. Fresh live readback matches all35 served asset hashes and allfive route HTML files to the local build. Both large archives were fully downloaded and verified; a first timeout did not count as a successful check. The107-page/nine-figure release reports6,416 canonical gaps (254sparse,6,141main,21dense), with zero audited known-value construction-only gaps. The live overview and interval figure were also visually checked. Research source commit1a226ec contains the mathematical checkpoint; research/website-deployment.json records this subsequent readback. The project remains unsubmitted and the classification remains open.


## 13 September 2026: private threshold-bridging ideas and finite checks

The bounded response to Angel's request for serious threshold-lowering ideas produced two concrete modifications: six-offset circles with three-way escape, and coordinated reductions of bulk-to-hub access and hub-to-guide cop moves. Root independently reconstructed and replayed 27 full optional envelopes for all 872 recipients, with 689,714 nonterminal obligations plus 125,564 stronger top-intermediary obligations. They fill all formerly unresolved middle cells at n28..42 and n26. Combined with the existing43+ theorem, this supplies a finite-certificate extension to n>=28 for 3n<=m<=n(n-3). It is not yet incorporated in public summaries or Lean. At n25..42 exactly n25,m326..339 and n27,m352..375 remain in this middle range. The sparse band and its maximum unresolved order103 are unchanged.

The worked-through sparse proposals are staged messenger bases against successive cop envelopes, then a marked order-extension operation with net+2/+3 arrows. The note records exact capacity barriers, recipient-delivery failures of past splices, and proof obligations; no new sparse theorem is claimed. See research/threshold-bridging-ideas-2026-09-13.md and its frozen JSON/replay script. No website, manuscript, public ledger, or formalization artifacts were changed during this ideas pass.


## 13 September 2026: complete main interval from order twelve

All four authorized directions were attacked. Staged additions succeeded because the messenger can use earlier added arrows; fixed old policies had no unused global capacity. The first order-15 chain stalled, and a new fixed ordering repaired it. Longer ascending chains and reverse deletions from dense endpoint graphs meet at 6n for orders 12 through 18. Independently checked prefixes join the new circle and hub families for orders 19 through 42 and the retained tail. The exact theorem is now M(n,m)=n(n-1)-m for every n>=12 and 2n<=m<=n(n-3), with explicit recipes. The threshold twelve is sharp because M(11,22)=79<88.

Two general families support the bridge: six compulsory circle offsets with three escape choices, and a reduced twelve-hub interface with bulk vertices carrying antichain codes. The latter has A=106+18g+12b+W compulsory arrows and b(g+b+8) optional arrows, all subsets allowed, with delivery in at most five moves. Ordinary proofs and independent literal replays passed. Fixed promoted circle envelopes have separate source-rank certificates. The finite staged bridge has 67 records and 638 envelopes: 53,678,566 state checks and 177,279,925 cop-reply checks in independent direct replay, plus separate Python rank and alternating-queue crosschecks, including orders 91 and 103 and the new upward and downward stages. No infinite theorem is inferred by sampling circumferences.

The marked-extension direction independently certified fixed 25-to-26 and 26-to-27 whole-budget-family transports (106 graphs, 2,810 recipient games). It also proved why repeated attachment using only the newest vertex's ports fails: a new recipient has its complete predecessor set covered by one cop neighborhood. Refreshed ports or additional rewiring are needed for a repeatable small rule. This is a possible simplification, not a missing step in the finite-bridge proof.

The new dispatcher is src/main_interval_complete.py. Independent regression compared all 493,924 cells, preserved all 486,698 earlier exact values and every bound, and validated 5,962 newly exact cells. The remaining 454 canonical pairs split into 254 sparse, 179 main and 21 dense cases; main exceptions have orders 7 through 11. Every admissible n>=13,m>=22 has its value and explicit recipe; at n=12, dense budgets 109 and 112 remain open. Unknown small budgets 12 through 21 reduce to support at most 42. The separate construction audit still finds no known-value recipe gaps. All twelve Lean modules pass; StagedEnvelopes formalizes generic position-dependent rank semantics, not the external concrete classification.

Canonical scope, gap register, handoff, manuscript and web sources are updated. Build and deployment verification remain separate receipts; this entry asserts mathematical/source completion only. No arXiv submission or outreach was performed.

Release reproducibility review found that the historical staged producer selects gaps from the old ledger and is unsafe to rerun against the now-complete ledger. Its pinned source and frozen evidence are preserved. The new read-only src/check_sparse_staged.py is the canonical full release verifier; it passed all 638 stages and guards against overwriting frozen inputs. The evidence guide explicitly distinguishes these commands.

Release verified: the 114-page manuscript, all 36 served assets and all five HTML routes are live at website commit c04b3241007156f8d704b28956a74a633dc8de67 (Pages run 34762675567). Each live file matches its local hash. Both new evidence checks also passed from a fresh extraction of the final research download, without workspace or network dependencies. The source checkpoint is 92b1169. All 114 PDF pages were visually reviewed; the final spacing change affected only page 68, which was reinspected. Research remains open at the 454 canonical pairs listed above.

## 13 September 2026: small-case pass and independent consolidation

The active classification now has 101 unresolved representative pairs: 69 sparse
and32 main, no dense, all hosts at most18. The independent regression preserves
every old exact value and reconstructs all493,924 audited cells; it distinguishes
174 newly exact cases from179 still-unknown host repetitions removed by the
stronger reductions. Every admissible n>=11,m>=22 now has an exact value and an
explicit graph; the full n7 table and entire final dense band are complete.

The complete research record, including false leads, corrected root semantics,
comparison-witness repairs, resource decisions and proof boundaries, is
`research/small-case-execution-log.md`. Start at
`research/small-case-results.json` for the consolidated evidence and at
`research/CLASSIFICATION_GAPS.md` for the remaining scope. The construction audit
finds zero known-value construction-only gaps in the incorporated coverage;
unknown pairs still require both a value proof and a direct attaining graph.
New concrete finite proofs are externally reviewed, not a complete Lean theorem.
Build and live release claims require their separate receipts.

The small-case checkpoint is now built and live: website76eb745, successful
Pages run34768459410. All five routes,36 served assets and the release manifest
match fresh public readback. The130-page PDF, exact archive replays and mobile
layout checks passed. See `research/website-deployment.json` and the final
HANDOFF entry for the precise checks. Research remains open at101 representative
pairs; no background graph search is running.


## Complete classification and explicit attainers (final finite pass)

All101 formerly unresolved canonical pairs now have matching upper proofs and
explicit attaining graphs. The independent closure replay preserves all 492,834
previously exact stored cells, adds 1,090 exact host/budget cells, and checks
493,924 admissible pairs through order 114 with zero unresolved cells. Ordinary
parameterized constructions and finite-support reductions give the unbounded
classification; no extrapolation from the audit box is used. A separate recipe
audit finds zero numerical gaps and zero construction-only gaps.

The newly final arc maxima for budgets 12..21 are
9,11,13,15,19,28,33,40,53,60, with least attaining hosts
7,8,8,8,8,10,9,11,10,12. Complete finite tables cover all orders 1..11;
the uniform formula applies from order 12. Exactness includes the corrected
small hosts, such as M(9,22)=40, M(10,23)=61 and M(10,25)=65.

The principal useful reduction was to fix incoming and outgoing degree
partitions together, charge all source/sink arrows against the remaining live
rows and columns, and enumerate only residual patterns that could beat a saved
literal. Initial best-found graphs were not mistaken for optima: several scores
improved during complete enumeration. A restricted camping shortcut inherited
by an 18-arrow prototype was rejected, its omitted patterns restored, and the
complete corrected inventory independently reviewed before promotion.

The final dependencies and review distinctions are recorded in
publication/EVIDENCE_GUIDE.md, research/finish-case-approved-bounds.json,
research/finish-ledger-review.json, and the individual frozen review manifests.
Existing stronger construction properties and historical evidence are retained.
The concrete finite proofs remain externally reviewed computational proofs;
the 12 Lean modules do not yet instantiate the entire classification. Delivery
time optimization and all-extremizer classification remain outside the goal.
Mathematics is complete; the final PDF, package and public deployment are being
verified separately and will receive their own release receipts.


## Final released checkpoint — 2026-09-13T18:17:29.945405+00:00

The count-and-explicit-construction objective is complete. All101 former
canonical cases are numerically closed, with no unknown value and no absent
explicit attainer. This final release supersedes the build-in-progress notes
above. The136-page, nine-figure manuscript, complete finite tables, proof
evidence, construction inventory, partial Lean coverage and website are built,
checked and published. All136 PDF pages were visually reviewed. Fresh extracted
archives passed the complete numerical/recipe/table checks and all86 literal
graphs with121890 alternating-state rank obligations.

Release source commit: 44b10d90993a246c6b8d930313e890763fe00ce1.
Website commit: 3b9a4069f6025352ecd736062ec8e75dd27bb56c.
Successful GitHub Pages run: 34773982372.
Public readback matched all five pages, all36 served assets, and the release
manifest (42 checks). The precise receipt is research/website-deployment.json.
Both existing evidence archives preserve the verified file bytes and remain
within hosting limits; the evidence guide documents standard Python extraction.

No graph searches or build jobs remain running. Full Lean instantiation,
optimal delivery time, all-extremizer classification, final human publication
authorship, arXiv/journal submission and outreach remain separate from this
completed mathematical objective. No submission or outreach was performed.

## Proof simplification — 18 September 2026

Implemented the approved bounded pass: shared sparse upper induction, generalized separated pair codes and the ordinary order79 overlap, exact functional-tail attachment, and sharper odd projection from support98. The full execution record is research/proof-slimming-execution.md. The finite bridge required by the odd proof shrinks by47graphs; its old archives remain unchanged. Independent reviews found all earlier numbered claims and stronger timing/subset domains preserved. Review corrected the smallest enlarged dense core's proposed three-move bound to four; the full staircase's existing four-move guarantee is preserved.

No new extremal graph search or full Lean formalization was launched. New arithmetic, construction and frozen-rank checks passed, and all493,924 numerical cells/provider identities are unchanged. The new candidate PDF is124pages versus the preceding release's136. Build, visual review, extracted-archive replay and live publication are separate checkpoints recorded in their release receipts.


## Verified proof-simplification release — 18 September 2026

The revised 124-page manuscript is published, down from the preceding release's
136 pages. All 124 pages received visual review; the separate eight-page
delivery-time companion remains separate. The seven checks rerun from fresh
extractions of the final downloadable archives all passed, including the new
arithmetic/construction checks and actual replay of all 847 odd-family local
certificate modules. The 493,924 classified finite ledger cells and their
providers are unchanged, and the explicit-construction audit has zero gaps.
Earlier stronger construction guarantees and finite certificates are preserved.

Mathematical/source release commit: de220ab9b9001f87b5831f12168ba17cbbfc3899.
Website commit: dc725f9d65310e2aaba20cc453f207ff992a63a9.
Successful GitHub Pages run: 35328708118.
Live readback matched all five routes, all 36 served assets, and the release
manifest (42 checks). The complete deployment and extracted-archive replay
receipts are preserved in research/website-deployment.json. The earlier public
release receipt remains under research/history.

This pass does not add Lean coverage: the 12 existing modules remain partial
formalization. No arXiv submission or outreach was performed. Further proof
simplification and full formalization remain separate work. This checkpoint is
appended after packaging; the archived notes retain their unchanged prefixes.

## 18 September 2026 — arXiv preparation and second proof consolidation

User approved author order Angel Ivanov Raychev, then Alexandra Ignatova (Eindhoven University of Technology), the contribution statement, further simplification and Lean work. The current checkpoint threshold is40% remaining account usage. No submission occurred.

The guide lane replaces repeated safe-entry/count proofs for three hub families with a common attachment theorem and exact optional-arc accounting; the original concrete recipes and move bounds remain. Replayed971146 two-move,73101 entry and518089 rank obligations. The sparse lane introduces a common local simulation/window/progress argument and applies it across five chapters, preserving every finite certificate and source-eligibility premise. Net removal across the two lanes is approximately780words including the new common arguments; page count must be measured after adding front matter and formalization coverage. Independent peer review found no gap in either common theorem.

Lean now compiles18modules, including the general vertex bound for its explicit finite-strategy score, a finite-cover exclusion interface with a complete64graph three-vertex pilot, exact M(12,24)=108, and antichain guide attachment. Full compilation took38.122seconds; all source hashes match and only standard logical axioms occur. This is not full formalization: large enumeration coverage, infinite parameter instantiation, remaining upper bounds and the converse from arbitrary eventual strategies remain outside the present Lean proof. New finite semantic interfaces should reduce duplication when those parts are formalized.

The publication pass adds approved metadata, an abstract, a proof roadmap, explicit rule comparisons with cat-and-mouse and standard reachability games, bibliography and an upload guide. Provenance distinguishes original joint work from subsequent AI-assisted extensions. All classified values, attaining domains and stronger construction guarantees are retained. Frozen evidence pins remain historical rather than being silently rewritten to endorse new sources.

### Verified release of the arXiv-prepared manuscript

Final125-page/9-figure paper and272481-byte TeX upload package validated. Both human authors and the approved provenance statement are included. The independent extracted18-module Lean build and final numerical/recipe audits passed. Current guide/pair/all-parity/odd receipts were replayed rather than blindly repinned; old versions are archived. One stale intermediate-bound label and one scope-module-count label were corrected. Full visual review, standalone TeX replay and48live checks support website commitfa84dac6a6df1c753e1569bc02f238125193d3cf, successful Pages run35334806328. Full classification remains outside Lean; submission remains pending. This is a stable checkpoint, not an arXiv submission or a claim of complete formalization.


## 18 September 2026: actual-policy semantics and exact-score certificates

The continuation formally closes a foundational gap: on finite graphs, a finite winning tree exists exactly when one fixed legal messenger policy eventually delivers against every legal history-dependent cop. The policy can be fixed before both the initial cop position and its later policy. The losing complement supplies one positional cop policy preventing receipt at every horizon; finite reply sets supply the common winning bound. Waiting and recipient-priority semantics are preserved. Independent peer and root reviews attacked the quantifier order, clock-policy causality and both collision tests; no gap was found.

DenseZero derives the zero band directly from a guaranteed pair: each row must miss a nonloop arrow, so the graph has at most n(n-2) arrows. ExactScoreCertificates checks both accepted and rejected missing pairs. Its literal four-vertex/six-arrow witness has exactly two guarantees among six missing pairs, with every local winning and losing obligation kernel-checked. This is a graph-score theorem, not an extremal upper theorem for that cell. All21modules compile under Lean4.33.1 with only standard axioms. General sparse bounds, the staircase graph-counting bridge, infinite parameter choices and large finite exclusions remain outside Lean.

No numerical values, graph recipes or frozen certificate bytes changed. The paper remains125pages; coverage summaries and the Lean roadmap now distinguish the closed semantic gap from the remaining classification work. PDF-preview mode separates visual preparation from evidence packaging; the release build rejects a stale main-PDF visual receipt before its large archives. One intact six-type budget certificate moves between the two existing research archives to preserve hosting headroom, without changing its relative path or bytes.

The final bounded extension closes attainment in the zero region as well. DenseZero.initialGraph lists the first m nonloop ordered pairs in lexicographic order. The kernel proves enumeration has no duplicates, contains n(n-1) pairs, and the prefix graph is loopless with exactly m arrows for every admissible budget. Combining this with the unconditional obstruction proves IsMaximum n m 0 throughout n(n-2)<m<=n(n-1). No existence/counting premise is supplied.

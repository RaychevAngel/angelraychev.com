"""Three direct diagonal cuts contracting a corner square triangle."""
import json
from pathlib import Path

from bridge_upper_transport import neighborhood


def contract(radius, budget, w=None, n=None):
    r = radius
    w = w or 2 * r
    n = n or 2 * r
    assert r >= 3 and min(w, n) >= 2 * r
    K = min(budget, 2 * r - 2)
    assert 3 * K >= 4 * r - 1
    assert r <= K <= 2 * r - 2
    D = 2 * r - 2
    m = 2 * K - 2 * r
    source = {(x, y) for x in range(w) for y in range(n)
              if (x + y) % 2 == 0 and x + y <= D}
    target_survivor = {(x, y) for x in range(w) for y in range(n)
                       if (x + y) % 2 == 0 and x + y <= D - 2}
    shots = [
        {(x, D - x) for x in range(K)},
        {(x, D + 1 - x) for x in range(K, D + 2)}
        | {(x, D - 1 - x) for x in range(m)},
        {(x, D - x) for x in range(m, D + 1)},
    ]
    sizes = [len(source)]
    survivors = []
    A = set(source)
    for day, shot in enumerate(shots):
        assert shot <= A and len(shot) <= budget
        A -= shot
        survivors.append(len(A))
        if day == 2:
            assert A == target_survivor
        A = neighborhood(w, n, A)
        sizes.append(len(A))
    assert sizes == [r * r, r * (r + 1) - K, r * r + 2 * r - 2 * K, r * (r - 1)]
    assert A == neighborhood(w, n, target_survivor)
    assert sum(map(len, shots)) == 4 * r - 1
    return {'shape': [w, n], 'radius': r, 'budget': budget, 'used_quota': K,
            'inspection_counts': list(map(len, shots)), 'belief_sizes': sizes,
            'survivor_sizes': survivors, 'exact_final_survivor': True,
            'literal_neighborhood_replay': True, 'shots': [sorted(s) for s in shots]}


def audit():
    rows = []
    for r in range(3, 33):
        for k in range((4 * r + 1) // 3, 2 * r - 1):
            row = contract(r, k, 2 * r, 2 * r + r % 3)
            rows.append({key: value for key, value in row.items() if key != 'shots'})
        row = contract(r, 2 * r + 5, 2 * r + 3, 2 * r + 4)
        rows.append({key: value for key, value in row.items() if key != 'shots'})
    selected = contract(10, 13, 25, 26)
    return {'cases': len(rows), 'rows': rows, 'selected_25x26': selected,
            'scope': 'Uniform three-day corner-triangle contraction, with exact literal replay. No full-board capture-time equality claim.'}


if __name__ == '__main__':
    output = audit()
    Path('research/bridge-upper-transport-triangle-contraction.json').write_text(json.dumps(output, indent=2) + '\n')
    print({'cases': output['cases'], 'selected': output['selected_25x26']})

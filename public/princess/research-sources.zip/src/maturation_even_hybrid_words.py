#!/usr/bin/env python3
"""Exact three-inspection quota-word comparison in a targeted parent."""
from itertools import product
from pathlib import Path
from functools import lru_cache
import json
import time
from maturation_even_boundary_family import Family
from maturation_even_relative_family import neighborhood_size, is_hybrid


def neighbor_counts(h, c):
    if not c or not sum(c):
        return 0, ()
    full = [a == h+2*i+1 for i, a in enumerate(c)]
    out = ([c[0]-int(full[0])] if h else [])
    first = h-1 if h else 1
    for i, a in enumerate(c):
        below = c[i+1]-int(full[i+1]) if i+1 < len(c) else 0
        out.append(max(a+int(a > 0), below))
    while out and not out[0]:
        out.pop(0)
        first += 2
    while out and not out[-1]:
        out.pop()
    return first, tuple(out)


@lru_cache(None)
def next_profiles(h, c):
    size = sum(c)
    best = [None]*(size+1)
    hybrid = [None]*(size+1)
    for d in product(*(range(x+1) for x in c)):
        cost = size-sum(d)
        nxt = neighborhood_size(h, d)
        if best[cost] is None or nxt < best[cost][0]:
            best[cost] = nxt, d
        if is_hybrid(h, d) and (hybrid[cost] is None or nxt < hybrid[cost][0]):
            hybrid[cost] = nxt, d
    for budget in range(1, size+1):
        if best[budget-1][0] < best[budget][0]:
            best[budget] = best[budget-1]
        if hybrid[budget-1] is not None and (hybrid[budget] is None or hybrid[budget-1][0] < hybrid[budget][0]):
            hybrid[budget] = hybrid[budget-1]
    return best, hybrid


def main():
    started = time.process_time()
    f = Family(1, 3, 1, 1)
    c = tuple(f.counts())
    size = sum(c)
    max_next = neighborhood_size(f.h, c)
    raw = [[None]*(max_next+1) for _ in range(size+1)]
    restricted = [[None]*(max_next+1) for _ in range(size+1)]
    first_count = 0
    for d in product(*(range(x+1) for x in c)):
        first_count += 1
        cost = size-sum(d)
        nh, nc = neighbor_counts(f.h, d)
        ordinary, hybrid = next_profiles(nh, nc)
        is_h = is_hybrid(f.h, d)
        for q in range(max_next+1):
            b = min(q, sum(nc))
            item = ordinary[b]
            record = {"last_budget": item[0], "first_survivor": d,
                      "next_start": nh, "next_counts": nc, "second_survivor": item[1]}
            if raw[cost][q] is None or item[0] < raw[cost][q]["last_budget"]:
                raw[cost][q] = record
            if is_h and hybrid[b] is not None:
                item = hybrid[b]
                record = {"last_budget": item[0], "first_survivor": d,
                          "next_start": nh, "next_counts": nc, "second_survivor": item[1]}
                if restricted[cost][q] is None or item[0] < restricted[cost][q]["last_budget"]:
                    restricted[cost][q] = record
    for p in range(1, size+1):
        for q in range(max_next+1):
            for table in (raw, restricted):
                earlier = table[p-1][q]
                if earlier is not None and (table[p][q] is None or earlier["last_budget"] < table[p][q]["last_budget"]):
                    table[p][q] = earlier
    mismatches = []
    for p in range(size+1):
        for q in range(max_next+1):
            r, h = raw[p][q], restricted[p][q]
            if h is None or r["last_budget"] != h["last_budget"]:
                mismatches.append({"first_budget": p, "second_budget": q,
                                   "unrestricted": r, "hybrid": h})
    out = {"scope": "All at-most three-day quota words in one hybrid quadrant parent",
           "parent_start_diagonal": f.h, "parent_counts": c,
           "first_survivor_vectors": first_count,
           "distinct_second_parents": next_profiles.cache_info().currsize,
           "quota_pairs_checked": (size+1)*(max_next+1),
           "mismatches": mismatches,
           "cpu_seconds": round(time.process_time()-started, 6)}
    target = Path(__file__).resolve().parents[1]/"research/maturation-hybrid-word-check.json"
    target.write_text(json.dumps(out, indent=2)+"\n")
    print(json.dumps(out))


if __name__ == "__main__":
    main()

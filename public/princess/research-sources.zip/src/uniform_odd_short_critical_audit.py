#!/usr/bin/env python3
"""Raw physical-subset check of sharp odd-short critical frontiers."""
from pathlib import Path
from time import process_time
import json

def case(b,L):
    w=2*b+1;h=w*L;full=(1<<h)-1
    physical=[[(x,2*j+((p-x)%2)) for x in range(w) for j in range(L)] for p in (0,1)]
    critical=[[],[]]; neighborhoods=[[],[]]
    rowmask=(1<<L)-1
    for p in (0,1):
        idx={v:i for i,v in enumerate(physical[1-p])};adj=[]
        for x,y in physical[p]:
            adj.append(sum(1<<idx[v] for v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if v in idx))
        ns=[0]*(1<<h)
        for mask in range(1,1<<h):
            bit=mask&-mask;ns[mask]=ns[mask^bit]|adj[bit.bit_length()-1]
            k=mask.bit_count()
            if not (b*b<k<h-b*(b+1)) or ns[mask].bit_count()-k!=b:continue
            barrier=ns[mask] & (full^mask)
            lengths=[]
            for x in range(w):
                row=(mask>>(x*L))&rowmask;l=row.bit_count();lengths.append(l)
                assert row==(((1<<l)-1) if p==0 else ((1<<l)-1)<<(L-l))
                boundary=((barrier>>(x*L))&rowmask).bit_count()
                if x%2==0:assert boundary==0 and 1<=l<L
                else:assert boundary==1
            for x in range(1,w,2):
                for u in (x-1,x+1):assert lengths[x]<=lengths[u]<=lengths[x]+1
            critical[p].append(mask);neighborhoods[p].append(ns[mask])
    comparisons=0
    for p in (0,1):
        for nb in neighborhoods[p]:
            for other in critical[1-p]:
                assert other & (full^nb)
                comparisons+=1
    return dict(width=w,length=2*L,subsets=2*(1<<h),critical_counts=list(map(len,critical)),critical_transition_pairs=comparisons)

def main():
    start=process_time();cases=[case(b,L) for b,L in ((1,2),(1,3),(1,4),(2,3),(2,4))]
    out=dict(status='PASS',cases=cases,subsets=sum(c['subsets'] for c in cases),critical_transition_pairs=sum(c['critical_transition_pairs'] for c in cases),cpu_seconds=process_time()-start,scope='Finite raw-set supplement to the independently audited all-parameter geometry.')
    Path('research/uniform-odd-short-critical-independent-check.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items() if k!='cases'})
if __name__=='__main__':main()

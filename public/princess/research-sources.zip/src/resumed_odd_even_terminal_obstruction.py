"""Independent physical check of the 7x8 critical-pronic memory trigger."""
from itertools import combinations
from pathlib import Path
from time import process_time
import json


def run():
    start=process_time();w,n=7,8
    V=[[(x,y)for x in range(w)for y in range(n)if(x+y)%2==p]for p in(0,1)]
    I=[{v:i for i,v in enumerate(row)}for row in V]
    N=[[sum(1<<I[1-p][q]for q in((x-1,y),(x+1,y),(x,y-1),(x,y+1))if q in I[1-p])
        for x,y in V[p]]for p in(0,1)]
    C=[sum(1<<i for i,(x,y)in enumerate(V[p])if x in(0,w-1)and y in(0,n-1))
       for p in(0,1)]
    candidates=[];second=0;fail=[]
    for selected in combinations(range(28),6):
        S=sum(1<<i for i in selected)
        if S&C[0]:continue
        A=0
        for i in selected:A|=N[0][i]
        if A.bit_count()!=9 or(A&C[1]).bit_count()!=1:continue
        candidates.append(sorted(V[0][i]for i in selected))
        full_next=0
        for i in range(28):
            if A>>i&1:full_next|=N[1][i]
        assert not full_next&C[0]
        for subset in combinations([i for i in range(28)if A>>i&1],5):
            second+=1;H=0
            for i in subset:H|=N[1][i]
            if H.bit_count()==8 and(H&C[0]).bit_count()==1:fail.append(subset)
    assert not fail
    return {'shape':[7,8],'budget':4,
            'trigger_belief_pattern':[[10,0],[9,1]],
            'next_corner_count_forced':0,
            'first_survivors_enumerated':376740,'valid_first_survivors':candidates,
            'second_survivors_enumerated':second,'counterexamples':fail,
            'full_second_neighborhood_checked':True,
            'cpu_seconds':process_time()-start}


if __name__=='__main__':
    out=run();Path('research/resumed-odd-even-terminal-obstruction.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out)

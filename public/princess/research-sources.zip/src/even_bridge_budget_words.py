"""Finite exact attacks on budget-word preservation by geometric states.

No fixed budget assumption: enumerate distinct winning-support families
reachable by prepending any budget to any previously reached budget word.
Every transfer uses arbitrary physical subsets. A separate transfer requires
canonical survivor sets. Compare only canonical initial supports.
"""
import argparse
from collections import deque
from itertools import permutations, product
import json
from pathlib import Path
from time import process_time

from parity_corner_check import canonical_flags
from parity_trap_solver import setup, deletion_distance


def prefix_flags(shape, colors):
    flags = [bytearray(1 << len(row)) for row in colors]
    for reflection in product((0, 1), repeat=len(shape)):
        for perm in permutations(range(len(shape))):
            for p, row in enumerate(colors):
                mapped = [tuple(shape[j]-1-v[j] if reflection[j] else v[j]
                                for j in range(len(shape))) for v in row]
                order = sorted(range(len(row)), key=lambda i:
                               (sum(mapped[i]), tuple(-mapped[i][j] for j in perm)))
                mask = 0
                flags[p][0] = 1
                for i in order:
                    mask |= 1 << i
                    flags[p][mask] = 1
    return flags


def run(shape, family, seconds=15, state_cap=3000, full_only=False, min_budget=0, max_budget=None, maximum_only=False):
    start = process_time()
    colors, ns = setup(shape)
    flags = (canonical_flags if family == 'corner-ideals' else prefix_flags)(shape, colors)
    closure = all(not flags[p][a] or flags[1-p][nb]
                  for p in (0, 1) for a, nb in enumerate(ns[p]))
    # Closure is needed only if actual pre-inspection sets are also required
    # canonical. Survivor-only restriction remains well-defined without it.
    init = tuple(bytes([1])+bytes(len(row)-1) for row in ns)
    queue = deque([(init, init, ())]); seen = {(init, init)}
    maximum = max(map(len, colors)); inspected = transfers = 0
    budget_max = maximum if max_budget is None else min(max_budget, maximum)
    translations = {m:bytes(int(k<=m) for k in range(256))
                    for m in range(min_budget,budget_max+1)}
    checked = [[a for a,f in enumerate(row) if f and (not full_only or a==len(row)-1)]
               for row in flags]
    result = {'shape': shape, 'family': family,
              'canonical_counts': list(map(sum, flags)), 'neighborhood_closed': closure,
              'start_scope': 'maximum-cardinality' if maximum_only else ('full' if full_only else 'all canonical'),
              'budget_range': [min_budget, budget_max]}
    while queue:
        if process_time()-start > seconds or len(seen) > state_cap:
            result['status'] = 'bounded incomplete';break
        wins, restricted, word = queue.popleft(); inspected += 1
        ordinary_dist=[]; restricted_dist=[]
        for p in (0, 1):
            ordinary_dist.append(deletion_distance(
                bytes(wins[1-p][nb] for nb in ns[p]), maximum+1))
            restricted_dist.append(deletion_distance(
                bytes(restricted[1-p][nb] and flags[p][a]
                      for a,nb in enumerate(ns[p])), maximum+1))
        failure=None
        if maximum_only:
            for p in (0,1):
                ordinary_best=[(-1,0)]*(budget_max+1)
                canonical_best=[(-1,0)]*(budget_max+1)
                for a,d in enumerate(ordinary_dist[p]):
                    m=max(min_budget,d)
                    if m<=budget_max:ordinary_best[m]=max(ordinary_best[m],(a.bit_count(),a))
                for a in checked[p]:
                    m=max(min_budget,restricted_dist[p][a])
                    if m<=budget_max:canonical_best[m]=max(canonical_best[m],(a.bit_count(),a))
                for m in range(min_budget,budget_max+1):
                    if m>min_budget:
                        ordinary_best[m]=max(ordinary_best[m],ordinary_best[m-1])
                        canonical_best[m]=max(canonical_best[m],canonical_best[m-1])
                    if ordinary_best[m][0]>canonical_best[m][0]:
                        result['unrestricted_maximum']=ordinary_best[m][0]
                        result['restricted_prefix_maximum']=canonical_best[m][0]
                        if failure is None or m<failure[0]:failure=(m,p,ordinary_best[m][1])
                        break
        else:
            for p in (0, 1):
                for a in checked[p]:
                    m=max(min_budget,ordinary_dist[p][a])
                    if m<=budget_max and m<restricted_dist[p][a]:
                        if failure is None or m<failure[0]:failure=(m,p,a)
        if failure is not None:
            m,p,a=failure
            result.update(status='counterexample', budget_word=(m,)+word,
                          parity=p, mask=a,
                          rooms=[v for i,v in enumerate(colors[p]) if a>>i&1])
            result.update(CPU_seconds=process_time()-start,
                          families_seen=len(seen),families_processed=inspected,
                          transfers=transfers)
            return result
        for m in range(min_budget,budget_max+1):
            transfers += 1
            new = tuple(bytes(row).translate(translations[m]) for row in ordinary_dist)
            canon = tuple(bytes(row).translate(translations[m]) for row in restricted_dist)
            key=(new,canon)
            if key not in seen:
                seen.add(key);queue.append((new,canon,(m,)+word))
    else:result['status']='complete winning-family closure; every finite budget word checked'
    result.update(CPU_seconds=process_time()-start,families_seen=len(seen),
                  families_processed=inspected,transfers=transfers)
    return result


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('shape',nargs='+',type=int)
    p.add_argument('--family',choices=['corner-ideals','corner-prefixes'],default='corner-ideals')
    p.add_argument('--seconds',type=float,default=15)
    p.add_argument('--full-only',action='store_true')
    p.add_argument('--maximum-only',action='store_true')
    p.add_argument('--min-budget',type=int,default=0)
    p.add_argument('--max-budget',type=int)
    p.add_argument('--output',type=Path)
    args=p.parse_args();result=run(tuple(args.shape),args.family,args.seconds,
                                 full_only=args.full_only,min_budget=args.min_budget,
                                 max_budget=args.max_budget,maximum_only=args.maximum_only)
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

"""Uniform affine consequence of the physical day-28 barrier, width 24.

Independent finite substitutions use quadratic capacities directly rather
than the three-frontier closed inverse formulas. The h-uniform induction is
in research/bridge-boundary-numeric-24.md.
"""
from pathlib import Path
import json
import hashlib
from time import process_time

from bridge_corner_frontier import step
from resumed_even_construction_formula_clock import model_data


def F(i,j,s):
    if s < i+2*j:
        return -10**9
    if j:
        c=i+2*j-2
        return c+(s-c)*(s-c-1)
    if i:
        c=i-1
        return c+(s-c)**2
    return max(s*(s-1)//2,s*(s-2))


def G(i,j,s):
    A=2-i
    B=2-j
    if s < A+B:
        return -10**9
    z=s-A-B
    if B:
        return z*z+2*z+B
    if A:
        return z*z+z
    return max(s*(s-1)//2,s*(s-2))


def low_step(B):
    values=[]
    for c in range(3):
        qmax=0
        for i in range(c+1):
            for j,t in enumerate(B):
                if t < max(1,j):
                    continue
                for s in range(13):
                    q=t-s
                    if q>=max(1,i) and (s==12 or q<=F(i,j,s)):
                        qmax=max(qmax,q)
        values.append(13+qmax)
    return tuple(values)


def high_step(deficits):
    values=[]
    for c in range(3):
        candidates=[]
        for i in range(c+1):
            for j,d in enumerate(deficits):
                surplus=next(s for s in range(13) if s==12 or d<=G(i,j,s))
                candidates.append(d+surplus-13)
        values.append(min(candidates))
    return tuple(values)


def main():
    started=process_time()
    small_matrix=[[11+F(i,j,11)for j in range(3)]for i in range(3)]
    large_matrix=[[G(i,j,11)for j in range(3)]for i in range(3)]
    assert max(map(max,small_matrix))==132
    assert max(map(max,large_matrix))==121

    prefixes=[]
    for seed in ((0,-1,-1),(6,6,6)):
        B=seed
        rows=[B]
        for t in range(36):
            assert max(B)<=134
            nxt=low_step(B)
            assert nxt==step(24,24,13,B,critical=False)
            B=nxt
            rows.append(B)
        assert B==(135,135,135)
        prefixes.append({'seed':seed,'frontiers':rows})

    tail=[(121,121,121)]
    for _ in range(7):
        nxt=high_step(tail[-1])
        source=tuple(288-d for d in tail[-1])
        assert tuple(288-d for d in nxt)==step(24,24,13,source,critical=False)
        tail.append(nxt)
    assert tail[-2]==(112,112,112)
    assert tail[-1]==(111,111,110)

    # Separate graph-based predecessor audit through the entire base-board
    # finite trace, including both seeds. No scalar recurrence is used to
    # construct W; every admitted edge of the old corner model is retained.
    states,ids,edges=model_data(24,24,13,critical=False)
    memberships=0
    graph_audits=[]
    for seed in ((0,-1,-1),(6,6,6)):
        B=seed
        W=sum(1<<z for z,(a,c)in enumerate(states) if a<=seed[c])
        for t in range(76):
            expected=sum(1<<z for z,(a,c)in enumerate(states) if a<=B[c])
            assert W==expected,(seed,t,B)
            memberships+=len(states)
            if t==74:
                assert B==(176,176,176)
            if t==75:
                assert B==(177,177,178)
                break
            W=sum(1<<z for z,row in enumerate(edges) if row&W)
            B=step(24,24,13,B,critical=False)
        graph_audits.append({'seed':seed,'layers':76,'final':B})

    boundary_features=[]
    for critical in (False,True):
        states,ids,edges=model_data(24,24,13,critical=critical)
        forward=1<<ids[288,2]
        for _ in range(28):
            out=0
            while forward:
                bit=forward&-forward
                forward^=bit
                out|=edges[bit.bit_length()-1]
            forward=out
        backward=1<<ids[0,0]
        for _ in range(75):
            backward=sum(1<<z for z,row in enumerate(edges)if row&backward)
        choices=[(a,c)for z,(a,c)in enumerate(states)
                 if a>=177 and ((forward&backward)>>z)&1]
        boundary_features.append({'critical':critical,
                                  'allowed_day28_features_on_103_day_model_path':choices})

    receipt={'status':'PASS','scope':'Finite substitutions and independent base graph audit accompanying an h-uniform proof; no sampling extrapolation.',
             'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'small_at_11_plus_11':small_matrix,'large_at_11':large_matrix,
             'prefixes':prefixes,'tail_deficits':tail,
             'graph_audits':graph_audits,'graph_state_memberships':memberships,
             'remaining_24_square_boundary_features':boundary_features,
             'uniform_result':{'domain':'24 by n, every integer n>=24, budget 13',
                               'full_lower':'24*n-370',
                               'remaining_from_time28':'12*n-213',
                               'precentral_backward_maximum':'12*n-112'},
             'seconds':process_time()-started}
    Path('research/bridge-boundary-numeric-24-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print({k:v for k,v in receipt.items()if k not in ('prefixes',)})


if __name__=='__main__':
    main()

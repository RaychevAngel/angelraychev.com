"""Produce explicit scalar rank certificates and upper schedules, no trusted solver."""
import sys
sys.set_int_max_str_digits(100000)
from pathlib import Path
import json
from itertools import product
ROOT=Path(__file__).resolve().parents[1]
profile=[0,3,6,7,9,11,12,13,15,16,17,18,19,19,21,22,23,24,25,25,26,27,28,28,29,29,30,31,31,31,32,32,32]
budgets=[9,10,11,12,14,15,17,18,25,31]
expected=[20,16,12,10,8,7,6,5,4,3]
ranks=[]
for m,t in zip(budgets,expected):
 dist=[None]*1089;dist[0]=0;iteration=0
 while any(v is None for v in dist):
  iteration+=1;fresh=[]
  for a,b in product(range(33),repeat=2):
   idx=33*a+b
   if dist[idx] is not None:continue
   if any(dist[33*profile[max(0,b-(m-p))]+profile[max(0,a-p)]] is not None for p in range(m+1)):
    fresh.append(idx)
  assert fresh
  for idx in fresh:dist[idx]=iteration
 assert dist[-1]==t
 assert all(dist[33*a+b]<=dist[33*(a+1)+b] for a in range(32)for b in range(33))
 assert all(dist[33*a+b]<=dist[33*a+b+1] for a in range(33)for b in range(32))
 assert all(dist[33*a+b]<=1+dist[33*profile[max(0,b-(m-p))]+profile[max(0,a-p)]] for a in range(33)for b in range(33)for p in range(m+1))
 ranks.append(dist)
pack=lambda vals,width:sum(v<<(width*i)for i,v in enumerate(vals))
s='''import FourCubePotentialState
namespace Princess.FourCubeTimeCounter
open Princess.FourCubeCompression Princess.FiniteIdealCertificates Princess.FiniteSubsetProfiles

'''
s+=f'def profile (k : Nat) : Nat := ({pack(profile,6)} >>> (6*k)) &&& 63\n'
s+=f'def budget (kind : Fin 10) : Nat := ({pack(budgets,5)} >>> (5*kind.val)) &&& 31\n'
s+=f'def turns (kind : Fin 10) : Nat := ({pack(expected,5)} >>> (5*kind.val)) &&& 31\n'
s+=f'def rank (kind : Fin 10) (a b : Nat) : Nat := ({pack(sum(ranks,[]),5)} >>> (5*(1089*kind.val+33*a+b))) &&& 31\n'
s+='''
def profileCheck (mask : Nat) : Bool := decide
  (profile (sizeTable mask) ≤ countBits 64 (hoodTable mask))
set_option maxRecDepth 100000 in
set_option maxHeartbeats 10000000 in
theorem profile_even_checked : check down profileCheck ((colorRooms false).map Fin.val) 0=true := by decide +kernel
set_option maxRecDepth 100000 in
set_option maxHeartbeats 10000000 in
theorem profile_odd_checked : check down profileCheck ((colorRooms true).map Fin.val) 0=true := by decide +kernel

theorem profile_zero : profile 0=0 := by decide
theorem profile14 : profile 14=21 := by decide
theorem profile_bounds : ∀ k : Fin 33, profile k.val≤32 := by decide
theorem profile_mono_checked : ∀ k : Fin 32, profile k.val≤profile (k.val+1) := by decide
theorem rank_empty : ∀ kind : Fin 10, rank kind 0 0=0 := by decide
theorem rank_full : ∀ kind : Fin 10, rank kind 32 32=turns kind := by decide
end Princess.FourCubeTimeCounter
'''
(ROOT/'lean/FourCubeTimeCounterData.lean').write_text(s)
for kind in range(10):
 s=f'''import FourCubeTimeCounterData
namespace Princess.FourCubeTimeCounter
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem rank_left_{kind} : ∀ a : Fin 32, ∀ b : Fin 33,
    rank {kind} a.val b.val ≤ rank {kind} (a.val+1) b.val := by decide +kernel

theorem rank_right_{kind} : ∀ a : Fin 33, ∀ b : Fin 32,
    rank {kind} a.val b.val ≤ rank {kind} a.val (b.val+1) := by decide +kernel

theorem rank_step_{kind} : ∀ a b : Fin 33, ∀ p : Fin 32, p.val≤budget {kind} →
    rank {kind} a.val b.val ≤ 1+rank {kind}
      (profile (b.val-(budget {kind}-p.val))) (profile (a.val-p.val)) := by decide +kernel

end Princess.FourCubeTimeCounter
'''
 (ROOT/f'lean/FourCubeTimeCounter{kind}.lean').write_text(s)
print('scalar ranks generated:',list(zip(budgets,[r[-1]for r in ranks])))

"""Fixed-block lower and physical-prefix upper evaluations for even widths.

The block count parameter K is fixed independently of every input. This
is not a claim that the necessary corner model is physically attained.
"""
from math import isqrt
from pathlib import Path
import hashlib
import json
from time import process_time

from bridge_corner_frontier import step
from resumed_even_construction_prefix_arithmetic import neighborhood_count


def frontier(w, n, k, seed=0, day=None, K=16):
    r, h = w // 2, w * n // 2
    s, delta = k-r, k-r-1
    assert w == 2*r and r >= 2 and n >= w and k < h
    assert delta >= 1 and K*delta >= r*r
    B = (0, -1, -1) if seed == 0 else (seed,)*3
    assert seed == 0 or 2 <= seed <= h-2
    t = blocks = 0
    cap = (h-2, h-1, h)
    A = r*r+r+1
    U = h-max(r*r+1, s+1)

    def done():
        return B[2] == h or day is not None and t == day

    def advance():
        nonlocal B, t, blocks
        B = step(w, n, k, B, critical=True)
        t += 1
        blocks += 1
        assert B[0] <= B[1] <= B[2]
        assert B[1] <= B[0]+1 and B[2] <= B[1]+1

    for _ in range(2*K):
        if not done() and B[0] < A:
            advance()
    assert done() or B[0] >= A
    for _ in range(2):
        if not done() and B[0] >= A and B[2] <= U:
            advance()
    if not done() and B[2] <= U:
        assert B[0]+1 == B[1] == B[2] and B[0] >= A
        q = 1+(U-B[2])//s
        if day is not None:
            q = min(q, day-t)
        B = tuple(z+q*s for z in B)
        t += q
    for _ in range(K+1):
        if not done():
            advance()
    assert done(), (w, n, k, B, t, day, K)
    assert blocks <= 3*K+3
    if B[2] == h:
        assert B == cap
    return dict(day=t, frontier=B, blocks=blocks)


def prefix(w, n, k, phase=0, size=None, day=None, K=16):
    r, h = w//2, w*n//2
    s = k-r
    assert w == 2*r and r >= 2 and n >= w and s >= 1
    assert K*s >= r*r
    x = h if size is None else size
    t = blocks = 0
    last = None
    lower = k+(r-1)**2+1
    upper = k+h-r*r+r-1

    def done():
        return x == 0 or day is not None and t == day

    def advance():
        nonlocal x, phase, t, blocks, last
        last = x
        x = neighborhood_count(w, n, phase, max(x-k, 0))
        phase ^= 1
        t += 1
        blocks += 1

    for _ in range(K):
        if not done() and x > upper:
            advance()
    if not done() and lower <= x <= upper:
        q = 1+(x-lower)//s
        if day is not None:
            q = min(q, day-t)
        if q:
            last = x-(q-1)*s
        x -= q*s
        phase ^= q % 2
        t += q
    for _ in range(K+1):
        if not done():
            advance()
    assert done(), (w, n, k, x, t, day, K)
    assert blocks <= 2*K+1
    return dict(day=t, size=x, phase=phase, last=last, blocks=blocks)


def bounds(w, n, k, K=16):
    h, r = w*n//2, w//2
    B = frontier(w, n, k, K=K)
    tau = B['day']
    R = frontier(w, n, k, seed=k//2, day=tau-1, K=K)
    lower = 2*tau-int(R['frontier'][2] == h)
    P = [prefix(w, n, k, phase=p, K=K) for p in (0, 1)]
    prefix_upper = min(2*x['day']-int(2*x['last'] <= k) for x in P)
    q, z = divmod(h-r, k-r)
    root = isqrt(z)+int(isqrt(z)**2 < z)
    generic_upper = 2*q if not z else 2*q+1+int(2*(z+min(root, r)) > k)
    upper = min(prefix_upper, generic_upper)
    assert lower <= upper
    return dict(shape=[w, n], budget=k, K=K, lower=lower, upper=upper,
                model=B, halfbudget=R, prefixes=P)


def main():
    started = process_time()
    rows = []
    comparisons = 0
    for K in (1, 4, 16):
        for r in (2, 3, 5, 10, 20, 50):
            k0 = r+1+(r*r+K-1)//K
            for k in sorted({k0, k0+1, 2*r, r*r-r+1}):
                if k-r-1 < 1 or K*(k-r-1) < r*r:
                    continue
                for n in (2*r, 2*r+1, 5*r):
                    h = r*n
                    if k >= h:
                        continue
                    row = bounds(2*r, n, k, K)
                    for seed in (0, k//2):
                        B = (0, -1, -1) if seed == 0 else (seed,)*3
                        t = 0
                        while True:
                            fast = frontier(2*r, n, k, seed=seed, day=t, K=K)
                            assert fast['frontier'] == B
                            comparisons += 1
                            if B[2] == h:
                                break
                            B = step(2*r, n, k, B)
                            t += 1
                    for p in (0, 1):
                        x, phase, t = h, p, 0
                        while True:
                            fast = prefix(2*r, n, k, phase=p, day=t, K=K)
                            assert (fast['size'], fast['phase']) == (x, phase)
                            comparisons += 1
                            if x == 0:
                                break
                            x = neighborhood_count(2*r, n, phase, max(x-k, 0))
                            phase ^= 1
                            t += 1
                    rows.append(row)
    long_rows = []
    for r in (5, 20, 100, 1000):
        k = r+1+(r*r+15)//16
        long_rows.append(bounds(2*r, 10**12+1, k))
    receipt = dict(status='PASS', scope=__doc__,
                   source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   rows=rows, long_rows=long_rows,
                   full_deadline_comparisons=comparisons,
                   seconds=process_time()-started)
    Path('research/bridge-boundary-numeric-budget-check.json').write_text(
        json.dumps(receipt, indent=2)+'\n')
    print(dict(status='PASS', cases=len(rows), comparisons=comparisons,
               seconds=receipt['seconds']))


if __name__ == '__main__':
    main()

"""Attack corner-ideal optimality for one-cohort states, without full-board extrapolation."""
from itertools import product
from pathlib import Path
from time import monotonic
import json
from parity_trap_solver import setup, deletion_distance


def canonical_flags(shape, colors):
    output = []
    for row in colors:
        all_flags = bytearray(1 << len(row))
        for reflection in product((0, 1), repeat=len(shape)):
            coords = [tuple(shape[j]-1-v[j] if reflection[j] else v[j]
                            for j in range(len(shape))) for v in row]
            preds = [sum(1 << j for j, w in enumerate(coords)
                         if j != i and all(a <= b for a, b in zip(w, v)))
                     for i, v in enumerate(coords)]
            for b in range(len(all_flags)):
                if all_flags[b]:
                    continue
                remaining = b
                while remaining:
                    bit = remaining & -remaining
                    if preds[bit.bit_length()-1] & ~b:
                        break
                    remaining ^= bit
                else:
                    all_flags[b] = 1
        output.append(all_flags)
    return output


def ranks_for(neighborhoods, m, canonical=None):
    wins = [bytearray([1])+bytearray(len(t)-1) for t in neighborhoods]
    ranks = [[0]+[-1]*(len(t)-1) for t in neighborhoods]
    horizon = 0
    while True:
        new = []
        for p in (0, 1):
            good = bytearray(wins[1-p][nb] and (canonical is None or canonical[p][a])
                             for a, nb in enumerate(neighborhoods[p]))
            d = deletion_distance(good, m+1)
            new.append(bytearray(x <= m for x in d))
        horizon += 1
        for p in (0, 1):
            for b in range(len(ranks[p])):
                if new[p][b] and ranks[p][b] < 0:
                    ranks[p][b] = horizon
        if new == wins:
            return ranks
        wins = new


def main():
    start = monotonic()
    shape = (3, 3, 3)
    colors, neighborhoods = setup(shape)
    flags = canonical_flags(shape, colors)
    for p in (0, 1):
        assert all(not flags[p][b] or flags[1-p][nb] for b, nb in enumerate(neighborhoods[p]))
    result = {'shape': shape, 'scope': 'one initial parity cohort only',
              'canonical_counts': [sum(row) for row in flags], 'budgets': []}
    for m in range(1, 14):
        unrestricted = ranks_for(neighborhoods, m)
        restricted = ranks_for(neighborhoods, m, flags)
        failures = []
        for p in (0, 1):
            for b, flag in enumerate(flags[p]):
                if flag and unrestricted[p][b] != restricted[p][b]:
                    failures.append({'parity': p, 'mask': b, 'unrestricted': unrestricted[p][b],
                                     'restricted': restricted[p][b],
                                     'rooms': [colors[p][i] for i in range(len(colors[p])) if b >> i & 1]})
        report = {'budget': m, 'mismatches': len(failures), 'first_failures': failures[:5],
                  'full_parity_times': [row[-1] for row in unrestricted]}
        result['budgets'].append(report)
        print(report, flush=True)
    result['seconds'] = round(monotonic()-start, 3)
    path = Path(__file__).resolve().parents[1]/'research/parity-corner-three-cube-check.json'
    path.write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__':
    main()

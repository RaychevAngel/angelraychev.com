"""Test the two-solo-radius central-cut formula; no general exactness claim."""
from high_budget_odd_rectangles import profile,exact
from pathlib import Path
import json,time

def candidate(w,n,m):
 h=(w*n-1)//2;b=(w-1)//2
 g=[[profile(b,h,z,k)for k in range(h+2-z)]for z in(0,1)]
 a,c=h+1,h;t=0
 while a and c:
  prev=(a,c)
  a,c=g[1][max(0,c-m)],g[0][max(0,a-m)];t+=1
  if t>10*w*n:raise RuntimeError('infeasible guard')
 return 2*t-int(sum(prev)<=m),t,prev

if __name__=='__main__':
 start=time.monotonic();rows=[];failures=[]
 for w in range(3,28,2):
  for n in (w,w+2,w+6):
   for m in range((w+1)//2,min((w*n-1)//2,w+8)+1):
    pred,t,remainders=candidate(w,n,m);value=exact(w,n,m)
    row=dict(w=w,n=n,m=m,tau=t,residuals=remainders,predicted=pred,exact=value)
    rows.append(row)
    if pred!=value:failures.append(row);print('FAIL',row,flush=True)
    if time.monotonic()-start>45:break
   if time.monotonic()-start>45:break
  if time.monotonic()-start>45:break
 out=dict(scope='Finite central-cut formula attack, not a theorem.',seconds=time.monotonic()-start,results=rows,failures=failures)
 Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-central-cut.json').write_text(json.dumps(out,indent=2)+'\n')
 print('DONE',len(rows),out['seconds'],'failures',len(failures),flush=True)

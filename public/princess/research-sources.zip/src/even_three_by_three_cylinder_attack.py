"""Bounded experiments on the unresolved even 3x3xn five-probe family."""
from itertools import product
from collections import Counter
from time import monotonic
import json
G=((0,2,3,4,4,4),(0,3,4,5,5))

def hood(state,p):
 n=len(state)
 return tuple(max(G[(p+j)%2][state[j]],state[j-1] if j else 0,state[j+1] if j+1<n else 0) for j in range(n))

def critical(n):
 out=[];start=monotonic()
 for p in(0,1):
  counts=Counter();states=[]
  caps=[len(G[(p+j)%2])-1 for j in range(n)]
  for v in product(*(range(c+1) for c in caps)):
   k=sum(v);h=hood(v,p);surplus=sum(h)-k
   if surplus==4:counts[k]+=1;states.append((v,h))
  out.append(states)
  print(json.dumps({'n':n,'p':p,'critical_states':len(states),'counts':dict(counts),'seconds':round(monotonic()-start,3)}),flush=True)
 return out



def scalar_relaxation(h):
 from heapq import heappop,heappush
 profile=[0]+[k+min(4,k+1,(h-k+2)//2) for k in range(1,h)]+[h]
 states=[(k,e)for k in range(h+1)for e in(0,1) if not e or 8<=k<=h-4]
 rev={};charge=(0,0,1,2,3,3)
 for k,e in states:
  for p in range(min(k,5)+1):
   s=k-p
   ys=[0]if s==0 else range(profile[s],h+1)
   for y in ys:
    ne=int(y-s==4 and 4<=s<=h-8)
    if e and ne:continue
    rev.setdefault((y,ne),[]).append(((k,e),charge[p]))
 dist={};todo=[]
 for e in(0,):dist[0,e]=0;heappush(todo,(0,0,e))
 while todo:
  cost,k,e=heappop(todo)
  if dist[k,e]!=cost:continue
  for src,w in rev.get((k,e),[]):
   new=cost+w
   if new<dist.get(src,10**9):dist[src]=new;heappush(todo,(new,*src))
 return dist


def automaton_certificate():
 from collections import deque
 alph=list(product(range(6),range(5)))
 def vcost(s):
  a,b=s;return max(G[0][a],b)-a+max(G[1][b],a)-b
 def ecost(s,t):
  a,b=s;c,d=t
  return max(G[1][b],a,c)-max(G[1][b],a)+max(G[0][c],d,b)-max(G[0][c],d)
 assert all(vcost(s)>=0 for s in alph)
 assert all(ecost(s,t)>=0 for s in alph for t in alph)
 # last pair, cost, capped occupied/omitted counts, first-column>=3, capped pairs
 todo=deque();seen=set();parents={}
 for s in alph:
  cost=vcost(s)
  if cost<=4:
   a,b=s;key=(s,cost,min(4,a+b),min(8,9-a-b),a>=3,1)
   todo.append(key);seen.add(key);parents[key]=None
 count=0
 while todo:
  key=todo.popleft();s,cost,k,d,first,L=key
  if L==2:
   required=0 if k==0 or d==0 else min(4,k+1,(d+2)//2)
   assert cost>=required,(key,'profile')
   if cost==4 and k==4 and d==8:
    assert first and s[1]==0 and s[0]<=2,(key,'geometry')
  for t in alph:
   outcost=cost+ecost(s,t)+vcost(t)
   if outcost>4:continue
   a,b=t;out=(t,outcost,min(4,k+a+b),min(8,d+9-a-b),first,2)
   count+=1
   if out not in seen:seen.add(out);parents[out]=key;todo.append(out)
 return dict(reachable_states=len(seen),transitions_checked=count,all_terminal_assertions_pass=True)


def profile_lower(h,k):
 return 0 if k==0 else h if k==h else k+min(4,k+1,(h-k+2)//2)


def potential3(h,k,e):
 if e:
  assert 8<=k<=h-4
  return 6*k-39
 if k<=8:return (0,0,1,2,3,3,5,6,9)[k]
 return min(6*k-42,3*k+3*h-51,6*h-54)


def verify_scalar(h):
 charge=(0,0,1,2,3,3);checks=0
 for e in(0,1):
  domain=range(h+1) if not e else range(8,h-3)
  for k in domain:
   F=potential3(h,k,e)
   if k+1 in domain:assert F<=potential3(h,k+1,e)
   for p in range(min(k,5)+1):
    s=k-p
    candidates=[(0,0)]if not s else ([(s+4,1),(s+5,0)] if 4<=s<=h-8 else [(profile_lower(h,s),0)])
    for y,ne in candidates:
     if e and ne:continue
     assert (not ne or 8<=y<=h-4) and y<=h
     assert F<=charge[p]+potential3(h,y,ne),(h,k,e,p,y,ne,F,charge[p]+potential3(h,y,ne))
     checks+=1
 assert 2*potential3(h,h,0)==3*(4*h-36)
 return checks


def even_prefix_profiles(h):
 from three_by_three_cylinder_time import BASE_RANKS,BASE_WEIGHTS
 return [[0]+[k+sum(v for r,v in zip(BASE_RANKS[z],BASE_WEIGHTS[z])if r<=k)-4+sum(r<=h-k for r in BASE_RANKS[1-z])for k in range(1,h+1)]for z in(0,1)]


def physical_upper(n):
 from nested_grid_time import ordered_profiles,neighborhood
 report,data=ordered_profiles((3,3,n),weightlex=True)
 coords,adj,orders,prefixes,profiles=data;h=9*n//2
 assert report['nested'] and profiles==even_prefix_profiles(h)
 reverse={i:coords.index((v[0],v[1],n-1-v[2]))for i,v in enumerate(coords)}
 def reflected(mask):
  out=0
  while mask:
   bit=mask&-mask;mask-=bit;out|=1<<reverse[bit.bit_length()-1]
  return out
 belief=(1<<(9*n))-1;days=0;lengths=[];hits=[]
 for cohort in(0,1):
  k=h;phase=0;start=days;hit=[]
  while k:
   if k==22:hit.append((days-start,phase))
   survivor=prefixes[phase][max(0,k-5)]
   shot=prefixes[phase][k]^survivor
   if cohort:shot=reflected(shot)
   assert shot&~belief==0 and shot.bit_count()<=5
   belief=neighborhood(belief&~shot,adj)
   k=profiles[phase][max(0,k-5)];phase^=1;days+=1
  lengths.append(days-start);hits.append(hit)
 assert not belief and days==18*n-36
 assert lengths==[9*n-18]*2 and lengths[0]%2==0
 return dict(length=n,days=days,solo_lengths=lengths,cut22_visits=hits)


def full_certificate():
 from pathlib import Path
 start=monotonic();geometry=automaton_certificate()
 scalar={h:verify_scalar(h)for h in(18,27,36,45)}
 collar=[12,32]
 for e in(0,1):
  assert all(potential3(45,k,e)==6*k-42+3*e for k in range(12,33))
 physical=[physical_upper(n)for n in(4,6,8,10,12,30)]
 redundant={h:verify_scalar(h)for h in(46,54,65,145)}
 result=dict(status='Ordinary all-even theorem independently reviewed and accepted; finite premises checked exactly',formula='T5(3x3xn)=18n-36 for every even n>=4',geometry=geometry,scalar_checks=scalar,base_half_size=45,cut=22,displacement_bound=5,collar=collar,potential_formula='F0 low=(0,0,1/3,2/3,1,1,5/3,2,3); for k>=9 min(2k-14,k+h-17,2h-18); F1=2k-13',physical_cases=physical,redundant_insertions=redundant,seconds=round(monotonic()-start,3))
 Path('research/even-three-by-three-cylinder-certificate.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
 return result


if __name__=="__main__":
 full_certificate()

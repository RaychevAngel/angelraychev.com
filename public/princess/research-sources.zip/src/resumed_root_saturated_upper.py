"""Direct physical replay of root-saturated backward envelopes.

The construction and symbolic proof are in resumed-rectangle-research-log.md.
This is an upper-bound witness check, not a search or proof of optimality.
"""
from itertools import product
from math import isqrt
from pathlib import Path
import json
import time

ROOT = Path(__file__).resolve().parents[1]


def root(x):
    return isqrt(x) + (isqrt(x) ** 2 < x)


def pronic(x):
    z = isqrt(x)
    return 0 if x == 0 else z + 1 + (x > z * (z + 1))


def run(w, n, k, include_shots=False):
    assert 2 <= w <= n and w * n % 2 == 0 and w // 2 + 1 <= k < w * n // 2
    r, h = w // 2, w * n // 2
    if w % 2 == 0:
        q, s = divmod(h - r, k - r)
        count, p = s, 0
        J = s + min(root(s), r) if s else 0
    else:
        q, s = divmod(2 * h - w - 1, 2 * k - w)
        count, p = (s // 2, 1) if s % 2 == 0 else ((s + 1) // 2, 0)
        J = (count + min(pronic(count), r + 1) if p else count + min(root(count), r)) if s else 0
    target = 2 * q if s == 0 else 2 * q + (1 if 2 * J <= k else 2)
    vertices = set(product(range(w), range(n)))
    colors = [{v for v in vertices if sum(v) % 2 == pp} for pp in (0, 1)]
    orders = [sorted(C, key=lambda v: (v[1], v[0])) for C in colors]
    def N(S):
        return {v for x,y in S for v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if v in vertices}
    def ideal(S):
        return all((u,y-1) in S for x,y in S if y > 0 for u in (x-1,x+1) if 0 <= u < w)
    R = set(sorted(colors[p], key=lambda v: (sum(v), -v[0]))[:count])
    assert ideal(R)
    X = N(R)
    assert len(X) <= J <= k, (w,n,k,s,p,len(X),J)
    reverse = []
    for _ in range(q - 1):
        desired = len(R) + k
        roots = {(x,0) for x in range(w) if x % 2 == p}
        A = R | roots
        assert len(A) <= desired <= h and ideal(A)
        for v in orders[p]:
            if len(A) == desired:
                break
            A.add(v)
        assert len(A) == desired and ideal(A)
        reverse.append(A - R)
        cutoff = [max((y for x0,y in A if x0 == x), default=((p-x) % 2)-2) for x in range(w)]
        E = {v for v in colors[1-p] if v[1] <= cutoff[v[0]] - 1}
        assert ideal(E) and len(E) == len(A) - len(roots) and N(E) <= A
        R, p = E, 1-p
    assert len(colors[p] - R) == k, (w,n,k,q,s,len(R),p)
    reverse.append(colors[p] - R)
    half = list(reversed(reverse))
    belief = set(colors[p])
    for shots in half:
        assert len(shots) <= k
        belief = N(belief - shots)
    assert belief <= X
    if s == 0:
        shots = half + list(reversed(half))
    elif 2 * J <= k:
        reflection = (lambda A: {(w-1-x,y) for x,y in A}) if w % 2 == 0 else (lambda A: {(x,n-1-y) for x,y in A})
        shots = half + [X | reflection(X)] + [reflection(A) for A in reversed(half)]
    else:
        solo = half + [X]
        shots = solo + list(reversed(solo))
    assert len(shots) == target
    belief, first = set(vertices), None
    for t,A in enumerate(shots, 1):
        assert A <= vertices and len(A) <= k
        belief -= A
        if not belief and first is None:
            first = t
        belief = N(belief)
    assert not belief and first <= target
    result = dict(w=w,n=n,k=k,upper=target,first_actual_capture=first,q=q,s=s,J=J)
    if include_shots:
        result['shots'] = [sorted(A) for A in shots]
    return result


def main():
    start = time.monotonic()
    rows = []
    for w in range(2, 17):
        for n in range(w, w + 5):
            if w*n % 2:
                continue
            for k in range(w//2 + 1, w*n//2):
                rows.append(run(w,n,k))
    output = {'status':'PASS', 'scope':'Explicit upper-bound constructions physically replayed; no unrestricted lower bound or optimality inferred.',
              'cases':rows, 'elapsed_seconds':time.monotonic()-start}
    (ROOT/'research/resumed-root-saturated-upper.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'status':output['status'],'cases':len(rows),'seconds':output['elapsed_seconds']}))


if __name__ == '__main__':
    main()

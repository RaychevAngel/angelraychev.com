"""Focused ancestry and phase-reset diagnostics; no finite check is a proof."""
from bisect import bisect_right
from math import isqrt
from odd_serial_first_order_attack import profiles
from uniform_rectangle_half_time import capacities

def R(k): return isqrt(k)+(isqrt(k)**2<k)
def rho(k):
    r=isqrt(k)
    return r+(r*(r+1)<k)

def run(b, extra=0):
    w=2*b+1;n=w+2*extra;m=b+1;g=profiles((n-1)//2,b)
    E,M=len(g[0])-1,len(g[1])-1; C=b*(b-1);d=M-b*b-1
    I=[[bisect_right(g[p],z)-1 for z in range((M,E)[p]+1)] for p in (0,1)]
    tau,_,D=capacities(g,m)
    t0=next(t for t,v in enumerate(D) if v==(d,d))
    L=tau-1-t0
    # Tag primary initial physical color; retain each ancestry separately.
    rows=[];states={(d,0,0),(0,d,1)}; failures=[]
    for t in range(L+1):
        big=max(D[t0+t]);small=min(D[t0+t])
        mixed=[v for v in states if v[0] and v[1]]
        if mixed:
            maxsec=max(v[1-((v[2]+t)%2)] for v in mixed)
            minprimary=min(v[(v[2]+t)%2] for v in mixed)
        else:maxsec=0;minprimary=None
        rows.append((t,D[t0+t],len(mixed),maxsec,minprimary))
        for a,c,tag in mixed:
            p=(tag+t)%2;primary=(a,c)[p];sec=(a,c)[1-p]
            z=(E,M)[p]-primary
            # Candidate roots are recorded, not used to prune.
            roots=(R(z)+rho(sec),rho(z)+R(sec))
            if min(roots)>b+1:failures.append((t,(a,c),p,z,sec,roots))
        if t==L:break
        nxt={(D[t0+t+1][0],0,(t+1)%2),(0,D[t0+t+1][1],1-(t+1)%2)}
        for a,c,tag in states:
          for q in range(m+1):
            aa=I[0][c+m-q];cc=I[1][a+q]
            if aa and cc and aa+cc>min(D[t0+t+1]):nxt.add((aa,cc,tag))
        # Per-tag Pareto discard only.
        states=set()
        for tag in (0,1):
            top=-1
            for a,c,_ in sorted((v for v in nxt if v[2]==tag),reverse=True):
                if c>top:states.add((a,c,tag));top=c
    episodes=[];start=None;owner=None
    for t,v in enumerate(D[t0:]):
        own=None if v[0]==v[1] else (int(v[1]>v[0])+t)%2
        if own!=owner:
            if owner is not None:episodes.append((start,t-start,owner))
            start=t;owner=own
    if owner is not None:episodes.append((start,L+1-start,owner))
    return {'b':b,'n':n,'L':L,'tau':tau,'max_mixed':max(r[2]for r in rows),'max_secondary':max(r[3]for r in rows),'max_episode':max((x[1]for x in episodes),default=0),'root_failures':failures[:3],'episodes':episodes,'rows':rows}

if __name__=='__main__':
    import json,sys,time
    start=time.process_time();bs=list(map(int,sys.argv[1:]))or[2,3,4,9,12,20,40]
    ans=[run(b)for b in bs]
    for a in ans:print(json.dumps({k:v for k,v in a.items()if k not in ('rows','episodes')}))
    print('CPU seconds',time.process_time()-start)

"""Exact upper search inside unions OR intersections of two bottom prefixes.

Only survivors are restricted. Literal neighborhoods are retained as beliefs
whether or not they belong to that family. No normal-form assertion is made.
"""
from collections import deque,defaultdict
from pathlib import Path
import argparse,json,time
from resumed_even_construction_prefix import PrefixGame
from resumed_even_construction_transport import neighborhood


def run(w=24,n=None,k=13):
    if n is None:n=w
    start=time.monotonic();g=PrefixGame(w,n);h=w*n//2
    groups=[];representations=[]
    for p in(0,1):
        reps={}
        for u,I in enumerate(g.orders[p][0]):
            for v,J in enumerate(g.orders[p][4]):
                reps.setdefault(I|J,('union',u,v))
                reps.setdefault(I&J,('intersection',u,v))
        group=defaultdict(list)
        for mask in reps:group[mask.bit_count()].append(mask)
        groups.append(group);representations.append(reps)
    initial=(0,g.full);queue=deque([(initial,0)]);parents={initial:None}
    terminal=None;terminal_depth=None;tested=legal=0;layer_minima={}
    while queue:
        (p,mask),depth=queue.popleft()
        if terminal_depth is not None and depth>terminal_depth:break
        size=mask.bit_count();layer_minima[depth]=min(size,layer_minima.get(depth,h+1))
        if size<=k:
            if terminal is None or size<terminal[1].bit_count():terminal=(p,mask)
            terminal_depth=depth;continue
        if terminal_depth is not None:continue
        for survivor in groups[p][size-k]:
            tested+=1
            if survivor&~mask:continue
            legal+=1;nxt=(1-p,g.hood(p,survivor))
            if nxt not in parents:
                parents[nxt]=((p,mask),survivor);queue.append((nxt,depth+1))
    assert terminal is not None
    current=terminal;steps=[(terminal,0)]
    while parents[current]is not None:
        current,survivor=parents[current];steps.append((current,survivor))
    steps.reverse();shots=[];schedule=[]
    for (p,mask),survivor in steps:
        shotmask=mask^survivor
        shot={v for i,v in enumerate(g.colors[p])if shotmask>>i&1};shots.append(shot)
        schedule.append({'before_size':mask.bit_count(),'survivor_size':survivor.bit_count(),
                         'survivor_representation':representations[p][survivor],
                         'shots':sorted(shot)})
    sequences={'solo':shots,'full_even':shots+shots[::-1]}
    if 2*len(shots[-1])<=k:
        reflect=lambda S:{(w-1-x,y)for x,y in S}
        sequences['full_odd']=shots[:-1]+[shots[-1]|reflect(shots[-1])]+[reflect(S)for S in shots[-2::-1]]
    captures={}
    for mode,sequence in sequences.items():
        A=set(g.colors[0])if mode=='solo'else{(x,y)for x in range(w)for y in range(n)}
        first=None
        for day,shot in enumerate(sequence,1):
            assert len(shot)<=k
            A-=shot
            if not A and first is None:first=day
            A=neighborhood(w,n,A)
        assert not A;captures[mode]=first
    return {'shape':[w,n],'budget':k,'restricted_solo_clock':len(shots),
            'smallest_terminal_support':len(shots[-1]),'literal_capture_days':captures,
            'all_physical_replays_passed':True,
            'survivor_family_counts':[len(r)for r in representations],
            'visited_beliefs':len(parents),'containment_checks':tested,'legal_edges':legal,
            'layer_minimum_sizes':layer_minima,'schedule':schedule,'seconds':time.monotonic()-start,
            'scope':'Exact survivor-family upper search allowing unions and intersections of two bottom-corner prefixes. No unrestricted optimality assertion.'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--w',type=int,default=24)
    p.add_argument('--n',type=int);p.add_argument('--k',type=int,default=13);a=p.parse_args()
    n=a.n or a.w;out=run(a.w,n,a.k)
    Path(f'research/resumed-even-construction-union-intersection-{a.w}x{n}-k{a.k}.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k not in('schedule','layer_minimum_sizes')})

"""Combine physical corner counts and the enlarged odd-width critical history.

All permitted surpluses and corner counts are retained. This is a necessary
transition relaxation, not a normal-form assertion. Floating LP proposals
are checked with exact Fraction arithmetic before any lower bound is emitted.
"""
from pathlib import Path
from fractions import Fraction
from math import ceil
from collections import deque
import argparse,json,time
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from resumed_odd_even_corner_potential import root,rho,pronic
from resumed_even_construction_formula_profile import allowed,F


def build(b,n,m):
    h=(2*b+1)*n//2;B=b*(b+1);C=b*(b-1)
    states=[(k,c,z) for k in range(h+1) for c in range(3) for z in range(3)
            if c<=k<=h-2+c and
            (z==0 or z==1 and c==0 and b*b+1<=k<=h-b*b-1 or
             z==2 and h-b*b<=k<h)]
    index={s:i for i,s in enumerate(states)};edges=set()
    for (k,c,z),source in index.items():
        for p in range(min(m,k)+1):
            r=k-p
            if not r:
                edges.add((source,index[(0,0,0)],p));continue
            lo=min(root(r),b,rho(h-r))
            if z==1 and r<=b*b:lo=max(lo,min(pronic(r),b+1))
            for i in range(max(0,c-p),min(c,r)+1):
                if r>h-2+i:continue
                for s in range(lo,h-r+1):
                    critical=C<r<h-B and s==b
                    if critical and (i==0 or z==1 or z==2 and r>b*b):continue
                    nz=1 if critical else 2 if r>=h-B and s<=b and h-r>s*s else 0
                    for j in range(3):
                        if not j<=r+s<=h-2+j:continue
                        if critical and j:continue
                        # Complement-neighborhood dual of the enlarged critical
                        # theorem. Its dual surplus equals b by the strict
                        # subcritical size dichotomy, so no corner slack remains.
                        if s==b and b*b<r<h-b*b and (i!=2 or j>1):continue
                        if not allowed(h,b,r,i,r+s,j):continue
                        if s==b and (i,j)!=(2,0):
                            if not (r<=F(i,j,b) or h-r-b<=max(F(2-j,d,b-2+i+d)for d in range(3-i))):continue
                        if b>=2 and r==C and s==b and j==1:assert i==0
                        target=(r+s,j,nz)
                        assert target in index,target
                        edges.add((source,index[target],p))
    return states,sorted(edges)


def build_triangle_memory(b,n,m):
    assert b>=2
    states,edges=build(b,n,m);base=list(states);ids={s:i for i,s in enumerate(base)}
    C=b*(b-1);marked=(b*b,1,0);extra=len(states);states.append((*marked,4))
    outgoing=[[]for _ in base]
    for a,d,p in edges:outgoing[a].append((d,p))
    result=[]
    for a,state in enumerate(states):
        old=ids[state[:3]];flag=len(state)>3
        for d,p in outgoing[old]:
            target=base[d]
            if flag and target[1]>0:continue
            # The critical corner theorem itself forces survivor i=0 here,
            # checked during base-edge generation, even if corners were removed.
            dd=extra if state[0]-p==C and target==marked else d
            result.append((a,dd,p))
    return states,result


def solo_certificate(states,edges,h,initial_state=None):
    start=states.index(initial_state or(h,2,0));zero=states.index((0,0,0))
    forward=[set()for _ in states];backward=[set()for _ in states]
    for a,d,p in edges:forward[a].add(d);backward[d].add(a)
    def distances(graph,initial):
        dist={initial:0};todo=deque([initial])
        while todo:
            a=todo.popleft()
            for d in graph[a]:
                if d not in dist:dist[d]=dist[a]+1;todo.append(d)
        return dist
    f=distances(forward,start);g=distances(backward,zero)
    for a,d,p in edges:
        if a in f:assert f[d]<=f[a]+1
        if d in g:assert g[a]<=g[d]+1
    duration=g[start]
    return {'solo_relaxation_minimum':duration,
            'solo_forward_lower_potential':[f.get(i)for i in range(len(states))],
            'solo_backward_lower_potential':[g.get(i)for i in range(len(states))],
            'solo_optimal_layers':[[states[i]for i in range(len(states))
                                   if f.get(i,10**9)<=t and g.get(i,10**9)<=duration-t]
                                  for t in range(duration+1)],
            'solo_potential_inequalities_checked':2*len(edges)}


def build_with_forbidden_prefix(b,n,m,terminal=False):
    assert (b,n,m)==(3,8,4)
    states,edges=build(b,n,m);base=list(states);ids={s:i for i,s in enumerate(base)}
    marked=[(26,2,0),(24,1,2),(23,2,0)]
    extended={i+1:len(states)+i for i in range(3)}
    states += [(*s,i+1)for i,s in enumerate(marked)]
    terminal_id=len(states)
    if terminal:states.append((9,1,0,4))
    outgoing=[[]for _ in base]
    for a,d,p in edges:outgoing[a].append((d,p))
    result=[]
    for a,state in enumerate(states):
        old=ids[state[:3]];history=state[3]if len(state)>3 else 0
        for d,p in outgoing[old]:
            target=base[d]
            if history==3 and target[:2]==(22,2):continue
            if history==4 and target[1]>0:continue
            if state[:3]==(28,2,0) and target==marked[0]:dd=extended[1]
            elif history in(1,2)and target==marked[history]:dd=extended[history+1]
            elif terminal and state[:2]==(10,0) and target==(9,1,0):dd=terminal_id
            else:dd=d
            result.append((a,dd,p))
    return states,result


def joint_bfs(states,edges,m,h,initial_state=None):
    count=len(states);options=[{}for _ in states]
    for a,d,p in edges:options[a][d]=min(p,options[a].get(d,m+1))
    masks=[]
    for row in options:
        masks.append([sum(1<<d for d,p in row.items()if p<=q)for q in range(m+1)])
    initial=states.index(initial_state or(h,2,0));initial_pair=count*initial+initial
    seen=[0]*count;seen[initial]=1<<initial
    parents={initial_pair:None};frontier=[(initial,initial)];depth=0
    while frontier:
        for a,b in frontier:
            if states[a][0]+states[b][0]<=m:
                cursor=count*a+b;path=[]
                while parents[cursor] is not None:
                    previous,pa,pb=parents[cursor]
                    aa,bb=divmod(previous,count);cc,dd=divmod(cursor,count)
                    path.append({'before':[states[aa],states[bb]],'inspections':[pa,pb],
                                 'after':[states[cc],states[dd]]});cursor=previous
                path.reverse()
                return {'joint_lower_if_geometry_accepted':depth+1,
                        'reachable_pairs':len(parents),'relaxed_path':path,
                        'terminal_inspections':[states[a][0],states[b][0]]}
        following=[]
        for a,b in frontier:
            for aa,pa in options[a].items():
                new=masks[b][m-pa]&~seen[aa]
                seen[aa]|=new
                while new:
                    bit=new&-new;bb=bit.bit_length()-1;new-=bit
                    parents[count*aa+bb]=(count*a+b,pa,options[b][bb])
                    following.append((aa,bb))
        frontier=following;depth+=1
    raise AssertionError('No finite capture in the relaxed graph')


def audit_joint(states,edges,m,h,initial_state=None):
    """Construct backwards ranks and check them as a joint integer potential.

    This is independent of the forward BFS's discovery and stopping rule.
    Every permitted edge is checked against the resulting lower potential.
    """
    count=len(states);reverse=[{}for _ in states]
    for a,d,p in edges:reverse[d][a]=min(p,reverse[d].get(a,m+1))
    masks=[[sum(1<<a for a,p in row.items()if p<=q)for q in range(m+1)]
           for row in reverse]
    zero=states.index((0,0,0));seen=[0]*count;seen[zero]=1<<zero
    ranks=[[-1]*count for _ in states];ranks[zero][zero]=0
    frontier=[(zero,zero)];depth=0
    while frontier:
        following=[]
        for a,b in frontier:
            for aa,pa in reverse[a].items():
                new=masks[b][m-pa]&~seen[aa];seen[aa]|=new
                while new:
                    bit=new&-new;bb=bit.bit_length()-1;new-=bit
                    ranks[aa][bb]=depth+1;following.append((aa,bb))
        frontier=following;depth+=1
    maximum=max(map(max,ranks))+1
    ranks=[[maximum if x<0 else x for x in row]for row in ranks]
    greater=[[sum(1<<b for b,r in enumerate(row)if r>t)
              for t in range(maximum+2)]for row in ranks]
    checked=0
    for a in range(count):
        for b in range(count):
            threshold=ranks[a][b]+1
            for aa,pa in reverse[a].items():
                predecessor_mask=masks[b][m-pa]
                assert not predecessor_mask&greater[aa][threshold],(a,b,aa,pa)
                checked+=predecessor_mask.bit_count()
    start=states.index(initial_state or(h,2,0))
    assert ranks[zero][zero]==0
    return {'independent_joint_potential_lower':ranks[start][start],
            'independent_joint_inequalities_checked':checked,
            'joint_potential_states':states,'joint_integer_potential':ranks,
            'independent_joint_audit':'Reverse reachability produced an integer potential; its decrease is at most one on every allowed joint transition and it vanishes at capture.'}


def run(b,n,m,joint=False,audit=False,forbidden=False,terminal=False,triangle=False):
    started=time.process_time()
    states,edges=build_triangle_memory(b,n,m)if triangle else build_with_forbidden_prefix(b,n,m,terminal)if forbidden else build(b,n,m)
    h=(2*b+1)*n//2;offset=len(states);nv=offset+m+1;rows=[]
    for a,d,p in edges:
        row={a:1};row[d]=row.get(d,0)-1
        row[offset+p]=row.get(offset+p,0)-1;rows.append((row,0))
    for p in range(m+1):
        for q in range(m-p+1):
            row={offset+p:1};row[offset+q]=row.get(offset+q,0)+1
            rows.append((row,1))
    ii=[];jj=[];vv=[]
    for t,(row,_) in enumerate(rows):
        for j,v in row.items():
            if v:ii.append(t);jj.append(j);vv.append(v)
    mat=coo_matrix((vv,(ii,jj)),shape=(len(rows),nv)).tocsr()
    obj=np.zeros(nv);start=states.index((h,2,0));obj[start]=-2
    bounds=[(0,None)]*nv;bounds[states.index((0,0,0))]=(0,0);bounds[offset]=(0,0)
    lp=linprog(obj,A_ub=mat,b_ub=np.array([v for _,v in rows]),bounds=bounds,
               method='highs',options={'threads':1})
    assert lp.success,lp.message
    exact=[Fraction(float(v)).limit_denominator(1000000) for v in lp.x]
    bad=[i for i,(row,rhs) in enumerate(rows)
         if sum(exact[j]*v for j,v in row.items())>rhs]
    assert not bad,bad[:10]
    value=2*exact[start]
    result={'width':2*b+1,'length':n,'budget':m,'potential_value':str(value),
            'four_day_forbidden_prefix':forbidden,
            'terminal_two_step_obstruction':terminal,
            'uniform_pronic_triangle_memory':triangle,
            'integer_lower_if_geometry_accepted':ceil(value),
            'exact_fraction_verification':True,'states':len(states),
            'inequalities':len(rows),'charges':[str(v) for v in exact[offset:]],
            'potentials':{','.join(map(str,s)):str(exact[i])for i,s in enumerate(states)},
            'cpu_seconds':time.process_time()-started}
    if joint:result.update(joint_bfs(states,edges,m,h))
    if audit:
        result.update(audit_joint(states,edges,m,h))
        if joint:assert result['joint_lower_if_geometry_accepted']==result['independent_joint_potential_lower']
    result.update(solo_certificate(states,edges,h))
    result['cpu_seconds']=time.process_time()-started
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--cases',default='3,8,4;4,10,5')
    p.add_argument('--output',default='research/resumed-odd-even-corner-history.json')
    p.add_argument('--joint',action='store_true')
    p.add_argument('--audit',action='store_true')
    p.add_argument('--forbidden-prefix',action='store_true')
    p.add_argument('--terminal-obstruction',action='store_true')
    p.add_argument('--triangle-only',action='store_true')
    args=p.parse_args();out=[]
    for case in args.cases.split(';'):
        result=run(*map(int,case.split(',')),joint=args.joint,audit=args.audit,forbidden=args.forbidden_prefix,terminal=args.terminal_obstruction,triangle=args.triangle_only);out.append(result)
        print({k:v for k,v in result.items()if k not in ('potentials','relaxed_path','joint_integer_potential','joint_potential_states','solo_optimal_layers','solo_forward_lower_potential','solo_backward_lower_potential')},flush=True)
    Path(args.output).write_text(json.dumps({'scope':'Necessary transitions only; ordinary geometric inputs with exactly checked rational finite lower potentials. No dynamic sufficiency claim.','results':out},indent=2)+'\n')


if __name__=='__main__':main()

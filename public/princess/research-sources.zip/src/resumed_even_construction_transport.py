"""Direct virtual-height transport, with independent literal-grid replay."""
from pathlib import Path
import json,random


def neighborhood(w,n,A):
    return {v for x,y in A for v in((x-1,y),(x+1,y),(x,y-1),(x,y+1))
            if 0<=v[0]<w and 0<=v[1]<n}


def height(w,n,p,A):
    return [max((y for x,y in A if x==v),default=(p-v)%2-2)for v in range(w)]


def construct(w,n,p,a,b,t,k,boundary_credit=False):
    assert t>=0
    assert all((a[x]-(p-x))%2==0 and (b[x]-(p+t-x))%2==0 for x in range(w))
    assert all(abs(a[x+1]-a[x])==abs(b[x+1]-b[x])==1 for x in range(w-1))
    c=[min(x,y-t)for x,y in zip(a,b)]
    F=sum(x-y for x,y in zip(a,c))//2
    # Zero days permit only initial containment; there is no root credit.
    credit=sum(b[v]<0 and (p+t-v)%2==0 for v in range(w))if boundary_credit and t>=1 else 0
    assert F-credit<=k*t
    now=a.copy();word=[]
    while now!=c:
        v=max((x for x in range(w)if now[x]>c[x]),key=lambda x:(now[x],-x))
        assert all(now[u]==now[v]-1 for u in(v-1,v+1)if 0<=u<w)
        word.append((v,now[v]));now[v]-=2
    assert len(word)==F
    shots=[];position=0;free_by_day=[]
    for day in range(t):
        group=[];charged=0;free=0
        while position<len(word):
            v,y=word[position];is_free=boundary_credit and y<=-t
            if not is_free and charged==k:break
            group.append((v,y));position+=1
            if is_free:free+=1
            else:charged+=1
        shots.append({(v,y+day)for v,y in group if 0<=y+day<n})
        free_by_day.append(free)
        assert len(shots[-1])<=k
    assert position==len(word) and sum(free_by_day)==credit
    A={(x,y)for x in range(w)for y in range(n)if(x+y)%2==p and y<=a[x]}
    for shot in shots:A=neighborhood(w,n,A-shot)
    assert all(y<=b[x]for x,y in A)
    return shots,{'virtual_inspections':F,'guaranteed_free_root_flips':credit,
                  'daily_free_flips':free_by_day,'daily_visible_inspections':[len(s)for s in shots],
                  'endpoint_size':len(A),'physical_containment_verified':True}


def run():
    w=n=12;k=7
    original=json.loads(Path('research/resumed-even-construction-two-prefixes-12x12-k7.json').read_text())
    old=[set(map(tuple,row['shots']))for row in original['schedule']]
    A={(x,y)for x in range(w)for y in range(n)if(x+y)%2==0};beliefs=[A]
    for shot in old:A=neighborhood(w,n,A-shot);beliefs.append(A)
    entry,exit=18,26;t=exit-entry
    a=height(w,n,entry%2,beliefs[entry]);b=height(w,n,exit%2,beliefs[exit])
    bridge,receipt=construct(w,n,entry%2,a,b,t,k,boundary_credit=True)
    solo=old[:entry]+bridge+old[exit:]
    for label,sequence,initial in(('solo',solo,beliefs[0]),
                                  ('full',solo+solo[::-1],{(x,y)for x in range(w)for y in range(n)})):
        A=set(initial);first=None
        for day,shot in enumerate(sequence,1):
            A-=shot
            if not A and first is None:first=day
            A=neighborhood(w,n,A)
        assert not A;receipt[label+'_capture_day']=first
    # A bounded falsification audit uses independently generated legal height
    # walks and both board phases; it is not a replacement for the proof.
    from resumed_even_construction_square_audit import prepare
    d=prepare(6,6);rng=random.Random(20260913);checked=0
    for _ in range(100):
        p=rng.randrange(2);t=rng.randrange(1,10)
        a=list(rng.choice(d['heights'][p]));b=list(rng.choice(d['heights'][(p+t)%2]))
        F=sum(max(x-y+t,0)for x,y in zip(a,b))//2
        credit=sum(b[v]<0 and (p+t-v)%2==0 for v in range(6))
        budget=(F-credit+t-1)//t
        construct(6,6,p,a,b,t,budget,boundary_credit=True);checked+=1
    return {'scope':'Independently reviewed ordinary upper-containment lemma and root-credit strengthening, with literal-grid replay. No physical lower or uniform model attainment claim.',
            'shape':[w,n],'budget':k,'entry_day':entry,'exit_day':exit,
            'entry_size':len(beliefs[entry]),'exit_envelope_size':len(beliefs[exit]),
            'bridge':receipt,'random_containment_cases':checked,
            'bridge_shots':[sorted(s)for s in bridge]}


if __name__=='__main__':
    out=run()
    Path('research/resumed-even-construction-transport-check.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='bridge_shots'})

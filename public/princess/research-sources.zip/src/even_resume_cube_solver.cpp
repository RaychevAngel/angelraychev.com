// Exact BFS on the proved square-compression fixed family.
// Deduplicates identical successors only; no dominance or heuristic pruning.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
struct Choice { int next, residual; };
int main() {
  int n[2], first, last; cin >> n[0] >> n[1] >> first >> last;
  vector<uint64_t> masks[2]; vector<int> sizes[2], hood[2];
  vector<vector<vector<Choice>>> moves[2];
  for (int p=0; p<2; ++p) {
    masks[p].resize(n[p]); sizes[p].resize(n[p]); hood[p].resize(n[p]);
    for (int i=0; i<n[p]; ++i) cin >> masks[p][i] >> sizes[p][i] >> hood[p][i];
  }
  for (int p=0; p<2; ++p) {
    moves[p].resize(n[p]);
    for (int a=0; a<n[p]; ++a) {
      moves[p][a].resize(sizes[p][a]+1);
      for (int r=0; r<n[p]; ++r) if ((masks[p][r] & masks[p][a]) == masks[p][r]) {
        int cost=sizes[p][a]-sizes[p][r];
        auto &row=moves[p][a][cost];
        if (none_of(row.begin(),row.end(),[&](Choice x){return x.next==hood[p][r];}))
          row.push_back({hood[p][r],r});
      }
    }
  }
  for (int budget=first; budget<=last; ++budget) {
    auto start=chrono::steady_clock::now();
    int total=n[0]*n[1], initial=total-1, found=-1;
    vector<int> parent(total,-2), ra(total), rb(total), depth(total), queue;
    queue.reserve(total); queue.push_back(initial); parent[initial]=-1;
    uint64_t edges=0;
    for (size_t head=0; head<queue.size(); ++head) {
      int state=queue[head], a=state/n[1], b=state%n[1];
      if (sizes[0][a]+sizes[1][b]<=budget) {found=state; break;}
      int low=max(0,budget-sizes[1][b]), high=min(budget,sizes[0][a]);
      for (int p=low; p<=high; ++p)
        for (Choice x:moves[0][a][p]) for (Choice y:moves[1][b][budget-p]) {
          ++edges; int after=y.next*n[1]+x.next;
          if (parent[after]==-2) {
            parent[after]=state; ra[after]=x.residual; rb[after]=y.residual;
            depth[after]=depth[state]+1; queue.push_back(after);
          }
        }
    }
    vector<array<int,4>> steps;
    if (found>=0) {
      steps.push_back({found/n[1],found%n[1],0,0});
      for (int here=found; parent[here]>=0; here=parent[here]) {
        int before=parent[here];
        steps.push_back({before/n[1],before%n[1],ra[here],rb[here]});
      }
      reverse(steps.begin(),steps.end());
    }
    double sec=chrono::duration<double>(chrono::steady_clock::now()-start).count();
    cout << budget << ' ' << (found<0?-1:int(steps.size())) << ' ' << queue.size()
         << ' ' << edges << ' ' << sec << '\n';
    for (auto s:steps) cout << s[0] << ' ' << s[1] << ' ' << s[2] << ' ' << s[3] << '\n';
    cout.flush();
  }
}

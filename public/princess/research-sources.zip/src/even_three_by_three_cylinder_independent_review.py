"""Independent exact audit of the even 3x3xn five-probe theorem.

No imports from the proposed certificate or its geometry/profile modules.
The all-length argument is recorded separately in the accompanying review.
"""
from itertools import product
from pathlib import Path
import hashlib
import json
import time

CHARGE = (0, 0, 1, 2, 3, 3)
LOW = (0, 0, 1, 2, 3, 3, 5, 6, 9)
RANKS = ((1, 2, 3, 5, 8), (1, 2, 4, 6))
WEIGHTS = ((2, 1, 1, 0, 0), (2, 1, 1, 0))


def potential(h, k, marked):
    if marked:
        assert 8 <= k <= h - 4
        return 6 * k - 39
    if k <= 8:
        return LOW[k]
    return min(6 * k - 42, 3 * k + 3 * h - 51, 6 * h - 54)


def lower(h, k):
    if k in (0, h):
        return k
    return k + min(4, k + 1, (h - k + 2) // 2)


def scalar(h):
    checks = 0
    for old_mark in (0, 1):
        for k in range(h + 1):
            if old_mark and not 8 <= k <= h - 4:
                continue
            for probes in range(min(k, 5) + 1):
                remaining = k - probes
                outputs = (0,) if not remaining else range(lower(h, remaining), h + 1)
                for after in outputs:
                    marked = int(4 <= remaining <= h - 8 and after == remaining + 4)
                    if old_mark and marked:
                        continue
                    assert potential(h, k, old_mark) <= CHARGE[probes] + potential(h, after, marked)
                    checks += 1
    assert 2 * potential(h, h, 0) == 3 * (4 * h - 36)
    return checks


def profile(h, phase, k):
    if not k:
        return 0
    bottom = sum(w for r, w in zip(RANKS[phase], WEIGHTS[phase]) if r <= k)
    omitted_top = sum(r <= h - k for r in RANKS[1 - phase])
    return k + bottom - 4 + omitted_top


def physical(n):
    vertices = list(product(range(3), range(3), range(n)))
    index = {v: i for i, v in enumerate(vertices)}
    adjacency = []
    for v in vertices:
        mask = 0
        for axis, size in enumerate((3, 3, n)):
            for direction in (-1, 1):
                w = list(v)
                w[axis] += direction
                if 0 <= w[axis] < size:
                    mask |= 1 << index[tuple(w)]
        adjacency.append(mask)

    def neighborhood(mask):
        out = 0
        while mask:
            bit = mask & -mask
            mask -= bit
            out |= adjacency[bit.bit_length() - 1]
        return out

    prefixes = []
    for phase in (0, 1):
        ordered = sorted((v for v in vertices if sum(v) % 2 == phase),
                         key=lambda v: (sum(v), *(-x for x in v)))
        row = [0]
        for v in ordered:
            row.append(row[-1] | 1 << index[v])
        prefixes.append(row)
    h = 9 * n // 2
    for phase in (0, 1):
        for k in range(h + 1):
            output = neighborhood(prefixes[phase][k])
            assert output == prefixes[1 - phase][profile(h, phase, k)]

    # Direct symbolic recurrence, rather than insertion at a sampled cut.
    assert profile(h, 0, h - 5) == h - 2
    assert profile(h, 1, h - 7) == h - 3
    for k in range(10, h - 2):
        assert profile(h, 0, k - 5) == k - 1
        assert profile(h, 1, k - 6) == k - 1
    assert [profile(h, p, k - 5) for p, k in ((0, 9), (1, 8), (0, 7))] == [8, 7, 5]
    assert profile(h, 1, 0) == 0

    reflection = [index[(v[0], v[1], n - 1 - v[2])] for v in vertices]

    def reflect(mask):
        out = 0
        while mask:
            bit = mask & -mask
            mask -= bit
            out |= 1 << reflection[bit.bit_length() - 1]
        return out

    current = (1 << len(vertices)) - 1
    durations = []
    for cohort in (0, 1):
        count, phase, elapsed = h, 0, 0
        while count:
            active = prefixes[phase][count]
            shots = active ^ prefixes[phase][max(0, count - 5)]
            if cohort:
                active, shots = reflect(active), reflect(shots)
            assert active & current == active
            assert shots.bit_count() <= 5
            assert shots & current == shots
            current = neighborhood(current & ~shots)
            count = profile(h, phase, max(0, count - 5))
            phase ^= 1
            elapsed += 1
            expected = prefixes[phase][count]
            if cohort:
                assert current == reflect(expected)
            else:
                assert current == expected | prefixes[1 - phase][-1]
        assert elapsed == 2 * h - 18 and elapsed % 2 == 0
        durations.append(elapsed)
    assert not current
    assert sum(durations) == 18 * n - 36
    return {"n": n, "solo_durations": durations, "full_time": sum(durations),
            "all_prefix_neighborhoods_match": True, "all_physical_states_match": True}


def main():
    start = time.process_time()
    assert all(CHARGE[p] + CHARGE[q] <= 3
               for p in range(6) for q in range(6) if p + q <= 5)
    assert all(3 * (2 * p - 9) <= CHARGE[p] for p in range(6))
    assert all(3 * (2 * p - 10) <= CHARGE[p] for p in range(6))
    result = {
        "status": "PASS: independent scalar and physical-upper audit",
        "theorem_scope": "T5(3x3xn)=18n-36 for every even n>=4; ordinary proof, not new Lean",
        "scalar_all_output_checks": {h: scalar(h) for h in (18, 27, 36, 45, 46, 54, 145)},
        "physical": [physical(n) for n in (4, 6, 8, 10, 12, 30)],
        "unbounded_argument": "Three explicit source intervals prove potential insertion; direct recurrence proves upper without insertion",
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    result["cpu_seconds"] = round(time.process_time() - start, 6)
    path = Path("research/even-three-by-three-cylinder-independent-review.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

"""Exact minimum ammunition for the unbounded odd-rectangle corner model.

This does not by itself prove the physical midpoint criterion.
"""
from math import isqrt

def R(k):
    a=isqrt(k)
    return a+(a*a<k)

def rho(k):
    a=(isqrt(4*k+1)-1)//2
    return a+(a*(a+1)<k)

def lower(b,p,k):
    if not k:return 0
    return k+min(R(k),b) if p==0 else k+min(rho(k)+1,b+1)

def inverse(b,p,z):
    return z-min(rho(z),b) if p==0 else z-min(R(z),b+1)

def growth_cost(b,m,p,k):
    assert b>=1 and m>=b+1 and p in(0,1) and k>=0
    cost=0;D=2*m-2*b-1
    threshold=max(b*b+m,D)+1
    if k>=threshold:
        pairs=(k-threshold)//D+1
        k-=pairs*D;cost+=2*m*pairs
    while k:
        z=lower(b,p,k)
        q=min(m,z);cost+=q;k=z-q;p=1-p
    return cost

def clear_cost(b,m,p,k):
    return k if k<=m else m+growth_cost(b,m,p,k-m)


def independent_check(b,m,K=30):
    """Finite Dijkstra includes every path cheap enough to improve the formula."""
    import heapq
    candidate={(p,k):growth_cost(b,m,p,k)for p in(0,1)for k in range(K+1)}
    cap=max(candidate.values())
    inf=10**12;dist=[[inf]*(cap+1)for _ in(0,1)]
    Q=[]
    for p in(0,1):dist[p][0]=0;heapq.heappush(Q,(0,p,0))
    while Q:
        d,p,k=heapq.heappop(Q)
        if d!=dist[p][k]:continue
        for q in range(m+1):
            if d+q>cap:continue
            kk=inverse(b,1-p,k+q)
            assert kk<=cap
            if d+q<dist[1-p][kk]:
                dist[1-p][kk]=d+q;heapq.heappush(Q,(d+q,1-p,kk))
    for p in(0,1):
        for k in range(K+1):
            assert min(dist[p][k:])==candidate[p,k],(b,m,p,k,min(dist[p][k:]),candidate[p,k])
            if k:assert candidate[p,k]>=candidate[p,k-1]+1
            for q in range(m+1):
                after=lower(b,p,max(0,k-q))
                assert clear_cost(b,m,p,k)<=q+clear_cost(b,m,1-p,after),(b,m,p,k,q)
    return {'b':b,'m':m,'targets':2*(K+1),'cost_cap':cap,'pass':True}

if __name__=='__main__':
    import json
    from pathlib import Path
    from time import process_time
    t=process_time();rows=[]
    for b,m in[(1,2),(2,3),(3,4),(4,5),(4,8),(5,7),(5,12)]:rows.append(independent_check(b,m))
    out={'scope':'Bottom inverse minimum ammunition; not physical full-game classification','checks':rows,'CPU_seconds':process_time()-t}
    Path('research/maturation-odd-ammunition.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

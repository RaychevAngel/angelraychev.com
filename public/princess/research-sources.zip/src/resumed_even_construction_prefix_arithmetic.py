"""Fixed-size counts for anchored prefixes on even-width rectangles.

The functions in this file use a fixed number of arithmetic operations,
floors, roots, and finite cases. The entrance/exit clocks built from them
are still recurrences, not fixed-size formulas for capture time.
"""
from math import isqrt
from pathlib import Path
import random,json


def triangular_color(D,p):
    m=(D-p)//2
    return 0 if m<0 else (m+1)*(m+p+1)


def diagonal_count(w,n,p,D):
    return (triangular_color(D,p)-triangular_color(D-w,(p-w)%2)
            -triangular_color(D-n,(p-n)%2)
            +triangular_color(D-w-n,(p-w-n)%2))


def ceil_div(a,b):return -((-a)//b)


def pronic_root_floor(q,p):
    # Largest u with u(u+p)<=q, p in {0,1}.
    return (isqrt(p*p+4*q)-p)//2


def pronic_root_ceil(q,p):
    u=pronic_root_floor(q,p)
    return u+(u*(u+p)<q)


def prefix_parameters(w,n,p,q):
    assert w%2==0 and n>=w and 0<=q<=w*n//2
    if q==0:return p-2,w
    r=w//2;s=n//2;epsilon=n%2;v=s+epsilon*(1-p)
    first=r*(r+p);middle=r*(2*v+p-r)
    if q<=first:m=pronic_root_ceil(q,p)-1
    elif q<=middle:m=ceil_div(q-r*(p+2-r),2*r)
    else:
        opposite=p^epsilon
        m=(w+n-2-p-opposite)//2-pronic_root_floor(w*n//2-q,opposite)
    d=2*m+p;used=q-diagonal_count(w,n,p,d-2)
    upper=min(w-1,d);c=upper-used+1
    assert used>=1
    return d,c


def neighborhood_count(w,n,p,q):
    if q==0:return 0
    d,c=prefix_parameters(w,n,p,q)
    lower=max(0,d+2-n,c);upper=min(w-1,d+1)
    return diagonal_count(w,n,1-p,d-1)+max(0,upper-lower+1)


def erosion_count(w,n,p,q):
    """Number of opposite-color rooms all of whose neighbors lie in P_p(q)."""
    if q==0:return 0
    h=w*n//2
    if q==h:return h
    d,c=prefix_parameters(w,n,p,q)
    lower=max(0,d-n,c);upper=min(w-1,d-1)
    answer=diagonal_count(w,n,1-p,d-3)+max(0,upper-lower+1)
    if d>=n and c==d-n+1:answer+=1
    return answer


def entrance(w,n,k,p=0):
    a=w*n//2;clock=[a]
    while a>k:
        a=neighborhood_count(w,n,p,max(a-k,0));p=1-p
        clock.append(a)
    return clock


def exit_thresholds(w,n,k,steps):
    h=w*n//2;answer=[(0,0)]
    for _ in range(steps):
        b=answer[-1]
        answer.append(tuple(min(h,k+erosion_count(w,n,1-p,b[1-p]))for p in(0,1)))
    return answer


def run():
    from resumed_even_construction_prefix import PrefixGame
    checked=0
    boards=[(2,2),(2,7),(4,5),(6,6),(6,7),(8,10),(12,12),(14,17),(24,24)]
    for w,n in boards:
        g=PrefixGame(w,n);h=w*n//2
        for p in(0,1):
            for q,mask in enumerate(g.orders[p][0]):
                d,c=prefix_parameters(w,n,p,q)
                literal={(x,y)for x,y in g.colors[p]if x+y<d or(x+y==d and x>=c)}
                expected={v for i,v in enumerate(g.colors[p])if mask>>i&1}
                assert literal==expected,(w,n,p,q,d,c)
                assert neighborhood_count(w,n,p,q)==g.hood(p,mask).bit_count(),(w,n,p,q,'N')
                E=sum(1<<i for i,N in enumerate(g.adj[1-p])if not N&~mask)
                assert E==g.orders[1-p][0][erosion_count(w,n,p,q)],(w,n,p,q,'E')
                checked+=1
    return {'prefix_states_checked':checked,'boards':boards,
            'scope':'Independent literal-grid validation of fixed-size prefix parameter, neighborhood, erosion formulas. No full capture-time closed formula claim.'}


if __name__=='__main__':
    out=run();Path('research/resumed-even-construction-prefix-arithmetic-check.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

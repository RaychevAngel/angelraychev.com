"""Exact solo clock of the accepted necessary corner relaxation.

All formula-admitted target features are retained. Long surplus tails are
represented by integer bitsets, avoiding a quadratic edge dictionary.
This is an evaluator, not a fixed-size formula or a physical upper claim.
"""
from pathlib import Path
import json,time
from resumed_even_construction_formula_profile import allowed,F
from resumed_even_construction_prefix import PrefixGame


def model_data(w,n,k,critical=False):
    h=w*n//2;r=w//2
    states=[(a,c)for a in range(h+1)for c in range(3)if c<=a<=h-2+c]
    index={s:i for i,s in enumerate(states)}
    tails=[0]*(h+2)
    for a in range(h,-1,-1):
        tails[a]=tails[a+1]|sum(1<<index[a,c]for c in range(3)if(a,c)in index)
    targets={}
    for q,i in states:
        if q==0:targets[q,i]=1<<index[0,0];continue
        stop=q+r+int(critical)
        mask=tails[min(stop,h+1)]
        for t in range(q,min(stop,h+1)):
            for j in range(3):
                if(t,j)not in index or not allowed(h,r,q,i,t,j):continue
                if critical and t-q==r:
                    exception=((w==2*r or n==2*r)and(i,j)==(1,1))or((w==2*r+1 or n==2*r+1)and(i,j)==(2,0))
                    if not exception and not(q<=F(i,j,r)or h-q-r<=max(F(2-j,d,r-2+i+d)for d in range(3-i))):continue
                mask|=1<<index[t,j]
        targets[q,i]=mask
    options=[]
    for a,c in states:
        mask=0
        for q in range(max(0,a-k),a+1):
            for i in range(max(0,c-a+q),c+1):
                mask|=targets.get((q,i),0)
        options.append(mask)
    return states,index,options


def clock(w,n,k,critical=False,initial=None):
    h=w*n//2
    states,index,options=model_data(w,n,k,critical)
    if initial is None:initial=(h,2)
    seen=frontier=1<<index[initial];sizes=[];widths=[]
    while True:
        smallest=(seen&-seen).bit_length()-1
        sizes.append(states[smallest][0]);widths.append(frontier.bit_count())
        if sizes[-1]<=k:break
        successors=0
        while frontier:
            bit=frontier&-frontier;frontier^=bit
            successors|=options[bit.bit_length()-1]
        frontier=successors&~seen
        assert frontier,'No model capture'
        seen|=frontier
    return len(sizes),sizes,{'feature_states':len(states),'first_arrival_layer_counts':widths,
                             'critical_geometric_filter':critical,
                             'all_admitted_targets_retained':True}


def run(w,n,k):
    start=time.monotonic();tau,sizes,info=clock(w,n,k)
    game=PrefixGame(w,n)
    from resumed_even_construction_splice import prefix_path
    prefix=[]
    for p in (0,1):
        shots,beliefs=prefix_path(game,k,p,game.full,0)
        prefix.append(len(shots))
    return {'shape':[w,n],'budget':k,'corrected_solo_clock':tau,'model_sizes':sizes,
            'fixed_left_prefix_phase_clocks':prefix,'best_anchor_prefix_clock':min(prefix),
            'best_anchor_minus_model':min(prefix)-tau,'model_receipt':info,
            'seconds':time.monotonic()-start,
            'scope':'Exact necessary-model solo evaluator compared with deterministic prefix upper clocks. No physical lower attainment assumption.'}


if __name__=='__main__':
    rows=[run(w,n,k)for w,n,k in [(12,12,7),(16,16,9),(24,24,13),(32,32,17),(24,24,18)]]
    Path('research/resumed-even-construction-corrected-prefix-gap.json').write_text(json.dumps(rows,indent=2)+'\n')
    for row in rows:print({k:v for k,v in row.items()if k not in('model_sizes','model_receipt')})

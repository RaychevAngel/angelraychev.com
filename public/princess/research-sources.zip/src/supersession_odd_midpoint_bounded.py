"""Exact odd-rectangle midpoint through a bounded exceptional frontier.

Ordinary proof: research/supersession-odd-midpoint.md Sections8 and10.
No scalar endpoint-only midpoint assumption. No arbitrary-subset enumeration.
"""
from supersession_solo_bands import OddRectangle


def pareto(points):
    out=[];best=-1
    for x,y in sorted(set(points),reverse=True):
        if y>best:out.append((x,y));best=y
    return out


def retained_step(G,m,front,a,b):
    aa,bb=G.inverse(0,b+m),G.inverse(1,a+m)
    assert aa<G.E and bb<G.M
    B=min(aa,bb)
    out={(aa,0),(0,bb)}
    for x,y in front:
        for p in range(m+1):
            xx,yy=G.inverse(0,y+m-p),G.inverse(1,x+p)
            if xx and yy and xx+yy>B:out.add((xx,yy))
    return pareto(out),aa,bb


def union_max(G,front):
    return max(min(G.E,x+u)+min(G.M,y+v)
               for x,y in front for u,v in front)


def solve(w,n,m,accelerate=True):
    G=OddRectangle(w,n)
    if m< G.b+1:return {'time':None,'feasible':False}
    if m>=G.E:return {'time':1 if m>=G.E+G.M else 2,'feasible':True}
    H=(G.b+1)**2;gap=2*m+2;K=H-1+2*m*(gap//w+1)
    J=2*K+gap+2*m+H+2;W=gap+K+1;D=2*m-w
    day=a=b=updates=0;front=[(0,0)];maxfront=1
    entry=None;jumped=False;jumps=[]
    while True:
        aa,bb=G.inverse(0,b+m),G.inverse(1,a+m)
        if aa>=G.E or bb>=G.M:break
        safe=min(a,b)>=J and max(a,b)<=G.M-J
        if safe and entry is None:entry=day
        if safe and accelerate and not jumped and day-entry>=W:
            # Last safe layer of the current parity. Two-day increments D.
            pairs=(G.M-J-max(a,b))//D
            if pairs>0:
                increment=pairs*D
                shifted=[]
                for x,y in front:
                    if not x:shifted.append((0,y+increment))
                    elif not y:shifted.append((x+increment,0))
                    elif x>y:
                        assert y<=K and x>K
                        shifted.append((x+increment,y))
                    else:
                        assert x<=K and y>K
                        shifted.append((x,y+increment))
                jumps.append({'from_day':day,'pairs':pairs,'capacity_increment':increment})
                day+=2*pairs;a+=increment;b+=increment;front=shifted
                jumped=True
                continue
            jumped=True
        front,a,b=retained_step(G,m,front,a,b)
        day+=1;updates+=1;maxfront=max(maxfront,len(front))
        assert all(not x or not y or min(x,y)<=K for x,y in front)
    tau=day+1
    central=G.E+G.M-union_max(G,front)
    answer=2*tau-int(central<=m)
    return {'feasible':True,'time':answer,'tau':tau,'central_minimum':central,
            'solo_residual_sum':G.E+G.M-a-b,'precentral_capacities':[a,b],
            'frontier':front,'updates':updates,'maximum_frontier':maxfront,
            'H':H,'G':gap,'K':K,'J':J,'W':W,'jumps':jumps,
            'bound_updates':4*((J+D-1)//D)+W+8}


if __name__=='__main__':
    import argparse,json
    P=argparse.ArgumentParser();P.add_argument('width',type=int);P.add_argument('length',type=int);P.add_argument('budget',type=int)
    a=P.parse_args();print(json.dumps(solve(a.width,a.length,a.budget),indent=2))

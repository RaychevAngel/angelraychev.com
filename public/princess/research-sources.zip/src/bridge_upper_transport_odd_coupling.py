"""Audit of the odd-width buffered coupling under a proved budget condition."""
from pathlib import Path
import hashlib
import json
import time

from bridge_corner_frontier import step, R, rho


def physical_step(b, h, k, values):
    answer = []
    for p in (0, 1):
        target = values[1 - p]
        if target == h:
            answer.append(h)
            continue
        cost = (min(rho(target), b, R(h - target)) if p == 0
                else min(R(target), b + 1, 1 + rho(h - target)))
        answer.append(min(h, k + target - cost))
    return tuple(answer)


def sufficient(b, k):
    return k > b + 1 and k // 2 - b - 1 >= -(-b * b // (2 * (k - b - 1)))


def verify(b, n, k, seed, buffer):
    w = 2 * b + 1
    h = w * n // 2
    assert n % 2 == 0 and n >= w and sufficient(b, k) and k < h
    B = (0, -1, -1) if seed == 0 else (seed,) * 3
    X = (min(h, seed + buffer),) * 2
    days = 0
    middle_steps = 0
    A, U = b * (b + 1) + 1, h - b * b - 1
    delta = k - b - 1
    while True:
        a = max(0, B[2])
        assert max(X) >= a, (b, n, k, seed, buffer, days, B, X)
        if B[2] == h:
            break
        next_B = step(w, n, k, B, critical=True)
        assert next_B[2] >= min(h, a + delta)
        if A <= a <= U:
            assert next_B[0] == min(h - 2, a + delta)
            assert next_B[2] <= min(h, a + delta + 1)
        if B[0] >= A and B[2] <= U:
            expected = (min(h - 2, a + delta), min(h - 1, a + delta),
                        min(h, max(a, B[0] + 1) + delta))
            assert next_B == expected, (b, n, k, B, next_B, expected)
            middle_steps += 1
        B = next_B
        X = physical_step(b, h, k, X)
        days += 1
    return days, middle_steps


def audit():
    started = time.process_time()
    cases = deadlines = middle_steps = 0
    least = []
    for b in range(2, 101):
        clean = (8 * b + 2) // 3 + 2
        assert sufficient(b, clean)
        first = next(k for k in range(2 * b + 1, clean + 1) if sufficient(b, k))
        least.append([b, first, clean])
        for n in (2 * b + 2, 4 * b + 2, 8 * b + 4):
            h = (2 * b + 1) * n // 2
            for k in sorted({first, first + 1, clean}):
                if k >= h:
                    continue
                m = k // 2
                for seed, buffer in ((0, m), (m, k - m)):
                    count, middle = verify(b, n, k, seed, buffer)
                    cases += 1
                    deadlines += count
                    middle_steps += middle
    return dict(scope=__doc__, condition='floor(k/2)-b-1 >= ceil(b^2/(2*(k-b-1)))',
                clean_corollary='k >= ceil(8*b/3)+2', comparison='maximum of the two physical phases', cases=cases,
                capture_and_halfbudget_deadlines=deadlines,
                exact_middle_formula_checks=middle_steps,
                minimum_budgets=least, CPU_seconds=time.process_time() - started,
                source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in (Path(__file__), Path('src/bridge_corner_frontier.py'))})


if __name__ == '__main__':
    result = audit()
    Path('research/bridge-upper-transport-odd-coupling.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'minimum_budgets'}))

#!/usr/bin/env python3
"""Exact two-counter reduction for the moving princess on a two-row grid.

The accompanying proof is in research/ladder-investigation.md. This executable
checks the reduction against independently solved full belief-state cases.
"""
from collections import deque
import json
from pathlib import Path
import time


def step(n, b, p):
    return 0 if p >= b else min(n, b - p + 1)


def closed_formula(n, m):
    if m >= 2*n:
        return 1
    if n == 1:
        return 2
    if m == 1:
        return None
    N, M = n-1, m-1
    return (2*N + M - 1)//M + int(M % 2 == 0 and N % M == M//2)


def solve(n, m):
    initial = (n, n)
    queue = deque([initial])
    parent = {initial: None}
    while queue:
        b, c = queue.popleft()
        if b == c == 0:
            schedule, cur = [], (b, c)
            while parent[cur] is not None:
                prior, allocation = parent[cur]
                schedule.append(allocation)
                cur = prior
            schedule.reverse()
            result = {"n": n, "m": m, "status": "finite", "minimum_turns": len(schedule),
                      "allocations": schedule, "states_discovered": len(parent)}
            result["verified_schedule"] = verify(n, m, schedule)
            return result
        for p in range(m + 1):
            q = m - p
            after = step(n, b, p), step(n, c, q)
            if after not in parent:
                parent[after] = ((b, c), (p, q))
                queue.append(after)
    return {"n": n, "m": m, "status": "infeasible", "minimum_turns": None,
            "states_discovered": len(parent)}


def verify(n, m, allocations):
    """Build suffix-interval shots and check actual grid positions with sets."""
    belief = {(r, j) for r in range(2) for j in range(n)}
    # Cohort k has current checkerboard parity k + day modulo two.
    sizes = [n, n]
    trace = [{"belief": sorted(belief), "sizes": sizes[:]}]
    for day, allocations_today in enumerate(allocations):
        shots = set()
        for cohort, allowance in enumerate(allocations_today):
            b = sizes[cohort]
            for j in range(n-b, min(n, n-b+allowance)):
                r = (cohort + day - j) % 2
                shots.add((r, j))
        assert len(shots) <= m
        survivors = belief - shots
        sizes = [step(n, b, p) for b, p in zip(sizes, allocations_today)]
        if not survivors:
            assert day == len(allocations) - 1
            assert sizes == [0, 0]
            trace.append({"probes": sorted(shots), "belief": [], "sizes": sizes[:]})
            return trace
        belief = {(r2, j2) for r, j in survivors
                  for r2, j2 in ((1-r,j), (r,j-1), (r,j+1)) if 0 <= j2 < n}
        expected = {(r, j) for cohort, b in enumerate(sizes)
                    for j in range(n-b,n) for r in [(cohort+day+1-j)%2]}
        assert belief == expected
        trace.append({"probes": sorted(shots), "belief": sorted(belief), "sizes": sizes[:]})
    raise AssertionError("Unfinished schedule")


def main():
    started = time.monotonic()
    results = [solve(n, m) for n in range(1, 13) for m in range(1, 2*n+1)]
    for result in results:
        result["closed_formula"] = closed_formula(result["n"], result["m"])
        assert result["closed_formula"] == result["minimum_turns"]
    by_pair = {(r["n"], r["m"]): r for r in results}
    root = Path(__file__).resolve().parent.parent
    grids = json.loads((root / "research/grid-small-cases.json").read_text())
    compared = 0
    for r in grids["results"]:
        if len(r["shape"]) == 2 and r["shape"][0] == 2:
            reduced = by_pair[(r["shape"][1], r["m"])]
            assert reduced["status"] == r["status"]
            assert reduced["minimum_turns"] == r["minimum_turns"]
            compared += 1
    data = {"model": "Two suffix lengths, justified by lazy-column projection and neighborhood cardinality domination.",
            "max_n": 12, "full_belief_cases_agreed": compared,
            "closed_formula_cases_agreed": len(results),
            "seconds": round(time.monotonic() - started,6), "results": results}
    (root / "research/ladder-counter-cases.json").write_text(json.dumps(data,indent=2)+"\n")
    for n in range(2, 13):
        print(n, [by_pair[n,m]["minimum_turns"] for m in range(2, min(2*n,10)+1)])
    print("Compared", compared, "Seconds", data["seconds"])


if __name__ == "__main__":
    main()

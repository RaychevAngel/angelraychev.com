"""Exact capture-time algorithm for every Cartesian box with a length-two side.

Uses the established simplicial closed-neighborhood nesting theorem for the
remaining box. Mathematical proof and attribution are in
research/boxes-with-a-two-side.md.
"""
from itertools import product
from pathlib import Path
import json
import time
from nested_grid_time import grid, neighborhood, solve
from exact_grid_cases import make_grid, solve as unrestricted_solve


def prism_data(base_shape):
    base_shape = tuple(sorted(base_shape, reverse=True))
    base, base_adj = grid(base_shape)
    # Reverse coordinates puts shortest side first, matching the cited order.
    base_order = sorted(range(len(base)), key=lambda i:
        (sum(base[i]), tuple(-x for x in base[i][::-1])))
    base_prefix = [0]
    for i in base_order:
        base_prefix.append(base_prefix[-1] | (1 << i))
    profile = [(s | neighborhood(s, base_adj)).bit_count() for s in base_prefix]
    assert all(s | neighborhood(s, base_adj) == base_prefix[profile[k]]
               for k, s in enumerate(base_prefix))
    coords, adj = grid((2,)+base_shape)
    index = {c:i for i,c in enumerate(coords)}
    orders = [[index[((parity-sum(base[i]))%2,)+base[i]] for i in base_order]
              for parity in range(2)]
    prefixes = []
    for order in orders:
        row = [0]
        for i in order:
            row.append(row[-1] | (1<<i))
        prefixes.append(row)
    for parity in range(2):
        assert all(neighborhood(s,adj) == prefixes[1-parity][profile[k]]
                   for k,s in enumerate(prefixes[parity]))
    return (coords,adj,orders,prefixes,[profile,profile]), profile


def main():
    root = Path(__file__).resolve().parents[1]
    start = time.monotonic()
    comparisons = []
    for name in ['grid-small-cases.json','extension-grid-probe.json']:
        original = json.loads((root/'research'/name).read_text())
        for r in original['results']:
            shape=list(r['shape'])
            if 2 not in shape:
                continue
            shape.remove(2)
            data, _ = prism_data(shape)
            found = solve(data,r['m'])
            assert found['status']==r['status']
            assert found['minimum_turns']==r['minimum_turns']
            comparisons.append({'shape':r['shape'],'m':r['m'],'minimum_turns':found['minimum_turns'],'source':name})
    examples = []
    for shape in [(3,3),(4,3),(5,3),(4,4),(10,10),(3,3,3),(5,4,3),(2,2,2,2,2)]:
        data, profile = prism_data(shape)
        h = 1+max(c-k for k,c in enumerate(profile))
        cases=[]
        for m in sorted(set([h-1,h,h+1,len(data[0])//2])):
            result = solve(data,m)
            if m<h:
                assert result['status']=='infeasible'
            else:
                assert result['status']=='finite'
            cases.append({'m':m,**result})
        examples.append({'shape':(2,)+tuple(sorted(shape,reverse=True)),
                         'feasibility_threshold':h,'profile':profile,'results':cases})
    unrestricted = []
    shape=(2,3,3)
    coords,adj,neighborhoods=make_grid(shape)
    data,_=prism_data(shape[1:])
    for m in [3,4,5]:
        result=unrestricted_solve(coords,adj,neighborhoods,m,time.monotonic()+5)
        reduced=solve(data,m)
        if result['status']!='incomplete':
            assert result['status']==reduced['status']
            assert result['minimum_turns']==reduced['minimum_turns']
        unrestricted.append({'shape':shape,'m':m,'compressed':reduced['minimum_turns'],'full_belief':result})
    out={'scope':'Exact algorithm conditional on cited classical grid isoperimetric theorem; no claimed closed-form time or Lean verification. Every prefix witness replayed on actual graph.',
         'seconds':time.monotonic()-start,'prior_bfs_comparisons':comparisons,'examples':examples,'fresh_unrestricted_checks':unrestricted}
    (root/'research/prism-box-time-checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'seconds':out['seconds'],'prior_bfs_comparisons':len(comparisons),
          'examples':[{'shape':e['shape'],'threshold':e['feasibility_threshold'],
          'times':[(r['m'],r['minimum_turns']) for r in e['results']]} for e in examples],
          'fresh_unrestricted_checks':[{'m':r['m'],'status':r['full_belief']['status'],'time':r['compressed']} for r in unrestricted]},indent=2))


if __name__=='__main__':
    main()

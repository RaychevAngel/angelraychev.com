"""Independent physical replay of minimum-budget odd-width even-length sweeps."""
from pathlib import Path
from math import isqrt
import json,time
from nested_grid_time import ordered_profiles,neighborhood

def root(k):return isqrt(k)+(isqrt(k)**2<k)
def rho(k):
 a=(isqrt(1+4*k)-1)//2
 return a+(a*(a+1)<k)
def clock(b):
 a=c=0;t=0;m=b+1;target=b*(b-1)
 while c!=target:
  a,c=c+m-min(rho(c+m),b),a+m-min(root(a+m),b+1);t+=1
 return t

def check(b,n):
 w=2*b+1;m=b+1;h=w*n//2;report,data=ordered_profiles((n,w));assert report['nested']
 coords,adj,orders,prefixes,g=data;traces=[];candidates=[]
 for first in (0,1):
  k=h;p=first;shots=[];sizes=[]
  while k:
   sizes.append(k);survivor=max(k-m,0);shots.append(prefixes[p][k]^prefixes[p][survivor]);k=g[p][survivor];p^=1
  traces.append(sizes);candidates.append(shots)
 first=min((0,1),key=lambda p:len(candidates[p]));half=candidates[first];shots=half+half[::-1];belief=(1<<(w*n))-1
 for t,shot in enumerate(shots,1):
  assert shot.bit_count()<=m;belief=neighborhood(belief&~shot,adj);assert bool(belief)==(t<len(shots))
 L=clock(b);C=8*b*b-4*b-4*L+4;target=2*w*n-C
 assert len(shots)==target,(b,n,len(shots),target)
 return {'width':w,'length':n,'budget':m,'half_days':[len(x) for x in candidates],'shorter_initial_color':first,'L':L,'C':C,'physical_days':len(shots),'claimed_upper':target,'actual_rooms_replayed':True,'first_capture_on_final_day':True,'traces':traces}

def main():
 start=time.process_time();rows=[check(b,n) for b in range(1,13) for n in (2*b+2,2*b+4,4*b+4)]
 out={'scope':'Finite physical evidence for uniform minimum-budget upper T<=2wn-Cw on odd-width/even-length rectangles. No unrestricted lower or new exact classification claimed.','results':rows,'cpu_seconds':time.process_time()-start}
 Path('research/resumed-odd-even-minimum-upper.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='results'})
if __name__=='__main__':main()

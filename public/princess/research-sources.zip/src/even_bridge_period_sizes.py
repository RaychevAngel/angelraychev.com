"""Compare proof bounds without constructing the enormous old periods."""

import json
import math
from pathlib import Path


def log10_lcm_to(n):
    prime = bytearray(b"\x01") * (n + 1)
    prime[:2] = b"\x00\x00"
    for p in range(2, math.isqrt(n) + 1):
        if prime[p]:
            prime[p * p : n + 1 : p] = b"\x00" * (
                (n - p * p) // p + 1
            )
    result = 0.0
    for p in range(2, n + 1):
        if prime[p]:
            power = p
            while power * p <= n:
                power *= p
            result += math.log10(power)
    return result


def main():
    rows = []
    for order in (2, 3, 4, 5, 6, 8, 9):
        if order % 2:
            states = 8 * 2 ** (order - 1)
        else:
            states = 8 * 5 ** (order // 2 - 1)
        logarithm = math.log10(2) + log10_lcm_to(states)
        budget = order // 2 + 1
        drift = 2 * budget - order
        divisor = math.gcd(order, drift)
        rows.append(
            {
                "transverse_order": order,
                "critical_budget": budget,
                "old_state_upper_bound": states,
                "old_chosen_period_log10": logarithm,
                "old_chosen_period_digits": math.floor(logarithm) + 1,
                "new_state_upper_bound_one_orientation": 2**order,
                "new_valid_period": 2 * drift // divisor,
                "new_time_increment": 4 * order // divisor,
            }
        )
    receipt = {
        "scope": "Comparison of sufficient proof bounds, not minimum periods",
        "method": "Sum logarithms of maximal prime powers; no giant lcm integer",
        "rows": rows,
    }
    output = Path(__file__).resolve().parents[1] / "research/even-bridge-period-sizes.json"
    output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Bounded exact checks of Cartesian-product grids in the princess model.

This September 2026 exploratory computation is separate from the author's
2019--2020 path work. A reported 'infeasible' exhausts the reachable belief
graph; reaching the wall-clock bound instead reports 'incomplete'.
"""

from __future__ import annotations

from collections import deque
from itertools import combinations, product
import argparse
import json
from pathlib import Path
import time


def make_grid(shape):
    coords = list(product(*(range(k) for k in shape)))
    index = {c: i for i, c in enumerate(coords)}
    adjacent = []
    for c in coords:
        targets = set()
        for axis, extent in enumerate(shape):
            for shift in (-1, 1):
                d = list(c)
                d[axis] += shift
                if 0 <= d[axis] < extent:
                    targets.add(index[tuple(d)])
        adjacent.append(targets)
    masks = [sum(1 << v for v in a) for a in adjacent]
    neighborhoods = [0] * (1 << len(coords))
    for mask in range(1, len(neighborhoods)):
        bit = mask & -mask
        neighborhoods[mask] = neighborhoods[mask ^ bit] | masks[bit.bit_length() - 1]
    return coords, adjacent, neighborhoods


def solve(coords, adjacent, neighborhoods, m, deadline):
    n = len(coords)
    full = (1 << n) - 1
    parent = {full: None}
    queue = deque([full])
    examined = 0
    while queue:
        if time.monotonic() >= deadline:
            return {"status": "incomplete", "states_discovered": len(parent), "edges_examined": examined}
        belief = queue.popleft()
        if belief.bit_count() <= m:
            schedule = [belief]
            cur = belief
            while parent[cur] is not None:
                cur, shot = parent[cur]
                schedule.append(shot)
            schedule.reverse()
            inspections = [[i for i in range(n) if s & (1 << i)] for s in schedule]
            result = {
                "status": "finite", "minimum_turns": len(schedule),
                "inspections": inspections,
                "states_discovered": len(parent), "edges_examined": examined,
            }
            result["witness_beliefs"] = verify_witness(adjacent, m, inspections)
            return result
        bits = [1 << i for i in range(n) if belief & (1 << i)]
        for selection in combinations(bits, m):
            shot = sum(selection)
            after = neighborhoods[belief ^ shot]
            examined += 1
            if after not in parent:
                parent[after] = (belief, shot)
                queue.append(after)
    return {"status": "infeasible", "minimum_turns": None,
            "states_discovered": len(parent), "edges_examined": examined}


def verify_witness(adjacent, m, inspections):
    """Independent sets-based transition, rejecting death by an absent move."""
    belief = set(range(len(adjacent)))
    beliefs = [sorted(belief)]
    for day, shot in enumerate(inspections):
        assert len(shot) == len(set(shot)) <= m
        assert set(shot) <= set(range(len(adjacent)))
        survivors = belief - set(shot)
        if not survivors:
            assert day == len(inspections) - 1
            return beliefs + [[]]
        belief = {u for v in survivors for u in adjacent[v]}
        assert belief
        beliefs.append(sorted(belief))
    raise AssertionError("A possible princess trajectory survived the schedule")


def retrograde(shape, m, deadline):
    """Distinct all-states horizon iteration with all global sets of probes.

    Neighbors are constructed directly by Manhattan distance between tuples,
    not with the graph builder or precomputed bit-mask neighborhoods.
    """
    coords = list(product(*(range(k) for k in shape)))
    n = len(coords)
    states = [frozenset(i for i in range(n) if mask & (1 << i)) for mask in range(1 << n)]
    index = {state: i for i, state in enumerate(states)}
    adj = {i: {j for j in range(n) if sum(abs(a-b) for a, b in zip(coords[i], coords[j])) == 1} for i in range(n)}
    shots = [frozenset(s) for s in combinations(range(n), min(m, n))]
    transitions = [[index[frozenset(u for v in state - shot for u in adj[v])] for shot in shots] for state in states]
    previous = [not state for state in states]
    day = 0
    while True:
        if time.monotonic() >= deadline:
            return {"status": "incomplete"}
        current = [len(state) <= m or any(previous[target] for target in targets)
                   for state, targets in zip(states, transitions)]
        day += 1
        if current[-1]:
            return {"status": "finite", "minimum_turns": day}
        if current == previous:
            return {"status": "infeasible", "minimum_turns": None}
        previous = current


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seconds", type=float, default=55)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    start = time.monotonic()
    deadline = start + args.seconds
    results = []
    shapes = [(2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (3, 3), (3, 4), (2, 2, 2)]
    for shape in shapes:
        coords, adjacent, neighborhoods = make_grid(shape)
        for m in range(1, min(5, len(coords)) + 1):
            if time.monotonic() >= deadline:
                break
            begin = time.monotonic()
            result = {"shape": shape, "m": m, "vertices": coords}
            result.update(solve(coords, adjacent, neighborhoods, m, deadline))
            if (len(coords) <= 8 or m == 2) and result["status"] != "incomplete":
                check = retrograde(shape, m, deadline)
                result["independent_retrograde"] = check
                if check["status"] != "incomplete":
                    assert (check["status"], check["minimum_turns"]) == (result["status"], result["minimum_turns"])
            result["seconds"] = round(time.monotonic() - begin, 6)
            results.append(result)
            print(shape, m, result["status"], result.get("minimum_turns"), result["seconds"], flush=True)
    data = {"model": "Cartesian-product grid; arbitrary initial vertex; <=m simultaneous vertex inspections per day; after a miss exactly one edge must be traversed; no staying.",
            "evidence": "Finite exact BFS, with independently verified sets-based witnesses and a second all-states horizon solver for grids of at most eight vertices and every m=2 case. No general classification is claimed.",
            "indexing": "Inspections contain zero-based vertex indices into each result's vertices list; coordinates are zero-based.",
            "seconds": round(time.monotonic() - start, 6), "budget_seconds": args.seconds,
            "planned_shapes": shapes, "planned_m": "1 through min(5, vertex count)", "results": results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2) + "\n")
    print("Total seconds", data["seconds"], flush=True)


if __name__ == "__main__":
    main()

"""Exact transfer through the joint affine middle of an odd rectangle.

Tracks initial cohorts, so phase is the current color of the first cohort.
This is a constructive local theorem, not a serial-optimality assumption.
"""
from pathlib import Path
import json
import time


def drift(b, phase, days):
    return b * days + (days + phase) // 2


def interval(b, budget, low, high, a, other, phase, days):
    total = a + other + days * (2 * b + 1 - budget)
    lower = max(low, total - high, a + drift(b, phase, days) - budget * days)
    upper = min(high, total - low, a + drift(b, phase, days))
    return lower, upper


def witness(b, budget, low, high, a, other, phase, days, target):
    assert budget >= b + 1
    assert low <= a <= high and low <= other <= high
    left, right = interval(b, budget, low, high, a, other, phase, days)
    assert left <= target <= right
    allocations = []
    current = target
    for day in reversed(range(days)):
        lo, hi = interval(b, budget, low, high, a, other, phase, day)
        beta = b + (phase + day) % 2
        previous = max(lo, current - beta)
        assert previous <= min(hi, current - beta + budget)
        shots = previous + beta - current
        assert 0 <= shots <= budget
        allocations.append(shots)
        current = previous
    assert current == a
    allocations.reverse()
    x, y = a, other
    for day, shots in enumerate(allocations):
        beta = b + (phase + day) % 2
        x += beta - shots
        y += 2 * b + 1 - beta - (budget - shots)
        assert low <= x <= high and low <= y <= high
    assert x == target
    return allocations


def middle_distance(b, budget, low, high, start, finish):
    """Shortest positive/zero block between states indexed by current colors.

    Infinity is returned as None. Current-color indexing may swap the initial
    cohorts at an odd-duration endpoint, which is included explicitly.
    """
    a, other = start
    end_even, end_odd = finish
    assert all(low <= x <= high for x in (*start, *finish))
    change = 2 * b + 1 - budget
    difference = end_even + end_odd - a - other
    if change:
        if difference % change or difference // change < 0:
            return None
        days = difference // change
        target = end_even if days % 2 == 0 else end_odd
        lo, hi = interval(b, budget, low, high, a, other, 0, days)
        return days if lo <= target <= hi else None
    if difference:
        return None
    width = 2 * b + 1
    possibilities = []
    for parity in (0, 1):
        target = end_even if parity == 0 else end_odd
        # days=2q+parity. Both endpoint inequalities are lower bounds on q.
        q = max(0, (target - a - parity * b + width - 1) // width,
                (a - target - parity * (b + 1) + width - 1) // width)
        days = 2 * q + parity
        lo, hi = interval(b, budget, low, high, a, other, 0, days)
        assert lo <= target <= hi
        possibilities.append(days)
    return min(possibilities)


def verify():
    start_time = time.process_time()
    checks = witnesses = 0
    for b in range(1, 5):
        for budget in range(b + 1, 2 * b + 4):
            low, high = 3, 10
            for a in range(low, high + 1):
                for other in range(low, high + 1):
                    for phase in (0, 1):
                        states = {(a, other)}
                        for days in range(13):
                            lo, hi = interval(b, budget, low, high, a, other, phase, days)
                            total = a + other + days * (2 * b + 1 - budget)
                            predicted = {(x, total - x) for x in range(lo, hi + 1)}
                            assert states == predicted
                            checks += 1
                            for target in {lo, hi} if states else ():
                                witness(b, budget, low, high, a, other, phase, days, target)
                                witnesses += 1
                            beta = b + (phase + days) % 2
                            states = {(x + beta - r,
                                       y + 2 * b + 1 - beta - (budget - r))
                                      for x, y in states for r in range(budget + 1)
                                      if low <= x + beta - r <= high
                                      and low <= y + 2 * b + 1 - beta - (budget - r) <= high}
    result = {
        "scope": "Independent exhaustive local affine-middle attack; all-parameter proof is in the research note",
        "status": "PASS", "exact_reachable_set_checks": checks,
        "reconstructed_endpoint_witnesses": witnesses,
        "cpu_seconds": time.process_time() - start_time,
    }
    Path("research/uniform-odd-middle-transfer-check.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2))

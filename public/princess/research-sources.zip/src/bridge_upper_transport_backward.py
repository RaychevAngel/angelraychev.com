"""Capped backward physical-target construction for a prescribed solo deadline.

Every retained state has an explicit capture suffix. No lower bound follows
from beam exhaustion, policy exhaustion, or hitting the elapsed-time cap.
"""
import argparse
import json
from pathlib import Path
import time

from bridge_upper_transport import (
    prefix_height, prefix_tail, construct, neighborhood, support, capture_replay,
)
from resumed_even_construction_prefix_arithmetic import entrance


def erosion(w, n, p, b):
    """Canonical heights of E(B), whose physical phase is 1-p."""
    a = []
    for x in range(w):
        empty = (1 - p - x) % 2 - 2
        value = max(empty, b[x] - 1)
        if (x + n - 1) % 2 == 1 - p:
            if b[x] >= n - 2 and all(b[z] >= n - 1 for z in (x - 1, x + 1) if 0 <= z < w):
                value = n - 1
        a.append(value)
    assert all(abs(a[x + 1] - a[x]) == 1 for x in range(w - 1))
    return a


def grow(w, n, p, a, k, policy):
    a = list(a)
    shots = []
    for _ in range(k):
        legal = [x for x in range(w) if a[x] + 2 < n
                 and all(a[z] == a[x] + 1 for z in (x - 1, x + 1) if 0 <= z < w)]
        if not legal:
            break
        if isinstance(policy, int):
            x = min(legal, key=lambda x: (a[x] + policy * x, x))
        elif policy == 'left':
            x = min(legal)
        elif policy == 'right':
            x = max(legal)
        elif policy == 'high':
            x = max(legal, key=lambda x: (a[x], -x))
        elif policy == 'corners':
            x = min(legal, key=lambda x: (min(x, w - 1 - x), a[x], x))
        elif policy == 'center':
            x = min(legal, key=lambda x: (abs(2 * x - w + 1), a[x], x))
        else:
            raise ValueError(policy)
        a[x] += 2
        shots.append((x, a[x]))
    assert all(0 <= y < n and (x + y) % 2 == p for x, y in shots)
    return tuple(a), tuple(shots)


def size(a):
    return sum((x + 2) // 2 for x in a)


def run(w=24, n=24, k=13, target=103, beam=32, seconds=15):
    began = time.monotonic()
    policies = ('left', 'right', 'high', 'corners', 'center', -4, -2, -1, 0, 1, 2, 4)
    clocks = [entrance(w, n, k, p) for p in (0, 1)]
    entries = [[prefix_height(w, n, (p + e) % 2, q) for e, q in enumerate(clocks[p])]
               for p in (0, 1)]
    # Nodes contain only a proved physical suffix, never a model path.
    nodes = []
    current = [[], []]
    for p in (0, 1):
        a = tuple((p - x) % 2 - 2 for x in range(w))
        nodes.append((p, a, (), None))
        current[p].append(len(nodes) - 1)
    layer_rows = []
    found = None
    generated = 0
    literal_erosions = 0
    capped = False
    for s in range(1, target):
        if time.monotonic() - began > seconds:
            capped = True
            break
        end = target - s
        next_states = [[], []]
        layer = {'tail_days': s, 'phases': []}
        for p in (0, 1):
            candidates = {}
            for idx in current[1 - p]:
                _, b, _, _ = nodes[idx]
                E = erosion(w, n, 1 - p, b)
                if literal_erosions < 2 * s:
                    B = support(w, n, 1 - p, b)
                    literal = {(x, y) for x in range(w) for y in range(n)
                               if (x + y) % 2 == p and neighborhood(w, n, {(x, y)}) <= B}
                    assert literal == support(w, n, p, E)
                    literal_erosions += 1
                for policy in policies:
                    a, shots = grow(w, n, p, E, k, policy)
                    candidates.setdefault(a, (shots, idx, policy))
            scored = []
            p0 = (p - end) % 2
            for a, (shots, idx, policy) in candidates.items():
                credit = sum(a[x] < 0 and (p - x) % 2 == 0 for x in range(w))
                best = (-10**9, None, None)
                for e, old in enumerate(entries[p0][:end]):
                    t = end - e
                    F = sum(max(x - y + t, 0) for x, y in zip(old, a)) // 2
                    slack = k * t + credit - F
                    if slack > best[0]:
                        best = (slack, e, F)
                scored.append((best[0], size(a), a, shots, idx, policy, best[1], best[2]))
            generated += len(scored)
            scored.sort(key=lambda row: (-row[0], -row[1], row[2]))
            # Preserve both objective leaders and different cutoff locations.
            retained = scored[:max(1, beam // 2)]
            seen = {row[2] for row in retained}
            for x in range(w):
                for sign in (-1, 1):
                    row = max(scored, key=lambda row: (row[0], sign * row[2][x], row[1]))
                    if row[2] not in seen and len(retained) < beam:
                        retained.append(row)
                        seen.add(row[2])
            for row in scored:
                if len(retained) >= beam:
                    break
                if row[2] not in seen:
                    retained.append(row)
                    seen.add(row[2])
            for slack, count, a, shots, idx, policy, e, F in retained:
                node_id = len(nodes)
                nodes.append((p, a, shots, idx))
                next_states[p].append(node_id)
                if slack >= 0:
                    found = {'tail_days': s, 'end': end, 'entry': e, 'initial_phase': p0,
                             'target_phase': p, 'target_size': count, 'target_heights': a,
                             'slack': slack, 'virtual_flips': F, 'node': node_id, 'policy': policy}
                    break
            best = scored[0]
            layer['phases'].append({'phase': p, 'candidates': len(scored),
                                    'best_slack': best[0], 'best_size': best[1]})
            if found:
                break
        layer_rows.append(layer)
        current = next_states
        if found:
            break
    out = {'shape': [w, n], 'budget': k, 'target_solo': target,
           'beam_per_phase': beam, 'elapsed_cap_seconds': seconds,
           'elapsed_seconds': time.monotonic() - began, 'time_cap_reached': capped,
           'generated_targets': generated, 'literal_erosions_checked': literal_erosions,
           'layers': layer_rows, 'found': found,
           'scope': 'Capped physical backward-target beam; every state has an explicit capture suffix. Failure gives no lower bound.'}
    if found:
        p0, e, end = found['initial_phase'], found['entry'], found['end']
        a = entries[p0][e]
        b = found['target_heights']
        bridge, bridge_receipt = construct(w, n, (p0 + e) % 2, a, b, end - e, k)
        left = prefix_tail(w, n, k, p0, w * n // 2)
        suffix = []
        node = found['node']
        while nodes[node][3] is not None:
            _, _, shot, node = nodes[node]
            suffix.append(set(shot))
        solo = left[:e] + bridge + suffix
        if p0:
            solo = [{(w - 1 - x, y) for x, y in shot} for shot in solo]
        out.update(solo_capture=capture_replay(w, n, k, solo),
                   full_capture=capture_replay(w, n, k, solo + solo[::-1], True),
                   bridge=bridge_receipt, solo_schedule=[sorted(shot) for shot in solo])
    return out


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--w', type=int, default=24)
    parser.add_argument('--n', type=int, default=24)
    parser.add_argument('--k', type=int, default=13)
    parser.add_argument('--target', type=int, default=103)
    parser.add_argument('--beam', type=int, default=32)
    parser.add_argument('--seconds', type=float, default=15)
    args = parser.parse_args()
    result = run(args.w, args.n, args.k, args.target, args.beam, args.seconds)
    path = Path(f'research/bridge-upper-transport-backward-{args.w}x{args.n}-k{args.k}-t{args.target}-b{args.beam}.json')
    path.write_text(json.dumps(result, indent=2) + '\n')
    print({key: value for key, value in result.items() if key not in ('layers', 'solo_schedule')})

"""Search for integer counterexamples to the two-corner profile conjecture.

Solver infeasibility is recorded as numerical search evidence, not a rigorous
isoperimetric certificate. A found set is checked directly with integer sets.
"""
from itertools import product
from pathlib import Path
from time import monotonic
import json, warnings
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix
from nested_grid_time import ordered_profiles


def attack(shape,k,bound,seconds=2):
    vertices = list(product(*(range(n) for n in shape)))
    source = [v for v in vertices if sum(v)%2 == 0]
    target = [v for v in vertices if sum(v)%2 == 1]
    index = {v:i for i,v in enumerate(target)}
    edges=[]
    for i,v in enumerate(source):
        for axis,n in enumerate(shape):
            for delta in (-1,1):
                w=list(v); w[axis]+=delta
                if 0<=w[axis]<n: edges.append((i,index[tuple(w)]))
    size=len(vertices)
    matrix=lil_matrix((len(edges)+2,size),dtype=float)
    lower=np.full(len(edges)+2,-np.inf)
    upper=np.zeros(len(edges)+2)
    matrix[0,:len(source)]=1; lower[0]=upper[0]=k
    matrix[1,len(source):]=1; upper[1]=bound-1
    for row,(i,j) in enumerate(edges,2): matrix[row,i]=1; matrix[row,len(source)+j]=-1
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore',message='Unrecognized options detected')
        result=milp(np.zeros(size),integrality=np.ones(size),bounds=Bounds(0,1),
                    constraints=LinearConstraint(matrix.tocsr(),lower,upper),
                    options={'time_limit':seconds,'threads':1,'mip_rel_gap':0})
    out={'shape':shape,'k':k,'candidate':bound,'solver_status':int(result.status),'message':result.message}
    if result.x is not None:
        selected={source[i] for i in range(len(source)) if result.x[i]>.5}
        hood={target[j] for i,j in edges if source[i] in selected}
        assert len(selected)==k and len(hood)<bound
        out.update(counterexample=True,selected=sorted(selected),neighbors=sorted(hood))
    return out


def main():
    root=Path(__file__).resolve().parents[1]; start=monotonic(); rows=[]
    for shape in [(3,4,5),(4,4,6),(4,5,6),(4,6,6),(3,3,4,4),(3,4,4,4),(4,4,4,4)]:
        report,_=ordered_profiles(shape,weightlex=True)
        candidate=[min(a,b) for a,b in zip(*report['profiles'])]
        h=len(candidate)-1
        peaks=sorted(range(1,h),key=lambda k:(-(candidate[k]-k),abs(k-h/2)))
        for k in dict.fromkeys([peaks[0],h//2,h//3,2*h//3]):
            t=monotonic(); r=attack(shape,k,candidate[k]);r['seconds']=monotonic()-t;rows.append(r)
            print(shape,k,r['solver_status'],'counterexample',r.get('counterexample',False),flush=True)
            receipt={'status':'counterexample' if r.get('counterexample') else 'bounded_search',
                     'scope':__doc__,'seconds':monotonic()-start,'cases':rows}
            (root/'research/even-profile-milp-attack.json').write_text(json.dumps(receipt,indent=2)+'\n')
            if r.get('counterexample') or monotonic()-start>45:return


if __name__=='__main__': main()

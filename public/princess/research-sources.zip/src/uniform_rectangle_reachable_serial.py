"""Attack a reachable-state serial theorem; exact odd-rectangle profiles."""
from collections import deque
from pathlib import Path
import json,time
from odd_serial_first_order_attack import profiles
from uniform_rectangle_partial_serial import all_times,restricted_serial

def reachable(g,m):
    start=(len(g[0])-1,len(g[1])-1);Q=deque([start]);seen={start}
    while Q:
        a,b=Q.popleft()
        for p in range(m+1):
            t=(g[1][max(0,b-m+p)],g[0][max(0,a-p)])
            if t not in seen:seen.add(t);Q.append(t)
    return seen

def main(limit=15):
    start=time.process_time();checked=0;parameters=0;fail=None
    for b in range(1,7):
      for a in range(b,b+4):
        g=profiles(a,b)
        for m in range(b+1,min(len(g[1]),b+13)):
          R=reachable(g,m);dist=all_times(g,m);parameters+=1
          for state in R:
            want=restricted_serial(g,m,*state);got=dist.get(state);checked+=1
            if want!=got:fail={'shape':[2*a+1,2*b+1],'m':m,'state':state,'exact':got,'serial':want};break
          if fail or time.process_time()-start>limit:break
        if fail or time.process_time()-start>limit:break
      if fail or time.process_time()-start>limit:break
    out={'scope':'Serial conjecture only on states reachable from the full odd rectangle.','parameters':parameters,'reachable_states_checked':checked,'failure':fail,'CPU_seconds':time.process_time()-start}
    Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-reachable-serial.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()

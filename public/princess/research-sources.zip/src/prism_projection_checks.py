#!/usr/bin/env python3
"""Small independent checks of the closed-neighborhood parity projection."""
from itertools import product
from pathlib import Path
import json
import time


def vertices(shape):
    return list(product(*(range(n) for n in shape)))


def adjacent(u, v):
    return sum(abs(a - b) for a, b in zip(u, v)) == 1


def check(shape):
    base = vertices(shape)
    prism = vertices(tuple(shape) + (2,))
    neighborhoods = {v: {u for u in prism if adjacent(u, v)} for v in prism}
    count = 0
    for mask in range(1 << len(base)):
        selected = {v for i, v in enumerate(base) if mask >> i & 1}
        closed = selected | {u for u in base if any(adjacent(u, v) for v in selected)}
        for parity in (0, 1):
            lifted = {v + ((parity - sum(v)) % 2,) for v in selected}
            opened = {u for v in lifted for u in neighborhoods[v]}
            expected = {v + ((1 - parity - sum(v)) % 2,) for v in closed}
            assert opened == expected, (shape, mask, parity)
            count += 1
    return {"shape_of_H": shape, "cohort_subsets_checked": count}


def main():
    started = time.monotonic()
    results = [check(shape) for shape in [(1,), (2,), (3,), (2, 2), (2, 3), (3, 3), (2, 2, 2)]]
    receipt = {"claim_tested": "For both parities and every selected base subset, the full lifted open neighborhood equals the opposite-parity lift of the base closed neighborhood.",
               "results": results, "total_cohort_subsets": sum(r["cohort_subsets_checked"] for r in results),
               "seconds": round(time.monotonic() - started, 6), "status": "all_passed"}
    path = Path(__file__).resolve().parents[1] / "research/prism-projection-checks.json"
    path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()

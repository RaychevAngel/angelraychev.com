"""Uniform width-25 lower from the physical day-28 barrier.

All finite substitutions below use the original quadratic inequalities
directly, independently of the nine-frontier inverse-root implementation.
"""
from pathlib import Path
from time import process_time
import hashlib
import json

from bridge_boundary_numeric_24 import F
from bridge_lower_frontier_nine import step

FEATURES=tuple((c,e)for c in range(3)for e in range(3))


def P(v,u,j,s):
    if not 0<=u<=j<=2 or s<v+2*j:
        return -10**9
    z=s-v-2*j
    if u:
        return v+j+u+z*z+3*z
    if v:
        return v+j+z*z+2*z
    if j:
        return j-1+max((z+2)*(z+1)//2,(z+2)*(z-1)+1)
    return max(s*(s-1)//2,s*(s-2))


def choices(c,e):
    for i in range(c+1):
        for u in range(e+1):
            for j in range(u,3):
                for v in range(i,3):
                    if i>=max(0,c+v-2):
                        yield i,u,j,v


def low_step(frontier):
    following={}
    for c,e in FEATURES:
        best=0
        for i,u,j,v in choices(c,e):
            T=frontier[j,v]
            if T<=0:
                continue
            delta=v-i
            for s in range(14):
                q=T-delta-s
                if q>0 and (s==13 or s==12 and (v,j)==(2,0)
                            or T-s<=P(v,u,j,s)):
                    best=max(best,q)
        following[c,e]=13+best
    return following


def high_step(deficits):
    following={}
    for c,e in FEATURES:
        best=10**9
        for i,u,j,v in choices(c,e):
            d=deficits[j,v]
            delta=v-i
            for s in range(14):
                if not (s==13 or s==12 and (v,j)==(2,0)
                        or d<=F(2-j,2-v,s)):
                    continue
                if j==2 and (i,u,v)!=(1,2,1) and any(
                    max(r*(r-1)//2,r*(r-2))<d<=r*(r-1) and s+delta<=r
                    for r in range(2,13)):
                    continue
                best=min(best,d+delta+s-13)
                break
        following[c,e]=best
    return following


def main():
    started=process_time()
    max_low=max(12+P(v,u,j,12)for v in range(3)for j in range(3)for u in range(j+1))
    max_high=max(F(A,B,12)for A in range(3)for B in range(3))
    max_high_v01=max(F(2-j,2-v,12)for j in range(3)for v in range(2))
    max_high_j2=max(F(0,2-v,12)for v in range(3))
    assert (max_low,max_high,max_high_v01,max_high_j2)==(156,144,132,132)
    prefixes=[]
    for seed in (0,6):
        B={feature:seed for feature in FEATURES}
        trace=[list(B.values())]
        for _ in range(70):
            assert max(B.values())<=157
            nxt=low_step(B)
            assert nxt==step(12,325,13,B,strong_band=False)
            B=nxt
            trace.append(list(B.values()))
        assert set(B.values())=={157}
        prefixes.append({'seed':seed,'frontiers':trace})

    tail=[{feature:133 for feature in FEATURES}]
    for _ in range(19):
        nxt=high_step(tail[-1])
        source={feature:325-d for feature,d in tail[-1].items()}
        assert {feature:325-d for feature,d in nxt.items()}==step(12,325,13,source,strong_band=False)
        tail.append(nxt)
    assert min(tail[-2].values())==112
    assert min(tail[-1].values())==110

    receipt={'status':'PASS','scope':'Direct fixed quadratic substitutions accompanying a uniform plateau invariant, not a length sample.',
             'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'features':FEATURES,
             'capacity_maxima':{'sigma_plus_low_at_12':max_low,'high_at_12':max_high,
                               'high_v_at_most_one_at_12':max_high_v01,'high_j_two_at_12':max_high_j2},
             'prefixes':prefixes,'tail_deficits':[list(B.values())for B in tail],
             'uniform_result':{'domain':'25 by even n>=26, budget 13','full_lower':'50*n-926',
                               'remaining_from_time28':'25*n-491','precentral_backward_maximum':'25*n/2-112'},
             'seconds':process_time()-started}
    Path('research/bridge-boundary-numeric-25-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print({k:v for k,v in receipt.items()if k not in ('prefixes','tail_deficits')})


if __name__=='__main__':
    main()

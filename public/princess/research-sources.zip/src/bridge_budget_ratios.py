"""Compare named bounds where width and budget grow together.

The recurrence is an accepted necessary model. Prefix and envelope values
are upper bounds. Equality between named bounds settles only listed inputs.
"""
from math import isqrt
from pathlib import Path
import json,time
from bridge_corner_frontier import first_clock,step
from resumed_even_construction_prefix_arithmetic import neighborhood_count

def root(x):
    a=isqrt(x);return a+(a*a<x)

def analyze(w,n,k):
    h=w*n//2;r=w//2
    tau,_=first_clock(w,n,k,critical=True)
    B=tuple(min(k//2,h-2+c)for c in range(3))
    for _ in range(tau-1):B=step(w,n,k,B,critical=True)
    lower=2*tau-int(B[2]>=h)
    options=[]
    for phase in (0,1):
        q=h;p=phase;t=0
        while q>k:
            q=neighborhood_count(w,n,p,q-k);p=1-p;t+=1
        options.append(2*(t+1)-int(2*q<=k))
    Q,s=divmod(h-r,k-r)
    generic=2*Q if not s else 2*Q+1+int(2*(s+min(root(s),r))>k)
    upper=min(generic,*options)
    assert lower<=upper,(w,n,k,lower,upper)
    return dict(w=w,n=n,k=k,model_solo=tau,lower=lower,
                generic_upper=generic,prefix_uppers=options,upper=upper,gap=upper-lower)

if __name__=='__main__':
    started=time.process_time();rows=[]
    for w in (6,10,16,24,40,64,100):
        r=w//2
        for n in (w,w+1,2*w,4*w):
            for k in sorted({max(r+1,(3*r+1)//2),2*r,3*r,4*r}):
                if k>=w*n//2:continue
                rows.append(analyze(w,n,k))
                assert time.process_time()-started<25,'bounded run budget exceeded'
    out=dict(scope=__doc__,rows=rows,cases=len(rows),cpu_seconds=time.process_time()-started)
    Path('research/bridge-budget-ratios.json').write_text(json.dumps(out,indent=2)+'\n')
    print(dict(cases=len(rows),matched=sum(x['gap']==0 for x in rows),
        maximum_gap=max(x['gap']for x in rows),cpu_seconds=out['cpu_seconds']))
    print(sorted(rows,key=lambda x:x['gap'],reverse=True)[:12])

"""Bounded independent attack on row-interval survivor normal forms."""
import argparse
import json
from pathlib import Path
import even_bridge_budget_words as words


def interval_flags(shape, colors):
    answer=[]
    for row in colors:
        masks=[]
        for x in range(shape[0]):
            inds=[i for i,v in enumerate(row) if v[0]==x]
            masks.append([sum(1<<i for i in inds[l:r]) for l in range(len(inds)+1) for r in range(l,len(inds)+1)])
        states={0}
        for masks_x in masks:
            states={a|b for a in states for b in masks_x}
        flags=bytearray(1<<len(row))
        for a in states:flags[a]=1
        answer.append(flags)
    return answer


def run(shape, seconds=5, full=False, constant=None):
    words.prefix_flags=interval_flags
    return words.run(shape,'row-interval-survivors',seconds=seconds,state_cap=1500,full_only=full,
                     min_budget=0 if constant is None else constant,max_budget=constant)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('shape',nargs=2,type=int)
    p.add_argument('--seconds',type=float,default=5);p.add_argument('--full',action='store_true')
    p.add_argument('--constant',type=int);p.add_argument('--output',type=Path)
    a=p.parse_args();r=run(tuple(a.shape),a.seconds,a.full,a.constant)
    if a.output:a.output.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps(r,indent=2))

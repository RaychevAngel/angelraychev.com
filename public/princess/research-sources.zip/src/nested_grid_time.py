#!/usr/bin/env python3
"""Exact capture-time DP conditional on a verified isoperimetric nesting order.

Small-case tests below independently check both nesting and isoperimetry.
The general rectangle theorem must be supplied by the cited mathematical proof.
No exponential neighborhood table is built by the compressed solver.
"""
from collections import deque
from itertools import product
from pathlib import Path
import json
import time


def grid(shape):
    coords = list(product(*(range(k) for k in shape)))
    index = {c: i for i, c in enumerate(coords)}
    adj = []
    for c in coords:
        mask = 0
        for j, extent in enumerate(shape):
            for delta in (-1, 1):
                d = list(c)
                d[j] += delta
                if 0 <= d[j] < extent:
                    mask |= 1 << index[tuple(d)]
        adj.append(mask)
    return coords, adj


def neighborhood(mask, adj):
    result = 0
    while mask:
        bit = mask & -mask
        result |= adj[bit.bit_length() - 1]
        mask ^= bit
    return result


def ordered_profiles(shape, brute=False, weightlex=False):
    coords, adj = grid(shape)
    orders = [sorted((i for i, c in enumerate(coords) if sum(c) % 2 == parity),
                     key=lambda i: (sum(coords[i]), tuple(-x for x in coords[i]) if weightlex else coords[i])) for parity in range(2)]
    prefixes = []
    for order in orders:
        row = [0]
        for i in order:
            row.append(row[-1] | (1 << i))
        prefixes.append(row)
    profiles = [[neighborhood(s, adj).bit_count() for s in row] for row in prefixes]
    for parity in range(2):
        for k, mask in enumerate(prefixes[parity]):
            actual = neighborhood(mask, adj)
            if actual != prefixes[1-parity][profiles[parity][k]]:
                return {"shape": shape, "nested": False, "failure": [parity, k]}, None
    report = {"shape": shape, "nested": True, "profiles": profiles}
    if brute:
        minima = []
        subsets = 0
        for order in orders:
            sizes = [len(coords) + 1] * (len(order) + 1)
            masks = [0] * (1 << len(order))
            for code in range(1, len(masks)):
                bit = code & -code
                masks[code] = masks[code ^ bit] | (1 << order[bit.bit_length()-1])
            for code, mask in enumerate(masks):
                k = code.bit_count()
                sizes[k] = min(sizes[k], neighborhood(mask, adj).bit_count())
            subsets += len(masks)
            minima.append(sizes)
        report.update(isoperimetric=minima == profiles, subsets_checked=subsets)
        if minima != profiles:
            report["actual_minima"] = minima
    return report, (coords, adj, orders, prefixes, profiles)


def solve(data, m):
    coords, adj, orders, prefixes, profiles = data
    start = (len(orders[0]), len(orders[1]))
    parents = {start: None}
    queue = deque([start])
    edges = 0
    while queue:
        a, b = state = queue.popleft()
        if a + b <= m:
            shots = [prefixes[0][a] | prefixes[1][b]]
            while parents[state] is not None:
                previous, p, q = parents[state]
                x, y = previous
                shots.append((prefixes[0][x] ^ prefixes[0][max(x-p, 0)]) |
                             (prefixes[1][y] ^ prefixes[1][max(y-q, 0)]))
                state = previous
            shots.reverse()
            belief = (1 << len(coords)) - 1
            for day, shot in enumerate(shots):
                assert shot.bit_count() <= m
                belief &= ~shot
                if not belief:
                    assert day == len(shots)-1
                else:
                    belief = neighborhood(belief, adj)
                    assert belief
            assert not belief
            return {"status": "finite", "minimum_turns": len(shots),
                    "states": len(parents), "edges": edges,
                    "inspections": [[coords[i] for i in range(len(coords)) if s & (1 << i)] for s in shots]}
        for p in range(m+1):
            q = m-p
            after = (profiles[1][max(b-q, 0)], profiles[0][max(a-p, 0)])
            edges += 1
            if after not in parents:
                parents[after] = ((a, b), p, q)
                queue.append(after)
    return {"status": "infeasible", "minimum_turns": None,
            "states": len(parents), "edges": edges}


def main():
    root = Path(__file__).resolve().parents[1]
    begin = time.monotonic()
    nesting = []
    cached = {}
    for a in range(2, 21):
        for b in range(2, a+1):
            report, data = ordered_profiles((a, b), brute=a*b <= 24)
            nesting.append(report)
            if not report['nested'] or report.get('isoperimetric') is False:
                print('FAILED', report, flush=True)
            cached[(a, b)] = data
    comparisons = []
    for name in ['grid-small-cases.json', 'extension-grid-probe.json']:
        source = json.loads((root/'research'/name).read_text())
        for original in source['results']:
            shape = tuple(sorted(original['shape'], reverse=True))
            if len(shape) != 2:
                continue
            data = cached.get(shape)
            if data is None:
                report, data = ordered_profiles(shape, brute=True)
                assert report['nested'] and report['isoperimetric']
            result = solve(data, original['m'])
            comparisons.append({'shape': shape, 'm': original['m'], 'source': name,
                                'ordered_strategy_turns': result['minimum_turns'],
                                'true_minimum_turns': original['minimum_turns'],
                                'matched': result['status'] == original['status'] and result['minimum_turns'] == original['minimum_turns']})
    examples = []
    for shape in [(3, n) for n in range(2, 11)] + [(5, 5), (8, 6), (10, 10)]:
        shape = tuple(sorted(shape, reverse=True))
        report, data = ordered_profiles(shape)
        assert report['nested']
        budgets = [2] if min(shape) == 3 else [min(shape)//2, min(shape)//2+1, min(shape), sum(shape)]
        for m in budgets:
            result = solve(data, m)
            examples.append({'shape': shape, 'm': m, **result})
    cubes = []
    for d in range(2, 7):
        report, data = ordered_profiles((2,)*d, brute=d <= 5, weightlex=True)
        assert report['nested'] and report.get('isoperimetric', True)
        h = 1 + sum(__import__('math').comb(i, i//2) for i in range(d-1))
        report['budget_results'] = [{'m':m, **solve(data,m)} for m in sorted(set([h-1,h,h+1,2**(d-1)]))]
        cubes.append(report)
    out = {'scope': 'FAILED unrestricted-grid reduction: the diagonal orders are neighborhood-nested but not always isoperimetric. Ordered_strategy_turns are upper bounds only. The conditional exact theorem applies when BOTH hypotheses hold; cubes are separately verified against the published nesting theorem.',
           'seconds': time.monotonic()-begin, 'nesting_checks': nesting,
           'unrestricted_bfs_comparisons': comparisons, 'ordered_examples': examples,
           'hypercubes': cubes}
    (root/'research/nested-grid-time-checks.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({'seconds':out['seconds'], 'rectangles_checked':len(nesting),
                      'bfs_comparisons':len(comparisons),
                      'counterexamples': [r for r in comparisons if not r['matched']],
                      'cubes': [{'d':len(r['shape']), 'results':[{k:v for k,v in s.items() if k!='inspections'} for s in r['budget_results']]} for r in cubes]}, indent=2))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Bounded LP attack on additive potentials at the minimum odd-grid budget.

Numerical optimization is exploratory. Every rounded output is checked again
over exact fractions before it can be reported as a finite lower certificate.
Run with scipy available; it is not needed by the main game solver.
"""
from fractions import Fraction
from pathlib import Path
from time import monotonic
import argparse, json

from odd_serial_first_order_attack import profiles, serial


def solve(width, length):
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import lil_matrix
    b=(width-1)//2; m=b+1; g=profiles((length-1)//2,b)
    offsets=(0,len(g[0])); size=sum(map(len,g)); charge=size
    nvars=size+2*(m+1)
    rows=[]; bounds=[]
    for p in (0,1):
        for k in range(len(g[p])):
            for r in range(m+1):
                nxt=g[p][max(0,k-r)]
                rows.append({offsets[p]+k:1,
                             offsets[1-p]+nxt:-1,
                             charge+p*(m+1)+r:-1})
                bounds.append(0)
    for r in range(m+1):
        rows.append({charge+r:1,charge+(m+1)+m-r:1})
        bounds.append(1)
    mat=lil_matrix((len(rows),nvars))
    for i,row in enumerate(rows):
        for j,a in row.items():mat[i,j]=a
    obj=np.zeros(nvars)
    for p in (0,1):obj[offsets[p]+len(g[p])-1]=-1
    vbounds=[(0,None)]*nvars
    for p in (0,1):vbounds[offsets[p]]=(0,0)
    result=linprog(obj,A_ub=mat.tocsr(),b_ub=bounds,bounds=vbounds,
                   method='highs',options={'threads':1})
    if not result.success:raise RuntimeError(result.message)
    exact=[Fraction(float(v)).limit_denominator(10000) for v in result.x]
    violations=[i for i,(row,rhs) in enumerate(zip(rows,bounds))
                if sum(exact[j]*a for j,a in row.items())>rhs]
    value=sum(exact[offsets[p]+len(g[p])-1] for p in (0,1))
    return {'width':width,'length':length,'budget':m,
            'potential_value':str(value),'serial_upper':min(serial(g,m,p) for p in (0,1)),
            'exact_fraction_verified':not violations,'constraint_count':len(rows),
            'violations':violations[:5],
            'charges':[[str(exact[charge+p*(m+1)+r])for r in range(m+1)]for p in(0,1)],
            'potentials':[[str(exact[offsets[p]+k])for k in range(len(g[p]))]for p in(0,1)]}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--max-width',type=int,default=15)
    args=parser.parse_args();start=monotonic()
    results=[solve(w,w)for w in range(3,args.max_width+1,2)]
    out={'scope':'Finite additive-potential certificates; no all-length theorem.',
         'seconds':monotonic()-start,'results':results}
    Path(__file__).resolve().parents[1].joinpath('research/odd-minimum-budget-potentials.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({**out,'results':[{k:v for k,v in r.items()if k!='potentials'}for r in results]},indent=2))

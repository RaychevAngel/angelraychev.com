"""Construct a solo schedule with each survivor a union of two corner prefixes.

This restricted search is only an upper construction. It does not assert an
unbounded normal form or exactness of this family for other parameters.
"""
from collections import defaultdict,deque
from itertools import combinations
from pathlib import Path
import json,time

from resumed_even_construction_prefix import PrefixGame
from resumed_even_construction_square_audit import prepare


def run(w=12,k=7):
    start=time.monotonic();d=prepare(w,w);g=PrefixGame(w,w)
    I,S,H=[d[q]for q in('ideals','sizes','hood')]
    representations=[];groups=[]
    for p in (0,1):
        reps=[];by_size=defaultdict(list)
        for j,mask in enumerate(I[p]):
            pieces=[]
            for order_id,order in enumerate(g.orders[p]):
                best=0;size=0
                for s,prefix in enumerate(order):
                    if prefix&~mask:break
                    best=prefix;size=s
                pieces.append((best,order_id,size))
            pair=next(((a[1:],b[1:])for a,b in combinations(pieces,2)
                       if a[0]|b[0]==mask),None)
            reps.append(pair)
            if pair is not None:by_size[S[p][j]].append(j)
        representations.append(reps);groups.append(by_size)
    initial=(0,len(I[0])-1);queue=deque([(initial,0)]);parents={initial:None}
    terminal=None
    while queue:
        (p,i),depth=queue.popleft()
        if S[p][i]<=k:terminal=(p,i);break
        for j in groups[p][S[p][i]-k]:
            if I[p][j]&~I[p][i]:continue
            nxt=(1-p,H[p][j])
            if nxt not in parents:
                parents[nxt]=((p,i),j);queue.append((nxt,depth+1))
    assert terminal is not None
    steps=[(terminal,0)];current=terminal
    while parents[current] is not None:
        current,j=parents[current];steps.append((current,j))
    steps.reverse();shots=[];rows=[]
    for (p,i),j in steps:
        shot=[v for bit,v in enumerate(d['colors'][p])if (I[p][i]^I[p][j])>>bit&1]
        shots.append(set(shot))
        rows.append({'before':S[p][i],'survivor':S[p][j],
                     'survivor_heights':d['heights'][p][j],
                     'two_prefixes_order_id_and_size':representations[p][j],
                     'shots':shot})
    vertices={(x,y)for x in range(w)for y in range(w)}
    for mode,sequence,belief in (
            ('solo',shots,set(d['colors'][0])),
            ('full',shots+shots[::-1],set(vertices))):
        for t,shot in enumerate(sequence,1):
            assert len(shot)<=k and shot<=vertices
            belief-=shot
            assert bool(belief)==(t<len(sequence))
            belief={u for x,y in belief for u in
                    ((x-1,y),(x+1,y),(x,y-1),(x,y+1))if u in vertices}
        assert not belief
    return {'w':w,'n':w,'k':k,'solo_days':len(shots),'full_upper':2*len(shots),
            'two_prefix_pyramid_counts':[sum(r is not None for r in row)for row in representations],
            'both_physical_replays_passed':True,'schedule':rows,
            'search_states':len(parents),'seconds':time.monotonic()-start,
            'scope':'Constructive finite upper in a stricter family than all pyramids. No general optimal-family theorem.'}


if __name__=='__main__':
    out=run()
    Path('research/resumed-even-construction-two-prefixes-12x12-k7.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='schedule'})

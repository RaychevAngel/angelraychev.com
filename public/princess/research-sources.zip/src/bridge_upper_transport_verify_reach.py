"""Independent radius-model BFS without monotone dominance.

Reuses the reviewed finite base-edge generator, but groups equal-radius
states into integer bitsets. No comparison between different radius pairs
is used. This verifies the finite evaluator, not its geometric premises.
"""
from pathlib import Path
import hashlib
import json
import math
import time

from bridge_lower_frontier_flagged import base_cache, flagged
from bridge_lower_frontier_diagnostic import square_successor_flag


def ids(bits):
    while bits:
        low = bits & -bits
        bits ^= low
        yield low.bit_length() - 1


def verify(w=25, n=26, k=13, cpu_limit=30, seed_size=None, all_larger=False,
           radius_length=None, dump_depths=(), seed_feature=None):
    begin = time.process_time()
    b = (w - 1) // 2
    data, cached = base_cache(b, n, k)
    assert cached, 'The bounded verifier requires the existing cached base.'
    states, edges, rows = flagged(data, b, n, k, 'forbid-pair', return_weighted=True)
    states, edges, rows = square_successor_flag(states, rows, b, n, k)
    total = (1 << len(states)) - 1
    start = 1 << states.index((w * n // 2, 2, 2))
    zero = 1 << states.index((0, 0, 0))
    reached, frontier = start, start
    for _ in range(28):
        out = 0
        for a in ids(frontier):
            out |= edges[a]
        frontier = out & ~reached
        reached |= frontier
    seeds = reached & sum(1 << a for a, s in enumerate(states)
                          if s[0] >= w * n // 2 - 111)
    day_offset = 28
    if seed_size is not None:
        seeds = sum(1 << a for a, s in enumerate(states)
                    if s[0] >= seed_size if all_larger or s[0] == seed_size)
        day_offset = 0
    if seed_feature is not None:
        seeds &= sum(1 << a for a, s in enumerate(states) if tuple(s[1:3]) == tuple(seed_feature))
    radius_n = n if radius_length is None else radius_length
    assert radius_n <= n
    diameter = w + radius_n - 2
    flagged_masks = {}
    normal = total
    for a, state in enumerate(states):
        if len(state) > 3 and state[3] in (4, 7):
            q, flag = state[0], state[3]
            if flag == 4:
                r = math.isqrt(q)
                assert r * r == q
                key = (0, 2 * r - 2)
            else:
                r = (math.isqrt(4 * q + 1) - 1) // 2
                assert r * (r + 1) == q
                key = (1, 2 * r - 1)
            flagged_masks[key] = flagged_masks.get(key, 0) | (1 << a)
            normal &= ~(1 << a)
    feature_masks = {(c, e): sum(1 << a for a, s in enumerate(states)
                                if s[1] <= c and s[2] <= e)
                     for c in range(3) for e in range(3)}
    front = {(diameter, diameter): seeds}
    seen = dict(front)
    layers = []
    dumps = {}
    raw_edges = filtered_edges = sources = 0
    for depth in range(1000):
        size_minimum = min(states[a][0] for mask in front.values() for a in ids(mask))
        layer_count = sum(mask.bit_count() for mask in front.values())
        layers.append(dict(tail_depth=depth, new_augmented_states=layer_count,
                           first_arrival_minimum=size_minimum))
        if depth in dump_depths:
            dumps[depth] = [dict(radii=pair, base_states=[states[a] for a in ids(mask)])
                            for pair, mask in sorted(front.items())]
        if any(mask & zero for mask in front.values()):
            break
        following = {}
        for (r0, r1), mask in front.items():
            nr0, nr1 = min(diameter, r1 + 1), min(diameter, r0 + 1)
            c = min(1 + (nr0 >= w - 1), (nr1 >= radius_n - 1) + (nr1 >= w + radius_n - 2))
            e = min((nr0 >= radius_n) + (nr0 >= w + radius_n - 3), (nr1 >= 1) + (nr1 >= w))
            allowed = feature_masks[c, e]
            out = 0
            for a in ids(mask):
                out |= edges[a]
                raw_edges += edges[a].bit_count()
                filtered_edges += (edges[a] & allowed).bit_count()
                sources += 1
            out &= allowed
            base = out & normal
            following[nr0, nr1] = following.get((nr0, nr1), 0) | base
            for (coordinate, radius), part in flagged_masks.items():
                target = (min(nr0, radius), nr1) if coordinate == 0 else (nr0, min(nr1, radius))
                following[target] = following.get(target, 0) | (out & part)
        front = {}
        for pair, mask in following.items():
            fresh = mask & ~seen.get(pair, 0)
            if fresh:
                front[pair] = fresh
                seen[pair] = seen.get(pair, 0) | fresh
        assert front
        if time.process_time() - begin > cpu_limit:
            raise RuntimeError(dict(bounded_stop=True, depth=depth, processed_sources=sources))
    else:
        raise AssertionError('No capture before bounded depth.')
    result = dict(scope=__doc__, shape=[w, n], budget=k, dominance=False,
                  base_cache_reused=True, seed_count=seeds.bit_count(), day_offset=day_offset,
                  radius_length=radius_n, frontier_dumps=dumps,
                  square_trigger_radii=sorted({(r + 1) // 2 for d, r in flagged_masks if d == 1}),
                  seed_size=seed_size, all_larger=all_larger, seed_feature=seed_feature,
                  solo_days=day_offset + depth,
                  minimum_before_first_capture=min(x['first_arrival_minimum'] for x in layers[:-1]),
                  augmented_states=sum(mask.bit_count() for mask in seen.values()),
                  radius_pairs=len(seen), processed_sources=sources,
                  raw_edges=raw_edges, feature_filtered_edges=filtered_edges,
                  CPU_seconds=time.process_time() - begin, layers=layers,
                  source_sha256={str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                                 for path in (Path(__file__), Path('src/bridge_lower_frontier_diagnostic.py'),
                                              Path('src/bridge_lower_frontier_flagged.py'))},
                  base_source_sha256=data['source_sha256'], base_model_sha256=data['model_sha256'])
    result['full_lower'] = (2 * result['solo_days'] - (2 * result['minimum_before_first_capture'] <= k)
                            if seed_size is None else None)
    return result


if __name__ == '__main__':
    answer = verify()
    Path('research/bridge-upper-transport-persistent-verified.json').write_text(json.dumps(answer, indent=2) + '\n')
    print(json.dumps({k: v for k, v in answer.items() if k != 'layers'}))

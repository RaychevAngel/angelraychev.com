"""Enumerate every surplus-b support via its deleted boundary and SCC closure.

Finite evidence only. The search enumerates actual physical supports, not a
prefix or pyramid family. A separate coordinate replay checks any witness.
"""
from itertools import combinations
from pathlib import Path
from time import process_time
import json,argparse
from resumed_even_construction_formula_profile import F

def build(b,n):
 w=2*b+1;ell=n//2;h=w*ell
 adj=[]
 for x in range(w):
  for j in range(ell):
   neigh=[x*ell+j]
   if x:neigh.append((x-1)*ell+j)
   if x+1<w:neigh.append((x+1)*ell+j)
   z=j+(-1 if x%2==0 else 1)
   if 0<=z<ell:neigh.append(x*ell+z)
   adj.append(neigh)
 return adj

def scc(adj,removed):
 n=len(adj);num={};low={};stack=[];on=set();out=[]
 def visit(v):
  num[v]=low[v]=len(num);stack.append(v);on.add(v)
  for u in adj[v]:
   if removed>>u&1:continue
   if u not in num:visit(u);low[v]=min(low[v],low[u])
   elif u in on:low[v]=min(low[v],num[u])
  if low[v]==num[v]:
   comp=0
   while True:
    u=stack.pop();on.remove(u);comp|=1<<u
    if u==v:break
   out.append(comp)
 for v in range(n):
  if not removed>>v&1 and v not in num:visit(v)
 return out

def physical(b,n,mask,p):
 ell=n//2
 return {(v//ell,2*(v%ell)+((p-v//ell)%2)) for v in range((2*b+1)*ell) if mask>>v&1}
def hood(S,b,n):
 return {(u,v)for x,y in S for u,v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if 0<=u<2*b+1 and 0<=v<n}
def enumerate_critical(b,n,seconds=30):
 start=process_time();adj=build(b,n);h=len(adj);ab=[sum(1<<v for v in row)for row in adj];found={};blocks=0;maxcomps=0
 for boundary in combinations(range(h),b):
  B=sum(1<<v for v in boundary);comps=scc(adj,B);maxcomps=max(maxcomps,len(comps));closures=[(0,0)]
  for C in comps:
   N=0
   for v in range(h):
    if C>>v&1:N|=ab[v]
   closures += [(R|C,H|N)for R,H in closures]
  for R,N in closures:
   if N&~R==B:found[R]=N
  blocks+=1
  if blocks%1000==0 and process_time()-start>seconds:return {'complete':False,'boundaries':blocks,'supports':len(found),'seconds':process_time()-start}
 ell=n//2
 reflect=lambda R:sum(1<<(x*ell+ell-1-j)for x in range(2*b+1)for j in range(ell)if R>>(x*ell+j)&1)
 candidates=[reflect(R)for R in found if b*(b-1)<R.bit_count()<h-b*(b+1)]
 pairs=0;witness=None;marginal_failures=[];dual_failures=[];critical_corner_failures=[]
 bottom=(1<<0)|(1<<(2*b*ell));top=(1<<(ell-1))|(1<<((2*b+1)*ell-1))
 for R,N in found.items():
  i=(R&bottom).bit_count();j=(N&top).bit_count();a=R.bit_count()
  if (i,j)!=(2,0) and not (a<=F(i,j,b) or h-a-b<=max(F(2-j,d,b-2+i+d)for d in range(3-i))):
   critical_corner_failures.append({'mask':R,'size':a,'incoming_corners':i,'outgoing_corners':j})
  if b*b<R.bit_count()<h-b*b:
   if R&bottom!=bottom or (N&top).bit_count()>1:
    dual_failures.append({'mask':R,'size':R.bit_count(),'incoming_corners':(R&bottom).bit_count(),'outgoing_corners':(N&top).bit_count()})
  if b*(b-1)<R.bit_count()<h-b*(b+1):
   if not R&bottom or N&top:marginal_failures.append({'mask':R,'size':R.bit_count(),'bottom_present':bool(R&bottom),'outgoing_top_present':bool(N&top)})
 for R,N in found.items():
  if not b*(b-1)<R.bit_count()<h-b*(b+1):continue
  for S in candidates:
   if S&~N:continue
   A=physical(b,n,R,0);Z=physical(b,n,S,1);NA=hood(A,b,n);NZ=hood(Z,b,n)
   assert len(NA)-len(A)==len(NZ)-len(Z)==b and Z<=NA
   witness={'source':sorted(A),'next_survivor':sorted(Z),'source_size':len(A),'next_size':len(Z),'neighborhood':sorted(NA),'deletions':len(NA-Z)};break
  if witness:break
  pairs+=len(candidates)
 return {'width':2*b+1,'length':n,'complete':True,'boundaries':blocks,'critical_supports':len(found),'max_scc_count':maxcomps,'candidate_next_supports':len(candidates),'pairs_checked':pairs,'seconds':process_time()-start,'threshold':b*(b-1),'marginal_failures':marginal_failures[:10],'dual_failures':dual_failures[:10],'critical_corner_failures':critical_corner_failures[:10],'witness':witness}

def main():
 a=argparse.ArgumentParser();a.add_argument('--b',type=int,default=3);a.add_argument('--n',type=int,default=8);a.add_argument('--seconds',type=float,default=20);p=a.parse_args();r=enumerate_critical(p.b,p.n,p.seconds);Path(f'research/resumed-odd-even-cheap-pairs-{2*p.b+1}x{p.n}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()

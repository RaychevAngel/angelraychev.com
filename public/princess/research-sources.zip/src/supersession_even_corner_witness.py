"""Direct physical replay of the six-vertex terminal-corner obstruction.

This is a single explicit witness check, not an optimum-search program.
The matching lower bound is the spanning 5-by-6 rectangle theorem.
"""

from collections import deque
from itertools import combinations
import json
from pathlib import Path


def main():
    edges = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (1, 4), (2, 5)]
    adj = [set() for _ in range(6)]
    for u, v in edges:
        adj[u].add(v)
        adj[v].add(u)
    distance_sums = []
    for v in range(6):
        dist = {v: 0}
        queue = deque([v])
        while queue:
            u = queue.popleft()
            for z in adj[u]:
                if z not in dist:
                    dist[z] = dist[u] + 1
                    queue.append(z)
        distance_sums.append(sum((d + 1) // 2 for d in dist.values()))

    board = {(x, y) for x in range(6) for y in range(5)}

    def neighborhood(support):
        return {
            (u, z)
            for x, y in support
            for u, z in [(v, y) for v in adj[x]] + [(x, y - 1), (x, y + 1)]
            if (u, z) in board
        }

    def pyramid(support):
        return all(
            y == 0 or all((u, y - 1) in support for u in adj[x])
            for x, y in support
        )

    r = {(0, 0), (0, 2)}
    a = {(0, 0), (0, 2), (1, 1), (1, 3), (2, 0), (2, 2),
         (3, 1), (4, 0), (4, 2), (5, 1)}
    e = {(0, 1), (1, 0), (1, 2), (2, 1), (3, 0), (4, 1), (5, 0)}
    s = {(3, 0), (5, 0)}
    b = {(1, 0), (3, 0), (5, 0), (0, 1), (2, 1), (4, 1),
         (1, 2), (3, 2), (5, 2), (0, 3)}
    f = {(0, 0), (0, 2), (1, 1), (2, 0), (3, 1), (4, 0), (5, 1)}
    classes = [{v for v in board if sum(v) % 2 == p} for p in (0, 1)]
    assert all(pyramid(t) for t in (a, e, b, f, s))
    assert not pyramid(r)
    assert neighborhood(e) <= a and neighborhood(f) <= b
    minimum_pyramid_costs = []
    for color in classes:
        minimum_pyramid_costs.append(min(
            len(neighborhood(set(pair)))
            for pair in combinations(color, 2)
            if pyramid(set(pair))
        ))
    assert minimum_pyramid_costs == [5, 4]
    shots = [classes[1] - e, a - r, neighborhood(r) | neighborhood(s),
             b - s, classes[0] - f]
    belief = board
    counts = []
    for inspected in shots:
        assert len(inspected) == 8
        belief = neighborhood(belief - inspected)
        counts.append(len(belief))
    assert not belief
    receipt = {
        "scope": "explicit physical upper witness; lower uses spanning rectangle theorem",
        "Q_edges": edges,
        "length": 5,
        "budget": 8,
        "H_Q_distance_sums": distance_sums,
        "H_Q": max(distance_sums),
        "two_room_pyramid_neighborhood_minima": minimum_pyramid_costs,
        "nonpyramid_neighborhood": sorted(neighborhood(r)),
        "shots": [sorted(t) for t in shots],
        "belief_sizes_after_moves": counts,
        "capture_verified": True,
    }
    output = Path(__file__).resolve().parents[1] / "research/supersession-even-corner-witness.json"
    output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: receipt[k] for k in (
        "H_Q", "two_room_pyramid_neighborhood_minima",
        "belief_sizes_after_moves", "capture_verified")}, sort_keys=True))


if __name__ == "__main__":
    main()

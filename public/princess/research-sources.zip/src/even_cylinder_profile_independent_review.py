"""Independent physical-set and finite-language audit of the 3x3x(2L) lemma.

No imports from the discovery implementation.  Transverse neighborhoods,
two-pair costs, and transitions are rebuilt from actual grid coordinates.
"""

from collections import deque
from itertools import product
import json
from pathlib import Path


SQUARE = tuple(product(range(3), repeat=2))
ORDER = tuple(
    tuple(sorted((v for v in SQUARE if sum(v) % 2 == p),
                 key=lambda v: (sum(v), -v[0], -v[1])))
    for p in range(2)
)
PREFIX = tuple(tuple(frozenset(order[:k]) for k in range(len(order) + 1))
               for order in ORDER)


def square_neighbors(support):
    return frozenset(v for v in SQUARE
                     if any(sum(abs(a - b) for a, b in zip(v, u)) == 1
                            for u in support))


def physical_word(counts):
    n = len(counts)
    support = frozenset((x, y, z) for z, k in enumerate(counts)
                        for x, y in PREFIX[z % 2][k])
    neighbors = set()
    for room in support:
        for axis, cap in enumerate((3, 3, n)):
            for step in (-1, 1):
                nxt = list(room)
                nxt[axis] += step
                if 0 <= nxt[axis] < cap:
                    neighbors.add(tuple(nxt))
    for z in range(n):
        actual = frozenset((x, y) for x, y, j in neighbors if j == z)
        assert actual == PREFIX[1 - z % 2][len(actual)]
    return len(neighbors) - len(support)


def project(state):
    symbol, cost, occupied, omitted, first, length = state
    return symbol, cost, occupied, omitted, first >= 3, length


def main():
    subset_checks = 0
    profiles = []
    for color, order in enumerate(ORDER):
        profiles.append([len(square_neighbors(s)) for s in PREFIX[color]])
        for mask in range(1 << len(order)):
            support = frozenset(v for i, v in enumerate(order) if mask >> i & 1)
            actual = square_neighbors(support)
            compressed_actual = PREFIX[1 - color][len(actual)]
            compressed_neighbors = square_neighbors(PREFIX[color][len(support)])
            assert compressed_neighbors <= compressed_actual
            subset_checks += 1

    alphabet = tuple(product(range(6), range(5)))
    vertex = {s: physical_word(s) for s in alphabet}
    edge = {(s, t): physical_word(s + t) - vertex[s] - vertex[t]
            for s in alphabet for t in alphabet}
    assert min(vertex.values()) >= 0 and min(edge.values()) >= 0

    # The exact first count refines the discovery automaton's Boolean field.
    states = set()
    queue = deque()
    arcs = set()
    terminal_checks = critical_checks = 0
    for symbol in alphabet:
        value = vertex[symbol]
        if value <= 4:
            a, b = symbol
            state = (symbol, value, min(4, a + b), min(8, 9 - a - b), a, 1)
            states.add(state)
            queue.append(state)
    while queue:
        state = queue.popleft()
        symbol, value, occupied, omitted, first, length = state
        if length == 2:
            required = (0 if occupied == 0 or omitted == 0
                        else min(4, occupied + 1, (omitted + 2) // 2))
            assert value >= required
            terminal_checks += 1
            if value == 4 and occupied == 4 and omitted == 8:
                assert first >= 3 and symbol[1] == 0 and symbol[0] <= 2
                critical_checks += 1
        for target in alphabet:
            new_value = value + edge[symbol, target] + vertex[target]
            if new_value > 4:
                continue
            a, b = target
            nxt = (target, new_value, min(4, occupied + a + b),
                   min(8, omitted + 9 - a - b), first, 2)
            arcs.add((project(state), target))
            if nxt not in states:
                states.add(nxt)
                queue.append(nxt)

    receipt = {
        "status": "all physical and finite-language assertions passed",
        "ordinary_proof_scope": "every even longitudinal length n>=4",
        "single_color_square_subsets_checked": subset_checks,
        "square_prefix_profiles": profiles,
        "physical_two_slice_costs_checked": len(vertex),
        "physical_four_slice_costs_checked": len(edge),
        "refined_reachable_states": len(states),
        "projected_reachable_states": len({project(s) for s in states}),
        "projected_state_symbol_transitions": len(arcs),
        "terminal_profile_assertions": terminal_checks,
        "critical_terminal_assertions": critical_checks,
        "compression_bridge": "minimal-surplus equality gives N(CR)=C(NR)",
        "formalization": "ordinary finite certificate, not Lean",
    }
    target = Path(__file__).resolve().parents[1] / "research/even-cube-cylinder-profile-independent-review.json"
    target.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()

"""Physical-window scheduling for the descending-height transport word.

The theorem is uniform. The exploratory splice-index loops below are bounded
diagnostics, not an O(1) capture-time formula. No old artifact is overwritten.
"""
from bisect import bisect_left
from pathlib import Path
import argparse
import json
import random
import time

from resumed_even_construction_transport import neighborhood
from resumed_even_construction_prefix_arithmetic import (
    entrance, exit_thresholds, prefix_parameters, neighborhood_count,
)


def prefix_height(w, n, p, q, right=False):
    d, c = prefix_parameters(w, n, p ^ (right and (w - 1) % 2), q)
    answer = []
    for x in range(w):
        z = w - 1 - x if right else x
        empty = (p - x) % 2 - 2
        top = n - 1 - ((n - 1 - p + x) % 2)
        answer.append(max(empty, min(top, d - z - 2 + 2 * (z >= c))))
    return answer


def support(w, n, p, a):
    return {(x, y) for x in range(w) for y in range(n)
            if (x + y) % 2 == p and y <= a[x]}


def word(a, b, t):
    c = [min(x, y - t) for x, y in zip(a, b)]
    letters = sorted(((x, H) for x in range(len(a))
                      for H in range(a[x], c[x], -2)),
                     key=lambda letter: (-letter[1], letter[0]))
    return letters, c


def window(a, b, n, t, k):
    """Exact fixed-word feasibility; no assertion of physical necessity."""
    if t == 0:
        return {'feasible': all(x <= y for x, y in zip(a, b)), 'window': None}
    letters, _ = word(a, b, t)
    heights = sorted(H for _, H in letters)
    count = len(heights)
    best_gain = None
    best_i = 0
    best_slack = -10**18
    best_pair = None
    for j in range(t):
        above = count - bisect_left(heights, n - j)
        gain = above - k * j
        if best_gain is None or gain > best_gain:
            best_gain, best_i = gain, j
        not_below = count - bisect_left(heights, -j)
        slack = best_gain + k * (j + 1) - not_below
        if slack > best_slack:
            best_slack = slack
            best_pair = (best_i, j)
    return {'feasible': best_slack >= 0, 'window': best_pair,
            'slack': best_slack, 'virtual_flips': count}


def construct(w, n, p, a, b, t, k):
    result = window(a, b, n, t, k)
    assert result['feasible'], result
    if t == 0:
        return [], result
    letters, c = word(a, b, t)
    # Validate legality independently of sorting the static flip multiset.
    current = list(a)
    for x, H in letters:
        assert current[x] == H
        assert all(current[z] == H - 1 for z in (x - 1, x + 1)
                   if 0 <= z < w)
        current[x] -= 2
    assert current == c
    i, j = result['window']
    top = [letter for letter in letters if letter[1] >= n - i]
    middle = [letter for letter in letters if -j <= letter[1] < n - i]
    bottom = [letter for letter in letters if letter[1] < -j]
    assert letters == top + middle + bottom
    groups = [[] for _ in range(t)]
    groups[i].extend(top)
    # Charge every middle letter; optional additional free letters only help.
    for offset, letter in enumerate(middle):
        assert k > 0
        groups[i + offset // k].append(letter)
    groups[j].extend(bottom)
    shots = [{(x, H + day) for x, H in group if 0 <= H + day < n}
             for day, group in enumerate(groups)]
    A = support(w, n, p, a)
    free = []
    for day, (shot, group) in enumerate(zip(shots, groups)):
        assert len(shot) <= k
        free.append(len(group) - len(shot))
        A = neighborhood(w, n, A - shot)
    assert all(y <= b[x] for x, y in A)
    result.update(visible_inspections=sum(map(len, shots)),
                  free_flips=sum(free), daily_free_flips=free,
                  endpoint_size=len(A), physical_containment_verified=True)
    return shots, result


def oracle_schedule(heights, n, t, k):
    """Independent DP over every legal word-prefix split; small inputs only."""
    positions = {0}
    for day in range(t):
        after = set()
        for position in positions:
            after.add(position)
            charged = 0
            for end in range(position, len(heights)):
                charged += 0 <= heights[end] + day < n
                if charged > k:
                    break
                after.add(end + 1)
        positions = after
    return len(heights) in positions


def audit():
    from resumed_even_construction_square_audit import prepare
    data = prepare(6, 6)
    rng = random.Random(202609131)
    checked = 0
    strict = []
    for _ in range(500):
        p = rng.randrange(2)
        t = rng.randrange(1, 10)
        a = list(rng.choice(data['heights'][p]))
        b = list(rng.choice(data['heights'][(p + t) % 2]))
        k = rng.randrange(0, 9)
        result = window(a, b, 6, t, k)
        letters, _ = word(a, b, t)
        expected = oracle_schedule([H for _, H in letters], 6, t, k)
        assert result['feasible'] == expected, (a, b, t, k, result)
        credit = sum(b[x] < 0 and (p + t - x) % 2 == 0 for x in range(6))
        old = len(letters) <= k * t + credit
        assert not old or result['feasible']
        if result['feasible']:
            _, receipt = construct(6, 6, p, a, b, t, k)
            if not old and len(strict) < 5:
                strict.append({'p': p, 'a': a, 'b': b, 't': t, 'k': k,
                               'root_credit': credit, **receipt})
        checked += 1
    return {'cases': checked, 'oracle': 'all fixed-word day partitions',
            'strict_improvements': strict}


def prefix_tail(w, n, k, p, q, right=False):
    shots = []
    A = support(w, n, p, prefix_height(w, n, p, q, right))
    while q:
        remaining = max(0, q - k)
        R = support(w, n, p, prefix_height(w, n, p, remaining, right))
        assert R <= A
        shots.append(A - R)
        A = neighborhood(w, n, R)
        q = len(A)
        p = 1 - p
        assert A == support(w, n, p, prefix_height(w, n, p, q, right))
    return shots


def capture_replay(w, n, k, sequence, full=False):
    A = {(x, y) for x in range(w) for y in range(n)
         if full or (x + y) % 2 == 0}
    first = None
    for day, shot in enumerate(sequence, 1):
        assert len(shot) <= k
        A -= shot
        if not A and first is None:
            first = day
        A = neighborhood(w, n, A)
    assert not A
    return first


def height_neighborhood(w, n, p, a):
    """Exact canonical height vector of the physical neighborhood."""
    out = []
    for x in range(w):
        empty = (1 - p - x) % 2 - 2
        top = n - 1 - ((n - 1 - (1 - p) + x) % 2)
        choices = [empty]
        if a[x] >= 0:
            choices.append(min(top, a[x] + 1))
        for y in (x - 1, x + 1):
            if 0 <= y < w and a[y] >= 0:
                choices.append(a[y])
        out.append(max(choices))
    return out


def clipped_bridge(w, n, p, a, b, t, k, mode='low'):
    """Recompute the exact physical envelope after each day of legal flips."""
    current = list(a)
    shots = []
    for day in range(t):
        phase = (p + day) % 2
        c = [min(x, y - (t - day)) for x, y in zip(current, b)]
        shot = set()
        while True:
            legal = [x for x in range(w) if current[x] > c[x]
                     and all(current[z] == current[x] - 1
                             for z in (x - 1, x + 1) if 0 <= z < w)]
            if not legal:
                break
            invisible = [x for x in legal if current[x] < 0]
            if invisible:
                x = min(invisible, key=lambda x: (current[x], x))
            elif len(shot) < k:
                if mode == 'low':
                    x = min(legal, key=lambda x: (current[x], x))
                elif mode == 'high':
                    x = max(legal, key=lambda x: (current[x], -x))
                elif mode == 'left':
                    x = min(legal)
                elif mode == 'right':
                    x = max(legal)
                elif mode == 'deficit':
                    x = max(legal, key=lambda x: (current[x] - c[x], -current[x], -x))
                else:
                    raise ValueError(mode)
                shot.add((x, current[x]))
            else:
                break
            current[x] -= 2
        current = height_neighborhood(w, n, phase, current)
        shots.append(shot)
    feasible = all(x <= y for x, y in zip(current, b))
    result = {'feasible': feasible, 'mode': mode,
              'excess_height': sum(max(x - y, 0) for x, y in zip(current, b)) // 2,
              'end_heights': current}
    if feasible:
        A = support(w, n, p, a)
        for shot in shots:
            assert len(shot) <= k
            A = neighborhood(w, n, A - shot)
        assert A == support(w, n, (p + t) % 2, current)
        assert all(y <= b[x] for x, y in A)
        result['physical_containment_verified'] = True
    return shots, result


def alternate_bridge(w, n, p, a, b, t, k, mode='low'):
    """A direct legal-flip priority rule; success is an upper certificate only."""
    current = list(a)
    c = [min(x, y - t) for x, y in zip(a, b)]
    shots = []
    flips = 0
    free = 0
    for day in range(t):
        shot = set()
        while True:
            legal = [x for x in range(w) if current[x] > c[x]
                     and all(current[z] == current[x] - 1
                             for z in (x - 1, x + 1) if 0 <= z < w)]
            if not legal:
                break
            invisible = [x for x in legal if not 0 <= current[x] + day < n]
            if invisible:
                x = min(invisible, key=lambda x: (current[x], x))
                free += 1
            elif len(shot) < k:
                if mode == 'low':
                    x = min(legal, key=lambda x: (current[x], x))
                elif mode == 'left':
                    x = min(legal)
                elif mode == 'right':
                    x = max(legal)
                elif mode == 'deficit':
                    x = max(legal, key=lambda x: (current[x] - c[x], -current[x], -x))
                else:
                    raise ValueError(mode)
                shot.add((x, current[x] + day))
            else:
                break
            current[x] -= 2
            flips += 1
        shots.append(shot)
    feasible = current == c
    result = {'feasible': feasible, 'mode': mode,
              'remaining_flips': sum(x - y for x, y in zip(current, c)) // 2,
              'performed_flips': flips, 'free_flips': free}
    if feasible:
        A = support(w, n, p, a)
        for shot in shots:
            assert len(shot) <= k
            A = neighborhood(w, n, A - shot)
        assert all(y <= b[x] for x, y in A)
        result['physical_containment_verified'] = True
    return shots, result


def alternatives(w, n, k, target, cap=250, clipped=False, p0=0):
    """Capped endpoint shortlist, not exhaustive physical search."""
    began = time.monotonic()
    sizes = entrance(w, n, k, p0)
    exits = exit_thresholds(w, n, k, target)
    rows = []
    for end in range(1, target):
        end_phase = (p0 + end) % 2
        q = exits[target - end][1 - end_phase]
        b = prefix_height(w, n, end_phase, q, right=True)
        credit = sum(b[x] < 0 and (end_phase - x) % 2 == 0 for x in range(w))
        for entry in range(min(end, len(sizes))):
            a = prefix_height(w, n, (p0 + entry) % 2, sizes[entry])
            t = end - entry
            F = sum(max(x - y + t, 0) for x, y in zip(a, b)) // 2
            slack = k * t + credit - F
            rows.append((slack, entry, end, q, a, b))
    rows.sort(key=lambda row: (-row[0], row[2] - row[1]))
    results = []
    selected = None
    checks = 0
    for slack, entry, end, q, a, b in rows[:cap]:
        for mode in ('low', 'left', 'right', 'deficit', 'high') if clipped else ('low', 'left', 'right', 'deficit'):
            method = clipped_bridge if clipped else alternate_bridge
            bridge, result = method(w, n, (p0 + entry) % 2, a, b, end - entry, k, mode)
            checks += 1
            row = {'entry': entry, 'end': end, 'q': q, 'old_slack': slack, **result}
            results.append(row)
            if result['feasible']:
                left = prefix_tail(w, n, k, p0, w * n // 2)
                tail = prefix_tail(w, n, k, (p0 + end) % 2, q, right=True)
                solo = left[:entry] + bridge + tail
                if p0:
                    solo = [{(w - 1 - x, y) for x, y in shot} for shot in solo]
                selected = {**row,
                            'solo_capture_day': capture_replay(w, n, k, solo),
                            'full_capture_day': capture_replay(w, n, k, solo + solo[::-1], full=True),
                            'schedule': [sorted(shot) for shot in solo]}
                break
        if selected:
            break
    return {'shape': [w, n], 'budget': k, 'target_solo': target, 'initial_prefix_phase': p0,
            'endpoint_cap': cap, 'priority_rules_checked': checks,
            'selected': selected,
            'closest': sorted(results, key=lambda row: row.get('remaining_flips', row.get('excess_height')))[:5],
            'clipped_each_day': clipped,
            'elapsed_seconds': time.monotonic() - began,
            'scope': 'Capped construction search with specified legal-flip priorities; failure proves no lower bound.'}


def splices(w, n, k, target, p0=0):
    began = time.monotonic()
    sizes = entrance(w, n, k, p0)
    exits = exit_thresholds(w, n, k, target)
    candidates = []
    checked = 0
    old_count = 0
    best = None
    for end in range(1, target):
        end_phase = (p0 + end) % 2
        q = exits[target - end][1 - end_phase]
        b = prefix_height(w, n, end_phase, q, right=True)
        credit = sum(b[x] < 0 and (end_phase - x) % 2 == 0 for x in range(w))
        for entry in range(min(end, len(sizes))):
            a = prefix_height(w, n, (p0 + entry) % 2, sizes[entry])
            t = end - entry
            result = window(a, b, n, t, k)
            checked += 1
            old = result['virtual_flips'] <= k * t + credit
            old_count += old
            assert not old or result['feasible']
            row = {'entry': entry, 'end': end, 't': t, 'q': q,
                   'entry_size': sizes[entry], 'old_root_credit': credit,
                   'old_criterion': old, **result}
            if best is None or row['slack'] > best['slack']:
                best = row
            if result['feasible']:
                candidates.append((row, a, b))
    out = {'shape': [w, n], 'budget': k, 'target_solo': target, 'initial_prefix_phase': p0,
           'anchored_solo': len(sizes), 'checked_splices': checked,
           'successful_splices': len(candidates), 'old_successful_splices': old_count,
           'best': best, 'elapsed_seconds': time.monotonic() - began,
           'scope': 'Necessary and sufficient only for the fixed descending virtual word; these endpoint clocks and splice-index optimization remain restricted.'}
    if candidates:
        row, a, b = max(candidates, key=lambda item: (item[0]['slack'], -item[0]['t']))
        bridge, receipt = construct(w, n, (p0 + row['entry']) % 2, a, b, row['t'], k)
        left = prefix_tail(w, n, k, p0, w * n // 2)
        tail = prefix_tail(w, n, k, (p0 + row['end']) % 2, row['q'], right=True)
        solo = left[:row['entry']] + bridge + tail
        if p0:
            solo = [{(w - 1 - x, y) for x, y in shot} for shot in solo]
        out.update(selected=row, transport=receipt,
                   solo_capture_day=capture_replay(w, n, k, solo),
                   full_capture_day=capture_replay(w, n, k, solo + solo[::-1], full=True),
                   schedule=[sorted(shot) for shot in solo])
    return out


def balanced(w, n):
    """Uniform minimum-budget construction, with no splice-index search."""
    assert w % 2 == 0 and w >= 10 and n >= w
    r = w // 2
    k = r + 1
    QA = r * (n - r) + 2 * r - 2
    QB = r * (n - r) + 3
    t = 2 * r - 5
    entry_phase = (n + 1) % 2
    target_phase = n % 2
    b = prefix_height(w, n, target_phase, QB, right=True)
    assert min(b) >= n - w and max(b) <= n - 3
    choices = []
    schedules = []
    for p0 in (0, 1):
        q = w * n // 2
        p = p0
        e = 0
        while q > QA or p != entry_phase:
            q = neighborhood_count(w, n, p, max(0, q - k))
            p = 1 - p
            e += 1
        assert q in (QA, QA - 1)
        a = prefix_height(w, n, p, q)
        assert min(a) >= n - w + 2
        F = sum(max(x - y + t, 0) for x, y in zip(a, b)) // 2
        assert F == q - QB + r * t <= k * t
        left = prefix_tail(w, n, k, p0, w * n // 2)
        bridge, receipt = construct(w, n, p, a, b, t, k)
        tail = prefix_tail(w, n, k, target_phase, QB, right=True)
        solo = left[:e] + bridge + tail
        if p0:
            solo = [{(w - 1 - x, y) for x, y in shot} for shot in solo]
        solo_day = capture_replay(w, n, k, solo)
        full = solo + solo[::-1]
        if 2 * len(solo[-1]) <= k:
            reflect = lambda shot: {(w - 1 - x, y) for x, y in shot}
            full = solo[:-1] + [solo[-1] | reflect(solo[-1])] + [reflect(s) for s in solo[-2::-1]]
        full_day = capture_replay(w, n, k, full, full=True)
        choices.append({'initial_prefix_phase': p0, 'entry_steps': e,
                        'entry_size': q, 'bridge_steps': t,
                        'target_size': QB, 'tail_steps': len(tail),
                        'solo_days': solo_day, 'full_days': full_day,
                        'final_inspections': len(solo[-1]), 'virtual_flips': F,
                        'physical_replay': True})
        schedules.append((solo, full))
    chosen = min(range(2), key=lambda p: (choices[p]['full_days'], choices[p]['solo_days']))
    solo, full = schedules[chosen]
    return {'shape': [w, n], 'budget': k, 'formula_entry_size': QA,
            'formula_target_size': QB, 'choices': choices, 'selected': choices[chosen],
            'solo_schedule': [sorted(shot) for shot in solo],
            'full_schedule': [sorted(shot) for shot in full],
            'scope': 'Direct uniform upper strategy at minimum budget; entrance and tail are deterministic prefix clocks. No optimality assertion.'}


def balanced_audit():
    from resumed_even_construction_formula_clock import clock
    plateau = 0
    for r in range(2, 20):
        for n in range(2 * r, 2 * r + 8):
            for p in (0, 1):
                for q in range((r - 1) ** 2 + 1, r * (n - r) + r):
                    assert neighborhood_count(2 * r, n, p, q) == q + r
                    plateau += 1
    endpoints = 0
    for r in range(5, 81):
        for n in (2 * r, 2 * r + 1, 2 * r + 2, 3 * r):
            QA = r * (n - r) + 2 * r - 2
            QB = r * (n - r) + 3
            t = 2 * r - 5
            b = prefix_height(2 * r, n, n % 2, QB, True)
            assert min(b) >= n - 2 * r and max(b) <= n - 3
            for q in (QA, QA - 1):
                a = prefix_height(2 * r, n, (n + 1) % 2, q)
                assert min(a) >= n - 2 * r + 2
                F = sum(max(x - y + t, 0) for x, y in zip(a, b)) // 2
                assert F == q - QB + r * t <= (r + 1) * t
                endpoints += 1
    rows = []
    for w, n in ((10, 10), (10, 11), (12, 12), (12, 13), (12, 14),
                 (14, 14), (14, 15), (16, 16), (16, 17), (16, 18),
                 (20, 20), (20, 21), (24, 24), (24, 25), (24, 26), (28, 28), (32, 32)):
        result = balanced(w, n)
        Path(f'research/bridge-upper-transport-uniform-{w}x{n}.json').write_text(json.dumps(result, indent=2) + '\n')
        tau, sizes, _ = clock(w, n, w // 2 + 1, critical=True)
        lower = 2 * tau - (2 * sizes[-1] <= w // 2 + 1)
        if (w, n) == (24, 24):
            lower = max(lower, 206)
        row = {'shape': [w, n], 'budget': w // 2 + 1,
               'critical_model_solo_lower': tau, 'known_full_lower': lower,
               'uniform_upper': result['selected']['full_days'],
               'gap': result['selected']['full_days'] - lower,
               'choices': result['choices']}
        assert row['gap'] >= 0
        rows.append(row)
    return {'plateau_values_checked': plateau, 'endpoint_pairs_checked': endpoints,
            'physical_full_board_replays': 2 * len(rows), 'rows': rows,
            'scope': 'Finite validation of a uniform theorem, not a replacement for its proof. Root critical corner-model lower, with existing physical amendment on24x24.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--audit', action='store_true')
    parser.add_argument('--w', type=int, default=24)
    parser.add_argument('--n', type=int)
    parser.add_argument('--k', type=int, default=13)
    parser.add_argument('--target', type=int, default=103)
    parser.add_argument('--alternatives', action='store_true')
    parser.add_argument('--clipped', action='store_true')
    parser.add_argument('--cap', type=int, default=250)
    parser.add_argument('--phase', type=int, choices=(0, 1), default=0)
    parser.add_argument('--balanced', action='store_true')
    parser.add_argument('--balanced-audit', action='store_true')
    args = parser.parse_args()
    if args.balanced_audit:
        output = balanced_audit()
        name = 'bridge-upper-transport-uniform-audit.json'
    elif args.balanced:
        output = balanced(args.w, args.n or args.w)
        name = f'bridge-upper-transport-uniform-{args.w}x{args.n or args.w}.json'
    elif args.audit:
        output = audit()
        name = 'bridge-upper-transport-audit.json'
    elif args.alternatives:
        output = alternatives(args.w, args.n or args.w, args.k, args.target, args.cap, args.clipped, args.phase)
        kind = 'clipped' if args.clipped else 'alternative'
        name = f'bridge-upper-transport-{kind}-{args.w}x{args.n or args.w}-k{args.k}-t{args.target}.json'
    else:
        output = splices(args.w, args.n or args.w, args.k, args.target, args.phase)
        name = f'bridge-upper-transport-{args.w}x{args.n or args.w}-k{args.k}-t{args.target}.json'
    if args.phase and not args.audit:
        name = name.replace('.json', '-p1.json')
    Path('research', name).write_text(json.dumps(output, indent=2) + '\n')
    print({key: value for key, value in output.items() if key not in ('schedule', 'solo_schedule', 'full_schedule')})

"""Evaluate exact odd-rectangle solo times through O(width) translation bands.
Research implementation; full two-cohort scalar midpoint necessity is unproved.
"""
from math import isqrt
from dataclasses import dataclass

def R(k):
    return isqrt(k)+(isqrt(k)**2<k)

def rho(k):
    s=(isqrt(4*k+1)-1)//2
    return s+(s*(s+1)<k)

@dataclass
class OddRectangle:
    w:int
    n:int
    def __post_init__(self):
        assert 3<=self.w<=self.n and self.w%2==self.n%2==1
        self.b=(self.w-1)//2
        self.E=(self.w*self.n+1)//2
        self.M=self.E-1
        self.C=(self.E,self.M)
    def profile(self,p,k):
        assert 0<=k<=self.C[p]
        if not k:return 0
        if p==0:return k+min(R(k),self.b,R(self.E-k)-1)
        return k+min(rho(k)+1,self.b+1,rho(self.M-k)+1)
    def inverse(self,p,z):
        if z<0:return -1
        if z>=self.C[1-p]:return self.C[p]
        if p==0:return z-min(rho(z),self.b,rho(self.M-z))
        return z-min(R(z),self.b+1,1+R(self.E-z))
    def breaks(self,p):
        if p==0:
            B={r*r+1 for r in range(self.b)}|{self.E-r*r for r in range(self.b+1)}
        else:
            B={r*(r-1)+1 for r in range(1,self.b+1)}|{self.M-r*(r-1) for r in range(1,self.b+1)}
        return sorted({1}|{k for k in B if 1<=k<=self.C[p]})
    def step(self,p,k,m):
        return self.profile(p,max(0,k-m))
    def pair_bands(self,p,m):
        assert m>=self.b+1
        # Up to this count the cohort disappears within at most two days.
        cutoff=min(self.C[p],m+self.inverse(p,m))
        # Positive part of the paired map has the form k -> k - d.
        edges={cutoff+1,self.C[p]+1}
        edges.update(m+s for s in self.breaks(p))
        edges.update(m+self.inverse(p,m+s-1)+1 for s in self.breaks(1-p))
        edges=sorted(x for x in edges if cutoff+1<=x<=self.C[p]+1)
        bands=[]
        for lo,hi in zip(edges,edges[1:]):
            hi-=1
            if lo>hi:continue
            after=self.step(1-p,self.step(p,lo,m),m)
            d=lo-after
            assert 1<=d and after>0
            assert self.step(1-p,self.step(p,hi,m),m)==hi-d
            if bands and bands[-1][2]==d and bands[-1][1]+1==lo:
                bands[-1]=(bands[-1][0],hi,d)
            else:bands.append((lo,hi,d))
        return cutoff,bands
    def solo(self,p,m,start=None,at_day=None):
        """Exact solo duration, or exact remaining count after at_day days.
        Starting count may be any canonical one-color prefix.
        """
        assert m>=self.b+1
        k=self.C[p] if start is None else start
        assert 0<=k<=self.C[p]
        if k==0:return {'time':0,'count':0,'segments':[],'band_count':0} if at_day is None else 0
        cutoff,bands=self.pair_bands(p,m)
        pairs=0;segments=[]
        for lo,hi,d in reversed(bands):
            if k<lo:continue
            assert k<=hi
            take=(k-lo)//d+1
            if at_day is not None:
                take=min(take,max(0,at_day//2-pairs))
            segments.append((2*pairs,k,take,d,lo,hi))
            k-=take*d;pairs+=take
            if at_day is not None and pairs==at_day//2:
                return self.step(p,k,m) if at_day%2 else k
        assert k<=cutoff
        tail=0 if k==0 else 1 if k<=m else 2
        if at_day is not None:
            left=at_day-2*pairs
            if left==0:return k
            return self.step(p,k,m) if left==1 else 0
        return {'time':2*pairs+tail,'count':k,'segments':segments,'band_count':len(bands)}
    def half_time(self,m):
        if m<self.b+1:return None
        times=[self.solo(p,m)['time'] for p in (0,1)]
        tau=min(times); t=tau-1
        residual=[self.solo(p^(t%2),m,at_day=t) for p in (0,1)]
        return {'solo_times':times,'tau':tau,'precentral_residuals':residual,
                'lower':2*tau-1,'upper':2*tau,
                'short_sufficient':sum(residual)<=m,
                'scalar_candidate':2*tau-int(sum(residual)<=m)}

if __name__=='__main__':
    import argparse,json
    P=argparse.ArgumentParser();P.add_argument('width',type=int);P.add_argument('length',type=int);P.add_argument('budget',type=int)
    a=P.parse_args();G=OddRectangle(a.width,a.length)
    print(json.dumps(G.half_time(a.budget),indent=2))

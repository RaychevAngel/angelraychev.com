"""Scalar-only screening of the finite linear-budget complement.

No joint solver is called. Each filter is an accepted sufficient theorem.
The deadline orientation guard is the onset argument on the last W steps.
"""
from collections import Counter
from math import isqrt
from pathlib import Path
from time import process_time
import hashlib
import json

from supersession_solo_bands import OddRectangle
from bridge_odd_clock_linear_budget import constants as linear_constants
from bridge_odd_clock_orientation_onset import constants as old_constants


def ceildiv(x,y):
    return (x+y-1)//y


def root(z):
    return isqrt(z)+int(isqrt(z)**2<z)


def improved_constants(b,m):
    old=old_constants(b,m)
    fixed=linear_constants(b,m)
    q=max(root(b),ceildiv(m-1,b-1))
    r=ceildiv(q*(b+1)+m-1,2*q)
    assert 1<=r<=b and q*(2*r-b-1)>=m-1
    adaptive=(q-1)*m+r*(r-1)
    K=min(old['K'],fixed['K'],adaptive)
    J=max(2*K+m+1,K+b*b+1)
    W=2*root(m-1)
    return dict(K=K,J=J,W=W,onset=J+m-1+m*(W+1),
                adaptive_q=q,adaptive_r=r,adaptive_K=adaptive)


def filter_case(w,n,m,params):
    G=OddRectangle(w,n)
    if G.M>=params['onset']:
        return dict(reason='adaptive_onset')
    # Cache the two independent band constructions for all prescribed days.
    bands={p:G.pair_bands(p,m) for p in (0,1)}
    G.pair_bands=lambda p,mm: bands[p]
    info=G.half_time(m)
    base=dict(tau=info['tau'],scalar_time=info['scalar_candidate'])
    if info['short_sufficient']:
        return dict(reason='physical_short_sufficient',**base)
    L=info['tau']-1
    D={L:tuple(G.C[p]-info['precentral_residuals'][p] for p in (0,1))}
    def deficit(t):
        if t not in D:
            D[t]=tuple(G.C[p]-G.solo(p^(t%2),m,at_day=t) for p in (0,1))
        return D[t]
    if D[L][0]==D[L][1]:
        return dict(reason='final_tie',**base)
    if L>=params['W'] and min(deficit(L-params['W']))>=params['J']:
        return dict(reason='deadline_orientation',**base)
    secondary=int(D[L][0]>D[L][1])
    critical=ceildiv(G.C[secondary]-m,2)
    short=(0,0)
    for age in range(17):
        if age:
            short=(G.inverse(0,short[1]+m),G.inverse(1,short[0]+m))
        i=L-age
        if i<0 or short[secondary]>=critical:
            break
        current=deficit(i)
        previous=(0,0) if i==0 else deficit(i-1)
        gap=current[0]-current[1]
        oldgap=previous[0]-previous[1]
        if gap*oldgap>=0:
            return dict(reason='recent_reset',reset_age=age,**base)
    return dict(reason='unresolved',solo_deficits=D[L],**base)


def main():
    started=process_time()
    source=Path('research/bridge-odd-clock-linear-budget-complement.json')
    regions=json.loads(source.read_text())['rows']
    counts=Counter();unresolved=[]
    for region in regions:
        w,m=region['width'],region['budget']
        params=improved_constants((w-1)//2,m)
        for n in range(region['first_length'],region['last_length']+1,2):
            row=filter_case(w,n,m,params)
            counts[row['reason']]+=1
            if row['reason']=='unresolved':
                unresolved.append(dict(width=w,length=n,budget=m,**params,**row))
    out=dict(status='PASS',scope=__doc__,
             source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             complement_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
             counts=dict(counts),unresolved=unresolved,seconds=process_time()-started)
    Path('research/bridge-odd-clock-linear-budget-filter.json').write_text(
        json.dumps(out,indent=2)+'\n')
    print(dict(status='PASS',counts=dict(counts),seconds=out['seconds'],
               unresolved_width_range=([min(r['width'] for r in unresolved),
                                        max(r['width'] for r in unresolved)] if unresolved else None)))


if __name__=='__main__':
    main()

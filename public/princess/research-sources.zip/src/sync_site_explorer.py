"""Copy replayed strategy data into the native Astro website component."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
site = root.parent / "polyominoes" / "website"
source = (root / "website" / "data.js").read_text()
assert source.startswith("const STRATEGIES = ")
target = site / "src" / "lib" / "princess-strategies.js"
target.write_text("// Generated from the Princess project; every schedule is independently replayed.\n" + source.replace("const STRATEGIES = ", "export default ", 1))
print(f"Updated {target}")

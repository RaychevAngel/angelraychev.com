"""Bounded prefix-endpoint repairs with a separately prescribed last quota."""
from pathlib import Path
import hashlib
import json
import time

from bridge_upper_transport import (
    alternate_bridge, capture_replay, clipped_bridge, construct, entrance,
    prefix_height, prefix_tail, window,
)
from resumed_even_construction_prefix_arithmetic import erosion_count


def repair(w, n, k, days, last, endpoint_cap=250):
    begin = time.process_time()
    h = w * n // 2
    exits = [(0, 0), (last, last)]
    for _ in range(days - 1):
        previous = exits[-1]
        exits.append(tuple(min(h, k + erosion_count(w, n, 1 - p, previous[1 - p]))
                           for p in (0, 1)))
    candidates = []
    for p0 in (0, 1):
        sizes = entrance(w, n, k, p0)
        for end in range(1, days):
            phase = (p0 + end) % 2
            q = exits[days - end][1 - phase]
            target = prefix_height(w, n, phase, q, right=True)
            for entry in range(min(end, len(sizes))):
                source = prefix_height(w, n, (p0 + entry) % 2, sizes[entry])
                duration = end - entry
                test = window(source, target, n, duration, k)
                candidates.append((test['slack'], p0, entry, end, q, source, target))
    candidates.sort(key=lambda row: (-row[0], row[3] - row[2]))
    tries = 0
    best_remaining = None
    selected = None
    for slack, p0, entry, end, q, source, target in candidates[:endpoint_cap]:
        methods = [('descending', None)] if slack >= 0 else [
            ('alternate', mode) for mode in ('low', 'left', 'right', 'deficit')
        ] + [('clipped', mode) for mode in ('low', 'left', 'right', 'deficit', 'high')]
        for method, mode in methods:
            tries += 1
            if method == 'descending':
                bridge, detail = construct(w, n, (p0 + entry) % 2, source, target, end - entry, k)
            else:
                function = alternate_bridge if method == 'alternate' else clipped_bridge
                bridge, detail = function(w, n, (p0 + entry) % 2, source, target, end - entry, k, mode)
            remainder = detail.get('remaining_flips', detail.get('excess_height', 0))
            if best_remaining is None or remainder < best_remaining:
                best_remaining = remainder
            if not detail['feasible']:
                continue
            solo = prefix_tail(w, n, k, p0, h)[:entry] + bridge + prefix_tail(w, n, k, (p0 + end) % 2, q, True)
            if p0:
                solo = [{(w - 1 - x, y) for x, y in shot} for shot in solo]
            assert len(solo) <= days
            assert len(solo) < days or len(solo[-1]) <= last
            solo_capture = capture_replay(w, n, k, solo)
            reflect = lambda shot: {(w - 1 - x, y) for x, y in shot}
            full = solo + solo[::-1]
            if 2 * len(solo[-1]) <= k:
                full = solo[:-1] + [solo[-1] | reflect(solo[-1])] + [reflect(shot) for shot in solo[-2::-1]]
            full_capture = capture_replay(w, n, k, full, full=True)
            selected = dict(initial_phase=p0, entry=entry, end=end, target_size=q,
                            method=method, priority=mode, fixed_word_slack=slack,
                            solo_days=solo_capture, last_size=len(solo[-1]), full_days=full_capture,
                            bridge=detail, solo_shots=[sorted(s) for s in solo],
                            full_shots=[sorted(s) for s in full[:full_capture]])
            break
        if selected:
            break
    return dict(shape=[w, n], budget=k, target_solo=days, target_last=last,
                endpoint_cap=endpoint_cap, available_endpoint_pairs=len(candidates),
                method_trials=tries, best_remaining=best_remaining,
                best_fixed_word_slack=candidates[0][0], selected=selected,
                CPU_seconds=time.process_time() - begin)


if __name__ == '__main__':
    cases = [(24, 27, 25, 21, 12), (28, 28, 28, 22, 28)]
    results = []
    for case in cases:
        row = repair(*case)
        results.append(row)
        print(json.dumps({k: v for k, v in row.items() if k != 'selected'}), flush=True)
        if row['selected']:
            print(json.dumps({k: v for k, v in row['selected'].items() if 'shots' not in k}), flush=True)
        output = dict(scope=__doc__, failure_is_no_lower_bound=True,
                      source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                                     for p in (Path(__file__), Path('src/bridge_upper_transport.py'))}, rows=results)
        Path('research/bridge-upper-transport-budget-repairs.json').write_text(json.dumps(output, indent=2) + '\n')

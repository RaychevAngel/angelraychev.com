"""Necessary transitions tracking own corners and eroded opposite corners.

The refined capacity and state transition rule are ordinary proof inputs
under parent review. No geometric sufficiency or merger closure is assumed.
"""
from pathlib import Path
import argparse,json,time
from resumed_even_construction_formula_profile import F
from resumed_odd_even_corner_potential import root,rho
from resumed_odd_even_corner_history import solo_certificate,joint_bfs,audit_joint


def one_neighbor(s):
    if s<0:return -10**12
    return s*(s-1)//2 if s<=4 else s*(s-3)+1


def low(i,j,u,s):
    if not 0<=u<=j<=2 or not 0<=i<=2 or s<i+2*j:return -10**12
    z=s-i-2*j;base=i+j+u
    if u:return base+z*z+3*z
    if i:return base+z*z+2*z
    if j:return base+one_neighbor(z+2)-1
    return max(s*(s-1)//2,s*(s-2))


def build(b,n,m,closed=False,triangle=False,maximal=False,dual=False,compact=False,all_radii=False,band_memory=False,band_dual=False):
    assert b>=2 and n%2==0 and n>=2*b+1
    h=(2*b+1)*n//2
    states=[(k,c,e)for k in range(h+1)for c in range(3)for e in range(3)
            if c+2*e<=k<=h-4+c+e]
    ids={s:i for i,s in enumerate(states)};edges=set()
    radii=tuple(range(2,b+1)) if all_radii else (b,)
    flags={r:len(states)+offset for offset,r in enumerate(radii)} if triangle else {}
    C=b*(b-1);D=max(C//2,b*(b-2))
    band_flags={a:len(states)+len(flags)+offset for offset,a in enumerate(range(h-C,h-D))}if band_memory else{}
    masks=[0]*(len(states)+len(flags)+len(band_flags))
    def add(a,d,p,trigger=None):
        if compact:masks[a]|=1<<(trigger if trigger is not None else d)
        else:edges.add((a,d,p,trigger))
    for (k,c,e),a in ids.items():
        for p in range(min(m,k)+1):
            q=k-p
            if q==0:
                add(a,ids[(0,0,0)],p);continue
            start=min(root(q),b,rho(h-q))
            for i in range(max(0,c-p),c+1):
                for u in range(max(0,e-(p-c+i)),e+1):
                    if not i+2*u<=q<=h-4+i+u:continue
                    for s in range(start,h-q+1):
                        t=q+s
                        for j in range(u,3):
                            for ee in range(i,3):
                                if maximal and i<max(0,c+ee-2):continue
                                target=(t,j,ee)
                                if target not in ids:continue
                                if dual and s in radii and q==h-s*s and j==2 and(i,u,ee)!=(1,2,1):continue
                                if band_dual and j==2 and h-C<=t<h-D and s<=b:
                                    if s!=b or(i,u,ee)!=(1,2,1):continue
                                trigger=flags.get(s) if q==s*(s-1) and i==0 else None
                                if trigger is not None and(j,ee)!=(1,0):continue
                                if j==2 and t in band_flags and s<=b:
                                    if ee!=1:continue
                                    trigger=band_flags[t]
                                delta=ee-i if closed else 0
                                ss=s-delta;ii=i+delta
                                if ss<0:continue
                                if ss<=b:
                                    small=q+delta<=low(ii,j,u,ss)
                                    large=h-q-s<=F(2-j,2-ee,s+i-ee)
                                    critical=ss==b and(ii,j)==(2,0)
                                    if not(small or large or critical):continue
                                add(a,ids[target],p,trigger)
    if triangle or band_memory:
        states.extend((r*r,1,0,4) for r in flags)
        states.extend((a,2,1,5)for a in band_flags)
        if compact:
            no_corner=sum(1<<d for d,state in enumerate(states)if state[1]==0)
            for r,extra in flags.items():masks[extra]=masks[ids[(r*r,1,0)]]&no_corner
            forbidden=sum(1<<d for d in band_flags.values())
            for a,extra in band_flags.items():masks[extra]=masks[ids[(a,2,1)]]&~forbidden
            return states,masks
        result=[(a,flag if flag is not None else d,p)for a,d,p,flag in edges]
        for r,extra in flags.items():
            base=ids[(r*r,1,0)]
            result +=[(extra,flag if flag is not None else d,p)for a,d,p,flag in edges
                      if a==base and states[d][1]==0]
        forbidden=set(band_flags.values())
        for size,extra in band_flags.items():
            base=ids[(size,2,1)]
            result +=[(extra,flag if flag is not None else d,p)for a,d,p,flag in edges
                      if a==base and flag not in forbidden]
    else:
        if compact:return states,masks
        result=[(a,d,p)for a,d,p,flag in edges]
    return states,sorted(set(result))


def run(b,n,m,closed=False,joint=False,audit=False,triangle=False,maximal=False,dual=False,all_radii=False,band_memory=False,band_dual=False):
    started=time.process_time();ss,ee=build(b,n,m,closed,triangle,maximal,dual,all_radii=all_radii,band_memory=band_memory,band_dual=band_dual);h=(2*b+1)*n//2
    result={'width':2*b+1,'length':n,'budget':m,'corner_closure_used':closed,
            'uniform_pronic_memory':triangle,
            'maximal_survivor_corner_intersection':maximal,
            'uniform_dual_pronic_rule':dual,
            'pronic_radii':list(range(2,b+1))if all_radii else[b],
            'uniform_near_pronic_band_memory':band_memory,
            'uniform_near_pronic_band_dual':band_dual,
            'states':len(ss),'cohort_transitions':len(ee),
            'scope':'Necessary physical transition model, conditional on the refined erosion-corner proof; no sufficiency assertion.'}
    result.update(solo_certificate(ss,ee,h,(h,2,2)))
    if joint:result.update(joint_bfs(ss,ee,m,h,(h,2,2)))
    if audit:result.update(audit_joint(ss,ee,m,h,(h,2,2)))
    result['cpu_seconds']=time.process_time()-started
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cases',default='3,8,4;4,10,5')
    p.add_argument('--closed',action='store_true');p.add_argument('--joint',action='store_true')
    p.add_argument('--audit',action='store_true')
    p.add_argument('--triangle-memory',action='store_true')
    p.add_argument('--maximal',action='store_true')
    p.add_argument('--dual-pronic',action='store_true')
    p.add_argument('--all-pronic-radii',action='store_true')
    p.add_argument('--band-memory',action='store_true')
    p.add_argument('--band-dual',action='store_true')
    p.add_argument('--output',default='research/resumed-odd-even-erosion-corners.json')
    a=p.parse_args();results=[]
    for case in a.cases.split(';'):
        r=run(*map(int,case.split(',')),closed=a.closed,joint=a.joint,audit=a.audit,triangle=a.triangle_memory,maximal=a.maximal,dual=a.dual_pronic,all_radii=a.all_pronic_radii,band_memory=a.band_memory,band_dual=a.band_dual);results.append(r)
        print({k:v for k,v in r.items()if k not in('solo_optimal_layers','solo_forward_lower_potential','solo_backward_lower_potential','relaxed_path','joint_integer_potential','joint_potential_states')},flush=True)
    Path(a.output).write_text(json.dumps({'results':results},indent=2)+'\n')

"""Publish the ratified scope assessment without maintaining a second account."""
from pathlib import Path
import json, re
from publication_paths import SITE
ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT/'publication/manuscript-scope.json').read_text())
owners = manifest['label_roles']

def public_text(source):
    text = source.replace('\\[', '$$').replace('\\]', '$$').replace('\\(', '$').replace('\\)', '$')
    text = re.sub(r'\[([^\]]+)\]\((?:research/)?CLASSIFICATION_SCOPE.md\)', r'[\1](/princess/scope.md)', text)
    text = re.sub(r'\[([^\]]+)\]\((?:research/)?RECTANGLE_COVERAGE.md\)', r'[\1](/princess/coverage/)', text)
    text = re.sub(r'\[([^\]]+)\]\((?:research/)?RECTANGLE_GAPS.md\)', r'[\1](/princess/gaps/)', text)
    def theorem(match):
        key = match.group(1)
        route = '/princess/extensions/proofs/' if owners.get(key) == 'extensions' else '/princess/proofs/'
        return f'[{key}]({route}#{key})'
    return re.sub(r'`((?:thm|lem|lemma|prop|cor|eq|sec):[^`]+)`', theorem, text)

for slug, filename, title, desc in [
    ('coverage', 'RECTANGLE_COVERAGE.md', 'Rectangle capture time: exact coverage', 'Accepted formulas, exact evaluators, direct strategies and the precise remaining parameter ranges.'),
    ('gaps', 'RECTANGLE_GAPS.md', 'Rectangle capture time: remaining gaps', 'Documented attempts, failures, dependencies and proposed directions under the fixed-size numerical goal.')]:
    source = (ROOT/'research'/filename).read_text()
    body = source.split('\n', 1)[1].lstrip()
    front = f'''---
layout: "../../layouts/Post.astro"
title: "{title}"
description: "{desc}"
updated: 2026-09-13
---

[Rectangle overview](/princess/) · [Exact coverage](/princess/coverage/) · [Remaining gaps](/princess/gaps/) · [Manuscript](/princess/paper/) · [Parked extensions](/princess/extensions/)

This page is generated from the private project's canonical assessment. Named research files and certificates are preserved in the [mathematical sources package](/princess/research-sources.zip); theorem links lead to the current manuscript-derived proofs. [Download this assessment](/princess/{'rectangle-coverage' if slug == 'coverage' else 'rectangle-gaps'}.md).

'''
    (SITE/'src/pages/princess'/f'{slug}.md').write_text(front + public_text(body))

artifacts = json.loads((ROOT/'publication/artifact-manifest.json').read_text())['files']
lines = ['# Parked extensions: source index', '',
    'The companion is parked. Read [HANDOFF.md](HANDOFF.md) before any resumption. The main rectangle completion criterion is not enlarged by these independent applications.', '',
    'Canonical source files remain in one dependency-preserving tree. The companion manuscript is [extensions.tex](../paper/extensions.tex); its public home is [/princess/extensions/](https://angelraychev.com/princess/extensions/). The following index is generated from the publication membership manifest. Shared files are listed separately; package inclusion never creates a second authoritative proof source.', '']
for kind, label in [('parked', 'Independent applications and preserved evidence'), ('shared', 'Shared dependencies and publication infrastructure')]:
    lines += ['## ' + label, '']
    lines += [f'- [{name}](../{name})' for name, row in sorted(artifacts.items()) if row['scope'] == kind]
    lines += ['']
(ROOT/'extensions/README.md').write_text('\n'.join(lines))
print('Published canonical coverage/gap pages and the parked source index.')

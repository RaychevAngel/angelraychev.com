"""Physical certificates for the P4^5 prefix-family feasibility obstruction."""
from itertools import product
from pathlib import Path
from time import process_time
import json


def prefix_data(shape):
    vertices = list(product(*(range(n) for n in shape)))
    orders = [sorted((v for v in vertices if sum(v) % 2 == p),
                     key=lambda v: (sum(v), tuple(-x for x in v))) for p in (0, 1)]
    rank = [{v: i for i, v in enumerate(row)} for row in orders]
    profiles = []
    for p in (0, 1):
        neighbors = set()
        profile = [0]
        for v in orders[p]:
            for axis, n in enumerate(shape):
                for step in (-1, 1):
                    w = list(v)
                    w[axis] += step
                    if 0 <= w[axis] < n:
                        neighbors.add(rank[1 - p][tuple(w)])
            assert max(neighbors, default=-1) + 1 == len(neighbors)
            profile.append(len(neighbors))
        profiles.append(profile)
    return vertices, orders, profiles


def run():
    start = process_time()
    shape = (4,) * 5
    vertices, orders, profiles = prefix_data(shape)
    assert len(orders[0]) == len(orders[1]) == 512
    u = max(min(a, b) - k for k, (a, b) in enumerate(zip(*profiles)))
    assert u == 88
    assert profiles[0][242] == 329
    assert profiles[1][240] == 331
    assert profiles[0][240] == profiles[0][241] == 328
    source = set(orders[0][:240])
    target = set(orders[1][:330])
    # Analytic noncontainment only needs these layer counts. Coordinate
    # permutations leave them unchanged; odd reflections have1,3,or5 axes.
    assert {v for v in orders[0] if sum(v) <= 6} <= source
    high_slots = sum(sum(v) == 9 for v in target)
    assert high_slots == 34 and max(map(sum, target)) == 9
    for reflected_axis in range(5):
        slice_rooms = {v for v in source if sum(v) == 6 and v[reflected_axis] == 0}
        assert len(slice_rooms) == 44
        assert all(sum(v) + 3 - 2 * v[reflected_axis] == 9 for v in slice_rooms)
    # For three reflections, set each unreflected coordinate to3 and the
    # reflected coordinates to0. It lies in source and maps to weight15.
    for reflected in product((0, 1), repeat=5):
        if sum(reflected) == 3:
            v = tuple(0 if flag else 3 for flag in reflected)
            assert v in source and sum(3 - x if flag else x for x, flag in zip(v, reflected)) == 15
        elif sum(reflected) == 5:
            assert (0,) * 5 in source

    # Abstract orbit barrier, checked for every phase/cardinality/survivor
    # possibility. The only exceptional transitions are ruled out by the
    # preceding geometric noncontainment, not an assumed normal form.
    barriers = (331, 329)
    checked = 0
    excluded = set()
    for p in (0, 1):
        for k in range(barriers[p], 513):
            for q in (0, 1):
                for r in range(max(k - 89, 0), k + 1):
                    if profiles[q][r] < barriers[1 - q]:
                        assert p == 1 and q == 0 and k <= 330 and r >= 240
                        excluded.add((p, k, q, r))
                    checked += 1
    assert excluded == {(1, 329, 0, 240), (1, 329, 0, 241), (1, 330, 0, 241)}

    def neighborhood(support):
        result = set()
        for v in support:
            for axis in range(5):
                for step in (-1, 1):
                    w = list(v)
                    w[axis] += step
                    if 0 <= w[axis] < 4:
                        result.add(tuple(w))
        return result
    trajectories = []
    schedules = []
    for initial in (0, 1):
        p = initial
        actual = set(orders[p])
        trajectory = []
        shots = []
        while actual:
            k = len(actual)
            residual = set(orders[p][:max(k - 90, 0)])
            assert residual <= actual
            shot = actual - residual
            assert len(shot) <= 90
            trajectory.append((p, k, len(shot), len(residual)))
            shots.append(shot)
            actual = neighborhood(residual)
            p = 1 - p
            assert actual == set(orders[p][:len(actual)])
        trajectories.append(trajectory)
        schedules.append(shots)
    assert list(map(len, schedules)) == [96, 97]
    # Both physical cohorts can use the96-day phase0 schedule: after the
    # first96 days the other color is full and a one-axis reflection flips
    # its intrinsic phase. Replay on the full1024-room board.
    reflection = lambda v: (3 - v[0],) + v[1:]
    complete = schedules[0] + [{reflection(v) for v in shot} for shot in schedules[0]]
    actual = set(vertices)
    for shot in complete:
        assert len(shot) <= 90
        actual = neighborhood(actual - shot)
    assert not actual
    return {'shape': shape, 'profile_neighborhood_closed': True,
            'profiles': profiles, 'minimum_profile_max_surplus': u,
            'candidate_static_bound': u + 1,
            'exact_prefix_family_hunter_number': 90,
            'barrier_thresholds_by_intrinsic_phase': barriers,
            'abstract_transition_checks': checked,
            'geometrically_excluded_transitions': sorted(excluded),
            'one_reflection_source_weight9_rooms': 44,
            'target_weight9_capacity': high_slots,
            'budget90_cohort_trajectories': trajectories,
            'full_board_budget90_replay_days': len(complete),
            'full_board_physical_replay_passed': True,
            'CPU_seconds': process_time() - start,
            'scope': 'Exact hunter number only within all reflected/permuted weightlex-prefix survivors. Unrestricted hunter number at89 is unresolved.'}


if __name__ == '__main__':
    result = run()
    destination = Path(__file__).resolve().parents[1] / 'research/even-bridge-feasibility-prefix-4power5.json'
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('profiles', 'budget90_cohort_trajectories')}, indent=2))

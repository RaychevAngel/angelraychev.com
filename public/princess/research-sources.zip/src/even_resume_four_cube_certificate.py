"""Small exact charged-potential certificate for the critical 4-cube budget."""
from heapq import heappop, heappush
from itertools import product
from pathlib import Path
import json
import sys
from pyramidal_time import prepare, replay

ROOT=Path(__file__).resolve().parents[1]
CHARGE=(0,0,0,0,1,2,2,2,2)  # scale two


def main(shape=(4,4,4), odd_paths=False, stem='four-cube-critical'):
    charges=tuple(range(9)) if shape==(3,4,4) else CHARGE
    scale=max(charges[a]+charges[b] for a in range(9) for b in range(9-a))
    data=prepare(shape,odd_paths=odd_paths); counts=[len(row) for row in data['ideals']]
    assert counts[0]==counts[1]
    number=counts[0]
    reverse=[[] for _ in range(sum(counts))]
    transitions=[]
    for p in(0,1):
        for a,A in enumerate(data['ideals'][p]):
            for r,R in enumerate(data['ideals'][p]):
                quota=A.bit_count()-R.bit_count()
                if 0<=quota<=8 and R&A==R:
                    target=(1-p)*number+data['hood'][p][r]
                    reverse[target].append((p*number+a,charges[quota]))
                    transitions.append((p*number+a,target,quota))
    potential=[10**9]*sum(counts);queue=[]
    for p in(0,1):potential[p*number]=0;heappush(queue,(0,p*number))
    while queue:
        cost,v=heappop(queue)
        if potential[v]!=cost:continue
        for a,charge in reverse[v]:
            if cost+charge<potential[a]:
                potential[a]=cost+charge;heappush(queue,(potential[a],a))
    # The following direct inequalities are the certificate, independent of
    # the shortest-path method used to discover the integer values.
    assert potential[number-1]==potential[-1]
    initial=potential[number-1]
    expected=(2*initial+scale-1)//scale
    assert potential[0]==potential[number]==0 and min(potential)>=0
    assert all(charges[a]+charges[b]<=scale for a in range(9) for b in range(9-a))
    for a,b,q in transitions:assert potential[a]<=potential[b]+charges[q]

    coords=list(product(*(range(side) for side in shape)))
    orders=[sorted([v for v in coords if sum(v)%2==p],key=lambda v:(sum(v),tuple(-x for x in v)))for p in(0,1)]
    def hood(S):
        return {w for v in S for w in coords if sum(abs(a-b)for a,b in zip(v,w))==1}
    belief=set(coords);shots=[];paths=[]
    for cohort in(0,1):
        logical=0;b=len(coords)//2;path=[b]
        flip=(cohort+len(shots))%2
        axis=next(i for i,side in enumerate(shape) if side%2==0)
        def transform(v):
            if not flip:return v
            w=list(v);w[axis]=shape[axis]-1-w[axis];return tuple(w)
        while b:
            before={transform(v) for v in orders[logical][:b]}
            residual={transform(v) for v in orders[logical][:max(b-8,0)]}
            assert before<=belief
            shot=before-residual;assert len(shot)<=8
            belief=hood(belief-shot);shots.append(sorted(shot))
            b=len(hood(residual));logical=1-logical;path.append(b)
        paths.append(path)
    assert not belief and len(shots)==expected, (shape, expected, len(shots))
    replay(shape,8,shots)
    result={'shape':list(shape),'budget':8,'minimum_turns':expected,
            'scope':'Exact finite charged-potential lower proof on the proved compression family, plus physical prefix upper. Ordinary, not Lean.',
            'charges':charges,'daily_charge_bound':scale,'initial_potentials':[initial,initial],
            'potential_inequalities_checked':len(transitions),
            'canonical_masks':data['ideals'],'potentials':[potential[:number],potential[number:]],
            'compact_cohort_count_paths':paths,'physical_shots':shots,
            'geometric_explanation':'Independent reflection in an even axis lets each cohort start the chosen weightlex parity; both solo lengths agree.'}
    if shape==(4,4,4):
        result.update(charges_scaled_by_two=charges,initial_potential_scaled_by_two=[initial,initial],
                      potentials_scaled_by_two=[potential[:number],potential[number:]])
    (ROOT/f'research/even-resume-{stem}-certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in('canonical_masks','potentials','potentials_scaled_by_two','physical_shots')}))

if __name__=='__main__':
    if sys.argv[-1]=='344':main((3,4,4),True,'three-four-four-eight-probe')
    else:main()

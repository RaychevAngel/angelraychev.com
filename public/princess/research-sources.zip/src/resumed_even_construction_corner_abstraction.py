"""Finite feature relaxations, tested only for their full-start lower bound."""
from collections import defaultdict,deque
import json
from pathlib import Path

from resumed_even_construction_square_audit import prepare
from resumed_even_construction_ammunition import labels


def run():
    w=8;k=5;d=prepare(w,w)
    source=json.loads(Path('research/resumed-even-construction-ammunition-8x8-k5.json').read_text())
    rows={(z['p'],z['id']):z for z in source['rows']}
    corners=((0,0),(0,7),(7,0),(7,7));keys=[{}, {}, {}]
    for (p,i),z in rows.items():
        a=z['heights']
        inside=[(x,y) for x in range(w) for y in range(w)
                if (x+y)%2==p and y<=a[x]]
        outside=[(x,y) for x in range(w) for y in range(w)
                 if (x+y)%2==p and y>a[x]]
        presence=tuple(v in inside for v in corners)
        dist_in=tuple(min((abs(x-u)+abs(y-v) for x,y in inside),default=99)
                      for u,v in corners)
        dist_out=tuple(min((abs(x-u)+abs(y-v) for x,y in outside),default=99)
                       for u,v in corners)
        z.update(corner_present=presence,corner_distance_inside=dist_in,
                 corner_distance_outside=dist_out)
        keys[0][p,i]=(p,z['size'],presence)
        keys[1][p,i]=(p,z['size'],dist_in,dist_out)
        keys[2][p,i]=(p,z['size'],dist_in,dist_out,z['bottom_roots'],
                      z['top_fibers'],z['height_span'])
    I,S,H=[d[q] for q in ('ideals','sizes','hood')]
    edges=[]
    for p in (0,1):
        for i,a in enumerate(I[p]):
            for j,r in enumerate(I[p]):
                cost=S[p][i]-S[p][j]
                if 0<=cost<=k and r&~a==0:
                    edges.append(((p,i),(1-p,H[p][j]),cost))
    reports=[]
    for name,feature in zip(('presence','corner_distances','distances_and_counts'),keys):
        buckets=defaultdict(list)
        for state,key in feature.items():buckets[key].append(rows[state])
        reverse={key:[] for key in buckets}
        for before,after,cost in edges:
            reverse[feature[after]].append((feature[before],cost))
        distance=labels(reverse,[feature[0,0],feature[1,0]])
        full=distance[feature[0,len(I[0])-1]][0]
        # These abstract values are valid lower potentials on every physical
        # compressed transition, even where merged states have unequal optima.
        assert all(distance[feature[a]][0]<=cost+distance[feature[b]][0]
                   for a,b,cost in edges)
        clashes=[]
        for key,group in buckets.items():
            low=min(group,key=lambda z:z['F']);high=max(group,key=lambda z:z['F'])
            if high['F']>low['F']:clashes.append((high['F']-low['F'],key,low,high))
        gap,key,low,high=max(clashes,key=lambda t:t[0])
        reports.append({'feature':name,'feature_states':len(buckets),
                        'full_start_ammunition_lower':full,'exact_full_ammunition':96,
                        'resulting_full_time_lower':(2*full+k-1)//k,
                        'clashing_keys':len(clashes),'largest_exact_F_difference':gap,
                        'worst_same_feature_pair':[low,high],
                        'potential_inequalities_checked':len(edges)})
        if name=='presence':
            options={key:{} for key in buckets}
            for before,after,cost in edges:
                a,b=feature[before],feature[after]
                options[a][b]=min(cost,options[a].get(b,k+1))
            initial=(feature[0,len(I[0])-1],feature[1,len(I[1])-1])
            queue=deque([(initial,0)]);parents={initial:None}
            terminal=None;examined=0
            while queue:
                (a,b),depth=queue.popleft()
                if a[1]+b[1]<=k:
                    terminal=(a,b);break
                for aa,cost in options[a].items():
                    for bb,other in options[b].items():
                        if cost+other>k:continue
                        examined+=1;nxt=(bb,aa)
                        if nxt not in parents:
                            parents[nxt]=((a,b),cost,other)
                            queue.append((nxt,depth+1))
            assert terminal is not None
            schedule=[];current=terminal
            while parents[current] is not None:
                old,one,other=parents[current]
                schedule.append({'before':old,'costs':[one,other],'after':current})
                current=old
            schedule.reverse()
            reports[-1]['joint_relaxation']={
                'minimum_days':depth+1,'discovered_states':len(parents),
                'examined_edges':examined,'abstract_witness':schedule,
                'scope':'Lower bound only: same-feature physical states are freely merged.'}
    return {'scope':'Finite full-start lower potentials. Feature relaxations need not recover arbitrary-state optima. No uniform-width theorem.',
            'results':reports}


if __name__=='__main__':
    out=run()
    Path('research/resumed-even-construction-corner-features.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({**out,'results':[{k:v for k,v in row.items() if k!='worst_same_feature_pair'}
                                     for row in out['results']]},indent=2))

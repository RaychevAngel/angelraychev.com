"""Direct physical verification of a constant-budget partial-prefix failure."""
from collections import deque
from functools import lru_cache
from itertools import permutations, product
from pathlib import Path
from time import process_time
import json


def run():
    start = process_time()
    vertices = list(product(range(6), repeat=2))
    index = {v: i for i, v in enumerate(vertices)}
    masks = lambda rooms: sum(1 << index[tuple(v)] for v in rooms)
    neighbors = [masks(u for u in vertices if sum(abs(x-y) for x, y in zip(u, v)) == 1)
                 for v in vertices]
    @lru_cache(None)
    def N(a):
        result = 0
        while a:
            bit = a & -a; a -= bit
            result |= neighbors[bit.bit_length()-1]
        return result
    family = {0}
    for reflection in product((0, 1), repeat=2):
        mapped = [tuple(5-v[i] if reflection[i] else v[i] for i in range(2)) for v in vertices]
        for perm in permutations(range(2)):
            for p in (0, 1):
                order = sorted((i for i, v in enumerate(vertices) if sum(v) % 2 == p),
                               key=lambda i: (sum(mapped[i]), tuple(-mapped[i][j] for j in perm)))
                a = 0
                for i in order:
                    a |= 1 << i
                    family.add(a)
    assert all(N(a) in family for a in family)
    rooms = [(0,0),(0,2),(0,4),(1,1),(1,3),(1,5),(2,2),(2,4),(3,3),(3,5)]
    initial = masks(rooms)
    assert initial in family
    shots = [[(1,5),(2,4),(3,3),(3,5)],
             [(0,5),(1,4),(2,3),(3,2)],
             [(0,4),(1,3),(2,2),(3,1)],
             [(0,3),(1,2),(2,1),(3,0)],
             [(0,0),(0,2),(1,1),(2,0)]]
    actual = initial
    counts = []
    for shot in shots:
        assert len(shot) <= 4
        counts.append(actual.bit_count())
        actual = N(actual & ~masks(shot))
    assert not actual
    queue = deque([(initial, 0)])
    seen = {initial}
    layers = []
    while queue:
        before, depth = queue.popleft()
        if before.bit_count() <= 4:
            minimum = depth + 1
            break
        if len(layers) <= depth:
            layers.append({'prior_inspections': depth, 'states': 0, 'minimum_count': 36})
        layers[depth]['states'] += 1
        layers[depth]['minimum_count'] = min(layers[depth]['minimum_count'], before.bit_count())
        for residual in family:
            if not residual & ~before and before.bit_count()-residual.bit_count() <= 4:
                following = N(residual)
                if following not in seen:
                    seen.add(following); queue.append((following, depth+1))
    assert minimum == 6
    return {'shape': [6,6], 'budget': 4, 'initial_support': rooms,
            'initial_is_reflected_permuted_prefix': True,
            'physical_five_day_witness': shots, 'physical_belief_counts': counts,
            'physical_replay_passed': True, 'restricted_minimum_days': minimum,
            'restricted_states_seen': len(seen), 'restricted_layers': layers,
            'CPU_seconds': process_time()-start,
            'scope': 'Constant-budget arbitrary-prefix-start normal form fails. Full-board constant-budget normal form remains open. Unrestricted optimum below five is not needed for the claim.'}


if __name__ == '__main__':
    result = run()
    output = Path(__file__).resolve().parents[1] / 'research/even-bridge-constant-partial-prefix-check.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'physical_five_day_witness'}, indent=2))

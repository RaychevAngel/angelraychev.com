"""One 20-CPU-second attempt to certify the complete finite complement.

No scalar filters. Also covers the 26 small-width nonminimum cases so
the global theorem need not invoke special five- or seven-row formulas.
"""
from pathlib import Path
import hashlib
import json
import resource
import subprocess
import tempfile

from bridge_odd_clock_linear_budget import constants as fixed_constants
from bridge_odd_clock_orientation_onset import constants as old_constants


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cap_cpu():
    resource.setrlimit(resource.RLIMIT_CPU,(20,20))


def main():
    root=Path(__file__).resolve().parents[1]
    cpp=root/'src/bridge_odd_clock_linear_verify_full.cpp'
    old_complement=root/'research/bridge-odd-clock-linear-budget-complement.json'
    expected=json.loads(old_complement.read_text())['rows']
    intervals=[];cases=[]
    for b in range(2,140):
        for m in range(b+2,2*b+1):
            fixed=fixed_constants(b,m);old=old_constants(b,m)
            K=min(fixed['K'],old['K']);w=2*b+1
            J=max(2*K+m+1,K+b*b+1)
            onset=J+m-1+m*(fixed['W']+1)
            count=max(0,(onset-2*b*(b+1)+w-1)//w)
            if count:
                intervals.append(dict(b=b,width=w,budget=m,K=K,J=J,W=fixed['W'],
                                      onset=onset,first_length=w,
                                      last_length=w+2*(count-1),count=count))
                cases.extend((w,w+2*j,m) for j in range(count))
    old_keys={(r['width'],n,r['budget']) for r in expected
              for n in range(r['first_length'],r['last_length']+1,2)}
    assert {(w,n,m) for w,n,m in cases if w>=9}==old_keys
    words=''.join(f'{w} {n} {m} 0 0\n' for w,n,m in cases)
    dependencies=[cpp,Path(__file__),old_complement,
                  root/'src/bridge_odd_clock_linear_budget.py',
                  root/'src/bridge_odd_clock_orientation_onset.py',
                  root/'research/bridge-odd-clock-linear-budget.md',
                  root/'research/bridge-odd-clock-orientation-onset.md']
    with tempfile.TemporaryDirectory(prefix='princess-odd-full-') as temporary:
        binary=Path(temporary)/'verify'
        compiler=subprocess.run(['/usr/bin/clang++','--version'],capture_output=True,text=True,check=True)
        subprocess.run(['/usr/bin/clang++','-std=c++17','-O3',str(cpp),'-o',str(binary)],check=True)
        run=subprocess.run([str(binary)],input=words,text=True,capture_output=True,
                           preexec_fn=cap_cpu,timeout=35)
    rows=[json.loads(line) for line in run.stdout.splitlines() if line.strip().endswith('}')]
    result=dict(status='PASS' if run.returncode==0 and len(rows)==len(cases) else 'INCOMPLETE',
                scope=__doc__,cpu_limit_seconds=20,returncode=run.returncode,
                compiler=compiler.stdout.splitlines()[0],compile_flags=['-std=c++17','-O3'],
                model='Exact retained exceptional frontier, every quota split, inverse lookup, per-x maxima and descending-x Pareto, exhaustive central pairs.',
                hashes={str(p.relative_to(root)):digest(p) for p in dependencies},
                inputs_sha256=hashlib.sha256(words.encode()).hexdigest(),
                input_count=len(cases),verified_count=len(rows),
                original_complement_count=len(old_keys),small_width_extra=len(cases)-len(old_keys),
                intervals=intervals,quota_splits=sum(r['quota_splits'] for r in rows),
                max_frontier=max((r['maximum_frontier'] for r in rows),default=0),
                reported_timing=run.stderr.strip(),rows=rows)
    path=root/'research/bridge-odd-clock-linear-budget-whole-verified.json'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print({k:result[k] for k in ('status','input_count','verified_count','quota_splits','max_frontier','reported_timing')})
    assert result['status']=='PASS',run.stderr


if __name__=='__main__':
    main()

"""Bounded physical checks for symbolic pyramid block transitions.

This does not search finite-board optimal strategies or replace the ordinary
unrestricted lower-bound proof. It checks maximal erosion at physical ends,
then reconstructs and replays prescribed-quota interior height transitions.
"""
from collections import deque
from itertools import product
from pathlib import Path
from time import process_time
import json
import math
import random

ROOT = Path(__file__).resolve().parents[1]


def graph(a, extras=()):
    return [(i, i + 1) for i in range(a - 1)] + list(extras)


def prepare(a, n, edges):
    vertices = list(product(range(a), range(n)))
    neighbors = {v: set() for v in vertices}
    qadj = [[] for _ in range(a)]
    for u, v in edges:
        qadj[u].append(v)
        qadj[v].append(u)
        for y in range(n):
            neighbors[u, y].add((v, y))
            neighbors[v, y].add((u, y))
    for v in vertices:
        x, y = v
        for z in (y - 1, y + 1):
            if 0 <= z < n:
                neighbors[v].add((x, z))
    return vertices, neighbors, qadj


def neighborhood(s, neighbors):
    return set().union(*(neighbors[v] for v in s)) if s else set()


def rooms(heights, n, p):
    return {(x, y) for x, top in enumerate(heights)
            for y in range((p - x) % 2, min(top + 1, n), 2)}


def heights(s, a, p):
    return [max((y for x, y in s if x == v), default=(p-v) % 2 - 2)
            for v in range(a)]


def ideals(a, n, edges, p):
    row = [(x, y) for x in range(a) for y in range(n) if (x+y) % 2 == p]
    index = {v: i for i, v in enumerate(row)}
    pred = []
    for x, y in row:
        pred.append(sum(1 << index[u, y-1] for u, v in edges if v == x and y)
                    + sum(1 << index[v, y-1] for u, v in edges if u == x and y))
    queue, seen = deque([0]), {0}
    while queue:
        mask = queue.popleft()
        for i, needed in enumerate(pred):
            if not (mask >> i & 1) and mask & needed == needed:
                new = mask | 1 << i
                if new not in seen:
                    seen.add(new)
                    queue.append(new)
    return [{v for i, v in enumerate(row) if mask >> i & 1} for mask in sorted(seen)]


def erosion_checks():
    tests = 0
    coverage_tests = 0
    for a, n, extras in [(2, 1, ()), (3, 2, ()), (4, 3, ()), (4, 6, ()),
                          (6, 6, ()), (6, 5, ((1, 4), (2, 5)))]:
        edges = graph(a, extras)
        vertices, neighbors, qadj = prepare(a, n, edges)
        families = [ideals(a, n, edges, p) for p in (0, 1)]
        lookup = [{frozenset(s) for s in family} for family in families]
        for p in (0, 1):
            for target in families[p]:
                b = heights(target, a, p)
                actual = {v for v in vertices if sum(v) % 2 == 1-p
                          and neighbors[v] <= target}
                e = []
                for v in range(a):
                    s = (p-v) % 2
                    top_extra = ((n-1) % 2 == 1-s and b[v] == n-2
                                 and all(b[u] == n-1 for u in qadj[v]))
                    e.append(max(b[v]-1, (1-s)-2) + 2 * top_extra)
                assert rooms(e, n, 1-p) == actual
                assert frozenset(actual) in lookup[1-p]
                tests += 1
                for source in families[1-p]:
                    residual = source & actual
                    cost = sum(max(x-y, 0) for x, y in zip(heights(source, a, 1-p), e)) // 2
                    assert cost == len(source-residual)
                    assert neighborhood(residual, neighbors) <= target
                    coverage_tests += 1
    return {'erosions': tests, 'source_target_cost_checks': coverage_tests}


def descend(a, c, qadj):
    x = list(a)
    word = []
    while x != c:
        candidates = [v for v in range(len(x)) if x[v] > c[v]]
        v = max(candidates, key=lambda u: (x[u], -u))
        assert all(x[u] == x[v]-1 for u in qadj[v])
        x[v] -= 2
        assert x[v] >= c[v]
        word.append(v)
    return word


def realize(a, z, n, edges, budgets, p, balanced=False):
    a = list(a)
    t = len(budgets)
    vertices, neighbors, qadj = prepare(len(a), n, edges)
    c = [v-t for v in z]
    assert all(v <= u and (v-u) % 2 == 0 for u, v in zip(a, c))
    word = deque(descend(a, c, qadj))
    assert len(word) <= sum(budgets)
    total_flips = len(word)
    belief = rooms(a, n, p)
    state = list(a)
    shots = []
    for day, quota in enumerate(budgets):
        shot = []
        used = ((day+1)*total_flips//t-day*total_flips//t
                if balanced else min(quota, len(word)))
        assert used <= quota
        for _ in range(used):
            v = word.popleft()
            assert all(state[u] == state[v]-1 for u in qadj[v])
            shot.append((v, state[v]))
            state[v] -= 2
        assert len(shot) == len(set(shot)) <= quota
        assert set(shot) <= belief
        belief -= set(shot)
        assert belief == rooms(state, n, (p+day) % 2)
        belief = neighborhood(belief, neighbors)
        state = [v+1 for v in state]
        assert belief == rooms(state, n, (p+day+1) % 2)
        shots.append(shot)
    assert not word and state == list(z)
    assert belief == rooms(z, n, (p+t) % 2)
    return shots


def block_checks():
    rng = random.Random(20260913)
    cases = []
    for a, extras in [(4, ()), (5, ()), (6, ()), (6, ((1,4), (2,5))), (7, ())]:
        edges = graph(a, extras)
        n = 100
        _, _, qadj = prepare(a, n, edges)
        m = a // 2 + 1
        for p in (0, 1):
            initial = [40+(p-v) % 2 for v in range(a)]
            for t in range(1, 5):
                budgets = [rng.randrange(m+1) for _ in range(t)]
                if not sum(budgets):
                    budgets[0] = 1
                unshifted = list(initial)
                used = rng.randrange(sum(budgets)+1)
                for _ in range(used):
                    maxima = [v for v in range(a) if all(unshifted[u] == unshifted[v]-1 for u in qadj[v])]
                    v = rng.choice(maxima)
                    unshifted[v] -= 2
                target = [v+t for v in unshifted]
                initial_size = len(rooms(initial, n, p))
                assert initial_size-sum(budgets) > (a-2)**2 // 4
                assert t <= min(initial+target)
                assert max(initial+target) <= n-1-t
                shots = realize(initial, target, n, edges, budgets, p)
                t0 = max(0, max(v-u for u, v in zip(initial, target)),
                         math.ceil((sum(initial)-sum(target))/(2*m-a)))
                t0 += (t-t0) % 2
                assert t0 <= t
                optimal_shots = realize(initial, target, n, edges, [m]*t0, p)
                cases.append({'order': a, 'extra_edges': extras, 'initial_phase': p,
                              'days': t, 'quotas': budgets, 'source_heights': initial,
                              'target_heights': target, 'actual_shots': shots,
                              'symbolic_constant_budget_minimum': t0,
                              'minimum_witness': optimal_shots})
    return cases


def long_block_checks():
    result = []
    for a, n, extras in [(4, 61, ()), (5, 100, ()), (5, 101, ()),
                          (6, 100, ()), (6, 101, ((1,4), (2,5)))]:
        for target_phase in (0, 1):
            m = a // 2 + 1
            initial = [2*(3*n//8)+(-v) % 2 for v in range(a)]
            target = [2*(n//8)+(target_phase-v) % 2 for v in range(a)]
            t0 = max(0, max(z-x for x,z in zip(initial, target)),
                     math.ceil((sum(initial)-sum(target))/(2*m-a)))
            t0 += (target_phase-t0) % 2
            assert t0 > min(target)
            shots = realize(initial, target, n, graph(a, extras), [m]*t0, 0, balanced=True)
            result.append({'order': a, 'length': n, 'extras': extras, 'budget': m,
                           'source_heights': initial, 'target_heights': target,
                           'days': t0, 'physical_replay': True,
                           'total_useful_inspections': sum(map(len,shots))})
    return result


def main():
    start = process_time()
    receipt = {'scope': 'Physical formula and witness checks; arbitrary-intermediate lower bound is an ordinary proof, not finite enumeration.',
               'erosion': erosion_checks(), 'block_cases': block_checks(),
               'long_block_cases': long_block_checks()}
    receipt['cpu_seconds'] = process_time()-start
    (ROOT/'research/maturation-even-transition-check.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'erosion': receipt['erosion'], 'block_cases': len(receipt['block_cases']),
                      'long_block_cases': len(receipt['long_block_cases']),
                      'cpu_seconds': receipt['cpu_seconds']}))


if __name__ == '__main__':
    main()

"""Independent raw-coordinate attack on corner localization; single worker."""
from __future__ import annotations

import json
import time
from pathlib import Path


def neighbors(s, width):
    return {(x + dx, y + dy) for x, y in s
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
            if 0 <= x + dx < width and y + dy >= 0}


def connected(s):
    left = set(s)
    if not left:
        return False
    reached = {left.pop()}
    while left:
        new = {v for v in left if any(abs(v[0]-u[0])+abs(v[1]-u[1]) == 2
                                      for u in reached)}
        if not new:
            return False
        left -= new
        reached |= new
    return True


def check():
    start = time.process_time()
    counts = dict(raw_supports=0, subcritical=0, square_large=0,
                  pronic_large=0, connected_origin=0, pronic_equality=0)
    shapes = [(4, 7), (6, 5), (8, 4), (10, 3)]
    for width, height in shapes:
        b = width // 2
        cells = [(x, y) for x in range(width) for y in range(height)
                 if (x+y) % 2 == 0]
        targets = [(x, y) for x in range(width) for y in range(height+1)
                   if (x+y) % 2 == 1]
        target_index = {v: i for i, v in enumerate(targets)}
        masks = [sum(1 << target_index[v] for v in neighbors({c}, width))
                 for c in cells]
        n = len(cells)
        unions = [0] * (1 << n)
        for bits in range(1, 1 << n):
            low = bits & -bits
            i = low.bit_length()-1
            unions[bits] = unions[bits ^ low] | masks[i]
            k = bits.bit_count()
            surplus = unions[bits].bit_count()-k
            counts['raw_supports'] += 1
            if surplus >= b:
                continue
            counts['subcritical'] += 1
            s = {cells[i] for i in range(n) if bits >> i & 1}
            origin = (0, 0) in s
            conn = connected(s)
            if origin and conn:
                counts['connected_origin'] += 1
                assert max(x+y for x, y in s) <= 2*surplus-2, (width, s)
            if k > surplus*(surplus-1):
                counts['square_large'] += 1
                assert origin and conn
                assert max(x+y for x, y in s) <= 2*surplus-2
            cap2 = max(surplus*(surplus-1)//2, surplus*(surplus-2))
            if not origin and k > cap2:
                counts['pronic_large'] += 1
                assert conn and (width-1, 0) in neighbors(s, width)
                assert max(width-1-x+y for x, y in s) <= 2*surplus-3
            if not origin and k == surplus*(surplus-1):
                counts['pronic_equality'] += 1
                expected = {(width-1-x, y) for x in range(2*surplus)
                            for y in range(2*surplus)
                            if (x+y) % 2 == 1 and x+y <= 2*surplus-3}
                assert s == expected, (width, surplus, s, expected)
    counterexample = {(4, 0), (5, 1)}
    assert len(neighbors(counterexample, 6))-len(counterexample) == 2
    receipt = dict(status='PASS', shapes=shapes, counts=counts,
                   cpu_seconds=round(time.process_time()-start, 4),
                   scope='Raw finite supports; all neighbors in the actual half-strip.',
                   proof='research/maturation-cheap-step-rigidity.md',
                   false_component_C2_counterexample=sorted(counterexample))
    output = Path(__file__).resolve().parents[1] / 'research/maturation-cheap-step-independent-check.json'
    output.write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    check()

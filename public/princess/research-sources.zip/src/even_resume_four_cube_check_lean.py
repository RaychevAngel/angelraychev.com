"""Fresh, one-worker Lean closure check for the full physical four-cube theorem."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time

ROOT=Path(__file__).resolve().parents[1]
LEAN=Path('/Users/angel/code/math/polyominoes/.tools/lean-4.33.1-darwin_aarch64/bin/lean')
STAMP=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
BUILD=ROOT/'.build'/('four-cube-review-'+STAMP)
BUILD.mkdir(parents=True, exist_ok=False)
SOURCES={p.stem:p for p in (ROOT/'lean').glob('*.lean')}
ordered=[]
visiting=set()
def visit(name):
    if name in ordered: return
    if name in visiting: raise RuntimeError('Import cycle: '+name)
    visiting.add(name)
    for line in re.findall(r'^import\s+([^\n]+)',SOURCES[name].read_text(),re.M):
        for mod in line.split('--')[0].split():
            if mod in SOURCES: visit(mod)
    visiting.remove(name)
    ordered.append(name)
visit('FourCubeClassification')
env=dict(os.environ, LEAN_PATH=str(BUILD))
version=subprocess.run([str(LEAN),'--version'],capture_output=True,text=True,check=True).stdout.strip()
receipt={'status':'running','utc':datetime.now(timezone.utc).isoformat(),
         'compiler':str(LEAN),'compiler_version':version,'workers':1,
         'fresh_output_directory':str(BUILD),'root_module':'FourCubeClassification',
         'planned_modules':len(ordered),'modules':[],
         'scope':'Full physical 4x4x4 capture feasibility and exact minimum for every natural daily probe budget. Includes proved square factor compression, product normalization, complete ideal coverage, geometric lower certificates, and actual room schedule replay.'}
path=ROOT/'research/even-resume-four-cube-lean-verification.json'
begin=time.monotonic()
def save():
    receipt['total_seconds']=time.monotonic()-begin
    path.write_text(json.dumps(receipt,indent=2)+'\n')
save()
for name in ordered:
    source=SOURCES[name]
    raw=source.read_bytes()
    if re.search(r'^\s*(?:axiom|unsafe|opaque)\b',raw.decode(),re.M):
        raise RuntimeError('Explicit trust declaration needs review: '+name)
    start=time.monotonic()
    try:
        result=subprocess.run([str(LEAN),'-j1','-o',str(BUILD/(name+'.olean')),str(source)],
            cwd=ROOT/'lean',env=env,capture_output=True,text=True,timeout=300)
        output=result.stdout+result.stderr
        code=result.returncode
    except subprocess.TimeoutExpired as e:
        output=str(e)
        code=124
    record={'module':name,'source':str(source.relative_to(ROOT)),
            'sha256':hashlib.sha256(raw).hexdigest(),'seconds':time.monotonic()-start,
            'exit_code':code,'output':output}
    receipt['modules'].append(record)
    passed=code==0 and 'sorryAx' not in output
    print(f'{len(receipt["modules"]):2}/{len(ordered)} {name}: {"PASS" if passed else "FAIL"} {record["seconds"]:.3f}s',flush=True)
    save()
    if not passed:
        receipt['status']='failed'
        save()
        raise SystemExit(1)
unchanged=all(hashlib.sha256((ROOT/r['source']).read_bytes()).hexdigest()==r['sha256'] for r in receipt['modules'])
receipt['sources_unchanged_during_check']=unchanged
receipt['status']='passed' if unchanged else 'source_changed'
save()
print(f'Finished {len(ordered)} modules in {receipt["total_seconds"]:.3f}s; {receipt["status"]}.',flush=True)
raise SystemExit(0 if unchanged else 1)

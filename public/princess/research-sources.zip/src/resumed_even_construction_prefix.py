"""Bounded full-board constant-budget prefix solo experiments.

This is an exact optimizer only within reflected weightlex prefix survivors.
Its winning schedules are physical upper certificates, not unrestricted lower
bounds. The scalar comparison is the existing static isoperimetric relaxation.
"""
from collections import deque
from functools import lru_cache
from itertools import product
from math import isqrt
from pathlib import Path
import argparse
import json
import time


def ceilroot(s):
    q = isqrt(s)
    return q + (q*q < s)


def rho(s):
    q = (isqrt(1+4*s)-1)//2
    return q + (q*(q+1) < s)


def scalar(w, n, k):
    h, r = w*n//2, w//2
    state, clock = h, [h]
    while state:
        s = max(0, state-k)
        state = s + min(ceilroot(s), r, rho(h-s))
        if state >= clock[-1]:
            return None, clock
        clock.append(state)
    return len(clock)-1, clock


class PrefixGame:
    def __init__(self, w, n):
        self.w, self.n = w, n
        self.colors = [[(x,y) for x in range(w) for y in range(n)
                        if (x+y)%2 == p] for p in (0,1)]
        self.index = [{v:i for i,v in enumerate(row)} for row in self.colors]
        self.orders, self.prefixes, self.adj = [], [], []
        for p, row in enumerate(self.colors):
            orders = []
            for rx, ry, swapped in product((0,1), repeat=3):
                def key(v):
                    x,y = v
                    x = w-1-x if rx else x
                    y = n-1-y if ry else y
                    return (x+y, -y, -x) if swapped else (x+y, -x, -y)
                order = sorted(range(len(row)), key=lambda i:key(row[i]))
                prefix, mask = [0], 0
                for i in order:
                    mask |= 1 << i
                    prefix.append(mask)
                orders.append(tuple(prefix))
            orders = tuple(dict.fromkeys(orders))
            self.orders.append(orders)
            self.prefixes.append(tuple(tuple(set(row[s] for row in orders))
                                       for s in range(len(self.colors[p])+1)))
            adj=[]
            for x,y in row:
                adj.append(sum(1 << self.index[1-p][u] for u in
                               ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                               if u in self.index[1-p]))
            self.adj.append(adj)
        self.full = (1 << len(self.colors[0]))-1
        self.hood = lru_cache(None)(self._hood)

    def _hood(self, p, mask):
        answer = 0
        while mask:
            bit = mask & -mask
            mask ^= bit
            answer |= self.adj[p][bit.bit_length()-1]
        return answer

    def solo(self, k, witness=False):
        initial=(0,self.full)
        queue=deque([(initial,0)])
        parents={initial:None}
        terminal=None
        while queue:
            state, depth=queue.popleft()
            p, mask=state
            need=mask.bit_count()-k
            if need <= 0:
                terminal=state
                break
            # Every larger prefix of the same order contains its need-prefix.
            # Thus exact-need survivors dominate all less-than-budget actions.
            for survivor in self.prefixes[p][need]:
                if survivor & ~mask:
                    continue
                nxt=(1-p,self.hood(p,survivor))
                if nxt not in parents:
                    parents[nxt]=(state,survivor)
                    queue.append((nxt,depth+1))
        if terminal is None:
            return {'days':None,'states':len(parents)}
        result={'days':depth+1,'states':len(parents)}
        if witness:
            steps=[(terminal,0)]
            while parents[state] is not None:
                state,survivor=parents[state]
                steps.append((state,survivor))
            steps.reverse()
            actual=set(self.colors[0]);shots=[];counts=[]
            for (p,mask),survivor in steps:
                shots.append([v for i,v in enumerate(self.colors[p])
                              if (mask ^ survivor) >> i & 1])
                assert len(shots[-1]) <= k
                counts.append(len(actual))
                actual -= set(shots[-1])
                actual={u for x,y in actual for u in
                        ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                        if 0<=u[0]<self.w and 0<=u[1]<self.n}
            assert not actual
            result.update(shots=shots,preinspection_counts=counts,
                          physical_replay_passed=True)
        return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--widths', default='6,8,10,12,14,16')
    parser.add_argument('--extra-length',type=int,default=10)
    parser.add_argument('--output',default='research/resumed-even-construction-prefix.json')
    args=parser.parse_args()
    started=time.monotonic();rows=[];worst=-1
    for w in map(int,args.widths.split(',')):
        r=w//2
        for n in range(w,w+args.extra_length+1):
            game=PrefixGame(w,n)
            for k in range(r+1,r*(r-1)+1):
                tau,clock=scalar(w,n,k)
                answer=game.solo(k)
                gap=answer['days']-tau if answer['days'] is not None else None
                row={'w':w,'n':n,'k':k,'scalar_tau':tau,
                     'prefix_solo':answer['days'],'gap':gap,'states':answer['states']}
                if gap is None or gap>worst:
                    row['witness']=game.solo(k,witness=True)
                    row['scalar_clock']=clock
                    worst=gap if gap is not None else worst
                    print('new_worst', {q:v for q,v in row.items()
                                        if q not in ('witness','scalar_clock')},flush=True)
                rows.append(row)
            print('board',w,n,'elapsed',round(time.monotonic()-started,2),flush=True)
    output={'scope':'Restricted prefix solo upper versus static scalar lower; full initial color, constant budget.',
            'seconds':time.monotonic()-started,'results':rows}
    Path(args.output).write_text(json.dumps(output,indent=2)+'\n')


if __name__=='__main__':
    main()

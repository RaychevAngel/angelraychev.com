"""Even-square diagnostic using proved subcritical erosion-corner restrictions.

At the critical surplus only the accepted unrefined F/G theorem is used;
the odd-width critical refinement and pronic rules are never imported.
The output is a necessary solo-model value, not a physical strategy.
"""
from pathlib import Path
from time import process_time
from math import isqrt
import argparse,json
from resumed_odd_even_erosion_corners import low,F


def root(q):
    r=isqrt(q);return r+(r*r<q)


def rho(q):
    r=isqrt(q)
    return r+(r*(r+1)<q)


def G(i,j,s):
    return max(F(2-j,d,s-2+i+d) for d in range(3-i))


def run(w,k,pronic=False):
    assert w>=6 and w%2==0
    start_time=process_time();r=w//2;h=w*w//2
    states=[(a,c,e)for a in range(h+1)for c in range(3)for e in range(3)
            if c+2*e<=a<=h-4+c+e]
    ids={state:i for i,state in enumerate(states)}
    flag_ids={t:len(states)+t-2 for t in range(2,r)} if pronic else {}
    targets={}
    # Exact target-feature tables are shared by all predecessor beliefs.
    for q,i,u in states:
        masks=[0,0,0]
        if q==0:
            targets[q,i,u]=[1<<ids[(0,0,0)]]*3;continue
        for s in range(min(root(q),r,rho(h-q)),h-q+1):
            t=q+s
            for j in range(u,3):
                for v in range(i,3):
                    target=(t,j,v)
                    if target not in ids:continue
                    if pronic and 2<=s<=r:
                        # Root-reviewed pronic equality: at the square's
                        # critical radius its second hood reaches both corners.
                        kappa=2 if s==r else 0
                        if q==h-s*s and j==2 and(i,u,v)!=(1,2-kappa,1):continue
                        if q==s*(s-1) and i==0 and(j,v)!=(1,0):continue
                    delta=v-i;ss=s-delta
                    if ss<0:continue
                    if ss<r:
                        if not(q+delta<=low(v,j,u,ss) or
                               h-q-s<=F(2-j,2-v,ss)):
                            continue
                    elif ss==r:
                        if not(q+delta<=F(v,j,ss) or h-q-s<=G(v,j,ss)
                               or (v,j)==(1,1)):
                            continue
                    if s==r and not(q<=F(i,j,r) or h-q-s<=G(i,j,r)
                                    or (i,j)==(1,1)):
                        continue
                    target_id=flag_ids[s] if (s in flag_ids and q==s*(s-1) and i==0) else ids[target]
                    for c in range(i,3):
                        if i>=max(0,c+v-2):masks[c]|=1<<target_id
        targets[q,i,u]=masks
    arcs=[]
    for a,c,e in states:
        mask=0
        for p in range(min(k,a)+1):
            q=a-p
            if q==0:
                mask|=1<<ids[(0,0,0)];continue
            for i in range(max(0,c-p),c+1):
                for u in range(max(0,e-(p-c+i)),e+1):
                    row=targets.get((q,i,u))
                    if row is not None:mask|=row[c]
        arcs.append(mask)
    if pronic:
        no_corner=sum(1<<j for j,(_,c,e)in enumerate(states) if c==0)
        for t in range(2,r):
            states.append((t*t,1,0,4))
            arcs.append(arcs[ids[(t*t,1,0)]]&no_corner)
    frontier=1<<ids[(h,2,2)];seen=frontier;days=0
    layers=[]
    while True:
        layers.append([states[j]for j in range(len(states))if frontier>>j&1])
        if frontier>>ids[(0,0,0)]&1:break
        next_mask=0
        while frontier:
            bit=frontier&-frontier;frontier-=bit
            next_mask|=arcs[bit.bit_length()-1]
        frontier=next_mask&~seen;seen|=frontier;days+=1
        assert frontier,'No relaxed capture'
    return {'width':w,'length':w,'budget':k,'necessary_solo_days':days,
            'state_count':len(states),'solo_arcs':sum(x.bit_count()for x in arcs),
            'cpu_seconds':process_time()-start_time,
            'first_arrival_layers':layers,
            'all_radii_pronic_rule':pronic,
            'scope':'Necessary solo model: refined erosion capacity strictly below critical surplus; accepted unrefined critical F/G with exception11; corner closure and maximal retention. Optional root-reviewed all-radii pronic rule uses second-hood corner count0 subcritically and2 critically on a square. No odd critical refinement, geometric sufficiency, or cohort merger asserted.'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--width',type=int,default=24)
    p.add_argument('--budget',type=int,default=13)
    p.add_argument('--pronic',action='store_true');a=p.parse_args()
    result=run(a.width,a.budget,a.pronic)
    suffix='-pronic'if a.pronic else''
    path=Path(f'research/resumed-odd-even-erosion-square-{a.width}x{a.width}-k{a.budget}{suffix}.json')
    path.write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items()if k!='first_arrival_layers'},flush=True)

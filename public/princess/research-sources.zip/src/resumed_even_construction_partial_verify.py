"""Independent verifier for the prefix123 impossibility certificate.

Does not import the search, height-walk enumeration, or model edge builder.
Uses literal neighbor sets and downward local-maximum deletion closure.
"""
from pathlib import Path
from functools import lru_cache
from math import isqrt
import json,time


def capacity(i,j,s):
    if s<i+2*j:return -10**9
    if j>0:return i+2*j-2+(s-i-2*j+2)*(s-i-2*j+1)
    if i>0:return i-1+(s-i+1)**2
    return max(s*(s-1)//2,s*(s-2))


def verify(data=None):
    start=time.monotonic();source=Path('research/resumed-even-construction-partial-prefix123.json')
    d=json.loads(source.read_text())if data is None else data;w,n=d['shape'];k=d['budget'];r=w//2;h=w*n//2
    potential={(row['size'],row['corners']):row['lower']for row in d['model_lower_potential']}
    potential[0,0]=0
    features=[(q,c)for q in range(h+1)for c in range(3)if c<=q<=h-2+c]
    assert set(potential)==set(features)
    for q,c in features:
        if q<=k:assert potential[q,c]==int(q>0)
    next_min={};profile_edges=0
    for q,i in features:
        if q==0:next_min[q,i]=0;continue
        root=isqrt(q)+(isqrt(q)**2<q)
        deficit=h-q;rho=(isqrt(1+4*deficit)-1)//2;rho+=rho*(rho+1)<deficit
        minimum=min(root,r,rho)
        best=10**9
        for t,j in features:
            s=t-q
            if s<minimum:continue
            if s<=r:
                exception=s==r and((i,j)==(1,1)or(n==w+1 and(i,j)==(2,0)))
                if not exception:
                    small=q<=capacity(i,j,s)
                    dual=h-t<=max(capacity(2-j,z,s-2+i+z)for z in range(3-i))
                    if not(small or dual):continue
            profile_edges+=1;best=min(best,potential[t,j])
        next_min[q,i]=best
    transition_inequalities=0
    for a,c in features:
        for q in range(max(0,a-k),a+1):
            spent=a-q
            for i in range(max(0,c-spent),c+1):
                if(q,i)not in next_min:continue
                assert potential[a,c]<=1+next_min[q,i],(a,c,q,i)
                transition_inequalities+=1
    failed={(row['phase'],tuple(row['heights']),row['remaining_days'])for row in d['failed_state_certificate']}
    vertices={(x,y)for x in range(w)for y in range(n)}
    color=[{v for v in vertices if sum(v)%2==p}for p in(0,1)]
    initial=sorted(color[d['initial_prefix_phase']],key=lambda v:(sum(v),-v[0]))[:d['initial_prefix_size']]
    p0=d['initial_prefix_phase'];A0=tuple(d.get('initial_heights',tuple(max((y for x,y in initial if x==v),default=(p0-v)%2-2)for v in range(w))))
    assert(p0,A0,d['deadline'])in failed
    @lru_cache(None)
    def next_state(p,B):
        S={(x,y)for x,y in color[p]if y<=B[x]}
        N={v for x,y in S for v in((x-1,y),(x+1,y),(x,y-1),(x,y+1))if v in vertices}
        C=[(1-p-x)%2-2 for x in range(w)]
        for x,y in N:C[x]=max(C[x],y)
        assert all(abs(C[x+1]-C[x])==1 for x in range(w-1))
        corners=sum(v in N for v in((0,0),(0,n-1),(w-1,0),(w-1,n-1)))
        return tuple(C),len(N),corners
    enumerated=0;geometric_prunes=0;recursive_edges=0
    for p,A,left in sorted(failed):
        assert all((A[x]-(p-x))%2==0 and(p-x)%2-2<=A[x]<n for x in range(w))
        assert all(abs(A[x+1]-A[x])==1 for x in range(w-1))
        size=sum((A[x]-((p-x)%2-2))//2 for x in range(w))
        assert size>k and left>=1
        level={A}
        for _ in range(k):
            nxt=set()
            for B in level:
                for x in range(w):
                    if B[x]<0:continue
                    if any(B[u]!=B[x]-1 for u in(x-1,x+1)if 0<=u<w):continue
                    C=list(B);C[x]-=2;nxt.add(tuple(C))
            level=nxt
        for B in level:
            enumerated+=1;C,q,j=next_state(p,B)
            if potential[q,j]>left-1:geometric_prunes+=1
            else:
                assert(1-p,C,left-1)in failed,(p,A,left,B,C,q,j)
                recursive_edges+=1
    return {'verified':True,'failed_states':len(failed),'all_quota_survivors_checked':enumerated,
            'potential_profile_edges':profile_edges,'potential_inequalities':transition_inequalities,
            'potential_pruned_edges':geometric_prunes,'recursive_certificate_edges':recursive_edges,
            'literal_neighbor_shapes':next_state.cache_info().currsize,'seconds':time.monotonic()-start,
            'scope':'Independent finite lower certificate for all downward-pyramid strategies from the specified123-room prefix; unrestricted interpretation additionally uses the existing square fixed-state compression theorem.'}


if __name__=='__main__':
    out=verify();Path('research/resumed-even-construction-partial-prefix123-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

"""Independent attack on the proposed consecutive sharp-event inequality.

This checks a necessary scalar/lens relaxation, not physical attainability.
Every failed inequality is recorded as a failure of that proof route only.
"""
from functools import lru_cache
from math import isqrt
from pathlib import Path
import hashlib
import json
import time


def root(x):
    r = isqrt(x)
    return r + (r * r < x)


def pronic(x):
    r = (isqrt(1 + 4 * x) - 1) // 2
    return r + (r * (r + 1) < x)


def tri(x):
    x = max(0, x)
    return x * (x + 1) // 2


def run(limit=20):
    start = time.process_time()
    checks = 0
    per_width = []
    failures = []
    for b in range(2, limit + 1):
        k, n = b + 1, 2 * b + 2

        def f(p, a):
            q = max(0, a - k)
            if not q:
                return 0
            surplus = min(root(q), b) if p == 0 else min(pronic(q) + 1, b + 1)
            return q + surplus

        @lru_cache(None)
        def tau(p, a):
            if not a:
                return 0
            return 1 + tau(1 - p, f(p, a))

        local = 0
        for old_r in range(1, b):
            for a in range(old_r * old_r + 1, old_r * (old_r + 1) + 1):
                initial_time = tau(1, a)
                neutral = a
                for t in range(1, initial_time):
                    if t % 2:
                        lower_q = max(1, neutral - k)
                        radius = 2 * old_r + t - 2
                        lens_t = (radius - n + 1) // 2
                        for r in range(1, b):
                            q = max(r * (r - 1) + 1, lower_q)
                            missing = tri(r - 1 - lens_t) - 2 * tri(-1 - lens_t) + tri(-r - 1 - lens_t)
                            if q > min(r * r, r * r - missing):
                                continue
                            final_time = tau(1, q + r)
                            checks += 1
                            local += 1
                            if t + final_time < initial_time:
                                failures.append(dict(b=b, k=k, n=n, initial_radius=old_r,
                                                     initial_size=a, initial_clock=initial_time,
                                                     inter_event_time=t, neutral_lower_size=neutral,
                                                     new_radius=r, survivor=q, lens_radius=radius,
                                                     new_size=q + r, new_clock=final_time))
                                if len(failures) == 20:
                                    return dict(status='COUNTEREXAMPLES', checks=checks,
                                                width_rows=per_width, failures=failures,
                                                CPU_seconds=time.process_time()-start)
                    neutral = f(1, neutral)
                    if time.process_time() - start > 15:
                        return dict(status='INCOMPLETE', checks=checks, width_rows=per_width,
                                    failures=failures, CPU_seconds=time.process_time()-start)
        per_width.append(dict(b=b, tests=local))
    return dict(status='PASS' if not failures else 'COUNTEREXAMPLES', checks=checks,
                width_rows=per_width, failures=failures, CPU_seconds=time.process_time()-start)


if __name__ == '__main__':
    result = run()
    result['scope'] = __doc__
    result['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    Path('research/bridge-sharp-event-charge-check.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))

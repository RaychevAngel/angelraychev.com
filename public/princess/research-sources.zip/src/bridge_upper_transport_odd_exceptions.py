"""Finite residue certificate for seven remaining odd-width budget lines.

The all-length implication is the ordinary affine-insertion proof in the
companion note, not an extrapolation from the checked lengths.
"""
from pathlib import Path
import hashlib
import json
import time

from bridge_corner_frontier import step
from bridge_upper_transport_odd_coupling import physical_step

CASES = ((2, 7), (4, 12), (5, 15), (7, 20), (8, 23), (11, 31), (14, 39))


def advance(b, n, k, state):
    B, X = state
    w = 2 * b + 1
    return step(w, n, k, B, critical=True), physical_step(b, w * n // 2, k, X)


def initial(k, mode):
    m = k // 2
    return ((0, -1, -1), (m, m)) if mode == 0 else ((m,) * 3, (k, k))


def entry(b, k, mode):
    virtual_n = 100000
    A = b * (b + 1) + 1
    state = initial(k, mode)
    trace = [state]
    while True:
        B, X = state
        if B[0] >= A and B[0] == B[1] and B[2] - B[0] in (0, 1) and min(X) >= b * b + 1:
            break
        state = advance(b, virtual_n, k, state)
        trace.append(state)
        assert len(trace) < 1000
    first = advance(b, virtual_n, k, state)
    second = advance(b, virtual_n, k, first)
    D = 2 * k - 2 * b - 1
    assert second == tuple(tuple(x + D for x in row) for row in state)
    largest_source = max(max(B), max(X))
    for B, X in trace + [first]:
        largest_source = max(largest_source, max(B), max(X))
    safe_h = largest_source + max(b * b + 1, k + 2)
    return dict(mode=mode, time=len(trace) - 1, state=state,
                next_state=first, safe_h=safe_h)


def trace(b, n, k, mode):
    h = (2 * b + 1) * n // 2
    state = initial(k, mode)
    out = [state]
    while True:
        B, X = state
        assert max(X) >= max(0, B[2]), (b, n, k, mode, len(out) - 1, state)
        if B[2] == h:
            return out
        state = advance(b, n, k, state)
        out.append(state)
        assert len(out) < 10000


def run():
    started = time.process_time()
    rows = []
    lengths = deadlines = translated_states = 0
    for b, k in CASES:
        w = 2 * b + 1
        D = 2 * k - 2 * b - 1
        entries = [entry(b, k, mode) for mode in (0, 1)]
        safe_h = max(e['safe_h'] for e in entries)
        n0 = max(w + 1, 2 * ((safe_h + w - 1) // w))
        checked = []
        for n in range(w + 1, n0 + 2 * D, 2):
            clocks = []
            for mode in (0, 1):
                actual = trace(b, n, k, mode)
                if n >= n0:
                    assert actual[entries[mode]['time']] == entries[mode]['state']
                clocks.append(len(actual) - 1)
                deadlines += len(actual)
            checked.append([n, *clocks])
            lengths += 1
            assert time.process_time() - started < 10, 'Bounded diagnostic exceeded10 CPU seconds.'
        # Independent finite checks of the exact insertion identity at n0.
        for mode in (0, 1):
            short = trace(b, n0, k, mode)
            long = trace(b, n0 + 2 * D, k, mode)
            e = entries[mode]['time']
            shift = w * D
            assert long[:e + 1] == short[:e + 1]
            assert len(long) == len(short) + 2 * w
            for a, z in zip(short[e:], long[e + 2 * w:]):
                assert z == tuple(tuple(x + shift for x in row) for row in a)
                translated_states += 1
        rows.append(dict(b=b, width=w, budget=k, pair_translation=D,
                         length_period=2 * D, inserted_days=2 * w,
                         first_stable_length=n0, entries=entries,
                         finite_lengths_and_two_clocks=checked))
    return dict(scope=__doc__, status='PASS', domain='All even n>=w on the seven listed width/budget lines.',
                compared_lengths=lengths, coupling_deadlines=deadlines,
                translated_tail_states=translated_states, rows=rows,
                CPU_seconds=time.process_time() - started,
                source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in (Path(__file__), Path('src/bridge_corner_frontier.py'),
                                         Path('src/bridge_upper_transport_odd_coupling.py'))})


if __name__ == '__main__':
    result = run()
    Path('research/bridge-upper-transport-odd-exceptions.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))
    print([(r['width'], r['budget'], r['first_stable_length'], r['length_period']) for r in result['rows']])

"""Bounded physical two-day bridge search; a returned witness is replayed."""
from pathlib import Path
from time import process_time
from itertools import combinations
import argparse
import json
import warnings
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix
from even_bridge_feasibility_profiles import prefix_data


def run(source_size=331, target_size=330, parity=0, budget=89, seconds=2, pyramidal=False):
    start = process_time()
    vertices, orders, _ = prefix_data((4,) * 5)
    all_rooms = set(vertices)
    neighbors = {}
    for v in vertices:
        neighbors[v] = {u for axis in range(5) for step in (-1, 1)
                        if 0 <= v[axis] + step < 4
                        for u in [v[:axis] + (v[axis] + step,) + v[axis + 1:]]}
    source = set(orders[parity][:source_size])
    target = set(orders[parity][:target_size])
    erosion = {v for v in orders[1 - parity] if neighbors[v] <= target}
    bad = sorted(set().union(*(neighbors[v] for v in source)) - erosion)
    good_source = sorted(source)
    index = {v: i for i, v in enumerate(good_source)}
    bad_index = {v: len(source) + i for i, v in enumerate(bad)}
    rows, columns, values = [], [], []
    low, high = [], []
    for v in good_source:
        for w in neighbors[v] - erosion:
            row = len(low)
            rows.extend((row, row)); columns.extend((index[v], bad_index[w]))
            values.extend((1, -1)); low.append(-np.inf); high.append(0)
    if pyramidal:
        for v in good_source:
            for i, j in combinations(range(5), 2):
                for step in (-1, 1):
                    w = list(v)
                    w[i] += step
                    w[j] -= 1
                    if all(0 <= x < 4 for x in w):
                        w = tuple(w)
                        assert w in source
                        row = len(low)
                        rows.extend((row, row)); columns.extend((index[v], index[w]))
                        values.extend((1, -1)); low.append(-np.inf); high.append(0)
    row = len(low)
    for i in range(len(source)):
        rows.append(row); columns.append(i); values.append(1)
    low.append(source_size - budget); high.append(np.inf)
    count = len(source) + len(bad)
    matrix = coo_matrix((values, (rows, columns)), shape=(len(low), count)).tocsr()
    objective = np.array([0] * len(source) + [1] * len(bad), dtype=float)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        answer = milp(objective, integrality=np.ones(count), bounds=Bounds(0, 1),
                      constraints=LinearConstraint(matrix, np.array(low), np.array(high)),
                      options={'time_limit': seconds, 'threads': 1, 'mip_rel_gap': 0.0})
    result = {'source_size': source_size, 'target_size': target_size,
              'parity': parity, 'budget': budget, 'time_limit_seconds': seconds,
              'pyramidal_implications': pyramidal,
              'variables': count, 'constraints': len(low), 'erosion_size': len(erosion),
              'status': int(answer.status), 'message': answer.message,
              'objective': float(answer.fun) if answer.fun is not None else None,
              'dual_bound': float(answer.mip_dual_bound) if answer.get('mip_dual_bound') is not None else None,
              'CPU_seconds': process_time() - start, 'witness_passed': False}
    if answer.x is not None:
        residual = {v for v, i in index.items() if answer.x[i] > 0.5}
        shot1 = source - residual
        next_belief = set().union(*(neighbors[v] for v in residual)) if residual else set()
        shot2 = next_belief - erosion
        final = set().union(*(neighbors[v] for v in next_belief - shot2)) if next_belief - shot2 else set()
        assert len(shot1) <= budget and final <= target
        if len(shot2) <= budget:
            result.update(witness_passed=True, shot_counts=[len(shot1), len(shot2)],
                          final_count=len(final), first_shots=sorted(shot1),
                          second_shots=sorted(shot2), final_support=sorted(final))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=int, default=331)
    parser.add_argument('--target', type=int, default=330)
    parser.add_argument('--parity', type=int, default=0)
    parser.add_argument('--budget', type=int, default=89)
    parser.add_argument('--seconds', type=float, default=2)
    parser.add_argument('--pyramidal', action='store_true')
    args = parser.parse_args()
    result = run(args.source, args.target, args.parity, args.budget, args.seconds, args.pyramidal)
    suffix = '-pyramidal' if args.pyramidal else ''
    output = Path(__file__).resolve().parents[1] / f'research/even-bridge-two-day-milp-p{args.parity}-{args.source}-{args.target}{suffix}.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('first_shots', 'second_shots', 'final_support')}, indent=2))

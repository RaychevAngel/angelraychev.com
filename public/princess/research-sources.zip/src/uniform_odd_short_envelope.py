"""Finite attack on an UNREVIEWED historical-potential proposal; not a theorem."""
import json
from pathlib import Path
from time import process_time
from high_budget_odd_rectangles import potential, J, Q, R


def main():
    start = process_time()
    rows, gaps = [], []
    for b in range(1, 26):
        w, collar = 2*b+1, b*(b+1)
        for n in (2*b+2, 2*b+4, 4*b+8):
            h = w*n//2
            for m in range(collar+1, min(h, collar+4*b+10)):
                d = 2*m-w
                q, r = divmod(2*h-w-1, d)
                c = min(x + potential(b, m, 2*(h-x+min(R(h-x), b, Q(x)-1)))
                        for x in range(collar+1))
                lower = (2*c+m-1)//m
                upper = 2*q + (0 if r == 0 else 1 if 2*J(b, r) <= m else 2)
                if lower < upper:
                    gaps.append([w, n, m, q, r, c, J(b, r), lower, upper])
                rows.append([w, n, m, c, lower, upper])
    result = {
        'status': 'finite candidate check only; generic geometric potential proof and universal corner evaluation not independently reviewed',
        'cases': len(rows), 'gaps': gaps, 'cpu_seconds': process_time()-start, 'rows': rows,
    }
    path = Path(__file__).resolve().parents[1] / 'research/uniform-odd-short-envelope-check.json'
    path.write_text(json.dumps(result, indent=2)+'\n')
    print({'cases': len(rows), 'gaps': len(gaps), 'cpu_seconds': result['cpu_seconds']})


if __name__ == '__main__':
    main()

"""Physical attaining searches in the restricted up/down pyramid family.
A success is an actual upper certificate; a failure proves no unrestricted lower.
"""
from itertools import product
from pathlib import Path
import json

def solve_word(w,n,word,initial=0,ammunition=False):
 vertices=[(x,y)for x in range(w)for y in range(n)];index={v:i for i,v in enumerate(vertices)}
 colors=[sum(1<<i for i,v in enumerate(vertices)if sum(v)%2==p)for p in (0,1)]
 adj=[sum(1<<index[u]for u in ((x-1,y),(x+1,y),(x,y-1),(x,y+1))if u in index)for x,y in vertices]
 def N(S):
  out=0
  while S:
   bit=S&-S;S^=bit;out|=adj[bit.bit_length()-1]
  return out
 def reflect(S):return sum(1<<index[x,n-1-y]for i,(x,y) in enumerate(vertices)if S>>i&1)
 fam=[set(),set()]
 for p in (0,1):
  for first in range((p%2)-2,n,2):
   for diffs in product((-1,1),repeat=w-1):
    hs=[first]
    for d in diffs:hs.append(hs[-1]+d)
    if not all(((p-x)%2)-2<=h<n for x,h in enumerate(hs)):continue
    mask=sum(1<<i for i,(x,y)in enumerate(vertices)if sum((x,y))%2==p and y<=hs[x])
    fam[p].add(mask);fam[1-p].add(reflect(mask))
 for p in (0,1):assert all(N(s)in fam[1-p] for s in fam[p])
 if ammunition:
  from heapq import heappush,heappop
  budget=word[0];start=(colors[initial],initial);best={start:0};queue=[(0,*start)];parent={}
  while queue:
   cost,before,p=heappop(queue)
   if best.get((before,p))!=cost:continue
   if not before:
    path=[];state=(before,p)
    while state!=start:
     old,shot=parent[state];path.append(shot);state=old
    path.reverse()
    return dict(minimum_ammunition=cost,days=len(path),shot_counts=list(map(int.bit_count,path)),family_sizes=list(map(len,fam)))
   for residual in fam[p]:
    used=before.bit_count()-residual.bit_count()
    if residual&~before or used>budget:continue
    target=(N(residual),1-p);value=cost+used
    if value<best.get(target,10**9):
     best[target]=value;parent[target]=((before,p),before^residual);heappush(queue,(value,*target))
  return dict(minimum_ammunition=None)
 current={colors[initial]:[]};counts=[1]
 for t,quota in enumerate(word):
  p=(initial+t)%2;nextstates={}
  for before,trace in current.items():
   for residual in fam[p]:
    if residual&~before or before.bit_count()-residual.bit_count()>quota:continue
    after=N(residual)
    if after not in nextstates:nextstates[after]=trace+[before^residual]
  current=nextstates;counts.append(len(current))
  if not current:break
 if 0 not in current:return dict(win=False,counts=counts,family_sizes=list(map(len,fam)))
 shots=current[0];belief=colors[initial];trace=[]
 for A in shots:
  assert A.bit_count()<=word[len(trace)]
  trace.append(dict(before=belief.bit_count(),shots=[vertices[i]for i in range(len(vertices))if A>>i&1]));belief=N(belief&~A)
 assert belief==0
 return dict(win=True,counts=counts,family_sizes=list(map(len,fam)),trace=trace)

if __name__=='__main__':
 result=[]
 for w,n,m in [(5,16,11),(9,10,21)]:
  if w>5:continue
  for word in ([11,11,11,11,6],[5,11,11,11,11]):
   r=solve_word(w,n,word);result.append(dict(w=w,n=n,word=word,**r));print(w,n,word,r['win'],r['counts'])
 Path('research/supersession-odd-short-physical-check.json').write_text(json.dumps(result,indent=2)+'\n')

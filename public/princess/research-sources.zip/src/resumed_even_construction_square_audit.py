"""Independent height-walk generation and finite solo Bellman certificates.

For square boards, unrestricted interpretation uses the existing ordinary
equal-coordinate compression theorem. No new compression theorem is assumed.
"""
from collections import deque
from itertools import product
from pathlib import Path
import json
import signal
import sys
import time

from resumed_even_construction_prefix import scalar


def prepare(w,n):
    colors=[[(x,y) for x in range(w) for y in range(n) if (x+y)%2==p]
            for p in (0,1)]
    index=[{v:i for i,v in enumerate(row)} for row in colors]
    masks=[];heights=[]
    for p in (0,1):
        walks=[]
        def extend(prefix):
            x=len(prefix)
            if x==w:
                walks.append(tuple(prefix));return
            s=(p-x)%2
            candidates=range(s-2,n,2) if not prefix else (prefix[-1]-1,prefix[-1]+1)
            for a in candidates:
                if s-2<=a<n:
                    extend(prefix+[a])
        extend([])
        row=[]
        for heights_now in walks:
            mask=sum(1<<i for i,(x,y) in enumerate(colors[p]) if y<=heights_now[x])
            row.append((mask,heights_now))
        row.sort(key=lambda pair:(pair[0].bit_count(),pair[0]))
        masks.append([mask for mask,_ in row]);heights.append([a for _,a in row])
    lookup=[{mask:i for i,mask in enumerate(row)} for row in masks]
    hood=[]
    for p in (0,1):
        row=[]
        for mask in masks[p]:
            physical={v for i,v in enumerate(colors[p]) if mask>>i&1}
            neighbors={u for x,y in physical for u in
                       ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                       if 0<=u[0]<w and 0<=u[1]<n}
            nb=sum(1<<index[1-p][v] for v in neighbors)
            assert nb in lookup[1-p]
            row.append(lookup[1-p][nb])
        hood.append(row)
    return dict(colors=colors,ideals=masks,heights=heights,hood=hood,
                sizes=[[mask.bit_count() for mask in row] for row in masks],shape=(w,n))


def audit(w,n,k):
    started=time.monotonic();data=prepare(w,n)
    ideals,sizes,hood=[data[q] for q in ('ideals','sizes','hood')]
    edges=[[],[]];reverse=[ [[] for _ in row] for row in ideals]
    for p in (0,1):
        for i,a in enumerate(ideals[p]):
            options=[]
            for j,r in enumerate(ideals[p]):
                if sizes[p][i]-k<=sizes[p][j]<=sizes[p][i] and r&~a==0:
                    nxt=hood[p][j]
                    options.append((nxt,j))
                    reverse[1-p][nxt].append((p,i))
            edges[p].append(options)
    rank=[[-1]*len(row) for row in ideals]
    queue=deque([(0,0),(1,0)])
    rank[0][0]=rank[1][0]=0
    while queue:
        p,j=queue.popleft()
        for q,i in reverse[p][j]:
            if rank[q][i]<0:
                rank[q][i]=rank[p][j]+1;queue.append((q,i))
    # Exhaustively verify each finite Bellman equation, including lower bound.
    for p in (0,1):
        for i in range(1,len(ideals[p])):
            targets=[rank[1-p][nxt] for nxt,_ in edges[p][i]
                     if rank[1-p][nxt]>=0]
            assert rank[p][i]==(1+min(targets) if targets else -1)
    p=0;i=len(ideals[0])-1;shots=[];witness=[]
    physical=set(data['colors'][p])
    while i:
        nxt,j=next((nxt,j) for nxt,j in edges[p][i]
                   if rank[1-p][nxt]==rank[p][i]-1)
        shot=[v for t,v in enumerate(data['colors'][p])
              if (ideals[p][i]^ideals[p][j])>>t&1]
        assert len(shot)<=k
        survivors=physical-set(shot)
        following={u for x,y in survivors for u in
                   ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                   if 0<=u[0]<w and 0<=u[1]<n}
        expected={v for t,v in enumerate(data['colors'][1-p])
                  if ideals[1-p][nxt]>>t&1}
        assert following==expected
        witness.append({'before':len(physical),'survivor':len(survivors),
                        'next':len(following),'heights':data['heights'][p][i],
                        'survivor_heights':data['heights'][p][j],'shots':shot})
        physical=following;p=1-p;i=nxt
    assert not physical
    reachable={len(ideals[0])-1};layers=[];p=0
    relaxed_tau,clock=scalar(w,n,k)
    for day in range(rank[0][-1]+1):
        minimum=min(sizes[p][i] for i in reachable)
        extremal=[i for i in reachable if sizes[p][i]==minimum]
        layers.append({'day':day,'reachable_count':len(reachable),
                       'minimum_cardinality':minimum,
                       'scalar_minimum':clock[min(day,len(clock)-1)],
                       'extremal_heights':[data['heights'][p][i] for i in extremal]})
        reachable={nxt for i in reachable for nxt,_ in edges[p][i]};p=1-p
    return {'w':w,'n':n,'k':k,'state_counts':list(map(len,ideals)),
            'solo_optimum':rank[0][-1],'scalar_relaxation':relaxed_tau,
            'bellman_equations_checked':sum(map(len,rank))-2,
            'rank_tables':rank,'physical_replay_passed':True,
            'layers':layers,'optimal_solo_witness':witness,
            'seconds':time.monotonic()-started},data


def main():
    output,data=audit(8,8,5)
    path=Path('research/resumed-even-construction-square-8x8-k5.json')
    path.write_text(json.dumps(output,indent=2)+'\n')
    print({k:v for k,v in output.items() if k not in
           ('rank_tables','layers','optimal_solo_witness')},flush=True)
    print('layers',[(x['day'],x['minimum_cardinality'],x['scalar_minimum'],
                     len(x['extremal_heights'])) for x in output['layers']],flush=True)
    # Existing solver is an independent dynamic program and physical replay.
    from pyramidal_time import solve
    def timeout(*_):raise TimeoutError('30-second joint budget reached')
    signal.signal(signal.SIGALRM,timeout);signal.alarm(30)
    started=time.monotonic()
    try:
        joint=solve(data,5)
        joint['seconds']=time.monotonic()-started
    except TimeoutError as error:
        joint={'status':'inconclusive','reason':str(error),'seconds':time.monotonic()-started}
    finally:signal.alarm(0)
    output['joint']=joint
    path.write_text(json.dumps(output,indent=2)+'\n')
    print('joint',{k:v for k,v in joint.items() if k!='shots'},flush=True)


if __name__=='__main__':main()

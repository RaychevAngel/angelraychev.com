#!/usr/bin/env python3
"""Explicit Hamilton cycle witnesses for the odd-grid Hall lemma."""
import json
from pathlib import Path
import time


def edge(a,b):return frozenset((a,b))

def perimeter(lo,width):
    hi=lo+width-1
    path=[(0,c) for c in range(lo,hi+1)]+[(1,hi)]+[(2,c) for c in range(hi,lo-1,-1)]+[(1,lo)]
    return {edge(a,b) for a,b in zip(path,path[1:]+path[:1])}

def even_strip(lo,width):
    assert width>=2 and width%2==0
    E=perimeter(lo,width)
    for c in range(lo+1,lo+width-1,2):
        E.remove(edge((2,c),(2,c+1)))
        E.update((edge((2,c),(1,c)),edge((1,c),(1,c+1)),edge((1,c+1),(2,c+1))))
    return E

def splice(A,B,left,right):
    E=A|B
    E.remove(edge((1,left),(2,left)))
    E.remove(edge((1,right),(2,right)))
    E.update((edge((1,left),(1,right)),edge((2,left),(2,right))))
    return E

def cycle(n,hole):
    r,c=hole
    assert n>=3 and n%2==1 and (r+c)%2==0
    if r==2:
        return {frozenset((2-rr,cc) for rr,cc in e) for e in cycle(n,(0,c))}
    if r==0:
        if c:
            E=even_strip(0,c)
            E.remove(edge((1,c-1),(2,c-1)))
            E.update((edge((1,c-1),(1,c)),edge((1,c),(2,c)),edge((2,c),(2,c-1))))
            if c<n-1:E=splice(E,even_strip(c+1,n-c-1),c,c+1)
            return E
        E=even_strip(1,n-1)
        E.remove(edge((1,1),(2,1)))
        E.update((edge((1,1),(1,0)),edge((1,0),(2,0)),edge((2,0),(2,1))))
        return E
    E=perimeter(c-1,3)
    if c>1:E=splice(even_strip(0,c-1),E,c-2,c-1)
    if c<n-2:E=splice(E,even_strip(c+2,n-c-2),c+1,c+2)
    return E

def main():
    start=time.monotonic();count=0
    for n in range(3,52,2):
        for r in range(3):
            for c in range(n):
                if (r+c)%2:continue
                E=cycle(n,(r,c));V={(rr,cc)for rr in range(3)for cc in range(n)}-{(r,c)}
                adj={v:set() for v in V}
                for e in E:
                    assert len(e)==2
                    a,b=tuple(e)
                    assert a in V and b in V and abs(a[0]-b[0])+abs(a[1]-b[1])==1
                    adj[a].add(b);adj[b].add(a)
                assert all(len(a)==2 for a in adj.values())
                seen=set();todo=[next(iter(V))]
                while todo:
                    a=todo.pop()
                    if a in seen:continue
                    seen.add(a);todo.extend(adj[a]-seen)
                assert seen==V
                count+=1
    out=dict(status='all constructed cycles verified',odd_n_range=[3,51],deleted_majority_vertices_checked=count,
             elapsed_seconds=round(time.monotonic()-start,4))
    p=Path(__file__).resolve().parents[1]/'research/three-row-hamilton-checks.json'
    p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

if __name__=='__main__':main()

"""Corner-only necessary histories with persistent triangle radius bounds.

Research diagnostic. The underlying three-feature model is checked against
the older independent graph before the new history restrictions are used.
No model path is asserted to be physically attainable.
"""
from bisect import bisect_left
from math import isqrt
from pathlib import Path
import argparse
import json
import time

from bridge_corner_frontier import survivor_bound
from resumed_even_construction_formula_clock import model_data
from resumed_even_construction_prefix_arithmetic import diagonal_count


def bits(mask):
    while mask:
        bit = mask & -mask
        mask ^= bit
        yield bit.bit_length()-1


def graph(w,n,k,near_square=True):
    h=w*n//2
    states=[(a,c) for a in range(h+1) for c in range(3) if c<=a<=h-2+c]
    index={s:j for j,s in enumerate(states)}
    relations={}
    for i in range(3):
        for j in range(3):
            lo=max(1,j); hi=h-2+j
            caps=[survivor_bound(w,n,i,j,t,True) for t in range(lo,hi+1)]
            assert all(x<=y for x,y in zip(caps,caps[1:]))
            tail=[0]*(hi-lo+2)
            for z in range(hi-lo,-1,-1):
                tail[z]=tail[z+1]|(1<<index[z+lo,j])
            for q in range(max(1,i),h-2+i+1):
                mask=tail[bisect_left(caps,q)]
                special={}
                r=isqrt(q)+int(isqrt(q)**2<q)
                square_event = q>r*(r-1) if near_square else q==r*r
                if i==1 and j==0 and square_event and 2<=r<w//2:
                    target=q+r
                    bit=1<<index[target,j]
                    if mask&bit:
                        special[1,2*r-1]=bit
                        mask^=bit
                r=(1+isqrt(1+4*q))//2
                if i==0 and j==1 and r*(r-1)==q and 2<=r<w//2:
                    target=r*r
                    bit=1<<index[target,j]
                    if mask&bit:
                        special[0,2*r-2]=bit
                        mask^=bit
                special[-1,-1]=mask
                relations[q,i,j]=special
    rows=[]
    for a,c in states:
        row={}
        if a<=k: row[-1,-1]=1<<index[0,0]
        for q in range(max(1,a-k),a+1):
            for i in range(max(0,c-a+q),c+1):
                for j in range(3):
                    for key,mask in relations.get((q,i,j),{}).items():
                        row[key]=row.get(key,0)|mask
        rows.append(row)
    return states,index,rows


def run(w,n,k,area=True,check=True,near_square=True):
    assert w%2==0 and n>=w and k>w//2
    start=time.process_time(); h=w*n//2; diameter=w+n-2
    states,index,rows=graph(w,n,k,near_square)
    if check:
        old,oldid,oldrows=model_data(w,n,k,True)
        assert old==states and oldid==index
        for a,row in enumerate(rows):
            mask=0
            for x in row.values():mask|=x
            assert mask==oldrows[a],(states[a],mask^oldrows[a])
    masks={}
    for d in range(2):
        for R in range(diameter+1):
            C=sum(D<=R and D%2==d for D in (0,w-1,n-1,diameter))
            size=diagonal_count(w,n,d,R) if area else h
            masks[d,R]=sum(1<<z for z,(a,c) in enumerate(states) if a<=size and c<=C)
    # Infinity means no localization certificate; unlike a literal ball,
    # it must not impose a color-class size restriction at the diameter.
    full=(1<<len(states))-1
    masks[0,diameter]=masks[1,diameter]=full
    front={(diameter,diameter):1<<index[h,2]}; seen=dict(front)
    zero=1<<index[0,0]; layers=[]
    for t in range(4*w*n):
        layers.append(min(states[z][0] for mask in front.values() for z in bits(mask)))
        if any(mask&zero for mask in front.values()):break
        following={}
        for (r0,r1),source in front.items():
            pair=(min(diameter,r1+1),min(diameter,r0+1))
            events={}
            for a in bits(source):
                for key,mask in rows[a].items():events[key]=events.get(key,0)|mask
            for (d,R),mask in events.items():
                new=list(pair)
                if d>=0:new[d]=min(new[d],R)
                new=tuple(new)
                mask &= masks[0,new[0]] & masks[1,new[1]]
                following[new]=following.get(new,0)|mask
        front={pair:mask&~seen.get(pair,0) for pair,mask in following.items() if mask&~seen.get(pair,0)}
        assert front
        for pair,mask in front.items():seen[pair]=seen.get(pair,0)|mask
    else: raise RuntimeError('No capture inside diagnostic bound')
    residual=min(layers[:-1])
    return dict(shape=[w,n],budget=k,area_bounds=area,near_square=near_square,solo=t,residual=residual,
                full_lower=2*t-int(2*residual<=k),layers=layers,
                state_count=sum(mask.bit_count() for mask in seen.values()),
                radius_pairs=len(seen),base_rows_checked=len(rows) if check else 0,
                CPU_seconds=time.process_time()-start)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cases',default='12,12,16;8,9,10;12,12,7;16,16,18');p.add_argument('--output',default='research/bridge-corner-reach-check.json');a=p.parse_args()
    out=[]
    for case in a.cases.split(';'):
        row=run(*map(int,case.split(',')));out.append(row)
        Path(a.output).write_text(json.dumps(out,indent=2)+'\n')
        print({k:v for k,v in row.items() if k!='layers'},flush=True)

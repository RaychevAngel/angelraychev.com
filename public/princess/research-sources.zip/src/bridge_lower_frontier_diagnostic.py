"""Recover a time-filtered necessary-model witness, never a physical strategy."""
from collections import deque
from pathlib import Path
import json
import argparse
import time
from bridge_lower_frontier_flagged import base_cache, flagged
from bridge_lower_frontier_nine import root, pronic, quadratic, validate_edge

def bfs(masks, seeds):
    dist=[None]*len(masks); parent=[None]*len(masks);todo=deque(seeds)
    for a in seeds:dist[a]=0
    while todo:
        a=todo.popleft();bits=masks[a]
        while bits:
            bit=bits&-bits;bits-=bit;d=bit.bit_length()-1
            if dist[d] is None:dist[d]=dist[a]+1;parent[d]=a;todo.append(d)
    return dist,parent

def chain(parent,end):
    path=[end]
    while parent[path[-1]] is not None:path.append(parent[path[-1]])
    return path[::-1]

def anchored(b,n,k,phase):
    h=(2*b+1)*n//2;a=h;out=[a]
    while a:
        a=max(0,a-k)
        if a:a+=min(root(a),b,quadratic(1,h-a)) if phase==0 else min(pronic(a),b+1,root(h-a))
        phase^=1;out.append(a)
    return out

def square_successor_flag(states,rows,b,n,k):
    """One consequence of exact-square localization: corner-reach bounds."""
    states=list(states);ids={s:i for i,s in enumerate(states)}
    # Keep the square-equality diagnostic subcritical; critical rigidity
    # is a separate equality analysis, not inferred from its scalar bound.
    extras={r:len(states)+r-2 for r in range(2,b)}
    rows=[list(row)+[0]*len(extras) for row in rows]
    for a,source in enumerate(states):
        for r,extra in extras.items():
            old=ids[(r*(r+1),0,1)];p=source[0]-r*r
            if 0<=p<=k and rows[p][a]>>old&1:
                rows[p][a]=(rows[p][a]&~(1<<old))|(1<<extra)
    states.extend((r*(r+1),0,1,7)for r in extras)
    for r,extra in extras.items():
        radius=2*r
        max_c=1+int(radius>=2*b)
        max_e=int(radius>=n)+int(radius>=2*b+n-2)
        allowed=sum(1<<d for d,s in enumerate(states)if s[1]<=max_c and s[2]<=max_e)
        old=ids[(r*(r+1),0,1)]
        for p in range(k+1):rows[p][extra]=rows[p][old]&allowed
    masks=[0]*len(states)
    for row in rows:
        for a,bits in enumerate(row):masks[a]|=bits
    return states,masks,rows

def radius_caps(d,r,w,n):
    if d==0:return 1+int(r>=w-1),int(r>=n)+int(r>=w+n-3)
    return int(r>=n-1)+int(r>=w+n-2),int(r>=1)+int(r>=w)

def persistent_path(states,masks,seeds,w,n,max_seconds=50,cardinality_cap=None):
    """Monotone radius dominance gives a bounded exact shortest-path search."""
    started=time.monotonic();infinity=w+n-2
    seedkeys=[(s,infinity,infinity)for s in seeds]
    queue=deque(seedkeys);parents={s:None for s in seedkeys};distance={s:0 for s in seedkeys}
    frontiers={s:[(infinity,infinity)]for s in seeds}
    feature_masks={}
    for c in range(3):
        for e in range(3):feature_masks[c,e]=sum(1<<i for i,s in enumerate(states)if s[1]<=c and s[2]<=e)
    checked=0
    while queue:
        key=queue.popleft();a,r0,r1=key;depth=distance[key]
        if states[a][0]==0:
            path=[key]
            while parents[path[-1]] is not None:path.append(parents[path[-1]])
            residual=min(states[key[0]][0]for key,level in distance.items()if level<depth)
            return path[::-1],dict(augmented_states=len(parents),edges_considered=checked,seconds=time.monotonic()-started,tail_days=depth,penultimate_residual=residual)
        nr0,nr1=min(infinity,r1+1),min(infinity,r0+1)
        c0,e0=radius_caps(0,nr0,w,n);c1,e1=radius_caps(1,nr1,w,n)
        bits=masks[a]&feature_masks[min(c0,c1),min(e0,e1)]
        while bits:
            bit=bits&-bits;bits-=bit;d=bit.bit_length()-1;checked+=1
            rr0,rr1=nr0,nr1;target=states[d]
            if len(target)>3 and target[3]==4:rr0=min(rr0,2*root(target[0])-2)
            if len(target)>3 and target[3]==7:rr1=min(rr1,2*quadratic(1,target[0])-1)
            if cardinality_cap is not None and target[0]>cardinality_cap(rr0,rr1):continue
            old=frontiers.setdefault(d,[])
            if any(x>=rr0 and y>=rr1 for x,y in old):continue
            # Entries from earlier depths must remain as valid dominance witnesses.
            old.append((rr0,rr1));following=(d,rr0,rr1)
            assert following not in parents
            parents[following]=key;distance[following]=depth+1;queue.append(following)
        if len(parents)>250000 or checked>120000000 or time.monotonic()-started>max_seconds:
            raise RuntimeError(dict(bounded_stop=True,augmented_states=len(parents),edges_considered=checked,seconds=time.monotonic()-started))
    raise RuntimeError('No capture state in persistent model')

def run(square_memory=False,persistent=False):
    b,n,k=12,26,13;h=(2*b+1)*n//2
    data,cached=base_cache(b,n,k);assert cached
    states,masks,rows=flagged(data,b,n,k,'forbid-pair',return_weighted=True)
    if square_memory or persistent:states,masks,rows=square_successor_flag(states,rows,b,n,k)
    start=states.index((h,2,2));zero=states.index((0,0,0))
    pre,pre_parent=bfs(masks,[start])
    at28=[i for i,s in enumerate(states)if pre[i] is not None and pre[i]<=28 and s[0]>=h-111]
    detail={}
    if persistent:
        augmented,detail=persistent_path(states,masks,at28,2*b+1,n)
        tail=[x[0]for x in augmented]
    else:
        post,post_parent=bfs(masks,at28);tail=chain(post_parent,zero)
    head=chain(pre_parent,tail[0]);path=[start]*(28-pre[tail[0]])+head+tail[1:]
    anchors=[anchored(b,n,k,p)for p in(0,1)]
    witness=[]
    for day,(a,d) in enumerate(zip(path,path[1:]),1):
        source=states[a];target=states[d];costs=[p for p in range(k+1)if rows[p][a]>>d&1]
        assert costs
        choices=[]
        if target[0]==0:choices=[(source[0],None,None)]
        else:
            for p in costs:
                for i in range(source[1]+1):
                    for u in range(source[2]+1):
                        try:validate_edge(b,h,k,source[:3],target[:3],p,i,u,strong_band=True)
                        except AssertionError:continue
                        choices.append((p,i,u))
        assert choices,(source,target,costs)
        p,i,u=min(choices,key=lambda z:(-z[0],-(z[1] or 0),-(z[2] or 0)))
        row=dict(day=day,source=source,target=target,cost=p,anchored_sizes=[x[day]if day<len(x)else 0 for x in anchors])
        if i is not None:
            row.update(survivor=(source[0]-p,i,u),surplus=target[0]-source[0]+p,closed_surplus=target[0]-source[0]+p+i-target[2])
        witness.append(row)
    better=[r for r in witness if r['target'][0]<min(r['anchored_sizes'])]
    out=dict(scope=__doc__,shape=[2*b+1,n],budget=k,source_sha256=data['source_sha256'],model_sha256=data['model_sha256'],mode='forbid-pair',square_successor_memory=square_memory or persistent,persistent_corner_reach=persistent,time28_joint_barrier=True,solo_days=len(witness),day28_state=states[path[28]],first_faster_than_both=better[0]if better else None,search=detail,witness=witness)
    if persistent:
        out['full_lower']=2*len(witness) if 2*detail['penultimate_residual']>k else 2*len(witness)-1
        out['square_trigger_radii']=[2,b-1]
    suffix='-persistent'if persistent else('-square'if square_memory else'')
    Path(f'research/bridge-lower-frontier-filtered-witness{suffix}.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({key:value for key,value in out.items()if key!='witness'}))
    if better:
        for row in witness[max(0,better[0]['day']-5):better[0]['day']+5]:print(json.dumps(row))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--square-memory',action='store_true');parser.add_argument('--persistent',action='store_true');args=parser.parse_args()
    run(args.square_memory,args.persistent)

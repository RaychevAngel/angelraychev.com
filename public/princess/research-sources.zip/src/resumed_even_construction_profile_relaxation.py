"""Corner-profile relaxation that discards all same-corner shape containment.

Finite diagnostic for a prospective uniform conditional isoperimetric theorem.
Source profiles are obtained from pyramids, so only squares inherit existing
unrestricted compression; this is not an uncompressed conditional profile.
"""
from collections import defaultdict,deque
from pathlib import Path
import argparse,json,time

from resumed_even_construction_square_audit import prepare
from resumed_even_construction_ammunition import labels


def run(w,k):
    started=time.monotonic();d=prepare(w,w)
    I,S,H=[d[q] for q in ('ideals','sizes','hood')]
    features=[];transitions=set()
    for p in (0,1):
        features.append([(s,sum((x+y)%2==p and y<=a[x]
                               for x,y in ((0,0),(0,w-1),(w-1,0),(w-1,w-1))))
                        for s,a in zip(S[p],d['heights'][p])])
    for p in (0,1):
        for j,R in enumerate(I[p]):
            transitions.add((features[p][j],features[1-p][H[p][j]]))
    states=set(features[0]+features[1]);options=defaultdict(dict)
    for before in states:
        a,c=before
        for (s,z),nxt in transitions:
            cost=a-s
            # R subset A implies source corner inclusion, and removed source
            # corners cannot exceed the number of inspected cells.
            if 0<=cost<=k and z<=c<=z+cost:
                options[before][nxt]=min(cost,options[before].get(nxt,k+1))
    h=w*w//2;initial=((h,2),(h,2));queue=deque([(initial,0)])
    seen={initial};checked=0
    while queue:
        (a,b),depth=queue.popleft()
        if a[0]+b[0]<=k:break
        for aa,cost in options[a].items():
            for bb,other in options[b].items():
                if cost+other>k:continue
                nxt=tuple(sorted((aa,bb)));checked+=1
                if nxt not in seen:seen.add(nxt);queue.append((nxt,depth+1))
    else:raise AssertionError('no terminal')
    reverse={s:[] for s in states}
    for a,row in options.items():
        for b,cost in row.items():reverse[b].append((a,cost))
    F=labels(reverse,[(0,0)])
    base=json.loads(Path(f'research/resumed-even-construction-corner-count-{w}x{w}-k{k}.json').read_text())
    old={tuple(row['before']):{tuple(b):c for b,c in row['targets']} for row in base['options']}
    added=[(a,b,c) for a,row in options.items()for b,c in row.items()
           if c<old.get(a,{}).get(b,k+1)]
    return {'shape':[w,w],'budget':k,'profile_triples':len(transitions),
            'joint_lower':depth+1,'joint_states':len(seen),'joint_edges':checked,
            'ammo_lower':F[(h,2)][0],'extra_relaxed_edges':len(added),
            'seconds':time.monotonic()-started,
            'profiles':[{'survivor':a,'neighborhood':b}for a,b in sorted(transitions)],
            'scope':'Finite corner-conditioned pyramid neighborhood profile plus only size/corner survivor containment. General uncompressed profile remains unproved.'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--w',type=int,default=8)
    p.add_argument('--k',type=int,default=5);a=p.parse_args();out=run(a.w,a.k)
    Path(f'research/resumed-even-construction-profile-relaxation-{a.w}x{a.w}-k{a.k}.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='profiles'})

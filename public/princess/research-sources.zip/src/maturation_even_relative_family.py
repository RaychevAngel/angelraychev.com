#!/usr/bin/env python3
"""Exact small relative-profile test via valid diagonal compression."""
from itertools import product
from pathlib import Path
import json
import time
import sys
from maturation_even_boundary_family import Family


def neighborhood_size(h, counts):
    if not counts:
        return 0
    full = [a == h+2*i+1 for i, a in enumerate(counts)]
    out = counts[0]-int(full[0])
    for i, a in enumerate(counts):
        below = counts[i+1]-int(full[i+1]) if i+1 < len(counts) else 0
        out += max(a+int(a > 0), below)
    return out


def is_hybrid(h, counts):
    counts = list(counts)
    while counts and counts[0] == 0:
        h += 2
        counts.pop(0)
    while counts and counts[-1] == 0:
        counts.pop()
    if not counts:
        return True
    if 0 in counts:
        return False
    full = 0
    while full < len(counts) and counts[full] == h+2*full+1:
        full += 1
    if full == len(counts):
        return True
    first = counts[full]
    ramp = 1
    while full+ramp < len(counts) and counts[full+ramp] == first+ramp:
        ramp += 1
    if full+ramp == len(counts):
        return True
    return full+ramp+1 == len(counts) and counts[-1] <= first+ramp


def main():
    start = time.process_time()
    parents = [Family(0, 1, 3, 2), Family(0, 2, 2, 4, 2),
               Family(2, 1, 2, 4, 2), Family(3, 1, 2, 5, 3),
               Family(3, 0, 4, 3), Family(4, 0, 3, 4),
               Family(2, 2), Family(2, 2, 1, 6), Family(4, 1, 1, 6)]
    followup = "--followup" in sys.argv
    if followup:
        parents = [Family(0, 3, 3, 1), Family(0, 3, 4, 1, 2),
                   Family(1, 3, 3, 1), Family(2, 2, 4, 1, 2),
                   Family(2, 3, 3, 2, 1), Family(4, 2, 3, 1),
                   Family(0, 3, 3, 2, 1)]
    checked = 0
    differences = []
    trim_differences = []
    for f in parents:
        a = f.counts()
        size = sum(a)
        best = [None]*(size+1)
        hybrid = [None]*(size+1)
        for c in product(*(range(x+1) for x in a)):
            checked += 1
            k = sum(c)
            n = neighborhood_size(f.h, c)
            if best[k] is None or n < best[k][0]:
                best[k] = n, c
            if is_hybrid(f.h, c) and (hybrid[k] is None or n < hybrid[k][0]):
                hybrid[k] = n, c
        for k in range(size+1):
            if best[k][0] != hybrid[k][0]:
                differences.append({"parent": f.__dict__, "parent_counts": a,
                                    "survivor_size": k,
                                    "exact": best[k], "hybrid": hybrid[k]})
            trim = f.truncate(k)
            n = neighborhood_size(trim.h, trim.counts())
            if n != best[k][0]:
                trim_differences.append({"parent": f.__dict__, "parent_counts": a,
                                         "survivor_size": k, "exact": best[k],
                                         "trim_count": n, "trim": trim.__dict__})
    out = {"scope": "Exact finite relative profiles by subset-preserving diagonal compression",
           "parents_checked": len(parents), "count_vectors_checked": checked,
           "hybrid_mismatches": differences,
           "diagonal_order_truncation_mismatches": trim_differences,
           "cpu_seconds": round(time.process_time()-start, 6)}
    name = "maturation-relative-family-followup-check.json" if followup else "maturation-relative-family-check.json"
    target = Path(__file__).resolve().parents[1]/"research"/name
    target.write_text(json.dumps(out, indent=2)+"\n")
    print(json.dumps({**out, "hybrid_mismatches": differences[:2],
                     "diagonal_order_truncation_mismatches": trim_differences[:2]}))


if __name__ == "__main__":
    main()

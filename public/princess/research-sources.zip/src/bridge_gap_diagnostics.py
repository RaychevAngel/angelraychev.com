"""Named, certified lower models versus physical prefix upper constructions.

No claim that the compared upper family is optimal. Lower-model paths are
not assumed physically attainable. These finite diagnostics select proof work.
"""
from collections import deque
from pathlib import Path
import argparse, hashlib, json, time
from resumed_even_construction_formula_clock import clock
from resumed_even_construction_prefix import PrefixGame


def neighborhood(w, n, cells):
    return {z for x, y in cells for z in ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
            if 0 <= z[0] < w and 0 <= z[1] < n}


def prefix_upper(w, n, k):
    g = PrefixGame(w, n)
    first = (0, g.full)
    queue = deque([(first, 0)])
    parents = {first: None}
    terminal = None
    last_depth = None
    minima = []
    while queue:
        state, depth = queue.popleft()
        if last_depth is not None and depth > last_depth:
            break
        p, mask = state
        size = mask.bit_count()
        if depth == len(minima):
            minima.append(size)
        else:
            minima[depth] = min(minima[depth], size)
        if size <= k:
            last_depth = depth
            if terminal is None or size < terminal[1].bit_count():
                terminal = state
            continue
        for survivor in g.prefixes[p][size-k]:
            if survivor & ~mask:
                continue
            nxt = (1-p, g.hood(p, survivor))
            if nxt not in parents:
                parents[nxt] = (state, survivor)
                queue.append((nxt, depth+1))
    assert terminal is not None
    steps = [(terminal, 0)]
    state = terminal
    while parents[state] is not None:
        state, survivor = parents[state]
        steps.append((state, survivor))
    steps.reverse()
    shots = [{v for i, v in enumerate(g.colors[p]) if (mask ^ survivor) >> i & 1}
             for (p, mask), survivor in steps]
    vertices = {(x,y) for x in range(w) for y in range(n)}
    def replay(sequence, initial):
        A = set(initial)
        for day, shot in enumerate(sequence, 1):
            assert len(shot) <= k and shot <= vertices
            A -= shot
            if not A:
                return day
            A = neighborhood(w, n, A)
        raise AssertionError('No physical capture')
    assert replay(shots, g.colors[0]) == len(shots)
    full = shots + shots[::-1]
    if 2 * len(shots[-1]) <= k:
        reflect = (lambda S: {(w-1-x,y) for x,y in S}) if w % 2 == 0 else (lambda S: {(x,n-1-y) for x,y in S})
        full = shots[:-1] + [shots[-1] | reflect(shots[-1])] + [reflect(S) for S in shots[-2::-1]]
    capture = replay(full, vertices)
    return dict(solo=len(shots), terminal_size=len(shots[-1]), full_upper=capture,
                states=len(parents), layer_minima=minima,
                solo_shots=[sorted(S) for S in shots], full_shots=[sorted(S) for S in full[:capture]],
                physical_replay=True)


def run(w, n, k):
    assert w <= n and w*n % 2 == 0 and k > w//2
    started = time.process_time()
    tau, sizes, info = clock(w, n, k, critical=True)
    lower = 2*tau - int(2*sizes[-1] <= k)
    upper = prefix_upper(w, n, k)
    assert lower <= upper['full_upper']
    return dict(shape=[w,n], budget=k,
                lower_model='Uniform size-corner model including proved critical filter; no erosion refinement.',
                solo_lower=tau, terminal_model_minimum=sizes[-1], full_lower=lower,
                physical_upper=upper['full_upper'], compared_gap=upper['full_upper']-lower,
                model_layer_minima=sizes, model=info, upper=upper,
                CPU_seconds=time.process_time()-started)


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--cases', default='8,8,5;12,12,7;16,16,9;24,24,13;32,32,17;8,10,5;12,14,7;16,18,9;24,26,13;7,8,4;9,10,5;11,12,6')
    p.add_argument('--output', default='research/bridge-gap-diagnostics.json')
    args=p.parse_args(); rows=[]
    sources={Path(__file__).name:hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    for case in args.cases.split(';'):
        row=run(*map(int,case.split(',')));rows.append(row)
        Path(args.output).write_text(json.dumps(dict(scope=__doc__, source_sha256=sources, rows=rows),indent=2)+'\n')
        print({k:v for k,v in row.items() if k not in ('upper','model','model_layer_minima')},flush=True)

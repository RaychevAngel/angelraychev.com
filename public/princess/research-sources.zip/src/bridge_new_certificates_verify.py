"""Independent literal replay of new upper witnesses and old necessary-model bounds."""
from pathlib import Path
import json
from resumed_even_construction_formula_clock import clock


def verify(path):
    d=json.loads(Path(path).read_text());w,n=d['shape'];k=d['budget']
    board={(x,y) for x in range(w) for y in range(n)}
    solo=[set(map(tuple,s)) for s in d['schedule']]
    assert all(s<=board and len(s)<=k for s in solo)
    initial_phase=d.get('initial_prefix_phase',0)
    def replay(initial,shots):
        A=set(initial);sizes=[len(A)]
        for day,S in enumerate(shots,1):
            A-=S
            if not A:return day,sizes
            A={(x+dx,y+dy) for x,y in A for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))
               if 0<=x+dx<w and 0<=y+dy<n}
            sizes.append(len(A))
        raise AssertionError('capture not established')
    # The support itself identifies which initial color the witness addresses.
    initial_phase=next(iter(solo[0]))[0]+next(iter(solo[0]))[1]
    initial_phase%=2
    solo_day,sizes=replay({z for z in board if sum(z)%2==initial_phase},solo)
    full_day,_=replay(board,solo+solo[::-1])
    tau,model_sizes,_=clock(w,n,k,critical=True)
    lower=2*tau-int(2*model_sizes[-1]<=k)
    assert lower==full_day==d['full_capture_day']
    return dict(shape=[w,n],budget=k,solo_days=solo_day,full_days=full_day,
                independent_physical_replay=True,accepted_model_solo_lower=tau,
                model_preterminal_minimum=model_sizes[-1],physical_full_lower=lower,
                exact_full_value=full_day,source=str(path))

if __name__=='__main__':
    rows=[verify(p) for p in ['research/bridge-upper-transport-12x14-k7-t48.json',
        'research/bridge-upper-transport-16x16-k9-t56-p1.json',
        'research/bridge-upper-transport-16x18-k9-t72-p1.json']]
    Path('research/bridge-new-certificates-check.json').write_text(json.dumps(dict(
        status='PASS',rows=rows,scope='Independent finite physical replay plus the previously proved corner-merger necessary model. No Lean claim or infinite family inference.'),indent=2)+'\n')
    print(rows)

"""Full-board varying-budget counterexample to all-corner prefix normal form.

The successful physical schedule is replayed directly. Restricted failure
is a complete fixed-horizon reachability calculation on every reflected
and axis-permuted weightlex prefix; no isoperimetric claim is assumed.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import permutations,product
import json
from pathlib import Path
from time import process_time


def run():
    start=process_time();root=Path(__file__).resolve().parents[1]
    shape=(6,6);vertices=list(product(range(6),repeat=2));index={v:i for i,v in enumerate(vertices)}
    color_masks=[sum(1<<i for i,v in enumerate(vertices)if sum(v)%2==p)for p in(0,1)]
    adjacency=[]
    for v in vertices:
        adjacency.append(sum(1<<index[u]for u in vertices
                             if sum(abs(a-b)for a,b in zip(u,v))==1))
    def mask(rooms):return sum(1<<index[tuple(v)]for v in rooms)
    @lru_cache(None)
    def N(a):
        hood=0
        while a:
            bit=a&-a;a-=bit;hood|=adjacency[bit.bit_length()-1]
        return hood
    prefixes=[{0},{0}]
    for reflection in product((0,1),repeat=2):
        transformed=[tuple(5-v[j]if reflection[j]else v[j]for j in range(2))for v in vertices]
        for perm in permutations(range(2)):
            for p in(0,1):
                order=sorted([i for i,v in enumerate(vertices)if sum(v)%2==p],
                             key=lambda i:(sum(transformed[i]),tuple(-transformed[i][j]for j in perm)))
                a=0
                for i in order:a|=1<<i;prefixes[p].add(a)
    assert all(N(a)in prefixes[1-p]for p in(0,1)for a in prefixes[p])
    @lru_cache(None)
    def options(p,a,m):
        return tuple((N(r),a.bit_count()-r.bit_count())for r in prefixes[p]
                     if not r&~a and a.bit_count()-r.bit_count()<=m)
    states={tuple(color_masks)};layers=[]
    for m in(6,8,5,6):
        following=set()
        for a,b in states:
            for ar,cost in options(0,a,m):
                for br,other in options(1,b,m-cost):following.add((br,ar))
        states=following
        layers.append({'budget':m,'states':len(states),
                       'minimum_belief_size':min(a.bit_count()+b.bit_count()for a,b in states)})
    assert layers[-1]['minimum_belief_size']==20
    original=json.loads((root/'research/even-bridge-full-prefix-counterexample-6x6.json').read_text())
    shots=[r['shots']for r in original['schedule']]
    shots.append([v for v in vertices if sum(v)%2==1])
    quotas=(6,8,5,6,18);belief=(1<<36)-1;actual=[]
    for day,(rooms,m)in enumerate(zip(shots,quotas),1):
        S=mask(rooms);assert len(rooms)==S.bit_count()<=m
        R=belief&~S;following=N(R)
        actual.append({'day':day,'budget':m,'belief_size':belief.bit_count(),
                       'shots':rooms,'survivor_size':R.bit_count(),
                       'following_belief_size':following.bit_count()})
        belief=following
    assert belief==0
    return {'shape':shape,'initial':'all36rooms','quotas':quotas,
            'prefix_counts':list(map(len,prefixes)),'prefix_neighborhood_closed':True,
            'restricted_layers':layers,'restricted_last_required':20,'last_available':18,
            'unrestricted_physical_replay_passed':True,'physical_schedule':actual,
            'CPU_seconds':process_time()-start,
            'scope':'Counterexample to full-board prefix-survivor preservation for prescribed varying daily budgets. Does not refute constant-budget full-board optimality.'}


if __name__=='__main__':
    data=run();root=Path(__file__).resolve().parents[1]
    (root/'research/even-bridge-full-board-prefix-failure-6x6.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({k:v for k,v in data.items()if k!='physical_schedule'},indent=2))

#!/usr/bin/env python3
"""Independent coordinate-profile audit of the uniform solo-time sandwich.
This finite check supplements the ordinary all-parameter proof; it is not it.
"""
from collections import deque
from math import isqrt
import json
from pathlib import Path
from time import process_time

def roots(z):
    r=isqrt(z)
    r += r*r<z
    q=r
    while q*(q+1)<z:q+=1
    while q and (q-1)*q>=z:q-=1
    return r,q

def direct_profiles(n,w):
    vertices=[(x,y) for x in range(n) for y in range(w)]
    order=[sorted((v for v in vertices if sum(v)%2==p),key=lambda v:(sum(v),v[0])) for p in (0,1)]
    neighbors={v:{u for u in vertices if abs(v[0]-u[0])+abs(v[1]-u[1])==1} for v in vertices}
    g=[]
    for p in (0,1):
        seen=set(); row=[0]
        for v in order[p]:
            seen|=neighbors[v]
            assert seen==set(order[1-p][:len(seen)])
            row.append(len(seen))
        g.append(row)
    return g

def exact(g,m):
    start=(len(g[0])-1,len(g[1])-1)
    queue=deque([(start,0)]);seen={start}
    while queue:
        (a,b),t=queue.popleft()
        if a+b<=m:return t+1
        for p in range(m+1):
            nxt=(g[1][max(0,b-(m-p))],g[0][max(0,a-p)])
            if nxt not in seen:seen.add(nxt);queue.append((nxt,t+1))
    return None

def main():
    start=process_time(); lemmas=0; cases=[]
    for w,n in [(3,3),(3,5),(3,7),(5,5),(5,7),(7,7)]:
        g=direct_profiles(n,w); E=len(g[0])-1;M=E-1;b=(w-1)//2
        I=[[max(k for k,v in enumerate(g[p]) if v<=z) for z in range((M if p==0 else E)+1)] for p in (0,1)]
        for z in range(M):
            assert I[0][z]==z-min(roots(z)[1],b,roots(M-z)[1])
        assert I[0][M]==E
        for z in range(E+1):
            assert I[1][z]==z-min(roots(z)[0],b+1,1+roots(E-z)[0])
        for x in range(M+1):
            for y in range(M+1-x):
                assert I[0][x]+I[1][y]<=I[0][x+y];lemmas+=1
                if x>=2:assert I[1][x]+I[0][y]<=I[1][x+y];lemmas+=1
        for m in range(b+1,E+M+1):
            ds=[(0,0)]
            while ds[-1][0]<E and ds[-1][1]<M:
                d0,d1=ds[-1]
                ds.append((I[0][min(M,d1+m)],I[1][min(E,d0+m)]))
                assert len(ds)<2*(E+M)+1
            tau=len(ds)-1
            actual=exact(g,m)
            assert actual in (2*tau-1,2*tau),(w,n,m,tau,actual)
            cases.append(dict(width=w,length=n,budget=m,solo=tau,full=actual))
    return dict(status='PASS',inverse_concentration_inequalities=lemmas,cases=cases,cpu_seconds=process_time()-start,scope='Finite independent coordinate-profile and exact two-count checks; the all-parameter theorem is established by the separate ordinary proof audit.')
if __name__=='__main__':
    result=main();out=Path('research/uniform-odd-solo-bound-independent-check.json');out.write_text(json.dumps(result,indent=2)+'\n'); print({k:v for k,v in result.items() if k!='cases'},'cases',len(result['cases']))

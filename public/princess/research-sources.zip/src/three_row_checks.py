#!/usr/bin/env python3
"""Bounded attacks on the 3-by-n, two-probe proof and its explicit sweep."""
import json
from pathlib import Path
import time


def graph(n):
    V=[(r,c) for r in range(3) for c in range(n)]
    idx={v:i for i,v in enumerate(V)}
    adj=[]
    for r,c in V:
        adj.append(sum(1<<idx[w] for w in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)) if w in idx))
    def N(a):
        out=0
        while a:
            bit=a&-a;a-=bit;out|=adj[bit.bit_length()-1]
        return out
    return V,idx,N


def phase(n):
    if n==2:
        return [[(0,1),(1,0)],[(1,1),(2,0)]]
    if n==3:
        return [[(0,1),(1,0)],[(0,2),(1,1)],[(1,0),(1,2)],[(1,1),(2,0)],[(1,2),(2,1)]]
    shots=[[(0,1),(1,0)],[(0,2),(1,1)],[(1,0),(2,1)],[(0,2),(1,1)],[(1,2),(2,1)]]
    for j in range(2,n-2):
        shots.extend([[(0,j),(2,j)],[(0,j+1),(1,j)],[(1,j+1),(2,j)]])
    shots.extend([[(0,n-2),(1,n-1)],[(1,n-2),(2,n-3)],[(1,n-1),(2,n-2)]])
    return shots


def main():
    start=time.monotonic();counts=[]
    for n in range(2,7):
        V,idx,N=graph(n)
        ps=[sum(1<<i for i,v in enumerate(V) if sum(v)%2==p) for p in (0,1)]
        total=0;critical=0
        for p,P in enumerate(ps):
            a=P
            while True:
                b=N(a);r=a.bit_count();s=b.bit_count();total+=1
                if n%2==0:
                    h=3*n//2
                    assert s>=r
                    assert (s==r)==(a in (0,P))
                    if s==r+1 and r<=h-2:
                        # Reflect to the parity whose outer corners are on the left.
                        aa={V[i] for i in range(len(V)) if a>>i&1}
                        if p:aa={(rr,n-1-cc) for rr,cc in aa}
                        valid=False
                        for j in range(n//2):
                            pre={(0,2*i) for i in range(j)}|{(2,2*i) for i in range(j)}|{(1,2*i+1) for i in range(j)}
                            for extra in (set(),{(0,2*j)},{(2,2*j)},{(0,2*j),(2,2*j)}):
                                valid |= aa==pre|extra
                        assert valid
                        critical+=1
                        # Exhaustively attack two consecutive efficient ordinary steps.
                        bi=[i for i in range(len(V)) if b>>i&1]
                        for ix,x in enumerate(bi):
                            for y in bi[ix+1:]:
                                rr=b&~((1<<x)|(1<<y))
                                if rr:
                                    assert N(rr).bit_count() != r
                else:
                    h=(3*n-1)//2
                    if p==1 and a and a!=P:
                        assert s>=r+2
                    if p==0 and 0<r<=h-1:
                        assert s>=r+1
                    if p==0 and r>=h:
                        assert b==ps[1]
                if not a:break
                a=(a-1)&P
        counts.append(dict(n=n,subsets=total,critical_small_sets=critical))
    schedules=[]
    for n in range(2,101):
        shots=phase(n)
        assert len(shots)==3*n-4
        assert all({sum(v)%2 for v in s}=={(1+t)%2} for t,s in enumerate(shots))
        # Verify the single-cohort invariant using actual room sets.
        B={(r,c) for r in range(3) for c in range(n) if (r+c)%2==1}
        for t,s in enumerate(shots):
            R=B-set(s)
            if not R:
                assert t==len(shots)-1
                B=set();break
            B={(rr,cc) for r,c in R for rr,cc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)) if 0<=rr<3 and 0<=cc<n}
            if n>=4 and t==4:
                assert B=={(r,c) for r in range(3) for c in range(2+(r==1),n,2)}
        assert not B
        second=shots if n%2 else [[(r,n-1-c) for r,c in s] for s in shots]
        B={(r,c) for r in range(3) for c in range(n)}
        for t,s in enumerate(shots+second):
            R=B-set(s)
            if not R:
                assert t==6*n-9
                B=set();break
            B={(rr,cc) for r,c in R for rr,cc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)) if 0<=rr<3 and 0<=cc<n}
        assert not B
        schedules.append(dict(n=n,turns=2*len(shots)))
    out=dict(status='all checks passed',local_cases=counts,explicit_schedules=schedules,
             elapsed_seconds=round(time.monotonic()-start,4),
             boundary='Targeted finite checks; all-parameter proof is in three-row-investigation.md, not Lean verified.')
    dest=Path(__file__).resolve().parents[1]/'research/three-row-checks.json'
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='explicit_schedules'},indent=2))


if __name__=='__main__':main()

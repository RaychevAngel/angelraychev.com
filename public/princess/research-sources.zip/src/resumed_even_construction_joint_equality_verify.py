"""Independent equality-graph and filtered-clock verifier.

Rebuilds weighted edges from separate budget-indexed bitset relations, then
expands component transitions rather than testing a list of joint targets.
"""
from collections import deque
from pathlib import Path
import json,time
from resumed_even_construction_formula_clock import model_data


def bfs(O,initial):
    dist={initial:0};frontier=[initial]
    while frontier:
        nxt=[]
        for a in frontier:
            for b in O[a]:
                if b not in dist:dist[b]=dist[a]+1;nxt.append(b)
        frontier=nxt
    return dist


def verify():
    start=time.monotonic();source=json.loads(Path('research/resumed-even-construction-joint-equality28.json').read_text())
    S,I,_=model_data(24,24,13);h=288;k=13;goal=(176,1);full=(288,2)
    O={a:{}for a in S};seen=[0]*len(S)
    for quota in range(k+1):
        states,index,relation=model_data(24,24,quota)
        assert states==S
        for i,a in enumerate(S):
            assert seen[i]&~relation[i]==0
            new=relation[i]&~seen[i];seen[i]=relation[i]
            while new:
                bit=new&-new;new^=bit;O[a][S[bit.bit_length()-1]]=quota
    rev={a:set()for a in S}
    for a,row in O.items():
        for b in row:rev[b].add(a)
    forward=bfs(O,full);backward=bfs(rev,goal)
    assert forward[goal]==28
    current={(full,full)};edge_checks=0
    for t in range(1,29):
        geo={a for a in S if forward.get(a,-1)==t and backward.get(a,-1)==28-t}
        record=source['layers'][t-1]
        assert geo==set(map(tuple,record['merged_geodesic_features']))
        targets=set()
        for X,Y in current:
            for A,spent in O[X].items():
                for m,c in geo:
                    b=h+m-A[0]
                    for j in range(3):
                        B=(b,j)
                        if B not in I or max(0,A[1]+j-2)!=c:continue
                        edge_checks+=1
                        if spent+O[Y].get(B,k+1)<=k:targets.add(tuple(sorted((A,B))))
        advertised={tuple(map(tuple,row))for row in record['reachable_pairs']}
        assert targets==advertised,(t,len(targets),len(advertised))
        current=targets
    assert current=={(goal,full)}
    current={full};clock=[];at28=[]
    for t in range(103):
        if t==28:
            at28=sorted(a for a in current if a[0]<=176)
            current={a for a in current if a[0]>=177}
        minimum=min(a[0]for a in current);clock.append(minimum)
        if t<102:assert minimum>k
        current={b for a in current for b in O[a]}
    assert at28==[goal]and clock[-1]==9
    return {'verified':True,'equality_pair_transition_checks':edge_checks,
            'weighted_model_edges_checked':sum(map(len,O.values())),
            'unique_extremal_joint_pair':(goal,full),
            'filtered_solo_clock':103,'minimum_last_support':9,
            'full_board_lower_from_filtered_merger':206,
            'filtered_minimum_sizes':clock,'seconds':time.monotonic()-start,
            'scope':'Independent finite equality and filtered-model checks. Physical interpretation also uses the near-square history barrier, full-start merger, and midpoint reversal theorem.'}


if __name__=='__main__':
    out=verify();Path('research/resumed-even-construction-joint-equality28-verification.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items()if k!='filtered_minimum_sizes'})

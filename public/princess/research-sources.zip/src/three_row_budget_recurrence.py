"""Three-row closed formula, exact rank recurrence, witnesses, and bounded discovery checks.

The ordinary proof is research/three-row-all-budgets.md; no Lean claim is made.
Run from project root; default verification is a few seconds in one worker.
"""
from collections import deque
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import json,time
from nested_grid_time import grid,ordered_profiles,solve

def exact(n,m,seconds=15):
    coords,adj=grid((n,3));full=(1<<len(coords))-1
    @lru_cache(None)
    def hood(mask):
        out=0
        while mask:
            bit=mask&-mask;out|=adj[bit.bit_length()-1];mask^=bit
        return out
    deadline=time.monotonic()+seconds
    parents={full:None};q=deque([full]);edges=0
    while q:
        state=q.popleft()
        if state.bit_count()<=m:
            shots=[state];v=state
            while parents[v] is not None:
                v,s=parents[v];shots.append(s)
            shots.reverse();s=full
            for shot in shots:
                assert shot.bit_count()<=m;s=hood(s&~shot)
            assert s==0
            return dict(status='exact',turns=len(shots),states=len(parents),edges=edges,
                shots=[[coords[i] for i in range(len(coords)) if shot>>i&1] for shot in shots])
        bits=[1<<i for i in range(len(coords)) if state>>i&1]
        for chosen in combinations(bits,m):
            shot=sum(chosen);after=hood(state^shot);edges+=1
            if after not in parents:parents[after]=(state,shot);q.append(after)
            if edges%10000==0 and time.monotonic()>deadline:
                return dict(status='incomplete',states=len(parents),edges=edges)
    return dict(status='infeasible',turns=None,states=len(parents),edges=edges)


def phase_solver(n,m):
    """Upper bound: separate diagonal orientation for each initial parity cohort.
    Full cohorts may change orientation for free. No normal-form theorem assumed.
    """
    assert n%2==0
    h=3*n//2
    def norm(b,z):return (b,0 if b in (0,h) else z)
    start=(h,0,h,0);parents={start:None};q=deque([start])
    while q:
        state=q.popleft();a,x,b,y=state
        if a+b<=m:
            path=[(state,a,b,x,y)];v=state
            while parents[v] is not None:
                v,p,zz=parents[v];path.append((v,*p,*zz))
            return dict(turns=len(path),states=len(parents),reverse_path=path)
        for p in range(m+1):
            for xx in ([0,1] if a==h else [x]):
                for yy in ([0,1] if b==h else [y]):
                    r=max(a-p,0);s=max(b-(m-p),0)
                    aa=0 if not r else min(h,r+1+xx)
                    bb=0 if not s else min(h,s+1+yy)
                    # Full survivors have their actual neighborhood full.
                    if r==h:aa=h
                    if s==h:bb=h
                    after=(*norm(aa,1-xx),*norm(bb,1-yy))
                    if after not in parents:
                        parents[after]=(state,(p,m-p),(xx,yy));q.append(after)
    return dict(turns=None,states=len(parents))

def lower_solver(n,m):
    """Rigorous relaxation: last efficient survivor orientation, not a strategy.
    The simulation lemma is in the accompanying note; compare to phase upper bound.
    """
    assert n%2==0;h=3*n//2
    def nxt(b,z,p):
        r=max(b-p,0)
        if not r:return [(0,0)]
        if r>=h-1:return [(h,0)]
        out=[(min(h,r+2),0)]
        if not z or (b==h-1 and r==1):out.append((r+1,1))
        return out
    start=(h,0,h,0);parents={start:None};q=deque([start])
    while q:
        state=q.popleft();a,x,b,y=state
        if a+b<=m:
            path=[state];v=state
            while parents[v] is not None:v,p=parents[v];path.append(v)
            return dict(turns=len(path),states=len(parents),reverse_path=path)
        for p in range(m+1):
            for aa,xx in nxt(a,x,p):
                for bb,yy in nxt(b,y,m-p):
                    after=(aa,xx,bb,yy)
                    if after not in parents:parents[after]=(state,p);q.append(after)
    return dict(turns=None,states=len(parents))

def rank_solver(n,m,witness=False):
    """Exact for every even length and every positive budget.
    Initial cohorts carry independent fixed diagonal orientations while proper.
    """
    assert n%2==0;h=3*n//2
    def f(u,p):return 0 if u//2<=p else min(2*h,u-2*p+3)
    start=(2*h,2*h);parent={start:None};q=deque([start])
    while q:
        state=q.popleft();u,v=state
        if u//2+v//2<=m:
            path=[(state,u//2,v//2)];s=state
            while parent[s] is not None:
                s,p=parent[s];path.append((s,p,m-p))
            path.reverse();out=dict(turns=len(path),states=len(parent))
            if witness:
                coords,adj=grid((n,3));index={c:i for i,c in enumerate(coords)}
                orders=[sorted((i for i,c in enumerate(coords) if sum(c)%2==z),key=lambda i:(sum(coords[i]),coords[i])) for z in range(2)]
                prefixes=[]
                for z in range(2):
                    row=[0]
                    for i in orders[z]:row.append(row[-1]|(1<<i))
                    prefixes.append(row)
                def canonical(b,phase,physical):
                    mask=prefixes[phase][b]
                    if phase==physical:return mask
                    result=0
                    for i,(c,r) in enumerate(coords):
                        if mask>>i&1:result|=1<<index[(n-1-c,r)]
                    return result
                def hood(mask):
                    result=0
                    while mask:
                        bit=mask&-mask;result|=adj[bit.bit_length()-1];mask^=bit
                    return result
                actual=(1<<len(coords))-1;shots=[]
                for day,((u,v),p,qq) in enumerate(path):
                    a=canonical(u//2,u%2,day%2);b=canonical(v//2,v%2,1-day%2)
                    assert actual==a|b
                    ra=canonical(max(u//2-p,0),u%2,day%2)
                    rb=canonical(max(v//2-qq,0),v%2,1-day%2)
                    shot=(a^ra)|(b^rb);assert shot.bit_count()<=m
                    actual=hood(actual&~shot)
                    shots.append([coords[i] for i in range(len(coords)) if shot>>i&1])
                assert actual==0;out['shots']=shots
            return out
        for p in range(m+1):
            after=f(u,p),f(v,m-p)
            if after not in parent:parent[after]=(state,p);q.append(after)
    return dict(turns=None,states=len(parent))

def closed_formula(n,m):
    """Closed time formula for three-row grids, from the research proof.
    Positive n,m. n=1 is the three-vertex path.
    """
    assert n>=1 and m>=1
    if n==1:return 1 if m>=3 else 2
    if m==1:return None
    total=3*n
    if m>=total:return 1
    if m>=total//2:return 2
    w=total-4;d=2*m-3;q,r=divmod(w,d)
    if not r:return 2*q
    threshold=r+4-(q%2 if n%2==0 else 0)
    return 2*q+1 if m>=threshold else 2*q+2



def formula_strategy(n,m):
    """Direct closed-form optimal schedule, with physical-grid replay. No search."""
    turns=closed_formula(n,m)
    if turns is None:return dict(turns=None,inspections=[])
    coords,adj=grid((n,3));total=len(coords);index={c:i for i,c in enumerate(coords)}
    full=(1<<total)-1
    def hood(mask):
        out=0
        while mask:
            bit=mask&-mask;out|=adj[bit.bit_length()-1];mask^=bit
        return out
    if n==1:
        shots=[full] if m>=3 else [1<<index[(0,1)]]*2
    elif m>=total:
        shots=[full]
    elif m>=total//2:
        minority=sum(1<<i for i,c in enumerate(coords) if sum(c)%2==1)
        shots=[minority,minority]
    else:
        w=total-4;d=2*m-3;q,r=divmod(w,d)
        if not r:allocations=[(m,0)]*q+[(0,m)]*q
        elif turns==2*q+1:
            p=(r+4)//2
            allocations=[(m,0)]*q+[(p,m-p)]+[(0,m)]*q
        else:allocations=[(m,0)]*(q+1)+[(0,m)]*(q+1)
        orders=[sorted((i for i,c in enumerate(coords) if sum(c)%2==z),key=lambda i:(sum(coords[i]),coords[i])) for z in range(2)]
        prefixes=[]
        for z in range(2):
            row=[0]
            for i in orders[z]:row.append(row[-1]|(1<<i))
            prefixes.append(row)
        def canonical(b,z,physical):
            mask=prefixes[z][b]
            if n%2==1 or z==physical:return mask
            out=0
            for i,(c,rr) in enumerate(coords):
                if mask>>i&1:out|=1<<index[(n-1-c,rr)]
            return out
        first=n%2 # Initially minority on odd boards; corner parity on even boards.
        cohorts=[prefixes[first][-1],prefixes[1-first][-1]]
        phases=[first,1-first] if n%2 else [0,0]
        shots=[]
        for day,counts in enumerate(allocations):
            shot=0
            for j,p in enumerate(counts):
                physical=first^j^(day%2);b=cohorts[j].bit_count()
                z=physical if n%2 else phases[j]
                assert cohorts[j]==canonical(b,z,physical)
                survivors=canonical(max(b-p,0),z,physical)
                shot|=cohorts[j]^survivors
                cohorts[j]=hood(survivors)
                phases[j]=1-z
                if n%2==0 and cohorts[j]==prefixes[1-physical][-1]:phases[j]=0
            shots.append(shot)
    belief=full
    for day,shot in enumerate(shots):
        assert shot.bit_count()<=m
        belief=hood(belief&~shot)
        if not belief:assert day==len(shots)-1
    assert not belief and len(shots)==turns
    return dict(turns=turns,inspections=[[coords[i] for i in range(total) if shot>>i&1] for shot in shots])


def validate_receipts():
    """Fast comparison and physical witness replay; writes unique receipts."""
    begin=time.monotonic();rank_rows=[];formula_rows=[]
    for n in range(2,31):
        _,data=ordered_profiles((n,3))
        for m in range(1,3*n+1):
            actual=rank_solver(n,m)['turns'] if n%2==0 else solve(data,m)['minimum_turns']
            formula=closed_formula(n,m)
            assert actual==formula,(n,m,actual,formula)
            formula_rows.append(dict(n=n,m=m,minimum_turns=formula))
            if n%2==0 and m<=24:
                rank=rank_solver(n,m,witness=True)
                assert rank['turns']==phase_solver(n,m)['turns']==lower_solver(n,m)['turns']
                rank_rows.append(dict(n=n,m=m,turns=actual,states=rank['states'],witness_replayed=actual is not None))
    result=dict(seconds=time.monotonic()-begin,formula_cases=len(formula_rows),physical_witness_comparisons=len(rank_rows))
    Path('research/three-row-closed-form-checks.json').write_text(json.dumps(dict(method='Closed formula compared with rank recurrence for even lengths and independently implemented exact compatible-isoperimetric-prefix DP for odd lengths. No formula fitted to these data.',**result,results=formula_rows),indent=2)+'\n')
    Path('research/three-row-rank-recurrence-checks.json').write_text(json.dumps(dict(method='Rank recurrence, independent two-phase upper recurrence, geometric lower relaxation with the corner exception, and physical-grid prefix schedule replay; physical exactness comes from the written theorem.',**result,results=rank_rows),indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full-bfs',action='store_true',help='Repeat bounded unrestricted discovery searches; otherwise verify recurrence/formula and physical witnesses.')
    args=parser.parse_args()
    if not args.full_bfs:
        validate_receipts()
    else:
        rows=[];start=time.monotonic()
        for n,ms in [(4,range(3,7)),(6,range(3,8)),(8,range(3,6)),(10,[3])]:
            _,d=ordered_profiles((n,3))
            for m in ms:
                t=time.monotonic();r=dict(n=n,m=m,**exact(n,m,10));r['seconds']=time.monotonic()-t
                r['ordered_turns']=solve(d,m)['minimum_turns'];rows.append(r)
                print({k:v for k,v in r.items() if k!='shots'},flush=True)
                Path('research/three-row-all-budget-experiments.json').write_text(json.dumps(dict(method='Full unrestricted belief BFS with cached neighborhoods, bounded individually. Exact schedule replayed on adjacency; ordered solver is only a comparator.',seconds=time.monotonic()-start,results=rows),indent=2)+'\n')

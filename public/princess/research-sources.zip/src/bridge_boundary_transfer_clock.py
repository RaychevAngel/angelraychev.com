"""Consequences of the independently reviewed uniform physical time-28 barrier.

Uses a further necessary relaxation at time28: all features with size>=h-111.
Backward frontiers thereafter are exact in the stated models, not physical.
"""
import json
from pathlib import Path
from bridge_corner_frontier import step as three_step
from bridge_lower_frontier_nine import step as nine_step


def compute(w,n):
    assert w in (24,25) and n>=w and w*n%2==0
    h=w*n//2;k=13;floor=h-111
    if w==24:
        initial=(0,-1,-1)
        step=lambda B:three_step(w,n,k,B,critical=True)
        residual=tuple(min(h-2+c,k//2) for c in range(3))
        maximum=max
    else:
        initial={(c,e):0 for c in range(3) for e in range(3)}
        step=lambda B:nine_step((w-1)//2,h,k,B,strong_band=False)
        residual={(c,e):min(h-4+c+e,k//2) for c in range(3)for e in range(3)}
        maximum=lambda B:max(B.values())
    B=initial;layers=[B]
    while maximum(B)<floor:
        B=step(B);layers.append(B)
        assert len(layers)<4*w*n
    remaining=len(layers)-1
    for _ in range(remaining-1):residual=step(residual)
    tau=28+remaining
    midpoint_excluded=maximum(residual)<floor
    return dict(shape=[w,n],budget=k,time28_minimum_merged_size=floor,
        model_remaining_clock=remaining,solo_lower=tau,
        halfbudget_backward_maximum=maximum(residual),
        full_lower=2*tau-int(not midpoint_excluded),
        scope='New uniform physical barrier plus necessary model; no upper or complete classification claim.')

if __name__=='__main__':
    rows=[compute(w,n) for w,n in [(24,24),(24,25),(24,26),(24,28),(25,26),(25,28),(25,30)]]
    Path('research/bridge-boundary-transfer-clock.json').write_text(json.dumps(dict(status='PASS',rows=rows),indent=2)+'\n')
    print(rows)

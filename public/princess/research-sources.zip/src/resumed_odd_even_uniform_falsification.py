"""Bounded falsification of the uniform necessary solo model against uppers.

Uses bitset adjacency so no joint graph or multi-million-tuple edge list is
materialized. Finite agreement is not a uniform optimality proof.
"""
from pathlib import Path
from time import process_time
import json,argparse
from resumed_odd_even_erosion_corners import build
from resumed_odd_even_minimum_upper import check as physical_upper


def run(b,n):
    start=process_time();m=b+1;h=(2*b+1)*n//2
    states,arcs=build(b,n,m,closed=True,triangle=True,maximal=True,dual=True,compact=True)
    first=states.index((h,2,2));zero=states.index((0,0,0))
    frontier=1<<first;seen=frontier;days=0
    while not(frontier>>zero&1):
        next_mask=0
        while frontier:
            bit=frontier&-frontier;frontier-=bit
            next_mask|=arcs[bit.bit_length()-1]
        frontier=next_mask&~seen;seen|=frontier;days+=1
        assert frontier,'No relaxed capture'
    upper=physical_upper(b,n);tau=upper['physical_days']//2
    assert days<=tau,(b,n,days,tau)
    return {'width':2*b+1,'length':n,'budget':m,'uniform_necessary_solo':days,
            'physically_replayed_solo_upper':tau,'solo_gap':tau-days,
            'physical_full_game_upper':upper['physical_days'],
            'feature_states':len(states),'solo_arcs':sum(x.bit_count()for x in arcs),
            'cpu_seconds':process_time()-start}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-b',type=int,default=8)
    a=p.parse_args();results=[]
    path=Path('research/resumed-odd-even-uniform-falsification.json')
    for b in range(3,a.max_b+1):
        for n in(2*b+2,2*b+4):
            r=run(b,n);results.append(r);print(r,flush=True)
            path.write_text(json.dumps({'scope':'Bounded attempt to falsify the uniform necessary solo model against independently replayed physical uppers. No joint merger or uniform classification inferred.','results':results},indent=2)+'\n')

"""Exact odd-five count recurrence and independently restricted sweep schedules.

The exactness input is the proved all-odd isoperimetric nesting theorem.
A one-overlap strategy is only an upper class until separately proved optimal.
"""
from functools import lru_cache
from pathlib import Path
from time import monotonic
import json


def profile(h,p,k):
    if not k:return 0
    if p==0:
        if k>=h:return h
        return k+(1 if k==1 or k>=h-3 else 2)
    if k==h:return h+1
    return k+(2 if k<=2 or k>=h-2 else 3)


def exact(n,m,path=False):
    assert n>=5 and n%2==1 and m>=1
    h=(5*n-1)//2
    frontier={(h+1,h)};seen=set();layers=[]
    for day in range(1,20*h+1):
        if any(a+b<=m for a,b in frontier):
            return day
        if frontier <= seen:return None
        seen.update(frontier)
        nexts={}
        for a,b in frontier:
            for p in range(max(0,m-b),min(m,a)+1):
                out=(profile(h,1,max(0,b-(m-p))),profile(h,0,max(0,a-p)))
                if out[1]<nexts.get(out[0],10**9):nexts[out[0]]=out[1]
        frontier=set();best=10**9
        for a,b in sorted(nexts.items()):
            if b<best:frontier.add((a,b));best=b
    raise RuntimeError((n,m,'iteration guard'))


def full(h,z):return h+1-z


def solo(h,m,b,z):
    for t in range(1,10*h):
        if b<=m:return t
        b=profile(h,z,b-m);z=1-z
    return None


def overlap(n,m):
    """Best schedule: full shots into one cohort, one shared day, full other."""
    h=(5*n-1)//2
    if m>=2*h+1:return (1,(0,0,0))
    best=(10**9,None)
    for start in (0,1):
        b=full(h,start);z=start
        for q in range(10*h):
            if b<=m:
                otherz=1-z;other=full(h,otherz)
                remainder=m-b
                after=profile(h,otherz,max(0,other-remainder))
                tail=0 if after==0 else solo(h,m,after,1-otherz)
                if tail is not None:best=min(best,(q+1+tail,(start,q,b)))
            if b==0:break
            b=profile(h,z,max(0,b-m));z=1-z
    return best


def run():
    start=monotonic();rows=[]
    for n in range(5,62,2):
        for m in range(4,min((5*n-1)//2,22)):
            t=exact(n,m);upper,strategy=overlap(n,m)
            rows.append(dict(n=n,m=m,exact=t,one_overlap=upper,strategy=strategy))
            if t!=upper:print('GAP',rows[-1],flush=True)
    payload=dict(scope='Exact count recurrence under proved odd-rectangle profiles versus a restricted one-overlap upper class; finite comparison only.',seconds=monotonic()-start,rows=rows)
    Path('research/recurrence-bridge-odd-five-checks.json').write_text(json.dumps(payload,indent=2)+'\n')
    print(dict(cases=len(rows),gaps=sum(x['exact']!=x['one_overlap']for x in rows),seconds=payload['seconds']))
    for m in range(4,15):print(m,[(r['n'],r['exact'],r['strategy'])for r in rows if r['m']==m][:16])

if __name__=='__main__':run()


def ammunition(h,m):
    """Minimum total probes to clear one cohort; time unrestricted."""
    import heapq
    caps=(h+1,h)
    rev={};dist={};todo=[]
    for z in (0,1):
        for b in range(caps[z]+1):
            src=(b,z)
            for p in range(min(m,b)+1):
                out=(profile(h,z,b-p),1-z)
                rev.setdefault(out,[]).append((src,p))
        dist[(0,z)]=0;heapq.heappush(todo,(0,0,z))
    while todo:
        cost,b,z=heapq.heappop(todo)
        if dist[(b,z)]!=cost:continue
        for src,p in rev.get((b,z),[]):
            c=cost+p
            if c<dist.get(src,10**9):dist[src]=c;heapq.heappush(todo,(c,*src))
    return dist


def J(r):
    if r == 0: return 0
    if r == 1: return 2
    if r == 2: return 3
    if r <= 4: return 4
    return (r+6)//2


def candidate(n,m):
    h = (5*n-1)//2
    if m >= 2*h+1: return 1
    if m >= h: return 2
    if m == 3: return 10*n-20
    if m == 4: return 2*((2*h-6)//3)+2*(h%3 == 1)
    q,r = divmod(5*n-6,2*m-5)
    result = 2*q+(0 if not r else 1 if 2*J(r) <= m else 2)
    correction = m%2 == 0 and ((m == 6 and r == 2) or
                    (m == 8 and r == 4) or (m >= 10 and r == m-5))
    return result+int(correction)


def delta(r):
    return int(r in (1,2,4) or (r >= 5 and r%2 == 1))


def direct_strategy(n,m,coordinates=False):
    """Uniform physical construction for the candidate formula; no search."""
    from nested_grid_time import ordered_profiles, neighborhood
    h=(5*n-1)//2
    if m<3:return None
    report,data=ordered_profiles((n,5))
    assert report['nested']
    coords,adj,orders,prefixes,profiles=data
    if m>=2*h+1:
        plans=[(h+1,h)];first=0
    elif m>=h:
        plans=[(h,0),(0,h)];first=1
    elif m==3:
        length=2*h-9;first=1
        plans=[(m,0)]*length+[(0,m)]*length
    elif m==4:
        length=candidate(n,m)//2;first=0
        plans=[(m,0)]*length+[(0,m)]*length
    else:
        q,r=divmod(5*n-6,2*m-5);first=1
        if r==0:
            plans=[(m,0)]*q+[(0,m)]*q
        elif 2*J(r)+delta(r)<=m:
            plans=[(m,0)]*q+[(J(r),J(r)+delta(r))]+[(0,m)]*q
        else:
            plans=[(m,0)]*(q+1)+[(0,m)]*(q+1)
    counts=[h+1-first,h+first]
    belief=(1<<(5*n))-1;shots=[]
    for day,allocations in enumerate(plans):
        shot=0;nextcounts=[]
        for cohort,p in enumerate(allocations):
            z=first^cohort^(day%2);b=counts[cohort]
            support=prefixes[z][b];remain=prefixes[z][max(0,b-p)]
            assert support&~belief==0
            shot |= support^remain
            after=neighborhood(remain,adj)
            assert after==prefixes[1-z][profile(h,z,max(0,b-p))]
            nextcounts.append(after.bit_count())
        assert shot.bit_count()<=m
        belief=neighborhood(belief&~shot,adj);shots.append(shot);counts=nextcounts
    assert not belief
    assert len(shots)==candidate(n,m)
    result=dict(n=n,m=m,turns=len(shots))
    if coordinates:
        result['inspections']=[[coords[i] for i in range(len(coords)) if s>>i&1] for s in shots]
    return result

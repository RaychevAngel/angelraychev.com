#!/usr/bin/env python3
"""Attack length pumping of exact rational one-cohort potential certificates."""
from fractions import Fraction
from heapq import heappop,heappush
from math import lcm
from pathlib import Path
import json,time
from odd_serial_first_order_attack import profiles,serial


def ranks(g,charges):
    scale=lcm(*(v.denominator for p in charges for v in p))
    m=len(charges[0])-1
    costs=[[int(v*scale)for v in p]for p in charges]
    states=[(p,k)for p in(0,1)for k in range(len(g[p]))]
    rev={v:[]for v in states}
    for p,k in states:
        for r in range(m+1):
            rev[1-p,g[p][max(0,k-r)]].append(((p,k),costs[p][r]))
    dist={v:10**12 for v in states};queue=[]
    for p in(0,1):dist[p,0]=0;heappush(queue,(0,(p,0)))
    while queue:
        t,v=heappop(queue)
        if dist[v]!=t:continue
        for z,c in rev[v]:
            if t+c<dist[z]:dist[z]=t+c;heappush(queue,(t+c,z))
    return [[Fraction(dist[p,k],scale)for k in range(len(g[p]))]for p in(0,1)]


if __name__=='__main__':
    path=Path(__file__).resolve().parents[1]/'research'
    cases=json.loads((path/'odd-minimum-budget-potentials.json').read_text())['results']
    rows=[];start=time.monotonic()
    for case in cases:
        w=case['width'];b=(w-1)//2;charges=[[Fraction(s)for s in p]for p in case['charges']]
        base=None
        for n in(w,w+2,w+4,w+8,w+20):
            g=profiles((n-1)//2,b);f=ranks(g,charges)
            total=f[0][-1]+f[1][-1];upper=min(serial(g,b+1,p)for p in(0,1))
            deficit=2*w*n-total
            if base is None:base=deficit
            rows.append({'width':w,'length':n,'potential':str(total),'rounded_lower':(total.numerator+total.denominator-1)//total.denominator,
                         'serial_upper':upper,'deficit':str(deficit),'same_deficit_as_square':deficit==base,
                         'ranks':[[str(v)for v in p]for p in f]})
    out={'scope':'Fixed charges from square LP, exact shortest-path potentials at bounded longer lengths.',
         'seconds':time.monotonic()-start,'results':rows}
    (path/'odd-minimum-budget-pumping.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({**out,'results':[{k:v for k,v in r.items()if k!='ranks'}for r in rows]},indent=2))

"""Cross-check the browser calculator against an independent Python recurrence and physical replay."""
from pathlib import Path
from itertools import product
import json, subprocess, time, hashlib
from nested_grid_time import ordered_profiles, solve

ROOT=Path(__file__).resolve().parents[1]
script=ROOT/'src/odd_box_search.mjs'
shapes=[(1,),(3,),(7,),(1,5,3),(3,5),(3,7),(5,5),(5,7),
        (3,3,3),(3,3,5),(3,5,7),(7,3,5),(5,5,5),(3,3,3,3),(3,3,3,3,3),(7,7,7)]
cases=[];data={}
for shape in shapes:
    report,raw=ordered_profiles(tuple(sorted(shape)),weightlex=True)
    assert report['nested'];data[shape]=(report,raw)
    threshold=1 if len(raw[0])==1 else 1+max(v-k for k,v in enumerate(report['profiles'][0]))
    volume=len(raw[0])
    budgets=range(1,volume+1) if volume<=27 else sorted({1,threshold-1,threshold,threshold+1,volume//3,volume//2,volume-1,volume})
    cases.extend({'shape':shape,'m':m} for m in budgets if m>0)
start=time.monotonic()
source=f'''import {{oddBoxSearch}} from {json.dumps(script.as_uri())};
const rows={json.dumps(cases)}.map(c=>{{const r=oddBoxSearch(c.shape,c.m);return {{...c,days:r.days,threshold:r.threshold,profiles:r.profiles,shots:r.shots.map(s=>s.map(v=>r.vertices[v]))}};}});
console.log(JSON.stringify(rows));'''
rows=json.loads(subprocess.run(['node','--input-type=module','-'],input=source,text=True,capture_output=True,check=True).stdout)
checked=[]
for row in rows:
    shape=tuple(row['shape']);report,raw=data[shape]
    expected=solve(raw,row['m'])
    assert row['profiles']==report['profiles'],row
    assert row['days']==expected['minimum_turns'],(shape,row['m'],row['days'],expected['minimum_turns'])
    if row['days'] is not None:
        possible=set(product(*(range(n) for n in shape)))
        for i,shots in enumerate(row['shots']):
            shots=set(map(tuple,shots));assert len(shots)<=row['m']
            survivors=possible-shots
            if not survivors:assert i==len(row['shots'])-1
            possible=set()
            for room in survivors:
                for axis,n in enumerate(shape):
                    for delta in (-1,1):
                        v=list(room);v[axis]+=delta
                        if 0<=v[axis]<n:possible.add(tuple(v))
        assert not survivors
    checked.append({k:row[k] for k in ('shape','m','days','threshold')})
receipt={'all_passed':True,'cases':len(checked),'seconds':time.monotonic()-start,
         'javascript_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
         'scope':'Independent Python count recurrence and actual-coordinate replay for the JavaScript calculator. The unbounded optimality justification is the ordinary odd-box nesting theorem.',
         'results':checked}
(ROOT/'research/odd-box-explorer-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='results'},indent=2))

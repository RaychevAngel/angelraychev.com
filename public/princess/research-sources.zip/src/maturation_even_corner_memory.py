#!/usr/bin/env python3
"""Replay the 41-room partial-start capacity witness on a width-14 strip."""
from pathlib import Path
import json


def neighbors(s):
    return {(x+dx, y+dy) for x, y in s
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
            if 0 <= x+dx < 14 and y+dy >= 0}


def right_prefix(parity, size):
    rooms = set()
    d = parity
    while size:
        available = [(13-u, d-u) for u in range(min(14, d+1))]
        take = min(size, len(available))
        rooms.update(available[:take])
        size -= take
        d += 2
    return rooms


def main():
    survivors = right_prefix(1, 32)
    first_shots = {(0, 2*j) for j in range(9)}
    assert not survivors & first_shots
    belief = survivors | first_shots
    assert len(belief) == 41 and (0, 0) in belief
    shots = [sorted(first_shots)]
    counts = [41]
    belief = neighbors(survivors)
    counts.append(len(belief))
    local_phase = 0
    for _ in range(8):
        assert belief == right_prefix(local_phase, len(belief))
        remain = max(0, len(belief)-9)
        survivor = right_prefix(local_phase, remain)
        assert survivor <= belief
        shot = belief-survivor
        assert len(shot) <= 9
        shots.append(sorted(shot))
        belief = neighbors(survivor)
        counts.append(len(belief))
        local_phase ^= 1
    assert not belief
    assert counts == [41, 39, 36, 33, 29, 25, 20, 15, 9, 0]
    receipt = {"scope": "Actual partial-start witness, not a full-board search time",
               "width": 14, "daily_budget": 9, "initial_size": 41,
               "initial_corner_present": True, "belief_sizes": counts,
               "physical_shots": shots, "all_checks_passed": True}
    target = Path(__file__).resolve().parents[1]/"research/maturation-corner-memory-witness.json"
    target.write_text(json.dumps(receipt, indent=2)+"\n")
    print(json.dumps({k: v for k, v in receipt.items() if k != "physical_shots"}))


if __name__ == "__main__":
    main()

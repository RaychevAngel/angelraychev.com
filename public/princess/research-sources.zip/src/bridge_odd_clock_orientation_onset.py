"""Audit the new sufficient onset for the exact odd-board scalar midpoint.

The ordinary proof is bridge-odd-clock-orientation-onset.md. This checker
does not use agreement with the joint solver to infer the theorem.
"""
from math import isqrt
from pathlib import Path
from time import process_time
import hashlib
import json

from supersession_solo_bands import OddRectangle
from supersession_odd_midpoint_bounded import solve


def root(z):
    return isqrt(z)+int(isqrt(z)**2 < z)


def constants(b, m):
    assert b >= 2 and m >= b+1
    w, G = 2*b+1, m-1
    H = b*b+1
    K = b*b+2*m*(G//w+1)
    W = (max(0,G-b*b)+b-1)//b+2*min(b,root(G))
    J0 = 2*K+m+1
    onset = J0+G+m*(W+1)
    old_J = 2*K+G+2*m+H+2
    old_W = G+K+1
    old_onset = 2*old_J+G+m*(old_W+3)
    return dict(width=w,budget=m,H=H,G=G,K=K,J0=J0,W=W,
                onset=onset,previous_onset=old_onset)


def maximal_debt_successor(b, v):
    lo, hi = 0, v
    while lo < hi:
        mid=(lo+hi+1)//2
        if mid+min(root(mid),b) <= v:
            lo=mid
        else:
            hi=mid-1
    return lo


def main():
    started=process_time()
    rows=[]
    parameters=[(b,m) for b in (3,5,10,20,40) for m in (b+2,2*b)]
    parameters += [(10,50),(20,200)]
    for b,m in parameters:
        row=constants(b,m)
        w=row['width']
        n=max(w,(2*row['onset']+1+w-1)//w)
        n += int(n%2 == 0)
        G=OddRectangle(w,n)
        assert G.M >= row['onset']
        assert n == w or OddRectangle(w,n-2).M < row['onset']
        solo=G.half_time(m)
        answer=solve(w,n,m)
        assert solo['scalar_candidate'] == answer['time']
        debt=row['G'];steps=0
        while debt:
            debt=maximal_debt_successor(b,debt)
            steps+=1
        assert steps <= row['W']
        row.update(first_odd_length=n,actual_M=G.M,
                   scalar_time=solo['scalar_candidate'],exact_time=answer['time'],
                   exact_solver_updates=answer['updates'],
                   maximal_relaxed_debt_lifetime=steps,
                   fixed_K16_expression=16*(2*m-w)>=b*b)
        rows.append(row)
    result=dict(status='PASS',scope=__doc__,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                rows=rows,seconds=process_time()-started)
    Path('research/bridge-odd-clock-orientation-onset-check.json').write_text(
        json.dumps(result,indent=2)+'\n')
    print(dict(status='PASS',cases=len(rows),seconds=result['seconds'],
               sample_onsets=[(r['width'],r['budget'],r['first_odd_length'],
                               r['onset'],r['previous_onset']) for r in rows]))


if __name__ == '__main__':
    main()

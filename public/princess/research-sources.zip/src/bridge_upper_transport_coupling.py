"""Bounded checks of a stronger scalar-to-prefix buffered coupling.

The root erosion identity is proved in the accompanying note. The orbit
comparison remains a conjecture, even when every finite check passes.
"""
from math import isqrt
from pathlib import Path
import hashlib
import json
import time

from resumed_even_construction_prefix_arithmetic import erosion_count


def square(q):
    u = isqrt(q)
    return u + (u * u < q)


def pronic(q):
    u = (isqrt(4 * q + 1) - 1) // 2
    return u + (u * (u + 1) < q)


def physical_erosion(r, n, phase, target):
    h = r * n
    if target == h:
        return h
    low = square(target) if phase == 0 else pronic(target)
    high = square(h - target) if phase == n % 2 else 1 + pronic(h - target)
    return target - min(low, r, high)


def scalar_erosion(r, n, target):
    return max(0, target - min(r, pronic(target), square(r * n - target)))


def orbit(r, n, k, seed, buffer, require_min=False):
    h = r * n
    scalar = seed
    physical = (min(h, seed + buffer),) * 2
    checked = 0
    while True:
        if scalar > (min(physical) if require_min else max(physical)):
            return checked, dict(r=r, n=n, k=k, seed=seed, buffer=buffer,
                                 day=checked, scalar=scalar, physical=physical)
        if scalar == h:
            return checked, None
        scalar = min(h, k + scalar_erosion(r, n, scalar))
        physical = tuple(min(h, k + physical_erosion(r, n, 1 - p, physical[1 - p]))
                         for p in (0, 1))
        checked += 1


def audit():
    begin = time.process_time()
    profile_checks = local_checks = 0
    for r in range(2, 41):
        for n in (2 * r, 2 * r + 1, 2 * r + 2, 4 * r):
            h = r * n
            for target in range(h + 1):
                for phase in (0, 1):
                    value = physical_erosion(r, n, phase, target)
                    assert value == erosion_count(2 * r, n, phase, target)
                    profile_checks += 1
                    if target < h:
                        assert physical_erosion(r, n, phase, target + 1) >= scalar_erosion(r, n, target)
                        local_checks += 1
    cases = deadlines = 0
    for r in range(2, 101):
        for n in (2 * r, 2 * r + 1, 4 * r):
            h = r * n
            for k in (2 * r, 2 * r + 1, 3 * r):
                for seed in (0, r, r * r // 2, r * r, h // 2, h - r * r):
                    count, failure = orbit(r, n, k, seed, r)
                    assert failure is None, failure
                    cases += 1
                    deadlines += count
    _, below = orbit(4, 8, 5, 0, 4)
    assert below is not None
    proved_cases = proved_deadlines = 0
    boundary_budgets = []
    for r in range(2, 101):
        condition = lambda k: k // 2 - r >= -(-(r - 1) ** 2 // (2 * (k - r)))
        first = next(k for k in range(2 * r, 3 * r + 1) if condition(k))
        boundary_budgets.append([r, first])
        assert condition(3 * r)
        for n in (2 * r, 2 * r + 1, 4 * r):
            h = r * n
            for k in sorted({first, first + 1, 3 * r}):
                if k >= h:
                    continue
                for seed, buffer in ((0, k // 2), (k // 2, k - k // 2),
                                     (h // 2, k // 2), (h - r * r, k // 2)):
                    count, failure = orbit(r, n, k, seed, buffer, require_min=True)
                    assert failure is None, failure
                    proved_cases += 1
                    proved_deadlines += count
    return dict(scope=__doc__, proved_profile_identity=True,
                universal_buffered_orbit_comparison_proved=False,
                sufficient_condition_proved='floor(k/2)-r >= ceil((r-1)^2/(2*(k-r)))',
                proved_subregion_cases=proved_cases, proved_subregion_deadlines=proved_deadlines,
                least_budget_meeting_sufficient_condition=boundary_budgets,
                profile_checks=profile_checks, local_one_room_checks=local_checks,
                buffered_orbit_cases=cases, buffered_orbit_deadlines=deadlines,
                below_regime_counterexample=below,
                CPU_seconds=time.process_time() - begin,
                source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in (Path(__file__), Path('src/resumed_even_construction_prefix_arithmetic.py'))})


if __name__ == '__main__':
    result = audit()
    Path('research/bridge-upper-transport-coupling.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))

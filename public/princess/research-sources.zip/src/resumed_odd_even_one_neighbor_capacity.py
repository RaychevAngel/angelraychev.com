"""Check the partially punctured odd-quadrant capacity by diagonal DP.

The unbounded proof is in the research note. The finite horizon here checks
its small numerical values against the exact compressed-neighborhood rule.
"""
from pathlib import Path
import json


def check(s):
    # State: last diagonal count and surplus already charged through the
    # output immediately below it. Value: largest total source cardinality.
    dp={(0,0):0}
    if s>=1:dp[(1,1)]=1
    for j in range(1,max(2,2*s+1)):
        length=2*j+2;new={}
        for (previous,used),area in dp.items():
            for current in range(length+1):
                output=max(previous+(previous>0),current-(current==length))
                cost=used+output-previous
                if cost>s:continue
                key=current,cost;new[key]=max(new.get(key,-1),area+current)
        dp=new
    actual=max(area for (last,used),area in dp.items()if used+(last>0)<=s)
    formula=s*(s-1)//2 if s<=4 else s*(s-3)+1
    assert actual==formula,(s,actual,formula)
    return {'surplus':s,'diagonal_horizon':max(2,2*s+1),
            'finite_exact_diagonal_capacity':actual,'formula':formula}


if __name__=='__main__':
    out={'scope':'Finite exact-neighborhood check, supplementing the separate unbounded proof.',
         'results':[check(s)for s in range(13)]}
    Path('research/resumed-odd-even-one-neighbor-capacity.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out)

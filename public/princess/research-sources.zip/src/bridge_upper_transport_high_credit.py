"""Bounded arithmetic audit of the uniform high-region credit lemma."""
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import time

from bridge_upper_transport_coupling import orbit, square
from bridge_upper_transport_odd_exceptions import trace


def slack(v, A, t):
    return 4*v*t*A + A*t*(t-1) - 4*v*(t-1) - 4*v**3


def gate(half, k, odd):
    c = k//2-half-int(odd)
    v = half if odd else half-1
    A = k-1-v if odd else k-v
    return c >= 1 and A > 0 and slack(v, A, 2*c) >= 0


def run():
    started = time.process_time()
    cases = deadlines = high_steps = 0
    first_budgets = []
    for half in range(2, 61):
        r = half
        even_bound = (13*r+4)//5
        odd_bound = even_bound+3
        assert gate(r, even_bound, False)
        assert gate(r, odd_bound, True)
        lower = slack(r-1, Fraction(8*r+5, 5), Fraction(3*r-5, 5))*125
        assert lower == 52*r**3-95*r*r-25*r+250 > 0
        lower = slack(r, Fraction(8*r+10, 5), Fraction(3*r, 5))*125
        assert lower == 52*r**3+270*r*r+350*r > 0
        for odd in (False, True):
            w = 2*r+int(odd)
            upper = odd_bound if odd else even_bound
            first = next(k for k in range(w, upper+1) if gate(r, k, odd))
            first_budgets.append([w, first])
            for k in sorted({first, first+1, upper}):
                c = k//2-r-int(odd)
                v, K = (r, k-1) if odd else (r-1, k)
                A = K-v
                d = v*v
                j = 0
                while d:
                    assert d <= v*v-j*A
                    assert square(d) <= v-(j*A//(2*v))
                    d = max(0, d-K+square(d))
                    j += 1
                assert j <= 2*c
                high_steps += j
                for n in ((w+1, 2*w, 4*w) if odd else (w, w+1, 2*w)):
                    h = w*n//2
                    if k >= h:
                        continue
                    if odd:
                        for mode in (0, 1):
                            actual = trace(r, n, k, mode)
                            deadlines += len(actual)
                            cases += 1
                    else:
                        for seed, buffer in ((0, k//2), (k//2, k-k//2)):
                            count, failure = orbit(r, n, k, seed, buffer, require_min=True)
                            assert failure is None, failure
                            deadlines += count+1
                            cases += 1
                assert time.process_time()-started < 10
    sources = (Path(__file__), Path('src/bridge_upper_transport_coupling.py'),
               Path('src/bridge_upper_transport_odd_exceptions.py'),
               Path('src/bridge_upper_transport_odd_coupling.py'),
               Path('src/bridge_corner_frontier.py'))
    return dict(scope=__doc__, status='PASS', coupled_cases=cases,
                checked_deadlines=deadlines, abstract_high_steps=high_steps,
                least_HP_budget_by_width=first_budgets,
                CPU_seconds=time.process_time()-started,
                source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in sources})


if __name__ == '__main__':
    result = run()
    Path('research/bridge-upper-transport-high-credit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('source_sha256', 'least_HP_budget_by_width')}))

"""Publish the manuscript's complete proofs through the existing Astro layout.

Pandoc parses LaTeX/macros; the site's own KaTeX renders every formula strictly.
No second hand-maintained copy of the mathematical arguments is introduced.
"""
from pathlib import Path
import subprocess, json, re, html
import pypandoc

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT.parent/'polyominoes/website'
TMP=ROOT/'tmp';TMP.mkdir(exist_ok=True)
PANDOC=pypandoc.get_pandoc_path()
ast=json.loads(subprocess.run([PANDOC,'main.tex','--from=latex','--to=json',
    '--citeproc','--bibliography=references.bib'],cwd=ROOT/'paper',check=True,capture_output=True,text=True).stdout)
labels=dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',(ROOT/'paper/main.aux').read_text()))
maths=[];toc=[];section=0;theorem=0

def inline_text(nodes):
    return ''.join(n['c'] if n['t']=='Str' else ' ' if n['t'] in ('Space','SoftBreak') else
                   inline_text(n['c']) if isinstance(n.get('c'),list) and n['t'] in ('Emph','Strong') else '' for n in nodes)

def walk(node):
    global section,theorem
    if isinstance(node,list):return [walk(n) for n in node]
    if not isinstance(node,dict):return node
    t=node.get('t');c=node.get('c')
    if t=='Header':
        if c[0]==1:
            if 'unnumbered' not in c[1][1]:section+=1;theorem=0
            toc.append((c[1][0],inline_text(c[2])))
        c[0]=min(c[0]+1,6)
    if t=='Div' and any(x in c[0][1] for x in ('theorem','lemma','proposition','corollary','definition','remark')):
        theorem+=1
        first=c[1][0]['c'][0]
        if first['t'] in ('Strong','Emph'):
            first['c'][-1]={'t':'Str','c':f'{section}.{theorem}'}
    if t=='Link':
        attrs=dict(c[0][2]);key=attrs.get('reference')
        if key in labels:
            num=labels[key]
            c[1]=[{'t':'Str','c':f'({num})' if attrs.get('reference-type')=='eqref' else num}]
    if t=='Image':
        target=c[2][0]
        if target.startswith('figures/') and target.endswith('.pdf'):
            c[2][0]='/princess/'+target[:-4]+'.svg'
    if t=='Math':
        display=c[0]['t']=='DisplayMath';source=c[1]
        keys=re.findall(r'\\label\{([^}]+)\}',source)
        source=re.sub(r'\\label\{[^}]+\}','',source)
        source=re.sub(r'\\(?:begin|end)\{equation\*?\}','',source)
        source=source.replace('{align*}','{aligned}').replace('{align}','{aligned}')
        i=len(maths);maths.append({'source':source,'display':display,'keys':keys})
        return {'t':'RawInline','c':['html',f'PRINCESSMATHPLACEHOLDER{i}END']}
    if 'c' in node:node['c']=walk(c)
    return node

ast['blocks']=walk(ast['blocks'])
(TMP/'paper-web-ast.json').write_text(json.dumps(ast))
(TMP/'paper-web-math.json').write_text(json.dumps(maths))
node_script=r'''
const fs=require('fs');
const {createRequire}=require('module');
const requireSite=createRequire(process.argv[2]+'/package.json');
const katex=requireSite('katex');
const rows=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
const out=rows.map((r,i)=>{try{return katex.renderToString(r.source,{displayMode:r.display,throwOnError:true,strict:'error'});}catch(e){throw new Error('Formula '+i+': '+r.source+'\n'+e.message);}});
fs.writeFileSync(process.argv[4],JSON.stringify(out));
'''
(TMP/'render-paper-math.cjs').write_text(node_script)
subprocess.run(['node',str(TMP/'render-paper-math.cjs'),str(SITE),str(TMP/'paper-web-math.json'),str(TMP/'paper-web-rendered.json')],check=True)
rendered=json.loads((TMP/'paper-web-rendered.json').read_text())
body=subprocess.run([PANDOC,str(TMP/'paper-web-ast.json'),'--from=json','--to=html5','--wrap=none'],check=True,capture_output=True,text=True).stdout
for i,(record,markup) in enumerate(zip(maths,rendered)):
    anchors=''.join(f'<span id="{html.escape(k)}"></span>' for k in record['keys'])
    nums=[labels[k] for k in record['keys'] if k in labels]
    tag=('<span class="note">('+', '.join(nums)+')</span>') if nums else ''
    body=body.replace(f'PRINCESSMATHPLACEHOLDER{i}END',anchors+markup+tag)
body=re.sub(r'(<table(?:\s[^>]*)?>)',r'<div class="tablewrap">\1',body)
body=body.replace('</table>','</table></div>')
body=body.replace('<img ', '<img loading="lazy" ')
navigation='<nav aria-label="Proof contents"><p><strong>Contents</strong></p><ol>'+''.join(f'<li><a href="#{html.escape(k)}">{html.escape(title)}</a></li>' for k,title in toc)+'</ol></nav>'
dest=SITE/'src/content/generated/princess-proofs.html';dest.parent.mkdir(parents=True,exist_ok=True)
dest.write_text('\n'.join(line.rstrip() for line in (navigation+'\n'+body).splitlines())+'\n')
page=SITE/'src/pages/princess/proofs.astro';page.parent.mkdir(exist_ok=True)
page.write_text('''---
import Post from "../../layouts/Post.astro";
import proofHtml from "../../content/generated/princess-proofs.html?raw";
---
<Post title="Princess searches: detailed proofs" description="Complete mathematical arguments for paths, narrow grids, odd boxes, and exact finite certificates." updated="2026-09-12">
  <p>This is the complete proof text of the current research manuscript. Return to the <a href="/princess/">interactive overview</a>, read the <a href="/princess/paper/">paper and provenance</a>, or inspect the <a href="/princess/lean/">exact Lean coverage</a>.</p>
  <p>The proofs below and the <a href="/princess/princess-searches.pdf">PDF</a> are generated from the same source. The website uses the paper's theorem and equation numbers. The general rectangular-box problem remains open; precise completed families are stated below.</p>
  <Fragment set:html={proofHtml} />
</Post>
''')
print(f'Generated complete proof page; {len(maths)} formulas rendered strictly; {len(toc)} sections.')

"""Independent unpruned eight-count BFS; no imports from research solvers."""
import itertools,json,time
from collections import deque
from pathlib import Path
start=time.process_time()
g=((0,2,3,4,4,4),(0,3,4,5,5))
initial=(5,4,5,4,4,5,4,5)
queue=deque([initial]);previous={initial:None};depth={initial:0}
expanded=transitions=0
status='incomplete'
while queue:
    if time.process_time()-start>15:
        status='CPU cap';break
    a=queue.popleft();expanded+=1
    if sum(a)<=6:
        terminal=a;status='optimal state reached';break
    def survivors(i,left,b):
        if i==8:
            if left==0:yield tuple(b)
            return
        for r in range(min(left,a[i])+1):
            yield from survivors(i+1,left-r,b+[a[i]-r])
    for b in survivors(0,6,[]):
        transitions+=1;out=[0]*8
        for p in (0,1):
            for j in range(4):
                own=4*p+j
                out[4*(1-p)+j]=max(g[(p+j)%2][b[own]],b[own-1] if j>0 else 0,b[own+1] if j<3 else 0)
        out=tuple(out)
        if out not in previous:
            previous[out]=(a,b);depth[out]=depth[a]+1;queue.append(out)
result={'status':status,'CPU_seconds':time.process_time()-start,'states_expanded':expanded,'states_seen':len(previous),'transitions_examined':transitions,'uses_profile_lower_pruning':False,'uses_beam_pruning':False}
if status=='optimal state reached':
    steps=[(terminal,(0,)*8)];a=terminal
    while previous[a] is not None:
        before,b=previous[a];steps.append((before,b));a=before
    steps.reverse();coords=list(itertools.product(range(3),range(3),range(4)))
    orders={(p,j):sorted([v for v in coords if v[2]==j and sum(v)%2==p],key=lambda v:(v[0]+v[1],-v[0],-v[1])) for p in (0,1) for j in range(4)}
    adj={v:{u for u in coords if sum(abs(x-y) for x,y in zip(u,v))==1} for v in coords}
    S=set(coords);shots=[]
    for a,b in steps:
        expected=set().union(*(set(orders[p,j][:a[4*p+j]]) for p in (0,1) for j in range(4)))
        assert S==expected
        R=set().union(*(set(orders[p,j][:b[4*p+j]]) for p in (0,1) for j in range(4)))
        shot=S-R;assert len(shot)<=6;shots.append(sorted(shot))
        S=set().union(*(adj[v] for v in R)) if R else set()
    assert not S
    result.update({'optimal_days':len(steps),'physical_replay_passed':True,'shots':shots})
result['scope']='Exact full physical capture time via the proved 3x3 transverse-prefix compression; exhaustive BFS, no heuristic pruning. The finite search is not a new Lean theorem.'
receipt=Path(__file__).resolve().parents[1]/'research'/'six-probe-three-by-three-by-four-exact.json'
receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='shots'}))
if status != 'optimal state reached':
    raise SystemExit('The search did not finish; no exact-time conclusion was verified.')
assert result['optimal_days'] == 16 and result['physical_replay_passed']

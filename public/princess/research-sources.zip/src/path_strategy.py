"""Indexed optimal path-search schedule reconstructed from the 2020 parity sweeps.

Coordinates are 1,...,n. Inspections occur before each forced adjacent move.
This file supplies an upper-bound witness; lower bounds are a separate proof.
No search over belief states is used by the schedule generator.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from time import perf_counter


def ceil_div(a: int, b: int) -> int:
    return -(-a // b)


def claimed_time(n: int, m: int) -> int:
    if n < 1 or m < 1:
        raise ValueError("n and m must be positive integers")
    if n <= m:
        return 1
    if m == 1:
        return 2 if n == 2 else 2 * n - 4
    d = 2 * m - 1
    extra = (n - m - 1) % d == 0 and (n % 2 != 0 or m % 2 != 0)
    return ceil_div(2 * n - 4, d) + int(extra)


def parameters(n: int, m: int) -> dict[str, int | bool]:
    """Parameters for n>m and n>=3, including m=1."""
    if not (n > m >= 1 and n >= 3):
        raise ValueError("sweep parameters require n>m>=1 and n>=3")
    d = 2 * m - 1
    e = ceil_div(n - 2, d)
    rho = n - 2 - (e - 1) * d
    c = rho // 2 + 1
    spare = m - c
    s = e if spare > 0 else e + 1
    second_descends = n % 2 != 0 or s % 2 == 0
    # The other trajectory class started with the parity of n.
    parity_at_s = (n + s - 1) % 2
    # If ascending in original coordinates, reflect to descending coordinates.
    reflected_parity = parity_at_s if second_descends else (n + 1 - parity_at_s) % 2
    r0 = n if n % 2 == reflected_parity else n - 1
    b = spare if spare > 0 else m
    r1 = r0 - 2 * b + 1
    remaining_turns = ceil_div(r1 - 1, d)
    total = s + remaining_turns
    return dict(d=d, e=e, rho=rho, c=c, spare=spare, s=s,
                second_descends=second_descends, r0=r0, b=b,
                r1=r1, remaining_turns=remaining_turns, total=total)


def schedule(n: int, m: int) -> list[tuple[int, ...]]:
    """Return explicit inspection sets. Construction does not inspect beliefs."""
    if n < 1 or m < 1:
        raise ValueError("n and m must be positive integers")
    if n <= m:
        return [tuple(range(1, n + 1))]
    if n == 2:  # necessarily m=1
        return [(1,), (1,)]
    p = parameters(n, m)
    d, e, s = int(p["d"]), int(p["e"]), int(p["s"])
    total = int(p["total"])
    turns: list[set[int]] = [set() for _ in range(total)]
    # First trajectory class: delete the rightmost m possible vertices.
    for t in range(1, e + 1):
        r = n - 1 - (t - 1) * d
        count = min(m, (r + 1) // 2)
        turns[t - 1].update(r - 2 * j for j in range(count))
    # Second trajectory class: one possibly partial batch, then full batches.
    for t in range(s, total + 1):
        if t == s:
            r, budget = int(p["r0"]), int(p["b"])
        else:
            r = int(p["r1"]) - (t - s - 1) * d
            budget = m
        count = min(budget, (r + 1) // 2)
        for j in range(count):
            u = r - 2 * j
            v = u if p["second_descends"] else n + 1 - u
            turns[t - 1].add(v)
    return [tuple(sorted(turn)) for turn in turns]


def verify(n: int, m: int, turns: list[tuple[int, ...]]) -> dict[str, int]:
    """Independent ordinary-set replay, with capture checked before movement."""
    possible = set(range(1, n + 1))
    used = 0
    for day, probes in enumerate(turns, 1):
        inspected = set(probes)
        if len(probes) != len(inspected) or len(inspected) > m:
            raise AssertionError(("invalid inspection count", n, m, day, probes))
        if not inspected <= set(range(1, n + 1)):
            raise AssertionError(("out of range", n, m, day, probes))
        used += len(inspected)
        survivors = possible - inspected
        if not survivors:
            if day != len(turns):
                raise AssertionError(("redundant trailing turns", n, m, day))
            return {"capture_day": day, "total_probes": used}
        following: set[int] = set()
        for vertex in survivors:
            if vertex > 1:
                following.add(vertex - 1)
            if vertex < n:
                following.add(vertex + 1)
        if not following:
            raise AssertionError("An uncaptured trajectory disappeared at an isolated vertex")
        possible = following
    raise AssertionError(("schedule did not capture", n, m, sorted(possible)))


def exhaustive_check(max_n: int) -> dict:
    start = perf_counter()
    checked = 0
    for n in range(1, max_n + 1):
        for m in range(1, n + 1):
            turns = schedule(n, m)
            replay = verify(n, m, turns)
            if replay["capture_day"] != claimed_time(n, m):
                raise AssertionError((n, m, replay, claimed_time(n, m)))
            checked += 1
    examples = {}
    for n, m in [(3, 1), (8, 2), (9, 2), (12, 4), (14, 3), (30, 4), (31, 4)]:
        examples[f"{n},{m}"] = {"parameters": parameters(n, m),
                                   "schedule": schedule(n, m)}
    return {"checked_pairs": checked, "max_n": max_n,
            "elapsed_seconds": perf_counter() - start,
            "result": "every indexed schedule captures in the claimed number of turns",
            "scope": "upper-bound witnesses only; no lower-bound inference",
            "examples": examples}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-through", type=int)
    parser.add_argument("--n", type=int)
    parser.add_argument("--m", type=int)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.check_through:
        result = exhaustive_check(args.check_through)
    elif args.n and args.m:
        turns = schedule(args.n, args.m)
        result = {"n": args.n, "m": args.m, "schedule": turns,
                  "verification": verify(args.n, args.m, turns)}
    else:
        parser.error("pass --check-through N or --n N --m M")
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered)
        print(json.dumps({k: v for k, v in result.items() if k != "examples"}))
    else:
        print(rendered, end="")

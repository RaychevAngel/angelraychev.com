"""Bounded probes of the stated merger relaxation and symbolic lower-clock gaps.

All-radius near-pronic interval mode is a proposed geometric strengthening
whose proof is recorded separately. No canonical source is edited.
"""
from pathlib import Path
from collections import deque, Counter
from math import isqrt
import argparse, ast, hashlib, json, time

ROOT = Path(__file__).resolve().parents[1]

def load_model(all_bands=False,strong_band=False,square_memory=False,weighted_cache=False):
    source = (ROOT/'src/resumed_odd_even_erosion_corners.py').read_text()
    original_hash = hashlib.sha256(source.encode()).hexdigest()
    replacements = {
        'if c+2*e<=k<=h-4+c+e': 'if (k>0 or c==e==0) and k<=h-4+c+e',
        'if not i+2*u<=q<=h-4+i+u:continue': 'if not 0<q<=h-4+i+u:continue',
    }
    if all_bands:
        threshold='((s-1)*(s-2) if ee==1 else max(s*(s-1)//2,s*(s-2)))' if strong_band else 'max(s*(s-1)//2,s*(s-2))'
        replacements.update({
            'if band_dual and j==2 and h-C<=t<h-D and s<=b:':
            'if band_dual and j==2 and 2<=s<=b and '+threshold+'<h-t<=s*(s-1):',
            'if s!=b or(i,u,ee)!=(1,2,1):continue':
            'if (i,u,ee)!=(1,2,1):continue',
        })
    if square_memory:
        replacements.update({
            'masks=[0]*(len(states)+len(flags)+len(band_flags))':
            '''near_square_flags={a:len(states)+len(flags)+len(band_flags)+offset
                for offset,a in enumerate(a for r in range(2,b+1) for a in range(h-r*r,h-r*(r-1)))}
    masks=[0]*(len(states)+len(flags)+len(band_flags)+len(near_square_flags))''',
            'if compact:masks[a]|=1<<(trigger if trigger is not None else d)':
            '''if compact:
            bit=1<<(trigger if trigger is not None else d)
            masks[a]|=bit
            size,c,e=states[a]
            if size in near_square_flags and(c,e)==(1,2):
                T,j,v=states[d];ss=T-size+p-1
                allowed=True
                if(j,v)==(1,2) and 2<=ss<=b and ss*(ss-1)<h-T<=ss*ss:
                    rr=root(h-size);inner=min(rr,max(0,n//2-ss))
                    allowed=1>=max(0,inner*inner-(rr*rr-(h-size)))
                if allowed:masks[near_square_flags[size]]|=bit''',
            'add(a,ids[target],p,trigger)':
            '''if i==2 and(j,ee)==(1,2) and 2<=s<=b and s*(s-1)<h-t<=s*s:
                                    trigger=near_square_flags[t]
                                add(a,ids[target],p,trigger)''',
            'if triangle or band_memory:': 'if triangle or band_memory or near_square_flags:',
            'states.extend((a,2,1,5)for a in band_flags)':
            'states.extend((a,2,1,5)for a in band_flags)\n        states.extend((a,1,2,6)for a in near_square_flags)',
        })
    for old, new in replacements.items():
        assert source.count(old)==1, (old,source.count(old))
        source=source.replace(old,new)
    if weighted_cache:
        assert not square_memory
        old='masks=[0]*(len(states)+len(flags)+len(band_flags))'
        assert source.count(old)==1
        source=source.replace(old,old+'''\n    global _bridge_last_weighted
    weighted=[[0]*len(masks) for _ in range(m+1)]
    _bridge_last_weighted=weighted''')
        old='if compact:masks[a]|=1<<(trigger if trigger is not None else d)'
        assert source.count(old)==1
        source=source.replace(old,'''if compact:
            bit=1<<(trigger if trigger is not None else d)
            masks[a]|=bit
            weighted[p][a]|=bit''')
        old='for r,extra in flags.items():masks[extra]=masks[ids[(r*r,1,0)]]&no_corner'
        assert source.count(old)==1
        source=source.replace(old,'''for r,extra in flags.items():
                masks[extra]=masks[ids[(r*r,1,0)]]&no_corner
                for p in range(m+1):weighted[p][extra]=weighted[p][ids[(r*r,1,0)]]&no_corner''')
    # Extract the original builder/functions unchanged, avoiding unused LP imports.
    fsource=(ROOT/'src/resumed_even_construction_formula_profile.py').read_text()
    ftree=ast.parse(fsource)
    fnode=next(node for node in ftree.body if isinstance(node,ast.FunctionDef) and node.name=='F')
    tree=ast.parse(source)
    nodes=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('one_neighbor','low','build')]
    def root(x):return isqrt(x)+(isqrt(x)**2<x)
    def rho(x):
        r=(isqrt(4*x+1)-1)//2
        return r+(r*(r+1)<x)
    ns={'__name__':'bridge_necessary_model','root':root,'rho':rho}
    exec(compile(ast.Module(body=[fnode]+nodes,type_ignores=[]),'<bridge stated model>','exec'),ns)
    return ns['build'], original_hash, hashlib.sha256(source.encode()).hexdigest()

def distances(masks,start):
    dist=[None]*len(masks);dist[start]=0;todo=deque([start])
    while todo:
        a=todo.popleft();bits=masks[a]
        while bits:
            bit=bits&-bits;bits-=bit;d=bit.bit_length()-1
            if dist[d] is None:dist[d]=dist[a]+1;todo.append(d)
    return dist

def clocks(b,n,k):
    h=(2*b+1)*n//2
    def square(x):return isqrt(x)+(isqrt(x)**2<x)
    def rho(x):
        s=(isqrt(4*x+1)-1)//2
        return s+(s*(s+1)<x)
    def pronic(x):
        if not x:return 0
        s=(isqrt(4*x+1)+1)//2
        return s+(s*(s-1)<x)
    def g(p,a):
        if not a:return 0
        return a+(min(square(a),b,rho(h-a)) if not p else min(pronic(a),b+1,square(h-a)))
    F=[[0]*(h+1) for _ in range(2)]
    for a in range(1,h+1):
        for p in range(2):
            z=a;phase=p;t=0
            while z:
                z=g(phase,max(0,z-k));phase=1-phase;t+=1
                assert t<10000
            F[p][a]=t
    return F

def check(b,n,k,all_bands=False,detail=False):
    started=time.process_time();build,sha,weaksha=load_model(all_bands)
    states,masks=build(b,n,k,closed=True,triangle=True,maximal=True,dual=True,compact=True,all_radii=True,band_dual=True)
    h=(2*b+1)*n//2;start=states.index((h,2,2));zero=states.index((0,0,0))
    forward=distances(masks,start);reverse=[0]*len(masks)
    for a,row in enumerate(masks):
        bits=row
        while bits:
            bit=bits&-bits;bits-=bit;d=bit.bit_length()-1;reverse[d]|=1<<a
    backward=distances(reverse,zero);tau=backward[start]
    f=min(s[0] for i,s in enumerate(states) if forward[i] is not None and forward[i]<=tau-1)
    F=clocks(b,n,k);minimum=[min(F[0][a],F[1][a])for a in range(h+1)]
    corrections=[backward[i]-minimum[s[0]] for i,s in enumerate(states)]
    failed=[];checks=0
    for a,row in enumerate(masks):
        bits=row
        while bits:
            bit=bits&-bits;bits-=bit;d=bit.bit_length()-1;checks+=1
            assert backward[a]<=1+backward[d]
            assert forward[d]<=forward[a]+1 if forward[a] is not None else True
            if minimum[states[a][0]]>1+minimum[states[d][0]] and len(failed)<12:
                failed.append({'source':states[a],'target':states[d], 'min_clock':[minimum[states[a][0]],minimum[states[d][0]]]})
    out=dict(width=2*b+1,length=n,budget=k,all_radius_bands=all_bands,states=len(states),edges=checks,
             solo_tau=tau,prefix_upper=min(F[0][h],F[1][h]),penultimate_residual=f,
             full_lower_from_merger=2*tau if 2*f>k else 2*tau-1,
             correction_histogram=dict(sorted(Counter(corrections).items())),min_clock_edge_failures=failed,
             canonical_source_sha256=sha,model_source_sha256=weaksha,cpu_seconds=time.process_time()-started)
    if detail:
        out['state_table']=[dict(state=s,forward=forward[i],backward=backward[i],F0=F[0][s[0]],F1=F[1][s[0]],correction=corrections[i]) for i,s in enumerate(states)]
        path=[start]
        while path[-1]!=zero:
            a=path[-1];choices=[];bits=masks[a]
            while bits:
                bit=bits&-bits;bits-=bit;d=bit.bit_length()-1
                if backward[d]==backward[a]-1:choices.append(d)
            path.append(min(choices,key=lambda d:(states[d][0],states[d])))
        out['shortest_model_path']=[states[i]for i in path]
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--cases',default='5,12,6;6,14,7');ap.add_argument('--all-bands',action='store_true');ap.add_argument('--detail',action='store_true');ap.add_argument('--output',default='research/bridge-lower-frontier-probe.json');args=ap.parse_args()
    rows=[]
    for case in args.cases.split(';'):
        row=check(*map(int,case.split(',')),all_bands=args.all_bands,detail=args.detail);rows.append(row)
        print(json.dumps({k:v for k,v in row.items()if k not in ('state_table','shortest_model_path','min_clock_edge_failures') }),flush=True)
        Path(args.output).write_text(json.dumps(dict(scope=__doc__,rows=rows),indent=2)+'\n')

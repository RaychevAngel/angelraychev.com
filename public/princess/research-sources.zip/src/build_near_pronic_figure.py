"""Illustrate the proved near-pronic dual obstruction with literal rooms."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
ROOT=Path(__file__).resolve().parents[1]
w,n,b=11,12,5
board={(x,y) for x in range(w) for y in range(n)}
def prefix(size,top=False):
    cells=sorted(((x,y) for x,y in board if (x+y)%2==1),key=lambda v:(sum(v),v[0]))[:size]
    return {(x,n-1-y) if top else (x,y) for x,y in cells}
def neighbors(cells):
    return {(x+dx,y+dy) for x,y in cells for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)) if (x+dx,y+dy) in board}
U,V=prefix(17),prefix(18,True)
NV=neighbors(V); witness=(1,0)
assert len(neighbors(U))==22 and len(NV)==23
assert witness in U and witness not in NV
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(7.4,4.85))
for ax,title,cells,col,origin in zip(axes,['First cleared region: 17 rooms','Proposed next region: 18 rooms'],[U,V],['#9d4b19','#245a82'],[(0,0),(0,n-1)]):
    for x,y in sorted(board):
        fill='#e7edf0' if ax is axes[1] and (x,y) in NV else '#ffffff'
        ax.add_patch(Rectangle((x,y),1,1,facecolor=fill,edgecolor='#c3c9cc',linewidth=.4))
    for x,y in cells:
        ax.add_patch(Circle((x+.5,y+.5),.27,facecolor=col,edgecolor='none'))
    ax.add_patch(Rectangle(origin,1,1,fill=False,edgecolor=col,linewidth=1.8))
    ax.add_patch(Circle((witness[0]+.5,witness[1]+.5),.36,fill=False,edgecolor='#191919',linewidth=1.4))
    ax.set(xlim=(-.1,w+.1),ylim=(-.1,n+.1),aspect='equal',title=title)
    ax.set_xticks([]);ax.set_yticks([])
    for spine in ax.spines.values():spine.set_visible(False)
axes[0].set_xlabel('Zero slack would force every orange room\ninto the gray neighborhood on the right.',labelpad=9)
axes[1].set_xlabel('Gray: the next region’s neighborhood.\nIt cannot contain the circled room.',labelpad=9)
fig.subplots_adjust(left=.05,right=.98,top=.92,bottom=.17,wspace=.18)
for ext in ('pdf','svg'):
    fig.savefig(ROOT/'paper/figures'/f'near-pronic-localization.{ext}',bbox_inches='tight')
fig.savefig(ROOT/'tmp/near-pronic-localization.png',dpi=150,bbox_inches='tight')
print('17/22 and 18/23 support/neighborhood counts verified; figure saved.')

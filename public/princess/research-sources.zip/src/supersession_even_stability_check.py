"""Constructive attack on the uniform boundary/stability lemmas.

Random physical supports, no capture-time search. All assertions use actual
coordinate neighborhoods independently of the proof's row formulas.
"""
from pathlib import Path
from random import Random
import json
from time import process_time


def neighbors(S, w, n):
    ans = set()
    for x, y in S:
        if x: ans.add((x-1, y))
        if x+1<w: ans.add((x+1, y))
        if y: ans.add((x, y-1))
        if y+1<n: ans.add((x, y+1))
    return ans


def rows_and_boundary(S, w, n):
    R=[set() for _ in range(w//2)]
    N=[set() for _ in R]
    for x,y in S: R[x//2].add(y)
    for x,y in neighbors(S,w,n): N[x//2].add(y)
    B=[a-r for a,r in zip(N,R)]
    return R,B


def lift(rows, p):
    return {(2*i+((p-y)%2),y) for i,row in enumerate(rows) for y in row}


def prefix_height(x,c,p):
    return c-1-((c-1-p+x)%2)


def pyramid_background(S,w,n,p):
    R,B=rows_and_boundary(S,w,n)
    good=[i for i,row in enumerate(B) if len(row)==1]
    assert good
    reflected=R[good[0]] != set(range(len(R[good[0]])))
    if reflected:
        R=[{n-1-y for y in a} for a in R]
        B=[{n-1-y for y in a} for a in B]
        p=(p+n-1)%2
    assert all(R[i]==set(range(len(R[i]))) for i in good)
    blocks=[]
    for i in good:
        if blocks and i==blocks[-1][-1]+1: blocks[-1].append(i)
        else: blocks.append([i])
    heights=[None]*w
    delta=0
    previous_end=None
    for block in blocks:
        first,last=2*block[0],2*block[-1]+1
        original=prefix_height(first,len(R[block[0]]),p)
        if previous_end is not None:
            distance=first-previous_end
            diff=original+delta-heights[previous_end]
            old_delta=delta
            if diff>distance: delta-=diff-distance
            if diff < -distance: delta+=-distance-diff
            egap=sum(len(B[i])-1 for i in range(previous_end//2+1,first//2))
            assert abs(delta-old_delta)<=16*egap
        assert delta%2==0
        for i in block:
            for x in (2*i,2*i+1):
                heights[x]=prefix_height(x,len(R[i]),p)+delta
        if previous_end is not None:
            steps=first-previous_end
            ups=(steps+heights[first]-heights[previous_end])//2
            assert 0<=ups<=steps
            current=heights[previous_end]
            for step in range(1,steps):
                current += 1 if step<=ups else -1
                heights[previous_end+step]=current
        previous_end=last
    first=2*blocks[0][0]
    for x in range(first-1,-1,-1): heights[x]=heights[x+1]-1
    for x in range(previous_end+1,w): heights[x]=heights[x-1]+1
    assert all(-2<=a<n and (a+x-p)%2==0 for x,a in enumerate(heights))
    assert all(abs(a-b)==1 for a,b in zip(heights,heights[1:]))
    P={(x,y) for x,a in enumerate(heights) for y in range((p-x)%2,a+1,2)}
    if reflected: P={(x,n-1-y) for x,y in P}
    return P


def check(S,w,n,p,stats):
    b=w//2
    R,B=rows_and_boundary(S,w,n)
    s=sum(map(len,B))
    assert s==len(neighbors(S,w,n))-len(S)
    for i in range(b-1):
        assert len(R[i]^R[i+1])<=2*(len(B[i])+len(B[i+1]))+n%2
        assert len(R[i]^R[i+1])<=3*(len(B[i])+len(B[i+1]))
        stats['row_inequalities']+=2
    anchor=min(range(b),key=lambda i:len(B[i]))
    J=R[anchor]|{y for y in range(1,n-1) if y not in R[anchor]
                 and y-1 in R[anchor] and y+1 in R[anchor]}
    cuts=sum((y in J)!=(y+1 in J) for y in range(n-1))
    P=lift([J]*b,p)
    assert cuts<=s//b
    assert len(S^P)<=((4 if n%2==0 else 6)*b+1)*s
    assert len(neighbors(P,w,n))-len(P)==b*cuts
    stats['slab_checks']+=1
    if b<=s<2*b and 40*b*s<len(S)<b*n-40*b*s:
        P=pyramid_background(S,w,n,p)
        e=s-b
        distance=len(S^P)
        assert distance<=50*b*e
        NP=neighbors(P,w,n)
        NS=neighbors(S,w,n)
        minus,plus=P-S,S-P
        H={v for v in neighbors(minus,w,n) if v in NP
           and neighbors({v},w,n)&P<=minus}
        assert (NP-H)|neighbors(plus,w,n)==NS
        assert len(NS^NP)<=4*distance
        stats['pyramid_checks']+=1
        stats['exact_neighborhood_checks']+=1
        stats['positive_excess_checks']+=int(e>0)
        stats['maximum_actual_pyramid_distance']=max(stats['maximum_actual_pyramid_distance'],distance)
        stats['maximum_actual_excess']=max(stats['maximum_actual_excess'],e)


def main():
    start=process_time()
    rng=Random(13092026)
    stats={'row_inequalities':0,'slab_checks':0,'pyramid_checks':0,
           'exact_neighborhood_checks':0,'positive_excess_checks':0,
           'maximum_actual_pyramid_distance':0,'maximum_actual_excess':0}
    for b in range(2,9):
        w=2*b
        for parity in range(2):
            n=160*b+80+parity
            for p in range(2):
                for trial in range(5):
                    height=n//2
                    height-=(height-p)%2
                    heights=[height]
                    for _ in range(w-1): heights.append(heights[-1]+rng.choice((-1,1)))
                    S={(x,y) for x,a in enumerate(heights) for y in range((p-x)%2,a+1,2)}
                    if trial:
                        interior=sorted((x,y) for x,y in S if 10<y<min(heights)-10)
                        S.difference_update(rng.sample(interior,min(trial,b-1)))
                    if trial==2:
                        corner=(0,n-1) if (n-1)%2==p else (w-1,n-1)
                        S.add(corner)
                    if trial==3:
                        for _ in range(4):
                            x=rng.randrange(w)
                            y=heights[x]+2*rng.choice((-2,-1,0,1,2))
                            if (x,y) in S:S.remove((x,y))
                            else:S.add((x,y))
                    if trial==4: S={(x,n-1-y) for x,y in S};pcheck=(p+n-1)%2
                    else:pcheck=p
                    check(S,w,n,pcheck,stats)
    # Arbitrary small supports attack the row and slab lemmas outside stability's guard.
    for b in range(1,5):
        w=2*b
        for n in range(2,10):
            for p in range(2):
                vertices=[(x,y) for x in range(w) for y in range(n) if (x+y)%2==p]
                for _ in range(12):
                    density=rng.random()
                    S={v for v in vertices if rng.random()<density}
                    check(S,w,n,p,stats)
    stats['status']='all checks passed'
    stats['seed']=13092026
    stats['scope']='random coordinate-set verification of proved geometric statements; no capture-time search'
    stats['CPU_seconds']=round(process_time()-start,6)
    Path('research/supersession-even-stability-check.json').write_text(json.dumps(stats,indent=2)+'\n')
    print(json.dumps(stats,indent=2))


if __name__=='__main__':main()

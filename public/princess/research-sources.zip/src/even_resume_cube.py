"""Prepare and verify the exact even-cube native BFS certificate."""
import json
from pathlib import Path
import sys
from pyramidal_time import prepare, replay

ROOT=Path(__file__).resolve().parents[1]

def setup():
    data=prepare((4,4,4))
    target=ROOT/'research/even-resume-four-cube-input.txt'
    with target.open('w') as out:
        out.write('292 292 7 32\n')
        for p in(0,1):
            for mask,size,hood in zip(data['ideals'][p],data['sizes'][p],data['hood'][p]):
                out.write(f'{mask} {size} {hood}\n')
    return data

def verify(shape=(4,4,4), stem='four-cube', odd_paths=False):
    data=prepare(shape,odd_paths=odd_paths); rows=[]
    lines=iter((ROOT/f'research/even-resume-{stem}-raw.txt').read_text().splitlines())
    for line in lines:
        m, turns, states, edges, seconds=line.split()
        m,turns=int(m),int(turns); shots=[]
        for _ in range(max(turns,0)):
            a,b,r,s=map(int,next(lines).split())
            assert data['ideals'][0][r]&~data['ideals'][0][a]==0
            assert data['ideals'][1][s]&~data['ideals'][1][b]==0
            shot=[]
            for p,before,after in((0,a,r),(1,b,s)):
                removed=data['ideals'][p][before]^data['ideals'][p][after]
                shot.extend(v for i,v in enumerate(data['colors'][p]) if removed>>i&1)
            shots.append(shot)
        if turns>=0:replay(data['shape'],m,shots)
        rows.append({'budget':m,'minimum_turns':None if turns<0 else turns,
                     'states_seen':int(states),'deduplicated_transition_count':int(edges),
                     'solver_seconds':float(seconds),'physical_replay':turns>=0,'shots':shots})
    result={'shape':list(shape),'canonical_supports':[len(row) for row in data['ideals']],
            'includes_odd_path_compression':odd_paths,
            'exactness':'Proved square-pair/optional odd-path strategy compression plus exhaustive finite BFS; ordinary, not Lean.',
            'pruning':'Only identical successor deduplication and earliest visits. All exact full useful allocations retained.',
            'results':rows}
    (ROOT/f'research/even-resume-{stem}-exact.json').write_text(json.dumps(result,indent=2)+'\n')
    for row in rows:print({k:v for k,v in row.items() if k!='shots'})

if __name__=='__main__':
    if sys.argv[-1]=='verify':verify()
    elif sys.argv[-1]=='verify344':verify((3,4,4),'three-four-four',True)
    else:setup()

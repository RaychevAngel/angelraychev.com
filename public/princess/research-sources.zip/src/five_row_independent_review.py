"""Independent physical checks for the all-length five-row proof review.

The finite checks attack the coordinate interpretation; the accompanying
proof note explains why the symbolic argument covers unbounded lengths.
"""
import json
from pathlib import Path
from time import monotonic


def physical_graph(n):
    vertices = [(x, y) for x in range(n) for y in range(5)]
    index = {v: i for i, v in enumerate(vertices)}
    adjacency = []
    for x, y in vertices:
        adjacency.append(sum(1 << index[w] for w in
                             [(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)]
                             if w in index))
    return vertices, index, adjacency


def neighbors(mask, adjacency):
    answer = 0
    while mask:
        bit = mask & -mask
        answer |= adjacency[bit.bit_length() - 1]
        mask ^= bit
    return answer


def exhaustive_physical_check(n=6):
    vertices, index, adjacency = physical_graph(n)
    q, h = n // 2, 5 * n // 2
    reports = []
    for parity in range(2):
        # Reverse the paired-column coordinate for physical parity one.
        embedding = []
        for j in range(q):
            for y in range(5):
                jj = j if parity == 0 else q - 1 - j
                x = 2 * jj + ((parity - y) % 2)
                embedding.append(index[(x, y)])
        low_boundary = {0: 0, 1: 0, 2: 0}
        for support in range(1 << h):
            physical = sum(1 << embedding[i] for i in range(h) if support >> i & 1)
            physical_hood = neighbors(physical, adjacency)
            size = support.bit_count()
            surplus = physical_hood.bit_count() - size
            word = [(support >> (5 * j)) & 31 for j in range(q)]
            local_sum = 0
            for j, b in enumerate(word):
                a = word[j - 1] if j else 0
                c = word[j + 1] if j + 1 < q else 0
                vertical = ((b << 1) | (b >> 1)) & 31
                local_sum += ((~b) & 31 & (vertical | (a & 10) | (c & 21))).bit_count()
            assert local_sum == surplus, (parity, support, local_sum, surplus)
            if surplus in low_boundary:
                low_boundary[surplus] += 1
            if surplus == 0:
                assert size in (0, h)
            if surplus == 1:
                assert size in (1, h - 2, h - 1)
            if surplus == 2:
                row_prefix = all(all(not (word[j] >> y & 1) or all(word[i] >> y & 1
                                 for i in range(j)) for j in range(q)) for y in range(5))
                if 3 <= size <= h - 5:
                    assert row_prefix
                empty_row = any(all(not (b >> y & 1) for b in word) for y in range(5))
                if row_prefix and empty_row:
                    assert size <= 5
                if row_prefix and 4 <= size <= 6:
                    last = word[-1] | (((word[-1] << 1) | (word[-1] >> 1)) & 31)
                    last |= word[-2] & 10
                    assert last == 0
        reports.append(dict(parity=parity, supports=1 << h,
                            low_boundary_counts=low_boundary))
    return dict(length=n, checks=reports)


def independent_sweep(n):
    vertices, _, adjacency = physical_graph(n)
    h = 5 * n // 2
    orders = [sorted((i for i, (x, y) in enumerate(vertices) if (x + y) % 2 == p),
                     key=lambda i: (sum(vertices[i]), vertices[i][0])) for p in range(2)]
    prefix = [[0] for _ in range(2)]
    for p in range(2):
        for i in orders[p]:
            prefix[p].append(prefix[p][-1] | (1 << i))
        for k, s in enumerate(prefix[p]):
            image = neighbors(s, adjacency)
            surplus = (1 if k in (1, h - 2, h - 1) else 2) if p == 0 else (
                1 if k == h - 1 else 2 if k in (1, 2, h - 4, h - 3, h - 2) else 3)
            expected = 0 if k == 0 else h if k == h else k + surplus
            assert image == prefix[1-p][expected] if p == 1 else image.bit_count() == expected
    # Now both prefix arrays have been built, check the full nesting identities.
    for p in range(2):
        for support in prefix[p]:
            image = neighbors(support, adjacency)
            assert image == prefix[1-p][image.bit_count()]
    # Construct/replay each cohort independently with a fixed reflection.
    final_days = []
    for cohort in range(2):
        belief = prefix[cohort][h]
        day = 0
        while belief:
            physical_parity = cohort ^ (day % 2)
            phase = day % 2
            order = orders[phase]
            if cohort:
                order = [(n - 1 - vertices[i][0]) * 5 + vertices[i][1] for i in order]
            assert all(sum(vertices[i]) % 2 == physical_parity for i in order)
            b = belief.bit_count()
            assert belief == sum(1 << i for i in order[:b])
            shots = sum(1 << i for i in order[max(0, b - 3):b])
            belief = neighbors(belief & ~shots, adjacency)
            day += 1
            assert day <= 2 * h
        assert day == 2 * h - 10 and day % 2 == 0
        final_days.append(day)
    return dict(length=n, cohort_days=final_days, total_days=sum(final_days))


def independent_odd_sweep(n):
    vertices, _, adjacency = physical_graph(n)
    h = (5 * n - 1) // 2
    orders = [sorted((i for i, (x, y) in enumerate(vertices) if (x + y) % 2 == p),
                     key=lambda i: (sum(vertices[i]), vertices[i][0])) for p in range(2)]
    prefix = [[0] for _ in range(2)]
    for p in range(2):
        for i in orders[p]:
            prefix[p].append(prefix[p][-1] | (1 << i))
    for p in range(2):
        for k, support in enumerate(prefix[p]):
            if not k:
                expected = 0
            elif p == 0:
                expected = h if k >= h else k + (1 if k == 1 or k >= h - 3 else 2)
            else:
                expected = k + (1 if k == h else 2 if k <= 2 or k >= h - 2 else 3)
            assert neighbors(support, adjacency) == prefix[1-p][expected]
    belief = (1 << len(vertices)) - 1
    days = 0
    cohort_days = []
    # The two actual physical cohorts, initially minority first.
    for initial_color in (1, 0):
        start = days
        support = prefix[1][h]
        while support:
            current_color = initial_color ^ (days % 2)
            assert support == (belief & prefix[current_color][-1])
            b = support.bit_count()
            survivors = prefix[current_color][max(0, b - 3)]
            assert not survivors & ~support
            shots = support ^ survivors
            assert shots.bit_count() <= 3
            belief = neighbors(belief & ~shots, adjacency)
            support = neighbors(survivors, adjacency)
            days += 1
        cohort_days.append(days - start)
        assert days - start == 2 * h - 9 and (days - start) % 2 == 1
    assert not belief and days == 10 * n - 20
    return dict(length=n, cohort_days=cohort_days, total_days=days)


if __name__ == '__main__':
    started = monotonic()
    exhaustive = exhaustive_physical_check()
    sweeps = [independent_sweep(n) for n in (6, 8, 10, 12, 14, 20, 50, 100)]
    odd_sweeps = [independent_odd_sweep(n) for n in (5, 7, 9, 11, 15, 21, 51, 101)]
    result = dict(status='passed', exhaustive_physical_support_check=exhaustive,
                  independently_constructed_sweeps=sweeps,
                  independently_constructed_odd_sweeps=odd_sweeps,
                  seconds=monotonic() - started,
                  proof_scope='Finite implementation attacks. All-length pumping and diagonal-layer arguments are reviewed separately in five-row-independent-review.md.')
    Path('research/five-row-independent-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

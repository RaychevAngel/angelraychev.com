"""Small scalar-only audit of the proposed precentral ammunition guard.
No joint strategy search is performed by this script.
"""
from supersession_solo_bands import OddRectangle
from maturation_odd_ammunition import growth_cost
from math import isqrt
from time import process_time
from pathlib import Path
import json

def main():
    start=process_time();rows=[]
    for b in [3,4,5,7,10,15,20,30,50,100,200]:
        w=2*b+1
        for m in sorted({b+2,2*b,isqrt(b**3),b*b//4,b*b//2,b*b-1,b*b}):
            if not b+1<m<=b*b:continue
            for n in [w,w+2,3*w,101*w]:
                G=OddRectangle(w,n);half=G.half_time(m)
                D=[G.C[p]-half['precentral_residuals'][p] for p in [0,1]]
                delta=abs(D[0]-D[1])
                if not delta:continue
                primary=int(D[1]>D[0]);q=1-primary
                critical=(G.C[q]-m+1)//2
                overhead=growth_cost(b,m,q,critical)-critical
                rows.append(dict(b=b,n=n,m=m,L=half['tau']-1,D=D,delta=delta,critical=critical,overhead=overhead,margin=overhead-delta,coarse_margin=overhead-(m-1)))
                if process_time()-start>5:break
            if process_time()-start>5:break
        if process_time()-start>5:break
    out=dict(scope='Scalar-only finite evidence for a proposed sufficient barrier, not a theorem',seconds=process_time()-start,cases=rows)
    Path('research/resumed-odd-compatibility-solo-guard.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(seconds=out['seconds'],cases=len(rows),failures=[x for x in rows if x['margin']<=0],smallest_margin=min([x['margin'] for x in rows]),coarse_guard_passed=sum(x['coarse_margin']>0 for x in rows),coarse_guard_failed=sum(x['coarse_margin']<=0 for x in rows)),indent=2))
if __name__=='__main__':main()

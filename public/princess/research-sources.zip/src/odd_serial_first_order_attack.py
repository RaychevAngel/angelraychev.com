#!/usr/bin/env python3
"""Test a stronger, prescribed-first-cohort version of serial optimality."""
from collections import deque
from math import isqrt
from pathlib import Path
import json,time


def profiles(a,b):
    e=((2*a+1)*(2*b+1)+1)//2;o=e-1
    rt=lambda k:isqrt(k)+(isqrt(k)**2<k)
    def q(k):
        r=isqrt(k)+1
        while r*(r-1)<k:r+=1
        return r
    return [[0]+[k+min(rt(k),b,rt(e-k)-1)for k in range(1,e+1)],
            [0]+[k+min(q(k),b+1,q(o-k))for k in range(1,o+1)]]


def solve(g,m,first):
    start=(len(g[first])-1,len(g[1-first])-1,first)
    queue=deque([(start,0)]);seen={start}
    while queue:
        (a,b,p),t=queue.popleft()
        if a+b<=m:return t+1
        for k in range(m+1):
            na=g[p][max(0,a-k)];nb=g[1-p][max(0,b-(m-k))]
            if not nb and na:continue
            nxt=(na,nb,1-p)
            if nxt not in seen:seen.add(nxt);queue.append((nxt,t+1))
    return None


def serial(g,m,first):
    a,b,p=len(g[first])-1,len(g[1-first])-1,first;t=0;seen=set()
    while (a,b,p)not in seen:
        if a+b<=m:return t+1
        seen.add((a,b,p));k=min(a,m)
        a,b=g[p][a-k],g[1-p][max(0,b-(m-k))]
        p=1-p;t+=1
    return None


if __name__=='__main__':
    start=time.monotonic();rows=[];count=0
    for b in range(1,5):
      for a in range(b,b+4):
        g=profiles(a,b)
        for m in range(b+1,len(g[1])):
          for first in(0,1):
            got=solve(g,m,first);candidate=serial(g,m,first);count+=1
            if got!=candidate:rows.append({'shape':[2*a+1,2*b+1],'budget':m,'first_parity':first,'optimum_given_first_cohort':got,'serial':candidate})
    out={'scope':'Stronger prescribed-first-cohort conjecture only. Its failure need not refute serial play optimized over the first parity.','checks':count,'failures':rows,'seconds':time.monotonic()-start}
    Path(__file__).resolve().parents[1].joinpath('research/odd-serial-first-order-attack.json').write_text(json.dumps(out,indent=2)+'\n')
    print({**out,'failures':rows[:20]})

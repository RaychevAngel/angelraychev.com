"""Independent direct-neighborhood checks for the odd-cylinder proof.

This deliberately does not import the profile implementation under review.
The ordinary proof, not this finite check, supplies the universal theorem.
"""

from itertools import product
import json
from pathlib import Path


def vertices(shape):
    return list(product(*(range(a) for a in shape)))


def ordered(shape, parity):
    return sorted((v for v in vertices(shape) if sum(v) % 2 == parity),
                  key=lambda v: (sum(v), tuple(-x for x in v)))


def neighbors(v, shape):
    for i, size in enumerate(shape):
        for step in (-1, 1):
            if 0 <= v[i] + step < size:
                out = list(v)
                out[i] += step
                yield tuple(out)


def cost(v, shape):
    positive = [i for i, x in enumerate(v) if x]
    if not positive:
        return len(shape)
    j = positive[-1]
    return len(shape) - j - int(v[j] == shape[j] - 1)


def profile(shape, parity):
    hood = set()
    answer = [0]
    for v in ordered(shape, parity):
        hood.update(neighbors(v, shape))
        answer.append(len(hood))
    return answer


def check(cross):
    w = 1
    for side in cross:
        w *= side
    s = sum(a - 1 for a in cross)
    z = w * (s + 1)
    n = 4 * (s + 1) + 3
    slab = cross + (s + 1,)
    tables = []
    for p in (0, 1):
        ranks = {v[:-1]: i + 1 for i, v in enumerate(ordered(slab, p)) if v[-1] == 0}
        assert max(ranks.values()) <= z
        tables.append(ranks)
    shapes = [cross + (n,), cross + (n + 2,)]
    profiles = [[profile(shape, p) for p in (0, 1)] for shape in shapes]
    checked = 0
    for shape, ps in zip(shapes, profiles):
        h = (w * shape[-1] + 1) // 2
        assert h >= 2 * z + 3
        for p, gs in enumerate(ps):
            ranks = tables[p]
            qcount = len(ranks)
            for k, actual in enumerate(gs):
                u = sum(cost(v, cross) for v, rank in ranks.items() if rank <= k)
                tail_b = sum(rank <= h - p - k for rank in ranks.values())
                predicted = k + p + u - qcount + tail_b if k else 0
                assert actual == predicted, (cross, shape[-1], p, k, actual, predicted)
                assert actual - k <= (w - 1) // 2 + p
                if k > z and h - p - k > z:
                    assert actual == k + (w - 1) // 2 + p
                checked += 1
            assert max(g - k for k, g in enumerate(gs)) == (w - 1) // 2 + p
    h = (w * n + 1) // 2
    translations = 0
    for p in (0, 1):
        for k, actual in enumerate(profiles[0][p]):
            if h - p - k > z:
                assert profiles[1][p][k] == actual
                translations += 1
            if k > z:
                assert profiles[1][p][k + w] == actual + w
                translations += 1
    return {"cross_section": cross, "lengths": [n, n + 2], "W": w, "S": s,
            "profile_entries_checked": checked, "translation_entries_checked": translations,
            "hunter_number": (w + 1) // 2}


if __name__ == "__main__":
    rows = [check(q) for q in [(3,), (5,), (3, 3), (3, 5), (3, 3, 3),
                               (3, 3, 5), (5, 5)]]
    result = {"status": "passed", "method": "independent actual coordinate neighborhood unions",
              "universal_claim": "ordinary proof only; these checks are supplementary",
              "cases": rows}
    path = Path(__file__).resolve().parents[1] / "research/odd-cylinder-independent-review.json"
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "boards": 2 * len(rows),
                      "profile_entries": sum(r["profile_entries_checked"] for r in rows),
                      "translations": sum(r["translation_entries_checked"] for r in rows)}))

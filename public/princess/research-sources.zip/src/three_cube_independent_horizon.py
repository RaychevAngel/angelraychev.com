#!/usr/bin/env python3
"""Independent backwards min-max horizon certificate for the 3x3x3 cube.

Does not import the root's pyramidal solver. Computes least uniform budget
for every horizon on all32x28 fixed states, then reads all optimal times.
"""
from itertools import product,combinations
from pathlib import Path
from time import monotonic
import json
from square_strategy_compression import one_operator


def main():
    start=monotonic()
    points=list(product(range(3),repeat=3))
    colors=[[v for v in points if sum(v)%2==p]for p in(0,1)]
    ns=[]
    for p in(0,1):
        singles=[sum(1<<j for j,w in enumerate(colors[1-p]) if sum(abs(a-b)for a,b in zip(v,w))==1)for v in colors[p]]
        table=[0]*(1<<len(singles))
        for a in range(1,len(table)):
            bit=a&-a;table[a]=table[a^bit]|singles[bit.bit_length()-1]
        ns.append(table)
    ops=[one_operator(colors,i,j,sign)for i,j in combinations(range(3),2)for sign in(1,-1)]
    fixed=[[a for a in range(len(ns[p]))if all(op[p][a]==a for op in ops)]for p in(0,1)]
    ids=[{a:i for i,a in enumerate(row)}for row in fixed]
    for p in(0,1):assert all(ns[p][a]in ids[1-p]for a in fixed[p])
    n0,n1=map(len,fixed);state_count=n0*n1
    edges=[];edges_total=0
    for a,b in product(fixed[0],fixed[1]):
        choices={}
        for r in fixed[0]:
            if r&a!=r:continue
            for s in fixed[1]:
                if s&b!=s:continue
                target=ids[0][ns[1][s]]*n1+ids[1][ns[0][r]]
                cost=a.bit_count()+b.bit_count()-r.bit_count()-s.bit_count()
                choices[target]=min(cost,choices.get(target,28))
        edges.append(list(choices.items()));edges_total+=len(choices)
    values=[28]*state_count;values[0]=0
    budgets=[28];horizon=0
    while True:
        nxt=[min(max(cost,values[target])for target,cost in choices)for choices in edges]
        horizon+=1;budgets.append(nxt[-1])
        if nxt==values:break
        values=nxt
        assert horizon<=state_count
    times=[]
    for m in range(1,28):
        t=next((t for t,b in enumerate(budgets)if b<=m),None)
        times.append({'budget':m,'minimum_turns':t})
    data={'model':'inspect first, then move one graph edge; exact fixed-state reduction proved separately',
          'method':'independent full-state backwards min-max recurrence, all budgets at once',
          'fixed_counts':[n0,n1],'states':state_count,'distinct_target_edges':edges_total,
          'least_budget_by_horizon':budgets,'fixed_point_horizon':horizon,
          'times':times,'seconds':round(monotonic()-start,4)}
    dest=Path(__file__).resolve().parents[1]/'research'/'three-cube-independent-horizon.json'
    dest.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2))


if __name__=='__main__':main()

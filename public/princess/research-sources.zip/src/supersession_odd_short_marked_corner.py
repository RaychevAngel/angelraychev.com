"""Attack a stronger corner-history relation; never a physical upper certificate."""
from high_budget_odd_rectangles import potential, R, Q, low

def check(w,n,m):
 b=w//2; h=w*n//2; B=b*(b+1)
 F=lambda k,z:min(potential(b,m,2*h),potential(b,m,2*k+(z!=0)))
 g=lambda s:s+min(R(s),b,Q(h-s)-1) if s else 0
 states=[(k,0)for k in range(h+1)]
 states += [(k,1)for k in range(b*b+b+1,h-B+b)]
 states += list({(h-x+a,2)for x in range(1,B+1)for a in range(Q(x)-1,b+1)if x>a*a})
 failures=[]
 for k,z in states:
  for p in range(min(m,k)+1):
   s=k-p
   if not s:targets=[(0,0)]
   elif s>=h-B:
    x=h-s
    targets=[(s+a,2 if x>a*a else 0)for a in range(g(s)-s,min(b,h-s)+1)]
    if s+b+1<=h:targets.append((s+b+1,0))
   elif s<=b*b:targets=[(max(g(s),low(b,1 if z==1 else 0,s)),0)]
   else:
    targets=[(s+b+1,0)]
    if not z:targets.append((s+b,1))
   for j,v in targets:
    if F(k,z)>p+F(j,v):
     failures.append((k,z,p,s,j,v,F(k,z),p+F(j,v)))
 return dict(shape=[w,n],m=m,failures=len(failures),examples=failures[:12])

if __name__=='__main__':
 for w,n,m in [(3,12,4),(5,16,11),(9,10,21),(15,18,59),(29,64,218),(31,68,247),(37,80,344)]:
  print(check(w,n,m))

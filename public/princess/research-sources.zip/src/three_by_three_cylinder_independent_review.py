"""Independent exact checks of the all-odd 3-by-3 cylinder time proof."""
from pathlib import Path
import json
from odd_cylinder_independent_review import ordered, neighbors

COST = [0, 0, 1, 2, 3, 3]  # quota charges multiplied by three


def physical_profiles(n):
    shape = (3, 3, n)
    orders = [ordered(shape, p) for p in (0, 1)]
    prefixes = []
    for row in orders:
        acc = set()
        out = [set()]
        for v in row:
            acc.add(v)
            out.append(acc.copy())
        prefixes.append(out)
    profile = []
    for p in (0, 1):
        hood, out = set(), [0]
        for v in orders[p]:
            hood.update(neighbors(v, shape))
            out.append(len(hood))
            assert hood == prefixes[1-p][len(hood)]
        profile.append(out)
    return shape, prefixes, profile


def check_potential(g, f):
    assert all(COST[r]+COST[s] <= 3 for r in range(6) for s in range(6-r))
    count = 0
    for p in (0, 1):
        assert f[p][0] == 0 and min(f[p]) >= 0
        for k in range(len(g[p])):
            for r in range(6):
                assert f[p][k] <= COST[r]+f[1-p][g[p][max(k-r, 0)]]
                count += 1
    return count


def independent_distances(g):
    # Bellman relaxation, independent of the submitted Dijkstra generator.
    f = [[0]+[10**7]*(len(row)-1) for row in g]
    changed = True
    while changed:
        changed = False
        for p in (0, 1):
            for k in range(1, len(g[p])):
                bound = min(COST[r]+f[1-p][g[p][max(k-r,0)]] for r in range(6))
                if bound < f[p][k]:
                    f[p][k] = bound
                    changed = True
    return f


def physical_sweep(shape, prefixes, g, cut=None):
    belief = prefixes[0][-1] | prefixes[1][-1]
    a, b, p, days = len(prefixes[1][-1]), len(prefixes[0][-1]), 1, 0
    hit = [False, False]
    while belief:
        if cut is not None and a == cut:
            assert b == len(prefixes[1-p][-1])
            hit[0] = True
        if cut is not None and a == 0 and b == cut:
            hit[1] = True
        qa, qb = min(a, 5), min(b, max(5-a, 0))
        shots = (prefixes[p][a]-prefixes[p][a-qa]) | (prefixes[1-p][b]-prefixes[1-p][b-qb])
        assert len(shots) <= 5 and shots <= belief
        remaining = belief - shots
        belief = {v for x in remaining for v in neighbors(x, shape)}
        a, b = g[p][a-qa], g[1-p][b-qb]
        p, days = 1-p, days+1
        assert belief == prefixes[p][a] | prefixes[1-p][b]
    return days, hit


if __name__ == "__main__":
    rows, count = [], 0
    base = None
    for n in (3, 5, 7, 9, 11):
        shape, prefixes, g = physical_profiles(n)
        f = independent_distances(g)
        count += check_potential(g, f)
        days, hits = physical_sweep(shape, prefixes, g, 25 if n == 11 else None)
        assert sum(row[-1] for row in f) == 3*days == 3*(18*n-36)
        if n == 11:
            assert all(hits)
            assert all(f[p][k] == 3*(2*k-14+p) for p in (0,1) for k in range(13,38))
            base = f
        rows.append({"n": n, "days": days, "lower_charge_scaled_by_three": sum(row[-1] for row in f)})
    for n in (13, 31):
        shape, prefixes, g = physical_profiles(n)
        delta = 9*(n-11)//2
        f = [[base[p][k] if k <= 25 else
              base[p][25]+6*(k-25) if k <= 25+delta else
              base[p][k-delta]+6*delta for k in range(len(g[p]))] for p in (0,1)]
        count += check_potential(g, f)
        days, _ = physical_sweep(shape, prefixes, g)
        assert sum(row[-1] for row in f) == 3*days == 3*(18*n-36)
        rows.append({"n": n, "days": days, "inserted_delta": delta})
    result = {"status": "passed", "physical_boards": rows, "exact_inequalities": count,
              "base_collar_and_both_clean_cut_visits": True,
              "method": "independent actual neighborhoods, Bellman potentials, physical replay",
              "scope": "supplementary finite checks; ordinary insertion argument supplies all n"}
    target = Path(__file__).resolve().parents[1] / "research/three-by-three-cylinder-independent-review.json"
    target.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result))

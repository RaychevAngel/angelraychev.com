"""Exact reduced game under the proved equal-coordinate compression theorem.

Common fixed states are generated without enumerating all physical subsets.
The theorem is in research/corner-ideal-exchange.md. For unequal boxes only
pairs of equal side lengths are compressed; this still gives an exact game,
but can leave an impractically large family. Explicit state limits prevent
uncontrolled searches. No polynomial complexity claim is made.
"""
from collections import deque
from itertools import combinations, product
from pathlib import Path
from time import monotonic
import argparse
import json


def prepare(shape, limit=20000, odd_paths=False):
    vertices = list(product(*(range(n) for n in shape)))
    if len(vertices) > 300:
        raise ValueError('This exploratory implementation is limited to300rooms.')
    colors = [[v for v in vertices if sum(v) % 2 == p] for p in (0, 1)]
    indices = [{v: i for i, v in enumerate(row)} for row in colors]
    ideals, adj = [], []
    for p, row in enumerate(colors):
        predecessors = []
        neighbors = []
        for v in row:
            pred = 0
            if odd_paths:
                for axis, n in enumerate(shape):
                    if n % 2 and v[axis] >= 2:
                        w = list(v)
                        w[axis] -= 2
                        pred |= 1 << indices[p][tuple(w)]
            for i, j in combinations(range(len(shape)), 2):
                if shape[i] != shape[j]:
                    continue
                for direction in (-1, 1):
                    w = list(v)
                    w[i] += direction
                    w[j] -= 1
                    if all(0 <= w[k] < shape[k] for k in range(len(shape))):
                        pred |= 1 << indices[p][tuple(w)]
            predecessors.append(pred)
            nb = 0
            for i, n in enumerate(shape):
                for direction in (-1, 1):
                    w = list(v)
                    w[i] += direction
                    if 0 <= w[i] < n:
                        nb |= 1 << indices[1-p][tuple(w)]
            neighbors.append(nb)
        adj.append(neighbors)
        seen = {0}
        queue = deque([0])
        while queue:
            b = queue.popleft()
            for i, pred in enumerate(predecessors):
                bit = 1 << i
                if not b & bit and pred & b == pred:
                    new = b | bit
                    if new not in seen:
                        seen.add(new)
                        queue.append(new)
                        if len(seen) > limit:
                            raise ValueError(f'Canonical state limit{limit}exceeded on parity{p}')
        ideals.append(sorted(seen, key=lambda b: (b.bit_count(), b)))
    lookup = [{b: i for i, b in enumerate(row)} for row in ideals]
    hood = []
    for p in (0, 1):
        nbs = []
        for b in ideals[p]:
            nb, remaining = 0, b
            while remaining:
                bit = remaining & -remaining
                nb |= adj[p][bit.bit_length()-1]
                remaining ^= bit
            assert nb in lookup[1-p], ('closure', shape, p, b, nb)
            nbs.append(lookup[1-p][nb])
        hood.append(nbs)
    return {'shape': shape, 'odd_paths': odd_paths, 'colors': colors, 'ideals': ideals, 'hood': hood,
            'sizes': [[b.bit_count() for b in row] for row in ideals]}


def solve(data, budget, product_limit=2000000):
    ideals, sizes, hood = (data[k] for k in ('ideals', 'sizes', 'hood'))
    if len(ideals[0])*len(ideals[1]) > product_limit:
        raise ValueError('Two-cohort state product exceeds exploration limit.')
    descendants = []
    for p in (0, 1):
        rows = []
        for b, size in zip(ideals[p], sizes[p]):
            rows.append([(j, size-sizes[p][j]) for j, r in enumerate(ideals[p])
                         if r & b == r and size-sizes[p][j] <= budget])
        descendants.append(rows)
    initial = (len(ideals[0])-1, len(ideals[1])-1)
    parents = {initial: None}
    queue = deque([initial])
    edges = 0
    while queue:
        state = queue.popleft()
        a, b = state
        if sizes[0][a]+sizes[1][b] <= budget:
            schedule = [(state, 0, 0)]
            while parents[state] is not None:
                state, r, s = parents[state]
                schedule.append((state, r, s))
            schedule.reverse()
            rooms = []
            for (a, b), r, s in schedule:
                shot = []
                for p, before, after in ((0, a, r), (1, b, s)):
                    mask = ideals[p][before] ^ ideals[p][after]
                    shot += [v for i, v in enumerate(data['colors'][p]) if mask >> i & 1]
                rooms.append(shot)
            replay(data['shape'], budget, rooms)
            return {'minimum_turns': len(rooms), 'discovered_states': len(parents),
                    'examined_edges': edges, 'shots': rooms}
        for r, cost in descendants[0][a]:
            for s, other_cost in descendants[1][b]:
                if cost+other_cost > budget:
                    continue
                successor = (hood[1][s], hood[0][r])
                edges += 1
                if successor not in parents:
                    parents[successor] = (state, r, s)
                    queue.append(successor)
    return {'minimum_turns': None, 'discovered_states': len(parents), 'examined_edges': edges}


def one_cohort(data, budget):
    """Exact single-cohort times; their finiteness also decides full feasibility."""
    ideals, sizes, hood = (data[k] for k in ('ideals', 'sizes', 'hood'))
    edges = []
    for p in (0, 1):
        edge_rows = []
        for a, size in zip(ideals[p], sizes[p]):
            edge_rows.append([hood[p][j] for j, r in enumerate(ideals[p])
                              if r & a == r and size-sizes[p][j] <= budget])
        edges.append(edge_rows)
    ranks = [[0]+[-1]*(len(row)-1) for row in ideals]
    rounds = 0
    while True:
        changes = []
        for p in (0, 1):
            for b, successors in enumerate(edges[p]):
                if ranks[p][b] < 0 and any(ranks[1-p][nxt] >= 0 for nxt in successors):
                    changes.append((p, b))
        if not changes:
            return {'one_cohort_minimum_turns': [row[-1] for row in ranks],
                    'fixed_point_rounds': rounds,
                    'full_board_feasible': all(row[-1] >= 0 for row in ranks)}
        rounds += 1
        for p, b in changes:
            ranks[p][b] = rounds


def replay(shape, budget, shots):
    """Direct tuple/set physical replay, independent of ideal transition tables."""
    vertices = set(product(*(range(n) for n in shape)))
    belief = vertices.copy()
    for t, shot in enumerate(shots):
        assert len(shot) == len(set(shot)) <= budget
        assert set(shot) <= vertices
        survivors = belief-set(shot)
        following = set()
        for v in survivors:
            for i, n in enumerate(shape):
                for delta in (-1, 1):
                    w = list(v)
                    w[i] += delta
                    if 0 <= w[i] < n:
                        following.add(tuple(w))
        belief = following
        assert bool(belief) == (t < len(shots)-1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--shape', default='3,3,3')
    parser.add_argument('--budgets', default='1:28')
    parser.add_argument('--output', default='research/three-cube-optimal-times.json')
    parser.add_argument('--odd-paths', action='store_true')
    args = parser.parse_args()
    shape = tuple(map(int, args.shape.split(',')))
    begin = monotonic()
    data = prepare(shape, odd_paths=args.odd_paths)
    print('canonical_counts', list(map(len, data['ideals'])), flush=True)
    if ':' in args.budgets:
        lo, hi = map(int, args.budgets.split(':'))
        budgets = range(lo, hi)
    else:
        budgets = list(map(int, args.budgets.split(',')))
    rows = []
    for m in budgets:
        row = {'budget': m, **solve(data, m)}
        rows.append(row)
        print({k: row[k] for k in ('budget', 'minimum_turns', 'discovered_states')}, flush=True)
    receipt = {'shape': shape, 'canonical_counts': list(map(len, data['ideals'])),
               'includes_odd_path_compressions': args.odd_paths,
               'exactness_basis': 'Equal-coordinate strategy-compression theorem, independently reviewed ordinary proof; not yet a Lean proof.',
               'seconds': round(monotonic()-begin, 3), 'results': rows}
    path = Path(__file__).resolve().parents[1]/args.output
    path.write_text(json.dumps(receipt, indent=2)+'\n')


if __name__ == '__main__':
    main()

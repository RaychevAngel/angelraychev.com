#!/usr/bin/env python3
"""Exact bounded tests of geometric normal forms; no general compression assumed.

The all-state solver applies the subset maximum transform to Bellman's exact
recurrence. It avoids enumerating the 3**|V| pairs (belief, survivor).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time


def board(height, width):
    coords = [(r, c) for r in range(height) for c in range(width)]
    neighbors = [sum(1 << j for j, (u, v) in enumerate(coords)
                     if abs(r-u)+abs(c-v) == 1) for r, c in coords]
    count = 1 << len(coords)
    neighborhoods = [0] * count
    sizes = [0] * count
    for a in range(1, count):
        bit = a & -a
        neighborhoods[a] = neighborhoods[a ^ bit] | neighbors[bit.bit_length()-1]
        sizes[a] = sizes[a ^ bit] + 1
    return coords, neighborhoods, sizes


def interval(mask, indices):
    positions = [j for j, v in enumerate(indices) if mask >> v & 1]
    return not positions or positions[-1]-positions[0]+1 == len(positions)


def geometric_families(height, width, coords):
    count = 1 << len(coords)
    rows = [[i for i, (r, c) in enumerate(coords) if r == row and (r+c)%2 == color]
            for color in range(2) for row in range(height)]
    cols = [[i for i, (r, c) in enumerate(coords) if c == col and (r+c)%2 == color]
            for color in range(2) for col in range(width)]
    ideals = []
    for color in range(2):
        variants = []
        for sr, sc in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
            variants.append([(i, sum(1 << j for j, (u, v) in enumerate(coords)
                                      if (u+v)%2 == color and sr*u <= sr*r and sc*v <= sc*c))
                             for i, (r, c) in enumerate(coords) if (r+c)%2 == color])
        ideals.append(variants)
    out = {name: bytearray(count) for name in
           ('row_intervals', 'orthoconvex', 'row_frontiers', 'axis_frontiers', 'corner_ideals')}
    for mask in range(count):
        row_ok = all(interval(mask, row) for row in rows)
        col_ok = all(interval(mask, col) for col in cols)
        out['row_intervals'][mask] = row_ok
        out['orthoconvex'][mask] = row_ok and col_ok
        frontier = []
        for color in range(2):
            directions = []
            for lines in (rows[color*height:(color+1)*height], cols[color*width:(color+1)*width]):
                for reverse in (False, True):
                    good = True
                    for line in lines:
                        ordered = list(reversed(line)) if reverse else line
                        found_gap = False
                        for i in ordered:
                            if mask >> i & 1:
                                if found_gap:
                                    good = False
                                    break
                            else:
                                found_gap = True
                        if not good:
                            break
                    directions.append(good)
            frontier.append(directions)
        out['row_frontiers'][mask] = all(any(directions[:2]) for directions in frontier)
        out['axis_frontiers'][mask] = all(any(directions) for directions in frontier)
        out['corner_ideals'][mask] = all(
            any(all(not (mask >> i & 1) or mask & lower == lower for i, lower in variant)
                for variant in ideals[color]) for color in range(2))
    return out


def solve_all(neighborhoods, sizes, m, family=None, restrict_survivors=True):
    """Return ALL exact remaining times; -1 means no finite strategy.

    If family is supplied both before-probe beliefs and, optionally,
    after-probe survivor sets must belong to it. Returned times are then
    exact for this restricted game and upper bounds for the original game.
    """
    started = time.monotonic()
    count = len(sizes)
    n = (count-1).bit_length()
    values = [-1] * count
    values[0] = 0
    witnesses = [-1] * count
    witnesses[0] = 0
    t = 0
    totals = [1]
    while True:
        best = [a if values[neighborhoods[a]] >= 0 and
                (family is None or not restrict_survivors or family[a]) else -1
                for a in range(count)]
        for bit_index in range(n):
            bit = 1 << bit_index
            for base in range(0, count, bit << 1):
                for a in range(base + bit, base + (bit << 1)):
                    other = best[a ^ bit]
                    if other >= 0 and (best[a] < 0 or sizes[other] > sizes[best[a]]):
                        best[a] = other
        t += 1
        changed = 0
        for a, survivor in enumerate(best):
            if values[a] < 0 and (family is None or family[a]) and survivor >= 0 and sizes[a]-sizes[survivor] <= m:
                values[a] = t
                witnesses[a] = survivor
                changed += 1
        if not changed:
            break
        totals.append(totals[-1] + changed)
    return values, witnesses, {'seconds': round(time.monotonic()-started, 4),
                               'winning_by_horizon': totals,
                               'full_board_time': values[-1],
                               'finite_states': sum(v >= 0 for v in values)}


def signature(mask, coords, height):
    return tuple(sum(bool(mask >> i & 1) for i, (r, c) in enumerate(coords)
                     if r == row and (r+c)%2 == color)
                 for color in range(2) for row in range(height))


def mismatch(values, sizes, coords, height):
    first = {}
    for a in sorted(range(len(values)), key=lambda x: (sizes[x], x)):
        key = signature(a, coords, height)
        if key in first and values[first[key]] != values[a]:
            b = first[key]
            return {'signature': key, 'size': sizes[a], 'states':
                    [{'mask': x, 'cells': [coords[i] for i in range(len(coords)) if x >> i & 1],
                      'remaining_time': values[x]} for x in (b, a)]}
        first.setdefault(key, a)
    return None


def schedule(start, values, witnesses, neighborhoods, m):
    result = []
    a = start
    while a:
        r = witnesses[a]
        assert r >= 0 and r & a == r
        shot = a ^ r
        assert shot.bit_count() <= m
        result.append({'before': a, 'shot': shot, 'survivors': r, 'after': neighborhoods[r]})
        after = neighborhoods[r]
        assert values[after] < values[a]
        a = after
    assert len(result) == values[start]
    return result


def run(height, width, budgets, names):
    coords, neighborhoods, sizes = board(height, width)
    families = geometric_families(height, width, coords)
    result = {'shape': [height, width], 'vertices': coords,
              'family_sizes': {k: sum(v) for k, v in families.items()}, 'budgets': []}
    for m in budgets:
        exact, witnesses, stats = solve_all(neighborhoods, sizes, m)
        case = {'m': m, 'unrestricted': stats, 'row_count_counterexample': mismatch(exact, sizes, coords, height),
                'restrictions': {}}
        if exact[-1] >= 0:
            case['unrestricted_schedule'] = schedule(len(sizes)-1, exact, witnesses, neighborhoods, m)
        for name in names:
            family = families[name]
            restricted, witness, stats = solve_all(neighborhoods, sizes, m, family)
            failures = [a for a in range(len(sizes)) if family[a] and exact[a] != restricted[a]]
            stats['canonical_states_with_worse_time'] = len(failures)
            if failures:
                a = min(failures, key=lambda a: (sizes[a], a))
                stats['smallest_counterexample'] = {'mask': a, 'size': sizes[a],
                    'cells': [coords[i] for i in range(len(coords)) if a >> i & 1],
                    'unrestricted_time': exact[a], 'restricted_time': restricted[a]}
            if restricted[-1] >= 0:
                stats['full_board_schedule'] = schedule(len(sizes)-1, restricted, witness, neighborhoods, m)
            case['restrictions'][name] = stats
        result['budgets'].append(case)
        print(height, width, m, 'exact', exact[-1], {k: v['full_board_time'] for k, v in case['restrictions'].items()}, flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--shape', type=int, nargs=2, default=(3, 4))
    parser.add_argument('--budgets', type=int, nargs='+', default=(2, 3))
    parser.add_argument('--families', nargs='+', default=('row_frontiers', 'axis_frontiers', 'corner_ideals', 'orthoconvex'))
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.shape[0]*args.shape[1] > 16:
        parser.error('Bounded experiment only: at most 16 rooms')
    started = time.monotonic()
    data = run(*args.shape, args.budgets, args.families)
    data['total_seconds'] = round(time.monotonic()-started, 4)
    args.output.write_text(json.dumps(data, indent=2)+'\n')

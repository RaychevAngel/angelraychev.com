"""Short bounded pyramidal survivor-envelope bridge on the five-dimensional4-cube."""
from itertools import combinations
from pathlib import Path
from time import process_time
import argparse
import json
import warnings
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix
from even_bridge_feasibility_profiles import prefix_data


def run(source_size=331, target_size=330, parity=0, days=4, budget=89, seconds=2):
    start = process_time()
    vertices, orders, _ = prefix_data((4,) * 5)
    neighborhoods = {}
    for v in vertices:
        neighborhoods[v] = {v[:j] + (v[j] + s,) + v[j + 1:]
                            for j in range(5) for s in (-1, 1) if 0 <= v[j] + s < 4}
    def N(s):
        return set().union(*(neighborhoods[v] for v in s)) if s else set()
    source = set(orders[parity][:source_size])
    target = set(orders[parity ^ (days % 2)][:target_size])
    erosion = {v for v in orders[1 - (parity ^ (days % 2))] if neighborhoods[v] <= target}
    reachable = [source]
    for t in range(1, days):
        reachable.append(N(reachable[-1]))
    domains = [s.copy() for s in reachable]
    domains[-1] &= erosion
    X, Y = [], [{}]
    count = 0
    for domain in domains:
        X.append({v: count + i for i, v in enumerate(sorted(domain))})
        count += len(domain)
    for t in range(1, days):
        Y.append({v: count + i for i, v in enumerate(sorted(reachable[t]))})
        count += len(Y[-1])
    rows, cols, vals, low, high = [], [], [], [], []
    def constraint(terms, lower=-np.inf, upper=0):
        row = len(low)
        for col, value in terms:
            rows.append(row); cols.append(col); vals.append(value)
        low.append(lower); high.append(upper)
    constraint([(i, 1) for i in X[0].values()], source_size - budget, np.inf)
    for t in range(1, days):
        constraint([(i, 1) for i in Y[t].values()], -np.inf, budget)
        for v, before in X[t - 1].items():
            for w in neighborhoods[v]:
                terms = [(before, 1), (Y[t][w], -1)]
                if w in X[t]:
                    terms.append((X[t][w], -1))
                constraint(terms)
    for domain in X:
        for v, i in domain.items():
            for a, b in combinations(range(5), 2):
                for sign in (-1, 1):
                    w = list(v); w[a] += sign; w[b] -= 1
                    if all(0 <= x < 4 for x in w):
                        w = tuple(w)
                        assert w in domain
                        constraint([(i, 1), (domain[w], -1)])
    matrix = coo_matrix((vals, (rows, cols)), shape=(len(low), count)).tocsr()
    # A feasibility objective avoids optimizing an irrelevant total quota.
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        answer = milp(np.zeros(count), integrality=np.ones(count), bounds=Bounds(0, 1),
                      constraints=LinearConstraint(matrix, np.array(low), np.array(high)),
                      options={'time_limit': seconds, 'threads': 1, 'mip_rel_gap': 0.0})
    result = {'source_size': source_size, 'target_size': target_size, 'parity': parity,
              'days': days, 'budget': budget, 'time_limit_seconds': seconds,
              'variables': count, 'constraints': len(low), 'pyramidal': True,
              'status': int(answer.status), 'message': answer.message,
              'CPU_seconds': process_time() - start, 'witness_passed': False}
    if answer.x is not None:
        envelopes = [{v for v, i in row.items() if answer.x[i] > 0.5} for row in X]
        shots = [source - envelopes[0]]
        shots.extend(N(envelopes[t - 1]) - envelopes[t] for t in range(1, days))
        actual = source.copy()
        for shot in shots:
            assert len(shot) <= budget
            actual = N(actual - shot)
        assert actual <= target
        result.update(witness_passed=True, physical_shots=[sorted(s) for s in shots],
                      shot_counts=list(map(len, shots)), final_count=len(actual),
                      final_support=sorted(actual))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=int, default=331)
    parser.add_argument('--target', type=int, default=330)
    parser.add_argument('--parity', type=int, default=0)
    parser.add_argument('--days', type=int, default=4)
    parser.add_argument('--budget', type=int, default=89)
    parser.add_argument('--seconds', type=float, default=2)
    args = parser.parse_args()
    result = run(args.source, args.target, args.parity, args.days, args.budget, args.seconds)
    output = Path(__file__).resolve().parents[1] / f'research/even-bridge-envelope-{args.days}days-p{args.parity}-{args.source}-{args.target}.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('physical_shots', 'final_support')}, indent=2))

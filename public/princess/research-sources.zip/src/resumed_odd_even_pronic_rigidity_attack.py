"""Independent exhaustive physical attack on the all-even pronic equality.

Enumerates every support of the required size on eight bounded boards,
including square, near-square, and odd-width endpoints. No abstract
transition code or capacity formula is used by this checker.
"""
from itertools import combinations
from pathlib import Path
from time import process_time
import json


def run(w,n):
    started=process_time();colors=[[(x,y)for x in range(w)for y in range(n)
                                   if(x+y)%2==p]for p in range(2)]
    ids=[{cell:i for i,cell in enumerate(c)}for c in colors]
    corner_cells={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
    corners=[sum(1<<i for i,c in enumerate(cc)if c in corner_cells)for cc in colors]
    neighborhoods=[]
    for p in range(2):
        neighborhoods.append([sum(1<<ids[1-p][d]for d in((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                                  if d in ids[1-p])for x,y in colors[p]])
    def hood(mask,p):
        out=0
        while mask:
            bit=mask&-mask;mask-=bit;out|=neighborhoods[p][bit.bit_length()-1]
        return out
    results=[]
    for t in range(2,min(w//2,3)+1):
        expected_kappa=0 if t<w//2 or w%2 else 2 if w==n else 1
        for p in range(2):
            q=t*(t-1);checked=matches=0
            expected=[]
            for origin in corner_cells:
                if sum(origin)%2==p:continue
                expected.append(sum(1<<i for i,(x,y)in enumerate(colors[p])
                                    if abs(x-origin[0])+abs(y-origin[1])<=2*t-3))
            for choice in combinations(range(len(colors[p])),q):
                checked+=1;mask=sum(1<<x for x in choice)
                if mask&corners[p]:continue
                first=hood(mask,p)
                if first.bit_count()!=t*t:continue
                matches+=1
                assert mask in expected,(w,n,t,p,mask,'not a triangle')
                assert(first&corners[1-p]).bit_count()==1
                erosion_corners=sum((neighbors&first)==neighbors
                                    for i,neighbors in enumerate(neighborhoods[p])if corners[p]>>i&1)
                assert erosion_corners==0
                assert(hood(first,1-p)&corners[p]).bit_count()==expected_kappa
            results.append({'radius':t,'phase':p,'supports_enumerated':checked,
                            'equality_supports':matches,'second_hood_corners':expected_kappa})
    return {'width':w,'length':n,'checks':results,'cpu_seconds':process_time()-started}


if __name__=='__main__':
    results=[]
    for w,n in((4,4),(4,5),(4,6),(5,6),(6,6),(6,7),(6,8),(7,8)):
        r=run(w,n);results.append(r);print(r,flush=True)
    Path('research/resumed-odd-even-pronic-rigidity-physical-attack.json').write_text(
        json.dumps({'scope':'Exhaustive physical equality-support check on the stated finite boards, radii2 and3 only. Independent of the capacity-model implementation; no unbounded proof inferred.','results':results},indent=2)+'\n')

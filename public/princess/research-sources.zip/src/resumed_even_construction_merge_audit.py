"""Independent finite audit of the guarded exact-target merger lemma."""
from pathlib import Path
import json,time

from resumed_even_construction_formula_profile import build


def check(w,k):
    start=time.monotonic();states,options=build(w,k);h=w*w//2;count=0
    for a in states:
        for b in states:
            if a[0]+b[0]<=h+k:continue
            merged=(a[0]+b[0]-h,max(0,a[1]+b[1]-2))
            assert merged in options
            for aa,p in options[a].items():
                for bb,q in options[b].items():
                    if p+q>k:continue
                    target=(aa[0]+bb[0]-h,max(0,aa[1]+bb[1]-2))
                    assert target in options,(a,b,aa,bb,p,q,'invalid target')
                    count+=1
                    assert options[merged].get(target,k+1)<=p+q,(a,b,aa,bb,p,q)
    return {'w':w,'n':w,'k':k,'guard':'merged source cardinality>k',
            'all_exact_target_edges_pass':True,'edge_pairs_checked':count,
            'seconds':time.monotonic()-start}


if __name__=='__main__':
    rows=[]
    for w,k in ((6,5),(8,6)):
        row=check(w,k);rows.append(row);print(row,flush=True)
    Path('research/resumed-even-construction-merge-independent-audit.json').write_text(json.dumps({'results':rows},indent=2)+'\n')

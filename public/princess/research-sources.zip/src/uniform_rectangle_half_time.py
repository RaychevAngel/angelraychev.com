"""Uniform half-time theorem diagnostics; remaining-bit necessity is conjectural."""
from bisect import bisect_right
from pathlib import Path
from time import process_time
import json
from odd_serial_first_order_attack import profiles
from uniform_rectangle_serial_attack import serial

def capacities(g,m):
    E,M=len(g[0])-1,len(g[1])-1
    I=[[bisect_right(g[p],z)-1 for z in range((M,E)[p]+1)] for p in (0,1)]
    D0=D1=0;trace=[(0,0)];seen={(0,0)}
    while True:
        a,b=I[0][min(M,D1+m)],I[1][min(E,D0+m)]
        if a==E or b==M:return len(trace),(D0,D1),trace
        if (a,b) in seen:return None,(D0,D1),trace
        D0,D1=a,b;trace.append((a,b));seen.add((a,b))

def check_inverse(g):
    E,M=len(g[0])-1,len(g[1])-1
    I=[[bisect_right(g[p],z)-1 for z in range((M,E)[p]+1)] for p in (0,1)]
    pairs=0
    for x in range(M+1):
        for y in range(M-x+1):
            assert I[0][x]+I[1][y]<=I[0][x+y]
            if x>=2:assert I[1][x]+I[0][y]<=I[1][x+y]
            pairs+=1
    return pairs

def main():
    start=process_time();rows=[];pairs=0
    for b in range(1,15):
      for a in (b,b+1,b+3):
        g=profiles(a,b);E,M=len(g[0])-1,len(g[1])-1
        if b<=8:pairs+=check_inverse(g)
        for m in range(b+1,min(b*b+2,M)):
            tau,D,_=capacities(g,m)
            assert tau is not None
            bound=2*tau-1;upper=2*tau
            middle=E+M-sum(D);candidate=upper-int(m>=middle)
            serial_time=serial(g,m)
            assert bound<=serial_time<=upper
            assert serial_time==candidate
            rows.append({'width':2*b+1,'length':2*a+1,'budget':m,'tau':tau,'precentral_capacities':D,'proved_lower':bound,'proved_upper':upper,'central_residual':middle,'serial_time':serial_time})
    out={'scope':'Uniform T in{2tau−1,2tau} has an ordinary proof; this check validates its inverse lemmas and records a sufficient central condition. Necessity of the condition is still conjectural; comparisons here are to physical serial upper times, not a new full DP.','inverse_pairs':pairs,'parameter_pairs':len(rows),'CPU_seconds':process_time()-start,'results':rows}
    Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-half-time.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k!='results'}))
if __name__=='__main__':main()

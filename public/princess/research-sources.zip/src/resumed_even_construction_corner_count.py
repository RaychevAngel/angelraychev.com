"""Corner-count full-start relaxation; finite certificates, no normal form.

The source states are physical pyramids. Their unrestricted interpretation is
only justified here on squares by the existing compression theorem.
"""
from collections import defaultdict,deque
from pathlib import Path
import argparse,json,time

from resumed_even_construction_square_audit import prepare
from resumed_even_construction_prefix import ceilroot,rho


def run(w,k):
    started=time.monotonic();d=prepare(w,w)
    I,S,H=[d[q] for q in ('ideals','sizes','hood')]
    feature=[];groups=[]
    for p in (0,1):
        feature.append([(s,sum((x+y)%2==p and y<=a[x]
                               for x,y in ((0,0),(0,w-1),(w-1,0),(w-1,w-1))))
                        for s,a in zip(S[p],d['heights'][p])])
        group=defaultdict(list)
        for j,s in enumerate(S[p]):group[s].append(j)
        groups.append(group)
    options=defaultdict(dict);physical_edges=0
    for p in (0,1):
        for i,a in enumerate(I[p]):
            for size in range(max(0,S[p][i]-k),S[p][i]+1):
                cost=S[p][i]-size
                for j in groups[p][size]:
                    if I[p][j]&~a:continue
                    before,after=feature[p][i],feature[1-p][H[p][j]]
                    options[before][after]=min(cost,options[before].get(after,k+1))
                    physical_edges+=1
    # The two phases are identified by a graph reflection. Aggregating their
    # transitions can only relax the physical game, independently of that fact.
    h=w*w//2;initial=((h,2),(h,2));queue=deque([(initial,0)])
    parents={initial:None};terminal=None;edges=0
    while queue:
        (a,b),depth=queue.popleft()
        if a[0]+b[0]<=k:terminal=(a,b);break
        for aa,cost in options[a].items():
            for bb,other in options[b].items():
                if cost+other>k:continue
                edges+=1
                nxt=tuple(sorted((aa,bb)))
                if nxt not in parents:
                    parents[nxt]=((a,b),cost,other)
                    queue.append((nxt,depth+1))
    assert terminal is not None
    # Compare each feature's achievable next size with the naive static g.
    g=lambda s:s+min(ceilroot(s),w//2,rho(h-s))
    forbidden=[]
    for a in sorted(options):
        for budget in range(k+1):
            targets=[b for b,cost in options[a].items() if cost<=budget]
            if not targets:continue
            actual=min(b[0] for b in targets);relaxed=g(max(0,a[0]-budget))
            if actual>relaxed:
                forbidden.append({'before':a,'budget':budget,
                                  'scalar_next':relaxed,'corner_next_min':actual,
                                  'possible_minimum_target_corner_counts':sorted({b[1]for b in targets if b[0]==actual})})
    return {'shape':[w,w],'budget':k,'pyramid_counts':list(map(len,I)),
            'corner_count_states':len(options),'physical_edges_checked':physical_edges,
            'joint_lower':depth+1,'joint_abstract_states':len(parents),
            'joint_abstract_edges':edges,'seconds':time.monotonic()-started,
            'options':[{'before':a,'targets':[[b,c]for b,c in sorted(row.items())]}
                       for a,row in sorted(options.items())],
            'scalar_transition_prohibitions':forbidden,
            'scope':'Finite lower relaxation with shape/phase/cohort identity forgotten. Unrestricted lower uses ordinary square compression.'}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--w',type=int,default=8)
    parser.add_argument('--k',type=int,default=5);args=parser.parse_args()
    out=run(args.w,args.k)
    Path(f'research/resumed-even-construction-corner-count-{args.w}x{args.w}-k{args.k}.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k not in('options','scalar_transition_prohibitions')})
    print('full_budget_prohibitions',[r for r in out['scalar_transition_prohibitions']if r['budget']==args.k])

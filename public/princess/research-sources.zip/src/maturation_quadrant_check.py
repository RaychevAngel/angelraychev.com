"""Independent coordinate attacks on punctured-quadrant capacities.

Raw subsets use no diagonal compression or layer-cost formula. Constructed
witnesses are replayed as coordinate sets, including every intermediate size.
The unbounded result still requires the separate ordinary proof.
"""
from pathlib import Path
from time import process_time
import json


def neighbors(S):
    return {(x+dx,y+dy) for x,y in S for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))
            if x+dx>=0 and y+dy>=0}


def capacity(h,s):
    return max(s*(s-1)//2,s*(s-h))


def witness(h,s,k):
    assert 0<=k<=capacity(h,s)
    if not k:return set()
    counts=[]
    if h>=1 and k<=s*(s-1)//2:
        q=0
        while (q+1)*(q+2)//2<=k:q+=1
        counts=list(range(1,q+1));rem=k-q*(q+1)//2
        if rem:counts.append(rem)
    else:
        assert s>=h+1
        L=0
        while (L+1)*(h+L+1)<=k:L+=1
        counts=[h+1+2*i for i in range(L)];rem=k-L*(h+L)
        if rem:counts.append(rem)
    return {(h+2*i-y,y) for i,a in enumerate(counts)for y in range(a)}


def raw_subsets(h,maxsum):
    vertices=[(x,y)for x in range(maxsum+1)for y in range(maxsum+1-x)
              if x+y>=h and (x+y-h)%2==0]
    nv=sorted(neighbors(vertices));index={v:i for i,v in enumerate(nv)}
    masks=[sum(1<<index[v]for v in neighbors({u}))for u in vertices]
    checked=0;maxsize={}
    stack=[(0,0,0)]
    while stack:
        j,k,N=stack.pop()
        if j==len(vertices):
            delta=N.bit_count()-k
            assert delta>=0 and k<=capacity(h,delta),(h,k,delta,N)
            maxsize[delta]=max(maxsize.get(delta,0),k);checked+=1
        else:
            stack.append((j+1,k,N));stack.append((j+1,k+1,N|masks[j]))
    return {'h':h,'maximum_coordinate_sum':maxsum,'support_universe_size':len(vertices),
            'raw_subsets_checked':checked,'largest_size_by_exact_surplus':maxsize}


def main():
    start=process_time();raw=[raw_subsets(h,6 if h%2==0 else 5)for h in range(7)]
    count=0;first_layer=[]
    for h in range(17):
      for s in range(17):
        for k in range(capacity(h,s)+1):
            S=witness(h,s,k);N=neighbors(S)
            assert len(S)==k
            assert all(x>=0 and y>=0 and x+y>=h and (x+y-h)%2==0 for x,y in S)
            assert len(N)-k<=s,(h,s,k,len(N)-k)
            count+=1
        if s==h+1 and s<=16:
            first_layer.append({'h':h,'initial_partial_surpluses':
                [len(neighbors({(h-y,y)for y in range(k)}))-k for k in range(1,h+2)]})
    result={'status':'PASS','scope':'Independent finite-coordinate attacks only; ordinary unbounded audit is separate.',
      'raw_subset_cases':raw,'total_raw_subsets':sum(r['raw_subsets_checked']for r in raw),
      'all_size_coordinate_witnesses_checked':count,'first_full_block_partial_layer_checks':first_layer,
      'CPU_seconds':process_time()-start}
    root=Path(__file__).resolve().parents[1]
    (root/'research/maturation-punctured-quadrant-independent-check.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k not in ('raw_subset_cases','first_full_block_partial_layer_checks')},indent=2))


if __name__=='__main__':main()

"""Attack the bounded-midpoint solver with a separate forward game solver.

Reference neighborhoods are built from coordinates. The reference searches
complete two-count Pareto layers forwards until capture, with neither the
midpoint theorem nor the exceptional-state deletion used by the new solver.
"""
import json
from pathlib import Path
from time import monotonic
from supersession_solo_bands_audit import physical_profiles
from supersession_odd_midpoint_bounded import solve


def minimal(points):
    answer = []
    best = None
    for a,b in sorted(set(points)):
        if best is None or b < best:
            answer.append((a,b))
            best=b
    return answer


def forward_time(g, m):
    front=[(len(g[0])-1,len(g[1])-1)]
    day=1
    while not any(a+b<=m for a,b in front):
        targets=[]
        for a,b in front:
            for p in range(m+1):
                targets.append((g[1][max(0,b-(m-p))],g[0][max(0,a-p)]))
        front=minimal(targets)
        day+=1
        assert day<=10*(len(g[0])+len(g[1]))
    return day


def main():
    started=monotonic()
    cases=[]
    for b in range(1,7):
        w=2*b+1
        for n in (w,w+2,w+8):
            g=physical_profiles(w,n)
            budgets={b+1,b+2,2*b+1,b*b+1,len(g[1])-1}
            for m in sorted(budgets):
                actual=forward_time(g,m)
                result=solve(w,n,m)
                assert result['time']==actual,(w,n,m,actual,result)
                cases.append(dict(width=w,length=n,budget=m,time=actual))
    # These larger comparisons attack the skip independently of the full
    # midpoint reduction; both use the retained recurrence without/with skip.
    skips=[]
    for w,n,m in [(3,3001,2),(7,6001,5),(11,12001,7),(15,12001,12)]:
        fast=solve(w,n,m)
        slow=solve(w,n,m,accelerate=False)
        for key in ('time','tau','central_minimum','precentral_capacities','frontier'):
            assert fast[key]==slow[key],(w,n,m,key)
        assert fast['jumps'],(w,n,m,'no skip exercised')
        skips.append(dict(width=w,length=n,budget=m,time=fast['time'],
                          updates=fast['updates'],reference_updates=slow['updates']))
    receipt=dict(status='passed',forward_physical_cases=cases,skip_comparisons=skips,
                 seconds=monotonic()-started,
                 scope='Independent finite forward-game comparisons use coordinate neighborhoods and retain complete Pareto layers. Larger comparisons isolate acceleration equivalence. Universal correctness is the independently reviewed ordinary proof; no pure-endpoint criterion is assumed.')
    target=Path(__file__).resolve().parents[1]/'research/supersession-odd-acceleration-independent-check.json'
    target.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(status='passed',forward_cases=len(cases),skip_cases=len(skips),seconds=receipt['seconds'])))


if __name__=='__main__':
    main()

"""Build two scoped publications and preserve the immutable combined checkpoint.

This command packages existing mathematics; it neither deploys nor submits it.
"""
from pathlib import Path
import argparse, subprocess, json, hashlib, zipfile, shutil, re, sys
from datetime import datetime, timezone
from publication_paths import SITE
ROOT=Path(__file__).resolve().parents[1];PAPER=ROOT/'paper';PUBLIC=SITE/'public/princess';PUBLIC.mkdir(parents=True,exist_ok=True)
EXT=PUBLIC/'extensions';EXT.mkdir(exist_ok=True);OUTPUT=ROOT/'output/pdf';OUTPUT.mkdir(parents=True,exist_ok=True)
TEX=Path('/Users/angel/Library/TinyTeX/bin/universal-darwin')
p=argparse.ArgumentParser();p.add_argument('--reuse-pdf',action='store_true',help='Require source inputs to match the last packaged copies');args=p.parse_args()
def run(command,cwd=ROOT):
 r=subprocess.run([str(x) for x in command],cwd=cwd,text=True,capture_output=True)
 if r.returncode:raise RuntimeError(r.stdout+'\n'+r.stderr)
 return r.stdout
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def archive(path,files,base,extra=None):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for file in sorted(set(files)):
   if extra and str(file.relative_to(base)) in extra:continue
   z.write(file,file.relative_to(base))
  for name,value in (extra or {}).items():z.writestr(name,value)
def tex_closure(entry):
 found=set()
 def visit(path):
  path=path.resolve()
  if path in found:return
  assert path.is_file(),path;found.add(path)
  source=re.sub(r'(?<!\\)%[^\n]*','',path.read_text())
  for x in re.findall(r'\\(?:input|include)\{([^}]+)\}',source):visit(PAPER/(x if Path(x).suffix else x+'.tex'))
 visit(PAPER/entry)
 figs=set()
 for path in found:
  for x in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}',path.read_text()):
   q=PAPER/x
   if not q.suffix:q=q.with_suffix('.pdf')
   assert q.exists(),q;figs.add(q.resolve())
 return found,figs
scopes=json.loads((ROOT/'publication/lean-scope.json').read_text());manifest=json.loads((ROOT/'publication/artifact-manifest.json').read_text())
texscope=json.loads((ROOT/'publication/manuscript-scope.json').read_text())
manifest['manuscripts']={s:{'entrypoint':texscope[s]['entrypoint'],'sources':texscope[s]['sources']} for s in ('main','extensions')}
manifest['shared_canonical_tex']=texscope['shared_canonical_tex']
(ROOT/'publication/artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt=json.loads((ROOT/'research/lean-verification.json').read_text());assert receipt['all_passed']
byname={Path(r['file']).stem:r for r in receipt['files']};assert set(byname)==set(scopes['modules'])
for name,row in scopes['modules'].items():
 path=ROOT/row['file'];assert digest(path)==byname[name]['sha256'],f'{path}: source changed since recorded compilation'
 actual=[x for x in re.findall(r'^import\s+([\w.]+)',path.read_text(),re.M) if x in byname];assert actual==row['imports']
sets={scope:{n for n,r in scopes['modules'].items() if r['scope'] in kinds} for scope,kinds in [('main',('main','shared')),('extensions',('parked','shared'))]}
for scope,names in sets.items():
 for n in names:assert set(scopes['modules'][n]['imports'])<=names,(scope,n)
reuse={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'source_hashes_unchanged':True,'local_import_closures_passed':True,'new_compilation':False,'original_checked_at_utc':receipt['checked_at_utc'],'original_receipt_sha256':digest(ROOT/'research/lean-verification.json'),'module_counts':{s:len(n) for s,n in sets.items()},'canonical_module_count':len(byname)}
(ROOT/'research/separation-lean-verification.json').write_text(json.dumps(reuse,indent=2)+'\n')
# The historical combined materials are copied byte-for-byte, never regenerated.
old=ROOT/'archive/2026-09-13-combined';dest=PUBLIC/'archive/2026-09-13-combined';dest.mkdir(parents=True,exist_ok=True)
frozen=json.loads((old/'archive-manifest.json').read_text())
public_history={'princess-searches.pdf','manuscript-source.zip','lean-proofs.zip','research-sources.zip','release.json','lean-verification.json','research-history.md','proofs.html'}
for name,sha in frozen['files'].items():
 assert digest(old/name)==sha,name
 if name in public_history:shutil.copy2(old/name,dest/name)
public_frozen={**frozen,'files':{n:s for n,s in frozen['files'].items() if n in public_history}}
(dest/'archive-manifest.json').write_text(json.dumps(public_frozen,indent=2)+'\n')
if not args.reuse_pdf:
 for script in ('build_paper_figures.py','build_uniform_even_figure.py','build_corner_memory_figure.py','build_near_pronic_figure.py'):run([sys.executable,ROOT/'src'/script])
(PUBLIC/'figures').mkdir(exist_ok=True)
for path in (PAPER/'figures').glob('*.svg'):shutil.copy2(path,PUBLIC/'figures'/path.name)
(PUBLIC/'lean').mkdir(exist_ok=True)
for row in scopes['modules'].values():shutil.copy2(ROOT/row['file'],PUBLIC/'lean'/Path(row['file']).name)
for filename in ('lean-scope.json','artifact-manifest.json'):shutil.copy2(ROOT/'publication'/filename,PUBLIC/filename)
for source,target in [('CLASSIFICATION_SCOPE.md','scope.md'),('RECTANGLE_COVERAGE.md','rectangle-coverage.md'),('RECTANGLE_GAPS.md','rectangle-gaps.md')]:
 for candidate in (ROOT/source,ROOT/'research'/source):
  if candidate.exists():shutil.copy2(candidate,PUBLIC/target);break
for candidate in (ROOT/'extensions/HANDOFF.md',ROOT/'parked/HANDOFF.md',ROOT/'EXTENSIONS_HANDOFF.md'):
 if candidate.exists():shutil.copy2(candidate,EXT/'handoff.md');break
shutil.copy2(ROOT/'FORMAL_ARTIFACT.md',PUBLIC/'formal-artifact.md');shutil.copy2(ROOT/'FORMAL_ARTIFACT.md',EXT/'formal-artifact.md')
shutil.copy2(ROOT/'RESEARCH_HISTORY.md',PUBLIC/'research-history.md');shutil.copy2(PAPER/'references.bib',PUBLIC/'references.bib')
for name in ('separation-lean-verification.json',):shutil.copy2(ROOT/'research'/name,PUBLIC/name)
configs={'main':{'entry':'main.tex','root':PUBLIC,'pdf':'princess-searches.pdf','source':'manuscript-source.zip','lean':'lean-proofs.zip','research':'research-sources.zip','kinds':{'main','shared'}},'extensions':{'entry':'extensions.tex','root':EXT,'pdf':'princess-extensions.pdf','source':'extensions-source.zip','lean':'extensions-lean-proofs.zip','research':'extensions-research-sources.zip','kinds':{'parked','shared'}}}
releases={};closures={};research_packages={}
from pypdf import PdfReader
for scope,cfg in configs.items():
 stem=Path(cfg['entry']).stem;out=cfg['root'];pdf=OUTPUT/cfg['pdf'];texts,figs=tex_closure(cfg['entry']);sources=texts|figs|{PAPER/'references.bib'}
 if scope=='extensions':sources.add(PAPER/'main.aux')
 if args.reuse_pdf:
  previous=json.loads((out/'release.json').read_text());assert digest(pdf)==previous['files'][pdf.name]['sha256']
  with zipfile.ZipFile(out/cfg['source']) as z:
   for path in sources:assert z.read(str(path.relative_to(PAPER)))==path.read_bytes(),f'{path} changed after PDF build'
 else:
  for command in [(TEX/'pdflatex','-interaction=nonstopmode','-halt-on-error',cfg['entry']),(TEX/'bibtex',stem),(TEX/'pdflatex','-interaction=nonstopmode','-halt-on-error',cfg['entry']),(TEX/'pdflatex','-interaction=nonstopmode','-halt-on-error',cfg['entry'])]:run(command,PAPER)
  log=(PAPER/f'{stem}.log').read_text();assert not re.search(r'Overfull|undefined references|undefined citations|Citation .* undefined|Reference .* undefined',log),log[-6000:]
  shutil.copy2(PAPER/f'{stem}.pdf',pdf)
 sources.add(PAPER/f'{stem}.bbl');shutil.copy2(pdf,out/pdf.name)
 scoped=dict(receipt);scoped['files']=[row for row in receipt['files'] if Path(row['file']).stem in sets[scope]];scoped['original_full_check_seconds']=receipt['seconds'];scoped['seconds']=sum(row['seconds'] for row in scoped['files']);scoped['scope']='Filtered source-specific historical compilation receipt. No new compile was run during scope separation. See lean/README.md and publication/lean-scope.json.';scoped['derived_from_full_receipt_sha256']=reuse['original_receipt_sha256'];scoped['scope_separation_checked_at_utc']=reuse['checked_at_utc'];scoped['new_compilation']=False
 scopedtext=json.dumps(scoped,indent=2)+'\n';(out/'lean-verification.json').write_text(scopedtext)
 notes={ROOT/n for n,r in manifest['files'].items() if r['scope'] in cfg['kinds'] and (ROOT/n).is_file()}
 formal={ROOT/scopes['modules'][n]['file'] for n in sets[scope]}|{ROOT/'lean/README.md',ROOT/'lean/lean-toolchain',ROOT/'src/check_lean.py',ROOT/'FORMAL_ARTIFACT.md',ROOT/'publication/lean-scope.json',ROOT/'research/separation-lean-verification.json'}
 formal|={path for path in notes if path.parent==ROOT/'research' and ('semantic-review' in path.name or 'independent-review' in path.name or path.name=='maturation-formal-status.md')}
 extra={'research/lean-verification.json':scopedtext,'research/lean-verification-full.json':json.dumps(receipt,indent=2)+'\n'}
 archive(out/cfg['lean'],formal,ROOT,extra)
 guide=(ROOT/'FORMAL_ARTIFACT.md').read_text()+f'\nThis manuscript entry point is `{cfg["entry"]}`.\n'
 if scope=='extensions':guide+='The included main.aux is a frozen cross-document reference index. It supplies theorem numbers from the separately available rectangle manuscript; it is not a second TeX entry point.\n'
 archive(out/cfg['source'],sources,PAPER,{'anc/FORMAL_ARTIFACT.md':guide})
 research_packages[scope]=(notes|formal|sources,extra)
 closures[scope]={'entrypoint':cfg['entry'],'tex_sources':sorted(str(x.relative_to(ROOT)) for x in texts),'figures':sorted(str(x.relative_to(ROOT)) for x in figs),'lean_modules':sorted(sets[scope])}
 names=[cfg[k] for k in ('pdf','source','lean','research')]
 release={'prepared_at_utc':datetime.now(timezone.utc).isoformat(),'status':'Active rectangle checkpoint; explicit value-and-strategy classification remains open; not submitted to arXiv.' if scope=='main' else 'Parked companion; independent extensions are not completion requirements for the rectangle project.','scope':scope,'pages':len(PdfReader(pdf).pages),'figures':len(figs),'lean_modules':len(sets[scope]),'lean_evidence':'Unchanged source hashes and import closure checked against the existing compilation receipt; no new Lean compilation.','lean_original_checked_at_utc':receipt['checked_at_utc'],'lean_check_seconds':scoped['seconds'],'files':{name:{'sha256':digest(out/name),'bytes':(out/name).stat().st_size} for name in names if (out/name).exists()}}
 (out/'release.json').write_text(json.dumps(release,indent=2)+'\n');releases[scope]=release
# Existing originals remain at their established URLs.
originals=Path('/Users/angel/Downloads/drive-download-20260912T014242Z-1-001')
for original,name in [('Optimal_Strategies_for_Finding_a_Princess_in_a_Linear_Graph_Student_Conference_2020.pdf','raychev-rusev-2020-student.pdf'),('Optimal_Strategies_for_Finding_a_Princess_in_a_Linear_Table_Spring_Conference_2020.pdf','raychev-2020-spring.pdf')]:
 if (originals/original).is_file():shutil.copy2(originals/original,PUBLIC/name)
run([sys.executable,ROOT/'src/build_proof_pages.py'])
run([sys.executable,ROOT/'src/build_scope_pages.py'])
shutil.copy2(ROOT/'publication/proof-anchor-migration.json',PUBLIC/'proof-anchor-migration.json')
(ROOT/'publication/package-closures.json').write_text(json.dumps(closures,indent=2)+'\n')
# Research archives are assembled after both PDFs and the cross-document map exist.
for scope,cfg in configs.items():
 files,extra=research_packages[scope]
 files|={ROOT/n for n,r in manifest['files'].items() if r['scope'] in cfg['kinds'] and (ROOT/n).is_file()}
 archive(cfg['root']/cfg['research'],files,ROOT,extra)
 name=cfg['research'];releases[scope]['files'][name]={'sha256':digest(cfg['root']/name),'bytes':(cfg['root']/name).stat().st_size}
 (cfg['root']/'release.json').write_text(json.dumps(releases[scope],indent=2)+'\n')
(ROOT/'research/publication-build.json').write_text(json.dumps({'publications':releases,'lean_evidence':reuse},indent=2)+'\n')
# Every served file has an explicit role; canonical shared URLs are retained.
served={}
mainfig={Path(n).stem for n in closures['main']['figures']};extfig={Path(n).stem for n in closures['extensions']['figures']}
for path in sorted(PUBLIC.rglob('*')):
 if not path.is_file():continue
 rel=str(path.relative_to(PUBLIC))
 if rel.startswith('archive/'):role='historical'
 elif rel.startswith('extensions/'):role='parked'
 elif rel.startswith('lean/') and path.stem in scopes['modules']:role=scopes['modules'][path.stem]['scope']
 elif rel.startswith('figures/'):role='shared' if path.stem in mainfig&extfig else 'main' if path.stem in mainfig else 'parked'
 else:role='main' if rel in set(configs['main'][k] for k in ('pdf','source','lean','research')) or rel in {'release.json','lean-verification.json','scope.md','rectangle-coverage.md','rectangle-gaps.md'} else 'shared'
 served['/princess/'+rel]={'scope':role,'bytes':path.stat().st_size}
(PUBLIC/'served-assets.json').write_text(json.dumps({'policy':'All current and historical served assets are classified; canonical Lean and figure namespaces are shared.','assets':served},indent=2)+'\n')
print(json.dumps({s:{k:r[k] for k in ('pages','figures','lean_modules','status')} for s,r in releases.items()},indent=2))

"""Build and package a reviewed research checkpoint; does not deploy or submit."""
from pathlib import Path
import subprocess, json, hashlib, zipfile, shutil, re, sys
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
PAPER=ROOT/'paper'; SITE=ROOT.parent/'polyominoes/website'
PUBLIC=SITE/'public/princess';PUBLIC.mkdir(parents=True,exist_ok=True)
shutil.copy2(ROOT/'src/odd_box_search.mjs',SITE/'src/lib/odd-box-search.js')
OUTPUT=ROOT/'output/pdf';OUTPUT.mkdir(parents=True,exist_ok=True)
TEX=Path('/Users/angel/Library/TinyTeX/bin/universal-darwin')

def run(args,cwd=ROOT):
    p=subprocess.run([str(x) for x in args],cwd=cwd,text=True,capture_output=True)
    if p.returncode:raise RuntimeError(p.stdout+'\n'+p.stderr)
    return p.stdout

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

run([sys.executable,ROOT/'src/build_paper_figures.py'])
for cmd in [[TEX/'pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],
            [TEX/'bibtex','main'],
            [TEX/'pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],
            [TEX/'pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex']]:run(cmd,PAPER)
log=(PAPER/'main.log').read_text()
assert not re.search(r'Overfull|undefined references|undefined citations|Citation .* undefined|Reference .* undefined',log),log
pdf=OUTPUT/'princess-searches.pdf';shutil.copy2(PAPER/'main.pdf',pdf)
shutil.copy2(pdf,PUBLIC/pdf.name)
(PUBLIC/'figures').mkdir(exist_ok=True)
for p in (PAPER/'figures').glob('*.svg'):shutil.copy2(p,PUBLIC/'figures'/p.name)

receipt=json.loads((ROOT/'research/lean-verification.json').read_text())
assert receipt['all_passed']
leanfiles=[ROOT/r['file'] for r in receipt['files']]
for r,p in zip(receipt['files'],leanfiles):assert digest(p)==r['sha256'],str(p)+' changed after verification'
guide='''# Princess searches: formal artifact

This checkpoint uses Lean 4.33.1 and Std. The source-specific verification
receipt gives the exact files and their SHA-256 hashes. The final physical
classifications cover all paths, all two-row grids, and every budget on the
3×3×3 box. The ordinary proofs of the other manuscript results are not
presented as complete Lean proofs.

Download `lean-proofs.zip`, extract it, and run
`python3 src/check_lean.py --lean /path/to/lean` from its root. Read
`lean/README.md` for the exact theorem map and partial proof boundaries.
The checker uses one compiler worker and no additional packages.

`release.json` gives archive and PDF checksums for this checkpoint.
`research/lean-verification.json` contains the compiler output and per-source
hashes. Finite kernel-checked certificates do not trust their generating search.

Companion: https://angelraychev.com/princess/
Paper: https://angelraychev.com/princess/paper/
Proofs: https://angelraychev.com/princess/proofs/
Lean: https://angelraychev.com/princess/lean/
'''
(ROOT/'FORMAL_ARTIFACT.md').write_text(guide)
shutil.copy2(ROOT/'FORMAL_ARTIFACT.md',PUBLIC/'formal-artifact.md')
shutil.copy2(ROOT/'research/lean-verification.json',PUBLIC/'lean-verification.json')
shutil.copy2(ROOT/'RESEARCH_HISTORY.md',PUBLIC/'research-history.md')
shutil.copy2(PAPER/'references.bib',PUBLIC/'references.bib')
(PUBLIC/'lean').mkdir(exist_ok=True)
for p in leanfiles:shutil.copy2(p,PUBLIC/'lean'/p.name)

formal=leanfiles+[ROOT/'lean/README.md',ROOT/'lean/lean-toolchain',ROOT/'src/check_lean.py',
    ROOT/'research/lean-verification.json',ROOT/'FORMAL_ARTIFACT.md',ROOT/'RESEARCH_HISTORY.md']
for name in ['path-matching-rank-proof.md','ladder-game-independent-review.md','three-cube-time-independent-review.md']:
    formal.append(ROOT/'research'/name)
def archive(path,files,base):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(set(files)):z.write(p,p.relative_to(base))
archive(PUBLIC/'lean-proofs.zip',formal,ROOT)

# The arXiv source package contains only TeX inputs, figures and an artifact guide.
# Full mathematical code/certificates are supplied as a separate research archive.
sourcefiles=[PAPER/'main.tex',PAPER/'main.bbl',PAPER/'references.bib']+list((PAPER/'sections').glob('*.tex'))+list((PAPER/'figures').glob('*.pdf'))
anc=PAPER/'anc';anc.mkdir(exist_ok=True)
(anc/'FORMAL_ARTIFACT.md').write_text(guide+'\nThe complete mathematical source and finite certificates are available as\nhttps://angelraychev.com/princess/research-sources.zip .\n')
sourcefiles.append(anc/'FORMAL_ARTIFACT.md')
archive(PUBLIC/'manuscript-source.zip',sourcefiles,PAPER)

# Curate mathematical material; retain private intake and authorship discussions locally.
prefixes=('path-','ladder-','three-','four-','five-','odd-','affine-','boxes-with-',
          'cylinder-','nested-','corner-','serial-','grid-','frontier-','pyramidal-',
          'prism-','closed-grid-','cubic-','trap-recurrence-','square-strategy-')
mathnotes=[p for p in (ROOT/'research').iterdir() if p.is_file() and p.suffix in ('.md','.json') and p.name.startswith(prefixes)]
researchfiles=formal+mathnotes+list((ROOT/'src').glob('*.py'))+[ROOT/'RESEARCH_HISTORY.md']
researchfiles+=list((ROOT/'src').glob('*.mjs'))
researchfiles+=sourcefiles
archive(PUBLIC/'research-sources.zip',researchfiles,ROOT)

originals=Path('/Users/angel/Downloads/drive-download-20260912T014242Z-1-001')
for original,name in [('Optimal_Strategies_for_Finding_a_Princess_in_a_Linear_Graph_Student_Conference_2020.pdf','raychev-rusev-2020-student.pdf'),
                      ('Optimal_Strategies_for_Finding_a_Princess_in_a_Linear_Table_Spring_Conference_2020.pdf','raychev-2020-spring.pdf')]:
    p=originals/original
    if p.is_file():shutil.copy2(p,PUBLIC/name)

run([sys.executable,ROOT/'src/build_proof_pages.py'])
from pypdf import PdfReader
count=len(PdfReader(pdf).pages)
names=['princess-searches.pdf','manuscript-source.zip','lean-proofs.zip','research-sources.zip']
release={'prepared_at_utc':datetime.now(timezone.utc).isoformat(),
         'status':'Research checkpoint; not submitted to arXiv.',
         'pages':count,'figures':len(list((PAPER/'figures').glob('*.pdf'))),
         'lean_modules':len(leanfiles),'lean_check_seconds':receipt['seconds'],
         'files':{name:{'sha256':digest(PUBLIC/name),'bytes':(PUBLIC/name).stat().st_size} for name in names}}
(PUBLIC/'release.json').write_text(json.dumps(release,indent=2)+'\n')
(ROOT/'research/publication-build.json').write_text(json.dumps(release,indent=2)+'\n')
print(json.dumps(release,indent=2))

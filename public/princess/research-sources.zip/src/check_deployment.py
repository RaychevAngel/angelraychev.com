"""Verify both scoped publications and the historical archive against the build."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import argparse,hashlib,json,re,ssl,subprocess,urllib.request
from publication_paths import SITE
ROOT=Path(__file__).resolve().parents[1];DIST=SITE/'dist'
p=argparse.ArgumentParser();p.add_argument('--commit',required=True);p.add_argument('--workflow-id',required=True);args=p.parse_args()
context=ssl.create_default_context(cafile='/etc/ssl/cert.pem' if Path('/etc/ssl/cert.pem').exists() else None)
run=json.loads(subprocess.check_output(['gh','run','view',args.workflow_id,'--repo','RaychevAngel/angelraychev.com','--json','status,conclusion,headSha,url'],text=True));assert run['headSha']==args.commit;assert run['status']=='completed' and run['conclusion']=='success',run
pages=sorted(str(x.relative_to(DIST)) for x in (DIST/'princess').rglob('index.html'))
files={'princess/release.json','princess/lean-scope.json','princess/artifact-manifest.json','princess/served-assets.json','princess/lean-verification.json','princess/separation-lean-verification.json','princess/proof-anchor-migration.json','princess/extensions/release.json','princess/extensions/lean-verification.json'}
inventory=json.loads((DIST/'princess/served-assets.json').read_text())['assets']
files|={route.lstrip('/') for route in inventory}
for prefix in ('princess','princess/extensions'):
 release=json.loads((DIST/prefix/'release.json').read_text());files|={prefix+'/'+n for n in release['files']}
for filename in ('scope.md','rectangle-coverage.md','rectangle-gaps.md','extensions/handoff.md'):
 if (DIST/'princess'/filename).exists():files.add('princess/'+filename)
# Check every module, every figure and every historical public download.
files|={str(x.relative_to(DIST)) for directory in ('princess/lean','princess/figures','princess/archive/2026-09-13-combined') for x in (DIST/directory).rglob('*') if x.is_file()}
for page in pages:files|={x.lstrip('/') for x in re.findall(r'["\'](/_astro/[^"\']+)["\']',(DIST/page).read_text())}
def check(path):
 route=path[:-10] if path.endswith('index.html') else path;url='https://angelraychev.com/'+route
 request=urllib.request.Request(url,headers={'Cache-Control':'no-cache'})
 with urllib.request.urlopen(request,timeout=40,context=context) as response:data=response.read();status=response.status
 expected=(DIST/path).read_bytes();assert status==200 and data==expected,(url,status,len(data),len(expected))
 return path,{'url':url,'http_success':True,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'matches_checked_local_artifact':True}
with ThreadPoolExecutor(max_workers=4) as pool:checks=dict(pool.map(check,sorted(set(pages)|files)))
receipt={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'website_commit':args.commit,'workflow':run['url'],'workflow_conclusion':run['conclusion'],'live_readback_passed':True,'checks':checks,'canonical_routes_verified':[checks[p]['url'] for p in pages]}
(ROOT/'research/deployment-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'live_readback_passed':True,'files_checked':len(checks),'website_commit':args.commit,'workflow':run['url']},indent=2))

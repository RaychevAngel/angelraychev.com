"""Verify the deployed release against the locally checked static build."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import ssl
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
from publication_paths import SITE
DIST = SITE / 'dist'
parser = argparse.ArgumentParser()
parser.add_argument('--commit', required=True)
parser.add_argument('--workflow-id', required=True)
args = parser.parse_args()
context = ssl.create_default_context(cafile='/etc/ssl/cert.pem' if Path('/etc/ssl/cert.pem').exists() else None)
run = json.loads(subprocess.check_output([
    'gh', 'run', 'view', args.workflow_id,
    '--repo', 'RaychevAngel/angelraychev.com',
    '--json', 'status,conclusion,headSha,url'], text=True))
assert run['headSha'] == args.commit, run
assert run['status'] == 'completed' and run['conclusion'] == 'success', run
pages = ['princess/index.html', 'princess/proofs/index.html',
         'princess/lean/index.html', 'princess/paper/index.html']
files = ['princess/release.json', 'princess/princess-searches.pdf',
         'princess/manuscript-source.zip', 'princess/lean-proofs.zip',
         'princess/research-sources.zip', 'princess/lean-verification.json',
         'princess/lean/FourCubeClassification.lean',
         'princess/lean/RootConvolution.lean',
         'princess/lean/ProbeLocalization.lean']
files += ['princess/lean/'+name+'.lean' for name in
          ['FastestAncestry','ClippedPyramidErosion','ConvexCapacityConvolution']]
files += [str(p.relative_to(DIST)) for p in (DIST/'princess/figures').glob('*.svg')]
assets = set()
for page in pages:
    assets.update(re.findall(r'["\'](/_astro/[^"\']+)["\']', (DIST/page).read_text()))
files += sorted(a.lstrip('/') for a in assets)

def check(path):
    route = path[:-10] if path.endswith('index.html') else path
    url = 'https://angelraychev.com/' + route
    request = urllib.request.Request(url, headers={'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(request, timeout=40, context=context) as response:
        data = response.read()
        status = response.status
    expected = (DIST/path).read_bytes()
    assert status == 200 and data == expected, (url, status, len(data), len(expected))
    return path, {'url': url, 'http_success': True, 'bytes': len(data),
                  'sha256': hashlib.sha256(data).hexdigest(),
                  'matches_checked_local_artifact': True}

with ThreadPoolExecutor(max_workers=4) as pool:
    checks = dict(pool.map(check, pages + files))
receipt = {'checked_at_utc': datetime.now(timezone.utc).isoformat(),
           'website_commit': args.commit, 'workflow': run['url'],
           'workflow_conclusion': run['conclusion'], 'live_readback_passed': True,
           'checks': checks, 'canonical_routes_verified': [checks[p]['url'] for p in pages]}
(ROOT/'research/deployment-verification.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'live_readback_passed': True, 'files_checked': len(checks),
                  'website_commit': args.commit, 'workflow': run['url']}, indent=2))

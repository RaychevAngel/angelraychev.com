"""Finite exact controls for abstract monotone surjective integer maps."""
from itertools import product
from pathlib import Path
import json,time


def make_map(drops):
    return lambda n:n-sum(i<=n for i in drops)


def inverse(h,k):
    z=k
    while h(z)<k:z+=1
    return z


def reverse_schedule(h,m,p,k):
    costs=[];seen=set();initial=(p,k)
    while k:
        if (p,k)in seen:return None
        seen.add((p,k));z=inverse(h[p],k)
        costs.append(min(m,z));k=max(z-m,0);p=(p-1)%len(h)
        if len(costs)>100:return None
    return {'cost':sum(costs),'quotas':list(reversed(costs)),
            'start_phase':p,'end_phase':initial[0]}


def check(h,m,K=10,initial=None):
    candidates={(p,k):reverse_schedule(h,m,p,k)for p in range(len(h))for k in range(K+1)}
    horizon=max((len(v['quotas'])for v in candidates.values()if v),default=0)+3
    # All initial zero phases. The phase of h used by the next step is p+1.
    states={(p,0):0 for p in range(len(h))if initial is None or p==initial};checks=0
    for t in range(horizon+1):
        for (p,k),v in candidates.items():
            true=min((cost for(pp,n),cost in states.items()if pp==p and n>=k),default=None)
            want=v['cost']if v and v['cost']<=m*t else None
            if initial is not None and p!=(initial+t)%len(h):want=None
            assert true==want,(m,p,k,t,true,want)
            checks+=1
        ns={}
        for (p,n),cost in states.items():
          for q in range(m+1):
            pp=(p+1)%len(h);z=h[pp](n+q)
            ns[pp,z]=min(ns.get((pp,z),10**9),cost+q)
        states=ns
    return checks


def main():
    start=time.process_time();choices=[(),(1,),(2,),(1,2),(1,3),(2,4),(1,2,3)]
    checks=0;models=0
    for cycle in(1,2,3):
      # Varied small models, not a broad parameter survey.
      rows=list(product(range(len(choices)),repeat=cycle))
      if cycle==3:rows=rows[::11]
      for row in rows:
        h=[make_map(choices[i])for i in row]
        for m in(1,2,3):
            checks+=check(h,m);models+=1
    # A valid cyclic model whose reverse threshold increases on one phase.
    nonmonotone=[lambda z:max(z-3,0),lambda z:z]
    checks+=check(nonmonotone,2);models+=1
    fixed_phase_checks=sum(check(nonmonotone,2,initial=p)for p in range(2))
    fixed_phase_checks+=sum(check([make_map((1,)),make_map((2,4)),make_map(())],2,initial=p)for p in range(3))
    ex=reverse_schedule(nonmonotone,2,0,1)
    assert ex['cost']==4 and ex['quotas']==[2,2]
    result={'status':'PASS','scope':'Finite exact control checks for abstract maps; ordinary proof is separate.',
      'models':models,'phase_target_horizon_checks':checks,'fixed_initial_phase_checks':fixed_phase_checks,
      'reverse_step_can_increase_example':{'maps':['max(z-3,0)','z'],'budget':2,'target_phase':0,'target':1,
        'reverse_targets':[1,2,0],'optimal_cost':4,'optimal_quotas':[2,2]},
      'termination_is_needed_example':{'map':'max(z-2,0)','budget':2,'positive_targets':'infeasible despite L(k)=k+m'},
      'CPU_seconds':time.process_time()-start}
    root=Path(__file__).resolve().parents[1]
    (root/'research/maturation-cyclic-ammunition-independent-check.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

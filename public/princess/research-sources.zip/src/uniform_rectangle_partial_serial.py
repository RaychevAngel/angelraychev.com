"""Exact finite test of serial play from arbitrary canonical partial states."""
from collections import deque
from pathlib import Path
import json,time
from odd_serial_first_order_attack import profiles

def restricted_serial(g,m,a,b,p=0):
    best=None
    for first in (0,1):
        x,y=(a,b)if first==0 else(b,a);z=first^p;t=0;seen=set()
        while(x,y,z)not in seen:
            if x+y<=m:
                best=t+1 if best is None else min(best,t+1);break
            seen.add((x,y,z));q=min(m,x)
            x,y=g[z][x-q],g[1-z][max(0,y-(m-q))];z^=1;t+=1
    return best

def all_times(g,m):
    E,M=len(g[0])-1,len(g[1])-1
    states=[(a,b)for a in range(E+1)for b in range(M+1)]
    rev={s:[]for s in states};dist={};Q=deque()
    for a,b in states:
        if a+b<=m:dist[a,b]=1;Q.append((a,b));continue
        for p in range(m+1):
            nxt=(g[1][max(0,b-m+p)],g[0][max(0,a-p)])
            rev[nxt].append((a,b))
    while Q:
        s=Q.popleft()
        for prev in rev[s]:
            if prev not in dist:dist[prev]=dist[s]+1;Q.append(prev)
    return dist

def main():
    start=time.process_time();checked=0;fail=[]
    for b in range(1,5):
      for a in range(b,b+3):
        g=profiles(a,b)
        for m in range(b+1,min(len(g[1]),b+8)):
          dist=all_times(g,m)
          for(a0,b0),time0 in dist.items():
            want=restricted_serial(g,m,a0,b0);checked+=1
            if want!=time0:
              fail.append({'shape':[2*a+1,2*b+1],'m':m,'partial_state':[a0,b0],'exact':time0,'serial':want})
              break
          if fail:break
        if fail:break
      if fail:break
    out={'scope':'Arbitrary partial-state canonical recurrence; genuine odd rectangle profiles.','states_checked':checked,'first_failure':fail,'CPU_seconds':time.process_time()-start}
    Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-partial-serial.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()

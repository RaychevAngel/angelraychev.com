"""Bounded phase/history-aware LP lower certificates for odd-width even rectangles.

Geometry inputs are the accepted static profile and critical-orientation lemma.
Every possible abstract surplus is retained; no static minimizer composition is
assumed. The LP proposes additive charges; exact Fraction checks are mandatory.
Physical prefix searches provide upper bounds only.
"""
from pathlib import Path
from fractions import Fraction
from math import isqrt,ceil
import json,time,argparse
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from nested_grid_time import ordered_profiles,solve as prefix_solve

def root(k):return isqrt(k)+(isqrt(k)**2<k)
def rho(k):
 a=(isqrt(1+4*k)-1)//2
 return a+(a*(a+1)<k)
def pronic(k):
 if k==0:return 0
 a=(1+isqrt(1+4*k))//2
 return a+(a*(a-1)<k)
def transitions(b,n,m,flags=True,enlarged=False):
 w=2*b+1;h=w*n//2;B=b*(b+1)
 critical_start=b*(b-1) if enlarged else b*b
 states=[(k,z) for k in range(h+1) for z in range(3 if flags else 1)
         if z==0 or z==1 and critical_start+b+1<=k<=h-b*b-1 or z==2 and h-b*b<=k<h]
 index={s:i for i,s in enumerate(states)};edges=[]
 for state,i in index.items():
  k,z=state
  for p in range(min(m,k)+1):
   r=k-p
   if r==0:edges.append((i,index[(0,0)],p));continue
   lo=min(root(r),b,rho(h-r))
   if flags and z==1 and r<=b*b:lo=max(lo,min(pronic(r),b+1))
   for s in range(lo,h-r+1):
    middle=critical_start<r<h-B
    if flags and middle and s==b:
     # Flag two's co-large obstruction was proved only for the original
     # strict-middle target, which contains the entire favored endpoint row.
     if z==1 or z==2 and r>b*b:continue
     nz=1
    elif flags and r>=h-B and s<=b and h-r>s*s:nz=2
    else:nz=0
    after=(r+s,nz)
    assert after in index,(b,n,m,state,p,s,after)
    edges.append((i,index[after],p))
 return states,edges

def certificate(b,n,m,flags=True,enlarged=False):
 states,edges=transitions(b,n,m,flags,enlarged);h=(2*b+1)*n//2;offset=len(states);nv=offset+m+1
 rows=[]
 for a,d,p in edges:
  row={a:1}
  row[d]=row.get(d,0)-1;row[offset+p]=row.get(offset+p,0)-1
  rows.append((row,0))
 for p in range(m+1):
  for q in range(m-p+1):
   row={offset+p:1};row[offset+q]=row.get(offset+q,0)+1;rows.append((row,1))
 ii=[];jj=[];vv=[]
 for i,(row,_) in enumerate(rows):
  for j,v in row.items():
   if v:ii.append(i);jj.append(j);vv.append(v)
 mat=coo_matrix((vv,(ii,jj)),shape=(len(rows),nv)).tocsr()
 obj=np.zeros(nv);obj[states.index((h,0))]=-2
 bounds=[(0,None)]*nv;bounds[states.index((0,0))]=(0,0);bounds[offset]=(0,0)
 res=linprog(obj,A_ub=mat,b_ub=np.array([v for _,v in rows]),bounds=bounds,method='highs',options={'threads':1})
 if not res.success:return {'failure':res.message}
 exact=[Fraction(float(v)).limit_denominator(1000000) for v in res.x]
 violations=[i for i,(row,rhs) in enumerate(rows) if sum(exact[j]*v for j,v in row.items())>rhs]
 value=2*exact[states.index((h,0))]
 output={'width':2*b+1,'length':n,'budget':m,'flags':flags,'enlarged_critical_interval':enlarged,'potential_value':str(value),'proved_integer_lower_if_geometry_accepted':ceil(value),'exact_fraction_check_passed':not violations,'violations':violations[:10],'states':len(states),'constraints':len(rows),'charges':[str(v) for v in exact[offset:]],'potentials':{f'{k},{z}':str(exact[i]) for i,(k,z) in enumerate(states)}}
 report,data=ordered_profiles((n,2*b+1))
 if report['nested']:
  upper=prefix_solve(data,m);output['physical_prefix_upper']=upper['minimum_turns'];output['physical_prefix_shots']=upper.get('inspections');output['upper_status']='Attained physical prefix-restricted upper; no optimality assumption.'
 return output

def main():
 p=argparse.ArgumentParser();p.add_argument('--cases',default='3,8,4;3,8,5;3,8,6;3,10,4;4,10,5;4,10,6');p.add_argument('--output',default='research/resumed-odd-even-corner-potentials.json');p.add_argument('--enlarged',action='store_true');args=p.parse_args();start=time.process_time();results=[]
 for triple in args.cases.split(';'):
  b,n,m=map(int,triple.split(','));r=certificate(b,n,m,enlarged=args.enlarged);results.append(r);print({k:v for k,v in r.items() if k not in ('potentials','physical_prefix_shots')},flush=True)
 out={'scope':'Finite exact-rational additive lower certificates from accepted physical necessary conditions; no unbounded theorem or exact unrestricted classifier claimed.','results':results,'cpu_seconds':time.process_time()-start}
 Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()

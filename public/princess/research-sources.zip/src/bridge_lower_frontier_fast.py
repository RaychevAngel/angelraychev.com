"""Exact weighted rows from monotone fixed-target survivor thresholds.

This accelerates the reviewed necessary model, without asserting physical
attainability or interval closure after any history flags are attached.
"""
from bisect import bisect_left
from pathlib import Path
from math import isqrt
import argparse,json,pickle,time
from bridge_lower_frontier_nine import survivor_cap
from bridge_lower_frontier_probe import load_model

def build(b,n,k):
    assert b>=2 and n%2==0 and n>=2*b+1 and k>=0
    started=time.process_time();h=(2*b+1)*n//2
    states=[(a,c,e)for a in range(h+1)for c in range(3)for e in range(3)
            if(a>0 or c==e==0)and a<=h-4+c+e]
    ids={s:i for i,s in enumerate(states)}
    ordinary=len(states);flags={r:ordinary+r-2 for r in range(2,b+1)}
    states.extend((r*r,1,0,4)for r in flags)
    relations={};array_entries=0
    for j in range(3):
        for v in range(3):
            top=h-4+j+v
            suffix=[0]*(top+2)
            for T in range(top,0,-1):suffix[T]=suffix[T+1]|(1<<ids[T,j,v])
            for i in range(v+1):
                for u in range(j+1):
                    caps=[survivor_cap(b,h,T,i,u,j,v,strong_band=True)for T in range(1,top+1)]
                    assert all(x<=y for x,y in zip(caps,caps[1:])),(i,u,j,v)
                    relation=[0]+[suffix[bisect_left(caps,q)+1]for q in range(1,h+1)]
                    # If i=0 and q=r(r-1), original surplus r forces the
                    # outgoing feature (1,0), and flags that exact target.
                    if i==0:
                        for r,extra in flags.items():
                            q=r*(r-1);T=r*r
                            if T>top:continue
                            bit=1<<ids[T,j,v]
                            if relation[q]&bit:
                                relation[q]&=~bit
                                if(j,v)==(1,0):relation[q]|=1<<extra
                    relations[i,u,j,v]=relation;array_entries+=len(relation)
    weighted=[[0]*len(states)for _ in range(k+1)]
    zero=ids[0,0,0]
    for a,source in enumerate(states[:ordinary]):
        size,c,e=source
        for p in range(min(k,size)+1):
            q=size-p
            if q==0:weighted[p][a]=1<<zero;continue
            bits=0
            for i in range(c+1):
                for u in range(e+1):
                    if c-i+e-u>p or q>h-4+i+u:continue
                    for j in range(u,3):
                        for v in range(i,3):
                            if i<max(0,c+v-2):continue
                            bits|=relations[i,u,j,v][q]
            weighted[p][a]=bits
    no_corner=sum(1<<i for i,s in enumerate(states)if s[1]==0)
    for r,extra in flags.items():
        old=ids[r*r,1,0]
        for p in range(k+1):weighted[p][extra]=weighted[p][old]&no_corner
    masks=[0]*len(states)
    for row in weighted:
        for a,bits in enumerate(row):masks[a]|=bits
    _,source_sha,model_sha=load_model(True,True,weighted_cache=True)
    return dict(states=states,masks=masks,weighted=weighted,source_sha256=source_sha,model_sha256=model_sha,build_cpu_seconds=time.process_time()-started,engine='monotone-target-suffixes',array_entries=array_entries)

def run(b,n,k,compare=False,cache=False):
    data=build(b,n,k);row=dict(width=2*b+1,length=n,budget=k,states=len(data['states']),edges=sum(x.bit_count()for x in data['masks']),CPU_seconds=data['build_cpu_seconds'],array_entries=data['array_entries'])
    path=Path(f'.build/bridge-lower-frontier-weighted-{b}-{n}-{k}.pickle')
    if compare:
        with path.open('rb')as f:old=pickle.load(f)
        assert old['states']==data['states']
        assert old['source_sha256']==data['source_sha256']and old['model_sha256']==data['model_sha256']
        checked=0
        for p in range(k+1):
            for a,(x,y)in enumerate(zip(old['weighted'][p],data['weighted'][p])):
                if x!=y:
                    delta=x^y;bit=delta&-delta;d=bit.bit_length()-1
                    raise AssertionError(dict(cost=p,source=data['states'][a],target=data['states'][d],old_has=bool(x&bit),new_has=bool(y&bit)))
                checked+=1
        row.update(all_weighted_rows_equal=True,weighted_rows_checked=checked)
    if cache:
        assert not path.exists(),'Do not overwrite the independent reference cache'
        path.parent.mkdir(exist_ok=True)
        with path.open('wb')as f:pickle.dump(data,f)
        row['cache_written']=str(path)
    return row

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--case',default='12,26,13');p.add_argument('--compare',action='store_true');p.add_argument('--cache',action='store_true');p.add_argument('--output',default='research/bridge-lower-frontier-fast-check.json');a=p.parse_args()
    result=run(*map(int,a.case.split(',')),compare=a.compare,cache=a.cache)
    Path(a.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

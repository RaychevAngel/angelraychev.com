#!/usr/bin/env python3
"""Bounded independent LP attack on additive potentials at arbitrary odd-grid budgets.

Numerical optimization is exploratory. Every rounded output is checked again
over exact fractions before it can be reported as a finite lower certificate.
Run with scipy available; it is not needed by the main game solver.
"""
from fractions import Fraction
from pathlib import Path
from time import monotonic
import argparse, json

from odd_serial_first_order_attack import profiles, serial


def solve(width, length, budget):
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import lil_matrix
    b=(width-1)//2; m=budget; g=profiles((length-1)//2,b)
    offsets=(0,len(g[0])); size=sum(map(len,g)); charge=size
    nvars=size+2*(m+1)
    rows=[]; bounds=[]
    for p in (0,1):
        for k in range(len(g[p])):
            for r in range(m+1):
                nxt=g[p][max(0,k-r)]
                rows.append({offsets[p]+k:1,
                             offsets[1-p]+nxt:-1,
                             charge+p*(m+1)+r:-1})
                bounds.append(0)
    for r in range(m+1):
        rows.append({charge+r:1,charge+(m+1)+m-r:1})
        bounds.append(1)
    mat=lil_matrix((len(rows),nvars))
    for i,row in enumerate(rows):
        for j,a in row.items():mat[i,j]=a
    obj=np.zeros(nvars)
    for p in (0,1):obj[offsets[p]+len(g[p])-1]=-1
    vbounds=[(0,None)]*nvars
    for p in (0,1):vbounds[offsets[p]]=(0,0)
    result=linprog(obj,A_ub=mat.tocsr(),b_ub=bounds,bounds=vbounds,
                   method='highs',options={'threads':1})
    if not result.success:raise RuntimeError(result.message)
    exact=[Fraction(float(v)).limit_denominator(10000) for v in result.x]
    violations=[i for i,(row,rhs) in enumerate(zip(rows,bounds))
                if sum(exact[j]*a for j,a in row.items())>rhs]
    value=sum(exact[offsets[p]+len(g[p])-1] for p in (0,1))
    dual=[Fraction(-float(v)).limit_denominator(1000000) for v in result.ineqlin.marginals]
    coefficients=[Fraction(0) for _ in range(nvars)]
    for row,multiplier in zip(rows,dual):
        if multiplier:
            for j,a in row.items():coefficients[j]+=multiplier*a
    dual_violations=[j for j,a in enumerate(coefficients)
                     if j not in offsets and a < -int(obj[j])]
    dual_value=sum(y*b for y,b in zip(dual,bounds))
    dual_ok=all(y>=0 for y in dual) and not dual_violations and dual_value==value
    return {'width':width,'length':length,'budget':m,
            'exact_dual_verified':dual_ok,'dual_value':str(dual_value),
            'dual_nonzero':[[i,str(y)] for i,y in enumerate(dual) if y],
            'dual_violations':dual_violations[:5],
            'potential_value':str(value),'serial_upper':min(serial(g,m,p) for p in (0,1)),
            'exact_fraction_verified':not violations,'constraint_count':len(rows),
            'violations':violations[:5],
            'charges':[[str(exact[charge+p*(m+1)+r])for r in range(m+1)]for p in(0,1)],
            'potentials':[[str(exact[offsets[p]+k])for k in range(len(g[p]))]for p in(0,1)]}


if __name__=='__main__':
    from high_budget_odd_rectangles import exact
    from math import ceil
    start=monotonic(); results=[]
    for w in (3,5,7,9,11):
        for n in (w,w+2,w+6):
            for m in sorted({(w+1)//2,(w+3)//2,w-1,w}):
                if m>=(w*n-1)//2: continue
                row=solve(w,n,m)
                row['exact_time']=exact(w,n,m)
                row['rounded_bound']=ceil(Fraction(row['potential_value']))
                row['gap']=row['exact_time']-row['rounded_bound']
                results.append(row)
                print(w,n,m,row['potential_value'],row['exact_time'],row['gap'],row['exact_fraction_verified'],flush=True)
    out={'scope':'Exploratory finite rational-verified separable potentials; no uniform theorem.',
         'seconds':monotonic()-start,'results':results}
    Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-potential-attack.json').write_text(json.dumps(out,indent=2)+'\n')
    print('DONE',out['seconds'],'maxgap',max(r['gap']for r in results),flush=True)

"""Candidate exact three-threshold backward recurrence for the corner model.

Under proof review. Independent comparison uses every edge of the existing
bitset model, not just forward minima or selected optimal paths.
"""
from math import isqrt
from pathlib import Path
import json,time
from resumed_even_construction_formula_clock import model_data


def R(x):
    assert x >= 0
    s=isqrt(x);return s+(s*s<x)


def rho(x):
    assert x >= 0
    s=(isqrt(1+4*x)-1)//2;return s+(s*(s+1)<x)


def small_inverse(i,j,t):
    if j:
        c=i+2*j-2
        return c+max(2,R(max(0,t-2*c)))
    if i:
        c=i-1
        return c+max(1,rho(max(0,t-2*c)))
    return min(rho(2*t),rho(t)+1) if t else 0


def large_inverse(i,j,d):
    A=2-i;B=2-j
    if B:
        return A+B+max(0,R(max(0,d-B+1))-1)
    if A:
        return A+rho(d)
    return min(rho(2*d)+1,1+R(d+1)) if d else 0


def survivor_bound(w,n,i,j,t,critical=True):
    h=w*n//2;r=w//2
    if t<max(1,j):return 0
    t=min(t,h-2+j)
    exception=((w==2*r or n==2*r) and(i,j)==(1,1)) or ((w==2*r+1 or n==2*r+1)and(i,j)==(2,0))
    cap=r+int(critical and not exception)
    s=min(small_inverse(i,j,t),large_inverse(i,j,h-t),cap)
    q=min(h-2+i,t-s)
    return q if q>=max(1,i) else 0


def step(w,n,k,B,critical=True):
    h=w*n//2
    return tuple(min(h-2+c,k+max(survivor_bound(w,n,i,j,B[j],critical)
                              for i in range(c+1) for j in range(3)))
                 for c in range(3))


def first_clock(w,n,k,critical=True):
    h=w*n//2;B=(0,-1,-1);trace=[B]
    while B[2]<h:
        B=step(w,n,k,B,critical);trace.append(B)
        assert len(trace)<=4*w*n
    return len(trace)-1,trace


def audit(w,n,k,critical=True):
    h=w*n//2
    states,index,edges=model_data(w,n,k,critical)
    W=1<<index[0,0];B=(0,-1,-1);checks=0;layers=0
    full=(1<<len(states))-1
    while True:
        expected=sum(1<<z for z,(a,c)in enumerate(states) if a<=B[c])
        assert W==expected,dict(w=w,n=n,k=k,critical=critical,layer=layers,B=B,
                               missing=[states[z]for z in range(len(states)) if ((W^expected)>>z)&1][:20])
        checks+=len(states);layers+=1
        if W==full:break
        W=sum(1<<z for z,row in enumerate(edges) if row&W)
        B=step(w,n,k,B,critical)
        assert layers<4*w*n
    return dict(shape=[w,n],budget=k,critical=critical,layers=layers,
                all_state_membership_comparisons=checks,passed=True)


if __name__=='__main__':
    started=time.process_time();rows=[]
    for w in range(2,13):
        for n in range(w,w+4):
            if w*n%2:continue
            for k in range(w//2+1,min(w*w//2,w//2+5)):
                for critical in (False,True):rows.append(audit(w,n,k,critical))
    out=dict(scope=__doc__,rows=rows,cases=len(rows),state_membership_comparisons=sum(x['all_state_membership_comparisons']for x in rows),CPU_seconds=time.process_time()-started)
    Path('research/bridge-corner-frontier-check.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='rows'})

"""Independent finite checks of the two-round even-path lemma and failed lift."""
from itertools import product
from pathlib import Path
from time import process_time
import json


def predicted(length, a, p, q):
    if a <= p + q:
        return 0
    if a == length and p == 0:
        return length - q
    return min(length, a - p - q + 1)


def run(max_half_length=7):
    start = process_time()
    records = []
    for length in range(1, max_half_length + 1):
        full = (1 << length) - 1
        hoods = [[0] * (full + 1) for _ in range(2)]
        for mask in range(full + 1):
            hoods[0][mask] = mask | (mask >> 1)
            hoods[1][mask] = (mask | (mask << 1)) & full
        second = []
        for parity in (0, 1):
            rows = []
            for before in range(full + 1):
                best = [length] * (length + 1)
                survivor = before
                while True:
                    cost = before.bit_count() - survivor.bit_count()
                    best[cost] = min(best[cost], hoods[parity][survivor].bit_count())
                    if survivor == 0:
                        break
                    survivor = (survivor - 1) & before
                for q in range(1, length + 1):
                    best[q] = min(best[q], best[q - 1])
                rows.append(best)
            second.append(rows)
        checked = 0
        for parity in (0, 1):
            minima = [[[length] * (length + 1) for _ in range(length + 1)]
                      for _ in range(length + 1)]
            for before in range(full + 1):
                best = [[length] * (length + 1) for _ in range(length + 1)]
                survivor = before
                while True:
                    p = before.bit_count() - survivor.bit_count()
                    row = second[1 - parity][hoods[parity][survivor]]
                    for q, value in enumerate(row):
                        best[p][q] = min(best[p][q], value)
                    if survivor == 0:
                        break
                    survivor = (survivor - 1) & before
                for p in range(1, length + 1):
                    for q in range(length + 1):
                        best[p][q] = min(best[p][q], best[p - 1][q])
                a = before.bit_count()
                for p in range(length + 1):
                    for q in range(length + 1):
                        assert best[p][q] >= predicted(length, a, p, q)
                        minima[a][p][q] = min(minima[a][p][q], best[p][q])
                        checked += 1
            assert all(minima[a][p][q] == predicted(length, a, p, q)
                       for a, p, q in product(range(length + 1), repeat=3))
        records.append({'path_rooms': 2 * length, 'arbitrary_support_quota_checks': checked,
                        'all_lower_bounds_and_attainment_pass': True})

    vertices = set(product(range(2), range(4)))
    def neighborhood(support):
        return {v for v in vertices for u in support
                if abs(v[0] - u[0]) + abs(v[1] - u[1]) == 1}
    def common_end_compress(support):
        compressed = set()
        for x in range(2):
            for parity in (0, 1):
                count = sum((u == x and y % 2 == parity) for u, y in support)
                compressed.update((x, y) for y in list(range(parity, 4, 2))[:count])
        return compressed
    s = {(0, 3)}
    original = neighborhood(neighborhood(s))
    left = neighborhood(neighborhood(common_end_compress(s)))
    right = common_end_compress(original)
    assert left - right == {(1, 2)}
    # Favorable endpoint for each line's own parity also fails: the singleton
    # is fixed, but its distance-two neighbor in the other line moves ends.
    def favorable_compress(support):
        compressed = set()
        for x in range(2):
            for parity in (0, 1):
                count = sum((u == x and y % 2 == parity) for u, y in support)
                order = list(range(parity, 4, 2))
                if parity:
                    order.reverse()
                compressed.update((x, y) for y in order[:count])
        return compressed
    favorable_left = neighborhood(neighborhood(favorable_compress(s)))
    favorable_right = favorable_compress(original)
    assert favorable_left - favorable_right == {(1, 2)}
    return {'scope': 'Finite independent checks; the all-length proof is in the companion note.',
            'path_checks': records,
            'product_counterexample': {'shape': [2, 4], 'support': sorted(s),
                                      'original_N_squared': sorted(original),
                                      'N_squared_common_end_compressed': sorted(left),
                                      'common_end_compressed_N_squared': sorted(right),
                                      'N_squared_favorable_compressed': sorted(favorable_left),
                                      'favorable_compressed_N_squared': sorted(favorable_right)},
            'CPU_seconds': process_time() - start}


if __name__ == '__main__':
    result = run()
    output = Path(__file__).resolve().parents[1] / 'research/even-bridge-two-round-path.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

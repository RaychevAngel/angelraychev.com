"""Unpruned physical-transition audit for T5(P3 x P3 x P4)=36."""
from itertools import product
from collections import deque
from functools import lru_cache
from pathlib import Path
import json
import time

started = time.process_time()
transverse = list(product(range(3), repeat=2))
transverse_sets = 0
for p, expected in enumerate(((0,2,3,4,4,4), (0,3,4,5,5))):
    color = [v for v in transverse if sum(v)%2 == p]
    minima = [99]*(len(color)+1)
    for code in range(1 << len(color)):
        support = [v for i, v in enumerate(color) if code >> i & 1]
        hood = {v for u in support for v in transverse
                if sum(abs(a-b) for a, b in zip(u,v)) == 1}
        minima[len(support)] = min(minima[len(support)], len(hood))
        transverse_sets += 1
    assert tuple(minima) == expected
coords = list(product(range(3), range(3), range(4)))
adj = [sum(1 << j for j, w in enumerate(coords)
           if sum(abs(a-b) for a, b in zip(v, w)) == 1) for v in coords]
prefix = {}
for p in (0, 1):
    for z in range(4):
        order = sorted((i for i, v in enumerate(coords) if v[2] == z and sum(v)%2 == p),
                       key=lambda i: (sum(coords[i][:2]), -coords[i][0], -coords[i][1]))
        prefix[p,z] = [0]
        for i in order:
            prefix[p,z].append(prefix[p,z][-1] | (1 << i))
caps = [tuple(len(prefix[p,z])-1 for z in range(4)) for p in (0,1)]


def mask(p, counts):
    answer = 0
    for z, k in enumerate(counts):
        answer |= prefix[p,z][k]
    return answer


def neighborhood(s):
    answer = 0
    while s:
        bit = s & -s
        answer |= adj[bit.bit_length()-1]
        s ^= bit
    return answer


# Every single-cohort transition is computed from actual room neighborhoods,
# not from the submitted max/profile implementation.
successor = {}
for p in (0,1):
    for counts in product(*(range(c+1) for c in caps[p])):
        hood = neighborhood(mask(p, counts))
        out = tuple((hood & prefix[1-p,z][-1]).bit_count() for z in range(4))
        assert hood == mask(1-p, out)
        successor[p, counts] = out


@lru_cache(None)
def allocations(counts, quota):
    if not counts:
        return ((),) if quota == 0 else ()
    return tuple((counts[0]-r,)+tail
                 for r in range(min(counts[0], quota)+1)
                 for tail in allocations(counts[1:], quota-r))


initial = caps[0]+caps[1]
queue = deque([initial])
previous = {initial: None}
depth = {initial: 0}
expanded = transitions = 0
terminal = None
while queue:
    assert time.process_time()-started < 25, "CPU audit cap reached"
    state = queue.popleft()
    expanded += 1
    if sum(state) <= 5:
        terminal = state
        break
    for quota in range(6):
        for even in allocations(state[:4], quota):
            for odd in allocations(state[4:], 5-quota):
                transitions += 1
                out = successor[1, odd]+successor[0, even]
                if out not in previous:
                    previous[out] = state, even+odd
                    depth[out] = depth[state]+1
                    queue.append(out)
assert terminal is not None
assert depth[terminal]+1 == 36

steps = [(terminal, (0,)*8)]
here = terminal
while previous[here] is not None:
    before, survivors = previous[here]
    steps.append((before, survivors))
    here = before
steps.reverse()
belief = (1 << 36)-1
for source, remaining in steps:
    assert belief == mask(0, source[:4]) | mask(1, source[4:])
    residual = mask(0, remaining[:4]) | mask(1, remaining[4:])
    assert residual & ~belief == 0 and (belief & ~residual).bit_count() <= 5
    belief = neighborhood(residual)
assert belief == 0 and len(steps) == 36

result = {"status": "passed", "exact_days": 36, "CPU_seconds": time.process_time()-started,
          "transverse_arbitrary_subsets_checked": transverse_sets,
          "single_cohort_physical_states_checked": len(successor),
          "states_expanded": expanded, "states_seen": len(previous),
          "transitions_examined": transitions, "terminal_depth_before_final_probe": depth[terminal],
          "heuristic_or_profile_pruning": False, "physical_replay": True,
          "method": "actual-neighborhood transition table plus unpruned joint BFS",
          "scope": "finite computer-assisted result, ordinary compression proof; not Lean"}
path = Path(__file__).resolve().parents[1] / "research/even-cube-independent-review.json"
path.write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result))

"""Test total-deficit domination only from the full initial board.

Compares the formula corner relaxation with itself; no physical attainment or
arbitrary-partial-state seriality theorem is claimed.
"""
from collections import deque,defaultdict
from pathlib import Path
import json,time

from resumed_even_construction_formula_profile import build


def test(w,n,k):
    start=time.monotonic();h=w*n//2;states,options=build(w,k,n)
    initial=(h,2);queue=deque([(initial,0)]);solo={initial:0};solo_layers=defaultdict(list)
    tau=None
    while queue:
        a,depth=queue.popleft()
        if tau is not None and depth>=tau:break
        solo_layers[depth].append(a[0])
        if a[0]<=k:
            tau=depth+1
            continue
        for b,cost in options[a].items():
            if b not in solo:solo[b]=depth+1;queue.append((b,depth+1))
    assert tau
    minimum=h;solo_min=[]
    for t in range(tau):
        minimum=min(minimum,min(solo_layers[t],default=h));solo_min.append(minimum)
    pair=(initial,initial);queue=deque([(pair,0)]);seen={pair};layers=defaultdict(list);edges=0
    while queue:
        (a,b),depth=queue.popleft();layers[depth].append((a[0]+b[0],(a,b)))
        if depth+1>=tau:continue
        for aa,cost in options[a].items():
            for bb,other in options[b].items():
                if cost+other>k:continue
                nxt=tuple(sorted((aa,bb)));edges+=1
                if nxt not in seen:seen.add(nxt);queue.append((nxt,depth+1))
    minima=[];minimum=2*h;worst=None
    for t in range(tau):
        candidate,state=min(layers[t],default=(2*h,None))
        if candidate<minimum:minimum=candidate;worst=state
        row={'day':t,'solo_minimum':solo_min[t],'joint_minimum':minimum,
             'expected_joint_minimum':h+solo_min[t]}
        if minimum<h+solo_min[t]:row['counterexample_feature']=worst
        minima.append(row)
    failures=[row for row in minima if row['joint_minimum']<row['expected_joint_minimum']]
    return {'w':w,'n':n,'k':k,'relaxed_solo_tau':tau,'dominance_holds':not failures,
            'first_failure':failures[0]if failures else None,'precapture_layers':minima,
            'joint_states':len(seen),'joint_edges':edges,'seconds':time.monotonic()-start,
            'scope':'Full-initial corner formula model only. Conditional on necessary geometric inequality; no assertion about arbitrary partial states.'}


if __name__=='__main__':
    rows=[]
    for w,n,k in ((6,6,4),(6,6,5),(8,8,5),(8,8,6),(10,10,6),(10,10,7),(12,12,7)):
        out=test(w,n,k);rows.append(out)
        print({k:v for k,v in out.items()if k!='precapture_layers'},flush=True)
        if not out['dominance_holds']:break
    Path('research/resumed-even-construction-full-start-seriality.json').write_text(json.dumps({'results':rows},indent=2)+'\n')

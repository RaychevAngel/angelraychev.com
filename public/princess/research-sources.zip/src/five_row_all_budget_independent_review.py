"""Independent actual-board and endpoint checks for the five-row audit.

The universal proof is reviewed separately; no finite experiment is promoted
to an all-length statement by this script.
"""
import json
from pathlib import Path
from five_row_independent_review import physical_graph


def actual_compatibility(n=6):
    vertices, _, adjacency = physical_graph(n)
    h = 5 * n // 2
    by_parity = []
    vectors = {3: set(), 4: set(), 5: set()}
    for p in (0, 1):
        indices = [i for i, (x, y) in enumerate(vertices) if (x+y) % 2 == p]
        physical = [0] * (1 << h)
        hood = [0] * (1 << h)
        low = []
        for s in range(1, 1 << h):
            bit = s & -s
            i = indices[bit.bit_length()-1]
            physical[s] = physical[s ^ bit] | (1 << i)
            hood[s] = hood[s ^ bit] | adjacency[i]
            k = s.bit_count()
            surplus = hood[s].bit_count() - k
            if surplus in (1, 2):
                low.append((physical[s], hood[s], k, surplus))
            if surplus == 2 and 3 <= k <= 5:
                vector = tuple(sum(1 for j, (_, y) in enumerate(vertices)
                                   if y == row and physical[s] >> j & 1)
                               for row in range(5))
                vectors[k].add(vector)
                assert all(sum(1 for j, (_, y) in enumerate(vertices)
                               if y == row and hood[s] >> j & 1) <= 2
                           for row in range(5))
        by_parity.append(low)
    allowed = {(h-6, 3), (h-5, 3), (h-5, 4)}
    found, comparisons = set(), 0
    for p in (0, 1):
        for _, hood, k, surplus in by_parity[p]:
            if surplus != 2 or not 3 <= k <= h-5:
                continue
            for successor, _, j, next_surplus in by_parity[1-p]:
                comparisons += 1
                if successor & ~hood:
                    continue
                if next_surplus == 1 and j == 1:
                    assert k >= h-6
                if next_surplus == 2 and 3 <= j <= h-5:
                    assert (k, j) in allowed
                    found.add((k, j))
    assert found == allowed
    listed = {3: [(2,1,0,0,0), (1,1,1,0,0), (1,0,1,0,1)],
              4: [(2,1,1,0,0), (1,1,1,0,1)],
              5: [(2,1,1,0,1), (1,1,1,1,1)]}
    for k, vs in listed.items():
        assert vectors[k] == set(vs) | {v[::-1] for v in vs}
    return {"length": n, "physical_supports": 2*(1 << h),
            "compatibility_comparisons": comparisons,
            "allowed_pairs": sorted(found), "small_vectors_verified": True}


def endpoint_checks():
    def f(m, u):
        quotient, remainder = divmod(max(u-7, 0), 2*m-5)
        return (u+5*quotient)//2 - int(quotient >= 1 and remainder+1 in (1,2,4))
    def need(r):
        return [0,2,3,4,4][r] if r <= 4 else (r+6)//2
    count = 0
    for h in range(15, 501, 5):
        for m in range(5, h-7):
            q, r = divmod(2*h-6, 2*m-5)
            cap = min(f(m, 2*h), 2+f(m, 2*h-2), 4+f(m, 2*h-4))
            assert cap == q*m+need(r)-int(r == 2)
            target = 2*q if r == 0 else 2*q+1 if 2*need(r) <= m else 2*q+2
            assert (2*cap+m-1)//m == target
            count += 1
    return {"physical_parameter_pairs": count, "max_h": 500}


if __name__ == "__main__":
    result = {"status": "passed", "actual_geometry": actual_compatibility(),
              "endpoint_cap": endpoint_checks(),
              "scope": "supplementary attacks; ordinary proof supplies universal claims"}
    path = Path(__file__).resolve().parents[1] / "research/five-row-all-budget-independent-review.json"
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))

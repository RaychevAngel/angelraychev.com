"""Test the capped two-copy deficit inequality relevant to a central shot."""
from bisect import bisect_right
from pathlib import Path
from time import process_time
from odd_serial_first_order_attack import profiles
from uniform_rectangle_antichain_attack import advance
import json

def main(seconds=20):
 start=process_time();cases=pairs=0;fail=None
 for b in range(1,13):
  for a in (b,b+1,b+3):
   g=profiles(a,b);E,M=len(g[0])-1,len(g[1])-1
   I=[[bisect_right(g[p],z)-1for z in range((M,E)[p]+1)]for p in(0,1)]
   for m in range(b+1,min(2*b+4,M)):
    D0=D1=0;front=[(E,M)];t=0
    while True:
     C0,C1=I[0][min(M,D1+m)],I[1][min(E,D0+m)]
     if C0==E or C1==M:break
     D0,D1=C0,C1;front=advance(g,m,front);t+=1
    cases+=1;bound=max(E,D0+D1)
    for j,(a0,b0)in enumerate(front):
     for a1,b1 in front[j:]:
      value=min(E,2*E-a0-a1)+min(M,2*M-b0-b1);pairs+=1
      if value>bound:
       fail={'shape':[2*a+1,2*b+1],'m':m,'L':t,'capacities':[D0,D1],'beliefs':[[a0,b0],[a1,b1]],'union':value,'bound':bound,'middle_budget':E+M-value};break
     if fail:break
    if fail or process_time()-start>seconds:break
   if fail or process_time()-start>seconds:break
  if fail or process_time()-start>seconds:break
 out={'scope':'Conjectural capped two-copy deficit bound at the last pre-solo-capture layer.','parameters':cases,'state_pairs':pairs,'failure':fail,'CPU_seconds':process_time()-start}
 Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-central-pair-attack.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()

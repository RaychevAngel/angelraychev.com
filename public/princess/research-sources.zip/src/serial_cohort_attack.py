"""Test the one-overlap serial conjecture against exact nested count games.

This script checks a proposed simplification. The result is not a theorem
about serial play, and ordered rectangle profiles are only exact when their
isoperimetric optimality has been proved or separately certified.
"""
from collections import deque
from pathlib import Path
from time import monotonic
import json

from nested_grid_time import ordered_profiles


def exact_counts(profiles, budget):
    initial = tuple(len(g)-1 for g in profiles)
    queue = deque([(initial, 0)])
    seen = {initial}
    while queue:
        (a, b), day = queue.popleft()
        if a+b <= budget:
            return day+1
        for p in range(budget+1):
            after = (profiles[1][max(b-budget+p, 0)], profiles[0][max(a-p, 0)])
            if after not in seen:
                seen.add(after)
                queue.append((after, day+1))
    return None


def serial_counts(profiles, budget):
    sizes = [len(g)-1 for g in profiles]
    best = None
    for first in (0, 1):
        a, b = sizes[first], sizes[1-first]
        p, days = first, 0
        seen = set()
        while a and (p, a, b) not in seen:
            seen.add((p, a, b))
            if a <= budget:
                remaining = profiles[1-p][max(0, b-(budget-a))]
                current_parity = p
                tail = 1
                tail_seen = set()
                while remaining and (current_parity, remaining) not in tail_seen:
                    tail_seen.add((current_parity, remaining))
                    remaining = profiles[current_parity][max(0, remaining-budget)]
                    current_parity = 1-current_parity
                    tail += 1
                if not remaining and (best is None or days+tail < best):
                    best = days+tail
            a = profiles[p][max(0, a-budget)]
            b = profiles[1-p][b]
            p = 1-p
            days += 1
    return best


def main():
    started = monotonic()
    rows, failures = [], []
    for width in range(3, 14, 2):
        for length in range(width, width+10, 2):
            report, data = ordered_profiles((length, width))
            assert report['nested']
            for m in range(width//2+1, length*width//2+1):
                actual = exact_counts(data[-1], m)
                serial = serial_counts(data[-1], m)
                row = {'shape': [length, width], 'budget': m,
                       'ordered_count_optimum': actual, 'serial_turns': serial}
                rows.append(row)
                if actual != serial:
                    failures.append(row)
    result = {'scope': 'Finite attack on one-overlap serial optimality; no general theorem.',
              'parameter_pairs': len(rows), 'failures': failures,
              'seconds': round(monotonic()-started, 3), 'results': rows}
    path = Path(__file__).resolve().parents[1]/'research'/'serial-cohort-checks.json'
    path.write_text(json.dumps(result, indent=2)+'\n')
    print({k: v for k, v in result.items() if k != 'results'})


if __name__ == '__main__':
    main()

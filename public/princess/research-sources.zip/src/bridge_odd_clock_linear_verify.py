"""Run the independent C++ verifier on every unresolved finite case.

The child has an absolute 30 CPU second cap. All model inputs and every
case's exact central result are saved with source and dependency hashes.
"""
from pathlib import Path
import hashlib
import json
import resource
import subprocess
import tempfile
from time import process_time


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cap_cpu():
    resource.setrlimit(resource.RLIMIT_CPU,(30,30))


def main():
    root=Path(__file__).resolve().parents[1]
    cpp=root/'src/bridge_odd_clock_linear_verify.cpp'
    filtered=root/'research/bridge-odd-clock-linear-budget-filter.json'
    cases=json.loads(filtered.read_text())['unresolved']
    words=''.join(f"{r['width']} {r['length']} {r['budget']} {r['tau']} {r['scalar_time']}\n"
                  for r in cases)
    dependencies=[cpp,Path(__file__),filtered,
                  root/'src/bridge_odd_clock_linear_filter.py',
                  root/'src/supersession_solo_bands.py',
                  root/'src/supersession_odd_midpoint_bounded.py',
                  root/'research/bridge-odd-clock-linear-budget.md',
                  root/'research/bridge-odd-clock-orientation-onset.md',
                  root/'research/bridge-odd-clock-reset.md']
    with tempfile.TemporaryDirectory(prefix='princess-odd-linear-') as temporary:
        binary=Path(temporary)/'verify'
        compiler=subprocess.run(['/usr/bin/clang++','--version'],capture_output=True,text=True,check=True)
        subprocess.run(['/usr/bin/clang++','-std=c++17','-O3',str(cpp),'-o',str(binary)],check=True)
        run=subprocess.run([str(binary)],input=words,text=True,capture_output=True,
                           preexec_fn=cap_cpu,timeout=45)
    rows=[json.loads(line) for line in run.stdout.splitlines() if line.strip()]
    result=dict(status='PASS' if run.returncode==0 and len(rows)==len(cases) else 'INCOMPLETE',
                scope=__doc__,cpu_limit_seconds=30,returncode=run.returncode,
                compiler=compiler.stdout.splitlines()[0],compile_flags=['-std=c++17','-O3'],
                model='Exact retained exceptional frontier, all m+1 quota splits, coordinate Pareto dominance; no acceleration.',
                hashes={str(p.relative_to(root)):digest(p) for p in dependencies},
                inputs_sha256=hashlib.sha256(words.encode()).hexdigest(),
                input_count=len(cases),verified_count=len(rows),
                exact_central_comparisons=len(rows),
                quota_splits=sum(r['quota_splits'] for r in rows),
                max_frontier=max((r['maximum_frontier'] for r in rows),default=0),
                reported_timing=run.stderr.strip(),rows=rows)
    path=root/'research/bridge-odd-clock-linear-budget-finite-verified.json'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print({k:result[k] for k in ('status','verified_count','quota_splits','max_frontier','reported_timing')})
    assert result['status']=='PASS',run.stderr


if __name__=='__main__':
    main()

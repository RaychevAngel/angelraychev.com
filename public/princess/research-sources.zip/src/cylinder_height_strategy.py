"""Explicit height strategy on a bipartite box cross-section times a path.
Upper bounds only; never reports a non-optimal witness as an optimal time.
"""
from itertools import product
from pathlib import Path
from time import monotonic
import json


def strategy(base_shape, length, budget):
    cross = list(product(*(range(n) for n in base_shape)))
    a = len(cross)
    assert length >= 2 and 2*budget > a
    colors = [sum(v) % 2 for v in cross]
    day = 0
    shots = []
    phase_days = []
    for initial_cohort in (0, 1):
        start = day
        physical = (initial_cohort+day) % 2
        height = [length-1-((length-1-physical+c) % 2) for c in colors]
        higher = max(height)
        order = [i for i, h in enumerate(height) if h == higher]
        order += [i for i, h in enumerate(height) if h != higher]
        assert sorted(order) == list(range(a))
        flips = 0
        bound = (a*(length+2)+2*budget-a-1)//(2*budget-a)
        while max(height) >= 0:
            shot = []
            for _ in range(budget):
                i = order[flips % a]
                if 0 <= height[i] < length:
                    shot.append(cross[i]+(height[i],))
                height[i] -= 2
                flips += 1
            assert len(set(shot)) == len(shot) <= budget
            shots.append(shot)
            height = [h+1 for h in height]
            day += 1
            assert day-start <= bound
        phase_days.append(day-start)
    return shots, phase_days


def replay(shape, budget, shots):
    vertices = set(product(*(range(n) for n in shape)))
    belief = vertices.copy()
    first_empty = None
    for day, shot in enumerate(shots, 1):
        assert set(shot) <= vertices and len(set(shot)) <= budget
        survivors = belief-set(shot)
        following = set()
        for v in survivors:
            for axis, length in enumerate(shape):
                for delta in (-1, 1):
                    w = list(v)
                    w[axis] += delta
                    if 0 <= w[axis] < length:
                        following.add(tuple(w))
        belief = following
        if not belief and first_empty is None:
            first_empty = day
    assert not belief
    return first_empty


def main():
    begin = monotonic()
    records = []
    for base in ((1,), (2,), (3,), (4,), (3, 3), (2, 2, 2)):
        size = 1
        for n in base:
            size *= n
        for length in (2, 3, 4, 5, 10, 25, 50):
            for budget in (size//2+1, size+1):
                shots, phases = strategy(base, length, budget)
                first_empty = replay(base+(length,), budget, shots)
                records.append({'base': base, 'length': length, 'budget': budget,
                                'phase_days': phases, 'guaranteed_by': first_empty,
                                'schedule_days': len(shots)})
    result = {'method': __doc__, 'cases': len(records),
              'seconds': round(monotonic()-begin, 3), 'results': records}
    target = Path(__file__).resolve().parents[1]/'research/cylinder-height-checks.json'
    target.write_text(json.dumps(result, indent=2)+'\n')
    print({'cases': len(records), 'seconds': result['seconds']})


if __name__ == '__main__':
    main()

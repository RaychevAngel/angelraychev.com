"""Select an isolated website checkout without changing the saved project."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SITE = Path(os.environ.get('PRINCESS_SITE_ROOT',
                          str(ROOT.parent / 'polyominoes/website'))).resolve()

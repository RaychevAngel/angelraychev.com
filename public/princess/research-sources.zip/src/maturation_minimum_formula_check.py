"""Independent exact-frontier attack on the uniform odd minimum-budget law."""
from pathlib import Path
from time import process_time
import json

from supersession_solo_bands import R, rho
from supersession_odd_midpoint_bounded import solve


def clock(b):
    target, m = b*(b-1), b+1
    a = c = t = 0
    while c < target:
        a, c = c+m-min(rho(c+m), b), a+m-min(R(a+m), b+1)
        t += 1
    assert c == target
    assert (a, c) in ((target-1, target), (target, target))
    return t


def main():
    start = process_time()
    cases = []
    # Deliberately selected endpoint widths, new widths, and longer boards.
    # The predecessor frontier solver does not assume this formula.
    for b in (1, 2, 3, 9, 20, 40):
        w, m, L = 2*b+1, b+1, clock(b)
        K = 8*b*b-4*b-4*L+4
        for n in (w, w+2, 3*w):
            expected = 2*w*n-K
            actual = solve(w, n, m)
            assert actual['time'] == expected
            assert 2*actual['tau'] == expected
            assert actual['central_minimum'] > m
            cases.append({'b': b, 'width': w, 'length': n, 'budget': m,
                          'corner_clock': L, 'offset': K, 'time': expected,
                          'central_minimum': actual['central_minimum'],
                          'frontier_peak': actual['maximum_frontier']})
    result = {'status': 'PASS',
              'scope': 'Finite independent attack; ordinary unbounded proof is separate',
              'cases': cases, 'cpu_seconds': process_time()-start}
    (Path(__file__).resolve().parents[1]/'research/maturation-minimum-formula-check.json').write_text(
        json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status': 'PASS', 'cases': len(cases), 'cpu_seconds': result['cpu_seconds']}))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Targeted exact short-word comparison for narrow quadrant parents."""
from functools import lru_cache
from itertools import product
from pathlib import Path
import json
import time
from maturation_even_narrow_family import narrow
from maturation_even_hybrid_words import neighbor_counts
from maturation_even_relative_family import neighborhood_size


visited = 0


@lru_cache(None)
def last_profiles(h, a):
    global visited
    size = sum(a)
    raw, family = [None]*(size+1), [None]*(size+1)
    for r in product(*(range(x+1) for x in a)):
        visited += 1
        p, n = size-sum(r), neighborhood_size(h,r)
        if raw[p] is None or n < raw[p][0]:
            raw[p] = (n,r)
        if narrow(h,r) and (family[p] is None or n < family[p][0]):
            family[p] = (n,r)
    for p in range(1,size+1):
        for row in (raw,family):
            if row[p-1] is not None and (row[p] is None or row[p-1][0] < row[p][0]):
                row[p] = row[p-1]
    return raw, family


def main():
    started = time.process_time()
    parents = [(0,(1,2,3,4)), (0,(1,3,4,2)),
               (1,(2,3,4)), (2,(2,3,4)), (2,(3,5,2))]
    checks = 0
    mismatches = []
    for h,a in parents:
        size = sum(a)
        cap = neighborhood_size(h,a)
        raw = [[None]*(cap+1) for _ in range(size+1)]
        restricted = [[None]*(cap+1) for _ in range(size+1)]
        for r in product(*(range(x+1) for x in a)):
            p = size-sum(r)
            nh, nc = neighbor_counts(h,r)
            ordinary, family = last_profiles(nh,nc)
            good = narrow(h,r)
            for q in range(cap+1):
                cost = min(q,sum(nc))
                item = ordinary[cost]
                record = (item[0],r,nh,nc,item[1])
                if raw[p][q] is None or record[0] < raw[p][q][0]:
                    raw[p][q] = record
                if good and family[cost] is not None:
                    item = family[cost]
                    record = (item[0],r,nh,nc,item[1])
                    if restricted[p][q] is None or record[0] < restricted[p][q][0]:
                        restricted[p][q] = record
        for p in range(1,size+1):
            for q in range(cap+1):
                for table in (raw,restricted):
                    if table[p-1][q] is not None and (table[p][q] is None or table[p-1][q][0] < table[p][q][0]):
                        table[p][q] = table[p-1][q]
        for p in range(size+1):
            for q in range(cap+1):
                checks += 1
                if restricted[p][q] is None or raw[p][q][0] != restricted[p][q][0]:
                    mismatches.append({"h":h,"parent":a,"p":p,"q":q,
                                       "raw":raw[p][q],"narrow":restricted[p][q]})
    out = {"scope":"Exact three-day at-most quota words in five narrow partial parents",
           "parents":parents,"quota_pairs":checks,"second_parent_profiles":last_profiles.cache_info().currsize,
           "second_survivor_vectors":visited,"mismatches":mismatches,
           "cpu_seconds":round(time.process_time()-started,6)}
    path = Path(__file__).resolve().parents[1]/"research/maturation-narrow-word-check.json"
    path.write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out))


if __name__ == "__main__":
    main()

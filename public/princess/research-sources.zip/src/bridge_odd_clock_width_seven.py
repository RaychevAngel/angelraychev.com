"""Finite short-board certificate for the remaining width-seven odd strips.

The reference uses the proved retained frontier. The independent calculation
below keeps the complete Pareto frontier, including low-total mixed states.
Neither solver assumes the scalar midpoint answer.
"""
from pathlib import Path
from math import isqrt
from time import process_time
import hashlib
import json

from supersession_odd_midpoint_bounded import solve
from bridge_odd_clock_quadratic import half_time


def closed_value(n, m):
    """All odd n>=7, m=6,7,8,9; fixed finite numerical expression."""
    assert n >= 7 and n % 2 == 1 and m in (6,7,8,9)
    if m == 7:
        return 2*n-2
    D = 2*m-7
    q = (n-7)//(2*D)
    j = (n-7)//2-D*q
    constants = {6:(16,21,26,32,38),
                 8:(10,12,16,18,22,25,28,31,34),
                 9:(8,10,13,16,18,20,23,26,28,30,33)}
    return 28*q+constants[m][j]


def onset(b, m):
    w = 2*b+1
    H = b*b+1
    G = m-1
    K = H-1+2*m*(G//w+1)
    W = G+K+1
    J = 2*K+G+2*m+H+2
    return 2*J+G+m*(W+3)


def full_pareto(n, m):
    b = 3
    E = (7*n+1)//2
    M = E-1

    def root(z):
        r = isqrt(z)
        return r+(r*r < z)

    def pronic(z):
        r = (isqrt(4*z+1)-1)//2
        return r+(r*(r+1) < z)

    # Independently construct attained inverse tables from the forward
    # neighborhood profiles, instead of reusing the closed inverse formulas.
    profiles = [[0]+[k+min(root(k),b,root(E-k)-1)
                      for k in range(1,E+1)],
                [0]+[k+min(pronic(k)+1,b+1,pronic(M-k)+1)
                      for k in range(1,M+1)]]
    inverse = []
    for p, cap in ((0,M),(1,E)):
        table = []
        cursor = 0
        for z in range(cap+1):
            while cursor+1 < len(profiles[p]) and profiles[p][cursor+1] <= z:
                cursor += 1
            table.append(cursor)
        inverse.append(table)

    front = [(0,0)]
    day = 0
    maximum_frontier = 1
    transitions = 0
    while True:
        d0 = max(x for x,y in front)
        d1 = max(y for x,y in front)
        if d1+m >= M or d0+m >= E:
            break
        candidates = set()
        for x,y in front:
            for q in range(m+1):
                candidates.add((inverse[0][y+m-q],inverse[1][x+q]))
                transitions += 1
        # This removes only coordinatewise dominated points. In particular
        # it does not use a total-deficit, ancestry, serial, or scalar guard.
        front = []
        highest_y = -1
        for x,y in sorted(candidates,reverse=True):
            if y > highest_y:
                front.append((x,y))
                highest_y = y
        maximum_frontier = max(maximum_frontier,len(front))
        day += 1

    central = min(max(E-x-u,0)+max(M-y-v,0)
                  for x,y in front for u,v in front)
    scalar = E+M-d0-d1
    tau = day+1
    return {'n':n,'m':m,'tau':tau,'central':central,'scalar_central':scalar,
            'time':2*tau-int(central<=m),
            'precentral_deficits':[d0,d1],
            'frontier':front,'maximum_frontier':maximum_frontier,
            'quota_transitions':transitions}


def main():
    started = process_time()
    rows = []
    ranges = []
    for m in (6,7,8,9):
        threshold = onset(3,m)
        ns = [n for n in range(7,(2*threshold-1)//7+1,2)
              if (7*n-1)//2 < threshold]
        ranges.append({'m':m,'M_onset':threshold,'short_n_min':7,
                       'short_n_max':max(ns),'short_count':len(ns)})
        for n in ns:
            row = full_pareto(n,m)
            reference = solve(7,n,m,accelerate=False)
            bounded = half_time(7,n,m,K=16)
            assert row['tau'] == reference['tau'] == bounded['tau']
            assert row['central'] == reference['central_minimum']
            assert row['scalar_central'] == reference['solo_residual_sum']
            assert row['time'] == reference['time']
            assert (row['central']<=m) == (row['scalar_central']<=m), row
            assert sum(bounded['precentral_residuals']) == row['scalar_central']
            assert closed_value(n,m) == row['time']
            rows.append(row)
            if process_time()-started > 30:
                raise RuntimeError('Bounded certificate exceeded its 30-second CPU limit')
    large_checks = []
    for m in (6,7,8,9):
        D = 2*m-7
        for j in range(D):
            n = 7+2*j+2*D*10**12
            bounded = half_time(7,n,m,K=16)
            # These lengths are beyond the established scalar-necessity onset.
            scalar = 2*bounded['tau']-int(bounded['short_sufficient'])
            assert closed_value(n,m) == scalar
            large_checks.append({'m':m,'n':n,'time':scalar})
    source = Path(__file__).read_bytes()
    receipt = {'status':'PASS','scope':'Exhaustive finite short-length certificate. Combine with the accepted eventual-scalar theorem for all odd lengths; no new general-width midpoint proof.',
               'source_sha256':hashlib.sha256(source).hexdigest(),
               'cases':len(rows),'quota_transitions':sum(r['quota_transitions'] for r in rows),
               'largest_full_frontier':max(r['maximum_frontier'] for r in rows),
               'ranges':ranges,'seconds':process_time()-started,
               'large_residue_checks':large_checks,'rows':rows}
    Path('research/bridge-odd-clock-width-seven-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print({k:v for k,v in receipt.items() if k not in ('rows','large_residue_checks')})


if __name__ == '__main__':
    main()

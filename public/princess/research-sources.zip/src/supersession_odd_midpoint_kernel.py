"""Explicit root convolution and a constant-size midpoint invariant check.

The convolution formula is proved. Universal closure of the proposed
two-segment envelope is not proved; this module tests that precise claim.
"""
from math import isqrt
from supersession_solo_bands import OddRectangle, R, rho


def opposed_candidates(S, lo, hi):
    assert 0 <= lo <= hi <= S
    r = rho(lo)
    s = R(S-hi)
    return {min(hi, r*(r+1)), max(lo, S-s*s)}


def convolution_max(G, S, lo, hi):
    """Max I0(y)+I1(S-y), exact in at most seven explicit evaluations."""
    assert 0 <= lo <= hi <= S <= G.M
    candidates = set()
    if hi == G.M:
        candidates.add(hi)
        hi -= 1
    if lo <= hi:
        candidates.update((lo, hi))
        candidates.update(opposed_candidates(S, lo, hi))
        candidates.update(G.M-z for z in opposed_candidates(
            G.E+G.M-S, G.M-hi, G.M-lo))
    return max((G.inverse(0,y)+G.inverse(1,S-y), y) for y in candidates)


def envelope(G, a, b):
    A=max(a,b)
    K=max(G.E,a+b)
    color=int(b>a)
    low=min(A,K-A)
    H=(K-G.C[color])//2
    segments=[(low,max(0,low-a),min(b,low))]
    left,right=max(0,A-a),min(b,A)
    if color==0:right=min(right,H)
    else:left=max(left,A-H)
    if left<=right:segments.append((A,left,right))
    return {'A':A,'K':K,'color':color,'low':K-A,'H':H,'segments':segments}


def closure(G,m,a,b):
    aa=G.inverse(0,b+m)
    bb=G.inverse(1,a+m)
    assert aa<G.E and bb<G.M and max(a,b)+m<=G.M
    old,new=envelope(G,a,b),envelope(G,aa,bb)
    checks=[]
    for size,source_left,source_right in old['segments']:
        left,right=source_left,source_right
        total=size+m
        right+=m
        if new['color']==0:
            right=min(right,total-G.profile(1,new['H']+1))
        else:
            left=max(left,G.profile(0,new['H']+1))
        if left>right:continue
        value,Y=convolution_max(G,total,left,right)
        checks.append((value,Y,size,left,right))
        if value>new['low']:
            # Recover a concrete legal source on this segment.
            source_y=max(source_left,Y-m)
            assert source_y<=source_right and source_y<=Y
            source_x=size-source_y
            quota1=Y-source_y
            return False, {'old':[a,b],'new':[aa,bb],'old_envelope':old,
                           'new_envelope':new,'input_total':total,
                           'Y':Y,'value':value,'source':[source_x,source_y],
                           'quota0':m-quota1,'checks':checks}
    return True, {'old':[a,b],'new':[aa,bb],'checks':checks}

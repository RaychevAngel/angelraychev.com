#!/usr/bin/env python3
"""Independent physical-graph checks for the 3×3×3 five-probe theorem.

No import from the search code. Triple expansion is also proved geometrically
in research/three-cube-feasibility.md. The witness is a directly specified list.
"""
from itertools import product, combinations
from pathlib import Path
from time import monotonic
import json


def check():
    begin = monotonic()
    vertices = set(product(range(3), repeat=3))
    distance = lambda a, b: sum(abs(x-y) for x, y in zip(a, b))
    adjacency = {v: {w for w in vertices if distance(v, w) == 1} for v in vertices}
    def move(belief):
        return set().union(*(adjacency[v] for v in belief)) if belief else set()
    triples = []
    for p in (0, 1):
        cohort = sorted(v for v in vertices if sum(v) % 2 == p)
        minimum = 27
        total = 0
        equality = 0
        median_cases = 0
        for abc in combinations(cohort, 3):
            total += 1
            sizes = [len(adjacency[a]) for a in abc]
            overlaps = [len(adjacency[a] & adjacency[b]) for a, b in combinations(abc, 2)]
            assert max(overlaps) <= 2
            if min(overlaps) > 0:
                median_cases += 1
                q = tuple(sorted(a[i] for a in abc)[1] for i in range(3))
                assert all(distance(a, q) == 1 for a in abc)
            if p == 0 and sizes == [3, 3, 3]:
                assert sum(overlaps) <= 2
            union = move(abc)
            assert len(union) >= 7
            assert len(union) == sum(sizes)-sum(overlaps)+len(set.intersection(*(adjacency[a] for a in abc)))
            minimum = min(minimum, len(union))
            equality += len(union) == 7
        triples.append(dict(parity=p, triples=total, minimum_neighbors=minimum,
                            equality_cases=equality, median_cases=median_cases))
    encoded_phase = [
        "001 010 012 100 102", "011 020 101 110 200", "012 021 102 111 120",
        "022 101 110 112 121", "100 102 111 120 122", "101 110 112 121 200",
        "102 111 120 201 210", "022 112 121 202 211", "120 122 210 212 221",
    ]
    phase = [{tuple(map(int, xyz)) for xyz in row.split()} for row in encoded_phase]
    for day, shots in enumerate(phase):
        assert len(shots) == 5 and shots <= vertices
        assert all(sum(v) % 2 == (1-day) % 2 for v in shots)
    def replay(initial, shots):
        belief = set(initial)
        beliefs = [sorted(belief)]
        for s in shots:
            belief = move(belief-s)
            beliefs.append(sorted(belief))
        assert not belief
        return dict(days=len(shots), belief_sizes=[len(b) for b in beliefs],
                    beliefs=beliefs, shots=[sorted(s) for s in shots])
    odd = {v for v in vertices if sum(v) % 2}
    return dict(
        scope="Independent geometry checks and explicit witnesses; eighteen is an upper bound, not a claimed optimum.",
        vertices=len(vertices), directed_adjacencies=sum(map(len, adjacency.values())),
        triples=triples, odd_cohort=replay(odd, phase),
        full_board=replay(vertices, phase*2), seconds=monotonic()-begin,
    )


if __name__ == "__main__":
    result = check()
    root = Path(__file__).resolve().parents[1]
    (root/"research/three-cube-independent-checks.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(dict(triples=result["triples"],
                          full_board_days=result["full_board"]["days"],
                          full_board_belief_sizes=result["full_board"]["belief_sizes"],
                          seconds=result["seconds"]), indent=2))

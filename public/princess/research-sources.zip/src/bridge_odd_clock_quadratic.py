"""A bounded-operation solo evaluator in a fixed quadratic-surplus region.

Choose K once, independently of the board. On 2*K*m >= K*w+b*b,
the algorithm uses at most 3*K+1 paired updates and one bulk division.
It evaluates the proved solo dynamics; it does not assert midpoint necessity.
"""
from supersession_solo_bands import OddRectangle


def evaluate(w, n, m, p, *, K=16, start=None, at_day=None):
    G = OddRectangle(w, n)
    b = G.b
    assert b >= 2 and K >= 1 and m >= b + 1
    D = 2 * m - w
    assert K * D >= b * b
    x = G.C[p] if start is None else start
    assert 0 <= x <= G.C[p]
    assert at_day is None or at_day >= 0
    H = b * b + 1
    lo = 2 * m + H - (b + p)
    hi = m + G.M - H
    elapsed = paired_calls = bulk_pairs = 0

    def advance_pair():
        nonlocal x, elapsed, paired_calls
        if x == 0 or at_day is not None and elapsed >= at_day:
            return
        paired_calls += 1
        x = G.step(p, x, m)
        elapsed += 1
        if x == 0 or at_day is not None and elapsed >= at_day:
            return
        x = G.step(1-p, x, m)
        elapsed += 1

    for _ in range(K):
        if x > hi:
            advance_pair()

    stopped = x == 0 or at_day is not None and elapsed >= at_day
    if not stopped:
        assert x <= hi
        if lo <= x <= hi:
            bulk_pairs = (x-lo)//D + 1
            if at_day is not None:
                bulk_pairs = min(bulk_pairs, (at_day-elapsed)//2)
            x -= bulk_pairs * D
            elapsed += 2 * bulk_pairs

    for _ in range(2*K+1):
        advance_pair()

    if at_day is None:
        assert x == 0, (w, n, m, p, K, x, lo, hi)
    else:
        assert x == 0 or elapsed == at_day
    assert paired_calls <= 3*K+1
    return {'time': elapsed, 'count': x, 'paired_calls': paired_calls,
            'bulk_pairs': bulk_pairs, 'K': K}


def half_time(w, n, m, *, K=16):
    G = OddRectangle(w, n)
    times = [evaluate(w, n, m, p, K=K)['time'] for p in (0, 1)]
    tau = min(times)
    L = tau-1
    residuals = [evaluate(w, n, m, p ^ (L % 2), K=K,
                          at_day=L)['count'] for p in (0, 1)]
    return {'solo_times': times, 'tau': tau,
            'precentral_residuals': residuals,
            'lower': 2*tau-1, 'upper': 2*tau,
            'short_sufficient': sum(residuals) <= m,
            'scope': 'Exact solo values and known one-day interval; no new midpoint necessity.'}


if __name__ == '__main__':
    from pathlib import Path
    from time import process_time
    import json
    started = process_time()
    rows = []
    for K in (1, 4, 16):
        for b in (2, 3, 4, 7, 10, 20, 40, 80):
            w = 2*b+1
            threshold = (w+(b*b+K-1)//K+1)//2
            for m in sorted({max(b+1, threshold), max(b+1, threshold+1), b*b}):
                if K*(2*m-w) < b*b:
                    continue
                for n in (w, w+2, 5*w, 10**12+1):
                    G = OddRectangle(w, n)
                    actual = half_time(w, n, m, K=K)
                    expected = G.half_time(m)
                    for key in ('solo_times', 'tau', 'precentral_residuals', 'short_sufficient'):
                        assert actual[key] == expected[key], (K,w,n,m,key,actual,expected)
                    tests = 0
                    calls = 0
                    for p in (0, 1):
                        for start in sorted({0, m, min(G.C[p],m+1), G.C[p]//2, G.C[p]}):
                            if start > G.C[p]:
                                continue
                            reference = G.solo(p,m,start=start)
                            result = evaluate(w,n,m,p,K=K,start=start)
                            assert result['time'] == reference['time']
                            calls = max(calls,result['paired_calls'])
                            for day in sorted({0,1,reference['time']//2,max(0,reference['time']-1),reference['time'],reference['time']+3}):
                                result = evaluate(w,n,m,p,K=K,start=start,at_day=day)
                                assert result['count'] == G.solo(p,m,start=start,at_day=day)
                                calls = max(calls,result['paired_calls'])
                                tests += 1
                    rows.append({'K':K,'b':b,'w':w,'n':n,'m':m,
                                 'tau':actual['tau'],'count_checks':tests,
                                 'largest_paired_calls':calls})
    receipt = {'status':'PASS','scope':'Independent comparison with the accepted O(width) band evaluator. No midpoint or full-formula conclusion.',
               'seconds':process_time()-started,'cases':len(rows),
               'count_checks':sum(r['count_checks'] for r in rows),'rows':rows}
    Path('research/bridge-odd-clock-quadratic-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print({k:v for k,v in receipt.items() if k != 'rows'})

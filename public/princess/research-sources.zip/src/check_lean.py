"""Recheck project Lean sources sequentially and save source-specific evidence."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--lean',default=shutil.which('lean') or '/Users/angel/code/math/polyominoes/.tools/lean-4.33.1-darwin_aarch64/bin/lean')
parser.add_argument('--files',nargs='*')
args=parser.parse_args()
sources={p.stem:p for p in (root/'lean').glob('*.lean') if p.name!='lakefile.lean'}
selected=set(args.files or sources)
ordered=[]
visiting=set()
def visit(name):
    if name in ordered:return
    if name in visiting:raise RuntimeError('Cyclic local Lean imports')
    visiting.add(name)
    for mod in re.findall(r'^import\s+([A-Za-z0-9_.]+)',sources[name].read_text(),re.M):
        if mod in sources:visit(mod)
    ordered.append(name)
    visiting.remove(name)
for name in sorted(selected):visit(name)
build=root/'.build/lean'
build.mkdir(parents=True,exist_ok=True)
env=dict(os.environ)
env['LEAN_PATH']=str(build)
version=subprocess.run([args.lean,'--version'],capture_output=True,text=True,check=True).stdout.strip()
records=[]
begin=time.monotonic()
for name in ordered:
    p=sources[name]
    raw=p.read_bytes()
    if re.search(r'^\s*(?:axiom|unsafe|opaque)\b',raw.decode(),re.M):
        raise RuntimeError(f'Review explicit trusted declaration in {p.name}')
    start=time.monotonic()
    result=subprocess.run([args.lean,'-j1','-o',str(build/(name+'.olean')),str(p)],cwd=root/'lean',env=env,capture_output=True,text=True,timeout=300)
    output=result.stdout+result.stderr
    record={'file':str(p.relative_to(root)), 'sha256':hashlib.sha256(raw).hexdigest(),
            'exit_code':result.returncode, 'seconds':time.monotonic()-start,'output':output,
            'contains_sorryAx':'sorryAx' in output}
    records.append(record)
    print(name,'PASS' if result.returncode==0 and not record['contains_sorryAx'] else 'FAIL',flush=True)
    if result.returncode or record['contains_sorryAx']:break
receipt={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'compiler':version,
         'command_policy':'Sequential compilation with -j1; local imports built first; no package installation.',
         'seconds':time.monotonic()-begin,'all_passed':len(records)==len(ordered) and all(r['exit_code']==0 and not r['contains_sorryAx'] for r in records),
         'scope':'Successful compilation proves the declarations in these exact sources. Mathematical coverage is described separately in lean/README.md.',
         'files':records}
(root/'research/lean-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
if not receipt['all_passed']:raise SystemExit(1)
print('All selected Lean modules checked in',round(receipt['seconds'],3),'seconds.')

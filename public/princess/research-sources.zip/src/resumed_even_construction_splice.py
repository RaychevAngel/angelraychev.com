"""One left-prefix / root-credit transport / right-prefix tail upper family.

All optimizations here are research diagnostics. The transport itself is a
proved direct rule, but a uniform rule for selecting splice indices is open.
"""
from collections import deque
from pathlib import Path
import json,time
from resumed_even_construction_prefix import PrefixGame
from resumed_even_construction_formula_profile import build
from resumed_even_construction_transport import construct,height,neighborhood


def model_clock(w,n,k):
    from resumed_even_construction_formula_clock import clock
    tau,sizes,_=clock(w,n,k)
    return tau,sizes


def prefix_path(game,k,p,mask,order):
    shots=[];beliefs=[mask]
    while mask:
        q=max(mask.bit_count()-k,0)
        survivor=game.orders[p][order][q]
        assert not survivor&~mask
        shot=mask^survivor
        shots.append({v for i,v in enumerate(game.colors[p])if shot>>i&1})
        mask=game.hood(p,survivor);p=1-p;beliefs.append(mask)
        assert len(shots)<4*game.w*game.n
    return shots,beliefs


def run(w=12,n=12,k=7):
    started=time.monotonic();game=PrefixGame(w,n);h=w*n//2
    tau,clock=model_clock(w,n,k)
    left,beliefs=prefix_path(game,k,0,game.full,0)
    tails={}
    for p in range(2):
        for q in range(h+1):
            mask=game.orders[p][4][q]
            shots,_=prefix_path(game,k,p,mask,4)
            tails[p,q]=shots
    candidates=[];best_slack=-10**9;best_miss=None
    for end in range(1,tau):
        p=end%2
        feasible=[q for q in range(h+1)if len(tails[p,q])<=tau-end]
        q=max(feasible)
        B={v for i,v in enumerate(game.colors[p])if game.orders[p][4][q]>>i&1}
        b=height(w,n,p,B)
        credit=sum(b[x]<0 and(p-x)%2==0 for x in range(w))
        for entry in range(min(end,len(beliefs))):
            A={v for i,v in enumerate(game.colors[entry%2])if beliefs[entry]>>i&1}
            a=height(w,n,entry%2,A);t=end-entry
            F=sum(max(x-y+t,0)for x,y in zip(a,b))//2
            slack=k*t+credit-F
            row={'entry':entry,'end':end,'t':t,'target_size':q,'entry_size':len(A),
                 'virtual_cost':F,'root_credit':credit,'slack':slack}
            if slack>best_slack:best_slack=slack;best_miss=row
            if slack>=0:candidates.append((row,a,b,A,B))
    result={'shape':[w,n],'budget':k,'model_solo_clock':tau,'model_sizes':clock,
            'one_prefix_days':len(left),'successful_splices':len(candidates),
            'best_slack':best_slack,'best_pair':best_miss,'seconds':time.monotonic()-started,
            'scope':'One-transport constructive upper family versus necessary corner solo clock; no uniform attainment claim.'}
    if candidates:
        row,a,b,A,B=max(candidates,key=lambda item:(item[0]['slack'],-item[0]['t']))
        bridge,receipt=construct(w,n,row['entry']%2,a,b,row['t'],k,boundary_credit=True)
        solo=left[:row['entry']]+bridge+tails[row['end']%2,row['target_size']]
        physical=set(game.colors[0]);first=None
        for day,shot in enumerate(solo,1):
            assert len(shot)<=k
            physical-=shot
            if not physical and first is None:first=day
            physical=neighborhood(w,n,physical)
        assert first==tau and not physical
        physical={(x,y)for x in range(w)for y in range(n)};full=None
        for day,shot in enumerate(solo+solo[::-1],1):
            physical-=shot
            if not physical and full is None:full=day
            physical=neighborhood(w,n,physical)
        assert not physical
        result.update(selected=row,transport_receipt=receipt,solo_capture=first,
                      full_capture=full,physical_replay_passed=True,
                      schedule=[sorted(s)for s in solo],
                      successful_pairs=[x[0]for x in candidates])
    return result


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--w',type=int,default=12)
    p.add_argument('--n',type=int);p.add_argument('--k',type=int,default=7);a=p.parse_args()
    n=a.n or a.w;out=run(a.w,n,a.k)
    Path(f'research/resumed-even-construction-splice-{a.w}x{n}-k{a.k}.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k not in('schedule','successful_pairs')})

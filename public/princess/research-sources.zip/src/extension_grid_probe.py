"""A strictly bounded follow-up for three-row and wider grids.

Finite optimal values are evidence only; no formula is inferred by this file.
"""
import json
from pathlib import Path
import time
from exact_grid_cases import make_grid, solve


def main():
    started = time.monotonic()
    deadline = started + 30
    cases = [((3, 5), [2, 3, 4, 5]), ((3, 6), [2, 3, 4]),
             ((4, 4), [2, 3, 4, 5]), ((2, 2, 3), [2, 3, 4])]
    rows = []
    output = Path(__file__).resolve().parents[1] / 'research' / 'extension-grid-probe.json'
    for shape, budgets in cases:
        if time.monotonic() >= deadline:
            break
        coords, adjacent, neighborhoods = make_grid(shape)
        for m in budgets:
            if time.monotonic() >= deadline:
                break
            begin = time.monotonic()
            result = dict(shape=shape, m=m, vertices=coords)
            result.update(solve(coords, adjacent, neighborhoods, m, deadline))
            result['seconds'] = time.monotonic() - begin
            rows.append(result)
            output.write_text(json.dumps({
                'provenance': 'New bounded September 2026 research; not original 2020 notes',
                'method': 'Full-belief BFS with independent set-based witness replay; no sweep restriction',
                'budget_seconds': 30,
                'seconds': time.monotonic() - started,
                'results': rows,
            }, indent=2) + '\n')
            print(shape, m, result['status'], result.get('minimum_turns'),
                  round(result['seconds'], 3), flush=True)
    print('Elapsed', round(time.monotonic() - started, 3), flush=True)


if __name__ == '__main__':
    main()

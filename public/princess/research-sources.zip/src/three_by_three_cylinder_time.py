#!/usr/bin/env python3
"""Exact certificate: T5(P3 square P3 square Pn)=18n-36 for odd n>=3.

The finite checks combine with the already proved affine-insertion lemma.
All arithmetic is exact. Physical neighborhoods and serial room schedules
are checked directly, independently of the local-cost profile formula.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from time import monotonic
import json
from odd_minimum_budget_pumping import ranks
from odd_minimum_budget_all_lengths import verify_potential,serial_witness

CHARGES=[[F(x)for x in(0,0,'1/3','2/3',1,1)]]*2
BASE_RANKS=[[1,2,3,5,8],[1,2,4,6]]
BASE_WEIGHTS=[[2,1,1,0,0],[2,1,1,0]]


def table_profiles(H):
    out=[]
    for p in(0,1):
        row=[0]
        for k in range(1,H-p+1):
            u=sum(a for r,a in zip(BASE_RANKS[p],BASE_WEIGHTS[p])if r<=k)
            tail=sum(r<=H-p-k for r in BASE_RANKS[p])
            row.append(k+p+u-len(BASE_RANKS[p])+tail)
        out.append(row)
    return out


def physical(n):
    shape=(3,3,n);vertices=list(product(*(range(s)for s in shape)))
    order=[sorted((v for v in vertices if sum(v)%2==p),
                  key=lambda v:(sum(v),tuple(-x for x in v)))for p in(0,1)]
    adj={}
    for v in vertices:
        adj[v]=set()
        for j in range(3):
            for d in(-1,1):
                if 0<=v[j]+d<shape[j]:
                    w=list(v);w[j]+=d;adj[v].add(tuple(w))
    profile=[]
    for p in(0,1):
        hood=set();row=[0]
        for v in order[p]:
            hood.update(adj[v]);row.append(len(hood))
            assert hood==set(order[1-p][:len(hood)])
        profile.append(row)
    assert profile==table_profiles((9*n+1)//2)
    for p in(0,1):
        found=[i+1 for i,v in enumerate(order[p])if v[2]==0]
        assert found==BASE_RANKS[p]
    # Actual-room replay of the minority-first serial schedule.
    a,b=len(order[1]),len(order[0]);p=1;belief=set(vertices);days=0
    while a or b:
        qa=min(a,5);qb=min(b,5-qa)
        shots=set(order[p][a-qa:a])|set(order[1-p][b-qb:b])
        assert len(shots)<=5 and shots<=belief
        survivor=belief-shots
        belief=set().union(*(adj[v]for v in survivor))if survivor else set()
        a,b=profile[p][a-qa],profile[1-p][b-qb];p=1-p;days+=1
        assert belief==set(order[p][:a])|set(order[1-p][:b])
    assert days==18*n-36
    return profile,days


if __name__=='__main__':
    start=monotonic();rows=[];checks=0
    for n in(3,5,7,9,11):
        g,days=physical(n);f=ranks(g,CHARGES)
        verify_potential(g,5,CHARGES,f)
        lower=f[0][-1]+f[1][-1]
        assert lower==days==18*n-36
        checks+=6*sum(map(len,g))
        rows.append({'length':n,'majority_size':len(g[0])-1,'potential_lower':str(lower),
                     'physical_serial_days':days,'direct_neighborhoods_match_tables':True})
    H=50;cut=25;D=6;radius=8
    assert cut>=radius+2*D and H-cut>=radius+2*D+2
    alpha=[F(-14),F(-13)]
    for p in(0,1):
        assert all(f[p][k]==2*k+alpha[p]for k in range(cut-2*D,cut+2*D+1))
    days,hits=serial_witness(g,5,1,cut)
    assert days==162 and all(hits)
    for delta in(1,9,19,90):
        gg=table_profiles(H+delta)
        ff=[[f[p][k]if k<=cut else
             f[p][cut]+2*(k-cut)if k<=cut+delta else
             f[p][k-delta]+2*delta for k in range(len(gg[p]))]for p in(0,1)]
        verify_potential(gg,5,CHARGES,ff)
        assert ff[0][-1]+ff[1][-1]==162+4*delta
    result={'scope':'Exact finite premises for the ordinary affine-insertion lemma; together prove all odd n>=3.',
            'formula':'T5(3x3xn)=18n-36 for odd n>=3',
            'seconds':monotonic()-start,'base_rank_positions':BASE_RANKS,
            'base_cost_weights':BASE_WEIGHTS,
            'charges':[[str(x)for x in row]for row in CHARGES],
            'finite_physical_cases':rows,'exact_one_cohort_inequalities':checks,
            'base_length':11,'base_majority_size':H,'cut':cut,'profile_corner_radius':radius,
            'collar': [cut-2*D,cut+2*D],'collar_alpha':[str(x)for x in alpha],
            'both_serial_cohorts_hit_cut':all(hits),
            'insertion_attacks':[1,9,19,90],
            'base_potentials':[[str(x)for x in row]for row in f]}
    Path(__file__).resolve().parents[1].joinpath('research/three-by-three-cylinder-time.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='base_potentials'},indent=2))

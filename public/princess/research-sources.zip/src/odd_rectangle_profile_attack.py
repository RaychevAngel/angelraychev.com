#!/usr/bin/env python3
"""Exact odd-rectangle profiles using proved odd-path compression.

All common fixed states of coordinate spacing-two prefix compression are
pairs of Ferrers diagrams. Enumerating those suffices for arbitrary supports
by the N-subcommuting compression theorem. No cross-width extrapolation.
"""
from itertools import product
from math import comb
from pathlib import Path
from time import monotonic
import argparse,json


def decreasing_sequences(length,cap):
    if length==0:
        yield ()
    else:
        for first in range(cap+1):
            for tail in decreasing_sequences(length-1,first):
                yield (first,)+tail


def data(shape):
    points=[list(),list()]
    for v in product(*(range(n) for n in shape)):points[sum(v)%2].append(v)
    ids=[{v:i for i,v in enumerate(row)}for row in points]
    neighbors=[]
    for p,row in enumerate(points):
        nbr=[]
        for v in row:
            mask=0
            for d in(0,1):
                for sign in(-1,1):
                    w=list(v);w[d]+=sign;w=tuple(w)
                    if w in ids[1-p]:mask|=1<<ids[1-p][w]
            nbr.append(mask)
        neighbors.append(nbr)
    return points,ids,neighbors


def masks_for_pattern(shape,pattern,ids,neighbors):
    xs=list(range(pattern[0],shape[0],2));ys=list(range(pattern[1],shape[1],2))
    p=sum(pattern)%2
    for heights in decreasing_sequences(len(xs),len(ys)):
        mask=nbr=0
        for x,h in zip(xs,heights):
            for y in ys[:h]:
                i=ids[p][x,y];mask|=1<<i;nbr|=neighbors[p][i]
        yield(mask,nbr)


def run(shape,tie_axis=0):
    start=monotonic()
    assert len(shape)==2 and all(n%2 for n in shape)
    points,ids,neighbors=data(shape)
    patterns={r:list(masks_for_pattern(shape,r,ids,neighbors)) for r in product((0,1),repeat=2)}
    minima=[];witnesses=[];counts=[]
    for p in(0,1):
        parts=[v for r,v in patterns.items()if sum(r)%2==p]
        profile=[len(points[1-p])+1]*(len(points[p])+1);argmins=[0]*len(profile)
        for a,na in parts[0]:
            for b,nb in parts[1]:
                s=a|b;k=s.bit_count();cost=(na|nb).bit_count()
                if cost<profile[k]:profile[k]=cost;argmins[k]=s
        minima.append(profile);witnesses.append(argmins);counts.append(len(parts[0])*len(parts[1]))
    prefix_masks=[];prefix_neighbors=[]
    for p in(0,1):
        order=sorted(points[p],key=lambda v:(sum(v),v[tie_axis]))
        masks=[0];nbs=[0]
        for v in order:
            i=ids[p][v];masks.append(masks[-1]|1<<i);nbs.append(nbs[-1]|neighbors[p][i])
        prefix_masks.append(masks);prefix_neighbors.append(nbs)
    failures=[]
    for p in(0,1):
        for k,nb in enumerate(prefix_neighbors[p]):
            if nb.bit_count()!=minima[p][k]:
                if len(failures)<4:
                    s=witnesses[p][k]
                    failures.append({'parity':p,'size':k,'minimum':minima[p][k],
                         'prefix_neighborhood':nb.bit_count(),
                         'witness':[v for i,v in enumerate(points[p])if s>>i&1],
                         'prefix':[v for i,v in enumerate(points[p])if prefix_masks[p][k]>>i&1]})
    return {'shape':shape,'increasing_tie_axis':tie_axis,'fixed_counts':counts,'minima':minima,
            'long_first_prefix_isoperimetric':not failures,
            'prefix_neighborhoods_nested':all(nb==prefix_masks[1-p][nb.bit_count()] for p in(0,1)for nb in prefix_neighbors[p]),
            'failures':failures,'seconds':round(monotonic()-start,4)}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('shapes',nargs='*');args=parser.parse_args()
    shapes=[tuple(map(int,s.split('x')))for s in args.shapes] or[(7,5),(9,5),(7,7),(9,7),(11,7),(9,9)]
    start=monotonic();rows=[run(s)for s in shapes]
    result={'scope':'Exact arbitrary-support neighborhood profiles via proved odd-path compression; diagonal nesting remains a conjecture outside the listed finite boxes.','results':rows,'seconds':round(monotonic()-start,4)}
    path=Path(__file__).resolve().parents[1]/'research'/'odd-rectangle-profile-attack.json'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

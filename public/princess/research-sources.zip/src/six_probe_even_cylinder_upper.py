"""Replay the two exceptional initial moves plus a six-probe prefix sweep.
This is an upper-bound verifier, not an optimality certificate.
"""
import json
from pathlib import Path
from even_three_by_three_cylinder_attack import hood
from nested_grid_time import ordered_profiles, neighborhood

def verify(n):
    assert n >= 4 and n % 2 == 0
    _, data = ordered_profiles((3,3,n), weightlex=True)
    coords, adj, orders, prefixes, profiles = data
    h = 9*n//2
    slice_orders = {(p,j):sorted([i for i,v in enumerate(coords) if v[2]==j and sum(v)%2==p], key=lambda i:(sum(coords[i][:2]),-coords[i][0],-coords[i][1])) for p in (0,1) for j in range(n)}
    def mask(counts,p):
        return sum(1<<i for j,c in enumerate(counts) for i in slice_orders[p,j][:c])
    reflection = {i:coords.index((v[0],v[1],n-1-v[2])) for i,v in enumerate(coords)}
    def reflect(S):
        return sum(1<<reflection[i] for i in range(len(coords)) if S>>i&1)
    shots=[];phase=1;current=prefixes[1][h]
    for counts in ([4,5]*(n//2-1)+[2,1], [5,4]*(n//2-1)+[1,0]):
        survivor=mask(counts,phase)
        assert survivor&~current==0 and (current^survivor).bit_count()==6
        shots.append(current^survivor)
        current=neighborhood(survivor,adj);phase^=1
    trace=[current.bit_count()]
    while current:
        survivor=prefixes[phase][max(0,current.bit_count()-6)]
        assert survivor&~current==0
        shots.append(current^survivor)
        current=neighborhood(survivor,adj);phase^=1
        trace.append(current.bit_count())
    assert len(shots)==3*n-4 and len(shots)%2==0
    all_shots=shots+[reflect(S) for S in shots]
    belief=(1<<len(coords))-1
    for S in all_shots:
        assert S.bit_count()<=6 and not S&~belief
        belief=neighborhood(belief&~S,adj)
    assert belief==0 and len(all_shots)==6*n-8
    return {'n':n,'solo_days':len(shots),'days':len(all_shots),'trace_after_two_days':trace,'physical_replay':True}

if __name__=='__main__':
    receipt={'scope':'Physical upper bounds only; the all-even proof is in the accompanying research note.','cases':[verify(n) for n in (4,6,8,10,12,20,30)]}
    path=Path(__file__).resolve().parents[1]/'research'/'six-probe-even-cylinder-upper.json'
    path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({x['n']:x['days'] for x in receipt['cases']}))

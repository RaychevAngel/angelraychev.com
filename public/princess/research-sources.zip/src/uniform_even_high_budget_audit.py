#!/usr/bin/env python3
"""Independent coordinate reconstruction of the backward-pyramid upper."""
from math import isqrt
from pathlib import Path
from time import process_time
import json

def run_case(b,n,m,return_schedule=False):
    w=2*b;h=b*n;d=m-b;q,r=divmod(h-b,d)
    verts={(x,y) for x in range(w) for y in range(n)}
    colors=[{v for v in verts if sum(v)%2==p} for p in (0,1)]
    def N(S):return {(u,v) for x,y in S for u,v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if (u,v) in verts}
    def pyramid(S):return all((u,y-1) in S for x,y in S if y>0 for u in (x-1,x+1) if 0<=u<w)
    def enlarge(S,target):
        p=next(iter(S))[0]+next(iter(S))[1] if S else enlarge.phase
        p%=2;A=set(S)
        for v in sorted(colors[p],key=lambda v:(v[1],v[0])):
            if len(A)==target:break
            if v not in A:A.add(v)
        assert len(A)==target and pyramid(A)
        return A
    R=set(sorted(colors[0],key=lambda v:(sum(v),-v[0]))[:r]);p=0
    assert pyramid(R)
    X=N(R);J=0 if r==0 else r+min(isqrt(r)+(isqrt(r)**2<r),b)
    assert len(X)<=J
    reverse=[]
    for _ in range(q-1):
        enlarge.phase=p;A=enlarge(R,len(R)+m);reverse.append(A-R)
        assert len(A)>b*b
        heights=[max(y for xx,y in A if xx==x) for x in range(w)]
        E={v for v in colors[1-p] if v[1]<=heights[v[0]]-1}
        assert pyramid(E) and len(E)==len(A)-b and N(E)<=A
        R=E;p^=1
    assert len(colors[p]-R)==m
    reverse.append(colors[p]-R);half=list(reversed(reverse))
    S=set(colors[p])
    for shots in half:S=N(S-shots)
    assert S<=X
    if r==0:
        shots=half+list(reversed(half));want=2*q
    elif 2*J<=m:
        reflect=lambda A:{(w-1-x,y) for x,y in A}
        shots=half+[X|reflect(X)]+[reflect(A) for A in reversed(half)];want=2*q+1
    else:
        solo=half+[X];shots=solo+list(reversed(solo));want=2*q+2
    S=set(verts);first=None
    for t,A in enumerate(shots,1):
        assert len(A)<=m
        S-=A
        if not S and first is None:first=t
        S=N(S)
    assert not S and len(shots)==want and first==want,(b,n,m,want,first)
    result=dict(width=w,length=n,budget=m,q=q,r=r,minimum=want)
    if return_schedule:result["schedule"]=[sorted(A) for A in shots]
    return result

def main():
    start=process_time();cases=[]
    for b in range(1,7):
        for n in range(2*b,2*b+5):
            for m in range(b*b+1,b*n):cases.append(run_case(b,n,m))
    out=dict(status='PASS',cases=cases,cpu_seconds=process_time()-start,scope='Independent actual-room reconstruction and replay; mathematical lower and upper proofs audited separately.')
    Path('research/uniform-even-high-budget-independent-check.json').write_text(json.dumps(out,indent=2)+'\n')
    print(dict(status=out['status'],cases=len(cases),cpu_seconds=out['cpu_seconds']))
if __name__=='__main__':main()

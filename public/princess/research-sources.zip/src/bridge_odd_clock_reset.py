"""Deadline-only scalar necessity from a recent solo reset.

Uses no joint-state optimization to issue its certificate. The audit
compares issued certificates with the separately proved exact joint solver.
"""
from pathlib import Path
from time import process_time
import hashlib
import json

from bridge_odd_clock_quadratic import evaluate, half_time
from supersession_solo_bands import OddRectangle


def certificate(w, n, m, K=16, J=16):
    G = OddRectangle(w,n)
    assert G.b >= 2 and G.b+1 <= m < G.M
    assert K*(2*m-w) >= G.b*G.b
    info = half_time(w,n,m,K=K)
    L = info['tau']-1
    deficits = {L: tuple(G.C[p]-info['precentral_residuals'][p] for p in (0,1))}
    for age in range(1,J+2):
        t = L-age
        if t < 0:
            continue
        deficits[t] = tuple(G.C[p]-evaluate(w,n,m,p^(t%2),K=K,at_day=t)['count']
                            for p in (0,1))
    D = deficits[L]
    primary = int(D[1] > D[0])
    secondary = 1-primary
    critical = (G.C[secondary]-m+1)//2
    short = [(0,0)]
    for _ in range(J):
        x,y = short[-1]
        short.append((G.inverse(0,y+m),G.inverse(1,x+m)))
    witnesses = []
    for age in range(J+1):
        i = L-age
        if i < 0:
            continue
        gap = deficits[i][0]-deficits[i][1]
        old_gap = 0 if i == 0 else deficits[i-1][0]-deficits[i-1][1]
        if gap*old_gap >= 0 and short[age][secondary] < critical:
            witnesses.append(dict(reset_time=i, age=age, gap=gap, previous_gap=old_gap,
                                  secondary_bound=short[age][secondary]))
    certified = info['short_sufficient'] or D[0] == D[1] or bool(witnesses)
    scalar_time = 2*info['tau']-int(info['short_sufficient'])
    return dict(shape=[w,n], budget=m, K=K, J=J, L=L,
                solo_deficits=D, critical_secondary=critical,
                reset_witnesses=witnesses, certified=certified,
                certified_time=scalar_time if certified else None,
                scalar_candidate=scalar_time,
                short_sufficient=info['short_sufficient'])


def main():
    from supersession_odd_midpoint_bounded import solve
    started = process_time()
    rows = []
    for b in (3,4,5,7,10,15,20,30):
        w=2*b+1
        for n in (w,w+2,3*w):
            for m in sorted({b+2,2*b,(b*b+1)//2,b*b}):
                if m <= b+1 or 16*(2*m-w) < b*b:
                    continue
                row=certificate(w,n,m)
                answer=solve(w,n,m)
                if row['certified']:
                    assert row['certified_time'] == answer['time']
                row['independent_exact_time']=answer['time']
                rows.append(row)
    result=dict(status='PASS', scope=__doc__,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                rows=rows, seconds=process_time()-started)
    Path('research/bridge-odd-clock-reset-check.json').write_text(json.dumps(result,indent=2)+'\n')
    print(dict(status='PASS', cases=len(rows),certified=sum(r['certified'] for r in rows),
               necessity_certificates=sum(bool(r['reset_witnesses']) and not r['short_sufficient'] for r in rows),
               seconds=result['seconds']))


if __name__ == '__main__':
    main()

"""Independent literal-board attack on the proposed all-radius band theorem.

Enumerates original supports, with no compression and no capacity formulas.
The tested domain is deliberately small; this is not a uniform proof.
"""
from pathlib import Path
from itertools import combinations
import json,time

def check(w,n,r):
    started=time.process_time();D=max(r*(r-1)//2,r*(r-2));C=r*(r-1)
    rooms=[(x,y)for y in range(w)for x in range(n)]
    colors=[[v for v in rooms if sum(v)%2==p]for p in(0,1)]
    corner_set={(0,0),(0,w-1),(n-1,0),(n-1,w-1)}
    checked=hits=0;witnesses=[]
    for phase in(0,1):
        own,other=colors[phase],colors[1-phase];ids={v:i for i,v in enumerate(other)}
        owncorners={i for i,v in enumerate(own)if v in corner_set}
        masks=[]
        for x,y in own:
            masks.append(sum(1<<ids[v]for v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1))if v in ids))
        eligible=[i for i in range(len(own))if i not in owncorners]
        for size in range(D+1,C+1):
            for inds in combinations(eligible,size):
                checked+=1;neigh=0
                for i in inds:neigh|=masks[i]
                surplus=neigh.bit_count()-size
                if surplus>r:continue
                hits+=1
                outgoing=[v for i,v in enumerate(other)if (neigh>>i)&1 and v in corner_set]
                assert surplus==r and len(outgoing)==1,(w,n,r,inds,surplus,outgoing)
                ox,oy=outgoing[0]
                radius=max(abs(own[i][0]-ox)+abs(own[i][1]-oy)for i in inds)
                assert radius<=2*r-3,(w,n,r,inds,radius)
                support=set(inds);seen={inds[0]};todo=[inds[0]]
                while todo:
                    i=todo.pop()
                    for j in support-seen:
                        if masks[i]&masks[j]:seen.add(j);todo.append(j)
                assert seen==support
                # The dual theorem uses that N^2(U) misses the corners
                # whose two neighboring rooms must survive.
                double={i for i in range(len(own))if masks[i]&neigh}
                assert not(double&owncorners)
                if len(witnesses)<5:witnesses.append(dict(phase=phase,size=size,surplus=surplus,radius=radius))
    return dict(width=w,length=n,radius=r,arbitrary_supports_checked=checked,band_supports=hits,witnesses=witnesses,cpu_seconds=time.process_time()-started)

if __name__=='__main__':
    rows=[]
    for case in((5,6,2),(7,8,2),(7,8,3)):
        row=check(*case);rows.append(row);print(json.dumps(row),flush=True)
    Path('research/bridge-lower-frontier-geometry-check.json').write_text(json.dumps(dict(scope=__doc__,rows=rows),indent=2)+'\n')

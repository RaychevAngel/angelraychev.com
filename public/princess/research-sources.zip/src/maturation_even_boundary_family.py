#!/usr/bin/env python3
"""Small actual-quadrant check of the hybrid annulus/ramp identities."""
from dataclasses import dataclass
from pathlib import Path
import json
import time


@dataclass(frozen=True)
class Family:
    h: int
    full: int
    ramp: int = 0
    first: int = 0
    tail: int = 0

    def counts(self):
        result = [self.h + 2*i + 1 for i in range(self.full)]
        result += [self.first + i for i in range(self.ramp)]
        if self.tail:
            result.append(self.tail)
        return result

    def cells(self):
        return {(x, self.h + 2*i - x)
                for i, a in enumerate(self.counts()) for x in range(a)}

    def neighbor_family(self):
        if self.full:
            return Family(self.h-1 if self.h else 1,
                          self.full+1 if self.h else self.full,
                          self.ramp,
                          self.first+1 if self.ramp else 0,
                          self.tail+1 if self.tail else 0)
        if not self.ramp:
            return Family(0, 0)
        if self.first < self.h:
            return Family(self.h-1, 0, self.ramp+1, self.first,
                          self.tail+1 if self.tail else 0)
        assert self.first == self.h
        return Family(self.h-1, 1, self.ramp, self.first+1,
                      self.tail+1 if self.tail else 0)

    def truncate(self, size):
        counts = []
        for a in self.counts():
            if not size:
                break
            used = min(size, a)
            counts.append(used)
            size -= used
        assert size == 0
        if not counts:
            return Family(0, 0)
        full = 0
        while full < len(counts) and counts[full] == self.h+2*full+1:
            full += 1
        if full == len(counts):
            return Family(self.h, full)
        first = counts[full]
        ramp = 1
        while full+ramp < len(counts) and counts[full+ramp] == first+ramp:
            ramp += 1
        tail = 0
        if full+ramp < len(counts):
            assert full+ramp+1 == len(counts)
            tail = counts[-1]
            assert 1 <= tail <= first+ramp
        return Family(self.h, full, ramp, first, tail)


def neighbors(support):
    return {(x+dx, y+dy) for x, y in support
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
            if x+dx >= 0 and y+dy >= 0}


def main():
    started = time.process_time()
    families = 0
    truncations = 0
    max_size = 0
    for h in range(6):
        for full in range(3):
            candidates = [Family(h, full)]
            for ramp in range(1, 4):
                for first in range(1, h+2*full+1):
                    for tail in range(first+ramp+1):
                        candidates.append(Family(h, full, ramp, first, tail))
            for f in candidates:
                support = f.cells()
                assert all(x >= 0 and y >= 0 for x, y in support)
                assert neighbors(support) == f.neighbor_family().cells(), f
                families += 1
                max_size = max(max_size, len(support))
                ordered = sorted(support, key=lambda v: (sum(v), v[0]))
                for k in sorted({0, 1, len(support)//2,
                                 max(0, len(support)-1), len(support)}):
                    if k > len(support):
                        continue
                    small = f.truncate(k)
                    assert small.cells() == set(ordered[:k]), (f, k)
                    assert neighbors(small.cells()) == small.neighbor_family().cells()
                    truncations += 1
    receipt = {
        "scope": "Finite direct-coordinate check; unbounded proof is separate",
        "parameter_range": {"h": [0, 5], "full": [0, 2], "ramp": [0, 3]},
        "families_checked": families,
        "truncations_checked": truncations,
        "max_support_size": max_size,
        "all_checks_passed": True,
        "cpu_seconds": round(time.process_time()-started, 6),
    }
    target = Path(__file__).resolve().parents[1]/"research/maturation-boundary-family-check.json"
    target.write_text(json.dumps(receipt, indent=2)+"\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()

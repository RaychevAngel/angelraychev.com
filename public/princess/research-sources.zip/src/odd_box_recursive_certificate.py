"""Recursive finite certificates of parity isoperimetry on odd boxes.
Each face compression is used only after that face shape has been verified,
with dimensions one/two covered by proved ordinary path/rectangle theorems.
The finite state count is reported, not presumed polynomial.
"""
from itertools import product
from collections import deque
from time import monotonic
from pathlib import Path
import json
from nested_grid_time import ordered_profiles

cache={}
def verify(shape,limit=30000,seconds=12):
 shape=tuple(sorted(n for n in shape if n>1))
 if shape in cache:return cache[shape]
 if len(shape)<=2:
  r={'shape':shape,'status':'proved_base'};cache[shape]=r;return r
 if __import__('math').prod(shape)>3500:return {'shape':shape,'status':'volume_limit'}
 for i in range(len(shape)):
  face=verify(shape[:i]+shape[i+1:],limit,seconds)
  if face['status'] not in('exact_match','proved_base'):
   return {'shape':shape,'status':'face_unverified','face':face['shape']}
 start=monotonic();verts=list(product(*(range(n)for n in shape)))
 ordered,data=ordered_profiles(shape,weightlex=True)
 if not ordered['nested']:return {'shape':shape,'status':'nesting_failure','details':ordered}
 results=[]
 for p in(0,1):
  row=sorted((v for v in verts if sum(v)%2==p),key=lambda v:(sum(v),tuple(-a for a in v)))
  ix={v:i for i,v in enumerate(row)};opp=[v for v in verts if sum(v)%2!=p];oi={v:i for i,v in enumerate(opp)}
  pred=[0]*len(row);adj=[0]*len(row)
  for axis in range(len(shape)):
   groups={}
   for v in row:groups.setdefault(v[axis],[]).append(v)
   for group in groups.values():
    for u,v in zip(group,group[1:]):pred[ix[v]]|=1<<ix[u]
  for i,v in enumerate(row):
   for axis,n in enumerate(shape):
    for delta in(-1,1):
     w=list(v);w[axis]+=delta
     if 0<=w[axis]<n:adj[i]|=1<<oi[tuple(w)]
  seen={0};queue=deque([0]);profile=[len(opp)+1]*(len(row)+1);witness={}
  while queue:
   s=queue.popleft();k=s.bit_count();nb=0;remaining=s
   while remaining:
    bit=remaining&-remaining;remaining^=bit;nb|=adj[bit.bit_length()-1]
   if nb.bit_count()<profile[k]:profile[k]=nb.bit_count();witness[k]=s
   for j,pr in enumerate(pred):
    bit=1<<j
    if not s&bit and s&pr==pr:
     new=s|bit
     if new not in seen:seen.add(new);queue.append(new)
   if len(seen)>limit or monotonic()-start>seconds:
    return {'shape':shape,'status':'bounded','parity':p,'states':len(seen),'seconds':monotonic()-start}
  bad=[k for k,x in enumerate(profile)if x!=ordered['profiles'][p][k]]
  if bad:
   k=bad[0];s=witness[k]
   return {'shape':shape,'status':'counterexample','p':p,'k':k,'minimum':profile[k],'prefix':ordered['profiles'][p][k], 'set':[v for j,v in enumerate(row)if s>>j&1],'seconds':monotonic()-start}
  results.append({'p':p,'states':len(seen),'exact':True})
 r={'shape':shape,'status':'exact_match','results':results,'seconds':monotonic()-start};cache[shape]=r;return r

if __name__=='__main__':
 root=Path(__file__).resolve().parents[1];out=[]
 for shape in[(3,5,5,5),(5,5,5,5),(3,3,3,3,5),(3,3,3,5,5),(3,3,5,5,5),(3,5,5,5,5),(5,5,5,5,5),(3,)*6,(3,)*7,(3,5,7,9),(5,7,7,9),(3,3,5,7,9)]:
  r=verify(shape);out.append(r);print(json.dumps(r),flush=True)
  (root/'research/odd-box-recursive-certificate.json').write_text(json.dumps({'scope':'Recursive finite isoperimetric certificates. Each codimension-one compression is justified by already proved or recursively verified smaller shape. No claim of a universal theorem or polynomial state count.','requested':out,'certified_shapes':list(cache.values())},indent=2)+'\n')
  if r['status']=='counterexample':break

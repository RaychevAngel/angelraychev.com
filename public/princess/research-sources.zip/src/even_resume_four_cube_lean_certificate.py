"""Generate finite Lean data; Lean independently checks geometry and inequalities."""
import sys
sys.set_int_max_str_digits(100000)
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
r=json.loads((ROOT/'research/even-resume-four-cube-critical-certificate.json').read_text())
vs=list(range(64));xyz=lambda v:(v//16,v//4%4,v%4)
neighbors=[sum(1<<u for u in vs if sum(abs(a-b) for a,b in zip(xyz(u),xyz(v)))==1) for v in vs]
def hood(mask):
 out=0
 for v in vs:
  if mask>>v&1:out|=neighbors[v]
 return out
records={}
for p in (0,1):
 color=[v for v in vs if sum(xyz(v))%2==p]
 for mask,value in zip(r['canonical_masks'][p],r['potentials_scaled_by_two'][p]):
  full=sum(1<<v for i,v in enumerate(color) if mask>>i&1)
  rec=value+(mask.bit_count()<<6)+(hood(full)<<12)
  assert full not in records or records[full]==rec
  records[full]=rec
items=sorted(records.items())
def expr(rows,depth=1):
 if len(rows)==1:return str(rows[0][1])
 k=len(rows)//2
 return f'if mask < {rows[k][0]} then\n'+('  '*depth)+expr(rows[:k],depth+1)+'\n'+('  '*(depth-1))+'else\n'+('  '*depth)+expr(rows[k:],depth+1)
s='''import FourCubeIdeals

/-! Finite records imported as data only; the following checks verify them. -/
namespace Princess.FourCubeCompression
open Princess.FiniteSubsetProfiles Princess.FiniteIdealCertificates

'''
packedkeys=sum(mask<<(64*i) for i,(mask,_) in enumerate(items))
packedrecords=sum(record<<(76*i) for i,(_,record) in enumerate(items))
s+=f'def keyAt (i : Nat) : Nat := ({packedkeys} >>> (64*i)) &&& 18446744073709551615\n'
s+=f'def entryAt (i : Nat) : Nat := ({packedrecords} >>> (76*i)) &&& {2**76-1}\n'
s+="""def findIndex : Nat → Nat → Nat → Nat → Nat
  | 0, lo, _, _ => lo
  | fuel+1, lo, hi, mask => if hi≤lo+1 then lo else
      let mid := (lo+hi)/2
      if mask < keyAt mid then findIndex fuel lo mid mask else findIndex fuel mid hi mask
"""
s+=f'def record (mask : Nat) : Nat := entryAt (findIndex 10 0 {len(items)} mask)\n' 
s+='''def potential (mask : Nat) : Nat := record mask &&& 63
def sizeTable (mask : Nat) : Nat := (record mask >>> 6) &&& 63
def hoodTable (mask : Nat) : Nat := record mask >>> 12
'''
s+=f'def neighborMask (v : Room) : Nat := ({sum(nb<<(64*v) for v,nb in enumerate(neighbors))} >>> (64*v.val)) &&& 18446744073709551615\n'
s+='''
def rawHood (mask : Nat) : Nat := selectedMask neighborMask
  (fun v : Room => mask.testBit v.val) (List.finRange 64)

theorem neighbor_mask_correct : ∀ u v : Room,
    (neighborMask u).testBit v.val=true ↔ adj u v := by decide

def factsCheck (mask : Nat) : Bool := decide
  (sizeTable mask = countBits 64 mask ∧ hoodTable mask = rawHood mask)

set_option maxRecDepth 100000 in
set_option maxHeartbeats 10000000 in
theorem facts_even_checked : check down factsCheck ((colorRooms false).map Fin.val) 0=true := by decide +kernel

set_option maxRecDepth 100000 in
set_option maxHeartbeats 10000000 in
theorem facts_odd_checked : check down factsCheck ((colorRooms true).map Fin.val) 0=true := by decide +kernel

end Princess.FourCubeCompression
'''
(ROOT/'lean/FourCubePotentialData.lean').write_text(s)
print('generated',len(items),'records')

# Split the outer universal checker into small independent kernel reductions.
# This is purely a resource optimization: the generic branch lemmas reassemble
# the original full checker, preserving its quantified soundness theorem.
from functools import lru_cache
from itertools import combinations
pred=[[] for _ in vs]
for v in vs:
 for i,j in combinations(range(3),2):
  for dx in (-1,1):
   p=list(xyz(v));p[i]+=dx;p[j]-=1
   if all(0<=x<4 for x in p):pred[v].append(16*p[0]+4*p[1]+p[2])
weight=lambda v:sum((i+1)*x for i,x in enumerate(xyz(v)))
downs=[1<<v for v in vs]
for v in sorted(vs,key=weight):
 for u in pred[v]:downs[v]|=downs[u]
head='''import FourCubePotentialData
namespace Princess.FourCubeCompression
open Princess.FiniteIdealCertificates

def charge (p : Nat) : Nat := if p≤3 then 0 else if p=4 then 1 else 2
def transitionCheck (a r : Nat) : Bool := decide
  (r &&& a=r → sizeTable a-sizeTable r≤8 →
    potential a≤charge (sizeTable a-sizeTable r)+potential (hoodTable r))
def sourceCheck (p : Bool) (a : Nat) : Bool :=
  check down (transitionCheck a) ((colorRooms p).map Fin.val) 0

set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
'''
for parity in (0,1):
 ps='true' if parity else 'false';label='odd' if parity else 'even'
 verts=tuple(sorted([v for v in vs if sum(xyz(v))%2==parity],key=lambda v:(weight(v),v),reverse=True))
 @lru_cache(None)
 def leafcount(pos,mask):
  if pos==len(verts):return 1
  v=verts[pos]
  if mask>>v&1:return leafcount(pos+1,mask)
  return leafcount(pos+1,mask)+leafcount(pos+1,mask|downs[v])
 batches=[]
 def build(pos,mask):
  rest=list(verts[pos:])
  if leafcount(pos,mask)<=12:
   name=f'transitions_{label}_batch_{len(batches)}'
   batches.append((name,rest,mask,leafcount(pos,mask)))
   return name
  v=verts[pos];tail=list(verts[pos+1:])
  if mask>>v&1:
   return f'(check_forced down (sourceCheck {ps}) {v} {tail} {mask} (by decide) {build(pos+1,mask)})'
  return f'(check_branch down (sourceCheck {ps}) {v} {tail} {mask} (by decide) {build(pos+1,mask)} {build(pos+1,mask|downs[v])})'
 proof=build(0,0)
 for name,rest,mask,count in batches:
  head+=f'\n/-- {count} source states; all292 residual states per source are retained. -/\ntheorem {name} : check down (sourceCheck {ps}) {rest} {mask}=true := by decide +kernel\n'
 head+=f'\ntheorem transitions_{label}_checked : check down (sourceCheck {ps}) ((colorRooms {ps}).map Fin.val) 0=true := by\n  exact {proof}\n'
 print(label,'batches',len(batches),'sources',leafcount(0,0))
head+='''
theorem charge_budget_checked : ∀ p q : Fin 9, p.val+q.val≤8 → charge p.val+charge q.val≤2 := by decide
theorem charge_budget (p q : Nat) (h : p+q≤8) : charge p+charge q≤2 :=
  charge_budget_checked ⟨p,by omega⟩ ⟨q,by omega⟩ h
theorem potential_empty : potential 0=0 := by decide
theorem potential_even_full : potential 6510698340921550245=40 := by decide
theorem potential_odd_full : potential 11936045732788001370=40 := by decide
end Princess.FourCubeCompression
#print axioms Princess.FourCubeCompression.transitions_even_checked
#print axioms Princess.FourCubeCompression.transitions_odd_checked
'''
(ROOT/'lean/FourCubePotentialCertificate.lean').write_text(head)

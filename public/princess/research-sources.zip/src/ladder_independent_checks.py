#!/usr/bin/env python3
"""Independent attacks on the ladder proof; does not import its counter solver."""
from pathlib import Path
import json
import time


def f(n, b, p):
    if b <= p:
        return 0
    return min(n, b-p+1)


def closed(r, mask):
    return (r | (r << 1) | (r >> 1)) & mask


def allocations(n, m):
    if m >= 2*n:
        return [(n,n)]
    if n == 1:
        return [(1,0),(0,1)]
    if m == 1:
        return None
    M = m-1
    q, s = divmod(n-1, M)
    if s == 0:
        return [(m,0)]*q + [(0,m)]*q
    out = [(m,0)]*q + [(s+1,M-s)]
    b = (q-1)*M+2*s+2
    assert 2 <= b <= n
    out += [(0,m)]*((b-1+M-1)//M)
    return out


def direct_rooms(n, m, plan):
    belief = {(r,j) for r in (0,1) for j in range(n)}
    for t,(p,q) in enumerate(plan):
        assert p+q <= m
        probes = set()
        for origin, allowance in enumerate((p,q)):
            cohort = sorted((room for room in belief if (sum(room)-t)%2 == origin), key=lambda room:room[1])
            probes.update(cohort[:allowance])
        rem = belief-probes
        if not rem:
            assert t+1 == len(plan)
            return
        belief = {(rr,jj) for r,j in rem for rr,jj in ((1-r,j),(r,j-1),(r,j+1)) if 0 <= jj < n}
    raise AssertionError(('plan did not capture',n,m))


def main():
    start=time.monotonic()
    minimum_checks=0
    # Every subset and every useful action for all closed paths up to 12 vertices.
    for n in range(1,13):
        mask=(1<<n)-1
        for bmask in range(mask+1):
            b=bmask.bit_count()
            shot=bmask
            while True:
                p=shot.bit_count()
                assert closed(bmask & ~shot,mask).bit_count() >= f(n,b,p)
                minimum_checks+=1
                if shot == 0:
                    break
                shot=(shot-1)&bmask
        for p in range(n+2):
            values=[f(n,b,p) for b in range(n+1)]
            assert values == sorted(values)
            for b in range(n+1):
                suffix=((1<<b)-1)<<(n-b)
                # Clear the smallest column indices (left end of suffix).
                shot=0
                for j in range(n-b,min(n,n-b+p)):
                    shot |= 1<<j
                assert closed(suffix & ~shot,mask).bit_count() == f(n,b,p)
    tested=0
    direct=0
    for n in range(1,201):
        for m in range(1,2*n+3):
            plan=allocations(n,m)
            if plan is None:
                continue
            if m>=2*n:
                expect=1
            elif n==1:
                expect=2
            else:
                M=m-1;N=n-1
                expect=(2*N+M-1)//M + int(M%2==0 and N%M==M//2)
            assert len(plan)==expect
            b=c=n
            for p,q in plan:
                assert p+q<=m
                b,c=f(n,b,p),f(n,c,q)
            assert (b,c)==(0,0)
            tested+=1
            if n<=30:
                direct_rooms(n,m,plan)
                direct+=1
    out=dict(status='all checks passed',subset_action_checks=minimum_checks,
             explicit_strategy_cases=tested,direct_room_schedule_cases=direct,
             elapsed_seconds=round(time.monotonic()-start,4),
             limitations='Finite attacks on explicit construction and reduction; not a proof or novelty claim.')
    dest=Path(__file__).resolve().parents[1]/'research/ladder-independent-checks.json'
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()

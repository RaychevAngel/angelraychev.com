"""Test a time-dependent triangular deficit invariant before first capture."""
from bisect import bisect_right
from pathlib import Path
from time import process_time
from odd_serial_first_order_attack import profiles
import json

def main(limit=20):
 start=process_time();checks=params=0;fail=None
 for b in range(1,15):
  for a in (b,b+1,b+3):
   g=profiles(a,b);E,M=len(g[0])-1,len(g[1])-1
   inv=[[bisect_right(g[p],z)-1for z in range((M,E)[p]+1)]for p in(0,1)]
   for m in range(b+1,min(2*b+4,M)):
    D0=D1=0;params+=1
    for t in range(2*(E+M)):
     C0=inv[0][min(M,D1+m)];C1=inv[1][min(E,D0+m)]
     if C0==E or C1==M:break
     points=[(0,D1)]if not D0 else[(x,D1*(D0-x)//D0)for x in range(D0+1)]
     for x,y in points:
      for p in range(m+1):
       u=inv[0][min(M,y+m-p)];v=inv[1][min(E,x+p)];checks+=1
       good=(u<=C0 and v<=C1 and (u*C1+v*C0<=C0*C1 if C0 and C1 else (u==0 if not C0 else v==0)))
       if not good:fail={'shape':[2*a+1,2*b+1],'m':m,'day':t,'capacities':[D0,D1],'next_capacities':[C0,C1],'state':[x,y],'quotas':[p,m-p],'next':[u,v]};break
      if fail:break
     if fail:break
     D0,D1=C0,C1
    if fail or process_time()-start>limit:break
   if fail or process_time()-start>limit:break
  if fail or process_time()-start>limit:break
 out={'scope':'Triangle invariance on all integer boundary points, stronger than exact reachable-state checks.','parameters':params,'transitions':checks,'failure':fail,'CPU_seconds':process_time()-start}
 Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-triangle-attack.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()

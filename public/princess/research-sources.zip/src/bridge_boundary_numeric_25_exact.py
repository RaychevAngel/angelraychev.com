"""Fixed substitutions for the all-even-length exact width-25 theorem.

The persistent terminal exclusions are separately verified finite inputs;
this checker reads their receipts and verifies the new numerical transfer.
"""
from pathlib import Path
from time import process_time
import hashlib
import json

from bridge_boundary_numeric_25 import FEATURES, P, low_step, high_step
from bridge_lower_frontier_nine import root, pronic, step


def main():
    started = process_time()
    terminal_path = Path('research/bridge-upper-transport-terminal-feature-verified.json')
    terminal = json.loads(terminal_path.read_text())
    exclusions = []
    for e in range(3):
        candidates = [row for row in terminal
                      if row['seed_size'] == 157 and row['seed_feature'] == [0, e]]
        assert len(candidates) == 1
        row = candidates[0]
        assert row['solo_days'] == 71 and row['radius_length'] == 26
        assert row['dominance'] is False
        exclusions.append(dict(feature=[0, e], size=157, solo_days=71,
                               radius_length=26, source_sha256=row['source_sha256']))
    hull = {feature:156 if feature[0] == 0 else 157 for feature in FEATURES}
    following = low_step(hull)
    capacity_maxima = [max(s+P(v,u,j,s) for v in range(3)
                          for j in range(3) for u in range(j+1)) for s in (11,12)]
    assert capacity_maxima == [132,156]
    assert set(following.values()) == {157}
    assert following == step(12, 325, 13, hull, strong_band=False)

    exit_rows = [{feature:133 for feature in FEATURES}]
    for _ in range(19):
        exit_rows.append(high_step(exit_rows[-1]))
    assert min(exit_rows[18].values()) == 112
    assert min(exit_rows[19].values()) == 110

    # Independent physical near-corner tail: only the two proved forward
    # profile roots are used, not any corner-model transition.
    tails = []
    for initial_phase in (0, 1):
        a, phase, counts = 157, initial_phase, [157]
        while a:
            q = max(a-13, 0)
            a = q+(min(root(q), 12) if phase == 0 else min(pronic(q), 13)) if q else 0
            phase ^= 1
            counts.append(a)
        tails.append(dict(initial_phase=initial_phase, days=len(counts)-1,
                          final_preinspection=counts[-2], counts=counts))
    assert (tails[0]['days'], tails[0]['final_preinspection']) == (70, 2)
    assert (tails[1]['days'], tails[1]['final_preinspection']) == (71, 2)

    out = dict(status='PASS', scope=__doc__,
               source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               terminal_receipt_sha256=hashlib.sha256(terminal_path.read_bytes()).hexdigest(),
               terminal_exclusions=exclusions, features=FEATURES,
               terminal_hull=list(hull.values()),
               low_target_capacities_at_11_and_12=capacity_maxima,
               one_unflagged_predecessor=list(following.values()),
               exit_deficits=[list(row.values()) for row in exit_rows], physical_tails=tails,
               uniform_result=dict(domain='Every even n>=26, budget13, width25',
                                   exact_full_time='50*n-925',
                                   solo_construction_days='25*n-462',
                                   central_inspections=4,
                                   excluded_remaining_model_horizon='25*n-491'),
               seconds=process_time()-started)
    Path('research/bridge-boundary-numeric-25-exact-check.json').write_text(
        json.dumps(out, indent=2)+'\n')
    print({key:value for key,value in out.items()
           if key in ('status', 'uniform_result', 'seconds')})


if __name__ == '__main__':
    main()

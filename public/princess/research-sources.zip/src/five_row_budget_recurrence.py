"""Five rows, even lengths: upper prefix game and lower history relaxation.

Both retain a rigorous direction. Equality in finite tests is evidence only;
no universal exact recurrence is asserted by this exploratory module.
"""
from collections import deque
from functools import lru_cache
from pathlib import Path
import json,time
import heapq

def prefix(h,k,z):
    if k==0:return 0
    if k==h:return h
    if z==0:return k+(1 if k in (1,h-2,h-1)else 2)
    return k+(1 if k==h-1 else 2 if k in (1,2,h-4,h-3,h-2)else 3)

def history_next(h,b,z,p):
    r=max(b-p,0)
    if r==0:return((0,0),)
    if r==h:return((h,0),)
    ans=[(after,0)for after in range(r+3,h+1)]
    corner_forbidden=z==1 and b<h-4 and r==1
    if r in(1,h-2,h-1)and not corner_forbidden:ans.append((r+1,0))
    permitted_pair=(b-2,r)in((h-6,3),(h-5,3),(h-5,4))
    forbidden=z==1 and 3<=r<=h-5 and not permitted_pair
    if r<=h-2 and not forbidden:ans.append((r+2,int(3<=r<=h-5)))
    return tuple(set(ans))

def ammunition(n,m):
    h=5*n//2;start=(h,0);distance={start:0};todo=[(0,*start)]
    while todo:
        cost,b,z=heapq.heappop(todo)
        if cost!=distance[(b,z)]:continue
        if b==0:return cost
        for p in range(min(b,m)+1):
            for after in history_next(h,b,z,p):
                new=cost+p
                if new<distance.get(after,10**9):
                    distance[after]=new;heapq.heappush(todo,(new,*after))
    return None

def residue_need(r):
    return 0 if r==0 else 2 if r==1 else 3 if r==2 else 4 if r in(3,4)else(r+6)//2

def candidate_formula(n,m):
    h=5*n//2
    if m>=2*h:return 1
    if m>=h:return 2
    if m==3:return 4*h-20
    if m==4:return 2*((2*h-6)//3)
    q,r=divmod(2*h-6,2*m-5)
    return 2*q if not r else 2*q+1 if 2*residue_need(r)<=m else 2*q+2

@lru_cache(None)
def board(n):
    from nested_grid_time import ordered_profiles
    report,data=ordered_profiles((n,5));assert report['nested']
    coords,adj,orders,prefixes,profiles=data
    index={c:i for i,c in enumerate(coords)}
    reflected=[index[(n-1-x,y)]for x,y in coords]
    return coords,adj,prefixes,reflected

def direct_strategy(n,m):
    """Actual all-length upper construction; no state-space search."""
    from nested_grid_time import neighborhood
    h=5*n//2;coords,adj,prefixes,reflected=board(n)
    if m<3:return None
    if m>=2*h:plans=[(h,h)];start_phases=[0,0]
    elif m>=h:plans=[(h,0),(0,h)];start_phases=[0,0]
    elif m in(3,4):
        lengths=[]
        for initial_phase in(0,1):
            b=h;phase=initial_phase;turns=0
            while b:b=prefix(h,max(b-m,0),phase);phase=1-phase;turns+=1
            lengths.append(turns)
        phase=min(range(2),key=lambda z:lengths[z]);length=lengths[phase]
        plans=[(m,0)]*length+[(0,m)]*length;start_phases=[phase,phase]
    else:
        q,r=divmod(2*h-6,2*m-5)
        if not r:plans=[(m,0)]*q+[(0,m)]*q;start_phases=[0,0]
        elif 2*residue_need(r)<=m:
            j=residue_need(r);plans=[(m,0)]*q+[(j,j)]+[(0,m)]*q
            start_phases=[0,1 if j in(3,4)else 0]
        else:plans=[(m,0)]*(q+1)+[(0,m)]*(q+1);start_phases=[0,0]
    belief=(1<<(2*h))-1;counts=[h,h];phases=[0,0];active=[False,False];shots=[]
    def canon(b,z,physical):
        mask=prefixes[z][b]
        if z==physical:return mask
        out=0
        while mask:
            bit=mask&-mask;out|=1<<reflected[bit.bit_length()-1];mask^=bit
        return out
    for day,allocation in enumerate(plans):
        shot=0;nexts=[]
        for cohort,p in enumerate(allocation):
            if p and not active[cohort]:phases[cohort]=start_phases[cohort];active[cohort]=True
            z=phases[cohort];b=counts[cohort];physical=cohort^(day%2)
            support=canon(b,z,physical);survivors=canon(max(b-p,0),z,physical)
            assert support&~belief==0
            shot|=support^survivors
            actual=neighborhood(survivors,adj);bb=actual.bit_count();zz=1-z
            assert actual==canon(bb,zz,1-physical)
            nexts.append((bb,zz))
        assert shot.bit_count()<=m
        belief=neighborhood(belief&~shot,adj);shots.append(shot)
        counts=[x[0]for x in nexts];phases=[x[1]for x in nexts]
    assert not belief
    assert len(shots)==candidate_formula(n,m),(n,m,len(shots),candidate_formula(n,m))
    return dict(n=n,m=m,turns=len(shots),inspections=[[coords[i]for i in range(2*h)if s>>i&1]for s in shots])

def solve(n,m,lower=False,seconds=4):
    assert n>=6 and n%2==0 and m>=3
    h=5*n//2;started=time.monotonic();edges=0
    @lru_cache(None)
    def nxt(b,z,p):
        r=max(b-p,0)
        if r==0:return((0,0),)
        if r==h:return((h,0),)
        if not lower:
            ans=[]
            for zz in (0,1)if b==h else(z,):
                after=prefix(h,r,zz)
                ans.append((after,0 if after==h else 1-zz))
            return tuple(set(ans))
        return history_next(h,b,z,p)
    def canon(a,x,b,y):
        first,second=sorted(((a,x),(b,y)))
        return (*first,*second)
    start=(h,0,h,0);parents={start:None};todo=deque([start])
    while todo:
        a,x,b,y=state=todo.popleft()
        if a+b<=m:
            path=[(state,a,b)];here=state
            while parents[here]is not None:
                previous,p=parents[here];path.append((previous,p,m-p));here=previous
            return dict(turns=len(path),states=len(parents),edges=edges,seconds=time.monotonic()-started,path=list(reversed(path)))
        for p in range(max(0,m-b),min(m,a)+1):
            for aa,xx in nxt(a,x,p):
                for bb,yy in nxt(b,y,m-p):
                    after=canon(aa,xx,bb,yy);edges+=1
                    if after not in parents:parents[after]=(state,p);todo.append(after)
            if edges%1024<64 and time.monotonic()-started>seconds:
                return dict(status='incomplete',states=len(parents),edges=edges,seconds=time.monotonic()-started)
    return dict(turns=None,states=len(parents),edges=edges,seconds=time.monotonic()-started)

if __name__=='__main__':
    started=time.monotonic();rows=[]
    for n in (6,8,10,12):
        for m in range(3,5*n//2):
            upper=solve(n,m);lower=solve(n,m,True)
            row=dict(n=n,m=m,upper={k:v for k,v in upper.items()if k!='path'},lower={k:v for k,v in lower.items()if k!='path'})
            rows.append(row)
            if upper.get('turns')!=lower.get('turns'):
                row['upper_path']=upper.get('path');row['lower_path']=lower.get('path')
                print('GAP',n,m,upper.get('turns'),lower.get('turns'),flush=True)
    result=dict(scope='Prefix upper strategies versus arbitrary-support historical lower relaxation; finite comparison only, no universal equality claimed.',seconds=time.monotonic()-started,rows=rows)
    Path('research/five-row-budget-recurrence-checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(dict(cases=len(rows),gaps=sum(r['upper'].get('turns')!=r['lower'].get('turns')for r in rows),seconds=result['seconds']))

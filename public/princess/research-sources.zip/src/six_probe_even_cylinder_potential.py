"""Exact small shortest-path derivation for the six-probe history relaxation."""
from heapq import heappop,heappush
from even_three_by_three_cylinder_attack import profile_lower
CHARGE=(0,0,0,1,1,2,2)
def valid(h,k,e):return 0<=k<=h if e==0 else 8<=k<=h-4
def next_states(h,k,e,p):
 s=k-p
 if s==0:
  yield (0,0);return
 for y in range(profile_lower(h,s),h+1):
  ne=int(4<=s<=h-8 and y==s+4)
  if e and ne:continue
  assert valid(h,y,ne)
  yield y,ne

def derive(h):
 states=[(k,e)for e in (0,1) for k in range(h+1)if valid(h,k,e)]
 rev={s:[]for s in states}
 for k,e in states:
  for p in range(min(6,k)+1):
   for target in next_states(h,k,e,p):rev[target].append(((k,e),CHARGE[p]))
 dist={(0,0):0};Q=[(0,(0,0))]
 while Q:
  d,t=heappop(Q)
  if d!=dist[t]:continue
  for s,c in rev[t]:
   v=d+c
   if v<dist.get(s,10**9):dist[s]=v;heappush(Q,(v,s))
 assert len(dist)==len(states)
 return dist

def potential(h,k,e):
    assert h>=18 and h%9==0 and valid(h,k,e)
    if e:return (4*k+2)//3-7
    if k<=8:return (0,0,0,1,1,2,2,3,4)[k]
    return min(4*k//3-7,4*h//3-8)

def verify(h):
    checks=0
    for e in (0,1):
        for k in range(h+1):
            if not valid(h,k,e):continue
            if valid(h,k+1,e):assert potential(h,k,e)<=potential(h,k+1,e)
            for p in range(min(k,6)+1):
                for y,ne in next_states(h,k,e,p):
                    assert potential(h,k,e)<=CHARGE[p]+potential(h,y,ne),(h,k,e,p,y,ne)
                    checks+=1
    assert potential(h,h,0)==6*(2*h//9)-8
    return checks

def certificate():
    import json
    from pathlib import Path
    base={h:verify(h)for h in (18,27)}
    redundant={h:verify(h)for h in (36,45,54,90)}
    assert all(CHARGE[p]+CHARGE[q]<=2 for p in range(7)for q in range(7-p))
    middle={}
    for e,ne,a in ((0,1,4),(0,0,5),(1,0,5)):
        drops=[max((4*r+2*e)//3-(4*(r-p+a)+2*ne)//3 for r in range(3))for p in range(7)]
        assert all(d<=c for d,c in zip(drops,CHARGE))
        middle[f'{e}->{ne}']=drops
    out={'status':'Finite premises checked; all-even ordinary upper and lower proofs independently audited and accepted by root','charges':CHARGE,'base_checks':base,'redundant_extensions':redundant,'middle_max_drops':middle,'extension':'For h=27+delta, delta in9N: k<=14 unchanged; k>=20+delta translates bydelta; middle15..19+delta has only three residue/phase branches.'}
    (Path(__file__).resolve().parents[1]/'research'/'six-probe-even-cylinder-potential.json').write_text(json.dumps(out,indent=2)+'\n')
    return out

if __name__ == "__main__":
    import json
    print(json.dumps(certificate()))

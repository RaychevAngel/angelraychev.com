"""Bounded attack on the remaining historical-envelope equality cases."""
from pathlib import Path
import json,time
from high_budget_odd_rectangles import potential,J,Q,R,low

def model(b,h,m):
 B=b*(b+1)
 F=lambda k,z:potential(b,m,2*k+z)
 g=lambda s:s+min(R(s),b,Q(h-s)-1) if s else 0
 C=min(x+F(g(h-x),0) for x in range(B+1))
 def phi(k,z):return min(F(k,z),max(0,C-h+k)) if k else 0
 def nxt(k,z,p):
  s=max(0,k-p)
  if not s:return [(0,0)]
  if s>=h-B:return [(g(s),0)]
  if s<=b*b:return [(max(g(s),low(b,z,s)),0)]
  result=[(s+b+1,0)]
  if not z:result.append((s+b,1))
  return [(k,z)for k,z in result if k<=h]
 return C,phi,nxt

def attack(w,n,m):
 b=(w-1)//2;h=w*n//2;C,phi,nxt=model(b,h,m)
 best=10**9;examples=[];first=[]
 for p in range(m+1):
  for a in nxt(h,0,p):
   for c in nxt(h,0,m-p):
    slack=m+phi(*a)+phi(*c)-2*C
    if slack<=1:first.append((p,a,c,slack))
    for q in range(m+1):
     for aa in nxt(*a,q):
      for cc in nxt(*c,m-q):
       total=2*m+phi(*aa)+phi(*cc)-2*C
       if total<best:best=total;examples=[(p,q,a,c,aa,cc,total)]
       elif total==best and len(examples)<8:examples.append((p,q,a,c,aa,cc,total))
 return dict(shape=[w,n],m=m,C=C,first_low_slack=first,best_two_day_slack=best,witnesses=examples)

if __name__=='__main__':
 start=time.process_time();source=json.load(open('research/uniform-odd-short-envelope-check.json'))
 result=dict(scope='Abstract geometry-informed historical relaxation; not a physical strategy certificate.',cases=[attack(*row[:3])for row in source['gaps']],cpu_seconds=time.process_time()-start)
 Path('research/supersession-odd-short-equality-check.json').write_text(json.dumps(result,indent=2)+'\n')
 for r in result['cases']:print(r['shape'],r['m'],'two-day',r['best_two_day_slack'],'firstchoices',len(r['first_low_slack']),r['witnesses'][:2])
 print('cpu',result['cpu_seconds'])

def exact_slack_attack(w,n,m):
 b=(w-1)//2;h=w*n//2;C,phi,nxt=model(b,h,m)
 blocks,r=divmod(2*h-w-1,2*m-w);T=2*blocks+1;limit=T*m-2*C
 frontier={(h,0,h,0):[]};counts=[1]
 for day in range(1,T+1):
  new={}
  for (a,z,c,v),trace in frontier.items():
   for p in range(m+1):
    for aa,zz in nxt(a,z,p):
     for cc,vv in nxt(c,v,m-p):
      slack=day*m+phi(aa,zz)+phi(cc,vv)-2*C
      if slack>limit:continue
      key=(aa,zz,cc,vv)
      if key not in new:new[key]=trace+[(p,key,slack)]
  frontier=new;counts.append(len(frontier))
  if not frontier:break
 return dict(shape=[w,n],m=m,deadline=T,slack_limit=limit,frontiers=counts,winning_relaxed_trace=frontier.get((0,0,0,0)))

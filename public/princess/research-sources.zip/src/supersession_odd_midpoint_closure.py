"""Attack a proposed inductive capped-pair invariant, not actual seriality.

Relaxed states need only satisfy the already proved individual/total
bounds and pair constraints against themselves and both solo endpoints.
A counterexample refutes this closure argument, not the full-board theorem.
"""
from bisect import bisect_right
from itertools import combinations_with_replacement
from pathlib import Path
from time import process_time
import json
from odd_serial_first_order_attack import profiles
from uniform_rectangle_half_time import capacities


def attack(n,w,m,t,seconds=15,sharp=False):
    g=profiles((n-1)//2,(w-1)//2)
    E,M=len(g[0])-1,len(g[1])-1
    tau,D,trace=capacities(g,m)
    assert 0<=t<tau-1
    a,b=trace[t];aa,bb=trace[t+1]
    K=max(min(E,2*a),min(M,2*b),a+b) if sharp else max(E,a+b)
    KK=max(min(E,2*aa),min(M,2*bb),aa+bb) if sharp else max(E,aa+bb)
    I=[[bisect_right(g[p],z)-1 for z in range((M,E)[p]+1)]for p in(0,1)]
    def cap(x,y):return min(E,x[0]+y[0])+min(M,x[1]+y[1])
    states=[(x,y)for x in range(a+1)for y in range(min(b,max(a,b)-x)+1)
            if cap((x,y),(x,y))<=K and cap((x,y),(a,0))<=K and cap((x,y),(0,b))<=K]
    successors={z:[(I[0][z[1]+m-p],I[1][z[0]+p])for p in range(m+1)]for z in states}
    start=process_time();checks=0;failure=None;completed=True
    for x,y in combinations_with_replacement(reversed(states),2):
        if cap(x,y)>K:continue
        for p,xx in enumerate(successors[x]):
            for q,yy in enumerate(successors[y]):
                checks+=1
                if cap(xx,yy)>KK:
                    failure={'source_pair':[x,y],'quotas0':[p,q],'target_pair':[xx,yy],
                             'old_capped_sum':cap(x,y),'new_capped_sum':cap(xx,yy)}
                    break
            if failure:break
        if failure:break
        if process_time()-start>=seconds:
            completed=False;break
    return {'scope':'Relaxed local closure only; a failure need not be reachable.',
            'shape':[n,w],'budget':m,'time':t,'solo_time':tau,'sharp_bound':sharp,
            'source_capacities':[a,b],'target_capacities':[aa,bb],
            'old_bound':K,'new_bound':KK,'states':len(states),'checks':checks,
            'completed':completed,'failure':failure,'CPU_seconds':process_time()-start}

if __name__=='__main__':
    rows=[]
    for args in [(11,11,7,23),(13,13,8,26)]:
        row=attack(*args);rows.append(row);print(json.dumps(row),flush=True)
        if row['failure'] or not row['completed']:break
    Path(__file__).resolve().parents[1].joinpath('research/supersession-odd-midpoint-closure.json').write_text(json.dumps(rows,indent=2)+'\n')

"""Check packaged sources, local links, and independent TeX compilation."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote,urljoin
import json, hashlib, zipfile, subprocess, tempfile, re
ROOT=Path(__file__).resolve().parents[1]
from publication_paths import SITE
DIST=SITE/'dist';PUBLIC=SITE/'public/princess'
class Page(HTMLParser):
    def __init__(self,path):
        super().__init__();self.ids=set();self.links=[];self.errors=[];self.feed(path.read_text())
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.add(a['id'])
        if tag=='a' and 'href' in a:self.links.append(a['href'])
        if 'katex-error' in a.get('class',''):self.errors.append(a)
pages={}
for path in (DIST/'princess').rglob('index.html'):
    pages[path]=Page(path)
assert len(pages)==4,'Build the website before checking its four Princess pages'
issues=[];checked=0
for path,page in pages.items():
    assert not page.errors,str(path)
    base='https://local/'+str(path.relative_to(DIST))
    for href in page.links:
        u=urlparse(urljoin(base,href))
        if u.netloc not in ('local','angelraychev.com') or not u.path.startswith('/princess'):continue
        target=DIST/unquote(u.path.lstrip('/'))
        if target.is_dir():target=target/'index.html'
        if not target.exists():issues.append((str(path),href,'missing file'));continue
        if u.fragment and target.suffix=='.html':
            if target not in pages:pages[target]=Page(target)
            if unquote(u.fragment) not in pages[target].ids:issues.append((str(path),href,'missing anchor'))
        checked+=1
assert not issues,issues
assert checked>100,'The proof page should supply many internal theorem links'
release=json.loads((PUBLIC/'release.json').read_text())
for name,r in release['files'].items():assert hashlib.sha256((PUBLIC/name).read_bytes()).hexdigest()==r['sha256']
formal=json.loads((ROOT/'research/lean-verification.json').read_text())
with zipfile.ZipFile(PUBLIC/'lean-proofs.zip') as z:
    assert z.testzip() is None
    for row in formal['files']:assert hashlib.sha256(z.read(row['file'])).hexdigest()==row['sha256']
with zipfile.ZipFile(PUBLIC/'research-sources.zip') as z:
    assert z.testzip() is None
    assert 'src/even_resume_cube_solver.cpp' in z.namelist()
    assert not any('intake' in n or 'student-comparison' in n or 'source-inventory' in n for n in z.namelist())
tex=Path('/Users/angel/Library/TinyTeX/bin/universal-darwin')
with tempfile.TemporaryDirectory(prefix='princess-package-',dir=ROOT/'tmp') as td:
    with zipfile.ZipFile(PUBLIC/'manuscript-source.zip') as z:z.extractall(td)
    for command in [('pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'),('bibtex','main'),('pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'),('pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex')]:
        p=subprocess.run([str(tex/command[0]),*command[1:]],cwd=td,capture_output=True,text=True)
        assert p.returncode==0,p.stdout[-5000:]+p.stderr
    log=(Path(td)/'main.log').read_text()
    assert not re.search(r'Overfull|undefined references|undefined citations|Citation .* undefined|Reference .* undefined',log)
    from pypdf import PdfReader
    assert len(PdfReader(Path(td)/'main.pdf').pages)==release['pages']
receipt={'all_passed':True,'html_pages':len(pages),'local_links_and_anchors_checked':checked,'isolated_latex_compilation':True,'archive_hashes':release['files'],'lean_sources_match_fresh_receipt':True,'lean_modules':len(formal['files'])}
(ROOT/'research/publication-package-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='archive_hashes'},indent=2))

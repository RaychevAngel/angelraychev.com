#include <algorithm>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <vector>
using namespace std;
int main(int argc,char**argv){
 int w=argc>1?stoi(argv[1]):6,n=argc>2?stoi(argv[2]):8;
 if(w*n>48)return 2;
 for(int phase=0;phase<2;phase++){
  vector<pair<int,int>>v[2];int index[20][20];
  for(int x=0;x<w;x++)for(int y=0;y<n;y++){index[x][y]=v[(x+y)%2].size();v[(x+y)%2].push_back({x,y});}
  int h=v[phase].size();uint32_t end=1u<<h;vector<uint32_t>bits(h),pred(h);
  for(int i=0;i<h;i++){
   auto[x,y]=v[phase][i];for(auto[dx,dy]:vector<pair<int,int>>{{1,0},{-1,0},{0,1},{0,-1}}){int X=x+dx,Y=y+dy;if(X>=0&&X<w&&Y>=0&&Y<n)bits[i]|=1u<<index[X][Y];}
   if(y)for(int X:{x-1,x+1})if(X>=0&&X<w)pred[i]|=1u<<index[X][y-1];
  }
  vector<uint32_t>ideals;uint64_t candidates=1;for(int x=0;x<w;x++)candidates*=n/2+2;
  // Generate every parity-fiber prefix; all pyramids have this property.
  auto generate=[&](auto&&self,int x,uint32_t mask)->void{
   if(x==w){for(int i=0;i<h;i++)if(mask>>i&1)if((mask&pred[i])!=pred[i])return;ideals.push_back(mask);return;}
   self(self,x+1,mask);for(int y=0;y<n;y++)if((x+y)%2==phase){mask|=1u<<index[x][y];self(self,x+1,mask);}
  };generate(generate,0,0);
  vector<uint32_t>N(end);for(uint32_t a=1;a<end;a++){uint32_t bit=a&-a;N[a]=N[a^bit]|bits[__builtin_ctz(bit)];}
  uint64_t tested=0;for(uint32_t a:ideals){vector<int>ordinary(h+1,h+1),canon(h+1,h+1);for(uint32_t r=a;;r=(r-1)&a){ordinary[__builtin_popcount(r)]=min(ordinary[__builtin_popcount(r)],__builtin_popcount(N[r]));tested++;if(!r)break;}
   for(uint32_t r:ideals)if((r&a)==r)canon[__builtin_popcount(r)]=min(canon[__builtin_popcount(r)],__builtin_popcount(N[r]));
   for(int k=h-1;k>=0;k--){ordinary[k]=min(ordinary[k],ordinary[k+1]);canon[k]=min(canon[k],canon[k+1]);}
   for(int k=0;k<=__builtin_popcount(a);k++)if(ordinary[k]<canon[k]){cout<<"FAIL w="<<w<<" n="<<n<<" phase="<<phase<<" A="<<a<<" first="<<__builtin_popcount(a)-k<<" final="<<ordinary[k]<<" restricted="<<canon[k]<<"\n";for(uint32_t r=a;;r=(r-1)&a){if(__builtin_popcount(r)>=k&&__builtin_popcount(N[r])==ordinary[k]){cout<<"survivor="<<r<<"\n";break;}if(!r)break;}return 0;}
  }
  cout<<"PASS phase="<<phase<<" pyramids="<<ideals.size()<<" subsets="<<tested<<"\n";
 }
}

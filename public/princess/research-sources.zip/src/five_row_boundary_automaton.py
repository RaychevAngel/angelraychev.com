"""Exact finite weighted automaton for arbitrary five-row boundary supports.

Discovery/certificate extraction. Local weights are literal outside-neighborhood
counts. Repeated all-empty/all-full column loops are suppressed; every other
reachable product-state cycle is rejected, so successful output certifies a
finite pumping scheme rather than a finite-size extrapolation.
"""
from collections import deque
from functools import lru_cache
import json,time
from pathlib import Path

WIDTH=5
FULL=(1<<WIDTH)-1
ODD=sum(1<<r for r in range(WIDTH) if r%2)
EVEN=FULL^ODD

def vertical(b):return ((b<<1)|(b>>1))&FULL

def outside(a,b,c):return (~b)&FULL&(vertical(b)|(a&ODD)|(c&EVEN))

def local_cost(a,b,c):return outside(a,b,c).bit_count()

def reduced_graph(limit=2):
    starts=[(0,b,0)for b in range(FULL+1)]
    todo=deque(starts);seen=set(starts);edges={};loops=[]
    while todo:
        state=todo.popleft();a,b,cost=state;out=[]
        for c in range(FULL+1):
            newcost=cost+local_cost(a,b,c)
            if newcost>limit:continue
            nxt=(b,c,newcost)
            if nxt==state:
                assert a==b==c and b in (0,FULL),(state,c)
                loops.append(state);continue
            out.append(nxt)
            if nxt not in seen:seen.add(nxt);todo.append(nxt)
        edges[state]=out
    return starts,edges,loops

def analyze(limit=2,include_templates=False):
    starts,edges,loops=reduced_graph(limit)
    active=set();done=set();order=[]
    def dfs(s):
        assert s not in active,('unexpected nontrivial zero-cost cycle',s)
        if s in done:return
        active.add(s)
        for t in edges[s]:dfs(t)
        active.remove(s);done.add(s);order.append(s)
    for s in starts:dfs(s)
    count={};longest={};coaccessible=set()
    for s in order:
        a,b,cost=s;accept=cost+local_cost(a,b,0)==limit
        count[s]=int(accept)+sum(count[t]for t in edges[s])
        longest[s]=max([1]if accept else[0])+0
        for t in edges[s]:
            if count[t]:longest[s]=max(longest[s],1+longest[t])
        if count[s]:coaccessible.add(s)
    result=dict(boundary=limit,states=len(edges),edges=sum(map(len,edges.values())),loop_states=loops,
                coaccessible_states=len(coaccessible),reduced_accepting_paths=sum(count[s]for s in starts),
                max_reduced_columns=max(longest[s]for s in starts),acyclic_after_loops_removed=True)
    if include_templates:
        templates=[]
        def emit(s,word,pump):
            a,b,cost=s;word=word+[b]
            if s in loops:pump=pump+[len(word)-1]
            if cost+local_cost(a,b,0)==limit:templates.append(dict(word=word,pump=pump))
            for t in edges[s]:
                if count[t]:emit(t,word,pump)
        for s in starts:
            if count[s]:emit(s,[],[])
        result['templates']=templates
    return result

if __name__=='__main__':
    begin=time.monotonic();results=[analyze(k,True)for k in [0,1,2]]
    for r in results:print({k:v for k,v in r.items()if k!='templates'})
    Path('research/five-row-boundary-automaton.json').write_text(json.dumps(dict(
        method='Exact local outside-boundary automaton, reachable-state DAG check after only empty/full self-loops are suppressed. Each recorded template denotes arbitrary nonnegative repetitions at its pump positions.',
        seconds=time.monotonic()-begin,results=results),indent=2)+'\n')


def rows_are_prefixes(word):
    return all(not any((word[i]>>r&1)==0 and (word[j]>>r&1)==1
                       for i in range(len(word))for j in range(i+1,len(word)))for r in range(WIDTH))

def certify_geometry():
    """Check universal implications on pumping templates, not on finite lengths.
    Pumping a full column adds five survivors; pumping an empty column adds five
    absent cells. Those independent affine parameters settle the size guards.
    """
    reports=[]
    for surplus in [1,2]:
        data=analyze(surplus,True);counts=dict(templates=len(data['templates']),long_templates=0)
        for t in data['templates']:
            word=t['word'];pump=t['pump'];k=sum(x.bit_count()for x in word);missing=5*len(word)-k
            pf=any(word[i]==FULL for i in pump);pe=any(word[i]==0 for i in pump)
            if len(word)<3 and not pump:continue
            counts['long_templates']+=1
            if surplus==1:
                assert (k==1 and not pf) or (missing in (1,2) and not pe),t
                continue
            if pf:assert k>=10,t # full pump already contains two full columns
            if (k>=3 or pf) and (missing>=5 or pe):
                assert rows_are_prefixes(word),('bulk-prefix',t)
            if rows_are_prefixes(word) and any(all(not(c>>r&1)for c in word)for r in range(5)):
                assert not pf and k<=5,('empty-row',t)
            if rows_are_prefixes(word) and 4<=k<=6:
                assert not pf,t
                last=word[-1]|vertical(word[-1])|((word[-2]if len(word)>1 else 0)&ODD)
                assert last==0,('last-column',t,last)
        reports.append(dict(surplus=surplus,**counts))
    return dict(status='passed',domain='Every column length q>=3, via all nonnegative pump exponents',
                implications=['surplus-one sizes are 1,h-2,h-1',
                'surplus-two sets of size3..h-5 have prefix rows',
                'a prefix surplus-two set with an empty row has size at most5',
                'a prefix surplus-two set of size4..6 has no neighbor in the last column'],checks=reports)

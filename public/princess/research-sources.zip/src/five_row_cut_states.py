"""Small directed-cut experiments for five-row even-length grids; conjecture discovery only."""
from itertools import combinations
from pathlib import Path
import json,time

def graph(q,w=5):
    h=q*w;out=[{i} for i in range(h)]
    for j in range(q):
        for r in range(w):
            v=j*w+r
            for rr in (r-1,r+1):
                if 0<=rr<w:out[v].add(j*w+rr)
            jj=j+(-1 if r%2==0 else 1)
            if 0<=jj<q:out[v].add(jj*w+r)
    return [sum(1<<x for x in row) for row in out]

def hood(mask,adj):
    r=0
    while mask:
        bit=mask&-mask;r|=adj[bit.bit_length()-1];mask^=bit
    return r

def scc(adj,cut):
    n=len(adj);active=((1<<n)-1)&~cut;seen=0;order=[]
    def visit(v):
        nonlocal seen
        seen|=1<<v
        rem=adj[v]&active&~seen
        while rem:
            bit=rem&-rem;visit(bit.bit_length()-1);rem=adj[v]&active&~seen
        order.append(v)
    rem=active
    while rem:
        bit=rem&-rem;visit(bit.bit_length()-1);rem=active&~seen
    rev=[0]*n
    for v in range(n):
        rem=adj[v]
        while rem:
            bit=rem&-rem;rev[bit.bit_length()-1]|=1<<v;rem^=bit
    seen=0;groups=[]
    def fill(v):
        nonlocal seen
        seen|=1<<v;result=1<<v;rem=rev[v]&active&~seen
        while rem:
            bit=rem&-rem;result|=fill(bit.bit_length()-1);rem=rev[v]&active&~seen
        return result
    for v in reversed(order):
        if not(seen>>v&1):groups.append(fill(v))
    return groups

def critical_sets(q):
    adj=graph(q);h=len(adj);sets={};max_scc=0
    for cutsize in [1,2]:
        for cc in combinations(range(h),cutsize):
            cut=sum(1<<v for v in cc);groups=scc(adj,cut);max_scc=max(max_scc,len(groups))
            assert len(groups)<=12,(q,cc,len(groups))
            for code in range(1,1<<len(groups)):
                mask=0
                for j,g in enumerate(groups):
                    if code>>j&1:mask|=g
                nb=hood(mask,adj)
                if nb&~mask&~cut==0:sets[mask]=(nb&~mask).bit_count()
    return adj,sets,max_scc

def investigate(q):
    adj,sets,cmax=critical_sets(q);h=len(adj)
    def reflect(mask):
        return sum(1<<((q-1-j)*5+r) for j in range(q) for r in range(5) if mask>>(j*5+r)&1)
    buckets={}
    for mask,c in sets.items():
        if c==2:buckets.setdefault(mask.bit_count(),[]).append(reflect(mask))
    compatible=[];samples=[]
    for r,c in sets.items():
        if c!=2:continue
        k=r.bit_count();nb=hood(r,adj)
        for rr in buckets.get(k-1,[]):
            if rr&~nb==0:
                compatible.append(k)
                if len(samples)<20:samples.append(dict(size=k,first=[(v//5,v%5)for v in range(h)if r>>v&1],second=[(v//5,v%5)for v in range(h)if rr>>v&1]))
    return dict(n=2*q,h=h,critical_sets=len(sets),max_scc=cmax,surplus_one_sizes=sorted({m.bit_count()for m,c in sets.items()if c==1}),surplus_two_sizes=sorted({m.bit_count()for m,c in sets.items()if c==2}),consecutive_surplus_two_sizes=sorted(set(compatible)),compatible_pairs=len(compatible),samples=samples)

if __name__=='__main__':
    start=time.monotonic();rows=[]
    for q in range(3,11):
        r=investigate(q);rows.append(r);print({k:v for k,v in r.items()if k!='samples'},flush=True)
    Path('research/five-row-cut-states.json').write_text(json.dumps(dict(method='Enumerate outgoing closed unions of SCCs after every one/two-vertex deletion of the matched directed grid. Exact finite critical sets; no unbounded theorem claimed.',seconds=time.monotonic()-start,results=rows),indent=2)+'\n')

"""Small independent coordinate audit of the new anchored inequalities.

The unbounded theorem is proved in maturation-even-transitions.md Sections8-9.
This script checks one quadrant window and one half-strip window, including
neighbors outside the support window, rather than seeking finite game times.
"""
from itertools import product
from pathlib import Path
from time import process_time
import json
import math

ROOT = Path(__file__).resolve().parents[1]


def Q(k):
    q = 1
    while k > q*(q-1):
        q += 1
    return q


def N(s, width=None):
    return {(x+dx, y+dy) for x,y in s for dx,dy in ((-1,0),(1,0),(0,-1),(0,1))
            if x+dx >= 0 and y+dy >= 0 and (width is None or x+dx < width)}


def quadrant():
    row = [v for v in product(range(5), repeat=2) if sum(v) % 2 == 0 and v != (0,0)]
    tests = 0
    for mask in range(1, 1 << len(row)):
        s = {v for i,v in enumerate(row) if mask >> i & 1}
        delta = len(N(s))-len(s)
        assert len(s) <= delta*(delta-1)
        counts = [sum(x+y == 2*j for x,y in s) for j in range(5)] + [0]
        shifted = {(2*j-y, y) for j,k in enumerate(counts) for y in range(k)}
        assert (0,0) not in shifted and len(shifted) == len(s)
        ns = N(shifted)
        assert len(ns) <= len(N(s))
        layer_counts = [max(k+bool(k), counts[j+1]-(counts[j+1] == 2*j+3))
                        for j,k in enumerate(counts[:-1])]
        assert sum(layer_counts) == len(ns)
        d = len(ns)-len(s)
        occupied = [j for j,k in enumerate(counts) if k]
        L = len(occupied)
        assert d >= L+1
        assert all(counts[j] <= d-L+2*r-1 for r,j in enumerate(occupied, 1))
        tests += 1
    return tests


def halfstrip():
    width, height, b = 6, 6, 3
    rows = []
    for p in (0,1):
        vertices = [(x,y) for x in range(width) for y in range(height) if (x+y) % 2 == p]
        opposite = [(x,y) for x in range(width) for y in range(height+1) if (x+y) % 2 != p]
        index = {v:i for i,v in enumerate(opposite)}
        nb = [sum(1 << index[u] for u in N({v}, width)) for v in vertices]
        neighborhoods = [0]*(1 << len(vertices))
        omitted = [math.inf]*(len(vertices)+1)
        outgoing = [math.inf]*(len(vertices)+1)
        c = vertices.index((0,0) if p == 0 else (width-1,0))
        next_c = index[(width-1,0) if p == 0 else (0,0)]
        cheap = 0
        for mask in range(1, len(neighborhoods)):
            bit = mask & -mask
            hood = neighborhoods[mask ^ bit] | nb[bit.bit_length()-1]
            neighborhoods[mask] = hood
            k = mask.bit_count()
            size = hood.bit_count()
            surplus = size-k
            if not mask >> c & 1:
                assert size >= k+min(Q(k),b+1)
                omitted[k] = min(omitted[k], size)
            if hood >> next_c & 1:
                assert size >= k+min(Q(k),b)
                outgoing[k] = min(outgoing[k], size)
            if surplus < b and k > surplus*(surplus-1):
                assert mask >> c & 1
                assert not hood >> next_c & 1
                cheap += 1
        assert all(omitted[k] == k+min(Q(k),b+1) for k in range(1,len(vertices)))
        assert all(outgoing[k] == k+min(Q(k),b) for k in range(1,len(vertices)+1))
        rows.append({'physical_color': p, 'subsets_checked': len(neighborhoods)-1,
                     'forced_corner_switches': cheap,
                     'omitted_profile': omitted[1:-1], 'outgoing_profile': outgoing[1:]})
    return rows


def main():
    start = process_time()
    receipt = {'scope': 'Finite supplement to an unbounded ordinary anchored-profile proof; no game-time enumeration.',
               'quadrant_sets': quadrant(), 'halfstrip': halfstrip()}
    receipt['cpu_seconds'] = process_time()-start
    (ROOT/'research/maturation-even-anchored-check.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({'quadrant_sets': receipt['quadrant_sets'],
                      'halfstrip_sets': sum(r['subsets_checked'] for r in receipt['halfstrip']),
                      'cpu_seconds': receipt['cpu_seconds']}))


if __name__ == '__main__':
    main()

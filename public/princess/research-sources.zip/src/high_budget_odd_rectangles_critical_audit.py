"""Bounded independent attack on the final ordinary equality argument.

Theorems are proved in research/high-budget-odd-rectangles.md Section 16;
this file tests their delicate scalar endpoints without pretending finite
checks prove the unbounded statements.
"""
import json
from pathlib import Path
from time import monotonic
from high_budget_odd_rectangles import J,delta,profile,potential,corner_constant,discount_threshold,exact,candidate


def remainders(b,m,value):
    D=2*m-2*b-1;lo=1;hi=D
    while lo<hi:
        mid=(lo+hi)//2
        if J(b,mid)<value:lo=mid+1
        else:hi=mid
    while lo<D and J(b,lo)==value:
        yield lo;lo+=1


def run():
    start=monotonic();counts={'critical_arithmetic':0,'proper_clipped_steps':0,'first_day_splits':0,'physical_times':0};failures=[]
    for b in range(3,61):
        B=b*b;w=2*b+1
        for m in range(B+1,B+b):
            D=2*m-w
            for target in sorted({m//2,(m+1)//2,(m+2)//2}):
                for r in remainders(b,m,target):
                    eta=int(m<=discount_threshold(b,r));de=delta(b,r);tau=2*J(b,r)-m
                    counts['critical_arithmetic']+=1
                    if eta and de:failures.append(['discount-delta',b,m,r])
                    case='A' if eta==0 and tau==0 and de==1 else 'B' if eta==1 and tau==1 else 'C' if eta==1 and tau==2 else None
                    if case is None or b>10:continue
                    q=3 if r%2==0 else 2
                    while (q*D+r+w)//2 <2*B+2*b:q+=2
                    h=(q*D+r+w)//2;N=2*h+1;C=q*m+J(b,r)-eta
                    def F(u):return potential(b,m,u)
                    def phi(z,k):return min(F(2*k+z),C-(h+1-z-k)) if k else 0
                    def quotient(u):return max(0,u-w-2)//D
                    actual_C=min(x+F(2*profile(b,h,z,h+1-z-x)+1-z) for z in(0,1) for x in range(B+1))
                    if actual_C!=C:failures.append(['corner-constant',b,m,r,C,actual_C])
                    if case in('A','B'):
                        for z in(0,1):
                            for d in range(1,B+1):
                                k=h+1-z-d;u=2*k+z
                                for p in range(min(m,B-d)+1):
                                    nxt=profile(b,h,z,k-p);v=2*nxt+1-z
                                    slack=p+phi(1-z,nxt)-phi(z,k)
                                    counts['proper_clipped_steps']+=1
                                    if slack<0 or slack==0 and (p==0 or quotient(v)!=quotient(u)-1):
                                        failures.append(['proper-tight',case,b,m,r,z,d,p,slack,quotient(u),quotient(v)])
                    if case in('B','C'):
                        for p in range(m+1):
                            ne=profile(b,h,0,h+1-p);no=profile(b,h,1,h-(m-p))
                            slack=m+phi(1,ne)+phi(0,no)-2*C;counts['first_day_splits']+=1
                            if slack<1:failures.append(['first-slack',case,b,m,r,p,slack])
                            fullE=ne==h;fullO=no==h+1
                            if case=='B' and slack==1 and fullE!=fullO:
                                proper_u=2*no if fullE else 2*ne+1
                                if quotient(proper_u)!=q-1:failures.append(['first-one-proper',b,m,r,p,proper_u,quotient(proper_u),q])
                    if b<=8:
                        ns=[n for n in range(w,w+2*D,2) if (w*n-w-1)%D==r]
                        for n in ns[:1]:
                            observed=exact(w,n,m);upper=candidate(w,n,m);counts['physical_times']+=1
                            if observed!=upper:failures.append(['time',w,n,m,observed,upper])
    result={'purpose':__doc__,'counts':counts,'failures':failures,'seconds':round(monotonic()-start,3)}
    Path('research/high-budget-odd-rectangles-critical-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':run()

"""Does a serial strategy maximize cleared count at every prescribed day?"""
from pathlib import Path
from time import process_time
import json
from odd_serial_first_order_attack import profiles

def serial_step(g,m,state,first,t):
    a,b=state;active=first^(t%2)
    if active==0:
        p=min(a,m);q=m-p
    else:q=min(b,m);p=m-q
    return g[1][max(0,b-q)],g[0][max(0,a-p)]

def main(limit=15):
 starttime=process_time();cases=days=0;fail=None
 for b in range(1,8):
  for a in range(b,b+3):
   g=profiles(a,b);start=(len(g[0])-1,len(g[1])-1)
   for m in range(b+1,min(b+8,len(g[1]))):
    candidates=[start,start];R={start};cases+=1
    for t in range(3*sum(start)):
     nextR={(g[1][max(0,y-m+p)],g[0][max(0,x-p)])for x,y in R for p in range(m+1)}
     candidates=[serial_step(g,m,candidates[i],i,t)for i in (0,1)]
     got=min(map(sum,nextR));serial=min(map(sum,candidates));days+=1
     if got<serial:
      fail={'shape':[2*a+1,2*b+1],'m':m,'day':t+1,'minimum_belief':got,'serial_belief':serial,'minimizers':[s for s in nextR if sum(s)==got],'serial_states':candidates};break
     if got==0:break
     R=nextR
    if fail or process_time()-starttime>limit:break
   if fail or process_time()-starttime>limit:break
  if fail or process_time()-starttime>limit:break
 out={'scope':'Prescribed-day total-deficit concentration; stronger than capture optimality.','cases':cases,'day_checks':days,'failure':fail,'CPU_seconds':process_time()-starttime}
 Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-timed-concentration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()

"""Bounded width-parameter probes of a persistent terminal envelope.

Finite evidence for a general theorem search, not a family classification.
"""
from pathlib import Path
import json,pickle,time,argparse
from bridge_lower_frontier_fast import build
from bridge_lower_frontier_nine import root,pronic,step
from bridge_upper_transport_verify_reach import verify

def tail(b,phase):
    size=b*b+b+1;days=0
    while size:
        size=max(0,size-b-1)
        if size:size+=min(root(size),b)if phase==0 else min(pronic(size),b+1)
        phase^=1;days+=1
    return days

def run(width_parameters,max_seconds=50,output='research/bridge-lower-frontier-terminal-family-check.json'):
    started=time.process_time();results=[]
    for b in width_parameters:
        n=2*b+2;k=b+1;h=(2*b+1)*(b+1);K=b*b+b+1
        path=Path(f'.build/bridge-lower-frontier-weighted-{b}-{n}-{k}.pickle')
        if not path.exists():
            data=build(b,n,k)
            with path.open('wb')as f:pickle.dump(data,f)
        physical=[tail(b,p)for p in(0,1)];front={(c,e):0 for c in range(3)for e in range(3)}
        for _ in range(min(physical)):front=step(b,h,k,front,strong_band=True)
        row=dict(b=b,width=2*b+1,length=n,budget=k,boundary=K,physical_tails=physical,old_deadline_hull=[front[c,e]for c in range(3)for e in range(3)],features=[])
        for c in range(3):
            ans=verify(w=2*b+1,n=n,k=k,seed_size=K,seed_feature=(c,0),cpu_limit=15)
            row['features'].append(dict(c=c,e=0,days=ans['solo_days'],residual=ans['minimum_before_first_capture'],augmented_states=ans['augmented_states'],CPU_seconds=ans['CPU_seconds']))
        results.append(row);print(json.dumps(row),flush=True)
        Path(output).write_text(json.dumps(dict(scope=__doc__,rows=results,CPU_seconds=time.process_time()-started),indent=2)+'\n')
        if time.process_time()-started>max_seconds:break
    return results

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--b',default='6,8,10,12,14,16,20');p.add_argument('--output',default='research/bridge-lower-frontier-terminal-family-check.json');a=p.parse_args();run(list(map(int,a.b.split(','))),output=a.output)

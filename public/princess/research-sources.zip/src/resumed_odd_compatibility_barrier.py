"""Focused, exact precentral tests of a sufficient odd-board ancestry barrier.

No tested condition is promoted to a theorem. The retained recurrence is
already proved exact; this explores only its full-board precentral output.
"""
from pathlib import Path
import json
from time import process_time
from supersession_solo_bands import OddRectangle
from supersession_odd_midpoint_bounded import retained_step, union_max
from maturation_odd_ammunition import growth_cost


def inspect(w,n,m,seconds=3):
    G=OddRectangle(w,n);tau=G.half_time(m)['tau'];L=tau-1
    a=c=0;front=[(0,0)];start=process_time();max_credit=None;worst=None
    for t in range(L):
        front,a,c=retained_step(G,m,front,a,c)
        if process_time()-start>seconds:
            return dict(w=w,n=n,m=m,complete=False,last_time=t+1,seconds=process_time()-start)
    delta=abs(a-c)
    out=dict(w=w,n=n,m=m,complete=True,L=L,D=[a,c],delta=delta,frontier_size=len(front),seconds=process_time()-start)
    if not delta:
        out['solo_tie']=True;return out
    primary=int(c>a);secondary=1-primary;A=max(a,c);B=min(a,c)
    Cs=G.E if secondary==0 else G.M;crit=(Cs-m+1)//2
    over=growth_cost(G.b,m,secondary,crit)-crit
    ex=[v for v in front if min(v)>0 and sum(v)>B]
    for v in ex:
        lag=A-v[primary];s=v[secondary]
        credit=growth_cost(G.b,m,secondary,s)-lag
        if max_credit is None or credit>max_credit:max_credit=credit;worst=v
    out.update(primary=primary,secondary_class=Cs,critical_secondary=crit,critical_overhead=over,barrier_margin=over-delta,exceptional_count=len(ex),max_secondary=max([v[secondary] for v in ex],default=0),max_credit=max_credit,credit_witness=worst,solo_central=G.E+G.M-a-c,actual_central=G.E+G.M-union_max(G,front))
    return out


def main():
    start=process_time();rows=[]
    for w in [7,9,11,15,21,31,41]:
        b=(w-1)//2
        budgets=sorted({b+2,2*b,(b*b+1)//2,b*b})
        for m in budgets:
            if m<=b+1 or m>b*b:continue
            for n in [w,w+2,3*w]:
                rows.append(inspect(w,n,m))
                if process_time()-start>12:break
            if process_time()-start>12:break
        if process_time()-start>12:break
    out=dict(scope='Focused precentral ancestry/ammunition barrier tests; no proof of universal hypotheses',seconds=process_time()-start,cases=rows)
    Path('research/resumed-odd-compatibility-barrier.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(seconds=out['seconds'],cases=len(rows),complete=sum(x['complete'] for x in rows),barrier_failures=[x for x in rows if x.get('barrier_margin',1)<=0],credit_failures=[x for x in rows if (x.get('max_credit') or 0)>1],largest_credit=max([x['max_credit'] for x in rows if x.get('max_credit') is not None],default=None)),indent=2))

if __name__=='__main__':main()

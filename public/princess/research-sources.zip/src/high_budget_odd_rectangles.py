"""Fixed-width high-budget odd rectangle formula experiments.

Exactness of the two-count solver uses the proved odd-rectangle profiles.
The J/delta formula has an independently reviewed ordinary proof for
m >= b^2+1. Its root-free special case holds for m >= 2b^2+1.
Smaller budgets are outside the theorem and can violate the formula.
"""
from math import isqrt
from collections import deque
import heapq


def R(k):
    return isqrt(k)+(isqrt(k)**2<k)


def Q(k):
    r=isqrt(k)
    while r*(r-1)<k:r+=1
    return max(1,r)


def low(b,z,k):
    if not k:return 0
    return k+min(R(k),b) if z==0 else k+min(Q(k),b+1)


def profile(b,h,z,k):
    if not k:return 0
    if z==0:return k+min(R(k),b,R(h+1-k)-1)
    return k+min(Q(k),b+1,Q(h-k))


def J(b,r):
    return low(b,1,r//2) if r%2==0 else low(b,0,(r+1)//2)


def delta(b,r):
    if not r:return 0
    alternate=low(b,0,r//2+1) if r%2==0 else low(b,1,(r+1)//2)
    return alternate-J(b,r)


def potential(b,m,u):
    if u//2<=m:return u//2
    d=2*m-(2*b+1)
    q,r=divmod(u-(2*b+2),d)
    return q*m+J(b,r)


def candidate(w,n,m):
    h=(w*n-1)//2;b=(w-1)//2
    if m>=2*h+1:return 1
    if m>=h:return 2
    q,r=divmod(w*n-w-1,2*m-w)
    return 2*q+(0 if not r else 1 if m>=2*J(b,r)+delta(b,r) else 2)


def high_budget_formula(w,n,m):
    """Simple residue formula in the uniform proved high-budget range."""
    b=(w-1)//2;h=(w*n-1)//2
    assert w>=3 and w%2==1 and n>=w and n%2==1 and m>=2*b*b+1
    if m>=w*n:return 1
    if m>=h:return 2
    q,r=divmod(w*n-w-1,2*m-w)
    cutoff=m-w-1+(m==2*b*b+1)
    return 2*q+(0 if r==0 else 1 if r<=cutoff else 2)


def closed_formula(w,n,m):
    """Independently reviewed exact formula for every m >= b^2+1."""
    b=(w-1)//2
    assert w>=3 and w%2 and n>=w and n%2 and m>=b*b+1
    return candidate(w,n,m)


def corner_constant(w,n,m):
    b=(w-1)//2;h=(w*n-1)//2
    return min(x+potential(b,m,2*profile(b,h,z,h+1-z-x)+1-z)
               for z in (0,1) for x in range(b*b+1))


def discount_threshold(b,r,details=False):
    """Four endpoint tests for the possible one-inspection corner discount.

    Derived from convex quadratics on root bands; ordinary proof independently reviewed.
    Empty candidate intervals contribute nothing.
    """
    k=r//2;c=min(R(k+1),b) if r%2 else (min(Q(k),b+1) if k else 0)
    candidates=[]
    def include(label,lo,hi,f):
        if lo<=hi:
            for a in sorted({lo,hi}):candidates.append((label,a,f(a)))
    if r%2:
        include('E',Q(k+1),min(b,b+c-2),
                lambda a:(b-a+c)*(b-a+c-1)+b+a*a-a-k)
        include('O',1+R(k+2),b,
                lambda a:(b-a+c)**2+b+a*a-2*a-k)
    else:
        include('E',Q(k+1),min(b,b+c-2),
                lambda a:(b-a+c-1)**2+b+a*a-a-k)
        include('O',1+R(k+1),min(b,b+c-2),
                lambda a:(b-a+c)*(b-a+c-1)+b+a*a-2*a-k+1)
    value=max((t for _,_,t in candidates),default=-1)
    return (value,candidates) if details else value


def corner_constant_explicit(w,n,m):
    b=(w-1)//2
    assert w>=3 and w%2==1 and n>=w and n%2==1
    assert m>=b*b+1 and m<(w*n-1)//2
    _,r=divmod(w*n-w-1,2*m-w)
    return potential(b,m,w*n)-int(m<=discount_threshold(b,r))


def envelope(w,n,m,z,k):
    if not k:return 0
    h=(w*n-1)//2;b=(w-1)//2;C=corner_constant(w,n,m)
    return min(potential(b,m,2*k+z),max(0,C-(h+1-z-k)))


def direct_strategy(w,n,m,coordinates=False):
    """Uniform physical schedule; independent coordinate neighborhood replay."""
    from nested_grid_time import ordered_profiles,neighborhood
    b=(w-1)//2;h=(w*n-1)//2
    assert w>=3 and w%2 and n>=w and n%2 and m>=b*b+1
    report,data=ordered_profiles((n,w))
    assert report['nested']
    coords,adj,orders,prefixes,profiles=data
    if m>=w*n:
        plans=[(h+1,h)];first=0
    elif m>=h:
        plans=[(h,0),(0,h)];first=1
    else:
        q,r=divmod(w*n-w-1,2*m-w);first=1
        if r==0:
            plans=[(m,0)]*q+[(0,m)]*q
        elif 2*J(b,r)+delta(b,r)<=m:
            plans=[(m,0)]*q+[(J(b,r),J(b,r)+delta(b,r))]+[(0,m)]*q
        else:
            plans=[(m,0)]*(q+1)+[(0,m)]*(q+1)
    counts=[h+1-first,h+first]
    belief=(1<<(w*n))-1;shots=[]
    for day,allocations in enumerate(plans):
        shot=0;nextcounts=[]
        for cohort,p in enumerate(allocations):
            z=first^cohort^(day%2);k=counts[cohort]
            support=prefixes[z][k];remain=prefixes[z][max(0,k-p)]
            assert support&~belief==0
            shot|=support^remain
            after=neighborhood(remain,adj)
            assert after==prefixes[1-z][profile(b,h,z,max(0,k-p))]
            nextcounts.append(after.bit_count())
        assert shot.bit_count()<=m
        belief=neighborhood(belief&~shot,adj);shots.append(shot);counts=nextcounts
    assert not belief and len(shots)==candidate(w,n,m)
    result=dict(w=w,n=n,m=m,turns=len(shots))
    if coordinates:
        result['inspections']=[[coords[i] for i in range(len(coords)) if s>>i&1] for s in shots]
    return result


def exact(w,n,m):
    h=(w*n-1)//2;b=(w-1)//2
    tables=[[profile(b,h,z,k) for k in range(h+2-z)] for z in(0,1)]
    frontier={(h+1,h)}
    for day in range(1,20*h+1):
        if any(a+c<=m for a,c in frontier):return day
        nexts={}
        for a,c in frontier:
            for p in range(max(0,m-c),min(m,a)+1):
                out=(tables[1][max(0,c-m+p)],tables[0][max(0,a-p)])
                if out[1]<nexts.get(out[0],10**9):nexts[out[0]]=out[1]
        frontier=set();best=10**9
        for a,c in sorted(nexts.items()):
            if c<best:frontier.add((a,c));best=c
    raise RuntimeError('iteration guard')


def ammunition(w,n,m):
    h=(w*n-1)//2;b=(w-1)//2;rev={};dist={};todo=[]
    for z in(0,1):
        for k in range(h+2-z):
            for p in range(min(m,k)+1):
                out=(profile(b,h,z,k-p),1-z)
                rev.setdefault(out,[]).append(((k,z),p))
        dist[(0,z)]=0;heapq.heappush(todo,(0,0,z))
    while todo:
        cost,k,z=heapq.heappop(todo)
        if dist[(k,z)]!=cost:continue
        for source,p in rev.get((k,z),[]):
            new=cost+p
            if new<dist.get(source,10**9):
                dist[source]=new;heapq.heappush(todo,(new,*source))
    return dist[(h+1,0)]

#!/usr/bin/env python3
"""Independent physical-set checks of the quadrant and far-edge proof steps."""
from itertools import product
from pathlib import Path
from time import monotonic
import json
from odd_rectangle_profile_attack import data,masks_for_pattern


def neighborhood(vertices,shape=None):
    result=set()
    for v in vertices:
        for d in(0,1):
            for s in(-1,1):
                w=list(v);w[d]+=s
                if min(w)>=0 and(shape is None or all(w[i]<shape[i]for i in(0,1))):result.add(tuple(w))
    return result


def run(shape):
    points,ids,nbs=data(shape)
    patterns={r:list(masks_for_pattern(shape,r,ids,nbs))for r in product((0,1),repeat=2)}
    result={'shape':shape,'supports':0,'corner':0,'strip':0,'complement':0}
    a,b=[(n-1)//2 for n in shape]
    for p in(0,1):
        parts=[v for r,v in patterns.items()if sum(r)%2==p]
        for m0,_ in parts[0]:
            for m1,_ in parts[1]:
                mask=m0|m1;vertices={v for i,v in enumerate(points[p])if mask>>i&1}
                nb=neighborhood(vertices,shape);nbq=neighborhood(vertices)
                delta=len(nb)-len(vertices);deltaq=len(nbq)-len(vertices)
                ee=[sum(y==2*i for x,y in vertices)for i in range(b+1)]
                oo=[sum(y==2*i+1 for x,y in vertices)for i in range(b)]
                assert all(not k or k+i+p<=deltaq for i,k in enumerate(ee))
                assert all(not k or k+i+1<=deltaq for i,k in enumerate(oo))
                assert len(vertices)<=deltaq*(deltaq-p)
                f=sum(x==2*a for x,y in vertices);z=sum(y==2*b for x,y in vertices)
                assert deltaq==delta+f+z
                result['supports']+=1
                if bool(f)!=bool(z):
                    assert delta>=b+p
                    result['strip']+=1
                elif not f:
                    assert deltaq==delta
                    result['corner']+=1
                else:
                    assert all(v in nb for v in points[1-p]if 0 in v)
                    comp={(2*a-x,2*b-y)for x,y in set(points[1-p])-nb}
                    assert neighborhood(comp)==neighborhood(comp,shape)
                    compdelta=len(neighborhood(comp))-len(comp)
                    assert compdelta<=delta+1-2*p
                    result['complement']+=1
    return result


if __name__=='__main__':
    start=monotonic();rows=[run(shape)for shape in((3,3),(5,3),(7,5),(7,7))]
    result={'scope':'Checks actual point sets and neighborhoods against each quadrant row bound and the corner/strip/complement dichotomy; does not replace the general proof.','results':rows,'seconds':round(monotonic()-start,4)}
    Path(__file__).resolve().parents[1].joinpath('research/odd-rectangle-geometry-checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

"""Reproduce two precise failures of joint corner scheduling shortcuts."""
from maturation_odd_ammunition import inverse, lower, growth_cost
from supersession_odd_midpoint_bounded import pareto
import json


def step(b, m, state, p):
    x, y = state
    return inverse(b, 0, y + m - p), inverse(b, 1, x + p)


def serial_front(b, m, days):
    points = []
    for initial in (0, 1):
        for switch in range(days):
            for shared_quota in range(m + 1):
                state = (0, 0)
                for day in range(days):
                    quota = m if day < switch else shared_quota if day == switch else 0
                    p = quota if initial ^ (day % 2) == 0 else m - quota
                    state = step(b, m, state, p)
                points.append(state)
    return pareto(points)


def check():
    # Exact single-cohort costs fit the total two-day quota, but their
    # phase-correct one-day blocks both require the final day.
    target = (3, 2)
    costs = [growth_cost(3, 5, p, target[p]) for p in (0, 1)]
    one = {step(3, 5, (0, 0), p) for p in range(6)}
    two = {step(3, 5, s, p) for s in one for p in range(6)}
    assert costs == [5, 4] and sum(costs) <= 10
    assert not any(x >= 3 and y >= 2 for x, y in two)
    assert lower(3, 0, 3) + lower(3, 1, 2) == 9 > 3 + 5

    # One shared day between two pure blocks misses a reachable point.
    word = (7, 0, 1, 5)
    state = (0, 0)
    trace = [state]
    for p in word:
        state = step(4, 7, state, p)
        trace.append(state)
    assert state == (5, 6)
    serial = serial_front(4, 7, 4)
    assert not any(x >= 5 and y >= 6 for x, y in serial)
    return {'ammunition_only': {'b': 3, 'm': 5, 'days': 2,
                                'target': target, 'separate_costs': costs,
                                'reachable_frontier': pareto(two)},
            'two_block_seriality': {'b': 4, 'm': 7, 'days': 4,
                                    'physical_color0_quotas': word,
                                    'trace': trace, 'serial_frontier': serial,
                                    'limitation': 'target is low-total, so not a scalar midpoint counterexample'},
            'passed': True}


if __name__ == '__main__':
    print(json.dumps(check(), indent=2))

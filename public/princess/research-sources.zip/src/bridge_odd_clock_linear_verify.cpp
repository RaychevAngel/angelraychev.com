// Independent integer implementation of the accepted retained midpoint model.
// Input: width length budget expected_tau expected_time, one case per line.
// Every quota split is evaluated; no temporal or geometric approximation.
#include <algorithm>
#include <cmath>
#include <ctime>
#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>

using Point=std::pair<int,int>;

int floor_root(int z) {
    int r=static_cast<int>(std::sqrt(static_cast<double>(z)));
    while ((r+1)*(r+1)<=z) ++r;
    while (r*r>z) --r;
    return r;
}
int square_ceiling(int z) {
    const int r=floor_root(z);
    return r+(r*r<z);
}
int pronic_ceiling(int z) {
    int r=floor_root(z);
    while (r*(r+1)<z) ++r;
    while (r>0 && (r-1)*r>=z) --r;
    return r;
}

struct Board {
    int w,n,m,b,E,M;
    Board(int ww,int nn,int mm):w(ww),n(nn),m(mm),b((ww-1)/2),
        E((ww*nn+1)/2),M(E-1) {}
    int inverse(int p,int z) const {
        const int source_capacity=p==0 ? M:E;
        const int target_capacity=p==0 ? E:M;
        if (z>=source_capacity) return target_capacity;
        if (p==0) return z-std::min({pronic_ceiling(z),b,pronic_ceiling(M-z)});
        return z-std::min({square_ceiling(z),b+1,1+square_ceiling(E-z)});
    }
};

std::vector<Point> pareto(std::vector<Point> candidates) {
    std::sort(candidates.begin(),candidates.end(),[](Point a,Point b) {
        return a.first!=b.first ? a.first>b.first : a.second>b.second;
    });
    std::vector<Point> result;
    int largest_y=-1;
    for (Point p:candidates) {
        if (p.second>largest_y) {
            result.push_back(p);
            largest_y=p.second;
        }
    }
    return result;
}

int main() {
    int w,n,m,expected_tau,expected_time;
    unsigned long long all_splits=0;
    const std::clock_t total_start=std::clock();
    int case_count=0;
    while (std::cin>>w>>n>>m>>expected_tau>>expected_time) {
        const std::clock_t started=std::clock();
        if (w<3 || n<w || w%2!=1 || n%2!=1 || m<(w+1)/2)
            throw std::runtime_error("invalid input");
        const Board G(w,n,m);
        int a=0,c=0,day=0,max_frontier=1;
        unsigned long long splits=0;
        std::vector<Point> front={{0,0}};
        for (;;) {
            const int aa=G.inverse(0,c+m), cc=G.inverse(1,a+m);
            if (aa==G.E || cc==G.M) break;
            const int threshold=std::min(aa,cc);
            std::vector<Point> next={{aa,0},{0,cc}};
            for (Point old:front) {
                for (int quota=0;quota<=m;++quota) {
                    const int x=G.inverse(0,old.second+m-quota);
                    const int y=G.inverse(1,old.first+quota);
                    ++splits;
                    if (x>0 && y>0 && x+y>threshold) next.emplace_back(x,y);
                }
            }
            front=pareto(std::move(next));
            a=aa;c=cc;++day;
            max_frontier=std::max(max_frontier,static_cast<int>(front.size()));
        }
        int max_union=0;
        for (Point x:front) for (Point y:front)
            max_union=std::max(max_union,std::min(G.E,x.first+y.first)
                                          +std::min(G.M,x.second+y.second));
        const int central=G.E+G.M-max_union;
        const int tau=day+1;
        const int answer=2*tau-(central<=m);
        if (tau!=expected_tau || answer!=expected_time)
            throw std::runtime_error("finite scalar claim failed");
        ++case_count;all_splits+=splits;
        std::cout<<"{\"width\":"<<w<<",\"length\":"<<n<<",\"budget\":"<<m
            <<",\"b\":"<<G.b<<",\"E\":"<<G.E<<",\"M\":"<<G.M
            <<",\"tau\":"<<tau<<",\"time\":"<<answer
            <<",\"solo_deficits\":["<<a<<","<<c<<"]"
            <<",\"scalar_central_cost\":"<<G.E+G.M-a-c
            <<",\"exact_central_cost\":"<<central
            <<",\"final_frontier_size\":"<<front.size()
            <<",\"maximum_frontier\":"<<max_frontier
            <<",\"quota_splits\":"<<splits
            <<",\"cpu_seconds\":"<<double(std::clock()-started)/CLOCKS_PER_SEC
            <<"}\n";
    }
    std::cerr<<"cases="<<case_count<<" splits="<<all_splits
             <<" cpu_seconds="<<double(std::clock()-total_start)/CLOCKS_PER_SEC<<"\n";
}

"""Package independently replayed schedules for the four-cube web explorer."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
from publication_paths import SITE
source = json.loads((ROOT / 'research/even-resume-four-cube-exact.json').read_text())
endpoints = (8, 9, 10, 11, 12, 13, 15, 16, 18, 19, 26, 32)
expected = (40, 20, 16, 12, 10, 8, 7, 6, 5, 4, 3, 2)
cases = {r['budget']: r for r in source['results']}
vertices = [(x, y, z) for x in range(4) for y in range(4) for z in range(4)]
adj = {v: {w for w in vertices if sum(abs(a-b) for a,b in zip(v,w)) == 1}
       for v in vertices}
pack = {}
checks = []
for budget in range(1, 65):
    if budget < 8:
        pack[str(budget)] = {'days': None, 'shots': []}
        continue
    if budget == 64:
        shots, days = [vertices], 1
    else:
        e = max(x for x in endpoints if x <= budget)
        row = cases[e]
        days = expected[endpoints.index(e)]
        assert row['minimum_turns'] == days
        shots = [[tuple(v) for v in s] for s in row['shots']]
    belief = set(vertices)
    for day, shot in enumerate(shots, 1):
        shot = set(shot)
        assert len(shot) <= budget and shot <= set(vertices)
        survivors = belief - shot
        if not survivors:
            assert day == days == len(shots)
            break
        belief = set().union(*(adj[v] for v in survivors))
    else:
        raise AssertionError(f'Schedule does not capture at budget {budget}')
    pack[str(budget)] = {
        'days': days,
        'shots': [[16*x+4*y+z for x,y,z in s] for s in shots],
    }
    checks.append({'budget': budget, 'days': days, 'physical_replay': True})
(SITE / 'src/lib/four-cube-strategies.json').write_text(json.dumps(pack, separators=(',', ':'))+'\n')
(ROOT / 'research/four-cube-explorer-replay.json').write_text(json.dumps({
    'scope': 'All 57 feasible displayed budgets; impossibility and minimality come from FourCubeClassification.',
    'checks': checks,
}, indent=2)+'\n')
print(f'Four-cube explorer: {len(checks)} physical schedule replays passed.')

#!/usr/bin/env python3
"""Seven-day physical example for the uniform even-short-side theorem.
The image uses before-inspection beliefs, and every transition is replayed
from coordinate adjacency. No scalar-only trajectory is drawn.
"""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from uniform_even_high_budget_audit import run_case

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'paper/figures'
OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
    'svg.fonttype':'none','svg.hashsalt':'princess-research','pdf.fonttype':42,
    'axes.spines.top':False,'axes.spines.right':False})

result=run_case(3,9,10,return_schedule=True)
shots=[set(map(tuple,A)) for A in result.pop('schedule')]
vertices={(x,y) for x in range(6) for y in range(9)}
def neighbors(S):
    return {(u,v) for x,y in S for u,v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if (u,v) in vertices}

records=[];belief=set(vertices)
for day,A in enumerate(shots,1):
    assert len(A)<=10
    survivors=belief-A;following=neighbors(survivors)
    records.append(dict(day=day,before=sorted(belief),inspections=sorted(A),
        survivors=sorted(survivors),next_belief=sorted(following)))
    assert day==7 or survivors
    belief=following
assert not belief and len(records)==result['minimum']==7

fig,axes=plt.subplots(2,4,figsize=(6.8,3.92))
fig.subplots_adjust(left=.02,right=.985,bottom=.035,top=.865,wspace=.17,hspace=.56)
fig.suptitle('6 × 9 rooms · at most 10 inspections per day',y=.985,fontsize=11)
fig.text(.5,.925,'Each board shows possible positions before that day’s inspection.',
         ha='center',fontsize=8.5,color='.25')
for ax,rec in zip(axes.flat,records):
    B=set(map(tuple,rec['before']));A=set(map(tuple,rec['inspections']))
    for x,y in sorted(vertices):
        ax.add_patch(Rectangle((y-.5,x-.5),1,1,facecolor='white',edgecolor='.80',lw=.4))
        if (x,y) in B:
            ax.plot(y,x,'o',color='.18',ms=4.1,zorder=2)
        if (x,y) in A:
            col='white' if (x,y) in B else '.25'
            ax.plot([y-.16,y+.16],[x-.16,x+.16],color=col,lw=.85,zorder=3)
            ax.plot([y-.16,y+.16],[x+.16,x-.16],color=col,lw=.85,zorder=3)
    ax.set_title(f'Day {rec["day"]}',fontsize=9,pad=4)
    before=len(B);remain=len(rec['survivors']);next_size=len(rec['next_belief'])
    line=f'{before} possible · {len(A)} inspected'
    after='Captured with certainty' if not remain else f'{remain} survive → {next_size} after moving'
    ax.text(.5,-.06,line,transform=ax.transAxes,ha='center',va='top',fontsize=7.2,color='.25')
    ax.text(.5,-.185,after,transform=ax.transAxes,ha='center',va='top',fontsize=7.0,
            color='.12' if not remain else '.35',fontweight='bold' if not remain else 'normal')
    ax.set(xlim=(-.58,8.58),ylim=(5.58,-.58),aspect='equal');ax.axis('off')

legend=axes.flat[-1];legend.axis('off');legend.set(xlim=(0,1),ylim=(0,1))
legend.plot(.08,.88,'o',color='.18',ms=5.5)
legend.text(.19,.88,'Possible before inspection',va='center',fontsize=7.3)
legend.plot(.08,.65,'o',color='.18',ms=5.5)
legend.plot([.065,.095],[.635,.665],color='white',lw=1)
legend.plot([.065,.095],[.665,.635],color='white',lw=1)
legend.text(.19,.65,'Inspected today (×)',va='center',fontsize=7.3)
legend.text(.04,.48,'Inspect first.\nThen move to a\nneighboring room.',fontsize=7.3,color='.3',linespacing=1.5,va='top')
legend.text(.04,.02,'Seven days are optimal.',fontsize=8.5,fontweight='bold',color='.12')

name='even-rectangle-seven-days'
for ext in ('pdf','svg'):
    fig.savefig(OUT/f'{name}.{ext}',bbox_inches='tight',facecolor='white')
fig.savefig(ROOT/'research'/f'{name}-preview.png',dpi=190,bbox_inches='tight',facecolor='white')
plt.close(fig)
svg=OUT/f'{name}.svg';svg.write_text('\n'.join(line.rstrip() for line in svg.read_text().splitlines())+'\n')
receipt=dict(status='PASS',parameters=result,semantics='Before-inspection possible sets; remove the marked inspections, then take all grid neighbors.',days=records,
    files=[str(OUT/f'{name}.{ext}') for ext in ('pdf','svg')])
(ROOT/'research'/f'{name}-figure-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'PASS','days':[{'day':r['day'],'before':len(r['before']),'shots':len(r['inspections']),'after_move':len(r['next_belief'])} for r in records],'files':receipt['files']}))

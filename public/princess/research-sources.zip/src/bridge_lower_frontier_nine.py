"""Nine scalar backward thresholds for the all-band erosion relaxation.

The recurrence has a fixed number of quadratic-root branches. Its iteration
is NOT a fixed-size numerical answer to the physical capture problem.
"""
from math import isqrt
from pathlib import Path
import argparse,json,time
from bridge_lower_frontier_probe import load_model,distances,clocks

def root(x):
    x=max(0,x);r=isqrt(x);return r+(r*r<x)

def quadratic(m,x):
    """Smallest integer z>=0 with z(z+m)>=x; m>=0."""
    if x<=0:return 0
    z=(isqrt(m*m+4*x)-m)//2
    return z+(z*(z+m)<x)

def pronic(x):
    if x<=0:return 0
    z=(1+isqrt(1+4*x))//2
    return z+(z*(z-1)<x)

def theta_low(T,v,u,j):
    if u:return v+2*j+quadratic(4,T-2*v-3*j-u)
    if v:return v+2*j+quadratic(3,T-2*v-3*j)
    if j:return 2*j+min(quadratic(5,2*T-6*j),quadratic(2,T-3*j+2))
    return min(quadratic(1,2*T),pronic(T))

def theta_high(d,A,B):
    if B:
        base=A+2*B-2
        return base+max(2,pronic(d-base))
    if A:return A-1+max(1,root(d-A+1))
    return min(pronic(2*d),0 if d==0 else 1+root(d+1))

def survivor_cap(b,h,T,i,u,j,v,strong_band=False):
    if T<=0:return 0
    delta=v-i;d=h-T
    theta=min(theta_low(T,v,u,j),theta_high(d,2-j,2-v),b+1)
    if (v,j)==(2,0):theta=min(theta,b)
    r=pronic(d)
    band_cutoff=0
    threshold=(r-1)*(r-2) if strong_band and v==1 else max(r*(r-1)//2,r*(r-2))
    if j==2 and 2<=r<=b and threshold<d and(i,u,v)!=(1,2,1):
        band_cutoff=r+1-delta
    sigma=max(theta,band_cutoff,T-delta-(h-4+i+u),0)
    return max(0,T-delta-sigma)

def step(b,h,k,frontier,strong_band=False):
    following={}
    for c in range(3):
        for e in range(3):
            best=0
            for i in range(c+1):
                for u in range(e+1):
                    if c-i+e-u>k:continue
                    for j in range(u,3):
                        for v in range(i,3):
                            if i<max(0,c+v-2):continue
                            best=max(best,survivor_cap(b,h,frontier[j,v],i,u,j,v,strong_band))
            following[c,e]=min(h-4+c+e,k+best)
    return following

def recurrence(b,n,k,strong_band=False):
    h=(2*b+1)*n//2;frontier={(c,e):0 for c in range(3)for e in range(3)}
    layers=[frontier]
    for t in range(10000):
        frontier=step(b,h,k,frontier,strong_band);layers.append(frontier)
        if frontier[2,2]>=h:return layers
    raise RuntimeError('Bounded recurrence limit exceeded')

def full_prefix_upper(b,n,k):
    h=(2*b+1)*n//2;times=[]
    for phase in(0,1):
        a=h;t=0
        while a:
            a=max(0,a-k)
            if a:
                a+=min(root(a),b,quadratic(1,h-a)) if phase==0 else min(pronic(a),b+1,root(h-a))
            phase=1-phase;t+=1
            assert t<10000
        times.append(t)
    return min(times)

def validate_edge(b,h,k,source,target,p,i,u,strong_band=False):
    a,c,e=source;T,j,v=target;q=a-p;s=T-q
    assert 0<=p<=k and q>0 and 0<=i<=c and 0<=u<=e
    assert c-i+e-u<=p and 0<q<=h-4+i+u
    assert 0<T<=h-4+j+v and u<=j and i<=v
    assert i>=max(0,c+v-2)
    assert s>=min(root(q),b,quadratic(1,h-q))
    for r in range(2,b+1):
        threshold=(r-1)*(r-2) if strong_band and v==1 else max(r*(r-1)//2,r*(r-2))
        if j==2 and threshold<h-T<=r*(r-1) and s<=r:
            assert s==r and(i,u,v)==(1,2,1)
    delta=v-i;ss=s-delta
    assert ss>=0
    def F(A,B,t):
        if t<A+2*B:return -10**12
        if B:return A+2*B-2+(t-A-2*B+2)*(t-A-2*B+1)
        if A:return A-1+(t-A+1)**2
        return max(t*(t-1)//2,t*(t-2))
    def P(v,u,j,t):
        if t<v+2*j:return -10**12
        z=t-v-2*j
        if u:return v+j+u+z*z+3*z
        if v:return v+j+z*z+2*z
        if j:return j-1+max((z+2)*(z+1)//2,(z+2)*(z-1)+1)
        return max(t*(t-1)//2,t*(t-2))
    if ss<=b:
        assert q+delta<=P(v,u,j,ss) or h-T<=F(2-j,2-v,ss) or(ss==b and(v,j)==(2,0))

def reconstruct(b,n,k,layers,strong_band=False):
    h=(2*b+1)*n//2;source=(h,2,2);path=[]
    for remaining in range(len(layers)-1,0,-1):
        a,c,e=source
        if a<=k:
            assert remaining==1
            path.append(dict(source=source,target=(0,0,0),cost=a));break
        choices=[]
        for i in range(c+1):
            for u in range(e+1):
                ell=c-i+e-u
                if ell>k:continue
                for j in range(u,3):
                    for v in range(i,3):
                        if i<max(0,c+v-2):continue
                        T=layers[remaining-1][j,v]
                        Q=survivor_cap(b,h,T,i,u,j,v,strong_band)
                        if Q<a-k:continue
                        q=min(Q,a-ell);p=a-q
                        choices.append((T,j,v,p,i,u))
        T,j,v,p,i,u=min(choices)
        target=(T,j,v);validate_edge(b,h,k,source,target,p,i,u,strong_band)
        path.append(dict(source=source,target=target,cost=p,survivor=(a-p,i,u),surplus=T-a+p))
        source=target
    assert len(path)==len(layers)-1
    return path

def compare(b,n,k,full=True,strong_band=False):
    started=time.process_time();h=(2*b+1)*n//2;layers=recurrence(b,n,k,strong_band)
    out=dict(width=2*b+1,length=n,budget=k,strong_erosion_conditioned_band=strong_band,nine_clock=len(layers)-1,prefix_upper=full_prefix_upper(b,n,k))
    if full:
        build,*_=load_model(True,strong_band)
        states,masks=build(b,n,k,closed=True,triangle=False,maximal=True,dual=True,compact=True,all_radii=True,band_dual=True)
        reverse=[0]*len(states)
        for a,row in enumerate(masks):
            while row:
                bit=row&-row;row-=bit;reverse[bit.bit_length()-1]|=1<<a
        backward=distances(reverse,states.index((0,0,0)))
        checks=0
        for t,U in enumerate(layers):
            for i,(a,c,e) in enumerate(states):
                assert (backward[i]<=t)==(a<=U[c,e]),(b,n,k,t,states[i],backward[i],U[c,e])
                checks+=1
        out['state_deadline_equivalences_checked']=checks
        out['states']=len(states);out['edges']=sum(row.bit_count()for row in masks)
    out['frontiers']=[{str(c)+','+str(e):v for(c,e),v in row.items()}for row in layers]
    if out['nine_clock']!=out['prefix_upper']:
        out['validated_model_witness']=reconstruct(b,n,k,layers,strong_band)
    out['cpu_seconds']=time.process_time()-started
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--cases',default='3,8,4;5,12,6;7,16,8');ap.add_argument('--recurrence-only',action='store_true');ap.add_argument('--strong-band',action='store_true');ap.add_argument('--output',default='research/bridge-lower-frontier-nine-check.json');args=ap.parse_args()
    rows=[]
    for case in args.cases.split(';'):
        row=compare(*map(int,case.split(',')),full=not args.recurrence_only,strong_band=args.strong_band);rows.append(row)
        print(json.dumps({k:v for k,v in row.items()if k not in ('frontiers','validated_model_witness')}),flush=True)
        Path(args.output).write_text(json.dumps(dict(scope=__doc__,triangle_flags_dropped=True,rows=rows),indent=2)+'\n')

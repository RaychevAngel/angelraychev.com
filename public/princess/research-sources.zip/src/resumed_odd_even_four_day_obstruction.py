"""Exhaustive physical lift check for one four-day abstract prefix on 7x8.

The search enumerates all small complementary hole sets, not compressed
supports. It does not claim to rule out all 32-day strategies.
"""
from itertools import combinations
from pathlib import Path
import json,time


def run():
    started=time.process_time();w,n=7,8;h=w*n//2
    rooms=[[(x,y)for x in range(w)for y in range(n)if (x+y)%2==p]for p in (0,1)]
    ids=[{v:i for i,v in enumerate(row)}for row in rooms]
    neighborhoods=[];corners=[]
    for p in (0,1):
        neighborhoods.append([sum(1<<ids[1-p][u]for u in ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                                  if u in ids[1-p])for x,y in rooms[p]])
        corners.append(sum(1<<i for i,(x,y)in enumerate(rooms[p])
                           if x in(0,w-1)and y in(0,n-1)))
    previous={0};q_previous=0;results=[]
    for day,(q,c)in enumerate(((2,0),(4,1),(5,0),(6,0)),1):
        p=day%2;candidates=[];reached={};enumerated=0
        for selected in combinations(range(h),q):
            enumerated+=1;mask=sum(1<<i for i in selected)
            if (mask&corners[p]).bit_count()!=c:continue
            hood=0
            for i in selected:hood|=neighborhoods[p][i]
            if hood.bit_count()!=q_previous+4:continue
            # Check the actual next belief, not merely a subset of its holes.
            interior=sum(1<<i for i,H in enumerate(neighborhoods[p])if not H&~hood)
            if interior!=mask:continue
            candidates.append(mask)
            for old in previous:
                if not old&~hood:
                    reached[mask]=old;break
        results.append({'day':day,'hole_size':q,'hole_corner_count':c,
                        'all_subsets_enumerated':enumerated,
                        'individually_valid_hole_sets':len(candidates),
                        'reachable_from_previous':len(reached),
                        'candidate_coordinates':[[rooms[p][i]for i in range(h)if M>>i&1]
                                                 for M in candidates],
                        'reachable_coordinates':[[rooms[p][i]for i in range(h)if M>>i&1]
                                                 for M in reached]})
        previous=set(reached);q_previous=q
    assert not previous
    return {'shape':[w,n],'budget':4,
            'abstract_belief_prefix':[[28,2],[26,2],[24,1],[23,2],[22,2]],
            'phase_zero_initial':'The opposite initial phase follows by longitudinal reflection.',
            'result':'No physical lift of this four-day prefix exists.',
            'scope':'This excludes the displayed32-day relaxed path, not every32-day physical strategy.',
            'days':results,'cpu_seconds':time.process_time()-started}


if __name__=='__main__':
    out=run();Path('research/resumed-odd-even-four-day-obstruction.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='days'})
    for day in out['days']:
        print({k:v for k,v in day.items()if not k.endswith('coordinates')})

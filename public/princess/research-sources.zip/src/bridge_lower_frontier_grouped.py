"""Bounded equal-radius bitset evaluator for paired localization and lens.

No ordering or dominance between distinct radius pairs is used. This
finite evaluator uses the separately reviewed base relations and reset
lemmas; a finite result does not prove the variable-width clock claim.
"""
from pathlib import Path
from functools import lru_cache
import hashlib
import json
import math
import time

from bridge_lower_frontier_flagged import base_cache, flagged
from bridge_lower_frontier_diagnostic import square_successor_flag
from bridge_lower_frontier_interval import intervals, pronic_intervals, lens_counter


def ids(bits):
    while bits:
        bit = bits & -bits
        bits ^= bit
        yield bit.bit_length() - 1


def verify(b, feature=(0, 0), paired=True, lens=True, cpu_limit=13,
           deadline=300, keep_path=True):
    begin = time.process_time()
    w, n, k = 2*b+1, 2*b+2, b+1
    h, boundary, diameter = w*n//2, b*b+b+1, w+n-2
    data, cached = base_cache(b, n, k)
    assert cached, 'Bounded evaluator requires a cached base.'
    states, edges, rows = flagged(data, b, n, k, 'forbid-pair', return_weighted=True)
    states, edges, rows = square_successor_flag(states, rows, b, n, k)
    if paired:
        states, edges, rows = intervals(states, rows, b, n, k)
        states, edges, rows = pronic_intervals(states, rows, b, n, k)
    seed = states.index((boundary, *feature))
    zero = states.index((0, 0, 0))
    normal = (1 << len(states)) - 1
    triggers, trigger_by_id = {}, {}
    for a, state in enumerate(states):
        if len(state) <= 3 or state[3] not in (4, 7):
            continue
        size, flag = state[0], state[3]
        if flag == 4:
            r = math.isqrt(size)
            r += r*r < size
            key = (0, 2*r-2)
        else:
            r = (math.isqrt(4*size+1)-1)//2
            r += r*(r+1) < size
            key = (1, 2*r-1)
        triggers[key] = triggers.get(key, 0) | (1 << a)
        trigger_by_id[a] = key
        normal &= ~(1 << a)
    features = {(c, e): sum(1 << a for a, s in enumerate(states)
                           if s[1] <= c and s[2] <= e)
                for c in range(3) for e in range(3)}
    exact_sizes = [0]*(h+1)
    for a, s in enumerate(states):
        exact_sizes[s[0]] |= 1 << a
    prefixes = []
    mask = 0
    for group in exact_sizes:
        mask |= group
        prefixes.append(mask)
    lens_count = lens_counter(w, n)

    @lru_cache(None)
    def allowed(r0, r1):
        c = min(1 + (r0 >= w-1), (r1 >= n-1) + (r1 >= w+n-2))
        e = min((r0 >= n) + (r0 >= w+n-3), (r1 >= 1) + (r1 >= w))
        mask = features[c, e]
        if lens:
            mask &= prefixes[lens_count(r0, r1)]
        return mask

    def next_pair(pair, target):
        r0, r1 = min(diameter, pair[1]+1), min(diameter, pair[0]+1)
        if target in trigger_by_id:
            coordinate, radius = trigger_by_id[target]
            if coordinate == 0:
                r0 = min(r0, radius)
            else:
                r1 = min(r1, radius)
        return r0, r1

    front = {(diameter, diameter): 1 << seed}
    seen = dict(front)
    histories, layers = [], []
    complete, bounded = False, False
    for depth in range(deadline+1):
        if keep_path:
            histories.append(front)
        layers.append(dict(depth=depth, augmented_states=sum(x.bit_count() for x in front.values()),
                           size_minimum=min(states[a][0] for mask in front.values() for a in ids(mask))))
        capture_pair = next((pair for pair, mask in front.items() if mask >> zero & 1), None)
        if capture_pair is not None:
            complete = True
            break
        if time.process_time()-begin > cpu_limit:
            bounded = True
            break
        following = {}
        for pair, mask in front.items():
            nr0, nr1 = min(diameter, pair[1]+1), min(diameter, pair[0]+1)
            out = 0
            for a in ids(mask):
                out |= edges[a]
            base = out & normal & allowed(nr0, nr1)
            if base:
                following[nr0, nr1] = following.get((nr0, nr1), 0) | base
            for (coordinate, radius), group in triggers.items():
                hit = out & group
                if not hit:
                    continue
                target_pair = (min(nr0, radius), nr1) if coordinate == 0 else (nr0, min(nr1, radius))
                hit &= allowed(*target_pair)
                if hit:
                    following[target_pair] = following.get(target_pair, 0) | hit
        front = {}
        for pair, mask in following.items():
            fresh = mask & ~seen.get(pair, 0)
            if fresh:
                front[pair] = fresh
                seen[pair] = seen.get(pair, 0) | fresh
        if not front:
            break
    result = dict(shape=[w, n], budget=k, boundary=boundary, feature=feature,
                  paired_intervals=paired, lens=lens, dominance=False, complete=complete,
                  bounded_stop=bounded, depth=depth, radius_pairs=len(seen),
                  augmented_states=sum(x.bit_count() for x in seen.values()),
                  minimum_before_capture=min(x['size_minimum'] for x in layers[:-1]) if complete else None,
                  base_model_sha256=data['model_sha256'], layers=layers)
    if complete and keep_path:
        path = [(zero, capture_pair)]
        for earlier in reversed(histories[:-1]):
            target, target_pair = path[-1]
            predecessor = None
            for pair, mask in earlier.items():
                if next_pair(pair, target) != target_pair:
                    continue
                predecessor = next(((a, pair) for a in ids(mask) if edges[a] >> target & 1), None)
                if predecessor is not None:
                    break
            assert predecessor is not None
            path.append(predecessor)
        path.reverse()
        result['witness'] = []
        for day, ((a, pair), (target, target_pair)) in enumerate(zip(path, path[1:]), 1):
            costs = [p for p in range(k+1) if rows[p][a] >> target & 1]
            assert costs
            result['witness'].append(dict(day=day, source=states[a], target=states[target],
                                          source_radii=pair, target_radii=target_pair, costs=costs))
    result['CPU_seconds'] = time.process_time()-begin
    result['source_sha256'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                               for path in (Path(__file__), Path('src/bridge_lower_frontier_interval.py'),
                                            Path('src/bridge_lower_frontier_diagnostic.py'),
                                            Path('src/bridge_lower_frontier_flagged.py'))}
    return result


if __name__ == '__main__':
    result = verify(23, cpu_limit=13, deadline=163)
    path = Path('research/bridge-lower-frontier-b23-paired-lens-check.json')
    path.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('layers', 'witness', 'source_sha256')}))

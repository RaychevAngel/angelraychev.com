"""Bounded structural attack; abstract dual profiles are not physical grids."""
from collections import deque
from bisect import bisect_right
from time import process_time
from pathlib import Path
import json

def profiles(M,inc):
    E=M+1
    s=lambda k:2+sum(i<=min(k,M-k) for i in inc)
    odd=[0]+[k+s(k) for k in range(1,M)]+[E]
    even=[M-(bisect_right(odd,E-k)-1)for k in range(E+1)]
    assert even[0]==0 and even[-1]==M
    assert all(0<=even[k+1]-even[k]<=2 for k in range(E))
    return even,odd

def solve(g,m,witness=False):
    start=(len(g[0])-1,len(g[1])-1)
    Q=deque([start]);prev={start:None};depth={start:0}
    while Q:
        a,b=state=Q.popleft()
        if a+b<=m:
            trace=[];end=state
            while prev[state] is not None:
                old,p=prev[state];trace.append((old,p,m-p));state=old
            trace.reverse();trace.append((end,end[0],end[1]))
            return depth[end]+1,trace
        for p in range(m+1):
            after=(g[1][max(0,b-m+p)],g[0][max(0,a-p)])
            if after not in prev:prev[after]=(state,p);depth[after]=depth[state]+1;Q.append(after)
    return None,None

def serial(g,m):
    best=10**9
    for first in (0,1):
        a,b,p=len(g[first])-1,len(g[1-first])-1,first;t=0;seen=set()
        while (a,b,p)not in seen:
            if a+b<=m:best=min(best,t+1);break
            seen.add((a,b,p));k=min(a,m)
            a,b=g[p][a-k],g[1-p][max(0,b-(m-k))]
            p^=1;t+=1
    return None if best==10**9 else best

def selections(lo,hi):
    yield ()
    for i in range(lo,hi+1):
        for rest in selections(i+2,hi):yield (i,)+rest

def main(seconds=20):
    begin=process_time();cases=checks=0;failure=None;done=[]
    for M in range(6,55):
        for inc in selections(2,M//2):
            try:g=profiles(M,inc)
            except AssertionError:continue
            cases+=1
            for m in range(2,M):
                want=serial(g,m)
                if want is None:continue
                got,trace=solve(g,m);checks+=1
                if got!=want:
                    failure={'M':M,'increments':inc,'profiles':g,'budget':m,'exact':got,'serial':want,'witness':trace};break
            if failure or process_time()-begin>seconds:break
        if failure or process_time()-begin>seconds:break
        done.append(M)
    out={'scope':'Abstract dual symmetric profiles with both proper increments at most two; no physical-grid claim.','profiles_checked':cases,'budget_pairs':checks,'completed_M':done,'failure':failure,'CPU_seconds':process_time()-begin}
    Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-serial-abstract.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))
if __name__=='__main__':main()

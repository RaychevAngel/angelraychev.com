"""Four-row geometric certificates and candidate endpoint-phase recurrences."""
from collections import deque
from pathlib import Path
import json,time
from nested_grid_time import grid,ordered_profiles,neighborhood

def lower_profile(h,k):
    if not k:return 0
    if k==1:return 2
    if k==h-2:return h-1
    return min(h,k+2)

def counter_time(n,m,phase=True):
    h=2*n
    _,data=ordered_profiles((n,4));profiles=data[-1]
    start=(h,0,h,0) if phase else (h,h);parents={start:None};q=deque([start])
    while q:
        state=q.popleft()
        if phase:a,x,b,y=state
        else:a,b=state
        if a+b<=m:
            path=[state];v=state
            while parents[v] is not None:v=parents[v];path.append(v)
            return dict(turns=len(path),states=len(parents))
        for p in range(m+1):
            r=max(a-p,0);s=max(b-(m-p),0)
            if phase:
                for xx in ([0,1] if a==h else [x]):
                    for yy in ([0,1] if b==h else [y]):
                        aa=profiles[xx][r];bb=profiles[yy][s]
                        after=(aa,0 if aa in (0,h) else 1-xx,bb,0 if bb in (0,h) else 1-yy)
                        if after not in parents:parents[after]=state;q.append(after)
            else:
                after=(lower_profile(h,r),lower_profile(h,s))
                if after not in parents:parents[after]=state;q.append(after)
    return dict(turns=None,states=len(parents))

def verify_geometry(n):
    coords,adj=grid((n,4));h=2*n;counts=0;critical={0:set(),1:set()}
    for z in range(2):
        ids=[i for i,c in enumerate(coords) if sum(c)%2==z]
        full=sum(1<<i for i in ids)
        for code in range(1<<h):
            mask=sum(1<<i for j,i in enumerate(ids) if code>>j&1)
            k=code.bit_count();nk=neighborhood(mask,adj).bit_count();counts+=1
            assert nk>=lower_profile(h,k),(n,z,k,nk)
            if nk==k+1:critical[z].add(k)
    return dict(n=n,subsets=counts,surplus_one_sizes=[sorted(critical[z]) for z in range(2)])

if __name__=='__main__':
    started=time.monotonic();rows=[]
    for n in range(4,31):
        gaps=[]
        for m in range(3,min(16,4*n)+1):
            l=counter_time(n,m,False);u=counter_time(n,m,True)
            assert u['turns']>=l['turns']
            if u['turns']!=l['turns']:gaps.append((m,l['turns'],u['turns']))
            rows.append(dict(n=n,m=m,lower=l['turns'],upper=u['turns']))
        print(n,gaps,flush=True)
    checks=[verify_geometry(n) for n in range(4,8)]
    Path('research/four-row-recurrence-checks.json').write_text(json.dumps(dict(method='Candidate independent-orientation prefix upper recurrence versus minimum-neighborhood lower recurrence; agreement is finite evidence only. Exhaustive local subset certificates separately verify geometry.',seconds=time.monotonic()-started,results=rows,geometry_checks=checks),indent=2)+'\n')

def three_probe_strategy(n):
    assert n>=4
    coords,adj=grid((n,4));h=2*n;index={c:i for i,c in enumerate(coords)}
    orders=[sorted((i for i,c in enumerate(coords) if sum(c)%2==z),key=lambda i:(sum(coords[i]),coords[i])) for z in range(2)]
    pref=[]
    for z in range(2):
        row=[0]
        for i in orders[z]:row.append(row[-1]|(1<<i))
        pref.append(row)
    def canon(k,z,p):
        mask=pref[z][k]
        if z==p:return mask
        out=0
        for i,(c,r) in enumerate(coords):
            if mask>>i&1:out|=1<<index[(c,3-r)]
        return out
    belief=(1<<len(coords))-1;shots=[]
    for first in range(2):
        support=canon(h,0,first)
        for t in range(h-2):
            z=t%2;p=first^(t%2);k=support.bit_count()
            assert support==canon(k,z,p)
            survivors=canon(max(k-3,0),z,p)
            shot=support^survivors;shots.append(shot)
            support=neighborhood(survivors,adj)
            belief=neighborhood(belief&~shot,adj)
        assert not support
    assert not belief and len(shots)==4*n-4
    return dict(n=n,minimum_turns=len(shots),inspections=[[coords[i] for i in range(len(coords)) if shot>>i&1] for shot in shots])

def formula(n,m):
    assert n>=4 and m>=1
    h=2*n
    if m<=2:return None
    if m>=2*h:return 1
    if m>=h:return 2
    q,r=divmod(h-2,m-2)
    if not r:return 2*q
    return 2*q+1 if r==1 or m>=2*r+4 else 2*q+2

def direct_strategy(n,m):
    turns=formula(n,m)
    if turns is None:return dict(turns=None,inspections=[])
    coords,adj=grid((n,4));h=2*n;index={c:i for i,c in enumerate(coords)}
    full=(1<<len(coords))-1
    orders=[sorted((i for i,c in enumerate(coords) if sum(c)%2==z),key=lambda i:(sum(coords[i]),coords[i])) for z in range(2)]
    pref=[]
    for z in range(2):
        row=[0]
        for i in orders[z]:row.append(row[-1]|(1<<i))
        pref.append(row)
    def canon(k,z,p):
        mask=pref[z][k]
        if z==p:return mask
        out=0
        for i,(c,r) in enumerate(coords):
            if mask>>i&1:out|=1<<index[(c,3-r)]
        return out
    if m>=2*h:shots=[full]
    elif m>=h:shots=[pref[0][-1],pref[0][-1]]
    else:
        q,r=divmod(h-2,m-2)
        if not r:allocations=[(m,0)]*q+[(0,m)]*q
        elif turns==2*q+1:
            p=2 if r==1 else r+2
            allocations=[(m,0)]*q+[(p,m-p)]+[(0,m)]*q
        else:allocations=[(m,0)]*(q+1)+[(0,m)]*(q+1)
        first_phase=(q-1)%2 if r==1 and turns==2*q+1 else 0
        phases=[first_phase,0];cohorts=[pref[0][-1],pref[1][-1]];shots=[]
        for day,counts in enumerate(allocations):
            shot=0
            for j,p in enumerate(counts):
                physical=j^(day%2);z=phases[j];b=cohorts[j].bit_count()
                assert cohorts[j]==canon(b,z,physical)
                survivors=canon(max(b-p,0),z,physical)
                shot|=cohorts[j]^survivors
                cohorts[j]=neighborhood(survivors,adj)
                phases[j]=1-z
                if cohorts[j]==pref[1-physical][-1]:phases[j]=first_phase if j==0 else 0
            shots.append(shot)
    belief=full
    for day,shot in enumerate(shots):
        assert shot.bit_count()<=m
        belief=neighborhood(belief&~shot,adj)
        if not belief:assert day==len(shots)-1,(n,m,day,len(shots))
    assert not belief and len(shots)==turns
    return dict(turns=turns,inspections=[[coords[i] for i in range(len(coords)) if shot>>i&1] for shot in shots])

"""Refresh explicit publication membership after the reviewed rectangle pass."""
from pathlib import Path
import ast,hashlib,json,re
ROOT=Path(__file__).resolve().parents[1];PAPER=ROOT/'paper'
def closure(name):
    out=set()
    def walk(p):
        assert p.is_file(),p
        if p in out:return
        out.add(p);s=re.sub(r'(?<!\\)%[^\n]*','',p.read_text())
        for x in re.findall(r'\\(?:input|include)\{([^}]+)\}',s):walk(PAPER/(x if Path(x).suffix else x+'.tex'))
    walk(PAPER/name);return out
p=ROOT/'publication/manuscript-scope.json';m=json.loads(p.read_text())
sets={scope:closure(entry) for scope,entry in [('main','main.tex'),('extensions','extensions.tex')]}
oldlabels=set(m['main']['labels'])|set(m['extensions']['labels'])
for scope,paths in sets.items():
    m[scope]['sources']=sorted(str(x.relative_to(ROOT))for x in paths)
    m[scope]['labels']=sorted(set(k for x in paths for k in re.findall(r'\\label\{([^}]+)\}',x.read_text())))
alllabels=set(m['main']['labels'])|set(m['extensions']['labels'])
assert oldlabels<=alllabels,oldlabels-alllabels
m['operation']='Rectangle bridge checkpoint: exact new families, uniform bounds, fixed-operation evaluators, and baseline reconciliation. Parked scope and canonical formal sources unchanged.'
m['label_roles']={k:('shared'if k in m['main']['labels']and k in m['extensions']['labels']else'main'if k in m['main']['labels']else'extensions')for k in sorted(alllabels)}
m['shared_canonical_tex']=sorted(str(x.relative_to(ROOT))for x in sets['main']&sets['extensions'])
m['current_source_sha256']={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted(sets['main']|sets['extensions'])}
p.write_text(json.dumps(m,indent=2)+'\n')
p=ROOT/'publication/artifact-manifest.json';a=json.loads(p.read_text());files=a['files']
new=set(ROOT.glob('research/resumed-*'))|set(ROOT.glob('src/resumed_*'))|set(ROOT.glob('paper/sections/resumed-*'))
new|=set(ROOT.glob('research/bridge-*'))|set(ROOT.glob('src/bridge_*'))|set(ROOT.glob('paper/sections/bridge-*'))
new|=set(ROOT.glob('archive/2026-09-13-scope-baseline/*'))|{ROOT/'research/BOX_RECONCILIATION.md'}
new|={ROOT/'research/RESUMED_RECTANGLE_CHECKPOINT.md',ROOT/'src/build_near_pronic_figure.py',ROOT/'src/refresh_resumed_publication.py'}
private={'research/resumed-rectangle-research-log.md','research/resumed-corner-integration-plan.md','research/bridge-research-log.md','archive/2026-09-13-scope-baseline/CURRENT_CHECKPOINT.md'}
for x in sorted(new):
    if not x.is_file():continue
    name=str(x.relative_to(ROOT));scope='private'if name in private or 'research-log' in name else'main'
    files[name]={'scope':scope,'reason':'Private chronological/assembly record.'if scope=='private'else'Rectangle proof sources, current or historical research, failed approaches, and reproducible evidence. Each file states its proof status; no new formal coverage implied.'}
    if x.suffix=='.py':
        deps=set()
        for node in ast.walk(ast.parse(x.read_text())):
            names=[n.name for n in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)and node.module else[]
            for module in names:
                for base in [ROOT/'src',ROOT/'research']:
                    dep=base/(module.split('.')[0]+'.py')
                    if dep.is_file()and dep!=x:deps.add(str(dep.relative_to(ROOT)))
        if deps:files[name]['local_imports']=sorted(deps)
for scope,paths in sets.items():
    for x in paths:
        name=str(x.relative_to(ROOT));role='shared'if x in sets['main']&sets['extensions']else'main'if scope=='main'else'parked'
        files[name]={'scope':role,'reason':'Canonical manuscript source; retained scope and dependencies.'}
a['files']=dict(sorted(files.items()));p.write_text(json.dumps(a,indent=2)+'\n')
print({scope:len(paths)for scope,paths in sets.items()},'All prior labels retained; new files explicitly scoped.')

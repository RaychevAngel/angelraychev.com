"""Exact odd-box profile attack using proved odd-rectangle fiber compressions.
Each fixed support is an ideal in the pair-prefix predecessor order.
The executable limit is a resource bound, not a mathematical restriction.
"""
from itertools import product,combinations
from collections import deque
from time import monotonic
from pathlib import Path
import json
from nested_grid_time import ordered_profiles

def prepare(shape,limit=50000,seconds=12):
 start=monotonic();verts=list(product(*(range(n)for n in shape)));result=[]
 for p in range(2):
  row=sorted((v for v in verts if sum(v)%2==p),key=lambda v:(sum(v),tuple(-x for x in v)))
  idx={v:i for i,v in enumerate(row)};opp=[v for v in verts if sum(v)%2!=p];oi={v:i for i,v in enumerate(opp)}
  pred=[0]*len(row);adj=[0]*len(row)
  for i,j in combinations(range(len(shape)),2):
   groups={}
   for v in row:
    key=tuple(v[a]for a in range(len(shape))if a not in(i,j))
    groups.setdefault(key,[]).append(v)
   for group in groups.values():
    # Inherited full weightlex order agrees with pair simplicial order.
    for a,b in zip(group,group[1:]):pred[idx[b]]|=1<<idx[a]
  for k,v in enumerate(row):
   for a in range(len(shape)):
    if v[a]>=2:
     w=list(v);w[a]-=2;pred[k]|=1<<idx[tuple(w)]
    for delta in(-1,1):
     w=list(v);w[a]+=delta
     if 0<=w[a]<shape[a]:adj[k]|=1<<oi[tuple(w)]
  seen={0};queue=deque([0]);profile=[len(opp)+1]*(len(row)+1);witness={};profile[0]=0
  while queue:
   s=queue.popleft();k=s.bit_count();nb=0;t=s
   while t:
    bit=t&-t;t^=bit;nb|=adj[bit.bit_length()-1]
   if nb.bit_count()<profile[k]:profile[k]=nb.bit_count();witness[k]=s
   for j,pr in enumerate(pred):
    bit=1<<j
    if not s&bit and s&pr==pr:
     after=s|bit
     if after not in seen:seen.add(after);queue.append(after)
   if len(seen)>limit or monotonic()-start>seconds:return {'shape':shape,'status':'bounded','p':p,'states':len(seen),'seconds':monotonic()-start}
  report,data=ordered_profiles(shape,weightlex=True)
  expected=report['profiles'][p] if report['nested'] else None
  if expected is None:return {'shape':shape,'status':'nesting_failure','details':report}
  bad=[k for k in range(len(row)+1)if profile[k]!=expected[k]]
  result.append({'p':p,'states':len(seen),'equal':not bad})
  if bad:
   k=bad[0];s=witness[k]
   return {'shape':shape,'status':'counterexample','p':p,'k':k,'optimal':profile[k],'prefix':expected[k], 'set':[v for j,v in enumerate(row)if s>>j&1],'seconds':monotonic()-start}
 return {'shape':shape,'status':'exact_match','colors':result,'seconds':monotonic()-start}

if __name__=='__main__':
 root=Path(__file__).resolve().parents[1];out=[]
 shapes=[(3,5,7),(3,5,9),(3,7,9),(5,5,7),(5,7,7),(7,7,7),(3,3,3,5),(3,3,5,5),(3,3,3,3,3),(3,3,3,7),(3,5,5,5),(5,5,5,5)]
 for shape in shapes:
  r=prepare(shape);out.append(r);print(json.dumps(r),flush=True)
  (root/'research/odd-box-nesting-attack.json').write_text(json.dumps({'scope':'Exact among common pair-prefix fixed supports; exact unrestricted profiles follow from proved odd-rectangle fiber compression and common decreasing order potential. Resource-limited cases are not exact.','results':out},indent=2)+'\n')
  if r['status']=='counterexample':break

"""Focused validation of the reviewed eventual scalar onset against old frontier.

No scalar assumption enters the reference solver. Not a proof substitute.
"""
from supersession_odd_midpoint_bounded import solve
from supersession_solo_bands import OddRectangle
from time import process_time
import json


def onset(w, m):
    b = (w - 1) // 2
    H = b ** 2 + 1
    G = m - 1
    K = H - 1 + 2 * m * (G // w + 1)
    W = G + K + 1
    J = 2 * K + G + 2 * m + H + 2
    return 2 * J + G + m * (W + 3)


def check():
    start = process_time()
    rows = []
    for w, m in [(5, 4), (7, 5), (9, 7), (15, 12)]:
        bound = onset(w, m)
        n = max(w, (2 * bound + 1 + w - 1) // w)
        n += 1 - n % 2
        for length in [n, n + 2] + ([10**12 + 1] if w == 15 else []):
            shape = OddRectangle(w, length)
            half = shape.half_time(m)
            reference = solve(w, length, m)
            a, b = reference['precentral_capacities']
            scalar = 2 * half['tau'] - int(shape.E + shape.M - a - b <= m)
            assert shape.M >= bound
            assert half['tau'] == reference['tau']
            assert scalar == reference['time']
            if length < 10**12:
                daywise = solve(w, length, m, accelerate=False)
                assert reference['jumps']
                assert daywise['frontier'] == reference['frontier']
                assert daywise['time'] == reference['time']
            rows.append({'w': w, 'n': length, 'm': m, 'M_onset': bound,
                         'tau': half['tau'], 'time': scalar,
                         'reference_midpoint': reference['central_minimum'],
                         'solo_midpoint': reference['solo_residual_sum'],
                         'reference_updates': reference['updates']})
    return {'scope': 'finite independent-algorithm comparison, not proof',
            'cases': rows, 'seconds': process_time() - start, 'passed': True}


if __name__ == '__main__':
    print(json.dumps(check(), indent=2))

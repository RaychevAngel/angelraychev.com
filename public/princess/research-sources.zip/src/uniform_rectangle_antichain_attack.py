"""Exact antichain attack on prescribed-day serial concentration on odd grids."""
from pathlib import Path
from time import process_time
from odd_serial_first_order_attack import profiles
from uniform_rectangle_timed_concentration import serial_step
import json

def advance(g,m,front):
    candidates={(g[1][max(0,b-m+p)],g[0][max(0,a-p)])for a,b in front for p in range(m+1)}
    out=[];best=10**9
    for a,b in sorted(candidates):
        if b<best:out.append((a,b));best=b
    return out

def main(seconds=25):
    starttime=process_time();params=days=maxfront=0;fail=None;completed=[]
    for b in range(1,26):
      for a in (b,b+1,b+3):
        g=profiles(a,b);start=(len(g[0])-1,len(g[1])-1)
        for m in sorted(set(range(b+1,2*b+3))|{b*b//2+1,b*b}):
          if m<b+1 or m>=len(g[1]):continue
          front=[start];serial=[start,start];params+=1
          for t in range(3*sum(start)):
            front=advance(g,m,front);maxfront=max(maxfront,len(front));days+=1
            serial=[serial_step(g,m,serial[i],i,t)for i in (0,1)]
            true=min(map(sum,front));candidate=min(map(sum,serial))
            if true<candidate:
              fail={'shape':[2*a+1,2*b+1],'budget':m,'day':t+1,'min_remaining':true,'serial_remaining':candidate,'min_states':[s for s in front if sum(s)==true],'serial_states':serial,'frontier':front};break
            if true==0:break
          if fail or process_time()-starttime>seconds:break
        if fail or process_time()-starttime>seconds:break
      if fail or process_time()-starttime>seconds:break
      completed.append(2*b+1)
    out={'scope':'Exact monotone antichain dynamics; full-board prescribed-day serial concentration remains a conjecture.','parameter_pairs':params,'day_layers':days,'maximum_frontier':maxfront,'completed_widths':completed,'failure':fail,'CPU_seconds':process_time()-starttime}
    Path(__file__).resolve().parents[1].joinpath('research/uniform-rectangle-antichain-attack.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()

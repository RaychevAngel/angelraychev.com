"""Compare maximal winning size using exact equal-box compression.

The baseline family is proved sufficient for arbitrary starting supports
up to a cardinality-preserving strategy compression. Consequently its
maximum winning cardinality equals the unrestricted maximum. The other
family contains all reflected/permuted weightlex prefixes and is only a
restricted physical game. Explore their paired budget-word automata.
"""
from collections import deque
from itertools import permutations, product
from pathlib import Path
from time import process_time
import argparse,json
from pyramidal_time import prepare


def run(shape,seconds=15,limit=10000):
    start=process_time();data=prepare(shape,limit=3000,odd_paths=True)
    colors=data['colors'];indices=[{v:i for i,v in enumerate(row)}for row in colors]
    adjacency=[]
    for p,row in enumerate(colors):
        aa=[]
        for v in row:
            nb=0
            for axis,n in enumerate(shape):
                for sign in (-1,1):
                    w=list(v);w[axis]+=sign
                    if 0<=w[axis]<n:nb|=1<<indices[1-p][tuple(w)]
            aa.append(nb)
        adjacency.append(aa)
    def N(p,a):
        nb=0
        while a:
            bit=a&-a;a-=bit;nb|=adjacency[p][bit.bit_length()-1]
        return nb
    pref=[{0},{0}]
    for refl in product((0,1),repeat=len(shape)):
        for perm in permutations(range(len(shape))):
            for p,row in enumerate(colors):
                mapped=[tuple(shape[i]-1-v[i]if refl[i]else v[i]for i in range(len(shape)))for v in row]
                order=sorted(range(len(row)),key=lambda i:(sum(mapped[i]),tuple(-mapped[i][j]for j in perm)))
                a=0
                for i in order:a|=1<<i;pref[p].add(a)
    families=[data['ideals'],[sorted(row,key=lambda a:(a.bit_count(),a))for row in pref]]
    sizes=[[[a.bit_count()for a in row]for row in family]for family in families]
    transitions=[]
    for family in families:
        lookup=[{a:i for i,a in enumerate(row)}for row in family];rows=[]
        for p in (0,1):
            neighborhoods=[lookup[1-p][N(p,r)] for r in family[p]]
            rows.append([[(neighborhoods[j],a.bit_count()-r.bit_count())
                          for j,r in enumerate(family[p])if not r&~a]for a in family[p]])
        transitions.append(rows)
    initial=tuple(tuple(bytes([1])+bytes(len(row)-1)for row in family)for family in families)
    queue=deque([(initial,())]);seen={initial};processed=0;maximum=max(map(len,colors))
    tables=[bytes(int(k<=m)for k in range(256))for m in range(maximum+1)]
    result={'shape':shape,'families':[list(map(len,x))for x in families],
            'scope':'maximum-cardinality winning support for every finite quota word; exact baseline compression, unrestricted-vs-prefix comparison'}
    while queue:
        if process_time()-start>seconds or len(seen)>limit:
            result['status']='bounded incomplete';break
        wins,word=queue.popleft();processed+=1;dist=[]
        for f in (0,1):
            rr=[]
            for p in (0,1):
                rr.append(bytes(min((cost for j,cost in row if wins[f][1-p][j]),default=maximum+1)
                                for row in transitions[f][p]))
            dist.append(rr)
        for m in range(maximum+1):
            new=tuple(tuple(row.translate(tables[m])for row in rr)for rr in dist)
            for p in (0,1):
                exact=max(size for size,w in zip(sizes[0][p],new[0][p])if w)
                restricted=max(size for size,w in zip(sizes[1][p],new[1][p])if w)
                if exact!=restricted:
                    result.update(status='counterexample',parity=p,budget_word=(m,)+word,
                                  unrestricted_maximum=exact,prefix_maximum=restricted)
                    result.update(CPU_seconds=process_time()-start,states_seen=len(seen),states_processed=processed)
                    return result
            if new not in seen:seen.add(new);queue.append((new,(m,)+word))
    else:result['status']='complete closure; all finite quota words pass'
    result.update(CPU_seconds=process_time()-start,states_seen=len(seen),states_processed=processed)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('shape',nargs='+',type=int)
    p.add_argument('--seconds',type=float,default=15);p.add_argument('--output',type=Path)
    args=p.parse_args();result=run(tuple(args.shape),args.seconds)
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

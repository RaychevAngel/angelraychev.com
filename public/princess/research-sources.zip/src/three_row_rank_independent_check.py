#!/usr/bin/env python3
"""Independent parity-subset audit of the even-three-row phase-rank proof.

No full 2**(3*n) belief graph is built. Each color has h=3*n/2 bits.
"""
import json
from pathlib import Path
import time


def run(n):
    coords = [[(r, c) for r in range(3) for c in range(n) if (r+c)%2 == s] for s in (0, 1)]
    h = len(coords[0]); full = (1 << h)-1
    neighborhoods = []
    for s in (0, 1):
        single = [sum(1 << j for j, (u, v) in enumerate(coords[1-s]) if abs(u-r)+abs(v-c) == 1)
                  for r, c in coords[s]]
        table = [0] * (1 << h)
        for mask in range(1, 1 << h):
            bit = mask & -mask
            table[mask] = table[mask ^ bit] | single[bit.bit_length()-1]
        neighborhoods.append(table)
    orders = [sorted(range(h), key=lambda i: (sum(coords[s][i]), coords[s][i][1])) for s in (0, 1)]
    prefixes = []
    for order in orders:
        acc = [0]
        for i in order: acc.append(acc[-1] | (1 << i))
        prefixes.append(acc)
    prefix_checked = 0
    for s in (0, 1):
        for k, p in enumerate(prefixes[s]):
            expected = min(h, k+1+s) if k else 0
            assert neighborhoods[s][p] == prefixes[1-s][expected], (n,s,k)
            prefix_checked += 1
    compatibility_checked = 0; transitions_checked = 0; exceptions = []
    histories = [set(), set()]
    for s in (0,1):
        for r, a in enumerate(neighborhoods[s]):
            if 1 <= r.bit_count() <= h-2 and a.bit_count() == r.bit_count()+1:
                histories[1-s].add(a)
                sub = a
                while sub:
                    nr = neighborhoods[1-s][sub]
                    if sub.bit_count() <= h-2 and nr.bit_count() == sub.bit_count()+1:
                        assert r.bit_count() == h-2 and sub.bit_count() == 1, (n,s,r,sub)
                        compatibility_checked += 1
                    sub = (sub-1) & a
    for s in (0,1):
        for a in histories[s]:
            old_rank = 2*a.bit_count()+1
            sub = a
            while True:
                p = a.bit_count()-sub.bit_count()
                ns = neighborhoods[s][sub]
                label = int(1 <= sub.bit_count() <= h-2 and ns.bit_count() == sub.bit_count()+1)
                actual = 2*ns.bit_count()+label if ns else 0
                predicted = 0 if a.bit_count() <= p else min(2*h, old_rank-2*p+3)
                if p < h-2:
                    assert actual >= predicted, (n,s,a,sub,p,actual,predicted)
                    transitions_checked += 1
                elif actual < predicted:
                    assert p == h-2 and sub.bit_count() == 1 and actual == 5 and predicted == 6
                    if len(exceptions) < 2:
                        exceptions.append({'parity':s, 'support':[coords[s][i] for i in range(h) if a>>i&1],
                                           'survivors':[coords[s][i] for i in range(h) if sub>>i&1],
                                           'useful_probes':p, 'actual_next_rank':actual, 'naive_next_rank':predicted})
                if sub == 0: break
                sub = (sub-1) & a
    return {'n':n,'h':h,'prefix_identities_checked':prefix_checked,
            'compatible_surplus_one_pairs_checked':compatibility_checked,
            'historical_label_one_supports':sum(map(len,histories)),
            'low_budget_rank_transitions_checked':transitions_checked,
            'high_budget_counterexamples':exceptions}


if __name__ == '__main__':
    started=time.monotonic()
    results=[run(n) for n in (2,4,6,8,10)]
    data={'method':'Independent direct grid adjacency and all parity subsets; no imports from candidate recurrence.',
          'results':results,'seconds':round(time.monotonic()-started,4)}
    target=Path(__file__).resolve().parents[1]/'research'/'three-row-rank-independent-checks.json'
    target.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(data,indent=2))

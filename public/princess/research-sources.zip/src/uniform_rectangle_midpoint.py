"""Exact odd-rectangle time by a half-horizon frontier and a midpoint cut.

Uses the proved odd-rectangle profiles and the independently reviewed
2*tau-1 / 2*tau theorem. The simpler solo-residual criterion is NOT assumed.
Every reported witness is replayed on the actual coordinate grid.
"""
from bisect import bisect_left, bisect_right
from math import inf
from pathlib import Path
from time import process_time
import argparse
import json

from odd_serial_first_order_attack import profiles
from uniform_rectangle_half_time import capacities
from nested_grid_time import ordered_profiles, neighborhood


def midpoint_minimum(front, E, M):
    """Exact capped pair minimum in O(K log K) for a Pareto frontier.

    front has increasing first counts and strictly decreasing second counts.
    For a fixed first state, the second states with both summands positive
    form an interval. Inside it, minimize the sum of their two counts;
    outside it, monotonicity leaves only the two boundary candidates.
    """
    size = len(front)
    xs = [a for a, _ in front]
    minus_ys = [-b for _, b in front]
    base = 1
    while base < size:
        base *= 2
    tree = [(inf, -1)] * (2 * base)
    for i, (a, b) in enumerate(front):
        tree[base+i] = (a+b, i)
    for i in range(base-1, 0, -1):
        tree[i] = min(tree[2*i], tree[2*i+1])

    def range_min(left, right):
        answer = (inf, -1)
        left += base
        right += base
        while left < right:
            if left & 1:
                answer = min(answer, tree[left])
                left += 1
            if right & 1:
                right -= 1
                answer = min(answer, tree[right])
            left //= 2
            right //= 2
        return answer[1]

    answer = (inf, -1, -1)
    for i, (a, b) in enumerate(front):
        first_positive = bisect_right(xs, E-a)
        last_positive = bisect_left(minus_ys, b-M)-1
        candidates = {0, size-1, first_positive-1, last_positive+1}
        if first_positive <= last_positive:
            candidates.add(range_min(first_positive, last_positive+1))
        else:
            # The two positive regions are disjoint, possibly leaving a
            # nonempty zero interval. Its first index is a boundary above.
            candidates.add(first_positive)
        for j in candidates:
            if 0 <= j < size:
                c, d = front[j]
                answer = min(answer, (max(0, a+c-E)+max(0, b+d-M), i, j))
    return answer


def solve(n, w, m):
    n, w = max(n, w), min(n, w)
    if n % 2 != 1 or w % 2 != 1 or w < 3 or m < 1:
        raise ValueError('Requires odd sides n>=w>=3 and positive budget.')
    start_clock = process_time()
    g = profiles((n-1)//2, (w-1)//2)
    E, M = len(g[0])-1, len(g[1])-1
    tau, D, _ = capacities(g, m)
    if tau is None:
        return {'shape': [n, w], 'budget': m, 'status': 'infeasible'}

    front = [(E, M)]
    parents = []
    largest_frontier = 1
    for _ in range(tau-1):
        candidates = {}
        for a, b in front:
            for p in range(m+1):
                after = (g[1][max(0, b-m+p)], g[0][max(0, a-p)])
                candidates.setdefault(after, ((a, b), p))
        front = []
        best_b = inf
        for a, b in sorted(candidates):
            if b < best_b:
                front.append((a, b))
                best_b = b
        parents.append({state: candidates[state] for state in front})
        largest_frontier = max(largest_frontier, len(front))

    central, i, j = midpoint_minimum(front, E, M)
    report, data = ordered_profiles((n, w))
    assert report['nested'] and report['profiles'] == g
    coords, adj, orders, prefixes, _ = data
    coordinate_index = {cell: i for i, cell in enumerate(coords)}
    reflected_index = {i: coordinate_index[(n-1-x, w-1-y)]
                       for i, (x, y) in enumerate(coords)}

    def reflect(mask):
        out = 0
        while mask:
            bit = mask & -mask
            out |= 1 << reflected_index[bit.bit_length()-1]
            mask ^= bit
        return out

    def half_shots(state):
        shots = []
        for history in reversed(parents):
            (a, b), p = history[state]
            shots.append((prefixes[0][a] ^ prefixes[0][max(0, a-p)]) |
                         (prefixes[1][b] ^ prefixes[1][max(0, b-m+p)]))
            state = (a, b)
        assert state == (E, M)
        return list(reversed(shots))

    if central <= m:
        left, right = front[i], front[j]
        forward = prefixes[0][left[0]] | prefixes[1][left[1]]
        backward = reflect(prefixes[0][right[0]] | prefixes[1][right[1]])
        middle = forward & backward
        assert middle.bit_count() == central
        shots = half_shots(left) + [middle] + [reflect(s) for s in reversed(half_shots(right))]
        construction = 'Two canonical midpoint halves in opposite spatial orders.'
    else:
        solo = []
        for initial in (0, 1):
            phase, count = initial, (E, M)[initial]
            shots_one = []
            while count:
                residual = max(0, count-m)
                shots_one.append(prefixes[phase][count] ^ prefixes[phase][residual])
                count, phase = g[phase][residual], 1-phase
            solo.append(shots_one)
        first = min(solo, key=len)
        assert len(first) == tau
        shots = first + list(reversed(first))
        construction = 'A shortest solo schedule followed by its time reversal.'

    belief = (1 << (n*w))-1
    for day, shot in enumerate(shots, 1):
        assert shot.bit_count() <= m
        belief = neighborhood(belief & ~shot, adj)
        if not belief:
            assert day == len(shots)
    assert belief == 0
    return {
        'shape': [n, w], 'budget': m, 'status': 'finite',
        'minimum_turns': len(shots), 'solo_time': tau,
        'precentral_solo_deficits': list(D),
        'central_minimum': central,
        'solo_residual_sum': E+M-sum(D),
        'midpoint_beliefs': [list(front[i]), list(front[j])],
        'last_frontier_size': len(front), 'maximum_frontier_size': largest_frontier,
        'construction': construction, 'actual_coordinate_replay': True,
        'CPU_seconds': process_time()-start_clock,
        'inspections': [[coords[k] for k in range(n*w) if shot >> k & 1] for shot in shots],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('length', type=int)
    parser.add_argument('width', type=int)
    parser.add_argument('budget', type=int)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    answer = solve(args.length, args.width, args.budget)
    if args.output:
        args.output.write_text(json.dumps(answer, indent=2)+'\n')
    print(json.dumps({key: value for key, value in answer.items() if key != 'inspections'}))


if __name__ == '__main__':
    main()

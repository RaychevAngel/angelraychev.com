"""Reproducible vector illustration of the accepted corner-localization theorem."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "paper/figures"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                     "svg.fonttype": "none", "svg.hashsalt": "princess-research",
                     "pdf.fonttype": 42})


def neighbors(s):
    return {(x+dx, y+dy) for x,y in s
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))
            if 0 <= x+dx < 8 and y+dy >= 0}


def main():
    left = {(x,y) for x in range(8) for y in range(5)
            if (x+y) % 2 == 0 and x+y <= 4}
    right = {(x,y) for x in range(8) for y in range(4)
             if (7-x+y) % 2 == 1 and 7-x+y <= 3}
    cases = [(left, (7,0), 3, "Current-corner triangle", "c′"),
             (right, (0,0), 4, "Opposite-corner triangle", "c")]
    assert len(left) == 9 and len(right) == 6
    assert len(neighbors(left)) == 12 and len(neighbors(right)) == 9
    fig, axes = plt.subplots(1,2,figsize=(7.0,3.55))
    fig.subplots_adjust(left=.015,right=.985,top=.86,bottom=.20,wspace=.11)
    for ax,(s,target,d,title,target_name) in zip(axes,cases):
        nxt = neighbors(s)
        assert target not in nxt
        assert min(abs(x-target[0])+abs(y-target[1]) for x,y in s) == d
        for x in range(9):
            ax.plot([x-.5,x-.5],[-.5,5.5],color=".86",lw=.45,zorder=0)
        for y in range(7):
            ax.plot([-.5,7.5],[y-.5,y-.5],color=".86",lw=.45,zorder=0)
        for x,y in sorted(nxt):
            ax.plot(x,y,"o",mfc="white",mec=".45",mew=1,ms=5.2,zorder=2)
        for x,y in sorted(s):
            ax.plot(x,y,"o",color=".12",ms=5.2,zorder=3)
        ax.plot(*target,marker="x",color=".08",ms=8,mew=1.7,zorder=4)
        ax.text(0,.45,"c",ha="center",va="bottom",fontsize=9)
        ax.text(7,.45,"c′",ha="center",va="bottom",fontsize=9)
        ax.annotate("",xy=(target[0],-.93),xytext=(4,-.93),
                    arrowprops={"arrowstyle":"->","color":".25","lw":1.15})
        ax.plot([4,4],[-.12,-.93],color=".5",lw=.65,ls=":",zorder=1)
        ax.plot([target[0],target[0]],[-.12,-.93],color=".5",lw=.65,ls=":",zorder=1)
        ax.text((4+target[0])/2,-1.18,f"{d} movements",ha="center",va="top",fontsize=8.5)
        ax.set_title(f"{title}\n$|S|={len(s)},\\quad |N(S)|={len(nxt)}$",fontsize=9,pad=7)
        ax.set(xlim=(-.7,7.7),ylim=(-1.65,5.7),aspect="equal")
        ax.axis("off")
    legend = [Line2D([],[],marker="o",color="none",mfc=".12",mec=".12",ms=5,label="Survivor S"),
              Line2D([],[],marker="o",color="none",mfc="white",mec=".45",ms=5,label="One-move neighborhood N(S)"),
              Line2D([],[],marker="x",color="none",mec=".08",mew=1.5,ms=7,label="Excluded corner")]
    fig.legend(handles=legend,loc="lower center",bbox_to_anchor=(.5,.07),ncol=3,
               frameon=False,fontsize=8,handletextpad=.45,columnspacing=1.4)
    fig.text(.5,.024,"Width 8, surplus 3. Arrows show the first possible arrival; inspections can only delay it.",
             ha="center",fontsize=8)
    OUT.mkdir(parents=True,exist_ok=True)
    for ext in ("pdf","svg"):
        fig.savefig(OUT/f"corner-memory.{ext}",bbox_inches="tight",facecolor="white",
                    metadata={"Creator":"Princess-search reproducible figure"})
    svg = OUT/"corner-memory.svg"
    svg.write_text("\n".join(line.rstrip() for line in svg.read_text().splitlines())+"\n")
    plt.close(fig)
    print("Created corner-memory.pdf and corner-memory.svg; exact set and distance assertions passed.")


if __name__ == "__main__":
    main()

"""Physical upper search using pyramids in any of four board directions."""
from collections import defaultdict,deque
from itertools import product
from pathlib import Path
import argparse,json,time

from resumed_even_construction_square_audit import prepare


def run(w,n,k):
    start=time.monotonic();colors=[[(x,y)for x in range(w)for y in range(n)if(x+y)%2==p]
                                   for p in(0,1)]
    index=[{v:i for i,v in enumerate(row)}for row in colors];all_masks=[set(),set()]
    for swapped in(0,1):
        d=prepare(n,w)if swapped else prepare(w,n)
        for p in(0,1):
            for mask in d['ideals'][p]:
                cells=[v for bit,v in enumerate(d['colors'][p])if mask>>bit&1]
                for rx,ry in product((0,1),repeat=2):
                    mapped=[]
                    for a,b in cells:
                        x,y=(b,a)if swapped else(a,b)
                        mapped.append((w-1-x if rx else x,n-1-y if ry else y))
                    if not mapped:all_masks[0].add(0);all_masks[1].add(0);continue
                    q=sum(mapped[0])%2
                    all_masks[q].add(sum(1<<index[q][v]for v in mapped))
    I=[sorted(row,key=lambda x:(x.bit_count(),x))for row in all_masks]
    lookup=[{mask:i for i,mask in enumerate(row)}for row in I]
    sizes=[[x.bit_count()for x in row]for row in I];hood=[]
    for p in(0,1):
        row=[]
        for mask in I[p]:
            cells=[v for bit,v in enumerate(colors[p])if mask>>bit&1]
            N={u for x,y in cells for u in((x-1,y),(x+1,y),(x,y-1),(x,y+1))
               if 0<=u[0]<w and 0<=u[1]<n}
            nmask=sum(1<<index[1-p][v]for v in N)
            assert nmask in lookup[1-p]
            row.append(lookup[1-p][nmask])
        hood.append(row)
    grouped=[defaultdict(list),defaultdict(list)]
    for p in(0,1):
        for i,size in enumerate(sizes[p]):grouped[p][size].append(i)
    initial=(0,len(I[0])-1);queue=deque([(initial,0)]);parents={initial:None}
    terminal=None
    while queue:
        (p,i),depth=queue.popleft()
        if sizes[p][i]<=k:terminal=(p,i);break
        for j in grouped[p][sizes[p][i]-k]:
            if I[p][j]&~I[p][i]:continue
            nxt=(1-p,hood[p][j])
            if nxt not in parents:
                parents[nxt]=((p,i),j);queue.append((nxt,depth+1))
    assert terminal is not None
    steps=[(terminal,0)];current=terminal
    while parents[current]is not None:
        current,j=parents[current];steps.append((current,j))
    steps.reverse();belief=set(colors[0]);trace=[]
    for(p,i),j in steps:
        shot={v for bit,v in enumerate(colors[p])if(I[p][i]^I[p][j])>>bit&1}
        assert len(shot)<=k
        trace.append({'before':sizes[p][i],'survivor':sizes[p][j],'shots':sorted(shot)})
        belief-=shot;belief={u for x,y in belief for u in((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                            if 0<=u[0]<w and 0<=u[1]<n}
    assert not belief
    return {'w':w,'n':n,'k':k,'solo_upper':len(trace),'family_counts':list(map(len,I)),
            'search_states':len(parents),'physical_replay_passed':True,'trace':trace,
            'seconds':time.monotonic()-start,
            'scope':'Restricted physical upper. No unrestricted optimal-family assumption.'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--w',type=int,default=7)
    p.add_argument('--n',type=int,default=8);p.add_argument('--k',type=int,default=4)
    a=p.parse_args();out=run(a.w,a.n,a.k)
    Path(f'research/resumed-even-construction-all-pyramid-orientations-{a.w}x{a.n}-k{a.k}.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='trace'})

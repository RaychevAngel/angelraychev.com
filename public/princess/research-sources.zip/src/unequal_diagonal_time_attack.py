#!/usr/bin/env python3
"""Reproduce a small time-increasing unequal-diagonal compression example."""
from pathlib import Path
import json
from parity_trap_solver import setup
from parity_corner_check import ranks_for
from square_strategy_compression import one_operator

shape=(4,5)
points,neighbors=setup(shape)
ids=[{v:i for i,v in enumerate(row)}for row in points]
support=[(0,1),(0,3),(3,4)]
p=1
mask=sum(1<<ids[p][v]for v in support)
compressed=one_operator(points,0,1,-1)[p][mask]
ranks=ranks_for(neighbors,2)
result={'shape':shape,'budget':2,'support':support,
        'compressed':[v for i,v in enumerate(points[p])if compressed>>i&1],
        'original_minimum_time':ranks[p][mask],
        'compressed_minimum_time':ranks[p][compressed]}
assert(result['original_minimum_time'],result['compressed_minimum_time'])==(2,3)
Path(__file__).resolve().parents[1].joinpath('research/unequal-diagonal-time-small-counterexample.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

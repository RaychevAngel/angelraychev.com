"""Literal audit of the uniform 25-by-even-length, quota13 prefix strategy."""
from pathlib import Path
import hashlib
import json
import math
import time

from bridge_gap_diagnostics import neighborhood
from bridge_upper_transport import capture_replay


def ceil_root(q):
    r = math.isqrt(q)
    return r + (r * r < q)


def plus_root(q):
    r = (math.isqrt(4 * q + 1) - 1) // 2
    return r + (r * (r + 1) < q)


def profile(h, phase, q):
    if q == 0:
        return 0
    if phase == 0:
        return q + min(ceil_root(q), 12, plus_root(h - q))
    return q + min(1 + plus_root(q), 13, ceil_root(h - q))


def clock(h, q=None):
    q = h if q is None else q
    phase = 0
    sizes = [q]
    while q:
        q = profile(h, phase, max(0, q - 13))
        phase ^= 1
        sizes.append(q)
    return sizes


def literal(n):
    w, k = 25, 13
    h = w * n // 2
    orders = [sorted(((x, y) for x in range(w) for y in range(n) if (x + y) % 2 == p),
                     key=lambda v: (sum(v), -v[0])) for p in (0, 1)]
    phase, current = 0, set(orders[0])
    shots, sizes = [], [h]
    while current:
        keep = set(orders[phase][:max(0, len(current) - k)])
        assert keep <= current
        shots.append(current - keep)
        current = neighborhood(w, n, keep)
        phase ^= 1
        assert current == set(orders[phase][:len(current)])
        sizes.append(len(current))
    assert sizes == clock(h)
    assert sizes[46] == h - 132
    assert sizes[2 * h - 532] == 157
    assert sizes[2 * h - 532:] == clock(325, 157)
    assert len(shots) == 25 * n - 462 and len(shots[-1]) == 2
    assert capture_replay(w, n, k, shots) == len(shots)
    reflect = lambda shot: {(x, n - 1 - y) for x, y in shot}
    full = shots[:-1] + [shots[-1] | reflect(shots[-1])] + [reflect(shot) for shot in shots[-2::-1]]
    assert len(full[len(shots) - 1]) == 4
    assert capture_replay(w, n, k, full, full=True) == 50 * n - 925
    return dict(length=n, solo_days=len(shots), full_days=len(full), terminal_size=2,
                entry_days=46, entry_size=h - 132,
                plateau_days=2 * (h - 289), tail_days=70,
                last_shot=sorted(shots[-1]), full_literal_replay=True)


def run():
    began = time.process_time()
    baseline = clock(325)
    entrance = baseline[:47]
    tail = clock(325, 157)
    assert len(tail) - 1 == 70 and tail[-2] == 2
    assert min(q - 13 for q in entrance[:-1]) >= 181
    shift_cases = 0
    for n in range(26, 202, 2):
        h = 25 * n // 2
        sizes = clock(h)
        assert sizes[:47] == [q + h - 325 for q in entrance]
        assert sizes[2 * h - 532:] == tail
        assert len(sizes) - 1 == 25 * n - 462
        shift_cases += 1
    rows = [literal(n) for n in (26, 28, 30, 40, 64)]
    return dict(scope=__doc__, theorem='For every even n>=26, T_13(25,n)<=50n-925.',
                clock_length_cases=shift_cases, physical_full_replays=rows,
                entrance_sizes_n26=entrance, terminal_sizes=tail,
                entrance_defects=[325 - q for q in entrance],
                source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in (Path(__file__), Path('src/bridge_upper_transport.py'),
                                         Path('src/bridge_gap_diagnostics.py'))},
                CPU_seconds=time.process_time() - began)


if __name__ == '__main__':
    result = run()
    Path('research/bridge-upper-transport-odd-length.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('entrance_sizes_n26', 'terminal_sizes', 'entrance_defects')}))

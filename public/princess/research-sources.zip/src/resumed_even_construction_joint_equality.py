"""Bounded equality graph for the existing subcritical-model merger.

Only merged single-model states on a shortest path from full to(176,1)
are retained. This is a necessary restriction for any28-day joint history
with the corresponding total deficit. All labeled component feature pairs
and both alignments of every unordered pair transition are tested.
"""
from collections import deque
from pathlib import Path
import json,time
from resumed_even_construction_formula_profile import build


def distances(edges,start):
    D={start:0};Q=deque([start])
    while Q:
        a=Q.popleft()
        for b in edges[a]:
            if b not in D:D[b]=D[a]+1;Q.append(b)
    return D


def run():
    start=time.monotonic();w=n=24;k=13;h=288;goal=(176,1);deadline=28
    S,O=build(w,k,n);reverse={a:[]for a in S}
    for a,targets in O.items():
        for b in targets:reverse[b].append(a)
    forward=distances(O,(h,2));backward=distances(reverse,goal)
    assert forward[goal]==deadline
    geo=[[a for a in S if forward.get(a,10**6)==t and backward.get(a,10**6)==deadline-t]
         for t in range(deadline+1)]
    valid=set(S)
    def pairs(layer):
        answer=set()
        for m,c in layer:
            total=h+m
            for a in range(max(0,total-h),min(h,total//2)+1):
                b=total-a
                for i in range(3):
                    if(a,i)not in valid:continue
                    for j in range(3):
                        if(b,j)not in valid or max(0,i+j-2)!=c:continue
                        answer.add(tuple(sorted(((a,i),(b,j)))))
        return sorted(answer)
    initial=((h,2),(h,2));reachable={initial};parent={};levels=[];checks=0
    for t in range(1,deadline+1):
        targets=pairs(geo[t]);next_reachable=set()
        for A,B in targets:
            for X,Y in reachable:
                checks+=1
                first=O[X].get(A,k+1)+O[Y].get(B,k+1)
                second=O[X].get(B,k+1)+O[Y].get(A,k+1)
                if min(first,second)<=k:
                    next_reachable.add((A,B));parent[t,(A,B)]=((X,Y),min(first,second));break
        reachable=next_reachable
        levels.append({'day':t,'merged_geodesic_features':geo[t],
                       'candidate_joint_pairs':len(targets),'reachable_joint_pairs':len(reachable),
                       'reachable_pairs':sorted(reachable)})
        assert reachable
    mixed=[pair for pair in reachable if pair[0][0]<h and pair[1][0]<h]
    witness=[]
    if mixed:
        current=mixed[0]
        for t in range(deadline,0,-1):
            prev,cost=parent[t,current];witness.append({'day':t,'pair':current,'daily_quota':cost});current=prev
        witness.reverse()
    return {'shape':[w,n],'budget':k,'deadline':deadline,'merged_target':goal,
            'pure_concentration_forced':not mixed,'terminal_pairs':sorted(reachable),
            'mixed_terminal_pairs':mixed,'mixed_witness':witness,'layers':levels,
            'transition_pair_checks':checks,'seconds':time.monotonic()-start,
            'scope':'Exact finite equality test in the established subcritical necessary model; a mixed witness is not a physical construction.'}


if __name__=='__main__':
    out=run();Path('research/resumed-even-construction-joint-equality28.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items()if k not in('layers','mixed_witness','mixed_terminal_pairs','terminal_pairs')});print('terminals',out['terminal_pairs'][:20])

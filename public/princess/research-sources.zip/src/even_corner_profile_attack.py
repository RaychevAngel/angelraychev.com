"""Attack the conjecture that some corner simplicial prefix is isoperimetric.

Reference profiles are exact by proved odd transverse nesting and the cylinder
profile transfer theorem. This does not assume temporal compatibility.
"""
from itertools import permutations, product
from pathlib import Path
from time import monotonic
import json
from cylinder_profile_transfer import transfer
from nested_grid_time import ordered_profiles


def candidates(shape, parity=0):
    vertices = list(product(*(range(n) for n in shape)))
    row = [v for v in vertices if sum(v) % 2 == parity]
    other = [v for v in vertices if sum(v) % 2 != parity]
    index = {v: i for i, v in enumerate(other)}
    adj = {}
    for v in row:
        nb = 0
        for axis, n in enumerate(shape):
            for delta in (-1, 1):
                w = list(v)
                w[axis] += delta
                if 0 <= w[axis] < n:
                    nb |= 1 << index[tuple(w)]
        adj[v] = nb
    best = [len(other)+1] * (len(row)+1)
    best[0] = 0
    witnesses = [None] * len(best)
    for axes in permutations(range(len(shape))):
        for flips in product((False, True), repeat=len(shape)):
            def key(v):
                w = tuple(shape[j]-1-v[j] if flips[j] else v[j] for j in axes)
                return sum(w), tuple(-x for x in w)
            order = sorted(row, key=key)
            nb = 0
            for k, v in enumerate(order, 1):
                nb |= adj[v]
                if nb.bit_count() < best[k]:
                    best[k] = nb.bit_count()
                    witnesses[k] = {'axes': axes, 'flips': flips}
    return best, witnesses


def main():
    root = Path(__file__).resolve().parents[1]
    out = root / 'research/even-corner-profile-attack.json'
    start = monotonic()
    cases = []
    shapes = [(q, n) for q in [(3,), (5,), (7,), (3,3), (3,5), (5,5), (3,3,3)]
              for n in [4,6,8,10,12]]
    for cross, n in shapes:
        t = monotonic()
        transverse, _ = ordered_profiles(cross, weightlex=True)
        exact = transfer(transverse['profiles'], n, 0)
        best, orders = candidates(cross+(n,))
        bad = [k for k in range(len(exact)) if exact[k] != best[k]]
        result = {'shape': cross+(n,), 'exact_profiles': exact,
                  'candidate_profiles': best, 'mismatch_sizes': bad,
                  'seconds': monotonic()-t}
        if bad:
            result['first_candidate_order'] = orders[bad[0]]
        cases.append(result)
        receipt = {'status': 'counterexample' if bad else 'bounded_match',
                   'scope': 'Exact one-step profiles; no claim of exact time.',
                   'seconds': monotonic()-start, 'cases': cases}
        out.write_text(json.dumps(receipt, indent=2)+'\n')
        print(result['shape'], 'mismatches', bad[:10], 'seconds', round(result['seconds'],3), flush=True)
        if bad or monotonic()-start > 40:
            break


if __name__ == '__main__':
    main()

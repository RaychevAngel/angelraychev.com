"""Reproducible vector figures from actual graph sets and proved formulas."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from path_strategy import schedule, verify, claimed_time
from nested_grid_time import grid, ordered_profiles, neighborhood

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'paper/figures'
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'svg.fonttype': 'none', 'pdf.fonttype': 42,
                     'axes.spines.top': False, 'axes.spines.right': False})
manifest = []

def save(fig, name, caption):
    for ext in ['pdf', 'svg']:
        fig.savefig(OUT / f'{name}.{ext}', bbox_inches='tight', facecolor='white')
    plt.close(fig)
    manifest.append({'name': name, 'description': caption})

fig, ax = plt.subplots(figsize=(6.8, 3.4))
shots = schedule(8, 2)
verify(8, 2, shots)
belief = set(range(1, 9))
for t, S in enumerate(shots):
    y = len(shots)-t
    ax.plot(range(1, 9), [y]*8, color='.78', lw=1, zorder=0)
    ax.scatter(range(1, 9), [y]*8, s=130, facecolors='white', edgecolors='.6', zorder=1)
    ax.scatter(sorted(belief), [y]*len(belief), s=130, color='.18', zorder=2)
    for x in S:
        ax.plot([x-.15, x+.15], [y-.15, y+.15], color='white' if x in belief else 'black', lw=2, zorder=3)
        ax.plot([x-.15, x+.15], [y+.15, y-.15], color='white' if x in belief else 'black', lw=2, zorder=3)
    survivors = belief-set(S)
    belief = {v+d for v in survivors for d in (-1,1) if 1<=v+d<=8}
    ax.text(.35, y, f'Day {t+1}', ha='right', va='center')
assert not belief
for x in range(1,9): ax.text(x, .43, str(x), ha='center', va='center', color='.35')
ax.text(4.5, -.08, 'Filled: still possible before inspection. Cross: inspected today.', ha='center', fontsize=9)
ax.set(xlim=(-.55,8.6), ylim=(-.3,4.7)); ax.axis('off')
save(fig, 'path-sweep', 'Eight rooms, two daily probes, four days. All possible positions are replayed exactly.')

report, data = ordered_profiles((9, 7))
assert report['nested']
coords, adj, orders, prefixes, profiles = data
fig, axes = plt.subplots(1,3, figsize=(7.1,2.8))
for ax, k, name in zip(axes, [4,17,30], ['Corner', 'Across the width', 'Almost full']):
    S = prefixes[0][k]; N = neighborhood(S, adj)
    assert N.bit_count() == profiles[0][k]
    for i,(x,y) in enumerate(coords):
        ax.add_patch(Rectangle((x-.5,y-.5),1,1,fill=False,edgecolor='.82',lw=.45))
        if S>>i&1: ax.plot(x,y,'o',color='.12',ms=5)
        elif N>>i&1: ax.plot(x,y,'o',mfc='white',mec='.4',ms=5)
    ax.set_title(f'{name}\n{k} positions → {N.bit_count()} neighbors',fontsize=9)
    ax.set(xlim=(-.6,8.6),ylim=(-.6,6.6),aspect='equal'); ax.axis('off')
fig.text(.5,.01,'Filled circles: source set. Open circles: its possible neighbors.',ha='center',fontsize=9)
save(fig, 'odd-rectangle-prefixes', 'Minimizing prefixes of one color on the nine-by-seven board.')

fig, axes = plt.subplots(1,3,figsize=(6.8,2.45))
first = {1,3,5,9,11}
for x, ax in enumerate(axes):
    for y in range(3):
        for z in range(3):
            v=9*x+3*y+z
            ax.add_patch(Rectangle((z-.5,y-.5),1,1,facecolor='.18' if v in first else 'white',edgecolor='.5',lw=.8))
            ax.text(z,y,str(v),ha='center',va='center',color='white' if v in first else '.25')
    ax.set_title(f'Layer x = {x}',fontsize=10)
    ax.set(xlim=(-.6,2.6),ylim=(-.6,2.6),aspect='equal');ax.invert_yaxis();ax.axis('off')
fig.text(.5,.015,'First day of the optimal 18-day, five-probe schedule.',ha='center',fontsize=9)
save(fig, 'three-cube-layers', 'Physical room numbering and the first day of the five-probe cube schedule.')

fig, ax = plt.subplots(figsize=(6.8,3.6))
ns=list(range(4,21))
series=[('One row; 1 probe',lambda n:2*n-4,'o','-'),
        ('Two rows; 2 probes',lambda n:2*n-2,'s','--'),
        ('Three rows; 2 probes',lambda n:6*n-8,'^','-.'),
        ('Four rows; 3 probes',lambda n:4*n-4,'D',':')]
for label,fn,marker,ls in series:
    ax.plot(ns,[fn(n) for n in ns],color='.15',lw=1.4,ls=ls,marker=marker,markevery=4,ms=4,label=label)
ax.plot(ns[1:],[10*n-20 for n in ns[1:]],color='.42',lw=1.6,ls='-',marker='x',markevery=4,ms=4,label='Five rows; 3 probes')
ax.set(xlabel='Number of columns',ylabel='Minimum guaranteed days',xticks=range(4,21,4),xlim=(3.6,20.4))
ax.grid(axis='y',color='.9',lw=.6);ax.legend(frameon=False,fontsize=8,loc='upper left')
save(fig, 'minimum-budget-times', 'Proved time formulas at the minimum feasible budgets; lengths four through twenty.')

fig, axes = plt.subplots(1,3,figsize=(6.8,2.55))
def transverse_cost(v):
    if not any(v): return len(v)
    j=max(i for i,x in enumerate(v) if x)
    return len(v)-j-int(v[j]==2)
for kind,(ax,title) in enumerate(zip(axes,['First slice','Every interior slice','Last slice'])):
    for x in range(3):
        for y in range(3):
            cost=transverse_cost((x,y)) if kind==0 else (0 if kind==1 else -1)
            dark=(x+y)%2==0
            ax.add_patch(Rectangle((y-.5,x-.5),1,1,facecolor='.18' if dark else 'white',edgecolor='.5',lw=.8))
            ax.text(y,x,str(cost).replace('-', '−'),ha='center',va='center',color='white' if dark else '.15',fontsize=12)
    ax.set_title(title,fontsize=10)
    ax.set(xlim=(-.6,2.6),ylim=(-.6,2.6),aspect='equal');ax.invert_yaxis();ax.axis('off')
fig.text(.5,.015,'Local contribution to neighborhood surplus in a 3 × 3 × n odd cylinder.',ha='center',fontsize=9)
save(fig, 'cylinder-corner-costs', 'The local cost a(x)−1 is nonnegative on the first slice, zero in the interior, and minus one on the last slice. Shading distinguishes parity.')
(ROOT/'research/paper-figure-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Created',len(manifest),'figures as PDF and SVG.')

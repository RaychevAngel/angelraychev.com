"""Bounded all-downward-pyramid attack for one specified physical prefix.

Survivors are generated on demand by their height walks, not from a global
catalogue. The necessary corner model is used only for admissible pruning.
A cutoff or exhaustive family failure is never an unrestricted impossibility.
"""
from collections import deque
from functools import lru_cache
from pathlib import Path
import json,time
from resumed_even_construction_formula_clock import model_data
from resumed_even_construction_prefix import PrefixGame
from resumed_even_construction_transport import height,neighborhood


def run(w=24,n=24,k=13,p0=1,q0=123,deadline=28,seconds=15,initial_heights=None):
    start=time.monotonic();states,index,options=model_data(w,n,k,critical=True)
    reverse=[0]*len(states)
    for i,mask in enumerate(options):
        while mask:
            bit=mask&-mask;mask^=bit;reverse[bit.bit_length()-1]|=1<<i
    dist=[10**6]*len(states);queue=deque()
    for i,(q,c)in enumerate(states):
        if q<=k:dist[i]=1;queue.append(i)
    while queue:
        i=queue.popleft();mask=reverse[i]
        while mask:
            bit=mask&-mask;mask^=bit;j=bit.bit_length()-1
            if dist[j]>dist[i]+1:dist[j]=dist[i]+1;queue.append(j)
    g=PrefixGame(w,n)
    initial_set=({v for i,v in enumerate(g.colors[p0])if g.orders[p0][0][q0]>>i&1}
                 if initial_heights is None else{v for v in g.colors[p0]if v[1]<=initial_heights[v[0]]})
    initial=tuple(height(w,n,p0,initial_set))
    column=(1<<n)-1;full=(1<<(w*n))-1
    bottom=sum(1<<(x*n)for x in range(w));top=bottom<<(n-1)
    column_masks=[[[sum(1<<(x*n+y)for y in range(a+1)if(x+y)%2==p)
                       for a in range(-2,n)]for x in range(w)]for p in(0,1)]
    count=0;generated=0;pruned=0;failed=set();chosen={};maxdepth=0
    def info(p,A):
        q=sum((a-((p-x)%2-2))//2 for x,a in enumerate(A))
        c=sum(A[x]>=y for x,y in((0,0),(0,n-1),(w-1,0),(w-1,n-1))if(x+y)%2==p)
        return q,c
    def mask_of(p,A):return sum(column_masks[p][x][a+2]for x,a in enumerate(A))
    def next_of(p,B):
        mask=mask_of(p,B)
        hood=(((mask&~top)<<1)|((mask&~bottom)>>1)|(mask<<n)|(mask>>n))&full
        return tuple((part.bit_length()-1 if(part:=((hood>>(x*n))&column))else(1-p-x)%2-2)for x in range(w))
    def survivors(p,A):
        result=[];B=[0]*w
        def rec(x,remaining):
            if x==w:
                if remaining==0:result.append(tuple(B))
                return
            lo=(p-x)%2-2
            choices=range(A[0],max(lo,A[0]-2*k)-1,-2)if x==0 else(B[x-1]-1,B[x-1]+1)
            for b in choices:
                if b<lo or b>A[x]:continue
                used=(A[x]-b)//2
                if used>remaining:continue
                rem=remaining-used
                if sum(max(0,(A[y]-b-(y-x))//2)for y in range(x+1,w))>rem:continue
                B[x]=b;rec(x+1,rem)
        rec(0,k)
        return result
    def dfs(p,A,left):
        nonlocal count,generated,pruned,maxdepth
        if time.monotonic()-start>seconds:raise TimeoutError
        count+=1;maxdepth=max(maxdepth,deadline-left)
        size,c=info(p,A)
        if size<=k:chosen[p,A,left]=None;return True
        if dist[index[size,c]]>left:pruned+=1;return False
        state=(p,A,left)
        if state in failed:return False
        candidates=[]
        for B in survivors(p,A):
            C=next_of(p,B);q,j=info(1-p,C);generated+=1
            if dist[index[q,j]]<=left-1:candidates.append((q,dist[index[q,j]],B,C))
            else:pruned+=1
        candidates.sort(key=lambda row:(row[1],row[0]))
        for _,_,B,C in candidates:
            if dfs(1-p,C,left-1):chosen[state]=(B,C);return True
        failed.add(state);return False
    exhausted=False;found=False
    try:found=dfs(p0,initial,deadline);exhausted=not found
    except TimeoutError:pass
    out={'shape':[w,n],'budget':k,'initial_prefix_phase':p0,'initial_prefix_size':q0,
         'deadline':deadline,'found':found,'restricted_search_exhausted':exhausted,
         'initial_heights':initial,
         'visited_calls':count,'generated_survivors':generated,'model_prunes':pruned,
         'failed_states':len(failed),'deepest_layer':maxdepth,'seconds':time.monotonic()-start,
         'scope':'Bounded on-demand downward-pyramid upper search from a specified physical prefix. No unrestricted lower claim.'}
    if exhausted:
        out['failed_state_certificate']=[{'phase':p,'heights':A,'remaining_days':left}
                                          for p,A,left in sorted(failed)]
        out['model_lower_potential']=[{'size':q,'corners':c,'lower':dist[i]}
                                       for i,(q,c)in enumerate(states)]
    if found:
        p,A,left=p0,initial,deadline;shots=[];records=[]
        while True:
            decision=chosen[p,A,left];B=tuple((p-x)%2-2 for x in range(w))if decision is None else decision[0]
            shotmask=mask_of(p,A)^mask_of(p,B)
            shot={(x,y)for x in range(w)for y in range(n)if shotmask>>(x*n+y)&1};shots.append(shot)
            records.append({'before_size':info(p,A)[0],'survivor_heights':B,'shots':sorted(shot)})
            if decision is None:break
            A=decision[1];p^=1;left-=1
        actual=set(initial_set)
        for shot in shots:
            assert len(shot)<=k;actual=neighborhood(w,n,actual-shot)
        assert not actual;out.update(capture_days=len(shots),physical_replay_passed=True,schedule=records)
    return out


if __name__=='__main__':
    out=run();Path('research/resumed-even-construction-partial-prefix123.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items()if k!='schedule'})

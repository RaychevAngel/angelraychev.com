"""Cached exact-cost graphs for near-square history-filter counterattacks.

The cache is local execution data. Model claims remain conditional on the
ordinary geometric and merger proofs; no physical upper is generated.
"""
from pathlib import Path
from collections import deque
import argparse,json,pickle,time
from bridge_lower_frontier_probe import load_model,distances

def base_cache(b,n,k):
    folder=Path('.build');folder.mkdir(exist_ok=True)
    path=folder/f'bridge-lower-frontier-weighted-{b}-{n}-{k}.pickle'
    if path.exists():
        with path.open('rb')as f:return pickle.load(f),True
    started=time.process_time();build,sha,modelsha=load_model(True,True,weighted_cache=True)
    states,masks=build(b,n,k,closed=True,triangle=True,maximal=True,dual=True,compact=True,all_radii=True,band_dual=True)
    data=dict(states=states,masks=masks,weighted=build.__globals__['_bridge_last_weighted'],source_sha256=sha,model_sha256=modelsha,build_cpu_seconds=time.process_time()-started)
    with path.open('wb')as f:pickle.dump(data,f)
    return data,False

def flagged(data,b,n,k,mode,return_weighted=False):
    h=(2*b+1)*n//2;states=list(data['states']);ids={s:i for i,s in enumerate(states)}
    near={a:len(states)+offset for offset,a in enumerate(a for r in range(2,b+1)for a in range(h-r*r,h-r*(r-1)))}
    rows=[[x for x in row]+[0]*len(near)for row in data['weighted']]
    # Source c2 and target erosion2 force survivor i2 by maximality.
    for a,source in enumerate(states):
        size,c,e=source[:3]
        if c!=2:continue
        for T,extra in near.items():
            old=ids[(T,1,2)];bit=1<<old;d=h-T
            for p in range(k+1):
                r=T-size+p
                if 2<=r<=b and r*(r-1)<d<=r*r and rows[p][a]&bit:
                    rows[p][a]=(rows[p][a]&~bit)|(1<<extra)
    # From the flagged c1/e2 source to target c1/e2, maximality forces
    # survivor i1, so closed surplus is original surplus minus one.
    for size,extra in near.items():
        old=ids[(size,1,2)]
        for p in range(k+1):
            row=rows[p][old]
            for T in near:
                s=T-size+p-1;d=h-T
                if not(2<=s<=b and s*(s-1)<d<=s*s):continue
                forbidden=mode=='forbid-pair'
                if mode=='inner-slack':
                    oldd=h-size;r=int(oldd**0.5)
                    if r*r<oldd:r+=1
                    q=min(r,max(0,n//2-s))
                    forbidden=1<max(0,q*q-(r*r-oldd))
                if forbidden:row&=~(1<<ids[(T,1,2)])
            rows[p][extra]=row
    states.extend((a,1,2,6)for a in near)
    masks=[0]*len(states)
    for row in rows:
        for i,bits in enumerate(row):masks[i]|=bits
    return (states,masks,rows) if return_weighted else (states,masks)

def multi_distances(masks,initial):
    dist=[None]*len(masks);todo=deque(initial)
    for i in initial:dist[i]=0
    while todo:
        a=todo.popleft();bits=masks[a]
        while bits:
            bit=bits&-bits;bits-=bit;d=bit.bit_length()-1
            if dist[d] is None:dist[d]=dist[a]+1;todo.append(d)
    return dist

def run(b,n,k,mode,with_time_cut=False):
    started=time.process_time();data,cached=base_cache(b,n,k)
    print(json.dumps(dict(event='base-ready',width=2*b+1,length=n,cached=cached,build_cpu_seconds=data['build_cpu_seconds'])),flush=True)
    states,masks=flagged(data,b,n,k,mode);h=(2*b+1)*n//2
    initial=states.index((h,2,2));zero=states.index((0,0,0));dist=distances(masks,initial);tau=dist[zero]
    residual=min(s[0]for i,s in enumerate(states)if dist[i] is not None and dist[i]<=tau-1)
    out=dict(width=2*b+1,length=n,budget=k,mode=mode,source_sha256=data['source_sha256'],model_sha256=data['model_sha256'],cached_base=cached,states=len(states),edges=sum(x.bit_count()for x in masks),solo_tau=tau,penultimate_residual=residual)
    if with_time_cut:
        assert k==13 and 2*b+1>=24
        at28=[i for i,s in enumerate(states)if dist[i] is not None and dist[i]<=28 and s[0]>=h-111]
        later=multi_distances(masks,at28);filtered_tau=28+later[zero]
        filtered_f=min(s[0]for i,s in enumerate(states)if later[i] is not None and later[i]<=later[zero]-1)
        out.update(time28_joint_barrier_used=True,filtered_solo_tau=filtered_tau,filtered_penultimate_residual=filtered_f,full_lower=2*filtered_tau if 2*filtered_f>k else 2*filtered_tau-1)
    # Check all reachable directed edges against computed forward ranks.
    checks=0
    for a,bits in enumerate(masks):
        if dist[a] is None:continue
        while bits:
            bit=bits&-bits;bits-=bit;d=bit.bit_length()-1
            assert dist[d] is not None and dist[d]<=dist[a]+1;checks+=1
    out['forward_edge_inequalities_checked']=checks;out['cpu_seconds']=time.process_time()-started
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--case',default='12,26,13');ap.add_argument('--mode',choices=('inner-slack','forbid-pair'),default='forbid-pair');ap.add_argument('--time-cut',action='store_true');ap.add_argument('--output',default='research/bridge-lower-frontier-forbidden-pair-check.json');args=ap.parse_args()
    row=run(*map(int,args.case.split(',')),args.mode,args.time_cut)
    print(json.dumps(row),flush=True)
    Path(args.output).write_text(json.dumps(dict(scope=__doc__,row=row),indent=2)+'\n')

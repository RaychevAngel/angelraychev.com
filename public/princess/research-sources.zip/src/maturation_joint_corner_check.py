"""Direct finite checks of simultaneous source/outgoing corner omissions."""
from pathlib import Path
from time import process_time
import json
from maturation_quadrant_check import witness as quadrant_witness, capacity


def neighbors(S,w):
    return {(x+dx,y+dy)for x,y in S for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))
            if 0<=x+dx<w and y+dy>=0}


def bound(b,s):
    if s<=b:return capacity(2,s)
    if s==b+1:return max(b*(b+1)//2,b*b-2)
    return None


def forbidden(b):return {(0,0),(2*b-2,0),(2*b-1,1)}


def full_pyramid(b,k):
    S=set();y=0
    while len(S)<k:
        for x in range(2*b):
            if (x+y)%2==0 and len(S)<k:S.add((x,y))
        y+=1
    return S


def ordinary_quadrant_prefix(k):
    S=set();d=0
    while len(S)<k:
        for x in range(d+1):
            if len(S)<k:S.add((x,d-x))
        d+=2
    return S


def construction(b,k):
    K=max(b*(b+1)//2,b*b-2)
    if not k:return set()
    if k<=capacity(2,b):
        s=next(s for s in range(b+1)if k<=capacity(2,s))
        return {(y,x)for x,y in quadrant_witness(2,s,k)}
    if k<=K:
        if b==2:return set([(0,2),(0,4),(1,3)][:k])
        return ordinary_quadrant_prefix(k+1)-{(0,0)}
    return full_pyramid(b,k+3)-forbidden(b)


def raw_check(b,height):
    w=2*b;F=forbidden(b)
    cells=[(x,y)for x in range(w)for y in range(height)if (x+y)%2==0 and(x,y)not in F]
    ns=sorted(neighbors(cells,w));idx={v:i for i,v in enumerate(ns)}
    masks=[sum(1<<idx[v]for v in neighbors({c},w))for c in cells]
    stack=[(0,0,0)];checked=0;mins={}
    while stack:
        j,k,N=stack.pop()
        if j==len(cells):
            delta=N.bit_count()-k;lim=bound(b,delta)
            assert lim is None or k<=lim,(b,k,delta,lim)
            mins[k]=min(mins.get(k,10**9),delta);checked+=1
        else:
            stack.append((j+1,k,N));stack.append((j+1,k+1,N|masks[j]))
    return {'b':b,'height':height,'admissible_cells':len(cells),'raw_subsets':checked,
            'minimum_surplus_by_size':mins}


def main():
    start=process_time();raw=[raw_check(2,10),raw_check(3,6),raw_check(4,4)]
    checks=0
    for b in range(2,14):
      for k in range(3*b*b+1):
        S=construction(b,k);N=neighbors(S,2*b)
        assert len(S)==k,(b,k,len(S))
        assert not S&forbidden(b)
        assert (2*b-1,0)not in N
        assert all(0<=x<2*b and y>=0 and(x+y)%2==0 for x,y in S)
        want=next(s for s in range(b+3)if bound(b,s)is None or k<=bound(b,s))
        assert len(N)-k==want,(b,k,len(N)-k,want)
        checks+=1
    result={'status':'PASS','scope':'Finite coordinate checks only; the unbounded ordinary proof is audited separately.',
      'raw_cases':raw,'total_raw_subsets':sum(x['raw_subsets']for x in raw),
      'all_size_witnesses':checks,'CPU_seconds':process_time()-start}
    root=Path(__file__).resolve().parents[1]
    (root/'research/maturation-joint-corner-independent-check.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='raw_cases'},indent=2))


if __name__=='__main__':main()

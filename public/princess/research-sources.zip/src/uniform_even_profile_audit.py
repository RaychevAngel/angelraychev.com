#!/usr/bin/env python3
"""Independent raw-subset audit of the even-short-side profile formula."""
from math import isqrt
from pathlib import Path
from time import process_time
import json

def root(k):
    s=isqrt(k)
    return s+(s*s<k)

def rho(k):
    s=isqrt(k)
    while s*(s+1)<k:s+=1
    while s and (s-1)*s>=k:s-=1
    return s

def case(w,n):
    verts=[(x,y) for x in range(w) for y in range(n)]
    parity=[[v for v in verts if sum(v)%2==p] for p in (0,1)]
    h=w*n//2; b=w//2
    theory=[k+min(root(k),b,rho(h-k)) for k in range(h+1)]
    minima=[]
    for p in (0,1):
        idx={v:j for j,v in enumerate(parity[1-p])}
        adj=[]
        for x,y in parity[p]:
            adj.append(sum(1<<idx[(u,v)] for u,v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if (u,v) in idx))
        ns=[0]*(1<<h); best=[h+1]*(h+1)
        for mask in range(1<<h):
            if mask:
                bit=mask&-mask;ns[mask]=ns[mask^bit]|adj[bit.bit_length()-1]
            k=mask.bit_count();j=ns[mask].bit_count();best[k]=min(best[k],j)
            s=j-k
            if s<b:assert k<=s*s or h-k<=s*(s+1),(w,n,p,mask,s)
        assert best==theory,(w,n,p,best,theory)
        minima.append(best)
    return dict(width=w,length=n,subsets=2*(1<<h),profiles=minima)

def main():
    start=process_time()
    cases=[case(w,n) for w,n in [(2,2),(2,3),(2,7),(4,4),(4,5),(4,6),(4,7),(6,6),(6,7)]]
    result=dict(status='PASS',cases=cases,subsets=sum(c['subsets'] for c in cases),cpu_seconds=process_time()-start,scope='Every physical same-color subset on nine finite boards; ordinary all-parameter proof audited separately.')
    Path('research/uniform-even-profile-independent-check.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k!='cases'})
if __name__=='__main__':main()

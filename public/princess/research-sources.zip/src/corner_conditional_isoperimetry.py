#!/usr/bin/env python3
"""Necessary local exchange tests inside corner ideals, with exact cardinality.

For each canonical starting support I and residual size k, compare the true
minimum |N(R)| over R subset I against the same minimum over corner ideals R.
This is a one-step property, not the requested multistep optimality theorem.
"""
from pathlib import Path
from time import monotonic
import argparse
import json
from parity_trap_solver import setup
from parity_corner_check import canonical_flags


def subset_minimum(values):
    n = (len(values)-1).bit_length()
    result = values[:]
    for i in range(n):
        bit = 1 << i
        for base in range(0,len(result),bit<<1):
            for mask in range(base+bit,base+(bit<<1)):
                if result[mask^bit] < result[mask]: result[mask] = result[mask^bit]
    return result


def run(shape):
    start=monotonic()
    colors, ns = setup(shape)
    flags=canonical_flags(shape,colors)
    result={'shape':shape,'canonical_counts':[sum(f) for f in flags], 'failures':[], 'pairs_checked':0}
    for p in (0,1):
        sizes=[a.bit_count() for a in range(len(ns[p]))]
        costs=[a.bit_count() for a in ns[p]]
        infinity=len(colors[1-p])+1
        for k in range(1,len(colors[p])+1):
            exact=subset_minimum([costs[a] if sizes[a]==k else infinity for a in range(len(sizes))])
            canonical=subset_minimum([costs[a] if sizes[a]==k and flags[p][a] else infinity for a in range(len(sizes))])
            for a,flag in enumerate(flags[p]):
                if flag and sizes[a]>=k:
                    result['pairs_checked']+=1
                    if exact[a]!=canonical[a]:
                        if len(result['failures'])>=5: continue
                        r=a
                        while not (sizes[r]==k and costs[r]==exact[a]):
                            r=(r-1)&a
                        js=[j for j in range(len(ns[p])) if j&a==j and flags[p][j] and sizes[j]==k]
                        j=min(js,key=lambda j:costs[j])
                        result['failures'].append({'parity':p,'start_size':sizes[a],'residual_size':k,
                            'minimum_neighborhood':exact[a], 'minimum_corner_neighborhood':canonical[a],
                            'start':[colors[p][i]for i in range(len(colors[p]))if a>>i&1],
                            'best_survivor':[colors[p][i]for i in range(len(colors[p]))if r>>i&1],
                            'best_corner_survivor':[colors[p][i]for i in range(len(colors[p]))if j>>i&1]})
    result['seconds']=round(monotonic()-start,4)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('shape',nargs='+',type=int)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    data=run(tuple(args.shape))
    args.output.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(data,indent=2))

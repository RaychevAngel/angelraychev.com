"""Direct attaining five-row/three-probe sweeps; all lengths n>=5.
The ordinary all-length proof is research/five-row-investigation.md.
"""
from nested_grid_time import ordered_profiles,neighborhood
from five_row_boundary_automaton import analyze,certify_geometry
from five_row_cut_states import critical_sets,hood
from pathlib import Path
import json,time

def strategy(n):
    if n%2:return odd_strategy(n)
    assert n>=6 and n%2==0
    report,data=ordered_profiles((n,5));assert report['nested']
    coords,adj,orders,prefixes,profiles=data;h=5*n//2;index={c:i for i,c in enumerate(coords)}
    def canon(b,z,physical):
        mask=prefixes[z][b]
        if z==physical:return mask
        return sum(1<<index[(n-1-c,r)]for i,(c,r)in enumerate(coords)if mask>>i&1)
    # Check the explicit symbolic prefix tables at this length.
    for k in range(h+1):
        g0=0 if k==0 else h if k==h else k+1 if k in(1,h-2,h-1)else k+2
        g1=0 if k==0 else h if k==h else k+1 if k==h-1 else k+2 if k in(1,2,h-4,h-3,h-2)else k+3
        assert profiles[0][k]==g0 and profiles[1][k]==g1,(n,k)
    full=(1<<len(coords))-1;belief=full;shots=[]
    for cohort in range(2):
        b=h;z=0;started=len(shots)
        while b:
            physical=cohort^(len(shots)%2)
            support=canon(b,z,physical);survivors=canon(max(b-3,0),z,physical)
            shot=support^survivors;assert shot.bit_count()<=3 and shot&~belief==0
            belief=neighborhood(belief&~shot,adj);shots.append(shot)
            actual=neighborhood(survivors,adj);b=actual.bit_count();z=1-z
            assert actual==canon(b,z,1-physical)
        assert len(shots)-started==2*h-10
    assert not belief and len(shots)==10*n-20
    return dict(n=n,turns=len(shots),shots=[[coords[i]for i in range(len(coords))if s>>i&1]for s in shots])

def odd_profile(h,b,z):
    if b==0:return 0
    if z==0:
        if b>=h:return h
        return b+(1 if b==1 or b>=h-3 else 2)
    return b+(1 if b==h else 2 if b<=2 or b>=h-2 else 3)

def odd_value(h,b,z):
    if b==0:return 0
    if b<=2:return 1
    if b<=5:return b-2
    return min(2*b+z-8,b+h+z-10)

def odd_strategy(n):
    assert n>=5 and n%2==1
    report,data=ordered_profiles((n,5));assert report['nested']
    coords,adj,orders,prefixes,profiles=data;h=(5*n-1)//2
    for z in range(2):
        for b in range(h+2-z):
            assert profiles[z][b]==odd_profile(h,b,z),(n,z,b)
    belief=(1<<len(coords))-1;shots=[]
    # The minority-first solo length is odd. The initially larger cohort
    # therefore starts its own sweep in the smaller physical parity too.
    for cohort in (1,0):
        z=cohort^(len(shots)%2);assert z==1
        b=h;started=len(shots)
        while b:
            support=prefixes[z][b];survivors=prefixes[z][max(b-3,0)]
            shot=support^survivors;assert shot.bit_count()<=3 and shot&~belief==0
            belief=neighborhood(belief&~shot,adj);shots.append(shot)
            actual=neighborhood(survivors,adj)
            assert actual.bit_count()==odd_profile(h,max(b-3,0),z)
            b=actual.bit_count();z=1-z
            assert actual==prefixes[z][b]
        assert len(shots)-started==2*h-9
    assert not belief and len(shots)==10*n-20
    return dict(n=n,turns=len(shots),shots=[[coords[i]for i in range(len(coords))if s>>i&1]for s in shots])

def verify_odd():
    started=time.monotonic();cases=0
    for h in range(12,101):
        for z in range(2):
            for b in [0]+list(range(3-z,h+2-z)):
                for p in range(4):
                    after=odd_profile(h,max(b-p,0),z)
                    assert odd_value(h,b,z)<=odd_value(h,after,1-z)+(p>=2),(h,b,z,p)
                    cases+=1
    rows=[]
    for n in range(5,102,2):
        r=odd_strategy(n);rows.append({k:v for k,v in r.items()if k!='shots'})
    result=dict(method='Direct odd-length physical sweeps and exact profile tables; finite arithmetic attack supplements the universal Lean potential lemma.',potential_cases=cases,strategies=rows,seconds=time.monotonic()-started)
    Path('research/five-row-odd-three-probe-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def expand_template(t,q):
    word=t['word'];pumps=t['pump'];remaining=q-len(word)
    if remaining<0:return
    if not pumps:
        if not remaining:yield tuple(word)
        return
    def assign(i,left,extra):
        if i==len(pumps)-1:
            extra=extra+[left];repeat=dict(zip(pumps,extra));out=[]
            for j,c in enumerate(word):out.extend([c]*(1+repeat.get(j,0)))
            yield tuple(out)
        else:
            for k in range(left+1):yield from assign(i+1,left-k,extra+[k])
    yield from assign(0,remaining,[])

def finite_crosscheck(q,templates):
    adj,sets,_=critical_sets(q)
    generated=set()
    for t in templates:
        for word in expand_template(t,q):generated.add(sum(c<<(5*j)for j,c in enumerate(word)))
    expected={s for s,c in sets.items()if c==2}
    assert generated==expected,(q,len(generated),len(expected),next(iter(generated^expected),None))
    return dict(columns=q,surplus_two_sets=len(generated),equal_to_independent_SCC_enumerator=True)

if __name__=='__main__':
    started=time.monotonic();geometry=certify_geometry();templates=analyze(2,True)['templates']
    comparisons=[finite_crosscheck(q,templates)for q in range(3,9)]
    rows=[]
    for n in range(6,102,2):
        r=strategy(n);rows.append({k:v for k,v in r.items()if k!='shots'})
    result=dict(method='Direct physical sweeps, no search; symbolic geometry implications checked on all pump exponents; independent finite SCC comparison attacks the automaton implementation.',geometry=geometry,finite_crosschecks=comparisons,strategies=rows,seconds=time.monotonic()-started)
    Path('research/five-row-three-probe-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(dict(lengths=len(rows),seconds=result['seconds'],geometry=geometry['status'],finite_crosschecks=comparisons))
    odd=verify_odd();print(dict(odd_lengths=len(odd['strategies']),potential_cases=odd['potential_cases'],seconds=odd['seconds']))

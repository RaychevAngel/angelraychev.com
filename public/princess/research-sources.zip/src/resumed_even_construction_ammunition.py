"""Exact finite ammunition potentials for compressed even-square states.

The daily cap remains k. Edge weight is useful inspections, so the shortest
cost-to-empty is a per-state potential valid under every allocation <=k.
"""
import heapq
import json
from pathlib import Path
import time

from resumed_even_construction_square_audit import prepare
from resumed_even_construction_prefix import ceilroot,rho


def labels(reverse, terminals):
    distance={s:(0,0) for s in terminals};queue=[(0,0,s) for s in terminals]
    heapq.heapify(queue)
    while queue:
        ammunition,days,s=heapq.heappop(queue)
        if distance[s]!=(ammunition,days):continue
        for before,cost in reverse[s]:
            candidate=(ammunition+cost,days+1)
            if candidate<distance.get(before,(10**9,10**9)):
                distance[before]=candidate
                heapq.heappush(queue,(*candidate,before))
    return distance


def run(w=8,k=5):
    started=time.monotonic();d=prepare(w,w)
    ideals,sizes,hood=[d[q] for q in ('ideals','sizes','hood')]
    reverse={(p,i):[] for p in (0,1) for i in range(len(ideals[p]))}
    edges={s:[] for s in reverse}
    for p in (0,1):
        for i,a in enumerate(ideals[p]):
            for j,r in enumerate(ideals[p]):
                cost=sizes[p][i]-sizes[p][j]
                if 0<=cost<=k and r&~a==0:
                    nxt=(1-p,hood[p][j]);before=(p,i)
                    reverse[nxt].append((before,cost));edges[before].append((nxt,cost,j))
    distance=labels(reverse,[(0,0),(1,0)])
    h=w*w//2;r=w//2
    g=lambda s:s+min(ceilroot(s),r,rho(h-s))
    scalar_reverse={i:[] for i in range(h+1)}
    for s in range(h+1):
        for m in range(min(s,k)+1):scalar_reverse[g(s-m)].append((s,m))
    scalar=labels(scalar_reverse,[0])
    rows=[]
    for p in (0,1):
        for i,a in enumerate(ideals[p]):
            state=(p,i);F,days=distance[state]
            # Every admissible transition obeys the potential inequality.
            assert all(F<=cost+distance[nxt][0] for nxt,cost,_ in edges[state])
            if a:
                assert (F,days)==min((cost+distance[nxt][0],1+distance[nxt][1])
                                     for nxt,cost,_ in edges[state])
            aa=d['heights'][p][i];size=sizes[p][i]
            bottom=sum(aa[x]>=0 for x in range(w) if (p-x)%2==0)
            full=sum(aa[x]>=w-2 for x in range(w))
            rows.append({'p':p,'id':i,'size':size,'F':F,'F_days':days,
                         'scalar_F':scalar[size][0],'correction':F-scalar[size][0],
                         'heights':aa,'height_span':max(aa)-min(aa),
                         'bottom_roots':bottom,'top_fibers':full})
    state=(0,len(ideals[0])-1);witness=[];physical=set(d['colors'][0])
    while state[1]:
        p,i=state;F,days=distance[state]
        nxt,cost,j=next((nxt,cost,j) for nxt,cost,j in edges[state]
                        if (F,days)==(cost+distance[nxt][0],1+distance[nxt][1]))
        shot=[v for bit,v in enumerate(d['colors'][p])
              if (ideals[p][i]^ideals[p][j])>>bit&1]
        assert len(shot)==cost<=k
        physical-=set(shot)
        physical={u for x,y in physical for u in
                  ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                  if 0<=u[0]<w and 0<=u[1]<w}
        witness.append({'before':sizes[p][i],'after':sizes[nxt[0]][nxt[1]],
                        'cost':cost,'F_before':F,'F_after':distance[nxt][0],
                        'heights':d['heights'][p][i],'shots':shot})
        state=nxt
    assert not physical
    full=distance[(0,len(ideals[0])-1)][0]
    return {'shape':[w,w],'daily_cap':k,'F_full':full,'scalar_F_full':scalar[h][0],
            'additive_full_game_lower_bound':(2*full+k-1)//k,
            'state_count':len(rows),'potential_inequalities_checked':sum(map(len,edges.values())),
            'physical_ammunition_witness':witness,'rows':rows,
            'seconds':time.monotonic()-started,
            'scope':'Finite square compression theorem plus exhaustive weighted Bellman potential; no general closed expression or Lean claim.'}


if __name__=='__main__':
    output=run()
    Path('research/resumed-even-construction-ammunition-8x8-k5.json').write_text(json.dumps(output,indent=2)+'\n')
    print({k:v for k,v in output.items() if k not in ('rows','physical_ammunition_witness')})
    print('cost_word',[x['cost'] for x in output['physical_ammunition_witness']])

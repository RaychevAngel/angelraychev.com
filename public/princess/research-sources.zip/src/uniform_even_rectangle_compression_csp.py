"""Necessary finite constraints for an N-subcommuting pyramid retraction.

Arc consistency only: contradiction disproves this particular operator class;
nonempty domains are not evidence that a solution exists.
"""
from collections import deque
from itertools import product
import json
from time import process_time
from pathlib import Path

def run(w,n):
 start=process_time();V=[[(x,y) for x in range(w) for y in range(n) if (x+y)%2==p] for p in (0,1)]
 idx=[{v:i for i,v in enumerate(row)} for row in V];N=[];I=[]
 for p in (0,1):
  singleton=[sum(1<<idx[1-p][v] for v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if v in idx[1-p]) for x,y in V[p]]
  ns=[0]*(1<<len(V[p]));pred=[sum(1<<idx[p][(X,y-1)] for X in (x-1,x+1) if y and 0<=X<w) for x,y in V[p]]
  ideals=[]
  for a in range(len(ns)):
   if a:bit=a&-a;ns[a]=ns[a^bit]|singleton[bit.bit_length()-1]
   if all(not(a>>i&1) or a&r==r for i,r in enumerate(pred)):ideals.append(a)
  N.append(ns);I.append(ideals)
 offset=[0,len(N[0])];D=[]
 for p in (0,1):
  for a in range(len(N[p])):
   # Monotonicity with every fixed ideal gives these necessary interval bounds.
   lower=0;upper=len(N[p])-1
   for j in I[p]:
    if j&a==j:lower|=j
    if j&a==a:upper&=j
   D.append({j for j in I[p] if j.bit_count()==a.bit_count() and j&lower==lower and j&upper==j})
   if not D[-1]:return {'status':'contradiction before propagation','phase':p,'support':a,'shape':[w,n]}
 # Directed binary constraints, revisable in both directions.
 before_sizes={k:sum(len(d)==k for d in D) for k in range(1,max(map(len,D))+1)}
 edges=[];inc=[[] for _ in D]
 def add(a,b,kind,p):
  i=len(edges);edges.append((a,b,kind,p));inc[a].append(i);inc[b].append(i)
 for p in (0,1):
  for a in range(len(N[p])):
   for i in range(len(V[p])):
    if not(a>>i&1):add(offset[p]+a,offset[p]+(a|(1<<i)),0,p)
   add(offset[p]+a,offset[1-p]+N[p][a],1,p)
 queue=deque(range(len(edges)));queued=set(queue);rounds=0
 while queue:
  e=queue.popleft();queued.remove(e);a,b,kind,p=edges[e];rounds+=1
  def ok(x,y):
   z=x if not kind else N[p][x]
   return z&y==z
  da={x for x in D[a] if any(ok(x,y) for y in D[b])}
  db={y for y in D[b] if any(ok(x,y) for x in D[a])}
  if not da or not db:
   phase=0 if (a if not da else b)<offset[1] else 1
   return {'status':'arc-consistency contradiction','shape':[w,n],'edge':[a,b,kind,p],'old_domains':[sorted(D[a]),sorted(D[b])],'revisions':rounds,'CPU_seconds':process_time()-start}
  for node,new in ((a,da),(b,db)):
   if D[node]!=new:
    D[node]=new
    for z in inc[node]:
     if z not in queued:queued.add(z);queue.append(z)
 assign=[min(d) for d in D]
 failures=[]
 for a,b,kind,p in edges:
  x=assign[a] if not kind else N[p][assign[a]]
  if x&assign[b]!=x:failures.append([a,b,kind,p]);break
 Path('research/uniform-even-rectangle-compression-map.json').write_text(json.dumps({'shape':[w,n],'coordinates':V,'ideals':I,'images':[assign[:offset[1]],assign[offset[1]:]]})+'\n')
 return {'initial_sizes':before_sizes,'minimum_assignment_passes':not failures,'first_minimum_failure':failures,'status':'arc-consistent only','shape':[w,n],'domain_sizes':{k:sum(len(d)==k for d in D) for k in range(1,max(map(len,D))+1)},'revisions':rounds,'CPU_seconds':process_time()-start}

if __name__=='__main__':
 r=run(4,6);print(json.dumps(r,indent=2));Path('research/uniform-even-rectangle-compression-csp.json').write_text(json.dumps(r,indent=2)+'\n')

"""Attack two-block serial domination only for exceptional precapture states.

Finite odd-rectangle profiles are used, including reflected corners.
Serial words are A^i, one shared quota, B^j, where A,B are the two
different initial cohorts. Every i,j,quota is included by a two-mode DP.
"""
from supersession_solo_bands import OddRectangle
from supersession_odd_midpoint_bounded import pareto
from time import process_time
import json


def prune(states):
    return {s: states[s] for s in pareto(states)}


def attack(w, n, m, cutoff):
    G = OddRectangle(w, n)
    front = {(0, 0): ()}
    pure = [(0, 0), (0, 0)]
    switched = [{}, {}]
    day = a = c = 0
    maximum = 0

    def step(s, p):
        x, y = s
        return G.inverse(0, y + m - p), G.inverse(1, x + p)

    while True:
        aa, cc = G.inverse(0, c + m), G.inverse(1, a + m)
        if aa >= G.E or cc >= G.M:
            return {'shape': [w, n], 'm': m, 'passed': True,
                    'layers': day, 'maximum_frontier': maximum}
        next_front = {}
        for s, word in front.items():
            for p in range(m + 1):
                z = step(s, p)
                if not min(z) or sum(z) > min(aa, cc):
                    next_front.setdefault(z, word + (p,))
        front = prune(next_front)
        for first in (0, 1):
            physical = first ^ (day % 2)
            quota_first = m if physical == 0 else 0
            quota_second = m - quota_first
            after = {step(s, quota_second): word + (quota_second,)
                     for s, word in switched[first].items()}
            prefix = tuple(m if first ^ (t % 2) == 0 else 0
                           for t in range(day))
            for p in range(m + 1):
                after.setdefault(step(pure[first], p), prefix + (p,))
            switched[first] = prune(after)
            pure[first] = step(pure[first], quota_first)
        a, c = aa, cc
        day += 1
        maximum = max(maximum, len(front))
        serial = prune(switched[0] | switched[1])
        for (x, y), word in front.items():
            if x and y and x + y > min(a, c):
                if not any(u >= x and v >= y for u, v in serial):
                    return {'shape': [w, n], 'm': m, 'passed': False,
                            'day': day, 'solo_capacities': [a, c],
                            'state': [x, y], 'actual_word_color0': word,
                            'serial_frontier': list(serial),
                            'actual_frontier': list(front)}
        if process_time() >= cutoff:
            return {'shape': [w, n], 'm': m, 'complete': False,
                    'last_day': day}


def check(seconds=4):
    start = process_time()
    rows = []
    for b in (2, 3, 4, 7, 10):
        w = 2 * b + 1
        for n in (w, w + 2, 3 * w):
            for m in sorted({b + 1, b + 2, 2 * b, b * b // 2}):
                if m < b + 1:
                    continue
                row = attack(w, n, m, start + seconds)
                rows.append(row)
                if not row.get('passed', False):
                    return {'scope': 'bounded falsification only', 'cases': rows,
                            'seconds': process_time() - start}
    return {'scope': 'bounded falsification only', 'cases': rows,
            'seconds': process_time() - start}


if __name__ == '__main__':
    print(json.dumps(check(), indent=2))

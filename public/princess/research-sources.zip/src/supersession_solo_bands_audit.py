"""Independent physical-coordinate attack of the solo band evaluator.

Finite verification supplements the separately reviewed universal proof.
The reference profiles are neighborhood unions, not root expressions.
"""
import json
from pathlib import Path
from time import monotonic
from supersession_solo_bands import OddRectangle


def physical_profiles(w, n):
    cells = {(x, y) for x in range(n) for y in range(w)}
    order = [sorted((v for v in cells if sum(v) % 2 == p),
                    key=lambda v: (sum(v), v[0])) for p in (0, 1)]
    profiles = []
    for p in (0, 1):
        image = set()
        row = [0]
        for x, y in order[p]:
            image.update(v for v in ((x-1,y), (x+1,y), (x,y-1), (x,y+1))
                         if v in cells)
            assert image == set(order[1-p][:len(image)])
            row.append(len(image))
        profiles.append(row)
    return profiles


def main():
    started = monotonic()
    board_count = cases = starts = counts = profile_entries = 0
    max_bands = 0
    for b in range(1, 9):
        w = 2*b+1
        for n in (w, w+2, w+8):
            G = OddRectangle(w, n)
            physical = physical_profiles(w, n)
            board_count += 1
            for p in (0, 1):
                for k, v in enumerate(physical[p]):
                    assert G.profile(p, k) == v
                    profile_entries += 1
            for m in range(b+1, G.E+2):
                cases += 1
                for p in (0, 1):
                    _, bands = G.pair_bands(p, m)
                    assert len(bands) <= 4*b+2
                    max_bands = max(max_bands, len(bands))
                    selected = range(G.C[p]+1) if b <= 3 else {0, 1, m//2, min(m,G.C[p]), G.C[p]}
                    for initial in selected:
                        if initial > G.C[p]:
                            continue
                        trajectory = [initial]
                        k, phase = initial, p
                        while k:
                            k = physical[phase][max(0,k-m)]
                            trajectory.append(k)
                            phase ^= 1
                            assert len(trajectory) <= 4*w*n+1
                        got = G.solo(p, m, start=initial)
                        assert got['time'] == len(trajectory)-1, (w,n,m,p,initial)
                        starts += 1
                        checkpoints = range(len(trajectory)+2) if b <= 2 else {0,1,len(trajectory)//2,len(trajectory)-1,len(trajectory)+1}
                        for day in checkpoints:
                            reference = trajectory[day] if day < len(trajectory) else 0
                            assert G.solo(p,m,start=initial,at_day=day) == reference
                            counts += 1
    huge = OddRectangle(41,10**18+1).half_time(24)
    assert huge['tau'] == 5857142857142857020
    receipt = dict(status='passed', physical_boards=board_count,
                   physical_profile_entries=profile_entries,
                   rectangle_budget_cases=cases, solo_start_cases=starts,
                   prescribed_day_counts=counts, max_positive_bands=max_bands,
                   huge_integer_example=huge, seconds=monotonic()-started,
                   scope='Finite coordinate-neighborhood checks of formula implementation, all sampled solo starts and selected prescribed days. Universal correctness is the separate ordinary proof and its independent review; no full-game midpoint necessity is asserted.')
    target = Path(__file__).resolve().parents[1] / 'research/supersession-solo-bands-audit.json'
    target.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()

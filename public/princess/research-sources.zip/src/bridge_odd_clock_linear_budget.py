"""Fixed arithmetic audit for the uniform odd-board linear-budget theorem.

No joint-state solver. The proof is bridge-odd-clock-linear-budget.md.
"""
from math import isqrt
from pathlib import Path
from time import process_time
import hashlib
import json


def root(z):
    return isqrt(z)+int(isqrt(z)**2<z)


def constants(b,m):
    assert b>=2 and b+1<=m<=2*b
    q=8
    r=(8*(b+1)+m-1+15)//16
    G=m-1
    K=7*m+r*(r-1)
    assert 1<=r<=b and q*(2*r-b-1)>=G and K>=m
    J=max(2*K+m+1,K+b*b+1)
    W=2*root(G)
    onset=J+G+m*(W+1)
    return dict(b=b,width=2*b+1,budget=m,q=q,r=r,K=K,J=J,W=W,
                onset=onset,smallest_board_M=2*b*(b+1),
                margin=2*b*(b+1)-onset)


def main():
    started=process_time()
    finite=[constants(b,2*b) for b in range(140,160)]
    large=[constants(b,2*b) for b in (160,256,1000,10**6,10**12)]
    assert all(row['margin']>=0 for row in finite+large)
    assert [row['margin'] for row in finite] == [
        184,205,226,427,450,473,96,117,324,347,
        370,583,608,633,852,879,1102,1131,1160,1389]
    for row in large:
        b=row['b']
        assert 2*row['K']<=b*b
        assert 4*(row['W']+2)<=b
        assert row['onset']<=2*b*b
    result=dict(status='PASS',scope=__doc__,
                source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                finite_rows=finite,large_rows=large,seconds=process_time()-started)
    Path('research/bridge-odd-clock-linear-budget-check.json').write_text(
        json.dumps(result,indent=2)+'\n')
    print(dict(status='PASS',finite_cases=len(finite),large_cases=len(large),
               smallest_margin=min(r['margin'] for r in finite),seconds=result['seconds']))


if __name__=='__main__':
    main()

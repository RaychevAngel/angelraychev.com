#!/usr/bin/env python3
"""Bounded independent checks of N-subcommuting square-factor compressions."""
from itertools import combinations
from pathlib import Path
from time import monotonic
import json
from parity_trap_solver import setup


def one_operator(colors, axis_i, axis_j, sign):
    maps=[]
    for points in colors:
        groups={}
        for i,point in enumerate(points):
            key=tuple(x for k,x in enumerate(point) if k not in (axis_i,axis_j))+(point[axis_i]+sign*point[axis_j],)
            groups.setdefault(key,[]).append(i)
        fibers=[]
        for indices in groups.values():
            indices.sort(key=lambda i:points[i][axis_j])
            prefixes=[0]
            for i in indices:prefixes.append(prefixes[-1]|(1<<i))
            fibers.append((prefixes[-1],prefixes))
        maps.append([sum(prefixes[(mask&fiber).bit_count()] for fiber,prefixes in fibers)
                     for mask in range(1<<len(points))])
    return maps


def reflection_operator(shape, colors, axis):
    """Polarize toward the lower half of an odd coordinate's middle layer."""
    if shape[axis]%2!=1:raise ValueError('odd coordinate length required')
    maps=[]
    for points in colors:
        index={v:i for i,v in enumerate(points)}
        pairs=[]
        for i,v in enumerate(points):
            if v[axis]>shape[axis]//2:
                w=list(v);w[axis]=shape[axis]-1-w[axis]
                pairs.append((1<<index[tuple(w)],1<<i))
        mapping=[]
        for mask in range(1<<len(points)):
            output=mask
            for lower,upper in pairs:
                if mask&upper and not mask&lower:output=(output^upper)|lower
            mapping.append(output)
        maps.append(mapping)
    return maps


def odd_path_operator(shape, colors, axis):
    """Compress spacing-two fibers toward coordinate zero on an odd path."""
    if shape[axis]%2!=1:raise ValueError('odd coordinate length required')
    maps=[]
    for points in colors:
        groups={}
        for i,v in enumerate(points):
            key=tuple(x for j,x in enumerate(v) if j!=axis)+(v[axis]%2,)
            groups.setdefault(key,[]).append(i)
        fibers=[]
        for indices in groups.values():
            indices.sort(key=lambda i:points[i][axis])
            prefixes=[0]
            for i in indices:prefixes.append(prefixes[-1]|(1<<i))
            fibers.append((prefixes[-1],prefixes))
        maps.append([sum(prefixes[(mask&fiber).bit_count()] for fiber,prefixes in fibers)
                     for mask in range(1<<len(points))])
    return maps


def all_operators(shape, colors, include_reflections=False, include_odd_paths=False):
    """Bounded explicit maps; larger solvers should enumerate the fixed poset."""
    output=[]
    for i,j in combinations(range(len(shape)),2):
        if shape[i]==shape[j]:
            for sign in(1,-1):output.append(({'axes':[i,j],'diagonal_sign':sign},one_operator(colors,i,j,sign)))
    if include_reflections:
        for axis,n in enumerate(shape):
            if n%2:output.append(({'reflection_axis':axis},reflection_operator(shape,colors,axis)))
    if include_odd_paths:
        for axis,n in enumerate(shape):
            if n%2:output.append(({'odd_path_axis':axis},odd_path_operator(shape,colors,axis)))
    return output


def check_operator(maps,ns):
    inclusions=0;cover_relations=0
    for p in (0,1):
        for a,ca in enumerate(maps[p]):
            assert ca.bit_count()==a.bit_count()
            assert not ns[p][ca]&~maps[1-p][ns[p][a]]
            inclusions+=1
            remaining=a
            while remaining:
                bit=remaining&-remaining
                assert not maps[p][a^bit]&~ca
                cover_relations+=1
                remaining^=bit
    return {'neighborhood_inclusions':inclusions,'monotonicity_covers':cover_relations}


def run(shape,include_reflections=False,include_odd_paths=False):
    start=monotonic();colors,ns=setup(shape)
    if max(map(len,colors))>15:raise ValueError('bounded verification at most15bits per parity')
    operators=[];records=[]
    for metadata,op in all_operators(shape,colors,include_reflections,include_odd_paths):
        record=check_operator(op,ns)
        record.update(metadata)
        operators.append(op);records.append(record)
    limit=[list(range(len(row)))for row in ns];max_cycles=0
    for p in (0,1):
        for a in range(len(ns[p])):
            cur=a;cycles=0
            while True:
                nxt=cur
                for op in operators:nxt=op[p][nxt]
                cycles+=1
                if nxt==cur:break
                cur=nxt
            limit[p][a]=cur;max_cycles=max(max_cycles,cycles)
    final=check_operator(limit,ns)
    counts=[]
    for p in(0,1):
        count=0
        for a,ca in enumerate(limit[p]):
            assert limit[p][ca]==ca
            if ca==a:
                count+=1
                assert limit[1-p][ns[p][a]]==ns[p][a]
                for op in operators:assert op[p][a]==a
        counts.append(count)
    return {'shape':shape,'includes_odd_reflections':include_reflections,'includes_odd_paths':include_odd_paths,'parity_sizes':list(map(len,colors)),'operators':records,
            'composed_checks':final,'max_cycles_to_stabilize':max_cycles,
            'common_fixed_counts_by_parity':counts,'combined_fixed_state_count':counts[0]*counts[1],
            'all_belief_state_count':2**sum(map(len,colors)), 'seconds':round(monotonic()-start,4)}


if __name__=='__main__':
    start=monotonic()
    data={'scope':'Operator identities for every parity subset; not a numerical full-board time search.',
          'results':[run(shape)for shape in ((3,3),(4,4),(5,5),(3,3,3))],
          'total_seconds':round(monotonic()-start,4)}
    dest=Path(__file__).resolve().parents[1]/'research'/'square-strategy-compression-checks.json'
    dest.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(data,indent=2))

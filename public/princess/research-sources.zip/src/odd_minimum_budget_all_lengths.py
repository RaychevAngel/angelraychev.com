#!/usr/bin/env python3
"""Exact finite certificates for a proved affine potential-insertion lemma.

Uses rational arithmetic only. No numerical solver is required. All one-day
inequalities, finite smaller lengths, collar identities, and serial witnesses
are checked; research/odd-minimum-budget-all-lengths.md gives the implication
from these finite facts to every larger odd longitudinal length.
"""
from fractions import Fraction as F
from pathlib import Path
from time import monotonic
import json
from odd_serial_first_order_attack import profiles,serial
from odd_minimum_budget_pumping import ranks

CHARGES={
 3: [[0,0,1],[0,0,1]],
 5: [[0,0,1,1],[0,0,1,1]],
 7: [[0,0,0,1,1],[0,0,1,1,1]],
 9: [[0,0,'1/3','2/3',1,1]]*2,
 11:[[0,0,'1/6','1/2','5/6',1,1]]*2,
 13:[[0,0,'1/4','1/2','3/4','3/4',1,1],
     [0,0,'1/4','1/4','1/2','3/4',1,1]],
 15:[[0,0,'1/7','2/7','1/2','5/7','6/7',1,1]]*2,
}
CONSTANTS={3:8,5:20,7:44,9:84,11:136,13:208,15:288}


def verify_potential(g,m,c,f):
    assert all(c[0][r]+c[1][m-r]<=1 for r in range(m+1))
    assert all(v>=0 for row in c for v in row)
    for p in(0,1):
        assert f[p][0]==0 and all(v>=0 for v in f[p])
        for k in range(len(g[p])):
            for r in range(m+1):
                assert f[p][k]-f[1-p][g[p][max(0,k-r)]]<=c[p][r],(p,k,r)


def serial_witness(g,m,first,cut):
    a,b=len(g[first])-1,len(g[1-first])-1;p=first;days=0
    hit=[False,False];seen=set()
    while a or b:
        assert (a,b,p)not in seen
        seen.add((a,b,p))
        active=0 if a else 1
        if (a if active==0 else b)==cut:hit[active]=True
        qa=min(a,m);qb=min(b,m-qa)
        a,b=g[p][a-qa],g[1-p][b-qb]
        p=1-p;days+=1
    return days,hit


def one_width(w):
    b=(w-1)//2;m=b+1;D=m+1;corner=b*(b+1)
    charges=[[F(x)for x in row]for row in CHARGES[w]]
    n=w
    while ((w*n+1)//2)//2<corner+2*D+2:n+=2
    checked=[]
    for length in range(w,n+1,2):
        g=profiles((length-1)//2,b);f=ranks(g,charges)
        verify_potential(g,m,charges,f)
        lower=f[0][-1]+f[1][-1]
        rounded=(lower.numerator+lower.denominator-1)//lower.denominator
        upper=min(serial(g,m,p)for p in(0,1))
        assert rounded==upper==2*w*length-CONSTANTS[w]
        checked.append({'length':length,'lower':str(lower),'upper':upper})
    H=len(g[0])-1;cut=H//2
    assert cut>=corner+2*D and H-cut>=corner+2*D+2
    alpha=[f[p][cut]-2*cut for p in(0,1)]
    for p in(0,1):
        assert all(f[p][k]==2*k+alpha[p]for k in range(cut-2*D,cut+2*D+1))
    first=min((0,1),key=lambda p:serial(g,m,p))
    days,hits=serial_witness(g,m,first,cut)
    assert days==checked[-1]['upper'] and all(hits)
    # A redundant fresh attack on the explicit insertion formula, at three
    # integer offsets including offsets not themselves physical rectangles.
    insertion_checks=0
    for delta in(1,w,2*w+1):
        HH=H+delta
        from math import isqrt
        rt=lambda k:isqrt(k)+(isqrt(k)**2<k)
        def qt(k):
            q=isqrt(k)+1
            while q*(q-1)<k:q+=1
            return q
        gg=[[0]+[k+min(rt(k),b,rt(HH-k)-1)for k in range(1,HH+1)],
            [0]+[k+min(qt(k),b+1,qt(HH-1-k))for k in range(1,HH)]]
        ff=[]
        for p in(0,1):
            row=[]
            for k in range(len(gg[p])):
                row.append(f[p][k] if k<=cut else
                           f[p][cut]+2*(k-cut) if k<=cut+delta else
                           f[p][k-delta]+2*delta)
            ff.append(row)
        verify_potential(gg,m,charges,ff)
        insertion_checks+=1
    return {'width':w,'minimum_budget':m,'constant':CONSTANTS[w],
            'base_length':n,'base_majority_size':H,'cut':cut,
            'displacement_bound':D,'collar_alpha':[str(x)for x in alpha],
            'charges':[[str(x)for x in row]for row in charges],
            'finite_lengths':checked,'serial_first_parity':first,
            'both_serial_cohorts_hit_cut':all(hits),
            'exact_insertion_attacks':insertion_checks,
            'base_potentials':[[str(x)for x in row]for row in f]}


if __name__=='__main__':
    start=monotonic();results=[one_width(w)for w in CHARGES]
    out={'scope':'Finite premises for affine-insertion theorem; combined with the written proof, certifies every odd n>=w for widths3,5,7,9,11,13,15.',
         'seconds':monotonic()-start,'results':results}
    Path(__file__).resolve().parents[1].joinpath('research/odd-minimum-budget-all-lengths.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({**out,'results':[{k:v for k,v in row.items()if k!='base_potentials'}for row in results]},indent=2))

#!/usr/bin/env python3
"""Exact finite belief-state search for the moving-princess game on a path.

This new computational check is independent of the author's 2019--2020 work.
Vertices in JSON witnesses are numbered 1 through n. The solver performs a
breadth-first search from the initial belief (all vertices), so its answer is
the minimum number of turns among all strategies for the stated model.
"""

from __future__ import annotations

import argparse
from collections import deque
from itertools import combinations
import json
from pathlib import Path
import time


def vertices(mask: int) -> list[int]:
    return [i + 1 for i in range(mask.bit_length()) if mask & (1 << i)]


def neighborhood(mask: int, full: int) -> int:
    return ((mask << 1) | (mask >> 1)) & full


def solve(n: int, m: int) -> dict:
    assert n >= 1 and m >= 1
    full = (1 << n) - 1
    parent = {full: None}
    queue = deque([full])
    edges = 0
    while queue:
        belief = queue.popleft()
        if belief.bit_count() <= m:
            moves = [belief]
            cur = belief
            while parent[cur] is not None:
                prior, inspected = parent[cur]
                moves.append(inspected)
                cur = prior
            moves.reverse()
            return {
                "n": n,
                "m": m,
                "minimum_turns": len(moves),
                "inspections": [vertices(move) for move in moves],
                "states_discovered": len(parent),
                "edges_examined": edges,
            }
        bits = [1 << i for i in range(n) if belief & (1 << i)]
        # Inspecting additional possible vertices cannot hurt. Thus exact m
        # inspections suffice whenever more than m possibilities remain.
        for parts in combinations(bits, m):
            inspected = sum(parts)
            after = neighborhood(belief & ~inspected, full)
            edges += 1
            if after not in parent:
                parent[after] = (belief, inspected)
                queue.append(after)
    raise AssertionError("No winning strategy; a path with m >= 1 is searchable")


def check_witness(result: dict) -> list[list[int]]:
    n, m = result["n"], result["m"]
    possible = set(range(1, n + 1))
    beliefs = [sorted(possible)]
    # Separate set-based transition implementation deliberately avoids using
    # the bit-shift neighborhood from the search.
    for turn, inspected in enumerate(result["inspections"], start=1):
        assert len(inspected) <= m and len(set(inspected)) == len(inspected)
        assert all(1 <= v <= n for v in inspected)
        survivors = possible - set(inspected)
        if not survivors:
            assert turn == result["minimum_turns"]
            beliefs.append([])
            return beliefs
        possible = {
            u for v in survivors for u in (v - 1, v + 1) if 1 <= u <= n
        }
        assert possible, "Survival cannot terminate merely by an absent move"
        beliefs.append(sorted(possible))
    raise AssertionError("Witness did not capture every trajectory")


def manuscript_formula(n: int, m: int, protect_m1: bool = True) -> int:
    if n <= m:
        return 1
    one = 2 if n == 2 else 2 * n - 4
    if m == 1 and protect_m1:
        return one
    divisor = 2 * m - 1
    answer = (one + divisor - 1) // divisor
    if (n - m - 1) % divisor == 0 and (n % 2 or m % 2):
        answer += 1
    return answer


def retrograde(n: int, m: int) -> int:
    """Second exact algorithm: all states, all global shots, finite horizons.

    This deliberately does not use the BFS queue, parent pointers, local-shot
    reduction, or the bit-shift implementation of the movement relation.
    It is intended only for n <= 9 as an independent implementation check.
    """
    states = [frozenset(vertices(mask)) for mask in range(1 << n)]
    index = {state: i for i, state in enumerate(states)}
    adjacent = {
        v: frozenset(u for u in (v - 1, v + 1) if 1 <= u <= n)
        for v in range(1, n + 1)
    }
    neighbors = [
        index[frozenset(u for v in state for u in adjacent[v])]
        for state in states
    ]
    shots = [frozenset(s) for s in combinations(range(1, n + 1), min(m, n))]
    transitions = [
        [neighbors[index[state - shot]] for shot in shots]
        for state in states
    ]
    winning = [not state for state in states]
    turns = 0
    while not winning[-1]:
        previous = winning
        winning = [
            len(state) <= m or any(previous[target] for target in targets)
            for state, targets in zip(states, transitions)
        ]
        turns += 1
        assert winning != previous, "The finite winning-state process stalled"
    return turns


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=12)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    started = time.monotonic()
    results = []
    for n in range(1, args.max_n + 1):
        for m in range(1, n + 1):
            begin = time.monotonic()
            result = solve(n, m)
            result["witness_beliefs"] = check_witness(result)
            result["formula_m1_separate"] = manuscript_formula(n, m)
            result["formula_literal"] = manuscript_formula(n, m, False)
            if n <= 9:
                result["independent_retrograde_turns"] = retrograde(n, m)
                assert result["independent_retrograde_turns"] == result["minimum_turns"]
            result["seconds"] = round(time.monotonic() - begin, 6)
            results.append(result)
        print(n, [r["minimum_turns"] for r in results if r["n"] == n], flush=True)
    data = {
        "model": "Initially any vertex of P_n; inspect <=m vertices simultaneously; on a miss the princess must move exactly one edge.",
        "method": "Breadth-first search of all reachable belief subsets, with exactly m inspected possible vertices unless immediate capture is available.",
        "author_original_work_dates": "October 2019--March 2020",
        "evidence_provenance": "New computational verification, September 2026; does not establish an unbounded theorem.",
        "max_n": args.max_n,
        "seconds": round(time.monotonic() - started, 6),
        "results": results,
        "substantive_disagreements": [r for r in results if r["minimum_turns"] != r["formula_m1_separate"]],
        "literal_formula_disagreements": [r for r in results if r["minimum_turns"] != r["formula_literal"]],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2) + "\n")
    print("seconds", data["seconds"], "substantive disagreements", len(data["substantive_disagreements"]))


if __name__ == "__main__":
    main()

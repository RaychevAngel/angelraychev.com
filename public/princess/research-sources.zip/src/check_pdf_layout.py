"""Render every page of both scoped PDFs; contact sheets need visual review."""
from pathlib import Path
import json
import pymupdf as fitz
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1];receipts={}
for scope,filename in [('main','princess-searches.pdf'),('extensions','princess-extensions.pdf')]:
 out=root/'output/pdf/qa'/scope;out.mkdir(parents=True,exist_ok=True);doc=fitz.open(root/'output/pdf'/filename);outside=[]
 for stale in out.glob('*.png'):stale.unlink()
 for i,page in enumerate(doc):
  pix=page.get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False);pix.save(out/f'page-{i+1:02d}.png')
  for block in page.get_text('dict')['blocks']:
   for line in block.get('lines',[]):
    for span in line['spans']:
     x0,y0,x1,y1=span['bbox']
     if x0<20 or x1>page.rect.width-20 or y0<20 or y1>page.rect.height-20:outside.append({'page':i+1,'text':span['text'],'bbox':span['bbox']})
 for start in range(0,len(doc),12):
  sheet=Image.new('RGB',(1120,1260),'#dddddd');draw=ImageDraw.Draw(sheet)
  for j in range(start,min(start+12,len(doc))):
   page=Image.open(out/f'page-{j+1:02d}.png');page.thumbnail((270,390));x,y=((j-start)%4)*280+5,((j-start)//4)*420+22;sheet.paste(page,(x,y));draw.text((x,y-17),f'Page {j+1}',fill='black')
  sheet.save(out/f'contact-{start+1}.png')
 receipts[scope]={'pdf':filename,'pages':len(doc),'outside_safe_margin':outside,'rendered_every_page':True,'visual_review_required':True,'render_directory':str(out)}
(root/'research/pdf-layout-verification.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipts,indent=2))

"""Exact finite spatial transfer with arbitrary survivor envelopes.

The theorem is in research/fixed-horizon-transfer-theorem.md. This reference
implementation keeps Pareto-minimal cost vectors, and reconstructs physical
shots. It is meant for small independent validation cases, not huge searches.
"""
from itertools import product
from pathlib import Path
from time import monotonic
import json


def adjacency(size, edges):
    result = [0] * size
    for u, v in edges:
        result[u] |= 1 << v
        result[v] |= 1 << u
    return result


def pareto(rows):
    keep = {}
    for cost in sorted(rows):
        if not any(all(a <= b for a, b in zip(old, cost)) for old in keep):
            keep[cost] = rows[cost]
    return keep


def solve(adj, n, horizon, upper=None, limit=20_000_000):
    a = len(adj)
    assert a > 0 and n >= 1 and horizon >= 1
    if horizon == 1:
        return {'minimum_budget': a*n, 'shots': [[(v,j) for j in range(n) for v in range(a)]],
                'states_seen': 1, 'transitions': 0}
    if upper is None:
        upper = min(a*n, a*((n+horizon-1)//horizon+1))
    masks = range(1 << a)
    hood = []
    for mask in masks:
        nb = 0
        for v in range(a):
            if mask >> v & 1:
                nb |= adj[v]
        hood.append(nb)
    alphabet = list(product(masks, repeat=horizon-1))
    zero = 0
    weights = {}
    for x, left in enumerate(alphabet):
        for y, middle in enumerate(alphabet):
            for z, right in enumerate(alphabet):
                cost = [a-middle[0].bit_count()]
                consistent = True
                for t in range(horizon-1):
                    before = hood[middle[t]] | left[t] | right[t]
                    after = middle[t+1] if t+1 < horizon-1 else 0
                    if after & ~before:
                        consistent = False
                    cost.append((before & ~after).bit_count())
                # Exact physical survivor histories always satisfy this.
                # Restricting to them preserves completeness and substantially
                # reduces the reference computation's transition count.
                if consistent:
                    weights[x,y,z] = tuple(cost)
    current = {(zero,b): {(0,)*horizon: (b,)} for b in range(len(alphabet))}
    transitions = 0
    seen = len(current)
    for j in range(n):
        following = {}
        choices = [zero] if j == n-1 else range(len(alphabet))
        for (x,y), costs in current.items():
            for z in choices:
                weight = weights.get((x,y,z))
                if weight is None:
                    continue
                key = (y,z)
                target = following.setdefault(key,{})
                for cost, word in costs.items():
                    transitions += 1
                    if transitions > limit:
                        raise RuntimeError('Explicit transition limit exceeded')
                    value = tuple(b+c for b,c in zip(cost,weight))
                    if max(value) <= upper:
                        target.setdefault(value, word if j == n-1 else word+(z,))
        current = {key: pareto(costs) for key,costs in following.items() if costs}
        seen += sum(len(costs) for costs in current.values())
    if not current:
        return {'minimum_budget': None, 'states_seen': seen, 'transitions': transitions}
    cost, word = min(((cost,word) for costs in current.values() for cost,word in costs.items()),
                     key=lambda item: (max(item[0]),item[0]))
    envelopes = [{(v,j) for j,b in enumerate(word) for v in range(a)
                  if alphabet[b][t] >> v & 1} for t in range(horizon-1)] + [set()]
    vertices = {(v,j) for j in range(n) for v in range(a)}
    def move(s):
        result = set()
        for v,j in s:
            result.update((w,j) for w in range(a) if adj[v] >> w & 1)
            if j: result.add((v,j-1))
            if j+1<n: result.add((v,j+1))
        return result
    bound = vertices.copy()
    actual = vertices.copy()
    shots = []
    for t,envelope in enumerate(envelopes):
        shot = bound-envelope
        assert len(shot) == cost[t]
        assert actual <= bound
        actual = move(actual-shot)
        bound = move(envelope)
        shots.append(sorted(shot))
    assert not actual
    return {'minimum_budget': max(cost), 'cost_vector': cost, 'column_word': word,
            'shots': shots, 'physical_replay': True, 'states_seen': seen,
            'transitions': transitions}


def main():
    from path_strategy import claimed_time
    from ladder_counter_model import closed_formula
    root = Path(__file__).resolve().parents[1]
    start = monotonic()
    rows = []
    for a in (1,2):
        adj = adjacency(a, [(i,i+1) for i in range(a-1)])
        for horizon in (1,2,3,4):
            for n in range(2,9):
                formula = claimed_time if a == 1 else closed_formula
                expected = next(m for m in range(1,a*n+1)
                                if formula(n,m) is not None and formula(n,m)<=horizon)
                t = monotonic()
                result = solve(adj,n,horizon,upper=expected)
                assert result['minimum_budget'] == expected, (a,n,horizon,result,expected)
                rows.append({'cross_size':a,'length':n,'horizon':horizon,
                             'expected':expected,'seconds':monotonic()-t,**result})
                print(a,n,horizon,expected,'transitions',result['transitions'],flush=True)
                receipt = {'all_checks_passed':True, 'complete':False, 'seconds':monotonic()-start,
                           'scope':'Exact spatial transfer compared to independently proved path and ladder formulas; all recovered schedules physically replayed.',
                           'cases':rows}
                (root/'research/fixed-horizon-transfer-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
    receipt['complete'] = True
    (root/'research/fixed-horizon-transfer-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')


if __name__ == '__main__':
    main()

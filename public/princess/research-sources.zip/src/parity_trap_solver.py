#!/usr/bin/env python3
"""Exact one-cohort reachability and trap certificates on small bipartite grids.

Uses every subset of each color class, without a geometric normal-form
assumption. One-cohort feasibility equals full-board feasibility; its time
need not equal the optimal full-board time. This is a finite checker, not
an unbounded-grid theorem.
"""
from itertools import product
from pathlib import Path
from time import monotonic
import argparse
import json


def setup(shape):
    vertices = list(product(*(range(n) for n in shape)))
    colors = [[v for v in vertices if sum(v) % 2 == p] for p in range(2)]
    indices = [{v: i for i, v in enumerate(row)} for row in colors]
    tables = []
    for p in range(2):
        adj = []
        for v in colors[p]:
            mask = 0
            for axis, extent in enumerate(shape):
                for delta in (-1, 1):
                    w = list(v)
                    w[axis] += delta
                    if 0 <= w[axis] < extent:
                        mask |= 1 << indices[1-p][tuple(w)]
            adj.append(mask)
        table = [0] * (1 << len(adj))
        for b in range(1, len(table)):
            bit = b & -b
            table[b] = table[b ^ bit] | adj[bit.bit_length()-1]
        tables.append(table)
    return colors, tables


def deletion_distance(good, cap):
    """min(cap, min{|B-A|: A subset B and good[A]}) for every B."""
    d = bytearray(len(good))
    for b in range(1, len(good)):
        if good[b]:
            continue
        best = cap
        remaining = b
        while remaining:
            bit = remaining & -remaining
            candidate = d[b ^ bit] + 1
            if candidate < best:
                best = candidate
                if best == 1:
                    break
            remaining ^= bit
        d[b] = best
    return d


def replay(colors, neighborhoods, start_parity, start_mask, shots, budget):
    p, belief = start_parity, start_mask
    for shot in shots:
        assert shot['parity'] == p
        mask = shot['mask']
        assert mask.bit_count() <= budget
        assert not mask & ~belief
        belief = neighborhoods[p][belief & ~mask]
        p = 1-p
    assert belief == 0


def solve(shape, budget, include_witness=True):
    begin = monotonic()
    colors, neighborhoods = setup(shape)
    ranks = [[0] + [-1] * (len(row)-1) for row in neighborhoods]
    winning = [bytearray([1]) + bytearray(len(row)-1) for row in neighborhoods]
    history = [[1, 1]]
    horizon = 0
    while True:
        new = []
        for p in range(2):
            good = bytearray(winning[1-p][nb] for nb in neighborhoods[p])
            distance = deletion_distance(good, budget+1)
            new.append(bytearray(x <= budget for x in distance))
        horizon += 1
        for p in range(2):
            for b in range(1, len(new[p])):
                if new[p][b] and ranks[p][b] == -1:
                    ranks[p][b] = horizon
        history.append([sum(w) for w in new])
        if new == winning:
            break
        winning = new
    minimal_traps = []
    for p in range(2):
        generators = []
        for b in range(1, len(winning[p])):
            if winning[p][b]:
                continue
            remaining = b
            minimal = True
            while remaining:
                bit = remaining & -remaining
                if not winning[p][b ^ bit]:
                    minimal = False
                    break
                remaining ^= bit
            if minimal:
                generators.append(b)
        minimal_traps.append(generators)
    result = {
        'shape': shape, 'budget': budget,
        'model': 'one initial parity cohort, inspect before forced move',
        'one_cohort_optimal_times': [row[-1] for row in ranks],
        'full_board_feasible': all(row[-1] >= 0 for row in ranks),
        'subset_states': sum(map(len, ranks)),
        'fixed_point_horizon': horizon, 'winning_counts_by_horizon': history,
        'minimal_trap_generators': minimal_traps,
        'minimal_trap_cardinalities': [sorted(set(b.bit_count() for b in row)) for row in minimal_traps],
        'coordinates_by_parity': colors,
    }
    if include_witness and result['full_board_feasible']:
        schedules = []
        for initial_parity in range(2):
            p = initial_parity
            b = len(ranks[p])-1
            shots = []
            while b:
                t = ranks[p][b]
                good = bytearray(0 <= ranks[1-p][nb] < t for nb in neighborhoods[p])
                distance = deletion_distance(good, budget+1)
                a = b
                while not good[a]:
                    remaining = a
                    while remaining:
                        bit = remaining & -remaining
                        if distance[a ^ bit] + 1 == distance[a]:
                            a ^= bit
                            break
                        remaining ^= bit
                    else:
                        raise AssertionError('No deletion witness')
                shots.append({'parity': p, 'mask': b ^ a,
                              'rooms': [colors[p][i] for i in range(len(colors[p])) if (b ^ a) >> i & 1]})
                b = neighborhoods[p][a]
                p = 1-p
            replay(colors, neighborhoods, initial_parity, len(ranks[initial_parity])-1, shots, budget)
            assert len(shots) == ranks[initial_parity][-1]
            schedules.append(shots)
        result['one_cohort_schedules'] = schedules
    # Verify the trap independently through all useful maximum-budget shots
    # on minimal losing generators. Upward closure covers other beliefs;
    # adding shots only makes the successor smaller.
    from itertools import combinations
    transitions = 0
    for p in range(2):
        for b in minimal_traps[p]:
            bits = [1 << i for i in range(len(colors[p])) if b >> i & 1]
            assert len(bits) > budget
            for shot in combinations(bits, budget):
                successor = neighborhoods[p][b & ~sum(shot)]
                assert any(g & successor == g for g in minimal_traps[1-p])
                transitions += 1
    result['trap_generator_transitions_verified'] = transitions
    result['seconds'] = round(monotonic()-begin, 3)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--shape', default='3,3,3')
    parser.add_argument('--budgets', default='3,4,5')
    parser.add_argument('--output', default='research/parity-trap-experiments.json')
    args = parser.parse_args()
    shape = tuple(map(int, args.shape.split(',')))
    results = []
    for budget in map(int, args.budgets.split(',')):
        result = solve(shape, budget)
        results.append(result)
        print({k: result[k] for k in ['shape', 'budget', 'one_cohort_optimal_times',
              'minimal_trap_cardinalities', 'trap_generator_transitions_verified', 'seconds']}, flush=True)
    target = Path(__file__).resolve().parents[1] / args.output
    target.write_text(json.dumps({'method': __doc__, 'results': results}, indent=2)+'\n')


if __name__ == '__main__':
    main()

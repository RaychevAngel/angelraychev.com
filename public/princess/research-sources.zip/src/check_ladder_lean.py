#!/usr/bin/env python3
"""Single-thread kernel check and narrow, reproducible proof-boundary receipt."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", type=Path, default=Path(
        "/Users/angel/code/math/polyominoes/.tools/lean-4.33.1-darwin_aarch64/bin/lean"))
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    sources = [root / "lean" / name for name in (
        "BeliefSemantics.lean", "LadderCounters.lean", "LadderGeometry.lean",
        "LadderCardinality.lean", "LadderGame.lean")]
    for source in sources:
        contents = source.read_text()
        prohibited = re.findall(r"\b(?:sorry|admit|native_decide|unsafe)\b|^\s*(?:axiom|opaque)\b", contents, re.M)
        if prohibited:
            raise RuntimeError(f"Forbidden proof shortcut/declaration detected: {prohibited}")
    version = subprocess.run([str(args.lean), "--version"], check=True,
                             capture_output=True, text=True, timeout=10).stdout.strip()
    start = time.monotonic()
    output, commands = "", []
    environment = dict(os.environ, LEAN_PATH=str(root / "lean"))
    for source in sources:
        command = [str(args.lean), "-j1", "-o", str(source.with_suffix(".olean")), str(source)]
        commands.append(command)
        checked = subprocess.run(command, cwd=root, env=environment, capture_output=True, text=True, timeout=30)
        output += checked.stdout + checked.stderr
        if checked.returncode:
            raise RuntimeError(output)
    elapsed = time.monotonic() - start
    axioms = {name: [a.strip() for a in assumptions.split(",") if a.strip()]
              for name, assumptions in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]", output)}
    axioms.update({name: [] for name in re.findall(r"'([^']+)' does not depend on any axioms", output)})
    required = {"Princess.Ladder.counter_classification", "Princess.Ladder.one_probe_no_clears",
                "Princess.Ladder.optimalTurns_ceiling",
                "Princess.Ladder.capture_strict_when_nondivisible", "Princess.Ladder.two_probe_optimal",
                "Princess.LadderGeometry.rowAdj_iff_colorAdj", "Princess.LadderGeometry.cohort_projection",
                "Princess.LadderGame.actual_ladder_classification",
                "Princess.LadderGame.actual_single_edge_classification",
                "Princess.LadderGame.actual_one_probe_impossible",
                "Princess.LadderGame.empty_iff_guaranteed_capture"}
    if not required <= axioms.keys():
        raise RuntimeError("Missing expected theorem axiom audit")
    approved = {"propext", "Classical.choice", "Quot.sound"}
    if any(set(values) - approved for values in axioms.values()):
        raise RuntimeError(f"Nonstandard theorem assumptions: {axioms}")
    receipt = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "version": version, "commands": commands, "seconds": round(elapsed, 6),
        "sources": [{"path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest()}
                    for source in sources],
        "exit_code": checked.returncode, "single_thread": True, "axioms": axioms,
        "verified_claim": "Exact ordinary physical ladder-room classification for every positive n and m: for n>=2, no finite guaranteed-capture strategy with one probe and an attaining probe sequence with all-sequences optimality for every m>=2; the n=1 single-edge case is also classified. Includes actual row-edge geometry, finite cardinalities, probe budgets, suffix construction, counter arithmetic including the ceiling-form equivalence, and the connection to arbitrary legal avoiding trajectories.",
        "room_graph_classification_formalized": True,
        "remaining_bridge": None,
        "explicit_limits": ["These theorems concern ladders only and do not classify wider grids or establish literature novelty."],
        "output": output,
    }
    destination = root / "research/ladder-lean-verification.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"result": "kernel check passed", "seconds": receipt["seconds"],
                      "receipt": str(destination), "room_graph_classification_formalized": True}, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Bounded physical checks of the narrow quadrant family; no normal-form claim."""
from itertools import product
from pathlib import Path
import json
import time
from maturation_even_hybrid_words import neighbor_counts
from maturation_even_relative_family import neighborhood_size, is_hybrid


def normalize(h, a):
    a = list(a)
    while a and not a[0]:
        h += 2
        a.pop(0)
    while a and not a[-1]:
        a.pop()
    return h, tuple(a)


def narrow(h, a):
    h, a = normalize(h, a)
    if not a:
        return True
    if any(x <= 0 or x > h+2*i+1 for i, x in enumerate(a)):
        return False
    proper = [x-i for i, x in enumerate(a[:-1]) if x < h+2*i+1]
    c = proper[0] if proper else max(1, h+len(a)-1, a[-1]-len(a)+1)
    return c >= 1 and all(x == min(h+2*i+1, c+i) for i, x in enumerate(a[:-1])) and a[-1] <= min(h+2*len(a)-1, c+len(a)-1)


def cells(h, a):
    return frozenset((x, h+2*i-x) for i, k in enumerate(a) for x in range(k))


def neighborhood(s):
    return frozenset((x+dx, y+dy) for x, y in s
                     for dx, dy in ((1,0),(-1,0),(0,1),(0,-1))
                     if x+dx >= 0 and y+dy >= 0)


def counts(s):
    if not s:
        return 0, ()
    h = min(x+y for x, y in s)
    end = max(x+y for x, y in s)
    a = tuple(sum(x+y == d for x, y in s) for d in range(h, end+1, 2))
    assert cells(h, a) == s
    return h, a


def erosion(s):
    if not s:
        return frozenset()
    return frozenset(v for v in neighborhood(s) if neighborhood({v}) <= s)


def erosion_counts(h, a):
    if not a:
        return 0, ()
    b = {h+2*i: k for i, k in enumerate(a)}
    out = []
    first = 1-(h % 2)
    for d in range(first, h+2*len(a), 2):
        upper = max(0, b.get(d+1, 0)-1)
        lower = b.get(d-1, 0)
        out.append(upper if d == 0 else min(upper, lower+int(lower == d)))
    return normalize(first, out)


def main():
    started = time.process_time()
    family = set()
    for h in range(5):
        for length in range(1, 6):
            for c in range(1, h+length+3):
                core = tuple(min(h+2*i+1, c+i) for i in range(length-1))
                for v in range(1, min(h+2*length-1, c+length-1)+1):
                    family.add((h, core+(v,)))
    supports = [(h, a, cells(h, a)) for h, a in sorted(family)]
    for h, a, s in supports:
        assert narrow(h, a)
        assert cells(*neighbor_counts(h, a)) == neighborhood(s)
        assert narrow(*neighbor_counts(h, a)), ("N", h, a)
        assert cells(*erosion_counts(h, a)) == erosion(s)
        assert narrow(*erosion_counts(h, a)), ("E", h, a, erosion_counts(h, a))
    intersection_checks = 0
    # Independent physical intersections, bounded deterministic selection.
    for i, (h, a, s) in enumerate(supports[::7]):
        for j, (q, b, t) in enumerate(supports[::11]):
            if h % 2 == q % 2:
                intersection_checks += 1
                assert narrow(*counts(s & t)), (h,a,q,b)

    parents = [(0,(1,2,3,4)), (0,(1,3,4,5,2)),
               (0,(1,3,5,6,3)), (1,(2,3,4,5,2)),
               (2,(2,3,4,5)), (2,(3,5,6,7,3)),
               (4,(3,4,5,6,2)), (2,(3,5,7,8,9,3))]
    relative_checks = 0
    differences = []
    for h, a in parents:
        assert narrow(h, a)
        raw = [None]*(sum(a)+1)
        restricted = [None]*len(raw)
        for r in product(*(range(x+1) for x in a)):
            relative_checks += 1
            k, n = sum(r), neighborhood_size(h, r)
            if raw[k] is None or n < raw[k][0]:
                raw[k] = (n,r)
            if narrow(h,r) and (restricted[k] is None or n < restricted[k][0]):
                restricted[k] = (n,r)
        for k in range(len(raw)):
            if restricted[k] is None or raw[k][0] != restricted[k][0]:
                differences.append({"h":h,"parent":a,"k":k,"raw":raw[k],"narrow":restricted[k]})

    # The broad family's first genuine quota-word counterexample.
    h, a = 2, (3,5,1,2,3,4,5,6)
    broad = [None, None]
    candidates = 0
    for r in product(*(range(x+1) for x in a)):
        if sum(r) < 24:
            continue
        candidates += 1
        n = len(neighborhood(cells(h,r)))
        if broad[0] is None or n < broad[0][0]:
            broad[0] = (n,r)
        if is_hybrid(h,r) and (broad[1] is None or n < broad[1][0]):
            broad[1] = (n,r)
    assert broad[0][0] == 33 and broad[1][0] == 34
    out = {"scope":"Bounded actual closure and exact relative profiles; no unbounded optimality claim",
           "narrow_supports":len(supports),"intersection_checks":intersection_checks,
           "relative_parents":len(parents),"relative_count_vectors":relative_checks,
           "relative_mismatches":differences,
           "broad_word_counterexample":{"h":h,"parent":a,"first_quota":5,"last_quota":33,
                 "candidate_survivors":candidates,"raw":broad[0],"hybrid":broad[1]},
           "cpu_seconds":round(time.process_time()-started,6)}
    path = Path(__file__).resolve().parents[1]/"research/maturation-narrow-family-check.json"
    path.write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out))


if __name__ == "__main__":
    main()

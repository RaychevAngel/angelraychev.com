"""Restricted physical prefix-family search; no optimality claim is assumed."""
from collections import deque
from functools import lru_cache
from itertools import permutations, product
import argparse,json
from pathlib import Path
from time import process_time


def run(shape, budget, permute=True, joint=False):
    start=process_time();vertices=list(product(*(range(n) for n in shape)))
    colors=[[v for v in vertices if sum(v)%2==p] for p in (0,1)]
    index=[{v:i for i,v in enumerate(row)} for row in colors]
    adjacency=[]
    for p,row in enumerate(colors):
        aa=[]
        for v in row:
            hood=0
            for j,n in enumerate(shape):
                for sign in (-1,1):
                    u=list(v);u[j]+=sign
                    if 0<=u[j]<n:hood|=1<<index[1-p][tuple(u)]
            aa.append(hood)
        adjacency.append(aa)
    @lru_cache(None)
    def neighborhood(p,mask):
        hood=0
        while mask:
            bit=mask&-mask;mask-=bit;hood|=adjacency[p][bit.bit_length()-1]
        return hood
    prefixes=[{0},{0}]
    for reflection in product((0,1),repeat=len(shape)):
        for perm in (permutations(range(len(shape))) if permute else [tuple(range(len(shape)))]):
            for p,row in enumerate(colors):
                mapped=[tuple(shape[j]-1-v[j] if reflection[j] else v[j]
                              for j in range(len(shape))) for v in row]
                order=sorted(range(len(row)),key=lambda i:
                             (sum(mapped[i]),tuple(-mapped[i][j] for j in perm)))
                mask=0
                for i in order:mask|=1<<i;prefixes[p].add(mask)
    closure=all(neighborhood(p,a) in prefixes[1-p]
                for p in (0,1) for a in prefixes[p])
    candidates=[sorted(row,key=int.bit_count,reverse=True) for row in prefixes]
    sols=[]
    for initial_p in (0,1):
        initial=(initial_p,(1<<len(colors[initial_p]))-1)
        queue=deque([(initial,0)]);seen={initial};parent={}
        terminal=None
        while queue:
            (p,a),depth=queue.popleft()
            if a.bit_count()<=budget:terminal=(p,a);break
            minimum=a.bit_count()-budget
            for r in candidates[p]:
                if r.bit_count()<minimum:break
                if r&~a:continue
                following=(1-p,neighborhood(p,r))
                if following not in seen:
                    seen.add(following);queue.append((following,depth+1))
                    parent[following]=((p,a),r)
        if terminal is None:sols.append({'start_parity':initial_p,'days':None});continue
        actions=[(terminal,0)];current=terminal
        while current!=initial:
            before,r=parent[current];actions.append((before,r));current=before
        actions.reverse();shots=[];actual=initial[1];p=initial_p
        for (q,a),r in actions:
            assert q==p and a==actual and r in prefixes[p] and not r&~a
            shot=a^r;assert shot.bit_count()<=budget
            shots.append([v for i,v in enumerate(colors[p]) if shot>>i&1])
            actual=neighborhood(p,r);p=1-p
        assert actual==0
        sols.append({'start_parity':initial_p,'days':len(actions),'states_seen':len(seen),
                     'physical_replay_passed':True,'shots':shots})
    result={'shape':shape,'budget':budget,'permutes_axes':permute,'prefix_counts':list(map(len,prefixes)),
            'neighborhood_closed':closure,'cohorts':sols,'CPU_seconds':process_time()-start,
            'scope':'Exact minimum only among survivors that are reflected/permuted weightlex prefixes. Physical upper bound; unrestricted optimum requires separate proof.'}
    if joint:
        @lru_cache(None)
        def choices(p,a):
            return [(r,neighborhood(p,r),a.bit_count()-r.bit_count())
                    for r in candidates[p] if not r&~a and a.bit_count()-r.bit_count()<=budget]
        initial=tuple((1<<len(row))-1 for row in colors)
        queue=deque([(initial,0)]);parents={initial:None};terminal=None;edges=0
        while queue:
            (a,b),depth=queue.popleft()
            if a.bit_count()+b.bit_count()<=budget:terminal=(a,b);break
            for r,nr,cost in choices(0,a):
                for s,ns,other in choices(1,b):
                    if cost+other>budget:continue
                    edges+=1;following=(ns,nr)
                    if following not in parents:
                        parents[following]=((a,b),r,s);queue.append((following,depth+1))
        if terminal is None:
            result['joint']={'days':None,'states_seen':len(parents),'transitions':edges}
        else:
            steps=[(terminal,0,0)];current=terminal
            while parents[current] is not None:
                before,r,s=parents[current];steps.append((before,r,s));current=before
            steps.reverse();actual=initial;shots=[]
            for before,r,s in steps:
                assert before==actual
                assert r in prefixes[0] and s in prefixes[1]
                masks=(before[0]^r,before[1]^s)
                assert not r&~before[0] and not s&~before[1]
                assert sum(x.bit_count()for x in masks)<=budget
                shots.append([v for p in(0,1)for i,v in enumerate(colors[p])if masks[p]>>i&1])
                actual=(neighborhood(1,s),neighborhood(0,r))
            assert actual==(0,0)
            result['joint']={'days':len(steps),'states_seen':len(parents),'transitions':edges,
                             'physical_replay_passed':True,'shots':shots}
        result['CPU_seconds']=process_time()-start
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('shape',nargs='+',type=int)
    p.add_argument('--budget',type=int,required=True);p.add_argument('--output',type=Path)
    p.add_argument('--standard-order-only',action='store_true')
    p.add_argument('--joint',action='store_true')
    args=p.parse_args();result=run(tuple(args.shape),args.budget,not args.standard_order_only,args.joint)
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({**result,'cohorts':[{k:v for k,v in r.items() if k!='shots'}for r in result['cohorts']]},indent=2))

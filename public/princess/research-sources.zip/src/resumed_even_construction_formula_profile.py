"""Attack candidate general necessary corner-profile inequalities.

The capacity formula is supplied by split_manuscripts and still under proof
review. This experiment is conditional on that formula, not a theorem claim.
"""
from collections import defaultdict,deque
from pathlib import Path
import argparse,json,time

from resumed_even_construction_prefix import ceilroot,rho
from resumed_even_construction_ammunition import labels


def F(i,j,s):
    if s<0 or s<i+2*j:return -10**12
    if j:return i+2*j-2+(s-i-2*j+2)*(s-i-2*j+1)
    if i:return i-1+(s-i+1)**2
    return max(s*(s-1)//2,s*(s-2))


def allowed(h,r,q,i,t,j):
    s=t-q
    if q==0:return t==0 and i==0 and j==0
    if s<min(ceilroot(q),r,rho(h-q)):return False
    if s>=r:return True
    return q<=F(i,j,s) or h-q-s<=max(F(2-j,d,s-2+i+d)for d in range(3-i))


def build(w,k,n=None):
    if n is None:n=w
    h=w*n//2;r=w//2
    states=[(s,c)for s in range(h+1)for c in range(3)if c<=s<=h-2+c]
    targets=defaultdict(list)
    for q,i in states:
        for t,j in states:
            if t>=q and allowed(h,r,q,i,t,j):targets[q,i].append((t,j))
    options={a:{}for a in states}
    for a,c in states:
        for q in range(max(0,a-k),a+1):
            cost=a-q
            for i in range(max(0,c-cost),c+1):
                for b in targets[q,i]:options[a,c][b]=min(cost,options[a,c].get(b,k+1))
    return states,options


def run(w,k):
    start=time.monotonic();h=w*w//2
    states,options=build(w,k)
    reverse={s:[]for s in states}
    for a,row in options.items():
        for b,cost in row.items():reverse[b].append((a,cost))
    Fvalue=labels(reverse,[(0,0)])
    assert all(Fvalue[a][0]<=cost+Fvalue[b][0]
               for a,row in options.items()for b,cost in row.items())
    # Keep every target. Discarding a larger same-corner target would require
    # an additional dynamic monotonicity proof, and is not used here.
    initial=((h,2),(h,2));queue=deque([(initial,0)]);seen={initial};edges=0
    layer_minima={};layer_extremizers=defaultdict(list)
    while queue:
        (a,b),depth=queue.popleft()
        cardinality=a[0]+b[0]
        if cardinality<layer_minima.get(depth,10**12):
            layer_minima[depth]=cardinality;layer_extremizers[depth]=[(a,b)]
        elif cardinality==layer_minima.get(depth):
            layer_extremizers[depth].append((a,b))
        if a[0]+b[0]<=k:break
        for aa,cost in options[a].items():
            for bb,other in options[b].items():
                if cost+other>k:continue
                nxt=tuple(sorted((aa,bb)));edges+=1
                if nxt not in seen:seen.add(nxt);queue.append((nxt,depth+1))
    else:raise AssertionError('no capture')
    return {'w':w,'k':k,'conditional_ammunition_lower':Fvalue[h,2][0],
            'conditional_joint_lower':depth+1,'states':len(states),
            'joint_states':len(seen),'joint_edges':edges,
            'ammunition_potential':[{'state':a,'value':Fvalue[a][0]}for a in states],
            'ammunition_inequalities_checked':sum(map(len,options.values())),
            'first_arrival_layers':[{'depth':t,'minimum_cardinality':size,
                                     'minimizers':layer_extremizers[t]}
                                    for t,size in sorted(layer_minima.items())],
            'seconds':time.monotonic()-start,
            'scope':'Diagnostic of proof-pending geometric formula; all allowed targets retained in exact abstract BFS.'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--w',type=int,default=8)
    p.add_argument('--k',type=int,default=5);a=p.parse_args();out=run(a.w,a.k)
    Path(f'research/resumed-even-construction-formula-profile-{a.w}x{a.w}-k{a.k}.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k not in('ammunition_potential','first_arrival_layers')})

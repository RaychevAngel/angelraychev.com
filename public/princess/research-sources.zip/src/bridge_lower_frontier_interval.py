"""Near-square interval localization in a bounded terminal diagnostic.

This is a stronger variant; the exact-triangle width-25 receipts retain
their original model. The source/cost/target inequalities force the new
event for every witness of each redirected edge.
"""
from pathlib import Path
import json
from functools import lru_cache
from bridge_lower_frontier_flagged import base_cache,flagged
from bridge_lower_frontier_diagnostic import square_successor_flag,persistent_path
from bridge_lower_frontier_nine import root,pronic,validate_edge

def intervals(states,rows,b,n,k):
    states=list(states);ids={s:i for i,s in enumerate(states)}
    extras={T:(len(states)+offset,r)for offset,(T,r)in enumerate((T,r)for r in range(2,b)for T in range(r*r+1,r*(r+1)))}
    rows=[list(row)+[0]*len(extras)for row in rows]
    for a,source in enumerate(states):
        for T,(extra,r)in extras.items():
            q=T-r;p=source[0]-q
            if 0<=p<=k:
                old=ids[T,0,1]
                if rows[p][a]>>old&1:rows[p][a]=(rows[p][a]&~(1<<old))|(1<<extra)
    # The existing generic radius updater infers r as least u with
    # T<=u(u+1), valid throughout this target interval as well.
    states.extend((T,0,1,7)for T in extras)
    allowed=sum(1<<d for d,s in enumerate(states)if s[1]<=1 and s[2]==0)
    for T,(extra,r)in extras.items():
        old=ids[T,0,1]
        for p in range(k+1):rows[p][extra]=rows[p][old]&allowed
    masks=[0]*len(states)
    for row in rows:
        for a,bits in enumerate(row):masks[a]|=bits
    return states,masks,rows

def pronic_intervals(states,rows,b,n,k):
    states=list(states);ids={s:i for i,s in enumerate(states)}
    extras={T:(len(states)+offset,r)for offset,(T,r)in enumerate((T,r)for r in range(2,b+1)for T in range((r-1)*(r-2)+r+1,r*r))}
    rows=[list(row)+[0]*len(extras)for row in rows]
    for a,source in enumerate(states):
        for T,(extra,r)in extras.items():
            q=T-r;p=source[0]-q
            if 0<=p<=k:
                old=ids[T,1,0]
                if rows[p][a]>>old&1:rows[p][a]=(rows[p][a]&~(1<<old))|(1<<extra)
    states.extend((T,1,0,4)for T in extras)
    allowed=sum(1<<d for d,s in enumerate(states)if s[1]==0)
    for T,(extra,r)in extras.items():
        old=ids[T,1,0]
        for p in range(k+1):rows[p][extra]=rows[p][old]&allowed
    masks=[0]*len(states)
    for row in rows:
        for a,bits in enumerate(row):masks[a]|=bits
    return states,masks,rows

def quadrant_lens_count(p,L,D):
    """Count nonnegative x,y of color p with x+y<=L and x-y<=D."""
    r=max(0,(L-p)//2+1);t=(D-p)//2
    def tri(x):return max(0,x)*(max(0,x)+1)//2
    outside=tri(r-1-t)-tri(-1-t)-tri(-p-1-t)+tri(-p-r-1-t)
    return r*(r+p)-outside

def lens_count_closed(w,n,r0,r1):
    D=r1-n+1
    return(quadrant_lens_count(0,r0,D)
           -quadrant_lens_count(w%2,r0-w,D-w)
           -quadrant_lens_count(n%2,r0-n,D+n)
           +quadrant_lens_count((w+n)%2,r0-w-n,D-w+n))

def lens_counter(w,n):
    @lru_cache(None)
    def count(r0,r1):
        return lens_count_closed(w,n,r0,r1)
    return count

def run(use_intervals=True,feature=(1,0),paired=False,lens=False):
    b=11;n=24;k=12;h=(2*b+1)*n//2;K=b*b+b+1
    data,cached=base_cache(b,n,k);assert cached
    states,masks,rows=flagged(data,b,n,k,'forbid-pair',return_weighted=True)
    states,masks,rows=square_successor_flag(states,rows,b,n,k)
    if use_intervals:states,masks,rows=intervals(states,rows,b,n,k)
    if paired:states,masks,rows=pronic_intervals(states,rows,b,n,k)
    seed=states.index((K,*feature));path,stats=persistent_path(states,masks,[seed],2*b+1,n,max_seconds=20,cardinality_cap=lens_counter(2*b+1,n)if lens else None)
    anchor=K;phase=0;witness=[]
    for day,(aa,dd)in enumerate(zip(path,path[1:]),1):
        a,d=aa[0],dd[0];source,target=states[a],states[d]
        anchor=max(0,anchor-k)
        if anchor:anchor+=min(root(anchor),b)if phase==0 else min(pronic(anchor),b+1)
        phase^=1
        costs=[p for p in range(k+1)if rows[p][a]>>d&1];choices=[]
        for p in costs:
            if target[0]==0:choices.append((p,None,None));continue
            for i in range(source[1]+1):
                for u in range(source[2]+1):
                    try:validate_edge(b,h,k,source[:3],target[:3],p,i,u,strong_band=True)
                    except AssertionError:continue
                    choices.append((p,i,u))
        assert choices,(source,target,costs)
        p,i,u=min(choices,key=lambda v:(-v[0],-(v[1]or 0),-(v[2]or 0)))
        row=dict(day=day,source=source,target=target,cost=p,survivor=(source[0]-p,i,u),surplus=target[0]-source[0]+p,source_radii=aa[1:],target_radii=dd[1:],anchored_size=anchor)
        witness.append(row)
    out=dict(scope=__doc__,shape=[2*b+1,n],budget=k,boundary=K,feature=feature,near_square_intervals=use_intervals,near_pronic_intervals=paired,corner_ball_lens=lens,days=len(witness),search=stats,witness=witness)
    suffix='interval'if use_intervals else'exact'
    if paired:suffix+='-paired'
    if lens:suffix+='-lens'
    if feature!=(1,0):suffix+=f'-c{feature[0]}e{feature[1]}'
    Path(f'research/bridge-lower-frontier-b11-{suffix}-witness.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k!='witness'}))
    faster=[r for r in witness if r['target'][0]<r['anchored_size']]
    if faster:
        for r in witness[max(0,faster[0]['day']-5):faster[0]['day']+5]:print(json.dumps(r))
    return out

if __name__=='__main__':
    run(False);run(True)

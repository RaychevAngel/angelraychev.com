"""Independent integer verification of the complete 4x4x4 and 3x4x4 results.

Canonical ideals are reconstructed by optional inclusion in a topological
vertex order, rather than the forward-addition enumerator used for discovery.
All neighborhoods are recomputed in the original room coordinates.
"""
from collections import deque
from itertools import combinations, product
from pathlib import Path
from time import monotonic
import json

ROOT = Path(__file__).resolve().parents[1]


def review(shape, stem, certificate_name, state_count, surplus):
    start = monotonic()
    coords = list(product(*(range(n) for n in shape)))
    volume = len(coords)
    half = volume//2
    indices = {v:i for i,v in enumerate(coords)}
    colors = [[v for v in coords if sum(v)%2 == p] for p in (0,1)]
    adj = []
    for v in coords:
        nb = 0
        for axis in range(3):
            for delta in (-1,1):
                w = list(v); w[axis] += delta
                if 0 <= w[axis] < shape[axis]:
                    nb |= 1 << indices[tuple(w)]
        adj.append(nb)
    def hood(s):
        out = 0
        while s:
            bit = s & -s; s ^= bit
            out |= adj[bit.bit_length()-1]
        return out
    ideals = []
    for p in (0,1):
        row = sorted(colors[p], key=lambda v:(sum((j+1)*v[j] for j in range(3)),v))
        family = [0]
        for v in row:
            required = 0
            for i,n in enumerate(shape):
                if n%2 and v[i]>=2:
                    w=list(v);w[i]-=2
                    required |= 1 << indices[tuple(w)]
            for i,j in combinations(range(3),2):
                if shape[i] != shape[j]:
                    continue
                for sign in (-1,1):
                    w = list(v); w[i] += sign; w[j] -= 1
                    if all(0 <= a < n for a,n in zip(w,shape)):
                        required |= 1 << indices[tuple(w)]
            bit = 1 << indices[v]
            family += [s|bit for s in family if s & required == required]
        ideals.append(sorted(family))
        assert len(family) == len(set(family)) == state_count
    profiles = []
    for p in (0,1):
        profile = [volume]*(half+1)
        for s in ideals[p]:
            nb = hood(s)
            assert nb in ideals[1-p]
            profile[s.bit_count()] = min(profile[s.bit_count()],nb.bit_count())
        profiles.append(profile)
    assert profiles[0] == profiles[1]
    assert max(v-k for k,v in enumerate(profiles[0])) == surplus

    certificate = json.loads((ROOT/'research'/certificate_name).read_text())
    potentials = {}
    for p in (0,1):
        masks = certificate['canonical_masks'][p]
        values = certificate.get('potentials_scaled_by_two',certificate.get('potentials'))[p]
        decoded = [sum(1<<indices[v] for i,v in enumerate(colors[p]) if s>>i&1) for s in masks]
        assert len(decoded) == len(set(decoded)) == len(ideals[p])
        assert set(decoded) == set(ideals[p])
        for s,value in zip(decoded,values):
            if s in potentials: assert potentials[s] == value
            potentials[s] = value
    charge = certificate.get('charges_scaled_by_two',certificate.get('charges'))
    daily = certificate.get('daily_charge_bound',2)
    assert potentials[0] == 0
    full = [(sum(1<<indices[v] for v in colors[p])) for p in (0,1)]
    initial = [potentials[s] for s in full]
    assert initial == certificate.get('initial_potentials',certificate.get('initial_potential_scaled_by_two'))
    critical_lower = (sum(initial)+daily-1)//daily
    assert critical_lower == certificate['minimum_turns']
    assert all(charge[p]+charge[q] <= daily for p in range(9) for q in range(9-p))
    checked = 0
    for family in ideals:
        for b in family:
            for r in family:
                used = b.bit_count()-r.bit_count()
                if 0 <= used <= 8 and r & b == r:
                    assert potentials[b] <= charge[used]+potentials[hood(r)]
                    checked += 1

    def scalar_lower(m):
        queue = deque([((half,half),0)])
        seen = {(half,half)}
        while queue:
            (a,b),t = queue.popleft()
            if a+b <= m: return t+1
            for p in range(m+1):
                nxt = (profiles[1][max(0,b-(m-p))],profiles[0][max(0,a-p)])
                if nxt not in seen: seen.add(nxt); queue.append((nxt,t+1))
        return None

    data = json.loads((ROOT/'research'/f'even-resume-{stem}-exact.json').read_text())
    reviewed = []
    for row in data['results']:
        m = row['budget']; claimed = row['minimum_turns']
        if m <= surplus:
            assert claimed is None and scalar_lower(m) is None
            reviewed.append({'budget':m,'time':None,'lower':'cardinality trap'})
            continue
        lower = critical_lower if m == 8 else scalar_lower(m)
        assert lower == claimed, (m,lower,claimed)
        belief = (1<<volume)-1
        for t,shot in enumerate(row['shots'],1):
            mask = sum(1<<indices[tuple(v)] for v in shot)
            assert mask.bit_count() == len(shot) <= m
            survivors = belief & ~mask
            if not survivors:
                assert t == claimed
            belief = hood(survivors)
        assert not belief and len(row['shots']) == claimed
        reviewed.append({'budget':m,'time':claimed,'lower':'charged potential' if m==8 else 'exact scalar profile relaxation','physical_replay':True})
    # The remaining ranges follow from the perfect-matching two-day lower
    # bound and the immediate all-room one-day threshold.
    assert scalar_lower(half) == 2 and scalar_lower(volume-1) == 2 and scalar_lower(volume) == 1
    receipt = {'all_checks_passed':True,'seconds':monotonic()-start,
               'independent_canonical_states':[len(s) for s in ideals],
               'critical_potential_inequalities':checked,'profiles':profiles,
               'scope':'Integer certificate and physical-coordinate replay; the universal strategy-compression theorem remains an ordinary proof.',
               'reviewed':reviewed}
    (ROOT/'research'/f'even-resume-{stem}-independent-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k not in ('profiles','reviewed')}))


if __name__ == '__main__':
    review((4,4,4),'four-cube','even-resume-four-cube-critical-certificate.json',292,7)
    review((3,4,4),'three-four-four','even-resume-three-four-four-eight-probe-certificate.json',1936,6)

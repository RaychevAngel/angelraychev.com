"""Independent physical attacks of the seven fixed-width insertion proofs.

Physical neighborhoods here are reconstructed from coordinate adjacency,
without using the algebraic profile formulas of the certificate generator.
The all-length justification is the separately reviewed insertion proof.
"""
from fractions import Fraction
from pathlib import Path
from time import monotonic
import json
from odd_minimum_budget_all_lengths import one_width, CHARGES


def physical_prefixes(width, length):
    vertices = [(x, y) for x in range(length) for y in range(width)]
    index = {v: i for i, v in enumerate(vertices)}
    adjacency = []
    for x, y in vertices:
        adjacency.append(sum(1 << index[v] for v in
                             [(x-1,y), (x+1,y), (x,y-1), (x,y+1)] if v in index))
    orders = [sorted((i for i,v in enumerate(vertices) if sum(v) % 2 == p),
                     key=lambda i: (sum(vertices[i]), vertices[i][0])) for p in (0,1)]
    prefixes, images = [], []
    for order in orders:
        prefix, image = [0], [0]
        for i in order:
            prefix.append(prefix[-1] | (1 << i))
            image.append(image[-1] | adjacency[i])
        prefixes.append(prefix)
        images.append(image)
    for p in (0,1):
        for image in images[p]:
            assert image == prefixes[1-p][image.bit_count()]
    return adjacency, prefixes, images


def hood(mask, adjacency):
    image = 0
    while mask:
        bit = mask & -mask
        image |= adjacency[bit.bit_length()-1]
        mask ^= bit
    return image


def attack(case, length):
    w, m, base = case['width'], case['minimum_budget'], case['base_length']
    delta = w * (length-base) // 2
    cut = case['cut']
    adjacency, prefixes, images = physical_prefixes(w, length)
    charges = [[Fraction(x) for x in row] for row in case['charges']]
    potentials = [[Fraction(x) for x in row] for row in case['base_potentials']]
    extended = []
    for p in (0,1):
        row = []
        for k in range(len(prefixes[p])):
            if k <= cut:
                row.append(potentials[p][k])
            elif k <= cut+delta:
                row.append(potentials[p][cut] + 2*(k-cut))
            else:
                row.append(potentials[p][k-delta] + 2*delta)
        extended.append(row)
    inequalities = 0
    for p in (0,1):
        for k in range(len(prefixes[p])):
            for r in range(m+1):
                nxt = images[p][max(0,k-r)].bit_count()
                assert extended[p][k]-extended[1-p][nxt] <= charges[p][r]
                inequalities += 1
    first = case['serial_first_parity']
    a, b = prefixes[first][-1], prefixes[1-first][-1]
    days = 0
    hits = [False, False]
    while a or b:
        p = first ^ (days % 2)
        ka, kb = a.bit_count(), b.bit_count()
        assert a == prefixes[p][ka] and b == prefixes[1-p][kb] and not a & b
        active = 0 if a else 1
        if (ka if a else kb) == cut+delta:
            hits[active] = True
        qa = min(m,ka)
        qb = min(m-qa,kb)
        sa, sb = prefixes[p][ka-qa], prefixes[1-p][kb-qb]
        shots = (a ^ sa) | (b ^ sb)
        assert shots.bit_count() <= m
        actual = hood((a | b) & ~shots, adjacency)
        a, b = hood(sa,adjacency), hood(sb,adjacency)
        assert actual == a | b
        days += 1
        assert days <= 2*w*length
    assert all(hits)
    assert days == 2*w*length-case['constant']
    lower = extended[0][-1] + extended[1][-1]
    assert (lower.numerator+lower.denominator-1)//lower.denominator == days
    return dict(width=w, length=length, delta=delta, days=days,
                physical_potential_inequalities=inequalities,
                both_translated_cut_visits=True)


if __name__ == '__main__':
    start = monotonic()
    cases = [one_width(w) for w in CHARGES]
    rows = [attack(case, case['base_length']+extra) for case in cases for extra in (0,2,8)]
    result = dict(status='passed',
                  exact_certificate_widths=len(cases),
                  exact_certificate_finite_lengths=sum(len(c['finite_lengths']) for c in cases),
                  independent_physical_boards=rows,
                  seconds=monotonic()-start,
                  proof_scope='Independent finite attacks of actual coordinate adjacency, every extended potential inequality, and full-board serial witnesses. Universal length extension is the separately reviewed ordinary affine-insertion argument.')
    Path('research/odd-minimum-budget-independent-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

"""Check the exact formula at k=r(r-1), including the shape-change residue.

The unbounded claim rests on the ordinary proof in the companion note.
These checks compare its arithmetic with existing recurrences. The sole
prefix gap is closed by bridge-quadratic-edge-exception.md's construction.
"""
from math import isqrt
from pathlib import Path
from time import process_time
import hashlib
import json

from bridge_boundary_numeric_budget import bounds
from resumed_even_construction_prefix import scalar


def evaluate(r, n):
    assert r >= 3 and n >= 2*r
    h, k, s = r*n, r*(r-1), r*(r-2)
    j = max(0, (h-k-s-3)//s)
    z = h-(j+1)*s-k-1
    root = isqrt(z)+int(isqrt(z)**2 < z)
    c, tau = z+root, j+3
    requires_shape_change = r == 8 and n % 12 == 10
    return dict(width=2*r, length=n, budget=k, affine_steps=j,
                last_survivor=z, scalar_last=c, solo=tau,
                formula=2*tau-int(2*c <= k), requires_shape_change=requires_shape_change)


def main():
    started = process_time()
    rows = []
    for r in (3,4,5,6,7,8,9,10,16,25,50):
        for n in range(2*r, 2*r+2*(r-2)):
            row = evaluate(r, n)
            actual_tau, counts = scalar(2*r, n, row['budget'])
            assert (actual_tau, counts[-2]) == (row['solo'], row['scalar_last'])
            bracket = bounds(2*r, n, row['budget'], K=16)
            assert bracket['lower'] == row['formula']
            if row['requires_shape_change']:
                assert bracket['upper'] == row['formula']+1
            else:
                assert bracket['upper'] == row['formula']
            rows.append(row)
    large = []
    for r in (3,6,8,25,1000):
        for n in (10**12, 10**12+1):
            row = evaluate(r,n)
            bracket = bounds(2*r,n,row['budget'],K=16)
            assert bracket['lower'] == row['formula']
            assert bracket['upper'] == row['formula']+int(row['requires_shape_change'])
            large.append(row)
    out = dict(status='PASS', scope=__doc__,
               shape_change_proof='research/bridge-quadratic-edge-exception.md',
               source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               finite_rows=rows, large_rows=large, seconds=process_time()-started)
    Path('research/bridge-boundary-numeric-quadratic-edge-check.json').write_text(
        json.dumps(out,indent=2)+'\n')
    print(dict(status='PASS', finite_cases=len(rows), large_cases=len(large),
               seconds=out['seconds']))


if __name__ == '__main__':
    main()

"""Exact parity neighborhood profiles on Q × P_n from compatible profiles of Q.

This is an isoperimetric transfer recurrence, not a claim of compatible
nesting or an exact two-count capture-time recurrence for the whole cylinder.
"""
from pathlib import Path
import json,time
from collections import deque
from nested_grid_time import ordered_profiles

def transfer(profiles,n,p):
    assert n >= 1 and p in (0,1)
    caps=[len(row)-1 for row in profiles]
    states={(0,k,k):0 for k in range(caps[p]+1)}
    for column in range(n-1):
        phase=(p+column)%2;following={}
        for (a,b,total),cost in states.items():
            for c in range(caps[1-phase]+1):
                key=(b,c,total+c);value=cost+max(profiles[phase][b],a,c)
                if value<following.get(key,10**20):following[key]=value
        states=following
    result=[10**20]*(sum(caps[(p+i)%2] for i in range(n))+1)
    phase=(p+n-1)%2
    for (a,b,total),cost in states.items():
        result[total]=min(result[total],cost+max(profiles[phase][b],a))
    return result

def lower_time(profiles,m):
    initial=tuple(len(row)-1 for row in profiles)
    queue=deque([(initial,0)]);seen={initial}
    while queue:
        (a,b),t=queue.popleft()
        if a+b<=m:return t+1
        for p in range(m+1):
            after=(profiles[1][max(0,b-(m-p))],profiles[0][max(0,a-p)])
            if after not in seen:seen.add(after);queue.append((after,t+1))
    return None

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1];start=time.monotonic()
    transverse,raw=ordered_profiles((3,3),weightlex=True)
    results=[]
    for n in range(3,31):
        exact=[transfer(transverse['profiles'],n,p) for p in (0,1)]
        prefix,data=ordered_profiles((3,3,n),weightlex=True)
        assert prefix['nested']
        if n%2:assert exact==prefix['profiles']
        solo=[]
        for phase in (0,1):
            b=len(prefix['profiles'][phase])-1;days=0;seen=set()
            while b>5 and (b,phase) not in seen:
                seen.add((b,phase));b=prefix['profiles'][phase][b-5];phase=1-phase;days+=1
            solo.append(None if b>5 else days+1)
        results.append({'shape':[3,3,n],'max_surplus':[max(v-k for k,v in enumerate(row)) for row in exact],
                        'lower_time_five':lower_time(exact,5),
                        'serial_upper_five':2*min(s for s in solo if s is not None),
                        'prefix_matches':[exact[p]==prefix['profiles'][p] for p in (0,1)],
                        'profiles':exact})
    # Independent exhaustive subset minima on the 36-room board (18 rooms/color).
    _,data=ordered_profiles((3,3,4),weightlex=True)
    coords,adj,orders,_,_=data
    for p,order in enumerate(orders):
        hood=[0]*(1<<len(order));minima=[1000]*(len(order)+1);minima[0]=0
        for code in range(1,len(hood)):
            bit=code&-code;hood[code]=hood[code^bit]|adj[order[bit.bit_length()-1]]
            k=code.bit_count();minima[k]=min(minima[k],hood[code].bit_count())
        assert minima==results[1]['profiles'][p]
    receipt={'all_checks_passed':True,'seconds':time.monotonic()-start,
             'scope':'Exact isoperimetric transfer from proved transverse nesting. The time column is only a lower bound unless independently matched by a physical construction. Even-length prefix-minimum failures are retained.',
             'exhaustive_subsets_checked':2*(1<<18),'results':results}
    (root/'research/odd-cylinder-profile-transfer.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='results'}))
    for r in results:print(r['shape'],r['lower_time_five'],r['serial_upper_five'],r['prefix_matches'])

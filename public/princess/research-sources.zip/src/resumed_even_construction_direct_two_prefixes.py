"""Direct two-bottom-prefix-union solo upper search, without all pyramids.

Every permitted belief is a union of two prefixes. The exact quota contour
retains every distinct survivor of that size. The resulting capture clock
is exact within this explicitly restricted family only.
"""
from collections import deque
from pathlib import Path
import json,time
from resumed_even_construction_prefix import PrefixGame
from resumed_even_construction_transport import neighborhood,height


def prepare(g):
    h=len(g.colors[0]);data=[]
    for p in (0,1):
        left,right=g.orders[p][0],g.orders[p][4]
        identifiers={};masks=[];maxima=[];pairs=[];counts=[]
        for u in range(h+1):
            row=[];sizes=[]
            for v in range(h+1):
                mask=left[u]|right[v]
                if mask not in identifiers:
                    identifiers[mask]=len(masks);masks.append(mask);maxima.append([u,v])
                identifier=identifiers[mask]
                maxima[identifier][0]=max(maxima[identifier][0],u)
                maxima[identifier][1]=max(maxima[identifier][1],v)
                row.append(identifier);sizes.append(mask.bit_count())
            pairs.append(row);counts.append(sizes)
        data.append({'masks':masks,'maxima':maxima,'pairs':pairs,'counts':counts,
                     'index':identifiers,'sizes':[mask.bit_count()for mask in masks]})
    for p in (0,1):
        left_next=[g.hood(p,A).bit_count()for A in g.orders[p][0]]
        right_next=[g.hood(p,A).bit_count()for A in g.orders[p][4]]
        assert all(g.hood(p,A)==g.orders[1-p][0][s]for A,s in zip(g.orders[p][0],left_next))
        assert all(g.hood(p,A)==g.orders[1-p][4][s]for A,s in zip(g.orders[p][4],right_next))
        data[p]['hood']=[data[1-p]['pairs'][left_next[u]][right_next[v]]
                          for u,v in data[p]['maxima']]
    return data


def run(w=24,n=None,k=13):
    if n is None:n=w
    started=time.monotonic();g=PrefixGame(w,n);d=prepare(g);h=w*n//2
    initial=(0,d[0]['index'][g.full]);queue=deque([(initial,0)]);parents={initial:None}
    terminal=None;terminal_depth=None;tested=0;first_minima={}
    while queue:
        (p,i),depth=queue.popleft()
        if terminal_depth is not None and depth>terminal_depth:break
        size=d[p]['sizes'][i];first_minima[depth]=min(size,first_minima.get(depth,h+1))
        if size<=k:
            if terminal is None or size<d[terminal[0]]['sizes'][terminal[1]]:terminal=(p,i)
            terminal_depth=depth;continue
        if terminal_depth is not None:continue
        U,V=d[p]['maxima'][i];q=size-k;v=V;previous=-1
        for u in range(min(U,q)+1):
            while v>=0 and d[p]['counts'][u][v]>q:v-=1
            if v<0:break
            if d[p]['counts'][u][v]!=q:continue
            j=d[p]['pairs'][u][v]
            if j==previous:continue
            previous=j;tested+=1
            nxt=(1-p,d[p]['hood'][j])
            if nxt not in parents:
                parents[nxt]=((p,i),j);queue.append((nxt,depth+1))
    assert terminal is not None
    steps=[(terminal,d[terminal[0]]['index'][0])];current=terminal
    while parents[current] is not None:
        current,j=parents[current];steps.append((current,j))
    steps.reverse();shots=[];schedule=[]
    for (p,i),j in steps:
        shotmask=d[p]['masks'][i]^d[p]['masks'][j]
        shot={v for bit,v in enumerate(g.colors[p])if shotmask>>bit&1};shots.append(shot)
        schedule.append({'before_size':d[p]['sizes'][i],
                         'survivor_size':d[p]['sizes'][j],
                         'survivor_prefix_sizes':d[p]['maxima'][j],
                         'shots':sorted(shot)})
    seqs={'solo':shots,'full_even':shots+shots[::-1]}
    if 2*len(shots[-1])<=k:
        reflection=lambda S:{(w-1-x,y)for x,y in S}
        seqs['full_odd']=shots[:-1]+[shots[-1]|reflection(shots[-1])]+[reflection(S)for S in shots[-2::-1]]
    captures={}
    for mode,sequence in seqs.items():
        A=set(g.colors[0])if mode=='solo'else{(x,y)for x in range(w)for y in range(n)}
        first=None
        for day,shot in enumerate(sequence,1):
            assert len(shot)<=k
            A-=shot
            if not A and first is None:first=day
            A=neighborhood(w,n,A)
        assert not A;captures[mode]=first
    return {'shape':[w,n],'budget':k,'restricted_solo_clock':len(shots),
            'smallest_terminal_support':len(shots[-1]),'literal_capture_days':captures,
            'all_physical_replays_passed':True,'family_states_per_color':[len(x['masks'])for x in d],
            'visited_states':len(parents),'quota_contour_edges':tested,
            'first_arrival_min_sizes':first_minima,'schedule':schedule,
            'seconds':time.monotonic()-started,
            'scope':'Exact clock inside two fixed bottom-prefix unions; physical upper certificates only, no unrestricted normal-form assertion.'}


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--w',type=int,default=24)
    p.add_argument('--n',type=int);p.add_argument('--k',type=int,default=13);a=p.parse_args()
    n=a.n or a.w;out=run(a.w,n,a.k)
    Path(f'research/resumed-even-construction-direct-two-prefixes-{a.w}x{n}-k{a.k}.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k not in('schedule','first_arrival_min_sizes')})

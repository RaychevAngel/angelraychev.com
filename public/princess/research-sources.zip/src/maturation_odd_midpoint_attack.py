"""Focused actual-horizon attacks; no assumption of serial optimality."""
from supersession_solo_bands import OddRectangle
from supersession_odd_midpoint_bounded import retained_step, union_max
from math import isqrt
from time import process_time

def inspect(w,n,m,limit=6.0):
    G=OddRectangle(w,n);half=G.half_time(m)
    tau=half['tau'];L=tau-1
    a=b=0;front=[(0,0)];maxfront=1;checks=0;start=process_time()
    worst=None
    for t in range(L):
        front,a,b=retained_step(G,m,front,a,b)
        maxfront=max(maxfront,len(front));checks+=len(front)*(m+1)
        if process_time()-start>limit:return {'shape':[w,n],'m':m,'tau':tau,'complete':False,'seconds':process_time()-start,'last_day':t+1,'front':len(front)}
    cap=union_max(G,front);K=max(G.E,a+b)
    central=G.E+G.M-cap;res=G.E+G.M-a-b
    failure=cap>K;weak_failure=(central<=m)!=(res<=m)
    if failure:
        pair=next((x,y) for x in front for y in front if min(G.E,x[0]+y[0])+min(G.M,x[1]+y[1])>K)
    else:pair=None
    return {'shape':[w,n],'m':m,'tau':tau,'complete':True,'seconds':process_time()-start,'front':len(front),'maxfront':maxfront,'actual_central':central,'solo_central':res,'strong_failure':failure,'criterion_failure':weak_failure,'pair':pair}

if __name__=='__main__':
    import json,argparse
    P=argparse.ArgumentParser();P.add_argument('width',type=int);P.add_argument('length',type=int);P.add_argument('budget',type=int)
    args=P.parse_args();print(json.dumps(inspect(args.width,args.length,args.budget),indent=2))

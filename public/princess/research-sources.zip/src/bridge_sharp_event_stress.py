"""Targeted rounding attack on the proposed sharp-event charge.

Selected large widths and proportional corner radii test the regime where
the continuous estimate pays less than one day. This is not a proof.
"""
from array import array
from math import e
from pathlib import Path
import hashlib
import json
import time
from bridge_sharp_event_charge import root, pronic, tri


def main():
    started = time.process_time()
    rows = []
    failures = []
    checks = 0
    for b in (31, 64, 127, 256, 511, 1000):
        k, n = b + 1, 2 * b + 2
        top = b * (b - 1)
        tau0, tau1 = array('I', [0]) * (top + 1), array('I', [0]) * (top + 1)
        for a in range(1, top + 1):
            q = max(0, a - k)
            if not q:
                tau0[a] = tau1[a] = 1
            else:
                u, v = q + min(root(q), b), q + min(pronic(q) + 1, b + 1)
                assert u < a and v < a
                tau0[a], tau1[a] = 1 + tau1[u], 1 + tau0[v]
        local = 0
        for old_r in sorted({13 * k // 20, 7 * k // 10, 3 * k // 4}):
            predicted_r = max(1, int(k - e * (k - old_r)))
            predicted_t = 2 * (k - old_r + predicted_r)
            for a in (old_r * old_r + 1, old_r * old_r + old_r // 2,
                      old_r * (old_r + 1)):
                neutral = a
                for t in range(1, tau1[a]):
                    if t % 2 and abs(t - predicted_t) <= 61:
                        low_q = max(1, neutral - k)
                        radius = 2 * old_r + t - 2
                        v = (radius - n + 1) // 2
                        for r in range(1, b):
                            q = max(r * (r - 1) + 1, low_q)
                            missing = tri(r - 1 - v) - 2 * tri(-1 - v) + tri(-r - 1 - v)
                            if q > min(r * r, r * r - missing):
                                continue
                            local += 1
                            checks += 1
                            if t + tau1[q + r] < tau1[a]:
                                failures.append(dict(b=b, k=k, n=n, initial_radius=old_r,
                                                     initial_size=a, initial_clock=tau1[a],
                                                     inter_event_time=t, neutral_lower_size=neutral,
                                                     new_radius=r, survivor=q, lens_radius=radius,
                                                     new_size=q+r, new_clock=tau1[q+r]))
                                break
                        if failures:
                            break
                    q = max(0, neutral - k)
                    neutral = 0 if not q else q + min(pronic(q) + 1, b + 1)
                if failures:
                    break
            if failures:
                break
        rows.append(dict(b=b, tests=local))
        if failures or time.process_time() - started > 15:
            break
    result = dict(status='COUNTEREXAMPLE' if failures else 'PASS',
                  scope=__doc__, width_rows=rows, checks=checks, failures=failures,
                  CPU_seconds=time.process_time()-started,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    Path('research/bridge-sharp-event-stress-check.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

"""Width-independent operation scheme for two-prefix transport cost.

The evaluator always uses12 affine lines,72 cut positions, and at most142
interval sums. A width-sized sum appears only in the independent test oracle.
"""
from pathlib import Path
import json,random


def endpoint_lines(w,n,phase,epsilon,params,shift):
    d,c,f,g=params;s=(phase-epsilon)%2
    low=s-2+shift;high=n-1-(n-1-s)%2+shift
    left=(-2,d-epsilon-2+shift)
    right=(2,f-w-1+epsilon+shift)
    lines=[(0,low),(0,high),left,(left[0],left[1]+2),right,(right[0],right[1]+2)]
    switches=[-(-(c-epsilon)//2),(w-1-epsilon-g)//2+1]
    def value(z):
        x=2*z+epsilon
        L=left[0]*z+left[1]+2*(x>=c)
        R=right[0]*z+right[1]+2*(w-1-x>=g)
        return max(low,min(high,max(L,R)))
    return lines,switches,value


def transport_cost(w,n,p,a,b,t):
    total=0;intervals=0
    for epsilon in(0,1):
        M=(w+1-epsilon)//2
        if M<=0:continue
        al,ac,A=endpoint_lines(w,n,p,epsilon,a,0)
        bl,bc,B=endpoint_lines(w,n,p+t,epsilon,b,-t)
        lines=al+bl;cuts=[0,M]+ac+bc
        for i in range(12):
            for j in range(i):
                m,c=lines[i];s,d=lines[j]
                cuts.append((d-c)//(m-s)+1 if m!=s else 0)
        assert len(cuts)==72
        cuts=sorted(max(0,min(M,z))for z in cuts)
        for L,U in zip(cuts,cuts[1:]):
            if L==U:continue
            first=max(A(L)-B(L),0);last=max(A(U-1)-B(U-1),0)
            numerator=(U-L)*(first+last)
            assert numerator%2==0
            total+=numerator//2;intervals+=1
    assert total%2==0 and intervals<=142
    return total//2,intervals


def run():
    rng=random.Random(20260913);maximum=0
    for case in range(1000):
        w=rng.randrange(2,401);n=rng.randrange(w,3*w+1)
        p=rng.randrange(2);t=rng.randrange(n+1)
        def parameters(phase):
            d=rng.randrange(-2,w+n+3);d-=((d-phase)%2)
            f=rng.randrange(-2,w+n+3);f-=((f-phase+(w-1))%2)
            return d,rng.randrange(w+1),f,rng.randrange(w+1)
        a=parameters(p);b=parameters(p+t)
        bounded,intervals=transport_cost(w,n,p,a,b,t);maximum=max(maximum,intervals)
        direct=0
        for epsilon in(0,1):
            _,_,A=endpoint_lines(w,n,p,epsilon,a,0)
            _,_,B=endpoint_lines(w,n,p+t,epsilon,b,-t)
            direct+=sum(max(A(z)-B(z),0)for z in range((w+1-epsilon)//2))
        assert direct==2*bounded,(w,n,p,a,b,t,direct,bounded)
    return {'cases':1000,'all_constant_cost_comparisons_pass':True,
            'maximum_nonempty_intervals_observed':maximum,
            'absolute_affine_line_count':12,'absolute_cut_count_per_parity':72,
            'absolute_interval_sum_bound':142,
            'scope':'Independent numerical verification of bounded-operation transport expression; no full capture-time formula claim.'}


if __name__=='__main__':
    out=run()
    Path('research/resumed-even-construction-transport-constant-check.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out)

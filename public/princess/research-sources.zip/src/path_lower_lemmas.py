#!/usr/bin/env python3
"""Exhaustive attacks on local lemmas used in the path lower-bound proof.

No final formula is used. Enumerates all belief sets, not only reachable ones.
Single process; bounded instances. This is supporting evidence, not a proof.
"""
import itertools
import json
import time
from pathlib import Path


def neighborhood(s, mask):
    return ((s << 1) | (s >> 1)) & mask


def shots(b, m):
    vs = [1 << i for i in range(b.bit_length()) if b & (1 << i)]
    for r in range(min(m, len(vs)) + 1):
        for c in itertools.combinations(vs, r):
            yield sum(c)


def component_count(s):
    return (s & ~(s << 2)).bit_count()


def run(n, m):
    mask = (1 << n) - 1
    odd = sum(1 << i for i in range(0, n, 2))
    even = mask ^ odd
    end = 1 | (1 << (n - 1))
    checks = 0
    # Identity on every subset of each one-parity class.
    for parity in (odd, even):
        a = parity
        while True:
            assert neighborhood(a, mask).bit_count() - a.bit_count() == component_count(a) - (a & end).bit_count()
            checks += 1
            if a == 0:
                break
            a = (a - 1) & parity
    # Store every high-decrement transition, including its action.
    high = {}
    all_edges = 0
    for b in range(1, mask + 1):
        options = []
        for s in shots(b, m):
            nb = neighborhood(b & ~s, mask)
            delta = b.bit_count() - nb.bit_count()
            all_edges += 1
            assert delta <= m + (n % 2)
            if delta >= m:
                options.append((nb, delta, s))
            if n % 2 and delta == m + 1:
                assert b & odd == odd
                assert b & even == s
                assert s.bit_count() == m
                assert nb == even
                checks += 1
        high[b] = options
    pairs = 0
    triples = 0
    for b, es in high.items():
        for nb, d, s in es:
            for nb2, d2, s2 in high.get(nb, []):
                pairs += 1
                if n % 2:
                    # All consecutive high steps finish capture; no m+1 adjacent.
                    assert d == d2 == m
                    assert nb2 == 0
                else:
                    parts = (b & odd, b & even)
                    fulls = (parts[0] == odd, parts[1] == even)
                    if nb2:
                        assert sum(fulls) == 1
                        f = odd if fulls[0] else even
                        p = even if fulls[0] else odd
                        assert b & p and b & p != p
                        assert not s & f  # Full color is untouched on first step.
                        assert nb2 & p == 0  # Two movements restore initial parity.
                    for nb3, d3, s3 in high.get(nb2, []):
                        triples += 1
                        assert nb3 != 0
                        assert not high.get(nb3, [])  # No four consecutive high steps.
                        # In a triple the full color is untouched through first 2.
                        f = odd if fulls[0] else even
                        assert nb2 & f == f
                        assert nb2.bit_count() == n // 2
                checks += 1
    return dict(n=n, m=m, all_transitions=all_edges, high_pairs=pairs, high_triples=triples, assertions=checks)


def main():
    t = time.monotonic()
    cases = []
    for n, m in [(5, 1), (6, 1), (7, 1), (8, 1), (9, 2), (10, 2), (11, 2), (12, 2), (13, 3), (14, 3)]:
        cases.append(run(n, m))
    out = dict(status='all assertions passed', seconds=round(time.monotonic()-t, 3), cases=cases,
               scope='All belief states and useful inspection subsets in listed cases; local claims only.')
    target = Path(__file__).resolve().parents[1] / 'research' / 'path-lower-lemma-checks.json'
    target.write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps(out, indent=2))

if __name__ == '__main__':
    main()

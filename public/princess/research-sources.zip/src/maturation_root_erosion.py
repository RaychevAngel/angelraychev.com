"""Coordinate checks of clipped erosion and the improved even-width theorem.

The proof is in research/maturation-boundary-connections.md. Finite checks
test the physical upper construction and endpoint arithmetic independently;
they are not a substitute for its unbounded lower proof.
"""
from collections import deque
from math import isqrt
from pathlib import Path
from time import process_time
import json


def root(k):
    return isqrt(k) + (isqrt(k) ** 2 < k)


def pronic(k):
    r = isqrt(k)
    return r if k <= r * (r + 1) else r + 1


def geometric_check(edges, size):
    adj = [set() for _ in range(size)]
    for u, v in edges:
        adj[u].add(v)
        adj[v].add(u)
    distances = []
    for v in range(size):
        dist = {v: 0}
        q = deque([v])
        while q:
            x = q.popleft()
            for y in adj[x]:
                if y not in dist:
                    dist[y] = dist[x] + 1
                    q.append(y)
        assert len(dist) == size
        distances.append(dist)
    chi = [distances[0][v] % 2 for v in range(size)]
    assert all(chi[u] != chi[v] for u, v in edges)
    order = sorted(range(size), key=lambda v: (distances[0][v], v))
    n = max(max(d.values()) for d in distances) + 2
    board = {(v, y) for v in range(size) for y in range(n)}
    def N(S):
        return {(u, z) for v, y in S
                for u, z in [(v, y-1), (v, y+1)] + [(u, y) for u in adj[v]]
                if (u, z) in board}
    counts = [0, 0]
    bounds = []
    for p in (0, 1):
        parity = [(p-chi[v]) % 2 for v in range(size)]
        expected = max(sum(d // 2 for d in distances[v].values())
                       for v in range(size) if chi[v] == p)
        maximum = -1
        heights = {}
        def visit(j):
            nonlocal maximum
            if j < size:
                v = order[j]
                previous = [u for u in adj[v] if u in heights]
                choices = set(range(parity[v]-2, n, 2))
                for u in previous:
                    choices &= {heights[u]-1, heights[u]+1}
                for a in choices:
                    heights[v] = a
                    visit(j+1)
                heights.pop(v, None)
                return
            A = {(v, y) for v, y in board
                 if y % 2 == parity[v] and y <= heights[v]}
            e = {v: max(heights[v]-1, (1-parity[v])-2) for v in range(size)}
            E = {(v, y) for v, y in board
                 if y % 2 != parity[v] and y <= e[v]}
            assert all(abs(e[u]-e[v]) == 1 for u, v in edges)
            occupied_roots = sum((v, 0) in A for v in range(size) if chi[v] == p)
            assert len(A)-len(E) == occupied_roots
            assert N(E) <= A
            if occupied_roots < sum(c == p for c in chi):
                maximum = max(maximum, len(A))
            counts[p] += 1
        visit(0)
        assert maximum == expected, (edges, p, maximum, expected)
        bounds.append(expected)
    return {"vertices": size, "edges": edges, "phase_bounds": bounds,
            "pyramids_checked": sum(counts)}


def physical_case(b, n, m):
    w, h = 2*b, b*n
    d = m-b
    q, r = divmod(h-b, d)
    board = {(x, y) for x in range(w) for y in range(n)}
    colors = [{v for v in board if sum(v) % 2 == p} for p in (0, 1)]
    def N(S):
        return {(u, v) for x, y in S
                for u, v in ((x-1, y), (x+1, y), (x, y-1), (x, y+1))
                if (u, v) in board}
    def ideal(S):
        return all((u, y-1) in S for x, y in S if y > 0
                   for u in (x-1, x+1) if 0 <= u < w)
    R = set(sorted(colors[0], key=lambda v: (sum(v), -v[0]))[:r])
    p = 0
    X = N(R)
    J = 0 if not r else r+min(root(r), b)
    assert ideal(R) and len(X) <= J
    reverse = []
    for _ in range(q-1):
        A = set(R)
        target = len(R)+m
        for v in sorted(colors[p], key=lambda v: (v[1], v[0])):
            if len(A) == target:
                break
            A.add(v)
        assert len(A) == target and ideal(A)
        reverse.append(A-R)
        heights = [max((y for xx, y in A if xx == x), default=(p-x) % 2-2)
                   for x in range(w)]
        cutoffs = [max(heights[x]-1, (1-(p-x) % 2)-2) for x in range(w)]
        E = {(x, y) for x, y in colors[1-p] if y <= cutoffs[x]}
        assert len(A) > b*(b-1)
        assert ideal(E) and len(E) == len(A)-b and N(E) <= A
        R, p = E, 1-p
    assert len(colors[p]-R) == m
    reverse.append(colors[p]-R)
    half = list(reversed(reverse))
    if not r:
        shots, target_time = half+list(reversed(half)), 2*q
    elif 2*J <= m:
        def reflect(S):
            return {(w-1-x, y) for x, y in S}
        shots = half+[X | reflect(X)]+[reflect(A) for A in reversed(half)]
        target_time = 2*q+1
    else:
        solo = half+[X]
        shots, target_time = solo+list(reversed(solo)), 2*q+2
    belief = board
    for day, A in enumerate(shots, 1):
        assert len(A) <= m
        belief = N(belief-A)
        assert bool(belief) == (day < target_time), (b, n, m, day, target_time)
    assert len(shots) == target_time
    return {"b": b, "n": n, "m": m, "T": target_time}


def scalar_case(b, n, m):
    h = b*n
    d = m-b
    q, r = divmod(h-b, d)
    J = 0 if not r else r+min(root(r), b)
    predicted = 2*q if not r else 2*q+1+(2*J > m)
    c = h
    t = 0
    before = None
    while c:
        before = c
        k = max(c-m, 0)
        c = k+min(root(k), b, pronic(h-k))
        t += 1
    lower = 2*t-1+(2*before > m)
    assert predicted == lower, (b, n, m, q, r, predicted, lower)


def main():
    start = process_time()
    graphs = [geometric_check([(i, i+1) for i in range(a-1)], a)
              for a in range(2, 10)]
    graphs += [geometric_check([(0, i) for i in range(1, 6)], 6),
               geometric_check([(u, v) for u in (0, 1) for v in (2, 3, 4)], 5),
               geometric_check([(0, 1), (1, 2), (2, 3), (3, 0)], 4)]
    physical = []
    for b in range(1, 10):
        for n in range(2*b, 2*b+7):
            for m in range(max(b+1, b*(b-1)+1), min(b*b+2, b*n)):
                physical.append(physical_case(b, n, m))
    scalar_count = 0
    for b in range(1, 31):
        for n in range(2*b, 2*b+21):
            for m in range(max(b+1, b*(b-1)+1), min(b*b+2, b*n)):
                scalar_case(b, n, m)
                scalar_count += 1
    result = {"status": "PASS", "scope": "Finite attack of separately proved unbounded theorem",
              "graphs": graphs, "physical_cases": physical,
              "scalar_cases": scalar_count, "cpu_seconds": process_time()-start}
    path = Path(__file__).resolve().parents[1]/"research/maturation-root-erosion-check.json"
    path.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"status": result["status"], "geometric_pyramids": sum(g["pyramids_checked"] for g in graphs),
                      "physical_cases": len(physical), "scalar_cases": scalar_count,
                      "cpu_seconds": result["cpu_seconds"]}))


if __name__ == '__main__':
    main()

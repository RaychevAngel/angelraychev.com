"""Generate independently replayed schedules for grids with one to four rows."""
import json
from pathlib import Path
from path_strategy import schedule, verify, claimed_time
from ladder_counter_model import solve, closed_formula
from three_row_budget_recurrence import formula_strategy as three_strategy
from four_row_recurrence import direct_strategy as four_strategy

root = Path(__file__).resolve().parents[1]
data = {}
for n in range(1, 25):
    for m in range(1, n+1):
        shots = schedule(n, m)
        verify(n, m, shots)
        assert len(shots) == claimed_time(n, m)
        data[f'path,{n},{m}'] = {'days': len(shots), 'shots': [[v-1 for v in s] for s in shots]}
    for m in range(1, 2*n+1):
        r = solve(n,m)
        assert r['minimum_turns'] == closed_formula(n,m)
        data[f'ladder,{n},{m}'] = {'days': r['minimum_turns'],
            'shots': [[row*n+j for row,j in t['probes']] for t in r.get('verified_schedule', [])[1:]]}
    for rows,family in [(3,'three'),(4,'four')]:
        for m in range(1,rows*n+1):
            if rows==3:
                r=three_strategy(n,m)
                result={'days':r['turns'],'shots':[[y*n+x for x,y in S] for S in r['inspections']]}
            elif n>=4:
                r=four_strategy(n,m)
                result={'days':r['turns'],'shots':[[y*n+x for x,y in S] for S in r['inspections']]}
            elif n==1:
                S=schedule(4,m)
                result={'days':len(S),'shots':[[v-1 for v in s] for s in S]}
            elif n==2:
                r=solve(4,m)
                result={'days':r['minimum_turns'],'shots':[[col*2+row for row,col in t['probes']] for t in r.get('verified_schedule',[])[1:]]}
            else:
                r=three_strategy(4,m)
                result={'days':r['turns'],'shots':[[x*3+y for x,y in S] for S in r['inspections']]}
            data[f'{family},{n},{m}']=result

# Recheck the exact flattened coordinates that the browser will display.
for key,result in data.items():
    family,nn,mm=key.split(',');n=int(nn);m=int(mm)
    rows={'path':1,'ladder':2,'three':3,'four':4}[family]
    if result['days'] is None:
        assert not result['shots'];continue
    assert len(result['shots'])==result['days']
    B=set(range(n*rows))
    for day,shots in enumerate(result['shots'],1):
        S=set(shots);assert len(S)==len(shots) and len(S)<=m and S<=set(range(n*rows)),key
        R=B-S
        if not R:
            assert day==result['days'],key
            B=set();break
        B=set()
        for v in R:
            row,col=divmod(v,n)
            for rr,cc in [(row-1,col),(row+1,col),(row,col-1),(row,col+1)]:
                if 0<=rr<rows and 0<=cc<n:B.add(rr*n+cc)
        assert B,(key,'uncaptured target at isolated vertex')
    assert not B,key
(root/'website').mkdir(exist_ok=True)
(root/'website/data.js').write_text('const STRATEGIES = '+json.dumps(data,separators=(',',':'))+';\n')
print(f'Prepared {len(data)} verified strategy entries, columns 1 through 24.')
(root/'research/explorer-verification.json').write_text(json.dumps({'cases':len(data),'families':['path','ladder','three','four'],'max_columns':24,'all_physical_replays_passed':True,'scope':'Printed formulas supply lower proofs. This independent replay checks the actual browser coordinates, budget, movement and final capture of every finite displayed strategy.'},indent=2)+'\n')

# From the odd-five recurrence to explicit formulas

12 September 2026. New work in the current investigation; no claim of prior
literature priority. This builds on the independently reviewed exact
odd-rectangle neighborhood profiles, rather than an assumed serial strategy.

**Current proof boundary.** Sections 1--3 give complete ordinary proofs for
budgets four and five, with kernel-checked finite arithmetic bases. Section4
retains the original candidate-stage derivation; Sections6--8 complete its
all-budget proof. The entire argument passed root's independent review in
`recurrence-bridge-odd-five-independent-review.md`. No complete physical Lean
theorem is claimed here.

## 1. Exact state semantics

Let n>=5 be odd and h=(5n-1)/2, so h>=12 and h=2 (mod5). Physical parity zero
has h+1 rooms and parity one has h. The proved profiles are g_z(0)=0 and

    g_0(k)=h                       if h<=k<=h+1,
           k+1                    if k=1 or h-3<=k<=h-1,
           k+2                    otherwise;
    g_1(k)=h+1                     if k=h,
           k+2                    if k<=2 or h-2<=k<=h-1,
           k+3                    otherwise.

Every optimal strategy can use the simultaneously nested prefixes. Thus
(a,b) -> (g_1((b-q)_+),g_0((a-p)_+)), p+q<=m, is the exact game, including
partial prefix beliefs. Every nonempty reachable parity-z count is at least
3-z. Useful probes against one cohort satisfy p<=b and the two useful
allocations sum to at most m.

`src/recurrence_bridge_odd_five.py` has an independent Pareto-frontier solver
of this exact recurrence. Its separately implemented `overlap` routine is
only a restricted upper class: full inspections of one cohort, a single
shared day, then full inspections of the other. Those two agree in 507
initial tests, but no general serial-normal-form theorem is assumed.

## 2. Four probes: a three-residue formula

**Theorem (ordinary proof; awaiting independent review).** For every odd n>=5,

    T_4(P_5 square P_n)
      = 2 ceil((5n-9)/3) + 2*1_[3 divides n].                  (1)

Equivalently, writing h=3t,3t+1,3t+2, the times are 4t-4,4t-2,4t-2.

Use the same interior arithmetic function as the earlier four-probe proof:

    H(b,z)=b                                         if b<=4,
           6                                         if (b,z)=(5,0),
           4 floor((2b+z)/3)-8
              +3*1_[(2b+z) mod3=2]                   otherwise.

Set C(h)=8t-8,8t-5,8t-4 for h=3t,3t+1,3t+2, respectively, and define

    V_h(b,z)=C(h)-1                         if z=0,b=h,
             min(H(b,0),C(h)-2)             if z=0,b=h-1,
             min(C(h),H(b,z))               otherwise.       (2)

For every h>=12, z in{0,1}, b=0 or 3-z<=b<=h+1-z, and 0<=p<=4,

    V_h(b,z) <= p + V_h(g_z((b-p)_+),1-z).                   (3)

Here is an explicit finite reduction proving that the arithmetic assertion
has no hidden cutoff. The residue formula gives

    C(h+3)=C(h)+8,
    H(b+3,z)=H(b,z)+8                 for b>=6.

The endpoint clauses in (2) consequently give the same +8 translation
when h and b are both increased by three, provided the smaller b>=7.
The exact profile identity is

    g_(h+3,z)(k+3)=g_(h,z)(k)+3       for k>=3,
                                      k<=h+1-z.

For h>=24 and b>=13, reduce (h,b) to (h-3,b-3). Its survivor size is at
least six when p<=4. Both source and target potentials decrease by eight;
the target size before reduction is at least ten. The desired inequality
is therefore exactly the smaller-h inequality. The domain is preserved.

For h>=24 and b<=12, instead reduce h alone by three. All survivor sizes
are at most twelve, and all target sizes are at most fifteen. For h-3>=21,
no near-full profile clause, exceptional potential clause, or cap is active
on these sizes: C(h-3)>=48 whereas H(b',z')<=32 for b'<=15. Thus both sides
are unchanged. These reductions leave only 12<=h<=23. All b<=h+1, both
parities, and all five allocations in that range are checked by
`RecurrenceBridgeOddFiveFour.finite_certificate` in Lean. It has no axioms.
The reductions themselves are ordinary mathematics here.

Initially both cohorts have potential C(h), and at capture both potentials
are zero. Summing (3) gives T>=ceil(C(h)/2), which evaluates to (1).

For attainment, sweep the majority cohort first using the exact prefixes.
Its first two full allocations give

    (h+1,0) -> (h-2,1) -> (h-3,0).

From a parity-zero count b>=9, two further full allocations give
(b-2,1) then (b-3,0). The final parity-zero counts 6,7,8 have tails

    6 -> 4 -> 0;
    7 -> 5 -> 3 -> 0;
    8 -> 6 -> 4 -> 0.

The solo duration L is 2t-2,2t-1,2t-1 for h=3t,3t+1,3t+2. In the latter
two cases L is odd, so the untouched other cohort is majority when its
sweep starts and uses the same L-day construction. In the first case L
is even; the minority solo sweep also takes L days: its first allocation
gives majority size h-1, followed by the same three-unit pair reduction
and the size-eight tail. Thus two solos take 2L=ceil(C(h)/2), as claimed.

## 3. Five probes: an affine formula

**Theorem (ordinary proof; awaiting independent review).** For every odd n>=5,

    T_5(P_5 square P_n)=2n-2.                               (4)

For b<=5 put K(b,z)=b. For b>=6 put

    K(b,0)=2b-6 if b mod5 is0or3, and 2b-5 otherwise;
    K(b,1)=2b-5 if b mod5 is0or2, and 2b-4 otherwise.

Set C=2h-5 and

    W_h(b,z)=2h-6                         if z=0,b=h,
             min(C,K(b,z))                otherwise.        (5)

For h>=12, h=2(mod5), the same physical domain and every p<=5,

    W_h(b,z)<=p+W_h(g_z((b-p)_+),1-z).                      (6)

Again there is a finite reduction, not a finite extrapolation. For h>=22
and b>=13 reduce (h,b) by (5,5). The reduced survivor is at least three,
so the profile translates by five. The source potential translates by ten.
An E-to-O target is at least ten and an O-to-E target at least eleven;
K(b'+5,z')=K(b',z')+10 also holds at the sole reduced endpoint (b',z')=(5,1).
Thus the target potential also translates by ten. For b<=12 reduce h alone
by five. At the reduced h>=17, survivor sizes at most twelve do not use the
near-full profile clauses, target sizes are at most fifteen, and the cap
is at least29 whereas the interior values are at most26. Both sides remain
unchanged. Only h=12,17 remain. The entire bounded arithmetic base is
`RecurrenceBridgeOddFiveFive.finite_certificate`; it has no axioms.

Both initial potentials are C, giving
T>=ceil(2C/5)=2n-2 because h=5q+2 and n=2q+1.

For attainment, a majority solo starts
(h+1,0)->(h-2,1)->(h-4,0).
At a parity-zero count b>=11, two full allocations give (b-3,1) then
(b-5,0). Since h=5q+2, after the first pair the count is h-4=5q-2;
repeat until parity-zero size eight, whose tail is 8->5->0.
The total is 2+2(q-2)+2=2q=n-1 days, which is even. The minority solo
starts (h,1)->(h-2,0); repeat the same pairs until parity-zero size ten,
then use the three-round tail 10->7->4->0. Its duration is
1+2(q-2)+3=2q as well. Two successive solos
attain 4q=2n-2 days.

## 4. Candidate for all larger budgets

For m>=5 below the two-day threshold h, write

    5n-6=qD+r, D=2m-5, 0<=r<D,
    J(0)=0,J(1)=2,J(2)=3,J(3)=J(4)=4,
    J(r)=ceil((r+5)/2) for r>=5.

The baseline is the same formula as for even-length five-row boards:

    B=2q if r=0; 2q+1 if r>0 and 2J(r)<=m; 2q+2 otherwise.

The candidate odd-length answer is B+epsilon, where epsilon=1 precisely
when m is even and one of the following holds:

    m=6,r=2;   m=8,r=4;   m>=10,r=m-5.                     (7)

Budgets h<=m<2h+1 have time two; m>=2h+1 has time one. The existing
three-probe theorem and Sections2--3 handle the smaller budgets.

The exact count recurrence agrees with this candidate in 4,080 cases:
every odd 5<=n<=81 and every nontrivial budget, plus n101,151,201 at budgets
4..24. Receipt: `recurrence-bridge-odd-five-formula-checks.json`.

For the larger-budget lower bound reuse the previously proved interior
ammunition function F_m(u) from the even-five proof. Put

    C=min(F_m(2h+1),4+F_m(2h-3)),
    A=min(C,F_m(2h),3+F_m(2h-3)).
    Phi(b,z)=A if z=0,b=h; min(C,F_m(2b+z)) otherwise.

Every actual transition lowers this potential by at most its useful
allocation. The bulk and small-source verification is exactly the previous
movement-five residue argument. The only additional proper near-full
improvement is majority size h with three probes, which is the new term A.
Detailed endpoint exhaustion and the equality case are being written next.

For m>=6 direct remainder evaluation gives C=qm+J(r). For m=5 the only
exceptional remainder is three; physical h=2(mod5) forces r=4, so the same
identity holds. Consequently ceil(2C/m)=B. The eleven observed cases where
this lower bound misses the exact answer all have exact ammunition equality
2C=(2q+1)m, and are exactly (7).

No serial-normal-form assumption enters this lower-bound approach. The
remaining obstruction should come from tight transitions: in the generic
case both cohorts must start in the minority parity, and each tight
nonterminal step lowers the ammunition quotient by exactly one. The small
budgets six and eight have different allowed initial tight allocations;
their shared-round budget should be incompatible instead.

## 5. Failed approaches and computational limits

A direct enormous Lean case split for the four-probe universal inequality
was stopped after its simplifier expanded too many redundant branches.
It produced no result and is not evidence for the theorem. The successful
replacement is the explicit length/state translation above followed by a
small kernel-checked base. It is both faster and makes the source of
unbounded validity visible.

The ammunition function is experimentally the exact minimum total useful
probes for a single cohort, but only its lower-potential property is needed.
Weighted shortest-path experiments do not establish a strategy-normal-form
theorem or justify any unbounded claim by themselves.

## 6. Completed larger-budget lower potential

This section supplies the endpoint verification omitted from Section4. Use

    D=2m-5,
    j(u)=floor((u-7)_+/D), s(u)=((u-7)_+ modD)+1,
    F(u)=floor((u+5j(u))/2)-1_[j(u)>=1,s(u) in{1,2,4}].

The earlier even-five residue proof establishes, for m>=5:

* F is nondecreasing; F(u+1)-F(u)<=2 and F(u+2)-F(u)<=3.
* floor(u/2)<=m implies F(u)=floor(u/2).
* If p<=m and floor(u/2)>p, then F(u)<=p+F(u-2p+5).

Let C,A,Phi be as in Section4. The exceptional value A lies between
min(C,F(2h-2)) and min(C,F(2h)), so Phi is nondecreasing in each physical
parity's cardinality. The first bound uses F(2h-2)<=2+F(2h-3).
This also permits direct transfer from minimum profiles to arbitrary supports.

The ordinary bulk transition has rank u->u-2p+5. The same inequality applies
after clipping by C, unless the target is the corrected majority count h.
Small survivors require only the following familiar values:

    F(2m+2)=m+2; F(2m+3)=m+3;
    F(2m+4)=m+4; F(2m+5)=m+4.

The majority singleton has target size two and the minority survivors of
size one or two have target sizes three or four. These values prove their
transition inequalities; when the source size is at most m, plain
cardinality suffices. Capture uses F(2b+z)=b.

Here is the complete high-end check:

1. **Corrected source (h,0).** Allocations zero and one reach full minority.
   Allocation two reaches minority h-1 and uses F(2h)<=2+F(2h-1).
   Allocation three reaches minority h-2 and is paid by A<=3+F(2h-3).
   All allocations at least four use the bulk or low-end argument.
2. **Corrected target (h,0).** Its minority survivor has size h-2 or h-3.
   If the survivor is h-2, useful allocations are 0,1,2; the source ranks
   are 2h-3,2h-1,2h+1. Their bounds by p+A follow respectively from
   F(2h-3)<=A; F(2h-1)<=1+A; and C<=2+A. For the middle inequality use
   the two-rank increment bound on the term 3+F(2h-3). For the final one
   use C<=2+F(2h) and C<=4+F(2h-3). Survivor h-3 gives allocations0..3
   and no stronger source bound.
3. **Proper majority surplus one.** Survivor sizes h-1,h-2 give a target
   rank at least the source rank. At survivor h-3, the only decreasing
   proper-source case is (h-1,0),p=2 ->(h-2,1), a one-rank decrease
   paid by the at-most-two increment bound.
4. **Full majority.** Allocations0..2 reach full minority. Allocation three
   reaches minority h-1, paid by C<=3+F(2h-1). Allocation four reaches
   minority h-2, paid by C<=4+F(2h-3). Larger allocations use the bulk or
   low-end inequality. Full minority at zero allocation stays full.
5. **Other minority surplus-two high endpoints.** Survivor h-1 reaches
   full majority. Survivor h-2 is already in item2. There are no others.

In these statements each F target may be replaced by min(C,F), because
source potential is at most C. Thus every physical transition obeys
Phi(b,z)<=p+Phi(b',1-z), including all cap corrections.

For physical h and m>=5, writing 2h-5=qD+r gives

    C=F(2h+1)=qm+J(r).                                    (8)

To evaluate the minimum defining C, shifting the positive remainder by four
shows 4+F(2h-3)>=F(2h+1) for every m>=6. For m=5 the only possible saving
is at r=3 (and requires a positive earlier quotient); physical h=2(mod5)
forces r=4. The first-quotient boundary only increases the shifted value,
so introduces no further exception. Both initial potentials equal C.
Therefore every strategy takes at least B=ceil(2C/m) days.

The proof was separately attacked on 6,951,682 transitions over every
12<=h<=72 and every 5<=m<h, including nonphysical h residues; no failure
was found. The arithmetic argument above is independent of this finite check.

## 7. The exact extra day: equality and active intervals

Suppose r>0 and the baseline B=2q+1. A further day is needed only when
m=2J(r) and delta(r)=1; these are exactly the three cases (7).
Then 2C=(2q+1)m. A successful (2q+1)-day schedule would use the full useful
budget each day, and every individual potential inequality would be tight.

By the proved exactness of the count recurrence, any hypothetical optimal
physical schedule can be replaced by a prefix schedule of the same minimum
duration. In this section every transition is therefore an exact profile
transition. We do not infer quotient equality for an arbitrary larger
neighborhood merely from equality of its clipped potential.

The following tightness facts follow from the same F residue row. We give
all exceptional high-end cases so the argument is independently checkable.

**Full-state tight starts.** Zero allocations are tight while the cohort is
full. The positive tight allocations are:

| Critical case | Majority full | Minority full |
|---|---|---|
| m=6,r=2 | 3 or4 | 5 or6 |
| m=8,r=4 | 4 | 8 |
| even m>=12,r=m-5 | none | every p with m/2<=p<=m |

There is no physical critical case at m=10: D=15 and r=5 would contradict
2h-5=5n-6=4(mod5). The table is a direct substitution into the two full
profiles and (8). In the last row, a minority start has remainder
r+2(m-p), whereas a majority bulk start has r+2(m-p)+1. The latter gives
one unit of strict slack; the former is tight exactly from p=m/2 onward.
The small allocations1..4 use the displayed endpoint profiles directly.
Every positive tight start lowers j(2b+z) from q to q-1.

For an explicit check of the unbounded row, let m>=12. A majority bulk
start with p<=m/2 keeps the quotient q and has positive remainder
m+1-2p; its cost exceeds C. For p>m/2 it has quotient q-1 and even
remainder 3m-4-2p>=m-4>=8, so its cost is exactly C+1. A minority bulk
start with p<m/2 has remainder m-2p and cost greater than C. At p=m/2
its new remainder is zero and its cost is C. For p>m/2 its quotient is
q-1 and its odd remainder is 3m-5-2p>=m-5>=7, again giving cost C.
Allocations1..4 are the already listed finite profile endpoints. For
m6 and m8 the same substitution has fixed denominators7 and11 and
produces exactly the finite allocation sets in the table.

**A proper tight transition.** Once a positive allocation has occurred,
potential is strictly below C and can never return to C along tight moves.
For every subsequent noncapture tight move,

    j(2b+z)=j(2b'+1-z)+1.                                 (9)

A tight capture has source quotient zero. No zero allocation can be tight
from such a nonempty proper state.

For the bulk proof of (9), if p>=3 and the quotient does not decrease, the
uncorrected F inequality has slack at least two; changing its discount can
save at most one. Thus equality forces a quotient decrease. Its decrease
is at most one because 2p-5<=D. Allocations1,2 do not decrease rank, while
allocation zero increases a proper rank by at least three and strictly
increases F. For a small-survivor exception, a noncaptured source of size
at most m gives strict cardinality slack. The remaining source sizes are
m+1 or m+2, with quotient one, and their target has quotient zero. A
capture itself has size at most m and hence quotient zero.

The remaining high-end nonbulk tight transitions, with potential<C, are
exactly

    m6: (h,0),p2 ->(h-1,1); (h,0),p3 ->(h-2,1);
    m8: (h-1,0),p2 ->(h-2,1); (h,0),p3 ->(h-2,1).

Their quotients explicitly drop from q to q-1. At m6 the corrected A
already equals F(2h); at m8, A=C-1 while F(2h)=C, and the second listed
transition is its only additional corrected-source equality. In the
generic critical case A=C, so the corrected state cannot occur after a
positive tight allocation. There are no tight moves into that corrected
state from a proper state of potential<C. These finite endpoint checks
complete (9), without a support-shape assumption beyond the proved exact
count recurrence.

Consequently each cohort is active on exactly q+1 consecutive days: its
first positive tight move leaves quotient q-1, each further noncapture
move lowers it by one, and its final capture occurs from quotient zero.
The two active intervals must cover the entire horizon because every day
uses m useful probes. Two intervals of length q+1 covering 2q+1 days
therefore overlap on exactly one day and start on days0 andq.

In the generic case, r=m-5 is odd and 2h-5 is odd, so q is even. Both
cohorts must start in minority parity, but their initial parities differ
and their starting days0,q have the same parity. This is impossible.

In the small cases, r is even and q is odd. On day0 the full allocation m
can only go to the minority cohort, by the full-start table. The second
cohort is also minority when it starts on dayq. It then needs at least
five of six probes, or all eight probes, respectively. The first cohort's
final allocation is at least m/2: its total C=qm+m/2 cannot be paid by its
preceding q days plus fewer probes. The shared-day total exceeds m. This
is again impossible. Therefore all cases (7) need the extra day.

## 8. Uniform attaining schedules at every larger budget

The all-budget answer, now with the lower argument supplied, is

    T_m = 2q                    if r=0;
          2q+1                  if r>0 and m>=2J(r)+delta(r);
          2q+2                  otherwise,                 (10)

where delta(r)=1 for r in{1,2,4} or odd r>=5, and zero otherwise.
This includes (4). Independent review of Sections6--8 is requested.

A useful exact auxiliary recurrence is the **low-corner q-shot capacity**.
For the uncapped low-end profile functions g_0(k)=k+1_[k=1]+2_[k>=2] and
 g_1(k)=k+2_[1<=k<=2]+3_[k>=3], the largest parity-z count clearable by
q>=1 full allocations is

    K_z(q)=floor((q(2m-5)+6-z)/2).                          (11)

For q=1 this is m. For the induction step, the current survivor can be
as large as K_(1-z)(q)-(2+z), since each target capacity is at least
m>=5; add m inspected cells. This proves (11) directly. The finite-board
profiles are no larger, so rank at most qD+6 is also sufficient on the
actual board. This supplies an exact partial-state recurrence and its
closed solution, rather than guessing the total-time formula.

Start the minority cohort and make q full allocations. If r=0 it is
captured. Here q is odd, so the other initial cohort is minority when its
q-day sweep begins; this gives 2q days.

If r>0, the first cohort has exactly J(r) remaining vertices after q full
allocations. Before the last full allocation its survivor size is r/2
in minority parity for even r, and (r+1)/2 in majority parity for odd r.
The small-survivor profile entries give J(1),J(2),J(4); the bulk gives
all other J values.

On the shared day the other full cohort is minority if r is even and
majority if r is odd. The following initial allocations reduce its rank
by at least r and hence put it within q further full allocations by (11):

    minority: 2 at r1, 4 at r2/r3, 5 at r4, J(r) at r>=5;
    majority: 3 at r1/r2, 4 at r3/r4, ceil((r+6)/2) at r>=5.

Only the even-r minority row and odd-r majority row are used. Their
needed allocation is exactly J(r)+delta(r). Thus the single shared day
uses 2J(r)+delta(r) probes, proving the second branch of (10). These
partial allocations are at most m-J(r)<=m-2<h-2, so their survivors do
not enter the unlisted small near-total-allocation exceptions.

If sharing is unavailable, use two solo sweeps of q+1 full days. A
majority solo after q full days has residual J(r)+delta(r), while a
minority solo has J(r); both are at most m. Hence both solo parities
clear within q+1 days, independently of the parity at which the second
cohort starts. This proves the last branch.

`direct_strategy` emits actual room-coordinate schedules from this formula
and replays them against the complete possible-position set; it does not
search over strategies. The separate receipt tests every odd n5..51 and
every budget3..5n. This is additional construction verification, separate
from the universal proof and the independent lower-bound audit.

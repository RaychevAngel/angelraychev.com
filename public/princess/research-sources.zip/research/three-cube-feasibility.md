# Five probes are necessary and sufficient on the 3 × 3 × 3 cube

Independent proof and construction, 12 September 2026 UTC.

**Result.** For the mandatory-move game on $P_3\square P_3\square P_3$,
the minimum feasible daily budget is five. Four probes cannot guarantee capture.
Five probes admit an explicit eighteen-day strategy.

This is a result established in the present investigation, **not a claim of
priority**. A search for previous publication of this particular cube value
remains necessary. Eighteen is an upper bound for full-board capture time here;
this note does not prove it optimal.

## The geometric lower bound

Write the vertices as $(x,y,z)\in\{0,1,2\}^3$, with adjacency given by changing
one coordinate by one. The parity of $x+y+z$ gives the bipartition. Throughout,
$N(A)$ means the union of the individual neighbor sets of vertices in $A$.

**Triple lemma.** Any three distinct vertices of the same parity have at least
seven neighbors in total.

We first record two simple observations.

1. Two distinct same-parity vertices have at most two common neighbors.
   If they have any, their Manhattan distance is two. If they differ by two
   in a single coordinate, their common neighbor is unique. If they differ by
   one in each of two coordinates, there are two common neighbors.
2. If each pair of three distinct same-parity vertices has a common neighbor,
   all three have a common neighbor. Indeed all three pairwise Manhattan
   distances are two. Their coordinatewise median $q$ lies on a shortest path
   between each pair. Writing $d_i=d(q,v_i)$ gives
   $d_1+d_2=d_1+d_3=d_2+d_3=2$, hence $d_1=d_2=d_3=1$.

The degree of a vertex is three plus the number of its coordinates equal to
one. We now apply inclusion-exclusion to the three neighbor sets.

- **Odd parity.** Every vertex has degree at least four. The sum of the degrees
  is at least twelve, and the sum of the three pairwise overlaps is at most
  six. If the latter is at most five, the union has size at least seven.
  If it equals six, every pair overlaps; observation 2 supplies a triple
  intersection, again giving at least $12-6+1=7$ neighbors.
- **Even parity, at least two face centers.** Even vertices are either corners,
  of degree three, or face centers, of degree five. With at least two face
  centers the degree sum is at least thirteen. Subtracting at most six pairwise
  overlaps gives at least seven neighbors.
- **Even parity, exactly one face center.** The degree sum is eleven. Two
  distinct corners have at most one common neighbor, so the total pairwise
  overlap is at most $1+2+2=5$. If it is at most four, we obtain seven directly;
  if it equals five, observation 2 adds a triple intersection, giving
  $11-5+1=7$.
- **Three corners.** The degree sum is nine. A pair of corners has a common
  neighbor precisely when the corners differ in exactly one coordinate.
  These pairs are the edges of an ordinary cube, which contains no triangle.
  Thus at most two of the three pairs overlap, and their union has size at
  least $9-2=7$.

These cases exhaust both parity classes and prove the lemma.

**Four-probe impossibility.** Consider a belief contained in one parity class
and having at least seven vertices. After at most four inspections, at least
three of its vertices remain. By the triple lemma, their possible next
positions include at least seven vertices. All these new positions belong
to the other parity class.

Therefore the family

$$
\mathcal U=\{B:B\text{ is contained in one parity class and }|B|\ge7\}
$$

is a trap: every legal inspection and compulsory move keeps the belief inside
it, while the empty belief lies outside it. Starting from either full parity
class—of sizes fourteen and thirteen—capture is impossible with four probes.
Consequently it is also impossible from the full board. This is an infinite-time
obstruction, not merely a failure to find a sufficiently short strategy.

## An explicit eighteen-day strategy with five probes

Let $O=\{(x,y,z):x+y+z\text{ is odd}\}$. The following nine-day sequence clears
every trajectory starting in $O$. In the table, xyz abbreviates $(x,y,z)$.
The third column is the number of possible rooms **after the miss and move**,
starting with all thirteen rooms of $O$.

| Day | Five inspected rooms | Next belief size |
|---:|---|---:|
| 1 | 001, 010, 012, 100, 102 | 12 |
| 2 | 011, 020, 101, 110, 200 | 10 |
| 3 | 012, 021, 102, 111, 120 | 10 |
| 4 | 022, 101, 110, 112, 121 | 9 |
| 5 | 100, 102, 111, 120, 122 | 9 |
| 6 | 101, 110, 112, 121, 200 | 8 |
| 7 | 102, 111, 120, 201, 210 | 7 |
| 8 | 022, 112, 121, 202, 211 | 5 |
| 9 | 120, 122, 210, 212, 221 | 0 |

For complete transparency, the possible-position sets after each round are
saved in research/three-cube-independent-checks.json; they can also be
recomputed directly by $B_{t+1}=N(B_t\setminus S_t)$.

**Repeat these nine days once, without modification.** After the first nine
days, no trajectory starting in $O$ survives. A trajectory starting in the even
class has made an odd number of moves, so its current room is in $O$. The
second copy of the same sequence captures all such trajectories. Thus eighteen
days suffice from the full twenty-seven-room board.

Direct full-board replay gives successive belief sizes

$$
27,\ 25,\ 24,\ 23,\ 23,\ 22,\ 22,\ 20,\ 19,\ 13,\
12,\ 10,\ 10,\ 9,\ 9,\ 8,\ 7,\ 5,\ 0.
$$

The source search found the nine-day sequence by exact one-cohort dynamic
programming. The upper-bound proof only requires checking this explicit
sequence, not trusting the search or its assertion of optimality.

## Independent checks and proof boundary

The script src/three_cube_independent.py rebuilds the physical graph directly
from Manhattan distance, without importing the searcher's adjacency or
transition tables. It checks all $364+286=650$ same-parity triples, the geometric
pair-overlap and median facts, the nine-day odd-cohort witness, and the
eighteen-day full-board witness.

The earlier searcher's one-cohort optimal times are ten days for the even class
and nine for the odd class. Those numbers are not needed for the feasibility
theorem proved here, and do not establish the optimal full-board time.

The file lean/ThreeCubeTrap.lean uses the physical coordinate graph, with a room
encoded as $9x+3y+z$. Its kernel-evaluated triple theorem covers all distinct
same-parity triples, independently of the geometric presentation. Its finite
schedule certificate checks the actual twenty-seven-room transitions, and a
proved bridge connects that certificate with capture of every actual surviving
walk using legal probe sets of at most five rooms. No extra axioms or admitted
proofs are used.

The companion file lean/ThreeCubeLower.lean completes the cardinality bridge:
it selects three distinct surviving rooms, applies the triple theorem, proves
the seven-room trap survives every legal inspection, and connects this
obstruction to arbitrary actual target walks. It also converts the upper
strategy's list representation into the same finite-set cardinality budget.

The final theorem, Princess.ThreeCubeLower.feasible_iff_five_le, states that
for every natural daily budget $m$, a finite guaranteed capture strategy exists
on the full physical board if and only if $5\le m$. Thus the feasibility
classification $h(P_3^3)=5$ now has a complete Lean proof as well as the geometric
proof above. It does not assert an optimal full-board capture time.

# Independent review: every even 3×3×n cylinder at five inspections

12 September 2026. **Verdict: passed.**

The ordinary theorem in `even-three-by-three-cylinder-time.md` establishes

    T5(P3 × P3 × Pn) = 18n − 36, for every even n >= 4.

Together with the earlier independently reviewed odd-length theorem, this
gives the same exact formula for every integer n >= 3. This review covers
the historical scalar potential, its unrestricted-strategy interpretation,
and the unbounded physical upper construction. The separate geometry audit
is recorded in `even-cube-cylinder-profile-independent-review.json`.
There is no claim that this new unbounded theorem has a complete Lean proof.

## Arbitrary physical histories and the daily charge

Put h=9n/2. The lower profile and the incompatibility of two consecutive
critical survivors are the necessary geometric inputs. For each initial
parity cohort, the current bit records whether its immediately preceding
survivor was critical. It therefore begins at zero, and a marked current
count lies in [8,h−4]. Its own useful inspections are counted by p, so the
survivor size is exactly s=k−p. Useful allocations to the two current
cohorts sum to at most five, regardless of any irrelevant inspections.

When 4<=s<=h−8, the next state is marked precisely when its count is s+4;
otherwise its count is at least s+5 and it is unmarked. A marked source
cannot have a marked successor. Outside that survivor interval, the next
state is unmarked and its count is bounded by the ordinary profile.
This is a valid relaxation of every physical schedule, including schedules
whose actual neighborhoods are substantially larger than the lower bound.
It does not presume a serial or prefix strategy for the lower bound.

The two potentials are nondecreasing on their stated domains. The scaled
charges (0,0,1,2,3,3) satisfy c(p)+c(q)<=3 for p+q<=5. Thus each verified
one-cohort inequality gives a total potential loss of at most one per day
after dividing by three. Each full initial cohort has potential 2h−18,
while an empty cohort has potential zero and remains empty. This proves
the claimed lower bound for any guaranteed capture schedule.

The critical-survivor obstruction genuinely transfers to arbitrary sets:
criticality and the profile lower bound force equality in
N(CR) subset C(NR). Cardinality preservation then makes these two sets
equal. Monotonicity carries a hypothetical second critical survivor into
the first compressed neighborhood. Without this equality step, the
canonical endpoint incompatibility alone would not have been sufficient.

## Explicit proof that the finite scalar check extends to all h

The base checks at h=18,27,36,45 cover the physically relevant small cases.
For the unbounded extension write h=45+delta with delta>=0. Every minimum
output differs from its source count by at most five. The following three
source ranges avoid any implicit assumption about a transition crossing
the inserted interval.

1. If k<=17, every minimum output is at most22. All relevant low profile
   values, potentials, and history conditions are identical to h=45.
   The base inequality applies without a translation.
2. If k>=27+delta, put k0=k−delta. The residual is at least22+delta,
   and every output minus delta is at least22. Subtracting delta from
   the source and output preserves both branches and history conditions.
   The profile translates by delta; both potentials translate by2delta.
   This is exactly the corresponding base inequality at h=45.
3. If 18<=k<=26+delta, the residual lies in
   [13,26+delta], inside [4,h−8]. All minimum source and output counts
   lie in the affine region, where F_e(k)=2k−14+e. The possible potential
   drops are 2p−9 for the transitions 0→1 and1→0, and2p−10 for0→0.
   Each is at most the displayed charge for every p=0,...,5. The
   transition1→1 is forbidden by the geometric history lemma.

The source ranges are disjoint and exhaustive. The target bounds also
respect the marked domain. This proves every minimum-output inequality
for every integer h>=45; monotonicity handles all larger actual outputs.
No finite-horizon or finite-length extrapolation is being used.

## A direct all-length physical upper, without insertion

The independent review found a shorter construction proof than the
proposed sampled-base insertion. It follows directly from the exact
physical prefix profiles in the submitted note. Their neighborhood-prefix
property holds on these even boxes and does not assert that their
neighborhood sizes are isoperimetric minima.

Start one cohort in virtual phase zero, and inspect the last five rooms
of its current prefix, or all its rooms when fewer remain. For every
h>=18 the first two days have counts

    h → h−2 → h−3,

returning to phase zero. From each phase-zero count10<=k<=h−3, the next
two days have counts

    (k,0) → (k−1,1) → (k−1,0).

There are exactly h−12 such pairs before reaching count9. The four-day
tail is

    (9,0) → (8,1) → (7,0) → (5,1) → (0,0).

For example, the pair identities use saturation of the weighted bottom
rank sums already at ranks3 and4, respectively; the later bottom ranks
have weight zero. The complementary top-rank counts have saturated by
ranks6 and8. These facts verify the identities on the entire displayed
interval, for arbitrary h>=18.

The solo duration is therefore

    2 + 2(h−12) + 4 = 2h−18 = 9n−18.

It is even. During the first sweep the uninspected opposite cohort remains
globally full: the cylinder has no isolated vertex and its full color
classes map onto one another. At the second sweep it occupies physical
phase one. Reflecting the longitudinal coordinate exchanges the physical
colors because n is even, so that cohort starts in virtual phase zero
of the reflected prefix order. The same solo sweep applies. The first
cohort is already empty, so no additional budget is needed. The total is
4h−36=18n−36. Independent reflected orders for the two cohorts are an
essential part of this stated construction.

## Independent computation

`src/even_three_by_three_cylinder_independent_review.py` imports none of
the proposed certificate, geometry, or profile modules. It checks every
allowed scalar output, not just the minimum branches, for h=18,27,36,45
and the redundant extensions46,54,145: **157,064 exact integer
inequalities**. It checks the shared charge bound and the symbolic middle
branch drops separately.

It reconstructs vertices and adjacency directly from coordinate
differences, builds the two weightlex prefix orders, checks every prefix
neighborhood, and replays both complete physical cohorts at n=4,6,8,10,12,30.
Every intermediate mixed support equals its claimed prefix plus the full
or empty companion. All six replays attain the formula. The run used
approximately0.061 CPU seconds on one worker. The receipt is
`even-three-by-three-cylinder-independent-review.json`.

The finite checks support the audit. The explicit three-range proof and
the direct sweep recurrence above establish the unbounded result.

# Independent audit: expansive-primary suffix exchange

13 September 2026. Euler review of
`maturation-odd-midpoint.md` Section 13. **PASS as an ordinary conditional
exchange lemma.** It does not establish unrestricted exceptional-output
seriality or remove the primary lower-root-collar hypothesis.

## Reviewed statement

On an odd rectangle of width 2b+1, let m>=b+1, H=b^2+1, and let
tau be the first solo capture time. Consider a legal quota history ending
at t<tau. At some time i it is a pure full-budget solo endpoint of an
initial cohort A, with the other cohort B at deficit zero. Suppose every
subsequent OLD primary inverse input is at least H. Then the final pair
is dominated by a history of the same horizon which is pure A, followed
by at most one shared day, followed by pure B.

The empty history and a pure-block history are degenerate cases. In
particular t=0 does not require an actual shared day. For positive t the
pure case can alternatively be represented using a shared quota of zero
to one cohort. This small convention was communicated to the author.

## Proper inputs are justified independently of the exchange

Write the exact finite inverses as

    I0(z)=z-min(rho(z),b,rho(M-z)),             z<M,
    I1(z)=z-min(R(z),b+1,1+R(M+1-z)).

Before tau, an arbitrary coordinate is bounded by its full-budget solo
coordinate by monotonicity. The accepted total concentration bound gives
total deficit at the preceding layer at most the larger solo deficit.
That larger solo deficit plus m is at most M: if it were at least M+1,
its next pure step would capture, regardless of which physical color it
occupies. Therefore old primary input plus old secondary input is at most
M, even if the old schedule leaves some of the daily quota unused.

For the NEW word, its legality alone supplies coordinatewise solo
domination. At every time up to t<tau, an I0 input is strictly below M
and an I1 input is at most M. Thus its inputs are proper before any
state-comparison induction is attempted. There is no circular assumption
that the new word avoids an endpoint merely because it is meant to
dominate the old word.

## Expansion and secondary bottom dynamics

At z>=H both lower root terms have reached their caps. On proper inputs
the remaining reflected term is nonincreasing, so I_p(z)-z is
nondecreasing. Consequently

    I_p(v)-I_p(u)>=v-u   for proper v>=u>=H.

This holds across reflected-root jumps. No concavity or Lipschitz claim
about the finite inverse is being substituted for this expansion.

The old secondary input is at most M-H because the old primary input is
at least H. On [0,M-H] the reflected roots are at least their caps, so
the finite inverse is exactly the corresponding bottom inverse j_p.
Thus the old secondary is a genuine bottom growth process throughout the
suffix, starting from zero with its fixed actual initial-cohort phase.

Let its final count be k, its final physical phase p, suffix length r,
and old total secondary quota Q. The accepted single-cohort ammunition
theorem gives an exact-target schedule of cost mu_p(k)<=Q and length
ceil(mu_p(k)/m)<=r. For k>0 its positive quotas are one partial first
quota followed by full quotas. Pad it with zeros at the beginning.
Fixing final phase p and total length r automatically fixes the initial
phase to p-r, which is exactly B's original phase. This does not use a
free change of initial cohort.

## Cumulative quotas give the required stronger state comparison

For the latest-packed secondary schedule, at each prefix s of the suffix,

    Q_new(s)=max(0,mu-m(r-s))
            <=max(0,Q-m(r-s))<=Q_old(s).

Give the complementary quota to A. Its cumulative new quota is at least
its old cumulative quota, including when the old history used less than
the full daily budget. Define Delta_s as this difference. It is
nonnegative at every prefix, although individual quota differences may
have either sign.

The inductive claim is stronger than coordinatewise domination:

    a_new(s)-a_old(s)>=Delta_s.

It is equality at the pure endpoint. At the next step, adding the new
minus old quota gives an input difference at least Delta_(s+1)>=0.
The old input is at least H, both inputs are proper by the preceding
independent argument, and expansion gives the desired next state
difference. This verifies the nontrivial scheduling exchange; plain
monotonicity without this stronger invariant would not suffice.

## Why the packed secondary stays in the finite bottom region

The ammunition recurrence constructs an exact-target schedule whose LAST
input is precisely the least inverse input L_p(k), not merely some input
that overshoots k. The old final bottom transition attained k, hence
L_p(k) is at most its old input and therefore at most M-H.

Every full-quota bottom map sends v to at least v because m>=b+1 bounds
both loss caps. Inputs during the packed positive block are consequently
nondecreasing. The first partial input is at most m and cannot exceed
the following full input. Hence EVERY new secondary input is at most
its last input L_p(k)<=M-H. Its finite-board evolution is exactly the
constructed bottom evolution, with final output k. The primary weakly
improves and the secondary ends unchanged.

Before the first positive B quota all quota goes to A, extending its
original pure endpoint. After that first shared day all quota goes to B.
Replacing the prefix before time i by the pure A history reaches the same
endpoint, so the entire word has the claimed two-block form and horizon.

## Boundary of the conclusion

The hypothesis concerns every old primary INPUT during the suffix,
not only its initial or final size. No assertion that actual exceptional
histories automatically satisfy it has been proved here. If an old input
enters the lower-root collar, the primary expansion may fail and the
cumulative-quota argument no longer applies. The known low-total
two-block counterexample therefore does not conflict with this lemma.

No numerical experiment or new Lean claim is used in this audit.

# A finite-board corner-count restriction below the strip surplus

13 September 2026. Ordinary theorem independently reviewed and accepted
by the parent. No Lean claim is made. This is a necessary static inequality for
**every physical one-color support**, not an assertion that corner counts
classify every support or that individual profile minimizers can be chained.

## Statement

Let G=P_w x P_n, where 2<=w<=n and wn is even. Put b=floor(w/2)
and h=wn/2. Either side may be the even one. Each physical color has
h rooms and contains exactly two of the four board corners. For a support S in one color, write

    a=|S|,  s=|N(S)|-|S|,
    i=number of corners of S's color contained in S,
    j=number of opposite-color corners contained in N(S).

Thus 0<=i,j<=2. Neighborhoods are taken in the entire finite board.
Put C_2(s)=max(s(s-1)/2,s(s-2)). Define the following bounded-expression
capacity, with -infinity for an impossible argument:

    F_(i,j)(s) = -infinity                         if s<i+2j;
    F_(i,j)(s) = i+2j-2
                  +(s-i-2j+2)(s-i-2j+1)           if j>=1;
    F_(i,0)(s) = i-1+(s-i+1)^2                    if i>=1;
    F_(0,0)(s) = C_2(s).

The first case has priority, so negative arguments are impossible.
Define the dual bound, using at most three explicitly listed candidates,

    G_(i,j)(s) = max_{0<=d<=2-i} F_(2-j,d)(s-2+i+d).

This maximum is a fixed finite case distinction: the candidate d values
are always among 0,1,2; it is not a parameter-length optimization.

**Theorem.** If 0<=s<b, then

    a <= F_(i,j)(s)
    OR
    h-a-s <= G_(i,j)(s).                         (1)

The theorem includes the empty and full support endpoints. It strengthens
the previous size-only dichotomy a<=s^2 or h-a<=s(s+1). At surplus s>=b,
(1) is not asserted; the existing unrestricted static profile still applies.
The matching proof therefore covers odd-width/even-length boards too; it
does not rely on the smaller side being even.

## Proof: the finite board really separates into four quadrants

Use the already proved matching contraction from
`paper/sections/even-rectangle-profiles.tex`. Choose an even side e and let o be the other side. The directed graph D
has e/2 matched rows and o columns, bidirectional edges along every row, and
vertical rungs whose direction alternates with the column parity. For the
contracted support R, let B=N_D^+(R) minus R. Thus |B|=s, and R is
outgoing-closed in D-B.

Since e/2>=b>s, some matched row avoids B. Since o>=2b>=2s+2,
some two consecutive columns avoid B. The two columns form a strongly connected
ladder and meet every entirely undeleted row. Therefore all such rows
and all such pairs of columns belong to one strongly connected component
C of D-B. Outgoing closure implies that R either contains C or avoids C.

Suppose first that R avoids C. Select one undeleted matched row and one
pair of consecutive undeleted columns. They contain neither R nor B.
In physical coordinates the empty matched row supplies two consecutive
transverse rows, and the empty columns supply two consecutive longitudinal
columns. Neither S nor its neighborhood occupies those separators.

Split S into the four resulting corner pieces, permitting empty pieces.
Their neighborhoods are disjoint: across either separator, one piece's
one-step neighborhood ends no farther than the first empty row/column,
while the opposing neighborhood starts no earlier than the second.
Each piece has exactly the same neighborhood when viewed in the whole
quadrant based at its board corner. The two actual board edges are the
quadrant axes; the separator keeps both the support and its neighborhood
away from the other two physical board edges. This checks both ends of
the finite board, rather than applying a half-strip bound without its guard.
Hence the four cardinalities and their nonnegative surpluses add.

The two corners of the source color give even-color quadrant pieces.
If such a corner belongs to S, its piece has surplus at least one and
capacity C_0(u)=u^2. If it does not, the origin is forbidden and its
capacity is C_2(u). The two opposite-color board corners give odd-color
quadrant pieces. If such a corner belongs to N(S), its piece is nonempty,
has surplus at least two, and has capacity C_1(u)=u(u-1). If it does not,
both odd neighbors of its origin are forbidden, giving capacity C_3(u).
Here the C_l are the already proved punctured-quadrant capacities

    C_l(u)=max(u(u-1)/2,u(u-l)).

These are upper bounds for the pieces regardless of their shape.

There are i required even-origin pieces and j required odd-origin pieces,
so their mandatory surplus is i+2j. All four capacity functions are
nondecreasing and discretely convex. Subject to those lower bounds and
total surplus s, their sum is maximized by allocating all surplus left
over to a single piece. To see this directly, fix the other two pieces;
the convex sum for any two variable pieces attains its maximum at an
endpoint of their allocation interval. Repeatedly shift to such an endpoint.
Only four candidate recipients remain.

Write z=s-i-2j. A required even piece contributes excess capacity
(z+1)^2-1=z^2+2z over its mandatory one room. A required odd piece
contributes (z+2)(z+1)-2=z^2+3z over its mandatory two rooms. An optional
omitted-origin piece contributes at most C_2(z)<=z^2; an optional
omitted-odd-neighbors piece contributes C_3(z)<=C_2(z). Thus a required
odd piece is the largest recipient if j>0, a required even piece is
largest if j=0<i, and an omitted-even-origin piece is largest if i=j=0.
This gives precisely F_(i,j)(s), proving the first branch when R avoids C.

## Proof: the co-small branch and the missing-corner slack

Suppose now R contains C, and put

    U=V_(opposite color) minus N(S),
    u=|U|=h-a-s,
    t=|N(U)|-|U|.

Then N(U) is contained in V_(source color) minus S, so 0<=t<=s.
In the transposed matching contraction, U is outgoing-closed outside B
and avoids the same component C. The identical empty-row/empty-column
split applies to U. Its source-corner count is exactly 2-j. Let d be its
outgoing-corner count. Since N(U) avoids S, one has 0<=d<=2-i.
The just-proved four-quadrant bound gives

    u<=F_(2-j,d)(t).

The corner information gives more than the coarse t<=s. The set

    (V_(source color) minus S) minus N(U)

has exactly s-t rooms. It contains every source-color board corner
that is neither in S nor in N(U); there are exactly 2-i-d such corners.
Consequently

    t<=s-(2-i-d).

Monotonicity of F in its surplus argument gives
u<=F_(2-j,d)(s-2+i+d)<=G_(i,j)(s). This proves the second branch
and completes the proof of (1). The slack term is essential: omitting
it would lose the 8x8 exclusion described below. QED.

## Direct consequence for an inspection step

Let A be an arbitrary one-color belief, with K=|A| and c of its two
current-color board corners present. Inspect p useful rooms, leaving
S subset A of size a=K-p. If S contains i source-colored corners, then

    i<=c<=i+p.

Put the next belief size K'=|N(S)|, its corner count j, and s=K'-a.
When s<b, the transition must satisfy (1) for some integer i in {0,1,2}
satisfying this inspection bookkeeping. For s>=b retain the previous
size-only profile. This gives a uniform necessary transition relaxation
using only size and current corner count. Every physical transition is
included, without a compression theorem. The relaxation need not be
sharp or sufficient to construct a strategy.

For 8x8 with daily budget five, take K=25 and c=1. A proposed next size
23 requires a>=20 and s<=3. At the least possible survivor size a=20,
s=3, the first branch of (1) is too small for every i<=1. The dual
branch also fails: for i=1, j=0 gives dual capacity two,
j=1 gives dual capacity four, and j=2 gives dual capacity six; but
h-a-s=9. The possibilities i=0 are no larger. Larger a gives no escape: a=21,...,23 gives s=2,...,0,
with both a>s^2 and h-a>s(s+1), contradicting the original static
profile. Values a>23 have negative surplus. Thus
this direction captures the missing-corner obstruction to 25->23.
This is a transition exclusion, not yet a complete uniform capture-time law.

## Evidence, limits, and next question

The accompanying focused checker directly enumerates all one-color
subsets, both colors, on 2x2,2x3,3x4,4x4,4x5,4x6,5x6,6x6. It verifies
(1) on every subcritical support; the exact counts and CPU duration are
recorded in `research/resumed-even-corner-profile-check.json`. No pyramid restriction is used in this check.
The ordinary proof above covers all widths and lengths; finite checks
only test for transcription or small-endpoint mistakes.

Separately, the rectangle agent checked (1) on all 63 subcritical
physical pyramid profile triples for 8x8 and all 276 for 12x12. Both
passed. Those checks test the formula against the earlier independent
height-state data, but they are not the proof of unrestricted validity.

The unresolved geometric case is s=b. When the shorter side is even,
a clean matched row need not exist then. If every row contains one boundary vertex, the row sets are
prefixes, suffixes, empty, or full except one point. Controlling their
corner conditions uniformly requires a separate critical-surplus
argument. This note makes no claim about that case or about parameter-
independent capture-time formulas. Root and the rectangle agent are
independently reviewing the theorem and testing its time-bound strength.

## Independent review and manuscript handoff

The parent independently checked and accepted the universal argument on
13 September 2026: physical separators from the matching contraction, the
transposed U branch, mandatory-surplus convex capacity allocation, and
the dual missing-corner slack. Its proof does not rely on exact partial
states or the finite computational checks. The parent separately derived
the same dual inequality.

A concise manuscript-ready source is preserved in
`paper/sections/resumed-even-corner-profile.tex`. It is not wired into the
manuscript entrypoint by this subagent. Its six new labels use
`sec:finite-corner-count`, `eq:finite-corner-*`, `thm:finite-corner-count`,
and `cor:finite-corner-transition`; existing sources are unchanged.

## A bounded attack of the critical boundary

The restriction s<b cannot simply be changed to s<=b. A literal-support
check found genuine violations at s=b, summarized by their source/output
corner counts:

- 4x4: 32 violating supports across both colors, all (i,j)=(1,1).
- 4x5: 40, of types (1,1) and (2,0).
- 5x6: 36, all (2,0).
- 6x6: 248, all (1,1).

For instance the (1,1) channel describes a front reaching both sides of an
even transverse section; it is allowed in the strip middle and cannot be
bounded by a corner capacity independent of the longer length. The
(2,0) channel on odd-width/even-length rectangles similarly contains a
front based at the end whose two physical corners have the source color.
The finite observations do not prove that these are all critical exceptions.

The existing exact-surplus frontier theorem does force a single oriented
front when both the support and its complement exceed 4b^2, for even
transverse width. That implies (i,j)=(1,1) there, but its collars are too
large to answer the critical near-square cases. A sharper argument would
have to analyze a boundary with one point per matched row and separate
fronts traversing the board from pieces localized at corners. The
subcritical proof's two empty separators are unavailable in general. No
new critical-surplus theorem has been established in this pass.

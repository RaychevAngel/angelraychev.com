# Phase-aware lower-frontier research

13 September 2026. Authorized research after the frozen checkpoint. This
lane owns only `research/bridge-lower-frontier*` and
`src/bridge_lower_frontier*`. No manuscript, common model, or Lean source
has been changed. No uniform matching lower or numerical classification
is claimed by this log.

## First bounded probes

`src/bridge_lower_frontier_probe.py` extracts the existing necessary model
builder with AST, avoiding unrelated numerical-library imports. It makes
the same two explicitly documented positive lower-cardinality relaxations
used in the proved merger, and optionally extends the near-pronic band
filter to every radius. Original and modified model source hashes are
recorded. Forward/backward distances are integer BFS values; every graph
edge is checked against both distances. This is finite evidence, not a
symbolic invariant or physical realization claim.

The current critical-band model gives:

- 13x14,k7: solo78, penultimate residual7, anchored solo upper78.
- 15x16,k8: solo96, penultimate residual6, anchored solo upper96.

The new all-radius filter gives solo64/residual4 on11x12 and
solo78/residual7 on13x14, so the first added filters do not improve those
full-start clocks. The upper numbers here are evaluated anchored-clock
expressions already justified geometrically; this probe does not itself
replay literal inspections.

### A correction cannot automatically be assumed nonnegative

On15x16 the old critical-band relaxation has14 partial feature states
whose exact remaining distance is one LESS than the minimum of the two
anchored clocks, although its full-start clock matches the anchored upper.
This rejects a nonnegative correction to that minimum on every model
state for this model. It does not produce a physical counterexample.
Testing whether all-radius band constraints remove these paths is next.

Update: all-radius intervals do NOT remove the14 partial-state negative
corrections on15x16. The exact necessary distances remain below the
minimum anchored clock there; this is a relaxation counterexample only.

The two earlier physical counterexamples remain mandatory tests for any
proposed Bellman potential. Neither corner counts selecting an anchor nor
pointwise minimization between anchors is being reinstated as a theorem.

## All-radius interval theorem

Full argument and independent checks are in
`bridge-lower-frontier-all-radius-proof.md`. The proof is an extension of
the accepted critical near-pronic localization argument and its merger
identity argument, not an inferred result from finite agreement. It is
independently reviewed by the root lane. Its sufficiency for a matching
full-start frontier remains unproved.

## Nine-threshold closure and the next actual model gap

An exact backward frontier theorem for a slightly weakened model is
written in `bridge-lower-frontier-nine-proof.md`. Triangle flags are
deliberately dropped; all-radius static interval rules remain. One update
uses nine scalar thresholds and a fixed number of explicit quadratic-root
branches. It replaces scanning a board-sized feature graph, while still
requiring iteration in the clock and therefore NOT satisfying the final
fixed-size numerical criterion.

The separately implemented graph builder checks every backward
state/deadline membership against the nine inequalities. The initial
three cases7x8,k4;11x12,k6;15x16,k8 pass148,841 comparisons; secondary
5x6,k3;7x8,k5;9x10,k6 pass14,151. These receipts test full frontier
equivalence, not merely the full-start clock.

A bounded four-case probe through the cheap recurrence found a real
lower-model gap at25x26,k13: solo186 versus explicit anchored188.
The corresponding reconstructed186-day model path passes a separate
primal transition validator. Its three exact pronic triangle triggers
also satisfy the original next-corner-zero restrictions, so its shorter
clock is not caused by dropping triangle flags. All positive physical
cardinality lower bounds hold along this witness as well. These facts do
NOT establish physical realizability.

An additional observed-erosion localization theorem lowers the band
threshold when target e=1; see
`bridge-lower-frontier-erosion-band-proof.md`. It changes some survivor
features in the short witness but does not close the gap. The first
size improvement over both anchored paths occurs at day28 and leaves112
holes, reproducing the old24-square near-square boundary obstruction.
That points to physical entrance timing, not another orientation choice
from the existing static features.

The all-radius theorem was independently attacked by literal support
enumeration on5x6,r2;7x8,r2;7x8,r3, covering622,726 original supports.
All qualifying supports satisfy exact surplus, one outgoing corner,
connectivity and radius; the second neighborhoods omit the required
corners. The checker uses neither capacity formulas nor compression.
This is bounded falsification evidence only.

## Near-square history and the remaining 25x26 gap

The stronger ordinary geometric result is now in
`bridge-lower-frontier-near-square-slack.md`: a strict near-square event
with target corner/erosion pair (1,2) cannot be followed by any closed
near-square event with the same target pair. The proof counts the whole
corner triangle outside the opposite triangle's neighborhood. At least
`r(r-1)/2+1 >= 2` rooms remain, while closure and maximal survivor
retention permit at most one. This replaces the weaker inner-triangle
slack inequality as the operative rule. Formation of the one-step flag
and exclusion of its successor both preserve the guarded merger by an
identity argument. Root and upper-construction lanes independently
reviewed the geometry and both merger arguments.

The exact-cost static base graph is cached in
`.build/bridge-lower-frontier-weighted-12-26-13.pickle`. It includes the
stronger observed-erosion bands and the earlier exact-pronic triangle
flags. The new flag is built from its budget-indexed transition bitsets,
avoiding repeated survivor enumeration. This is execution data; the
unflagged nine-threshold theorem is not being extended to history flags.

The strongest forbidden-pair graph on 25x26 at budget 13 still has solo
clock 186 and preterminal residual 9. It contains 2,996 states and
4,335,862 edges. Root's independently proved day-28 joint deficit bound
raises its filtered solo clock to 187, still with residual 9. The guarded
merger and `2*9>13` then give the full lower bound 374; the explicit
anchored upper bound is 376. Thus the additional local geometry is a
uniform theorem but does not finish the matching formula. The receipt
`bridge-lower-frontier-forbidden-pair-check.json` records 4,275,456 checked
forward-edge inequalities and distinguishes the time-dependent cut.

The manuscript treatment is isolated in
`../paper/sections/bridge-local-geometry.tex`, containing the all-radius
bands and the forbidden successor with their merger proofs. Its labels,
references, and environment matching were checked; manuscript integration
and compilation belong to the root lane. These are ordinary proofs and
finite verifier receipts, not new Lean results.

## Persistent corner reach closes the 25x26 instance

Continued research, without starting a publication build, reconstructed
the remaining 187-day model path. Its first size advantage was at day
172, but the missing geometry occurred earlier: an exact square survivor
of 100 rooms gives a full pronic triangle of 110 rooms at day 165, after
which the model acquired a distant corner pair before it could be
reached. The tempting later 100-to-81 triangle transfer is physically
possible in three days at quota 13 and is not a lower obstruction.

The resulting uniform invariant is two radius bounds, one for each
relative anchor color. They propagate by swapping and adding one, and
are tightened by exact square/pronic localizations. Literal corner
distances bound both corner counts and erosion counts. The per-coordinate
minimum of the two component radii proves guarded merger inheritance;
it neither identifies anchors nor relies on one component remaining full
after the localization event. Full proof and independent review notes
are in `bridge-lower-frontier-corner-reach.md`.

Using only the subcritical square triggers, the persistent model and the
joint day-28 barrier give solo clock 188 and preterminal minimum 2, hence
full lower 375. An independent search with no cross-radius dominance
checks 276,525 augmented states and confirms both values. A separate
literal replay of the physical anchored strategy with the four-room
central reflected union gives full upper 375. Thus the new exact finite
case is `T_13(25,26)=375`. Receipts:
`bridge-lower-frontier-filtered-witness-persistent.json`,
`bridge-upper-transport-persistent-verified.json`, and
`bridge-upper-transport-25x26-prefix.json`.

The numeric lane subsequently converted this to an all-length theorem
using a terminal capturable-set hull, without assuming flagged interval
closure. Its proof `bridge-boundary-numeric-25-exact.md` was independently
reviewed by this lane, as was the uniform physical upper proof
`bridge-upper-transport-odd-length.md`. Together they establish
`T_13(25,n)=50n-925` for every even n>=26. This uses a fixed finite terminal
certificate and a proved repeatable middle segment, not extrapolation
from three boards. The broader variable-width family remains open.

## Variable-width terminal attack

The next candidate theorem uses boundary K=b²+b+1 and the two physical
infinite-corner prefix clocks. A bounded probe over both even and odd b
from6 through20 (excluding18) exposed one failure of the exact-triangle
radius model at b11: its clocks from K133 were one below the physical
phase clocks. The missing reset was a99-room survivor in the100-room
corner triangle, not an exact equality. The root lane's proposed
near-square interval trigger supplies the same radius certificate for
every q>r(r-1), original surplus r<b, and current corner count one.
Its identity merger proof and implementation's witness uniqueness are
recorded in `bridge-lower-frontier-terminal-family.md`.

The strengthened b11 model now matches64 days for c0 and63 days for
c1/c2, at e0. These are finite terminal-model checks; no variable-width
capture formula is inferred. The remaining proof task is a uniform
account of the time spent changing the effective corner orientation.

The exact weighted graph builder was also replaced by monotone target
suffix bitsets, an algebraic consequence of the nine-threshold theorem.
Every40,866 weighted row on25x26 matches the independent old cache, while
build time falls from47 seconds to0.128 CPU seconds. Source and proof:
`src/bridge_lower_frontier_fast.py` and
`bridge-lower-frontier-fast-builder.md`.

## Paired radii, lens, and a uniform lower potential

The paired pronic interval reset and corner-ball lens are proved in
the terminal-family and lens notes. Parent review accepted the lens's
closed formula, parity inclusion-exclusion, and same/different-component
merger cases. Literal geometry checks are finite verification of those
formulas; they are not substituted for the ordinary derivation.

A selected larger stress case, b23 at quota24, repeats the arithmetic
one-day defect. Exact triggers, even with the lens, permit162 from
(K553,c0,e0), whereas paired interval resets plus the lens require163,
matching that physical terminal phase. The five bounded runs used
19.35 CPU seconds total; two exploratory variants hit their declared
caps and make no clock claim. The completed grouped evaluator uses
equal-radius bitsets with no cross-radius dominance and received an
independent code review. Details and witness steps are in the terminal-
family note. This does not establish the proposed boundary statement
for every b or all corner/erosion features.

The new ordinary potential in `bridge-lower-frontier-radius-clock.md`
uses an anchor-aware surplus profile: a cheap square step must fit its
near-square survivor inside the old anchor ball. Monotonicity turns
that condition into a one-step Bellman clock inequality, stable under
every later reset and guarded merger. Clipping its size argument at K
extends the inequality to histories that leave the low sector. Its
initial value with both radii uninformative remains weaker than the
desired terminal clock. The next precise target is a scalar charge
inequality between consecutive sharp events, whose intervening steps
obey the pronic map; repeated flips and critical-band entrances remain
part of the open proof obligation.

# Boundary connections and genuine theorem supersession

13 September 2026. Root research lane. The full 2D objective remains open.
Start: research commit 95e7e50; fresh account usage 7 percent used. Work
resumed by the user's explicit instruction. Stop new research at 10 percent
remaining and finish the verified manuscript/site/formal checkpoint.

## 1. A stronger erosion threshold: independently reviewed ordinary proof

For a finite connected bipartite graph Q with at least two vertices,
fix its bipartition chi. A physical-color-p pyramid A in Q times P_n has
virtual cutoffs a_v=s_v-2+2k_v, s_v=(p-chi(v)) mod2. Adjacent cutoffs
differ by one. Empty fibers have k_v=0.

Define the clipped erosion by

    e_v=max(a_v-1, (1-s_v)-2).

Both height vectors inside the maximum have the required target parity
and are edgewise 1-Lipschitz. Their maximum is therefore 1-Lipschitz;
opposite parity on each edge makes every difference exactly one. The
cutoffs respect the physical bottom and top. Thus E is a pyramid.
Every selected point in E has height at most a_v-1; the other term in
the maximum represents an empty fiber and adds no actual point.
Every longitudinal or transverse neighbor is consequently in A.
Hence N(E) is contained in A.

The exact cardinality loss is the number of NONEMPTY fibers with s_v=0:

    |A|-|E| = #{v: chi(v)=p and k_v>0}.

This is the number of occupied bottom-row roots of A. Requiring all
fibers to be nonempty, as the older H_Q threshold did, was stronger than
necessary for a fixed loss |Q_p|.

Put

    B_(Q,p)=max_{v:chi(v)=p} sum_u floor(dist_Q(v,u)/2).

If a root fiber v with chi(v)=p is empty, the height distance bound gives
k_u<=floor(dist(v,u)/2). Thus |A|>B_(Q,p) guarantees all bottom roots
are present, and then |E|=|A|-|Q_p|. The bound is sharp for sufficiently
tall cylinders: at a maximizing root v, choose a_u=dist(v,u)-2.
These heights have the required parity, valid edge differences and an
empty root fiber, and fit for n>=max(1,diam(Q)).

An arbitrary target R is permitted whenever its pyramid closure fits in
k points: |cl(R)|<=k<=|V_p|. Enlarge that ideal to k, then clip-erode.
If k>B_(Q,p), the resulting fixed-size backward step uses exactly
k-|R| designated inspections. This strictly improves the previous
one-step theorem while retaining arbitrary target supports and all its
older guarantees. Keep the older sharp ALL-fiber threshold as a separate
geometric fact; it is not false, merely unnecessary for this erosion loss.

For path cross-sections the phase thresholds are

    P_(2b): B_0=B_1=b(b-1);
    P_(2b+1): B_0=b^2, B_1=b(b-1),

where color0 contains the endpoints of the odd path. These follow by
maximizing the floor-distance sum over vertices of the required parity.

## 2. Strengthened even-width time theorem

Let width=2b, n>=2b, h=bn, and

    m>=max(b+1,b(b-1)+1), m<h.

Put d=m-b, h-b=qd+r, 0<=r<d, J(0)=0 and
J(r)=r+min(ceil(sqrt(r)),b) for r>0. The exact formula is the
existing high-budget formula: 2q if r=0, otherwise 2q+1 when 2J(r)<=m,
and 2q+2 when 2J(r)>m.

The backward construction is unchanged except that all envelopes have
size at least m>B_p, so clipped erosion suffices. The corner pyramid
and all prescribed-size enlargements remain actual physical sets.

For the lower bound, m>b(b-1) implies rho(m)>=b. Thus the decreasing
reflected branch of the full-budget scalar recurrence never improves
the corner/plateau branch. Now d>=(b-1)^2. If d>(b-1)^2 or r>0, the
old plateau calculation applies unchanged: c_t=h-td up to t=q-1,
then c_q=J(r). At the sole new equality d=(b-1)^2,r=0, with b>=2,
one has c_(q-1)=m-1 instead of m and tau=q; 2(m-1)>m still forces
2q days. Here q>=2 since m<h. For b=1, m>=2 gives d>=1>(b-1)^2.

This theorem strictly subsumes BOTH four-row low-budget
formulas (b=2,m=3,4) as well as the previous high-budget theorem.
This is an actual reduction of one previously independent result-item.

## 3. Further target, not a theorem

For odd width the same improved construction works at m>b^2, matching
the all-odd high-budget threshold. Extending the odd-short/even-long
LOWER proof to this range remains unproved: its old arithmetic uses a
larger step size to limit corner jumps. Five-row m5,6 suggest the
extension, but they are not a general argument. Do not lower that
theorem's published hypothesis without a separate complete lower proof.

The old corner inequalities do NOT extend verbatim. A targeted exact
arithmetic attack already fails on width 5, length 6, budget 5:
with U=29, a=2, x=4, the proposed square-corner inequality is
x+F(U-2(x-a))=4+F(25)=23 < F(29)=24. The corrected inequality also
fails at a=2,x=6: 6+F(22)=23 < 24. These are counterexamples to
intermediate potential inequalities, not to the candidate full-game
formula (the already proved five-row theorem gives T=10 here).
Therefore merely adjusting the old period-crossing algebra cannot
prove the extension. A different mark or a stronger physical
reachability restriction would be needed.

## Verification status

Socrates independently accepted Sections 1--2; his written audit is
`maturation-even-transitions.md` Section 5. The independent coordinate
checker passed 4,112 physical pyramids on paths and other bipartite
graphs, 370 complete physical strategy replays, and 10,373 scalar lower
comparisons. Receipt: `maturation-root-erosion-check.json`. These finite
checks support the separate unbounded arguments; they do not replace
them. No shared manuscript or Lean claim has been changed yet.

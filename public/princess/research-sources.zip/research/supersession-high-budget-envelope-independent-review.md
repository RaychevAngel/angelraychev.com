# Independent review of the general pyramid envelope lemma

12 September 2026. Reviewer: Euler (`trap_recurrence_formal`).

**PASS as an ordinary proof.** Reviewed Sections 1–3 of
`supersession-high-budget-envelopes.md`, with the author's explicit
scope guard that Q is finite, connected, bipartite, and has at least
two vertices. No Hamiltonian path is needed for the one-step lemma.
The Hamiltonian assumption is used only for the later balanced-phase
backward formulas. No exact general-Q capture-time formula is inferred.

## Empty-fiber threshold and sharpness

For current physical color p, put s_u=(p−chi(u)) mod 2 and write a
fiber's virtual last height as a_u=s_u−2+2k_u. If v is empty, the
edge height inequalities imply

    k_u ≤ (s_v+dist(v,u)−s_u)/2.

Bipartiteness makes this quantity exactly floor(dist/2) when s_v=0,
and ceil(dist/2) when s_v=1. Hence the proposed

    H_Q=max_v sum_u ceil(dist_Q(v,u)/2)

is a valid bound at either physical color and at every finite height.
For a maximizing v choose the current color with s_v=1 and set
a_u=dist(v,u)−1. Adjacent distances differ by exactly one in a
bipartite graph. These are valid cutoff heights, all at most diam(Q)−1,
so they attain the bound when n≥diam(Q). Sharpness is asserted across
the two colors; no false fixed-color equality is needed.

For paths the endpoint sum gives b² at order 2b and b(b+1) at order
2b+1. Convexity of the partial sums of ceil(j/2) puts the maximum at
an endpoint. Thus these are exactly the two earlier rectangle
thresholds, rather than larger substitute bounds.

## Enlargement, erosion, and the physical inspection

The predecessor relation stays in one physical color and strictly
decreases the longitudinal coordinate, so its transitive closure is a
finite poset. Every ideal can be extended to every prescribed size up
to the whole color class by adding minimal complement elements. For
an arbitrary target R, its ideal closure must be enlarged: enlarging R
itself without paying for its closure would be invalid.

Choose an ideal A containing cl(R), of size k, with

    |cl(R)|≤k≤|V_p|,       k>H_Q.

Every fiber of A is nonempty. Lowering every cutoff by one changes
physical color and preserves every edge height difference. No height
crosses the new allowed empty value. A fiber loses one room exactly
when s_v=0, equivalently chi(v)=p. Thus

    |E|=k−|Q_p|,          N(E)⊆A.

The inclusion uses the actual longitudinal and transverse neighbors
and remains valid at both finite ends. If the preceding survivor is
contained in E, movement enters A. Inspecting A minus R then leaves
a survivor contained in R, using exactly k−|R| designated rooms.
Some designated rooms can be irrelevant to the actual smaller belief;
this is still a legal upper construction with at most that budget.
Equality with R is neither asserted nor required.

The connected order-at-least-two guard also ensures that transverse
predecessor closure implies spacing-two closure within a fiber. With
Q=P1 that predecessor condition would be vacuous; paths are already
handled separately, or one would have to include fiber-prefix closure
explicitly in the definition.

## Backward recursion and timing

For a q-inspection half-search, the target survivor at day i has color
p_i and size r_i. An envelope of size r_i+m is eroded to the preceding
day's opposite-color survivor of size

    r_(i−1)=r_i+m−|Q_(p_i)|.

The first envelope is the full initial color class, so the final
backward equality is |V_(p_1)|=r_1+m. Reading the blocks forwards
therefore gives q actual inspections and q−1 intervening movements;
the additional following movement ends inside N(R). This is exactly
the half-search timing needed before a central inspection. For q=1
there is no earlier erosion step, only the first-envelope inspection.

When the two actual color classes have size h and m>H_Q, the backward
sizes increase because H_Q≥max(|Q_0|,|Q_1|). In fact H_Q≥|Q|−1 for
any connected nontrivial Q. Thus the final full-envelope equality
indeed bounds every earlier requested enlargement. Undirected walk
reversal joins two such containing envelopes at a central inspection;
it does not require the intermediate actual beliefs to equal the
chosen envelopes.

No transverse color-swapping symmetry is assumed. For general Q and
odd n, the two physical colors can have different terminal costs even
when |Q| is even. The note correctly keeps both costs. Longitudinal
reflection swaps current physical color when n is even.

## Tiny counterexample independently verified

I separately rebuilt the 30-room graph of Section 5 directly from its
seven transverse edges and longitudinal coordinate differences. The
distance sums are [7,5,5,6,5,6], giving H_Q=7. Exhausting only the
two-room pyramid candidates gives neighborhood minima five and four
in the respective colors. The displayed nonpyramidal two-room R has
four neighbors and a five-room predecessor closure.

Every displayed envelope is a physical pyramid, both erosion
inclusions hold, and all five shot sets have exactly eight rooms.
Direct physical replay gives belief sizes 25,19,13,8,0. The spanning
P5 times P6 rectangle requires five days at this budget by the already
proved mixed-parity high-budget theorem, so the physical five-day
upper is exact. A pyramid-only terminal cost would incorrectly predict
six. This is a genuine limitation of that extra optimality hypothesis,
not of the closure-admitting envelope lemma.

The direct verification is recorded in
`supersession-high-budget-envelope-independent-replay.json`.
Sections 4–6 are not being promoted here to a new general-Q lower
classification. The accepted shared manuscript ingredient is the
one-step geometric lemma and its actual backward realization.

I also read the frozen manuscript presentation
`paper/sections/pyramid-envelope-lemma.tex`, label
`lem:pyramid-envelope`. It matches the audited statement, includes
the connected order-at-least-two guard, preserves the arbitrary-target
closure condition and exact designated inspection cost, and states
the sharp path specialization correctly. No substantive correction
was requested.

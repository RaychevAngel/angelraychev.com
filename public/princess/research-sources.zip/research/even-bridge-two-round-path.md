# Exact two-round even-path minimization and its product obstruction

12 September2026. Ordinary all-length proof; external audit requested.
No manuscript or website change. The finite checker is independent of
the interval proof and uses arbitrary physical subsets.

## The exact statement

Let the path have vertices0,...,2L−1, whereL≥1. An initial supportA lies
in one checkerboard class and has cardinalitya. Inspect at mostp rooms,
move once, inspect at mostq rooms, and move again. For either initial
color, the minimum possible final cardinality, minimizing over all such
A of sizea and all legal inspections, is

    0,                         if a≤p+q;
    L−q,                       if a=L and p=0 and q<L;
    min(L,a−p−q+1),            otherwise.

In particular this is a universal lower bound from every initialA; the
attainment statement choosesA favorably. It is not an assertion that
every setA of the same size has an equally good strategy.

The full-support, zero-first-quota exception is necessary. OnP6, start
from{0,2,4}, wait, then inspect1. The final support is{2,4}, of size2,
whereas the expressionmin(3,3−0−1+1) would incorrectly give3.

## Equality in the path matching bound

Identify the even and odd classes with indices0,...,L−1 through2i and
2i+1 respectively. Their neighborhood maps are

    N_E(R)=R∪(R−1),      N_O(R)=R∪(R+1),

with indices outside the path omitted. Each neighborhood has size at
least|R|. A nonempty properR has equality precisely when it is a prefix
{0,...,r−1} inE or a suffix{L−r,...,L−1} inO. This follows directly from
the formulas: equality forces closure under decrement or increment.
Equivalently, equality sets are precisely spacing-two prefixes starting
at the unique path endpoint belonging to the source color.

For a proper equality setR, N(R) avoids the endpoint of its own color.
Every nonemptyB⊆N(R) therefore has|N(B)|≥|B|+1: equality would require
B to contain that endpoint.

## Lower bound

The zero case needs no argument. Assumea>p+q. WriteR for first survivors,
U=N(R), B for second survivors, andV=N(B). All are nonempty, and

    |R|≥a−p,  |U|≥|R|,  |B|≥|U|−q,  |V|≥|B|.

If|U|≥|R|+1, these give|V|≥a−p−q+1. If|U|=|R|<L, the preceding
equality characterization gives the same extra unit in the second
neighborhood. The only remaining case isR being the full color class.
ThenA is full and|V|≥L−q. Forp≥1 this is at leasta−p−q+1; forp=0
it is exactly the stated exceptional bound. Atp=q=0, fullA simply
remains full, accounting for the outer minimum withL.

## Attainment

ChooseA as a spacing-two prefix starting at its color's endpoint. If
a≤p+q, delete up top initial rooms while keeping such a prefix; its
neighborhood has the same cardinality and the remainingq probes clear it.

Otherwise, except at the full-support exception, first keep the prefix
of sizea−p. From its neighborhood keep the prefix from the same physical
end of sizea−p−q. The second neighborhood has size
min(L,a−p−q+1). In the exception, first wait, then keep the prefix of
sizeL−q from the opposite physical endpoint. Its neighborhood has the
same cardinalityL−q. Reflection handles the other initial color.

## Why a direct product lift fails

With no intervening inspections, two steps on an isolated even path
are the closed neighborhood operation of anL-vertex path on each color.
Hence sorting each color's indices toward either fixed endpoint is a
valid monotone cardinality-preserving compression forN² on that isolated
path. This does not imply a product compression.

OnP2×P4, use coordinates(x,y), and letC compress eachy-fiber toward0,
preserving the spacing-two parity. ForS={(0,3)},

    N²(S)={(0,1),(0,3),(1,2)},
    N²(C(S))={(0,1),(0,3),(1,0),(1,2)},
    C(N²(S))={(0,1),(0,3),(1,0)}.

ThusN²(C(S)) is not contained inC(N²(S)). The failure comes from a
two-step walk using one longitudinal edge and one transverse edge:
compression turns an endpoint into an interior point of its parity.

Choosing each fiber's favorable endpoint does not repair the lift.
LetD send even fiber indices toward0 and odd ones toward3. NowD(S)=S,
butD(N²(S))={(0,1),(0,3),(1,0)} still omits(1,2)∈N²(D(S)).
One global endpoint loses local endpoint expansion; independently
favorable endpoints fail to align across a transverse edge.

These examples rule out the two specified product operators. They do
not rule out a richer two-round state, an exchange of inspections among
fibers, or a normal form restricted to full-board constant-budget play.

## Independent finite checks

`src/even_bridge_two_round_path.py` enumerates arbitrary one-color
supports and every pair of quotas on pathsP2 throughP14. It checks both
the lower bound for every support and exact attainment for everya,p,q.
It also constructs both product counterexamples by direct physical
adjacency. Receipt:`research/even-bridge-two-round-path.json`.

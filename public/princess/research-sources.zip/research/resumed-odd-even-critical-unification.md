# One critical corner dichotomy for odd widths

13 September 2026. New ordinary proof for independent review. This strictly
strengthens the separately proved enlarged critical interval and its dual;
it does not assert that its permitted transitions are all attainable.

Parent independent review accepted the alternating-fiber bounds and their
capacity absorption. The separator argument was checked again at s=b:
ell>b still provides an empty matched row, the assumed adjacent unmarked
pair provides the second separator, and transposing the complement preserves
both empty separators and the missing-corner slack. No use of s<b remains
in that branch. The shorter statement and proof replace the unintegrated
longer proof in `paper/sections/resumed-odd-critical-extension.tex`.

Let w=2b+1>=3, n=2ell>=w, h=w*ell. For a physical one-color support S put
a=|S|, s=|N(S)|-|S|, i=its own-colored corner count, and j=the opposite
corner count in its neighborhood. Use F and G from the finite-board
corner theorem (`research/resumed-even-corner-profile.md`).

**Theorem.** If s=b, then

    a<=F_(i,j)(b) OR h-a-b<=G_(i,j)(b) OR (i,j)=(2,0).

Together with the existing theorem for s<b, this is one necessary corner
bound at every surplus up to and including b, with exactly one extra
alternative at the critical surplus. Both its numeric capacities and this
exception have a fixed-size description independent of width and length.

## Proof

Use the longitudinal matching contraction, with majority columns
U={0,2,...,2b} and minority columns V={1,3,...,2b-1}. Reflect to phase zero.
The outside boundary H contains b vertices, and ell>b ensures at least one
boundary-free horizontal row.

If two adjacent columns avoid H, the entire proof of the four-quadrant
F/G dichotomy applies verbatim. The unmarked pair and unmarked row lie in
one strongly connected component K. Either the source or its transposed
complement avoids K, giving four physical corner quadrants, additive
surpluses, and the same missing-corner slack in the dual case. That proof
needs the two separators, rather than the strict inequality s<b itself.

Otherwise the marked columns form a size-b vertex cover of a path on
2b+1 positions. They are exactly V, each with one mark (v,c_v). Each U
fiber is a prefix with length t_u. Horizontal closure gives

    R_v subset R_u,       R_u minus R_v subset {c_v}.

Consequently adjacent U lengths differ by at most one, and

    |R_v| <= min(t_u,t_u'),
    ell-|R_v| <= min(ell-t_u,ell-t_u')+1.

An outgoing opposite-colored corner belongs to N(S) exactly when its
endpoint U fiber is full: the neighborhood adds no U vertices. If any U
fiber is full, all U fibers are nonempty, because ell>b and their length
can fall by at most one across each of the b intervening V positions.
Thus j>0 implies i=2.

There are now five possibilities, only one of which needs the exception:

* i=0,j=0: both endpoint U lengths are zero, so
  t_(2q)<=min(q,b-q). Using the first V bound, total size is at most
  b(b-1)/2<=F_(0,0)(b).
* i=1,j=0: one endpoint U is empty. The same one-sided distance bound
  and first V bound give size at most b^2=F_(1,0)(b).
* i=2,j=0: this is precisely the stated exception.
* i=2,j=1: one endpoint U is full. Apply the second V bound to its
  distance-bounded deficiencies. Their sum is at most b(b+1), so
  h-a-b<=b^2=G_(2,1)(b).
* i=2,j=2: both endpoint U fibers are full. Their deficiencies are
  bounded by min(q,b-q), and the second V bound gives total deficiency
  at most b(b+1)/2. Hence
  h-a-b<=b(b-1)/2<=F_(0,0)(b)=G_(2,2)(b).

These exhaust the cases. The argument did not assume the V fibers were
prefixes, nor did it use a dynamic compression or reachability assertion.
The theorem follows.

## Relation to the interval statements

For C=b(b-1)<a<h-b(b+1), the dual branch is impossible because every
G_(i,j)(b)<=b^2. In the first branch, j>0 or i=0 gives F_(i,j)(b)<=C.
Thus i>=1 and j=0, exactly the enlarged orientation conclusion.
The exceptional pair (2,0) already satisfies this conclusion.

The small-corner Q consequence still follows by applying the theorem to
the next support, whose i=0. Its exceptional branch is unavailable;
for a<=b^2 the dual branch is excluded, and F_(0,j)(s)<=s(s-1).
The former dual interval restriction follows either by complementing
this argument or directly from these F/G bounds. Therefore the longer
anchored-W(W-1) proof remains an independent proof and research record,
but need not add another main-paper geometric argument.

## Counterattack and actual effect on the game relaxation

The complete directed-boundary/SCC enumeration on 9x10 checked all 205709
surplus-four physical supports against this stronger dichotomy. No failures:
`research/resumed-odd-even-cheap-pairs-9x10.json`, field
`critical_corner_failures`. Its phase reflection covers both colors.

Adding this theorem removes additional abstract transitions, but does not
improve the tested joint lower values beyond 64 for 7x8,k=4 and 96 for
9x10,k=5. Thus a stronger uniform static theorem still does not settle all
dynamic compatibility. The exact-rational potential and all-target joint
BFS receipt is `research/resumed-odd-even-corner-history-critical.json`.
The 9x10 lower matches the independently replayed upper96; the 7x8 upper
remains68. No general minimum-budget equality is claimed here.

The9x10 lower now has an independently checked integer joint-state
potential in `resumed-odd-even-corner-history-9x10-audited.json`: reverse
reachability produced value96 at the full state, and all123798386 allowed
joint transition inequalities were then checked exactly. This agrees with
the separate forward BFS and the physical upper.

The particular7x8 relaxed32-day solo path was subsequently proved
unliftable already by day4, with a separate exhaustive physical check;
see `resumed-odd-even-four-day-obstruction.md`. This is concrete evidence
that corner counts forget relevant distance information, but does not rule
out every other32-day physical strategy.

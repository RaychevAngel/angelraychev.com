# Independent review of the cylinder profile transfer

12 September 2026 UTC. **Verdict: passed for the stated isoperimetric scope.**

Reviewed `src/cylinder_profile_transfer.py` and the scope and checks recorded
in `odd-cylinder-profile-transfer.json`. The mathematical inputs are a
bipartite transverse graph Q with two fixed orders whose prefixes attain
the exact one-parity neighborhood profiles and whose neighborhoods are
opposite-parity prefixes. These inputs are available for all-odd boxes.
The longitudinal length is any positive integer, including even lengths.

Fix a global parity p and the cardinalities k_i of the source in the
successive slices. In slice i, the neighborhood is the union of the transverse
neighborhood of its own source and the two neighboring sources. All three
sets belong to transverse parity 1-(p+i mod2). Consequently its size is at
least

    max(g_(p+i mod2)(k_i), k_(i-1), k_(i+1)),

with zero boundary sizes outside the cylinder. Choosing each source slice
to be the prefix of its transverse parity order makes these three sets
prefixes of the *same* opposite order. Their union then has exactly that
maximum. The choices attain equality simultaneously for every slice, so
the global minimum at total cardinality k is exactly the minimum sum of
these maxima over legal vectors with sum k.

The implementation's state (a,b,total) remembers the previous two source
sizes and the cumulative cardinality. Appending c charges precisely the
middle slice's maximum and updates the pair to (b,c). Initialization sets
the absent left size to zero; the final maximum uses zero on the right.
Every legal size vector is represented and no other vector is admitted.
The n=1 case reduces to the transverse profile itself. The public mathematical
domain should explicitly say n>=1; the code currently assumes that domain.

Every minimum-neighborhood profile is monotone: take a minimizing larger
set and remove vertices to obtain a smaller set. Thus the two-count search
in `lower_time` gives a valid lower bound on physical capture time. Its
coordinate swap correctly reflects that each move switches checkerboard
parity. Quotas exceeding a current count are harmless padding under the
positive-part convention. If this finite relaxed game has no winning path,
neither does an actual strategy.

The converse does **not** follow. Minimizers for different total sizes need
not form compatible global prefixes, and an individually minimum-neighborhood
support may not fit inside the current belief. The file and receipt correctly
retain this distinction; the even-length mismatch in their prefix comparison
is positive evidence against silently assuming such a normal form.

The separately reported serial upper values require actual nested physical
prefixes plus phase/orientation handling. For the even 3×3×n cylinders,
reflection of the long axis swaps global parity and permits independent
cohort orientations. For the odd family, the separately checked favorable
minority phase has odd solo duration, allowing the other cohort to begin in
the same phase. Those facts justify the displayed upper strategies; fiber
compression alone would not justify simply doubling the best solo time.

The receipt's exhaustive comparison on all 524,288 one-parity subsets of
the 3×3×4 board supplements the proof. No new finite experiment or Lean
formalization was needed for this conceptual audit.

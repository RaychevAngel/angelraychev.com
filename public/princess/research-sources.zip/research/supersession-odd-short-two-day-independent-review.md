# Independent review: completion of the odd-short high-budget formula

13 September2026. Euler independently reviewed the root agent's two-day
total-deficit argument, together with the q=1 and q=3 reductions developed
in the potential lane. **Verdict: PASS as an ordinary proof.** No Lean
formalization or manuscript edit is claimed in this review.

## Statement and proof boundary

Let w=2b+1≥3, let n≥w be even, put h=wn/2 and B=b(b+1), and assume
B+1≤m<h. Write

    2h−w−1=q(2m−w)+r,  0≤r<2m−w.

Use the accepted corner cost J from the odd-rectangle theorem:
J(0)=0, J(2k)=k+min(Q(k),b+1),
J(2k+1)=k+1+min(R(k+1),b), with R=ceil sqrt and
Q(k)=min{a≥1:k≤a(a−1)} for positive k.

The physical upper already proved independently is now sharp:

    T=2q                  if r=0;
    T=2q+1                if r>0 and 2J(r)≤m;
    T=2q+2                otherwise.

This completes this high-budget range only. It says nothing new about
m≤b(b+1), and does not provide an unrestricted even-rectangle dynamic
normal form.

The first potential lower, its one-unit corner bound, the strengthened
co-small marker, and the exact theorem under h>m+2b²+b are independently
accepted in `supersession-odd-short-potential.md` §§1–7 and the root's
`supersession-odd-short-corner-independent-review.md`.

## 1. Exactly which quotient cases remain

Since h≥m+1, the numerator 2h−w−1 is at least (2m−w)+1, so q≥1.
The initial envelope already proves the formula except when

    J(r)=floor(m/2)+1 and C=F(2h)−1.                    (E)

Every q≥4 is covered by the accepted tall-board theorem.

For q=1, parity forces r=2s−1 with s≥1, and h=m+s. Therefore
F(2h)=h+c, c=min(R(s),b). For any corner deficiency x≤B, set
a=rho(x)=min{j≥0:x≤j(j+1)} and t=x−a≤a². If t≥s, the target is
in the cardinality branch and its departure cost is h+a≥h+c. If t<s,
the exact departure cost is

    x+F(2(h−t))=h+a+min(R(s−t),b)≥h+c.

The final inequality follows from R(s)≤a+R(s−t), since t≤a²;
if clipping affects the right-hand root it makes the bound immediate.
Thus C=F(2h) and (E) cannot occur. This calculation includes x=0.

For q=3 in (E), write r=2k+1 and c=min(R(k+1),b). Then
k+c=floor(m/2), so k≥b(b−1)/2. Also h=3m−2b+k, giving

    h−m−2b²−b≥k−b+2≥(b²−3b+4)/2>0.

Thus every unresolved q=3 tuple is already in the accepted tall-board
range. The only case still requiring an argument is q=2, r>0,
2J(r)>m. The next section proves the necessary lower without assuming
serial play, normalized supports, or a particular shape of inspections.

## 2. Root's uniform two-day total-deficit bound

Write r=2k, k≥1, c=min(Q(k),b+1). Then

    h=2m−b+k,  J(r)=k+c.

Let I(z) be the maximum possible deficit after moving from a survivor
obtained by deleting z cells from one full color. The accepted exact
even-area profile and neighborhood-complement duality give

    I(z)=z−min(rho(z),b,R(h−z)), 0≤z≤h,

with I(0)=0. The accepted inverse-profile inequality makes I monotone
and superadditive when its arguments have sum at most h.

**Claim.** After any two inspection days and the following movements,
the sum of the deficits in the two physical color classes is at most

    D*=h−k−c=2m−b−c.                                  (1)

It is harmless to fill an unused first-day quota, since an enlarged
inspection set can only increase subsequent deficits. Let its two
positive allocations be p and m−p. Because
h−m=m−b+k>b², the reflected profile term in I(p) and I(m−p) exceeds b.
Consequently their total deficit is at most m−b−1. Indeed, if the two
positive costs min(rho(p),b), min(rho(m−p),b) summed to at most b,
each would be below b and

    m≤a(a+1)+a'(a'+1)≤b(b+1),

contrary to m≥B+1. The same loss of one occurs if all m first-day
inspections go to one cohort but its survivor has surplus at least b+1.

In either case, second-day allocations plus superadditivity give a
total deficit at most I(Z), Z=2m−b−1. Since h−Z=k+1 and
Z≥2b²+b+1>B,

    I(Z)=Z−min(b,R(k+1))≤h−k−c=D*,

using 1+min(b,R(k+1))≥min(Q(k),b+1). All inverse arguments have sum
at most Z<h, so superadditivity is used inside its valid domain.

The sole exceptional first day therefore allocates all m inspections
to one cohort and leaves a survivor with surplus exactly b. Its size
h−m=m−b+k is strictly between b² and h−B, so the accepted critical
frontier theorem applies. After its movement the active cohort has
m+k cells, and the other cohort is still full.

On day two allocate m−u inspections to the active cohort and u to the
other. The active survivor has s=k+u>0.

* If s<h−B, the active neighborhood has at least L_1(s) cells: for
  s≤b² this is the conditional minority-corner theorem; for s>b² the
  no-consecutive-critical theorem forces surplus at least b+1, which
  is L_1(s)'s surplus. The inactive cohort gains deficit at most u.
  Their total deficit is therefore at most

      h−L_1(k+u)+u≤h−k−c.

* If s≥h−B, then u≥2m−b−B>m−b≥b²+1. Since u≤m and
  h−m>b², both other terms in I(u) are at least b, giving I(u)=u−b.
  The active survivor is nonempty and proper: s≤k+m<h. The accepted
  static profile has all three surplus terms at least one for such a
  survivor, so its neighborhood has at least s+1 cells. The total deficit
  is at most

      h−(k+u+1)+(u−b)=h−k−b−1≤h−k−c.

This proves (1) for arbitrary physical two-day strategies. A second-day
quota need not be full: one may augment it monotonically, or use the
same inequalities with a smaller total. No pure-cohort assumption is
made except in the one first-day equality case that was derived above.

## 3. Five-day impossibility and exact timing

Suppose a five-day schedule guaranteed capture. Evolve the full board
forward through the first two inspections and movements, and backwards
through the last two inspections and movements. Undirected adjacency
identifies the latter with another ordinary two-day process, with the
same inspection budget. Both central beliefs have total deficit at
most D* by (1).

Their intersection at the third inspection therefore contains at least

    2h−2D*=2(k+c)=2J(r)>m

cells. Every cell in that intersection lies on an avoiding walk through
the first two days and on an avoiding reversed walk through the last
two days; concatenating the walks gives a full avoiding trajectory
unless that cell is inspected on day three. The middle quota cannot
inspect the entire intersection. This contradicts guaranteed capture.

The day count is exactly 2+1+2; both middle beliefs include their second
movement, and the central inspection has no duplicated movement. The
argument uses the total of the two colors, so a parity swap on reversal
does not affect it. The accepted six-day physical construction now
matches the lower. Together with Section1 and the preceding accepted
potential results, this proves the stated uniform high-budget formula.

## Review conclusions and failed stronger routes

All endpoint, clipping, strict-middle, and inverse-domain guards above
were checked independently. The method deliberately avoids claiming
that a full cohort always needs F(2h) total useful inspections at all
short-board parameters, or that efficient small supports have canonical
corner shapes. Those stronger statements were unproved and are not
needed. Likewise the candidate disjoint-small-support overlap inequality
recorded in the working note remains unproved and is superseded as a
route to this particular theorem.

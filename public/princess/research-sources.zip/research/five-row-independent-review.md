# Independent review: five rows, three probes, even length

12 September 2026. Reviewer: independent proof/geometry agent.

## Conclusion and scope

The argument in the final section of `five-row-investigation.md` establishes

\[
T_3(P_5\square P_n)=10n-20\qquad(n\ge6\text{ even}).
\]

I found no substantive gap after independently deriving the physical coordinate
map, reviewing every symbolic certificate implication, checking the historical
potential's geometric hypotheses, and constructing/replaying the attaining
strategy independently. This is a **computer-assisted ordinary proof**: its
unbounded geometric classification reduces to an exhaustive finite automaton
certificate. The potential inequality is separately proved in Lean, but the
geometric bridge and final five-row theorem are **not yet fully formalized**.

This review concerns the three-probe theorem on even lengths only. It does not
establish the other budgets or import an odd-length conclusion by analogy.
The opening paragraphs of the investigation log are historical and should not
be mistaken for the current theorem status.

## Physical interpretation of the automaton

Write `n=2q`, `h=5q`. Use coordinates `(x,y)` with `0≤x<2q`, `0≤y<5`.
For physical parity zero, its room in matched pair `j` and row `y` is
`x=2j+(y mod 2)`. The matched neighbor has the opposite parity in the same
pair. After identifying the opposite parity using this matching, adjacency
becomes:

- a loop at every `(j,y)`;
- both vertical directions within a column;
- a left arrow on rows `0,2,4`;
- a right arrow on rows `1,3`.

For physical parity one, the horizontal arrows reverse. Reflection of the
matched-column index identifies its graph with the first orientation.
Consequently the matching supplies an injection of every support into its
neighborhood, and the remaining neighborhood cells are precisely the directed
outside boundary counted by the code.

For successive column masks `A,B,C`, an outside cell in column `B` can be
reached vertically from `B`, from `A` on odd rows, or from `C` on even rows.
Thus the local mask in `five_row_boundary_automaton.py` is exact. The zero
sentinels correctly remove nonphysical neighbors at the two ends. The graph
is strongly connected: move vertically to an even row to go left, or to an
odd row to go right. Therefore only the empty and full supports have boundary
zero.

As a separate implementation attack, `five_row_independent_review.py` constructs
the physical room graph directly and checks the coordinate identity for all
32,768 supports of each parity on the `6×5` board. It also checks all four
geometric implications below on those supports. This finite check is not the
reason the theorem extends to arbitrary length.

## Why the finite certificate covers every length

The automaton state `(A,B,c)` records two consecutive columns and the exact
boundary already counted. Each next column contributes a nonnegative local
weight. Discarding a state above the desired boundary budget cannot remove an
accepted word. The starts include every possible first column; the terminal
test counts the last column against the right sentinel.

The complete reachable graph at budget two has 1,124 states and 3,874 edges
after removal of the permitted loops. The code checks acyclicity of this
entire graph. Every removed loop is a repetition of an empty or full column,
and has weight zero. It follows that deleting such repetitions from an
arbitrary accepted word leaves a directed path in this DAG. Every such
terminal path is enumerated, with its legal repetition positions recorded.
Conversely restoring any nonnegative number of repetitions preserves the
boundary. The resulting 1,057 templates therefore describe every boundary-two
support of every length. The analogous boundary-one enumeration has 59
templates.

I checked the quantifiers in `certify_geometry()`. If a template has `k`
present cells and `a` absent cells, then full-column repetitions increase
`k` by multiples of five without changing `a`; empty-column repetitions
increase `a` by multiples of five without changing `k`. Repeating a column
preserves the assertion that each row is a left prefix. These facts justify
the following certificate implications uniformly in all repetition counts:

1. Boundary one implies size `1,h−2,h−1`. The checker explicitly forces either
   size one with no full-column repetition, or one/two absent cells with no
   empty-column repetition.
2. Boundary two and `3≤k≤h−5` imply prefix rows. The check includes every
   template for which present cells can reach three and absent cells can reach
   five. This condition is conservative; it does not omit a feasible exponent.
3. A boundary-two prefix support with an empty row has at most five cells.
   Such a template cannot contain a full-column repetition, and empty-column
   repetitions do not alter its size or create a cell in the empty row.
4. A boundary-two prefix support of size four, five, or six has no neighbor in
   the final column. A full-column repetition position already requires two
   full columns, hence at least ten cells, and cannot occur here. The checker
   computes the last-column neighborhood exactly on each remaining template.
   An empty repetition in a nonempty prefix support occurs after its nonempty
   columns; extending that tail cannot create a new last-column neighbor.

Templates too short to give `q≥3` and without any repetition position are
correctly excluded. No finite upper limit on a repetition exponent is used.

## Review of the incompatibility and potential bridge

Let `R` have boundary two and `4≤k=|R|≤h−5`. If the next survivors `R'⊆N(R)`
have boundary two, `k−1≤|R'|≤k+2`, and `|R'|≤h−5`, then both supports have at
least three cells. The first support has left-prefix rows and the opposite
parity's support has right-prefix rows. Its size is at least three because
`k≥4`.

The neighborhood of a left-prefix support again has left-prefix rows: loops,
vertical unions and either horizontal shift preserve that property. Since
`|N(R)|=k+2≤h−3`, at least one such row misses its last cell. The corresponding
right-prefix row of `R'` must be empty. Implication 3 gives `|R'|≤5`, whence
`k≤6`. Implication 4 now removes the last cell from every row of `N(R)`, forcing
every right-prefix row of `R'` to be empty. This contradicts `|R'|≥3`.

The old historical mark refers to the immediately preceding survivors, not to
an arbitrary earlier favorable step. If that mark is one and the current
belief has size `b`, then the preceding survivor size is `k=b−2`. Removing
`p≤3` useful probes gives `k−1≤b−p≤k+2`, exactly the interval required above.
Thus the forbidden branch in `FiveRowRankArithmetic.Transition` matches the
physical incompatibility, including allocations of zero, one, two and three
useful probes.

All other branches also match the physical process: no survivors; full
survivors; boundary one; unmarked boundary two; boundary at least three. The
strong-connectivity argument excludes any missing nonempty proper
boundary-zero branch. Every nonempty reachable belief has at least two cells,
because it is a neighborhood of a nonempty support and the physical graph has
minimum degree two. A marked belief has size between six and `h−3`. These are
precisely the hypotheses of the arithmetic lemma's `Valid` predicate.

Use the actual number of inspected cells inside each cohort, so subtraction
of probes is exact. Their supports have opposite physical parities on every
day, hence their useful allocations sum to at most three. The kernel-checked
arithmetic inequality says that the potential can decrease by one only for
an allocation of at least two probes. At most one cohort receives such an
allocation daily. The sum starts at `4h−20` and ends at zero, giving the lower
bound against every all-failure schedule. As usual, any deterministic adaptive
strategy has one such all-failure branch, so adaptation does not evade it.

## An explicit all-length derivation of the upper tables

The attaining construction does not require a separate isoperimetric theorem.
Order each physical parity by increasing `x+y`, then increasing `x`. Let `d`
be a diagonal and let

\[
\ell(d)=\max(0,d-4),\quad u(d)=\min(n-1,d),\quad L(d)=u(d)-\ell(d)+1.
\]

Suppose a nonempty prefix ends with the first `j` vertices of diagonal `d`.
Its size is the total size of the earlier same-parity diagonals plus `j`.
Its neighborhood contains all earlier opposite-parity diagonals and a prefix
of diagonal `d+1`. That new diagonal prefix has length

\[
j+1-\mathbf1_{d\ge4}
     -\mathbf1_{\ell(d)+j-1=n-1}.
\]

To verify this directly, a cell `(x,d−x)` has upper-diagonal neighbors at
`x` and `x+1`, except that the first is absent on row four and the second is
absent at long-coordinate `n−1`. The union is an interval of `x` values starting
at the first vertex of diagonal `d+1`. The lower-diagonal neighbors lie in
the already full preceding diagonal. The same description covers the final
diagonal, where the displayed length is zero.

Define the alternating preceding-layer difference

\[
A(d)=\sum_{s<d,\ s\not\equiv d\ (2)}L(s)
     -\sum_{s<d,\ s\equiv d\ (2)}L(s).
\]

Then `A(0)=0`, `A(d+1)=L(d)−A(d)`, and the surplus of this prefix is

\[
A(d)+1-\mathbf1_{d\ge4}
       -\mathbf1_{\ell(d)+j-1=n-1}.
\]

The layers have lengths `1,2,3,4,5`, then constant length five, then `4,3,2,1`.
For even `n≥6`, the recurrence gives

- `A(d)=ceil(d/2)` for `0≤d≤4`;
- `A(d)=2+(d mod 2)` for `4≤d≤n−1`;
- `A(n),A(n+1),A(n+2),A(n+3)=2,2,1,1`.

Substitution yields the claimed tables for every length, including `n=6`:

- Even phase: surplus one at sizes `1,h−2,h−1`; surplus two at every other
  proper nonempty size.
- Odd phase: surplus two at sizes `1,2,h−4,h−3,h−2`; surplus three at sizes
  `3,...,h−5`; surplus one at size `h−1`.

The neighborhoods themselves, not just their sizes, are the opposite-phase
prefixes. Therefore deleting the last three cells of the current prefix
implements these tables. Starting in the favorable even phase, the first
three rounds give `h→h−1→h−2→h−3`; then `h−8` pairs of a stationary round and
a one-cell decrease reach five; the last three rounds give `5→4→2→0`.
The total is `2h−10`, an even number.

Sweep one initial cohort completely and then the other. The uninspected cohort
stays the full alternating parity during the first sweep, because a full
parity has the entire opposite parity as its neighborhood. Reflection
`x↦n−1−x` swaps the two physical parities for even `n`. Thus the second cohort
can also begin in the favorable phase with a fixed reflected orientation,
without an extra wait. The two sweeps take `4h−20=10n−20` rounds.

The independent review script reconstructs these orders and physical
neighborhoods without importing the discovery/strategy modules. It replays
the two fixed-orientation cohort sweeps at lengths `6,8,10,12,14,20,50,100`.
The receipt is `five-row-independent-review.json`. This attacks the formula
and indexing; the preceding layer calculation supplies the uniform proof.

## Remaining work

For a fully formal five-row result, encode the bounded local automaton,
kernel-check the template certificate, prove its pumping interpretation for
arbitrary column words, and connect the geometric transition relation to the
already verified potential. The current theorem should be presented with its
computer-assisted finite-certificate proof boundary clearly stated.

# Feasibility on every odd box: a single profile maximum

12 September 2026. Ordinary corollary of the proved odd-box nesting theorem
and the published Bolkema–Groothuis hunter-number criterion. This is not yet
a Lean theorem, and the general criterion is not a new contribution here.

Let B be a Cartesian box whose nontrivial side lengths are odd. Put
`E=(|B|+1)/2`, `M=(|B|−1)/2`, and let g₀,g₁ be its exact majority/minority
open-neighborhood profiles. Exclude the one-room box for the moment.

Then the exact minimum feasible number of daily probes is

\[
\boxed{h(B)=1+\max_{0\le k\le E}\bigl(g_0(k)-k\bigr).}
\]

Thus feasibility no longer needs the two-count shortest-path computation.
Minimum capture time still uses that exact recurrence. The one-room box has
feasibility threshold one by direct inspection.

## 1. Exact profile duality

For any finite bipartite graph with parts of sizes E and M, define

\[
J(z)=\max\{x:0\le x\le E,\ g_0(x)\le z\},\qquad0\le z\le M.
\]

The feasible set is nonempty since g₀(0)=0. The exact duality is

\[
g_1(y)=E-J(M-y),\qquad0\le y\le M. \tag{1}
\]

Indeed a majority set X of size x with at most M−y neighbors leaves at least
y minority vertices outside its neighborhood. Choosing any such y-element
set Y gives `N(Y)⊆V₀\X`, and therefore `g₁(y)≤E−x`. This proves one inequality
at x=J(M−y). Conversely, choose a y-element minority set Y attaining g₁(y)
and take `X=V₀\N(Y)`. Then `|X|=E−g₁(y)` and its neighborhood lies outside Y,
so this x is feasible in J(M−y). This proves the reverse inequality.

This argument uses neither nesting nor a geometric symmetry. In particular,
it does not assume the unproved pointwise comparison `g₁(k)≥g₀(k)`.

## 2. The two maximum surpluses differ by exactly one

Assume now there are no isolated vertices and `E=M+1`. Set

\[
u_0=\max_x(g_0(x)-x),\qquad u_1=\max_y(g_1(y)-y).
\]

Both maxima include zero. We prove

\[
u_1=u_0+1. \tag{2}
\]

By (1), substituting `z=M−y` gives

\[
u_1=1+\max_{0\le z\le M}(z-J(z)).
\]

For the upper bound on the second maximum, if J(z)<E, set x=J(z)+1. By
maximality `g₀(x)>z`, so integer-valuedness gives

    z−J(z) ≤ g₀(x)−x ≤ u₀.

If J(z)=E, the absence of isolated minority vertices gives g₀(E)=M and hence
z=M. In this endpoint case `z−J(z)=M−E=−1≤u₀`.

For the reverse bound, choose a **positive** x attaining u₀. Such a choice
exists: if u₀>0 then x=0 cannot attain it; if u₀=0, the absence of isolated
majority vertices gives g₀(1)≥1, hence g₀(1)=1 and x=1 works. Put
`z=g₀(x)−1`. This lies in `[0,M−1]`. Monotonicity of g₀ implies J(z)≤x−1,
and consequently

    z−J(z) ≥ g₀(x)−1−(x−1) = u₀.

This proves (2), including u₀=0 and the full-set inverse endpoint. Every
nontrivial odd box is connected and has no isolated vertices, so it satisfies
these assumptions.

## 3. Applying the established hunter-number criterion

Bolkema and Groothuis, *Hunting Rabbits on the Hypercube*, Theorem 16,
establish that a bipartite graph with compatible isoperimetric nesting and
maximum parity surpluses differing by at most one has hunter number

    1+min(u₀,u₁).

The source is their [primary preprint](https://arxiv.org/pdf/1701.08726),
first posted 30 January 2017 and revised 7 October 2018; the article appeared
in *Discrete Mathematics* 342 (2019), 360–372. The manuscript bibliography
key is `BolkemaGroothuis2019`. Their criterion determines the minimum number
of hunters, not minimum capture time.

Our ordinary odd-box theorem supplies exactly their nesting hypothesis, and
(2) supplies their surplus hypothesis. Their criterion therefore yields
`h(B)=1+u₀`. This corollary should explicitly cite that theorem. The lower
bound is being invoked from their general result, not independently claimed
from profile duality alone or from a pointwise parity comparison.

For clarity, the upper bound also has a direct construction. Allocate all
`m=u₀+1` probes to one current prefix cohort. If a nonempty remainder exists,
a majority step has next size at most

    (b−m)+u₀ = b−1,

and a minority step has next size at most

    (b−m)+u₁ = b.

Thus a nonzero cohort strictly decreases at least every two rounds and
eventually clears. Prefix nesting makes these updates physical strategies.
Clearing the two initial cohorts successively gives a full-board strategy.
No serial-optimality claim about the number of days is needed.

## 4. A direct evaluation from the box coordinates

Sort the nontrivial odd side lengths increasingly, with even maxima Lᵢ, and
list the even vertices `e₁,...,e_E` by increasing weight and decreasing lex.
The proved linear-cost identity gives

\[
g_0(k)-k=\sum_{i=1}^k(a(e_i)-1),
\]

where `a(0)=d` and, for nonzero x with last positive coordinate j,

\[
a(x)=d-j+1-\mathbf1_{x_j=L_j}.
\]

Consequently the exact feasibility threshold is one plus the maximum partial
sum of this explicit integer sequence. Computing it requires only an ordered
scan after the vertices have been sorted. This is polynomial in the number
of rooms; it is not asserted to be polynomial in the binary encoding of very
large side lengths.

Some values, evaluated directly from that sum, are:

| Box side lengths | Maximum majority surplus | Minimum feasible probes |
|---|---:|---:|
| 3×3 | 1 | 2 |
| 5×5 | 2 | 3 |
| 3×3×3 | 4 | 5 |
| 3×3×5 | 4 | 5 |
| 3×5×5 | 7 | 8 |
| 5×5×5 | 11 | 12 |
| 3×3×3×3 | 11 | 12 |
| 3×3×3×3×3 | 30 | 31 |

The first cubic value agrees with the separately complete physical Lean
classification. These evaluations are examples of the theorem, not evidence
substituting for the general proof.

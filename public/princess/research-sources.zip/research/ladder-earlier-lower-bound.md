# Earlier independent lower-bound derivation

Preserved from the initial 12 September 2026 working proof. The shorter weight proof in `ladder-investigation.md` is now preferred; this argument remains a useful independent check.

## 3. A lower bound from expansion costs

Track the sum of the two cohort belief cardinalities. Initially it is
`2n`, and it is zero after a successful strategy's last inspection. It is
convenient to keep an eliminated cohort empty thereafter.

On a particular day, let `u≤m` be the number of useful probes, let `e` be
the number of cohorts newly eliminated that day, and let `g` be the total
increase in cardinality contributed by closed-neighborhood expansion of
the surviving sets. The total decrease is exactly

```
Delta = u−g.
```

If `e=0` and at least one useful probe is made, at least one survivor set
is nonempty and proper. It contributes at least one expansion, giving
`Delta≤m−1=M`. If no useful probes are made, `Delta≤0≤M`.
If `e=1`, simply `Delta≤m=M+1`. If `e=2`, then
`Delta≤m=M+1<M+2`.

In all cases,

```
Delta ≤ M+e.
```

Exactly two cohort eliminations occur in total, counted with multiplicity
if simultaneous. Summing over `t` days gives

```
2n ≤ Mt+2,       hence t≥ceil(2N/M).
```

No shape assumption about the intermediate beliefs was used.

## 4. When equality is impossible

Suppose `2N` is divisible by `M` and the lower bound `t=2N/M` is attained.
Then every day's preceding inequality must be an equality.

First, the cohorts must be eliminated on different days: simultaneous
elimination has a strict deficit of at least one unit. On the first
elimination day, equality requires a decrease of `m`, all `m` probes useful,
and zero expansion. The other cohort survives, so its survivor set must be
the entire path. It was therefore untouched that day and its pre-inspection
belief was full. All `m` probes eliminate the first cohort, whose belief
then has exactly `m` columns.

Before that first elimination, each equality day must use all `m` probes
and have exactly one unit of expansion. It has precisely one nonempty
proper survivor set; the other cohort's survivor set is full. In
particular, all `m` probes are aimed at a single cohort. That cohort's
belief decreases by `M>0`, and is subsequently proper. The strategy cannot
switch to the full cohort on a later equality day while the first remains
nonempty: the unprobed proper cohort expands by at least one, and a
nonterminal probe of the other cohort causes another expansion. An
elimination of the other cohort would also fail equality because the
surviving first cohort is proper.

Thus one fixed cohort is swept on every day up to its elimination. If that
elimination takes place on day `k`, it has `k−1` decreases of `M`, followed
by a final decrease of `m=M+1`. Hence

```
n = (k−1)M + m = kM+1,
```

which requires `N` to be divisible by `M`.

The only way `2N` can be divisible by `M` while `N` is not is that `M` is
even and `N mod M=M/2`. In exactly that residue class the elementary
lower bound requires one additional day. The argument also rules out a
putative one-day strategy in that residue class: both eliminations would
then be simultaneous and the inequality would be strict.


# Localization with an observed outgoing hole corner

13 September2026. Proposed uniform ordinary theorem, submitted for
independent review. This strengthens the all-radius near-pronic interval
when the existing erosion feature already determines the hole's outgoing
corner count. It introduces no new state. No full matching theorem follows.

Let w=2b+1>=5, n>=w be even, h=wn/2, 2<=r<=b and

    A_r=(r-1)(r-2),      C_r=r(r-1).

Suppose a physical support U has no own corner, N(U) has exactly one
opposite-colored corner o, A_r<|U|<=C_r, and surplus<=r. Then U is
connected under sharing a neighbor, its surplus is exactly r, and U
lies within distance2r-3 of o.

The proof is the one in `bridge-lower-frontier-all-radius-proof.md`
with its unnecessary outgoing-corner inference removed. Every component
has positive surplus>=2 and capacity<=s_i(s_i-1); the high branch is
excluded by h-r^2>r^2. Two components have total area at most
(r-2)(r-3)+2<=A_r for r>=3, while for r=2,3 their required surplus
already exceeds r. Surplus<=r-1 gives area<=A_r. The outgoing corner
is supplied by the hypothesis, so the old F00(r)=D_r threshold is no
longer needed. The small-side separator places the connected support in
the genuine quadrant at o. At the critical odd-width endpoint, the
alternating-fiber case has outgoing count0 when current count is0,
and is again excluded by the observed outgoing count1. The unchanged
upper-shadow argument gives radius2r-3.

For a survivor S and B=N(S), take U=complement B. The physical feature
e(B)=1 says exactly c(N(U))=1. Consequently

    c(B)=2, e(B)=1, A_r<h-|B|<=C_r, |B|-|S|<=r

forces

    |B|-|S|=r,       c(S)=1, e(S)=2.

Equality of the neighborhood-complement inclusion gives N(U)=complement S.
The first neighborhood contains exactly one current corner, while the
second neighborhood, radius<=2r-1, misses both opposite-colored corners
at distance>=n-1>=2b+1. This proves both survivor counts.

## Merger inheritance

In a triggering merged action, J=2 forces both component outgoing counts
to be2, and V=1 gives the merged observed erosion count. As before the
small branches are excluded by total holes<=C_r<h-r^2. The high branches
give d_l<=s_l(s_l-1). If both original surpluses were positive with
s1+s2<=r, their hole sum would be at most(r-1)(r-2)=A_r, contradicting
the trigger. Thus the other component is original-full-to-full and the
merger is an identity, transferring the complete feature rule. No memory
or physical interpretation of a synthetic merged set is assumed.

## Computation and its limit

The explicitly named `strong_band=True` variant in
`bridge_lower_frontier_probe.py` and `bridge_lower_frontier_nine.py`
uses A_r when target erosion v=1, retaining D_r otherwise. The old
all-radius variant remains separately selectable and its receipts remain
unchanged. The nine-threshold proof extends: the stricter band simply
changes the cutoff on original surplus for the wrong survivor triple.
Its intervals are now C_(r-1)<d<=C_r; at entry the preceding d=C_r+1
already required original surplus>=r+1, preserving target monotonicity.

This rule does NOT close the new25x26,k13 gap: the necessary solo clock
remains186 versus the anchored upper188, and at25x28 it gives236 versus238.
The reconstructed witness merely changes six survivor erosion choices
from0 to2; the source features already permit those choices. No target
belief sizes or times change. Thus this new physical rule does not
address the actual entrance-time obstruction in that witness.

The first lower-model size better than both anchored paths is at day28:

    (215,2,1) --[13 inspections; survivor(202,2,0)]--> (213,1,2).

It leaves112 holes with surplus11 and one hole corner, exactly the
near-square object from the earlier24x24 obstruction. Both anchored
cohorts have214 rooms at day28. Root is independently developing the
uniform transfer of the existing24-square shape and equality certificates
to larger boards; that physical/joint transfer is a separate result.

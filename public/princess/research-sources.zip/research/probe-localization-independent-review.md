# Independent semantic review: ProbeLocalization.lean

12 September 2026. Reviewer: frontier-state research agent, independent
of the root agent who wrote the module. **PASS on the semantic statement.**
This is a source review; the root separately reports the successful
kernel compilation. No new compilation was needed for this review.

Reviewed `lean/ProbeLocalization.lean` together with the definitions and
probe monotonicity in `lean/BeliefSemantics.lean`.

`possible adj initial probes t` is the belief before inspection t, after
exactly t earlier inspections and compulsory moves. Consequently a probe
at time t can affect the horizon endpoint exactly through walks of length
`horizon-t`. The direction and the subtraction in `cone` are correct.

The induction `restore_on_cone` takes a localized avoiding predecessor,
extends its reachability-to-danger by the actual outgoing edge, and uses
the resulting cone membership to recover the original missed-probe
condition. Its hypothesis `t≤horizon` justifies the subtraction identity;
there is no unproved path-consistency assumption.

The set `danger` is the unrestricted no-probe final belief minus the
original probed final belief. Removing probes can only enlarge beliefs.
If a new endpoint appears, it belongs to danger and hence to its own
zero-step cone; `restore_on_cone` then rules it out. This proves actual
set equality, not merely a one-sided strategy guarantee.

`exact_endpoint_in_region` uses the two correct antitone inclusions of
probe sets: canonical localized probes are contained in the larger-region
localized probes, which are contained in the original probes. Therefore
any larger retained spatial region is sound as claimed.

The theorem works on arbitrary directed graphs and arbitrary predicates;
no finiteness, matching, cardinality, or grid geometry is imported. In the
rectangle application, the cardinality bound on danger, its confinement
to a bounded band, and the finite physical edge table remain ordinary
mathematical results. The source does not purport to prove them in Lean.

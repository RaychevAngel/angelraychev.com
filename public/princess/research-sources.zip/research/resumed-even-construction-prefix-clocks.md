# Explicit anchored-prefix clocks and a conditional one-splice theorem

13 September2026. New ordinary derivations, sent to root for independent
review. The prefix parameter, neighborhood, erosion, and exit-clock
formulas subsequently passed independent algebra reviews by both
artifact_scope_assessment and split_manuscripts. The individual counting functions below use a fixed number of
standard numerical operations. Their iteration is still a recurrence,
and the result does not evaluate T_k(a,b) in fixed size.

## Exact prefix parameters

Work on width w=2r and length n=2s+epsilon>=w, with epsilon in{0,1},
h=wn/2. Let P_p(q) consist of the first q rooms of physical color p,
ordered by increasing x+y and, within a diagonal, decreasing x.
For q>0, write it uniquely as all color-p diagonals below d, together
with the rooms on x+y=d having x>=c.

Define, for any integer D and eta in{0,1},

    A_eta(D)=0 if D<eta,
    A_eta(D)=(m+1)(m+eta+1), m=floor((D-eta)/2), otherwise.

Then the number of color-p rooms with x+y<=D is

    C_p(D)=A_p(D)-A_((p-w) mod2)(D-w)
                    -A_((p-n) mod2)(D-n)
                    +A_((p-w-n) mod2)(D-w-n).

This is elementary inclusion-exclusion applied to the nonnegative
quadrant. It uses four fixed terms, not a variable-length sum.
Put v=s+epsilon(1-p), and define

    R_eta^+(q)=ceil((sqrt(eta^2+4q)-eta)/2),
    R_eta^-(q)=floor((sqrt(eta^2+4q)-eta)/2).

For q>0 the last diagonal is d=2m+p, where

    m=R_p^+(q)-1                         if q<=r(r+p),
    m=ceil((q-r(p+2-r))/(2r))             if r(r+p)<q<=r(2v+p-r),
    m=floor((w+n-2-p-(p xor epsilon))/2)
           -R_(p xor epsilon)^-(h-q)     otherwise.

The first case inverts the initial quadratic count. In the middle case,
only the even-width truncation is active and the count is
r(2m+p+2-r), hence linear. In the last case, rotate the omitted rooms
through180 degrees and invert the small complementary triangle. The
case boundaries are the counts at m=r-1 and m=v-1. Finally set

    ell=q-C_p(d-2),
    c=min(w-1,d)-ell+1.

For q=0 use d=p-2,c=w. Thus q is converted to geometric prefix
parameters by a fixed finite case distinction.

## Neighborhood and erosion counts

For q>0 and its parameters(d,c), put

    g_p(q)=C_(1-p)(d-1)
             +max(0,min(w-1,d+1)-max(0,d+2-n,c)+1).

Set g_p(0)=0. This is exactly |N(P_p(q))|, and N(P_p(q)) is itself a
prefix in the opposite phase. Indeed all earlier opposite-color
diagonals are full, and the neighbors on the last diagonal x+y=d+1
are exactly the rooms whose x coordinates lie between the displayed
lower and upper bounds.

Let e_p(q) count the opposite-color rooms every neighbor of which belongs
to P_p(q). Set e_p(0)=0 and e_p(h)=h. For0<q<h,

    e_p(q)=C_(1-p)(d-3)
           +max(0,min(w-1,d-1)-max(0,d-n,c)+1)
           +[d>=n and c=d-n+1].

The eroded set is again a prefix. Every diagonal through d-3 is full.
On diagonal d-1, both forward neighbors must lie on the target partial
diagonal, giving x>=c. The only exception is the room on the top side,
whose upward neighbor is absent: when x=d-n=c-1, its right neighbor
suffices, giving the one extra room shown. A room on a still higher
diagonal can qualify only at the top-right corner, and this requires
the target prefix to be full; that was handled separately.

The implementation `src/resumed_even_construction_prefix_arithmetic.py`
checks these formulas, actual prefix room sets, and actual eroded room
sets against literal finite-board neighborhoods. The receipt covers
1,172 prefixes on nine boards through24x24.

## Deterministic entrance and exit clocks

For a fixed left-bottom anchor and initial phase p0, define

    a_0=h,
    a_(t+1)=g_((p0+t) mod2)(max(a_t-k,0)).

The direct strategy at time t inspects the last min(k,a_t) rooms of its
current prefix. The next belief is exactly the prefix of size a_(t+1).
The first index t with a_t<=k is its final inspection day minus one.
Finite-clock uses here assume k>r. At an infeasible budget the recurrence
is still defined, but it need not terminate; its Python stopping loop is
not intended as a decision procedure for such inputs.

For an exit clock, put b_0(0)=b_0(1)=0 and

    b_(s+1)(p)=min(h,k+e_(1-p)(b_s(1-p))).

Then b_s(p) is exactly the largest phase-p anchored prefix capturable
within s days by strategies retaining prefixes at that anchor. There is
no optimization hidden in this recurrence: all its step functions have
the bounded arithmetic expressions above. To prove the statement,
inspect the final k rooms of the current prefix. Its surviving prefix
has neighborhood in P_(1-p)(b_s(1-p)) precisely when it lies inside
that target's erosion. Both sets are prefixes, so this is equivalent
to a single cardinality inequality. It gives the displayed recurrence.
Smaller same-anchor survivors dominate larger ones at every step, so
under-spending cannot improve this restricted clock.

For a right-bottom anchor, horizontal reflection changes the physical
phase by one. Its exit threshold on physical phase p is therefore
b_s(1-p).

## Conditional one-splice theorem

Choose nonnegative entrance and exit counts e,s, and a positive transport
length t. Start in physical phase0. Put

    A=P_left,(e mod2)(a_e),
    B=P_right,((e+t) mod2)(b_s(1-((e+t) mod2))),
    D=|A|-|B|.

If

    D+r*t >= r(w-1),
    D <= (k-r)*t+z(B),

then an explicitly prescribed solo strategy captures by day e+t+s:
use the deterministic entrance clock, the accepted virtual transport
word with bottom-root credit, and the deterministic exit clock. The
transport endpoint need only be contained in B, which is sufficient
for all later inspections. Its full-board palindrome captures by
2(e+t+s) days. A compatible central merger can save one day when the
two final supports fit the budget; it is a separate condition.

The first displayed condition follows from a general geometric bound.
For any canonical pyramid cutoffs a,b of even-width boards, delta=b-a
is2-Lipschitz and has sum -2D. If M=max(delta), then

    sum_x delta_x >= w*M-w(w-1),

because the sum of distances from the maximizer to all w positions is
at most w(w-1)/2. Hence M<=w-1-D/r. The first condition makes M<=t,
so the positive-part transport penalty vanishes and
F_t=D+rt. The second condition is exactly the accepted root-credit
upper bound. This geometric bound was independently checked by root.

The numerical size inequalities are O(1) in their supplied size and
root-count statistics. Obtaining those statistics from an arbitrary
height vector requires reading that input. For the prefix family here,
the fixed-size formulas above provide the relevant data.

This theorem is conditional on the selected e,s,t. Neither the existence
of suitable indices attaining the corrected necessary solo clock for
every rectangle, nor a fixed-size expression for those indices or the
clock, has been established. In particular24x24,k13 defeats the first
single-splice experiment at the necessary102-day clock: both anchored
entrance clocks need104 days, every tested102-day splice has negative
budget slack, and even the full two-bottom-prefix union family still
needs104 solo days. That is a restricted-family limitation, not a proof
that102 physical solo days are impossible.

Checkpoint correction: the102-day necessary clock mentioned above has now
been strengthened. The near-square history barrier and its independently
checked joint equality transfer give solo lower103 and full lower206 on
24x24,k13; the current full interval is206–207. The earlier102-day tests
remain valid falsifications of the weaker model's proposed attainment.
See `paper/sections/resumed-near-square-localization.tex` and the final
entry in `research/resumed-even-construction-log.md`.

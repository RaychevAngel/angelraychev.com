# Independent audit of T5(3×3×4)=36

12 September 2026 UTC. **Verdict: passed as a finite computer-assisted theorem.**
This is the single 36-room board, not a claim about every even cylinder.
No physical Lean formalization is claimed.

## Why the eight-count state space is exact

Partition a belief by its current physical checkerboard color and its four
longitudinal slices. Compress each of the eight subsets to a prefix of the
corresponding 3×3 parity order, preserving its size. The exact transverse
profiles are

    g0=(0,2,3,4,4,4),  g1=(0,3,4,5,5).

Their prefix neighborhoods are opposite-parity prefixes. For residual slice
sizes b_j, the compressed neighborhood in the opposite-color slice j has
size max(g_(p+j mod2)(b_j),b_(j-1),b_(j+1)). An arbitrary residual with
the same slice sizes has at least this many neighbors in that slice: its
neighborhood contains all three corresponding sets. All these compressed
neighborhoods are prefixes, so the cardinality comparison is inclusion in
the compressed arbitrary neighborhood.

This comparison can be iterated through a complete strategy. If the current
compressed belief has no more positions in each slice than the arbitrary
belief, choose in each compressed slice the prefix of size equal to the
minimum of its current size and the arbitrary residual size. The number
of deleted compressed rooms is no larger than the arbitrary useful quota.
The neighborhood comparison preserves the invariant for the next round.
Starting from the common full belief, an arbitrary successful search
therefore gives a no-longer compressed successful search. Conversely every
compressed move is an actual physical move. This proves equality of the
physical optimum and the eight-count optimum, without requiring globally
nested isoperimetric minimizers.

The counts are indexed by current physical colors. Moving swaps the two
four-vectors; no omitted time-parity state is needed. The resulting dynamics
are stationary. An earliest visit to a state dominates every later visit.

## Actions, horizons, and the final inspection

While the total count exceeds five, it suffices to enumerate exactly five
useful deletions. Any legal smaller allocation can be enlarged within the
remaining belief, and the next compressed belief only becomes smaller.
Subsequent choices can preserve that inclusion, so extra probes cannot
remove a winning possibility. Enumerating all bounded deletion compositions
over all eight counts therefore covers a strategy at least as good as every
under-budget strategy. When at most five positions remain, the next
inspection captures immediately.

An unpruned breadth-first search processes states by completed-round depth.
The first state with total count at most five occurs at depth35. Thus the
shortest capture takes36 inspections, including its final inspection. A
hypothetical35-day capture would have reached such a state by depth34 and
would already have been detected. Revisiting a state is the only pruning
in the independent search; no scalar lower-bound or beam cutoff is used.

## Independent implementation and evidence

`src/even_cube_independent_review.py` does not import the submitted search
or its max/profile transition implementation. It first checks the transverse
minimum-neighborhood tables on all48 arbitrary single-parity subsets. It
constructs actual36-room coordinate neighbors and checks all1,800 canonical
single-cohort states, obtaining their transitions directly from those
physical neighborhoods. It then enumerates all joint five-deletion actions
in a separate unpruned breadth-first search and physically replays the
first successful path.

The result independently agrees with the submitted unpruned search:

- 1,993 states expanded; 2,017 states seen;
- 1,109,364 raw joint transitions examined;
- first terminal state at completed-round depth35;
- actual36-day replay successful;
- 0.246 CPU seconds, one worker.

The machine-readable receipt is `even-cube-independent-review.json`.
The proof does not rely on the earlier pruned horizon35 run or the beam
search. Their admissibility therefore need not be trusted to accept this
finite result. Research is frozen after this audit.

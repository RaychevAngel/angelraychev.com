# A uniform one-day bracket for 24 by even-length rectangles

13 September 2026. New ordinary proof and exact finite arithmetic certificate
by the boundary-numeric branch; independently reviewed and accepted by root,
including the guarded-merger argument at the final precentral horizon. Uses the
independently reviewed physical day-28 barrier from
`bridge-boundary-history-transfer.md` and the accepted old corner-model merger.

## Result

For budget 13 and every integer n>=24,

    T_13(24,n)>=24n-370.

In particular, combining this with the newly proved construction and its
two-row extension gives, for every even n>=24,

    24n-370 <= T_13(24,n) <= 24n-369.

This is a uniform numerical one-day bracket, not an equality claim. The
lower proof also covers odd n. The upper in the displayed bracket uses the
even-length construction; no odd-length upper constant is inferred here.

Put h=12n. The transferred physical theorem says that after 28 full-board
inspection-and-move steps, the joint possible-position set has at least
2h-111 rooms. Its merged feature therefore has size at least h-111.
We evaluate the subsequent necessary-model lower uniformly in h, using
the OLD unrefined corner model with unrestricted surplus at 12. The new
critical refinements are not needed for this result.

## Two elementary capacity maxima

Use the existing model capacities F_ij(s), G_ij(s), their least-surplus
inverses S_ij(t), H_ij(d), and the three-threshold backward recurrence from
`bridge-corner-frontier-proof.md`. Direct substitution at s=11 gives

    (11+F_ij(11)) = ((110,121,85),
                     (132,102,70),
                     (112,85,57)),

    (G_ij(11)) = ((65,81,90),
                  (82,100,110),
                  (101,121,99)).

Rows index i=0,1,2 and columns index j=0,1,2. All nine domains are valid
at this surplus. By monotonicity of the capacities, these imply

    t>=133  => S_ij(t)>=12 for every i,j;
    d>=122  => H_ij(d)>=12 for every i,j.

The exact model surplus is min(S_ij(t),H_ij(h-t),12).

## Fixed initial segments, with no dependence on h

Consider the two backward seeds

    B_0=(0,-1,-1),           R_0=(6,6,6).

B describes capture within the indicated number of days. R describes
reaching a feature of size at most six after the indicated number of moves.
In the model, both backward sets consist of all valid states below the
respective three thresholds.

Exact substitution in the recurrence for 36 steps gives

    B_35=(133,134,134),      R_35=(134,134,134),
    B_36=R_36=(135,135,135).

The full two 37-row traces are retained in the finite receipt. For every
target used before step 36 its size is at most 134. Thus h-t>=154>121
for all h>=288: the high branch can never improve the unrestricted surplus
12. All source/target corner-state upper bounds are inactive in these
small states. Consequently these 36 substitutions are identical for EVERY
h>=288, not just for the base square on which they were checked.

The independent arithmetic check derives these initial segments directly
from the quadratic small capacities by enumerating only s=0,...,12; it
does not use the closed inverse-root implementation to obtain them.

## An arbitrarily long exact plateau

Suppose 135<=a<=h-122 and all three backward thresholds equal a. Both
displayed capacity implications apply. Every minimum surplus is therefore
exactly 12, for every source/target corner choice. All state bounds are
inactive, so the best survivor size in every choice is a-12. The backward
update with budget 13 is exactly

    (a,a,a) -> (a+1,a+1,a+1).

Both backward sequences consequently reach

    (h-121,h-121,h-121)

at time 36+(h-121-135)=h-220. The argument covers every intervening
integer state with one invariant; no variable-length numerical computation
is needed in the resulting formula.

## One fixed seven-step exit

Write a backward threshold triple as (h-d_0,h-d_1,h-d_2). Starting from
d=(121,121,121), the next seven triples of deficits are exactly:

| Added steps | Deficits from h |
|---|---|
| 0 | (121,121,121) |
| 1 | (120,120,119) |
| 2 | (118,118,118) |
| 3 | (117,117,116) |
| 4 | (115,115,115) |
| 5 | (114,114,113) |
| 6 | (112,112,112) |
| 7 | (111,111,110) |

Every target here has size at least h-121>=167>132. Its small branch is
therefore inactive below surplus 12. The update in deficit coordinates is
the h-independent formula

    d'_c=min_(i<=c,j) [d_j+min(H_ij(d_j),12)]-13.

The state caps are again inactive; all displayed deficits are at least
110. Thus these seven substitutions are identical at all h>=288. The
independent check computes the least high-branch surplus directly from
G_ij(s), s=0,...,12, rather than using H's closed inverse formulas.

Combining the three portions gives, for BOTH seeds,

    B_(h-214)=R_(h-214)=(h-112,h-112,h-112),
    B_(h-213)=R_(h-213)=(h-111,h-111,h-110).

The first index when either set contains any state of size at least h-111
is h-213. Earlier frontiers are smaller: the finite entrance, exact plateau,
and six preceding exit rows explicitly verify this, or one can use backward
set monotonicity. This proves the complete necessary-model calculation in
a fixed-size arithmetic expression.

## Direct application to the physical joint game

Set L=h-186. We prove that every full-board belief after L steps contains
at least h+7 rooms; the central intersection argument then supplies the
desired lower bound.

Let a_t be the joint possible-position count minus h, and use the accepted
guarded corner merger while a_t>13. At the first time it becomes at most
13, the whole prior history maps to a legal old-model solo history, which
can be cleared by one further model inspection. Such a crossing cannot
occur in the first 28 steps: it would give a model capture in at most 29
days from a full color class, whereas the fixed backward entrance has
B_29=(124,125,125), strictly below h>=288.

At time 28 the physical transferred theorem gives a_28>=h-111. If the
first crossing to at most 13 occurred at some t<=L-1, the merged history
would give a model capture from that time-28 feature in

    t-28+1 <= L-28 = h-214

days. This is impossible because B_(h-214) has maximum h-112. Therefore
the merger remains valid through time L. If a_L<=6, it would give a
model path from a size at least h-111 to a size at most six in L-28=h-214
steps, contradicted by R_(h-214). Thus a_L>=7, proving the claimed joint
cardinality bound. The guarded-merger issue is handled explicitly; no
automatic transfer of a time-filtered solo theorem is assumed.

Now take any proposed strategy of length 2L+1. Its first L inspections
and its final L inspections read in reverse each produce a physical
full-board belief of size at least h+7 at the middle day, by undirected
walk reversal. Their intersection has size at least

    2(h+7)-2h=14.

The middle inspection has budget 13 and cannot cover that intersection.
An avoiding walk therefore exists. Hence

    T>=2L+2=2h-370=24n-370.

The proof uses the genuinely joint day-28 restriction; two independent
solo cardinality bounds would not give the required merged time-28 size.

## Verification and the remaining square features

`src/bridge_boundary_numeric_24.py` stores the independent quadratic
substitutions, both complete initial traces, and the exit table in
`research/bridge-boundary-numeric-24-check.json`. In addition, it independently
propagates the full old-model graph backward for both seeds through 76
base-board layers and compares every state membership with the three
thresholds. All 130,872 memberships agree. The first complete run took
0.039898 CPU seconds. The unbounded result is the invariant argument above,
not an extrapolation from comparisons at several rectangle lengths.

For the constructive lane, the same receipt records a separate exact
forward-28/backward-75 intersection on the 24-square. With the physical
size floor 177, the refined critical model permits exactly

    (177,1), (177,2), (178,2).

The old model additionally permits (177,0). Thus a 103-day solo model path
does not force size 177 with one corner; a proposed next localization must
also address the other admitted features. This finite diagnostic is not
part of the uniform lower proof and asserts no physical attainment.

No new upper strategy, exact value inside the one-day bracket, manuscript
integration, or physical Lean verification is claimed by this branch.

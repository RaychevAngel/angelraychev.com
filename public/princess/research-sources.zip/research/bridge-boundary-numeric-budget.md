# Fixed-block lower and physical upper clocks at arbitrary even-width budgets

13 September 2026. Ordinary argument and targeted arithmetic audit,
independently reviewed and accepted by root, including the extra (2,0)
critical cap on n=2r+1 and the empty-middle-interval endpoint. This is a numerical evaluation theorem for
the accepted necessary model and for actual anchored-prefix searches.
It does not assert equality between them or physical attainment of the model.

## Uniform statement

Fix K>=1 independently of every input. Put w=2r>=4, n>=w, h=rn,
s=k-r and delta=s-1. Assume r+2<=k<h and K*delta>=r^2.

The exact critical three-threshold model capture clock, and its backward
frontier from a fixed capture or half-budget seed at an arbitrary prescribed
deadline, each use at most 3K+3 ordinary three-coordinate update blocks
and one bulk floor division. Each update already has fixed-size root formulas.

An actual fixed anchored-prefix solo duration, including its last inspection
count, or its residual at any prescribed day, uses at most 2K+1 ordinary
one-day blocks and one bulk division under the slightly weaker K*s>=r^2.
Both initial physical phases are allowed.

Thus the strongest critical-three-frontier physical lower, and the minimum
of the two prefix-palindrome uppers and the generic root-saturated upper,
are absolute O(1) numerical expressions in the displayed region. Fixing K=16
gives 51 blocks per lower-frontier evaluation and 33 per physical-prefix
evaluation. Two lower evaluations and two prefix evaluations suffice for
the entire lower/upper comparison: at most 168 such blocks and four bulk
divisions, with fixed-size arithmetic within every block. No variable
matrix order, state list, or unbounded iteration is hidden in this claim.

## Three-frontier spread and universal progress

Use the proved critical three-frontier update, with unrestricted cap r+1
and the exception cap r at (i,j)=(1,1). When n=2r+1, the second exception
(i,j)=(2,0) is present as well; the implementation retains it. After any first update its vector B
satisfies

    B0<=B1<=B2,  B1<=B0+1,  B2<=B1+1.

The ordering follows by enlarging the source-corner choice set. To prove
the adjacent spread bound, take a survivor with i current corners and size
q. If one corner must be removed to fit the smaller source class, replace
(q,i) by (q-1,i-1) and increase surplus by one, leaving the target fixed.
The established deletion inequality

    F_(i-1,j)(z+1)>=F_(i,j)(z)-1

preserves the low branch. The high capacity also weakens:

    G_(i-1,j)(z+1)>=G_(i,j)(z).

For the latter, A=2-i increases by one while the shifted quadratic argument
z-A-B is unchanged. The only branch change, A=B=0 to A=1,B=0, replaces
C2(z) by z^2+z, which is no smaller. The domains remain valid. An
unrestricted transition stays unrestricted; losing the special i=1,j=1
critical pair raises its surplus from r to r+1, which is unrestricted.
The same reasoning applies when dropping i=2 to i=1 removes the extra
(2,0) exception at n=2r+1.
If q=1, discarding it leaves zero, and the claimed one-unit bound is
automatic. The state caps differ by exactly one between adjacent source
corner classes. Therefore their backward thresholds differ by at most one.

For B2>=k>=r+2 choose survivor corner i=0 and the largest target class.
Unrestricted surplus r+1 gives a valid positive survivor B2-r-1<=h-2.
Consequently

    next B2>=min(h,B2+delta).

For either B0=(0,-1,-1) or the half-budget seed (floor(k/2))^3, the first
updated B2 is at least k. Hence, until B2 reaches h, after t>=1 updates

    B2>=t*delta+r+1,  B0>=t*delta+r-1.

When B2=h the adjacent spread inequalities force the whole vector to its
state caps (h-2,h-1,h); this is absorbing for either backward seed.

## One common affine interval, and normalization in two steps

Set

    A=r^2+r+1,  H=r^2+1,
    U=h-max(H,s+1).

All finite low capacities at surplus r are at most r^2, so the condition
target>=A forces its inverse surplus above r. Likewise all high capacities
at surplus r are at most r^2, so at least H holes forces its inverse
surplus above r. If every coordinate of B lies in [A,U], only the cap
branches apply. Writing B=(x,y,z), the exact update is

    (z+delta, max(z,y+1)+delta, max(z,y+1)+delta).

The additional (2,0) cap on n=2r+1 does not affect this formula: for
n<=2r+1, U<=h-r^2-1<=r^2+r-1<A, so the common interval is empty.
Every board on which this affine formula is used has only the (1,1) cap.

The definition U<=h-s-1 keeps all resulting state caps inactive.
Because y<=z, the output is either an all-equal vector or

    V(a)=(a-1,a,a).

An all-equal vector becomes a V-vector in one more update, and exactly

    V(a) -> V(a+s).

Thus at most two ordinary updates normalize any vector in the common
interval, provided their sources remain there. If a source leaves at the
upper end, the calculation proceeds directly to the terminal portion.

## Absolute block counts, including short boards

Use 2K conditional updates while B0<A and the full state is not yet
admitted. If not finished, the progress bound gives B0>=2K*delta+r-1>=A:
here 2r^2+r-1>=r^2+r+1 for r>=2. Hence this fixed entrance always suffices.
It also covers boards where the common interval is empty: such a board
either finishes in the entrance or is already in the terminal portion.

Use at most two normalization updates whose sources are in [A,U]. If
the remaining vector is V(a) with a<=U, take exactly

    q=1+floor((U-a)/s)

translation steps at once, replacing a by a+q*s. This exits above U.
For a prescribed deadline, cap q by the number of remaining updates.

At entrance to the terminal portion, B2>U, so

    h-B2 <= max(r^2,s).

Universal progress admits the full state in at most
max(K,ceil(s/delta))<=K+1 updates, since s=delta+1. Thus the total
is at most 2K+2+(K+1)=3K+3. A deadline exhausted in an earlier block
stops the calculation there; all remaining conditional blocks do nothing.
The exact first capture time is recorded before the vector becomes
absorbing. Every count in this prescription is bounded independently
of input parameters because K was fixed in advance.

## An even shorter exact evaluator for a physical prefix

The already proved anchored-prefix plateau says, in both phases,

    g_p(q)=q+r when (r-1)^2+1<=q<=h-r^2+r-1.

Every prefix also has g_p(q)<=q+r, by its canonical one-unit height
envelope. Precisely, Lemma `lem:pyramid-envelope` in
`paper/sections/pyramid-envelope-lemma.tex` supplies neighborhood containment
in the height-plus-one envelope. There are only r transverse columns of
the newly added physical parity; each contributes at most one new room,
and clipping or empty fibers only removes contributions. Hence its size
is at most q+r. The same deduction is used in the accepted tail proof in
`research/bridge-upper-transport.md`, under "Two-row length extension".
Therefore a full-budget one-day step satisfies

    f_p(x)<=max(0,x-s),

and is exactly x-s in the common source interval

    ell=k+(r-1)^2+1 <= x <= u=k+h-r^2+r-1.

The full initial excess above u is h-u=r^2-r+1-k<=r^2. Under K*s>=r^2,
K conditional ordinary steps capture the cohort or place it at x<=u.
If ell<=x<=u, take q=1+floor((x-ell)/s) affine steps at once, subtract
q*s, and change physical phase by q modulo two. Otherwise omit the bulk.
The remaining size is at most

    ell-1=k+(r-1)^2=s+r^2-r+1<=s+r^2,

so K+1 further ordinary steps capture it. This proves 2K+1 total blocks.
The last preinspection size is retained in the last ordinary block, giving
the exact optional central merger of two reflected copies. Prescribed-day
residuals simply cap the bulk step or stop an ordinary block. The same
argument applies from any partial canonical prefix, not just full size.

## Physical lower/upper expressions

Let tau be the first time the capture frontier admits (h,2). At L=tau-1,
evaluate the half-budget backward frontier R_L. The model reaches size
at most floor(k/2) from full size within L moves exactly when R_L(2)=h.
The accepted guarded-merger lower-clock theorem therefore gives

    Lower = 2*tau-1 + indicator(R_L(2)<h).

For each initial prefix phase let t_p be its exact solo duration and a_p
its final preinspection size. Reflection across the even short axis
permits two opposite cohorts with the same residual, giving the actual
upper

    Upper_prefix = min_p [2*t_p - indicator(2*a_p<=k)].

Taking its minimum with the existing fixed-expression generic upper is
also valid. Equality of these explicit quantities proves the physical
capture time on that numerical subfamily. A strict gap is not an exact
classification and does not show that either physical upper is optimal.

## Targeted independent checks and the linear-budget boundary

`src/bridge_boundary_numeric_budget.py` implements the fixed block
prescription. The receipt `bridge-boundary-numeric-budget-check.json`
compares every deadline in 140 selected finite cases against the direct
three-frontier and physical-prefix recurrences: 6,811 comparisons agree.
It includes K=1,4,16, r=2,3,5,10,20,50, threshold and adjacent budgets,
and several lengths. Four further bounded evaluations use length 10^12+1
and r up to1000. The ordinary proof supplies unbounded validity; these
checks test stopping, normalization, phase, and bulk-count details.

Root's separate linear-budget search suggested a one-day gap for k>=2r.
Exact agreement is false: 24x27,k25 has critical lower41 and both fixed
prefix full uppers42; generic upper48. Its critical solo duration21
equals both prefix durations21, but the model permits a precentral
half-budget residual whereas the prefix final sizes are13 and15.
Also40x41,k41 has critical solo31, prefix solo32, and final prefix sizes5
and9; its full lower62 and prefix upper63 differ by one for a different
reason. These are model/upper gaps, not physical nonattainment proofs.

Nor do the entire frontiers coincide at k=2r: on40x80,k40 the critical
three-frontier first exceeds both prefix backward capacities at day13,
with (355,356,356) versus(354,355), and its lead later reaches four.
A proof of a uniform linear-budget one-day interval must handle these
full-start and last-layer effects rather than identify all partial states.
The proposed linear-budget coupling remains unproved.

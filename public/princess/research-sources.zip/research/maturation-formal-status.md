# Three formal components in the consolidated checkpoint

13 September 2026. New source: `lean/FastestAncestry.lean`.

The module imports only `Std` and adds no axioms, admissions, unsafe code,
or native computation. Its individual check preceded the new 83-module release verification;
the source-specific full receipt is authoritative for the final package.

## What is kernel checked

* `step_individual` and `step_concentrated`: each shared-budget inverse
  transition respects the full-budget scalar capacities and total bound.
* `low_total_persists`: a positive-minority successor of a state below the
  smaller solo capacity remains below the smaller next capacity.
* `pure_high_primary`: a bounded secondary cannot masquerade as the primary
  when a high-total trajectory passes through a pure state.
* `high_primary_step` and `trace_high_primary`: the complete ancestry
  induction, including all intermediate steps, actual nonnegative quota
  allocations whose sum is at most `m`, and initial-cohort phase changes.
* `midpoint_obstruction`: two such high-primary states cannot fit within the
  central budget if both the scalar residual and secondary-color bound
  exceed that budget.
* `reset_midpoint_obstruction`: the composed conclusion for two independent
  histories, deriving their ancestry properties internally from the stated
  recurrence and fresh-secondary hypotheses.

The formal induction uses the inverse concentration inequalities directly;
it does not assume that the fastest initial cohort has fixed order or that
the ancestry conclusion already holds. It also avoids assuming arbitrary
partial-state serial optimality.

## Explicit remaining interpretation

`InverseSystem` is a structure requiring monotonicity, the two inverse
concentration inequalities on a stated finite domain, and vanishing of the
minority inverse at inputs zero and one. These are the mathematical premises
already established for odd rectangles in ordinary proofs, but their root
formula instances are not added here. The trace also explicitly assumes
the fresh-secondary bound and that the supplied reset state is pure.

The physical odd-rectangle compression theorem, pure-reset replacement,
width-only clock `L_b`, and physical midpoint theorem remain outside this
module. Therefore the new kernel check certifies the decisive abstract
ancestry/midpoint argument, not the entire minimum-budget rectangle formula.

A source-specific compilation receipt is saved separately as
`research/maturation-fastest-ancestry-lean-verification.json`.

## Second new component: clipped physical pyramid erosion

`lean/ClippedPyramidErosion.lean` also imports only `Std` and is separately
kernel checked, with no added axioms or admissions.

It represents each fiber by actual nonnegative room heights, its parity
bit, and its virtual last height `s−2+2k`. The theorems prove:

* `height_clipped`: subtracting one from every cutoff and clipping at the
  opposite empty height is exactly `k↦k−1` on root-phase fibers and
  `k↦k` on the others; empty fibers remain empty.
* `eroded_edge` and `eroded_fits`: the construction preserves the edgewise
  height difference of one and the finite cylinder's top bound.
* `neighbor_in_original`: every valid cylinder neighbor of an actual
  eroded cell lies in the original region. Both longitudinal and transverse
  edges, and both finite physical boundaries, are handled explicitly.
* `mem_fiberRooms_bounded`, `rooms_are_cells`, `rooms_nodup`, and
  `rooms_length`: the enumerated finite room list is exactly the represented
  region, without duplicates when transverse vertices are listed once;
  its length is the sum of the fiber counts.
* `exact_loss` and `room_cardinality_loss`: erosion loses exactly the
  number of occupied root-phase fibers. If all root fibers are occupied,
  this is the size of that transverse bipartition. Empty fibers in the
  other phase are allowed, as required by the sharper envelope theorem.

The abstract transverse graph and its bipartition/height conditions are
explicit parameters. No graph-distance threshold is assumed as an axiom:
the module's final loss theorem directly requires root occupancy. The
ordinary distance argument proving that occupancy from `k>B_(Q,p)`, the
closed-form path thresholds, prescribed-size ideal enlargement, and the
complete high-budget game constructions are not formalized here.

Its independent receipt is
`research/maturation-clipped-erosion-lean-verification.json`. These first two
modules were checked individually before the third component below. The
consolidated release has a fresh full receipt covering all 83 sources.

## Third component: convex capacities and all punctured root costs

`lean/ConvexCapacityConvolution.lean` constructs least inverses by finite
search from an unboundedness witness. Monotonicity and discrete convexity
are explicit capacity properties; the endpoint maximum is derived from
increasing increments rather than assumed. The two clipped candidates
attain the exact inverse-cost minimum on every integer interval.

Concrete square and pronic capacities recover the earlier root calculation.
Triangular, truncated-quadratic and maximum constructors instantiate
C_h(s)=max(s(s-1)/2,s(s-h)) for every natural h, including flat initial
levels. `punctured_exact_minimum` has only the standard three axioms in
its printed dependency report. This proves the complete arithmetic
optimization for these capacities, not the geometric quadrant theorem.

Independent acceptance and exact final source hash are recorded in
`maturation-convex-capacity-independent-review.md` and
`maturation-convex-capacity-final-independent-check.json`.

# Exact quadrant profiles beyond a forbidden initial triangle

13 September 2026. Root derivation. **Ordinary theorem independently
reviewed and accepted by Euler; not yet promoted to the manuscript or website.**
This seeks one theorem containing the ordinary square/pronic bounds and
all initial-diagonal corner restrictions.

## Statement

In the nonnegative square-grid quadrant, fix checkerboard parity p in
{0,1} and r>=0. A finite support S may contain only that parity and must
avoid the r initial diagonals x+y=p,p+2,...,p+2(r-1). Its neighborhood
is still taken in the WHOLE quadrant; the forbidden cells are constraints
on S, not removed graph vertices. Put h=2r+p and

    C_h(s)=max(s(s-1)/2, s(s-h)),       s>=0.

For every nonnegative integer s, the maximum size of such a support with
surplus |N(S)|-|S| at most s is exactly C_h(s). The empty set is permitted. For every k>0
the exact minimum neighborhood size is therefore

    k + min{s>=0: k<=C_h(s)}.

Equivalently, the minimum surplus is the smaller of the two integer
quadratic roots specified by k<=s(s-1)/2 and k<=s(s-h). For h=0 this
is ceil(sqrt(k)); for h=1 it is the usual pronic root Q(k). The missing
even origin is h=2. Omitting both odd neighbors of the origin is h=3.

## Compression and exact layer cost

Compress each permitted diagonal toward smaller y, retaining its count
a_j on x+y=2j+p, of length l_j=2j+p+1. Counts for j<r vanish. The
already proved square diagonal compression, applied inside a sufficiently
large square, does not increase the quadrant neighborhood. No far square
boundary is reached, before or after compression. It preserves the
forbidden-diagonal condition.

Set epsilon_j=1 if a_j=l_j, and zero otherwise. For j>=0 the output
diagonal x+y=2j+p+1 has exactly

    n_j=max(a_j+1_[a_j>0], a_(j+1)-epsilon_(j+1))

neighbors. For p=1 there is also the initial output x+y=0, of count
n_(-1)=a_0-epsilon_0. For p=0 set n_(-1)=0; the same expression is
zero because a_0 is either zero or the full singleton. Thus it is valid
in both cases. All layer contributions are prefixes at the same end.

Put delta_j=n_j-a_j for j>=0, delta_(-1)=n_(-1). These are nonnegative,
and their sum is the actual compressed surplus delta. They satisfy

    delta_j >= 1_[a_j>0],
    delta_j >= a_(j+1)-a_j-epsilon_(j+1).

## One dichotomy proves the capacity bound

Let j_1<...<j_L be the occupied input diagonals, and let f_t count the
full ones through j_t. Telescoping from the initial output through the
output immediately below j_t bounds that prefix surplus below by
a_(j_t)-f_t. The remaining output surplus is at least L-t+1, one for
each occupied diagonal from j_t onward. Hence

    a_(j_t) <= delta-L+t-1+f_t.                         (1)

If no occupied diagonal is full, f_t=0 and the initial surplus before
the first occupied diagonal is at least one. Thus L<=delta-1 and

    |S| <= L*delta-L(L+1)/2 <= delta(delta-1)/2.

The last quadratic is increasing over integers 0<=L<=delta-1.

If the first full diagonal has occupied rank u, then f_u=1 and
j_u>=r+u-1. Its size is at least h+2u-1. Applying (1) at that rank
therefore gives

    h+2u-1 <= delta-L+u,
    L <= delta-h-u+1 <= delta-h.

For every t, f_t<=t; summing (1) with this weaker bound gives
|S|<=L*delta<=delta(delta-h). These two cases prove the bound at the
actual compressed surplus. Both displayed capacity branches are
nondecreasing wherever they can dominate: the triangular branch always,
and the second branch when delta>=h. Thus C_h(delta)<=C_h(s) if
delta<=s. Compression consequently proves the assertion for arbitrary
uncompressed S as well.

## Sharpness, including every intermediate cardinality

There are two nested families, described entirely by their diagonal
counts.

For h>=1, take the partial ramp

    a_(r+i)=i+1,   i=0,...,s-2,

with every other count zero. Each selected diagonal is proper because
its length is h+1+2i>i+1. Its size is s(s-1)/2, its initial surplus
is one, and each of its s-1 occupied diagonals contributes one more.
Thus its surplus is s. To interpolate, retain a complete shorter ramp
and fill any positive number of cells of its next diagonal up to the
next ramp length. That addition raises surplus by exactly one, regardless
of the partial fill. Starting from the empty ramp covers every positive
cardinality up to a ramp's capacity at no greater surplus.

For s>=h+1, take all the permitted diagonals

    a_(r+i)=h+1+2i,   i=0,...,s-h-1.

There are L=s-h full diagonals. Their size is L(h+L)=s(s-h); initial
surplus h and one per occupied diagonal give total s. Appending a
partially filled next diagonal raises the surplus by exactly one:
its downward contribution fits inside the preceding full diagonal's
upper neighborhood, including when the new diagonal becomes full.
It therefore realizes every cardinality between two successive nonempty
full-block capacities with the larger surplus. For the first block, a
partial initial layer of v<h+1 rooms has surplus v+1<=h+1, while its
full h+1-room layer has surplus h+1. This separately handles the empty
predecessor, for which a one-unit surplus-increase claim would be false.

The full-block branch dominates the ramp branch when s>=2h-1. For
h>=2 its first dominant positive level has s>=h+1. At a tie either
family is enough.
For h=1, full blocks dominate at every positive capacity and begin at
s=2; intermediate initial size one has surplus two. For h=0, full
blocks alone give the ordinary square capacities s^2 from s=1 onward,
again interpolated by a partial last diagonal. Hence every cardinality
between the preceding maximum and C_h(s) is realized by whichever
branch supplies the new maximum. Zero capacities cause no exception.

## Intended use and limitations

The theorem concerns finite sets in the quadrant and exact neighborhood
profiles. It does not assert temporal compatibility of its minimizers
inside an arbitrary earlier belief. On an even-width half-strip, a
boundary-free transverse matched row splits certain corner restrictions
into independent quadrants with h=2 or h=3. Since C_h is the maximum
of convex quadratics, allocations of a total surplus between two such
parts can often be optimized at endpoints. Critical surplus equal to
half the strip width still needs the separate matched-row argument.

## Independent verification

Euler's independent mathematical audit accepted the capacity proof and
all-size attainment, including both parity conventions, gaps between
occupied diagonals, zero support, crossover levels, and the first full
block. His raw-coordinate check covered 107,712 arbitrary supports and
14,969 constructed witnesses in 0.34 CPU seconds, with no failures.
The unbounded proof is independent of those finite checks. See
`maturation-punctured-quadrant-independent-review.md` and
`maturation-punctured-quadrant-independent-check.json`.

## A general two-candidate convolution consequence

New corollary submitted for independent review. Let A(s),B(s) be any
nondecreasing, unbounded, discretely convex integer capacities on
nonnegative integers, with A(0)=B(0)=0. Put
alpha(k)=min{s:k<=A(s)} and beta(k)=min{s:k<=B(s)}.
For integers 0<=l<=u<=S, the minimum of

    alpha(y)+beta(S-y),        l<=y<=u,

is attained at one of the two explicit candidates

    y_1=min(u,A(alpha(l))),
    y_2=max(l,S-B(beta(S-u))).

To prove this, take any feasible y of cost t, and set
a=alpha(y), b=beta(S-y). Then a+b=t,
a>=alpha(l), b>=beta(S-u), and A(a)+B(b)>=S. The function
A(z)+B(t-z) is discretely convex, so its maximum over
alpha(l)<=z<=t-beta(S-u) occurs at an endpoint. At the first endpoint
one has A(alpha(l))+B(t-alpha(l))>=S; the candidate y_1 lies in the
prescribed interval, has first cost at most alpha(l), and its other
count is at most B(t-alpha(l)). If y_1 is clipped to u, this uses
beta(S-u)<=t-alpha(l) and monotonicity of B; otherwise it follows
directly from the endpoint capacity sum. Thus its total cost is at most t.
The other endpoint gives y_2 symmetrically, using alpha(l)<=t-beta(S-u)
if it is clipped to l. Both candidates are legal
by the definitions of the inverse capacities. The minimum over the two
is therefore the full minimum.

Every C_h above is such a convex capacity, since it is the maximum of
two convex quadratics restricted to nonnegative integers. Consequently
the old opposed inverse-pronic/square-root theorem, with capacities
A(s)=s(s+1) and B(s)=s^2, is an instance of this more general lemma.
Its inverse-pronic root is rho, not the Q root from h=1. The lemma also handles any two deleted-triangle
profiles. No interval enumeration is required. The old Lean theorem
remains a verified special case; it is not claimed to formalize this
new general capacity assertion. Euler independently accepted this
general lemma after checking both clipped-endpoint cases.

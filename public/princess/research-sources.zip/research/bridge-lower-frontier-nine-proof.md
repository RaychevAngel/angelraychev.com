# Exact nine-threshold backward frontier for the erosion relaxation

13 September2026. Proposed ordinary theorem submitted for independent
review. It concerns an explicitly necessary relaxed model, not physical
attainment of its paths or a matching full-board formula. Every transition
of the recurrence below takes a fixed number of integer/root operations;
iterating it is still an evaluation gap under the user's O(1) criterion.

## Model

Take the odd-width/even-length erosion model with its proved merger
weakening: remove only the two positive lower-cardinality bounds, retaining
all upper bounds, coupled deletion charges, corner closure and maximal
survivor constraints. Add the all-radius near-pronic interval filters from
`bridge-lower-frontier-all-radius-proof.md`. DROP all triangle history flags.
Their removal is a further legitimate relaxation, so the existing merger
proof applies without its flag clauses. No new geometric sufficiency is
asserted. Parameters satisfy b>=2, w=2b+1, n even>=w, h=wn/2, and1<=k<h.
For terminating minimum-budget use below k=b+1. Formula closure itself
also permits other k, with the coupled deletion charge explicitly checked.

Each positive state(a,c,e) has0<=c,e<=2 and

    1<=a<=H_ce=h-4+c+e.

Zero has only the feature(0,0,0). Let B_t(c,e) be the maximum positive
size in this feature class capturable within t days, or zero if none.

**Proposed theorem.** The capturable set in every feature class is exactly
the initial size interval1..B_t(c,e). Thus nine scalar thresholds describe
the entire backward frontier. They satisfy the explicit recurrence below.

## Fixed-size inverse functions

Let R(x)=ceil(sqrt(max(0,x))), and for integer m>=0 define

    A_m(x)=min{z>=0:z(z+m)>=x}
          =max(0,ceil((-m+sqrt(m*m+4max(0,x)))/2)).

Let Q(x)=0 for x<=0, and Q(x)=ceil((1+sqrt(1+4x))/2) for x>0.
These inverses use only a fixed number of standard operations. Exact
integer arithmetic in the accompanying script verifies endpoints.

For target size T and fixed(v,u,j), the smallest sigma in the domain
of P(v,u,j;sigma) for which T<=sigma+P(v,u,j;sigma) is L(T;v,u,j):

    v+2j + A_4(T-2v-3j-u),                         u>0;
    v+2j + A_3(T-2v-3j),                           u=0<v;
    2j+min(A_5(2T-6j), A_2(T-3j+2)),               v=u=0<j;
    min(A_1(2T), Q(T)),                            v=u=j=0.

These follow by substituting z=sigma-v-2j into the four already proved
P branches. In the third case, the two branches of H(z+2) yield
sigma+P=max((z*z+5z+6j)/2,z*z+2z+3j-2).

For d>=0 and(A,B) in{0,1,2}^2, let K(d;A,B) be the smallest sigma in
the domain of F_(A,B)(sigma) with d<=F_(A,B)(sigma). Its formula is

    A+2B-2+max(2,Q(d-A-2B+2)),                     B>0;
    A-1+max(1,R(d-A+1)),                           B=0<A;
    min(Q(2d), 1+R(d+1)),                          A=B=0,d>0;
    0,                                            A=B=d=0.

The positive domains of the mandatory corner pieces are essential here;
one must not choose the smaller roots outside these domains.

## Maximum survivor for a fixed target

Fix a target(T,j,v), T>0, and survivor corner counts(i,u) with
0<=i<=v<=2 and0<=u<=j<=2. Set delta=v-i>=0 and d=h-T. With q the
survivor size, closed surplus is sigma=T-q-delta. Therefore

    q=T-delta-sigma,     q+delta=T-sigma.

The unfiltered closed profile admits exactly every sigma at or above

    theta=min(L(T;v,u,j), K(d;2-j,2-v), b+1,
              b if(v,j)=(2,0), otherwise infinity).

Indeed low/high branches are monotone above their domain thresholds.
The critical exception supplies sigma=b, joined immediately to the
unrestricted range sigma>=b+1. Either a low/high branch also implies the
unconditional size profile: P and F are bounded by sigma^2, and actual
surplus is sigma+delta. Critical/unrestricted surpluses are at least b.

At most one all-radius interval is active for a fixed hole size d.
Put r=Q(d). If

    j=2, 2<=r<=b, D_r<d<=r(r-1), (i,u,v)!=(1,2,1),

set ell_band=r+1-delta; otherwise set ell_band=0. The exact all-band
restriction is sigma>=ell_band: every original surplus less than r was
already excluded by the old capacities, and surplus r is the additional
forbidden value for the wrong triple. For the right triple there is no
additional lower bound. Exact dual-pronic rules are included in the band
endpoint and impose nothing extra.

The survivor upper bound q<=h-4+i+u supplies one more lower bound on sigma.
Consequently the maximum permitted positive survivor is

    S_(i,u,j,v)(T)
      =max(0,T-delta-max(theta,ell_band,T-delta-(h-4+i+u),0)).       (S)

Set S(0)=0. A zero output in(S) means no nonempty survivor, not a legal
q=0 action to this positive target.

## Two monotonicity facts

For fixed target and features, admissible positive q form an initial
interval. Decreasing q increases sigma. All profile branches and feature
upper bounds become weaker. An active all-band restriction is itself a
lower bound on sigma, so this remains true after filtering.

For fixed i,u,j,v, S(T) is nondecreasing in T throughout the target feature
domain. Without the band restriction: L(T) increases by at most one per
unit increase of T, because sigma+P(sigma) increases by at least one
throughout its integer domain. K(h-T) is nonincreasing in T. Hence every
candidate T-delta-theta and their maximum is nondecreasing; clipping at
the constant survivor cap preserves this.

For the band, its cutoff is constant within an interval and disappears
at the high-T endpoint. At its low-T entrance, the previous hole size is
r(r-1)+1. A profile at original surplus<=r is already impossible there:
the high bound is at most r(r-1), while the small branch with outgoing
corner count2 has target size<=r^2, less than h-r(r-1)-1 on the stated
boards. The critical exception has outgoing count0. Thus the previous
target already required original surplus>=r+1. At the entrance the new
constraint cannot make S smaller: keep the same q and raise T by one,
which increases original surplus by one and preserves raw feasibility.
Distinct r-bands are disjoint; the preceding check covers every entrance.
This proves monotonicity including the only potentially adverse jumps.

## The nine-threshold recurrence

Initialize B_0(c,e)=0 for all c,e. For each source(c,e), take the maximum
in the following expression over the fixed set of indices satisfying

    i<=c, u<=e, u<=j, i<=v, i>=max(0,c+v-2),
    c-i+e-u<=k.

Then

    B_(t+1)(c,e)
      =min(H_ce, k+max(0, max_(i,u,j,v) S_(i,u,j,v)(B_t(j,v)))).    (B)

The number of indices is at most81 per source; every function uses a
fixed finite list of square/pronic inverses. There is no scan over sizes,
surpluses, inspections, or board-dependent feature lists in one update.

**Proof by induction.** At t=0 no positive state is capturable. At t+1,
source sizes<=k clear directly. For a nonempty survivor landing in a
t-day capturable target of class(j,v), target size is at most B_t(j,v).
Monotonicity of(S) bounds its survivor by the displayed S at that endpoint.
Since at most k rooms are inspected, (B) is necessary.

Conversely, choose an index tuple achieving the inner maximum Q>0,
and the corresponding target endpoint. Let deletion-feature loss be
ell=c-i+e-u<=k. For a source size a in(k,B_(t+1)(c,e)], choose

    q=min(Q,a-ell),      p=a-q.

Then q>=a-k>=1, p<=k and p>=ell. Crucially

    H_ce-ell=h-4+i+u,

exactly the survivor cap. Thus any source size up to
min(H_ce,k+Q) has enough room to realize the coupled deletion charge,
without any extra condition. The chosen q is at most Q, so the initial
interval property supplies its target transition. All remaining feature
and maximality inequalities are precisely those imposed on the indices.
The target is capturable by the induction hypothesis. Every source size
in the asserted interval is therefore admitted by the model, proving
the exact recurrence and interval description.

This is a theorem about the relaxed feature game; its converse is MODEL
attainment, not physical room-set realization.

## Verification and remaining objective

`src/bridge_lower_frontier_nine.py` implements these formulas separately
from the old graph builder. The graph comparison checks the equivalence
of every state/deadline pair with the nine inequalities a<=B_t(c,e),
not only agreement of a full-board clock. Initial checks pass7x8,k4 and
11x12,k6, with8,225 and37,505 equivalences respectively. Receipts are
`research/bridge-lower-frontier-nine-check.json`; additional rows are
recorded there only after completion.

The missing matching theorem is now an invariant comparison between this
explicit nine-number recurrence and the two anchored prefix clocks, plus
the preterminal residual needed to exclude a one-day central saving.
The recurrence alone does not establish either comparison uniformly.

# Independent review of the first two conditional strip profiles

13 September 2026. Root review of `maturation-even-transitions.md`
Sections 8--9. **PASS for the stated half-strip profiles and guarded
transition inequalities.**

The missing-origin quadrant compression preserves cardinality and the
missing diagonal. The exact output layer is the maximum of two prefixes;
the full-layer correction is necessary and has the stated sign. Initial
surplus and the occupied-layer contributions are disjoint. Telescoping
the remaining contributions gives precisely the claimed pronic area
bound, which applies to arbitrary original supports by monotonicity.

In the matched half-strip, a row with no outgoing boundary must be empty,
since a nonempty finite subset of a connected horizontal ray cannot be
closed. This supplies TWO empty transverse physical rows. The two pieces
have disjoint neighborhoods, including the layers inside that gap, so
their quadrant surpluses add exactly. When every matched row has one
boundary point, each occupied row must be an initial interval. The
missing current favorable corner makes its endpoint row empty. The
directed even-position rungs give the stated bound c_(i+1)<=c_i+2,
and hence size<=b(b-1). These cover all cases of surplus at most b.

For attainment of the omitted-corner profile above that threshold, the
empty-fiber distance bound at transverse vertex 1 is b(b-1)+1. A larger
pyramid therefore contains (1,1) and the origin. Deleting the origin
does not remove either of its neighbors from the neighborhood. This
attains the required extra unit of surplus. The smaller odd-quadrant
prefixes fit in the strip and omit the opposite favorable corner.

For the outgoing-corner profile, the right quadrant part is nonempty
whenever the next favorable corner is a neighbor. Its odd-parity
surplus is at least two. Combining the square and pronic bounds gives
the claimed pronic capacity below the strip plateau. The large-size
attaining pyramid contains the bottom root adjacent to the next
favorable corner, by the sharp root threshold. The two conditional
inequalities may both be imposed as lower bounds, but their separate
attainment does NOT imply simultaneous attainment inside an arbitrary
belief.

One gap was found in the initial local 6x6 illustration: an initial
pyramid avoiding the far row need not have a neighborhood avoiding it.
The author corrected the illustration to an explicit four-room corner
triangle whose neighborhood stays in rows 0--3. The illustration now
shows incompatible local scalar choices without claiming by itself to
exclude every physical joint search. Each use of a half-strip profile
on a finite board must separately justify its far-boundary condition.

# Independent review: the even 3 × 3 cylinder boundary certificate

12 September 2026. Reviewer: the frontier/geometry lane.

**Pass.** This reviews only the arbitrary-support compression,
all-length finite automaton, and no-consecutive-critical-surplus lemma.
Root separately reviews the scalar potential and the attaining strategy.
No conclusion about an optimal time is inferred here from the geometry
alone. The certificate is an ordinary finite proof, not Lean verification.

Discovery source: `src/even_three_by_three_cylinder_attack.py`, function
`automaton_certificate`. Independent implementation:
`src/even_cylinder_profile_independent_review.py`. The latter imports no
discovery code and reconstructs its costs from actual room coordinates.
Receipt: `research/even-cube-cylinder-profile-independent-review.json`.

## 1. Statements actually established

Let n>=4 be even and h=9n/2. For any one-color support R of size k in
P_3 × P_3 × P_n,

    |N(R)|-k >= min(4,k+1,floor((h-k+2)/2)),  0<k<h.       (1)

The empty and full one-color sets have surplus zero. Moreover two
consecutive actual survivors cannot both have surplus exactly four and
have sizes in the interval [4,h-8]. The word "consecutive" means that
the second support S is contained in N(R), as it must be after the next
inspection. No restriction to prefix strategies is assumed.

## 2. Verify the physical transverse compression

Order each color of the 3 × 3 square by increasing coordinate sum and
decreasing first coordinate to break ties. Its prefix-neighborhood
profiles are

    G0=(0,2,3,4,4,4),       G1=(0,3,4,5,5).

Every prefix neighborhood is the opposite-color prefix of the indicated
size. I independently enumerated all 32 even-color and 16 odd-color
subsets using actual coordinate adjacency and checked

    N_Q(CU) subset C(N_Q U),

where C replaces a set by its same-color prefix of the same cardinality.
The source also directly verifies the displayed profiles and prefix
identities; no discovery profile values are imported.

Apply C separately to every longitudinal slice. It is monotone and
cardinality preserving. The neighbors in slice j are the union of its
transverse neighbors and the supports in slices j-1 and j+1. Monotonicity
and the transverse inequality therefore imply the global inequality

    N(CR) subset C(NR).                                  (2)

This is a one-step statement for arbitrary supports. It is not a
conjectured optimal-state normal form. For compressed slice counts k_j,
the next slice count is exactly

    max(G_(p+j mod 2)(k_j), k_(j-1), k_(j+1)),

with exterior counts zero, because all three sets in that union are
prefixes of the same opposite transverse color.

## 3. Exact nonnegative pair costs

For phase zero, group the even number of slices into symbols (a,b) with
0<=a<=5 and 0<=b<=4. A two-slice symbol contributes

    w(a,b)=max(G0(a),b)-a + max(G1(b),a)-b.

Joining (a,b) to (c,d) adds

    e((a,b),(c,d))
      =max(G1(b),a,c)-max(G1(b),a)
       +max(G0(c),d,b)-max(G0(c),d).

Thus the complete word surplus is the sum of all vertex costs w and
all successive edge costs e. Each external adjacency changes one
different slice term, so this addition has no omitted or duplicated
contribution. The edge costs are nonnegative term by term, and
w>=b-a+a-b=0 because each maximum is at least its other slice count.

My independent implementation constructs all 30 vertex costs from
physical two-slice sets and all 900 edge costs by constructing physical
four-slice sets and subtracting the two vertex costs. It verifies that
every resulting neighborhood slice is the expected actual prefix.

## 4. Why the finite automaton proves every even length

It suffices to examine words of total cost at most four: every larger
cost automatically satisfies (1), whose right side is at most four.
Nonnegative increments imply that every prefix of such a word also has
cost at most four. Therefore cost pruning never excludes a word relevant
to either conclusion.

The discovery automaton records the final symbol, exact cost in [0,4],
occupied count capped at four, omitted count capped at eight, whether
the first slice count is at least three, and the number of symbols
capped at two. It starts with every allowed one-symbol word and closes
under every one-symbol extension of cost at most four. The caps retain
all information in the final predicates: (1) is already capped at four,
and the critical range is exactly occupied>=4 and omitted>=8.
Length cap two distinguishes n=2 from all n>=4.

Induction on word length shows that every relevant finite word has its
summary among these reachable states. Conversely, each initialized or
extended state is realized by a word. Exhaustive closure terminates in
113 projected states and 346 state-symbol transitions. Every terminal
state with at least two symbols satisfies the lower bound (1). Every
terminal state of cost four with occupied>=4 and omitted>=8 satisfies

    first slice count >=3,
    final slice count =0,
    penultimate slice count <=2.                        (3)

The independent checker deliberately refines the Boolean first-slice
field to its exact value. Its 164 reachable states project to exactly
the same 113 states and 346 transitions. All 136 refined terminal
profile assertions and all six refined critical-terminal assertions
pass. This is closure of a finite weighted-word automaton, not an
extrapolation from tested cylinder lengths.

Phase one follows by reversing the longitudinal order. Since n is
even, this changes its slice-color pattern to phase zero without
changing adjacency, size, or surplus. In that phase, (3) says that the
last slice has at least three rooms, while the first slice is empty
and the second has at most two.

## 5. Transfer back to arbitrary consecutive survivors

First apply (2) and cardinality preservation. The compressed support CR
has size k and no larger neighborhood than R, so its certified lower
bound (1) proves the same bound for every arbitrary R.

Now suppose 4<=|R|<=h-8 and its surplus is exactly four. Bound (1)
forces the compressed support's surplus to be at least four, whereas
(2) forces it to be at most four. Consequently the inclusion (2) has
equal finite cardinalities and is an equality:

    N(CR)=C(NR).                                        (4)

If an actual next survivor S is also critical in that size range, then
CS is likewise compressed and critical. Its actual containment gives

    CS subset C(NR)=N(CR).

For phase-zero CR, property (3) makes its last slice empty and its
penultimate slice of size at most two. The last slice of N(CR) therefore
has size at most two: its only contributors are the empty slice's
transverse neighborhood and the penultimate slice. But a critical
phase-one CS must have at least three rooms in its last slice, by the
reversed version of (3). This contradicts containment. Reversal proves
the other phase direction.

Thus the no-consecutive-four assertion holds for arbitrary actual
supports, including ones whose individual slices are not prefixes. The
equality step (4) is the essential link; merely knowing that some optimal
strategy could be compressed would not suffice for this local claim.

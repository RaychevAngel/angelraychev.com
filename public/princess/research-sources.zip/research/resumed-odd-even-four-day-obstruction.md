# Why the displayed 32-day relaxed solo path cannot be lifted

13 September 2026. Ordinary geometric obstruction with a separate exhaustive
physical check. This rules out one abstract path, not every 32-day strategy.

The strongest current corner/history relaxation on 7x8 with budget four
returns a 32-day solo route beginning with belief size/current-corner count

    (28,2) -> (26,2) -> (24,1) -> (23,2) -> (22,2).

Its corresponding complementary hole sizes are 0,2,4,5,6, with the four
nonempty hole sets containing respectively 0,1,0,0 corners of their color.
Let H_t denote these holes after t unsuccessful inspections and moves.
The holes before the next move are H_(t-1) union the inspected rooms.
Every neighbor of H_t must lie in that union. For this proposed trajectory,
the static bounds give

    |N(H_t)| >= 4,6,8,9 = |H_(t-1)|+4  (t=1,2,3,4).

The inspection budget forces equality at every step and therefore
H_(t-1) subset N(H_t). This necessary inclusion already creates a
contradiction on the fourth day.

Reflect to initial color zero. H_1 has two rooms, surplus two, and neither
of its own-colored far corners. The subcritical quadrant theorem forces
it to be the two odd neighbors of one near corner c. H_2 has four rooms,
surplus two, and one own-colored near corner. The square capacity is sharp,
so it is the full even triangle at a near corner. Its six-room neighborhood
must contain H_1, forcing the same corner c. In particular c belongs to H_2.

Since H_2 subset N(H_3), the five-room H_3 contains a neighbor of c.
No full classification of H_3 is needed.

Now H_4 has six rooms, surplus three, and no own-colored near corner.
The critical corner dichotomy excludes its dual branch and its (2,0)
exception. Its only possible small branch is (i,j)=(0,1), with capacity
Phi_(0,1)(3)=6. In the alternating-mark case an i=0 support has size at
most three, so here there is a genuine four-quadrant split. Equality puts
all surplus into one odd quadrant: H_4 is the full odd triangle on relative
diagonals1 and3 based at one FAR corner. Its neighborhood is the nine-room
even triangle on relative diagonals0,2,4.

Every neighbor of c is at graph distance at least six from either far
corner, since the longitudinal side has length eight. But N(H_4) lies at
distance at most four from its far corner. Thus it cannot contain the
neighbor of c that belongs to H_3. This contradicts H_3 subset N(H_4).

Equality of the raw triangle shapes follows from the existing quadrant
layer proof: compression preserves each diagonal's cardinality, and equality
in these square/pronic capacities forces the initial consecutive diagonals
to be full. It is not a claim that a dynamically chosen compression
preserves previous-state containment.

## Independent physical check

`src/resumed_odd_even_four_day_obstruction.py` enumerates all physical hole
sets of the required sizes, verifies the actual neighborhood and erosion,
and checks the inclusion against every predecessor. The four enumerations
contain378,20475,98280,376740 subsets. Their individually valid candidate
counts are2,2,4,2; their reachable counts are2,2,4,0. Both initial phases
are covered by longitudinal reflection. Receipt:
`research/resumed-odd-even-four-day-obstruction.json`.

This is a proved dynamic obstruction not visible in the corner-count model:
it remembers the location of a corner-adjacent hole through the next phase.
It does NOT establish that every 32-day solo strategy is impossible, nor
that the upper68 is optimal. The rectangle agent separately searched all
four orientations of physical pyramids, allowing an orientation switch
every day, and found shortest solo length34. That is a stronger failed
upper search, but remains a restricted family on this nonsquare board.

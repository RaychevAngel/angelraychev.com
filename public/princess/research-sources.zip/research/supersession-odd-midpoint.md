# A uniform midpoint criterion for odd rectangles: resumed attack

**13 September2026 improvement:** `maturation-odd-midpoint.md` Sections7
and9 prove an explicit eventual scalar criterion and strengthen all the
bounded-frontier constants below to H=b^2+1 and G=m-1. The earlier larger
constants and receipts in this historical derivation remain valid. The
current manuscript and solver use the strengthened version.

12 September 2026. The bounded exceptional-frontier theorem (§8) and exact
interior stabilization/evaluation theorem (§10) have passed root independent
ordinary review. They strengthen the uniform all-budget algorithm while
leaving the endpoint-only scalar midpoint criterion unresolved. The opposed-
root lemma (§5) is independently proved and also formalized by root in Lean.
Historical failed approaches and an unreviewed eventual-onset corollary are
kept separately below.

## 1. Antecedents and exact unresolved target

Write the physical color sizes as E=M+1. The exact inverse profiles are
I_0,I_1. The attainable solo deficits D_0(t),D_1(t) satisfy

    D_0(t+1)=I_0(min(M,D_1(t)+m)),
    D_1(t+1)=I_1(min(E,D_0(t)+m)).

Let τ be the first solo capture time and L=τ−1. The accepted ordinary
theorem, independently reviewed by root and Euler, is

    T_m ∈ {2τ−1,2τ}.

The exact midpoint optimization over the attainable canonical deficit
frontier F_L is

    C_L=min_{d,e∈F_L} [(E−d_0−e_0)_+ +(M−d_1−e_1)_+].

The shorter time occurs exactly when C_L≤m. Its physical construction uses
prefixes for one half and reflected prefixes for the reverse half. Neither
this exact reduction nor the half-time theorem proves the proposed scalar
criterion

    C_L≤m iff E+M−D_0(L)−D_1(L)≤m.             TARGET, NOT PROVED.

A sufficient stronger statement is the capped two-copy inequality

    min(E,d_0+e_0)+min(M,d_1+e_1)
       ≤max(E,D_0(L)+D_1(L)).                 TARGET, NOT PROVED.

The unclipped residual-sum lower bound is false: at 3×3,m=3 its value is
six, while the actual midpoint minimum is five. Both exceed m, so the
budget-qualified scalar criterion survives that counterexample.

## 2. A candidate inductive closure, tested but not proved

For a time t before solo capture put a=D_0(t),b=D_1(t), A=max(a,b),
K=max(E,a+b). A relaxed state set is assumed to have:

* individual bounds d_0≤a,d_1≤b;
* total deficit at most A;
* both solo endpoints (a,0),(0,b);
* every pair, including a self-pair, satisfying the capped bound K.

Applying every quota split sends (x,y) to

    (I_0(y+m-p),I_1(x+p)), 0≤p≤m.

The inputs are unsaturated whenever t+1<τ. The candidate closure says the
new family has the capped pair bound max(E,a'+b'), where
(a',b')=(I_0(b+m),I_1(a+m)). Such a lemma would induct the global target
without a serial strategy theorem and without assuming interval supports.

The new focused checker `src/supersession_odd_midpoint_closure.py` considers
all relaxed individual states that satisfy the self-pair and both solo-
endpoint conditions. It then checks every pair satisfying the mutual old
bound and every pair of quota splits. A failure would refute this closure
lemma, not necessarily the full-board conjecture.

At 11×11,m=7,t=23, the old solo capacities are (49,52), the next capacities
are (58,52). The complete check covered 1,380 relaxed states and 60,917,760
pair/quota transitions, with no counterexample, in 8.04 CPU seconds. A
second test at 13×13,m=8,t=26 was explicitly stopped after 15 CPU seconds;
its 115,562,457 tested transitions had no counterexample, but that case is
NOT complete. See `supersession-odd-midpoint-closure.json`. No broad
catalogue is planned; the unresolved task is an algebraic closure proof.

## 3. Restrictions already deduced from the accepted inverse inequalities

The earlier note's §7 gives the following ordinary deductions, not yet
separately audited.

If a state's total deficit is at most min(D_0(t),D_1(t)), and its next
minority deficit is positive, its next total is at most the smaller next
solo deficit. Both inverse concentration inequalities apply to the same
total input. Therefore an above-minimum mixed episode cannot begin from
below the smaller solo bound without passing through a pure-majority state.

The profiles interlace by g_0(k)≤g_1(k)≤g_0(k)+2. Their inverse consequence
is I_1(z)≤I_0(z)≤I_1(z+2), with the full endpoint excluded from the second
inequality. Thus the fastest initial cohort can change only through a tie
or a majority solo advantage of one. A phase change that keeps the same
physical majority color fastest erases every high-total mixed state.

For a possible capped-pair violation, both states must have total strictly
above the smaller solo deficit: if one is at most the smaller bound, the
other is at most the larger bound and their untruncated sum already obeys
the desired pair bound. Hence only simultaneous exceptional mixed episodes
can threaten the midpoint criterion. This is the current analytic focus.

## 4. A failed stronger quantitative restriction

It is tempting to bound the secondary deficit in a high-total state by
Δ(Δ+1)/2, where Δ is the current solo-capacity difference. This is false
even before solo capture. On 41×39,m=24, at time 17 the solo capacities
are (210,212), while the canonical state (4,207) is reachable. Its total
211 exceeds the smaller capacity 210, but its secondary deficit four
exceeds Δ(Δ+1)/2=3. Therefore an argument controlling exceptional states
only through the current capacity difference loses necessary history.
This does not refute the capped pair target at time L.

## Status

The scalar midpoint necessity remains open. Later sections prove an exact
bounded-state replacement for the unrestricted frontier and stabilize its
long interior; these are algorithmic theorems, not an endpoint-only formula.

## 5. An exact two-candidate opposed-root lemma

**Ordinary proved lemma, independently derived and accepted by root.**
Write R(k)=ceil(sqrt(k)) and rho(k)=min{r≥0:k≤r(r+1)}. For integers
0≤l≤u≤S, the minimum of rho(y)+R(S−y) on l≤y≤u is attained at one of

    y_1=min(u,rho(l)(rho(l)+1)),
    y_2=max(l,S−R(S−u)^2).

To prove this, suppose some feasible y has root cost t, and put
r=rho(y),s=R(S−y). Feasibility implies r≥rho(l), s≥R(S−u), r+s=t,
and r(r+1)+s²≥S. Conversely these inequalities allow some y in the
interval with cost at most t. At fixed t the capacity r(r+1)+(t−r)²
is convex in r. Its maximum on rho(l)≤r≤t−R(S−u) occurs at an endpoint.
Therefore an admissible pair of cost at most t exists with either r at
its minimum rho(l) or s at its minimum R(S−u). For the former choose the
largest allowed y with rho(y)≤rho(l); for the latter choose the smallest
y with R(S−y)≤R(S−u). These are exactly the two displayed candidates.
Zero roots and one-point intervals are included.

This gives an exact constant-size formula for

    max_{l≤y≤u} I_0(y)+I_1(S−y),  0≤l≤u≤S≤M.

For proper y<M expand the two inverse deficits as minima of three
branches each. Seven of the nine branch pairs are monotone or constant
and attain their minimum at an interval endpoint. The remaining pairs
are rho(y)+R(S−y) and rho(M−y)+1+R(E−S+y). Apply the lemma to the first
with total S, and to the second after setting z=M−y, with total E+M−S.
Thus evaluate at the two endpoints and at the two candidates for each
opposed pair. If y=M is permitted, add that endpoint separately and
restrict the ordinary formula to y≤M−1; its full-profile jump must not
be replaced by the proper inverse formula. The result uses at most
seven inverse evaluations and includes every quota split exactly.

`src/supersession_odd_midpoint_kernel.py` implements this formula.
All 455 interval triples for the 5×5 board agree with direct evaluation;
this check supplements the proof, not substitutes for it.

## 6. A two-segment candidate envelope

At a precapture layer let a=D_0,b=D_1,A=max(a,b),K=max(E,a+b), and choose
the dominant physical color p (p=0 on a tie). Put

    L=K−A, H=floor((K−C_p)/2), (C_0,C_1)=(E,M).

The stronger proposed invariant is that every deficit state d satisfies
its known individual and total bounds, together with

    d_0+d_1≤L  OR  d_{1−p}≤H.                 NOT PROVED.

It implies the desired capped two-copy inequality: if one state has
small total, the two raw totals sum to at most L+A=K; otherwise the
capped dominant-coordinate contribution is at most C_p and the two
secondary coordinates sum to at most 2H, again giving K.

The downward-closed proposed envelope has only two Pareto segments.
Write y=d_1. The low segment has total s=min(A,L), with
max(0,s−a)≤y≤min(b,s). The high segment has total A and the same
individual restrictions, additionally y≤H if p=0 or y≥A−H if p=1.
Empty segments are omitted. A source segment of total s and interval
l≤y≤u, under every full-budget quota split, has the exact next image

    (I_0(Y),I_1(s+m−Y)),   l≤Y≤u+m.

To test envelope closure, restrict this interval to points where the
new secondary coordinate exceeds its new threshold. If the new
dominant color is 0 this means Y≤s+m−g_1(H'+1); if it is 1 it means
Y≥g_0(H'+1). On the restricted interval the root lemma evaluates the
maximum new total with at most seven evaluations. Closure is equivalent
to this maximum being at most L' on both old segments. Smaller quotas
cannot be worse because both inverse functions are monotone and the
forbidden region is upward closed. This is an exact local closure test,
not a proof that every actual solo trajectory passes it.

Focused complete tests of this constant-size condition passed at every
precapture layer for (w,n,m)=(5,5,3),(7,7,4),(9,9,5),(11,11,7),
(17,17,10),(23,23,12),(39,41,24), then for 39×41 at budgets20–23 and
41×41 at budgets21–24. Receipts are the kernel and targeted-capacities
JSON files. These tests do not establish a parameter-uniform theorem.

## 7. Why arbitrary monotone capacity pairs are insufficient

On 39×41 at budget24, take the hypothetical capacities (393,397).
They advance to (402,397), so both capacities are nondecreasing and all
inputs are proper. The old envelope allows source (3,394). Allocating
all24 probes to its physical minority coordinate gives (399,1). The
new low-total threshold is398 and its secondary threshold is0, so this
state violates the new envelope. Paired with the new pure endpoint
(402,0), its capped union deficit is801, exceeding K=E=800.

The old state and both old solo endpoints obey the old pair bounds,
including self-pairs and their mutual pairs. Thus coordinatewise solo
monotonicity, bounded gap, individual bounds and the preceding capped
pair inequality do not alone imply closure. These hypothetical capacities
are not on this board's actual solo trajectory. Any successful closure
proof needs a property inherited from the genuine initial condition,
for example a constraint on the phase offsets entering the affine bands.
The exact counterexample is saved in the abstract-capacities JSON file.

## 8. A bounded exceptional-frontier theorem

**Ordinary theorem independently audited and accepted by root.** This does
not assume the unresolved scalar midpoint criterion. It gives an exact
finite-state reduction with a state bound independent of the long side.

Put w=2b+1, H=(b+1)^2 and G=2m+2, and define

    K=H−1+2m(floor(G/w)+1).

For every t<τ and every attainable mixed deficit pair d with

    min(D_0(t),D_1(t)) < d_0+d_1,

one has min(d_0,d_1)≤K. Thus each exceptional state lies in one of two
endpoint collars of width K, even when the board is arbitrarily long.

### Uniform solo-gap bound

The solo recurrence is monotone from its zero initial pair. For t≤τ−2,
its next capacities are proper, so
D_0(t)≤D_0(t+1)≤D_1(t)+m and the reversed inequality also holds.
Consequently |D_0(t)−D_1(t)|≤m. For the final layer L=τ−1, the previous
input arguments differ by at most m. On their proper domains each inverse
is 2-Lipschitz. Moreover 0≤I_0(z)−I_1(z)≤2 for 0≤z<M: in the explicit
root formulas, the three branches of the second inverse deficit differ
from their corresponding first-inverse branches by respectively 0 or1,
1, and1 or2. Comparing at the smaller input therefore gives

    |D_0(L)−D_1(L)|≤2m+2=G.

If the I_1 input equals M, use I_1's 2-Lipschitz estimate from the smaller
proper input; I_0's full jump at M is never used before τ. If τ=1 there
is only the zero initial layer. Hence the bound G holds at every layer
needed below.

### A mixed exceptional run cannot stay in the bulk for long

Write s=d_0+d_1 and A=max(D_0,D_1). Known concentration gives s≤A.
If d_0,d_1≥H at a source layer and its successor is still precapture,
the inverse inputs X,Y satisfy X,Y≥H and X+Y=s+m≤M. All four root
arguments are therefore beyond their lower corners and before their
upper corners. The exact bulk formulas give

    I_0(Y)=Y−b, I_1(X)=X−(b+1),
    s'=s+m−w.

Every solo capacity gains at least D=2m−w over two proper transitions,
since I_0(z)≥z−b and I_1(z)≥z−(b+1). Thus whenever two successive
source states lie in the bulk,

    (A−s)(t+2) ≥ (A−s)(t)+w.

At an exceptional layer, 0≤A−s<A−min(D_0,D_1)≤G. Therefore a run of
bulk exceptional states contains at most 2floor(G/w)+1 transitions.

To apply this to an arbitrary target exceptional mixed state, trace back
to the most recent state with min(d_0,d_1)<H. Such a state exists because
the initial deficits vanish. Every intervening bulk state is mixed and
exceptional: accepted persistence says a mixed exceptional successor
cannot come from a predecessor whose total was below the smaller solo
capacity. At the first bulk state its smaller coordinate is at most
H−1+m, because each inverse output is at most its input and therefore a
single transition increases the smaller coordinate by at most m. The
same bound per transition, together with the run-length bound, gives

    min(d_0,d_1) ≤ H−1+m+m(2floor(G/w)+1)=K.

If the target already has a coordinate below H, the bound is immediate.

### Exact reduced recurrence

At each layer retain the two pure solo endpoints and only those mixed
states whose total exceeds the smaller solo capacity. Apply all quota
splits, retain the same types again, and optionally discard dominated
states. This reduced recurrence has exactly the same maximum capped
union deficit at the central layer as the full two-count recurrence.

Indeed, by induction every actual exceptional state is dominated by a
retained attainable state. A mixed exceptional successor must have an
exceptional predecessor by persistence; pure successors are dominated
by the current pure solo endpoint. Monotonicity transports domination
through a quota split. Conversely every retained state is physically
attainable because it was generated by the exact canonical recurrence
or is an actual solo endpoint. This proves the domination assertion.

Any pair involving a discarded state of total at most the smaller solo
capacity has raw total at most D_0+D_1. The two opposite solo endpoints
already attain capped union D_0+D_1. Thus discarded states cannot improve
the central optimization. The exact midpoint identity applies unchanged
to the retained frontier, so no serial optimality assumption is needed.

At most G different integer total deficits can exceed the smaller
capacity while remaining at most the larger. For each such total there
are at most 2(K+1) pairs with one coordinate at most K. Consequently the
reduced frontier has at most

    2+2G(K+1)

states, independently of the long side n. Its one-layer transition uses
at most m+1 quota splits per state. This theorem gives bounded memory
and a bounded transition state alphabet for fixed width and budget;
fast-forwarding its changing operators is a separate next step and is
not asserted here.

## 9. Subsequent failed closure attempts

The §6 envelope also fails to close at genuine solo capacities. On
15×75,m=12,t=59 the capacities (279,276) advance to (281,283). The old
envelope admits (3,276); assigning all12 to its minority coordinate
produces (279,3), total282. The new low threshold is281 and its allowed
secondary coordinate is at most1, so this is a violation. The source
is not reachable or dominated by an actually reachable state; the exact
frontier near the minority endpoint contains (3,271), not (3,276).
The actual frontiers at times59 and60 obey the proposed envelope.
Thus this refutes the proposed abstract closure, not the global target.

Root suggested the unconditional corner penalty

    x+y+min(rho(x),R(y))≤max(D_0,D_1)+1.

It fails already on15×75,m12,t2: capacities(16,16), reachable(9,6),
left side18>17. Restricting the claim to x+y>min(D_0,D_1) passes the
focused actual traces, but remains conjectural. Even its abstract local
closure fails for hypothetical monotone capacities: on9×15,m7,
(3,1)→(5,6), source(2,1) with quota0=2 goes to(4,2). The new total6
exceeds the smaller capacity5, but its root-penalized total8 exceeds7.
Those hypothetical capacities are not on the actual solo trajectory.
The bounded-frontier theorem in §8 avoids both unproved penalties.

## 10. Exact interior stabilization and a length-independent evaluation

**Ordinary theorem independently audited and accepted by root.** This strengthens
finite Boolean powering: the mixed histories actually have bounded age
in the central region, so its retained normalized frontier stabilizes
with period two after a bounded warm-up.

Continue H,G,K from §8, put D=2m−w≥1, and take the safe collar

    J=2K+G+2m+H+2.

Call a precapture layer safe when J≤D_0,D_1≤M−J. The safe layers form
an interval because both capacities are nondecreasing. At such a layer,
represent a retained mixed state by (j,k,ell), where j is its larger
coordinate's physical color, k is the smaller deficit and
ell=D_j−d_j. The bounds of §8 give

    0≤k≤K, 0≤ell≤G+K.

Indeed ell=D_j−(d_0+d_1)+k<G+k. The primary coordinate is greater
than K because D_j≥J and ell≤G+K, so its color is unambiguous. Pure
states are replaced by the corresponding solo endpoint.

### The homogeneous one-step rule

Let q be the part of the budget allocated to the smaller-deficit cohort;
the remaining m−q goes to the primary cohort. Define the bottom inverses

    j_0(z)=z−min(rho(z),b),
    j_1(z)=z−min(R(z),b+1).

At a safe source layer the exact normalized update is

    (j,k,ell) -> (1−j, j_j(k+q), ell+q).                 (10)

To check it, the primary inverse input lies between H and M−H, as do
the solo inverse inputs. Thus both primary and solo transition use the
same affine branch, and their difference grows by exactly q. The
secondary input is at most K+m. Since a safe layer implies M≥2J,
its reflected upper-root branch cannot be the active branch; it uses
j_j. The primary output is still greater than K. If the successor
remains mixed and exceptional, §8 forces its secondary output to be at
most K. Otherwise it is discarded or replaced by a pure endpoint.
The generous J supplies these margins even if the successor is the
first layer outside the safe interval.

In this region the solo pair satisfies

    (D_0',D_1')=(D_1+m−b,D_0+m−b−1),
    (D_0(t+2),D_1(t+2))=(D_0(t)+D,D_1(t)+D).

Hence its physical-color difference, the high-total filter
ell−k<D_j−min(D_0,D_1), and the pure endpoint states are all periodic
with period two. Rule (10) is independent of the long side and of the
absolute capacities.

### A mixed history has bounded age

If the updated secondary coordinate is positive, j_j(z)≤z−1, so (10)
gives

    ell'−k' ≥ ell−k+1.

Every exceptional state requires ell−k<G. At entry ell−k≥−K.
Consequently no mixed exceptional history present at entry can remain
mixed and exceptional for G+K transitions. Becoming pure resets its
relevant history: the actual pure state is dominated by the solo
endpoint, which the reduced recurrence always includes. Falling below
the exceptional threshold also erases its future relevance until a
pure state is reached, by persistence.

A mixed history born from a pure endpoint starts from k=ell=0. Its
first positive secondary has ell−k≥1, and it lasts fewer than G further
steps. Thus after W=G+K+1 safe transitions, every relevant mixed state
is produced by a bounded recent history from one of the pure endpoints.
The rule, endpoint births and filters depend only on the two-day phase.
It follows that the complete normalized retained frontier is then
periodic with period two. Componentwise Pareto pruning preserves this
statement: within a fixed primary color dominance depends only on
(ell,k), and opposite primary colors are incomparable since one
coordinate is greater than K and the other at most K.

### Evaluating the whole game without iterating over its length

The following algorithm uses a number of ordinary transition steps
bounded solely by w,m.

1. Iterate the exact reduced recurrence until capture or until both
   solo capacities are at least J. This takes at most2ceil(J/D)+1 steps,
   because each proper pair of steps increases both capacities by at
   least D.
2. If a safe interval is entered, compute its last index using the
   displayed two-day affine solo formula. More explicitly, at first safe
   time t_0 let A_p=max D(t_0+p), p=0,1. For each admissible parity p,
   its final safe index is

       t_0+p+2floor((M−J−A_p)/D).

   Ignore a parity with A_p>M−J. The maximum is the last safe layer.
3. Perform at most W+2 warm-up steps. If the safe interval is longer,
   jump an even number of steps to its last matching parity. For each
   skipped pair add D to both solo capacities and to the primary
   coordinate of every retained state; leave its smaller coordinate
   unchanged. Interior stabilization proves this is the exact normalized
   frontier, not a relaxation. Finish the at most one remaining safe
   transition normally.
4. Once the safe interval is left, at least one solo capacity exceeds
   M−J, so that cohort has at most J remaining rooms. Capture follows
   within at most2ceil(J/D)+2 further steps. If the safe interval was
   empty when step1 ended, the same upper-collar bound applies.
5. Stop one layer before the first solo capture and evaluate the exact
   capped two-copy midpoint objective over the retained states. Use the
   accepted half-time theorem to select2τ−1 or2τ.

Thus at most 4ceil(J/D)+W+8 ordinary frontier updates, plus a constant
number of integer divisions and the final bounded frontier optimization,
suffice for every odd long side. The frontier bound is2+2G(K+1).
The arithmetic bit lengths still depend on log n; no claim of constant
bit complexity is intended. This is an exact uniform finite-arithmetic
reduction, not the unresolved assertion that only the two solo endpoints
are needed in the final optimization.

### Implementation evidence for §§8–10

`src/supersession_odd_midpoint_bounded.py` implements the exact retained
recurrence and the stabilized even jump. The independent reference here
is the full unpruned-in-type Pareto recurrence, not the endpoint-only
conjecture. Six focused final-midpoint comparisons agree exactly,
including39×41,m24, where446 full final states reduce to35 retained
states. Four runs with an actual accelerated middle agree state-for-state
with the daywise retained recurrence. The source also checked four boards
of long side10^12+1; the3-row and7-row minimum-budget outputs agree with
their already proved closed formulas. All these checks together used
0.82 CPU seconds. Receipt: `supersession-odd-midpoint-bounded.json`.

The39×(10^12+1),m24 computation used1128 ordinary updates, retaining at
most35 states, and gave tau=4,333,333,333,257 and full time
8,666,666,666,514. This numerical result is supported by the proposed
uniform algorithm theorem, not by extrapolating a finite sequence; its
new-proof status follows the independent audit status of §10.

## 11. Draft explicit onset for the eventual exact period

**Corollary draft, submitted for audit separately.** Put

    M*=2J+G+m(W+3),
    h=gcd(w,D), P=2D/h, c=w/h.

For odd n with M=(wn−1)/2≥M*, the preceding stabilization should imply

    T_m(w,n+P)=T_m(w,n)+4c.

Here is the full proposed argument. The first layer with both capacities
at least J has maximum at most J+G+m−1: at the preceding layer its
minimum is below J and its gap is at most G, and a single proper update
raises the maximum by at most m. For M≥M*, every inverse input through
this entry lies away from the upper root collar. Consequently entry
history, its solo pair and retained frontier depend only on w,m, not M.
The safe interval then contains at least W+2 additional steps because
its maximum rises by at most m per day. Thus it reaches the period-two
stabilized frontier.

Increasing n by P increases both color capacities by cD. The same entry
occurs at the same time. Each safely interior pair advances both solo
capacities by D, so the last safe layer of each parity is delayed by
exactly2c days. Its retained state set has exactly the same normalized
(secondary,primary-loss) values. Both capacities and every large deficit
coordinate are translated by cD; the smaller coordinates are unchanged.

Throughout the final upper collar, a large inverse argument is away from
its lower root branches, while a smaller argument at most K+m is away
from its upper root branches. This follows from M≥M*≥2J+G and the
lower bound D_j−ell≥M−J−2G−K for the large coordinate after entry into
the upper collar. The inverse formulas, including the full endpoint,
therefore commute with the same translation for large coordinates and
are unchanged for the smaller ones. The exact retained upper-collar
recurrence and first solo capture are translated identically; tau gains
2c days.

At the final midpoint, two states with the same primary color cannot
supply a winning cut: the other color has total deficit at most2K, so
at least M−2K>m rooms there still require central inspection. Pairs with
opposite primary colors have exactly invariant central costs when both
capacities and one primary contribution in each color increase by cD.
Thus the shorter/longer half-time bit is unchanged. Since tau increases
by2c, the total optimal time increases by4c, as claimed. This gives an
explicit width/budget-dependent onset rather than an existence-only
period statement. It does not prove the scalar midpoint criterion.

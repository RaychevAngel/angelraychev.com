# Root audit of the even Hamiltonian-cylinder period

12 September 2026. The root agent independently checked the proof in
`even-bridge-eventual-periodicity.md` and its exact-surplus prerequisite.
An additional fresh reviewer is checking the surgery argument before
publication integration.

The mathematical statement is: for fixed bipartite Hamiltonian `Q` of
order `2b` and fixed `m>b`, there are effective constants `Delta,N` such
that `T_m(Q x P_(n+Delta))=T_m(Q x P_n)+2b*Delta/(m-b)` for all `n>=N`.
It covers both longitudinal parities. It does not assert practical-sized
constants or a complete closed formula for all box dimensions.

The audit checked the following dependencies and possible failure points.

* The alternating-rung contraction is strongly connected when `n>=2`.
  Its outside directed boundary is exactly the ordinary neighborhood
  surplus under the matching identification, in either physical phase.
* The clipped potential has an integer daily loss bound `m-b`. Equality
  forces the full useful quota onto one cohort, an exact surplus of `b`,
  and source and successor counts in the linear band, including its
  endpoints. The survivor lies strictly inside the range required by
  the exact-frontier lemma. Clipping cannot conceal a larger raw loss.
* An untouched proper cohort strictly grows. A low-potential nonempty
  mate cannot persist through more than `K+m` efficient days; a high
  mate becomes full in at most `K` days. An efficient run has at most
  two owner blocks, since ownership can switch only after its former
  owner's potential reaches zero.
* The height bound used for the slack count was corrected to the actual
  proved bound `2 ceil(b(n+2)/(m-b))`. It yields
  `B=4K+4m+2b-2`; no separate diameter estimate is required.
* At the beginning of each nonclean block both supports are frontiers,
  full, or empty. Marking their actual cut columns and every actual
  nonclean shot, with a radius greater than the block length, protects
  a physical interval. This addresses arbitrary holes created elsewhere;
  a cardinality argument by itself would not suffice.
* Full regions persist without local shots using the matching within
  each column. Empty regions cannot be entered faster than one column
  per day. Thus the protected interval retains its status throughout
  each nonclean block. Clean fronts have a strictly monotone average
  and bounded width. Trimming the interval removes partial excursions,
  and each cohort makes exactly one complete crossing.
* Finite frontier states include physical phase and translation parity.
  A closed walk therefore has even time length and even displacement.
  The displacement has a fixed sign and equals `(m-b)*length/b`.
  Chunking a sufficiently long crossing gives disjoint cycles of one
  repeated length; the stated least common multiple permits deletion
  of exactly the required total length.
* The crossing endpoints lie on opposite sides of the actual deleted
  band. During a left crossing the required translation changes from
  `-Delta` to zero as cycles are deleted; the right crossing is reflected.
  Every retained transition is an even translate of a legal transition.
  The other cohort is globally full or empty, and the two crossings
  occur at disjoint times. The edits therefore preserve both cohorts,
  timing parity, and the daily quota.
* Outside crossings, neighborhood formation commutes with column
  surgery because the join is locally full or empty. Extra edges of
  `Q` stay in the same longitudinal column and impose only finite
  additional frontier restrictions. The insertion argument reverses
  the time and spatial changes and proves equality, not just a bound.

The root review finds no remaining gap after the explicit interval
margins, finite threshold, and height-bound corrections. This remains
an ordinary proof; it is not claimed to be a Lean theorem.

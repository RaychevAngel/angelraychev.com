# Near-pronic localization and a uniform forbidden consecutive transition

**Current strongest form:** the dual erosion-feature rule below makes
the initially proposed new history bit unnecessary. The history derivation
is retained as an independent argument and record of the route to the
stronger static statement.

13 September2026. New ordinary proof, independently checked by the parent
at the component-capacity and radius steps. This strengthens exact pronic
rigidity to an interval of support sizes. It concerns the physical full-board
game; it makes no assumption that arbitrary supports are compressed.

Let w=2b+1>=5, let n>=w be even, h=wn/2, C=b(b-1), and

    D=C2(b)=max(b(b-1)/2,b(b-2)).

## Localization throughout the band

If a one-color support U contains no corner of its own color,

    D<|U|<=C,  |N(U)|-|U|<=b,

then its surplus is exactly b, it is connected under sharing a neighbor,
and there is exactly one opposite-colored corner o in N(U). Moreover

    dist(u,o)<=2b-3 for every u in U.

Here dist is Manhattan distance in the original room coordinates.

**Proof.** For each nonempty sharing-neighbor component U_i, its size
is at most C and its surplus s_i is at most b. Its own-corner count is
zero. The accepted subcritical/critical finite-board F/G theorem has no
critical exception at that count, and its large branch is impossible:

    h-|U_i|-s_i >= h-b^2 > b^2 >= G_(0,j)(s_i).

Consequently |U_i|<=s_i(s_i-1), so s_i>=2. Sharing-neighbor components
have disjoint neighborhoods; therefore their sizes and surpluses add.
If there were at least two components, convex allocation at total
surplus<=b would give

    |U|<=(b-2)(b-3)+2<=D,  for b>=4.

For b<4 two nonempty components already require more surplus than is
available. Thus U is connected. If its surplus were at most b-1, its
size would be at most(b-1)(b-2)<=D, also impossible. Its surplus is b.
The capacities F00(b)=D and F02(b)<=D exclude outgoing corner counts0
and2, so its neighborhood contains exactly one such corner o.

The separator used in the critical odd-width proof is available in its
actual geometric first branch. Matching along the even side gives more
than b matched rows. If no adjacent boundary-free columns existed, the
alternating-fiber case with current-corner count0 would have outgoing
corner count0 and area at most b(b-1)/2<=D. Otherwise the empty row and
column pair separate the source or its transposed complement into true
board-corner quadrants. The complement alternative has just been ruled
out by its large-branch size bound. The source thus splits into quadrants
with disjoint neighborhoods, each agreeing with its whole quadrant.
Connectedness places all of U in the quadrant based at o.

The radius bound needs no compression. Touching o means diagonal1 is
occupied. A sharing-neighbor step changes the coordinate sum by0 or2;
therefore the occupied odd diagonals are1,3,...,2L-1 with no gaps. On
each such diagonal, the upper shadow has at least one more room than
that diagonal's support: for a nonempty finite integer set X,
|X union(X+1)|>=|X|+1. These upper-shadow diagonals are disjoint, and
the output origin adds one additional room. Hence

    |N(U)|>=|U|+L+1,  so L<=b-1.

Every room therefore lies within radius2b-3 of o. This proves the lemma.

## A uniform history rule in the physical game

The later, stronger static formulation is recorded at the end of this note.
It implies the history prohibition below using the existing erosion feature.

For a one-color belief A, let H be its same-colored complement. Call
an inspection transition A -> A'=N(A minus I) band-localizing when,
writing p=|I intersect A| and s=|A'|-|A|+p,

    c(A')=2,  D<h-|A'|<=C,  s<=b.

Here c(A') counts its two own-colored board corners. These conditions
are purely transition-size, cost, and corner data. They imply that
H'=the complement of A' satisfies the localization lemma: its own
corners are absent and N(H') lies in the complement of A minus I,
so its surplus is at most s<=b. In particular e(A')=1 follows.

**No two consecutive inspection transitions can both be band-localizing.**

To prove this, let U and V be the successive complementary holes. The
first transition makes U localized as above. The second makes V so.
The relation N(V) subset U union I and its surplus bound, together with
the exact surplus b supplied by the localization lemma, force

    |N(V)|=|V|+b=|U|+p,  and hence U subset N(V).

Indeed the second transition's original surplus is at most b, whereas
|V|+b<=|U|+p; equality follows in both inequalities.

The corners o_U and o_V have opposite colors. On an odd-width/even-length
rectangle their Manhattan distance is at least n-1>=2b+1. Since U
contains a neighbor u of o_U,

    dist(u,o_V)>=n-2>=2b.

But N(V) lies inside the radius2b-2 ball about o_V. This contradicts
U subset N(V). The argument allows arbitrary inspection budgets and
locations; the transition-size condition is the only cost restriction.

The memory is one bit: the preceding transition was band-localizing.
It clears on every nonlocalizing transition and forbids an immediately
following localizing transition. No corner-identity catalogue is needed.
The previous exact-pronic equality is contained in this support band,
although this history rule and the earlier one-step pronic rule supply
different observations and neither is discarded without a dependency check.

## The11x12 discrepancy that exposed the rule

With budget6, the known physical prefix clears one phase in64 days.
The enriched necessary model without this history admits63 days. Every
such optimal relaxed history reaches belief(49,c2,e1) at day8 and then
(48,c2,e1) at day9. The explicit64-day prefix agrees through day8 but
instead reaches(48,c1,e2) at day9.

For b=5, D=15 and C=20. These two target beliefs have complementary
holes17 and18. Their source sizes are50 and49, so budget6 makes both
original surpluses at most5. They are consecutive band-localizing
transitions and are therefore physically impossible. This obstruction
uses the entire uniform band, not a special17-room or18-room pattern.
The conclusion currently established here is that every63-day path in
that checked relaxation is unliftable. The full-game consequence still
requires a joint lower certificate or a merger proof preserving the new
history rule; a physical solo obstruction alone is not doubled silently.

## Focused model checks and proof integration

The optional `band_memory=True` in
`src/resumed_odd_even_erosion_corners.py` implements exactly the trigger
and one-step prohibition above, using tagged states(a,2,1,5). Exact
pronic flags retain tag4; the two target-size ranges are disjoint.
Only the two previously discrepant lengths were evaluated:

*11x12, budget6: necessary solo minimum64, matching physical64;
  1704182 forward/backward potential inequalities checked.
*11x14, budget6: necessary solo minimum86, matching physical86;
  2394982 forward/backward potential inequalities checked.

Receipts are `resumed-odd-even-erosion-corners-11x12-band-memory.json`
and `resumed-odd-even-erosion-corners-11x14-band-memory.json`.
These receipts retain the physical feature lower bounds. A separate
agent is checking the weakened feature model needed by the new merger
theorem and its central residual. No full-game equality is inferred
solely from the two solo computations.

The parent independently accepted the entire ordinary proof. Concise
manuscript source is `paper/sections/resumed-near-pronic-history.tex`,
with labels `thm:near-pronic-localization` and
`cor:no-consecutive-near-pronic`. No Lean formalization has been added.

## Stronger consolidation: the dual feature rule needs no new memory

The parent observed that the localization proof gives more than the
one-bit prohibition. Let S be a survivor, B=N(S), and suppose

    c(B)=2, D<h-|B|<=C, |B|-|S|<=b.

Then necessarily

    |B|-|S|=b, c(S)=1, e(S)=2, e(B)=1.

Proof: U=the complement of B has surplus at most |B|-|S| and lies in
the localized band. Its surplus is exactly b, so equality forces
N(U)=the complement of S. The unique corner of N(U) gives c(S)=1.
The second neighborhood N^2(U), of radius at most2b-1 around its
localization corner, misses both opposite-colored corners since their
distance is at least n-1>=2b+1. Both therefore have all their neighbors
in S, giving e(S)=2. Finally E(B)=the complement of N(U)=S, giving
e(B)=c(S)=1. This argument was independently checked against the prior
localization and erosion identities.

Two consecutive band transitions are now impossible without storing a
new flag: the first leaves a belief with e=1, and the next would require
a survivor with e=2. Removing rooms cannot increase this count.

The `band_dual=True` implementation, with `band_memory=False`, still
gives solo64 on11x12 and86 on11x14, matching the physical uppers.
It checks1696228 and2387028 forward/backward potential inequalities.
Receipt: `resumed-odd-even-erosion-corners-11-band-dual.json`.
This replaces the band-memory rule as the current mathematical input;
the earlier flag and its receipts remain only as research history.
The manuscript now presents this stronger result with label
`cor:dual-near-pronic`, followed by the immediate no-consecutive
corollary. The same newly proved localization is the common argument.

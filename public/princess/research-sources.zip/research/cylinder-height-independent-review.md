# Independent review of the cylinder height construction

12 September 2026 UTC. Review of root's construction on `H square P_n`,
where H is finite connected bipartite with A vertices and diameter D.
No gap found in the stated sufficient budget `m> A/2`. This note audits
the local-maximum version; later refinements to a fixed bipartition flip
word should retain their own verification.

Represent a single initial-parity cohort by a dominating prefix in every
H-fiber, with upper cutoff a_v of the appropriate parity. Initially the
cutoffs are n-1 or n-2; adjacent cutoffs differ by exactly one. A global
maximum is a local maximum, so every neighbor of v has height a_v-1.
Replacing a_v by a_v-2 therefore preserves all adjacent differences one.

Repeated virtual flips remove distinct successive top positions within
each fiber. Only positions lying in the physical interval 0,...,n-1
need be inspected. Skipping out-of-board removals uses fewer probes and
does not invalidate containment of the actual survivors in the lowered
prefixes. The method needs containment, not equality of actual beliefs
with the virtual prefixes.

After the m flips, denote the cutoffs by a'_v. Every path-direction move
is bounded above by a'_v+1. Every H-neighbor contribution is also bounded
by a'_v+1 because adjacent cutoffs differ by one. Thus the next vector
a'_v+1 dominates the entire actual neighborhood and has the correct
flipped parity. It remains Lipschitz on H. Clipping at the lower and
upper physical boundaries only deletes possibilities, so negative virtual
cutoffs cause no semantic difficulty.

The sum of cutoffs decreases each day by `delta=2m-A>0`. Connectedness
keeps their range at most D. If any cutoff were nonnegative, every other
cutoff would be at least -D, giving sum at least `-(A-1)D`. Therefore a
cohort starting from sum S_0 is cleared within

    max(0, floor((S_0+(A-1)D)/delta)+1)

days. The original all-miss trajectory semantics then says capture must
already have occurred by that day. The other initial-parity cohort can
be cleared in a second phase; while untouched it occupies a full current
parity class, so the same initialization applies.

Taking H=P_3 square P_3 gives A=9 and a five-probe strategy for every
length. Together with the independently certified five-probe lower bound
on the 3-by-3-by-3 subgraph, this proves feasibility threshold five for
3-by-3-by-n, n>=3. The n=1 and n=2 thresholds are supplied by the earlier
square and side-two classifications. This construction alone makes no
claim about optimal capture time on the longer cylinders.

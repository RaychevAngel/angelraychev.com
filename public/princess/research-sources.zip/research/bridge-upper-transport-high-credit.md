# A sharper uniform high-region credit bound

13 September 2026. Ordinary proof, independently reviewed and accepted
by the root lane, including the odd-width progress and clipped endpoints.
This strengthens the accepted even- and odd-width buffered couplings.
It retains their low-region and middle-region arguments unchanged.

For every even width `w=2r>=4`, length `n>=w`, and quota `k<rn`,
both couplings, and therefore the one-day lower/upper bracket, hold if

    k >= ceil(13r/5) = ceil(13w/10).

The sharper integer condition below applies to both width parities.
For odd width `w=2b+1`, `b>=2`, and even length `n>=w`, a clean
corollary is `k>=ceil(13b/5)+3`. The existing accepted common bound
`ceil(4w/3)` remains available wherever it is smaller. These results
do not settle the full proposed range `k>=w`.

## A decreasing-deficit lemma

Let `v>=1`, `K>v`, `A=K-v`. Suppose a nonnegative integer deficit
starts at `d0<=v²`, and, until it vanishes, satisfies

    d_(j+1) <= max(0, d_j-K+R(d_j)),

where R is the ceiling square root. Then capture occurs within t steps
if `t>=1` and

    t*A + sum_(j=0)^(t-1) floor(j*A/(2v)) >= v².          (H)

Indeed, as long as capture has not occurred, `d_j<=v²-j*A`.
Put `s=floor(j*A/(2v))`. Noncapture implies `s<v`, and

    (v-s)² >= v²-2v*s >= v²-j*A >= d_j.

Consequently `R(d_j)<=v-s`, and the j-th decrease is at least
`A+floor(j*A/(2v))`. Summing proves (H). If `j*A>=v²`, the coarser
bound already guarantees capture, so no later square-root estimate
is required.

A sufficient condition using a fixed number of arithmetic operations is

    4v*t*A + A*t*(t-1) - 4v*(t-1) >= 4v³.                (HP)

For j=1,...,t-1, use `floor(j*A/(2v))>=j*A/(2v)-1` and sum.
The explicit hypothesis `t>=1` is necessary for this last bound.

## Applying the lemma to both couplings

In the even-width proof, retain the scalar relaxation S. Upon high
entry its deficit is at most `(r-1)²`; its exact nonterminal update is
`d'=max(0,d-k+R(d))`. The low and middle arguments provide BOTH
physical trajectories with at least `c=m-r` credits, where `m=floor(k/2)`.
Each trajectory spends at most one credit on alternating high steps.
Thus both couplings hold whenever

    c>=1, v=r-1, K=k, t=2c,

satisfy (H), or the stronger sufficient test (HP). This replaces only
the former estimate `ceil((r-1)²/(2(k-r)))` on required high credits.

For odd width, retain the accepted phase alignment with
`c=m-b-1`. At high entry the largest corner threshold is `a=B2<h`
with deficit `d=h-a<=b²`. Choose survivor corner count i=1 and target
corner count j=2 in the backward update. Its high inverse is
`1+rho(d)<=1+R(d)`, and its unrestricted cap is b+1. The source
survivor lower bound is valid: here `a>=h-b²>=b²+3b+1`, so
`a-(1+rho(d))>1`; the upper survivor cap cannot intervene because
`a<h`. Consequently

    B'2 >= min(h, a+k-1-R(d)),
    d' <= max(0, d-(k-1)+R(d)).

Apply the same lemma with

    c>=1, v=b, K=k-1, t=2c.

The physical trajectory chosen at entry spends at most `ceil(j/2)`
credits in j steps, exactly as in the reviewed odd-width argument.
Capture by `2c` therefore proves both MAX-phase couplings. These
parameter conditions also ensure all seed and positive-progress
hypotheses of the earlier proofs; retain `k>=w` and `k<h` explicitly.

The leading-order form of (HP), with quota divided by half-width equal
to lambda, is

    (lambda-1)*((lambda-2)+(lambda-2)²/4) >= 1.

The left side minus one factors as
`lambda*(lambda²-lambda-4)/4`. Thus this sufficient gate asymptotically
starts at `(1+sqrt(17))/2`, approximately 2.56155, compared with the
earlier gate's `(3+sqrt(5))/2`, approximately 2.61803.

## Clean even-width corollary without finite exceptions

Suppose `k>=ceil(13r/5)`. Then c>=1 for r>=2. Write

    v=r-1, A=k-r+1 >= 8r/5+1,
    t=2(floor(k/2)-r) >= 3r/5-1.

The slack in (HP) is increasing in A and t on this domain. Substituting
these lower bounds and multiplying by125 gives

    52r³-95r²-25r+250
      =52(r-2)³+217(r-2)²+219(r-2)+236 > 0.

Hence (HP) holds for every r>=2. There is no exceptional-width table
or empirical extrapolation in this corollary.

For odd widths, `k>=ceil(13b/5)+3` gives `v=b`,
`A>=8b/5+2`, and `t>=3b/5`. Substitution yields positive slack

    (52b³+270b²+350b)/125,

so this is also a uniform sufficient corollary. A sharper rounding
statement is unnecessary for the integer gate itself.

## Scope and bounded checks

The owned verifier checks both exact abstract high-deficit clocks and
the original model/prefix couplings at budgets first admitted by (HP),
including its clipped capture boundary. It also checks the two polynomial
identities by exact rational arithmetic. The receipt records source
hashes and counts. These checks support the new local proof; they do
not replace its variable-width argument.

The low-root credit cannot simply be replaced by a fixed smaller
multiple of its old cost. For example, a proposed loss `ceil(3*rho/4)`
at r8,k16 and scalar size41 gives physical lower input43. Two physical
updates yield61 and60, while the proposed target demands both61.
Adding a constant to that loss does not repair the local invariant in
general. Further progress toward k>=w needs a different low invariant
or a count of the specific root bands where a high credit is actually
spent.

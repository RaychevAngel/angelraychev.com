# Independent audit: exact profile for an even shorter side

12 September 2026. Audit of all six sections of
`uniform-even-rectangle-isoperimetry.md`. **Verdict: PASS as an ordinary
all-parameter theorem.** No dynamic normalization or Lean verification
is implied.

For G=P_(2b)×P_n, b≥1, n≥2b, and h=bn, the common minimum
open-neighborhood profile of its two colors is

    g(k)=k+min(ceil(sqrt(k)), b, rho(h−k)),
    rho(d)=min{s≥0:d≤s(s+1)}.

The shorter-side and even-side hypotheses are retained exactly.

## Matching and the common core

I checked the parity-dependent coordinate identification directly. The
matched short-axis pairs give loops, the longitudinal edges become
bidirectional horizontal edges, and the unmatched short-axis edges form
rungs with uniform alternating column directions. Opposite physical
colors transpose this graph. Thus the physical neighborhood surplus is
exactly the directed outside boundary size s, and in particular s≥0.

For s<b, the inequality n≥2b≥2s+2 guarantees two consecutive columns
without a boundary vertex. They form a strongly connected ladder, even
for b=1. Every boundary-free row is an intact bidirectional path meeting
that ladder. Outgoing closure therefore forces *all* these rows to be
full or *all* to be empty. This does not assume that the entire remaining
digraph is strongly connected.

## The sharp anchored row bound

The selected downward-rung column parity telescopes toward a boundary-free
anchor row exactly as in (4); the anchor has both alpha_r and t_r zero.
For even n, the horizontal matching gives beta_i≤alpha_i+t_i directly.
For odd n, the only obstructing selected set is the entire larger column
parity. Such a set would require q=(n−1)/2 opposite-parity horizontal
neighbors. But (4) bounds the available selected or boundary vertices of
that parity by the total barrier size s, whereas q≥b>s. The exception
is therefore excluded without assuming even longitudinal length.

The weighted summation is valid even if occupied rows are disconnected.
Every occupied row has at least one barrier vertex. Reserving one there
gives coefficients 1,3,…,2a−1; any remaining barrier vertex has coefficient
at most 2a. Hence the sum is bounded by a²+2a(W−a)≤W². Repeating below
the anchor gives |U|≤W²+(s−W)²≤s². There is no unproved packing or
consecutiveness assumption in this argument.

## Complement and profile lower bound

When the selected set contains the core, T=V\(R∪B) is disjoint from the
same barrier B and empty on its boundary-free rows. Any transposed edge
from T into R would be an original edge from R outside R∪B, which is
impossible. Therefore B contains the transposed outside boundary of T,
which is precisely the generalized anchored lemma's hypothesis. It need
not equal that boundary. This gives |T|≤s² and h−|R|≤s(s+1).
The dichotomy then yields the stated minimum of the three surplus bounds.

## Attainment and endpoints

Downward pyramids are ideals of a finite acyclic predecessor relation,
so ideals of every cardinality exist. Their virtual fiber heights cover
empty rows and both boundary collars. The opposite-color neighborhood
height is at most the old height plus one. The per-fiber cardinality
change is (a'_x−a_x+2s_x−1)/2; the parity correction sums to zero because
there are 2b rows. Thus every pyramid has surplus at most b.

For ceil(sqrt(k))=s<b, a corner diagonal prefix fits together with its
neighborhood inside a 2s×2s square and has exactly k+s neighbors. For the
co-small case s=rho(h−k)<b, x=h−k−s lies in [0,s²]. The same construction
supplies an opposite-color X with |N(X)|≤h−k. Choosing k vertices outside
N(X) gives a set whose neighborhood avoids X and has size at most k+s.
This argument needs no compatibility between differently sized minimizers.
The empty/full endpoints and s=0 cases are included.

## Independent physical-subset supplement

`src/uniform_even_profile_audit.py` constructs adjacency directly from
coordinate differences and exhausts every same-color subset on nine
boards: 2×2, 2×3, 2×7, 4×4, 4×5, 4×6, 4×7, 6×6, and 6×7.
All 4,762,392 subsets satisfy the sharp dichotomy, and every exact minimum
profile agrees with the formula. The run used 0.790 CPU seconds; receipt:
`uniform-even-profile-independent-check.json`. This is an independent
finite supplement to the ordinary proof above.

## Scope

The result gives a sharp static isoperimetric profile on every rectangle
with an even shorter side. It does not supply an operator that preserves
all future search possibilities, nor make the two-cardinality search
relaxation exact. Existing partial-state and varying-budget prefix
counterexamples are unaffected. Dynamic optimal-time conclusions require
their own lower/upper arguments.

## Addendum: extension to every even-area rectangle

The proposed extension to **every rectangle of even area** also passes
independent review. Let e be either even side, o the other side, let
w=min(e,o), and put b=floor(w/2), h=eo/2. For w≥2, match along e.
The directed array has e/2 rows and o columns. If s<b, then e/2>s
supplies an anchor row and o≥2b≥2s+2 supplies two adjacent unmarked
columns. If o is odd, its minority-column size (o−1)/2≥b>s excludes
the same horizontal matching exception. Thus the anchored area proof
and transposed complement yield the same lower profile unchanged.

For attainment, put the physical short axis in the transverse coordinate
of a downward pyramid. If w is even, its parity correction sums to zero
as before. If w=2b+1 is odd, choose physical color p=0. There are b+1
fibers with s_x=0 and b with s_x=1, so

    sum_x(2s_x−1)=−1,
    |N(S)|−|S|≤(w−1)/2=b.

Reflection of an even side transfers the construction to the other color.
When the even side is longitudinal, this changes downward pyramids to
upward pyramids; that is harmless for static attainment and must not be
silently reused as dynamic nesting. The small and co-small constructions
fit exactly as before. The one-dimensional case w=1 has b=0 and follows
separately by even-path endpoint prefixes, giving g(k)=k.

The formula is therefore the same with b=floor(shorter side/2), without
an even-shorter-side restriction. The separate high-budget time theorem
in this audit still requires even shorter side; it has not been extended
by this static argument.

A further raw-coordinate check exhausts 2,172,032 physical same-color
subsets on 3×4, 3×6, 3×8, 5×6, and 5×8; both profiles agree exactly.
Receipt: `uniform-even-area-profile-independent-check.json`.

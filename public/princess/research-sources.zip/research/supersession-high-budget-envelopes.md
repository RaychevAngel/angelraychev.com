# A general large-budget envelope theorem and its precise limitation

12 September 2026. **Sections 1–3 and the explicit Section 5 example
independently accepted. Section 4 is an unpromoted general upper-bound
extension; Section 6 records the open lower-bound problem.** The audit is
`supersession-high-budget-envelope-independent-review.md`, with independent
replays in `supersession-high-budget-envelope-independent-replay.json`
and the root's `supersession-hamiltonian-corner-independent-check.json`.
The accepted one-step lemma is written in the separate reusable manuscript
file `paper/sections/pyramid-envelope-lemma.tex`; no other shared
manuscript or website file was edited by this research agent.
The purpose is to replace separate rectangle upper
constructions by one theorem for Hamiltonian cylinders, and to identify
the extra hypothesis needed before claiming an exact time formula.

## 1. The exact empty-fiber threshold

Let Q be a finite connected bipartite graph with at least two vertices.
Choose its bipartition
χ:V(Q)→{0,1}. A downward pyramid in Q □ P_n has virtual heights

    a_v=s_v−2+2k_v,   s_v=(p−χ(v)) mod 2,
    |a_u−a_v|=1 on every Q edge.

Its k_v rooms in fiber v are the spacing-two prefix from y=0. Define

    H_Q = max_v sum_u ceil(dist_Q(v,u)/2).                 (1)

**Lemma.** Every pyramid with an empty fiber has at most H_Q rooms.
Across both physical colors this bound is sharp whenever
n≥diam(Q). Consequently every pyramid larger than H_Q has every
physical fiber nonempty.

**Proof.** If fiber v is empty, a_v=s_v−2. The edge inequalities give
a_u≤s_v−2+dist(v,u), and hence

    k_u≤(s_v+dist(v,u)−s_u)/2.

Distance parity is χ(u)−χ(v). If s_v=0, the right side is
floor(dist(v,u)/2); if s_v=1 it is ceil(dist(v,u)/2). Summing proves
the bound for either physical color, including finite-height clipping.

Choose a maximizing v and the physical color with s_v=1. The heights
a_u=dist(v,u)−1 satisfy the required parity and differ by exactly one
across every Q edge: adjacent distances differ by at most one and have
opposite parity. They are valid virtual heights and give exactly
k_u=ceil(dist(v,u)/2). Their largest value is at most diam(Q)−1, so
they fit when n≥diam(Q). Fiber v is empty and the sum is H_Q. ∎

For a path of order 2b this gives H_Q=b²; for a path of order 2b+1
it gives H_Q=b(b+1). Indeed the sum is largest at an endpoint, since
the increments of sum_(j=1)^t ceil(j/2) are nondecreasing. Thus (1)
contains exactly the two thresholds used in the even-area rectangle
upper constructions. It is generally smaller for cross-sections with
short graph distances; for K_(b,b), b≥1, it is 2b−1.

## 2. Erosion and prescribed-size enlargement

Write c_p=|χ^−1(p)|. If a physical-color-p downward pyramid A has more
than H_Q rooms, lower every virtual height by one. The result E is a
valid opposite-color pyramid and

    |E|=|A|−c_p,             N(E)⊆A.                     (2)

All fibers of A are nonempty, so no lowered height crosses its allowed
empty value. Edge differences stay one and parity changes correctly.
In the cardinality formula, a fiber loses one room exactly when s_v=0,
which occurs at χ(v)=p. Every longitudinal or transverse neighbor of
E has height at most the appropriate a_v, proving the inclusion even
at the two physical ends.

Pyramids are ideals of the finite predecessor poset, whose relations
always decrease y. Any pyramid can be enlarged to every prescribed
cardinality between its size and the full color-class size: repeatedly
add a minimal element of its complement. More generally, for an arbitrary
one-color set R let cl(R) be its downward predecessor closure. If

    |cl(R)| ≤ |R|+m ≤ |V_p|,
    |R|+m > H_Q,                                         (3)

extend cl(R) to a pyramid A of exactly |R|+m rooms and apply (2).
The designated next inspection A\R has exactly m rooms. From any
earlier survivor contained in E, movement enters A, and these shots
leave an actual survivor contained in R. Thus a nonpyramidal terminal
support is admissible whenever its closure overhead is at most m.

This is the main strengthening over a pyramid-only endpoint rule.
No cardinality-preserving projection of R is used. The actual forbidden
rooms are inspected, while the nonpyramidal residual is retained.

## 3. Uniform backward realization, with physical timing

Assume henceforth Q has a Hamiltonian path and A=|Q|≥2. Its bipartition
is balanced or differs by one. Fix m>H_Q. Suppose an intended last
survivor R has physical color p and is admitted by (3).

One backward step gives a previous survivor E of physical color 1−p
and size

    |E|=|R|+m−c_p.                                      (4)

The survivor E is pyramidal, so every further backward step uses an
ordinary pyramid enlargement. Continue as long as the requested
pre-inspection envelope fits its color class. If the last enlargement
is the full initial color class, reading the construction forwards
gives an actual full-budget half-strategy with terminal survivor
contained in the original, possibly nonpyramidal, R.

Explicitly, for a q-day half with physical colors p_1,…,p_q and
p_(i+1)=1−p_i, define terminal size r_q=|R| and recursively

    r_(i−1)=r_i+m−c_(p_i)  (i=q,…,2),
    |V_(p_1)|=r_1+m.                                    (5)

If every enlargement r_i+m is at most its physical class size and
the terminal closure satisfies (3), this realizes the half. The final
actual belief after its following move is contained in N(R).

For cylinders of even area all color classes have the same size h,
and m>H_Q≥max(c_0,c_1) makes the backward sizes increase strictly.
Consequently the last equality in (5) alone ensures all intermediate
size bounds. Indeed H_Q≥A−1≥max(c_0,c_1): every other vertex contributes
at least one to the distance sum, and both parts are nonempty.

Time reversal joins two such halves. If a q-day sequence from a full
color class has next belief contained in X, then X followed by its
reversed q inspections captures the corresponding full color class.
An avoiding walk in the reversed sequence would reverse to a forward
avoiding walk ending outside X. Thus two q-day halves with opposite
middle colors and terminal neighborhood envelopes X,Y join through a
single shared day whenever |X|+|Y|≤m. This uses actual containing
envelopes, not equality of the intermediate beliefs.

## 4. Finite corner tables and two explicit uniform upper bounds

For a relative physical color p at the filled endpoint define

    C_(p,n)^m(k) = min |N(R)|
      over |R|=k and |cl(R)|−k≤m on Q □ P_n.              (6)

The table is used only when k+m≤h. Every pyramid is admissible, so
the relevant entries exist. If k≤m, any admissible closure has at most
2m rooms, and each of its fibers has at most 2m rooms. Thus its largest
height is below 4m and its neighborhood lies below 4m+1. It follows
that (6) stabilizes for n≥4m+2. For each fixed Q,m, all entries used
below therefore belong to a finite corner table depending on
min(n,4m+2). This is an exact finite minimization, not a claim of an
efficient algorithm for computing the parameter table.

### Even-order cross-section

Let A=2b, let h=An/2, and assume H_Q<m<h. Put d=m−b and divide

    h−b=qd+r,   0≤r<d.

For r>0 put C_p=C_(p,n)^m(r). Backward realization (5) works from
every admitted residual of size r in either phase. Since pyramids have
neighborhood at most r+b, C_p≤r+b<m.

If n is odd, set J_sum=C_0+C_1. If n is even, longitudinal reflection
swaps physical colors and orientation, so either physical cohort can
use the cheaper relative-phase corner; set J_sum=2min(C_0,C_1).
The physical half constructions give

    T_m ≤ 2q                         if r=0,
          2q+1                      if r>0 and J_sum≤m,
          2q+2                      otherwise.            (7)

No color-swapping automorphism of Q is assumed. For an even path Q,
its transverse reflection does supply such an automorphism, so both
corner costs agree and the earlier 2J central test is recovered.

### Odd-order cross-section, even length

Let A=2b+1, label the larger Q color by zero, and let n be even.
Assume H_Q<m<h=An/2. Put D=2m−A and divide

    W=2h−A−1=qD+r,   0≤r<D.

The rank u(R)=2|R|+p makes (4) add exactly D. Since W is even and
D odd, q and r have the same parity. Choose the last survivor to have
rank r+1, so its size/relative phase is

    (k,p)=(r/2,1) if r is even,
          ((r+1)/2,0) if r is odd.

For r=0 use an empty phase-one residual. Applying q−1 backward steps
gives first-survivor rank 2h−2m and phase zero; adding m gives the
full initial class. All size conditions hold. For r>0 set

    J = C_(p,n)^m(k).

Any pyramid of phase zero has surplus at most b, and any phase-one
pyramid at most b+1; hence J≤m. Longitudinal reflection swaps physical
colors, so the favorable initial relative phase zero is available for
either full cohort independently. The same construction gives

    T_m ≤ 2q                         if r=0,
          2q+1                      if r>0 and 2J≤m,
          2q+2                      otherwise.            (8)

Equations (7) and (8) are general physical upper bounds. They do not
assert that arbitrary optimal strategies satisfy the corresponding
scalar lower bound. Their new scope is arbitrary Hamiltonian Q and
admitted nonpyramidal terminal corners.

## 5. A concrete obstruction to a pyramid-only corner formula

Let Q have vertices 0,…,5, the Hamiltonian path edges 01,12,23,34,45,
and additional edges 14,25. Its bipartition is {0,2,4} and {1,3,5}.
The distance sums in (1), in vertex order, are

    7,5,5,6,5,6,

so H_Q=7. On Q □ P₅, the color-zero support

    R={(0,0),(0,2)}

has neighborhood {(0,1),(0,3),(1,0),(1,2)}, of size four. Every
downward pyramid of that color with two rooms lies entirely in y=0:
any room at y=1 has at least two required Q predecessors, because
all opposite-color Q vertices have degree at least two. Higher rooms
force one at y=1. Every pair of vertices in {0,2,4} has all three
opposite Q vertices as neighbors, so such a two-room bottom pyramid
has neighborhood size five. Thus the unrestricted corner minimum is
strictly better than the pyramid-only one.

The predecessor closure of R has five rooms:

    cl(R)={(0,0),(2,0),(4,0),(1,1),(0,2)}.

Its overhead is only three, so (3) admits R when m=8. In color one,
the pyramid S={(3,0),(5,0)} has neighborhood size four. This produces
an actual five-day search at m=8, with the following envelopes:

    A={(0,0),(0,2),(1,1),(1,3),(2,0),(2,2),
       (3,1),(4,0),(4,2),(5,1)},
    E={(0,1),(1,0),(1,2),(2,1),(3,0),(4,1),(5,0)},
    B={(1,0),(3,0),(5,0),(0,1),(2,1),(4,1),
       (1,2),(3,2),(5,2),(0,3)},
    F={(0,0),(0,2),(1,1),(2,0),(3,1),(4,0),(5,1)}.

They satisfy N(E)⊆A and N(F)⊆B, with |A|=|B|=10 and |E|=|F|=7.
Writing V_p for the full physical color class, inspect

    V_1\E,  A\R,  N(R)∪N(S),  B\S,  V_0\F.              (9)

Every shot set has size eight. Direct physical replay gives successive
belief sizes 25,19,13,8,0. The spanning P₆ □ P₅ rectangle requires
five days at budget eight by the already proved odd-short high-budget
theorem, so T₈(Q □ P₅)=5.

The direct coordinate checker is `src/supersession_even_corner_witness.py`;
its receipt is `supersession-even-corner-witness.json`. It verifies this
explicit schedule and the two-room pyramid costs, without searching for
an optimum or replacing the cited lower-bound proof.

Here h=15, d=5, q=2, r=2. The pyramid-only phase costs are five and
four, and n is odd; using those costs as an allegedly exact version
of (7) would return six. Admitting the nonpyramidal R changes the
central cost to eight and gives the true five-day strategy. This is
a precise failure of pyramid-only terminal optimality even above H_Q.
It does not refute the envelope theorem: it is an example of its
strictly stronger admitted-corner version.

## 6. Remaining lower-bound hypothesis

A matching general-Q lower theorem has not been proved. In the rectangle
proofs it comes from explicit unrestricted neighborhood profiles,
superadditivity or history-corrected deficit bounds, and a midpoint
intersection obstruction. The envelope theorem solves compatibility
of a terminal corner with the bulk when its closure overhead fits the
daily budget; it does not itself prove that every optimum has this
terminal form or that its total progress obeys the same scalar bound.

The appropriate next static/dynamic target is therefore a packing bound
for arbitrary supports that matches the admitted corner table (6).
Replacing that target by a pyramid-only isoperimetric assertion is
invalid, as Section 5 shows. No exact all-Hamiltonian-Q time formula
is claimed here.

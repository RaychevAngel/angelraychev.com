# Symbolic minimum-budget lower: bounded attempt and remaining obligation

13 September2026. This records an unfinished algebraic attempt after the
accepted near-pronic localization/dual-feature theorem. No new width scan,
unbounded minimum-time equality, or additional formalization is claimed.

## Precise intended theorem

For w=2b+1 and even n>=w, the explicit physical upper is

    T_(b+1)(w,n)<=2wn-C_w,
    C_w=8b^2-4b-4L_b+4.

Here L_b is the existing two-component width clock from the all-odd
minimum-budget theorem. The next target is the matching lower uniformly
in b,n; the recurrence evaluation would remain a separate O(1) numerical
gap. The strengthened necessary model now has a proved merger, so a
uniform solo lower plus the central residual would suffice. It is not
necessary to characterize every physically attainable partial state.

The known proof for odd lengths separates an initial corner clock, a
common affine interval, and a reflected terminal corner clock. On even
lengths the new critical orientation and near-pronic dual restrictions
provide analogous constraints, but an invariant joining all three pieces
has not yet been proved.

## First candidate: minimum of the two anchored clocks

Let F_p(a) be the direct anchored-prefix solo capture clock starting
with cardinality a and current phase p, evaluated by the already proved
oriented prefix profiles. A natural proposed lower potential is

    V(a,c,e,z)=min(F_0(a),F_1(a)).

This is NOT a valid one-step potential. A physical counterexample occurs
at budget6 on11x12: the phase-zero13-room prefix, after deleting its
last6 rooms, has a10-room phase-one neighborhood. Its feature transition
is(13,1,0)->(10,0,1). Yet

    min(F_0(13),F_1(13))=4,
    min(F_0(10),F_1(10))=2.

The actual phase-one remaining clock at10 is3. The pointwise minimum
silently changes the favored phase at the intermediate state. Thus even
validity on literal prefixes fails, despite the focused necessary graph's
exact remaining distances lying above this minimum at every state.

## Second candidate: assign an anchored phase from corner features

The next trial assigned phase1 when c=0, phase0 when e=0 or(c,e)=(2,1),
phase1 when(c,e)=(1,2), and the smaller clock in the remaining classes.
It too fails. In particular(10,1,2)->(6,0,1) at cost6 is permitted and
can be physical, while the proposed values are3 and1.

For an explicit construction in coordinates0<=x<12,0<=y<11, take

    S={(0,0),(0,2),(1,1),(2,0)},

and add the four neighbors of the two opposite-colored corners:

    (10,0),(11,1),(10,10),(11,9),

plus(5,5),(6,4). The resulting10-room source has c=1,e=2. Inspect the
six added rooms. N(S) is the6-room odd triangle, with c=0,e=1, and the
next day clears it. High erosion-corner count on a small disconnected
belief does not determine a stable spatial orientation: the remote
components can all be inspected immediately.

These examples reject the two stated formulas, not the existence of
a finite feature potential. They also explain why a stronger assertion
about all partial states should not become an additional research goal.

## A precise remaining frontier obligation

For each horizon t, seek a finite family of inequalities describing an
OUTER bound on feature states(a,c,e,z) capturable within t days. Its
coefficients may use the two anchored backward clocks B_0(t),B_1(t),
the corner capacities, and fixed case distinctions. It must satisfy:

1. Every terminal feature with a<=b+1 belongs to the one-day bound.
2. Every predecessor of a bounded target under the proved necessary
   transition rules belongs to the next bound, for every allocation,
   survivor feature, and target feature allowed by those rules.
3. The bound excludes the full state(h,2,2) before the physical solo
   upper clock, and yields the needed preterminal residual for the
   central-day exclusion.

The actual algebraic bottleneck is item2: eliminate the survivor and
target choices uniformly while retaining which endpoint supplies the
corner gain. The mixed low/high capacity and merger inequalities already
control sums of states; they do not automatically prove this one-state
predecessor invariant. No finite formula for that invariant, or proof of
its closure, was obtained in this bounded pass.

An obvious uniform strengthening to examine later is the near-pronic
dual interval at every subcritical radius, rather than just radius b:
the localization proof extends by the same component and upper-shadow
argument whenever the board's opposite-color corners are beyond the
relevant radius. This would remain a fixed-size geometric rule, but no
claim is made here that it supplies the missing frontier invariant.

Research was halted for the publication checkpoint at the parent's
request. The accepted geometric results and focused finite equalities
are unaffected by these failed potential proposals.

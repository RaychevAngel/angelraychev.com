# Grid nesting, source scope, and exact time dynamic programming

Audited 11 September 2026. **Conclusion:** the blanket assertion that rectangular grids satisfy full isoperimetric nesting is false. A two-count dynamic program is exact under genuine nesting, but that hypothesis must be established for the graph in question. Hypercubes, all two-row ladders, and odd squares survive the audit; rectangles with both sides at least three and an even side do not.

## 1. What the primary sources actually establish

**Bolkema and Groothuis, _Hunting Rabbits on the Hypercube_, arXiv:1701.08726v2 (7 October 2018), subsequently Discrete Mathematics 342 (2019), 360–372.** Definition 14, PDF p.5, requires both parity-prefix families to minimize neighborhood size at **every** cardinality, and requires their neighborhoods to be prefixes on the opposite side. On PDF p.6, the authors attribute grid nesting to their reference [1] and state that the order `(x+y,x)` works for `m×n` grids with `m>n`. Their Theorem 16 determines the minimum hunter count, not the minimum number of turns. The hypercube result is explicit: Theorem 35, PDF p.11, establishes full nesting for weightlex orders, using their Lemma 24 and Theorem 25. [Primary PDF](https://arxiv.org/pdf/1701.08726)

**Abramovskaya, Fomin, Golovach, and Pilipczuk, _How to hunt an invisible rabbit on a graph_, European Journal of Combinatorics 52 (2016), 12–26.** Section 3.1 concerns **square** grids. Theorem 1, printed p.20/PDF p.9, gives the minimum neighborhood size for an even-parity set of size `p` as the minimum of **two** explicit orders' prefix-neighborhood sizes. It does not say one order always wins. Printed p.21/PDF p.10 explicitly illustrates the switch on a `6×6` board: one candidate wins at size four, the other at size twelve. Corollary 1 uses a particular cardinality; Theorem 2 then obtains the general rectangular hunter threshold. [Author-hosted primary PDF](https://fedorvf.github.io/articles/2016/2016g.pdf)

Thus the 2018 paper's general-grid remark is stronger than the cited 2016 statement, and the elementary obstruction below refutes it as stated. This does not refute the independently proved rectangular hunter threshold or the hypercube nesting theorem.

## 2. A general obstruction: most rectangles have no compatible orders at all

Let `G=P_a square P_b`, where `a,b>=3`, and suppose at least one of `a,b` is even. Each bipartition class contains at least one corner. Corners are precisely the vertices of degree two; every neighbor of a corner has degree three because both side lengths are at least three.

Suppose full nesting orders existed. The first even vertex `u` would have to minimize the neighborhood of a singleton, so `u` would be a corner. Its two neighbors would form the first two vertices in the odd order. In particular, the first odd vertex would be a neighbor of `u`, and would have degree three. But there is an odd corner, whose neighborhood has size two. This contradicts singleton optimality of the odd order.

Therefore:

\[
 a,b\ge3,\quad ab\text{ even}
 \quad\Longrightarrow\quad
 P_a\square P_b\text{ has no full isoperimetric nesting orders.}
\]

This is an obstruction to **every** choice of compatible orders, not merely to the published diagonal order. It covers even squares, odd-by-even rectangles, and even-by-even rectangles.

For a concrete example with the longer coordinate first, the diagonal odd singleton on `4×3` is `(1,2)`, with three neighbors, whereas `(4,1)` is an odd corner with two neighbors. Even if one changes the initial odd vertex to that corner, compatibility with the opposite singleton still fails by the preceding argument.

The same argument applies to even paths of length at least four with degree one replacing degree two. Thus even the earlier path problem warns against using arbitrary minimum-neighborhood profiles without compatible minimizers.

## 3. Positive rectangle subclass: every two-row ladder

For the `n×2` ladder, each parity class has exactly one vertex in each column. Identify both parity classes with the column index set `{1,...,n}`. An opposite-parity neighbor is in the same column, or in a neighboring column. Consequently the open graph neighborhood of a parity subset with column set `S` corresponds exactly to the **closed** path neighborhood

\[
 \Gamma(S)=S\cup(S-1)\cup(S+1)
\]

within `{1,...,n}`.

For `0<k<n`, every `k`-element column set has at least one neighbor outside itself, by connectedness of the path, and therefore `|Gamma(S)|>=k+1`. A prefix of `k` columns attains this bound, with neighborhood the prefix of `k+1` columns. Empty and full sets give the endpoints. Thus both profiles are

\[
 g(0)=0,\qquad g(k)=\min(k+1,n)\quad(k>0),
\]

and ordering both parities by increasing column gives full nesting for **every** positive `n`. This is a direct proof, independent of the erroneous broad grid attribution. For `n=1`, the graph is one edge and the same formulas hold.

## 4. Positive square subclass: odd squares

Here is a derivation from the precise 2016 theorem, rather than from the blanket 2018 grid remark. It applies to side length `s>=3` odd.

### 4.1 One parity has nested minimizers

Let `E` be the vertices with even `x+y`, the parity containing all four corners. In the 2016 notation, reflection `(x,y)->(s+1-x,y)` maps the order defining `Z_p` to the order defining `Z'_p`. Since `s+1` is even, reflection preserves `E`. It preserves neighborhoods as well. Thus `|N(Z_p)|=|N(Z'_p)|` for every `p`.

Theorem 1 therefore implies that the diagonal `E` prefixes are minimum-neighborhood sets at every size. The original diagonal tie is increasing `y`; transposing the square gives the equivalent increasing-`x` convention used here.

### 4.2 Diagonal prefixes have prefix neighborhoods

Order each parity by increasing `(x+y,x)`. Any nonempty prefix consists of whole earlier diagonals and an initial interval on its last diagonal. All lower neighboring diagonals are filled. The upper neighbors of the partial diagonal form an initial interval on the next diagonal.

More explicitly, on the diagonal `x+y=t`, valid `x` coordinates run from `L=max(1,t-s)` to `U=min(s,t-1)`. If the selected interval ends at `k`, then its upper neighbors have consecutive `x` coordinates from `max(1,t+1-s)` to `min(s,k+1)`, omitting an empty interval at the extreme boundary. Thus the neighborhood is a prefix in the other parity. The first two diagonals and an empty prefix satisfy the same assertion directly.

This geometric closure statement also holds for general rectangles when the bounds are changed to the relevant side lengths. Closure alone, however, does not imply isoperimetric optimality.

### 4.3 Complement duality transfers optimality to the other parity

Central rotation `(x,y)->(s+1-x,s+1-y)` preserves both parity classes and reverses each diagonal order.

Let `S` be any `k`-element subset of the odd parity `O`, and put `T=E\N(S)`. No vertex of `T` is adjacent to `S`, so `|N(T)|<=|O|-k`. Replace `T` by the even prefix `I` of the same size. By even-prefix optimality, `|N(I)|<=|O|-k`. By prefix closure, `N(I)` is an odd prefix.

The last `k` odd vertices, call this set `J`, therefore avoid `N(I)`. Hence `N(J)` avoids `I`, giving

\[
 |N(J)|\le |E|-|I|=|N(S)|.
\]

Central rotation maps `J` to the first `k` odd vertices and preserves neighborhood size. Thus the odd prefix minimizes the neighborhood of every `k`-element odd set. Together with §4.2, both full nesting conditions follow.

**Conclusion:** every odd square of side at least three has full diagonal nesting. This conclusion is a short symmetry-and-duality consequence of the published 2016 theorem plus the explicit closure argument above. It is not a claim that the 2016 paper states this corollary in these terms.

### 4.4 What remains unproved here

Odd-by-odd **nonsquare** rectangles also passed the modest all-subset checks performed during this audit for `5×3` and `7×3`; `3×3` and `5×5` passed as well. These finite checks do not establish an all-parameter rectangular theorem. The square theorem cannot silently be extended to unequal sides. A separate rectangular compression theorem or proof is needed before claiming every odd rectangle.

The width-two exception is proved separately above. Width one is the already analyzed path family; the isolated `1×1` graph needs the game's immediate-capture convention and should not be passed through a no-isolated-vertices theorem.

## 5. Independent check of the conditional two-count dynamic program

Assume a finite bipartite graph without isolated vertices has genuine nesting orders, with parity sizes `e,o` and minimum open-neighborhood profiles `g_E,g_O`. Both profiles are nondecreasing: remove vertices from a larger optimal set to produce a smaller competitor.

A canonical current state `(a,b)` is the union of the even prefix of size `a` and the odd prefix of size `b`. Allocate capacities `p,q` with `p+q<=m`. Delete the tails of those prefixes, clipping to available vertices. The next state after a miss and a move is exactly

\[
 \bigl(g_O(\max(b-q,0)),\ g_E(\max(a-p,0))\bigr).
\]

The state is immediately capturable in the current round exactly when `a+b<=m`.

To prove optimality against unrestricted strategies, compare an arbitrary belief pair `(A,B)` whose sizes dominate `(a,b)`. If that strategy probes `p` even and `q` odd possible vertices, then the surviving sizes are at least `max(a-p,0)` and `max(b-q,0)`. Minimum-neighborhood bounds and monotonicity show that its next sizes dominate the canonical transition. Repeating the **same numeric allocations**, with clipping when the canonical set is smaller, produces a legal canonical schedule that captures no later than the unrestricted schedule. Conversely, every canonical transition is attained by actual tail probes. Hence shortest-path search on the count states gives the true optimum and a concrete strategy.

For the claimed `O(m(e+1)(o+1))` graph-search size, it is enough to consider capacities `p=0,...,m`, `q=m-p`. Unused capacity may be allocated then clipped; extra probes never increase a belief. Thus one need not enumerate `O(m^2)` pairs with a strict inequality budget. The terminal condition contributes the final inspection round; do not confuse it with a free final move.

This argument survives independent review. Its crucial upper-bound step is compatible realization at every transition. Using the two minimum profiles without nesting yields a relaxation, not an exact algorithm. Using a fixed nonoptimal prefix family yields a restricted-strategy upper bound, not an exact algorithm.

## 6. What is already known about capture-time optimization

The 2016 and 2018 papers checked above do not state this two-count, minimum-turn dynamic program. Their relevant optimization target is the number of hunters. This limited negative finding is not a novelty claim.

**Ben-Ameur, Gahlawat, and Maddaloni, _Hunting a rabbit: complexity, approximability and some characterizations_, arXiv:2502.15982v2, 4 December 2025.** Section 5, PDF pp.15–23, explicitly studies `h(G,l)`, the minimum hunters needed to guarantee capture within `l` rounds. It proves hardness results and an approximation algorithm. Corollary 5.7, PDF p.19, states `h(G,2)=M(G)=VC(G)` for bipartite graphs. The paper does not provide the above nesting/count-state recurrence. Therefore the general time-limited problem and the bipartite two-turn characterization are established prior work and must be credited; a new restricted-family algorithm would need a more thorough novelty search. [Primary PDF](https://arxiv.org/pdf/2502.15982)

For a rectangular grid with `N=ab>=2`, a snake Hamiltonian path gives a matching of size `floor(N/2)`, while no matching can be larger. Thus the known two-turn theorem yields the exact two-turn threshold `m>=floor(ab/2)`. This is a consequence of that prior theorem, not a new classification claim.

## 7. Recommended scope at the checkpoint

- Retain the complete path theorem and its reconstructed proofs.
- Use the exact count-state theorem for graphs whose nesting is actually established: hypercubes, ladders, and odd squares as above.
- Clearly separate an exact algorithm from a closed-form capture-time formula.
- Do not claim full rectangular nesting or an exact all-grid two-count algorithm.
- Record the blanket-grid nesting discrepancy as a substantive failed approach discovered by source checking and counterexamples.
- Preserve the older grid feasibility theorem and modern two-turn theorem as prior work.

# Exact odd-board midpoint throughout a uniform linear-budget interval

13 September 2026. The root independently reviewed and accepted the new
minimum-coordinate bound, generalized onset lemma, uniform parameter
inequality, and all twenty finite width margins below. No
manuscript integration, build, or Lean result is claimed.

For every b>=160, every odd n>=w=2b+1, and every budget

    b+1<=m<=2b,

the exact full-board time is

    T=2tau-1  if E+M-D_0(tau-1)-D_1(tau-1)<=m,
      2tau    otherwise.

Here tau and D_p are the already proved scalar solo clocks. Thus this
is an infinite-width matching theorem. It does not by itself replace the
O(width) solo clock by an absolute bounded expression at these budgets.
The fixed twenty arithmetic cases recorded below improve b>=160 to
b>=140 without a joint-state calculation.

## 1. A sharper minimum-coordinate bound from a short window

Write G=m-1 and H=b^2+1. Fix integers q>=1 and 1<=r<=b such that

    q*(2r-b-1)>=G.

Then every attainable exceptional mixed state obeys

    min(x,y)<=K(q,r):=(q-1)*m+r*(r-1).                (1)

This assertion applies to actual histories at proper solo layers. It
does not assert closure of a synthetic frontier.

Let t be its time. If t<q, the total deficit is at most tm, so (1) is
immediate. Otherwise suppose its final smaller coordinate is at least
K(q,r)+1. Under every quota split the new smaller coordinate is at most
the old smaller coordinate plus m, because both proper inverse outputs
are at most their inputs. Therefore both outputs in each of the last q
transitions are at least

    r*(r-1)+1.                                      (2)

At any such transition let X,Y be the two inverse inputs. Their sum is
the old total plus m and is at most M: before the next solo capture even
the larger solo capacity plus m is at most M. Each input is at least its
corresponding output. Hence X,Y,M-X,M-Y are all at least (2).

The exact inverse losses are

    z-I_0(z)=min(rho(z),b,rho(M-z)),
    z-I_1(z)=min(R(z),b+1,1+R(E-z)),

where R is the square-root ceiling and rho the pronic-root ceiling.
Condition (2) makes each of these losses at least r. Thus the joint
total S increases by at most m-2r in each of those q transitions.
The larger solo capacity A increases by at least m-b-1, since each
proper inverse is at least its input minus b+1. Consequently

    (A'-S')-(A-S)>=2r-b-1.

Total concentration gives A-S>=0 at the start of the window. At its
end A-S>=q(2r-b-1)>=G, whereas exceptionality requires
A-S<A-B<=G. This contradiction proves (1).

## 2. The orientation onset works with this smaller bound

More generally suppose K>=m is any valid minimum-coordinate bound for
every exceptional state. Put

    J=max(2K+m+1,K+H),
    W=ceil(max(0,G-b^2)/b)+2*min(b,ceil(sqrt(G))),
    M_onset=J+G+m*(W+1).                             (3)

Then the proof of `bridge-odd-clock-orientation-onset.md` gives the exact
scalar midpoint decision for M>=M_onset. The only adjustment needed when
K is smaller than H is the term K+H in J. Above this threshold the
numerical larger coordinate satisfies

    a>=B+1-K>=H+1,

so its inverse remains expansive. The other term 2K+m+1 prevents a
larger-coordinate identity swap along a surviving exception. Everything
else in the accepted proof is unchanged: a wrongly oriented exception
has negative difference F=B-S in [-G,-1], its root debt disappears within
W proper transitions, and correctly oriented exceptions have a common
ancestry-secondary of size at most K. The condition (3) supplies those
W transitions before capture and also gives M-2K>m.

A useful alternative uses an input-dependent window length without
iterating that window in the numerical answer. For b>=2 set

    q=max(ceil(sqrt(b)),ceil((m-1)/(b-1))),
    r=ceil((q*(b+1)+m-1)/(2q)).

Then q>=2 and q*(b-1)>=m-1 imply r<=b, while the definition of r
implies q*(2r-b-1)>=m-1. Thus Kq=(q-1)m+r(r-1) is another valid
bound, given by an absolute fixed-size arithmetic expression. The minimum
of Kq, the original bound, and K8 when defined is again a valid bound in
(3). This uses three explicit formulas, not a variable optimization.

A prescribed-day version of (3) is also useful. If L=tau-1>=W and
min(D_0(L-W),D_1(L-W))>=J, the last W proper transitions supply the
same cleanup interval. Scalar necessity follows directly even if the
coarser board-size onset is not met. No first-entry estimate is needed
for this deadline certificate.

## 3. A fixed choice covers every board for b>=160

Throughout b+1<=m<=2b take

    q=8,
    r=ceil((8*(b+1)+m-1)/16),
    K8=7m+r*(r-1),
    J=max(2K8+m+1,K8+b^2+1),  W=2*ceil(sqrt(m-1)).

Here r<=b for b>=2, K8>=m, and the inequality required in Section1
holds by the definition of r. Also G<=b^2, giving the stated W.
Every term of J+G+m(W+1) is nondecreasing in m, so it suffices to
bound it at m=2b.

At that endpoint,

    r<= (5b+11)/8,
    K8<= (25b^2+966b+33)/64 <= b^2/2             (b>=160).

For the last inequality, 7b^2-966b-33 is positive at160 and strictly
increasing thereafter. Thus

    J<=3b^2/2+1.

Indeed K8+H has this bound, and 2K8+2b+1<=b^2+2b+1 has the same
bound for b>=4. The square-root term obeys

    ceil(sqrt(2b-1)) <= sqrt(2b-1)+1 <= b/8-1,
    W<=b/4-2.                                      (4)

To check the second inequality in (4), its positive right side can be
squared: it is equivalent to b^2-160b+320>=0, which holds at160 and
is increasing thereafter. Combining these bounds yields

    M_onset=J+(2b-1)+2b*(W+1)
       <= (3b^2/2+1)+(2b-1)+2b*(b/4-1)
        = 2b^2.

Every admissible odd rectangle has M>=2b(b+1)>2b^2. Hence (3) applies
on every board, proving the stated uniform theorem. The already accepted
minimum-budget theorem also covers m=b+1 independently.

## 4. Twenty fixed arithmetic cases sharpen the width cutoff

At m=2b define the exact margin 2b(b+1)-M_onset from Section3. Direct
integer substitution gives the following margins for b=140,...,159:

    184,205,226,427,450,473,96,117,324,347,
    370,583,608,633,852,879,1102,1131,1160,1389.

They are all positive. Monotonicity in m then extends the theorem to
every b>=140, or every odd width w>=281. The finite arithmetic checker
`src/bridge_odd_clock_linear_budget.py` records these substitutions and
large-parameter evaluations in
`research/bridge-odd-clock-linear-budget-check.json`. These calculations
check a fixed twenty-element complement to an ordinary inequality. They
are not experimental evidence extrapolated to unbounded width, and no
joint solver is needed for this extension.

## Scope of the improvement

The resulting exact scalar decision holds uniformly for all odd boards
with w>=281 and (w+1)/2<=m<=w-1. It settles this whole parameter region
even where the earlier sufficient onset exceeds the board size. Budgets
above w-1 and the remaining bounded widths retain their previously stated
proved/open boundaries. In particular, no universal scalar criterion or
absolute bounded numerical expression for all these low budgets is
claimed here.

# Independent review of the fixed-horizon transfer theorem

12 September2026. Reviewed the entire argument in
`research/fixed-horizon-transfer-theorem.md`, not only its local transfer.
**Result: pass; no mathematical correction required.** No new numerical
experiment is needed for the following proof review.

## Envelope equivalence

The proposed R_t may extend outside the provisional current belief.
This is harmless: taking S_t=N(R_(t−1))\R_t gives actual survivors
contained in R_t by induction. The last empty envelope guarantees
capture. The first cost A−|b_1| is exact because the initial belief is
the full board. Conversely actual survivor sets, padded by emptiness
after earlier capture, supply every winning budget vector.

Every local triple cost has the correct neighboring columns and the
correct day index. Internal Q-edges stay in the column; longitudinal
edges supply precisely the adjacent-column survivor sections. Neither
bipartiteness nor any geometric normal form is used.

## Matrix and length accounting

An n-column word gives n transitions from (0,b¹) to (bⁿ,0), including
the two boundary triples. Thus uᵀMⁿv has the correct exponent; there is
no missing final transition or extra column. Each path corresponds to
one word. Commutative monomial weights sum the correct daily costs.
All coefficients are nonnegative, so existence is not spoiled by
cancellation. T=1 is correctly treated separately.

The displayed O(n|W|³(m+1)^T) bound is for a given budget. Searching
m≤An adds only polynomial overhead for fixed Q,T, as claimed. No small
uniform complexity in transverse size or horizon is asserted.

## Effective semilinearity and the optimum graph

The regular-expression route is valid. In particular, if
S=⋃ᵢ(bᵢ+monoid(Pᵢ)), the stated finite union for S* is exact: choose the
set of components used at least once, reserve one base from each, and
allocate every period to that reserved occurrence. Extra occurrences
are precisely extra bases. This proves both containments, including
the empty subset case.

I checked the primary source directly:
[Ginsburg and Spanier,1966](https://msp.org/pjm/1966/16-2/pjm-v16-n2-p09-s.pdf),
Theorem1.1 on printedp287 gives the required Boolean and projection
closure, and Theorem1.3 on printedp288 explicitly gives effective
conversion in both directions. The minimum-budget graph formula is
valid because feasibility is upward closed in m and some m always
works. Handling m=0 separately avoids negative arguments.

## Eventual affine components

Every linear component lies in the graph of a function. A nonzero
vertical generator is impossible. Two positive length generators
(aᵢ,dᵢ),(aⱼ,dⱼ) can be repeated aⱼ and aᵢ times to reach the same
length; uniqueness forces aⱼdᵢ=aᵢdⱼ. Hence each infinite component
lies on one rational affine line.

Its length projection is a translate of a finitely generated numerical
semigroup. Shortest paths in residues modulo any positive generator
give an effective eventual threshold for its gcd congruence class.
Taking a common multiple of the component periods and the maximum
threshold gives residue-wise affine formulas. Since the function is
defined at every n≥2, every eventual residue class is supplied by an
infinite component. If two components supply the same residue, they
overlap at infinitely many lengths and their affine formulas coincide.

## Identifying the slope

The longitudinal matching provides 2A floor(n/2) distinct alternating
trajectories. They occupy pairwise distinct rooms on each inspection
day, so each inspected room intercepts at most one of them that day.
Every winning schedule must intercept all of them. Thus the stated
lower bound holds even for arbitrary internal Q-edges.

For the upper bound, inspecting q+1 full columns while possible rooms
lie in a suffix advances its guaranteed left edge by at least q after
movement. After T−1 such rounds at most n−(T−1)q≤q columns remain.
The final inspection fits the same capacity. Early capture can be
padded. The proof also handles q=1 and horizons longer than n.

These bounds force every infinite affine component's slope to equal
A/T. Enlarging the period by T/gcd(A,T) preserves eventual periodicity
and makes its additive increment integral. Both the exception table
and eventual constants are effective through the previous constructions.

## Scope

This is a complete ordinary theorem about a fixed horizon and a fixed
transverse graph. It does not turn into a fixed-budget theorem merely
by substituting a growing horizon, because the transfer alphabet then
changes. The existing note states this boundary correctly. I make no
priority or complete-Lean claim in this review.

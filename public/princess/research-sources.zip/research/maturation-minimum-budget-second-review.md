# Second independent check of the minimum-budget theorem

13 September 2026. Euler review of root's accepted ordinary theorem and
Dirac's `maturation-odd-midpoint.md`, Section 4. **PASS.**

The argument uses actual initial-cohort ancestry, not whichever numerical
coordinate happens to be larger. A useful precise version of the reset
step is as follows. At the last solo tie, every state is low-total. A later
high mixed state must have a pure ancestor after that tie: otherwise
low-total persistence applies at every step. Begin its tagged history at
such a pure birth. There are at most `L_b` steps left, so the opposite
cohort's deficit is bounded by the fresh solo clock, hence by `C=b(b−1)`.
This does not assert that a pure endpoint coordinatewise dominates every
mixed state at a tie; that would be false. Low final states are handled
directly by total bounds, with no replacement required.

Since `C<d*≤min(D0,D1)`, a high pure state cannot have its nonzero deficit
only in the tagged secondary. For a high mixed successor, persistence
forces a high predecessor. If that predecessor's primary occupies color
zero, source total is at most `D0`. The second inverse-concentration
inequality bounds the successor total by `I1(D0+m)=D1(next)`. Positivity
of its minority coordinate gives the required input at least two. A high
successor must therefore have color one strictly fastest, exactly where
the same original primary moves. The first concentration inequality is
the symmetric color-one argument. All inverse arguments are proper
because each target time is at most `τ−1`; this is the same domain used
by the accepted half-time concentration theorem.

Thus two high midpoint states have their bounded secondaries in the same
physical color. They leave at least `M−2C≥4b>m` rooms there. A pair with
at least one low state instead has raw combined deficit at most `D0+D1`,
so its central cost is at least the solo residual sum. The two solo times
are exactly `τ,τ+1`; the latter fact makes that sum exceed `m` at time
`τ−1`. Both alternatives exclude the short horizon, while the ordinary
time-reversed solo strategy attains `2τ`.

The `b=1` boundary has `C=L_b=0`. The same proof applies: no exceptional
mixed half-history is possible, and the scalar argument is unchanged.
The width-only clock is independent of odd length, so the exact law
immediately gives length increment `4w` under `n→n+2`. There is no new
claim that the clock itself has an elementary expression in width.

`lean/FastestAncestry.lean` now independently verifies the direct abstract
induction and composed numerical midpoint obstruction. It retains explicit
root/concentration, proper-domain, fresh-secondary, and pure-start
hypotheses; the physical and clock instantiations remain ordinary proofs.
Dirac also completed a bounded semantic audit of that source, including
the pure-rebirth guard and movement indices, with no corrections requested.

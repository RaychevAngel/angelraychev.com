# Root review: all lengths at the five-inspection budget

12 September2026. Accepted as an ordinary theorem with exact certificates.
Root read the complete new proof and both independent reviews. The
paired-slice cost has nonnegative increments, so the finite closure
controls every word length. Equality in neighborhood compression at
critical surplus is essential and correctly proves the actual-history
obstruction. The scaled potential equals6k+3e−42 in its middle range;
its full value is6h−54 and combined daily charge is at most3. Hence the
lower time is4h−36. The explicit low/translated-high/middle source ranges
cover every inequality beyond h45, with minimum-output displacement≤5.

The direct sweep identities follow from the exact prefix profiles and
stable bottom/top ranks. Its2+2(h−12)+4=2h−18 solo duration is even;
longitudinal reflection makes the untouched second cohort start in the
same virtual phase. Neighborhood-prefix closure is used only for the
upper construction, never as an assertion of even-box isoperimetry.
The original proposed upper insertion argument also works but has been
replaced by these simpler identities. The resulting theorem is
T5(3×3×n)=18n−36 for every n>=3, by combining the separately proved
parity cases. Larger budgets and full physical Lean for the unbounded
family remain open.

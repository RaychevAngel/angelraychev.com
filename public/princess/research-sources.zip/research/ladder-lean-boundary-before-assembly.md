# Ladder Lean checkpoint: what is and is not proved

12 September 2026 UTC. The source files use Lean 4.33.1 and `Std` only.
They are checked with a single worker. The reproducible check is
`../src/check_ladder_lean.py`; the successful build receipt, source hashes,
compiler version, and printed axiom dependencies are recorded in
`../research/ladder-lean-verification.json`.

**The complete finite two-counter classification is kernel-checked. The
complete room-game classification is not yet assembled in Lean.**

## Counter model: complete for n≥2 and positive m

`LadderCounters.lean` defines the exact transition

```
next(n,b,p) = 0                    if b≤p;
              min(n,b−p+1)         otherwise.
```

`Clears n m b c t` is an inductively defined finite sequence of allowed
allocations to two such counters, starting at `(b,c)`, respecting the daily
sum budget `p+q≤m`, and ending at `(0,0)` after exactly `t` rounds. It is not
a hypothesis that an arbitrary room strategy belongs to this model.

For `n≥2,m≥2`, `counter_classification` proves both existence of a valid
attaining run and minimality among every valid finite counter run. Writing

```
N=n−1, M=m−1, q=N/M, s=N mod M,
```

the formally verified executable optimum is

```
2q       if s=0;
2q+1     if s>0 and 2s<M;
2q+2     otherwise.
```

This also gives one round automatically when `m≥2n`. The equivalence of
this quotient expression with the displayed ceiling-plus-half-residue
formula in the research note is explained mathematically; that final
syntactic equivalence is not a separate Lean theorem in this checkpoint.

The main checked declarations include:

| Declaration | Exact scope |
|---|---|
| `next_mono` | Counter monotonicity in the current belief size. |
| `counter_dominated` | Any cardinality process satisfying the stated transition lower bound dominates the suffix counter. The transition premise is explicit. |
| `capture_lower_bound` | Every successful functional counter schedule satisfies `2(n−1)≤t(m−1)`. |
| `tight_clears_divisible` | Equality forces each initial cohort weight to be divisible by `m−1`. |
| `capture_strict_when_nondivisible` | Strict capacity inequality when `m−1` does not divide `n−1`. |
| `quotient_upper` | An attaining finite strategy, using full sweeps and the shared transition. |
| `quotient_lower` | Optimality of that quotient/remainder bound. |
| `counter_classification` | The combined exact result for every `n≥2,m≥2`. |
| `one_probe_no_clears` | No successful finite counter run when `n≥2,m=1`. |
| `two_probe_optimal` | An explicit functional two-probe schedule and the matching `2n−2` lower bound. |
| `counter_tail_clears` | A successfully captured tail of a functional schedule is a `Clears` run. |

The dimension-one special case `n=1` is excluded from these classification
theorems. Its elementary room-game answer is recorded in the ordinary
research proof.

## Room geometry and set projection: checked separately

`LadderGeometry.lean` defines ordinary physical rooms as a column in `Fin n`
and a Boolean row. Its edge relation contains exactly vertical row flips
and horizontal one-column moves in the same row. It separately defines the
checkerboard encoding, where every edge flips color and the column either
stays or moves one step.

- `recolor_involutive` gives the explicit coordinate bijection.
- `rowAdj_iff_colorAdj` proves that this bijection preserves precisely the
  ordinary ladder edges.
- `physical_no_dead_ends` exhibits the vertical neighbor of every room.
- `physicalStep_iff_recolored` transports an arbitrary inspection/move step,
  including both the belief and the probe set.
- `step_fiber` proves that one color cohort follows the closed-neighborhood
  column update after its probes.
- `cohort_projection` proves the set-level projection for every finite time
  and every arbitrary sequence of room probe sets.
- `fiber_rooms_injective` proves that each fixed-color column embedding is
  injective.

These are statements about actual explicitly defined room edges, not a
declaration that the graph is a lazy path. The column stay is realized by a
vertical edge, so staying in the same physical room is still prohibited.

## Remaining before a complete room-game Lean theorem

The ordinary mathematical proof supplies these steps, but this checkpoint
does not yet contain their formal assembly:

1. Count a finite cohort and show that removing at most `p` probes leaves at
   least `b−p` positions.
2. Prove the closed-neighborhood cardinality bound for every nonempty proper
   subset of the finite path.
3. Prove suffix cardinalities and the exact attainment of `next`, including
   endpoints and empty suffixes.
4. Transfer the total room-probe budget to the sum of the two disjoint cohort
   allocations and transfer the constructed column allocations back.
5. Combine these with the checked set projection, counter optimality, and
   the general actual-trajectory semantics in `BeliefSemantics.lean`.

Until those steps are checked, it would be inaccurate to describe the full
ladder room-game classification as Lean-verified.

## Trust and verification

The files contain no unproved declarations, admitted goals, added axioms,
`native_decide`, or unsafe proofs. The build script rejects those shortcuts
and checks that the printed dependencies are confined to `propext`,
`Classical.choice`, and `Quot.sound`; several geometry lemmas use fewer or
no axioms. All arithmetic proof terms are checked by Lean's kernel.

The numerical BFS evidence is useful independent validation, but it is not
an assumption of any Lean theorem. The formal proof also makes no claim
that the mathematical result is new to the literature or absent from
Angel's earlier two-row notes.

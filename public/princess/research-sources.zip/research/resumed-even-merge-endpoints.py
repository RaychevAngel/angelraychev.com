"""Independent endpoint and constructive-survivor audit for the merger proof."""
import sys,json,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from resumed_even_construction_formula_profile import allowed

def valid(h,a,c):return 0<=c<=2 and c<=a<=h-2+c

def audit(r,h,k):
 states=[(a,c)for a in range(h+1)for c in range(3)if valid(h,a,c)]
 opts={}
 for a,c in states:
  edges=[]
  for p in range(min(k,a)+1):
   q=a-p
   for i in range(max(0,c-p),c+1):
    if not valid(h,q,i):continue
    for t,j in states:
     if t>=q and allowed(h,r,q,i,t,j):edges.append((p,q,i,t,j))
  opts[a,c]=edges
 pairs=clips=0
 for a,c in states:
  for b,d in states:
   m=a+b-h
   if m<=k:continue
   cm=max(0,c+d-2)
   assert valid(h,m,cm)
   for p,q,i,t,j in opts[a,c]:
    for pp,qq,ii,tt,jj in opts[b,d]:
     if p+pp>k:continue
     Q=q+qq-h;I=min(Q,max(0,i+ii-2));T=t+tt-h;J=max(0,j+jj-2)
     assert Q>0 and valid(h,Q,I) and valid(h,T,J)
     assert max(0,cm-p-pp)<=I<=cm
     assert allowed(h,r,Q,I,T,J),(r,h,k,(a,c),(b,d),(p,q,i,t,j),(pp,qq,ii,tt,jj),(Q,I,T,J))
     pairs+=1;clips+=Q<max(0,i+ii-2)
 return dict(r=r,h=h,k=k,constructed_edge_pairs=pairs,survivor_clippings=clips)

if __name__=='__main__':
 start=time.process_time();rows=[]
 for h in range(2,6):
  for k in range(1,h):rows.append(audit(1,h,k))
 for k in (1,2,3,7):rows.append(audit(2,8,k))
 # First clipped example within the refined subcritical branch.
 assert allowed(32,4,2,2,4,0) and allowed(32,4,31,2,32,2)
 assert allowed(32,4,1,1,4,0)
 result=dict(status='PASS',scope='Finite endpoint audit of the explicit merger-survivor construction; ordinary proof remains separate.',rows=rows,refined_clipping=dict(r=4,h=32,k=5,source=[[7,2],[31,2]],survivor=[[2,2],[31,2]],target=[[4,0],[32,2]],merged_source=[6,2],chosen_merged_survivor=[1,1],merged_target=[4,0]),CPU_seconds=time.process_time()-start)
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2));print('cases',len(rows),'edges',sum(r['constructed_edge_pairs']for r in rows),'clips',sum(r['survivor_clippings']for r in rows))

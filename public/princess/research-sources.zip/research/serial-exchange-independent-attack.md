# Independent attack on serial allocation for odd rectangles

12 September 2026 UTC. The exact odd-rectangle two-count recurrence is
proved in `odd-rectangle-isoperimetry.md`. The simplification investigated
here is still a conjecture: spend the full budget on one initial parity
cohort until it can be finished, use any remaining probes on that finishing
day on the other cohort, and then spend the full budget on the other.
Optimize which initial cohort goes first.

## 1. A stronger finite property

Prescribe which initial parity cohort must be eliminated first. Compare
serial play beginning with that cohort against the exact two-count state
graph in which elimination of the other cohort first is disallowed.
All 848 tested cases agree: odd widths 3,5,7,9; for each width, four odd
lengths starting at the square; all feasible budgets below the minority
class size; both prescribed first colors. The check took 1.45 seconds.

The implementation is independent of root's serial tester and generates
profiles from the proved square/pronic formulas. Source:
`src/odd_serial_first_order_attack.py`; receipt:
`research/odd-serial-first-order-attack.json`.

This stronger property would permit an exchange proof that preserves the
first eliminated cohort, but has not been proved for all parameters.

## 2. Unimodality does not by itself prove the exchange

The following are abstract count-game counterexamples, not asserted to be
neighborhood profiles with compatible orders of a particular physical
graph. In each case the two monotone profiles obey the complement-inverse
identity. They show why a proof formulated only in terms of the stated
algebraic profile hypotheses would be false.

For equal class sizes 9, take

    g0=[0,2,5,5,5,6,7,8,9,9],
    g1=[0,2,3,4,5,8,8,8,9,9].

Both proper-set surpluses g_p(k)-k are positive and unimodal. At budget 7,
the exact two-count optimum is three days, whereas either serial order
takes four. Receipt: `unimodal-profile-serial-attack.json`. This was found
in a bounded random attack with seed 5817.

Even symmetric unimodal minority surplus, increments of that surplus in
{0,1}, and a minority singleton neighborhood of three do not suffice.
Take class sizes E=13, M=12 and

    g0=[0,2,3,7,7,8,8,9,9,10,11,12,12,12],
    g1=[0,3,4,5,7,9,11,11,11,11,12,13,13].

The minority surplus is symmetric around M/2, apart from the special
empty-set definition. Budget 10 gives optimum three and serial four.
Receipt: `symmetric-profile-serial-degree-three-attack.json`, seed84027.
The majority profile's jump from3 to7 is unavailable in genuine odd grids.

Adding the requirement that both profiles have increments at most two
removed all counterexamples in a bounded search of 5,200 abstract profile
pairs and63,300 budgets (four seconds). This is evidence only. The
minority-surplus increase steps were separated, with first increase at
one and a symmetric reflection across M/2. Receipt:
`smooth-symmetric-profile-serial-attack.json`, seed84027.

## 3. A possible intermediate lower bound

Let tau_p be the greedy full-budget time for one full initial parity p,
which is individually optimal by monotonicity of the neighborhood profile.
For all genuine odd-rectangle cases checked with widths through13 and
five odd lengths each, serial time belongs to

    {tau_0+tau_1-1, tau_0+tau_1}.

A useful lower-bound target is therefore T>=tau_0+tau_1-1, followed by an
exact criterion for saving the single day. This has not been proved here.
The abstract counterexamples above also save only one day relative to the
sum of the two solo times, so this lower bound may be more general than
serial optimality.

For backward horizon reasoning define kappa_p(t) as the largest prefix
of current parity p clearable within t days at budget m. With
inv_p(z)=max{k:g_p(k)<=z}, its exact recurrence is

    kappa_p(0)=0,
    kappa_p(t+1)=min(|V_p|,m+inv_p(kappa_(1-p)(t))).

The dual profiles give

    inv_0(z)=E-g_1(M-z),
    inv_1(z)=M-g_0(E-z).

Thus lambda_p(t)=|V_p|-kappa_p(t) obeys

    lambda_p(t+1)=max(0,g_(1-p)(lambda_(1-p)(t))-m).

This is a reversed-order movement/inspection recurrence for the complement
of the winning-size threshold. It may connect forward progress and
backward remaining-time barriers without assuming serial play.

# Exact open-neighborhood profile of every even-area rectangle

12 September 2026. Complete ordinary proof, independently reviewed by Euler; see
`uniform-even-profile-independent-review.md`. This is not a dynamic nesting theorem, and no Lean claim
is made. Coordinates and all end cases are explicit to support review.

The initial proof below uses an even shorter side. Section 7 gives the
complete extension to every even-area rectangle, independently checked
by root and Euler. The unified formula is the same, with b equal to half
the shorter side rounded down.

Let G=P_(2b) □ P_n, b≥1, n≥2b, with coordinates (x,y),
0≤x<2b, 0≤y<n. Each checkerboard color has h=bn vertices. Reflection
x↦2b−1−x interchanges the colors, so their minimum open-neighborhood
profiles agree; denote the common profile by g(k).

Put R(k)=ceil(sqrt(k)) and

    rho(d)=min{s≥0 : d≤s(s+1)}.

**Theorem.** For every 0≤k≤h,

    g(k)=k+min(R(k), b, rho(h−k)).                         (1)

The endpoints give g(0)=0 and g(h)=h. In particular, for any set S of
one color with surplus s=|N(S)|−|S|<b,

    |S|≤s²   or   h−|S|≤s(s+1).                          (2)

The proof is elementary matching, directed reachability, and row counting.
It does not require the conjectural rectangular pyramid compression.

## 1. The directed matching model

Match physical rows x=2i and x=2i+1, i=0,...,b−1, at every y. A
physical parity-p vertex is identified with (i,y), taking

    x=2i+((p−y) mod 2).

Use the analogous identification of the opposite parity. Under these
identifications its neighborhood is the outgoing closed neighborhood in
a directed graph D_p on {0,...,b−1}×{0,...,n−1}:

* there is a loop at every vertex (the matched physical edge);
* all horizontal edges (i,y)↔(i,y+1) are bidirectional;
* at a column y with (p−y) mod 2 equal to 1, the vertical rung points
  i→i+1; at the other columns it points i→i−1.

The rung direction is uniform in each column and alternates between
successive columns. The two graphs D_0,D_1 are transposes. If R is the
coordinate image of S and B=N^+_(D_p)(R)\R, then

    |R|=|S|,  |B|=s,  R∩B=∅,

and R is outgoing-closed in D_p−B. The loops immediately show s≥0.

## 2. A common strongly connected core

Assume s<b. Mark a column when it contains a vertex of B. At most s
columns are marked. Since n≥2b≥2s+2, there are two consecutive unmarked
columns: if there were none, unmarked columns would number at most
marked columns plus one, giving n≤2s+1.

These two whole columns form a strongly connected directed ladder.
One column has all rungs upward and the other all rungs downward;
horizontal edges permit changing between them at any row. Every row
containing no vertex of B is a full bidirectional path in D_p−B and
meets that ladder. Thus all B-free rows lie in one strongly connected
component C. There is at least one such row because s<b.

An outgoing-closed set R either contains C or is disjoint from C.
Consequently either every B-free row is full in R, or every B-free row
is empty in R. We require no estimate on the size of C.

## 3. Sharp area bound on the side avoiding the core

The following slightly more general lemma is useful for the complement.
Let U be disjoint from B, suppose N^+_D(U)\U⊆B, and suppose every
B-free row is empty in U. We prove

    |U|≤s².                                               (3)

Choose one B-free row r. It is empty in U. Consider first the rows above
r, indexed i<r. Let P be the column parity on which rungs point downward,
and define

    alpha_i=|U_i∩P|,  beta_i=|U_i\P|,
    t_i=|B_i∩P|,     w_i=|B_i|.

Outgoing closure along the downward rungs gives

    alpha_i≤alpha_(i+1)+t_(i+1).

Since alpha_r=t_r=0, telescoping yields

    alpha_i≤sum_(i<j<r) t_j.                              (4)

### The horizontal matching inequality

We claim

    beta_i≤alpha_i+t_i.                                   (5)

All horizontal neighbors of U_i lie in U_i∪B_i.
If n is even, the path P_n has a perfect matching between its two
column parities, so (5) follows by matching the beta_i selected vertices
into the other parity.

If n=2q+1 is odd, the minority column parity always matches into the
majority. Every proper subset of the majority also has at least its
own number of minority neighbors: for selected indices among
0,2,...,2q, split into consecutive blocks, or match each proper initial
and final block inward. The only exceptional subset is the entire
majority, whose q+1 vertices have q neighbors.

If the beta_i selected vertices were exactly that exceptional majority,
then all q minority positions would lie in U_i∩P or B_i∩P. Equations
(4) and outgoing closure would imply

    q≤alpha_i+t_i≤sum_(i≤j<r)t_j≤s.

But n odd and n≥2b imply q=(n−1)/2≥b>s, a contradiction. Thus (5)
holds in the odd case as well. This is precisely where the long-side
hypothesis prevents the path-end exception.

Combining (4) and (5), for every occupied row i<r,

    |U_i|≤t_i+2 sum_(i<j<r)t_j
          ≤w_i+2 sum_(i<j<r)w_j.                         (6)

Every occupied row has w_i≥1: a B-free row is empty by hypothesis.
Put W=sum_(i<r)w_i, and let a be the number of occupied rows above r.
Then a≤W. Summing the right side of (6) over occupied rows gives at
most W². Here is the exact weighted counting, avoiding any assumption
that the occupied rows are consecutive.

In the sum, a boundary vertex in row j receives coefficient

    2·#{occupied rows i<j}+1_[j occupied].

Reserve one boundary vertex in each occupied row. Their coefficients
are 1,3,...,2a−1 and sum to a². Every one of the remaining W−a boundary
vertices has coefficient at most 2a. Hence the total is at most

    a²+2a(W−a)=2aW−a²≤W².                                (7)

Below r, use the column parity whose rungs point upward and repeat the
same argument with the row order reversed. If W' is the boundary count
below r, the area there is at most (W')². The anchor row has neither U
nor B, so W+W'=s. Therefore

    |U|≤W²+(W')²≤s²,

proving (3). The argument also handles b=1 and s=0: the only anchor
row is empty and both sides have area zero.

## 4. Dichotomy and the lower profile

If R avoids C, apply (3) to U=R to obtain |R|≤s².

If R contains C, put T=V(D)\(R∪B). Then T avoids every B-free row.
Moreover it is outgoing-closed in D^T−B: an edge T→R in D^T would be
an edge R→T in D, contradicting the definition of B. Thus (3), with
the same barrier B and the transposed rung directions, gives

    |T|≤s².

Since h−|R|=|T|+s, this proves (2). It is important that B need not be
exactly the boundary of T; the lemma only assumes that it contains that
boundary. There is no circular use of the desired profile for T.

For an arbitrary k-set, either s≥b, or (2) gives s≥R(k) or
s≥rho(h−k). In every case

    s≥min(R(k),b,rho(h−k)),

which proves the lower bound in (1).

## 5. Attainment without asserting dynamic nesting

We give three upper bounds and take their minimum. Since reflection of
the even short axis swaps colors, it suffices to construct each one in
whichever color is convenient.

### The plateau upper bound g(k)≤k+b

A downward pyramid has row cutoffs

    a_x∈[-2,n−1], a_x≡p−x (mod 2), |a_(x+1)−a_x|=1.

The virtual cutoff −2 or −1 represents an empty parity fiber. Its
neighborhood is again a pyramid with cutoff a'_x≤a_x+1, including both
end collars. There are b rows of each cutoff parity. The rowwise change is
(a'_x−a_x+2s_x−1)/2; its parity correction sums to zero. Consequently

    |N(S)|−|S|=(sum_x a'_x−sum_x a_x)/2≤b.

Every cardinality k occurs as a pyramid: these are ideals of the finite
predecessor poset (x,y)→(x±1,y−1), and taking the first k vertices of
any linear extension gives an ideal. Thus g(k)≤k+b for every k.

### The small-corner upper bound

If R(k)=s<b, use the even-checkerboard quadrant prefix of size k,
ordered by increasing x+y and then along the last diagonal. Its complete
previous even diagonals contain (s−1)² vertices; the current even diagonal
is x+y=2s−2. The familiar direct diagonal count gives exactly k+s
neighbors. Its support and neighborhood lie within coordinates
0,...,2s−1, hence within this rectangle because 2s<2b≤n.
This proves g(k)≤k+R(k) whenever that term is below b. The empty case
is immediate. No assumption about the future play of these corner sets
is used.

### The co-small upper bound by an empty bipartite pair

Put d=h−k and s=rho(d)<b. Set x=d−s. This is nonnegative, and
x≤s² because d≤s(s+1). The preceding corner construction gives a set
X of x vertices in one color with |N(X)|≤x+s=d (for x=0 use the empty
set). Choose any k vertices S of the opposite color outside N(X);
there are at least h−d=k available. Then N(S) is disjoint from X, so

    |N(S)|≤h−x=k+s.

The full case d=s=0 is included. Reflection transfers this construction
to either physical color. This proves the co-small upper bound whenever
it improves on b, completing (1).

## 6. Scope and next step

The theorem gives the exact scalar minimum neighborhood for every
rectangle with an even shorter side. It does NOT say that all minima
can be nested compatibly, that cardinality alone is an exact dynamic
state, or that the pyramid normal form conjectured in
`uniform-even-rectangle-states.md` holds. The known multi-day prefix
counterexamples remain relevant.

The immediate intended application is the uniform high-budget formula
proposed by root, with m≥b²+1. Its lower bound may use (1) on arbitrary
supports, while its upper construction must be checked as an actual
nested physical strategy. Those additional arguments are not claimed
in this note yet.


## 7. Extension to every even-area rectangle

Let the side lengths be w≤n with wn even, put

    b=floor(w/2), h=wn/2.

For either physical color and every 0≤k≤h, the exact profile is again

    g(k)=k+min(R(k),b,rho(h−k)).                            (9)

When w=1, this is g(k)=k on an even path, attained by a spacing-two
prefix from a favorable endpoint. Assume w≥2 below.

If w is even the earlier proof applies. Suppose w=2b+1 is odd, so n
is even. Match the even side n, producing a directed array with n/2
rows and w columns. The entire core-and-area proof of Sections 1–4
requires only the following inequalities for a boundary size s<b:

    number of rows > s,
    number of columns ≥ 2s+2,
    (number of columns−1)/2 > s when columns are odd.

Here n/2≥b+1>s, w=2b+1≥2s+3, and (w−1)/2=b>s. Thus all three
conditions hold. In particular there is a boundary-free anchor row;
two consecutive unmarked columns form the common core; and the exceptional
entire-majority subset of an odd horizontal path is still impossible.
The sharp dichotomy and hence the lower bound in (9) follow unchanged.

For the plateau upper bound, orient pyramids along the even long side
but now take transverse width w=2b+1. In the color of corner (0,0),
s_x=(-x mod 2), so

    sum_x(2s_x−1)=−1.

The exact rowwise neighborhood-cardinality identity from Section 5 gives

    |N(S)|−|S|
      = (sum_x(a'_x−a_x)+sum_x(2s_x−1))/2
      ≤ ((2b+1)−1)/2=b.

Every size k≤h occurs as an ideal in this color. Reflection of the EVEN
long side swaps the two colors, so the other physical color has the
same upper bound. The reflection changes downward pyramids into upward
pyramids; no fixed common orientation is asserted.

The small-corner construction still fits whenever R(k)<b. The co-small
empty-pair construction still applies because the color classes have
equal size and an even-axis reflection interchanges them. This completes
all upper bounds and proves (9).

The full theorem is therefore static and uniform over EVERY rectangle
of even area. It does not extend the dynamic high-budget theorem to an
odd shorter side: alternating frontier phases still need attention there.
The separate odd-area profile theorem has two different parity profiles.

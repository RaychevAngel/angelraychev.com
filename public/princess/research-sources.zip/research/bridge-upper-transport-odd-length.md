# A uniform 25-row upper bound with the shared final day

13 September 2026. Ordinary construction proof, with literal replay.

For every even `n>=26`,

    T_13(25,n) <= 50n-925.

This improves the previously used `50n-924` upper by sharing the last
inspection day. It is a physical upper construction; matching lower
claims require the separate history-model argument.

Use transverse coordinate `0<=x<25` and longitudinal coordinate
`0<=y<n`. Order each color by `(x+y,-x)`, ascending. This is precisely
the order `(x+y,x)` in the manuscript's convention where its x-coordinate
is longitudinal. On every day inspect the final13 rooms of the current
prefix, or all remaining rooms when there are fewer than13. Start in
physical color0. The nested-neighborhood calculation in
`paper/sections/resumed-odd-even-minimum-upper.tex` gives, for `h=25n/2`,

    g0(s)=s+min(R(s),12,rho(h-s)),
    g1(s)=s+min(Q(s),13,R(h-s)),

where `R(s)=ceil(sqrt(s))`, `rho(s)` is the least nonnegative integer u
with `s<=u(u+1)`, and `Q(s)` is the least positive integer u with
`s<=u(u-1)`. Both profiles vanish at0. Thus the exact physical recurrence
is `a_(t+1)=g_(t mod2)(max(0,a_t-13))`, with `a_0=h`.

## Fixed entrance

The first46 steps reach color0 size `h-132`, for every `h>=325` in
this family. At `h=325`, the successive defects `h-a_t`, including both
endpoints, are

    0,9,17,25,31,37,42,48,53,58,62,66,70,74,77,81,
    84,87,90,93,95,98,100,102,104,106,108,110,111,113,
    114,116,117,119,120,121,122,123,124,125,126,127,
    128,129,130,131,132.

Every survivor during these46 steps has size at least181. Consequently
its small-corner term R or Q exceeds the respective cap12 or13. If h is
increased and the belief size is increased by the same amount, the
far-corner term `rho(h-s)` or `R(h-s)` is unchanged and the small-corner
term remains above the cap. Induction proves exactly the same defect
sequence for all larger h. This is a uniform argument, not a sampled
length extrapolation.

## The repeatable middle segment

For a color0 belief of size q with

    158 <= q <= h-132,

the next two beliefs have sizes `q-1,q-1`. Indeed, after the first
inspection the survivor has size `q-13>=145`, so its R-term is at least12;
its far-corner argument is `h-q+13>=145`, so its rho-term is also at
least12. Therefore the first surplus is exactly12.

The second survivor has size `q-14>=144`, so its Q-term is at least13;
the far-corner argument is `h-q+14>=146`, whose R-term is at least13.
Therefore the second surplus is exactly13. Both actions use13
inspections, and the pair returns to color0 while reducing the size by1.

There are exactly `h-289` such pairs from `h-132` down to157. Increasing
n by2 increases h by25 and inserts exactly25 additional pairs, or50
solo days. The entrance phase and the finishing phase are unchanged.

## Fixed finishing sequence and the shared day

Once the color0 belief is157, every later survivor has size at most144.
Since `h>=325`, its far-corner argument is at least181. Hence both
far-corner terms exceed the corresponding caps throughout the tail.
The entire tail is independent of length. Its exact sizes are

    157,156,156,155,155,154,154,153,153,152,152,151,151,
    150,150,149,149,148,148,147,147,146,146,145,144,143,
    142,141,140,139,138,137,136,135,134,132,131,129,128,
    126,125,123,121,119,117,115,113,110,108,105,103,100,
    97,94,91,87,84,80,76,71,67,62,57,51,45,38,31,23,
    14,2,0.

There are70 tail days, and the final shot is `{(0,1),(1,0)}`. Thus

    solo days = 46 + 2(h-289) + 70 = 2h-462 = 25n-462.

Let sigma be longitudinal reflection `(x,y)->(x,n-1-y)`, which switches
colors because n is even. For solo shots `S_1,...,S_L`, use

    S_1,...,S_(L-1), S_L union sigma(S_L),
    sigma(S_(L-1)),...,sigma(S_1).

The shared shot contains four rooms, within quota13. This captures the
full board: an avoiding walk from the other initial color, restricted
to the last L days, reversed and reflected, would be an avoiding
color0 walk for the solo sequence. The parity check uses the even
number `2L-2` of moves from the first day to the last. The full length
is `2L-1=50n-925`.

## Verification and scope

`src/bridge_upper_transport_odd_length.py` independently constructs the
physical prefixes and neighborhoods, checks every inspection, and replays
the full board for lengths26,28,30,40,64. It also checks the entrance,
middle insertion and fixed-tail identities for all88 even lengths26
through200. The receipt `bridge-upper-transport-odd-length.json` records
the finite arithmetic, source hashes, and checks. These finite audits
support the uniform proof above; they do not replace it. Runtime was
1.584 CPU seconds.

# Independent review of the box reconciliation

13 September 2026. Bounded review requested after the research wrap.
No mathematical search, new width catalogue, or publication build was
performed. The only computation was a current-code equivalence replay
of the finite inputs required by the already accepted width25 theorem.

## Assessment

`BOX_RECONCILIATION.md` accurately separates new numerical coverage,
new matching-bound/direct-strategy regions, uniform proof tools, finite
evidence, and unchanged formalization obligations. I found no substantive
double-counting of the all-odd minimum-budget theorem, the earlier
high-budget families, the exact joint evaluator, or the finite boundary
representation. Its conclusion that the full fixed-expression objective
remains incomplete is supported by the accepted proof boundaries.

One domain wording correction is required if the scalar-region sentence
is read as a standalone theorem. It currently displays

    r+1<=k<=2r, or 27k³<=r⁴.

The second alternative must also retain feasibility. Recommended wording:

    for every feasible k>=r+1 satisfying k<=2r or 27k³<=r⁴.

This matches the actual hypotheses in
`bridge-odd-clock-superlinear-budget.md`, whose standing condition is
b+1<=m. The surrounding residual-family context suggests the intended
restriction, but need not be relied on to supply it implicitly.
This finding was sent to the parent for the parent-owned reconciliation.

One useful construction advance is underrepresented: the accepted
minimum-budget corner-changing upper works uniformly on even widths
2r, r>=5, with solo increment2r under n->n+2 and full increment4r.
Its width constant still needs iteration, so this is construction
progress rather than exact O(1) coverage. The reconciliation currently
gives only its width24 specialization. The upper lane also records
upper24n-368 at odd n>=25, complementing the stated all-length lower
24n-370. Adding a short sentence would make that progress visible.

For precision, the nontrivial linear one-day bracket theorems apply
below the half-board endpoint k<wn/2. Endpoint budgets have the
previously exact one-/two-day clauses. The coverage document already
states this explicitly, so this is a clarification rather than a
counterexample to the reconciliation's compressed wording.

## Baseline and coverage checks

The three archived assessment files are byte-for-byte identical to
their counterparts at commit d38c1b0:

* `CURRENT_CHECKPOINT.md`;
* `research/RECTANGLE_COVERAGE.md`;
* `research/RECTANGLE_GAPS.md`.

The archived scope explicitly contains the four residual families used
by the reconciliation. In particular the minimum odd-width expression
2wn-(8r²-4r-4L_r+4), its direct attaining strategy, and the O(r)-stage
width clock were already present. The new text correctly declines to
count that theorem again as closure of the fixed-size numerical gap.

The current accepted notes support the domains and counts used in the
reconciliation: the even-width quadratic boundary is new numerical
coverage; the uniform width25 law is exact at every even length; the
linear even-area estimates are one-day brackets; the fixed168-block and
fixed49-block results are numerical evaluators only on their specified
inequalities. The all-odd low-linear theorem uses the complete19852-case
certificate, and the superlinear region has the separate ordinary proof.
The old odd-board scalar/evaluation obligations remain distinguished.

The geometry paragraph also preserves the correct boundary. Whole
interval resets, their stated critical extensions, the lens, and the
clipped radius Bellman potential are accepted ordinary tools. Neither
the b11/b23 finite diagnostics nor the CHARGE tests prove a variable-
width terminal formula. CHARGE and the required entrance/critical
arguments remain open. The new fixed number of radius coordinates does
not make the iterative H clock an absolute O(1) expression.

There are no tracked changes under `lean/` relative to d38c1b0. The
reconciliation correctly claims no new complete physical-game Lean
classification. I did not perform a Lean or manuscript build during
this review, nor independently reprove the other lanes' accepted
theorems; this audit checks their scope against their proof/review notes.

Main comparison sources: the three archived baseline files;
`bridge-family-independent-review.md`;
`bridge-upper-transport-wrap.md`;
`bridge-upper-transport-high-credit.md`;
`bridge-boundary-numeric-budget.md`;
`bridge-odd-clock-quadratic.md`;
`bridge-odd-clock-linear-budget-all.md`;
`bridge-odd-clock-superlinear-budget.md`;
and the accepted width25/radius notes previously reviewed in this lane.

## Current-code width25 provenance refresh

The old finite terminal receipt had one stale source digest:
`src/bridge_lower_frontier_diagnostic.py`. Its later optional diagnostic
changes had not changed the exact-square flag function used by the
independent verifier. The verifier itself and the flagged base source
still matched their recorded hashes.

Replayed the three necessary exclusions from (157,c0,e), e=0,1,2,
using `bridge_upper_transport_verify_reach.verify`, radius_length26,
the original exact subcritical square triggers, and no dominance
between different radius pairs. All three again require71 days.
For each one, the replay is exactly equal to the historical result in:

* every first-arrival frontier layer;
* capture clock and preterminal minimum;
* augmented-state and radius-pair counts;
* processed-source, raw-edge, and feature-filtered-edge counts;
* the underlying model-source identifier.

The three corresponding rows in
`bridge-upper-transport-terminal-feature-verified.json` now contain the
current source hashes. The other nine historical rows were retained
unchanged; they are not needed as fresh exclusions for the uniform lower.
A separate receipt preserves the previous and current hashes plus all
equivalence checks:
`bridge-reconciliation-25-current-replay.json`.

Also rebuilt the small weighted base with the current fast builder and
compared it against the independent cached reference. All40866 weighted
source/cost rows,2919 states, and4280018 unweighted edges agree exactly.
The reference cache was not overwritten. The new receipt includes its
file digest and current builder/dependency digests. The historical field
`model_sha256` identifies model source, rather than the serialized graph;
the newly recorded reference-cache digest makes that distinction explicit.

Finally reran `src/bridge_boundary_numeric_25_exact.py`. It passes and
its receipt now refers to the refreshed terminal certificate. Its source
hash, the terminal-receipt hash, and all three exclusion source hashes
were checked against the current files. The theorem remains

    T_13(25,n)=50n-925 for every even n>=26.

CPU cost:0.700840 seconds for the three terminal replays,
0.142570 for current-builder equivalence, and0.007228 for the numerical
transfer replay, totaling0.850638 seconds. This is verification of the
existing theorem, not an additional mathematical coverage gain.

# Independent review: exact time on every odd 3×3×n cylinder

12 September 2026 UTC. **Verdict: passed.**

The ordinary theorem in `three-by-three-cylinder-time.md` proves

    T5(P3 × P3 × Pn)=18n-36 for every odd n>=3.

Five is the minimum feasible budget. The variable-length theorem uses the
proved all-odd-box isoperimetric nesting, exact rational finite certificates,
and an all-length insertion argument. It is not claimed as a complete
physical Lean theorem; the separate n=3 result already has that status.

## Stable geometric profiles

I independently checked the bottom rank lists and their costs. The last
even bottom point (2,2,0) is first in its weight-four layer. Its seven
predecessors all have weight zero or two and long coordinate at most two.
The last odd bottom point (1,2,0) is preceded by the three unit points and
(2,1,0),(2,0,1). Hence all bottom ranks stabilize already at n=3, including
the equal-axis cube. The order permits the longitudinal axis last among
equal lengths.

The bottom/interior/top cost identity and parity-preserving complement
give exactly the two displayed profiles, with the empty argument explicitly
zero. Their finite tables saturate by rank eight. Thus both low invariance
and high translation hold at every relevant length; this is stronger than
merely recognizing the plateau. The majority prefix of size three has
surplus four even at the smallest H=14, establishing feasibility threshold
five by the previously proved criterion.

## Lower certificate and unrestricted strategies

The scaled integer charges are (0,0,1,2,3,3), with scale three. For any
quota pair whose sum is at most five, their total charge is at most three.
Each one-cohort inequality therefore yields the daily lower bound. The
previously proved exact prefix normal form lets these inequalities bound
arbitrary original search strategies; the proof does not silently assume
that a minimum-neighborhood cardinality describes every physical support.

For n=3,5,7,9,11 the finite certificates give exact initial sums matching
the physically replayed upper schedules. In particular the n=11 certificate
has H=50, cut25, and Fp(k)=2k-14+p on every integer13<=k<=37.

## Insertion for all larger lengths

With displacement D=6 and radius eight, both margins hold:
25>=8+12 and 50-25>=8+12+2. The previously reviewed three-case insertion
proof applies literally with these stable corner profiles. Low sources
have unchanged profiles and potentials; high sources translate both by
Delta and 2Delta; middle sources and successors lie in the full affine
collar, where their potential difference is independent of the count.
All exact quota inequalities therefore survive every insertion, not just
the sampled displacements. The full initial potential sum rises by4Delta.

For the physical upper strategy, count25 exceeds the budget. At the first
cohort's cut visit the second has received no probes and is exactly full;
at the second cohort's cut visit the first is already empty. The last-day
sharing of leftover inspections is harmless and is included in the
definition of the serial strategy. The independently checked cut visits
therefore supply the actual full/empty companion condition required for
inserting two even blocks.

Each plateau pair decreases the active count by one. Inserting2Delta days
at each visit changes c+Delta to c and restores phase. The original final
sharing allocation is unchanged, and the second initial state translates
as required. The upper time rises by the same4Delta. For physical odd
n>=11, Delta=9(n-11)/2 is an integer, giving162+4Delta=18n-36.
The finite cases cover all remaining odd lengths.

## Independent computational attack

`src/three_by_three_cylinder_independent_review.py` reconstructs actual
coordinate neighborhoods and uses an independent integer Bellman relaxation,
rather than the submitted Dijkstra routine, to obtain the five base
potentials. It then checks the inequalities directly. It independently
replays actual room inspections, verifies the entire base collar and both
clean cut visits, and checks inserted potentials against actual boards at
n=13 and31. All4,350 inequalities and all seven physical replays passed.
The receipt is `three-by-three-cylinder-independent-review.json`.

No gap or mathematical correction was required. The finite checks support
the audit; the reviewed insertion proof is what establishes every length.

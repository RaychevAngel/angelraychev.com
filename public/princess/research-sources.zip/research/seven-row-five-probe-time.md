# Seven rooms across, five inspections per day

12 September 2026. **Ordinary proof candidate, awaiting independent review.**

For every odd n>=7, the proposed exact formula is

    T5(P7 × Pn) = 2 ceil((7n−16)/3).

The finite exact two-count solver first suggested the formula through n=55.
The argument below establishes it for all lengths, provided the listed finite
rational certificates are accepted. It uses the previously proved odd-box
isoperimetric nesting theorem. No new Lean or manuscript claim is made.

## Exact profiles and a rational potential

Write H=(7n+1)/2. The two current physical colors have capacities H,H−1.
Use the existing exact odd-rectangle profiles:

    g0(0)=g1(0)=0,
    g0(k)=k+min(ceil(sqrt(k)),3,ceil(sqrt(H−k))−1),
    g1(k)=k+min(q(k),4,q(H−1−k)),

where q(k) is the least positive integer q with q(q−1)>=k. The zero
argument is separately zero, as written. Neighborhoods of the corresponding
prefixes are prefixes; these profiles are actual isoperimetric minima.

Take daily charges

    c0=(0,0,1/2,3/4,1,1),
    c1=(0,0,1/4,1/2,1,1).

Their sum is at most one for allocations p+q<=5. For each finite base,
define f_p(k) as the least total charge to reach zero in the one-cohort
profile graph (exact rational shortest paths, not numerical optimization).
The attached complete tables explicitly satisfy f_p(0)=0, monotonicity, and

    f_p(k) <= c_p(r)+f_(1−p)(g_p(max(k−r,0)))

for every state and r=0,...,5. Summing across both colors gives a daily
potential decrease at most one, valid for arbitrary physical strategies.

The checked bases are n=7,9,11,13,15,17,19,21,23. Their initial potential
sums are respectively22,31.5,41,50,59.5,69,78,87.5,97. Serial upper times
are22,32,42,50,60,70,78,88,98. Thus rounding already proves the lower
except n congruent5 modulo6.

## The missing day in one residue class

For n=11,17,23, the potential total is exactly one below the asserted time.
If capture occurred in that smaller integer number of days, every day would
have to lose exactly one unit. The only tight first allocation is three
inspections in the current even color and two in the current odd color.
Its minimum possible next counts are (H−1,H−2). At this state the maximum
potential losses for the six full allocations r=0,...,5 are exactly

    (3/4, −1/4, 1/2, 0, 0, 1/4).

The second day is therefore not tight, contradiction. Larger actual
neighborhoods do not evade the argument: on a tight first day their total
potential equals the displayed minimum state's potential, and monotonicity
makes their next potential at least its next potential. Unused quota can
be filled without harming capture, so checking full allocations suffices.
The upper-tail translation below preserves this entire two-day calculation.

## Uniform extension of the lower bound

Choose bases (n0,H0,c)=(19,67,33),(21,74,36),(23,81,39). The complete
base tables satisfy

    f_p(k+3)=f_p(k)+2 for c−10<=k<=c+10,

and the profiles are g_p(k)=k+3+p throughout c−15<=k<=c+15.
For n=n0+6j, put delta=21j. Keep each potential below c, repeat its
three-residue pattern over the inserted interval of length delta, and
translate its upper part by delta in count and2delta/3 in value. The
explicit formula used by the verifier appears in the code below.

There are three exhaustive source ranges. If k<=c−5, the source and all
outputs lie in the unchanged lower part: the profile's upper corner is
far away. If k>=c+delta+5, subtract delta from source and output; the
profile's lower corner is saturated, so all profiles and potentials
translate exactly. In the remaining source range c−4<=k<=c+delta+4,
residuals are at least c−9 and outputs are at most c+delta+8. Source
and output lie in the extended periodic collar and the profile is k+3+p.
Reduce the source
modulo three to a base source in {c,c+1,c+2}; the output reduces by the
same multiple of three, and both potentials change by the same multiple
of two. This is one of the verified base inequalities. The ten-place
collar on either side exceeds the maximum one-day displacement five.

This proves every one-cohort inequality at all longer lengths. Initial
potential sums increase by4delta/3=28j. The exceptional residue's first
and second transitions are all in the upper part, so their exact loss
tables also translate unchanged. The predicted time increases by28j too.
Together with the six smaller bases, this proves the all-length lower.

## An attaining prefix strategy

Use the actual nested prefixes. Allocate all five inspections to one
cohort until it is captured, assigning any spare inspections on its last
day to the other cohort; then finish the second cohort. The successful
first colors for bases19,21,23 are respectively1,0,0. Their two middle
cut visits (count, current physical color) are respectively

    n19: (34,1), (34,1);
    n21: (37,1), (38,1);
    n23: (41,1), (41,1).

All cuts exceed five. Thus the other cohort is globally full during the
first cut and empty during the second. In the common middle plateau,
two successive full-budget days reduce the active count by three and
restore its color, from either starting color. Insert2delta/3 days at
each cut to change its translated count k+delta back to k.

Before the cut, the profile and counts translate by delta; after it,
low counts and profiles are unchanged. Each active count decreases under
five inspections, so the old high and low segments stay on their required
sides. The inserted block remains in the middle plateau. Its duration is
even, preserving the other cohort's color and the original last-day spare
allocation. Both cohort cuts therefore extend simultaneously, raising the
total time by4delta/3=28j. The finite bases supply the displayed formula.
This is an actual prefix strategy by the proved nesting theorem, not just
an unconstrained count trajectory.

## Certificate and scope

`seven-row-five-probe-certificate.json` contains all base potentials,
one-day checks, exceptional two-day losses, and clean cut visits. The
following reproduction uses only exact fractions and existing exact
profile definitions. The run used approximately0.015 CPU seconds on one
worker. Extra insertions delta=3,21,60 were checked to attack the gluing
formula; the three-case proof, rather than these samples, handles all j.

The ordinary proof is pending a fresh independent audit. No broad
low-budget odd-rectangle classification is asserted.

```python
import sys,json,time
from fractions import Fraction as F
from pathlib import Path
sys.path.insert(0,'src')
from odd_serial_first_order_attack import profiles,serial
from odd_minimum_budget_pumping import ranks
C=[[F(0),F(0),F(1,2),F(3,4),F(1),F(1)],[F(0),F(0),F(1,4),F(1,2),F(1),F(1)]]
assert all(C[0][p]+C[1][q]<=1 for p in range(6)for q in range(6)if p+q<=5)
def verify(g,f):
 count=0
 for p in(0,1):
  assert f[p][0]==0 and all(x<=y for x,y in zip(f[p],f[p][1:]))
  for k in range(len(g[p])):
   for r in range(6):
    assert f[p][k]<=C[p][r]+f[1-p][g[p][max(k-r,0)]]
    count+=1
 return count
def path(g,first,c):
 a,b=len(g[first])-1,len(g[1-first])-1;p=first;t=0;cuts=[None,None]
 while a or b:
  active=0 if a else 1;k=a if a else b
  if cuts[active] is None and c-2<=k<=c+2:
   assert k>5 and (b==len(g[1-p])-1 if active==0 else a==0)
   cuts[active]=(k,p if active==0 else 1-p,t)
  q=min(a,5);r=min(b,5-q)
  a,b=g[p][a-q],g[1-p][b-r];p^=1;t+=1
 assert all(cuts)
 return t,cuts
start=time.process_time();rows=[]
for n in range(7,24,2):
 g=profiles((n-1)//2,3);f=ranks(g,C);H=len(g[0])-1;v=sum(row[-1]for row in f);upper=min(serial(g,5,p)for p in(0,1));expected=2*((7*n-16+2)//3)
 assert upper==expected
 one=verify(g,f)
 losses=[]
 for p in range(6):
  a,b=g[1][H-1-(5-p)],g[0][H-p]
  loss=v-f[0][a]-f[1][b]
  if loss==1:
   second=[f[0][a]+f[1][b]-f[0][g[1][max(b-5+q,0)]]-f[1][g[0][max(a-q,0)]]for q in range(6)]
   losses.append((p,(a,b),list(map(str,second))))
 if n%6==5:
  assert v==upper-1 and len(losses)==1 and losses[0][0]==3 and max(map(F,losses[0][2]))<1
 else:assert (v.numerator+v.denominator-1)//v.denominator==upper
 row={'n':n,'H':H,'potential_total':str(v),'time':upper,'one_step_checks':one,'tight_initial_branches':losses}
 if n>=19:
  c=3*(H//6)
  for p in(0,1):
   assert all(f[p][k+3]==f[p][k]+2 for k in range(c-10,c+11))
   assert all(g[p][k]==k+3+p for k in range(c-15,c+16))
  first=min((0,1),key=lambda p:serial(g,5,p));t,cuts=path(g,first,c);assert t==upper
  row.update(cut=c,collar=[c-10,c+13],first=first,physical_prefix_cuts=cuts,base_potentials=[[str(x)for x in pp]for pp in f])
  checks=[]
  from math import isqrt
  rt=lambda k:isqrt(k)+(isqrt(k)**2<k)
  def qt(k):
   q=isqrt(k)+1
   while q*(q-1)<k:q+=1
   return q
  for delta in(3,21,60):
   HH=H+delta
   gg=[[0]+[k+min(rt(k),3,rt(HH-k)-1)for k in range(1,HH+1)],[0]+[k+min(qt(k),4,qt(HH-1-k))for k in range(1,HH)]]
   ff=[[f[p][k] if k<=c else (f[p][c+(k-c-1)%3+1]+2*((k-c-1)//3) if k<=c+delta else f[p][k-delta]+F(2*delta,3))for k in range(len(gg[p]))]for p in(0,1)]
   checks.append(verify(gg,ff))
  row['redundant_insertion_checks']=checks
 rows.append(row)
out={'status':'Exact finite premises verified; unbounded proof awaiting independent review','formula':'T5(P7 x Pn)=2 ceil((7n-16)/3), all odd n>=7','charges':[[str(x)for x in row]for row in C],'rows':rows,'cpu_seconds':time.process_time()-start}
Path('research/seven-row-five-probe-certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({**out,'rows':[{k:v for k,v in r.items()if k!='base_potentials'}for r in rows]},indent=2))
```

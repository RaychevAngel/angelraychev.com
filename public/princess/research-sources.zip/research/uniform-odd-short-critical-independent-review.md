# Independent audit: sharp critical fronts for odd-short even-long rectangles

12 September 2026. Audit of `uniform-odd-short-critical-frontiers.md`.
**Verdict: PASS as an ordinary theorem about arbitrary physical supports.**
This is not an exact optimal-time classification or a dynamic normal form.

For a (2b+1)×2L rectangle, the strict range is exactly

    b²<|R|<h−b(b+1),   h=(2b+1)L.

At surplus b, the boundary lies once on every odd transverse fiber V and
nowhere on the b+1 even fibers U. The support is a phase-forced prefix or
suffix front. Every U fiber is nonempty and nonfull; V fibers may be empty.
Consecutive strict-middle survivor sets cannot both have surplus b.

## The new equality case in the common-core argument

I checked the paired-longitudinal-coordinate contraction against physical
adjacency. Its short-axis edges are bidirectional and its longitudinal
flows alternate with the transverse coordinate, reversing with phase.
An adjacent pair of unmarked short-axis columns gives a full strongly
connected ladder. Since L≥b+1, a boundary-free horizontal anchor exists.

At total boundary b, the former strict Hall argument cannot use b>b.
The replacement correctly handles that equality: if an anchored row
selects the entire majority short-axis parity, each of the b minority
columns has a selected or boundary vertex there. Following that column's
forward chain toward the empty boundary-free anchor forces a boundary
vertex in the same column. All b barrier points are therefore in the b
odd columns, leaving only isolated even columns unmarked. This contradicts
the hypothesized adjacent unmarked pair. The argument works below the
anchor and in the transpose as well, because the directed parity is
chosen toward that anchor each time.

With that sole exception excluded, the existing weighted-row argument
proves area at most b². Applying it to the transposed complement uses the
same barrier legitimately, yielding the other exception h−|R|≤b(b+1).
Thus a strict-middle set forces the unique alternating boundary pattern.

## Sharp full and empty cases

With no U boundary points, every U fiber is a directed prefix. Across
an edge, R_v⊆R_u and R_u\R_v is contained in the unique V barrier point.
Hence neighboring U lengths differ by at most one. An empty U fiber at
index 2j bounds the total support by j²+(b−j)²≤b², with no assumption that
V fibers are already prefixes. Applying the same cardinal argument to the
transposed complement shows that a full U fiber forces
h−|R|≤b²+b. The strict range excludes both cases.

It is essential that these conclusions concern U. For example, on 3×4,
the parity-zero set {(0,0),(2,0)} has surplus one and lies in the strict
range, yet its middle V fiber is empty. The final theorem explicitly
allows this case, and the empty-V boundary argument gives its barrier at
zero exactly.

A V fiber misses the far endpoint because it is contained in a nonfull U
prefix. Its increasing directed flow prevents selected vertices beyond its
sole barrier, so it must also be a prefix. The boundary is exactly its next
position, including the empty case. In the next belief the U fibers remain
unchanged and omit the far endpoint. A critical support in the opposite
phase is a suffix nonempty on each U fiber and therefore cannot fit.
No claim that every V fiber of the next belief is nonfull is needed.

## Conditional corner consequence

The further corner bound in §5 also passes. In phase zero, the extreme
physical row y=2L−1 has current-color vertices only on U fibers. Those
endpoints are omitted, even when a V fiber is full in paired coordinates.
Thus every next survivor lies in the minority color of the odd rectangle
(2b+1)×(2L−1). Phase one is the reflected statement, with a parity flip
when the new origin is shifted by one row.

For a positive next survivor size q≤b², the odd subrectangle's minority
capacity is at least 2b(b+1), so its far-distance is at least b²+2b. The
reflected Q term in its exact minority profile is therefore at least b+1.
Its neighborhood inside that subrectangle, and hence in the original
board, has at least q+min(Q(q),b+1) vertices. No additional restriction
on the intervening inspection positions is required.

## Independent finite supplement

`src/uniform_odd_short_critical_audit.py` reconstructs adjacency from physical
coordinates and exhausts 2,172,032 same-color subsets on 3×4, 3×6, 3×8,
5×6, and 5×8. Every critical strict-middle set has the asserted shape,
and all 2,136 pairs of opposite-phase critical candidates violate the
required containment. The run used 0.338 CPU seconds; receipt:
`uniform-odd-short-critical-independent-check.json`.

The finite checks supplement the all-parameter proof audit; the theorem's
scope is sharp static critical geometry and its conditional next-step
consequences. A complete historical rank and an exact time formula still
require further work.

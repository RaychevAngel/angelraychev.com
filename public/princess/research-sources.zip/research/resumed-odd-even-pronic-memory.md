# Uniform pronic rigidity and two exact finite rectangle values

13 September 2026. Ordinary geometry reviewed independently by the parent,
plus finite exact lower certificates and separately replayed physical upper
constructions. No new Lean claim.

## The uniform geometric result

Let w=2b+1>=5, let n>=w be even, and let S be any physical one-color
survivor with size b(b-1), surplus b, and no own-colored corner. Then S
is exactly the full odd triangle at one opposite-colored corner, on relative
diagonals1,3,...,2b-3. Its neighborhood has size b^2 and contains exactly
that one corner. Its second neighborhood contains neither original-colored
corner, even before any additional inspections.

The concise proof is `cor:odd-critical-pronic-rigidity` in
`paper/sections/resumed-odd-critical-extension.tex`. The critical corner
dichotomy excludes the large branch and forces equality in the odd-corner
capacity. Convex allocation puts every surplus unit into that quadrant.
Equality in the layer proof forces all initial odd diagonals to be full.
Compression preserves each diagonal's cardinality, so the original support
itself is the triangle. Its second neighborhood has radius at most2b-1,
whereas the other-color board corners are at distance at leastn-1>=2b+1.

Thus one uniform memory flag is sound: after a survivor with these size,
surplus and corner data, the next move cannot produce an original-colored
corner, regardless of the intervening inspection locations or budget.
The flag records a proved geometric fact, not a normal-form assumption.

## The 7x8 result

The physical upper construction in `resumed-odd-even-minimum-upper.md`
gives T_4(7,8)<=68. The first corner/history model gave only64.
The four-day complementary-hole obstruction in
`resumed-odd-even-four-day-obstruction.md` raised the direct full-game
joint lower to66 when encoded by three history states.

The new uniform pronic lemma supplies a second valid history event:
on this board, (belief size10,corner count0) -> (size9,corner count1)
under budget4 forces a six-room critical pronic survivor. On the following
move the corner count is therefore zero. Adding just this one history
state raises the full-game joint lower to68, proving

    T_4(7,8)=68.

This is a finite computational lower certificate based on ordinary uniform
geometry and the proved four-day obstruction. It is not an inference from
a physical solo lower or from a merger that preserves arbitrary shapes.
Every allocation and every target permitted by the necessary inequalities
is retained. Forward breadth-first search gives68. Independently, reverse
reachability constructs an integer joint potential which is zero at capture,
has value68 at full uncertainty, and drops by at most one along every
allowed joint transition. All18031772 such inequalities pass exactly.

Receipt: `resumed-odd-even-corner-history-7x8-two-memories.json`.
Source: `src/resumed_odd_even_corner_history.py`, run with
`--joint --audit --forbidden-prefix --terminal-obstruction --cases '3,8,4'`.
The equality event was also attacked directly over all376740 physical
six-room subsets, then every possible five-room continuation from its two
candidate nine-room beliefs. A stronger check confirms that even the FULL
second neighborhood contains no original-colored corner; inspections can
only reduce it. Receipt: `resumed-odd-even-terminal-obstruction.json`;
source: `src/resumed_odd_even_terminal_obstruction.py`.

## The 9x10 result

The same uniform upper gives T_5(9,10)<=96. Here the corner/history
necessary model, including the critical corner dichotomy, already proves96
without either special7x8 history event. Independent reverse-potential
verification checked all123798386 joint inequalities. Thus

    T_5(9,10)=96.

Receipt: `resumed-odd-even-corner-history-9x10-audited.json`.
The fact that an additive rational potential gives only ceil(284/3)=95
illustrates why the separately checked joint bound matters.

## Boundary at the first certificate checkpoint

The unbounded results are the critical corner dichotomy, the pronic rigidity
and the explicit minimum-budget upper construction. The two exact values
above are finite certified consequences. They do not prove the proposed
minimum-budget equality for every odd width and even length, nor resolve
arbitrary budget. The parent is examining whether the uniform pronic flag
is preserved by cohort merging, and whether the dual corner-contact
information can replace the special initial four-day flag. Those extensions
are not assumed in either certificate above.

## Subsequent consolidation: no board-specific history is needed

The erosion-corner refinement now gives the same two exact values using
only uniform geometric restrictions. In addition to the own-corner count
`c(A)`, record `e(A)`, the number of opposite-colored corners whose two
neighbors both belong to A. The dual-pronic equality rule below replaces
the 7x8-specific initial four-day pattern. The earlier certificates and
physical enumeration remain independent evidence; they are no longer
necessary ingredients of the new lower certificate.

**Dual-pronic rule.** Put h=wn/2 and C=b(b-1). If a survivor S has
size h-b^2, surplus b, and N(S) contains both of its colored corners, then

    c(S)=1, e(S)=2, e(N(S))=1.

Indeed U, the opposite-colored complement of N(S), has size C, no own
corner, and surplus at most b, since N(U) is contained in the complement
of S. The unconditional small-support profile forces its surplus to be
at least b (for b>=2), so it is exactly b and N(U) equals the complement
of S. Uniform pronic rigidity makes U a full odd corner triangle. Its
first neighborhood contains exactly one corner, giving c(S)=1. Its
second neighborhood contains neither original corner, which says every
neighbor of those two corners lies in S, giving e(S)=2. Finally, a corner
lies in E(N(S)) precisely when it does not lie in N(U); this gives
e(N(S))=1. The parent independently checked each implication.

The same corner-capacity proof with one forbidden origin neighbor yields
the refined erosion-corner inequality in
`resumed-erosion-corner-profile.md`. Adding every corner whose neighbors
already belong to N(S) leaves that neighborhood unchanged and reduces
the surplus; its bound applies whenever the *reduced* surplus is at most
b, including original surpluses b+1 or b+2. Normalizing survivors to
A intersect E(N(S)) gives the exact corner-intersection restriction
without assuming any compression or particular inspection geometry.

With these rules, the uniform pronic memory, and the dual-pronic rule,
the necessary joint model gives68 and96. A separate reverse-potential
checker verifies respectively501667338 and4470748931 joint transition
inequalities for the original, conservatively closed version. Receipt:
`resumed-odd-even-erosion-corners-uniform-audited.json`; source:
`src/resumed_odd_even_erosion_corners.py`. The subsequent closure extension
only removes transitions by the same proved argument; therefore the
original potentials remain valid lower certificates. Fresh receipts are
kept separately when the stronger graph is evaluated.

No merger property for the richer erosion state is used in these joint
certificates. A solo lower bound in this relaxation does not on its own
give twice that bound for the full game. Its bounded falsification results
are recorded in `resumed-odd-even-uniform-falsification.json`; they are
diagnostic comparisons, not an unbounded classification theorem.

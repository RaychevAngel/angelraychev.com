# Second independent review: arbitrary odd boxes

12 September 2026. Independent reviewer: the agent that developed the linear
neighborhood-cost reduction, reviewing the frontier agent's subsequent
terminal-coordinate proof and root's independent reconstruction.

**Conclusion:** the terminal-coordinate exchange proof closes the previously
open lemma. Together with the separately reviewed odd-rectangle induction
base, it proves that the checkerboard weightlex prefixes minimize open
neighborhood size on every Cartesian box with odd side lengths. Their
neighborhoods are compatible opposite-parity prefixes. I found no substantive
gap. This is an ordinary all-dimensional proof; it does not rely on the finite
box experiments and is not yet a complete Lean theorem.

The precise convention is essential: remove singleton factors, sort the
remaining side lengths increasingly, and order vertices by increasing total
coordinate sum, then decreasing lexicographic coordinates. Let the coordinate
maxima be `2≤L₁≤...≤L_d`, all even. For `d≥3`, the partial order `P` is generated
by earlier same-parity vertices that agree in at least one coordinate.

## Independent attack of the missing lemma

The stronger terminal assertion is

    x<y, x_d=0<y_d, and common parity  ⇒  x≤_P y.

If any coordinate agrees the assertion is immediate. Otherwise all coordinates
differ, so in particular the first coordinate is the first lexicographic
difference. I checked the following potential failure points explicitly.

- **Different weights, a decreasing coordinate.** If `|x|<|y|` and `x_i>y_i`
  for some `i<d`, moving `x_i−y_i` units from coordinate `i` to the last
  coordinate stays inside the box: the last coordinate began at zero and the
  transfer is at most `L_i≤L_d`. The new vertex has x's weight, follows x
  lexicographically, and precedes y by weight. It shares an untouched
  coordinate with x and coordinate i with y.
- **Different weights, no decreasing coordinate.** Here `x≤y`
  coordinatewise. Realize the increments using two units in one coordinate,
  then pair the remaining odd one-unit increments. The total increment is
  even, so none is left unpaired. Every step stays within the target bounds,
  increases weight by two and changes at most two coordinates. The condition
  `d≥3` guarantees an unchanged coordinate and hence a generating P-link.
- **Equal weights, a decreasing middle coordinate.** The first coordinate
  satisfies `x₁>y₁`. A transfer from a decreasing middle coordinate to the
  last leaves the first coordinate unchanged. Therefore the intermediate
  vertex still precedes y in the common weight layer. The same capacity
  estimate applies.
- **Equal weights, all middle coordinates increasing.** Since all coordinates
  differ and `d≥3`, the sum of their increases is strictly positive. Weight
  equality gives `x₁−y₁=y_d+Σ_middle(y_i−x_i)>y_d`. Transferring `y_d` from
  coordinate one to the last leaves the new first coordinate strictly larger
  than `y₁`. It therefore lies strictly between x and y, stays nonnegative,
  shares a middle coordinate with x and the last coordinate with y.

These cases are exhaustive. Dimension two is intentionally not covered by this
lemma: there need not be an untouched coordinate. It is supplied by the
independent rectangle theorem, not silently included in the argument.

## Cost-decreasing pairs are exactly the needed cases

For the linear cost

    a(0)=d,
    a(x)=d−j+1−1_(x_j=L_j),  j=last positive coordinate of x,

consider an ordered pair `x<y` with `a(x)>a(y)`. Equal last coordinates already
give a P-link. If `y_d=0<x_d`, x has cost at most one and y has cost at least
one, so strict decrease is impossible. If `x_d=0<y_d`, the terminal assertion
applies. If both last coordinates are positive, the only strict decrease is

    0<x_d<L_d=y_d.

Coordinate complementation transforms this into the terminal assertion for
`complement(y)<complement(x)`. Complementation reverses both the global order
and every generating P-link. It preserves parity because the maxima are even.
Thus it returns the required `x≤_P y`. No additional hypothesis about the
earlier nonzero coordinates or endpoint positions is needed.

## Checking the induction and neighborhood identity

The linear identity is exact for every pair-compressed monochromatic support,
not only for the final global prefix. For a nonzero neighbor z, subtract one
from its last positive coordinate to obtain `ell(z)`. If z neighbors x, then
`ell(z)` differs from x in at most two coordinates and is no later in the
induced pair order. This forces `ell(z)` into the support. Conversely its
presence supplies z as a neighbor. The disjoint predecessor fibers have the
displayed sizes a(x). A nonempty odd compressed support contains a unit vector
by successive two-unit decreases, so its neighborhood additionally contains
the origin. Even supports do not neighbor the origin. Consequently

    |N(S)|=Σ_(x∈S)a(x)+1_(S is odd and nonempty).

I also checked the precise product-compression implication needed in the
induction. Fix one coordinate t and write S_t for the fiber in the remaining
`d−1` coordinates. The output neighborhood fiber is

    N_face(S_t) ∪ S_(t−1) ∪ S_(t+1),

with absent endpoint fibers interpreted as empty. The lower-dimensional
induction hypothesis makes the corresponding three compressed sets prefixes
in the **same output parity order**. Their union therefore has size the
maximum of their three sizes. Each size is bounded by the size of the original
union: the internal neighborhood uses the isoperimetric bound, and adjacent
fibers retain their cardinalities. Thus the global neighborhood cannot grow.
This is a direct verification; ordinary closed-neighborhood compression is not
being substituted for the required parity-open statement.

Repeated coordinate-fiber compressions terminate because every nontrivial
change strictly decreases the sum of global order positions. Their common
fixed sets are precisely P-ideals. Such a set is also pair-compressed: a
two-coordinate fiber lies in a fixed-coordinate face since `d≥3`, and the
restricted orders agree.

For a P-ideal that is not a global prefix, let x be the earliest missing vertex
and y the latest included vertex. The two are incomparable in P. The cost
lemma therefore gives `a(x)≤a(y)`. Removing y and inserting x preserves the
ideal: y is a P-maximal included point, and all predecessors of x were already
included and occur earlier than y. The two sets have the same size and parity,
so the origin term in the exact cost identity is unchanged. This proves the
neighborhood does not grow under the exchange. Repetition reaches the global
prefix and completes the induction.

## Prefix nesting and capture-time scope

Within a fixed weight layer, `ell` is order preserving for decreasing lexicographic
order. A parity prefix ending in weight r therefore has as neighborhood all
earlier opposite-parity layers and an initial segment of weight `r+1`. The
weight-zero exception is covered by the first unit vector of a nonempty odd
prefix. This verifies the required compatible neighborhood property; nesting
alone would not have proved isoperimetric optimality.

It follows that the two-cardinality capture game is exact from a full board or
any initial pair of these prefixes, including arbitrary daily probe budgets.
For constant budget, a shortest-path search on `(E+1)(O+1)` count states yields
feasibility, minimum days, and an explicit prefix-tail schedule. This is
polynomial in the number of rooms, not a claim of polynomial dependence on the
binary encoding of potentially enormous side lengths. A closed elementary
formula for arbitrary dimensions and budgets does not follow automatically.

The proof includes all singleton-factor reductions. The completely singleton
box is a separate trivial one-room game. Boxes with an even side greater than
two are not covered by this theorem. Literature priority remains to be checked;
this review concerns mathematical validity only.

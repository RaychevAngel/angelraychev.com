# Upper lane: accepted results and remaining proof boundary

13 September 2026. Research stopped at the user's wrap request. No new
search, manuscript build, publication, or formalization follows this note.

## What is now proved

1. On every even-area rectangle of width w>=4, length n>=w, and
   ceil(4w/3)<=k<wn/2, the accepted critical three-corner lower bound
   and an actual prefix-palindrome upper differ by at most one day.
   This uses two buffered terminal-objective couplings, not equality
   of the model and physical partial-state frontiers. The seven odd
   budget exceptions have a reviewed all-length insertion proof plus
   a199-length,12393-deadline finite base certificate (0.196 CPU seconds).
2. The subsequently accepted high-credit lemma strengthens the even-width
   range to k>=ceil(13w/10), without finite exceptions. For odd width
   w=2b+1 it gives the clean sufficient k>=ceil(13b/5)+3 and a sharper
   integer test. The older common bound remains available when smaller.
   The new audit checked1794 cases,128200 deadlines, and5247 abstract
   high steps in1.373 CPU seconds.
3. The integer high-credit test uses c>=1, t=2c, A=K-v>0 and

       4v*t*A+A*t*(t-1)-4v*(t-1) >= 4v³.

   On even width2r use c=floor(k/2)-r,v=r-1,K=k. On odd width2b+1
   use c=floor(k/2)-b-1,v=b,K=k-1. Retain k>=w and k<wn/2.
   This is a sufficient one-day bracket, not an exact-time formula.
4. The earlier direct minimum-budget even-width construction remains
   valid for w=2r,r>=5,k=r+1. It changes corners between explicit
   prefix endpoints, has exact solo length law L(n+2)=L(n)+2r, and
   full-length increment4r with the final shot preserved. In width24:

       upper24n-369 for even n>=24;
       upper24n-368 for odd n>=25.

5. The literal width25,k13 strategy has solo length25n-462 and final
   shot size2, hence full upper50n-925 for every even n>=26. Its
   shared middle uses the final shot and longitudinal reflection.
   The parent/lower lanes established a matching lower separately.
6. The exact fixed-descending-word scheduler and no-improvement theorem
   remain accepted. On width2r,k>=r, day-sensitive visibility reduces
   exactly to F<=kt+z(B). Alternate legal words can do better: the
   three-day square-triangle contraction is a literal uniform example.

All upper clocks refer to direct physical prefix, transport, or reversed
prefix strategies. The numerical necessary-model walks are not being
promoted to physical strategies.

## What this does not resolve

The broad arbitrary-budget exact classification and a fixed-operation
formula for every width, length, and quota remain open. In particular:

* The proposed full linear range k>=w is open below the accepted
  sufficient gates. No two-day gap was found, but that is evidence only.
* One-day brackets need not decide which endpoint is optimal.
* Width24,k13 still has the established206--207 square bracket in
  this lane; no103-day solo witness or complete physical impossibility
  certificate was produced by the bounded searches.
* The old prescribed minimum-budget upper has width constants defined
  by prefix-clock iteration. Its affine dependence on length is proved;
  this does not turn it into an O(1) evaluation in all parameters.
* The newer one-day coupling theorems are uniform inequalities. They
  do not, by themselves, replace the underlying lower and upper clocks
  by fixed-operation formulas. The high-credit gate itself does use a
  fixed number of arithmetic operations.

Thus the progress since the constant-operation aspiration is a larger
collection of proved parameter families, explicit strategies, necessary
geometry, and narrow uniform brackets. It is not completion of that
original all-parameter aspiration.

## Independent lower-lane reviews and unfinished CHARGE work

The grouped radius/lens evaluator's trigger root parsing, post-trigger
feature filtering, exact equal-radius grouping, and path reconstruction
were independently reviewed. No new large test was run by this lane.

Critical near-square localization at r=b is valid without equality in
the nonseparator (i,j)=(1,0) branch. Reflect its empty U endpoint to2b.
Then t_(2q)<=b-q and the odd fiber2q+1 lies in the next even prefix,
of length at most b-q-1. Under the physical map
(x,j)->(x,2j+(x mod2)), every room has x+y<=2b-2. No fiber needs
to attain its capacity. The separator branch uses the earlier genuine
quadrant argument. At r=b, after one more movement the radius is2b,
so BOTH same-colored board corners may appear; an inherited c<=1
filter would be wrong. The grouped radius caps already allow c<=2.

The radius-aware Bellman potential review identified the need to allow
actual histories to leave the low sector. The lower lane added the
clipped potential H(min(a,K),R), with a surviving subset proof and a
separate guarded-merger argument. This review did not prove its value
at unrestricted K equals the physical prefix clock.

A sufficient reduction for the remaining CHARGE claim was sent to
the lower lane. For the capped low-prefix maps, physical backward
phase thresholds differ by at most one room: each map is monotone
and1-Lipschitz, and the maps differ pointwise by at most one. Therefore
one extra room repairs the remaining phase choice. Along a pronic-only
segment compared with the alternating prefix, every even-numbered
strict-square-band step contributes at least one irreversible room
of lag before capture. TWO such steps before an odd final sharp event
suffice for CHARGE. It remains unproved that the lens forces this
count, or that the zero/one-credit cases satisfy CHARGE by another
argument. This one-room Lipschitz statement concerns the capped LOW
maps; full-board erosion can jump by two in the high corner.

Two-step low-credit shortcuts replacing rho by a smaller fixed multiple
failed at small root boundaries. These are counterexamples to proposed
proof invariants, not counterexamples to the k>=w conjecture.

## Main owned proof sources

* bridge-upper-transport-coupling.md: even scalar reduction and earlier gate.
* bridge-upper-transport-odd-coupling.md: odd three-frontier phase alignment.
* bridge-upper-transport-odd-exceptions.md: reviewed all-length seven-line proof.
* bridge-upper-transport-high-credit.md: accepted sharper high estimate.
* bridge-upper-transport-odd-length.md: physical width25 shared-day law.
* bridge-upper-transport-handoff.md: older transport/no-go/search receipts.

The matching owned Python/JSON artifacts retain exact audit counts and
source hashes. Existing manuscript draft bridge-uniform-upper.tex is
the only paper source edited by this lane; no build was run during wrap.

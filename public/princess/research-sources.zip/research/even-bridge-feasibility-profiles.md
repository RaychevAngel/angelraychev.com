# Feasibility from two prefix profiles: theorem and a five-dimensional obstruction

12 September2026. New ordinary proofs and finite physical certificates.
No changes to the manuscript or website. Independent audit requested.

## A useful sufficient condition

Suppose a balanced bipartite graph has nested prefix chainsI_p(k),
0≤k≤L, in both colors, withI_p(0)=empty andI_p(L) the full color.
Suppose their neighborhoods are compatible:

    N(I_p(k))=I_(1−p)(g_p(k)).

Setu=max_k(min(g_0(k),g_1(k))−k). If

    max_(p,k)(g_p(k)−k) ≤ u+1,

thenh=u+1 inspections per day suffice to clear either cohort. Indeed,
retaining a prefix after each inspection gives the exact transition

    F_p(k)=g_p(max(k−h,0)).

Every transition weakly decreases the count. If a positive transition
stalls at countk>h, then at remainderr=k−h the active profile has surplus
h. The other profile has surplus at mostu=h−1 at the same remainder,
so the next round decreases the count strictly. Thus every two rounds
reduce a positive count until it is at mosth and can be cleared.
Clearing the two initial cohorts successively gives a full-board strategy.

Ifmin(g_0,g_1) is also the actual minimum neighborhood-cardinality
profile of either color, this upper bound is sharp. Choosek attainingu
and putK=k+u. With onlyu inspections, every support of cardinality at
leastK leaves at leastk survivors and therefore has a next support of
size at leastg_min(k)=K. This invariant obstructs capture from a full
color. It is enough that the minimum profile supplies this lower bound;
no dynamic compression theorem is assumed in this argument.

The simpler pointwise condition|g_0(k)−g_1(k)|≤1 implies the displayed
sufficient condition, but is false already onP4^3, where a difference2
occurs. Even the maximum-surplus condition is not automatic: on
P5×P5×P5×P6 the two quantities in it are54 and53.

## The exact alternating-chain criterion

For an arbitrary budgetm, defineF_p(k)=g_p(max(k−m,0)). Since these
maps are monotone, the alternating chain clears both full colors if
and only if

    F_(1−p)(F_p(k))<k  for all p and all k>0.

Sufficiency follows by strict descent every two rounds. For necessity,
if a positivek has two-step image at leastk, every two-step iterate
starting fromL stays at leastk by monotonicity. Such a start cannot
clear. This criterion describes just the stated chains, not arbitrary
survivor geometries.

## Corner switching does not rescue the candidate bound onP4^5

ConsiderB={0,1,2,3}^5. Its two colors have512 rooms each. Order each
color by increasing total coordinate sum, with lexicographically
decreasing coordinates to break ties. LetI_p(k) be its standard prefix
andg_p(k)=|N(I_p(k))|. Direct finite neighborhood computation verifies
prefix closure and the identities

    max_k(min(g_0(k),g_1(k))−k)=88,
    g_0(240)=g_0(241)=328,  g_0(242)=329,
    g_1(240)=331.

Thus the proposed static minimum-profile expression gives89. However,
**the exact feasible daily budget among all reflected and axis-permuted
weightlex-prefix survivor strategies is90**. This does not identify the
unrestricted hunter number:89 may still be achievable using other shapes.

### Orbit states and the trap

Every allowed prefix is the image of someI_p(k) under a signed coordinate
permutation, that is, a coordinate permutation and a choice of reflected
axes. Normalizing by this graph isometry makes(p,k) a sufficient orbit
state for the restricted family. A retained prefix may have a different
intrinsic phaseq; its normalized next state is(1−q,g_q(r)), where r is
its retained cardinality. The daily cost isk−r.

Consider the following collection of orbit states:

    phase0: k≥331;       phase1: k≥329.

It contains both full colors. We prove it remains invariant under every
allowed prefix choice using at most89 inspections. Monotonicity of the
profiles and the displayed values show that every retainedr≥242 returns
to the collection, for either intrinsic phaseq. If the source is phase0,
its minimum retained size is331−89=242, so this already settles it.

For a phase1 source, retaining phase1 withr≥240 also returns to phase0
at size at least331. The only possible escapes therefore have a phase1
source of size329 or330 and a phase0 survivor of size240 or241. It is
enough to prove that no isometric image ofI_0(240) is contained in
I_1(330). This single noncontainment covers all three possible size pairs.

### A short geometric noncontainment proof

The prefixI_0(240) contains every even layer of total weight at most6.
The targetI_1(330) contains no vertex above weight9 and only34 vertices
of weight9. These layer counts follow from the finite prefix order:
I_0(240) has1,15,65,135,24 points on layers0,2,4,6,8;
I_1(330) has5,35,101,155,34 on layers1,3,5,7,9.

An isometry sending even to odd must reflect an odd number of the five
axes. Coordinate permutations do not affect the following argument.

* If it reflects all five axes, the origin maps to weight15.
* If it reflects three axes, take the weight6 vertex equal to3 on the
  two unreflected axes and0 on the reflected axes. It too maps to weight15.
* If it reflects one axis, consider all source vertices of weight6 whose
  reflected coordinate is0. There are

      [x^6](1+x+x²+x³)^4 = binom(9,3)−4binom(5,3)=44

  such vertices. Each maps to weight9. The target has only34 available
  vertices there, which is impossible for an injective map.

Thus none of the1920 parity-changing signed coordinate permutations
gives the required containment. The orbit collection is invariant,
and every state in it contains at least329 rooms. A final89-room
inspection cannot clear it. This proves the restricted lower bound90
for an arbitrary-length strategy, not just a failed bounded horizon.

### Upper bound and proof boundary

At budget90, the ordinary standard-prefix recurrence clears a full
intrinsic phase0 in96 days and phase1 in97 days. This is checked by the
exact physical neighborhoods of the512 prefixes in each phase. Both
physical initial cohorts can use the96-day strategy: reflect one axis
for the second cohort after the first clears. The resulting192-day
full-board schedule is physically replayed by the checker. Its time
is only an upper bound; the claim here is exact restricted feasibility.

Consequently one cannot reduce general mixed/even-box feasibility to
the static minimum of two standard profiles by asserting that these
prefixes always supply the corresponding strategy. Even arbitrary
corner and axis switching within that entire prefix family fails in
this five-dimensional example. A proof of the unrestricted89-probe
upper bound, if true, would need different survivor shapes.

## Reproducible evidence

`src/even_bridge_feasibility_profiles.py` generates the1024 physical rooms,
checks every prefix neighborhood, the stated layer counts, all abstract
orbit-barrier transitions, and an actual full-board90-probe replay.
The noncontainment proof uses the44-versus34 count rather than assuming
the result of an isometry search. Receipt:
`research/even-bridge-feasibility-prefix-4power5.json`.

An earlier separate enumeration tested all1920 parity-changing signed
permutations for the critical containments and found none in0.04CPU
seconds. It is supporting evidence only; the counting proof above
supplies the mathematical explanation.

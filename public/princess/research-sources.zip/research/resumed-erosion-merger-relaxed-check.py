"""Test a stated weakening of erosion features, without altering canonical code.
Only positive-state and survivor lower cardinality constraints are removed.
Upper feature bounds, empty/full endpoints, geometry, and cost charges remain.
"""
from pathlib import Path
import importlib.util,json,sys,time,hashlib
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'src'))
source=(root/'src/resumed_odd_even_erosion_corners.py').read_text()
original_sha256=hashlib.sha256(source.encode()).hexdigest()
changes={'if c+2*e<=k<=h-4+c+e':'if (k>0 or c==e==0) and k<=h-4+c+e',
         'if not i+2*u<=q<=h-4+i+u:continue':'if not 0<q<=h-4+i+u:continue'}
for old,new in changes.items():
 assert source.count(old)==1,(old,source.count(old));source=source.replace(old,new)
ns={'__name__':'erosion_relaxed_for_merger'};exec(compile(source,'<exact model with stated lower-bound weakening>','exec'),ns)
spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('resumed-erosion-merger-check.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);a.build=ns['build']
if __name__=='__main__':
 start=time.process_time();audits=[];solos=[]
 for b,n,k in[(2,6,3),(3,8,4)]:
  r=a.audit(b,n,k,closed=True,maximal=True,dual=True,all_radii=True);audits.append(r);print(json.dumps(r),flush=True)
 for b,n,k in[(2,6,3),(3,8,4),(4,10,5)]:
  h=(2*b+1)*n//2;states,edges=ns['build'](b,n,k,closed=True,triangle=True,maximal=True,dual=True,all_radii=True)
  c=ns['solo_certificate'](states,edges,h,(h,2,2))
  r=dict(width=2*b+1,n=n,k=k,states=len(states),edges=len(edges),solo=c['solo_relaxation_minimum'],triangle=True,potential_inequalities=c['solo_potential_inequalities_checked']);solos.append(r);print(json.dumps(r),flush=True)
 result=dict(scope=__doc__,audits=audits,solo_checks=solos,CPU_seconds=time.process_time()-start,canonical_source_sha256=original_sha256,weakened_source_sha256=hashlib.sha256(source.encode()).hexdigest(),profile_range='Full closure: filter whenever reduced surplus<=b; all pronic radii enabled.')
 Path(__file__).with_name('resumed-erosion-merger-relaxed-full-closure-check.json').write_text(json.dumps(result,indent=2)+'\n')

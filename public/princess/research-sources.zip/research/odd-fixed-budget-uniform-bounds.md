# Every fixed feasible budget: uniform potentials and a possible periodic law

Root derivation, 12 September 2026 UTC. The scalar argument below is an
ordinary proof from the established odd-rectangle profiles. The final
surgery proposal is not yet a theorem; it has been sent for independent
review and integration with the clean-band argument.

Let w=2b+1>=3, n>=w odd, H=(wn+1)/2, M=H-1, and m>=b+1.
Put d=2m-w>=1. With at most m inspections per day,

    ceil(2C/d) <= T_m(w,n) <= 4 ceil(max(M-m,0)/d)+2,
    C=max(0,2H-4b²-2m-5).

The upper bound need not be sharp when all rooms fit in one day.

## Scalar potential

Put K=2b²+2m+1 and F_p(k)=min(C,max(0,2k+p-K)). For an inspection
quota 0<=r<=m, let q=max(k-r,0) and j=g_p(q). Then

    F_p(k)-F_(1-p)(j) <= max(0,2r-w).

If C=0 this is immediate. Otherwise split into three regions.

* q<=b²: k<=b²+m, so 2k+p-K<=0. The source potential vanishes.
* q>=H-b²-1: every profile satisfies j>=q-1, giving
  2j+(1-p)-K>=2H-2b²-4-K=C. The successor is saturated at C.
* b²<q<H-b²-1: the exact profiles are on their affine plateau,
  j=q+b+p. The unclipped difference is 2r-2b-1=2r-w.
  Common clipping is monotone and one-Lipschitz, proving the inequality.

The first two regions may overlap; their proofs remain valid. In the
middle region q>0, hence q=k-r without truncated subtraction.

For two quotas r+s<=m,

    max(0,2r-w)+max(0,2s-w) <= d.

If both terms are positive, their sum is at most 2m-2w=d-w<d.
If exactly one is positive but its quota is less than m, the sum is at
most d-2<d. Thus equality at d forces all m inspections to one cohort.
At both full classes F=C, and at both empty classes F=0. Telescoping
therefore gives the lower bound against arbitrary prefix strategies;
the proved nesting theorem transfers it to unrestricted strategies.

## Explicit upper strategy

Starting from the full minority class M, direct all m inspections at
that cohort. If it is not already captured, two consecutive steps reduce
its count by at least d, because the two maximum profile surpluses are
b and b+1. After 2 ceil(max(M-m,0)/d) days, at most m positions remain;
one more day captures them. Pad this phase to the stated odd duration
if it finishes early. The untouched initial majority cohort is then the
full minority class. Repeat. This proves the upper bound.

## A finite bound on inefficient days

Suppose C>0 (so H>m). On an optimal strategy define the integer

    eta_t = d - (Phi_t-Phi_(t+1)),   Phi=F_0+F_1.

Each eta_t>=0 and their sum is dT-2C. The upper bound and
ceil(x/d)<=(x+d-1)/d for positive integer x show

    sum eta_t <= B := 8b²+6d+2.

Indeed dT<=4(H-1-m)+6d-4=4H-4m+6d-8, while
2C=4H-8b²-4m-10. Hence at most B days have eta_t>0.
On every other day one cohort receives all m inspections, its potential
drops by exactly d, and the inactive potential stays constant.
An inactive cohort with an intermediate potential has strictly increasing
potential under zero probes, so it cannot occur on such a day.

For endpoint control one can take L=b²+m+1: positive zero-potential
counts are at most L, whereas saturated counts are within b²+2 of full.
On a connected bipartite grid, N² strictly enlarges each proper nonempty
prefix of one color. This supplies length-independent bounds on time
spent near the endpoints without inspections.

## Proposed consequence, pending the band-surgery proof

The same finite bad-day argument as the minimum-budget case should leave
a clean common count band in every sufficiently long board. Take

    Delta=lcm(w,d),     J=m+1.

Each full-budget pair of plateau days reduces the active count by d.
Deleting 2Delta/d days from each of the two clean crossings would remove
Delta states from each full color class and preserve phase. Since
Delta/w is an integer, this changes n by 2Delta/w. The expected eventual
identity is consequently

    T_m(w,n+2d/gcd(w,d)) = T_m(w,n)+4w/gcd(w,d).

This would be eventual periodic affine behavior, not necessarily a
single affine formula. A proof must still justify the common band,
crossing uniqueness, all transformed transitions, and both directions
of the construction. These are not replaced by this algebraic note.

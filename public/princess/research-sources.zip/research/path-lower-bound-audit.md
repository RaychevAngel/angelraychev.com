# Path capture-time lower bound: reconstruction and adversarial audit

Date: 11 September 2026, Pacific time. This is a new English reconstruction of the lower-bound arguments in Angel Raychev's October 2019–March 2020 work. It is not a claim that those results were discovered now. Sources reviewed: `princess.final.tex`, its fuller `princess.finish.tex` variant, and the initial Spring/Student comparison reports. This document treats lower bounds only; optimal schedules are being reconstructed separately.

**Status:** The argument below proves the intended lower bound, including the exceptional extra turn, for every positive integer pair `(n,m)`. It explicitly handles small ranges and `m=1`. The proof has been attacked through exhaustive local-state tests and freshly reviewed by the coordinating agent, who found no substantive gap. It has not been checked in Lean or externally peer reviewed. The main compression is an exact component/endpoints identity followed by a short argument about consecutive maximal decreases. Several source indices and one non-strict inequality are repaired rather than copied.

## 1. Model and notation

Let `P_n` be the path on vertices `1,...,n`. In each round the searcher probes at most `m` vertices, then the uncaught target moves along exactly one edge. Let `T(n,m)` be the minimum number of rounds guaranteeing capture against every legal walk.

A deterministic strategy has a single sequence of actions along its all-misses branch. We can therefore regard it as a fixed schedule. Let `B_t` be the possible positions immediately before the probes in round `t`, let `C_t ⊆ B_t` be the useful probes, and put

\[
 B_1=\{1,\ldots,n\},\qquad B_{t+1}=N(B_t\setminus C_t),\qquad |C_t|\le m.
\]

Probes outside the current possible set can be discarded. For `n≥2`, every vertex has a neighbor, so capture by a round is equivalent to the next possible set being empty. We take `k` to be the first such round; hence `B_t` is nonempty for `t≤k` and `B_{k+1}=∅`.

Split `B_t` into the two classes of trajectories determined by their starting parity. Each class occupies one current parity and changes parity after every move. Their current supports are disjoint. For one class write `A_t`, its useful probe count `p_t`, its survivors `R_t`, and its decrement

\[
 \delta_t=|A_t|-|N(R_t)|.
\]

Write

\[
 \Delta_t=|B_t|-|B_{t+1}|,
 \qquad \sum_{t=1}^{k}\Delta_t=n.
\]

Decrements may be negative. The proof never assumes that all `m` probes are useful; when a maximal decrement occurs, the necessary equalities force full use of the capacity.

## 2. The component/endpoints identity

A **parity interval** is a set `{a,a+2,...,b}`. For a set `R` contained in one parity class, let `c(R)` be its number of maximal nonempty parity intervals and let `e(R)=|R∩{1,n}|`. Both are zero when `R=∅`.

**Lemma 1.** For `n≥2` and every one-parity set `R`,

\[
 |N(R)|-|R|=c(R)-e(R). \tag{1}
\]

**Proof.** A parity interval of `r` vertices has `r+1` neighbors, except that each path endpoint it contains removes one of those neighbors. The neighborhoods of distinct maximal parity intervals are disjoint: between them lies at least one missing vertex of the same parity, making the last possible neighbor from the left interval strictly smaller than the first possible neighbor from the right interval. Sum the counts. ∎

Consequently, for any one-color transition with `p` useful probes,

\[
 \delta=p-c(R)+e(R). \tag{2}
\]

This one identity replaces the source's repeated sector-by-sector estimates.

### Even paths

If `n=2h`, each parity contains exactly one path endpoint. Thus

\[
 |N(R)|\ge |R|,\qquad \delta\le p.
\]

Equality `|N(R)|=|R|` holds exactly when `R` is empty or a single parity interval containing its parity's path endpoint. If such an interval is proper, its neighborhood avoids the endpoint belonging to the opposite parity.

Call a current one-color support **full**, **partial**, or **empty**, according as it is its whole current parity, a nonempty proper subset, or empty.

Two immediate consequences are useful:

1. If a color is partial and has `δ=p` on two consecutive rounds, it is empty after those rounds. Indeed, after the first equality its nonempty support avoids its parity's endpoint; a surviving subset of that support cannot attain equality on the next round.
2. If a color is full, `δ=p`, and `p>0`, then after this round its support avoids its parity's endpoint and has size `h−p`. If `h>2m`, this is greater than `m`, so the next round cannot also have `δ=p`.

The second assertion is the strict inequality intended, but not correctly printed, in Spring Lemma 3.6. Its hypothesis `h>2m` is essential for this formulation.

### Odd paths

If `n=2h+1`, call `{1,3,...,n}` the large parity and `{2,4,...,n−1}` the small parity.

- Every nonempty small-parity set has neighborhood surplus at least one. Thus a small-parity color has `δ≤p−1` unless it is eliminated in this round, when `δ=p`.
- A proper large-parity set has nonnegative surplus, hence `δ≤p`.
- The only negative surplus is `−1`, attained by the full large parity. In a color transition this requires the color to be full and `p=0`; its decrement is then `1`. Therefore a color has `δ≤p+1`, and equality occurs exactly for an untouched full large parity.

In particular,

\[
 \Delta_t\le m+1. \tag{3}
\]

Equality in (3) is possible exactly when an untouched full large-parity color shrinks to the full small parity while the other color, consisting of exactly `m` vertices, is probed in its entirety. Such a round eliminates one color while leaving the other nonempty. There can be at most one round with `Δ=m+1`: an eliminated color never returns, and a single remaining color cannot decrease by `m+1` when `m≥1`.

## 3. The common lower bound for n > 4m

In this section `m≥1` and `n>4m`. Call a round **high** if `Δ_t≥m` and **low** otherwise. Let `x` and `y` be their respective counts, so `x+y=k`.

### Even n

Here every high round has `Δ=m`. Its two color decrements attain their respective probe counts, and exactly `m` useful probes are made.

**Lemma 2.** An internal run of consecutive high rounds has length at most three. There is at most one internal run of length at least two. A terminal run has length at most two.

**Proof.** Consider two consecutive high rounds whose end is nonterminal. If both initial color supports are partial, the two-equalities consequence of Lemma 1 eliminates both colors, a contradiction. The same conclusion holds if one is partial and the other empty. If both are full, some full color is probed on the first round; the full-color consequence excludes equality on the next round. If one is full and the other empty, all first-round probes go to the full color, giving the same contradiction.

The only remaining case is one full and one partial color. The full color is untouched on the first round, since otherwise the next equality is impossible. The partial color is eliminated by the end of the second round. Thus every internal pair of consecutive high rounds eliminates the first of the two colors, and this event can occur only once.

For a third consecutive high round, the formerly full color must also have been untouched on the second round. It is therefore still full before the third round, when it receives all `m` probes. Its remaining size is `h−m>m`, so the third round is nonterminal and the fourth round cannot be high. This excludes internal runs of length four and terminal runs of length three. ∎

There are at most `y+1` high runs. Their lengths exceed one by at most two in the unique internal long run and at most one in the terminal run. Hence

\[
 x\le y+4.
\]

All low decrements are at most `m−1`, so

\[
 2n\le 2mx+2(m-1)y
      =(2m-1)k+(x-y)
      \le (2m-1)k+4. \tag{4}
\]

### Odd n

Here `h≥2m`.

**Lemma 3.** Any two consecutive high rounds are both of decrement `m` and terminate the strategy. A decrement `m+1` is isolated, is neither first nor last, and occurs at most once.

**Proof.** Suppose a round begins with a full large-parity color. After that round, this color has more than `m` vertices in the small parity: if untouched it has `h≥2m>m`; if probed, its proper survivors have nonnegative surplus, leaving at least `h+1−m>m` vertices. On the next round its decrement is at most its probe count minus one. For the next total decrement to be high, the other color must supply a surplus decrease of one. By Lemma 1 this other color must then be the untouched full large parity. Its size therefore grew on the preceding round from at most `h` to `h+1`, so its preceding decrement was at most `−1`. The first color's preceding decrement was at most `max(p,1)≤m`. The preceding total was consequently at most `m−1`, contradicting two high rounds.

If a round begins without a full large-parity color, every color decrement is at most its probe count. For this round to be high, it must have `Δ=m`, all useful probes must be used, and the current small-parity color must be eliminated. Any surviving color lies in the small parity on the following round. A second high round must eliminate that color too, and also has decrement `m`.

Thus a high pair is terminal and contains no `m+1` decrement. A round with `m+1` cannot be last because it leaves the full small parity. It cannot be first because initially that parity has `h>m` vertices, whereas equality requires exactly `m`. The remaining assertions follow from the equality characterization in Lemma 1. ∎

All high runs except possibly the terminal run have length one, and the terminal run has length at most two. Hence `x≤y+2`. At most one high decrement is `m+1`. Therefore

\[
 2n\le 2\bigl(mx+(m-1)y+1\bigr)
      =(2m-1)k+(x-y)+2
      \le(2m-1)k+4. \tag{5}
\]

Equations (4) and (5) establish, for every `m≥1` and `n>4m`,

\[
 T(n,m)\ge \left\lceil\frac{2n-4}{2m-1}\right\rceil. \tag{6}
\]

## 4. Equality obstruction in the exceptional residue

Now assume `m≥2`, `n>4m`, and

\[
 n\equiv m+1\pmod d,\qquad d=2m-1.
\]

Then `K=(2n−3)/d` is an odd integer and is the ceiling in (6). Suppose a strategy takes exactly `K` rounds. We show that both `n` and `m` must be even.

The following accounting keeps all equality assumptions visible. Let

\[
 D=\sum_{\text{low rounds }t}(m-1-\Delta_t)\ge0.
\]

### Even n: a balanced transition forces even m

Every high decrement is `m`. Thus

\[
 2n=dK+(x-y)-2D.
\]

Since `dK=2n−3`, we have `x−y−2D=3`. By Lemma 2, `x−y≤4`; since `K` is odd, `x−y` is odd, hence at most three. Consequently

\[
 x-y=3,\qquad D=0. \tag{7}
\]

Every decrement is therefore exactly `m` or `m−1`. Denote these by `H` and `L`.

**There cannot be a run `HHH`.** Before this run the word ends in `L` (or is empty) and has no adjacent highs, so its numbers `a,b` of highs and lows satisfy `a−b≤0`. The suffix begins in `L` and can have only a terminal double high, so its excess of highs over lows is at most one. By (7), the prefix excess is either `0` or `−1`.

At the end of the second high in the triple, Lemma 2 says that one color is empty and the other is full. The total decrement through that point is exactly `n/2`. Modulo `d`, the prefix and those two highs therefore give

\[
 \frac n2\equiv 2m\equiv1\pmod d
 \quad\text{or}\quad
 \frac n2\equiv (m-1)+2m\equiv m\pmod d.
\]

But `n≡m+1 (mod d)`. In the first case, doubling gives `m≡1 (mod d)`, impossible because `0<m−1<d`. In the second case, doubling and using `2m≡1 (mod d)` gives `m≡0 (mod d)`, impossible because `0<m<d`.

This observation slightly simplifies the historical proof: it excludes a triple for **every** `m≥2` in this equality case, not only for odd `m`.

With no triple, the maximal possible excess of highs over lows is three. Equality forces one internal double high, one terminal double high, a high first and last symbol, and isolated lows. The whole word is thus

\[
 (HL)^u\,HH\,(LH)^v\,H, \tag{8}
\]

where `u≥0` and `v≥1`.

At the internal double, one color is full and the other partial. On the first of those two rounds the full color is untouched. On the second let `p` probes go to the full color and `q` to the partial color, which is eliminated. Since this is a high round, `p+q=m`, and both color decrements equal their useful probe counts.

The two colors initially had equal size `h=n/2`. Summing the decrements of the first color to be eliminated, and then of the remaining color, gives

\[
 h=ud+m+q,
 \qquad h=p+vd+m.
\]

The first identity remains valid even if earlier steps temporarily regrew a color: it follows by telescoping the total decrement up to the internal pair, at whose start the other color is full. Subtracting yields

\[
 (u-v)d=p-q.
\]

But `|p−q|≤m<d`. Therefore `p=q=m/2`, forcing `m` even.

### Odd n: the exceptional high cannot balance the two halves

Let `z` count decrements `m+1`; Lemma 3 gives `z≤1`. Now

\[
 2n=dK+(x-y)+2z-2D.
\]

Thus `(x−y)+2z−2D=3`. Lemma 3 gives `x−y≤2`; oddness of `K` improves this to `x−y≤1`. Equality forces

\[
 x-y=1,\quad z=1,\quad D=0. \tag{9}
\]

There is exactly one decrement `m+1`; all other decrements are `m` or `m−1`. Let the prefix before that exceptional decrement contain `a` highs and `b` lows, and its suffix `c` highs and `e` lows. Here “high” in these four counts means only decrement `m`.

By Lemma 3, the prefix ends in a low and has no adjacent highs, so `a−b≤0`. The suffix starts in a low and has at most a terminal double high, so `c−e≤1`. Equation (9) gives `(a−b)+(c−e)=0`. Therefore the only possibilities are

\[
 (a-b,c-e)=(0,0)\quad\text{or}\quad(-1,1). \tag{10}
\]

Immediately after the exceptional round, the only remaining color is the full small parity, of size `h=(n−1)/2`. The sum of decrements through that round is therefore `h+1`, while the suffix sum is `h`. Consequently

\[
 am+b(m-1)+m=cm+e(m-1). \tag{11}
\]

In the first case of (10), equation (11) gives `ad+m=cd`, so `d` divides `m`. In the second it gives `ad+(m−1)+m=ed+m`, again making `d` divide `m`. Both contradict `0<m<d`.

We conclude that a `K`-round strategy in the exceptional residue is possible only when both `n` and `m` are even. In all other cases,

\[
 T(n,m)\ge K+1.
\]

This is a necessity statement; a matching even-even construction belongs to the separate upper-bound proof.

## 5. Small ranges, with no hidden large-n assumption

### Monotonicity

If `a≤b`, a schedule that catches every legal walk in `P_b` catches every legal walk restricted to its first `a` vertices after ignoring probes outside them. Thus `T(a,m)≤T(b,m)` for `a≥2`; the one-vertex case is immediate.

### At least two rounds for n>m

One round can inspect at most `m` initial positions. Hence `T(n,m)≥2` when `n>m`.

### At least three rounds for n≥2m+2

For the even path of length `2m+2`, every decrement is at most `m`, by Lemma 1. Two rounds cannot decrease the initial `2m+2` positions to zero. Monotonicity handles all larger paths.

### At least four rounds for n≥3m+1

If `3m+1` is even, each decrement is at most `m`, so three rounds are insufficient.

If `3m+1` is odd, write `h=(3m)/2>m`. Every decrement is at most `m+1`, and at most one can be `m+1`. Three rounds could sum to `3m+1` only if one is exceptional. It cannot be first, since the initial small parity has `h>m` vertices. It cannot be last, since it leaves a nonempty full small parity. If it is second, it leaves `h>m` possible positions, which one final round cannot capture. Thus three rounds are impossible. Monotonicity again handles all larger paths.

### The remaining boundary n=3m for odd m≥3

Here `h=(3m−1)/2>m`. An exceptional decrement `m+1` in a three-round strategy is impossible by the same first/middle/last argument. Therefore three rounds would all have decrement `m`.

Initially the small parity has more than `m` vertices, so its first-round decrement is at most its probe count minus one. Attaining total decrement `m` requires the large parity's decrement to exceed its probe count by one. Lemma 1 forces this large parity to be untouched. The small parity receives all `m` probes and has decrement `m−1`.

After round one, the untouched color is the full small parity of size `h>m`; the other color is a proper large-parity set of size `(m+1)/2`. On round two the first color decreases by at most its probe count minus one, and the second by at most its probe count. The total decrement is at most `m−1`, a contradiction.

For `m≥2` the lower bounds just proved give the following table on `n≤4m`:

| Range | Required rounds |
|---|---:|
| `1≤n≤m` | at least 1 |
| `m+1≤n≤2m+1` | at least 2 |
| `2m+2≤n≤3m−1` | at least 3 |
| `n=3m`, `m` even | at least 3 |
| `n=3m`, `m` odd | at least 4 |
| `3m+1≤n≤4m` | at least 4 |

Elementary substitution shows that these are exactly the proposed formula's lower bounds on this range. Empty intervals in the table impose no case.

### One probe

For `m=1` and `n≥5`, (6) gives `T(n,1)≥2n−4`. For `n=4`, Lemma 1 for even paths gives a decrement at most one in each round, hence at least four rounds. The remaining lower bounds are `T(1,1)≥1`, `T(2,1)≥2`, and `T(3,1)≥2`.

Thus every positive pair is covered without applying the exceptional-residue correction at `m=1`.

## 6. Consolidated lower-bound statement

For every pair of positive integers `n,m`, every guaranteed-capture schedule has at least the following many rounds:

\[
 L(n,m)=
 \begin{cases}
 1,&n\le m,\\
 2,&m=1,\ n=2,\\
 2n-4,&m=1,\ n\ge3,\\
 \displaystyle\left\lceil\frac{2n-4}{2m-1}\right\rceil+\varepsilon(n,m),
     &m\ge2,\ n>m,
 \end{cases}
\]

where

\[
 \varepsilon(n,m)=
 \begin{cases}
 1,&n\equiv m+1\pmod{2m-1}\text{ and at least one of }n,m\text{ is odd},\\
 0,&\text{otherwise}.
 \end{cases}
\]

The separate construction proof is required to conclude `T=L`.

## 7. Independent attacks and remaining verification boundaries

1. **All-state local checking.** `src/path_lower_lemmas.py` enumerates every belief set and every useful probe subset for `(n,m)=(5,1),(6,1),(7,1),(8,1),(9,2),(10,2),(11,2),(12,2),(13,3),(14,3)`. It checks the component identity, maximum decrements, every consecutive high pair, every high triple, and the equality characterizations used above. Results are in `research/path-lower-lemma-checks.json`: all assertions passed across 1,928,358 transitions, in under one second on this machine. These are local checks, not a finite substitute for the unbounded proof.
2. **No false nonnegative-decrement assumption.** The all-state checker includes disconnected supports and actions that increase the possible set. The written proof treats all such decrements as low and allows arbitrary slack `D`.
3. **At most m probes.** Equality accounting is written with `p+q≤m` until a high round forces equality. No padding argument is needed.
4. **Color recontamination.** A partial color can become full again; the proof does not assume otherwise. The even equality-case balancing uses telescoped total decrements and the full state at the internal pair, not an assumption that the second color was never touched earlier.
5. **Terminal movement.** The proof explicitly uses that for `n≥2`, an empty neighborhood means an empty surviving set. The isolated one-vertex case is handled directly.
6. **Source defects repaired.** The strict full-color inequality is stated correctly. Time indices do not mix with state-type subscripts. The exception proof excludes triples for all `m≥2`, then states all equality constraints rather than assuming the displayed word without explanation.
7. **Independent read:** the coordinating agent freshly reviewed the complete reconstruction, including both parity lemmas, equality accounting, and small ranges, and found no substantive gap. A proposed arithmetic objection in the triple-exclusion step was retracted: the two divisibility forms are equivalent because `(m−1)+m=d`. The text now gives the two contradictions separately for clarity. A control-character typo in the displayed epsilon formula was repaired.
8. **Outstanding:** Lean verification and external peer review have not yet been performed. Upper constructions are outside this document. No novelty conclusion follows from this proof audit.

## 8. Formalization suggestion

A compact Lean route is to separate finite-set geometry from word counting:

- Prove (1) or equivalent endpoint-interval equality characterizations for parity subsets of a finite path.
- Derive the even and odd two-high-step lemmas for arbitrary finite supports and actions.
- Prove reusable finite-word run-count lemmas (`x≤y+4`, `x≤y+2`) and their equality cases.
- Use telescoping cardinalities, integer parity, and bounded divisibility for the final arithmetic.

The all-parameter upper schedule should share the same belief-update definition. No theorem should stop at checking a displayed finite certificate without linking it to arbitrary legal target walks.

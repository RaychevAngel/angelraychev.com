# Independent proof and Lean review: two root candidates

13 September 2026. Dirac and root independently derived the same reduction.
Let `q(y)` be the least integer r with `y<=r(r+1)`, and `R(y)` the least
integer s with `y<=s^2`. For `0<=l<=u<=S`, the minimum of
`q(y)+R(S-y)` on the integer interval is attained at one of

    min(u,q(l)(q(l)+1)),
    max(l,S-R(S-u)^2).

Root's separate derivation: for a proposed cost t and allocation r+s=t,
feasibility requires `r>=q(l)`, `s>=R(S-u)`, and
`r(r+1)+s^2>=S`. At fixed t the last expression is a convex quadratic
in r, so some endpoint of the allocation interval has at least that
capacity. Fixing one root to its minimum endpoint value gives the two
displayed positions. This proves a minimum of rounded roots, not an
incorrect claim that the original interval's own endpoints always suffice.

Root formalized this argument in `lean/RootConvolution.lean`. Both roots
are explicit recursively defined total functions with proved capacity
characterizations. The module proves candidate membership, the lower
bound against every interval point, and an attaining minimum. It has no
external root-oracle hypotheses. A direct sequential Lean 4.33.1 check
finished successfully in 0.53 seconds; the printed axioms of
`Princess.RootConvolution.exact_minimum` are only `propext`,
`Classical.choice`, and `Quot.sound`.

Dirac independently reviewed the final Lean statement and definitions:
PASS. The pronic and square conventions, clipping, subtraction directions,
zero cases, and actual-attainment conclusion agree with the ordinary lemma.

The application to a sum of reflected inverse profiles is a separate
ordinary argument. Neither result proves the outstanding full-board
midpoint criterion; the proposed closure also needs an invariant of the
actual solo trajectory, as its documented hypothetical-capacity
counterexample demonstrates.

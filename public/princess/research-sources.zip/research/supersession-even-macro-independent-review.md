# Independent audit: exact bounded-duration physical interfaces

13 September 2026. Root independently reviewed Sections 1--6 of
`supersession-even-macro-states.md`. **PASS as an ordinary theorem**,
with the explicit three-radius local verification used in the final draft.

The checks covered the physical pyramid definition at empty and full fibers,
the exact neighborhood cutoff (which need not be a uniform height increment),
matching nondecrease and the upper surplus b, and all clean-day timing.
The previously proved slack bound gives canonical endpoints at gaps of at
most E+1 inspection days. Appending the empty move after the last successful
inspection does not add a day.

For a block of r days, the no-inspection endpoint is a pyramid and contains
the actual endpoint. Their difference has at most (m+b)r rooms. Removing
shots outside distance r from that difference preserves the endpoint exactly:
any newly surviving bad walk would end in the difference and all its vertices
would lie inside the retained band. The independent Lean module
`ProbeLocalization.lean` verifies the general directed-graph semantic statement;
Socrates independently checked its statement and timing. It does not formalize
the geometric band bounds.

The difference of nested same-oriented pyramids fits in a bounded band by
their bounded height ranges. For opposite orientations, either the uninspected
endpoint is full or the target pyramid has an empty fiber and at most w^2
rooms. Both alternatives force a bounded end band. Owner changes likewise
force the departing or arriving pyramid to have bounded size or deficit.
The length guard n>=10R implies h>mL, preventing a full mate from becoming
empty inside an interior block.

For a local edge test, shots are in D+r. Only final rooms in D+2r can be
affected; every r-step walk to them starts and stays in D+3r. Simulating on
that last region and checking equality only on D+2r is exact. Outside it,
the free baseline equals the desired endpoint. Tests at separated physical
ends retain the shared daily quota and cannot communicate within r days.

Thus one translated height vector plus finite labels suffices at checkpoints.
The finite edge table allows arbitrary intermediate supports. The number
of states and edges is linear in the length after parameter-dependent
preprocessing; the finite short-length exceptions are explicitly bounded.
This is not a theorem about arbitrary initial supports or prescribed quota
words, and the earlier daily-prefix counterexamples do not contradict it.

Any subsequent logarithmic-time summary/powering theorem requires its own
path-decomposition argument; this review does not assume such a theorem.

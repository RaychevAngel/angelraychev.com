# Independent review of the universal height-loop period

12 September 2026. Reviewer: the separate physical-proof/formalization lane.

**Pass.** I independently reconstructed all eight sections of
`even-bridge-height-loop-period.md`. The sharper period is
Delta=2(2m-A)/gcd(A,2m-A), with time increment 4A/gcd(A,2m-A), in every
parity class covered by the two previously reviewed physical-frontier
reductions. The following points were checked against actual room
coordinates rather than only an abstract finite graph.

1. Every clean physical frontier admits longitudinal cutoffs a_v of its
   required checkerboard parity with |a_u-a_v|=1 on every Q edge.
   For even-order Q, its exact matched neighborhood advances both cutoffs
   in each transverse matched pair by one; any larger transverse height
   difference would violate that actual neighborhood. For odd-order Q
   and paired columns, substitute a_v=2(l_v-1)+sigma_v into the reviewed
   0/1 length relations in both alternating phases. Extra Q edges are
   covered in both arguments. Conversely, such interior cutoff fronts
   have exactly the neighborhood cutoff a_v+1.
2. Sorting vertices by their initial heights produces a legal A-flip
   word. Every higher neighbor has already moved down by two when a
   vertex is processed, while every lower neighbor has not moved; all
   are therefore one below it. Repeating this word preserves legality
   under arbitrary intervening uniform +1 movements. At survivor graph
   vertices the daily order is movement, then m flips. Each flip removes
   a distinct actual top room within that day when the cutoffs are
   interior.
3. With D=2m-A and g=gcd(A,D), exactly 2m/g words give ell=2A/g days and
   uniform height translation -Delta=-2D/g. The divisibility g|2m is
   justified by 2m=A+D. Both ell and Delta are even. This loop exists at
   every normalized height state, not just at a specially chosen one.
4. Relative heights along a spanning tree and the phase give at most
   M=2^A states per orientation. Every edge loses D in the sum of heights.
   A closed walk of length t has t even and uniform displacement 2s;
   hence 2As=Dt. Writing t=2r proves A/g divides r and ell divides t.
   The normalized phase is essential to this divisibility argument.
5. Given a walk of length t>=M, cycle erasure leaves a simple path of
   length p<=M-1. The removed length is a positive multiple of ell, so
   (t-p-ell)/ell is a nonnegative integer. Inserting that many universal
   loops at the start gives exactly t-ell edges with the same normalized
   endpoints. This is a replacement walk, not an unsupported claim that
   one can choose disjoint original cycles totaling ell.
6. From the same actual start the shortened walk ends Delta higher than
   the original endpoint. Starting it Delta lower therefore matches the
   endpoint exactly, as physical column deletion requires for a left
   frontier. Reflection handles the other orientation. Conversely one
   inserted universal loop matches the expansion endpoints.
7. All old and new height transitions have mean drift -D/A per day, and
   the edge condition bounds their height range by diam(Q)<=A-1. Every
   replacement configuration consequently lies within a fixed width of
   its endpoint-mean interval. Within an inspection day heights descend
   coordinatewise between the post-movement start and the next survivor,
   so no extra excursion proportional to the word length is hidden.
   The enlarged A+2 margins cover these configurations and the global +1.
   The protected band and the globally full/empty mate from the previous
   proofs therefore justify both physical surgeries without any new
   restriction on the rest of the optimal strategy.
8. In the odd paired-column construction, the survivor rank 2r-e differs
   from the sum of actual cutoff heights by a constant: the sum of
   longitudinal parity indicators is b+1-e for a left-oriented frontier.
   Thus the physical drift D/A and paired-coordinate drift D/(2A) are
   compatible, and paired displacement Delta/2 is integral. The history
   bit is determined by phase and orientation in this frontier graph.

The previous threshold construction remains sufficient after replacing
its cycle length by ell, its normalized state bound by M=2^A, its
long-walk allowance by M+ell+4, and its width margin by at least A+2.
Use physical displacement Delta for even-order Q and paired displacement
Delta/2 for odd-order Q. The resulting bounds are singly exponential in
A and polynomial in the fixed budget m; no large-lcm construction remains
necessary.

For odd-volume boxes the existing odd-length theorem already has the same
period. Consequently no least-common-multiple combination is needed for
the all-box conclusion. At the eventual minimum budget the period is two:
the increment is 2A for even A and 4A for odd A. Delta is a proved valid
period, not necessarily the smallest period of the actual optimal-time
sequence. Finite exception values and simple formulas for arbitrary
finite boxes remain outside this result. No Lean formalization is claimed.

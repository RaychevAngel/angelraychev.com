# Independent review: odd five-row boards with three probes

12 September 2026. The final odd-length section of
`five-row-investigation.md` passes independent mathematical review. Combined
with the separately reviewed even-length argument, the result is

\[
T_3(P_5\square P_n)=10n-20\qquad\text{for every }n\ge5.
\]

The odd case uses the ordinary odd-rectangle isoperimetric theorem and a
universal Lean-checked scalar potential. It does not rely on the even-length
automaton certificate. Neither physical five-row theorem is fully formalized
in Lean yet; the geometric interfaces must remain explicit in the paper.

## Profile and reachable-state checks

Write `h=(5n−1)/2`, so the majority class has `h+1` rooms and the minority has
`h` rooms. The specialized profiles in the new proof match the general
odd-rectangle formulas with short-side parameter two. In particular, the
majority entries `k=h,h+1` both have neighborhood size h; this is correctly
separated from the surplus-one interval `h−3≤k≤h−1`. The minority full set
has neighborhood size `h+1`, distinct from the surplus-two entries just below
it. The corner entries at zero, one and two are also consistent.

The physical graph has minimum degree two in the majority class and minimum
degree three in the minority class: all four corners have even checkerboard
parity because both side lengths are odd. Thus any nonempty current majority
belief obtained as a neighborhood has at least three cells, and any minority
belief has at least two. This verifies the exact `Valid` domain in
`FiveRowOddRankArithmetic.lean`, including the initial beliefs.

For arbitrary supports, take the useful probe count p inside a cohort. The
survivor count is exactly `b−p`; the next support size is at least the
appropriate profile value. The theorem `potential_step` supplies the bound
at that minimum, and `value_monotone` correctly transfers it to a larger
actual neighborhood. Both the phase and the current parity switch every
round. No historical-efficiency assumption is used in this odd-length proof.

The two cohorts are disjoint in physical parity at every time. Therefore at
most one can receive at least two useful probes under budget three. Adding
the two inequalities gives a potential loss of at most one per day. Their
initial potentials are each `2h−9`, and the final potentials are zero, yielding
the exact lower bound `4h−18=10n−20` for arbitrary schedules.

## Upper construction and parity alignment

The favorable first cohort is the initially minority class. Prefix nesting
makes the physical updates exactly the displayed profile transitions:

    (h, minority) → (h, majority) → (h−2, minority).

For each minority size `6≤b≤h−2`, a pair of three-probe rounds gives

    (b, minority) → (b, majority) → (b−1, minority).

The intermediate survivor sizes are `3≤b−3≤h−5`, which fall in the stated
surplus-three minority and surplus-two majority intervals. Thus there are
exactly `h−7` pairs before reaching size five. The final three rounds are
`(5, minority)→(4, majority)→(2, minority)→0`, using the separately checked
size-two and size-one corner entries.

One sweep lasts `2+2(h−7)+3=2h−9=5n−10` rounds, an odd number. The untouched
cohort has remained the full alternating parity, because full parity classes
map onto each other under neighborhood. Its initially majority parity is
therefore minority when the second sweep starts. The same favorable sweep
applies again without an extra waiting day. This parity alignment is the
reason the order of the two cohorts matters.

At the smallest allowed board, `n=5,h=12`, every interval is valid; each
sweep takes fifteen days and the total is thirty. There is no exceptional
square correction.

## Independent implementation attack

The independent physical checker `src/five_row_independent_review.py` now
reconstructs odd-board prefix orders and their actual room neighborhoods
without importing the author's strategy/profile implementation. It checks
all prefix identities and replays the entire two-cohort schedule against the
full physical belief for lengths `5,7,9,11,15,21,51,101`. Every check passes;
the shared receipt is `five-row-independent-review.json`.

These finite checks attack indexing and phase errors. The uniform profile
proof, universal scalar inequality and displayed all-length sweep supply the
mathematical result. No claim about other budgets, literature priority, or a
complete physical Lean classification is made here.

# Every fixed odd cross-section: eventual feasibility and affine time periods

12 September 2026 UTC. Ordinary theorem, independently audited with no gap;
see `odd-cylinder-eventual-independent-review.md`.
This extends the independently reviewed fixed-budget odd-rectangle proof
without assuming multidimensional profile behavior from finite examples.

## 1. Statement

Let Q be a fixed nontrivial Cartesian box with odd side lengths. Write

    W=|Q|,       S=sum_i(side_i-1),       Z=W(S+1).

Thus W is odd and S is even. Consider Q square P_n with odd n. Put
H=(Wn+1)/2. Once H>=2Z+3, its minimum feasible budget is exactly

    h(Q square P_n)=(W+1)/2.                           (1)

For every fixed m>=(W+1)/2, define

    d=2m-W,       g=gcd(W,d),       Delta=lcm(W,d),
    J=m+1,        A=Z+1,           R=Delta+2J,
    B=8Z+6d+2,    L=Z+m+1,         E=B+4L(B+1),
    H*=R+2A+4J+2+2E(R+2J+1).                           (2)

Then for every odd n with H>=H*,

    T_m(Q square P_(n+2d/g))
        = T_m(Q square P_n)+4W/g.                      (3)

For m<(W+1)/2, the sufficiently long cylinders are impossible by (1).
For each feasible fixed m, (3) gives the complete eventual time law and
an explicit method to extend optimal strategies. A one-point Q gives
odd paths, whose complete classification is already proved separately;
the nontrivial hypothesis here avoids a dimension-zero cost convention.

The proof below verifies all geometric and profile-translation premises.
The band-surgery argument is then exactly the already proved general
fixed-budget argument with W in place of the rectangle width and Z in
place of b². It is not an assertion that a plateau alone implies
periodicity: stable low and high corner profiles are also established.

## 2. Coordinates, stable base ranks, and the finite corner tables

Order the side lengths of Q increasingly. For n>=S+3, its longitudinal
coordinate is strictly the longest, hence is last in the proved all-odd
box order: increasing total weight and decreasing lexicographic coordinates.
Let a_Q(v) be the transverse local neighborhood cost from the all-odd-box
theorem. Let p denote a vertex's global checkerboard parity.

For each v in Q_p, let r_p(v) be the rank of (v,0) in the corresponding
parity order of the infinite prism Q times the nonnegative integers.
This is a finite rank: (v,0) has weight at most S, so all preceding
vertices have longitudinal coordinate at most S. Consequently it is
independent of the finite cylinder length whenever n>=S+1. It can be
computed in the single finite slab Q square P_(S+1).

At most W(S+1)=Z vertices in total have weight at most S, so
r_p(v)<=Z. Define two length-independent finite tables, for k>=0,

    U_p(k)=sum_{v in Q_p, r_p(v)<=k} a_Q(v),
    B_p(k)=#{v in Q_p: r_p(v)<=k}.                     (4)

They are constant for k>=Z. They can be evaluated once from the finite
slab; their definitions for larger k mean this constant extension.

The exact profile decomposition for every nonempty prefix is

    g_p^n(k)=k+1_(p=1)+U_p(k)-|Q_p|+B_p(H-p-k),       (5)
    g_p^n(0)=0.

To prove (5), inspect the ambient local cost a(x)-1. On the bottom slice
x_long=0 it equals a_Q(v), including the origin. On an interior slice
0<x_long<n-1 it is zero, since the last positive coordinate is the
longitudinal one and is not full. On the top slice x_long=n-1 it is -1.
The ordinary prefix-cost identity therefore gives

    g_p^n(k)-k=1_(p=1)
       +sum of selected bottom-slice a_Q
       -number of selected top-slice vertices.

The first term of the sum is U_p(k). Coordinate complement reverses
the weight and lexicographic order and preserves parity, because all
coordinate maxima are even. It carries the top slice to the bottom slice.
Thus a selected top vertex corresponds to a bottom vertex outside the
prefix of size H-p-k in the complemented order. Its selected count is
|Q_p|-B_p(H-p-k), proving (5).

The empty odd prefix must be handled separately, as stated: the extra
origin-neighbor indicator in the cost identity requires nonemptiness.

## 3. Exact plateau and stable translation identities

Since the neighborhood of a full color class in Q is its opposite class,
the transverse cost identity gives

    U_p(infinity)=|Q_(1-p)|-1_(p=1),
    B_p(infinity)=|Q_p|.

All a_Q are nonnegative. Equation(5) therefore gives the global bound

    g_p^n(k)-k <= |Q_(1-p)|=(W-1)/2+p.                 (6)

If k>Z and H-p-k>Z, both tables in (5) have stabilized, so

    g_p^n(k)=k+(W-1)/2+p.                              (7)

This proves the plateau from the actual multidimensional order.

More strongly, (5) supplies the two identities needed for contraction
and insertion. For two cylinder lengths with majority sizes H and
H+Delta, both with longitudinal length at least S+3:

* If the smaller remaining tail H-p-k>Z, then the low profile is
  independent of H:

      g_p^(H+Delta)(k)=g_p^H(k)
        =k+1_(p=1)+U_p(k)       for k>0.

  At k=0 the equality of the two profiles still holds because both are0;
  the nonempty-prefix expression on the right is not used there.

* If k>Z, then the upper profile translates:

      g_p^(H+Delta)(k+Delta)=g_p^H(k)+Delta.

The second identity holds because U has stabilized and the tail argument
H-p-k is unchanged. These identities would not follow from the plateau
statement alone; the stable rank decomposition is the additional proof.

## 4. Lower expansion and eventual feasibility

An all-odd box has a Hamiltonian path starting and ending in the majority
color. One constructs it recursively by traversing successive slices
alternately forward and backward; the odd number of slices leaves the
endpoint in the opposite geometric corner, still of majority parity.

On this spanning odd path, every proper majority k-set has at least k
minority neighbors. Omit an unselected majority vertex and match selected
vertices before it to their following path neighbor and selected vertices
after it to their preceding path neighbor. These neighbors are distinct.
Every nonempty minority k-set has at least k+1 majority neighbors: its
consecutive blocks in the spacing-two path order each contribute one
more neighbor than their size, and different blocks have disjoint neighbor
intervals. The box contains all these path edges. Hence

    g0(k)>=k for k<H,
    g1(k)>=k+1 for k>0,
    g0(H)=H-1.                                        (8)

In particular every surplus is at least -1, and an uninspected cohort's
intermediate clipped potential strictly grows, exactly as in the rectangle
proof. This also supplies the one-day displacement bound m+1 whenever
m>=(W+1)/2, by combining (6) and (8).

The all-odd-box hunter-number criterion is
h=1+max_k(g0(k)-k). Bound(6) gives the upper bound (W+1)/2. If H>=2Z+3,
take k=Z+1 in (7); its tail H-k>Z. The maximum majority surplus therefore
attains (W-1)/2, proving equality (1). The same size condition ensures
n>S+3, so the longitudinal ordering used above is valid.

## 5. All-budget potential and clean-band surgery

For fixed m>=(W+1)/2 use

    K=2Z+2m+1,
    C=2H-4Z-2m-5>0,
    F_p(k)=min(C,max(0,2k+p-K)).                        (9)

For survivor q<=Z, the current unclipped potential is zero. For
q>=H-Z-1, (8) gives successor j>=H-Z-2, whose unclipped potential is
at least C. In the middle, (7) gives raw potential difference2r-W.
Thus

    F_p(k)-F_(1-p)(g_p(max(k-r,0))) <=max(0,2r-W).

The shares of one day's quota sum to a maximum drop d=2m-W, attained
only when one cohort receives all m. The minority-first padded two-phase
upper bound and integer rounding give at most B=8Z+6d+2 total deficit
units. Hence there are at most B inefficient days.

Property(8) makes zero-quota intermediate potentials strictly increase.
There are at most two focused blocks per consecutive efficient run.
An inactive zero-potential cohort has count at most Z+m=L-1. An inactive
full-potential cohort is at deficit at most Z+2<=L from its full class.
Strict two-day growth of every nonempty proper parity support, from
connectedness, therefore bounds all endpoint transients by2L per block.
There are at most E=B+4L(B+1) nonclean days.

The proof in `odd-fixed-budget-eventual-periodicity.md` Sections4–5 now
applies with the literal parameters (2). For completeness, its mechanism
is as follows. Among integer cuts

    A+2J<=c<=H-R-A-2J-2,

exclude cuts for which either recorded source count lies in
[c-J,c+R+J]. At most2E(R+2J+1) cuts are
excluded; the threshold H* leaves a candidate. Each initial cohort's
first count x_i<=c+Delta+J lies in(c+Delta,c+Delta+J]. The next
2Delta/d full-budget days keep it in the clean plateau and end at
x_i-Delta, with parity restored. The two initial cohorts may use distinct
endpoints x_i, which handles skipped counts and different residues.

Deleting the two even-length blocks and subtracting Delta above each
cohort's individual upper cut gives a search on H-Delta. Low transitions
are unchanged and high transitions translate by Delta by Section3. The
inactive companion remains empty or full during each removed block.
Conversely, enlarging each block to twice its length produces a search on
H+Delta. Thus the optimum increases by exactly4Delta/d when H increases
by Delta. Since Delta/W=d/g, this is (3).

No geometric premise is lost during contraction. In fact

    H*-Delta >=2Z+6J+4,

so the contracted longitudinal length is greater than4(S+1), hence
greater than S+3 and every transverse side length. Both the base-rank
tables and the low/high profile translations remain valid. The upper and
lower individual cut margins likewise imply tails and survivor counts
strictly beyond Z, as required.

## 6. Exact finite computation and remaining scope

The tables U_p and B_p are computed on a single slab of Z rooms. Equation(5)
then produces the exact profiles for every longer cylinder without sorting
its entire vertex set. Combined with the exact two-count recurrence and
the eventual period, this gives feasibility, exact times and actual optimal
inspection strategies for all odd cylinder lengths, with short lengths
handled by the already proved general all-odd-box profile algorithm.

The large-threshold theorem proves eventual behavior; it does not prove
that the affine period begins at the first length for which the selected
coordinate is longest. It does not assert that the original full search
must be serial: only two protected interior crossing blocks are serial,
while the rest of an optimal search may interleave cohorts arbitrarily.
Boxes with even side lengths remain outside this theorem.

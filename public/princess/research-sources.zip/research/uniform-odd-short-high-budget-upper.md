# Uniform physical upper bounds for odd-short, even-long rectangles

12 September 2026. Ordinary construction independently accepted by Euler;
see `uniform-odd-short-high-budget-upper-independent-review.md`.
Matching lower bounds are not proved here. This is a physical
envelope construction, not an assumption that static minima nest.

Let `w=2b+1`, `n=2L≥w`, `b≥1`, `h=wn/2`, and

    b(b+1)+1≤m<h.

Put `D=2m−w>0`, and divide

    W=2h−w−1=qD+r,    0≤r<D.

Then q≥1. Define, for k>0,

    L_0(k)=k+min(ceil(sqrt(k)),b),
    L_1(k)=k+min(Q(k),b+1),
    Q(k)=min{t≥1:k≤t(t−1)},

with both L_p(0)=0. Finally put J(0)=0, and for r>0 put

    J(r)=L_1(r/2)          if r is even,
    J(r)=L_0((r+1)/2)      if r is odd.

**Proposition.** There are physical strategies proving

    T_m≤2q                         if r=0;
    T_m≤2q+1                       if r>0 and 2J(r)≤m;
    T_m≤2q+2                       otherwise.             (1)

There is no extra parity penalty in the middle-day test: reflecting the
even long axis lets either physical initial cohort choose the favorable
relative phase independently.

## 1. Backward enlargement and erosion

A downward pyramid of relative phase p has virtual heights

    a_x=s_x−2+2k_x,    s_x=(p−x) mod 2,
    |a_(x+1)−a_x|=1,

for 0≤x≤2b. These encode parity prefixes in each longitudinal fiber;
an empty fiber has virtual height −2 or −1. If fiber i is empty then

    k_x≤ceil(|x−i|/2).

Let `f(t)=sum_(j=1)^t ceil(j/2)`. Its nondecreasing increments imply
`f(i)+f(2b−i)≤f(2b)=b(b+1)`. Thus a pyramid with more than b(b+1)
vertices has no empty fiber.

For such a pyramid A, lowering EVERY virtual height by one gives a
valid opposite-phase pyramid E, and every neighbor of E belongs to A.
In phase p, the number of vertices removed is the number of even
virtual heights, namely b+1−p. Therefore

    |E|=|A|−(b+1−p),       N(E)⊆A.                       (2)

Every pyramid can be enlarged to any larger prescribed cardinality up
to h by extending its ideal in the finite predecessor poset. In
particular, starting with any survivor R, enlarge it by m vertices to A
whenever |R|+m≤h. Its size is at least m>b(b+1), so (2) applies.

The rank `u(R)=2|R|+p` makes the phase-dependent erosion uniform. If E
is the earlier survivor obtained by this operation, then

    u(E)=u(R)+D.                                          (3)

Indeed its phase is 1−p, so the increment is
`2m−2(b+1−p)+(1−p)−p=2m−2b−1=D`.

## 2. The controlled final corner

There is a relative-phase-p downward pyramid of every size k with
neighborhood at most L_p(k). For the small branch, take the ordinary
quadrant prefix: even diagonals give k+ceil(sqrt(k)); odd diagonals give
k+Q(k). When this beats the respective plateau, its support and
neighbors fit inside the width w and the length n. For larger k,
any pyramid has surplus at most b in phase 0 and at most b+1 in phase
1. This follows from the rowwise height-change formula and the one-row
parity imbalance. Empty pyramids have empty neighborhood.

Since W is even and D is odd, q and r have the same parity. Choose the
terminal survivor R to have rank r+1. Thus its size and phase are

    (|R|,p)=(r/2,1)       when r is even;
    (|R|,p)=((r+1)/2,0)   when r is odd.

In either case `|N(R)|≤J(r)`. When r=0 use the empty phase-1 survivor;
its virtual phase is only bookkeeping for the backward construction.

Apply (3) backwards q−1 times. The resulting first survivor has rank

    r+1+(q−1)D=2h−2m

and phase 0. Enlarge it by m vertices one last time. Its size is h,
so that first pre-inspection envelope is the full relative-phase-0
class. All earlier requested cardinalities are at most h because these
ranks increase monotonically to 2h−2m before that last enlargement.

Reading the construction forwards, each day's designated inspection set
is A\R, of size m, and the actual survivors remain contained in R.
Equation (2) guarantees containment in the following pre-inspection
envelope. Thus q days of actual inspections leave the cohort, after the
following move, in an envelope of at most J(r) rooms.

If r=0 those q days already capture the cohort. If r>0 then J(r)≤m:
for r even, r/2≤m−b−1, and for r odd, (r+1)/2≤m−b−1. One additional
inspection therefore captures it.

## 3. Independent phase choice and the shared middle day

Reflection `y↦n−1−y` swaps physical colors because n is even. It also
changes a downward pyramid into an upward pyramid. Relative to that
new endpoint, the initial phase is again 0. Consequently the same
q-day half-construction is available for either physical starting color.

If a sequence Q_1,...,Q_q, started from a full color class, leaves all
possible rooms after the following move in X, then

    X,Q_q,...,Q_1

captures the appropriate full starting color. A surviving walk for the
reversed shots would reverse to a walk avoiding all the forward shots
and ending outside X, a contradiction. This works for containing
envelopes X as well as exact terminal beliefs.

Use a q-day half forward on one cohort and a second q-day half backward
on the other. Their two terminal neighborhood envelopes occur in
opposite physical colors on the shared middle day. If 2J(r)≤m, inspect
their union and obtain 2q+1 days. Otherwise concatenate the two
(q+1)-day solo captures. For r=0 concatenate two q-day captures. This
proves (1).

## 4. Proof boundary

This upper construction is uniform in b,L,m within its stated budget
range. A sharp lower bound still has to account for the forced change
of orientation of critical-b supports. The common static neighborhood
profile alone is insufficient for arbitrary physical multi-day play.
The sharp obstruction relevant to that lower bound is proved separately
in `uniform-odd-short-critical-frontiers.md`.

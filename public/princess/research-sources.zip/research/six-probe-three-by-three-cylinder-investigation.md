# Six probes on a 3 × 3 × n cylinder

Final reviewed status, 12 September 2026: **T_6(3 × 3 × n)=6n−8 for every even n≥4.** Root independently audited the all-length upper and lower proofs; all finite premises passed. No new Lean theorem is claimed. The initial checkpoint text below is preserved as a discovery log; the final lower proof supersedes its unresolved even-length status.

Research checkpoint, 12 September 2026. This bounded follow-up develops a new
all-even **upper bound**, one complete finite exact computation, and a specific
obstruction to a tempting global-prefix normal form. It does not establish an
all-length six-probe optimal-time theorem. No new Lean verification is claimed.

## Outcomes and proof boundary

For every even n ≥ 4, there is an explicit physical strategy with

    T_6(3 × 3 × n) ≤ 6n − 8.

The proof below uses the previously proved transverse 3 × 3 compression and
compatible global weightlex prefixes. At n = 4, an exhaustive unpruned search
of the full compressed state space proves T_6 = 16. Its witness is replayed
on the actual coordinate graph. The new finite computation has not yet had a
separate independent audit.

**Conjecture:** T_6 = 6n − 8 for every n ≥ 3. Finite exact odd-board recurrence
evaluations at n = 3,5,…,19 give 10,22,…,106. For even n = 4,6,…,20, the valid
history-bit relaxation from the five-probe theorem gives lower values
16,28,…,112. These finite values motivate the conjecture but are not a proof
for unbounded n. In particular, no all-length six-probe scalar potential has
been supplied here.

## Why a fixed global-prefix strategy loses a day

For every even n = 4,6,…,20 checked, the full two-cohort prefix recurrence gives
6n − 7 days, including when the two cohorts have independently reflected
orientations. The exact n = 4 game takes 16 rather than 17 days. Thus this
restricted strategy family cannot be assumed optimal at budget six.

The winning first-cohort slice counts are as follows. Counts refer to the four
successive longitudinal slices, and phase is physical checkerboard parity.

| Day | Phase | Before | After the probes |
| --- | --- | --- | --- |
| 1 | 1 | (4,5,4,5) | (4,5,2,1) |
| 2 | 0 | (5,4,5,2) | (5,4,1,0) |
| 3 | 1 | (4,5,4,1) | (4,4,0,0) |
| 4 | 0 | (5,4,4,0) | (5,2,0,0) |
| 5 | 1 | (4,5,2,0) | (4,1,0,0) |
| 6 | 0 | (5,4,1,0) | (4,0,0,0) |
| 7 | 1 | (4,4,0,0) | (2,0,0,0) |
| 8 | 0 | (4,2,0,0) | (0,0,0,0) |

The first two survivor sets are transverse slice prefixes but are not global
weightlex prefixes. Both have surplus four; this does not contradict the
previous no-consecutive-critical-survivors lemma, since the first survivor
has size 12, outside its critical interval [4,h−8] = [4,10].

## Uniform upper construction for every even length

Write n = 2L and h = 9L. Let the first cohort start in phase 1. In a phase-1
slice, the alternating full counts are (4,5,4,5,…). Retain

    R_1 = (4,5)^(L−1), 2,1

on day 1. Exactly six cells have been probed. Using the transverse neighborhood
profiles G_0 = (0,2,3,4,4,4), G_1 = (0,3,4,5,5), the next belief is

    (5,4)^(L−1), 5,2,

of size h−2. On day 2 retain

    R_2 = (5,4)^(L−1), 1,0.

Again exactly six cells are probed. The resulting phase-1 belief is

    A = (4,5)^(L−1), 4,1,

of size h−4.

From day 3 onward, retain the global weightlex prefix of size max(k−6,0),
where k is the current cohort size. This first prefix, of size h−10, is
contained in A. Indeed, the only missing cells of A are the four non-origin
phase-0 transverse cells in the last slice. They have total coordinate weight
at least n+1. Reflection in all three coordinates maps cells of weight at
least n+1 to the seven phase-0 cells of weight at most two; hence these four
missing cells lie among the seven largest-weight cells of the original
cohort. A prefix omitting ten cells avoids all of them. After this first
prefix move, prefix compatibility guarantees containment at every later
step.

For clarity, the exact compatible prefix profiles are the previously derived

    f_p(s) = s + U_p(s) − 4 + B_(1−p)(h−s),   s > 0,
    f_p(0) = 0.

Here U_0 has ranks (1,2,3,5,8) and increments (2,1,1,0,0), while U_1 has ranks
(1,2,4,6) and increments (2,1,1,0). B_p counts those ranks at most its argument.
For every phase-1 count k in {17,20,…,h−4}, the two full six-probe moves are

    k → k−1 → k−3.

All relevant U and B terms are saturated; the inequalities s ≥ 8 and h−s ≥ 10
suffice. Since h is a multiple of nine, (h−4) mod 3 = 2. Therefore these pairs
reach 14, after (h−18)/3 pairs. The final six days are exactly

    14 → 13 → 11 → 10 → 8 → 6 → 0.

Thus one cohort is cleared in

    2 + 2(h−18)/3 + 6 = 2h/3 − 4 = 3n−4

days. This duration is even. The other initial cohort remains full while the
first is processed, because every vertex has a neighbor in the opposite
color class. Reflecting the long coordinate converts its current phase 0 to
the virtual starting phase 1. Repeating the same strategy therefore clears
both cohorts in 6n−8 days.

This is an ordinary all-length construction proof, not extrapolation from
its finite replays. It has not yet received an independent review.

## Exact n = 4 computation and receipts

`src/six_probe_three_by_three_by_four_exact.py` enumerates every useful
six-probe allocation among all eight parity/slice counts. Successors use the
exact transverse-prefix neighborhood maximum, so the previously proved
compression theorem identifies its shortest path with the physical optimum.
It uses neither heuristic nor lower-profile pruning. Breadth-first search
finished after 4,550 expanded states, 4,583 seen states and 5,242,808 transitions
(13.84 CPU seconds), and reconstructed a 16-day physical schedule.

- `research/six-probe-three-by-three-by-four-exact.json`: complete finite search
  receipt and coordinate shots.
- `src/six_probe_even_cylinder_upper.py`: direct full-coordinate verifier for
  the new uniform upper construction.
- `research/six-probe-even-cylinder-upper.json`: physical replays at
  n = 4,6,8,10,12,20,30; every value equals 6n−8.

The only substantial new computation was the bounded n = 4 search. No n = 6
full-state search was attempted. The next mathematical target is a
history-sensitive scalar potential proving the uniform lower bound; the
all-even upper construction removes any need for a global-prefix optimality
claim.

## Matching all-even lower bound: explicit periodic potential

**Subsequent progress, 10:11 UTC:** Root supplied the successful charge vector
below. A short periodic potential now proves the matching lower bound for
**every even n ≥ 4**. Root independently audited and accepted the argument and the construction above; the earlier conjectural/lower-bound status above
records the initial five-minute checkpoint. No new Lean claim is made.

Let h = 9n/2. The geometric results established independently of the probe
budget in `even-three-by-three-cylinder-time.md` give the following valid
relaxation of each arbitrary physical cohort. A state is (k,e), where k is its
size and e indicates that the preceding survivor had surplus four and size
in [4,h−8]. The domains are 0 ≤ k ≤ h for e=0 and 8 ≤ k ≤ h−4 for e=1. The
initial state is (h,0). On p useful probes, put s=k−p. If s=0 the next state
is (0,0). Otherwise write

    g_h(s) = s + min(4,s+1,floor((h−s+2)/2)),   0<s<h,
    g_h(h) = h.

The next size y is at least g_h(s). Its next bit is one precisely when
4 ≤ s ≤ h−8 and y=s+4; two consecutive bits equal to one are forbidden by
the proved arbitrary-support compatibility lemma. Outside that case the
next bit is zero. These statements concern actual supports; no global
prefix hypothesis is used in this lower bound.

Assign each useful probe count its integer charge:

| p | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|---|
| c(p) | 0 | 0 | 0 | 1 | 1 | 2 | 2 |

For p+q ≤ 6, c(p)+c(q) ≤ 2. Define the potential by

    F_0(k), k=0,…,8:  (0,0,0,1,1,2,2,3,4),
    F_0(k) = min(floor(4k/3)−7, 4h/3−8),       k≥9,
    F_1(k) = floor((4k+2)/3)−7,                 8≤k≤h−4.

Each function is nondecreasing on its valid domain. We claim that every
allowed transition satisfies

    F_e(k) ≤ c(p) + F_(e')(y).                         (L)

It suffices to check the least y in each possible next-bit class, since
potentials are nondecreasing. The following argument proves (L) at every
allowed h, not merely the sampled values.

### Two finite bases and an unbounded translation argument

Exhaustive exact integer checks verify (L), including every allowed larger
y, at h=18 and h=27. They contain 1,095 and 3,174 transitions, respectively.
The exact enumerator and potential definition are in
`src/six_probe_even_cylinder_potential.py`; its receipt is
`research/six-probe-even-cylinder-potential.json`.

For an arbitrary remaining h, write h=27+Δ with Δ a nonnegative multiple of
nine, and split the source count into three exhaustive ranges.

1. **k ≤ 14.** Every nonempty survivor has s≤14, so its lower profile and
   critical status are identical to those at h=27. The minimum output in
   either bit class is at most 19. All potentials at these source/output
   counts are unchanged. Therefore the base-h=27 inequality applies.

2. **k ≥ 20+Δ.** Subtract Δ from both source and its minimum output, and
   subtract Δ from h. Since p≤6, s−Δ≥14. For s<h the lower profile is
   s+min(4,floor((h−s+2)/2)); the case s=h remains the full state. Both
   alternatives and the critical upper endpoint are preserved by keeping
   h−s fixed. Thus this transformation gives exactly an allowed h=27
   transition. The lower endpoint s≥4 is automatic. Both source and target
   are at least 14 after translation, so their potentials each decrease by
   exactly 4Δ/3, including the full-state cap. Apply the base inequality.

3. **15 ≤ k ≤ 19+Δ.** Here 9≤s≤h−8, so the only least-output branches are
   (0→1,y=s+4), (0→0,y=s+5), and (1→0,y=s+5). Their source and target
   potentials have the simple uncapped form

       F_e(k) = floor((4k+2e)/3)−7.

   The source is at most h−8 and the target at most h−3, so the cap cannot
   intervene. Maximizing its drop over the three possible values of k mod 3
   gives the following explicit table:

| Branch / p | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|---|
| 0→1 | −6 | −4 | −3 | −2 | 0 | 1 | 2 |
| 0→0 | −6 | −5 | −4 | −2 | −1 | 0 | 2 |
| 1→0 | −6 | −4 | −3 | −2 | 0 | 1 | 2 |

   Every entry is at most c(p). This proves (L) in the entire middle range.

The three cases cover all valid source states and all probe allocations.
Monotonicity extends the least-output inequalities to arbitrary larger
actual neighborhoods. The all-length proof is therefore complete once the
finite base tables have been checked; no asymptotic assumption is involved.

### Summing the two cohort potentials

Both initial cohorts have potential F_0(h)=4h/3−8. An actual day's probes
split into useful counts p and q with p+q≤6, so (L) bounds the combined
potential drop by two. At capture both potentials are zero. Hence

    2(4h/3−8) ≤ 2T,
    T ≥ 4h/3−8 = 6n−8.

Together with the explicit upper construction this gives the ordinary
proof of **T_6(3 × 3 × n)=6n−8 for every even n≥4**. The additive charge
insight is due to root's independent shortest-path experiment; the exact
potential formula, residue calculation, and all-length translation proof
are developed here. These are subsequent AI-assisted extensions, not part
of Angel's 2019–2020 path manuscript.

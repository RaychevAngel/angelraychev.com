"""Finite tests of proposed erosion-capacity merger inequalities."""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from resumed_odd_even_erosion_corners import low
from resumed_even_construction_formula_profile import F

def check(limit=20):
 high=lowcount=0;bad=[]
 for s in range(limit+1):
  for t in range(limit+1):
   for a in range(3):
    for b in range(3):
     f=F(a,b,s)
     if f<0:continue
     for aa in range(3):
      for bb in range(3):
       ff=F(aa,bb,t)
       if ff<0:continue
       target=F(min(2,a+aa),min(2,b+bb),s+t)
       assert target>=f+ff,(a,b,s,aa,bb,t,f,ff,target)
       high+=1
   for v in range(3):
    for j in range(3):
     for u in range(j+1):
      p=low(v,j,u,s)
      if p<0:continue
      for a in range(3):
       for b in range(3):
        f=F(a,b,t)
        for C in range(a,3):
         loss=max(t,b+C)
         if f<max(0,b+C-t) or p<=loss:continue
         target=low(max(0,v-b),max(0,j-a),max(0,u-C),s+t)
         lowcount+=1
         if target<p-loss:
          bad.append(dict(source=(v,j,u,s),high=(a,b,C,t),P=p,F=f,hole_loss=loss,target=target))
          if len(bad)>=8:return dict(status='FAILED',high_pairs=high,mixed_cases=lowcount,bad=bad)
 return dict(status='PASS',high_pairs=high,mixed_cases=lowcount,bad=bad)
if __name__=='__main__':
 start=time.process_time();result=check();result['CPU_seconds']=time.process_time()-start
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

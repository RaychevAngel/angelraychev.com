# Root audit of six inspections on even 3 × 3 × n

Accepted ordinary theorem: T6=6n-8 for every even n>=4.
Root independently found charges (0,0,0,1,1,2,2) and checked the final
potential with a separate exact enumerator:1095 inequalities at h18
and3174 at h27. Its first draft omitted the special full-support profile
value g_h(h)=h and therefore counted one too few transitions per base;
restoring that case gave the exact counts above, with every inequality
passing. No mathematical inequality failed.

For h=27+delta, low sources k<=14 have unchanged minimum outputs<=19.
High sources k>=20+delta translate to the base, with minimum outputs
minusdelta>=18. Both floor formulas and the full-state cap translate
by4delta/3. Middle sources have critical survivors9<=s<=h-8; their
branch drops are ceilings of(4p-18)/3 or(4p-20)/3, exactly the reported
rows. Monotonicity extends the check to all larger allowed outputs.

The upper construction was separately checked. The four cells missing
after two moves are among the seven largest-weight cells, so the required
prefix of size h-10 fits. The bulk pair and six-day tail give even solo
duration3n-4. Reflection gives the second cohort the required starting
phase. The underlying critical-survivor geometry is the already reviewed
arbitrary-support result and is independent of the daily budget.

This proof is not a complete Lean formalization. Odd lengths at budget6
remain a conjectural extension in the current research notes.

# Independent review of the all-budget eventual scalar criterion

13 September 2026. Root review of `maturation-odd-midpoint.md` Section 7.
**PASS as ordinary mathematics**, with the entry-bound wording corrected
from growth of an individual physical coordinate to growth of the maximum
solo capacity. The latter is exactly what the proof uses.

The explicit M* supplies a safe layer before capture and at least W
subsequent safe transitions. The maximum solo capacity is initially at
most J+G+m-1 there and grows by at most m per proper step. A first
capture cannot interrupt this argument: its predecessor's inverse
inputs are still strictly below the full endpoint. Monotonicity keeps
both capacities above J. The constants give the required upper safe
margin through the whole warm-up.

The existing age-erasure theorem is essential. A numerical bound on
min(x,y) alone does not identify the ancestry-secondary coordinate.
After W safe transitions every relevant mixed history has a recent
pure ancestor inside the safe interval, where the larger coordinate is
preserved by the exact affine rule. Thus ancestry and numerical role
agree at the end of the warm-up.

In the final collar a secondary of size at most K can next have size
at most K+m, since its inverse argument is proper (K+m<M). Were its
ancestry-primary to become at most K, the total would be at most
2K+m<J<=min D, so the mixed state would cease to be exceptional.
The universal numerical K bound then restores secondary<=K at every
exceptional successor. Pure births and persistence account for all
other histories. This proves alignment without a translation assumption
at the far corner.

The global fastest-ancestry lemma now makes two exceptional midpoint
states share their secondary color, leaving at least M-2K>m rooms there.
A pair with one nonexceptional state cannot beat the sum of the two solo
deficits. The physical midpoint theorem therefore gives the exact scalar
criterion. Only its sufficiency uses the opposite pure endpoints.

The conclusion holds at every feasible budget after the explicit onset,
not for all short odd rectangles. The existing O(width) solo-band
evaluation now computes the entire answer in this range. The antecedent
exact bounded-frontier solver remains necessary in the still-open short
intermediate-budget range. Nine focused comparisons, including a length
of 10^12+1, passed against that prior solver; see
`maturation-odd-eventual-scalar-check.json`.

The constants were subsequently sharpened with another root review.
At a positive proper inverse input z>=m>=2, the color-zero inverse
subtracts at least one and the color-one inverse subtracts at least two.
Coordinatewise monotonicity of the actual solo iteration therefore gives
D_0(t+1)-D_1(t+1)<=m-1 and the reverse difference<=m-2. Together with
the initial tie, Gamma=m-1 is a valid uniform gap bound. The bulk inverse
argument needs only H=b^2+1: with both arguments at least H and their
sum at most M, all lower and reflected root branches reach their caps.
The downstream finite-age and non-swapping proofs are unchanged with
these smaller constants. The new receipt
`maturation-odd-sharp-constants-check.json` independently compares nine
scalar cases and eight accelerated/daywise frontiers, all successfully.

# A universal height loop gives a small longitudinal period

12 September 2026. Root proposed the universal-loop argument, and the
frontier lane independently reconstructed the geometric conversion,
loop, congruence, and surgery interface. Euler then independently audited
all eight sections and accepted the complete ordinary proof. No Lean
proof is claimed.
The subsequent `even-bridge-height-descent-onset.md` removes the
finite-state enumeration entirely and strengthens the onset bound from
singly exponential to polynomial. The present loop argument remains
valid and is retained as the intermediate proof.
It sharpens the finite-cycle step in the two independently accepted notes
`even-bridge-eventual-periodicity.md` and
`even-bridge-odd-cylinder-eventual-periodicity.md`.

## 1. Statement and the precise inherited hypothesis

Let Q be a fixed bipartite Hamiltonian graph with A>=2 vertices. Fix an
integer m>A/2, and set

    D=2m-A,  g=gcd(A,D),  ell=2A/g,  Delta=2D/g.

In every longitudinal parity class covered by one of the two accepted
frontier theorems, there is an effective threshold N such that

    T_m(Q × P_(n+Delta)) = T_m(Q × P_n) + 2ell
                       = T_m(Q × P_n) + 4A/g

for n>=N in that class. Delta is even. The covered classes are all n if
A is even, and even n if A is odd. If Q is a transverse Cartesian box,
the already proved all-odd-cylinder theorem covers the remaining odd n
when A is odd, with this same period. Consequently the displayed
recurrence holds for all sufficiently large n for every fixed transverse
box. The singleton cross-section has its separate exact path result.

This does not compute the finite exceptional values or the offsets.
The displayed Delta is a valid period, not necessarily the least period.
At the smallest feasible fixed budget, Delta=2 and the time increment is
2A for even A and 4A for odd A.

The inherited result is stronger than an abstract finite-state graph:
every optimal sufficiently long strategy has two disjoint clean owner
crossings of a common protected physical band. During each crossing the
other cohort is globally empty or full, all m inspections are useful
inspections of the owner, the owner is a common one-sided frontier, and
all nonclean events remain outside the protected band. The number of
nonclean days and all front widths are bounded independently of n.
That complete physical reduction was proved and independently reviewed
in the two cited notes; it is not assumed for arbitrary initial states.

## 2. Convert every clean frontier to actual cutoff heights

Reflect the longitudinal axis if necessary, so the occupied tail is the
left tail. For each v in Q let a_v be the largest occupied longitudinal
coordinate of that cohort in the fiber over v. The physical parity of
a_v is prescribed by the current cohort phase and the color of v.
Inside a clean crossing all these cutoffs lie well away from both ends.

The exact frontier lemmas imply

    |a_u-a_v|=1 whenever uv is an edge of Q.                 (2.1)

For even A, the transverse matching contraction has one prefix cut c_i
for each matched pair. The two actual fiber cutoffs in that pair are
c_i-1 and c_i-2, in the order prescribed by parity. Its actual
neighborhood is the matched prefix through c_i, so the next cutoff in
each actual Q fiber is exactly a_v+1. A transverse edge uv therefore
forces a_u<=a_v+1, and reversing uv forces a_v<=a_u+1. The two cutoffs
have opposite parities, which gives (2.1). This checks all extra Q edges,
not just the edges of the selected Hamiltonian path.

For odd A and even n, write l_v for the occupied length in paired-column
coordinates and sigma_v in {0,1} for its actual longitudinal parity.
Then a_v=2(l_v-1)+sigma_v. In a minimum-surplus phase the boundary-free
color's l_v equals the other color's length or exceeds it by one;
sigma_v is zero on that color and one on the other. These two choices
give a height difference -1 or +1. In the alternate efficient phase the
colors are exchanged, and the same calculation applies. The separately
proved containment lemma is what guarantees this form in that phase.

Conversely, any proper nonempty one-sided fiber prefixes satisfying
(2.1) have actual neighborhood cutoffs exactly a_v+1. Longitudinal
movement supplies that cutoff, and a neighboring Q fiber can supply
nothing larger by (2.1). Thus the next neighborhood is obtained by
adding one to every height. All extra transverse edges are already
accounted for in this identity.

For right frontiers use reflected physical coordinates. The same
arguments then apply without a change of period.

## 3. Local flips and a legal word lowering every vertex once

A vertex v is a local maximum of a height configuration if all its
neighbors have height a_v-1. Replacing a_v by a_v-2 preserves (2.1) and
removes exactly the top room of that fiber. Call this a flip.

Order the A vertices by decreasing initial height, breaking equal-height
ties arbitrarily. Flip each vertex once in that order. When v is about
to be flipped, every initially higher neighbor has already been flipped
and now has height a_v-1; every initially lower neighbor is still
unflipped and also has height a_v-1. Adjacent heights are never equal.
Therefore each indicated flip is legal. The word lowers every height
by exactly two. It can be repeated indefinitely, because after one word
the relative heights are unchanged.

Adding the same integer to all heights does not change any local-maximum
test. We can consequently intersperse the global +1 movements between
groups of m flips without affecting the legality of this repeated word.
At an after-inspection survivor vertex, a daily transition is global +1
(movement) followed by m flips (the next inspection). Grouping the word
this way therefore gives an actual m-probe frontier strategy. Its flip
cells are distinct within a day because each flip removes a different
current top cell, even if the same fiber is flipped repeatedly.

More generally, every edge of the actual clean frontier graph consists
of a legal target height configuration obtained by deleting m rooms
after the global +1. It need not be represented by the particular word
above. All such edges lower the sum of heights by exactly D. The
universal word only supplies additional legal edges and loops.

## 4. The same short loop exists at every state

Since g divides both A and D, it also divides 2m=A+D. Repeat the A-flip
word 2m/g times and group its 2mA/g flips into m-flip days. This gives
ell=2A/g days. Every vertex is flipped 2m/g times, while ell global
movements add ell to every height. The final height is therefore

    a_v - 4m/g + 2A/g = a_v - Delta.

Both ell and Delta are even. Thus the physical cohort phase and every
relative height return to their initial values. At every normalized
frontier state there is a closed walk of length ell translating its
front uniformly toward clearance by Delta physical columns.

The word is valid within any sufficiently interior band: all intermediate
heights still satisfy (2.1), so their range is at most diam(Q), while
their mean decreases at the constant daily rate D/A. This also gives a
uniform spatial bound during the loop; no estimate proportional to its
number of individual flips is necessary.

## 5. Every closed walk has length divisible by ell

Normalize heights modulo a common even translation and record the
current physical phase. Fixing an orientation, there are at most

    M=2^A

states: along a spanning tree, A-1 choices of differences in {-1,+1}
determine all relative heights, and there are two phases. Cycle
constraints of Q only remove patterns. In the odd-order construction
the history bit is determined by phase and orientation (the surplus is
the size of the color whose longitudinal parity is odd), so no extra
history coordinate is needed in this graph.

If a closed walk has length t, then its phase returns and t is even.
Its endpoint is an even uniform translation of its start; write its
displacement toward clearance as 2s. The constant sum decrease gives

    2As=Dt.

Writing t=2r yields A | Dr, and hence A/g | r. Therefore ell | t.
In particular the universal loop has the least possible positive
closed-walk length. Every state belongs to a strongly connected
component with cyclicity exactly ell; global strong connectivity is
unnecessary.

## 6. Shorten any sufficiently long walk by exactly ell

Take any frontier walk of length t>=M. Delete closed subwalks until a
simple path of length p<=M-1 remains, with the same initial and final
normalized states. The removed length t-p is positive and divisible by
ell, since every removed closed walk has that divisibility. Insert

    (t-p-ell)/ell

copies of the universal loop at the start of the simple path. The result
is a legal walk with the same endpoint states and length exactly t-ell.
All occurrences of the universal loop begin at the same normalized
state, so there is no compatibility issue between repetitions.

Starting at the same actual heights, the shortened walk ends at heights
Delta larger than the original endpoint, because its total height loss
is D ell smaller. Starting it instead Delta lower makes its final
actual frontier exactly the original endpoint. This is precisely the
translation needed when Delta columns are deleted under a left-going
front. Reflection gives the right-going version.

To lengthen a walk, insert one universal loop. Starting Delta higher
then leaves the old endpoint unchanged. Every constructed intermediate
configuration has mean between its endpoint means and has range at most
diam(Q). Consequently replacing an old crossing segment cannot send a
front far outside its original endpoint interval: a fixed width margin
and the extra Delta columns suffice. This replaces the earlier removal
of many scattered cycles by a replacement path; that distinction is
essential to obtaining the small period.

## 7. Physical surgery and an effective threshold

Use the already proved protected-band construction, with enough room
for a central owner segment of at least M edges and with all its fronts
farther than Delta+diam(Q)+2 from the outer band ends. The finite speed
and marking argument permits any prescribed band length once n is
sufficiently large. The same simple counting bounds therefore give an
effective N.

In each of the two disjoint owner crossings replace such a segment by
the shortened walk of Section 6, and delete Delta physical columns.
Translate cuts with their filled or empty tails, exactly as in the
accepted surgery proofs. Outside the crossing, all protected regions are
uniformly full or empty and no nonclean inspection occurs nearby, so
neighborhood formation commutes with the column deletion. Inside it,
Section 6 provides legal actual frontier transitions and the correct
endpoint translation. The companion cohort is globally full or empty.
Since ell and Delta are even, both temporal and spatial parity match.
The edges are movement followed by inspection, so removing ell edges
removes exactly ell inspection days from that owner crossing.

This proves T(n-Delta)<=T(n)-2ell. Inserting the universal loop in each
crossing and inserting Delta columns proves the reverse inequality.
Thus the desired exact eventual recurrence follows.

For explicit constants one may retain the two accepted notes' values
of K, B, E, F, and rho. Replace their cycle length by ell, physical
displacement by Delta (paired displacement Delta/2 in the odd-order
note), state bound by M=2^A, and their long-walk allowance by
H=M+ell+4. Enlarge their width parameter to at least A+2. Their displayed
W and threshold formulas then have all the required margins, with a
central segment longer than M. These formulas are singly exponential
in A and polynomial in m. The earlier lcm-based constants remain valid
but are unnecessary.

## 8. Boundary of the improvement

The small valid period is independent of the number of admissible
frontier shapes. The threshold and finite-state enumeration still have
an exponential bound in the transverse order A. The theorem remains a
fixed-cross-section result, not a uniform solution for cubes with every
side growing. It neither proves that every optimal finite strategy is
a pure frontier sweep nor makes the refuted arbitrary-start prefix
normal forms true.

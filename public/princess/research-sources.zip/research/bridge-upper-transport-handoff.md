# Upper-bridge research handoff

13 September 2026. Work is paused at the parent's request for consolidation
and independent geometry review. No search remains running. All edits in this
lane are confined to `src/bridge_upper_transport*.py` and
`research/bridge-upper-transport*.md/json`, plus the subsequently authorized
new manuscript section `paper/sections/bridge-uniform-upper.tex`.

## Uniform mathematics delivered

The main proof source is `research/bridge-upper-transport.md`.

1. The descending transport word has an exact physical scheduling criterion:
   a window `0<=i<=j<t` must have at most `k(j-i+1)` letters whose unshifted
   heights lie in `[-j,n-i-1]`. Empty words and zero paid quota are included.
   For even width `2r`, canonical endpoints and `k>=r`, this is equivalent
   to the existing `F_t<=kt+z(B)`. Thus time-sensitive visibility supplies
   no additional credit for that prescribed word at feasible budgets.
2. On every `2r` by `n` board, `r>=5,n>=2r,k=r+1`, the explicit sizes
   `Q_A=r(n-r)+2r-2`, `Q_B=r(n-r)+3` and bridge time `2r-5` produce an
   always-defined prefix/transport/prefix strategy. The entrance stops in
   phase `(n+1) mod2` at size `Q_A` or `Q_A-1`; the target is the right
   prefix in phase `n mod2`. No splice-index optimization is required.
3. This construction satisfies the exact solo length law
   `L_(r,p0)(n+2)=L_(r,p0)(n)+2r`, and preserves the final inspection size.
   Its full bound is therefore `2rn-C_(r,n mod2)`, with width constants
   still defined by deterministic prefix clocks at lengths `2r,2r+1`.

These are upper constructions and a fixed-word no-improvement theorem.
They do not identify the physical optimum at every parameter, classify
arbitrary partial-state values, or evaluate the remaining width clocks in
a fixed number of numerical operations. The new upper can be minimized
with earlier valid upper bounds; it is worse than the known optimum at
some inputs, including10x10.

## Reproduction and receipts

- `python3 src/bridge_upper_transport.py --audit`:500 comparisons with an
  independent fixed-word day-partition DP, including literal physical replay.
- `python3 src/bridge_upper_transport.py --balanced-audit`:19,080 plateau
  values,608 endpoint pairs through width160, and34 literal full-board
  replays on17 boards. Summary:
  `research/bridge-upper-transport-uniform-audit.json`.
- The per-board `bridge-upper-transport-uniform-WxN.json` receipts contain
  the actual solo and full-board inspections, including central-day mergers.
- `research/bridge-upper-transport-length-audit.json`:both initial phases
  at12 base lengths compared against length plus four, with literal replay.

The upper witnesses match the parent's independent critical-model lower
on12x12,12x14,14x14,14x15,16x16,16x18,and32x32. The new notable certificates
are112,144,and308 for the last three corresponding even-square/near-square
cases. Root owns the final lower verification and exact-result statements.

## Precisely what remains on width24

The uniform construction gives `24n-369` for even `n` and `24n-368` for odd
`n`. The separate lower lane has advanced a uniform `24n-370` lower.
On24x24 the exact interval remains206--207; solo remains103--104.

Both initial corner phases were checked for every deterministic
prefix/descending-transport/prefix splice at the103-day solo target:
5,253 pairs per phase, no success, best budget slack -1. This is a
restricted-family exclusion only. The older102-day diagnostic does not
address the corrected target and must not be cited as such.

Further bounded upper attempts, now stopped:

-250 endpoint pairs with four alternative legal-flip orders, and separately
  five rules with physical recanonicalization each day: no103-day witness.
- A backward beam of32 physical capturable pyramids per phase constructed
  23,752 candidate targets across all tail lengths in9.32seconds. Each
  target had an actual capture suffix; no target joined a deterministic
  entrance within103 days. Best transport slack remained -1. Source:
  `src/bridge_upper_transport_backward.py`; receipt:
  `research/bridge-upper-transport-backward-24x24-k13-t103-b32.json`.
- The two known177-room anchored beliefs reached after28 days were each
  attacked by the existing all-downward-pyramid solver for a75-day tail,
  capped at10seconds. Neither found a witness or exhausted its search.
  Receipts: `bridge-upper-transport-partial177-p0.json` and `...-p1.json`.

None of these failures proves a physical lower bound. In particular the
bounded DFS failed-state counts are not complete impossibility certificates.

## A finite day28 family worth preserving

The numeric lane's exact forward28/backward75 critical-model intersection
allows only `(177,1),(177,2),(178,2)` after the physical177-room restriction.
Thus it is incorrect to assume that every103-day model path passes through
177 rooms with one corner.

For downward pyramids on the24-square, the two-corner alternatives have an
especially simple geometry. In physical phase0, both own-colored corners
being present forces `a_23=23`, whence the height-walk condition gives
`a_x>=x`. Complementing the support and reflecting vertically gives a
phase1 downward pyramid with heights

    u_x=21-a_x <=21-x.

It lies in the132-room odd corner triangle on diagonals1,3,...,21.
The phase1 case is the horizontal reflection of this argument. Therefore
the two-corner alternatives correspond, up to symmetry, to deleting21 or22
rooms from that triangle. Exact local-maximum-deletion enumeration gives
76 and89 resulting pyramids, respectively. The165 candidates, their
neighborhoods, and complementary belief heights are stored in
`research/bridge-upper-transport-day28-pronic-candidates.json`.

Every candidate passes the coarse reverse28-day requirement
`|N(U)|<=123`; cardinality alone does not prune the family. To turn this
reduction into a full-start lower argument, explicitly invoke the accepted
simultaneous square strategy compression for the *whole history*, then
check every surviving candidate with sound arrival and remaining-time
conditions. Do not compress a complement and assume the required strategy
comparison direction without that history argument.

The one-corner alternative is not automatically a121-triangle case:
`|U|=111` and `|N(U)|<=123` permit surplus12. The near-square theorem with
surplus11 applies only after obtaining the sharper `|N(U)|=122` condition.

## Why repairing only the last central days cannot fix the known witness

For any even-horizon strategy with two middle inspection days, let `F` be
the possible rooms before the first middle day from its fixed prefix, and
let `B` be the analogous reverse possible rooms before the second middle
day. A fixed perfect matching of the board gives at least

    |F|+|B|-|V|

disjoint time-layer edges between these sets. The two inspections must
cover these edges, and each inspected time-layer vertex covers at most
one. A necessary condition is therefore `|F|+|B|-|V|<=2k`.

The known104-day solo witness leaves14 rooms after102 steps. Its proposed
206-day palindrome with only a two-day central repair would have
`|F|=|B|=288+14=302`; it needs at least28 middle inspections, exceeding26.
Thus that repair requires changing the earlier histories. This argument
does not exclude all206-day strategies: the current unrestricted lower
only forces297 rooms at that split, which gives18 matching edges.

## Restart criteria

Prefer a new uniform geometry or arrival restriction over enlarging the
same bounded searches. A useful next certificate would either construct a
103-day solo history through a genuinely new intermediate shape, establish
an admissible206-day joint-cohort strategy, or rule out every relevant
day28 arrival/75-day-tail combination with a verified compression/history
argument. The new near-square successor geometry from the lower lane is
the current independent-review target.

## Independent review of the new forbidden successor

Reviewed `research/bridge-lower-frontier-near-square-slack.md` after its
whole-triangle strengthening. The strongest physical forbidden-successor
corollary and both merger identity arguments are sound. Specifically:

- On diagonal `2j` the outside-half-plane count is
  `min(2j+1,j+z)`. Thus `C(r,1)=r(r+1)/2`; subtracting at most `r-1`
  missing rooms gives `r(r-1)/2+1>=2`.
- On odd width/even length the opposite-colored anchor is either adjacent
  along the even long side, where `n>=2b+2` gives `z>=1`, or diagonal,
  where the two radius bounds leave a gap of at least four. There is no
  adjacent opposite-colored anchor across the short side.
- The complement inclusion gives available slack at most `ell-s=1`.
  A projected maximal corner-retention count can be reconciled with the
  actual count: strict hole size `D>s(s-1)` forces physical surplus at
  least `s`, while any smaller actual retention count would force a
  closed upper bound at most `s-1`.
- At the second merger, zero closed surplus cannot belong to the flagged
  component: it would require survivor size `h-1`, exceeding its source
  size at most `h-3`. The other component is therefore a genuine
  original-full-to-full action, and the merger is the identity on the
  flagged physical component.

This review adds no capture-time claim beyond the source's proved flag
restriction and merger closure. It does not make the flagged lower model
exact or improve the width24 interval by itself.

## 25x26 closure and independent radius audit

The physical eight-order prefix construction at budget13 takes188 solo
days and ends with the two inspected rooms `(0,1),(1,0)`. Reflecting in
the even long direction, joining the two final shots into one four-room
shot, and reversing the reflected earlier shots gives375 full-board days.
Every inspection and the literal full650-room replay is saved in
`bridge-upper-transport-25x26-prefix.json`. This corrects the previously
used upper376; there is no parity obstacle to this reflection.

The independent verifier `src/bridge_upper_transport_verify_reach.py`
confirms the persistent two-radius necessary-model clock with ONLY
subcritical square triggers `r=2,...,11`. It groups equal-radius states
into bitsets and performs exact breadth-first propagation; it makes no
dominance comparisons between different radii. The cached weighted base
graph and reviewed flag construction are reused, so this is an
independent evaluator check, not a second proof of the geometric premises.
It explores276525 augmented states, with141443639 feature-permitted
directed transitions, in0.232 CPU seconds. First capture occurs188 days
from the full start, and minimum size before that deadline is2. The
resulting full lower375 matches the literal upper. The receipt
`bridge-upper-transport-persistent-verified.json` records all layer minima,
counts, source hashes, and the exact subcritical trigger scope.

The original evaluator's dominance also passes review: larger radii at
the same base feature admit every continuation of smaller radii, since
the feature bounds, propagation and trigger minima are monotone. BFS
ensures the dominating state is reached no later. Its reported residual
is the minimum over ALL accepted depths before first capture, which is
a valid conservative deadline residual; its label need not be read as
the minimum on the exact final noncapture layer.

## Correction to critical exact-square localization

The critical nonseparator pair `(i,j)=(1,0)` has capacity `b²`, not
`b(b-1)`. It cannot be excluded at square equality. Nevertheless its
equality is rigid. Place the empty endpoint at transverse coordinate2b.
The proof of the critical corner dichotomy gives

    t_(2q) <= b-q,       |R_(2q+1)| <= b-q-1.

These bounds sum to `b²`; equality forces every fiber to attain its
bound. Each odd fiber is contained in its shorter neighboring even
prefix and has the same size, so it equals that prefix. Under the
physical mapping `(x,j) -> (x,2j+(x mod2))`, the resulting set is exactly
the square corner triangle `x+y<=2b-2`. The other endpoint is obtained by
reflection. Thus the critical equality localization is repaired without
assuming that arbitrary odd fibers were initially prefixes. The finite
375 lower above already avoids this issue by using subcritical triggers.

The persistent-radius merger invariant and the corrected physical radius
caps were independently checked. For relative anchor color0 the bounds
are `c<=1+[R>=w-1]`, `e<=[R>=n]+[R>=w+n-3]`; for color1 they are
`c<=[R>=n-1]+[R>=w+n-2]`, `e<=[R>=1]+[R>=w]`. An adjacent corner's
neighbors have distances `D-1,D+1`, whereas a diagonally opposite
corner's two neighbors both have distance `D-1`.

# A shorter uniform onset for the exact odd-board midpoint

13 September 2026. Ordinary ancestry argument independently reviewed and
accepted by root. The audit checks concentration, wrong-ancestry orientation,
proper expansive inputs, the bottom transfer, capped root debt, first-entry
and capture indexing, and the final shared-color obstruction. This is a sufficient all-length region, not an all-parameter
midpoint theorem and not an equality of arbitrary partial-state frontiers.

Let w=2b+1, n>=w odd, b>=2, b+1<=m<M, and write E=M+1 for the two
color-class sizes. Use the accepted constants

    H=b^2+1,  G=m-1,
    K=b^2+2m*(floor(G/w)+1).

The accepted concentration and bounded-frontier theorems give, at every
proper solo layer with capacities A>=B, the bounds

    total deficit <= A,  A-B <= G,
    min(x,y) <= K  for every retained mixed exception.

Define the explicit integers

    J0=2K+m+1,
    W=ceil(max(0,G-b^2)/b)+2*min(b,ceil(sqrt(G))),
    M_new=J0+G+m*(W+1).

Then whenever M>=M_new the full physical time is exactly

    T=2tau-1  if E+M-D_0(tau-1)-D_1(tau-1)<=m,
      2tau    otherwise.

For the remaining intermediate budgets m<=b^2, the simpler expression
W=2*ceil(sqrt(m-1)) applies. At m=b+c for a fixed positive c, this onset
is 2b^2+O(b^(3/2)), whereas the previous sufficient onset grew cubically
in b. The statement follows from the ordinary proof below; finite checks
are only implementation audits.

## 1. Numerical orientation is preserved above J0

At a layer with B>=J0, every retained mixed exception has a unique larger
coordinate a>K and smaller coordinate k<=K. Indeed a+k>B and B>2K.
Label the larger coordinate by its initial cohort, following its physical
color under each move. Its current value is

    a>=B+1-K>=K+m+2>H.

On the next step the other coordinate is at most K+m. If the labelled
coordinate became at most K, the new total would be at most2K+m<J0.
Since the smaller solo capacity is nondecreasing, such a successor would
not be exceptional. Every surviving mixed exception therefore still has
the labelled coordinate greater than K. The numerical minimum bound then
forces its other coordinate to be at most K. Thus the larger-coordinate
label cannot swap along a surviving exceptional history in this region.

Fresh mixed births from pure solo endpoints have their numerical larger
coordinate in their ancestry-primary cohort: the old pure coordinate
exceeds K+m, whereas the newly born coordinate is at most m. Accepted
fastest ancestry also ensures that an exceptional birth uses the faster
initial cohort. A change of faster initial cohort erases a surviving
mixed exceptional history, as in the accepted reset argument.

## 2. A wrong orientation has a shrinking negative difference

Call an exception wrongly oriented when its numerical larger coordinate
is its ancestry-secondary cohort. By fastest ancestry, that numerical
larger coordinate is in the slower solo cohort. If its solo capacity is
D_j=B, put

    ell=D_j-a>=0,  F=ell-k=D_j-(a+k).

Total concentration and exceptionality give the particularly strong bounds

    -G <= B-A <= F < 0.                              (1)

This uses the total bound a+k<=A; replacing (1) by the old coarse bound
F>=-K needlessly lengthens the previous warm-up argument.

Allocate q probes to the smaller coordinate and m-q to the larger.
The latter inverse input is at least H. Both the actual larger input and
its corresponding solo input are proper before tau. The accepted expansive
inverse inequality above the lower-root collar therefore gives

    ell' >= ell+q.                                  (2)

For clarity, this is the same inequality as in the accepted expansive
primary exchange, but the label here is the numerical larger coordinate;
it need not be the ancestry-primary. The inequality itself only requires
the lower bound H on its input.

The smaller coordinate is a bottom process. Before every step ending
before tau, the total input is at most M. Subtracting the larger input,
which is at least H, leaves smaller input z=k+q<=M-H. On this range the
finite-board inverse equals the bottom inverse. If its output k' is
positive, the least input attaining k' is its lower profile, so

    z-k' >= min(ceil(sqrt(k')),b).                    (3)

For physical color zero this is the square-root lower profile. For color
one it follows from ceil(sqrt(k'))<=rho(k')+1. Equations (2)--(3) imply

    F' >= F+min(ceil(sqrt(k')),b).                    (4)

If the successor is still wrongly oriented, it again has F'<0 and
ell'>=0, hence k'>=-F'. Writing v=-F and v'=-F', (4) gives

    1<=v' <= v-min(ceil(sqrt(v')),b),  1<=v<=G.       (5)

## 3. Root arithmetic bounds the lifetime by W

Put q0=ceil(max(0,G-b^2)/b). If v stays above b^2 for q0 successive
updates, each of them decreases it by at least b, which contradicts its
being above b^2 at the last update. Thus after at most q0 updates it is
at most b^2, unless the wrong exception has already disappeared.

For 1<=r<=b, a value v<=r^2 cannot stay above (r-1)^2 for two further
updates. If it did, both new values would have square-root ceiling r;
(5) would give the second value at most r^2-2r<(r-1)^2, a contradiction.
Consequently each two updates remove one square-root level. Starting at
v<=G<=b^2 takes at most2*ceil(sqrt(G)) updates; starting above b^2 takes
at most q0+2b. This is exactly the stated W. After W updates a wrongly
oriented exception cannot remain mixed and exceptional.

This proof counts actual consecutive ancestry transitions. It does not
assume a fixed transfer matrix or that arbitrary synthetic capacities
arise on a full-start solo trajectory.

## 4. The stated board size supplies the required time

Let t0 be the first time when both solo capacities are at least J0.
It exists before capture under M>=M_new: if the smaller capacity were
below J0, the larger would be at most J0+G-1, and its next inverse input
would be at most J0+G+m-1<M, ruling out capture from that source layer.

At entry the larger capacity is at most J0+G+m-1. A proper inverse output
is at most its input, so after s further moves its maximum is at most

    J0+G+m-1+ms <= M-1,  0<=s<=W.

These layers all precede tau. To avoid assuming properness circularly,
consider a putative first captured layer in this range: the same estimate
bounds every input at that step by M-1, whereas the first saturated-input
threshold is M. Thus capture is impossible there. Both capacities remain
at least J0 by monotonicity.

Any wrongly oriented retained exception present at t0 dies by t0+W.
It cannot be replaced by a new wrong birth, and Section1 excludes an
orientation swap by a surviving exception. Therefore at t0+W and at
every later proper layer all retained exceptions have ancestry-secondary
at most K. At the precentral deadline they all share the same physical
secondary color by fastest ancestry. Two such histories leave at least

    M-2K >= m+1

rooms in that color and cannot win centrally. Pairs involving a
nonexceptional state have total deficit at most D_0+D_1 and cannot improve
the scalar central decision. The pure endpoints provide sufficiency,
proving the displayed exact full-board formula.

## Numerical endpoint and scope

For every fixed odd width, a possible failure of scalar midpoint necessity
is confined to a much smaller finite set of lengths. On the intermediate
budget interval b+2<=m<=b^2, all terms of M_new are nondecreasing in m.
At m=b^2 one has

    floor((b^2-1)/(2b+1))=floor((b-1)/2),
    K=b^2*(b+1+indicator(b odd)),  W=2b,
    M_new=b^2*(4b+5+2*indicator(b odd)).

The floor identity follows by division separately for b=2u and b=2u+1;
also (b-1)^2<b^2-1<=b^2 for b>=2. Hence, using the already accepted
minimum-budget and high-budget scalar theorems, ANY counterexample at
width w=2b+1 must have

    M < b^2*(4b+5+2*indicator(b odd)).

In particular only n=O(b^2) can remain at that width, improving the
previous O(b^4) length bound. This is an ordinary finite-reduction
statement. Enumerating that finite set would not be an absolute bounded
numerical expression when the width varies.

Combining this theorem with the accepted fixed K=16 solo evaluator gives
an absolute bounded expression for T throughout

    16(2m-w)>=b^2  and  M>=M_new.

It uses the same four 49-block evaluations as the earlier, much smaller
explicit numerical region. The new ancestry argument requires no mixed
frontier computation. Its input-dependent W only establishes that a
sufficiently long interval exists; it is not iterated to evaluate T.

Source dependencies: concentration, gap, minimum-coordinate bound and
fastest ancestry in `paper/sections/bounded-odd-frontier.tex`; the expansive
inverse and bottom-transfer proof in Section13 of
`research/maturation-odd-midpoint.md`; reset retention details in
`research/bridge-odd-clock-reset.md`.

The bounded implementation audit `src/bridge_odd_clock_orientation_onset.py`
checks twelve first-admissible odd lengths against the accepted exact joint
solver and checks the maximal relaxed debt lifetime independently. All pass
in0.156 CPU seconds; receipt
`research/bridge-odd-clock-orientation-onset-check.json`. For example at
w=81,m=42 the sufficient M threshold falls from82851 to4082, giving the
exact scalar decision for every odd n>=101. This example does not satisfy
the additional fixed K16 numerical inequality; its solo clocks still use
the accepted O(width) evaluation. At w=11,m=7 the new threshold is141,
so every odd n>=27 is covered and the fixed K16 expression also applies.

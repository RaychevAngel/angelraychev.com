# Near-pronic intervals at every subcritical radius

13 September 2026. Proposed ordinary theorem and proof, submitted to the
parent for independent review. No Lean formalization or full capture-time
classification is claimed.

## Statement

Let w=2b+1>=5, n>=w be even, h=wn/2, and 2<=r<=b. Put

    D_r=max(r(r-1)/2,r(r-2)),     C_r=r(r-1).

If a one-color physical support U has no own-colored corner and satisfies

    D_r<|U|<=C_r,    |N(U)|-|U|<=r,

then U is connected under sharing a neighbor, its surplus is exactly r,
N(U) contains exactly one opposite-colored corner o, and every room of U
has Manhattan distance at most2r-3 from o.

Consequently, if S is a physical survivor and B=N(S), then

    c(B)=2, D_r<h-|B|<=C_r, |B|-|S|<=r

implies

    |B|-|S|=r,     (c(S),e(S),e(B))=(1,2,1).

Here c counts own-colored board corners and e counts opposite-colored
corners whose two neighbors lie in the support.

## Localization proof

The accepted finite-board corner theorem applies at every surplus<=r.
At r=b its critical exception has positive current-corner count, so it
does not occur for U or for any sharing-neighbor component U_i. Each U_i
has size<=C_r and surplus s_i<=r. The large branch is impossible because

    h-|U_i|-s_i >= h-r^2 > r^2 >= G_(0,j)(s_i).

Indeed h>2b^2>=2r^2 on the stated odd-width/even-length boards. Therefore
each nonempty U_i obeys |U_i|<=s_i(s_i-1), hence s_i>=2. Distinct such
components have disjoint neighborhoods, so their sizes and surpluses add.
If at least two occur, convex allocation with each positive surplus>=2
gives

    |U| <= (r-2)(r-3)+2 <= D_r   (r>=4).

For r=2,3 two components would require surplus>=4>r. This proves
connectedness. If total surplus<=r-1, the same single-piece bound gives

    |U| <= (r-1)(r-2) <= D_r,

again impossible. Surplus is exactly r. The small capacities F00(r)=D_r
and F02(r)<=D_r exclude outgoing corner counts0 and2, leaving exactly one.

For r<b, the accepted subcritical separator proof places the small-side
support in genuine corner quadrants. Connectedness places it entirely in
one quadrant, based at o. For r=b, use the already proved critical
near-pronic localization argument: its alternating-fiber case with no
current corner has outgoing count0 and capacity at most r(r-1)/2<=D_r,
and is excluded; the remaining geometric separator is available. No
compression normal form for the original support is assumed.

Touching o means diagonal1 is occupied. A sharing-neighbor step changes
the distance from o by at most2. Thus the occupied odd diagonals are
1,3,...,2L-1, with no gaps. The upper shadow of each nonempty diagonal
has at least one more room; these upper-shadow diagonals are disjoint,
and the origin adds one further room. Therefore

    |N(U)| >= |U|+L+1,     L<=r-1.

This proves radius<=2r-3. It uses the same original-support upper-shadow
argument as the accepted critical theorem.

## Dual feature proof

Set U=V_opposite minus B. Its neighborhood lies in V_current minus S,
so its surplus is at most s=|B|-|S|<=r. Localization forces its surplus
to equal r; hence s=r and N(U)=V_current minus S. The one corner in
N(U) gives c(S)=1. Also N^2(U) lies within distance2r-1 of o. A board
corner of the opposite color from o is at distance at least n-1>=2b+1,
so neither of the two such corners lies in N^2(U). Both corresponding
neighbor pairs therefore lie in S, yielding e(S)=2. Finally
E(B)=V_current minus N(U)=S, giving e(B)=c(S)=1.

In particular two consecutive transitions cannot both satisfy a band
rule, even at DIFFERENT radii: the first leaves e(B)=1, while the next
requires a survivor with erosion count2. Deletion cannot increase e.

## Inheritance by the stated weakened merger model

Retain exactly the necessary model and its two positive-cardinality
relaxations in `resumed-erosion-merger-proof.md`. Consider a merged
transition triggering an r-band rule. Its outgoing corner count J=2
forces j1=j2=2. Its two nonnegative hole sizes d1,d2 sum to a quantity
in(D_r,C_r]. Each is therefore at most C_r.

A component cannot use its small closed branch: for positive outgoing
corner count the existing capacity gives x_l<=sigma_l(sigma_l-1), so
its target size is at most sigma_l^2<=r^2. Its holes would then be at
least h-r^2>C_r, a contradiction. The critical exception has outgoing
count0, also impossible. Both components use high branches. Thus

    d_l <= F_(0,2-v_l)(sigma_l) <= s_l(s_l-1).

Here sigma_l is closed surplus, 0<=sigma_l<=s_l, and s1+s2<=r. If both
original surpluses are positive, convex allocation gives

    d1+d2 <= s1(s1-1)+s2(s2-1)
           <= (r-1)(r-2) <= D_r,

contradicting the trigger. Therefore one original surplus is zero. The
unconditional size profile, nonempty merged survivor, and unchanged
feature upper bounds force that component to be a zero-cost original
full-to-full action. The merged transition is the identity on the other
component. Its physical/necessary r-band rule transfers the entire
triple(1,2,1) and surplus r.

This proves simultaneous closure under all the proposed r-band filters.
No new memory state is needed. The existing guarded merger and its
penultimate-residual corollary would therefore apply after review.

## Finite-test encoding and limits

For any allowed edge with actual surplus s, the all-radius filter can be
implemented as

    if 2<=s<=b and c(B)=2 and D_s<h-|B|<=s(s-1):
        require (c(S),e(S),e(B))=(1,2,1).

The apparent omitted r>s cases are already impossible in the old model:
the small/critical branches are excluded as above, while its high branch
would give holes<=s(s-1)<=(r-1)(r-2)<=D_r. Thus this code condition
retains exactly the extra all-radius restrictions, not only a subset of
their triggers. The source is isolated in `bridge_lower_frontier_probe.py`.

This theorem strengthens the model uniformly. It does not imply that its
full-start clock matches the explicit construction, prove a fixed-size
formula for that clock, or physically realize arbitrary model states.

# Scope separation: artifact policy

This is artifact maintenance, not resumed mathematical research.

- One canonical Lean source directory; import-closed main and parked packages.
- Main: rectangles with constant budget and full initial uncertainty.
- Shared: generic tools actually reused by both scopes or their artifact infrastructure.
- Parked: independent box/cube applications and general-cylinder conclusions.
- Fixed deadline at constant budget is an inverse parameterization of the same rectangle relation. Its rectangle theorem and proof remain in the main manuscript.
- General partial-state or varying-quota lemmas remain in the main proof when required. Package placement does not create an obligation to classify arbitrary starts or budget words.
- Source-specific original Lean receipt retained; only source-hash and import-closure checks are new. No new compilation or formal theorem is claimed.
- The historical combined PDF, source archives, release metadata, formal receipt and proof HTML remain immutable under archive/2026-09-13-combined.
- Public mathematical research packages use explicit file membership in publication/artifact-manifest.json. Private intake and authorship discussions remain private.
- Manuscript packages compile independently. The parked PDF may use the main PDF's frozen .aux only to resolve cross-document theorem numbers; this external-reference dependency is described in its artifact guide.
- Old main proof anchors for moved results have named legacy links to their new companion location. Public canonical Lean URLs remain stable; scope comes from membership manifests, not the URL prefix.

# Independent review of the reconstructed path lower bound

Reviewed 11 September 2026 by the agent that separately reconstructed the upper strategy. This review concerns `research/path-lower-bound-audit.md`, read in full. It is an independent mathematical reading, not a Lean verification and not merely a repetition of the original finite checks.

## Verdict

I found **no substantive gap** in the reconstructed lower bound. In particular, the delicate odd-path high-pair lemma, the exceptional-residue balancing, and the small-board boundary `n=3m` for odd `m` withstand the attacks below. Combined with the separate indexed construction proof, the two reconstructions give an ordinary all-parameter proof of the intended path formula. Formal verification still remains outstanding for the graph geometry and lower-bound combinatorics.

## Checks that could have broken the proof

### Component identity and disconnected supports

For a parity subset, distinct maximal parity intervals have disjoint neighborhoods: if one ends at `a`, the next starts at least at `a+4`, so their closest neighbors are `a+1` and `a+3`. Thus `|N(R)|-|R|=c(R)-e(R)` is valid even for disconnected supports. On odd paths, negative surplus `-1` really does force the *entire* large parity: a proper subset containing both endpoints has at least two components. This excludes a hidden exceptional decrement from a fragmented partial belief.

### Odd-path high-pair lemma

Suppose the first round of a proposed high pair begins with a full large-parity color. After that round, this color has more than `m` vertices in the small parity, whether it was untouched or probed. It therefore cannot be eliminated next, and contributes at most `p-1` to the next decrement. Making that next round high forces the other color to have surplus decrease `+1`, hence to be untouched and full in the large parity. That color must have grown from at most `h` positions to `h+1` on the preceding round, contributing at most `-1`. The first color contributed at most `max(p,1)<=m` then. Hence the preceding total is at most `m-1`, a contradiction.

If neither color was full in the large parity at the start, attaining a high decrement forces elimination of the small-parity color. The only possible following high eliminates the surviving color and ends the game. This argument also covers an already empty class. No unstated assumption of nonnegative decrements or permanence of a partial state is used.

### Even-path high runs and equality balancing

For even paths, equality in the neighborhood count leaves a proper surviving parity interval away from its next parity's endpoint. A second equality therefore eliminates that class. If a full class receives a positive probe batch, the size hypothesis `n/2>2m` prevents eliminating it on the following round. This justifies the full/partial case analysis of the internal high pair and the at-most-three high run.

In the exceptional equality case, the slack count forces every decrement to equal `m` or `m-1`. Once triples are excluded, excess `x-y=3` forces the displayed word `(HL)^u HH (LH)^v H`: all low runs are singleton, both boundary runs are present, and exactly the unique internal and terminal high runs have length two. At the internal pair, telescoping total cardinalities gives

`h=ud+m+q` and `h=p+vd+m`.

These equations remain valid even if an earlier partial color temporarily became full again. They use only fullness at this pair, not the unjustified stronger assertion that the second color was untouched throughout. Thus `d(u-v)=p-q` and `|p-q|<=m<d` correctly force `p=q` and even `m`.

### The triple-high congruence was a false alarm

The two congruences are `h congruent 2m` or `h congruent 3m-1`, modulo `d=2m-1`. Doubling and comparing with `n congruent m+1` gives, respectively, divisibility of `3m-1` or `5m-3`. Subtracting `d` or `2d` leaves `m` or `m-1`; either is impossible because `0<m<d` and `0<m-1<d`. Equivalently, since `m+(m-1)=d`, divisibility of either implies divisibility of the other. Therefore the original text's common contradiction is sound. A reader may prefer spelling out the two positive integers to make this transparent; this is exposition, not a mathematical defect.

### Odd exceptional balancing

The isolated `m+1` step is internal and leaves exactly the full small parity. Prefix and suffix high-minus-low excesses are therefore `(0,0)` or `(-1,1)`. Subtracting the one-position difference between the total decrements on the two sides correctly changes `m+1` to `m` in equation (11). Both excess patterns then force `d` to divide `m`. I checked the second pattern directly: with `b=a+1,c=e+1`, its two sides are `(a+1)d` and `ed+m`, which yield the contradiction immediately.

### Small boards and m=1

The `n=3m+1` obstruction uses the placement of the sole possible `m+1` decrement rather than the large-board high-pair lemma. If it is in the middle of three rounds, it leaves more than `m` positions for the last round. At `n=3m` with odd `m>=3`, attaining the first decrement `m` forces the large parity to be untouched; the resulting full small parity and proper large parity force the second decrement at most `m-1`. Thus the strict large-board hypotheses have not leaked into these cases.

For `m=1`, the large-board lower bound covers `n>=5`; the even cardinality bound handles `n=4`; and the remaining cases are direct. The exceptional residue is correctly not applied at `m=1`.

## Minor editorial issue

The consolidated formula contains an escaped-control-character rendering before `arepsilon(n,m)` in the local Markdown. Replace that sequence with the intended literal `\varepsilon(n,m)`. This does not affect the surrounding mathematical definition.

## Verification boundary

This review supplies a second derivation-level audit, including arbitrary disconnected beliefs, useless probes, possible belief growth, termination, and all parameter ranges. It does not certify a Lean theorem, establish novelty, or convert finite checks into a proof of arbitrary strategies. The actual unbounded argument is the component identity, high-run restrictions, telescoping counts, and exceptional equality analysis reviewed above.

# Direct height descent gives a polynomial onset bound

12 September 2026. Root proposed the bounded height-descent argument.
The frontier lane independently checked it and simplified the endpoint
construction below. Euler accepted the complete ordinary proof in
`even-bridge-height-descent-independent-review.md`; the assembled
manuscript also passed the frontier lane's independent interface audit
in `even-cylinder-manuscript-independent-review.md`. No computation
or Lean proof is involved.

This note sharpens `even-bridge-height-loop-period.md`: the same small
period now follows without enumerating a finite graph, finding cycles,
or inserting a residue-selected intermediate path. The protected-band
and bounded-nonclean-day geometry remains the independently accepted
one in the two earlier eventual-periodicity notes.

## 1. A legal descent between two height configurations

Let Q be a connected bipartite graph with A vertices and diameter R.
A height configuration is an integer vector a with

    |a_u-a_v|=1 for every edge uv of Q.

Its parity on each vertex records a physical cohort phase. A local flip
at a local maximum v replaces a_v by a_v-2. This preserves the edge
condition. When heights describe proper one-sided longitudinal prefixes,
the flip removes the top room of that fiber.

**Descent lemma.** Suppose a and c are height configurations, c_v<=a_v
for every v, and c_v is congruent to a_v modulo 2 for every v. Then a
can be changed into c by exactly sum_v(a_v-c_v)/2 legal local flips.

Proof. If the current vector x differs from c, choose a vertex v of
maximum current height among those with x_v>c_v. Suppose a neighbor w
has height x_w=x_v+1. If w is not above its target, then x_w=c_w, while
the parity condition gives c_v<=x_v-2. Thus c_w-c_v>=3, contradicting
the target edge condition. So every higher neighbor would also be above
its target, contradicting the choice of v. Therefore all neighbors of
v have height x_v-1, and v is a legal local maximum. Its flip keeps
x_v>=c_v and preserves all invariants. The sum of the nonnegative gaps
falls by exactly two until it becomes zero. This proves the lemma.

## 2. Every sufficiently long compatible endpoint pair is reachable

Fix m>A/2 and write D=2m-A>0. Daily frontier evolution is a global +1
movement followed by m local flips; its vertices are after-inspection
survivor configurations. Every such day lowers the height sum by D.

Put

    K0 = ceil(A R/m).

**Endpoint lemma.** Let a,b be height configurations. Suppose t>=K0 is
an integer such that

    b_v is congruent to a_v+t modulo 2 for every v,
    sum_v a_v - sum_v b_v = D t.

Then a legal t-day frontier path with exactly m useful inspections each
day joins a to b.

Proof. Set c=b-t·1, temporarily removing all t global movements. Then
c has the same vertexwise parities as a, and

    sum_v(c_v-a_v) = -Dt-At = -2mt.

Both a and c are 1-Lipschitz along Q paths. For any vertices v,w,

    (c_v-a_v)-(c_w-a_w) <= 2 dist(v,w) <= 2R.

Averaging over w gives

    c_v-a_v <= -2mt/A+2R <= 0.

Thus the descent lemma gives exactly mt legal flips taking a to c.
Split this word into t consecutive groups of m flips. Before each group
add one to every height. Global additions do not change comparisons
between heights, so every indicated flip remains legal. After t groups
the final vector is c+t·1=b, as required.

This is a direct endpoint construction. The old path need not supply
any of its flips, and the target need not be a previously chosen
canonical shape. Each flip deletes a different current top room, so the
m flips in a day are m distinct useful physical inspections.

## 3. Uniform control of intermediate physical positions

Let mu(x)=sum_v x_v/A. At the after-inspection states of the constructed
path,

    mu(x_j)=mu(a)-Dj/A.

The mean therefore moves monotonically from mu(a) to mu(b). Every height
configuration has range at most R, so every intermediate cutoff lies
between mu(b)-R and mu(a)+R. During a daily movement followed by partial
flips the upper bound can increase by at most one, and the lower bound
is no smaller than that day's final lower bound. Thus all physical
operations remain within

    [mu(b)-R, mu(a)+R+1].

In a protected interior crossing this guarantees that all removed top
cells are actual rooms and that neither end of the finite cylinder is
encountered. It also controls the modified path independently of its
number of flips or the length of the original strategy.

## 4. Shorten or lengthen a crossing directly

Let

    g=gcd(A,D),   ell=2A/g,   Delta=2D/g.

Both ell and Delta are even and A Delta=D ell. Consider a left-going
clean crossing whose after-inspection endpoints a,b are t days apart,
where t>=K0+ell. It obeys the endpoint sum and parity identities because
each old day uses m useful inspections and exact physical neighborhood
formation.

After deleting Delta physical columns, the required modified endpoints
are a-Delta·1 and b. Their sum difference is

    sum_v(a_v-Delta)-sum_v b_v = Dt-A Delta = D(t-ell).

Their phases have the correct difference t-ell because ell and Delta
are even. Since t-ell>=K0, the endpoint lemma constructs a legal path
between them in exactly t-ell days. Section 3 controls its position.

For insertion, the endpoints a+Delta·1 and b satisfy the corresponding
identities with duration t+ell. The same lemma constructs the longer
path. Reflection handles right-going crossings. No cycle extraction,
finite-state bound, or congruence-class selection is necessary.

## 5. The exact eventual recurrence and polynomial threshold

Apply the two independently accepted physical-band arguments. Their
inefficiency potentials show that only a bounded number E of days can
lie outside clean owner blocks. Mark their actual inspection columns
and the frontier positions at their boundaries, with bounded propagation
neighborhoods. A sufficiently long cylinder consequently has a common
protected band that each initial cohort crosses once in a clean owner
block, with the other cohort globally full or empty.

Choose the band so each crossing has a central segment of at least
K0+ell days and enough width for Delta-column deletion plus the range
margins of Section 3. Replace both segments by the direct shorter paths
and delete Delta columns. The accepted filled-tail and local-uniformity
arguments still justify every transition outside those replacements.
The mate is unchanged, and the even temporal and spatial shifts preserve
phase. This saves ell days per owner crossing. Reversing the operation
inserts ell days per crossing. Therefore

    T_m(Q × P_(n+Delta)) = T_m(Q × P_n) + 2ell
                       = T_m(Q × P_n) + 4A/g

for all sufficiently large n in the previously covered parity classes.
For a fixed transverse Cartesian box, those classes together cover both
longitudinal parities, as explained in the height-loop note.

The onset bound is now polynomial in A and m. Here is a direct effective
substitution into the already audited bounds; no new asymptotic
compactness argument is needed. Keep their polynomial quantities
K,B,E,F,rho. In the even-order proof use spatial displacement Delta; in
the odd-order paired-column proof use Delta/2. In both set the width
margin v=A+2 and replace the long-walk allowance by

    H=K0+ell+4.

Use their displayed formulas for W, the raw gap W+2v+4, and the resulting
threshold. Those formulas guarantee a central path with at least H
edges and the required Delta and width margins. Their respective mean
speeds are D/A in physical columns and D/(2A) in paired columns, exactly
as required by the conversion from actual cutoff heights.

Since R<=A-1 and m>A/2, we have K0<=2(A-1) and ell<=2A. Hence H<=4A+2.
Also Delta<=2D. All substituted quantities are therefore polynomially
bounded in A and m. More conservatively, with X=A+m+1, the explicit
marking formulas give E=O(X^4), F=O(X^5), rho=O(X^4), and W=O(X).
Their resulting onset bound is O(X^9). This coarse universal degree is
only an upper bound from the proof, not a claim of sharp threshold size.

The previously proved all-odd-box/odd-length theorem also has a
polynomial threshold in A and m: its corner collar can be bounded using
Z=A(S+1)<=A^2, where S is the sum of transverse side lengths minus one
per side. Taking the maximum of the two parity thresholds preserves a
polynomial bound for every fixed transverse box.

## 6. Scope and remaining limitations

The result now has a small explicit period and a polynomial sufficient
onset threshold, with a constructive replacement for every clean bulk
segment. It still does not compute the finitely many exceptional exact
times or the eventual offsets. Their existence and effective treatment
do not make general finite box classification a closed formula. The
argument fixes Q while the last dimension grows; it is not an asymptotic
theorem for cubes with all dimensions growing simultaneously.

## 7. Research corollary: exact bulk reachability after K0 days

This byproduct concerns the interior height graph only; it is not an
assertion about arbitrary finite-board supports or their optimal times.

Fix a root vertex o and a bipartition with o in color zero. Normalize a
height configuration by an even uniform translation so that a_o equals
its phase p in {0,1}. Write S(a)=sum_v a_v, regarded modulo 2A. A
normalized state consists of this actual relative height pattern and p,
not just the number S(a).

For any two normalized states (a,p) and (b,q), and every integer t>=K0,
there is a t-day path in the full-quota interior height graph between
them if and only if

    S(b) = S(a)-Dt  modulo 2A,
    q = p+t        modulo 2.                           (7.1)

Necessity follows from the height-sum drift and phase change on each
day; normalizing the endpoint changes its sum by a multiple of 2A.
For sufficiency, the first congruence selects an even translate b'=b+2j·1
with S(a)-S(b')=Dt. The second gives the vertexwise parity condition.
The endpoint lemma constructs the actual height path from a to b', whose
normalized endpoint is b. All its transitions are valid in a sufficiently
large interior band. This proves (7.1), without enumerating shapes.

If (7.1) has one integer solution t, its complete set of integer
solutions is one residue class modulo ell=2A/gcd(A,D). Indeed a
difference u between solutions must satisfy u=0 modulo 2 and Du=0
modulo 2A. Writing u=2r gives A | Dr, exactly ell | u. Thus all
sufficiently large times in that residue class are reachable, and no
times outside it are reachable. Times below K0 can have additional
shape-dependent restrictions.

Equivalently, consider the labels (S(a),p) in
(Z/(2A)Z) × (Z/2Z), with the daily label step (-D,1). The strongly
connected components of the interior height graph are exactly the
nonempty intersections of the realizable states with cosets of the
cyclic subgroup generated by (-D,1). A path cannot leave such a coset.
Conversely any two states in one coset admit a solution of (7.1); choose
its representative t in [K0,K0+ell-1] and apply the endpoint lemma.
The reverse direction has the same argument. Consequently every such
component has directed diameter at most K0+ell-1.

This classifies bulk reachability by arithmetic and gives a polynomial
bound on the necessary path length even when the number of possible
front shapes is exponential. It is recorded here as a research
corollary; the manuscript's eventual-periodicity proof only needs the
endpoint lemma of Section 2.

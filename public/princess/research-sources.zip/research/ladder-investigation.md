# Exact capture times on ladders: derivation and proof audit

12 September 2026 UTC. This is a new derivation in the current investigation,
independently developed and attacked by the coordinating agent and the
small-grid agent. Lean now checks the complete physical-room classification,
including finite cardinalities, probe budgets, suffix realization, and the
connection to arbitrary actual avoiding trajectories. This work does not
establish literature novelty and relies on no inaccessible notes. No claim
of priority should be made from this note.

The graph is the ladder `L_n = P_n □ P_2`, with two rows and `n` columns.
The princess starts anywhere, the searcher inspects at most `m` arbitrary
rooms simultaneously per turn, and after a miss the princess must traverse
exactly one edge. The searcher receives no information besides capture or
a miss. Write `T(n,m)` for the minimum guaranteed capture time, and infinity
when capture cannot be guaranteed.

## Result supported by the argument below

For `n ≥ 2` and positive `m`:

- `T(n,1) = infinity`;
- `T(n,m) = 1` when `m ≥ 2n`;
- when `2 ≤ m < 2n`, put `N=n−1` and `M=m−1`. Then

```
T(n,m) = ceil(2N/M) + epsilon,

epsilon = 1 if M is even and N mod M = M/2,
          0 otherwise.
```

Equivalently, the extra turn occurs when `m` is odd and
`n−1 ≡ (m−1)/2 (mod m−1)`. In particular,

```
T(n,2) = 2n−2   for every n≥2.
```

The degenerate ladder `n=1` is a single edge: its value is 2 for `m=1`
and 1 for `m≥2`.

The evidence below is a full mathematical argument for this ladder formula,
not just a guess from finite checks. Publication-quality exposition, independent external review, and a literature
comparison remain separate tasks. The complete Lean room-graph assembly and
its precise statement are recorded in
`lean/LADDER_PROOF_BOUNDARY.md`.

## 1. Two parity cohorts become two lazy walks on a path

Color room `(r,j)` by `(r+j) mod 2`. The princess changes checkerboard color
at every compulsory move. Therefore the possible trajectories split into
two disjoint cohorts according to the initial color. At a fixed time, each
cohort occupies at most one of the two rooms in every column.

Projecting a cohort onto column indices gives an invisible walk on `P_n`
which may move one column left, stay in its column, or move one column
right. Staying in the column means traversing the vertical edge; it does not
mean the princess stays in the same room. Every one of these column moves
is possible when it remains in the path. Thus if a cohort's column belief
is `B`, and the probes aimed at that cohort cover columns `S`, its next
column belief is the closed neighborhood `C(B \ S)` in `P_n`.

There is no interaction between the two cohorts except their shared probe
budget: their room sets have different checkerboard colors on every day.
Allocating `p` probes to one and `q` to the other is feasible whenever
`p+q≤m`.

For every nonempty proper subset `R` of a connected path,

```
|C(R)| ≥ |R|+1.
```

Indeed, some path edge joins `R` to its nonempty complement. A suffix
interval attains this lower bound unless expansion reaches the whole path.

## 2. Exact reduction to two integer counters

For a cohort with `b` possible columns receiving at most `p` probes, define

```
F(b,p) = 0                         if p≥b;
         min(n,b−p+1)              if p<b.
```

The next belief has at least `F(b,p)` columns. For `p<b`, the survivors
number at least `b−p`; if they are a nonempty proper set, their closed
neighborhood gains at least one column, and if they fill the path the
neighborhood has size `n`. This also covers probes wasted outside the
belief, since fewer useful probes can only enlarge the lower bound.

Conversely, if the belief is the suffix of length `b`, probing its leftmost
`min(p,b)` columns makes the next belief the suffix of length `F(b,p)`.
The empty belief remains empty.

Consequently the exact minimum time is the minimum number of transitions

```
(b,c) -> (F(b,p), F(c,q)),     p,q≥0, p+q≤m,
```

from `(n,n)` to `(0,0)`. This is not an unproved assumption that an optimal
strategy must be monotone. To see the domination directly, take any
successful arbitrary-belief strategy and its allocations to the two
cohorts. Follow those same allocations with suffix beliefs. Initially the
cardinalities agree. The monotonicity of `F` in `b` and the preceding lower
bound imply by induction that each suffix belief is no larger than its
counterpart in the original strategy. It is therefore empty no later.
Both suffix strategies can be implemented together because the cohorts
occupy disjoint rooms. This proves exactness of the reduction.

The reduction alone gives an exact algorithm with at most `(n+1)^2` states
and `m+1` allocations per state; the following argument solves it in closed
form while also proving a lower bound for arbitrary room-belief strategies.

## 3. A shorter potential lower bound

Give a cohort with `b` possible columns the weight

```
w(b) = max(b−1,0).
```

An unprobed cohort cannot lose weight, since its closed neighborhood contains
it. A cohort receiving `p≥1` useful probes loses at most `p−1` weight. If it
survives, the closed-neighborhood expansion restores at least one of the
removed columns; if it is eliminated, its old weight is at most `p−1`.
The full-path boundary causes no exception: after a positive useful probe,
the survivor set is a proper subset. Wasted probes only weaken the estimate.

With a total budget of `m`, the combined weight of the two cohorts can
therefore fall by at most `m−1=M` per day. If both cohorts receive positive
allocations, it falls by at most `m−2`; if neither receives a probe it cannot
fall. Initially the combined weight is `2(n−1)=2N`, and after capture it is
zero. Hence any successful `t`-day strategy satisfies

```
2N ≤ tM,          so t≥ceil(2N/M).
```

This argument applies to arbitrary cohort beliefs. Suffix intervals are
needed only for the attaining construction.

## 4. Equality forces individual divisibility

Suppose `2N=tM` and a `t`-day strategy achieves capture. Every day must then
attain the maximum weight decrease `M`.

Such a day cannot allocate a positive number of probes to both cohorts,
because that would give a decrease of at most `m−2<M`. Thus all useful
probes are aimed at one cohort. The other, unprobed cohort cannot lose
weight; the probed cohort loses at most `M`. Equality forces exactly a
loss of `M` from the probed cohort and no change in the other.

Consequently, throughout an equality strategy, each individual cohort's
weight decreases only by integer multiples of `M`. It starts at `N` and
ends at zero, so `M` must divide `N`.

If `M` divides `2N` but not `N`, the basic lower bound cannot be attained.
Writing `N=qM+s` with `0≤s<M`, this occurs precisely when `M` is even and
`s=M/2`, and then one additional turn is required. The construction below
attains that extra turn and attains the basic bound in every other case.

This shorter proof was independently kernel-checked for the exact counter
process in `lean/LadderCounters.lean`. The earlier first-elimination and
boundary-switching derivation is preserved in
`research/ladder-earlier-lower-bound.md` as an independent mathematical check.

## 5. An explicit strategy attaining the bound

Use suffix intervals for each cohort. A day with all `m` probes aimed at
a nonterminal cohort reduces its suffix length by `M=m−1`.

Write `N=qM+s` with `0≤s<M`.

If `s=0`, clear the first cohort in `q` days and then the second in `q`
days. Each phase has `q−1` ordinary sweep days, leaving exactly `m`
positions, followed by a terminal day inspecting those positions. The
untouched cohort remains full during the first phase. This uses `2q` days.

If `s>0`, first devote `q` ordinary sweep days to the first cohort,
leaving `s+1` positions. On the next day, use `s+1` probes to eliminate it
and the remaining `M−s` probes on the leftmost columns of the second
cohort. Its next suffix length is

```
b = n−(M−s)+1 = (q−1)M+2s+2.
```

We are treating `m<2n`. This guarantees that these spare probes do not
already eliminate the second cohort and that `b≥2`, including when
`q=0`. A suffix of length `b≥2` is cleared by the ordinary sweep in
`ceil((b−1)/M)` days. The total is therefore

```
q+1+ceil((b−1)/M) = 2q+ceil((2s+1)/M).
```

For `0<s<M`, this equals `ceil(2N/M)` unless `2s=M`, when it is one
larger. It agrees exactly with the lower bounds in Sections 3–4.
If `m≥2n`, inspect all rooms on day one instead.

Finally, for `n≥2` each ladder vertex has at least two neighbors. With one
probe, every vertex retains a possible neighbor after the inspection, so
the full room belief persists forever. This proves the infeasibility
branch and completes the classification under the stated model.

## Independent attacks and finite verification

- The tempting formula `max(2,ceil((2n−2)/(m−1)))` is false. For example
  `T(4,3)=4`, not 3, and `T(6,3)=6`, not 5. These were established by both
  full-belief BFS and an independent all-states horizon method; they are
  explained by the equality obstruction.
- The distinction between a column stay and staying in the same room was
  checked explicitly. The former is always available through the vertical
  edge, and the latter remains prohibited.
- The suffix domination proof handles unprobed partial beliefs growing
  again; no monotonicity of the original strategy is assumed.
- The shared transition formula was checked at `q=0`, at a single spare
  probe (`M−s=1`), at the half-residue obstruction, and at the separate
  one-day regime `m≥2n`.
- `../src/ladder_counter_model.py` solves all 156 pairs `1≤n≤12`,
  `1≤m≤2n`. It constructs actual room inspections and independently checks
  every finite schedule with sets on the ladder graph. Every computed value
  agrees with the displayed closed formula. The 24 previously solved
  full-belief ladder cases also agree with the counter reduction.
- The two-counter computation takes approximately 0.008 seconds in one
  process. The earlier independent grid computation took approximately
  0.596 seconds. No large or continuing computation was required.

The complete finite evidence is in `ladder-counter-cases.json` and
`grid-small-cases.json`. The mathematical conclusion does not depend on
extrapolating those finite values; their purpose is to attack indexing,
transition, and residue errors in the independent derivation.

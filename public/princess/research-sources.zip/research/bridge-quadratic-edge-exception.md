# Closing the exceptional residue in the quadratic-edge budget formula

13 September 2026. Ordinary construction by the root, independently
replayed and reviewed by the upper-construction lane.

The expression in `bridge-boundary-numeric-quadratic-edge.md` is exact
also in its former exception r=8, n=22 modulo12. Consequently that
expression now holds for EVERY r>=3, n>=2r at budget k=r(r-1).
This is mathematical unification of the full parameterized curve.

## A two-day physical transition

Use coordinates0<=x<16,0<=y<n, with n>=22, and let color be x+y modulo2.
The color-zero anchored prefix A of size127 is

    A = {(x,y): x+y even, x+y<=22} minus {(0,22)}.

All these coordinates lie inside the board. More precisely the displayed
set is intersected with the board, and removing(0,22) is redundant when
n=22. The source's column heights are20,21,20,19,...,7. In particular
A is the SAME finite set for every n>=22.

Let

    U = {(x,y): x+y even, y<=8} minus {(0,8)}.

It has71 rooms and is contained in A. Inspect A minus U, exactly56 rooms.
The next possible set is

    B = N(U) = {(x,y): x+y odd, y<=9} minus {(0,9)},

which has79 rooms. This equality is checked directly along the four
sides: every indicated room has a neighbor in U, and the single excluded
corner-adjacent room has none.

At the bottom-right corner take the color-one square triangle

    Q = {(x,y): x+y odd, (15-x)+y<=8},
    V = Q minus {(14,7),(15,8)}.

The full triangle Q has25 rooms; V has23 and lies inside B. Inspect
B minus V, again exactly56 rooms. Its neighborhood C=N(V) has28 rooms.
For a completely checkable description, the nonempty column heights of
V, at x=7,...,15, are

    0,1,2,3,4,5,6,5,6,

and those of C, at x=6,...,15, are

    0,1,2,3,4,5,6,7,6,7.

Each column contains precisely the nonnegative heights of its prescribed
color up to that height. Thus the two-day transition is exactly

    127 --56 inspections--> 79 --56 inspections--> 28.

It changes the shape of the possible set in the middle. Following the
original anchored prefix for both days instead left29 rooms. This is why
the earlier numerical lower was attainable despite that prefix gap.

## The uniform residue family

Write n=6j+16, where j is positive and odd. Start the ordinary anchored
prefix search in color one. Its first move leaves h-49 rooms, h=8n.
The next j-1 moves lie in the proved phase-independent plateau and each
reduce the count by48. After exactly j moves it therefore reaches

    h-49-48(j-1)=127

rooms in color zero, namely A. Apply the two-day transition above and
inspect C on the following day. This is a solo strategy of j+3 days,
ending with28 rooms. Reflection across x=15/2 switches the two colors;
the two terminal shots have union of size at most56. The reflected
central construction therefore gives full capture in

    2(j+3)-1 = 2j+5 = (n-1)/3 days.

This agrees with the already proved scalar lower in the exceptional
case. The formula outside this residue class was independently reviewed
in the quadratic-edge note, so the exception is completely removed.

## Verification and unsuccessful routes

Root independently replayed full strategies at n=22,34,46,58,70,142.
The upper lane separately replayed the local transition at n=22,34,142
and verified that its geometry and all heights are independent of n.
The root witness receipt is
`bridge-quadratic-edge-exception-splice.json`; the independent local
receipt is `bridge-upper-transport-quadratic-boundary-verified.json`.

A preliminary linear relaxation for three-day inspection of a fixed
23-room corner survivor had fractional optimum52.527<56, so it supplied
no lower obstruction. A three-second integer attempt produced no witness
and no usable bound. Neither failure was used as evidence of impossibility.
The actual resolution came from allowing the two-day shape change above.
No new Lean theorem or publication build is claimed here.

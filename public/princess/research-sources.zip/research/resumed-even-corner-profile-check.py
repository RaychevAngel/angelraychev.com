"""Independent literal-support checks of the proved candidate corner inequality.
Finite checking is not the universal proof.
"""
from collections import defaultdict

def C2(s):return max(s*(s-1)//2,s*(s-2))
def F(i,j,s):
 if s<i+2*j:return -1
 if j:return i+2*j-2+(s-i-2*j+2)*(s-i-2*j+1)
 if i:return i-1+(s-i+1)**2
 return C2(s)
def dual(i,j,s):return max(F(2-j,d,s-2+i+d) for d in range(3-i))
def check(w,n):
 corners={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
 row=defaultdict(int)
 for p in range(2):
  cells=[(x,y)for x in range(w) for y in range(n)if (x+y)%2==p]
  other=[(x,y)for x in range(w) for y in range(n)if (x+y)%2!=p]
  index={v:i for i,v in enumerate(other)}
  neighbours=[sum(1<<index[v] for v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if v in index)for x,y in cells]
  ci=sum(1<<i for i,v in enumerate(cells)if v in corners)
  cj=sum(1<<i for i,v in enumerate(other)if v in corners)
  h=len(cells);N=[0]*(1<<h)
  for S in range(1<<h):
   if S:
    bit=S&-S;N[S]=N[S^bit]|neighbours[bit.bit_length()-1]
   k=S.bit_count();s=N[S].bit_count()-k
   if s>=w//2:continue
   i=(S&ci).bit_count();j=(N[S]&cj).bit_count();row[i,j,s]+=1
   assert k<=F(i,j,s) or h-k-s<=dual(i,j,s),(w,n,p,k,s,i,j,F(i,j,s),dual(i,j,s))
 return sum(row.values())
if __name__=='__main__':
 import time,json
 from pathlib import Path
 start=time.process_time()
 rows=[dict(w=w,n=n,subcritical_supports=check(w,n),all_supports=2**(w*n//2+1)) for w,n in [(2,2),(2,3),(3,4),(4,4),(4,5),(4,6),(5,6),(6,6)]]
 result=dict(status='PASS',scope='All literal one-color subsets on these finite boards; universal claim uses the separate geometric proof.',rows=rows,CPU_seconds=time.process_time()-start)
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))

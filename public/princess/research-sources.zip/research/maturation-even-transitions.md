# Symbolic physical transitions on even-width rectangles

13 September 2026. New research after explicit resumption. Root independently
accepted Sections 1, 4, 6, and 7; the review is
`maturation-interior-independent-review.md`. Sections 8--9 are independently
accepted by root (`maturation-anchored-independent-review.md`); Section 10
is independently accepted by Euler (`maturation-joint-corner-independent-review.md`).
No manuscript, website, or Lean source is changed. The aim is to replace generic local
transition enumeration with exact symbolic costs, without assuming that
arbitrary static profile minimizers compose.

## 1. Exact one-day costs between pyramids, including the ends

Let Q be connected and bipartite with at least two vertices. Fix a cylinder
Q square P_n. For a pyramid B of current color p, write its virtual heights
as b_v, put s_v=(p-chi(v)) mod 2, and let q=1-p. The maximal graph erosion

    E(B)={u of color q : every neighbor of u lies in B}

is a pyramid. Here is its exact height formula, including the top cap:

    e_v=max(b_v-1, (1-s_v)-2) + 2 indicator(T_v),             (1)

where T_v means that n-1 has parity 1-s_v, b_v=n-2, and b_u=n-1
for every Q-neighbor u of v.

To verify (1), a room below the top has its upward path neighbor, so its
coordinate must be at most b_v-1; the transverse inequalities add nothing
because b_u is b_v-1 or b_v+1. Empty fibers require the stated lower clip.
A room at the top may additionally survive exactly under T_v: its downward
neighbor and every transverse neighbor must be present. That room is two
steps above the ordinary eroded cutoff. This is the only extra possibility.

The bottom clip only raises a local minimum -3 to -1, with adjacent new
heights -2. A top correction only raises a local minimum n-3 to n-1, with
adjacent new heights n-2. Therefore all neighboring eroded heights still
differ by one. The formula also holds at n=1: it reduces to the Q-neighbor
test. Thus E(B) is a physical pyramid, not just an envelope.

For a same-oriented pyramid A in color q, define R*=A intersect E(B).
Its height is min(a,e). Then the exact minimum useful inspections for a
one-day transition whose resulting belief is contained in B is

    C(A,B)=|A minus E(B)|=sum_v max(a_v-e_v,0)/2.             (2)

Every admissible survivor R must be contained in R*, and R* itself attains
the minimum. An exact endpoint B is reachable in one day if and only if

    N(R*)=B;                                               (3)

when it is, (2) is still the exact minimum. Indeed any exact-endpoint
survivor lies in R*, forcing B subset N(R*) subset B. This statement
allows arbitrary competing survivors; it does not assume a normal form.

In particular, every one-day edge between same-oriented pyramid checkpoints
has a closed physical cost. The unresolved effects can only arise across
several days or from changing endpoint orientations near a boundary.

## 2. An exact interior block theorem

Let Q=P_(2b), b>=1, and n>=2b. Let A and B be downward pyramids represented
by height vectors a and z; the letter z avoids confusing a height with b.
Let t>=1 and let p_1,...,p_t be nonnegative integer daily quotas, with
P=sum p_j and h=bn. Assume the following explicit interior guards:

    t <= min_v a_v, min_v z_v,
    max_v a_v, max_v z_v <= n-1-t,                         (4)
    |A|-P > (b-1)^2,
    |B|+P < h-b(b-1).                                     (5)

The two endpoint colors must differ by t modulo two. Then an actual
t-day block taking A EXACTLY to B exists, with no restriction on its
intermediate supports, if and only if

    z_v <= a_v+t for every v,
    F=(sum_v(a_v+t-z_v))/2 <= P.                           (6)

When it exists there is a block of the same duration and daily quotas
whose every survivor and possible-position set is a downward pyramid.
This is an interior endpoint theorem, not a general partial-state or
whole-board pyramid normal form.

### Necessity against arbitrary intermediate supports

The t-step free evolution of A has heights a+t under (4); hence any exact
endpoint B satisfies the componentwise part of (6). Put k_j for the belief
size after j inspections and moves, R_j for the survivor on day j, and u_j
for that day's useful inspections. The cylinder has a perfect matching,
so neighborhood size never decreases. Thus

    |R_j| >= |A|-P,
    |R_j| <= |B|+P.

The second inequality follows by bounding all later decreases by their
inspection quotas. The exact even-area static profile gives surplus at
least b whenever

    (b-1)^2 < |R_j| < h-b(b-1).

Indeed both ceil(sqrt(|R_j|)) and rho(h-|R_j|) are at least b in this
range. Therefore k_j-k_(j-1) >= b-u_j. Summing yields

    |A|-|B|+bt <= P.

Every color has b even path-parity fibers and b odd ones, so
|A|-|B|=(sum a-sum z)/2. This is exactly the second part of (6).

### Sufficiency by legal height descent

Put c=z-t. It has the same coordinatewise parities as a, neighboring
differences one, and c<=a. Any such target can be reached from a by legal
local-maximum flips, lowering a single height by two. To prove this, choose
a vertex of maximum current height among those above their targets. If it
had a higher neighbor already at target, the target's edge difference would
exceed one; that neighbor is therefore also above target, contradicting
maximality. All its neighbors are one lower, so the flip is legal. Repeating
reaches c in exactly F flips.

Choose integers 0<=q_j<=p_j summing to F and divide this flip word into
consecutive pieces of lengths q_j. On day j perform its piece, then add one
to every height for movement. Uniform additions commute with the local-
maximum test, so the endpoint is c+t=z. A piece uses distinct actual rooms
even when it flips the same fiber repeatedly.

All intermediate unshifted heights lie between c and a. Under (4), c>=0
and a+t<=n-1; before any movement the upper bound is n-2. Every survivor
fiber is nonempty and away from the upper cap, so its actual neighborhood
has heights exactly one higher. Thus this is an exact physical block, not
merely a dominating envelope. The quotas are respected individually.

Reflection gives the same theorem for upward pyramids. The proof of
sufficiency does not need (5); that guard only establishes necessity against
arbitrary intermediate supports.

## 3. Constant-budget symbolic cost and the surviving bottleneck

For m>b, define t0 to be the least nonnegative integer of the required
endpoint color parity satisfying

    t0 >= max(0, max_v(z_v-a_v), ceil((|A|-|B|)/(m-b))).     (7)

Whenever (4)-(5) hold with t=t0 and P=mt0, t0 is the exact unrestricted
transition time between these endpoint pyramids. The lower argument applies
to every shorter duration because the guards only become weaker. For
distinct endpoints t0 is positive. Equal endpoints permit the empty block.

For an interior canonical macro edge whose mate is full at both ends,
all mate inspections can be omitted: free evolution preserves its full
class. An empty mate also remains empty. Hence (7) applies to the proper
cohort with the entire shared budget m, reproducing the same joint endpoint.
The large collars of the existing physical-interface theorem dominate
(4)-(5) for all its bounded-duration interior blocks. Consequently its
translation-invariant interior transition table can be replaced by (6) or
(7); only endpoint-collar transition problems retain arbitrary geometry.

This does not evaluate those boundary tables, decide the 6x6,m5 last-day
obstruction, or justify a daily normal form through a corner. It is a
specific simplification of the accepted exact interface construction.

## 4. Stronger version: every Hamiltonian cross-section, either length parity

The earlier upper-cardinality guard and even-order restriction can both be
removed. Let Q be any connected bipartite graph with a Hamiltonian path,
of order A>=2. Index a Hamiltonian path by 0,...,A-1 and use its parity
as chi; when A is odd, chi=0 is the larger class. Set

    C_A=floor((A-2)^2/4),     gamma_p=|chi^(-1)(1-p)|.        (8)

### Half-infinite-strip expansion

For every finite monochromatic S in Q square P_infinity, with the path
starting at coordinate zero, one has |N(S)|>=|S|. Moreover

    |S|>C_A  implies  |N(S)|>=|S|+gamma_p                 (9)

when S has current physical color p.

To prove this using already accepted rectangle profiles, first restrict
Q's edges to its Hamiltonian path; deleting edges only decreases the
neighborhood. Place the finite support in a rectangle with sufficiently
large longitudinal length, so its neighborhood is unchanged and the far
profile branch is at least the middle cap. For A=2b the exact profile
becomes k+min(ceil(sqrt(k)),b); its plateau begins at k>(b-1)^2.
For A=2b+1, choose the auxiliary length odd. The two profiles become
k+min(R(k),b) and k+min(Q(k),b+1), respectively. Both are on their
plateau for k>b(b-1). These thresholds are exactly C_A in (8).
Their small-size branches are also nonnegative, proving the first claim.
This is an infinite-strip consequence of the finite proved formulas;
no new isoperimetric conjecture is being assumed.

### Uniform exact endpoint theorem

Retain the physical endpoint margin (4), with A in place of 2b, and replace
(5) by the single guard

    |initial pyramid|-sum_j p_j > C_A.                     (10)

For every positive longitudinal length n (of either parity), arbitrary
t-day physical transition feasibility between these same-oriented endpoint
pyramids is still equivalent to the two conditions (6), now summed over
all A vertices. Every feasible transition has a pyramid-only replacement
with the identical prescribed daily quota word and exact final belief.

Here is the part of necessity that changes. The free evolution has heights
a+j, so before every one of the t moves no survivor reaches the far
longitudinal row. Its neighborhood is therefore the same as in the
half-infinite strip. The nonnegative expansion in (9) bounds every survivor
below by |initial pyramid|-sum p_j, and (10) makes its surplus at least
gamma_(p+j-1), where p is the initial color. If s^p_v=(p-chi(v)) mod2,

    sum_(j=1)^t gamma_(p+j-1)
       = (At + sum_v s^p_v - sum_v s^(p+t)_v)/2.

Combine this with the endpoint cardinality identity

    |initial|-|final|
       = (sum a-sum z -sum s^p+sum s^(p+t))/2.

The parity corrections cancel, again giving exactly F<=sum p_j.
The sufficiency proof by legal height descent works on any connected
bipartite Q, so it is unchanged. This also explains why the condition is
an exact height condition even for odd A, although cardinality growth
alternates between the two physical colors.

For a constant budget m>A/2, replace (7) by the least nonnegative integer
t0 of the required endpoint parity satisfying

    t0 >= max(0, max_v(z_v-a_v),
              ceil((sum_v a_v-sum_v z_v)/(2m-A))).          (11)

Subject to (4) and (10) at t0, this is the exact unrestricted physical
transition time. It permits arbitrary partial pyramid starts, arbitrary
budget words in its fuller form, and exact endpoints. It says nothing
about initial or terminal collars when those guards fail.

### The virtual height graph itself needs no size or time guard

Independently of physical boards, on any connected bipartite Q the graph
of legal local-maximum flips and a global +1 after each day has an exact
reachability criterion: same endpoint parity, z<=a+t, and F<=sum p_j.
The legal-descent proof above proves sufficiency, and counting flips plus
coordinate monotonicity proves necessity. Thus the old large-duration
height-connection lemma is a sufficient-condition corollary, rather than
the sharp virtual reachability statement. Physical arbitrary-support
optimality requires the additional guards and lower expansion proof.

## 5. Independent audit of the parent's lowered even-width budget threshold

For Q=P_(2b), a pyramid can omit a bottom-parity-zero fiber only if its
size is at most b(b-1), in either physical color. The distance bound now
uses floor(dist/2) at such a root; its maximum occurs at the corresponding
path endpoint and equals b(b-1). Therefore the clipped erosion

    e_v=max(a_v-1, (1-s_v)-2)

loses exactly b rooms once |A|>b(b-1), even if some s_v=1 fibers are empty.
Its neighborhood remains contained in A. The previous upper construction
therefore works already for m>=max(b+1,b(b-1)+1).

The scalar lower also extends to that range. Its reflected profile branch
is at least b because rho(m)>=b exactly when m>b(b-1). Write D=m-b and
h-b=qD+r, 0<=r<D. Now D>=(b-1)^2. All previous plateau evaluations remain
valid except when D=(b-1)^2 and r=0: the last pre-capture size becomes
m-1 rather than m. That case has b>=2 and m>=3, so the central obstruction
2(m-1)>m still forces the same 2q-day answer. When r>0 or D>(b-1)^2,
the old evaluation is unchanged. Thus no q/r/J branch needs modification.

This audit is mathematical, independent of finite parameter checks; the
parent is writing the accepted theorem and arranging another review.

## 6. Constant-budget height descent with a fixed physical margin

The physical realization of a virtual connection needs no margin growing
with its duration. Let Q be connected bipartite, of order A>=2 and diameter
d_Q. Let m be a nonnegative integer, and assume the virtual criterion

    z<=a+t,    F=(sum a-sum z+At)/2 <= mt                  (12)

with correct endpoint parity. Suppose t>=1. Choose the numbers of flips

    q_j=floor(jF/t)-floor((j-1)F/t),   j=1,...,t.          (13)

They are nonnegative, sum to F, and are at most ceil(F/t)<=m. Group the
legal descent from a to z-t into these numbers of consecutive flips, then
move globally by +1 after each group. Write mu_a,mu_z for endpoint mean
heights. At the end of day j the mean is exactly

    mu_a+j-2 floor(jF/t)/A
      = (1-j/t)mu_a+(j/t)mu_z+2 frac(jF/t)/A.              (14)

It lies between min(mu_a,mu_z) and max(mu_a,mu_z)+2/A. Every valid height
vector has range at most d_Q. During an inspection group heights only
decrease, between its preceding belief and its next survivor; the latter
mean is its completed-day mean minus one. Consequently every height during
the whole construction lies in

    [min(mu_a,mu_z)-d_Q-1,
     max(mu_a,mu_z)+d_Q+2/A].                             (15)

If the endpoint means both lie in

    [d_Q+2, n-d_Q-3],                                    (16)

all these intermediate heights are between 1 and n-2 (using A>=2).
Every fiber is nonempty, every movement is the exact +1 neighborhood,
and every flip removes an actual room. Thus (12) is physically attainable
at constant budget m for any duration t satisfying it, however large t is.
This proof is stronger than the earlier large-duration endpoint lemma:
it retains the exact virtual conditions and has a physical margin depending
only on the diameter, not on t or the number of flips.

For m>A/2 the least virtual duration is the t0 in (11). Under (16), it has
an exact physical realization. This alone is an upper bound against all
physical strategies: an arbitrary strategy could exploit a small corner.
It becomes an exact lower as well when the competing transition remains in
the plateau, or when it is a concatenation of the interior macro edges
already certified by Section 4. Those qualifications are essential.

## 7. Eliminating the remaining interior graph powering

This consequence uses the accepted finite-interface theorem, and hence has
its scope: fixed bipartite Hamiltonian Q of order A>=2, fixed m>A/2, and
longitudinal lengths n with An even. It does NOT extend the canonical-
checkpoint existence theorem to odd-order Q at odd lengths.

Take its finite local graph C_n with common interior counter interval

    R <= z_counter <= floor((n-2-2R)/2).

Its enormous explicit R makes every interior edge satisfy Section 4's
physical and cardinality guards. Indeed each such edge has duration at
most L, all its endpoint heights are at least 2R-A and at most n-2R+A,
and its initial size exceeds mL+C_A. Hence each interior edge is feasible
if and only if the height criterion (6) holds for its duration. This
applies without an assumption on its original intermediate supports.

The finite controls that can change in the interior are the current color
and the relative height shape. The permanent proper cohort, its pyramid
orientation, and the full/empty status of its mate stay fixed. Call these
last three items its sector. Color parity determines the permissible
duration modulo two between two states in the same sector.

Retain as ports every state in the first R and last R counter levels of
the interior interval. These two sets have parameter-dependent but length-
independent cardinality. Keep all vertices and physical edges in the two
boundary families, all boundary-to-port edges, and all direct remote-
boundary edges of the old construction. Its displacement bound ensures
that no other interior vertex is directly adjacent to a boundary vertex.

For every ordered pair of ports in the same sector, add an edge of weight
t0 from (11), using downward physical heights or reflected heights for an
upward sector. Its upper realization is the balanced descent of Section 6;
all port means satisfy (16). The full/empty mate can be left uninspected.
The realizing descent need not remain inside the abstract interior range:
it remains a valid physical strategy, which is the condition needed here.

Every interior subpath of the old graph can be replaced by this edge with
no increase in duration. Its one-edge componentwise inequalities compose
to z<=a+t, and its flip inequalities telescope to F<=mt. Thus its total
duration is at least t0. The converse is stronger: each new edge already
has an actual physical realization. Decompose an old full-board optimum
at visits to the retained boundary families. Every omitted stretch starts
and finishes at ports and stays in one sector. Replacing these stretches
gives a path in the new finite graph of no larger weight. Conversely every
new graph path expands to a valid shared-budget physical strategy. Hence
the shortest-path value of this finite port graph is exactly T_m.

This argument includes repeated visits to the same boundary, reverse
longitudinal motion, opposite-end gadgets, and arbitrary owner changes
inside the retained boundary graph. It does not assume that an optimum
is two pure sweeps or that its excursions are monotone.

The graph has a number of vertices depending only on Q,m. Its boundary
tables require the same finite preprocessing as the accepted theorem.
Port heights depend affinely on n, with the physical parity taken into
account. Every new edge weight is given by maxima, one integer ceiling,
and one parity rounding in (11). One fixed-size shortest-path closure now
evaluates the entire graph in O_(Q,m)(1) integer arithmetic stages, instead
of a graph-powering step. The integers still have O(log n) bits.

Winning paths contain only a bounded number of retained edges after
removing cycles. A long interior edge is stored by its endpoints, duration,
and the rule (13) with the legal local-maximum descent; generating the
individual inspections incurs their output length. This is a mathematical
strategy compiler, not a claim that the general boundary tables have been
implemented or that an elementary formula in all parameters is known.

The substantive strengthening is the exact symbolic evaluation of ALL
interior transitions, including arbitrary-shape competitors. Merely having
constant arithmetic dependence on n was already obtainable from eventual
periodicity with its finite prefix precomputed. The irreducible remaining
geometry is now precisely the finite shared-quota boundary graph.

## 8. Exact isoperimetry with a forbidden favorable corner

This section is an ordinary proof independently accepted by root. Let

    strip = {0,...,2b-1} x {0,1,2,...},   b>=1.

The favorable bottom corner of physical color 0 is (0,0); that of color 1
is (2b-1,0). Let Q(k)=min{r>=1:k<=r(r-1)}, as in the odd-rectangle paper.

**Theorem.** Among finite color-p supports of k>0 rooms which omit their
favorable corner, the exact minimum neighborhood size is

    g_omit(k)=k+min(Q(k),b+1).                            (17)

Both colors have the same answer by transverse reflection. This is a
conditional neighborhood theorem, not a statement that an optimal game
retains a particular corner or can be encoded by this one bit alone.

### A quadrant lemma preserving the missing origin

In the infinite nonnegative quadrant, let S be finite, of even checkerboard
color, and suppose (0,0) is absent. If delta=|N(S)|-|S|, then

    |S| <= delta(delta-1).                               (18)

The empty set is immediate. For a nonempty S, compress independently on
each line x+y=2j toward smaller y, retaining that line's cardinality a_j.
The origin remains absent because its line has a_0=0. This is a legitimate
neighborhood-nonincreasing operation: apply the already proved square
diagonal compression inside a square larger than every x+y coordinate of
S and of its neighborhood. Neither the original nor shifted neighborhoods
then meet a far square boundary, so the same inequality holds in the
quadrant. There is one compression, with no input-dependent stopping rule.

We may therefore work with the compressed set. Its exact neighborhood
cardinality on x+y=2j+1 is

    n_j=max(a_j+1_[a_j>0], a_(j+1)-epsilon_(j+1)),
    epsilon_i=1_[a_i=2i+1].                              (19)

The first input diagonal expands by one when nonempty; the other diagonal
contracts only when entirely selected. Their compressed contributions
are prefixes from the same end. Put delta_j=n_j-a_j. Then

    delta_j >= 1_[a_j>0],
    delta_j >= a_(j+1)-a_j-epsilon_(j+1).                 (20)

Let j_1<...<j_L be the occupied even diagonals. Since a_0=0, j_1>=1.
The term delta_(j_1-1)=a_(j_1)-epsilon_(j_1) is at least one:
a proper nonempty diagonal contributes its positive size; a full first
diagonal has size 2j_1+1>=3 and contributes one less. This term is outside
the L occupied-diagonal terms, each at least one. Therefore

    delta >= L+1.                                       (21)

For the r-th occupied diagonal, telescope the second inequality of (20)
over indices 0,...,j_r-1. There are at most r full diagonals through j_r,
since there are exactly r occupied ones and a_0=0. The prefix sum is thus
at least a_(j_r)-r. The tail sum from j_r onward is at least L-r+1 by
the first inequality. Adding gives

    a_(j_r) <= delta-L+2r-1.

Summing these L bounds yields |S|<=L delta; (21) gives (18). Apply this
to the compressed surplus delta'<=delta_original. It also proves
delta'>=2 for a nonempty set, so x(x-1) is increasing over the relevant
values and (18) follows for the original arbitrary S.

### Split by a boundary-free matched row when surplus is below b

It suffices to treat physical color 0. Match transverse pairs (2i,2i+1).
Represent a color-zero room by (i,y), meaning physical x=2i+(y mod2).
The matching-contracted digraph has bidirectional horizontal edges; its
rungs go from row i to i-1 at even y, and from i to i+1 at odd y.
For the represented support R, let B=N_D^+(R) minus R. Its size s is
exactly the physical neighborhood surplus. Write r_i=|B intersect row i|.

If some r_i=0, that row's R_i is horizontally closed. Since R is finite
and the horizontal ray is connected, R_i is empty. Thus the original
support avoids BOTH physical transverse rows 2i and 2i+1. The parts on
their two sides have disjoint neighborhoods: the left neighborhood ends
at transverse row 2i, and the right one begins at row 2i+1. Their sizes
and surpluses therefore add exactly.

The left part is an even-color quadrant set omitting its origin, so (18)
applies. Reflecting the right part across x=2b-1 makes it an odd-color
quadrant set, so the already proved ordinary quadrant bound is also
|S_right|<=s_right(s_right-1). Neither part acquires missing neighbors when
viewed as a quadrant: its transverse neighbor layer lies inside the empty
two-row gap. Empty parts have zero surplus. Consequently

    |S| <= s_left(s_left-1)+s_right(s_right-1)
          <= s(s-1).                                    (22)

If s<b, such a boundary-free row necessarily exists. The argument also
handles s=b whenever a boundary-free row exists.

### The equality-surplus case s=b without a boundary-free row

Now every r_i>=1 and their sum is b, so r_i=1 for every matched row.
A finite nonempty subset of a horizontal ray with at most one external
horizontal neighbor must be an initial interval. Thus each R_i is either
empty or R_i={0,...,c_i-1}, with c_i>=0. Omitting the favorable corner
(0,0) means 0 is absent from R_0; therefore c_0=0.

We claim c_(i+1)<=c_i+2. If c_i=0, even positions of R_(i+1) all feed
into B_i through upward rungs. There is room for at most one of them,
so c_(i+1)<=2. If c_i>0, the horizontal boundary already forces
B_i={c_i}. Every even integer in [c_i,c_(i+1)-1] must consequently be
the single point c_i. For even c_i this gives c_(i+1)<=c_i+2; for odd
c_i it gives the stronger c_(i+1)<=c_i+1. Hence c_i<=2i by induction,
and

    |S|=sum_(i=0)^(b-1) c_i <= b(b-1).                  (23)

Together (22)-(23) show that EVERY support omitting the favorable corner
and having surplus s<=b has size at most s(s-1). For s>=b+1 the asserted
lower bound in (17) is automatic. This proves its lower direction.

### Attainment of every size

For k<=b(b-1), put q=Q(k)<=b. An odd-color quadrant prefix of k rooms,
placed at the unfavorable bottom corner, has k+q neighbors. Its support
is confined to the diagonal x+y<=2q-3 in coordinates measured from that
corner, so it and its full neighborhood fit within the width 2b and omit
the opposite favorable corner. This includes every positive size in this
range; when b=1 the range is empty.

For k>b(b-1), take any finite downward color-zero pyramid P of size k+1.
Such an ideal exists at every size by finite ideal extension in a tall
enough cylinder. If its fiber at transverse vertex 1 were empty, the
distance-bound argument would give

    |P| <= sum_(i=0)^(2b-1) ceil(|i-1|/2)
         = b(b-1)+1.

Since k+1>b(b-1)+1, P contains (1,1), and hence contains (0,0).
Delete (0,0), obtaining S. Both its neighbors (1,0),(0,1) are already
neighbors of (1,1), so N(S)=N(P). Every finite pyramid on this balanced
strip has surplus at most b, because its neighborhood heights are bounded
by a+1. Hence |N(S)|<=k+b+1, matching the proved lower bound. Reflection
gives the other physical color. This completes the exact formula (17).

For a finite cylinder, the lower bound applies whenever the support
does not meet its far longitudinal row; its neighborhood is then identical
to the half-strip neighborhood. No claim is made that the formula remains
valid for supports that exploit the far boundary.

## 9. The outgoing corner and the exact missing memory in a cheap step

Write c_p for the favorable bottom corner of current color p. A companion
conditional profile in the same half-strip is

    min{|N(S)|: |S|=k, c_(1-p) in N(S)}
        =k+min(Q(k),b),   k>0.                            (24)

For the lower bound, a support of surplus s<b has a boundary-free matched
row, and splits into independent left and right quadrant parts as above.
Assume p=0. If N(S) contains c_1=(2b-1,0), the right quadrant part is
nonempty. Let its surplus be r>=2; the left part has surplus s-r and may
now contain its origin. The ordinary two quadrant bounds give

    |S| <= (s-r)^2+r(r-1) <= s(s-1),

where the difference in the last inequality is (s-r)(2r-1)>=0. This proves
the lower in (24) when s<b; for s>=b the cap makes it automatic.

For k<=b(b-1), the same odd prefix at the unfavorable corner attains
k+Q(k), and its first room is adjacent to c_(1-p). For k>b(b-1), any
downward pyramid of size k contains every bottom-parity-zero fiber, by
the sharp floor-distance bound from Section 5. In phase 0 this includes
(2b-2,0), adjacent to c_1. Its surplus is at most b. Thus both ranges
attain (24), and reflection gives the other color.

Here are exact universal transition inequalities that do not assume any
compression of the actual survivor. Let A be the current belief, let S
be its next survivor of size k>0, and suppose the far longitudinal edge
does not affect N(S). Put

    e=1_[c_p in A],        f=1_[c_(1-p) in N(S)].

Then the neighborhood surplus is at least

    min(R(k),b)                  always;
    min(Q(k),b+1)                if e=0;
    min(Q(k),b)                  if f=1.                 (25)

When several conditions hold, their maximum is a valid lower bound.
These are conditional physical inequalities; no claim is made that all
their equality cases can be realized simultaneously inside an arbitrary A.

In particular, if a small survivor has surplus s<b and k>s(s-1), it must
contain c_p by Section 8 and its neighborhood must OMIT c_(1-p) by (24).
The next day's actual belief therefore has e=0 and obeys the stronger
pronic-root lower bound in (25). This rigorously prevents two consecutive
cheap square-root steps in precisely that range.

For example, consider on 6x6 the concrete four-room corner survivor
S={(0,0),(0,2),(1,1),(2,0)}. It has surplus2 and six neighbors, all in
longitudinal rows0,...,3. Since 4>2(2-1) and 2<3, that next belief omits
its favorable corner. Every singleton retained on the next day therefore
has at least3 neighbors, not2; the far row5 cannot supply an exception.
This illustrates the incompatible cheap steps in the scalar tail
9 -> survivor4 -> belief6 -> survivor1 -> belief2. It does not by itself
exclude every possible geometric realization of that scalar trajectory.
In particular, an initial pyramid avoiding the far row can reach it after
movement; that premise must be checked separately for every use of the
half-strip bounds. The full arbitrary-interleaving 13-day impossibility
still needs its existing joint midpoint argument.

## 10. Joint corner restrictions: checkpoint before manuscript integration

This section is an ordinary proof independently accepted by Euler in
`maturation-joint-corner-independent-review.md`; it is not yet a manuscript
theorem. It uses the independently proved punctured-quadrant capacity
from `maturation-punctured-quadrant.md`:

    C_h(s)=max(s(s-1)/2,s(s-h)), h=2r+p.

Here the current favorable corner and the next favorable corner are BOTH
absent: for phase zero the forbidden source rooms are
{(0,0),(2b-2,0),(2b-1,1)}. For b>=2 the proposed exact capacities are

    surplus <= s <= b:       C_2(s);
    surplus <= b+1:          max(b(b+1)/2,b^2-2);
    surplus <= b+2:          unbounded.

The width-two case is exceptional: surplus 2 already permits arbitrarily
large sets satisfying both omissions (translate an odd-size width-two
pyramid upward by two). No full game normal-form assertion is involved.

For s<=b, a boundary-free matched row splits the set into an even quadrant
missing its origin and an odd quadrant missing its first monochromatic
diagonal. The capacities are C_2(s_left), C_3(s_right). Convexity and
C_3<=C_2 give their sum <=C_2(s). Without a boundary-free row, s=b and
every boundary row has size one. Each occupied row is a prefix. Both end
prefixes are empty, and the rung conditions give

    c_i<=min(2i,2(b-i)-1), 1<=i<=b-2.

Their sum is b(b-1)/2-1 for b>=2, at most C_2(b). The two quadrant
attainers for C_2(s) fit the strip and avoid all three forbidden rooms:
the full-block attainer ends by diagonal 2s-4, while the proper-ramp
attainer is compressed toward small transverse coordinate.

For the s=b+1 lower bound, first suppose both neighbors of the omitted
origin belong to N(S). Adding the origin leaves N unchanged and preserves
the absence of the opposite bottom corner. A set whose next favorable
corner is absent and whose surplus is b has at most b^2-1 rooms. Thus
|S|<=b^2-2. The latter auxiliary bound follows as follows. With a
boundary-free row, the weighted area calculation in the static-profile
proof has at most b-1 occupied matched rows and yields
2(b-1)b-(b-1)^2=b^2-1. Without one, all rows are prefixes, the last is
empty, and the downward odd rungs give c_i<=2(b-i)-1 for i<b-1;
summing gives b^2-1.

If a boundary-free row exists but the origin-addition argument does not
apply, use the C_2/C_3 split directly. For b>=3, a nonempty right part
keeps the total below b^2-2. If only the left part is nonempty, the sole
larger possibility is C_2(b+1)=b^2-1. Equality in the quadratic branch
forces all even diagonals 2,...,2b-2 to be full after compression. Such
a set cannot fit to the left of an empty matched row: its transverse
extent there is at most 2b-3. Compress toward the small transverse
coordinate so this width constraint is preserved. For b=2 the general
quadrant bound already gives the stated capacity 3.

It remains to check the no-boundary-free-row case. Exactly one row has
two boundary vertices; all others have one and their occupied sets are
prefixes. If both endpoint rows are empty, put alpha_i and beta_i for
the even and odd occupied column counts, and t_i,u_i for the two boundary
parity counts. Rungs imply alpha_i<=sum_(j<i)t_j and
beta_i<=sum_(j>i)u_j. Hence

    |S|<=sum_j((b-1-j)t_j+j*u_j)
         <=(b+1)(b-1)-(b-2)=b^2-b+1<=b^2-2 (b>=3).

The subtraction reserves one boundary vertex on each internal row, whose
coefficient is at most b-2. If an endpoint row is nonempty, that row must
be the exceptional row, and its support is one interval avoiding column
zero (two finite components would need at least three boundary vertices).

At the first row, failure of the origin-addition condition forces the
interval to start at least at column 2. The next row must be empty:
otherwise its prefix contains the even room at zero and places zero in
the first boundary row, contrary to the missing neighbor. The interval
has at most one odd room, hence at most three rooms. Remaining ordinary
prefixes grow by at most two per row from that empty row. Their total,
plus three, is at most (b-2)(b-3)+3, which is below b^2-2 for b>=3.

At the last row, its interval also starts at least at 2. The ordinary
prefixes satisfy c_i<=2i. If the preceding row is nonempty with length c,
its sole boundary is c, so the interval's even rooms are at most c and
its length is at most c. This bounds the total by
(b-2)(b-1)+2(b-2)=b^2-b-2. If the preceding row is empty, it admits at
most one even room of the interval, so its length is at most three and
the earlier prefixes contribute at most (b-3)(b-2). For b=2 each endpoint
case instead gives the stated bound 3. These alternatives cover all
missing-neighbor cases.

For attainment at the b+1 threshold when b>=3, take all even rooms on
diagonals 2,...,2b-2 except (2b-2,0). This gives b^2-2 rooms and surplus
b+1. Every smaller size up to that threshold has surplus at most b+1:
take a quadrant prefix of size k+1, compressed toward small transverse
coordinate, then remove the origin. For b=2 the three-room ramp
{(0,2),(0,4),(1,3)} and its two initial subprefixes suffice.

For k above the threshold, take a downward pyramid P of size k+3 and
delete all three forbidden rooms. The size forces (1,1) and (2b-2,2)
to be present: their absence bounds the original pyramid sizes by
b(b-1)+1 and b^2+1 respectively. Deleting the origin loses no neighbor;
deleting the other two rooms loses exactly the opposite bottom corner,
since their other neighbors are covered by the forced rooms and their
predecessors. Thus the resulting k-set has surplus at most b+2.

Euler independently reconstructed all branches and checked additional raw
sets and explicit witnesses; see `maturation-joint-corner-independent-check.json`.
An earlier small check, not used as proof, enumerated the 2^15
admissible color-zero supports in a width-six, six-column window. The
minimum surpluses at sizes 1,...,15 were
[2,3,3,4,4,4,4,5,5,5,5,5,5,5,5], consistent with the proposed capacities.

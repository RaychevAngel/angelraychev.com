# Independent semantic audit of ConvexCapacityConvolution.lean

13 September 2026. Euler. **PASS** on the generic core at SHA
`52a81e2540fd0aea2f1afc79ef6704b523e1b6ffc08da22c50c40e2767acb4ab`.
Root may append concrete capacity instances afterward; this receipt
identifies the reviewed version rather than silently covering later code.

The ordinary reference is the final generic convolution lemma in
`maturation-punctured-quadrant.md`. No source edits were made. An isolated
single-worker Lean check also passed in 1.866 seconds, using only
`propext`, `Classical.choice`, and `Quot.sound`; see
`maturation-convex-capacity-independent-check.json`. This was not a full
package rebuild.

## Exact mathematical meaning

`Capacity` assumes a natural-valued monotone unbounded function with
nondecreasing integer increments. It does NOT assume the desired
endpoint-maximization conclusion. It also does not require value(0)=0:
the formal result is slightly stronger than the ordinary stated version.
Positive baseline capacities cause no problem because inverse cost zero
then pays for all targets already within that baseline.

`root_spec` proves the full least-root adjunction

    root A k <= t  iff  k <= A.value t.

The finite recursion starts from an arbitrary unboundedness witness.
If the preceding index already meets the target it recurses; otherwise
monotonicity proves that the current index is minimal. The result is
independent of the chosen witness by the adjunction. This covers flat
initial capacity segments, zero targets, and arbitrarily large jumps.
There is no hidden strict-monotonicity assumption or fixed search bound.

`endpoint_maximum` proves endpoint domination for an arbitrary integer
sequence on a bounded interval directly from increasing increments. If
the last increment before y is nonpositive, all earlier increments are
nonpositive and the left endpoint dominates. Otherwise all subsequent
increments are positive and the right endpoint dominates. The special
case y=l avoids truncated predecessor indexing. Bounds ensure every
increment comparison lies within the supplied convexity interval.

`sum_convex` then derives convexity of A(i)+B(T-i), on 0<=i<=T, from
the two capacity increment axioms. The reversed B difference has the
correct sign, and the proof explicitly removes truncated subtraction
using i,j<T. Thus `extreme_capacity` is proved rather than postulated.

## Clipped candidates and all edge cases

The candidates are exactly

    y1=min(u,A(root_A(l))),
    y2=max(l,S-B(root_B(S-u))).

Natural truncated subtraction in y2 is equivalent to integer subtraction
followed by max with l>=0. The feasibility theorem places both candidates
in [l,u] under 0<=l<=u<=S.

For any interior y, set r=root_A(y), s=root_B(S-y),
a=root_A(l), b=root_B(S-u). The proof derives a<=r, b<=s and
S<=A(r)+B(s), then applies the genuine convex endpoint result.
On the left endpoint alternative, root_A(y1)<=a. If y1=A(a), the
capacity sum bounds the B remainder directly. If y1=u, the existing
bound S-u<=B(b) and b<=r+s-a provide the missing clipped-endpoint
argument. The right endpoint is symmetric, using l<=A(a) when clipped
at l. These are exactly the two delicate branches of the ordinary proof.

`exact_minimum` chooses whichever feasible candidate has smaller cost
and proves it dominates EVERY feasible z. It is an attained minimum,
not merely a lower bound or an existence claim outside the interval.
The proof handles S=0, a singleton interval l=u, roots equal to zero,
capacity values larger than S, and equality of the two candidate costs.

## Formal scope

This version proves the general arithmetic theorem. It does not by itself
construct the punctured capacity C_h, prove a graph profile, or establish
temporal compatibility of any minimizers. Its inverse is noncomputable
because the unboundedness witness is chosen classically; no execution-time
claim follows merely from having two explicit mathematical candidates.

No substantive correction was requested.

## Frozen concrete-instance delta audit

The final module at SHA
`30c532ea1413a79b2c708412763f4e9d44ed713db8ae74772cc557a30827ec7e`
also **PASSES** independent review. Its isolated kernel check took 1.169
seconds and printed the same three standard axioms for both the generic
and concrete punctured-capacity minimum. The separate final receipt is
`maturation-convex-capacity-final-independent-check.json`; the earlier
generic-core receipt is preserved.

The appended square and pronic constructors prove their capacity axioms
from multiplication and expose the exact root adjunctions for s^2 and
s(s+1). This pronic root is rho, not the odd-quadrant root with capacity
s(s-1).

`maximumCapacity` derives increasing increments from the local midpoint
convexity inequality. Whichever function wins at the middle index has
both adjacent values bounded by the corresponding maxima, proving the
needed inequality; induction then proves all increment comparisons.
It does not assume the endpoint result or a maximum-closure oracle.

The triangular capacity is defined by successive increments n, and
`triangle_value` proves its exact n(n-1)/2 expression, including n=0.
The truncated quadratic is s*(s-h) in Nat: it vanishes below h and has
increment 2s+1-h from s>=h onward. The constructor proves monotonicity,
unboundedness, and convexity for every natural h, including h=0 and the
transition from the flat segment.

The maximum of this truncated quadratic and the nonnegative triangular
capacity is exactly the ordinary integer formula
max(s(s-1)/2,s(s-h)). When s<h the integer quadratic is nonpositive
and cannot exceed the triangle; when s>=h there is no truncation.
Thus `punctured_root_spec` and `punctured_exact_minimum` instantiate the
full all-h arithmetic statement, not a modified or approximate capacity.
Static quadrant geometry, every-size geometric attainment, and all
dynamic applications remain outside this module.

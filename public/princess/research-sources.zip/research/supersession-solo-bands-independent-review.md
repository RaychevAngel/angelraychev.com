# Independent review of the uniform solo band evaluation

13 September 2026. Reviewer: three_row_all_budgets lane. Sources actually
read: `research/supersession-solo-bands.md` and
`src/supersession_solo_bands.py`. No experiment was duplicated for this audit.

**Verdict: the ordinary proof passes; no substantive gap found.**

1. The majority breakpoint list includes every change of both capped root
   branches, including the full endpoint where its surplus becomes −1.
   The minority list includes each pronic-root change and its reflected
   counterpart, including the full endpoint of surplus one. Taking a
   minimum cannot introduce a change away from the union of these lists.
2. The cutoff min(C_p,m+I_p(m)) is exactly the set of starting counts
   eliminated in at most two days. Above it, both residuals are positive.
3. The second-stage threshold for a change at residual s is the first k
   with g_p(k−m)≥m+s. Since the profile is integer-valued and monotone,
   this is m+I_p(m+s−1)+1, including when a profile jump skips a value.
   The extended inverse handles unreachable thresholds harmlessly.
4. Both surpluses are constant between the stated endpoints. Their sum
   is at most 2b+1, so the paired decrement is at least
   2m−(2b+1)≥1. This proves strict progress on every positive paired band.
5. The quotient jump takes exactly all iterations whose source stays in
   the current band. Its final source is still in the positive domain,
   so its next count remains positive even when several lower bands are
   skipped. Processing bands in descending order is therefore exact.
6. The final zero-, one-, or two-day tail follows precisely from the
   cutoff definition. Prescribed-day evaluation truncates paired jumps
   and adds the correct single physical-color transition when necessary.
7. The implementation's half-time calculation uses the initial parity
   p XOR (t mod 2) to obtain the residual in current parity p at time t.
   This correctly returns the two residuals for the existing midpoint
   theorem, without assuming which initial cohort finishes first.

The complexity statement is the number of arithmetic stages and endpoint
comparisons, not a unit-cost bit-complexity claim. The note makes that
qualification. The result evaluates solo dynamics and does not prove the
unresolved two-cohort scalar midpoint criterion. No new Lean verification
is claimed.

# Manuscript separation: 13 September 2026

This is artifact scope separation, not mathematical unification or new research.
The absolute O(1) numerical criterion is `research/CLASSIFICATION_SCOPE.md`.
The immutable old combined manuscript is `archive/2026-09-13-combined/`.

## Entrypoints and authority

- `paper/main.tex`: rectangle capture time T_k(a,b), constant budget, full initial uncertainty, directly specified optimal inspections. k=0 has the separate no-inspection/infinite convention including 1x1. The main introduction gives the established feasibility criterion.
- `paper/extensions.tex`: parked independent applications. Imports main theorem references with `xr-hyper` and the `main-` prefix, with the public main PDF as the external target. Its source package needs the paired frozen main.aux, as coordinated with the publication builder.
- `publication/manuscript-scope.json`: exact input closures, labels, shared roles, source hashes and imported aliases. All old theorem/equation labels are preserved; no main reference requires an extension result.
- One canonical `lean/` directory remains. This edit touches no Lean mathematical source. The role manifest and source hash/import checks are owned by the publication pass.

## Moved applications

The all-odd-box isoperimetric theorem and its exact graph evaluator, equal-sided higher-dimensional normal form, side-two box reduction, general cylinder profile transfer, complete 3-cube and 4-cube applications, 3x4x4 classification, the 3x3xn families, and the fixed-transverse-box period synthesis are in the parked companion. Their original proofs, labels, finite evidence references and provenance remain.

`boxes.tex` no longer contains the authoritative height proof. It imports that theorem by reference; its generic height feasibility applications remain parked. The final general box synthesis moved out of `even-cylinder-eventual-time.tex` into `fixed-box-eventual-time.tex`.

## Retained shared tools and dependency extraction

- The physical height construction is now `cylinder-height.tex` in main. Its generality is needed by the rectangle interface proofs.
- `hamiltonian-cylinder-time.tex` retains the growth bound and even-width expansion lemma; higher-dimensional examples are in `cylinder-applications.tex`.
- `even-cylinder-eventual-time.tex` retains efficient frontiers, matching/paired-column lemmas, exact physical height endpoints, owner blocks, and their existing period arguments. The main interface proof directly cites these; it does not rely on the parked fixed-box synthesis.
- `odd-period-proof.tex` is one canonical argument shared by both documents. The main prelude `odd-eventual-time.tex` is the existing rectangle specialization Q=P_W, S=W-1, Z=W^2; it uses the already proved rectangle profiles. `odd-box-eventual-time.tex` retains the original all-odd-box prelude and its 3D application. No general box nesting theorem is a main dependency. The shared-source imported-reference aliases are recorded in the manifest.
- The rectangle-profile charge certificates and affine-insertion lemmas remain main in `odd-affine-insertion.tex`, even though their current independent 3D application is parked. They are legitimate rectangle proof tools, not additional completion requirements.
- Generic whole-strategy compression, square compression and exact odd-fiber evaluators remain main as relevant tools. Their independently broader applications are identified as parked.
- The inverse fixed-deadline minimum CONSTANT budget remains in main; the general transfer proof is retained to substantiate its rectangle consequence. Varying daily capacities are a proof device, not a new objective.

## Criterion and proof-status corrections

The abstract and introduction now explicitly reject recurrence evaluation, variable-length sums, parameter-dependent preprocessing and O_(w,k)(1) algorithms as numerical completion. The width-only O(w) minimum-budget clock is an exact intermediate theorem. Its displayed finite constants through width15 give numerical formulas only for those fixed widths; no arbitrary-width closed form is claimed. The odd-length domain is stated.

Ordinary proofs, finite checks and complete physical-game Lean classifications remain distinct. Main contains the complete path and two-row classifications. The companion contains the complete 3-cube and 4-cube classifications. The 83 canonical modules are partitioned into import-closed 43-module main and 51-module companion packages with 11 shared; no full newest rectangle theorem is claimed Lean verified.

## Checks so far

The static source-reference audit has no unresolved main or companion references and no duplicate local labels. A separate read of the actual archived manuscript-source.zip found 292 original labels; all 292 survive in the active input closures (298 unique labels after adding scope headings). An isolated clean two-entrypoint LaTeX/BibTeX build passed with no final undefined-reference, missing-destination or overfull warnings: main109pages, companion31pages before the final package-count prose and external-reference markers. The publication pass performs the authoritative final builds, full PDF visual/layout verification, source-package checks and deployment readback. Page totals are artifact facts, not evidence of mathematical unification.

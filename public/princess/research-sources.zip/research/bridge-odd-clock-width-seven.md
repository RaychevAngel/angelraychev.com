# Exact formulas for the remaining seven-row odd strips

13 September 2026. Computer-assisted family theorem by the odd-clock branch;
independently reviewed and accepted by root, including the finite code,
all affine/period algebra, and the precentral endpoint. This closes the width-seven
part of residual family 4. It does not prove the varying-width midpoint
conjecture or claim full physical-game Lean verification.

## Explicit numerical result

Let n>=7 be odd. For m=6,8,9 set D=2m-7 and write

    n=7+2Dq+2j, 0<=j<D.

Then the proposed exact capture time is

    T_m(7,n)=28q+c_m(j),

with the following fixed lists, indexed starting at j=0:

    m=6: (16,21,26,32,38);
    m=8: (10,12,16,18,22,25,28,31,34);
    m=9: (8,10,13,16,18,20,23,26,28,30,33).

For the remaining budget,

    T_7(7,n)=2n-2.

These are fixed-size numerical expressions with a fixed finite case split;
they contain no unbounded recurrence, table, sum, or search. Budgets m=4,5
and m>=10 on seven-row odd strips were already covered by accepted formulas.
The new claim concerns only m=6,7,8,9 and odd lengths.

The standard two pure prefix preparations and central shot, or the doubled
solo construction, give directly prescribed optimal inspections: select the
short option exactly when its two precentral residuals sum to at most m.
Their optimality follows from the scalar-necessity proof below. No joint
optimizer is needed to specify the strategy. The precentral residuals may
be evaluated by the independently reviewed fixed-block evaluator, with
K=16 (or K=2 for these budgets); printing inspections need not take O(1).

## All-length scalar necessity from a bounded finite certificate

Use the already accepted eventual-scalar theorem, with b=3 and its explicit
constants H=b^2+1, G=m-1, K=H-1+2m*(floor(G/7)+1),
W=G+K+1, J=2K+G+2m+H+2, M*=2J+G+m(W+3).

The exact resulting onsets and the entire remaining finite ranges are:

| m | M* | Short odd lengths checked | Number |
|---|---|---|---|
| 6 | 327 | 7 through 93 | 44 |
| 7 | 393 | 7 through 111 | 53 |
| 8 | 657 | 7 through 187 | 91 |
| 9 | 777 | 7 through 221 | 108 |

The next odd length in every row has M=(7n-1)/2>=M*, so the accepted
unbounded theorem covers it and every larger odd length. Thus these 296
cases exhaust the complement; there is no induction from observed periods
in the scalar-necessity argument.

`src/bridge_odd_clock_width_seven.py` independently constructs the finite
inverse tables by inverting the exact forward neighborhood profiles. It
starts with the full-board deficit pair (0,0), enumerates every daily quota
split, and keeps the complete coordinatewise Pareto frontier. In particular
it does NOT discard low-total mixed states or impose ancestry, credit,
seriality, or scalar assumptions. Monotonicity of both inverse maps makes
coordinatewise pruning exact. It stops at the independently determined
precentral horizon and minimizes the exact capped central cost over every
pair of retained full-frontier states.

Every central value agrees with the separately implemented accepted retained
frontier solver. Every case satisfies scalar necessity. The record includes
all final full frontiers and counts 27,746,689 quota transitions; the largest
frontier has 581 states. The first completed calculation took 6.956535 CPU
seconds; the current receipt adds checks of the numerical expression below.
This is an exhaustive finite certificate used with established unbounded
theorems, rather than sampling offered as an unbounded proof. Its source hash,
all inputs, full final frontiers, both central values, and outputs are in
`research/bridge-odd-clock-width-seven-check.json`.

## Unbounded period proof for the solo clocks and central decision

The finite certificate above establishes scalar necessity. The following
separate ordinary argument evaluates that scalar answer at all lengths;
it does not extrapolate a guessed period from the finite data.

Put E=M+1=(7n+1)/2 and p in {0,1}. The accepted forward profiles become

    g_0(k)=k+min(R(k),3,R(E-k)-1),
    g_1(k)=k+min(rho(k)+1,4,rho(M-k)+1),  k>0,

with g_p(0)=0. Define f_p(x)=g_p((x-m)_+) and P_p=f_(1-p) o f_p.
The profile surpluses are exactly 3 and 4 respectively on

    5<=k<=M-9,       7<=k<=M-7.

Consequently, for m=6,7,8,9, P_p(x)=x-D on the exact common intervals

    ell_0=2m+4 <= x <= u_0=m+M-9,
    ell_1=2m+1 <= x <= u_1=m+M-7.

These follow by requiring both successive survivor inputs to lie in the
displayed single-step affine intervals. For phase one, the comparison of
the two lower and two upper constraints uses m>=6, including equality.

Starting from the full color class, the first paired step has the output

    x_0=M-D,
    x_1=M-D-e,  where e=1 if m=6 and e=0 otherwise.

To check these four budget cases directly, the first phase-zero profile
surplus is 2 and the subsequent phase-one surplus is 4. Starting in phase
one, the first surplus is 3 at m=6 and 4 otherwise; the next surplus is 3.
All their increasing lower-root terms have reached the caps already at
n=7, and remain capped at larger n. The competing reflected-root arguments
depend only on m. Neither cohort is captured in this first pair, since the
smallest resulting count is 13 and m<=9.

At every allowed n, these x_p obey

    ell_p-D <= x_p <= u_p.

The upper comparisons reduce to elementary inequalities in m>=6. The lower
comparisons are M>=2m+4 and M-e>=2m+1, both valid already at M=24.
Thus the nonnegative integer

    q_p=1+floor((x_p-ell_p)/D)

counts exactly all subsequent paired steps whose source is in that affine
interval; if q_p=0 none are taken. The residual count

    r_p=x_p-q_p D

lies in [ell_p-D,ell_p-1]. In particular,

    11<=r_0<=2m+3<=21,       8<=r_1<=2m<=18.

Every following neighborhood argument is at most 12. For n>=7 both
reflected terms are then inactive: M>=24 gives R(E-k)-1>=3 and
rho(M-k)+1>=4. Counts strictly decrease while positive because every
surplus is at most 4<m. Hence the complete terminal search from (p,r_p)
is independent of n.

Replacing n by n+2D increases M by 7D. The x_p increase by 7D, q_p by 7,
and r_p do not change. Therefore both solo durations increase by exactly
14 days.

The common precentral residuals also repeat. For clarity about its endpoint,
q_1-q_0 is 0 or 1: the numerator defining q_1 is the numerator for q_0
plus 3-e, an integer between 2 and 3, smaller than D. Let S_p=2+2q_p be
the entry time to the terminal search. Then S_1 is S_0 or S_0+2. The
phase-zero terminal search takes at least two days because r_0>=11>m;
the phase-one search takes at least one day. Therefore L=min(tau_0,tau_1)-1
is at least S_0 and at least S_1-1. At that horizon phase zero is already
in its n-independent tail. Phase one is either in its tail, or exactly at
the first intermediate step of the last affine pair. In the latter case
q_1=q_0+1>=1, and that pair's source is r_1+D, also independent of n.
Its intermediate count is given by the affine profile, so repeats too.
The added 14 days preserve physical-color parity. This proves the required
period of the two scalar precentral residuals, including the possible
one-day-before-tail endpoint.

Scalar necessity at every length, already proved above, now implies

    T_m(7,n+2D)=T_m(7,n)+28.

The fixed tables in the statement are the exact base values at
n=7,9,...,7+2(D-1), all contained in the exhaustive certificate. For m=7
the seven base values are 12,16,20,24,28,32,36, which simplify the period
formula to 2n-2. This completes the computer-assisted all-length result.

## Verification boundary

The algebraic period argument is new ordinary mathematics independently
reviewed by root. The finite part has two different exact frontier
implementations with agreement on every required board. The retained
recurrence and the explicit eventual-scalar theorem are existing accepted
dependencies. No new physical Lean theorem, manuscript integration, or
publication is claimed by this branch.

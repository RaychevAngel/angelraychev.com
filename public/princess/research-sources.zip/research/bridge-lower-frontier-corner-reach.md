# A uniform corner-reach quantity after triangle equality

13 September 2026. Ordinary proof draft and targeted model diagnostic.
This is a necessary history restriction, not a physical construction or
a matching full-board formula. The first model check uses only the
one-step consequence of the quantity below.

Let `w=2b+1`, `n>=w` be even, and `h=wn/2`. A support localized within
Manhattan radius `R` of a board corner has a useful certificate `(d,R)`:
`d=0` means the corner has the support's color, and `d=1` means the other
color. After one inspection-and-move, `(d,R)` becomes `(1-d,R+1)`.
This update does not assume any compression or shape of the inspections.

## Exact feature consequences

For `d=0`, the two own-colored corners are at distances `0,w-1`, and
the opposite-colored corners are at distances `n-1,w+n-2`. Therefore

    c <= 1 + [R>=w-1],
    e <= [R>=n] + [R>=w+n-3].

For `d=1`, the analogous bounds are

    c <= [R>=n-1] + [R>=w+n-2],
    e <= [R>=1] + [R>=w].

For an adjacent corner at distance D, its neighbors have distances
D-1 and D+1. For the diagonally opposite corner both have distance D-1;
the anchor's own two neighbors have distance one. The upper-construction
lane caught and corrected an initially weaker erosion threshold. These
statements explain the erosion bounds. They only assert upper
bounds: no corner or pair is claimed to be occupied merely because it
lies inside the ball.

## An omitted equality localization

Suppose a survivor has `q=r²`, original surplus `r`, and features

    (i,u,j,v)=(1,0,0,1),       2<=r<=b.

Its target has size `r(r+1)`. The high branch is impossible since
`h-r(r+1)>r²`. In the small corner decomposition, total area `r²`
is the square maximum; equality forces one genuine square corner
triangle `Q_r`. Thus its neighborhood is the full odd/pronic triangle
of size `r(r+1)` and radius `2r-1` about the same corner. Its certificate
is `(1,2r-1)`. In particular its next target must satisfy

    c <= 1+[2r>=w-1],
    e <= [2r>=n]+[2r>=w+n-3].

For all `r<=b`, this gives `e=0`; for `r<b` it also gives `c<=1`.
This equality direction is distinct
from the already implemented pronic-survivor to square-target flag.

For `r<b`, the same square conclusion follows directly from near-square
localization after excluding the high branch: `r²>r(r-1)`, and the
containing triangle has exactly `r²` rooms.

At `r=b`, the critical nonseparator branch requires an equality argument;
its `(i,j)=(1,0)` capacity is `b²`, not `b(b-1)`. Reflect so its empty
endpoint is `x=2b`. In the notation of the critical corner proof,
`t_(2q)<=b-q` for `0<=q<=b`, and the intervening V column has at most
`b-q-1` rooms. These bounds sum exactly to `b²`, so equality forces
every U length to equal `b-q` and every V column to equal the entire
prefix of its shorter U neighbor. Returning to physical coordinates,
the even column `x=2q` has top room `y=2b-2q-2`, and the odd column
`x=2q+1` has top room `y=2b-2q-3`. This is exactly the full even triangle
`x+y<=2b-2`. Thus the critical equality also localizes; this explicit
mapping was independently checked by the upper-construction lane. The current diagnostic conservatively
uses only the already reviewed square triggers `r<b`.

## Merger inheritance of the one-step consequence

Suppose a synthetic merged transition triggers the square equality at
radius `r`. If both component original surpluses were positive, each
would be at most `r-1`. If a component is small, its closed survivor is
at most `(r-1)²`, so the merged survivor is at most that quantity,
contradicting `q=r²`. If both components are high, the accepted merger
capacity inequality bounds the merged target's holes by at most `r²`,
contradicting `h-r(r+1)>r²`. A critical exception is unavailable when
both positive surpluses are strictly below `r<=b`.

Thus one component has original surplus zero. The empty alternative is
excluded by the positive guarded merged survivor `q=r²`, so that
component is full-to-full at zero cost. Merger formation is the identity on the constrained
component. The merged flag is defined from its own triggering event.
On the following move its corner and erosion counts are at most the
corresponding counts of that flagged component, so both upper bounds
transfer. The flag then clears unless a new trigger occurs. This proves
the guarded merger for the one-step consequence.

## Persistent two-radius version

Retain two bounds `rho[0],rho[1]`, one for each relative anchor color;
infinity means no certificate. Each finite value certifies containment
about SOME corner of that relative color. Several certificates with the
same relative color may have different anchors, but the smallest radius
gives the strongest of the above feature bounds, so only that radius is
retained. No assertion identifies different anchors.

Every move first sends the pair to `(rho[1]+1,rho[0]+1)`. An exact
pronic-survivor event giving square target `r²` tightens coordinate zero
to at most `2r-2`. The square-survivor event above tightens coordinate
one to at most `2r-1`. Both operations are coordinatewise minima. Apply
both feature bounds after propagation and after any tightening. Radii
at least the board diameter `w+n-2` give no restriction and may be
represented by infinity.

This persistent update preserves the merger. The invariant for each
relative color is

    rho_merged[d] >= min(rho_component1[d],rho_component2[d]).

It holds initially. Propagation preserves it. Each merged localization
trigger is an identity merger by its corresponding formation proof, so
one component undergoes the same coordinate tightening. Extra component
triggers only decrease the right-hand side and cause no problem. Hence
the invariant continues to hold. For each merged radius certificate,
some component has an equal or stronger certificate. The merged corner
and erosion counts are at most those of that component, and the radius
feature bounds are monotone. Thus every new merged feature restriction
holds. The two coordinates may have different component witnesses;
the argument never needs a common anchor or a common witness.

The strict precapture merger guard is unchanged. The resulting model
still gives only necessary histories. Its exact finite clock can be
combined with the shared-budget bridge, once that clock and its
preterminal residual have been checked.

The upper-construction lane independently reviewed the equality
localization, identity formation (including the empty alternative), and
the persistent per-coordinate invariant. The root lane is independently
reviewing the integrated theorem.

## The surviving 25x26 witness

The strongest prior flagged model with the day-28 joint barrier still
has a 187-day solo path. Its first cardinality below both anchored
trajectories occurs at day 172, but the earlier impossible event is:

| Day | Survivor | Target | Surplus |
|---|---|---|---|
| 165 | `(100,1,0)` | `(110,0,1)` | 10 |
| 166 | `(97,0,1)` | `(108,0,1)` | 11 |
| 167 | `(95,0,1)` | `(106,1,0)` | 11 |

The day-165 equality localizes its target within radius 19 of a corner.
The next support lies within radius 20, whereas neighbors of either
opposite-colored corner lie at distance at least 24. Thus day 166 must
have erosion zero, contradicting the recorded value one. Independently,
day 167 cannot have its recorded own-colored corner: its distance is at
least 25, while the support radius is at most 21.

The later three-day transfer from a full square triangle of size 100 to
the neighborhood of one of size 81 is physically feasible at budget 13.
It therefore supplies no local obstruction. The upper-construction lane
independently replayed that transfer, charging 39 total inspections.

## Bounded persistent-model check

The exact two-radius update, including the corrected adjacent-corner
erosion distances, gives solo clock 188 on 25x26 at budget 13 after the
independently proved day-28 joint barrier. Its preterminal minimum size
is 2, so the merger proves the full lower bound 375, not 376.
With only subcritical square triggers, the run accepted 4,181 augmented
states, considered 5,887,664 directed edges, and took 3.29 seconds using
the cached base graph. The receipt is
`bridge-lower-frontier-filtered-witness-persistent.json`; it contains a
shortest necessary-model witness, not a physical strategy.

The search uses a sound monotone dominance reduction: at the same base
feature, an earlier state with both radius bounds at least as large
admits every future path of a state with smaller bounds. The corner and
erosion filters are monotone in both bounds, and both propagation and
trigger tightening preserve the coordinate order. Thus dominated states
may be discarded for shortest capture and preterminal minimum size.
The queue is processed in breadth-first order; a dominating certificate
is always reached no later than the state it discards. All accepted
states at depths strictly smaller than the first capture are included
in the residual minimum. The upper-construction lane independently
reviewed this dominance argument and implemented a separate search that
does not compare or discard different radius pairs. Its grouped bitsets
explore 276,525 augmented states in 362 radius pairs and 141,443,639
feature-filtered edges, confirming solo 188 and preterminal minimum 2.
The independent receipt is `bridge-upper-transport-persistent-verified.json`.

The same lane independently replayed a physical full-board strategy in
375 days: the anchored solo strategy takes 188 days and ends with two
rooms, so its reflected central union uses four inspections. The receipt
`bridge-upper-transport-25x26-prefix.json` verifies full capture literally.
Together the ordinary merger theorem and these finite checks establish

    T_13(25,26)=375.

This exact instance uses only subcritical square triggers and therefore
does not depend on the separate critical-equality extension. No uniform
all-length evaluation of the persistent model is inferred from one case.

The old one-step square flag alone still gives 187 solo days, since it
merely postpones the impossible orientation change from day 166 to day
168. This is the reason persistent radius information, rather than
another isolated forbidden pair, is used.

## A terminal envelope usable uniformly in the long side

A separate per-feature computation starts with unknown radii `(49,49)`
and the fixed 25x26 corner-distance bounds. At size157, each of the three
classes with `c=0` needs71 days; each class with `c=1` or `c=2` clears in70.
At size156, the three `c=0` classes clear in69. The old unflagged
backward bound already excludes every size above157 from70-day capture.
Therefore a necessary interval HULL for the new70-day capturable states
is

    D70(c,e)=156 if c=0, and157 if c=1 or2.

This statement does not assert that the flagged capturable set is an
interval. An outer hull suffices. The independent per-feature receipt is
`bridge-upper-transport-terminal-feature-verified.json`.

Direct substitution of this hull into the old nine-threshold predecessor
operator gives `E157`, the all157 vector, after one update. This is one
day later than the old unflagged capture sequence reached that vector.
The numeric lane is using this finite terminal correction with its
already proved exact two-step plateau and fixed high-side exit to obtain
the all-length lower bound.

The terminal certificate is independent of larger even lengths: any
successful70-day path remains within size157 at every suffix, by the
old backward bounds. In that range, on every25xn with n>=26, closed
surpluses at most12 have no high branch, state upper bounds do not bind,
and hole-based interval/history rules do not activate. All remaining
capacity and equality-trigger rules are the same. The fixed26 radius
bounds, saturated at49, are conservative for every larger n. Thus this
is an identical necessary terminal computation throughout the family;
no sampled affine extrapolation or flagged interval theorem is needed.

# Eliminating the quota in a prospective orientation crossing

13 September 2026. An exact elementary feasibility reduction for a fixed
pair of target deficits, independently reviewed and accepted by root. It does not prove orientation on genuine solo
orbits, and its variable target search is not a numerical endpoint formula.

Suppose the old faster solo capacity is A>B, its initial cohort remains
faster after movement, and its new physical color is p. Let g_p be the
exact neighborhood profile, so I_p is its maximal inverse. Consider a
prospective crossed mixed target(u,v), where u is ancestry-primary,
v is ancestry-secondary, 0<u<=v, and u+v exceeds the new smaller solo
capacity. Both targets are strictly below their color-class capacities.

The inputs that give these exact maximal inverse outputs form the integer
intervals

    [Ulo,Uhi]=[g_p(u),g_p(u+1)-1],
    [Vlo,Vhi]=[g_(1-p)(v),g_(1-p)(v+1)-1].

An empty interval means that the target is skipped by the maximal inverse.
The upper endpoints matter: an inverse plateau allows input strictly
above the least input without increasing the output. Thus replacing these
intervals by their left endpoints is not a valid necessity argument.

There exists an old oriented source(a,s), with

    a>=s>=0, a<=A, s<=B, B<a+s<=A,

and a full quota split producing precisely(u,v), if and only if both
input intervals are nonempty and

    max(Vlo,B+m+1-Uhi)
       <= min(Vhi,B+m,A+m-Ulo,Uhi+m,floor((A+2m)/2)).  (1)

Proof. With q probes assigned to the secondary, put
X=a+m-q and Y=s+q. Then the source total is S=X+Y-m. Such a source
exists exactly when

    B+1<=X+Y-m<=A,  Y<=B+m,  Y-X<=m,

in addition to X,Y lying in their respective input intervals. Indeed the
source secondary can be chosen as s=max(0,Y-m). The displayed inequalities
give s<=B and2s<=S; setting a=S-s then gives a>=s, a<=A and
0<=q=Y-s<=m. Conversely every valid source and quota satisfy them.

For a fixed Y, the admissible X interval is

    max(Ulo,Y-m,B+m+1-Y) <= X <= min(Uhi,A+m-Y).

Pairwise comparison of these lower and upper endpoints gives precisely(1).
The condition B+1<=A is already assumed. This proves the reduction.

## Why two preceding synthetic solo steps still do not suffice

On11x11 at budget7 the synthetic full-quota trace

    (4,5) -> (9,7) -> (10,12) -> (15,12)

is coordinatewise nondecreasing, has gaps at most3, and starts above both
genuine first-day capacities(4,4). At source(10,12), take ancestry-primary
physical color1 and source(primary,secondary)=(6,6). It is exceptional.
Giving all7 probes to the secondary yields new(primary,secondary)=(4,9),
whose total13 exceeds the new smaller capacity12 while reversing the
numerical orientation. Thus even two genuine full-quota update formulas
from a synthetic earlier pair do not prove the desired closure. The
initial pair(4,5) is not on the actual full-start solo orbit.

The outstanding possibility is that(1) is impossible at every TRUE solo
layer for any crossed exceptional target, or that every such candidate
is dominated by a correctly oriented reachable frontier point. Neither
claim is established by this elimination.

# Superseding theorem investigation

13 September 2026. Resumed by explicit user instruction. The target remains
the complete two-dimensional optimal-time classification. The priority is
strict strengthening that makes old statements consequences, not additional
isolated parameter families. Lines run concurrently rather than sequentially.

- Dirac: all-budget odd-rectangle midpoint criterion; attack the capped two-copy
  deficit inequality and account for the full initial condition.
- Socrates: necessary geometric state and attainable transitions on even-short
  rectangles at arbitrary budget; do not assume scalar nesting or a partial-state
  compression already contradicted by examples.
- Euler: independently audit and extend the odd-short/even-long historical
  potential; seek a common mechanism with odd high-budget time.
- Root: evaluate the solo recurrence uniformly by its finitely many square/pronic
  transition bands, then connect boundary/interior formulations and audit new proofs.

Every proposed theorem must record old conclusions recovered, added scope,
algorithm/construction strength, and remaining proof obligations. No unreviewed
claim enters the shared manuscript. Existing complete Lean classifications retain
that guarantee even when an ordinary general theorem subsumes their numerical result.

Starting account readback: 57% used, 43% remaining. Stop new research and finish
publication/verification at 10% remaining. Princess arXiv submission is outside
this run. Research repository began clean at 10a4cac053da8a25c9603bfd9f07edc9afc30a0e.

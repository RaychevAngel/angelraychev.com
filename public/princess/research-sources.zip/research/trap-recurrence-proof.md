# Exact recurrences, antichain barriers, and parity feasibility

Research note, 12 September 2026 UTC. These are general foundations derived in
the present investigation, not a claim of novelty for standard finite-state
reachability or antichain methods. The purpose is to turn Angel's partial-state
and incomparable-barrier intuition into exact statements usable in the grid
problem. The statements below do **not** assume that an optimal strategy has a
particular geometric shape.

## 1. Model and the necessary semantic qualification

Let $G=(V,E)$ be a finite graph. A belief $B\subseteq V$ records all possible
current rooms. A legal inspection $S\subseteq V$ has $ |S|\le m$. Conditional
on missing, and after the compulsory move, the next belief is

\[
 F(B,S)=N(B\setminus S).
\]

Here $N(A)=\{v:\exists u\in A,\ uv\in E\}$ is the union of individual
neighbor sets. We do **not** delete vertices belonging to $A$ from this union:
when a belief contains adjacent vertices, one possible target can move into
another vertex of the same belief. Some graph-theory sources instead use
$N(A)$ for the external boundary, so this convention must be explicit.

We assume every vertex has a neighbor. This is essential when using emptiness
after the move as a capture certificate: otherwise an uninspected isolated
vertex disappears under $N$, although it was not inspected. Degenerate
one-room boards must be handled separately, or the game at dead ends must be
defined differently.

An induction on time shows that $v\in B_t$ exactly when a legal target walk
reaches $v$ after avoiding all previous inspections. Thus $F(B,S)=\varnothing$
is equivalent to capturing every surviving trajectory in the current round.
This bridge already exists in `lean/BeliefSemantics.lean` and is used directly
by the new formal recurrence theorem.

An inspection strategy can be represented by a fixed sequence of sets: before
capture, the only observation is "miss", so there is only one continuing
observation history. Computing the next inspection from the current belief
does not provide additional information beyond that sequence.

## 2. Horizon recurrence and downward closure

Define $W_t$ to be the beliefs clearable in at most $t$ rounds. Then

\[
 W_0=\{\varnothing\},\qquad
 W_{t+1}=\{B:\exists S,\ |S|\le m,\ F(B,S)\in W_t\}.
\tag{1}
\]

Although the recurrence literally counts exactly $t$ belief transitions,
it also means at most $t$ actual capture rounds: the empty belief stays empty
under every subsequent legal inspection. In particular $W_t\subseteq W_{t+1}$.

Each $W_t$ is downward closed under inclusion. For $t=0$ this is immediate.
If $A\subseteq B\in W_{t+1}$, use the same first inspection $S$. Since

\[
 F(A,S)\subseteq F(B,S),
\]

the induction hypothesis gives $F(A,S)\in W_t$, proving the assertion.

The exact minimum time satisfies the Bellman recurrence

\[
 T(\varnothing)=0,\qquad
 T(B)=1+\min_{|S|\le m}T(F(B,S))\quad(B\ne\varnothing),
\tag{2}
\]

with $\infty$ allowed. The minimum is attained because the graph has finitely
many inspection sets. Formula (2) is an exact recurrence, but its raw state
space has $2^{|V|}$ beliefs. The main unresolved mathematical task is finding
a small sufficient structural description of these beliefs.

On a graph with $N$ vertices, (1) stabilizes by $W_{2^N-1}$. Either an earlier
step adds no beliefs, in which case all later steps are identical, or every
step adds at least one of the $2^N-1$ nonempty beliefs. Equivalently, a
shortest successful path in the belief graph visits no nonempty belief twice.
Hence every finitely clearable belief is clearable within $2^N-1$ rounds.
This bound is a decidability statement, not a practical complexity claim.

## 3. Exact backward recurrence through erosion

For a desired next belief $D$, define the graph erosion

\[
 I(D)=\{v\in V:N(\{v\})\subseteq D\}.
\]

Then the following equivalence is exact:

\[
 F(B,S)\subseteq D
 \quad\Longleftrightarrow\quad
 B\subseteq I(D)\cup S.
\tag{3}
\]

Indeed every uninspected vertex of $B$ must have all its neighbors in $D$,
and this condition is also sufficient. For a directed graph, use outgoing
neighbors; symmetry is not needed for (3).

Let \(\mathcal A_t=\operatorname{Max}_{\subseteq}W_t\) be the inclusion-maximal
winning beliefs. Downward closure and finiteness give

\[
 W_t=\{B:\exists D\in\mathcal A_t, B\subseteq D\}.
\]

Consequently

\[
 \boxed{\quad
 \mathcal A_{t+1}=
 \operatorname{Max}_{\subseteq}
 \{I(D)\cup S:D\in\mathcal A_t, |S|\le m\}.
 \quad}
\tag{4}
\]

Every set on the right is winning: after inspecting $S$, its remaining
vertices have all neighbors in $D$. Conversely, a winning belief has a first
inspection whose next belief lies below some $D\in\mathcal A_t$, and (3)
puts it below $I(D)\cup S$. This proves both directions and justifies deleting
dominated candidates after every step. There is no assumption that the
maximal beliefs form a chain; incomparable shapes are retained.

Only inspections outside $I(D)$ affect the union in (4). If enough vertices
remain, one may use exactly $m$ new vertices because larger generated sets
dominate smaller ones. This is an implementation simplification, not a claim
that the resulting antichain is small.

## 4. Impossibility as an upward-closed trap

A family \(\mathcal U\) of beliefs is a **trap** if

1. \(\varnothing\notin\mathcal U\);
2. for every \(B\in\mathcal U\) and every legal inspection \(S\),
   \(F(B,S)\in\mathcal U\).

If the initial belief lies in a trap, no legal sequence can clear it: induction
keeps every subsequent belief inside \(\mathcal U\).

Conversely, let

\[
 L=\{B:B\notin W_t\text{ for every finite }t\}.
\]

Then $L$ is itself a trap. It does not contain the empty belief. If a legal
inspection from $B\in L$ reached a belief in some $W_t$, that inspection
followed by its successful continuation would place $B\in W_{t+1}$, a
contradiction. Moreover every other trap is contained in $L$.

Thus **finite guaranteed capture is impossible exactly when the initial belief
belongs to a trap**, and $L$ is the greatest such trap. These equivalences do
not require a finite graph. Finiteness is used for the bounded algorithm and
finite antichain representation. We do not use this statement to assert a
separate theorem about eventual capture with no uniform time bound on arbitrary
infinite graphs.

Since each $W_t$ is downward closed, $L$ is upward closed. On a finite graph
it is therefore specified exactly by its inclusion-minimal antichain
\(\mathcal C=\operatorname{Min}_{\subseteq}L\).

More generally, an explicit nonempty-belief family \(\mathcal C\) certifies
impossibility from every belief containing one of its members if

\[
 \forall C\in\mathcal C\ \forall S,\ |S|\le m,\quad
 \exists C'\in\mathcal C: C'\subseteq N(C\setminus S).
\tag{5}
\]

To prove this, take the upward closure of \(\mathcal C\). Neighborhood
monotonicity extends (5) from the generators to every belief containing one.
No comparability or ordering of the generators is needed. Removing a generator
that contains another preserves the upward closure. Conversely, the minimal
antichain of $L$ satisfies (5), so this certificate format loses no information.

This gives a precise realization of Angel's proposal: after each legal probe,
one may move between several incomparable partial-state barriers, but some
barrier is always still contained in the possible locations. Cardinality alone
need not describe the barrier.

## 5. Bipartite feasibility reduces to a single initial parity

This equivalence is **known**, not a new contribution. Dissaux, Fioravantes,
Gahlawat, and Nisse, *Recontamination Helps a Lot to Hunt a Rabbit* (MFCS 2023),
state it on printed pages 42:2 and 42:5 and attribute it to Abramovskaya et al.
Their [primary paper](https://d-nb.info/1367155517/34) was checked directly.
The following is an independent short reconstruction for the current notation.

Let $V=E\mathbin{\dot\cup}O$ be a bipartition, and suppose empty inspections
are legal. The following three statements are equivalent for a fixed budget:

- the whole graph is finitely clearable;
- the full initial parity class $E$ is finitely clearable;
- the full initial parity class $O$ is finitely clearable.

Necessity follows by restricting the initial belief. If $E$ is clearable,
start from $O$, make an empty inspection, and move. The new belief is contained
in $E$, so the same clearing strategy works. This proves that one parity is
clearable if and only if the other is.

Now run an $E$-clearing strategy of length $t$ from the full graph. The
initial $E$ cohort is gone. Every surviving trajectory therefore started in
$O$, and its current vertex lies in $O$ when $t$ is even and in $E$ when
$t$ is odd. Apply a clearing strategy for that full parity class. Downward
closure makes it valid for the actual remaining subset.

This proves equality of the three minimum feasible budgets. It does **not**
claim equality of their optimal times: clearing the two cohorts sequentially
may be slower than sharing the budget between them. The proof does not require
that moving the full parity covers the opposite class; containment suffices.
The no-dead-ends assumption enters only when interpreting empty beliefs as
actual capture.

For computation, the single-cohort state space consists only of subsets of one
parity or the other: $2^{|E|}+2^{|O|}-1$ distinct beliefs, counting the empty
belief once. Thus a $3\times3\times3$ cube needs at most $2^{14}+2^{13}-1$
single-cohort states for an exact feasibility calculation, instead of $2^{27}$
unrestricted initial-belief states. This is a real reduction; all-budget
optimal time still requires tracking the simultaneous uncertainty of both
cohorts.

## 6. What algebra might and might not resolve

The recurrences naturally involve unions, inclusion, minima, and addition of
one day. They are not automatically ordinary linear recurrences with constant
coefficients, so characteristic roots and complex powers are not yet the right
default tools. If a finite list of frontier types with bounded auxiliary
parameters can be proved sufficient, transfer matrices over Boolean or min-plus
operations become plausible. A proved recurrence may then reveal periodic
residue classes, piecewise linear or quasipolynomial formulas, or a useful
generating function. None of those output forms is assumed here.

The priority is therefore to discover and prove an exact state compression.
Equations (4) and (5) provide dual tests: a proposed winning shape family must
cover every relevant predecessor, while a proposed losing family must survive
every legal inspection. Both can be attacked by small counterexample searches.

## 7. Formal verification boundary

`lean/CaptureRecurrence.lean` imports only the existing general semantics module
and Std. It proves:

- belief-transition monotonicity and downward closure of horizon winning sets;
- upward closure of the losing set;
- equivalence between losing and membership in a trap;
- the greatest-trap property;
- the generator criterion (5), for an arbitrary family of barriers;
- persistence of winning with a longer horizon;
- the erosion equivalence (3);
- the exact backward recurrence and its arbitrary-generator version, giving (4)
  once a maximal family is supplied;
- equivalence with legal inspection schedules;
- equivalence with capture of all actual surviving walks, with the explicit
  no-dead-ends hypothesis.

The module quantifies over an arbitrary legal-probe predicate. The specialization
"at most $m$ rooms" is direct; no particular graph or budget is hardcoded.
There are no admitted proofs or additional axioms. The purely logical trap
theorems use no axioms at all; extensionality/classical reasoning elsewhere uses
the ordinary Lean axioms reported by the compiler.

The finite-state bound, extraction of a finite minimal/maximal antichain, the
single-parity feasibility lemma, and prospective algebraic consequences are
ordinary arguments in this note, not presently formalized in this module.

# Independent all-budget four-cube semantic audit

12 September 2026. Reviewer: the separate recurrence/formula lane.

**Pass.** `FourCubeClassification.can_capture_iff` and `exact_minimum`
have the intended physical meaning on the actual 4 by 4 by 4 grid for
every natural daily inspection budget. This extends the independently
reviewed critical budget-eight chain; no source correction was necessary.

The final classification is infeasible for m<=7; its finite times are
40,20,16,12,10,8,7,6,5,4,3,2,1 at budgets/ranges respectively
8,9,10,11,12,13--14,15,16--17,18,19--25,26--31,32--63,64 and above.
The zero returned by `turns` at infeasible budgets is used only as a
sentinel; `can_capture_iff` separately proves no actual finite capture.

Reviewed semantic interfaces:

- `FourCubeTimeCounter.physical_step` uses a finite rank inequality for
  full allocation, then monotonicity to permit any p+q below the selected
  budget. Its comparison direction is correct: allocating unused probes
  can only make the relaxed next counts smaller. Every count is bounded
  by 32, and the selected budgets are at most 31, matching the finite
  quantifier bounds of the checked tables.
- `FourCubeProfileGeometry.profile_lower` obtains its profile inequality
  for an arbitrary predecessor-closed monochromatic subset through the
  generic checker, with the size and neighborhood tables interpreted as
  actual room sets. It does not silently assume all arbitrary subsets are
  cardinality prefixes or that the cardinality profile is an exact game.
- `FourCubeAllLower.part_next_profile` bounds actual surviving counts
  after arbitrary shots, using truncated subtraction and profile
  monotonicity in the correct direction. Its closed-survivor hypothesis
  is supplied by the physical normal-form theorem, so it is absent from
  `actual_endpoint_lower`.
- `actual_impossible_7` keeps each parity count at least 21: at most
  seven inspections leave at least fourteen survivors, whose neighborhood
  has at least 21 rooms. Starting both counts at 32 and alternating the
  parities gives an invariant at every length. This proves impossibility
  for arbitrary finite schedules, rather than failure of a bounded search.
- `actual_endpoint_upper` verifies every explicit finite inspection list
  against the actual 64-room adjacency and its selected budget. Its
  positive schedule length explicitly justifies turns-1 as the final
  zero-based round. Budgets at least 64 use a direct full-board inspection.
- The lower selector takes a proved budget at least m, while the upper
  selector takes a construction budget at most m. Both directions are
  correct for interpolation over the displayed ranges. The separate
  one-day obstruction covers all budgets below 64. The final theorem
  combines an actual attaining schedule with a universal actual-schedule
  lower bound, and feasibility guarantees its reported time is positive.

No duplicate Lean rebuild was run during this review, because the author
was already collecting a fresh full dependency receipt. A separate direct
coordinate replay read all twelve published endpoint schedules, rebuilt
neighbors from coordinate differences, and confirmed each budget and its
first capture day. All twelve passed; the receipt is
`four-cube-all-budget-semantic-replay.json`.

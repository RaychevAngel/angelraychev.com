# Critical orientation down to the pronic corner threshold

13 September 2026. New ordinary geometric proof, submitted for independent
review. No Lean claim. This is a necessary restriction on arbitrary physical
survivors, not a sufficiency statement about a family of compressed shapes.

## The unbounded statement

Let w=2b+1>=3 and n=2ell>=w, and put h=w*ell, B=b(b+1), C=b(b-1).
Use physical coordinates 0<=x<=2b, 0<=y<2ell and checkerboard color p.
If a color-zero support S satisfies

    |N(S)|-|S|=b,       C<|S|<h-B,

then S contains at least one of (0,0),(2b,0), while N(S) contains neither
(0,2ell-1) nor (2b,2ell-1). Color one has the reflected assertion.
Consequently two successive survivors in this enlarged cardinality
interval cannot both have surplus b.

After such a survivor, every next survivor A of size a<=b^2 satisfies

    |N(A)| >= a + min(Q(a),b+1),

where Q(0)=0 and Q(a)=min{q>=1:a<=q(q-1)} for a>0.
This extends both the incompatibility and the terminal-corner consequence
of Lemma `lem:odd-short-critical`, whose interval began at b^2.
It does not by itself establish an exact full-board capture time.

## 1. Contraction and the anchored area calculation

Match (x,2j) with (x,2j+1), identifying a color-p room with (x,j) by
y=2j+((p-x) mod 2). For p=0 the contracted graph D has loops,
bidirectional edges in x, downward j-edges on U={0,2,...,2b}, and upward
j-edges on V={1,3,...,2b-1}. Its outside directed boundary H has b
vertices, and the contracted support R is outgoing-closed in D-H.

Suppose two consecutive x-columns avoid H. They form a strongly connected
ladder, and all horizontal rows avoiding H lie in the same strongly
connected component K. Such a row exists because ell>=b+1. Closure implies
that R contains K or avoids K.

The accepted anchored-area proof applies at this critical value provided
there is this adjacent unmarked pair: every outgoing-closed set avoiding K
has size at most b^2. For completeness, its only possible odd-path matching
exception is a selected full majority U in a row. Each V column is then
selected or marked in that row; following its directed ray toward an empty
anchor requires a mark in the same column. All b marks would occupy exactly
V, contradicting the adjacent unmarked pair. Thus the row inequalities
used below hold. The same reasoning applies in the transposed graph.

If R contained K, its transposed complementary support
V(D) minus (R union H) would avoid K and have size at most b^2. This would
give h-|R|<=b^2+b=B, contrary to the hypothesis. Hence R avoids K.

Choose a horizontal anchor row r avoiding H. It is empty in R. Let W and
W' count boundary marks at j<r and j>r, respectively. Thus W+W'=b.
The standard anchored row calculation gives at most W^2 selected vertices
on the near side j<r. On the far side the sharper bound is W'(W'-1).
Here are all details of the extra unit per occupied row.

For j>r let alpha_j count selected U vertices, beta_j selected V vertices,
t_j boundary U vertices, and w_j all boundary vertices. Downward closure
gives alpha_j<=sum_{r<i<j} t_i. A nonempty subset of the minority V of the
odd path has at least one more horizontal neighbor than vertices. Thus,
when beta_j>0, beta_j<=alpha_j+t_j-1. If beta_j=0 but the row is occupied,
alpha_j>=1 and the same total bound follows. Every occupied row therefore
satisfies

    |R_j| <= w_j + 2 sum_{r<i<j} w_i - 1.

Every occupied row contains a boundary mark, since a boundary-free row is
either entirely selected or empty and here belongs to K. If a rows are
occupied, reserve one mark in each. The weights of these reserved marks
in the summed inequality are 1,3,...,2a-1, while every other mark has
weight at most 2a. Subtracting one per occupied row gives

    |R above r| <= a^2+2a(W'-a)-a <= W'(W'-1).

The final inequality holds since the difference is
(W'-a)(W'-a-1)>=0 for integer 0<=a<=W'. The identical calculation without
the minus one, using the majority matching bound whose exception was
excluded above, gives W^2 on the near side.

Consequently

    |R| <= W^2+W'(W'-1).

If W'>=1, convexity in W' on {1,...,b} bounds the right side by the larger
of (b-1)^2 and b(b-1), hence by C. Therefore |R|>C forces W'=0.
All boundary marks, all of R, and all of N_D(R)=R union H lie strictly
below the anchor r. In particular N(S) omits both far corners.

The two unmarked x-columns belong to K and contain neither R nor H.
They split S into two pieces with disjoint neighborhoods. Both pieces
have exactly their full neighborhood when viewed in their respective
near-corner nonnegative quadrants: the two empty transverse columns
separate them, and the empty matched anchor row prevents any far-end
clipping. The current physical color is even at each of these two origins.
If both near corners were absent, the punctured-quadrant theorem would give
piece capacities C_2(s_i)<=s_i(s_i-1), with s_1+s_2=b. Hence

    |S| <= C_2(s_1)+C_2(s_2) <= b(b-1)=C,

a contradiction. This proves both corner conclusions in the adjacent-pair
case. In fact S is then a single sharing-neighbor component based at one
near corner, contained in the triangle of coordinate-sum at most 2b-2
relative to that corner. Indeed two nonempty components require b>=2 and
have total square capacity at most (b-1)^2+1<=C; the connected occupied diagonals each
consume a surplus unit. This stronger localization is not needed below.

## 2. The exceptional alternating boundary

If no adjacent columns avoid H, a vertex cover of the path on 2b+1 columns
using at most b columns must be exactly V. Thus H consists of one vertex
(v,c_v) in each V column; U columns are unmarked. Every U fiber is a prefix
of length t_u, since its downward ray is unbroken. Horizontal closure gives

    R_v subset R_u,       R_u minus R_v subset {c_v}

for every adjacent pair uv. In particular adjacent U lengths differ by
at most one.

No U fiber is full. This can be proved before assuming any shape for V.
If t_(2j)=ell, set e_i=ell-t_(2i). Then e_j=0 and e_i<=|i-j|.
The number of missing vertices of each V fiber is at most the smaller
deficiency of its adjacent U fibers plus one. Summing gives

    h-|R| <= j(j+1)+(b-j)(b-j+1) <= b(b+1)=B,

contrary to the upper size restriction.

Since all U fibers are nonfull, R_v cannot reach j=ell-1. If it contained
a vertex above its sole mark c_v, its upward ray would reach that missing
endpoint. Thus every V fiber is also a prefix, and its length satisfies

    t_v <= t_u <= t_v+1       for each adjacent uv.

The neighborhood leaves every U fiber unchanged. Their nonfullness proves
that neither far corner lies in N(S).

Finally, if both near U endpoints had length zero, then

    t_(2i) <= min(i,b-i),
    t_(2i+1) <= min(i,b-i-1).

The sum of these bounds is b(b-1)/2<=C, again a contradiction. At least one
near corner belongs to S. This completes the unbounded orientation proof.

## 3. Successive survivors and the small-corner consequence

The next physical survivor is a subset of N(S), so it omits both of its
own favored board corners. Were it itself critical in the enlarged
interval, the reflected result just proved would require at least one
of those corners. This proves incompatibility without assuming a spatial
normal form for either support.

Let that next survivor A have size a<=b^2 and surplus s. Suppose s<=b.
If s=b, the theorem already proved implies a<=b(b-1): its upper size
condition is automatic since h-b^2>B. If s<b, the accepted matching
dichotomy excludes the co-small case h-a<=s(s+1), again because a<=b^2
and h>=(2b+1)(b+1). Thus A avoids the common component. An empty matched
row and two empty consecutive columns split it into four genuine corner
quadrants, exactly as in `research/resumed-even-corner-profile.md`.
Its two even quadrant pieces omit their origins and have capacity C_2;
the other two pieces have odd capacity C_1. Both capacities are at most
u(u-1) at surplus u. Additivity gives a<=s(s-1). This also holds at s=b
by the preceding critical argument. Therefore either s>=b+1 or s>=Q(a),
proving the displayed small-corner bound. The empty support is immediate.

## 4. A dual critical restriction

If surplus is b and b^2<|S|<h-b^2, then S contains BOTH corners of its
own color, while N(S) contains at most one opposite-colored corner.
To prove this, let A be the opposite color class minus N(S). Its size is
h-|S|-b, strictly between C and h-B. Its surplus t is at most b. Were
t<b, the old size dichotomy would give |A|<=t^2 or h-|A|<=t(t+1).
The first fails since |A|>C>=(b-1)^2; the second fails since
h-|A|=|S|+b>b^2+b. Thus t=b and N(A) equals the own color class minus S.
The critical theorem applied to A gives the two asserted corner counts.

This is stronger than merely carrying the direct theorem's one-corner
presence. It also covers co-large survivors with b^2<h-|S|<=B.
The complete 9x10 SCC enumeration was rerun with this additional dual
check; every one of its 205709 surplus-four supports passed.

## 5. What the combined transition relaxation establishes

`src/resumed_odd_even_corner_history.py` combines the subcritical four-corner
capacity theorem, the enlarged critical history, the old guarded co-large
history, and the preceding dual critical restriction. It retains EVERY
allowed larger surplus and corner count; it does not discard large states
or assume dynamic monotonicity. The exact joint exploration uses bitset
reachability only to accelerate a conventional breadth-first search.

Before the dual restriction, the joint lower bounds were 60 for 7x8,k=4
and 90 for 9x10,k=5. After it they are respectively 64 and 96. The latter
matches the separately replayed explicit palindrome upper of 96; the
former remains below the upper of 68. The latter gap could reflect missing
geometric restrictions or a nonoptimal upper construction; these data alone
do not distinguish them. Its rational additive
potentials give 64 and ceil(284/3)=95; the joint exploration gains the final
day on 9x10. Receipts: `resumed-odd-even-corner-history-dual.json` (current)
and `resumed-odd-even-corner-history.json` (before the dual filter).

The finite matching value on 9x10 is a computational certificate based on
ordinary general geometry, not a newly uniform minimum-budget lower theorem
and not a Lean-verified result. The unbounded achievements in this note
are the critical theorem, its terminal consequence, and its dual.

## Independent attacks and precise limits

The earlier complete boundary/SCC enumerations on 5x6, 7x8 and 9x10 checked
every physical surplus-b support, not just prefixes, against both new
corner conclusions, with no counterexamples. Their receipts are
`resumed-odd-even-cheap-pairs-5x6.json`, `...-7x8.json`, and `...-9x10.json`.
These checks preceded this proof and are evidence against mistakes only.

A tempting stronger assertion, that every support above C has boundary
only in V, is false: on 7x8 there are surplus-three supports of size eight
with a majority-column boundary mark. The adjacent-pair proof uses the
quadrant split instead and does not make that assertion. The existing
co-large-to-critical implication x<=s^2 required the old critical survivor
to contain the whole favored endpoint row. The new statement contains
only one favored corner, so that implication is NOT silently extended to
the new smaller interval. A transition checker must preserve this guard.

The theorem strengthens necessary physical transitions. It does not prove
that this finite amount of corner history captures all strategic
compatibility, nor that the minimum-budget upper law is already exact.

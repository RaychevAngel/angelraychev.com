# Independent review: boundary complexity and frontier stability

13 September 2026. Root independently checked the ordinary arguments in
`supersession-even-states.md`, against the physical matching and the previously
proved exact-surplus frontier theorem. This is not a Lean verification or an
optimal-strategy normal-form theorem.

## Verdict

The arbitrary-surplus slab theorem, the excess-sensitive pyramid theorem,
and the exact defect-neighborhood identity pass this review. Their guards,
two-sided defect sets, and lack of a dynamic optimality conclusion are essential.

## Checks and attempted failure points

1. The directed contraction has loops and horizontal edges in both directions.
   Across adjacent matched rows the vertical direction alternates with column
   parity. A horizontal matching covers the required opposite parity except
   at most one endpoint. The two directed difference estimates charge disjoint
   parity contributions with total coefficient two, giving
   `|R_i triangle R_j| <= 2(r_i+r_j)+[n odd]`.
   When both boundary counts vanish, horizontal closure makes each row empty
   or full; the existence of both rung directions rules out unequal rows.
   Thus the coarser factor three has no exceptional additive term.

2. Summing along rows counts every interior row boundary at most twice, giving
   distance at most `6s` (or `4s` for even length). Filling singleton holes in
   an anchor row creates no new cuts. Every remaining cut charges a distinct
   original boundary vertex. Replication adds at most `b r_anchor <= s` rooms,
   yielding `(6b+1)s` defects and at most `floor(s/b)` cuts. No containment or
   equal-cardinality assertion is being smuggled into the representation.

3. Under the bulk guard `40bs < |R| < bn-40bs`, every row has size and
   complementary size greater than `34s`. In particular it has a boundary
   point. With `s=b+e<2b`, there are at most `e` rows with more than one boundary
   point and at least one row with exactly one. A one-boundary row must be a
   proper prefix or suffix. Two oppositely oriented good rows have symmetric
   difference greater than `68s`, contradicting the `6s` estimate.

4. In a block of good rows, each cut differs from the next by at most two;
   when the difference is two, the intermediate rung must point inward. This
   is exactly the earlier local condition for a physical height walk with
   adjacent increments plus or minus one. The conversion to two physical
   heights `c-1,c-2` preserves checkerboard parity.

5. Across `l` bad rows, the difference of good cuts is at most
   `6+6l+6 e_gap`. Correcting the far endpoint by an even shift needs at most
   `6+4l+6 e_gap <= 16 e_gap`. Applying this correction relative to the
   previous block's accumulated shift gives total displacement at most
   `16e`, not that amount per gap. The remaining endpoints have the parity
   and distance required by a walk of exactly `2l+1` steps. The bulk collar
   exceeds every correction plus the at most `2b` extension, so physical
   endpoint clipping cannot invalidate the walk.

6. Good matched rows cost at most `16be` changed rooms. Each bad row costs
   at most `6s+16e+2b+3 <= 32b`; there are at most `e` of them. Thus the
   stated `50be` bound follows from the stronger intermediate `48be`.
   At `e=0`, the previously proved exact theorem applies under a smaller
   collar, so this branch is not based on a limiting approximation.

7. For `R=(P-D_minus) union D_plus`, a vertex of `N(P)` is removed exactly
   when all its neighbors in `P` were removed and it gains none from
   `D_plus`. This proves the exact new defect formulas. Such lost vertices
   lie in `N(D_minus)`, giving the degree-four difference bound. No claim
   of closed dynamics with a bounded defect budget follows from this alone.

## Remaining research boundary

The geometry applies to every physical support meeting its numerical guards.
It does not prove that a fastest search can avoid nonproductive steps, that
its defect positions stay close to the main frontier, or that a finite list
of normalized defect patterns suffices independently of board length.
Those are the substantive missing steps for the requested all-budget result.

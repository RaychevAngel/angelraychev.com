# Even-box bridge: what the corner families fail to preserve

12 September 2026. New investigation; no manuscript or website changes.

Section1 passed an independent geometric and physical audit; see
`research/even-resume-corner-obstruction-review.md` and its JSON receipt.

The intended stronger statement was: from any checkerboard corner ideal,
every winning prescribed sequence of inspection budgets has a winning
strategy with corner-ideal survivors. The following small example refutes
it. The original full-board, constant-budget normal-form conjecture is
not refuted by this example.

## 1. A five-day obstruction on 4×6

Coordinates are 0≤x≤3, 0≤y≤5; E is the even checkerboard color.
A corner ideal means a lower ideal for coordinatewise comparison after
reflecting an arbitrary subset of axes, restricted to E. The corner may
change at every step. Start from

    A={00,02,04,11,13,15,22,24}.

Here xy abbreviates (x,y). This is a corner ideal facing (0,5).
Use the daily quotas

    (2,0,3,0,11).

There is a winning strategy:

* Day1 inspect {15,24}.
* Day2 inspect nothing. The day3 belief is E\{35}.
* Day3 inspect {15,24,33}.
* Day4 inspect nothing. The day5 belief is again E\{35}.
* Day5 inspect those eleven rooms.

All statements follow by direct physical neighborhood union. In particular,
writing K(S)=N²(S),

    K(A\{15,24})=E\{35},
    K(E\{35,15,24,33})=E\{35}.

The first survivor set A\{15,24} is not a corner ideal in any orientation.

### Why every corner-ideal first survivor fails

With at most two deletions, the complete list of deletion sets that leave
a corner ideal is

    ∅, {00}, {11}, {22}, {00,11}, {00,22}, {11,22}, {22,24}.

Their K-images are E, except that deleting {11,22} gives E\{31}.
The list can be checked by the coordinatewise predecessor definition;
there are only 1+8+28=37 possible deletion sets to inspect.

For every v∈E, |K({v})|≥4. Equality occurs only at the two even corners
00 and35. Neither corner's K-ball contains31; every other K-ball has
at least five vertices. Thus, for either B=E or B=E\{31},

    |B∩K({v})|≥4 for every v∈E.

After three day3 inspections, at least one point of each K({v}) remains.
Consequently K(B\Q)=E for every |Q|≤3. The day5 belief has twelve rooms
and cannot be captured with eleven inspections. This argument allows
arbitrary subsequent survivor sets: the failure is already forced by
requiring only the first survivors to be a corner ideal.

This proves the obstruction with a short finite geometric argument,
not merely a failed restricted search.

## 2. The smaller prefix family already fails on 4×5

Allow all reflected and coordinate-permuted weightlex prefixes, not just
one fixed order. Starting from the prefix

    A={11,20,22,31,33}

on 4×5, the quota word (2,4,0,0,0,9) is winnable unrestricted but not
with prefix survivors. This counterexample was found by the exact
winning-family automaton below. Unlike Section1, its short manual proof
has not been independently audited yet.

## 3. Exact tests of every finite quota word

`src/even_bridge_budget_words.py` starts with the winning family
W_empty={∅}. For each family W and quota m, it computes exactly

    T_m(W)={A : some R⊆A has |A\R|≤m and N(R)∈W}.

A separate copy restricts R to the tested geometric family. The code
explores pairs of distinct unrestricted/restricted winning families;
prepending every possible quota to every encountered pair gives their
complete finite closure, or stops at a stated limit. It compares the
two languages on the requested starting states. Neighborhoods use
arbitrary physical subsets; no isoperimetric normal form is assumed.

Completed evidence:

* 4×4, all corner/permuted prefixes, every prefix starting set:
  71 family pairs, all finite quota words pass.
* 4×5, all corner ideals, every corner-ideal starting set:
  322 family pairs, all finite quota words pass.
* 4×5, all corner/permuted prefixes, full starting color only:
  352 family pairs, all finite quota words pass.
* 4×6, all corner/permuted prefixes, full starting color only:
  770 family pairs, all finite quota words pass.
* Stronger 4×6 maximum-cardinality comparison: for every finite quota
  word, the maximum cardinality of an unrestricted winning initial
  support is attained by a prefix having a prefix-survivor strategy.
  Complete closure of the same770 pairs passes. This is a promising
  backward formulation, but is only proved computationally for this
  fixed box so far.
* 4×6, corner ideals from arbitrary corner-ideal starts:
  the five-day counterexample in Section1.

These are finite-instance statements. They do not establish a uniform
theorem across side lengths. The initial 4×6 prefix/full-start run stopped
after ten CPU seconds; after replacing Python threshold loops with exact
byte-table translations, the same automaton completed in six CPU seconds.
All twelve constant-budget tests on4×6 separately pass from every corner
ideal. Thus the changing budget word is essential to the counterexample
found here; a constant-budget partial-state theorem remains unrefuted.

Later qualification: the smaller prefix-family partial-state theorem
is now refuted at constant budget on6×6; see the final subsection of
`even-bridge-full-prefix-failure.md`. The broader corner-ideal statement
and the full-board constant-budget statement are not refuted by that
later example. The completed4×6 tests above remain valid.

Additional fixed-budget full-cohort checks: all reflected/permuted
weightlex prefixes attain the exact ten-day optimum on3×4×4 at seven
inspections per day, and the exact eleven-day optimum on6×6 at four.
The 3D receipt is `even-bridge-prefix-game-3x4x4-m7.json`.
On that3D example, all reflected prefixes with the fixed sorted-axis
order require eleven days per cohort. Allowing axis permutations attains
ten. Thus equality of two standard one-step isoperimetric profiles
would not by itself remove the need to retain axis-order information
in a dynamic state.

Receipts: `even-bridge-*-budget-words-*.json` and
`even-bridge-ideal-counterexample-4x6.json`. The latter separately
enumerates all legal corner first survivors and all legal day3 survivors,
and records the actual winning room sets above.

## 4. Consequence for the next abstraction

One-step neighborhood minimization does not retain enough information:
the position of the one missing room after two moves matters. In the
counterexample a missing corner permits three later inspections to keep
that corner impossible; a missing noncorner does not. A useful exact
state reduction must preserve such future boundary accessibility, or
prove that full-board optimal play never needs the offending partial
states. The full-board restriction is therefore essential to keep
separate from a stronger arbitrary-start claim.

## 5. A proved normalization within the corner families

Even though these families are not universally optimal, there is a useful
exact simplification of their restricted games. On every odd-length axis,
all their corner directions may be fixed toward coordinate zero without
changing their full-board optimum or their behavior under any prescribed
budget sequence.

To prove this, let C_i be the already proved odd-path compression on an
odd axis i. For a one-color corner ideal S facing the lower end of i,
C_i(S)=S. If it faces the upper end, C_i(S)=sigma_i(S), where sigma_i
reflects that whole axis. The side length is odd, so this reflection
preserves checkerboard parity and converts every spacing-two suffix into
the matching prefix. Neighborhoods preserve the same corner direction,
and reflection is a graph automorphism. Consequently, on corner ideals,

    N(C_i(S))=C_i(N(S)),

with equality, stronger than the general compression inclusion.
For a corner-ideal strategy A_t→R_t→N(R_t), monotonicity gives
C_i(R_t)⊆C_i(A_t), and cardinality preservation gives exactly the same
inspection cost. The displayed equality identifies the next actual
support with C_i(A_(t+1)). Thus the transformed entire strategy remains
in the corner family and has the chosen axis always facing zero.
Current color cohorts can be transformed separately, so the argument
also respects shared daily budgets. Repeat for all odd axes.

The same proof applies to the reflected/permuted weightlex-prefix family:
an axis reflection sends such a prefix to another member of the family,
and its neighborhood is a corner ideal facing the same end. Starting
from a full board, which every C_i fixes, this yields equality of the
restricted optima. In d dimensions with o odd nontrivial axes, one only
needs the 2^(d−o) choices on the even axes, rather than all2^d corner
directions. This does not prove that the restricted optimum is the
unrestricted optimum.

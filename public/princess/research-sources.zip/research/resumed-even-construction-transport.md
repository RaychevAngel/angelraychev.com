# An unguarded upper transport lemma for pyramid envelopes

13 September 2026. Ordinary derivation by the rectangle construction lane,
independently accepted by root on13 September2026. This is an upper construction,
not an exact physical transition theorem. It has no physical-margin or
positive-fiber assumptions.

Let Q be a connected bipartite transverse graph, and consider Q x P_n.
For an initial physical color p, let a_v be integer cutoffs with the
correct fiber parities and `|a_u-a_v|=1` on every edge of Q. A physical
support is contained in the envelope a when every room (v,y) in it obeys
y<=a_v. Cutoffs below the board describe empty fibers; cutoffs above it
are allowed to dominate a full fiber.

Let b_v be a target cutoff vector of physical phase p+t, again with
edgewise differences one. Let t>=0 be the permitted number of days,
with daily quota k. Define

    F_t(a,b) = (1/2) sum_v max(a_v-b_v+t, 0).

**Sufficient transport condition.** If `F_t(a,b)<=kt`, there is a direct
t-day inspection rule with at most k inspections per day which leaves
the physical belief contained in the target envelope b. The condition
does not require `b_v<=a_v+t`, exact target attainment, or any distance
from the board's ends.

## Proof

Put `c_v=min(a_v,b_v-t)`. The two arguments have the same physical
parity. Both are edgewise1-Lipschitz; their pointwise minimum is likewise
1-Lipschitz, and parity forces adjacent differences to be exactly one.
Thus c is a valid virtual height walk, c<=a.

Starting from a, repeatedly choose a vertex of maximum current height
among those above c, resolving ties by a fixed vertex order, and lower
its height by two. This is a legal local-maximum flip. If a higher
neighbor were already at target, the target heights would differ by at
least three; otherwise the higher neighbor would itself be above target,
contradicting maximality. Hence every neighbor is one lower.

The total number of flips is exactly

    (sum_v(a_v-c_v))/2 = F_t(a,b).

Divide this finite flip word into t consecutive groups of at most k
flips, padding with empty groups if necessary. On each day, perform that
day's virtual flips and inspect each flipped old top room which lies
inside the physical board. Distinct flips in one fiber use distinct old
heights, so there are at most k distinct physical inspections that day.
Lowering an envelope top by two removes at most the inspected room of
that physical parity. If the flipped height is outside the board, the
change removes no physical room.

After the inspections, increase every virtual cutoff by one. This always
contains the physical neighborhood of the surviving support: longitudinal
neighbors have height at most their old cutoff plus one, and a transverse
neighbor's cutoff is at least the source cutoff minus one. Both physical
boundaries can only delete rooms. Negative virtual heights therefore cause
no failure of the inclusion.

Uniform additions commute with the legality of local-maximum flips. After
t days the virtual cutoff is

    c+t = min(a+t,b) <= b.

The physical belief is consequently contained in b. This proves the
upper construction. The case t=0 reduces to a<=b and no inspections.

## Relation to the existing exact interior transport

If `b-t<=a` coordinatewise, every positive part is active, and

    F_t = (sum a-sum b+|Q|t)/2.

For even transverse width2r, ordinary canonical pyramid cutoffs give
`F_t=|A|-|B|+rt`. The sufficient condition becomes
`(k-r)t>=|A|-|B|`. The existing exact interior theorem additionally
requires physical margins and cardinality guards to prove necessity and
exact endpoint equality. Those obligations are unnecessary for this
containment statement.

The positive-part form is stronger as an upper construction because it
also allows b to lie above the free-evolution envelope on some fibers.
The construction can simply leave those target rooms unused.

## Why it is relevant

The12x12,k7 optimal solo witness can be expressed as a left-corner prefix
sweep, a two-prefix handoff, and a right-corner prefix sweep. This lemma
can replace the handoff's detailed day-by-day casework with a single
inequality between its entry and exit envelopes. The remaining uniform
problem is to choose full-start entry and exit states with enough time
for this inequality while matching the corrected necessary corner clock.
No theorem that every model path lifts is claimed or needed.

The concrete12x12,k7 audit transports the39-room belief after18days to
the32-room envelope after25days: F=49 equals the seven-day budget49.
One more explicit physical boundary step then leaves25survivors with a
30-room neighborhood. Extending the single virtual transport through that
step would need57 flips in eight days, exceeding the budget56: the
virtual count charges one extra move below a now-empty bottom root.
This failed shortcut is useful evidence that the upper criterion is
sufficient rather than necessary. The seven-day transport plus the
original boundary step and greedy tail is replayed physically and still
gives solo36/full72. A separate100-case bounded audit checks physical
containment for arbitrary sampled canonical endpoint heights and phases.

Reproducer: `src/resumed_even_construction_transport.py`.
Receipt: `research/resumed-even-construction-transport-check.json`.

## Stronger criterion with a guaranteed bottom-boundary credit

The apparent one-unit loss in the eight-day bridge admits a uniform repair.
Root independently reviewed and accepted this strengthening after the
original lemma. The canonical-endpoint and positive-time hypotheses are
essential to the stated credit; time zero has no credit.

Suppose a,b are the canonical cutoffs of physical pyramids, and t>=1.
Let z(B) be the number of empty target fibers whose bottom room has the
target physical color. Then it suffices that

    F_t(a,b) <= kt + z(B).                              (BC)

Use the same legal flip word as above. A flip at unshifted old height
H<=-t names a room below the board on every possible day0 through t-1.
It is therefore unconditionally free. There is exactly one such flip in
each empty target bottom-root fiber and no others:

- In a target bottom-root fiber, b=-2 and its parity after t moves makes
  the last free unshifted height H=-t. The target c is -t-2. The canonical
  initial height is at least -t for t>=1, so the word includes that flip,
  exactly once.
- In an empty nonroot target fiber, b=-1. The last possible flip before
  b-t is at height1-t, which is not guaranteed to stay invisible.
- A nonempty target fiber has b>=0 or1, so its last flip is higher still.
  Initial canonical heights never exceed the board, so there are no
  guaranteed free top flips in this count.

Delete those z(B) free letters when counting each day's quota, while
preserving the original word order. Partition the remaining letters into
t groups of at most k and insert the free letters in their original
positions. Every actual visible flip is charged, hence the physical
quota is respected. The endpoint proof is unchanged. This proves (BC).

The12x12 bridge now works through day26: F=57,z(B)=1,kt=56. Its eight
days each inspect exactly7 visible rooms, and the final free flip occurs
below the left bottom boundary. Literal replay gives the30-room target
prefix and preserves the36-day solo/72-day full capture. The independent
100-case endpoint audit now uses the stronger budget
`ceil((F-z(B))/t)` and still passes.

This root credit is exactly the type of boundary correction absent from
the original all-virtual-flips upper bound. It remains a sufficient
criterion, not an exact transition cost. Its numerical evaluation for
two-prefix envelopes is bounded as described below: z(B) is the number
of zero target-root fibers, computable on the same finite affine pieces.

## Fixed-size evaluation for two bottom-corner prefix unions

This is a separate numerical lemma about the connecting criterion. It
does not evaluate the full capture-time clock.

A left bottom-corner prefix in physical phase p can be parametrized by
integers d,c with d congruent to p modulo2: include all current-color
rooms with x+y<d, and on x+y=d include those with x>=c. Its virtual
cutoff is

    L_x=max(e_x,min(u_x,d-x-2+2*[x>=c])),

where `e_x=((p-x) mod2)-2` is the empty-fiber height and u_x is the
largest height below n having physical parity p-x. A right prefix with
parameters f,g has

    R_x=max(e_x,min(u_x,f-(w-1-x)-2+2*[w-1-x>=g])),

where f has the parity of p-(w-1). The prefix union has cutoff
`max(L_x,R_x)`. These formulas also encode empty and full prefixes by
choosing d or f outside the board's weight range. Adjacent cutoffs differ
by one, so every such union is a pyramid.

For initial and final unions, fix x=2z+epsilon separately for
epsilon=0,1. Each endpoint's two prefixes use four affine functions:
the two possible values before and after its partial-diagonal switch.
There are additionally that endpoint's bottom and top constants. Thus
the two endpoint expressions a_x and b_x-t together use at most12
affine functions in z. There are exactly four possible switch positions,
one for each prefix. Every affine slope is0,+2 or-2.

The comparison order of those12 affine functions can change only at
their66 pairwise intersections. For every nonparallel pair, place a cut
at `floor(intersection)+1`. For parallel pairs, use a duplicate endpoint.
Include the four integer switch cuts and the two endpoints of the integer
z-domain, clipping every cut to that domain. This is a list of at most72
numbers, independent of w,n,k and the prefix parameters. It can be sorted
by one fixed finite comparison network. Min/max comparisons may also be
written with arithmetic and square roots of squares if desired.

Between consecutive distinct cuts, the active affine functions defining
a_x and b_x-t are fixed, as is their order. The positive part
`max(a_x-b_x+t,0)` is therefore one affine function throughout the
integer interval. If the interval is L<=z<U, its exact contribution is

    (U-L)*(value(L)+value(U-1))/2.

Use zero for an empty interval. Summing at most71 such contributions for
each of the two row parities and dividing by two evaluates F_t exactly.
This has at most142 summands and a fixed number of operations. The list
lengths are absolute constants and may be unrolled; no optimization,
parameter-length sum, width-dependent array update, or newly named atomic
operation is being hidden. Thus the connecting criterion for this family
meets the user's O(1) standard-operation requirement, even though the
overall capture-time goal remains open.

The neighborhood of either anchored prefix is again a prefix in the
same corner order: all earlier opposite-parity diagonals are full, and
neighbors on the last diagonal form an initial segment in that same
order. Since neighborhoods distribute over unions, this two-prefix
family is neighborhood-closed. Its optimal full-start sufficiency remains
a conjectural construction target; closure alone does not prove it.

## A one-splice construction and the remaining attainment question

The accepted transport lemma permits a much smaller upper family than all
pyramid paths: follow the deterministic left-bottom prefix strategy,
perform one virtual transport, and finish with the deterministic right-bottom
prefix strategy. The prefix strategies always inspect the last k rooms of
the current prefix in their fixed weightlex order, or all remaining rooms
on the final day. Their neighborhoods are prefixes in the same order.

On even width2r, canonical cutoff sums satisfy

    (1/2)*sum_x(a_x-b_x)=|A|-|B|.

Consequently the transport cost has the useful exact decomposition

    F_t(a,b)=|A|-|B|+r*t+(1/2)*sum_x(b_x-a_x-t)_+.

In particular, if t>=max_x(b_x-a_x), the sufficient condition is simply

    |A|-|B| <= (k-r)*t+z(B).

This isolates two obligations for a uniform proof: an entrance/exit
counting identity and enough time for the two opposing fronts to pass.
It does not assert that every relaxed corner-model path has a lift.

The bounded script `src/resumed_even_construction_splice.py` computes
only the corrected necessary solo clock, two deterministic prefix clocks,
and their possible splice times. It does not enumerate physical pyramids.
It finds49 successful splice pairs on12x12,k7. One uses11 initial days,
a7-day transport from46 to39 rooms, and18 final days. Here F=49=7*7,
with no root credit needed. Literal physical replay captures one color in36
days and the whole board by its72-day palindrome. The one-direction
prefix strategy takes37 days. On14x14,k8 there are73 successful pairs;
one uses15+9+23=47 days and its palindrome takes94. Its bridge has
F=72=8*9. These are independently replayed construction certificates.

The scripts still search over parameter-dependent splice indices, and
both endpoint clocks still iterate. Thus these finite checks are evidence
for a proposed uniform attainment theorem, not the final fixed-size
formula or a closed index-selection rule. In particular no assertion is
made yet that a successful splice always exists.

## Uniform corner change after at least width minus one days

Let w=2r, and let A and B be left-bottom and right-bottom weightlex
prefixes, respectively, with |A|>=|B|. Give them the physical phases of
a t-day transition. Then

    max_x(b_x-a_x) <= w-1  if t is odd,
    max_x(b_x-a_x) <= w    if t is even.

To prove this, reflect B horizontally and call the result B'. If t is
odd, reflection brings B' to A's phase, so the nesting of the fixed
prefix order gives B' subset A. Thus

    b_x <= a_(w-1-x) <= a_x+w-1.

If t is even, B' is in the opposite phase. The board has a perfect
matching across its even width, so |N(A)|>=|A|>=|B'|. Also N(A) is a
prefix in that same bottom-left order: every earlier diagonal is full,
and the neighbors of the current partially filled diagonal form the
initial segment of the next diagonal in the same tie order. Hence
B' subset N(A), whose cutoff is at most a+1. Therefore

    b_x <= a_(w-1-x)+1 <= a_x+w.

These cutoff comparisons remain true for empty fibers because their
canonical empty heights differ by at most one under a phase change.
The zero prefix and full prefix satisfy the same argument.

Since w is even, every t>=w-1 satisfies the appropriate bound. The
positive-part penalty in the preceding decomposition then vanishes.
Consequently, for t>=w-1 there is a directly prescribed physical
transition from A into B whenever

    |A|-|B| <= (k-r)*t+z(B).

Dropping the nonnegative z(B) gives the simpler sufficient condition
`|A|-|B|<=(k-r)*t`, consisting only of a fixed number of numerical
operations. This corollary is uniform in w,n,k. It establishes a
constructive linear-rate change of corner; it does not prove that the
necessary lower clock always provides suitable entrance and exit times.

The proof was sent to root for independent review on13 September2026.

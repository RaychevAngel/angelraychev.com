# What the fixed-horizon transfer matrix does not imply about its period

12 September 2026. Bounded theoretical audit of
`fixed-horizon-transfer-theorem.md`. No manuscript edits or numerical
experiments were performed.

## Conclusion

The known slope A/T, finite state bound, nonnegative costs at most A,
three-letter locality, complete pair-state transfer architecture, and
zero-letter boundary conditions do **not** by themselves imply period
T/gcd(A,T), 2T, or any similarly small arithmetic period.

The example below has A=T=2 and precisely the allowed alphabet size four
and pair-state count sixteen, but every valid eventual period is a
multiple of five. It is a counterexample to that inference from the
transfer architecture, **not** a counterexample for an actual cylinder:
its costs are not the special physical survivor-envelope costs.
Whether those extra identities force a small physical period remains
unresolved by this audit.

## A counterexample with the same transfer architecture

Take alphabet {0,1,2,3}, pair states (a,b), and every transition
(a,b)->(b,c), exactly as in the fixed-horizon construction. Initial
states are (0,b) and final states are (b,0). Give a transition the
two-dimensional weight

    (1,1) if abc is one of 001, 011, 112, 120, 200;
    (2,2) otherwise.

Every cost coordinate is a nonnegative integer at most A=2. The two
accumulated coordinates are equal, so minimizing their maximum is the
same as minimizing the scalar sum. Every length-n word has cost at
least n. Its cost equals n precisely when it uses only the five low
cost edges

    00 -> 01 -> 11 -> 12 -> 20 -> 00.

Among these cycle states, the initial states are 00 and 01 and the
terminal states are 00 and 20. Consequently low-cost successful walks
have lengths congruent to 0,3, or 4 modulo five, and all sufficiently
large lengths in those classes occur (in fact all positive such lengths
occur).

For n congruent to one modulo five, start at 00, use the high-cost
self-loop 000 once, and then go around the five-cycle as needed.
For n congruent to two modulo five, start at 02, take the high-cost
transition 020 to state 20, go around the five-cycle as needed, and
take the low-cost transition 200 to terminal state 00. These walks use
exactly one high-cost edge. No zero-high-cost walk exists in those two
classes by the preceding characterization. Thus the optimum is exactly

    f(n)=n+1[n mod 5 is 1 or 2],  n>=1.                 (1)

It has slope A/T=1 and bounded error at most one. If
f(n+p)=f(n)+p holds for all sufficiently large n, the nonconstant
five-periodic indicator in (1) must be invariant under addition by p.
Since five is prime, this requires 5|p. In particular p=2T=4 does not
work, nor does T/gcd(A,T)=1.

The physical transfer construction has the additional identities

    w1(a,b,c)=A-|b1|,
    wt(a,b,c)=|(N_Q(b_(t-1)) union a_(t-1)
               union c_(t-1)) minus b_t|.

The artificial weights above violate those identities, including the
first cost's independence of the neighboring letters. Therefore the
example does not justify claiming that an actual graph Q has period
five at deadline two.

## A possible physical route, not a proved improvement

The longitudinal perfect matching gives more structure than the generic
automaton uses. At a fixed deadline, an optimal word has only bounded
total excess cost over the matching trajectory lower bound. A small
period might follow by classifying spatial cycles of zero excess and
showing that their cost vectors admit a uniformly bounded balanced
insertion/removal. The exact matching and survivor identities, not
Presburger definability or the leading slope alone, would need to prove
that claim.

No classification of those zero-excess cycles or valid physical pumping
operation has been established here. The existing effective Presburger
period remains the justified statement. The fixed-budget height-descent
argument cannot simply be substituted: here the deadline is fixed while
the optimal budget grows with the cylinder length, so its polynomial
threshold in the budget does not yield a fixed spatial onset bound.

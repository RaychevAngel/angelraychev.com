# Root audit: odd cross-section, even longitudinal length

12 September 2026. The root agent accepts the ordinary proof in
`even-bridge-odd-cylinder-eventual-periodicity.md` and both geometric
lemmas in `even-bridge-odd-cross-section-paired-columns.md`. A second
independent reviewer is completing a separate audit before manuscript
integration. This is not a Lean verification claim.

The paired-column contraction was checked directly: transverse edges
are bidirectional within a pair, while the two transverse colors have
opposite longitudinal directions. An untouched fiber of each direction
joins every completely undeleted layer into one strongly connected
component. This forces the minimum middle surplus and the exact
distribution of a boundary of size `b`.

Bidirectional transverse edges give `R_u \ R_v` contained in the boundary
on fiber `v`. Along a simple path the cardinality variation is at most
the total boundary size. In the middle range every fiber is therefore
nonempty. Exact surplus `b` gives a phase-forced common frontier; its
neighborhood still omits the opposite endpoint in every fiber, which
rules out a second successive `b` surplus. For a following `b+1`
survivor, containment in that neighborhood forces one boundary point
on every fiber flowing toward the missing endpoint. All other fibers
are boundary-free, so the same edge argument gives a common frontier
and excludes distant holes.

The history bit is defined from the actual preceding survivor, including
nonclean days. In the middle range a `b` step has bit transition `0->1`,
and a `b+1` step has `1->0` when efficient. Thus the before-inspection
rank `2k+e` has loss at most `2p-A`. The low collar uses
`2(K+m)+1`; the high collar begins at rank `2h-2K`. Both endpoint
inequalities and the integer slack bound `8K+8m+2A` check. An untouched
proper cohort gains at least one in rank even when its bit falls, so
the clean-block argument remains valid.

The after-inspection cycle rank is instead `2r-e`. This timing sign
is essential and is correct in the proof. It decreases by `D=2m-A`
on each efficient edge. A closed walk has even length and translates
by `D*length/(2A)` paired columns. The proposed common multiple gives
an integer paired-column displacement and an even physical-column
period. The geometric average may stall at the minimum budget, but
the corrected average has strict drift and differs by less than one
paired column; the stated margins cover this.

The existing protected-band surgery applies in paired coordinates:
one day moves at most one pair, the matching is inside each pair,
translations by a pair preserve physical color, and even cycle lengths
preserve temporal phase. Each edited owner has a globally empty/full
mate. The cycle endpoints are survivor states, so deleting one edge
removes one following inspection day. The two inequalities have the
correct direction and together give exact eventual periodicity.

Combined with the earlier odd-length theorem for all-odd transverse
boxes and the even-order theorem, this gives eventual affine periodicity
for every fixed transverse Cartesian box and either longitudinal parity.
It does not extend the odd-length theorem to every odd-order Hamiltonian
graph, nor evaluate all finite exceptions or give a short formula for
arbitrary finite boxes.

# Five rows, even length: the all-budget continuation

12 September 2026. **Complete ordinary theorem; independently reviewed.**
Every even length `n≥6` and every positive budget is classified by (2)--(3)
and the elementary endpoint cases in Section 3. Sections 1--3 and 6--8 give
the complete geometric, lower-bound, and constructive proof. The independent
attack is recorded in `five-row-all-budget-independent-review.md`; it found
no substantive gap. Sections 4--5 preserve the discovery process and failed
approaches as historical research-log entries.

The symbolic arbitrary-support geometry is ordinary mathematics with an
exhaustive finite certificate. The new endpoint-deficit, four-probe potential,
equality-rigidity, and exceptional high-budget arithmetic are kernel checked
in Lean, universally where parameters are unbounded. This is **not** a claim
that the entire physical five-row theorem is formalized. The odd-length case
at every budget already has the exact recurrence supplied by the proved
odd-rectangle profiles; together these classify all five-row boards.

Write `n=2q≥6`, `h=5q`, and use the matched directed graph from the three-probe
proof. Its horizontal arrows point left on rows 0,2,4 and right on rows 1,3;
the other physical parity reverses the arrows.

## 1. Strong endpoint compatibility from five deficits

The preceding symbolic geometric theorem says that every surplus-two support
of size `3≤k≤h−5` has left-prefix rows. First assume `k≥6`. The empty-row
lemma then says **every row is nonempty**. Write its row lengths as `t_i`,
and set `d_i=q−t_i`. Its neighborhood has prefix rows, whose missing lengths are

```
e0 = min(d0,d1)
e1 = min(d0,(d1−1)_+,d2)
e2 = min(d1,d2,d3)
e3 = min(d2,(d3−1)_+,d4)
e4 = min(d3,d4).
```

Surplus two means `sum(d_i)=sum(e_i)+2`. The following universal integer
consequences are proved in `lean/FiveRowDeficitArithmetic.lean`:

1. If `e0=0` or `e4=0`, then `sum(d_i)≤6` (`endpoint`).
2. If `e0=e1=e2=0` or `e2=e3=e4=0`, then `sum(d_i)≤5` (`three_rows`).
3. If `e0=e2=e4=0`, then `sum(d_i)≤2` (`alternating_rows`).

All three compile with standard Lean axioms and no admissions. Their proofs
are complete splits of eight minima followed by linear integer arithmetic.
The interpretation as physical supports is ordinary mathematics here.

An outward singleton of surplus one in the opposite physical parity lies
in row 0 or 4 of the last matched column. If it belongs to `N(R)`, one of
`e0,e4` is zero. Thus a bulk surplus-two predecessor can expose such a corner
**only when `|R|≥h−6`**.

Now suppose `R'⊆N(R)` also has surplus two and `3≤|R'|≤h−5`. Its rows are
right prefixes, so every row it occupies must be entirely filled in `N(R)`.
At least one row is not full because `|N(R)|≤h−3`; the empty-row theorem
therefore gives `|R'|≤5`. The surplus-two prefix row-length vectors of these
three possible sizes are the following, together with their vertical
reflections:

| Size | Vectors, omitting reflected repetitions |
|---|---|
| 3 | `(2,1,0,0,0)`, `(1,1,1,0,0)`, `(1,0,1,0,1)` |
| 4 | `(2,1,1,0,0)`, `(1,1,1,0,1)` |
| 5 | `(2,1,1,0,1)`, `(1,1,1,1,1)` |

This is a bounded five-coordinate check: the entries sum to at most five,
and substituting their row-neighborhood maxima verifies the list. The list
is the same for every `q≥3`; for `q≥6` no far-edge truncation is possible,
while `q=3,4,5` give the same finite list directly.

The same list handles the source sizes `3≤|R|≤5` excluded from the deficit
formula: every listed diagram has all neighborhood row lengths at most two.
Consequently its neighborhood misses the last column for `q≥3`; it cannot
contain an outward corner or any nonempty right-prefix successor. This
separate argument is necessary because a horizontally directed empty row
does not acquire a neighbor merely from its own nonexistent first cell.
For source size at least six, all rows are nonempty and the displayed
deficit formula applies exactly.

Size three forces a zero endpoint deficit, so `h−|R|≤6`. Size four forces
three consecutive zero deficits at an end, or the stronger alternating-row
condition, so `h−|R|≤5`. Size five forces all alternating-row deficits to
vanish, contradicting `h−|R|≥5`. Consequently the only potentially compatible
bulk size pairs are

\[
(|R|,|R'|)\in\{(h-6,3),(h-5,3),(h-5,4)\}.\tag{1}
\]

These statements strengthen the previous three-probe history obstruction and
are independent of the allocated budget. Direct SCC enumeration checked the
actual allowed pairs at `q=3,...,7`; exactly these pairs occur in each case.

## 2. The one-bit-history lower recurrence

A cohort state is `(b,z)`, where `b` is its current cardinality and `z=1`
exactly when its immediately previous survivor set had surplus two and size
between three and `h−5`. Thus `z=1` implies `5≤b≤h−3`, and the previous
survivor size is `b−2`. The other states have `z=0`; nonempty reachable sizes
are at least two. Initial states are `(h,0)` for both cohorts.

For `p` useful probes, let `r=b−p`. The permitted lower transitions are:

- `r=0`: `(0,0)`;
- `r=h`: `(h,0)`;
- surplus at least three: every `(b',0)` with `r+3≤b'≤h`;
- surplus one: `(r+1,0)` when `r∈{1,h−2,h−1}`, except that `r=1` is
  forbidden if `z=1` and `b<h−4`;
- surplus two: `(r+2, 1[3≤r≤h−5])`, except that when `z=1` and
  `3≤r≤h−5`, the pair `(b−2,r)` must belong to (1).

The preceding lemmas prove that **every actual physical transition is
included**. In particular, the surplus-at-least-three branch retains all
larger output cardinalities; it does not assume that the minimum cardinality
dominates every marked history. This makes the recurrence a genuine lower
relaxation for arbitrary supports.

At each round split the useful budget between the two cohort states and
take any pair of their permitted transitions. The shortest path to two empty
states is a lower bound on physical capture time. Restricting to a full
budget until the terminal round is valid: any successful physical schedule
can have additional probes inserted until every nonterminal round uses the
whole budget, and inclusion-monotonicity of actual beliefs preserves success.
The code retains every permissible split of that full budget.

`src/five_row_budget_recurrence.py` contains this recurrence as
`history_next` and `solve(..., lower=True)`.

## 3. Prefix upper recurrence and exact closed formula

The upper game uses the two diagonal prefix surplus tables already proved in
`five-row-investigation.md`. Each cohort can choose its reflected orientation
independently when full, then alternates phases while proper. This is an
actual physical strategy class, without a normal-form assumption.

Its exact value is as follows. Budgets below three are impossible;
`m≥2h` gives one day, and `h≤m<2h` gives two. The proved `m=3` case gives
`4h−20`. For four probes the value is

\[
T=2\left\lceil\frac{2h-8}{3}\right\rceil.\tag{2}
\]

An explicit solo sweep begins in phase one. The first four probes give
`(h−2,phase0)`. For every phase-zero count `b≥9`, two further full shots give
`(b−2,phase1)` and then `(b−3,phase0)`. Repeat until the phase-zero count is
7, 8, or 6 according as `h mod3` is 0, 1, or 2. The final tails are respectively
`7→5→3→0`, `8→6→4→0`, and `6→4→0`. Counting gives
`L=ceil((2h−8)/3)` rounds in each case. Independently reflected cohort
orientations let both successive solo sweeps start in phase one, proving
the upper bound (2) uniformly.

For `5≤m<h`, write

\[
2h-6=q(2m-5)+r,\qquad 0\le r<2m-5,
\]

and define

\[
J(0)=0,\quad J(1)=2,\quad J(2)=3,\quad J(3)=J(4)=4,
\quad J(r)=\left\lceil\frac{r+5}{2}\right\rceil\ (r\ge5).
\]

The exact value is

\[
T=\begin{cases}
2q,&r=0,\\
2q+1,&r>0\text{ and }2J(r)\le m,\\
2q+2,&\text{otherwise}.
\end{cases}\tag{3}
\]

The upper construction behind (3) is two full-budget solo sweeps, sharing a
single round when possible. In the bulk the prefix rank `u=2b+phase` drops
by `D=2m−5` under a full allocation. After `q` such allocations, its last
remaining cohort size is `J(r)`. The exceptions at residues 1,2,4 come from
the small prefix surpluses: one instead of two at a singleton in phase zero,
and two instead of three at survivor sizes one and two in phase one.

Conversely `J(r)` probes in the first round of a fresh full cohort are enough
to put it within `q` further full-budget rounds of capture. Its optimally
oriented initial rank decrease is zero for allocations zero/one, one for two,
two for three, four for four, and `2p−5` for `5≤p<h/2`. The shared-round
construction only uses `p=J(r)≤m/2<h/2`, so this range suffices. This produces exactly
the same endpoint function `J`. Thus when `2J(r)≤m`, one round can finish
the first cohort and start the second. Otherwise use two separate last/first
rounds. The zero remainder case uses two solo sweeps of `q` days each.

The derivation supplies a uniform upper construction. Sections 6--8 prove
that arbitrary play cannot do better, completing (2)--(3).

## 4. Failed relaxations and numerical attacks

The first history model recorded only the earlier three-probe incompatibility.
It incorrectly allowed lower times 15 instead of prefix-upper 16 at `(n,m)=(6,4)`,
7 instead of 8 at `(6,6)`, and 35 instead of 36 at `(12,4)`. These were
counterexamples to the proposed proof, not successful physical schedules.
The stronger size-pair condition removed the `(6,6)` gap; the outward-corner
condition removed the remaining gaps.

The strengthened lower and prefix upper agree in all 78 cases with
`n∈{6,8,10,12}` and `3≤m<h`. Their receipt is
`five-row-budget-recurrence-checks.json`. The earlier failures are preserved
in `five-row-budget-coarse-history-checks.json`.

The closed candidate (2)--(3) matched the prefix upper solver in 533 cases,
all even `6≤n≤30` and `4≤m<h`. This is evidence for the formula, not a
universal lower proof.

## 5. Historical research log: the ammunition-potential route

Let `A_m(h)` be the minimum total useful probes needed to clear one cohort
in the lower history model, allowing any number of rounds. If each cohort
requires `A_m(h)` probes, total time is at least `ceil(2A_m(h)/m)`.

For `m≥5`, weighted shortest-path experiments suggest

\[
A_m(h)=qm+J(r)-\mathbf1_{r=2}.
\]

The correction at residue two is essential: for instance `(h,m)=(25,6)`
has lower-model ammunition 38, whereas `qm+J(r)=39`. The resulting rounded
two-cohort bound still equals (3). For physical `h` divisible by five,
the only problematic small budget would be `m=5,r=2`, which cannot occur.

For `m=4`, ammunition alone is insufficient: when `n` is divisible by six,
it permits one fewer round than (2). An equality/overlap argument is needed
there, as in the original path and three-row boundary cases.

A candidate interior state potential is `b` for `b≤m`, and otherwise
`qm+J(r)` for `2b+z−6=qD+r`. It needs endpoint saturation at full states,
and further correction for the rare compatible pairs (1) when `m` is near
`h`. Those corrections are the current proof obstacle; the relevant scalar
transition domain is now explicit and small.

## 6. Uniform lower potential for `5≤m≤h−8`

**Independently reviewed proof.** Put `D=2m−5` and, for an
integer rank `u≥0`, define

\[
j(u)=\left\lfloor\frac{(u-7)_+}{D}\right\rfloor,
\qquad s(u)=((u-7)_+\bmod D)+1,
\]

\[
F_m(u)=\left\lfloor\frac{u+5j(u)}2\right\rfloor
 -\mathbf1_{j(u)\ge1,\ s(u)\in\{1,2,4\}}.\tag{4}
\]

The subtraction is harmless at small ranks because the indicator is zero.
The following elementary properties follow from the residue table:

1. `F_m` is nondecreasing.
2. `F_m(u+2)−F_m(u)≤3`.
3. If `floor(u/2)≤m`, then `F_m(u)=floor(u/2)`.
4. For `p≤m` and `floor(u/2)>p`, putting `v=u−2p+5` gives
   `F_m(u)≤p+F_m(v)`.

Here is a proof of the only less immediate property, 4. Without the indicator,
this is the affine-ammunition inequality with movement cost five proved in
`affine-rank-ammunition-potential.md`. If `2p≤5`, monotonicity suffices. Otherwise
`u−v=2p−5≤D`, so the quotient decreases by at most one. With no quotient
decrease the undiscounted inequality has slack at least two, absorbing any
change of the indicator. If it decreases by one and the target is discounted,
both quotients are positive and the positive remainders satisfy
`s(v)=s(u)+2(m−p)`. A discounted target remainder 1,2,4 therefore forces a
discounted source remainder: respectively 1; 2; or 2/4. This preserves the
inequality. Properties 1--3 follow by reading the same residue values, including
the first nonzero quotient and the wrap from remainder `D` to one.

Choose the endpoint cap

\[
C=\min\{F_m(2h),\ 2+F_m(2h-2),\ 4+F_m(2h-4)\},
\]

and assign the physical history state the potential

\[
\Phi(b,z)=\min\{C,F_m(2b+z)\}.\tag{5}
\]

We claim that every transition in Section 2 with `p≤m≤h−8` satisfies
`Phi(b,z)≤p+Phi(b',z')`.

For a bulk surplus-two transition the new rank is `u−2p+5` when the old
mark is zero. If the old mark is one, such a transition is impossible: the
three exceptions (1) require at least `h−7` probes. For a surplus of at least
three the new rank is at least `u−2p+5`. These transitions follow from 1,4;
applying a common cap preserves a potential inequality.

It remains to check the exceptional survivor sizes:

- **Capture:** property 3 applies because `b≤p≤m`.
- **Surplus one at a singleton:** the old mark cannot be one, since the
  outward-corner lemma would require `p≥h−5>m`. Hence `u=2b` and `b≤m+1`.
  If `b≤m`, the old potential is at most `b`; if `b=m+1`, (4) gives
  `F_m(2m+2)=m+2`. The target is an unmarked pair and costs two, so the
  transition inequality holds in either case.
- **Surplus two at survivor size one or two:** if `b≤m`, the target cardinality
  already pays for the needed bound. Otherwise `b=m+1` or `b=m+2`. The four
  respective source potentials for `(b,z)=(m+1,0),(m+1,1),(m+2,0),(m+2,1)`
  are `m+2,m+3,m+4,m+4`. The target has size `r+2≤4≤m`, which verifies the
  inequality directly.
- **Near-full survivor sizes `h−4,...,h−1`:** when the resulting support is
  at least as large in rank as the source, monotonicity suffices. The only
  remaining proper-source decrease is the transition from unmarked `h−1`
  to unmarked `h−2` with three probes; property 2 pays for it. From the full
  state, the only exceptional improvements are reaching `h−1` with two
  probes or `h−2` with four probes; these are exactly the last two terms
  defining `C`.

The zero-probe full transition is tautological. This exhausts the lower
transition relation without assumptions on the physical supports.

Initially each cohort has potential `C`, so every successful strategy uses
at least `2C` useful probes. In the quotient/remainder coordinates of (3),
direct substitution gives, for `m≥6`,

\[
C=qm+J(r)-\mathbf1_{r=2}.\tag{6}
\]

For `m=5`, physical `h` is divisible by five and necessarily `r=4`; the same
identity holds. The otherwise exceptional residues 1 and 3 at this smallest
budget never occur on these grids. Consequently `ceil(2C/m)` equals (3): at
residue two both formulas give `2q+1` because `m≥6`. All other residues are
immediate. This proves the desired lower bound throughout `5≤m≤h−8`.

The inequality was additionally attacked on 7,953,891 transition checks for
physical `h=15,20,...,100`, all `5≤m≤h−8`, every valid cardinality/mark and
allocation. No failure was found. These checks supplement the proof.

## 7. High budgets reduce to three small checks

For `h≥25` and `h−7≤m<h`, the candidate upper formula is always three.
Indeed write `s=h−m∈{1,...,7}`; then `q=1`, `r=2s−1`, and the thresholds
`2J(r)` are `4,8,10,12,14,16,18`, all at most `h−s` for `h≥25`.
Two days are impossible when `m<h`: the perfect matching gives
`|N(B\setminus S)|≥|B|−|S|`, so after the first day at least `2h−m>m`
positions remain.

The only remaining boards are `h=15` and `h=20`. The universal cardinality
lower profile, directly from the surplus-one classification, is

```
g(0)=0; g(1)=2;
g(k)=k+2 for 2<=k<=h-3;
g(h-2)=h-1; g(h-1)=g(h)=h.
```

Propagate the pairs `(g((a-p)_+),g((b-(m-p))_+))`, sorting the pair and
retaining its Pareto-minimal members. Monotonicity of `g` makes this removal
valid. The following final antichains are obtained from `(h,h)`:

| `(h,m)` | Rounds already played | Pareto-minimal remaining pairs |
|---|---:|---|
| `(15,8)` | 3 | `(0,11),(2,10),(4,9),(7,8)` |
| `(15,11)` | 2 | `(0,12),(2,11),(4,10),(5,9),(6,8),(7,7)` |
| `(20,14)` | 2 | `(0,16),(2,15),(4,14),(5,13),(6,12),(7,11),(8,10),(9,9)` |

Every pair has total greater than the budget. Thus these cases require five,
four, four rounds, respectively. Budget monotonicity also covers `h=15,m=9,10`
and `h=20,m=13`. All other high-budget cases have the matching lower bound of
three and the attained upper bound of three. This closes all `m≥5`. The independent audit of Section 6 and the high-budget
reduction passed; its residue calculation is written out in the review.

## 8. Four probes: periodic potential and equality obstruction

For `h≥15` define the interior function

\[
H(b,z)=\begin{cases}
b,&b\le4,\\
6,&(b,z)=(5,0),\\
4\lfloor(2b+z)/3\rfloor-8+3\mathbf1_{(2b+z)\bmod3=2},&\text{otherwise}.
\end{cases}
\]

Set

\[
A_1=\min\{H(h-1,0),3+H(h-2,0)\},
\quad C_4=\min\{H(h,0),2+A_1,4+H(h-2,0)\}.
\]

Use `C4` at the full state, `A1` at the unmarked state `h−1`, and `H` at
all other valid states. The same transition analysis proves that allocating
`p≤4` lowers this potential by at most `p`. In the bulk, increasing rank by
three increases `H` by four; a one-rank decrease costs at most three.
The bounded small-cardinality cases and the two near-full corrections account
for the exceptions. The universal constant-modulus case proof is kernel checked
in `lean/FiveRowFourProbeArithmetic.lean`, theorem `potential_step`: it quantifies
over every `h≥15`, valid state, allocation up to four, and target allowed by the
historical transition relation. No finite bound on `h` is assumed. Only standard
Lean axioms occur; no admissions or unchecked decision procedure is used. The
assertion also passed 668,577 transition attacks for every `15≤h≤200`.

The endpoint values are explicitly:

| `h` | `A1` | `C4` |
|---|---:|---:|
| `3t` | `8t−12` | `8t−10` |
| `3t+1` | `8t−9` | `8t−8` |
| `3t+2` | `8t−5` | `8t−4` |

These formulas follow directly from the two minima and are used by the
new universal `FiveRowFourProbeArithmetic.lean` checker.

Put `L=ceil((2h−8)/3)`. For physical `h` divisible by five, evaluation gives

\[
C_4=\begin{cases}4L-2,&h\equiv0\pmod3,\\4L,&\text{otherwise}.\end{cases}
\]

The ordinary two-cohort ammunition bound already forces `2L` days in the
second case. In the first case it gives only `2L−1`; equality would require
every daily allocation to use four useful probes and every individual
potential inequality to be tight.

At either initial full state the only positive allocation that is tight is
two probes, producing a cohort of size `h−1` and potential `4L−4`. Thus the
first round of an equality strategy must allocate `2+2`. On the second round,
an `h−1` cohort cannot make a tight allocation of one, two or three probes.
The only remaining full-budget split is `4+0` (or its reversal), but the
unprobed `h−1` cohort necessarily expands to the full parity. Its potential
increases by two, making the zero allocation strictly slack. This contradicts
the required equality. Hence `2L−1` rounds are impossible and (2) follows.

Equivalently, after the forced first `2+2` round, a tight transition from either
`h−1` state requires four probes: zero probes increase the potential by two;
one or two probes cannot decrease it; three probes decrease it by at most one;
only four probes can decrease it by four. Two such transitions cannot share
the four-probe budget. The universal local facts are kernel checked as
`full_tight` and `penultimate_tight` in `lean/FiveRowFourProbeEquality.lean`.

## 9. Direct construction receipt

`direct_strategy(n,m)` emits and replays actual room inspections for the
entire even-length candidate classification, using no state-space search.
The fresh receipt `five-row-all-budget-direct-strategies.json` verifies 3,174
cases: every even length `6,...,50` and every budget from three through the
entire board. It includes the shared-round endpoint orientations at allocations
two, three and four, and the smallest/high-budget boards. The upper construction
is concretely reviewable as well as specified algebraically.

## 10. Completion and provenance

The completed theorem is a new extension developed in the present research
collaboration, beyond Angel Raychev's October 2019--March 2020 path results.
The geometric boundary automaton and historical mark originate in the preceding
five-row three-probe investigation; the endpoint-deficit strengthening, the
all-budget potential, and shared-round formula were derived here. Root and an
independent agent attacked the proof and supplied the endpoint and scalar
verification corrections described above. The final review found no gap.

New stable Lean modules: `FiveRowDeficitArithmetic`,
`FiveRowFourProbeArithmetic`, `FiveRowFourProbeEquality`, and
`FiveRowHighBudgetArithmetic`. The first three use only standard Lean axioms;
the finite high-budget arithmetic uses no axioms. The full geometric bridge
remains an ordinary proof. The polished proof is included in
`paper/sections/five-rows.tex`, Theorem `five-even-all-budgets`.

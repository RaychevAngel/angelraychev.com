# Bounded grid exploration, 12 September 2026 UTC

This is new exploratory work following the author's 2019–2020 path paper. It
does not claim a new theorem of the literature, a classification of general
rectangular grids, or Lean verification. Original path artifacts were not
modified.

## Model and evidence

The rooms are the vertices of the Cartesian product of paths. Initially every
vertex is possible. In each turn at most `m` arbitrary vertices are inspected
simultaneously. If the princess survives, she must traverse exactly one edge;
she cannot stay in her current room. There is no information other than
capture or a miss.

The new solver is `../src/exact_grid_cases.py`; machine-readable results,
complete inspection schedules, and all intermediate possible-position sets
are in `grid-small-cases.json`. Vertex indices are zero-based and each record
contains its coordinate list.

All 39 planned instances completed. The final run took 0.596 seconds in a
single process; its explicit budget was 55 seconds. There were no unfinished
or timeout cases. Every finite schedule was checked using an independent
sets-based movement implementation. All 23 selected instances—every grid
with at most eight vertices and every two-probe case—also agreed with a
distinct all-states, finite-horizon algorithm using all global probe sets and
a separately constructed Manhattan-distance adjacency relation.

The primary algorithm performs breadth-first search of the reachable belief
sets. Given current possible positions `B` and inspections `S`, the next
belief is `N(B \ S)` unless `B \ S` is empty, when capture occurs immediately.
The search terminates with the exact optimum upon first reaching a belief
with at most `m` positions. An infeasibility result means the entire reachable
belief graph was exhausted.

Checking exactly `m` positions from the current belief when more than `m`
remain loses no successful strategy: additional inspections only shrink the
surviving set, and neighborhoods preserve inclusion. Any sequence using
fewer useful inspections can therefore be simulated with extra useful
inspections, preserving containment at every later turn. The only observable
outcomes before capture are misses, so the search over fixed inspection
sequences covers adaptive strategies as well. On these finite graphs,
arbitrarily long surviving trajectories for a fixed sequence yield an
infinite surviving trajectory by finite branching; hence the exhausted-state
conclusion addresses eventual guaranteed capture, not merely a particular
time cutoff.

## Exact computed values

Entries are minimum turns; infinity means no guaranteed-capture strategy.
These are exhaustive finite computations, not experimental upper bounds.

| Grid | m=1 | m=2 | m=3 | m=4 | m=5 |
|---|---:|---:|---:|---:|---:|
| 2 × 2 | ∞ | 2 | 2 | 1 | not run |
| 2 × 3 | ∞ | 4 | 2 | 2 | 2 |
| 2 × 4 | ∞ | 6 | 4 | 2 | 2 |
| 2 × 5 | ∞ | 8 | 4 | 3 | 2 |
| 2 × 6 | ∞ | 10 | 6 | 4 | 3 |
| 3 × 3 | ∞ | 10 | 4 | 2 | 2 |
| 3 × 4 | ∞ | 16 | 6 | 4 | 3 |
| 2 × 2 × 2 | ∞ | ∞ | 4 | 2 | 2 |

The two-probe ladder values initially suggested `T(2 × n, 2) = 2n − 2` for
`n ≥ 2`. The subsequent `ladder-investigation.md` derives this identity and
an exact formula for every ladder probe budget by reducing the two parity
cohorts to lazy walks on a path. That separate note contains the unbounded
argument and its limitations; this report retains the initial finite
evidence. No originality claim is made. The larger two-dimensional and
multidimensional program should not be described as a routine extension of
the path formula.

## An elementary feasibility obstruction

If a graph has minimum degree greater than `m`, then no `m`-probe strategy can
guarantee capture. Initially all vertices are possible. After removing any
`m` vertices, every vertex still has at least one possible neighbor, so after
the compulsory move all vertices remain possible. Induction proves the
claim. The same argument applies inside any subgraph of minimum degree
greater than `m`, by letting the princess remain within that subgraph.

Consequently, a product of `d` paths, each having at least two vertices,
requires at least `d` probes for feasibility. A dimension of length one is
irrelevant to this count. This bound is necessary, and this note makes no
claim that it is sufficient for every grid.

Conversely, in any bipartite graph, if one entire color class has size at most
`m`, inspecting that same class on both of the first two turns guarantees
capture. The compulsory move takes every initial survivor from the other
class into the inspected class. When `m` is smaller than the total number of
vertices, one turn is impossible, so this gives exact two-turn values where
applicable.

The no-staying rule is essential: on the four-cycle `2 × 2`, two probes suffice
in two turns in the stated model. If staying were permitted, deleting two
positions would leave every vertex in the closed neighborhood of the
survivors, so two probes could never guarantee capture.

## A completely justified small three-dimensional example

For the cube `Q_3 = 2 × 2 × 2`, the exact answer for positive `m` is

```
T(Q_3,m) = infinity  if m = 1 or 2;
           4         if m = 3;
           2         if 4 <= m <= 7;
           1         if m >= 8.
```

The degree obstruction proves the first branch. The two color classes each
have four vertices, so the preceding two-turn strategy proves the third
branch; fewer than eight first-day probes cannot guarantee capture. The
last branch is immediate.

For three probes, a four-turn schedule, with rooms named by three binary
coordinates, is:

1. `000, 011, 101`;
2. `010, 100, 111`;
3. `001, 010, 100`;
4. `011, 101, 110`.

On the all-miss branch, the pre-inspection possible sets have sizes
`8, 7, 4, 3`, and after the fourth inspection no positions survive. In
conceptual terms, the first day checks three of the four even-parity rooms;
the second checks all neighbors of the remaining even room `110`. Thus all
trajectories starting in even parity are captured in these two turns. The
remaining belief is the odd color class. Day three checks three of those
rooms; day four checks all neighbors of its remaining room `111`.

Three turns cannot suffice. After the first three probes, a vertex is absent
from the next belief only if all three of its neighbors were inspected.
Distinct cube vertices have distinct three-element neighborhoods: for
opposite parity the neighborhoods belong to different color classes, while
distinct vertices of the same parity have exactly two common neighbors.
Thus at most one next position disappears, and the day-two belief has at
least seven rooms. After the second day's three probes, at least four rooms
survive. Flipping the first coordinate gives a fixed perfect matching of the
cube, so the neighborhood of any set has at least that set's cardinality.
The day-three belief consequently has at least four rooms; three final
probes cannot guarantee capture. This proves the remaining branch without
relying on the solver.

## Limits and next mathematical questions

- Prior literature may already contain any or all of these elementary
  observations; this computation does not establish novelty.
- The two-probe threshold is attained on every tested two-dimensional grid,
  but only grids of width at most three were included. It cannot support a
  claim about arbitrary widths.
- The path proof's belief sets can be compressed into parity intervals.
  Grid beliefs already have richer boundaries; a useful next step is to
  identify a structured family of frontier states and prove that an optimal
  strategy can be confined to it. Without such a theorem, a pleasing sweep
  supplies only an upper bound.
- Subsequent work kernel-checks the complete ladder room-game classification,
  including cardinalities, probe budgets, constructions, and actual trajectory
  semantics; see `../lean/LADDER_PROOF_BOUNDARY.md`. The cube classification
  in this note has an ordinary proof but no Lean theorem at this checkpoint.

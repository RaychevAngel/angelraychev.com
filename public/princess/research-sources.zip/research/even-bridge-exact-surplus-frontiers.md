# Exact minimum-surplus supports have a finite translated frontier

12 September2026. Ordinary lemma; root independently read and accepted
the complete proof, including the row-difference bound, common orientation,
endpoint rung condition, and transfer to a Hamiltonian transverse graph.
This concerns arbitrary supports, not a prefix restriction on strategies.
No manuscript or website change has been made.

## Directed model and statement

Use the contraction ofP_(2b)×P_n by matching short-axis rows2i and2i+1.
The directed graphD hasb rows andn columns, bidirectional horizontal
edges, and vertical rungs whose directions alternate with column parity.
In any fixed column all rungs have the same vertical direction. Matched
edges give loops, which do not affect the outside boundary.

ForR⊆V(D), letB=N_D(R)\R be its directed outside boundary. Ordinary
one-color neighborhood surplus before contraction equals|B|. Puth=bn.

**Lemma.** Suppose|B|=b and

    |R|>4b²,       h−|R|>4b².

ThenB has exactly one point(i,c_i) in each row. Either

    R∩row_i = {0,...,c_i−1}   for everyi,

or

    R∩row_i = {c_i+1,...,n−1} for everyi.

The cuts are interior,1≤c_i≤n−2, and adjacent cuts differ by at most2.
If they differ by2, the sole column strictly between them has its
vertical rung directed from the side outsideR toward the side insideR.
This condition, together with the common orientation, describes the
frontier completely.

## First reduction: one boundary vertex in each row

If some row avoidsB, it is an intact bidirectional row ofD−B. As in the
previous SCC argument, every pair of adjacent entirely undeleted columns
is strongly connected and joins that row. There are at mostb dirty
columns andb+1 isolated clean columns. Thus one SCC contains all but at
mostb(2b+1)≤4b² vertices ofD, counting the deleted vertices among the
exceptions. SinceR is outgoing-closed inD−B, this forces|R|≤4b² or
h−|R|≤4b², contrary to the assumptions.

Therefore every row meetsB. Its total size isb, so each row has exactly
one boundary pointc_i. Horizontal bidirectionality now implies thatR
includes all or none of each component of the row withc_i removed.
Each row setR_i is therefore empty, a prefix, a suffix, or the whole
row exceptc_i.

## Adjacent rows differ in at most four points in each direction

Fix adjacent rowsi,j. The setR_i\R_j is a union of at most two ordinary
integer intervals. This follows immediately from the four possible row
types: differences of prefixes and suffixes are intervals; removing one
point from such an interval gives at most two; the other cases are empty
or singletons.

At a column inR_i\R_j whose rung points fromi toj, outgoing closure
requires the point in rowj to be its unique boundary pointc_j. Thus
at most one point ofR_i\R_j has that outgoing column parity. An interval
of lengthl contains at leastfloor(l/2) points of either parity. A union
of at most two intervals containing at most one outgoing-parity point
therefore has total length at most4. Consequently

    |R_i\R_j|≤4,       |R_j\R_i|≤4,

and in particular their cardinalities differ by at most4.

If a row is empty, propagating this cardinality bound through theb rows
gives|R|≤4b(b−1)≤4b². If a row is full except its boundary point, the
same argument for row complements givesh−|R|≤b(1+4(b−1))≤4b².
Both cases contradict the middle-size assumptions. Thus every row is
a nonempty prefix or suffix that is not the whole row minus its cut.
Equivalently every cut is interior.

## All orientations agree

Suppose adjacent rows have opposite orientations, a left prefix of
lengthl and a right suffix of lengths. Their directed set-difference
sizes are

    min(l,n−s),       min(s,n−l),

and both are at most4 by the preceding estimate. The middle-size
assumptions implybn>8b² and hencen>8. If eitherl ors is greater than4,
the two inequalities force both to be at leastn−4. Otherwise both are
at most4. Thus this pair has either two small row sets or two small row
complements.

The cardinality difference bound propagates either conclusion through
all rows: starting from a row of size at most4 gives|R|≤4b², and starting
from a complement of size at most4 givesh−|R|≤4b². Again this contradicts
the assumptions. No adjacent orientations can differ, so every row
uses the same end of the cylinder.

## The local cut and parity conditions

Assume the common orientation is left; the right case reverses membership.
Between two unequal adjacent cuts, every column strictly between them
has one endpoint inR and the other outsideR and outsideB. At such a
column the rung cannot point out ofR. Since rung directions alternate,
an interval of two such columns would include a forbidden direction.
There can therefore be at most one intermediate column, proving

    |c_i−c_(i+1)|≤2.

If the difference is2, its unique intermediate rung must point intoR.
If the difference is0 or1, there is no intermediate column and this
condition is empty. Edges whose target is a boundary point are permitted.

Conversely, interior cuts with common orientation and these local rung
conditions have directed outside boundary exactly{(i,c_i):0≤i<b}.
Horizontal edges from the occupied side witness every cut as a boundary
point, and the rung conditions forbid every additional outside neighbor.

## Finite translated description

Writec_0=t andc_i=t+d_i, withd_0=0. The offsets satisfy

    |d_(i+1)−d_i|≤2,       |d_i|≤2i.

There are at most5^(b−1) possible offset sequences. For each one, the
only additional labels are the common left/right orientation and the
parity oft, which determines the allowed rung directions. All cuts lie
in a band of width at most2(b−1). Translating the frontier by two columns
preserves its local conditions and changes a left-oriented support's
cardinality by2b (and a right-oriented support's by−2b).

This gives a genuine finite family of translated bulk frontiers for
exact-surplusb supports of arbitrary long even-width rectangles. The
constant4b² was chosen for a short proof, not optimized. It does not by
itself show that every optimal search uses only exact-surplus supports;
the potential/inefficient-day argument needed to pass from this geometry
to an eventual-time theorem is a separate step.

## Exact transitions inside the bulk family

For a left-oriented survivor frontier with cutsc_i, its matched next
belief isR∪B, namely a prefix of lengthc_i+1 in rowi. A next survivor
frontier with left cutse_i is contained in this belief exactly when

    e_i≤c_i+1 for everyi.

The exact number of inspected rooms is

    p=Σ_i(c_i+1−e_i).

At full daily quotam this givesΣe_i=Σc_i−(m−b). Each individual
displacement lies between1−m and1, since the nonnegative row inspection
costs sum tom. Together with the finite offset and parity labels, these
conditions describe a finite-state additive walk of translated frontiers.
The reflected formulas describe right fronts.

Orientation cannot switch between consecutive bulk frontiers. Every
bulk left survivor has interior cuts and its next belief omits the
last-column vertex in every row. Every nonempty right suffix contains
that vertex, so no next bulk right frontier can be a subset. The reverse
argument applies to a right-to-left switch.

These are exact physical transition statements under the matching
identification. Their use in an optimal-strategy normal form still
requires bounding the rounds that are outside the exact-surplus bulk.

## Additional transverse edges

The geometric necessity also applies to a bipartite Hamiltonian cylinder
Q×P_n with|Q|=2b, using the matching along a fixed Hamiltonian path.
Its directed contraction containsD. If its total surplus isb and the
support is in the same middle range, the rectangle surplus is at mostb
and cannot be belowb by the preceding general SCC dichotomy. It is
therefore exactlyb, and the support has the frontier form just proved.
Additional transverse edges only impose further local restrictions on
this finite set of offset patterns. They cannot introduce new bulk forms.

The final necessity statement uses the already proved middle-surplus
lower bound, whose cutoff2b² is smaller than the present4b². No claim
is made here that every rectangle frontier remains valid after those
extra edges are added.

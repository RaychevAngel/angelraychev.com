# Independent review of the seven all-length minimum-budget formulas

12 September 2026. Independent review of Sections 2–4 of
`odd-minimum-budget-all-lengths.md`, the exact certificate generator, and its
imported profile/serial/potential routines.

**Conclusion:** the affine-insertion argument and its seven certificates pass.
They establish

\[
T_{(w+1)/2}(P_w\square P_n)=2wn-C(w)
\]

for `w∈{3,5,7,9,11,13,15}` and every odd `n≥w`, with respective constants
`8,20,44,84,136,208,288`. This is a computer-assisted ordinary theorem using
exact rational certificates and the proved odd-rectangle profile theorem.
It is not a Lean result and does not establish a formula for arbitrary width.

## Lower certificates apply to unrestricted strategies

The charges are indexed by **current physical parity** and the allotted daily
quota. The checked condition `c₀(r)+c₁(m−r)≤1` is exactly the condition needed
when the two current colors receive a full daily quota. All charges and
potentials are nonnegative, and both zero-state potentials vanish.

The one-cohort inequality is checked for every state and every quota, including
quotas larger than the current support; truncated subtraction then gives zero.
Consequently the final day can be padded to numerical quotas summing to m
without any assumption that those are useful physical inspections. Before the
last day, any prefix strategy can spend its entire available budget while
preserving prefixes. Additional deletions make the next support no larger,
so this modification cannot increase its capture time.

The established comparison theorem makes the optimum over these prefix
strategies equal to the unrestricted optimum. Thus the sum-potential bound
does not assume serial allocation or prohibit interleaving. The rational
one-day inequalities and the zero terminal values alone establish the lower
bound; the correctness of the Dijkstra routine that found the potentials is
not needed once those inequalities have been checked.

## Uniform displacement and the three insertion cases

Let `w=2b+1`, `m=b+1`, `D=m+1`, `A=b(b+1)`. A nonempty survivor support has
surplus between −1 and m, so for quota `0≤r≤m` its successor j obeys
`−D≤j−k≤m`. If the survivors are empty, `k≤r≤m` and the same absolute bound
holds. This validates the displacement estimate for every state, including
the full majority endpoint and the terminal cases.

The finite premise is

    c≥A+2D,  H−c≥A+2D+2,

and the two base potentials have slope two throughout `[c−2D,c+2D]`. Both
color arrays are defined on that collar, because `c+2D≤H−A−2<H−1`.

I checked each enlarged-state range independently.

- **Below `c−D`.** The survivor count is at most the source count. Both base
  and enlarged far-corner profile terms exceed the plateau cap, including the
  minority offset `H−1−q`. Thus the profiles coincide there. The successor is
  below c by the displacement bound, so both potential values are unchanged.
- **Above `c+Δ+D`.** Subtract Δ from the source and survivor. The base survivor
  exceeds `c+1`, so its low-corner term is past the plateau cap. The far-corner
  arguments agree exactly after translation. Hence the successor also gains
  Δ, and its base value exceeds c. Both potentials gain `2Δ`, which cancels.
- **In the middle.** The survivor is positive and satisfies
  `q≥c−D−m≥A+1`. Its far-corner distance is at least
  `H−c−D≥A+D+2`, so the majority and minority profile surpluses are exactly b
  and b+1. Both the source and target lie in
  `[c−2D,c+Δ+2D]`. On this whole enlarged interval, the three pieces of the
  inserted potential agree with `2k+α_p`. The resulting difference is
  `2r−2δ_p+α_p−α_(1−p)`, exactly the base inequality at source c.

These three ranges cover the equalities at both transition boundaries through
the middle case. For Δ=0 the construction is the original array. No bound on
Δ or extrapolation from finite sample lengths enters this proof.

The full majority and minority counts both lie above the cut, so each initial
potential gains `2Δ`. The total lower bound gains `4Δ`; taking its ceiling
commutes with this integer increment. In particular, the fractional width-11
certificate keeps the same rounding correction for every enlarged length.

## Review of the physical upper pumping

The finite witness checks that each active cohort visits c before an
inspection. With all m probes directed at a nonempty active cohort, the count
never increases: all profile surpluses are at most m. Therefore its first
visit to c is reached from above and its subsequent trajectory stays at or
below c.

For every source count at least c, its survivor after m probes is at least
`c−m`, well past the low-corner cap. The profile translation identity therefore
holds all the way down to c, including the strip not covered by the strict
high-case boundary used in the lower proof. For every source at most c, the
far corner is inactive, so its profile update is independent of Δ.

When the enlarged first trajectory reaches `c+Δ`, two full-budget rounds
reduce its count by one and restore its parity, regardless of which color
starts the pair: a majority round decreases by one and a minority round
leaves the count unchanged. The complete inserted block has `2Δ` rounds,
ends at c in the original phase, and stays inside the plateau. The untouched
cohort remains a full alternating color class and also returns to its original
phase after this even block.

The unchanged lower part of the first sweep uses the same quota on its final
day. Any leftover quota therefore changes the second cohort to exactly its
base state translated by Δ. This new state remains above the cut: even the
loose displacement bound gives a base count at least `H−m−2>c`, using the
displayed separation hypothesis. The second translated trajectory reaches
`c+Δ`; its own `2Δ`-round block restores its original phase, after which its
unchanged lower trajectory finishes. This gives a physical prefix schedule
with exactly `4Δ` additional days.

For actual odd rectangles, `Δ=w(n−n_base)/2` is an integer. The lower and upper
increments agree for every larger odd n, while the finite certificate covers
every smaller odd n from w through the base length. Thus no longitudinal
length is omitted.

## Independent implementation attack

The fresh checker `src/odd_minimum_budget_independent_review.py` reruns all
seven exact certificate constructions, covering 32 finite lengths. It then
constructs actual room adjacency without importing the algebraic profile
formula, verifies every physical prefix-neighborhood identity, verifies every
inserted potential inequality against those physical neighborhoods, and
replays the full two-cohort room schedule on 21 boards: each base length and
the lengths two and eight greater.

All checks pass. The receipt is `odd-minimum-budget-independent-review.json`.
The generated potential routine uses only integer-scaled shortest paths and
exact rational arithmetic; the final certificate directly verifies all
inequalities. Its arbitrary large finite initialization cannot invalidate a
passed certificate, because certificate validity does not depend on distance
optimality.

No substantive mathematical gap was found. The geometric odd-rectangle premise,
the finite certificate, and the unbounded insertion lemma should all remain
visible in the paper's proof dependencies. The formula is established for the
seven listed widths only; neither arbitrary-width serial optimality nor a
closed formula for `C(w)` has been proved by this argument.

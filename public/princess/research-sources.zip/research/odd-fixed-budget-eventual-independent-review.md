# Independent review: eventual periods at every fixed feasible budget

12 September 2026. The ordinary proof in
`odd-fixed-budget-eventual-periodicity.md` passes independent mathematical
review, including the generalized potential algebra and the separate-cut
surgery. For every fixed odd width `w≥3` and fixed feasible budget
`m≥(w+1)/2`, put `d=2m−w` and `g=gcd(w,d)`. Above the stated explicit
threshold it proves

\[
T_m(w,n+2d/g)=T_m(w,n)+4w/g.
\]

This is an affine period, with potentially different offsets in the odd
residue classes modulo `2d/g`. It is not a claim of a single affine formula
across every odd length at a larger budget. The minimum budget has d=1 and
therefore gives one eventual affine law. No full physical Lean formalization
or literature-priority claim is made by this review.

## Generalized scalar algebra

With `w=2b+1`, the proposed constants are

    K=2b²+2m+1,  C=2H−4b²−2m−5>0,
    F_p(k)=min(C,max(0,2k+p−K)).

For survivor `q=max(k−r,0)`, quota `r≤m`, the three profile regions give the
claimed loss bound `max(0,2r−w)`.

- If `q≤b²`, then `k≤b²+r≤b²+m`, so the current affine value is at most
  `p−1≤0`. The current potential vanishes, including when q=0.
- If `q≥H−b²−1`, the general neighborhood bound `j≥q−1` makes the target
  affine value at least C even for its smaller parity contribution.
- In between, the exact plateau gives `j=k−r+b+p`; the raw affine loss is
  `2r−w`. Common clipping preserves the positive-part upper bound.

The two quota charges sum to at most `d=2m−w`. If both positive parts are
positive their sum is `d−w<d`. If only one is positive and its quota is less
than m, its value is at most `d−2`; if neither is positive the sum is zero.
Thus equality can occur only when all m probes target one cohort. This
argument also covers padded final quotas.

Both full-class potentials equal C. A minority-first phase needs at most
`2 ceil((H−1−m)/d)+1` rounds: every pair lowers the count by at least d until
capture, and a final minority round removes the remaining at most m cells.
Padding the phase to its odd bound makes the untouched cohort start minority
again. The total upper bound is twice that phase length.

For integer `a=H−1−m≥0`, the ceiling estimate
`d ceil(a/d)≤a+d−1` gives exactly

    dT−2C ≤ 8b²+6d+2.

The explicit threshold makes both a and C positive, so the displayed
unclipped formulas apply. This checks the coefficient and the constant in the
bad-day bound; no rounding term has been omitted.

## Efficient blocks and the flat collars

An efficient day lowers the sum potential by exactly d. It must target one
cohort exclusively, lower its potential by d, and leave the other potential
exactly constant. Zero inspection strictly increases any interior potential:
the majority raw value gains at least one for a proper prefix, and the minority
raw value gains at least one for any nonempty prefix.

After losing d, an active potential is below C. If still positive, it cannot
become inactive on the next efficient day. A switch is possible only after
it reaches zero, and it cannot reactivate within that efficient run. Therefore
there are at most two focused blocks per efficient run, irrespective of any
residue of C modulo d.

The lower flat collar now contains at most `b²+m=L−1` cells. The upper flat
collar is unchanged: its count is at least `H−b²−2`, within at most
`b²+2≤L` of full. Strict growth under two zero-inspection neighborhood steps
limits both nonempty/proper collar transients to at most 2L days per focused
block. Consequently the claimed `E=B+4L(B+1)` bound on nonclean days remains
valid at every fixed feasible budget.

## The skipped-level issue and why separate cuts solve it

At larger budgets the active majority step decreases its count by `m−b`,
and the minority step by `m−b−1`. A trajectory need not visit a specified
integer count. Therefore the exact common-endpoint argument from the
minimum-budget proof would not have been sufficient.

The new draft correctly uses a common protected interval but independent
cut points for the two initial cohorts. Let

    Delta=lcm(w,d),  J=m+1,  R=Delta+2J.

There are at most 2E nonclean source-count records. Each forbids at most
`R+2J+1` candidate cuts. The explicit threshold leaves strictly more allowed
integer cuts than that total. Since every transition has displacement at most
J, source-only exclusion on `[c−J,c+R+J]` prevents a nonclean edge from
touching the protected band `[c,c+R]`.

For cohort i, its first count at most `c+Delta+J` has a preceding count strictly
above that threshold. Its displacement bound therefore gives

    c+Delta < x_i ≤ c+Delta+J.

This entry is clean. While inside the protected band, the cohort is the active
one, its companion is empty or full, and each pair of steps lowers its count
by exactly d. As d divides Delta, the next `tau=2Delta/d` steps end at

    ell_i=x_i−Delta ∈ (c,c+J].

All intermediate counts remain between these endpoints because both one-day
decrements are nonnegative. Hence the entire block stays in the protected
band and the exact plateau identities continue to hold. Its duration is an
even integer, so current parity is restored.

The resulting cuts may differ between the cohorts. This is harmless: each
initial cohort always has its own current parity and its own prefix support.
The inactive companion is empty or full during either crossing. The crossing
blocks cannot overlap, and the first-entry choice and impossibility of upward
recrossing ensure every strict-interior visit belongs to the chosen block.
Boundary stalls at the minimum budget are allowed and do not alter the glue.

## Checking all retained and replaced transitions

Delete each tau-round block and lower upper counts by Delta, using the
individual threshold pair `(ell_i,u_i=x_i)`. Both endpoints of that cohort's
block map to ell_i. The companion is empty or full at both ends and maps to
the appropriate empty or contracted full class. Even duration makes the
physical colors match.

For each retained low source `k≤ell_i`, its survivor is also low. The contracted
far margin is

    H−Delta−ell_i = H−u_i ≥ A+2J+2,

so neither far-corner profile cap changes. For each retained high source,
the contracted survivor is at least `ell_i−m>c−m>b²`. Its low-corner terms
are already capped, and its far-corner arguments agree exactly after
translation by Delta. These are the required profile conjugacy identities.
There is no retained edge into the strict removed interval; those edges lie
in the chosen crossing block. Incoming and outgoing boundary edges use their
respective high and low identities.

The companion's transformation uses its own cut, but zero lies below both
cuts and each full class lies above both. Thus the separate maps do not
conflict at either deletion. Quotas remain unchanged and preserve the budget.
The cut margins also ensure the contracted rectangle still has odd length at
least w; Delta is a multiple of w.

For expansion, replace each traversal from u_i to ell_i by one from
`u_i+Delta` to ell_i. It has `4Delta/d` steps, an even duration, and stays on
the enlarged plateau. Its upper far margin is unchanged because both H and
the upper endpoint gain Delta. The companion remains empty/full, and all
other transitions obey the same low/high identities. The two surgeries
therefore give matching upper and lower inequalities after applying
contraction to the larger board.

Finally, `Delta/w=d/g` and `Delta/d=w/g` give the stated period and time
increment. The proof determines all eventual residue offsets by finitely many
calls to the exact two-count recurrence. It does not claim a short formula
for those offsets, an early onset at the square, or analogous periodicity
for higher-dimensional or mixed-even boxes.

No substantive gap was found in this completed generalized argument.

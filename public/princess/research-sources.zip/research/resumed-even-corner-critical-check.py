"""Finite falsification check for the critical physical corner theorem.
The universal proof is separate. No strategies are enumerated here.
"""
import importlib.util,json,time
from pathlib import Path
p=Path(__file__).with_name('resumed-even-corner-profile-check.py')
spec=importlib.util.spec_from_file_location('caps',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def check(w,n):
 b=w//2;h=w*n//2;counts={};exceptions={}
 for phase in range(2):
  cells=[(x,y) for x in range(w) for y in range(n) if (x+y)%2==phase]
  other=[(x,y) for x in range(w) for y in range(n) if (x+y)%2!=phase]
  ix={v:i for i,v in enumerate(other)}
  neighbors=[sum(1<<ix[v] for v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if v in ix) for x,y in cells]
  corners={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
  ci=sum(1<<i for i,v in enumerate(cells) if v in corners);cj=sum(1<<i for i,v in enumerate(other) if v in corners)
  N=[0]*(1<<h)
  for S in range(1<<h):
   if S:
    bit=S&-S;N[S]=N[S^bit]|neighbors[bit.bit_length()-1]
   a=S.bit_count();nb=N[S];s=nb.bit_count()-a
   if s!=b:continue
   i=(S&ci).bit_count();j=(nb&cj).bit_count();key=f'{i},{j}'
   counts[key]=counts.get(key,0)+1
   if a<=m.F(i,j,s) or h-a-s<=m.dual(i,j,s):continue
   assert (i,j)==(1,1) or (n==w+1 and(i,j)==(2,0)),(w,n,phase,S,a,s,i,j)
   exceptions[key]=exceptions.get(key,0)+1
 return dict(width=w,length=n,literal_subsets=2**(h+1),critical_supports=sum(counts.values()),corner_counts=counts,exceptions_outside_FG=exceptions)
def algebra():
 count=0
 for b in range(1,201):
  d=[min(q,b-1-q) for q in range(b)]
  assert sum(d)+sum(min(d[q],d[q+1]) for q in range(b-1))==(b-1)*(b-2)//2
  for ell in range(1,b):
   z=b-ell;target=(b-1)**2+1
   assert ell*(ell-1)+z*(z-1)<=(b-1)*(b-2)<=m.C2(b)
   assert 2*max(ell,z)+(ell-1)**2+(z-1)**2<=target
   assert ell**2+z**2<=target
   if z>=2:assert b*b-2*(z-1)*(ell+1)<=target
   for L,R in ((0,0),(1,0),(0,1),(1,1),(2,0),(0,2)):
    assert 2*ell*L+2*z*R+(ell-1)**2+(z-1)**2<=b*b
   count+=1
 return dict(sizes_checked_through=200,mixed_splits=count)
start=time.process_time()
rows=[check(w,n) for w,n in [(2,2),(2,3),(2,4),(2,7),(4,4),(4,5),(4,6),(4,7),(4,8),(4,9),(6,6)]]
result=dict(status='PASS',scope='Every literal one-color support on the listed boards, both colors. This finite check is not the universal proof.',rows=rows,algebra=algebra(),CPU_seconds=time.process_time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

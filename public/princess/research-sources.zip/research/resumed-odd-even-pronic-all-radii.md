# Pronic equality at every radius on an even-area rectangle

13 September2026. Consolidates the critical odd-width pronic lemma with
its subcritical instances and the even-width endpoint. Ordinary geometric
argument reviewed by the parent; no new Lean claim. The implementation
uses only necessary transition restrictions, never geometric sufficiency.

Let an even-area rectangle have side lengths w<=n, w>=4, let h=wn/2,
and let b=floor(w/2). A support occupies one color. Its surplus is
|N(S)|-|S|. Write c(A) for its own-colored corner count and e(A) for
the number of opposite-colored corners with both neighbors in A.

## Uniform equality statement

Suppose2<=t<=b, |S|=t(t-1), c(S)=0, and the surplus is t. Then S is
exactly the full odd triangle based at one opposite-colored corner,
consisting of relative diagonals1,3,...,2t-3. In particular

    |N(S)|=t^2, c(N(S))=1, e(N(S))=0.

Its second neighborhood has exactly kappa original-colored corners, where

    kappa=0, if t<b or w is odd;
    kappa=1, if t=b, w is even and n>w;
    kappa=2, if t=b and w=n is even.

Every inspected subset of N(S) has next neighborhood with at most kappa
such corners. This gives a memory restriction; it is not a statement that
corner counts determine arbitrary shapes.

## Why the equality is rigid

The subcritical or critical F/G corner theorem applies. At critical
surplus its permitted exceptions have current corner count1 or2, so
c(S)=0 excludes them. The large branch is impossible: its left side is
h-t^2>=t^2, whereas every feasible G_(0,j)(t) is strictly less than t^2.
This follows directly from the three possible complementary outgoing
corner counts in the definition of G. The two small capacities F00(t)
and F02(t) are strictly less than t(t-1). Therefore j=1 and the small
branch is attained exactly, F01(t)=t(t-1).

In the quadrant decomposition, equality in convex surplus allocation
places all surplus in the one required odd-corner component. Equality in
the punctured-diagonal layer bound forces every initial odd diagonal to
be full. Diagonal compression preserves the count of each diagonal;
therefore the original support, not merely its compressed image, is the
full triangle. At a critical endpoint where the separator proof instead
uses alternating matched fibers, the equality analysis gives the same
conclusion: the even-square pure alternating case forces successive
clean lengths0,1,...,t-1 and equality in every intermediate/final fiber
bound. The mixed square case with current corners0 has outgoing corners0
and cannot attain F01. The odd-width and near-square alternating cases
with current corners0 likewise have outgoing corners0. The whole
half-strip case has an explicit equality argument as well. If a boundary-
free matched row exists, the preceding quadrant proof applies. Otherwise
each matched row has exactly one outside-boundary vertex and its occupied
set is an initial interval of length c_i. Omission of the current corner
gives c_0=0, while the alternating rungs give c_(i+1)<=c_i+2. Equality
in sum_i c_i<=sum_i2i=t(t-1) forces every c_i=2i. In physical coordinates
x=2i+(y mod2), these are exactly the odd triangle at the opposite corner
(2t-1,0): the reflected coordinate sum(2t-1-x)+y is one of
1,3,...,2t-3. This supplies the critical whole-half-strip equality case
without appealing to an unstated compression normal form.
These are the equality cases in `resumed-even-corner-critical.md` and
the half-strip/quadrant lemmas it invokes, not a compression normal form
assumed for arbitrary strategies.

The triangle's second neighborhood has radius2t-1. The only corners that
can lie within this radius are across a side whose edge-distance is odd:
w-1 or n-1. A diagonally opposite corner is farther away. This proves
the stated kappa, including the square endpoint where the old zero-corner
conclusion would be false. Its first neighborhood has radius2t-2; no other-colored
corner has both neighbors in that first neighborhood, giving e(N(S))=0.

## Dual equality rule

If |S|=h-t^2, its surplus is t, and c(N(S))=2, then

    c(S)=1, e(S)=2-kappa, e(N(S))=1.

Indeed U=the opposite-colored complement of N(S) has size t(t-1), no
own corner, and surplus at most t. The unconditional profile forces
surplus at least t: ceil(sqrt(t(t-1)))=t, the width cap is at least t,
and h-t(t-1)>=t(t+1) makes the complementary pronic cap at least t.
Consequently its surplus is exactly t and N(U) is the full complement
of S. The preceding rigidity statement applies to U. Its one first-
neighborhood corner gives c(S)=1. A corner's neighbors all lie in S
exactly when that corner does not lie in N^2(U), giving e(S)=2-kappa.
A corner belongs to E(N(S)) exactly when it lies outside N(U), giving
e(N(S))=1.

## Computation and limits

An independent physical checker, using no capacity formulas, enumerates
every support of size t(t-1) for radii2 and3 on4x4,4x5,4x6,5x6,6x6,
6x7,6x8 and7x8, in both phases. Every equality support is one of the two
corner triangles, and all first/second-neighborhood corner counts agree
with kappa0,1,2, including the even-square endpoint. Receipt:
`resumed-odd-even-pronic-rigidity-physical-attack.json`; source:
`src/resumed_odd_even_pronic_rigidity_attack.py`. This is a finite attack
on the proved statement, not a substitute for its argument.

`src/resumed_odd_even_erosion_corners.py --all-pronic-radii` applies this
rule for every2<=t<=b on odd-width/even-length boards, all with kappa0.
On11x12 with budget6 it still gives necessary solo63, versus the
independently replayed upper64. Thus this unification alone does not
resolve that remaining relaxation gap.

`src/resumed_odd_even_erosion_square_probe.py --pronic` applies kappa0
below critical and kappa2 at the square endpoint, together with only
the already established subcritical refined erosion inequality and the
unrefined critical F/G theorem. On24x24 with budget13 the necessary solo
value remains102, versus the separately established prefix upper104.
Receipts are the corresponding `erosion-corners-11x12-all-pronic-radii`
and `erosion-square-24x24-k13-pronic` JSON files in this directory.

These are diagnostics of a relaxation. Neither agreement nor disagreement
establishes a uniform optimal strategy, and no merger property for the
richer erosion state is used or asserted here.

# Transferring the 28-day boundary obstruction to larger rectangles

13 September 2026. New ordinary proof under independent review. It uses
the previously checked 24-square finite certificates; it does not turn
necessary feature paths into physical strategies.

## Proposed uniform statement

On every even-area rectangle with both side lengths at least 24, with
budget 13, after 28 unsuccessful inspection-and-move steps:

1. A full initial color class leaves at least h-111 possible rooms,
   where h is half the board area.
2. Full initial uncertainty leaves at least 2h-111 possible rooms.

The second statement is a joint shared-budget restriction. It does not
follow merely by adding two solo restrictions. At feasible budgets these
bounds apply to all even-area rectangles of width 24 or 25 and length
at least that width. They may be inserted into the existing necessary
models as a time-28 restriction, provided that their joint interpretation
is retained. They do not yet identify the final capture time.

## Deficit translation of the forward model

Use the OLD, unrefined 24-square corner model, with half-area h0=288
and unrestricted surplus starting at 12. This is the exact model used
by the accepted time-28 equality certificate.

For a physical feature (a,c) on the larger board, write d=h-a and map
it to (288-d,c). For a physical day with p<=13 inspections, survivor
q=a-p and i corners, target (t,j), and surplus s=t-q, this translation
preserves p, i, j, s and the target deficit h-t.

As long as source deficit d<=112, its survivor has

    q>=h-112-13>=163>11^2.

If s<12, the finite-board corner theorem is subcritical because the
width is at least 24. Its small component capacity, at most s^2, is
impossible. Therefore h-t<=G_ij(s), a condition unchanged by translation.
The translated edge is admitted by the 24-square model. If s>=12,
that model admits it without a component restriction.

The translated source, survivor and target are valid corner states.
In particular target deficit can rise by at most 13 in one day:
N(S) has at least |S| on these balanced rectangles, by a perfect
matching. Thus the translated target has size at least 288-125=163;
all positive lower corner bounds are automatic. The upper bound is
exactly d>=2-c, inherited from the physical corner count. Analogous
statements apply to survivor and target. Translated target sizes at
most288 follow from their nonnegative physical deficits.

For a SOLO history, this maps every step through the first hypothetical
crossing of deficit112. The accepted 24-square forward computation
has minimum size at least176 at every time through28. Hence such a
crossing is impossible through28: deficit is always at most112.
At time28 equality can only have corner count1.

For a JOINT history, let d1,d2 be the two nonnegative cohort deficits.
Until and including the first crossing d1+d2>112, each source cohort
has deficit at most112. Map both component transitions as above, with
their actual inspection allocations, whose sum is at most13. The
accepted guarded merger on the 24-square model has size

    288-(d1+d2),

and corners max(0,c1+c2-2). Its size exceeds13 throughout this argument,
including the potential first crossing, since the combined deficit
can rise by at most13 in one step. The same forward lower computation
excludes that crossing. Thus d1+d2<=112 at every time through28.

If the joint deficit is exactly112 at time28, the merged feature is
(176,1). The OLD independently verified equality certificate applies
to the translated component histories. Its unique terminal pair is

    ((176,1),(288,2)).

Undoing translation, one physical cohort has deficit112 and the other
is full. It remains to exclude the former physical solo history. It
may have received fewer than13 inspections on some days; enlarging its
allowance to13 only strengthens the contradiction below.

## The solo equality obstruction also transfers

Suppose a 28-day history from an entire physical color class ends in
A with |A|=h-112 and c(A)=1. Set U to the complementary112 rooms.
Reversing those inspections gives a 28-day capture strategy from N(U),
by the already proved inspection-and-move reversal lemma.

The old 24-square backward computation says that no feature of size
at least124 clears in28 days. This lower statement transfers to the
larger rectangle, as follows. Its backward accepted sets through28
have sizes at most123. If a physical transition reaches such a target
size t, its survivor has q<=t and its source has size at most t+13<=136.
All these sizes and corner features are valid in the24-square model.
For s<12 a physical small branch remains the identical small branch,
and a physical high branch h-t<=G_ij(s) implies288-t<=G_ij(s).
For s>=12 the old model is unrestricted. Backward induction therefore
maps every physical strategy of at most28 days into the old backward
model. Consequently |N(U)|<=123.

The unconditional size profile gives surplus at least11 at size112
on every rectangle under consideration: ceil(sqrt(112))=11, width cap
is at least12, and the complementary root is at least the root of176.
Hence |N(U)|=123 and surplus is exactly11.

The large branch of the finite corner dichotomy is impossible because
h-123>=165>11^2. Since112>11*10, the accepted near-square localization
places U in a single corner triangle of121 rooms, on diagonals
0,2,...,20 after reflection. Its neighborhood lies on diagonals at
most21, so both U and N(U) lie inside a24-square corner subboard and
have the same neighborhoods there as on the larger board.

Restricting the princess to this subboard can only make capture easier.
On that square, the accepted simultaneous strategy compression reduces
U to one of the eight121-triangle pyramids of size112. The prior
independently verified finite certificate proves that each corresponding
123-room neighborhood needs at least29 days. Therefore N(U) cannot
have a28-day strategy on the larger board either, a contradiction.

This excludes solo deficit112, proving statement1. Combined with the
translated equality certificate it excludes joint deficit112, proving
statement2. The joint argument uses the equality theorem explicitly;
no unproved inheritance of a time-dependent filter is being assumed.

## Evidence used and remaining work

The authoritative old proofs are in
paper/sections/resumed-near-square-localization.tex. The equality graph
was independently rebuilt by
src/resumed_even_construction_joint_equality_verify.py, with receipt
research/resumed-even-construction-joint-equality28-verification.json.
The eight-pattern lower certificate has its independent verifier listed
in paper/sections/resumed-even-area-certificates.tex. No new shape search
or parameter-specific equality enumeration is required for this transfer.

Independent review must check both uses of the old model, especially
first-crossing validity and reverse-model transfer. The resulting final
capture bounds on width24/25 are still to be computed and compared with
physical strategies. The theorem is not yet claimed Lean-verified.

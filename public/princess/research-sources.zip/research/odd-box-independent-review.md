# Independent review: isoperimetric nesting on every odd-sided box

12 September 2026 UTC. Root independently reconstructed the terminal-coordinate
exchange argument proposed by the frontier agent, building on the trap agent's
linear neighborhood-cost identity. This is an ordinary proof review, not a
Lean certificate or a literature-priority claim. The full proof is being written
in the companion odd-box research note.

## Exact setting

Remove singleton factors. The box has coordinates 0≤x_i≤L_i, with
2≤L_1≤...≤L_d all even. Its side lengths L_i+1 are odd. In a fixed
checkerboard class, order by increasing total weight and decreasing
lexicographic order within a layer. For d≥3 let P be the transitive closure
of the ordered pairs x<y that agree in at least one coordinate.

The induction base d=1 is the elementary odd-path profile. Dimension two
is the independently reviewed odd-rectangle theorem, with the smaller
coordinate first. No theorem about even rectangles is used.

## Terminal-coordinate lemma: independent reconstruction

Claim: if x<y have the same parity and x_d=0<y_d, then x≤_P y.
An equal coordinate makes this immediate, so suppose all coordinates differ.

If |x|<|y| and x_i>y_i for some i<d, set δ=x_i−y_i and
z=x−δe_i+δe_d. It lies in the box since δ≤L_i≤L_d. It has x's
weight, follows x lexicographically, and precedes y by weight. The pair
x,z retains an unchanged coordinate because d≥3, while z,y agrees at i.
Thus x<_P z<_P y.

If no such i exists, x is coordinatewise at most y. The sum of the
increments is even. Increase coordinates in steps of two, pairing the
remaining odd increments into steps of one in each of two coordinates.
Every step changes at most two coordinates, stays in the box, strictly
increases weight, and retains an unchanged coordinate. This supplies a
P-chain to y. The even-total condition follows from the common parity.

If |x|=|y|, the first differing coordinate gives x_1>y_1. An excess
x_i>y_i at any middle coordinate 1<i<d allows the previous transfer:
z retains x_1>y_1, so z still precedes y in the common weight layer.
Otherwise every middle coordinate increases strictly from x to y.
Weight equality gives

    x_1−y_1 = y_d + sum_(1<i<d)(y_i−x_i) > y_d.

Set z=x−y_d e_1+y_d e_d. It stays in the box, follows x, and still
has z_1>y_1, hence precedes y. It agrees with x at a middle coordinate
and with y at coordinate d. This completes the claim. The proof uses
neither a bound on d nor a finite enumeration of side lengths.

## The cost implication

For x≠0, put j=max{i:x_i>0} and

    a(x)=d−j+1−1_(x_j=L_j),       a(0)=d.

If x<y and a(x)>a(y), then x≤_P y. Indeed equal last coordinates
give a direct P-link. With distinct last coordinates, the only possible
cost-decreasing patterns are:

1. x_d=0<y_d: the terminal-coordinate lemma applies.
2. 0<x_d<L_d=y_d: apply that lemma to the coordinate complements,
   in the order complement(y)<complement(x).

The remaining pattern y_d=0<x_d cannot decrease cost: x has cost at
most one and y has cost at least one. When both last coordinates are
positive, their costs are either one (interior) or zero (maximal), so the
list is exhaustive. Coordinate complement reverses weightlex order and
each generating P-link, hence also reverses P. Complement preserves
common parity; every L_i is even in this theorem.

## Neighborhood cost and the ideal exchange

For a nonzero neighbor z, decrement its last positive coordinate to obtain
ell(z). This is its earliest lower neighbor in weightlex order. If z neighbors
x in a pair-compressed set S, ell(z) differs from x in at most two
coordinates and is no later in the induced two-coordinate order. Thus
ell(z) belongs to S. Conversely ell(z) in S implies z in N(S).
The number of preimages of x under ell is exactly a(x): increment its
last positive coordinate if possible, or introduce a one at a later
coordinate. The origin has d preimages. Every nonempty odd pair-compressed
set contains a unit vector (decrease weight by two until weight one), so
its neighborhood additionally contains the origin. Thus, for nonempty S,

    |N(S)| = sum_(x∈S) a(x) + 1_(S has odd parity).

Compress every codimension-one fiber using the induction hypothesis.
These operations decrease the sum of the vertices' global order positions
whenever they change S, preserve size, and do not increase neighborhood
size. A common fixed set is a P-ideal. It is pair-compressed because each
two-coordinate fiber is contained in a codimension-one fiber, and the
restricted orders agree.

If S is not a global prefix, let x be its earliest missing vertex and y
its latest included vertex. Then x<y. They are incomparable in P: x≤_P y
would contradict the ideal property and y≤_P x would reverse the global
order. The cost implication gives a(x)≤a(y). Removing y and inserting x
preserves the ideal (all predecessors of x are earlier than x; no member
of S follows y). Both sets have the same nonzero size and parity, so the
cost identity proves that this exchange does not increase |N(S)|.
Repeated exchanges terminate at the global prefix. This proves its
isoperimetric minimality.

## Compatible neighborhoods and algorithmic conclusion

Within a weight layer, ell is order preserving. A global prefix ending in
layer r therefore has as neighborhood all the earlier opposite-parity
layers and a prefix of layer r+1. The origin case for a nonempty odd
prefix is supplied by its first unit vector. Thus the neighborhood is
exactly the opposite prefix of its computed size.

The established two-count comparison theorem now applies to every odd
box: with parity class sizes E,O, the state space has (E+1)(O+1) states
and at most m+1 allocations per state. Computing prefix neighborhoods
requires only actual finite box adjacency. The exact shortest route to
a+b≤m gives the minimum number of inspection days and a prefix-tail
strategy; failure to reach it proves infeasibility. This is polynomial
in the number of rooms. It does not assert a closed expression in arbitrary
side lengths, nor does it classify boxes with even sides greater than two.

No substantive gap was found in this reconstructed argument. A second
independent reviewer was requested before promoting the universal result
to the website or manuscript theorem list.

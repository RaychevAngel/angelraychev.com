# Second independent review of the odd-width/even-length high-budget theorem

Reviewer: three_row_all_budgets. Read the complete current manuscript
`paper/sections/odd-short-even-high-budget.tex`, the root two-day argument
as recorded in `supersession-odd-short-two-day-independent-review.md`, the
inverse-superadditivity proof in `paper/sections/even-rectangle-time.tex`,
and the underlying static profile and corner-function definitions.

**Verdict: PASS as an ordinary proof.** No substantive gap found. This
review makes no new Lean claim and does not extend the budget range below
m=b(b+1)+1. No manuscript edits or experiments were performed.

## The inverse inequality is valid in exactly the domain used

With h rooms in each color, the deleted-set map is

    I(z)=h−g(h−z)=z−min(rho(z),b,R(h−z)).

It bounds the physical deficit after moving from any survivor obtained by
deleting z cells from a full color. Its subtracted cost is subadditive
for x+y≤h. If a cap or reflected branch attains either summand's minimum,
that same branch at x+y is no larger. Otherwise both minimizing branches
are rho, and pronic subadditivity proves the assertion. This includes
x+y=h, where the reflected cost is zero. Therefore I(x)+I(y)≤I(x+y)
holds for the full symmetric profile on every even-area rectangle,
including an odd shorter side. Dynamic attainment of profile minima is
neither claimed nor needed for this lower bound.

## The q=2 first-day split has no missing equality case

Write r=2k>0, c=min(Q(k),b+1), h=2m−b+k. The assumptions give
h−m=m−b+k>b², so the reflected cost in every I(p), p≤m, is above b.
If both first-day allocations are positive and their costs sum to at
most b, both costs are strictly below the cap (the other cost is at
least one). Thus p≤a(a+1), m−p≤a'(a'+1) and a+a'≤b, forcing
m≤b(b+1), a contradiction. Hence their total deficit is at most
m−b−1. For a pure allocation the static minimum surplus is b, so every
noncritical actual survivor also loses at least b+1.

For those nonexceptional first days the second-day total inverse input
is at most Z=2m−b−1<h, with h−Z=k+1. Thus the superadditive bound is
used strictly inside its valid domain. Since Z>B=b(b+1), its pronic
cost exceeds b and

    I(Z)=Z−min(b,R(k+1))≤h−k−c.

The final inequality follows from Q(k)≤1+R(k+1), including clipping.

## The exceptional second day covers both ends of the profile

A pure first-day survivor with surplus b has size h−m strictly between
b² and h−B because m>B. Its moved belief has exactly m+k rooms; its
mate stays full. Writing the second quotas as m−u and u leaves active
survivor size s=k+u.

When s<h−B, the conditional small-corner bound applies if s≤b².
Otherwise the static minimum is b and two successive strictly middle
critical survivors are excluded, so the actual surplus is at least
b+1. This is exactly the plateau of L_1. Monotonicity of its surplus
gives total deficit at most h−L_1(k+u)+u≤h−k−c.

When s≥h−B, the quota satisfies u≥2m−b−B>m−b≥b²+1. Therefore
rho(u)≥b, while R(h−u)>b since u≤m; I(u)=u−b. The active survivor
is nonempty and proper (k>0 and k+m<h), so each term of its static
surplus minimum is at least one. Its neighborhood has at least s+1
rooms, giving total deficit at most h−k−b−1≤h−k−c. No shape assumption
has entered this branch. Filling unused quotas monotonically is valid.

Thus every physical two-day process has total deficit at most h−k−c.
The forward and reversed two-day processes meet at the third inspection
of a five-day schedule, each including its second movement. Their
intersection has at least 2(k+c)=2J(r) rooms, so 2J(r)>m forbids the
fifth-day completion. There is no lost or duplicated movement.

## Quotient reductions and construction consistency

For q=1, r=2s−1 and h=m+s. A co-small departure with
x≤a(a+1), t=x−a≤a² has cost h+a in the cardinality branch and
h+a+min(R(s−t),b) otherwise. Both are at least h+min(R(s),b),
by t≤a² and square-root subadditivity. The zero deficiency is included.
For q=3 the sole unresolved residue yields k+c=floor(m/2),
k≥b(b−1)/2 and h=3m−2b+k; the stated strict separation inequality
is positive for every b≥1. The q≥4 estimate also follows directly
from m≥b(b+1)+1. Hence only the q=2 argument above was newly needed.

The backward construction's final first-survivor rank is
r+1+(q−1)(2m−w)=2h−2m. Parity forces phase zero, making its last
m-cell enlargement the full color. Reflection in the even coordinate
allows either physical initial cohort independently. Forward and reverse
half-searches therefore have the required opposite colors at the shared
day. These checks agree with the accepted physical construction.

The preceding critical-orientation and corner-potential lemmas were
read for consistency with the new application. Their earlier independent
proof boundaries remain as recorded in the root/Euler reviews; this
review does not replace those audits with a new exhaustive geometric
certificate.

## Genuine proof supersessions

1. Three rows, even n≥4: b=1 makes the new threshold3. Therefore every
   existing m≥3 case is now a direct specialization, including the old
   m=h−2,h−1 boundary exceptions. Only m=2 needs its separate historical
   rank proof (n=2 is already the two-row family). Its conclusion is
   T_2=6n−8. The old general quotient/shared-round proof and high-budget
   exception subsection can be removed after replacing the m=2 lower
   argument by the following specialization: for the existing exact
   rank update F_h, max(u−4,0) drops by at most one at p=2 and cannot
   drop at p=0,1. Thus its two-cohort sum drops by at most one per day
   and starts at4h−8. The existing prefix solo sweeps attain that time.
   Keep the arbitrary-support rank geometry; the new theorem does not
   prove that specific history lemma at m=2.

2. Five rows, even n≥6: b=2 makes the new threshold7. Only m=3,4,5,6
   need the special five-row proofs. In particular the high-budget
   finite antichain checks at (h,m)=(15,8),(15,11),(20,14), the nearby
   budget-monotonicity cases, and the h≥25,m≥h−7 discussion are fully
   superseded. Their Lean verification may remain documented in the
   formal-artifact inventory without retaining those proof paragraphs.
   Preserve the m=4 construction immediately following that discussion.
   The earlier potential proof for5≤m≤h−8 is still needed at m=5,6;
   those budgets always satisfy the range because h≥15. Its two
   remaining formulas specialize to T_5=2n−2 and, with
   5n−6=7q+r, 0≤r<7, T_6=2q if r=0, 2q+1 if r∈{1,2}, and2q+2
   otherwise. The generic high-budget construction can be cited for
   m≥7; preserve the existing actual-prefix construction for m=5,6.

3. The new bounded odd-frontier theorem strictly improves the full-board
   application paragraph after `thm:middle-transfer`, which currently
   advertises O((b²+m)E) retained states. That application can be dropped
   in favor of the new length-independent bound. The middle-transfer
   theorem itself remains a separate result: it characterizes arbitrary
   prescribed partial-state endpoints and supplies a Lean-verified
   constructive interval rule. The bounded-frontier theorem discards
   low-total states and therefore does not subsume that general transfer.

4. The new bounded odd-frontier theorem does not subsume the explicit
   low-width or high-budget closed formulas as formulas. It is an exact
   bounded arithmetic algorithm with a final finite optimization. The
   scalar endpoint-only midpoint criterion remains open. Removing those
   closed results merely because the algorithm can compute them would
   lose explicit information.

# Independent audit: uniform even-width high-budget lower bound

12 September 2026. The ordinary proof in
`uniform-even-rectangle-high-budget-lower.md` passes an independent
mathematical reconstruction. No additional computation or Lean claim.

* The inverse identity is the exact equal-color empty-pair duality,
  not an assumption that profile minimizers are nested.
* Subadditivity of A(z)=min(rho(z),b,R(h−z)) is correctly split by a
  minimizing branch. A plateau or decreasing reflected branch at either
  input bounds A(x+y) by that one input cost. In the remaining case,
  rho(x+y)≤rho(x)+rho(y) follows from the triangular-number thresholds.
* The total-deficit induction is deliberately stopped before scalar
  capture. Then D_t+m<h, so both individual inputs and their sum are
  in the domain where superadditivity applies. Saturating the sum at h
  without this guard would not be justified; the note does not do so.
* The even-horizon argument aligns the two sets at day L+1: the forward
  half includes its L-th movement, and the reversed half omits its final
  movement. The reversed set has already avoided the central-right shot,
  so an intersection yields a complete avoiding walk. Both cardinality
  bounds are at least h+1 because D_L<h and D_(L−1)+m<h.
* The odd-horizon argument omits precisely the central inspection from
  both halves. Their intersection lower bound 2c_L is a necessary central
  shot count, not a claimed sufficient construction.
* High-budget evaluation uses two distinct inequalities correctly:
  m>b(b−1) removes the far-corner branch at every positive survivor,
  and m−b>(b−1)² puts the first q−1 residuals on the plateau. The last
  residual is r. All q=1, r=0, and b=1 guards are handled explicitly.

Thus the lower matches the separate physical upper for every even
shorter side w=2b, n≥w, and b²+1≤m<h. The low-budget and mixed-parity
extensions are not inferred from this audit.

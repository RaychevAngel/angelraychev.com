# Every fixed feasible budget has an eventual affine period on odd rectangles

12 September 2026 UTC. Full ordinary proof, independently audited with no
gap; see `odd-fixed-budget-eventual-independent-review.md`.
It extends the independently reviewed minimum-budget band-surgery theorem.
The all-budget uniform potential bounds were derived independently by root
and written in `odd-fixed-budget-uniform-bounds.md`. No enumeration or
assumed optimal serial schedule enters the eventual-periodicity proof.

## 1. Statement

Fix an odd width w=2b+1>=3 and any fixed feasible budget m>=b+1. Put

    d=2m-w>0,     g=gcd(w,d),     Delta=lcm(w,d)=wd/g,
    J=m+1,        A=b(b+1),       R=Delta+2J,
    B=8b²+6d+2,   L=b²+m+1,      E=B+4L(B+1),
    H*=R+2A+4J+2+2E(R+2J+1).                           (1)

Then for every odd n>=w with H=(wn+1)/2>=H*,

    T_m(w,n+2d/g)=T_m(w,n)+4w/g.                       (2)

Thus the sequence has an affine period in the odd longitudinal length.
At the minimum budget, d=1, it becomes the earlier eventual affine law
T_(w+1)/2(w,n+2)=T_(w+1)/2(w,n)+4w.

Let n0 be the least odd length whose majority size is at least H*. For
each of the q=d/g odd residue classes modulo2q, compute the exact time
at one base length n0,n0+2,...,n0+2q-2 using the proved two-count recurrence.
Equation(2) then determines every larger time, and the construction below
extends an optimal base strategy. This does not assert that the period
already begins at the square. The threshold is explicit but deliberately
loose.

## 2. The general-budget potential and a bounded deficit

For a sufficiently large majority size H, define

    K=2b²+2m+1,
    C=2H-4b²-2m-5>0,
    F_p(k)=min(C,max(0,2k+p-K)).                         (3)

The sizes in (1) have C>0 and H-1>m. The previously proved profile formulas
give, for every quota0<=r<=m,

    F_p(k)-F_(1-p)(g_p(max(k-r,0))) <= max(0,2r-w).     (4)

Here is the short verification. If the survivor q<=b², then
k<=b²+m and the current unclamped value is at most0. If
q>=H-b²-1, the successor j>=q-1 has unclamped value at least C. In
the middle region the profile is exactly j=k-r+b+p, so the raw difference
is2r-w. Common monotone1-Lipschitz clipping gives (4).

For two quota shares r and m-r, their positive-part bounds sum to at
most d=2m-w. Equality is possible only for shares0,m or m,0. Indeed, if
both parts are positive their sum is2m-2w=d-w<d; if only one is positive
and neither share is m, its value is at most d-2. The same conclusion
holds for padded final quotas.

Use an optimal strategy in prefix normal form and let Phi_t be the sum
of its current-color potentials. Define

    eta_t=d-(Phi_t-Phi_(t+1))>=0.                       (5)

These are integers. Both full initial classes have potential C, and the
final state has potential zero. A minority-first two-phase strategy gives

    T_m <= 4 ceil((H-1-m)/d)+2,

because every pair of full-budget days reduces an uncleared cohort by
at least d, and each phase can be padded to odd length. Integer rounding
therefore yields

    sum_t eta_t=dT_m-2C <=8b²+6d+2=B.                  (6)

Call eta_t=0 days efficient and the others bad. There are at most B bad
days. An efficient day gives all m inspections to one cohort. That active
cohort loses exactly d potential, while the inactive cohort's potential
stays exactly constant.

## 3. At most E days lack a full or empty inactive cohort

Zero inspections strictly increase every intermediate potential:

    0<F_p(k)<C => F_(1-p)(g_p(k))>F_p(k).               (7)

For a proper majority prefix g0(k)>=k, so the parity reversal increases
the raw expression by at least one. The full majority prefix has value C
and is excluded. For a nonempty minority prefix g1(k)>=k+1, giving the
same strict increase. Clipping preserves it below C.

Within a consecutive run of efficient days, after an active cohort loses
d potential its value is strictly below C. If positive, (7) forces it
to remain active next day. A switch is therefore possible only when its
potential reaches zero. It cannot become active again during that run:
a zero value cannot lose d, and its value cannot increase while inactive
on an efficient day. Each efficient run consequently has at most two
focused blocks. There are at most2(B+1) blocks in total.

The inactive potential in a block is constantly0 or C. In the former
case its count is at most b²+m=L-1. In the latter its count is at least
H-b²-2, at deficit at most b²+2<=L from its full class. A nonempty proper
support strictly grows under N²: backtracking gives S subset N²(S),
and equality would make S closed under two-step paths, contrary to
connectivity of its parity class's two-step graph.

Thus an inactive positive zero-potential cohort can remain at zero
potential for at most2L days. An inactive full-potential cohort becomes
exactly full within at most2L days. Empty or full inactive cohorts remain
so under further zero-inspection moves.

Call a day clean if one cohort receives all m inspections and the other
is actually empty or actually its entire current color class. Counting
all bad days and all block transients gives at most

    E=B+4L(B+1)                                        (8)

nonclean days. Flat potential alone was not treated as actual emptiness
or fullness; the strict N² growth argument is the necessary bridge.

## 4. A common protected band, with separate cohort cut points

Each cohort's one-day count changes by at most J=m+1, since the profile
surplus is between -1 and b+1 and every quota is at most m. Record the
two source counts of every nonclean day. A recorded count k forbids
integer cuts c with k in[c-J,c+R+J], ruling out at most R+2J+1 cuts.
There are at most2E records.

Choose a candidate c in

    A+2J <= c <= H-R-A-2J-2.                           (9)

By (1), the number H-R-2A-4J-1 of candidates exceeds2E(R+2J+1).
Some candidate therefore has no recorded count in[c-J,c+R+J].
No nonclean transition can touch the protected interval[c,c+R], by
the displacement bound. When a cohort lies there, every day is clean,
and that cohort is active: an inactive clean cohort is empty or full,
both outside this interval. Its full-budget count never increases.
It cannot cross the protected interval upwards on any day, because a
nonclean transition cannot touch it and a clean active transition does
not increase. Both cohorts start above and finish below the interval.

For each initial cohort i, independently choose its first count x_i
at most c+Delta+J. The previous count is above that threshold, so

    c+Delta < x_i <= c+Delta+J.                        (10)

The step entering this range is clean, and x_i is inside the protected
interval. While it is active inside this interval, the profile plateaus
give

    g_p(k-m)=k-m+b+p.

Every pair of full-budget days consequently reduces the count by exactly
d and restores its current color. Since d divides Delta, the next

    tau=2Delta/d                                      (11)

days reduce x_i to x_i-Delta, which lies in(c,c+J]. This is an even
integer duration. The entire trajectory stays inside the protected band,
so throughout it the other cohort is empty or full and receives zero
inspections. The two cohorts' crossing blocks cannot overlap.

The lower and upper endpoints

    ell_i=x_i-Delta,          u_i=x_i                  (12)

may differ between cohorts. This is intentional: when d>1, a trajectory
can skip a chosen count, and the two cohorts need not have the same
residue modulo d. The proof does not assume a common exact crossing
level. It uses one common protected band to supply two valid individual
cuts. Current-color prefixes of the two initial cohorts are independent,
so distinct cuts cause no conflict.

All visits of cohort i to its strict interval(ell_i,u_i) occur within its
chosen block. Clean active steps are nonincreasing, and nonclean steps
cannot touch the larger protected band. Its endpoint visits outside the
block, if any, are harmless. In the minimum-budget case a minority step
may preserve a boundary count; the even block length includes the phase
needed to glue the paths.

## 5. Contraction and expansion

Contract the rectangle by Delta cells in each color class, which changes
its longitudinal length by2Delta/w. Delete each of the two blocks of
length tau from (11). On every remaining state, transform the count of
initial cohort i by

    f_i(k)=k             if k<=ell_i,
           k-Delta       if k>=u_i.                   (13)

There are no retained states strictly between these cases. At the two
ends of its deleted block, u_i and ell_i both map to ell_i. The inactive
cohort is empty or full at both endpoints; its full class becomes the
contracted full class. The block duration is even, so parity labels
match as well. Hence the paths glue.

Every retained edge is a valid contracted profile transition. For a low
source k<=ell_i, its survivor is no larger. The contracted far-distance
satisfies

    (H-Delta)-ell_i=H-u_i>=H-(c+R)>=A+2J+2,

so the low profile is unchanged. Its successor cannot enter the removed
interval, by the protected-band analysis. For a high source k>=u_i,
the contracted survivor is at least

    (k-Delta)-m >= ell_i-m > c-m > b².

Thus the low-corner terms are saturated and the high profile translates:

    g_p^H(q+Delta)=g_p^(H-Delta)(q)+Delta.

Its successor is likewise in the high case unless it belongs to a deleted
crossing edge. These identities prove (13) conjugates every retained
transition. Inspection quotas remain within the same m; when useful
counts shrink they may simply waste part of their quota.

The contracted search has length T_m(w,n)-2tau. Since Delta is divisible
by w, its rectangle has odd length n-2Delta/w, still at least w by the
margins in (9). We obtain

    T_m(w,n-2Delta/w) <= T_m(w,n)-4Delta/d.             (14)

For expansion, choose the protected blocks of an optimal search on any
H>=H*. Enlarge H to H+Delta. Keep low counts at or below ell_i unchanged
and increase upper counts at or above u_i by Delta. Replace each block
from u_i to ell_i by a clean block from u_i+Delta to ell_i, of duration
4Delta/d. It is longer by the even number tau. The affine profiles give
this trajectory explicitly, while the inactive companion stays empty
or the enlarged full class. The same low/high identities verify all
remaining edges. Therefore

    T_m(w,n+2Delta/w) <= T_m(w,n)+4Delta/d.             (15)

Apply (14) to H+Delta to obtain the reverse inequality in (15). Using
Delta/w=d/g and Delta/d=w/g proves (2).

## 6. Consequences and precise limits

For every fixed feasible pair(w,m), optimal time has eventual affine
period2d/g in n and increment4w/g in time. Its leading term is therefore

    T_m(w,n)=(2w/d)n+O_(w,m)(1).

The already proved uniform bounds quantify the bounded correction more
directly. The explicit threshold and the exact two-count recurrence give
a finite procedure to determine the eventual offsets and optimal base
strategies in every residue class. They do not give a small closed formula
for the offsets, and they do not establish that the eventual law starts
at the square. Arbitrary even or mixed side lengths are outside this
argument. The general odd-box profile theorem remains the exact method
in higher dimensions; no unproved multidimensional periodicity is inferred.

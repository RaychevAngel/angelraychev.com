"""Focused solo lower-clock audit in the stated weakened merger model.
Full reduced-surplus closure, all pronic radii, and the static band-dual rule enabled; no band-memory bit.
"""
from pathlib import Path
import importlib.util,json,time
p=Path(__file__).with_name('resumed-erosion-merger-relaxed-check.py')
spec=importlib.util.spec_from_file_location('relaxed',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def check(b,n,k):
 started=time.process_time();h=(2*b+1)*n//2
 states,masks=m.ns['build'](b,n,k,closed=True,triangle=True,maximal=True,dual=True,compact=True,all_radii=True,band_dual=True)
 initial=states.index((h,2,2));zero=states.index((0,0,0));seen=frontier=1<<initial
 dist={initial:0};layers=[];tau=None;depth=0;minimum=h
 while frontier:
  members=[];bits=frontier
  while bits:
   bit=bits&-bits;bits-=bit;a=bit.bit_length()-1;members.append(a)
  minimum=min(minimum,min(states[a][0]for a in members))
  layers.append(dict(moves=depth,minimum_reachable_size=minimum,new_states=len(members)))
  if zero in members and tau is None:tau=depth
  following=0
  for a in members:following|=masks[a]
  following&=~seen;seen|=following
  bits=following
  while bits:
   bit=bits&-bits;bits-=bit;dist[bit.bit_length()-1]=depth+1
  frontier=following;depth+=1
 assert tau is not None
 checked=0
 for a,row in enumerate(masks):
  if a not in dist:continue
  bits=row
  while bits:
   bit=bits&-bits;bits-=bit;d=bit.bit_length()-1
   assert d in dist and dist[d]<=dist[a]+1
   checked+=1
 f=layers[tau-1]['minimum_reachable_size']
 terminal=[states[i]for i,dd in dist.items()if dd<=tau-1 and states[i][0]==f]
 return dict(width=2*b+1,length=n,budget=k,states=len(states),edges=sum(x.bit_count()for x in masks),solo_tau=tau,penultimate_f=f,doubled_central_test=2*f>k,full_game_lower_from_reviewed_merger=2*tau if 2*f>k else 2*tau-1,terminal_minimizers=terminal,forward_edge_inequalities_checked=checked,layers=layers,CPU_seconds=time.process_time()-started)
if __name__=='__main__':
 rows=[check(5,n,6)for n in(12,14)]
 out=dict(scope=__doc__,positive_cardinality_lower_bounds_omitted=True,canonical_source_sha256=m.original_sha256,rows=rows)
 Path(__file__).with_name('resumed-erosion-merger-band-dual-solo-check.json').write_text(json.dumps(out,indent=2)+'\n')
 for r in rows:print(json.dumps({k:v for k,v in r.items()if k!='layers'},indent=2))

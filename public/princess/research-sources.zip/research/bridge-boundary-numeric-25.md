# A uniform two-day bracket for 25 by even-length rectangles

13 September 2026. New ordinary proof and fixed arithmetic certificate by
the boundary-numeric branch; independent review requested. This applies
the joint physical day-28 barrier and the accepted nine-threshold erosion
model without triangle flags and with the original all-radius band filter.

## Result

For every even n>=26,

    50n-926 <= T_13(25,n) <= 50n-924.

The lower is new here. The upper is the existing minimum-budget expression
2wn-C_w: at width 25, L_12=46 and C_25=924, recorded in
`resumed-odd-even-minimum-upper.json` and attained uniformly by the theorem
in `resumed-odd-even-minimum-upper.md`. No exact value inside this interval
is claimed. Set h=25n/2>=325 throughout.

## Capacity bounds and a fixed entrance

Write P(v,u,j;s) for the closed low capacity and F(A,B;s) for the high
capacity in `bridge-lower-frontier-nine-proof.md`. Direct substitution gives

    max_(v,u,j) [12+P(v,u,j;12)]=156,
    max_(A,B) F(A,B;12)=144,
    max_(j,v<=1) F(2-j,2-v;12)=132,
    max_v F(0,2-v;12)=132,
    max_(A,B) F(A,B;11)=121.

The domains include 0<=u<=j<=2 and 0<=v<=2. Monotonicity in surplus
extends these bounds to every smaller surplus. The critical branch permits
closed surplus 12 only when (v,j)=(2,0); otherwise the unrestricted branch
starts at 13. The original surplus is the closed surplus plus delta=v-i.

Take the capture seed B_0(c,e)=0 and the half-budget seed R_0(c,e)=6.
Direct exact substitution for 70 steps gives

    B_70(c,e)=R_70(c,e)=157 for all nine feature pairs.

Every target used in these 70 updates is at most 157. Its high-side deficit
is at least 325-157=168>144, so the high branch is inactive below closed
surplus 13. Every all-radius band has deficit at most 12*11=132, so no
band filter applies. All state upper bounds are inactive. Thus the entire
fixed entrance is independent of h>=325. The independent verifier computes
it directly from P, the critical exception, and surpluses 0,...,13, without
using the closed inverse-root formulas. Both complete 71-row traces are
stored in the receipt.

## A two-step plateau valid over every intervening size

For 157<=a<=h-134, let E(a) be the all-a vector and let C(a) be the vector
which equals a in own-corner classes c=0,1 and a+1 in class c=2, independently
of the eroded-corner index e. Then exactly

    E(a) -> C(a) -> E(a+1).

For the first step, target size is a and hole size is at least 134. The
low branch cannot supply any closed surplus <=12, since a>156. The high
branch cannot supply surplus <=11, since its capacity is at most 121.
For target erosion v<=1, even surplus 12 is excluded by the bound 132.
Consequently a source with c<=1 always pays original surplus at least 13:
if v=2 then delta=v-i>=1, and otherwise closed surplus is at least 13.
It cannot grow. A source with c=2 can grow by one, using i=v=2, u=j=0,
and critical surplus 12. These choices satisfy maximality and the coupled
deletion charge. All sources can attain the unchanged threshold using
i=v=u=j=0 and unrestricted surplus 13. This proves the first step.

For the second, target own-corner classes j=0,1 still have size a, so
surplus at least 12 bounds their contribution by a+1. Targets with j=2
have size a+1 and at least 133 holes. Even their high capacity at surplus
12 is at most 132, so their closed surplus is at least 13 and they too
contribute at most a+1. Equality in every source class is attained with
target (j,v)=(2,0), i=u=0, and unrestricted surplus 13. No band filter is
active because every target deficit in both steps is at least 133. All
upper state bounds and deletion charges are inactive or explicitly met.
This proves the two-step identity.

There are exactly h-290 such pairs from E(157) to E(h-133). Hence both
backward sequences reach the all-(h-133) vector at time

    70+2(h-133-157)=2h-510.

## A fixed nineteen-step exit

From that point every target is at least h-133>=192>156, so the low branch
is permanently inactive below closed surplus 13. All upper feature bounds
are inactive in the exit, whose deficits remain at least 110. In deficit
coordinates every subsequent update depends only on the nine current
deficits, the fixed high capacities, the critical exception, and the original
all-radius band rule. It is therefore independent of h.

Starting with the all-133 deficit vector, nineteen direct substitutions give,
at steps 18 and 19, in feature order (0,0),(0,1),(0,2),(1,0),...,(2,2),

    d_18=(113,113,113,112,112,112,112,112,112),
    d_19=(112,112,112,111,111,111,110,110,110).

Every earlier deficit is at least 112, as the full fixed exit table in the
receipt records. The independent calculation checks all eleven possible
band radii 2,...,12 directly; it does not replace them by a guessed critical
radius. Consequently, for both B and R,

    max B_(2h-492) = max R_(2h-492) = h-112,
    max B_(2h-491) = max R_(2h-491) = h-110.

The first backward time admitting any feature of size at least h-111 is
2h-491. This is an exact uniform evaluation, not a sampled linear trend.

## Full-board lower and the guarded merger

Put L=2h-464. The argument is the same direct middle-day intersection
argument proved in `bridge-boundary-numeric-24.md`, now using the erosion
merger and these nine thresholds. For completeness, let a_t be joint belief
size minus h. A first crossing a_t<=13 before or at day 28 would give an
unfiltered model capture by day 29, impossible since even B_70 has maximum
157<h. Thus the guarded merger is valid through time 28.

The physical day-28 theorem gives a_28>=h-111. A first crossing to at most
13 at some t<=L-1 would permit model capture from that feature in
t-28+1<=L-28=2h-492 days, contradicted by the displayed capture frontier.
Thus the merger is valid through time L. A value a_L<=6 would contradict
the half-budget frontier at the same remaining horizon. Therefore every
physical full-board belief after L steps has size at least h+7.

The first L inspections and reversed last L inspections of any proposed
2L+1-day strategy produce two such beliefs at its middle day. Their
intersection contains at least 14 rooms, exceeding budget 13. Hence

    T>=2L+2=4h-926=50n-926.

This uses the jointly proved transferred barrier; no sum of solo bounds
or automatic time-filter merger is substituted for it.

## Certificate and proof boundary

`src/bridge_boundary_numeric_25.py` evaluates the finite entrance and exit
directly through their quadratic inequalities, and independently compares
each substitution with `bridge_lower_frontier_nine.py`. The receipt
`bridge-boundary-numeric-25-check.json` contains the full traces, capacity
maxima, feature order, source hash, and PASS status; runtime 0.069091 CPU
seconds. The varying-length step is the explicit plateau invariant above.

This uses the existing accepted exactness and merger theorems for the
necessary nine-feature model. Model attainability is not physical strategy
attainability. No new room-level upper, exact classification of this interval,
or complete physical Lean theorem is asserted.

# Optimal-time slope on every Hamiltonian bipartite cylinder

12 September 2026. Root derivation; complete ordinary proof below, independently
reviewed by the frontier agent. No literature-priority claim or full Lean
claim is made.

## Theorem

Let Q be a fixed finite bipartite graph with A>=2 vertices and a Hamiltonian
path. Fix an integer daily budget m>A/2. Then, for all longitudinal parities,

    T_m(Q square P_n) = 2 A n / (2m-A) + O_(A,m)(1), as n tends to infinity.

In particular this holds for every Cartesian box used as Q, even when all
its nontrivial sides are even and greater than two. The lower comparison
uses only the spanning path in Q, so no other property of Q enters the
implicit constant. The already proved height strategy gives a constructive
upper bound

    T_m(Q square P_n) <= 2 ceil(A(n+2)/(2m-A)).

When A is even, the proof below gives the explicit lower bound

    T_m(Q square P_n)
      >= 2 max(0, A n/2 - A² - m)/(m-A/2).

Thus the upper and lower bounds differ by a constant independent of n.
For m<=floor(A/2), sufficiently long cylinders are impossible by the
Hamiltonian rectangular-subgraph feasibility theorem. This determines the
eventual feasibility and the exact linear growth rate for every budget.
It does not determine the bounded time offset or prove its periodicity on
general even cross-sections.

## 1. A coarse interior profile bound on every even-width rectangle

Consider P_(2b) square P_n, with b>=1 and n>=2. Match rows2i and2i+1 in
each column j. Identify either parity's rooms with the b*n matched pairs.
An original graph edge followed by the inverse matching becomes a directed
edge on these pairs. The resulting directed graph D has:

- a loop at every pair;
- horizontal edges in both directions along each of its b rows;
- vertical rungs between adjacent rows, all directed one way in even
  columns and the opposite way in odd columns.

Reversing the physical parity reverses the rung directions and changes
nothing in the argument. Under this identification,

    |N_original(R)| - |R| = |N_D^+(R) minus R|.

Let B=N_D^+(R) minus R and suppose s=|B|<b. In D-B, R is outgoing-closed.
There is an entirely undeleted horizontal row, since fewer than b vertices
were deleted. All its vertices lie in one strongly connected component C.

Call a column bad if it contains a deleted vertex. There are at most s bad
columns. Two adjacent columns which are not bad form a strongly connected
b-by-2 subgraph: horizontal edges move in both directions, while the two
opposite rung orientations allow travel both ways between any adjacent
rows. This subgraph meets the undeleted row, so all its vertices lie in C.

The only columns that can contain a vertex outside C are bad columns and
isolated good columns (a good column with no good neighbor). There are at
most s+1 isolated good columns, one in each gap between bad columns or at
an end. Consequently

    |V(D) minus C| <= b(2s+1) <= 2b²-b < K,  K=2b².

This includes the case with no adjacent good columns: then every column
belongs to the exceptional list. No assumption that n is large was used.
An outgoing-closed R either avoids C or contains C in its entirety, because
C is strongly connected. Therefore either |R|<=K or b*n-|R|<=K.

Contrapositively, for h=b*n,

    K<|R|<h-K  implies  |N_original(R)|>=|R|+b.       (1)

For every R the matching also gives |N_original(R)|>=|R|, including the
empty and full sets. This argument classifies only a broad interior band;
it does not purport to be an exact isoperimetric profile.

## 2. A clipped potential and an optimal slope

Set C=max(0,h-2K-m), L=K+m and

    psi(k)=min(C,max(0,k-L)).

For one cohort of size k, let p<=m useful probes leave r=k-p survivors,
and let k' be their actual next neighborhood size.

If r<=K, then k<=K+m=L and the source potential is zero. If r>=h-K,
then k'>=r>=h-K=L+C when C>0, so the target has the full potential C;
the case C=0 is trivial. Otherwise (1) gives k'>=k-p+b. Clipping is
monotone and1-Lipschitz, so in every case

    psi(k)-psi(k') <= max(0,p-b).                     (2)

Capture is included in the first case and hence causes no hidden endpoint
exception. The two initial-color cohorts occupy disjoint physical parities
at every time, so their useful shares p0,p1 have p0+p1<=m. Since m>b,

    max(0,p0-b)+max(0,p1-b) <= m-b.

Both full cohorts start with potential C, and successful capture ends with
zero. Telescoping (2) gives T_m>=2C/(m-b), the advertised explicit bound.
The height construction gives

    T_m <= 2 ceil(2b(n+2)/(2m-2b)).

Both bounds have slope 2(2b)/(2m-2b). All supports and schedules in the
lower proof are arbitrary; there is no prefix or monotonic-search premise.

## 3. General transverse graphs and odd size

A Hamiltonian path in Q gives the subgraph P_A square P_n. Any target walk
in that subgraph is legal in Q square P_n. Thus its optimal capture time
is a lower bound for that on the whole cylinder. For even A, Section2 and
the height upper prove the theorem immediately.

For odd A>=3, apply the independently reviewed odd-rectangle fixed-budget
time theorem to the spanning rectangle P_A square P_l, where l is the
largest odd integer at most n. For fixed m>A/2 its exact eventual affine
period has length increment 2(2m-A)/gcd(A,2m-A) and time increment
4A/gcd(A,2m-A). Hence

    T_m(P_A square P_l)=2 A l/(2m-A)+O_(A,m)(1).

Since n-l is zero or one, the same expression with n is a lower bound up
to a bounded constant. The height upper matches its slope. The case A=1
is a path and is covered separately by the complete path classification.

## Examples and boundary of the claim

- 4×4×n, m=9: T=16n+O(1), for either parity of n.
- 4×4×n, m=10: T=8n+O(1).
- 3×4×n, m=7: T=12n+O(1).
- 3×3×n, m=5: T=18n+O(1), consistent with the exact odd formula18n-36
  and the separately verified36-day even box3×3×4.

The constants in the even-size bound are deliberately coarse. This theorem
bridges the leading optimal-time behavior across all side parities; it does
not justify any of the missing exact even-side offsets or a universal
corner-prefix strategy.

## Final threshold audit: 12 September 2026

Root independently accepts Section16, extending the exact formula to
all m>=b²+1. The original threshold audits below remain historical.
The review checked the exact-profile reduction before any equality use,
the strict linear-target and zero-probe inequalities, clipped-source
quotient bounds, and the three possible total-slack cases. In the
discounted one-slack case, the first day consumes the entire slack;
proper tight tails must then be consecutive and the unique overlap
requires m+1 probes. The first-day rank gain is measured from N,
including the exceptional majority endpoint p=b². The b=3 residue
boundary is included explicitly in the manuscript. Finite arithmetic
and exact-time checks support this unbounded ordinary argument but do
not replace it. This result is not claimed as fully formalized in Lean.

# Independent review of the uniform high-budget rectangle theorem

12 September 2026. Root review of the recurrence agent's ordinary proof.
Accepted range: odd width w=2b+1>=3, odd length n>=w, m>=2b²+1.
This audit does not claim the lower-budget extension or full physical Lean.

The proof in `high-budget-odd-rectangles.md` was checked independently of
the finite data. Its key advance is a boundary envelope that removes the
need to list every possible near-full transition separately.

## Interior and boundary inequalities

I checked the positive-remainder and zero-remainder conventions for F.
They agree because J(D)=m; the cardinality branch handles the first period
without an artificial corner discount. At the first noncapture rank the
potential can jump by two, as required. The interior quotient decreases by
at most one. With no decrease the uncorrected slack is at least b and the
corner discount changes by at most b-1, so equality is impossible. For a
nonplateau survivor, the precise bounds s<=(b-1)² or s<=b(b-1) imply
quotient exactly one; the looser bound s<=b² alone would not justify that
claim at the smallest budgets. The stated sharper bounds do justify it.

For nonempty survivors the deficit inequality d'<=d+p correctly includes
the change in parity capacity. Capture must and does use F(rank)=k<=p
instead. The envelope argument bounds the source against each target
branch separately and hence proves the inequality against their minimum.
It transfers to arbitrary physical supports by the proved isoperimetric
profile lower bound and monotonicity of both envelope branches.

## Removing the boundary discount

For a deletion x<=b² from a full cohort, I verified the two rank decreases
2(x-R(x)) and2(x-Q(x))+1, including the negative minority gain at x=1.
The large-budget condition allows at most one quotient wrap and ensures
that the wrapped target remainder is on the bulk plateau.

Without wrapping, the even gain uses root subadditivity. The odd gain
uses the two cross-phase square/consecutive-product inequalities, with
the zero endpoint handled separately. The inequalities remain valid after
the two surplus caps are applied. With wrapping, direct substitution
gives the exact potential drops t+J(r)-ceil(r/2) and
t+J(r)-floor(r/2); the bounds r<2t and r<2t+1 give the asserted root
estimates. A target in the cardinality branch only improves the comparison.
This establishes C=F(N), not merely an experimentally matching value.

## The exact extra day

The critical case is even m, r=m-w, q even and positive, hence q>=2.
I verified the full-state departure calculations. For p<=b², the root
inequalities give strict slack for both phases; for larger p the source
survivor is on the true plateau. Only minority departures using at least
m/2 can be tight.

One clarification was required and has been incorporated by the author:
in this critical case N=qD+m+1 and C-h=qw/2>=w. Therefore the linear
envelope branch is positive on every nonempty physical support. Its strict
deficit inequality cannot be erased by clipping at zero. Every tight
target consequently uses the F branch, so the quotient rigidity argument
can be applied inductively rather than assumed.

For the remaining majority near-full case, the source deficit is
d=d0+s with d0=m/2-b and s+p<=b-1. The source has F=qm-s;
the clipped target has positive remainder2b-1-2(s+p), and its total
cost exceeds the source by at least b+1. It cannot be tight. This
exhausts the far-corner exceptions. Each cohort therefore has exactly
q+1 consecutive active days. Their forced one-day overlap makes both
starts have the same day parity, contradicting their required minority
phase. Arbitrary interleaving is excluded by equality, not by a serial
normal-form assumption.

## Construction and simplified formula

The capacity recurrence is valid because the queried targets are beyond
the largest nonplateau output b². The shared-day construction can be
expressed geometrically by inspecting the neighborhood of a terminal
corner prefix; complementing its neighborhood leaves an initial prefix.
Thus the deficit needed for the remaining q rounds is attained by actual
room inspections, including q=1 and the small-residue endpoints.

Finally H(r)=2J(r)+delta(r) is strictly increasing: successive increments
are increments of L0 and L1. Checking its crossing of m gives exactly
the cutoff m-w-1+1_[m=2b²+1]. I separately checked the b=1 endpoints
against both the exact count recurrence and the previously proved
three-row formula for odd lengths3 through21; all agree. The final
formula therefore requires only integer division and this one indicator.

The original computational checks and physical replays are corroboration.
The unbounded result rests on the profile theorem and the reviewed
arithmetic/geometry above. Lowering the quadratic budget threshold remains
a separate research problem.
# Extended threshold audit: 12 September 2026

After the original audit below, the root agent independently checked the
new Sections 11--14 of `high-budget-odd-rectangles.md`.

The full formula is accepted for every odd width `w=2b+1`, odd length
`n>=w`, and budget `m>=b^2+b`. The simpler formula without root functions
retains its stated range `m>=2b^2+1`. For `m>=b^2+1` the same explicit
strategy is within one day of optimal, without asserting its exactness
throughout the intervening range.

The review checked the four quotient-wrap inequalities directly. In the
majority rows the source surplus is at most the corner root `a`; in the
minority odd-remainder row it is at most `a-1`. The exceptional corner
root `a=b+1` uses `x<=b^2`, improving the naive consecutive-product bound
by `b`. The zero-source-surplus cases require separate inequalities and
are included. These establish `F(N)-1<=C` at `m>=b^2+1`, and `C=F(N)`
at `m>=b^2+b`.

For the equality case, the four strict non-wrap root inequalities were
checked including the plateau caps. A proper clipped source whose
positive-remainder quotient has fallen has `F(source)<C-deficit`:
the four gaps are at least `alpha-1, alpha, alpha, alpha`, respectively.
The `q=1` cardinality branch gives the first two gaps exactly. The
positive linear branch has strict slack at every proper noncapture
transition, so a tight history cannot return to the full state, pause
after departure, or skip a quotient. Its two activity intervals each
have `q+1` days and share exactly one day.

The final shared-day argument was checked against arbitrary physical
supports. Omitting `s+1` majority rooms, or `s` minority rooms, forces
inspection of their entire neighborhood. Their complementary deficits
are at least `m>b^2`, so the finite profile equals the unbounded corner
profile there. This requires `m/2+1` probes when only `m/2` remain.
The added width-three budget-two endpoint has remainder zero and is
handled separately. No unproved optimal-sweep assumption is used.

The intermediate claim that every tight initial allocation must start
in the minority phase is deliberately not used: it is false at the
improved threshold. Only the first full-budget day must start minority.

This is an ordinary mathematical audit, not complete Lean verification
of the unbounded rectangle theorem.

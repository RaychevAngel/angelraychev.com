# Independent review of the odd-rectangle theorem

12 September 2026 UTC. Root reviewed the independent frontier subtask's
ordinary proof in odd-rectangle-isoperimetry.md. No substantive gap remains
in the reviewed version. This is not a Lean verification or a priority claim.

The compression to two Ferrers diagrams follows from the separately checked
odd-path operator and its Cartesian lift. It does not presume ordinary
checkerboard corner ideals. Root independently derived the quadrant
neighborhood row sums and checked the telescoping tail bounds for both
parities, including zero rows and configurations in only one coordinate-
parity pattern. The lower bounds k<=delta^2 and k<=delta(delta-1) follow by
summing the positive rowwise bounds; no connectedness assumption is needed.

The finite rectangle loses exactly F+Z outward neighbors relative to the
quadrant, including two distinct outward neighbors at an occupied far corner.
When exactly one far edge is occupied, the last-row bound or its transposed
version gives the strip threshold. When both are occupied, the Ferrers
property implies coverage of the two opposite-parity near edges. The
reflected complement of the neighborhood is therefore untruncated at its
far edges. It is a Ferrers set because the neighborhood is fixed by each
odd-coordinate operator. Its neighborhood is contained in the reflected
complement of the original set, which justifies the surplus estimates.
The majority surplus -1 and 0 and the minority empty-complement case were
checked separately; the formulas use R(0)=0 and Q(0)=1 correctly.

An initial explanation of the middle prefix range incorrectly said all
neighboring diagonals have the constant width. This fails even on a square.
Root supplied a precise replacement. With source layer d, lower endpoint
L=max(0,d-2b), and j selected vertices on that layer, its contribution to the
upper opposite layer is exactly

    j+1-1_(d>=2b)-1_(L+j-1=2a).

All lower opposite-parity layers are full, including the special first odd
layer. Subtracting the earlier source-layer count yields the alternating
layer sum in the corrected proof. This establishes prefix attainment and
nesting without the inaccurate shortcut. The independent layer receipt
checks 3,684 physical prefixes through side length17 as an additional attack.

The conclusion is an exact open-neighborhood profile and compatible nested
orders for every odd-by-odd rectangle. Consequently the two-count recurrence
has exactly the unrestricted game's optimal capture time for every budget,
and its minimizing transitions provide physical optimal strategies. The
closed formulas currently proved for widths at most four are separate results;
this review does not establish a simple closed time formula for arbitrary odd
width, or any all-rectangle theorem when one side is even.

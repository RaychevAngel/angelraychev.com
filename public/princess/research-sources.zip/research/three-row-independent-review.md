# Independent adversarial review: three rows and two probes

Reviewed 11 September 2026. Target: `research/three-row-investigation.md`, which claims

\[
 T(P_3\square P_n,2)=6n-8\qquad(n\ge2).
\]

**Verdict:** I read the complete proof and independently reconstructed its sensitive steps. I found no substantive gap. The matching/SCC argument for even widths, the Hamilton-cycle/Hall argument for odd widths, the elimination-round bookkeeping, and the explicit construction all withstand the checks below. This is a second ordinary mathematical review, not a Lean verification, external peer review, or novelty certification.

## 1. Independent unrestricted computation

I separately implemented an on-the-fly breadth-first search using ordinary `frozenset` beliefs and Manhattan-distance adjacency, without the original solver's bitmask neighborhood table. It checks all pairs of useful probes and ends at the first belief with at most two possible rooms. It found exactly:

| n | Minimum turns | Distinct discovered beliefs |
|---|---:|---:|
| 2 | 4 | 11 |
| 3 | 10 | 35 |
| 4 | 16 | 95 |
| 5 | 22 | 186 |
| 6 | 28 | 368 |
| 7 | 34 | 573 |
| 8 | 40 | 961 |
| 9 | 46 | 1,395 |
| 10 | 52 | 2,029 |

All agree with `6n-8`. The entire independent run took about 2.5 seconds. The saved evidence is `three-row-independent-computation.json`. The ordinary proof below, rather than extrapolation from these values, supports the unbounded assertion.

## 2. Even-width critical sets

I recomputed the directed contraction from the stated horizontal matching. Its arcs are exactly the loops, `a_i <-> c_i <-> b_i`, leftward outer arcs, and rightward middle arcs. The neighborhood-surplus identity is therefore exact.

Deleting an outer vertex leaves a strongly connected graph: the other outer chain still permits leftward travel and the middle chain permits rightward travel. Deleting `c_j` leaves a directed condensation with the suffix pointing to the two outer singletons, each pointing to the prefix. Thus a nonempty outgoing-closed set of size at most `h-2` must have precisely the prefix-triples-plus-outer-singletons form in Lemma 1. This remains true at `j=0`, `j=q-1`, and `q=1`; missing pieces are simply empty.

The delicate next-step exclusion is sound. If `R` is such a critical survivor and `|R|<=h-3`, then `N(R)` contains neither corner at the opposite boundary. If `|R|=h-2`, it can contain only one. But a subsequent critical survivor `R'` has size `|R|-1`. In the latter case, for `q>=2`, this size is `h-3>=3`, which forces both opposite-boundary corners. For `q=1`, it would be empty, excluded by survival. Hence two consecutive ordinary efficient steps are impossible.

This is stronger than checking a scalar expansion bound: it explicitly rules out chaining independently optimal shapes, the actual obstacle to an invalid count-only proof.

## 3. Even-width global counting

Every positive non-elimination round has decrement at most one and must use both probes on the same cohort. Before the first elimination, the other cohort must be full and untouched. After one such round, the touched cohort is proper, so a following positive ordinary round must target it again; the critical-set lemma rules this out. After the first elimination, the same exclusion applies to the single remaining cohort.

Every adjacent positive pair consequently touches an elimination round. The first elimination has at most two incident pairs, the final one at most one. There are exactly two distinct eliminations: every nonempty cohort has at least two possible vertices, so each elimination uses both probes and both cohorts cannot disappear together. These observations justify the bound of three positive adjacencies and hence `x-y<=4`.

Each elimination has decrement at most two, all other positive rounds at most one, and all remaining rounds at most zero. Thus `3n<=x+2` and `k>=6n-8`, with no assumption that decrements are nonnegative.

The smallest even case `n=2` is covered. Its critical-survivor second-step case would require a nonempty set of size zero, so the exclusion is valid rather than an accidental use of a large-board hypothesis. Its four-round construction attains the lower bound.

## 4. Odd-width Hamilton cycles and Hall bounds

I checked the Hamilton-cycle construction after deleting an arbitrary majority vertex by splitting into the stated two cases.

- For an outer-row hole at an even column, both neighboring strips have even width. A cycle on one strip can insert the two surviving hole-column vertices using its middle-bottom boundary edge. The new middle-bottom edge then allows splicing the other strip. This also works when the hole is at the first or last column; at least one strip remains nonempty because `n>=3`.
- For a middle-row hole at an odd column, the central three-column perimeter is an eight-cycle. Each remaining side strip has even width, and splicing along separate boundary vertical edges joins all vertices into one cycle.

The even-strip cycles themselves are valid: the perimeter contains all boundary vertices, and disjoint detours through consecutive pairs of interior middle-row vertices include the omitted vertices without breaking the cycle. These detours do not remove the vertical edges needed for splicing.

The strong Hall deduction is also sound. For a nonempty proper minority subset `R`, choose a neighboring majority vertex `v` as the deleted vertex. On the remaining Hamilton cycle, `R` has at least `|R|+1` neighbors; reinserting `v` adds another. The complementary-set argument then gives the majority surplus bound. This uses actual properness of `R`, and the full-minority case is handled separately.

## 5. Odd-width elimination timing

A nonempty majority belief always has at least three vertices; a nonempty minority belief has at least two. Hence elimination is possible only from a two-vertex minority belief, using both probes.

Immediately before the first elimination, those two vertices must have arisen from a single majority corner. Any majority survivor with at least two vertices has at least three neighbors by the Hall inequalities. Since the preceding majority belief had at least three positions, exactly two probes were used and that cohort decreased from three to two. The other cohort was unprobed in the minority parity and grew by at least one. Therefore the preceding **total** decrement is nonpositive.

On the first elimination round, the unprobed other cohort is a majority belief of size at least three. Its next minority belief has at least four positions, including in the smallest case `n=3,h=4`. Two probes cannot eliminate it next, and its proper minority survivors expand by at least two. Thus the following total decrement is also nonpositive.

For an ordinary positive round before the first elimination, the only possible budget allocation is an untouched full majority belief plus two probes in the minority belief, whose survivors have surplus exactly two. Its next majority belief is proper, so this cannot repeat immediately. After the first elimination, an ordinary positive round can only occur in the majority parity, and the next round is in the minority parity. This establishes the isolation assertions without assuming beliefs stay connected or decrease monotonically.

Accordingly, only the final elimination can create a positive-positive adjacency, giving `x-y<=2`. The first elimination's possible bonus over an ordinary positive round is at most two, and the final one's at most one. Thus `3n<=x+3`, yielding the desired bound. If the first elimination itself is nonpositive, allocating it an unused bonus only weakens the inequality and does not invalidate it.

## 6. Explicit strategy and turn count

I manually replayed the startup sequence and obtained the stated row-frontiers:

`(2,1,0), (3,0,1), (2,1,2), (3,2,1), (2,3,2)`.

These remain correct when out-of-range row entries are empty, including `n=4`. The three-round shift of `F_j` to `F_(j+1)` follows the same row-neighborhood calculation. The terminal three-round sequence leaves first one bottom-row vertex, then a corner, then inspects the corner's two neighbors.

The number of shift blocks is `n-4`, which is zero for `n=4`; the phase length is therefore exactly `5+3(n-4)+3=3n-4`. I separately replayed the explicitly supplied phases for `n=2` and `n=3`.

Finally, the first phase probes only its tracked parity cohort. If the phase has odd length, the untouched cohort is in the desired starting parity for an identical second phase. If it has even length, horizontal reflection exchanges parities because `n` is even. The final first-phase round still causes a move for trajectories in the untouched cohort, so this parity accounting includes the correct boundary between phases. Capture in the final second-phase round occurs before movement. There is no extra terminal turn.

## 7. Boundaries and recommended wording

The evidence supports calling this an independently audited **ordinary mathematical proof** of the two-probe three-row formula for all `n>=2`. It does not establish a full classification for other probe budgets, prove the result is new to the literature, or constitute a Lean proof. The Hamilton-cycle lemma and directed critical-set lemma are natural separate formalization targets.

The `n=1` board is the three-vertex path and has capture time two with two probes; it must remain outside the displayed `6n-8` formula, exactly as the draft states.

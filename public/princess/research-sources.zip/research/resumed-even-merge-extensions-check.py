"""Finite counterattack on the two algebraic merger extensions.
No new universal claim is inferred from this finite test.
"""
import importlib.util,json,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from resumed_even_construction_formula_profile import allowed as base_allowed,F
def G(i,j,s): return max(F(2-j,d,s-2+i+d) for d in range(3-i))
spec=importlib.util.spec_from_file_location('endpoints',Path(__file__).with_name('resumed-even-merge-endpoints.py'))
e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
def filtered(h,r,q,i,t,j):
 return base_allowed(h,r,q,i,t,j) and(t-q!=r or q<=F(i,j,r) or h-t<=G(i,j,r))
def triggercheck(r,h):
 C=r*(r-1);triples={};count=0
 for q in range(1,h+1):
  for s in range(r+1):
   t=q+s
   if t>h:continue
   vals=[]
   for i in range(3):
    for j in range(3):
     if e.valid(h,q,i) and e.valid(h,t,j) and base_allowed(h,r,q,i,t,j): vals.append((i,j))
   triples[q,s]=vals
 for(q,s),vals in triples.items():
  q2=h+C-q;s2=r-s
  for i,j in vals:
   for i2,j2 in triples.get((q2,s2),[]):
    if max(0,i+i2-2)!=0 or max(0,j+j2-2)!=1:continue
    assert(q==h and s==0 and i==j==2) or(q2==h and s2==0 and i2==j2==2),(r,h,q,s,i,j,q2,s2,i2,j2)
    count+=1
 return dict(r=r,h=h,trigger_pairs=count)
start=time.process_time()
e.allowed=filtered
rows=[]
for h in range(2,6):
 for k in range(1,h):rows.append(e.audit(1,h,k))
for k in(1,2,3,7):rows.append(e.audit(2,8,k))
triggers=[triggercheck(r,h) for r in range(2,11) for h in sorted({2*r*r,(2*r+1)*(r+1),(2*r+1)*(r+3)})]
result=dict(status='PASS',scope='Finite tests of critical-filter closure and identity formation of the pronic trigger. The physical flag rule is separately proved only for odd width.',critical_filter='Retain exactly F/G profiles at critical surplus; hence a strongest such filter.',critical_endpoint_rows=rows,trigger_rows=triggers,CPU_seconds=time.process_time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in('critical_endpoint_rows','trigger_rows')},indent=2))
print('critical cases',len(rows),'constructed pairs',sum(r['constructed_edge_pairs']for r in rows),'trigger cases',len(triggers),'trigger pairs',sum(r['trigger_pairs']for r in triggers))

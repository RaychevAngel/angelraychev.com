# Independent review of symbolic interior transitions

13 September 2026. Root review of `maturation-even-transitions.md`,
Sections 1, 4, 6, and 7. **PASS as ordinary mathematics.** No claim of a
complete Lean formalization is made. Sections 2 and 3 are intermediate
versions superseded by the stated stronger sections.

The review checked the following points separately from the author's
finite experiments.

1. Maximal erosion is a physical pyramid even in an empty bottom fiber
   and at the top cap. The sole possible additional room is the actual
   top room: its downward and transverse neighbors give exactly the
   stated condition. At length one that test still works. The one-day
   optimum allows arbitrary survivors, because all of them must lie in
   the maximal erosion. Equality of the desired endpoint requires the
   extra neighborhood equality; containment alone is not substituted.

2. For a Hamiltonian cross-section, deleting transverse edges reduces
   the neighborhood. Embedding a finite support in a sufficiently tall
   auxiliary path rectangle removes the far profile branch. This proves
   the claimed half-strip surplus for arbitrary supports. During a
   guarded physical block, the free reachable pyramid bounds every
   competing support away from the far cap. Nonnegative expansion then
   bounds every survivor below by the initial size minus ALL prescribed
   quotas. Thus the lower-bound plateau argument applies to arbitrary
   strategies. The alternating fiber-parity corrections cancel exactly
   in the sum, giving the integer flip count F.

3. Legal descent is valid on every connected bipartite cross-section,
   not only a path: a highest vertex above its target cannot have a
   higher neighbor already at target. Each descent flip removes an
   actual room under the physical margins. Grouping a flip word by a
   quota word is valid because uniform movement commutes with each
   local-maximum test. The endpoint is equal to the specified pyramid.

4. For the duration-independent margin, completed mean heights are a
   linear interpolation of endpoint means plus a remainder in [0,2/A).
   The graph diameter bounds the range of each intermediate height
   function. Within an inspection group, each coordinate lies between
   its value before that group and its value after that group, the
   latter being one below the next completed height. The proposed lower
   and upper bounds therefore hold throughout, not only at day ends.
   The endpoint mean interval [diam(Q)+2,n-diam(Q)-3] keeps all heights
   in [1,n-2]. Thus every grouped flip and movement is physical for an
   arbitrarily long block. If t=0, the endpoint inequalities force equal
   endpoints and the empty block handles that case separately.

5. The shortest virtual duration is the least integer of the endpoint
   parity above the three displayed lower bounds. Coordinate bounds
   imply F>=0; endpoint parities imply F is integral. The denominator
   2m-A is positive. This is an upper construction for arbitrary
   physical competitors unless the plateau lower bound also applies.
   In particular, the single-block cardinality guard must NOT be
   applied with an arbitrarily long duration.

6. The finite-port consequence uses the earlier independently reviewed
   canonical-checkpoint theorem, in its even-area scope. Each bounded
   interior edge satisfies the guarded lower theorem separately. These
   coordinate inequalities compose and their flip charges telescope,
   so every concatenation is bounded below by the symbolic duration.
   Its new realization is supplied by the duration-independent margin,
   and need not stay inside the artificial interior interval. These two
   arguments have distinct roles and neither assumes a daily normal
   form for an unknown physical optimum.

7. The first and last R counter levels retain every possible contact
   with a boundary vertex because the old displacement bound is <R.
   Every removed path segment has retained endpoints and one unchanged
   proper cohort, orientation, and mate status. The new graph keeps
   boundary edges, remote-end quota gadgets, and repeated boundary
   visits. Replacing each segment never raises the weight, and every
   new edge expands to a physical shared-budget strategy. Both
   inequalities between the new shortest path and T therefore hold.

8. The construction for n>=n_0=10R has disjoint port regions and enough
   height margin. Smaller lengths must remain in the finite exception
   preprocessing, as in the antecedent theorem. No assertion that the
   boundary tables are implemented or small is justified. The new
   theorem should explicitly retain those qualifications. Its exact
   arithmetic evaluation after preprocessing takes a fixed number of
   operations in the length; integer bit cost and strategy output cost
   are still additional. This is not a new asymptotic claim over a
   fully precomputed eventual-period law.

The substantial conclusion is that all unbounded interior transition
optimization can be replaced by endpoint inequalities and a balanced
physical construction. The remaining finite boundary graph is not
evaluated by this theorem.

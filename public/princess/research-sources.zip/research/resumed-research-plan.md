# Resumed research, 12 September 2026

The user reports a usage reset and authorizes resumption until50% remains,
or earlier if the full mathematical problem is solved. The account tool
confirmed0% used at the start. The previous61-page/39-module publication
checkpoint remains the verified baseline. No Princess arXiv submission has
been made. This run must consolidate manuscript, site, artifacts and proof
boundaries before reporting at the requested threshold.

## Independent lanes

1. Root: general-box feasibility and isoperimetric geometry; inspect corner
   orders, profile bottlenecks, and relevant primary literature.
2. Frontier agent: even/mixed-side normal forms retaining sufficient shape
   or history information; attack arbitrary-budget-word sufficiency.
3. Recurrence agent: exact formulas or finite-state length recurrences,
   starting with the remaining five-row budgets.
4. Exact/formal agent:4×4×4 all-budget exact table, physical schedules and
   lower certificates; seek reusable structural explanations.

## Initial conjecture and evidence

A possible replacement for a single optimal order is a finite family of
corner-based weight-lexicographic orders, allowing all coordinate orders
and coordinate reflections. The minimum neighborhood size among their
k-prefixes agrees with the exact compressed profile at everyk on4×4,
6×6,3×3×4,3×4×4,4×4×4,5×5×5 and3×3×3×3. These are computations,
not a universal theorem. The current script extends the attack using the
proved cylinder profile transfer theorem as an independent exact oracle.

On4×4×4 the exact maximum surplus is7 in both colors; on3×4×4 it is6.
The resulting budget lower bounds are8 and7, respectively. The exact
agent reports a one-cohort construction at8 for4×4×4 and is verifying
the complete joint game. Final acceptance awaits its receipts and review.

Matching one-step isoperimetry does not prove compatible daily transitions.
The4×4 corner-degree contradiction rules out any universal pair of nested
minimizing orders on a rectangle with an even side and both sides>=3.
This failed simplification remains part of the research record.

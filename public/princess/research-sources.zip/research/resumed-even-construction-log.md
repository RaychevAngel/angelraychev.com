# Resumed even-width construction work

13 September 2026. Research explicitly resumed by user. Bounded lane:
full-initial-uncertainty rectangles of width `w=2r>=6`, length `n>=w`,
constant feasible budget `r+1<=k<=r(r-1)`. No claim about arbitrary partial
states or varying quotas is required.

## Existing baseline

The exact static profile supplies a scalar solo lower clock, but its
successive optimizers need not compose physically. The generic cyclic
height sweep is a valid upper strategy. Existing high-budget proof obtains
an exact formula above the root-occupancy threshold `r(r-1)`.

## Independent review of root's saturated-root upper construction

Root proposed enlarging each backward survivor ideal R to include every
bottom root before completing its prescribed envelope size. This adds at
most r cells, hence fits any enlargement by k>=r cells. Bottom roots are
minimal in the pyramid poset, so the union remains an ideal. The existing
clipped erosion then loses exactly r cells, without a size threshold.
The old backward construction's size identities remain unchanged.

For the residual budget range, the remainder s satisfies
`s<k-r<=r(r-2)`, so `ceil(sqrt(s))<=r-1`; its small-corner pyramid and
neighborhood fit `n>=2r`. Reflection across the even-width axis supplies
either physical color. This establishes the physical upper construction,
not the matching lower formula. No defect found in this independent proof
inspection. Root owns the full statement and its wider audit.

## Solo-clock experiment

`src/resumed_even_construction_prefix.py` tests the minimum full-color solo
time among reflected, axis-permuted weightlex prefix survivors, against the
existing scalar lower clock. Every generated witness is replayed using
literal grid sets. A restricted solo time matching the scalar bound is an
exact solo result for that finite instance. A gap only disproves equality
within this restricted strategy family; it is not an unrestricted lower
bound. Constant budget and full initial color are maintained throughout.

The search considers only survivors of size `max(|A|-k,0)`: every larger
prefix in the same order contains that prefix, so its successor is
dominated. This reduction is exact for the restricted prefix family.

The first scan covered 1,463 cases: widths 6,8,10,12,14,16, eleven
lengths starting at the width, and every budget in the residual range.
The hypothesis that prefix solo time exceeds the scalar lower clock by at
most one was refuted at 8x8,k=5 (20 versus 18). Its gap is three at
16x16,k=9. A separate small scan of 48 cases at widths18,20,24,32,48,64
found a restricted gap of22 at64x64,k=33 (392 versus370). These larger
restricted gaps are not lower bounds for arbitrary strategies and do not
prove an unbounded gap.

## Full-board, constant-budget 8x8 obstruction: independently checked

`src/resumed_even_construction_square_audit.py` independently generates the
424 pyramids of each physical color as height walks, builds neighborhoods
using literal coordinate sets, and computes a reverse Bellman rank. All846
nonempty-state Bellman equations were checked. The full-color solo optimum
is20. This agrees with the separate existing predecessor-ideal solver.
The unrestricted interpretation uses the already accepted ordinary square
strategy-compression theorem, not an unproved rectangle normal form.

The scalar clock is18. Its counts after successive inspections and moves
start `32,29,27,25,23`; the actual minimum possible counts start
`32,29,27,25,24`. At day3 the unique minimum compressed belief has virtual
heights `(3,4,3,4,5,6,7,6)`. The unique20-room pyramid whose neighborhood
has23 rooms has heights `(7,6,5,4,3,2,1,0)` and contains four rooms missing
from that belief. Thus the scalar optimizer tries to switch to an
incompatible corner shape already on day4. The later extra delay is not
solely a central-day issue.

The existing joint solver, fed the independently generated height states,
then gave full-board optimum40 after58,360 states and14,438,006
transitions (2.7 seconds), with literal physical replay of the40-day
witness. The old scalar lower bound is36; serial solo gives40. This
finite result refutes a universal `2*tau_rel` upper and the proposed
solo-within-one simplification. It is an ordinary compression theorem plus
an exhaustive finite certificate, not a physical-game Lean proof.

Receipt: `research/resumed-even-construction-square-8x8-k5.json`.

## Ammunition potentials and the boundary correction

For daily cap k, let F(A) be the minimum total useful inspections of a
successful solo strategy from A, with no time constraint. On every
admissible transition `A -> B` costing p<=k,

    F(A) <= p + F(B).

Therefore two initial cohorts require at least `F(V0)+F(V1)` total
inspections under any interleaving. On an even-width rectangle the two
values coincide by reflection, giving `T>=ceil(2F(full)/k)`.
This is an exact physical definition; compressed evaluation is justified
here only on the square by the accepted compression theorem.

`src/resumed_even_construction_ammunition.py` computed F on the8x8,k5
pyramid graph and checked all25,064 transition inequalities. It gives
F(full)=96, whereas the size-only scalar relaxation gives90. Thus it
improves the full lower bound from36 to39. The actual answer40 still
requires an additional compatibility argument.

The minimum-ammunition solo witness takes20days with useful costs
`4,4`, then seventeen `5`s, then `3`. Initial full-budget greed is not
necessary for ammunition optimality. For every pyramid of each size
15 through23, F is exactly `5*size-42`. The corner corrections cannot be
read from size, root count, top-fiber count, and height span alone:

- Heights `(2,3,4,5,6,5,6,7)` have F=78.
- Heights `(2,3,4,5,6,7,6,5)` have F=83.

Both have physical phase0, size25, four occupied bottom roots, three top
fibers, and height span5. The notch's location matters. This motivates a
small boundary-type description attached to an affine middle potential;
it does not yet prove such a description is sufficient uniformly.

The same finite potential computation gives F=44 on6x6,k4 and F=160
on10x10,k6, implying lower bounds22 and54 respectively. Both match the
known scalar/solo upper at those finite inputs.

Receipts: `research/resumed-even-construction-ammunition-8x8-k5.json` and
`research/resumed-even-construction-ammunition-minimum.json`.

## Minimum-budget unification target, still conjectural

Root's current target is a uniform statement
`T_(r+1)(2r,n)=2rn-C_r`, possibly with a necessary parity correction,
for all `n>=2r`. An implicit width-only clock would be an intermediate
advance, not completion of the user's O(1) numerical goal.

Restricted prefix solo data for the eleven tested lengths gives
`3n-7,4n-12,5n-23` at widths6,8,10. Width12's restricted prefix clock
has an apparent parity correction (`6n-35` even, `6n-36` odd), but on
12x12 a general pyramid strategy captures the solo cohort in36days,
matching the scalar lower clock, whereas the prefix restriction needs37.
Hence the apparent parity term is not an established property of the
physical game. A sufficient family must allow more than corner weightlex
prefixes, even from full initial uncertainty at minimum budget.

No unbounded exact time theorem has been proved in this lane yet. The
root-saturated construction supplies an independently reviewed unbounded
upper improvement; the new finite examples identify the missing lower
invariant and prevent an incorrect scalar-exactness claim.

## Full-start corner-count relaxation and the new geometric inequality

The inability of a feature to recover every partial-state optimum need not
prevent it from proving the full-start bound. Merging all same-(size,
physical-corner-presence) pyramids into abstract states, and allowing every
physical edge out of any member, preserves the full-start ammunition value
96 and the joint40-day lower bound on8x8,k5. Corner distances are not needed.
Forgetting phase and retaining only the number of current-color corners,
0,1,2, reduces this to57 states and still gives40. This is a lower
relaxation, not an assertion that all same-feature shapes are interchangeable
in the physical game.

At12x12,k7 the same count abstraction gives72, matching a physically
replayed72-day schedule made from a36-day solo search and its reversal.
There are133 feature states, and the abstraction examines742,029 joint
edges. The36-day optimal solo search's smallest possible pre-final support
has7 rooms, whereas the scalar clock's final residual is2. The apparent
71-day scalar possibility therefore cannot be justified by its residual.

Exact containment can be relaxed further: retain only

    |R|<=|A|,  cost=|A|-|R|<=k,
    corners(R)<=corners(A)<=corners(R)+cost,

and the conditional neighborhood profile of R. Doing so adds40 abstract
edges on8x8 and173 on12x12, yet still gives40 and72. This identifies
conditional isoperimetric inequalities as a useful target, without a
general transition or partial-state normal-form theorem.

Source and receipts:
`src/resumed_even_construction_corner_count.py`,
`src/resumed_even_construction_profile_relaxation.py`,
`research/resumed-even-construction-corner-count-8x8-k5.json`,
`research/resumed-even-construction-corner-count-12x12-k7.json`,
and the corresponding `profile-relaxation` receipts.

The teammate `split_manuscripts` then derived an unrestricted necessary
inequality, whose proof is in `research/resumed-even-corner-profile.md`
and is undergoing root's independent review. For surplus s<r, source
corner count i, and outgoing corner count j, its small-side capacity is

    F_ij(s) = -infinity if s<i+2j;
              i+2j-2+(s-i-2j+2)(s-i-2j+1) if j>0;
              i-1+(s-i+1)^2 if j=0<i;
              max(s(s-1)/2,s(s-2)) if i=j=0.

For |R|=q, h=wn/2 and |N(R)|=q+s, either

    q <= F_ij(s)

or

    h-q-s <= max_(0<=d<=2-i) F_(2-j),d(s-2+i+d).

The second branch accounts for slack between the complement and its
neighborhood. Merely complementing corner labels without this slack would
be incorrect.

I independently checked the candidate inequality on all63 subcritical
pyramid profiles on8x8 and276 on12x12. More substantively, a formula-only
abstract graph using this inequality, the old unconditional static profile,
and the trivial cardinality/corner constraints above recovers the same
40 and72 lower bounds. It admits arbitrary possible source features; it
does not enumerate pyramids or use square compression. The12x12 case has
ammunition potential252, so `2*252/7=72` proves its lower directly.

An initial implementation pruned larger target sizes sharing a corner
count; that requires an additional monotonicity argument and was removed.
The final rerun retains every formula-admitted target and gives40 and72
unchanged. This is recorded as a failed implementation shortcut, not as
part of the proof.

For8x8 the same formula graph proves that after19 inspection-and-move
steps every full-board belief has at least35 rooms. Its lowest reachable
feature is one full32-room cohort and one3-room cohort. A forward and
reversed19-day prefix of a purported39-day search therefore overlap in
at least6 rooms at the central day, exceeding budget5. This is a shorter
conceptual lower certificate than the40-day joint optimizer. The formula's
ordinary unrestricted proof must be accepted before promoting these
formula-only finite lower bounds into theorem claims.

Sources and receipts:
`src/resumed_even_construction_formula_profile.py`,
`research/resumed-even-construction-formula-profile-8x8-k5.json`,
`research/resumed-even-construction-formula-profile-12x12-k7.json`.
The8x8 receipt includes the93-state ammunition potential and all4,683
checked transition inequalities. No Lean development has been changed.

## Toward a corrected three-state clock

The full-start domination hypothesis compares the formula corner model
with itself: before its solo capture time, does the minimum total size of
the two cohorts equal h plus the minimum size of one fully searched
cohort? This holds at every pre-capture day in the bounded checks
6x6,k4 and5;8x8,k5 and6;10x10,k6 and7;12x12,k7. The code completes
every BFS layer before comparing minima. These are full-start checks,
not an arbitrary-partial-state seriality theorem and not physical
attainment of the relaxed solo clock.

`src/resumed_even_construction_full_start_seriality.py` and
`research/resumed-even-construction-full-start-seriality.json` record the
checks. Because the full initial state has a zero-inspection self-loop,
all states first reached earlier are also reachable at the comparison
time; cumulative first-arrival minima therefore give exact layer minima.

A local algebraic merger with source guard `merged size>k` is a possible
proof route. Add deficits and cap missing corners, defining

    M((a,c),(b,d))=(a+b-h,max(0,c+d-2)).

Every1,975,422 guarded pair of8x8,k5 formula edges admits the exact
merged target at their combined quota. The same merger is false at small
partial states without the guard. A three-state pre-capture induction
would not need those false cases. The proof reduction and a new closed
form for the dual capacity are in
`research/resumed-even-construction-merge-algebra.md`; the teammate is
independently attacking the finite indexed polynomial inequalities and
feature-validity endpoints. No uniform merger theorem is claimed yet.

## Accepted merger and a narrow physical-attainment target

The candidate merger above now has a complete ordinary algebraic proof
in `research/resumed-even-merge-proof.md`, independently reviewed by root.
It implies full-start pre-capture joint domination by the corrected solo
corner model. This resolves the joint-composition obstacle for that
necessary model. It does not prove physical attainment or a fixed-size
formula for its clock.

A new ordinary upper-containment lemma and bottom-boundary credit have
also been independently reviewed and accepted; see
`research/resumed-even-construction-transport.md` and its concise TeX.
They permit arbitrary canonical endpoint pyramids without boundary
margins, use a deterministic legal local-max flip word, and require
F_t<=kt+z(B) for t>=1. There is no credit at t=0. A bounded numerical
lemma evaluates F_t for unions of two bottom-corner prefixes using an
absolute fixed number of affine intervals, rather than a width-length
sum. This evaluates a connecting criterion, not the full capture clock.

The next physical target is a single splice: left-prefix entrance,
virtual transport, right-prefix exit. It succeeds on12x12,k7 in36 solo
moves and14x14,k8 in47, matching the accepted necessary solo model.
The12x12 instance had defeated every single fixed prefix. The new
script tests only splice indices and deterministic prefix clocks,
without any physical pyramid-state enumeration. All displayed winning
schedules and their full-board palindromes were replayed in literal
coordinates. Receipts are
`research/resumed-even-construction-splice-12x12-k7.json` and
`research/resumed-even-construction-splice-14x14-k8.json`.

The general existence and direct selection of suitable splice indices
remain open. Testing those finite instances is not a uniform attainment
proof. This is deliberately a full-start construction target, rather
than a requirement to realize every abstract partial-state transition.

## A decisive larger-instance falsifier:24x24 with budget13

A requested bounded check refutes the conjecture that a fixed anchored
prefix clock is always within one day of the corrected necessary solo
clock. On24x24,k13 the necessary clock is102 and both fixed-anchor
phase clocks take104. Adding the subsequently accepted critical-surplus
corner filter leaves the necessary clock102, with minimum final support9.
Checks on16x16,k9 and32x32,k17 gave gaps1 and0 respectively; no broad
parameter catalogue was launched.

The exact all-target necessary clock is now evaluated by integer bitsets
in `src/resumed_even_construction_formula_clock.py`. All targets with
surplus at least r (or r+1 under the critical filter) form a complete
size tail, and the remaining finitely indexed corner-profile targets
are included individually. No same-corner size pruning is used.
The selected checks took roughly0.12s in total. Receipts are
`research/resumed-even-construction-corrected-prefix-gap.json` and
`research/resumed-even-construction-critical-clock.json`.

Every single-splice candidate from the deterministic left entrance to
right exit failed at the102-day clock. Its best quota slack is minus2.
Next, a direct search of all unions of the two fixed bottom-corner
prefixes used18,791 shapes per phase,27,028 visited beliefs and353,275
exact-quota contour edges. It still needs104 solo days. It found a
terminal support of size2, giving a physically replayed207-day full
strategy by merging the two reflected final inspections. This search
does not enumerate all pyramids. Its receipt is
`research/resumed-even-construction-direct-two-prefixes-24x24-k13.json`.

The next family also permits intersections of those two prefixes.
This includes the missing single-peak fronts that clear both top corners.
Only survivors are restricted: every literal neighborhood is retained,
even when it leaves the survivor family. This larger search has36,990
survivors per color and60,865 visited beliefs;9,126,696 containment
checks and837,300 legal edges took1.94s. It again gives104 solo days,
terminal size2 and full upper207. See
`src/resumed_even_construction_union_intersection.py` and
`research/resumed-even-construction-union-intersection-24x24-k13.json`.

Exact-quota completeness within these families is justified as follows.
From any larger union survivor, decrease one prefix index and then the
other until empty; each deletion changes its size by at most one.
For an intersection, decrease either index to zero. Hence a permitted
survivor of every smaller cardinality is contained in the larger one,
and its physical neighborhood is contained in that of the larger one.
Using the full useful quota therefore loses no strategy in this family.
This does not prove an unrestricted physical normal form.

The larger family agrees with the necessary minimum through day27.
The first discrepancy is day28: the model permits178 to176, while the
family reaches177. The model's proposed survivor size165 and surplus11
force corner counts(i,j)=(2,1): its dual missing set has112 rooms,
one own-colored corner and no outgoing corners, satisfying112<=11^2.
Thus the bottleneck is near the co-small-to-interior handoff, when a
large cleared region must fit inside one favorable corner profile.
It is not simply the tiny initial-corner phase choice.

These computations refute the proposed small upper families and the
within-one prefix conjecture. They do not refute physical attainment
of102 solo days. The next useful proof target is the relevant shape
compatibility or a richer direct handoff; indiscriminate enlargement
of the catalogue is not an obligation.

## Final bounded breakthrough: near-square rigidity and the24x24 bracket

The actual phase1 anchored123-room prefix has unrestricted optimal solo
capture time29. Its direct prefix clock supplies the upper. A bounded
on-demand search of ALL downward-pyramid survivors excludes28 days;
only146 failed states and22,723 full-quota survivors are needed. An
independent verifier uses local-maximum deletion closure, literal room
neighborhoods, and separately reconstructed corner-potential inequalities.
It passes all22,723 branches,346,374 static profile edges and22,465
potential inequalities. The fixed-state clause of the existing square
strategy-compression theorem lifts this lower to arbitrary physical
strategies from that fixed initial prefix.

The partial-prefix finding led to a uniform geometric lemma. In a genuine
quadrant, surplus<=s and size>s(s-1) force all occupied diagonals to be
0,2,...,2s-2. The existing punctured-quadrant proof gives size<=L*delta
and L<=delta<=s; the near-square threshold forces L=delta=s. Every
occupied diagonal accounts for exactly one surplus, every empty one
for zero, and an initial or internal gap is impossible. Diagonal
compression preserves the original diagonal counts, so localization
holds for the ORIGINAL support, not merely its compressed shape.
Root independently reviewed and accepted this proof.

On24x24,k13, a hypothetical176-room belief after28 steps has a112-room
complement U. Reversing the inspections would capture N(U) in28 days.
The verified lower potential rules out |N(U)|>=124, while the static
profile forces |N(U)|>=123. Thus surplus(U)=11. The finite corner
profile forces the small branch, one current corner and no outgoing
corners. Its genuine-quadrant decomposition has only one nonempty
piece, since two nonempty pieces have total capacity at most
(s-1)^2+1<=s(s-1). The near-square lemma localizes U in a121-room
corner triangle. After square compression, there are exactly eight
112-room pyramids in that triangle; all their neighborhoods have123
rooms. All eight neighborhoods independently fail the28-day deadline:
one uses the146-state certificate and the other seven fail after their
first transition. Strategy compression preserves containment in the
fixed triangle and turns N(U) into precisely one of those eight
neighborhoods. Hence every actual solo belief after28 steps has at
least177 rooms. Applying that barrier to the necessary solo model
raises its clock to103, with final minimum9.

This physical SOLO barrier was not silently imposed on the synthetic
joint merger. A separate exact equality graph supplies the missing
bridge. Any joint history reaching total464 and merged corner count1
at day28 maps to a shortest28-step model path from(288,2) to(176,1).
Enumerating all component pairs above these shortest-path layers forces
the UNIQUE final pair((176,1),(288,2)). Thus the solo physical barrier
also excludes the joint equality. It does not matter whether the
cohort ending full had been inspected earlier.

The independent equality verifier rebuilds weighted edges from separate
budget-indexed bitset relations, then expands component successors
rather than testing the original search's candidate joint targets.
It checks380,358 weighted model edges and66,295 equality-pair
transitions. The filtered BASE/subcritical model still has clock103
and final minimum9. The guarded merger therefore gives at least297
possible rooms after102 full-board steps. Forward and reversed102-day
cuts in a205-day search would overlap in at least18 rooms, exceeding
the13-room central budget. This proves the new full lower206.
The previously replayed reflected-center construction gives upper207:

    206 <= T_13(24,24) <= 207.

Root independently reviewed the finite verifier and this complete logical
bridge and accepted the206 lower. The full value206 versus207 remains
open. The solo interval is103 versus104. No new Lean theorem is claimed.

Authoritative proof section:
`paper/sections/resumed-near-square-localization.tex`, with labels
`thm:near-square-localization`, `prop:twenty-four-boundary-history`,
and `cor:twenty-four-full-bracket`.

Authoritative receipts and independent verifiers:
- `research/resumed-even-construction-partial-prefix123.json` and
  `research/resumed-even-construction-partial-prefix123-verification.json`;
  `src/resumed_even_construction_partial_pyramid.py` and
  `src/resumed_even_construction_partial_verify.py`.
- `research/resumed-even-construction-near-square112.json`,
  `research/resumed-even-construction-near-square112-search.json`, and
  `research/resumed-even-construction-near-square112-verification.json`.
- `research/resumed-even-construction-joint-equality28.json` and
  `research/resumed-even-construction-joint-equality28-verification.json`;
  `src/resumed_even_construction_joint_equality.py` and
  `src/resumed_even_construction_joint_equality_verify.py`.
- Upper207: `research/resumed-even-construction-union-intersection-24x24-k13.json`
  and `src/resumed_even_construction_union_intersection.py`.

The weight-only attempt at equality was insufficient: all113 split-feature
pairs fit the total364-shot bound when time is ignored. Only the
shortest-path/time-sensitive equality graph proved concentration. This
failed route is preserved in
`research/resumed-even-construction-day28-ammunition-pairs.json`.

All new mathematical searches are now halted for the requested checkpoint.

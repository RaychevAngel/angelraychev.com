# Merger for the enriched erosion-corner relaxation

13 September 2026. Ordinary algebraic proof independently reviewed and
accepted by root, including full reduced-surplus closure. It is a theorem
about a precisely weakened necessary
model, not physical attainment or a closed numerical capture-time answer.
The weakening preserves every physical state/transition; finite tests
below suggest that it preserves the full-start lower clocks of interest.

## Model and the single deliberate weakening

Use the odd-width/even-length geometric rules in
`resumed-erosion-corner-profile.md`, with b>=2, h>=2b^2 and 1<=k<h.
Their actual physical scope is w=2b+1, even n>=w, h=wn/2.
The model feature is (a,c,e), with c,e in {0,1,2}, and

    0<=a<=h-4+c+e,     a=0 implies c=e=0.

DROP ONLY the lower bound c+2e<=a for positive states and i+2u<=q for
positive survivors. These are valid physical bounds, but their preservation
is unnecessary for a lower relaxation and their raw mergers can fail them.
Retain the upper bound, which in particular forces both corner counts to
be two at a full state.

A cost p<=k action chooses q=a-p. If q=0 the target is the empty feature.
If q>0 choose survivor features i,u obeying the upper bound and

    i<=c, u<=e, (c-i)+(e-u)<=p.

Choose target (t,j,v), t>=q, with u<=j, i<=v. Retain the unconditional
size profile. At any original surplus s=t-q, put

    delta=v-i, x=q+delta, sigma=s-delta.

The profile alternative is

    x<=P(v,u,j;sigma) OR h-t<=F_(2-j,2-v)(sigma),

or the critical exception sigma=b, v=2,j=0, whenever sigma<=b.
Require sigma>=0 at every surplus; if sigma>b no extra profile condition
is imposed. In particular closure remains active when original s>b but
its reduced surplus is at most b. This is the strengthened current model,
not the earlier version filtering only at original s<=b.
The P notation follows root's note (implementation low(i,j,u,s) permutes
its second and third arguments).

Retain also maximal-survivor i>=max(0,c+v-2), the dual-pronic condition

    q=h-b^2, s=b, j=2  implies (i,u,v)=(1,2,1),

and the one-step triangle flag, as discussed in section 6 below.
The finite source implementation is
`src/resumed_odd_even_erosion_corners.py`; the two exact source substitutions
implementing this stated weakening are logged in
`resumed-erosion-merger-relaxed-check.py`. No canonical source was modified.

Define

    M((a,c,e),(a',c',e'))
       =(a+a'-h, (c+c'-2)_+, (e+e'-2)_+).

**Theorem.** Before a solo clearing day, i.e. when the merged
source size is greater than k, every pair of transitions of total cost
p<=k has an exact-cost solo transition to its exact merged target in this
weakened model. The triangle flag is formed by the merged history's own
trigger, with the usual component-flag/other-full invariant.

## 1. Geometric premises independently checked

The disjoint physical corner rooms and opposite-corner neighbor pairs
justify the upper and coupled deletion bounds. The erosion identities
u<=j and i<=v are immediate from N(S). On the high side, E(B) gives the
exact observed corner count 2-v for N(V_other minus B); its v-i missing
corners charge the slack. The closed support adds only source corners
whose two neighbors were already present, so it keeps B and u unchanged.
The maximal survivor A intersect E(B) preserves B and may lower the useful
cost, so all p<=k must remain allowed. Root and the odd-width agent have
separately checked the strengthened critical case and the dual-pronic
geometric identity. This algebraic note does not replace those proofs.

## 2. Capacity algebra

All capacities below are extended by minus infinity outside their stated
feasibility domains. Let C2(s)=max(s(s-1)/2,s(s-2)) and H be the one-neighbor
capacity with H(0)=0. P is nondecreasing in surplus and, at fixed other
arguments, nondecreasing in the two-neighbor count u.

### A capped-sum inequality for F

For finite inputs,

    F_(min(2,a+a'),min(2,d+d'))(s+t)
       >=F_(a,d)(s)+F_(a',d')(t).                 (H)

This can be read directly from the quadrant allocation proof. Temporarily
allow arbitrary nonnegative required-piece counts in its same formula.
Combining the allocations for the two terms produces a feasible allocation
with a+a' even required pieces and d+d' odd required pieces; all optional
pieces can still be combined by convexity and superadditivity of C2.
The extended F is therefore at least the sum. Truncating a count greater
than two to two at fixed surplus can only increase this maximum: the
removed mandatory piece frees one or two surplus units to a remaining
piece of the same type, whose convex marginal gain is at least its removed
area. Such a type remains present after truncation. This proves (H).
Equivalently it follows by inserting the three polynomial branches of F.

### Three elementary P changes

For feasible P(i,u,j;s), one has

    P((i-1)_+,u,j;s+1) >= P(i,u,j;s)-1;            (I)
    P(i,(u-1)_+,j;s+1) >= P(i,u,j;s)-1.            (E)

Zero indices use monotonicity. For (I), all nonzero-u cases and the i=2
zero-u case increase their quadratic. At i=1,u=0,j>0, write z=s-1-2j;
the new H(z+4) term is at least (z+4)(z+1)+1, giving a nonnegative
increase. At i=1,j=u=0 use C2(s+1)>=s^2-1.
For (E), u=2 keeps the pronic branch, while u=1 to zero with i>0 again
increases the quadratic. At i=0,u=1 use
H(z+3)>=(z+3)z+1, giving a loss of at most one. These changes preserve
the capacity domains.

Deleting an outgoing corner is more generous: when j>0,

    P(i,0,j-1;s+1) >= F_(i,j)(s) >= P(i,u,j;s).    (J)

For j=1,i=0, use C2(s+1)>=s^2-1>=s(s-1). For j=1,i>0 the new square
beats the old pronic quadratic. For j=2,i=0 use
H(s+1)>=s^2-s-1>=s^2-5s+8=F02(s), since s>=4. For j=2,i>0, writing
z=s-i>=4, the new value is i+z^2 and the old one is
 i+z^2-5z+8. When j=0, u=0 and the corresponding operation is just
surplus monotonicity. Thus one outgoing-corner deletion can safely reset
ALL two-neighbor counts to zero.

One small exceptional comparison will also be useful: for i>0,

    P(i-1,0,j;s+2) >= F_(i,j)(s).                 (D)

For i=1,j=0, C2(s+2)>=s(s+2)>=s^2. For i=1,j>0 write z=s-1-2j;
H(z+5)>=(z+5)(z+2)+1 gives the comparison. For i=2 the new even-piece
quadratic after the three-unit increase in its free variable dominates
the old F branch. These are finite polynomial comparisons, including
all endpoints of their domains.

### The mixed inequality

Let A,B,C be in {0,1,2} with C>=A. Suppose

    F_(A,B)(t) >= max(0,B+C-t).

Then, whenever the right side is positive,

    P((v-B)_+,(u-C)_+,(j-A)_+;s+t)
       >=P(v,u,j;s)-max(t,B+C).                  (L)

If A>=1, apply (J) A times (a zero remaining outgoing count uses
monotonicity), resetting u to zero, and (I) B times. This needs A+B
surplus units and loses at most B area. F feasibility gives t>=A+2B,
so there is sufficient surplus. Monotonicity in u permits the desired
possibly positive final (u-C)_+ instead of zero.

If A=0 and t>=B+C, apply (I) B times and (E) C times. Their total loss
is at most B+C<=t. If t<B+C, feasibility t>=2B and the displayed lower
bound on F leave exactly one case:

    A=0, B=1, C=2, t=2.

For B=0 the alternatives t=0<C or t=1<C=2 fail because F00(0)=F00(1)=0.
For B=2, t>=4>=B+C. For B=1 the single listed case remains.
In that case, if v=0, two uses of (E) suffice and lose at most two,
less than the permitted loss three. If v>0, (D) applies. This proves (L).

A finite transcription check passed (H) on 26,244 input pairs and (L) on
87,164 applicable parameter choices with s,t<=20, in 0.052 CPU seconds.
Receipt: `resumed-erosion-merger-algebra-check.json`. This is only a
counterattack on the displayed universal algebra, not its proof.

## 3. Closure commutes with merger up to favorable slack

For two component actions write their costs p_l, survivors(q_l,i_l,u_l),
targets(t_l,j_l,v_l), and s_l=t_l-q_l. Put

    Q=q1+q2-h>0, T=t1+t2-h,
    I=(i1+i2-2)_+, U=(u1+u2-2)_+,
    J=(j1+j2-2)_+, V=(v1+v2-2)_+.

Let delta_l=v_l-i_l, x_l=q_l+delta_l, sigma_l=s_l-delta_l.
The merged closure has delta=V-I. Since v_l>=i_l,

    0<=delta<=delta1+delta2.

Writing eta=delta1+delta2-delta>=0 gives

    Q+delta=x1+x2-h-eta,
    (s1+s2)-delta=sigma1+sigma2+eta.              (C)

Thus the merged closed size loses eta and its surplus gains eta. Both
changes favor the needed capacity inequalities.

The merged reduced surplus is sigma=sigma1+sigma2+eta>=0. If sigma>b,
its profile filter is inactive and the old size profile is automatic since
s1+s2>=sigma>b. Otherwise both component reduced surpluses are at most b,
so their profile filters apply even when an original s_l exceeds b.

If one uses its critical exception, sigma1=b forces sigma2=eta=0.
A positive closed support at reduced surplus zero cannot use the low
branch. The high branch at zero requires j2=v2=2 and d2=0, so its target
and closed support are full. The merger's closed size is therefore x1,
its reduced surplus b, and its target corner features V=2,J=0. It retains
the same critical exception. This does NOT require the second ORIGINAL
source to be full or its inspection cost to vanish: full closed support
is sufficient for this profile argument. The stronger original-full
identity is used only in the separate trigger proofs below. The odd-width
agent independently checked this full-closure extension.

We may now assume that each component uses a low or high capacity branch.

Both cannot be low: q1+q2<=x1+x2<=sigma1^2+sigma2^2<=sigma^2<=b^2<h, whereas
Q>0. If both are high, their target-hole sizes add and (H), followed by
monotonicity in eta, gives the high merged branch. Their missing counts
are exactly the capped sums used in (H).

Suppose one is low. For the high component put

    A=2-j_H, B=2-v_H, C=2-u_H, t=sigma_H,
    d=h-t_H.

Then C>=A, d<=F_(A,B)(t), and its survivor upper bound gives

    t+d=h-x_H >= B+C.

Thus the hypotheses of (L) hold. The merged low-side counts are
(v_L-B)_+, (u_L-C)_+, (j_L-A)_+. Its closed size, by (C), is

    Q+delta=x_L-(t+d)-eta
      <=P(v_L,u_L,j_L;sigma_L)-max(t,B+C)-eta.

Apply (L) and surplus monotonicity in eta. This is exactly the low
merged branch. Either merged branch implies the old size-only profile
for Q and s1+s2 because P and F are at most their surplus squared.

## 4. Feature validity, inspection charges, and maximality

Raw merged state/survivor/target features obey the retained upper bounds
by adding the two component bounds and using

    min(c1+c2,2)+min(e1+e2,2)<=4.

The guarded source and survivor sizes are positive; the merged target
is at least the survivor size. Thus no empty-feature exception or lower
cardinality clipping is needed. Counts remain in {0,1,2} by definition.
The relations U<=J and I<=V follow from their component counterparts.

The map x -> (x-2)_+ is nondecreasing and one-Lipschitz. Hence the merged
losses of the current and eroded corner counts sum to at most the sum of
the four component losses, which is at most p1+p2. Survivor counts do not
increase. This proves the coupled inspection charge at the exact total
cost.

Maximal-retention also survives. Component bounds
 i_l>=(c_l+v_l-2)_+ imply
 I>=(c1+c2+v1+v2-6)_+.
The latter bounds (C_merged+V-2)_+: when either corner sum is below two
this desired quantity is zero; otherwise the expressions coincide.
Thus no new maximality assumption is introduced by the merger.

## 5. The dual-pronic filter is inherited

Suppose the merged chosen action has Q=h-b^2, total surplus b, and J=2.
Then j1=j2=2. It must be the identity merger of one critical component
with a full-to-full component. To see this, assume both original surpluses
are positive and below b.

A low component would have q_l<=sigma_l^2<=(b-1)^2, while the other has
q<=h. Their sum cannot equal 2h-b^2 since h>=2b^2. Thus both use the high
branch. As j_l=2, each target-hole size is at most

    F_(0,2-v_l)(sigma_l) <= s_l(s_l-1).

But their holes sum to b(b-1), whereas

    s1(s1-1)+s2(s2-1)=b(b-1)-2s1s2<b(b-1).

Contradiction. The remaining case has one surplus zero and therefore a
full-to-full action. Identity passes the required (i,u,v)=(1,2,1) from
the critical component to the merger. This argument does not assume
that all allowed enriched profiles are physically realizable.

## 6. Triangle formation and the one-step flag

First show that a raw merged chosen action with Q=b(b-1), I=0, total
surplus b must be an identity merger with a full-to-full component.
If both component surpluses were positive and below b, the mixed branch
would give Q<=x_low<=(b-1)^2, impossible. In the two high branches their
hole sum is h-b^2>=b^2. The merged high capacity is

    F_(2-J,2-V)(b-V),

because I=0. If V>0, this is at most (b-1)^2. If V=0, its second count
is two and F_(2-J,2)(b)<b^2, including minus-infinity endpoints.
Again a contradiction. The two low branches were already impossible.
Thus the triggering component's own rule forces target (b^2,1,0) and
sets its flag. Its other component is full-to-full. This also proves
that the merged triple cannot evade the forced target erosion zero.

Define the merged flag by its own preceding trigger, not by the OR of
component flags. Maintain the invariant that a flagged merged state has
one flagged component and the other component full. The formation
argument proves the invariant at every new flag. From such a state, the
flagged component's next target has current-corner count zero, so the
merged target has count (0+j_other-2)_+=0. On a nontriggering action the
merged flag resets to zero. This proves the required history merger.

## 7. Precapture consequence and what remains unproved

Induct from the full joint state, which merges to (h,2,2), with flag zero.
If the merged size becomes at most k, its already constructed solo history
can clear on the next day. Therefore every required merger before the
minimum solo clearing time satisfies the strict guard. The usual
concentration and reversed-walk lower-clock corollaries apply to this
weakened enriched model, with triangle memory if included.

This would reduce its full-start joint necessary lower computation to one
cohort without losing the tested 7x8 and 9x10 results. It does not evaluate
the remaining solo recurrence in O(1), give physical attainment for every
model path, or claim a complete classification for any untested family.
The independently audited finite joint lower certificates remain valid
regardless of any later implementation changes.

## Finite counterattack receipts

The full physical feature lower bound is not closed under raw merging:
on7x8,k4, (6,2,2)+(27,2,2) merges to (5,2,2), violating c+2e<=a.
That is why the theorem states its deliberate relaxation.

Before weakening, the exact edge check passed every pair with valid
merged features: 570,062 pairs on5x6,k3 and21,335,516 on7x8,k4 for the
closed/maximal/dual model, triangle flag disabled. No invalid merged target
occurred. Receipt: `resumed-erosion-merger-check.json`.

After the stated weakening, every tested source and target merger was
valid and all579,177 and21,370,210 exact-target transition pairs passed,
respectively. With triangle memory restored, its solo clocks remain20,
34,48 on5x6,k3;7x8,k4;9x10,k5. The resulting one-color forward/backward
integer potential inequalities were checked. Receipt:
`resumed-erosion-merger-relaxed-check.json`. These finite facts support
but do not replace the universal proof proposed above.

## 8. Uniform pronic radii and their parity-dependent outgoing allowance

Root supplied a geometric extension, independently checked here at the
corner-distance and merger-algebra level. For every integer radius
2<=r<=b, a physical survivor of size r(r-1), surplus r, and no own corner
is the full odd triangle at one opposite-colored corner. Its next feature
is (r^2,1,0). Its two-step neighborhood contains exactly kappa own-colored
board corners, where

    kappa=0,  if r<b or the shorter side is odd;
    kappa=1,  if r=b, the shorter side is even, and the board is not square;
    kappa=2,  if r=b and the board is an even square.

Indeed the two-step radius is 2r-1. At critical even width it reaches the
corner at the other end of the short side, and reaches a second own-color
corner exactly on the square. The target erosion count remains zero:
at every such newly reached corner exactly one of its two neighbors is
in the preceding triangle neighborhood. Inspections only reduce later
neighborhoods, so a flag triggered at radius r permits next corner count
at most kappa. This paragraph uses the separately reviewed universal proof in
`resumed-odd-even-pronic-all-radii.md`; it does not infer that proof merely from finite profiles.

All these flags preserve the merger simultaneously, by the same identity
formation argument with r replacing b. If a merged survivor has size
r(r-1), own count zero, and surplus r, two positive component surpluses
below r would yield either Q<=(r-1)^2, or a target-hole bound strictly
less than r^2, whereas h-r^2>=r^2. Therefore one component is full-to-full
and the merger is the identity on the triggering component. The merged
history's own flag records that radius (also recoverable from its square
target size), and its next count satisfies J<=j_flagged<=kappa.

The matching dual event is

    q=h-r^2, s=r, j=2  implies i=v=1, u=2-kappa.

It too is inherited by identity formation. If both component surpluses
were positive and below r, a low component cannot supply the required
near-full total. For two high components, j1=j2=2 and the separate target
holes are at most s_l(s_l-1). They cannot sum to r(r-1), because

    s1(s1-1)+s2(s2-1)=r(r-1)-2s1s2<r(r-1).

Thus one component is full-to-full, passing the board's appropriate
kappa and the entire dual feature restriction to the merger.

The algebra is valid whenever the enriched static profile premises are
available. Their currently proved critical refinement is odd-width/even-
length; a refined even-width critical profile must still be proved before
claiming this complete enriched merger model as a necessary model there.
The underlying geometric pronic rigidity and its individual memory/dual
rules have the broader all-even-area scope supplied by root.

## Full-closure interface audit

The canonical builder was strengthened while this work was in progress:
its filter now depends on reduced surplus, not original surplus. Section3
above has been corrected to prove the stronger interface. The odd-width
agent independently derived the same correction. The earlier finite
receipts are preserved rather than relabeled as tests of the new graph.

A new audit freezes the source text before compiling the two expressly
weakened lower cardinality checks, enables all pronic radii, and tests the
current full-closure model. All472,441 pairs on5x6,k3 and19,592,401 pairs
on7x8,k4 passed, with no invalid merged source or target. Restoring the
all-radius flags preserves solo20,34,48 on5x6;7x8;9x10. Exact forward and
backward one-color potential inequalities passed. Receipt:
`resumed-erosion-merger-relaxed-full-closure-check.json`.

A direct endpoint exercises the distinction between an originally full
component and a merely closed-full component. At b=3,h=28,k=4, the
zero-cost actions

    (10,2,0)->(13,0,2),    (27,1,2)->(28,2,2)

have original surpluses3 and1. They merge to the allowed zero-cost action

    (9,1,0)->(13,0,2),

whose original surplus is4>b but whose closed surplus is3. The second
component's original source is not full; its closed support is full.
All three edges were checked directly in the frozen weakened full-closure
model. This endpoint would not be justified by the old zero-original-
surplus identity explanation, which is why the revised proof distinguishes
those two notions explicitly.


Root independently checked the capped F inequality, all four elementary
P comparisons, the mixed funding exception, full-closure critical identity,
upper-feature/coupled-cost/maximality preservation, and both trigger proofs.
The odd-width agent independently checked chosen-survivor flag semantics
and the full-closure extension. This is ordinary proof review, not a Lean
verification or a physical attainment theorem.

## 9. The near-pronic band flag also inherits merger

Let C=b(b-1) and D=C2(b). The ordinary physical localization theorem in
`resumed-odd-even-near-pronic-history.md`, reviewed by root, proves that
no two consecutive transitions can both satisfy

    target corner count j=2,
    D < h-target_size <= C,
    original surplus s<=b.

Such a transition also forces target erosion count one. Flag its target;
forbid another band trigger immediately afterward, resetting the flag on
every nontrigger. This is a uniform interval rule, not a special numerical
history. It can coexist with the earlier pronic flags: their target corner
count is one, whereas a band target has corner count two.

The enriched merger inherits this flag and its target erosion constraint.
Suppose a merged transition triggers. Its target J=2 forces j1=j2=2,
and the two nonnegative component hole sizes sum to a number in (D,C].
In particular each is at most C. A component cannot use the small closed
branch: for a positive outgoing corner count,

    x_l<=P(v_l,u_l,j_l;sigma_l)<=sigma_l(sigma_l-1),

so its target size is at most sigma_l^2<=b^2, forcing its holes to be at
least h-b^2>=b^2>C. The critical exception has j=0 and is also unavailable.
Thus each component uses its high branch, yielding

    d_l<=F_(0,2-v_l)(sigma_l)<=s_l(s_l-1).

If both original surpluses are positive, their sum at most b gives

    d1+d2<=s1(s1-1)+s2(s2-1)
          <=(b-1)(b-2)<=D.

The second inequality is the endpoint maximum of the convex expression
with s1,s2>=1. It includes b=2 and3 without any additional case. This
contradicts the band trigger. Therefore one original surplus is zero,
forcing a zero-cost original-full-to-full partner. The merged action is
the identity on the triggering component, including target erosion one
and the new band flag.

As before, define the merged flag by its own history. A flagged merged
state has one band-flagged component and the other full. The flagged
component is not full, since its hole size exceeds D>=1. If the next
merged action also triggered, its identity formation would require the
same flagged component to trigger again: it cannot be the full source
partner, so the roles cannot swap. This contradicts its individual flag
restriction. Nontriggers reset the merged band flag. This proves merger
inheritance and hence the same full-start lower-clock corollary.

Root independently reviewed and accepted this algebraic argument, including
small b, closure, critical-exception exclusion, and the role-swap issue.
A full numerical two-cohort consequence still records the solo terminal
value f_(tau-1), so 2tau is not asserted from a solo time alone.

## 10. The band flag is superseded by a static feature rule

Root observed, and this subagent and the odd-width agent independently
checked, that the localization theorem gives more than the history rule.
For every band transition, its complementary holes U have surplus exactly
b. The original surplus s<=b and N(U) subset complement S then force
s=b and equality N(U)=complement S. The localized U has one opposite
corner in N(U), and N^2(U) misses both corners of U's color. Therefore

    (i,u,v)=(1,2,1).

This extends the exact critical dual-pronic triple across the entire band.
After such a transition the source of the next one has erosion count one,
whereas another band transition would require survivor erosion count two.
The ordinary constraint u<=e already forbids this. No new history bit is
needed. The preceding flag proof is preserved as the derivation history,
not as an additional requirement in the manuscript or current model.

The identity-formation argument of section9 transfers the entire static
triple and original surplus, so the same merger theorem holds directly
with the band-dual rule. The manuscript corollary now states this static
version, citing `cor:dual-near-pronic` in
`paper/sections/resumed-near-pronic-history.tex`.

Focused finite evaluation of the weakened, fully closed model with all
pronic radii and band_dual=True, band_memory=False gives:

* 11x12,k6: tau64, f_(tau-1)=4, therefore full lower128;
* 11x14,k6: tau86, f_(tau-1)=4, therefore full lower172.

In both cases 2f=8>6 explicitly excludes the one-day-shorter possibility.
The sole minimum terminal feature is (4,0,1). The exact forward lower
potential was checked on all154,016 and213,350 reachable one-color edges,
respectively, using0.76 and1.06 CPU seconds. Receipt:
`resumed-erosion-merger-band-dual-solo-check.json`.
These are exact finite lower-model evaluations plus the independently
reviewed universal merger, not a fixed-size capture-time formula. They
match separately supplied physical upper constructions; those upper
replay receipts remain the authority for attainment.

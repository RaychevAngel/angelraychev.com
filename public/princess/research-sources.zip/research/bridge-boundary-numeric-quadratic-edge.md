# The first budget below the existing even-width large-budget theorem

13 September 2026. New ordinary proof independently reviewed and accepted
by root, including the floor count, physical phase, and equality-case
classification. The root's two-day shape change, independently reviewed by
the upper-construction lane, closes the last residue class; see
`bridge-quadratic-edge-exception.md`. The full theorem below is accepted.
Not integrated or built. Odd-board midpoint necessity remains the priority.

Let w=2r, r>=3, n>=2r, h=rn, and k=r(r-1). Put s=k-r=r(r-2), and define

    j=max(0, floor((h-k-s-3)/s)),
    z=h-(j+1)*s-k-1,
    c=z+ceil(sqrt(z)),  tau=j+3.

For every such r and n, the exact physical time is

    T=2*tau-indicator(2*c<=k).

This is an absolute fixed-size arithmetic expression on an unbounded-width
curve just outside the previously proved strict threshold k>r(r-1).
At r=8 and n=22 mod12 the two anchored-prefix upper bounds exceed this
answer by one day. A prescribed change of shape attains the lower bound;
the historical analysis below identifies exactly where it is needed.

## Scalar lower clock

At the first step from h the reflected root is rho(k)=r-1, while the
increasing root has reached r. Thus the exact static scalar next size is

    x=h-s-1.

Thereafter the reflected term stays saturated: subsequent survivor hole
counts are at least k+s+1>r(r-1). The scalar profile is therefore
L(q)=q+min(ceil(sqrt(q)),r).

It has the affine full-budget map x->x-s whenever
x>=k+s+2, since s+1=(r-1)^2. The number of such maps after the first
step is exactly j above. The remaining source is k+z, with

    1<=z<=s+1,  z=-1 mod r.

In fact r-1<=z<=s-1, because r>=3. The initial source after the first
step is at least k+3r-1, so the last source is always strictly above k;
no earlier capture case was silently omitted. One further neighborhood
step leaves c=z+ceil(sqrt(z))<=k-2, and the next day captures. This gives
tau=j+3 exactly. The accepted symmetric scalar lower theorem gives
2tau-1, improved to2tau if2c>k.

## An actual anchored-prefix clock with the same duration

Choose initial phase p=(n+1) mod2. Its survivor after deleting k is the
full anchored prefix through diagonal n-1, of size h-k=r(n-r+1).
The opposite-parity diagonals through n-2 have r fewer rooms, and its
new last diagonal has2r-1 rooms. Hence its actual neighborhood has size
h-k+r-1=h-s-1, attaining the scalar first step.

The next j steps are in the already proved phase-independent anchored
plateau. Their survivor sizes lie between s+2=(r-1)^2+1 and
h-r^2+r-1=h-k-1. Hence they also coincide with the scalar steps.

The final survivor z<=s-1 lies wholly in the near-corner regime. Its
neighborhood has size either

    c=z+R(z),  or  c'=z+Q(z),

according to the current physical phase; here R=ceil sqrt and
Q(z)=min{u>=1:z<=u(u-1)}. Always R(z)<=Q(z)<=R(z)+1, and both
counts are at most k-1. Thus this physical strategy also has duration
tau. The parity at the final neighborhood step is (n+j) mod2.

If 2c<k, then k is even and c'<=c+1<=k/2, so the reflected central
construction attains2tau-1. If2c>k, the doubled solo construction
attains2tau and the scalar lower matches. Only equality c=k/2 can
need a separate check.

## The equality case has only two possible widths

Since z=-1 mod r and c=k/2, one has R(z)=k/2+1 mod r.
For odd r, k/2 is a multiple of r, so R(z)=1, impossible with
z>=r-1>=2. For even r=2u, this forces R(z)=u+1 and

    z=2u(u-1)-1.

The inequalities u^2<z<=(u+1)^2 hold only for u=3,4, i.e. r=6,8.
At r=6, z=11 and Q(11)=R(11)=4, so the physical central shot is exact
in both phases. At r=8, z=23, R(23)=5, Q(23)=6. Its defining size
equation is n=6j+16. This length is even, so the final phase is j mod2.
The good phase occurs exactly when j is even. The only case requiring
a change of shape is therefore r=8, n=22 mod12.

All other cases have the stated exact formula and a prescribed optimal
prefix/palindrome or central-union strategy. In the remaining class write
n=6j+16 with j positive and odd. After j ordinary prefix steps the belief
is the same color-zero prefix of size127 on every board. The root's
explicit two-day transition changes its size by127 ->79 ->28 using56
inspections on each day. Clearing on the next day gives solo duration
j+3 with final shot28; reflection joins the two shots using56 inspections.
Thus T=2j+5 also here, proving the formula on the entire parameter curve.
The finite sets and their ordinary neighborhood verification are given in
`bridge-quadratic-edge-exception.md`.

## Targeted arithmetic verification

`src/bridge_boundary_numeric_quadratic_edge.py` checks the derived formula
over one complete length residue period at each of eleven selected widths:
242 cases agree with the direct scalar clock and the independently derived
fixed-block physical-prefix upper. Ten further evaluations have lengths
10^12 or10^12+1 and r up to1000. The only observed strict prefix gaps are
the stated shape-change residue, resolved by the new transport construction.
Receipt: `research/bridge-boundary-numeric-quadratic-edge-check.json`.
This audit tests the arithmetic; the ordinary proof supplies the uniform
claim and does not use the data to infer the exceptional residue list.

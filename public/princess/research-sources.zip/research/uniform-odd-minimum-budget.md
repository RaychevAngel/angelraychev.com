# A uniform minimum-budget corner reset

**Supersession,13 September2026:** the full minimum-budget formula is now
proved by the ancestry argument in `maturation-odd-midpoint.md` Section4,
independently accepted by root. The earlier lower-root translation barrier
below was bypassed, not proved. The historical status and failed attacks
are preserved below.

12 September 2026. Sections1–3 have passed root independent ordinary
mathematical review. The exact full-game affine law is NOT proved here.
The shared-quota upper-corner translation barrier in §5 remains open.
Research was stopped at the user-authorized usage cutoff; no claim from
this note was added to the frozen manuscript. No broad enumeration is
used as a proof.

## 1. Setup and width-only corner clock

Let w=2b+1, m=b+1, and let n>=w be odd. Write E=M+1 and
M=(wn-1)/2. Set C=b(b-1). Define a width-only recurrence

    A(0)=B(0)=0,
    A(t+1)=B(t)+m-min(rho(B(t)+m),b),
    B(t+1)=A(t)+m-min(R(A(t)+m),b+1),

where R(z)=ceil(sqrt(z)) and rho(z) is the least r with z<=r(r+1).
Let L_b be the first t with B(t)=C (L_1=0).

This recurrence is just the exact inverse profiles with their distant
upper-corner branches omitted. It is monotone from zero. At x=C-1 its
two scalar maps both equal C, and at x=C they equal C+1 and C,
respectively. Before B first reaches C, A cannot exceed C: to produce
A>=C+1 the preceding B must already be >=C. The first arrival therefore
has

    (A(L_b),B(L_b)) in {(C-1,C),(C,C)}.

The second possibility includes b=1. For b>=2, B first reaches C only
from A>=C-1, so monotonicity gives the stated lower endpoint. The next
two states are always (C+1,C), then (C+1,C+1).

The lower recurrence reaches C in finitely many steps. Its first scalar
map is at least x+1 and its second is at least x, so either two-step
composition increases its argument by at least one.

## 2. Exact reset and solo time, uniformly in length

The lower history through day L_b+2 is physically exact on every allowed
board. All its inverse arguments are <=C+1+m=b^2+2. A reflected branch
could improve I_0 only from argument M-C onwards, at least b^2+3b;
the I_1 reflected branch starts still farther away. The b=1 endpoints
also satisfy these inequalities directly.

At day L_b+2 both physical solo deficits are C+1. The accepted total-
deficit concentration theorem says every reachable mixed state's total
is at most this same value. Such states can be discarded exactly by the
accepted persistence/midpoint theorem, retaining the two pure endpoints.

In the common bulk, ties evolve as

    (s,s) -> (s+1,s) -> (s+1,s+1).

Persistence keeps the retained frontier pure during these tie cycles:
from a state of total <=s both inverse concentration inequalities give
a mixed successor of total <=s, the smaller new solo capacity.

Choose the last convenient tie

    d*=M-b^2-1.

It lies beyond C+1 even on the square: d*-(C+1)>=3b-2>0.
The pure frontier reaches (d*,d*) at the exact day

    t*=L_b+2(d*-C).

Its two active solo belief sizes are b^2+2 and b^2+1.

For any monochromatic canonical starting belief of color p and size k,
greedy capture within T days is equivalent to

    k <= m + D_p(T-1),

where D is the fresh inverse recursion (compose the exact inverse
profiles backwards through the T-1 nonterminal moves). Hence the two
upper-tail solo durations are L_b+2 and L_b+1: their required fresh
deficits are C+1 in color0 and C in color1. This also proves that these
upper-tail durations are independent of n. Combining the times gives

    tau = wn - 4b^2 + 2b + 2L_b - 2.

In particular tau is odd, and the two full-board solo durations are
consecutive. The accepted half-time theorem therefore yields

    T_(b+1)(w x n) in {2wn-K_b-1, 2wn-K_b},
    K_b = 8b^2-4b-4L_b+4.

This is a uniform exact width-only expression for the SOLO time and a
uniform one-bit classification for the full game. It does not select the
final bit. Existing proved minimum-budget width formulas select the
larger value in their stated ranges.

## 3. A uniform bound on upper-tail secondary deficits

From the last tie, call a deficit the primary one if its ancestry is the
nonzero pure endpoint; the opposite ancestry is secondary. The secondary
starts at zero. Whatever quotas are used, monotonicity bounds it by the
fresh solo deficit at the elapsed upper-tail time.

The upper precentral horizon is exactly L_b. At every t<=L_b both fresh
solo deficits are <=C. Consequently every secondary deficit is <=C.

This already excludes a winning midpoint pair with the SAME primary
ancestry: in the other color their combined deficits are <=2C, leaving
at least M-2C>=4b>m rooms for the central inspection. Thus any putative
shorter strategy must use opposite primary ancestries.

## 4. Computation used to falsify candidates

Focused bounded-state checks at difficult square widths through161 found
no counterexample to T(w x(n+2))=T(w xn)+4w. This is evidence only.
Some final frontiers contain many genuinely mixed states. For example
b=80 has a secondary deficit244, so there is no uniform O(1) secondary
bound. At b=9 the solo precentral residuals are12 and4; thus the crude
bound2*min(residuals)>m fails. The secondary C bound above is derived by
inverse duality, rather than fitted from these observations.

## 5. Exact remaining barrier for the all-length full-game law

Increasing n by2 increases M by w. At the last pure tie, both primary
deficits increase by w, while all secondary deficits remain zero. To
couple the upper frontiers, translate a primary by w and leave its
secondary fixed. Every inverse branch commutes with this translation
EXCEPT the lower-root branch for the primary:

* I_0 can receive its lower-root improvement only at input <=C;
* I_1 can receive it only at input <=b^2.

The secondary remains <=C and therefore always uses the same bottom
branches on both boards. Opposite-primary final midpoint costs are
translation invariant; same-primary pairs cannot win by §3.

What is NOT proved is that a retained exceptional upper trajectory
never lets its primary enter one of these lower collars, or that any
such trajectory can be discarded without losing a winning midpoint.
Separate bounds on each coordinate, or the total-deficit bound alone,
do not prove this. Thus neither the full all-length affine identity nor
the all-width no-odd-day claim is promoted here.


## 6. Final bounded attack and restart point

An ancestry-tagged exact retained frontier, started at the pure tie d*,
was inspected for b=9,20,40,80. Among retained mixed successor states,
the smallest primary inverse-input margin above its lower-root cutoff
was53,119,237,479 respectively. None entered a lower-root branch. These
are focused finite checks, not an unbounded invariant.

The following weaker proposed barrier is NOT inductive: bound primary
remaining belief by b^2, bound the secondary by the fresh solo capacity,
and impose the individual solo and high-total bounds. At b=9, one day
after the tie, solo deficits are(100,98), fresh deficits(7,6). The
hypothetical primary-color0 state with remaining belief81 and secondary
deficit3 obeys those constraints. Giving7 probes to the primary produces
remaining belief83 and secondary4, still above the new smaller solo
bound. This source is not actually retained; it demonstrates that the
relaxed conditions omit required history.

Socrates also checked that a bare recovery bound cannot resolve the
barrier: at b=12, starting primary deficit b^2=144 and allocating all
remaining quota over the entire46-day upper horizon can recover to d*=167.
The time/resource cost of reaching that low-primary state matters.

A concrete untested next candidate is a phase-correct corner-root
invariant on retained exceptional states: if z is the primary remaining
belief and k the secondary deficit, an inequality resembling
R(z)+rho(k)<=b+1 or rho(z)+R(k)<=b+1 could exclude the lower collar.
The exact phase convention and the required high-total hypothesis remain
to be derived. This was not tested or promoted after the stop instruction.

The useful proved checkpoint is therefore the uniform width-only solo
formula and secondary bound, together with a sharply localized remaining
joint-state barrier. The full-game offset K_b is still conditional on
excluding the shorter day, and even the general full-game affine shift
has not been proved by this note.

# Main manuscript layout review — 2026-09-13

This is a read-only visual layout review of the 134-page main manuscript. It does not constitute a new mathematical proof audit or a new Lean verification claim.

## Exact artifact

- Source PDF: `paper/main.pdf`.
- Public release copy: `.build/site-release/public/princess/princess-searches.pdf`.
- Both files have SHA-256 `aaaf9fdefab96e5dff620d989ac16fff0969e6d612d340bae59662ee57f01b4f` (rechecked after visual inspection).
- Rendered pages and contact sheets: `tmp/resumed-main-layout/`.

## Actual visual coverage

All nine contact sheets were visually inspected. They cover 107 pages:

- `sheet-00.png`: pages 1–12.
- `sheet-01.png`: pages 13–24.
- `sheet-02.png`: pages 25–36.
- `sheet-03.png`: pages 37–44 and 68–71.
- `sheet-04.png`: pages 72–73 and 76–85.
- `sheet-05.png`: pages 86–97.
- `sheet-06.png`: pages 98–101 and 104–111.
- `sheet-07.png`: pages 112–123.
- `sheet-08.png`: pages 124–134.

Pages 70, 118, and 130 were additionally inspected as individual rendered pages. Page 70 contains the seven-day 6 × 9 search illustration; pages 118 and 130 were selected for their dense displayed formulas.

The remaining 27 pages—45–67, 74–75, and 102–103—were assigned to a separate reviewer. This note makes no claim to have visually inspected those pages.

## Findings

No blank or truncated pages, overlapping text, clipped figures or equations, visibly missing glyphs, or page-number problems were found in the inspected pages. Text and displayed mathematics remain within the page margins. The enlarged formula pages are readable and do not show equation-number collisions.

Page 70 is an intentional standalone figure page with substantial whitespace. Its room diagrams, day labels, counts, legend, and caption are readable and fit within the page. The sparse lower regions on the title and contents pages are likewise consistent with their purpose, rather than missing content.

The review is a layout check at contact-sheet scale, supplemented by the three individual-page checks listed above. It does not certify every character or reference in the manuscript. No PDF or manuscript sources were changed during this review.

## Final release comparison

After the final wording correction on page 103 (outside this reviewer's assigned pages), the fixed source PDF and public release copy both have SHA-256 `a070378c49ec580378751b05c49782dd3f6e0abe884cc3baf2a027407a03f5c0`.

All 107 assigned pages were rendered again into `tmp/resumed-main-layout-final/` with the original settings: `pdftoppm -f PAGE -singlefile -scale-to 950 -png`. Every new rendered page has the same dimensions and exactly identical RGB pixels as its previously inspected counterpart. No assigned page changed visually. This transfers the visual layout findings above to the final PDF at that hash; it does not add a review claim for page 103 or the other separately assigned pages.

The page-by-page comparison receipt is `research/resumed-pdf-main-layout-final-comparison.json`. No PDF or manuscript sources were changed during this final comparison.

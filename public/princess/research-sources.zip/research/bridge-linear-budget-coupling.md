# Two precise couplings for the even-width linear-budget region

13 September 2026. Research conjectures, not proved inequalities.

Let w=2r>=4, n>=w, h=rn, and k>=2r. Budgets at least h have their
existing elementary classification, so the interesting range has k<h.
Let B_t be the critical three-corner backward capture frontier and let
R_t be the same recurrence from the half-budget seed floor(k/2).
Let P_t(p) be the exact anchored-prefix backward threshold for capture
within t days, starting in physical phase p. Let Q_t(p) be its analogous
threshold for reaching at most floor(k/2) rooms in t days. These are
physical prefix thresholds, not necessary-model thresholds.

The candidate couplings are

    B_t(2) <= max_p Q_t(p),
    R_t(2) <= max_p P_(t+1)(p).

They do not identify all partial states or assert optimality of a prefix.
Both compare different terminal objectives, with a half-day budget buffer.
That buffer is the proposed reason a model advantage cannot accumulate
into two full days when k is at least the width.

## Why these two inequalities would suffice

Let tau be the first t with B_t(2)=h. The first inequality supplies a
physical prefix reaching at most k/2 rooms after tau moves, hence a solo
search in at most tau+1 days whose two final shots can share a day.
Thus the physical full upper is at most 2tau+1.

If the model half-budget test fails at tau-1, the accepted merger lower
is 2tau. The two bounds then differ by at most one day.

If the model half-budget test succeeds, R_(tau-1)(2)=h, and the second
inequality supplies a physical solo prefix in at most tau days. Two
copies give a full strategy in at most 2tau days, versus the accepted
2tau-1 lower. Again the gap is at most one day.

The two maxima may select different initial phases. This causes no
problem: each case requires only its own independently reflected solo
strategy. No mixed-phase numerical path is treated as physical.

## Evidence, counterexamples, and next proof obligation

A first deterministic check covered r=2,...,40; lengths 2r,2r+1,4r;
budgets 2r,2r+1,3r,4r below h. It checked both inequalities at 16,090
deadlines with no failure (0.64 CPU seconds). This is finite evidence
only. The separate larger named-bound comparison had 224 strict gaps
in 5,030 cases, all one day. Exact equality of the original lower and
prefix upper is false on, for example, 28x28 at budget28: 44 versus45.

The stronger equal-frontier shortcut is also false: on 40x80 at budget40,
the corner model overtakes both physical prefix thresholds at day13.
The lead can grow beyond one room. Thus an induction that simply replaces
the model frontier by the largest physical threshold is not available.

The missing step is a preserved comparison involving the two terminal
objectives. A useful invariant must retain either the two physical phases
and the three corner thresholds, or an explicitly justified coarser
potential. It must be proved on reachable frontier tuples; asking it to
hold for arbitrary unrelated partial states would be a stronger project.

## A separately tested geometric refinement

`src/bridge_corner_reach.py` extends subcritical triangle radius history
to the corner-only model on even-width rectangles. For near-square
survivor u(u-1)<q<=u², surplus u<r and one survivor corner, localization
gives a target contained within radius2u-1 about an opposite-color corner.
The corresponding exact pronic equality gives radius2u-2 about an
own-color corner. Both triggers have the identity-merger formation proof.
The two retained radii also bound total support size by the exact colored
corner-ball count. Such bounds inherit because merged size and corner
count are each no larger than the respective component quantities.

Every unfiltered graph row in the six-case receipt agrees with the older
independent corner graph. Adding this history does NOT improve the tested
full bounds at 12x12,k16; 16x16,k18; 24x24,k13; 24x27,k25; 28x28,k28;
40x41,k41. In particular it does not close their existing gaps. These
negative tests suggest that exact/near-square radius memory alone is not
the general linear-budget argument. They do not show that either the
physical constructions or the broader necessary model is optimal.

# Independent audit of the four-row classification

12 September 2026 UTC. Review by the frontier/compression subagent,
independent of the author of `four-row-investigation.md`. No substantive
gap was found in either the initial three-probe theorem or the subsequently
completed all-budget proof. This is an ordinary mathematical review, not
Lean verification or external peer review.

## Geometry and the three-probe slice

The vertical-pair perfect matching produces exactly two bidirectional
horizontal chains with alternating directed rungs. For a fixed parity,
an original edge followed by inverse matching is precisely one of these
arcs, so surplus equals directed outer-boundary size.

Deleting one vertex leaves the opposite chain intact. Every remaining
segment of length at least two has rungs of both orientations and joins
the intact chain's strongly connected component. For n>=4 there cannot
be two singleton segments; the only possible leftover is an endpoint
singleton attached in one direction. Thus an outgoing-closed nonempty
set has size 1, h-2 or h-1, with h=2n. The proof uses n>=4 exactly where
needed: at n=3, deleting the middle vertex could leave two singletons.

I checked the complete potential argument for three probes. With
`w(b)=max(b-3,0)`, allocations zero or one do not decrease weight; two
can decrease it by one only from a full cohort; three decrease it by at
most one, including the singleton-survivor endpoint. Every nonempty
physical support after movement has at least two rooms. Therefore two
cohorts require two distinct elimination rounds, each with nonpositive
total weight decrease. This gives T>=2h-4. The diagonal-prefix construction
spends h-4 bulk rounds, an even number, so the final singleton is in the
selected corner phase. Its h-2-day solo schedule is physically valid.

## Free holding is a legitimate lower relaxation

The minimum-neighborhood profile g_h is nondecreasing, including its
plateau at survivor sizes h-3 and h-2. The map

    H_h(b,p)=min(b,g_h(max(b-p,0)))

is nondecreasing in b and nonincreasing in p. Since actual neighborhoods
have at least g_h rooms, comparing the same useful allocations gives
relaxed counts no larger than the arbitrary actual supports. Unused
budget may be discarded or assigned harmlessly. Thus every successful
actual schedule supplies a successful relaxed one.

The relaxed holding move really is free: g_h(b)>=b, hence H_h(b,0)=b.
Every nonproductive allocation can therefore be deleted without changing
that cohort's later relaxed trajectory. This justifies counting productive
inspections even when they are separated by arbitrarily many other days.

## Endpoint bonuses and capacity

For a nonterminal productive inspection, output equals g_h of the
survivors (the minimum with b is inactive). The only surplus-one events
that can decrease the count are:

- h -> h-1, with exactly two useful probes; since counts never increase,
  this can occur only on the first productive inspection;
- a singleton survivor -> two possible rooms; the next productive
  inspection necessarily captures them using exactly two useful probes.

Survivor size h-1 outputs h and is never productive. Counts of size three
are never created by g_h. The two endpoint bonuses therefore occur at
most once each, and if both occur, the first and final two-probe
inspections are distinct. Their useful-probe total obeys all three
inequalities (5)–(7) as written.

The one-cohort capacity `K_j=min(h,j(m-2)+2)` also checks. Spending all
available probes is best by monotonicity. Above b=m+1 the survivors have
size between two and h-3, hence the next count is b-(m-2). At b=m+1,
the exceptional output two is already capturable within the next round.
Thus every successful cohort needs at least `ceil((h-2)/(m-2))`
productive inspections. This does not assert those inspections are
consecutive in the two-cohort game.

## Residue lower bounds

For `W=h-2=qD+r`, `D=m-2`, I checked all three packing arguments:

- At r=0 and k=q, one or two bonuses each force contradictory lower and
  upper probe totals when m>=4. At k>=q+1, even both bonuses leave
  P>=qm. Therefore T>=2q.
- At r=1, k>=q+1. Two bonuses at the smallest k are impossible; the
  resulting P>=qm+2 per cohort rules out 2q days.
- At r>=2, either possible bonus at k=q+1 contradicts its forced
  two-probe packing cap. Longer productive sequences still require
  P>=qm+r+2. Thus 2q+1 days require m>=2r+4.

The separate m=3 potential proof supplies the endpoint case where the
packing inequalities deliberately assume m>=4. This is a covered case,
not an omitted domain.

## Physical upper bounds and phases

The usual diagonal prefixes give the sharp bulk increment two in both
phases, for survivor sizes 2 through h-3. Full-budget solo sweeps therefore
have the same capacity as the relaxed process. A final singleton may have
two or three neighbors, but m>=3 captures either on the following day;
this is why the relaxed capacity remains attainable in the physical game.

For r=1, select the initial reflection so that the singleton left on day q
is a corner. The shared round uses two probes to clear it. The remaining
allocation D is at least three: W is even, so remainder one cannot occur
with D=2, and D=1 cannot have a positive remainder. The second cohort's
survivors are consequently in the bulk, and its next size is at most
qD+2, capturable in q further rounds.

For r>=2 with m>=2r+4, the shared allocation to the second cohort is
D-r>=r+2>=4. Its survivor size remains at least two and at most h-3,
so no endpoint profile is being silently substituted. The displayed next
size again lies below qD+2. Reflections can be chosen independently for
the two physical parity cohorts, whose probes remain disjoint.

The matching-based two-day lower bound, two-day upper strategy, and
one-day threshold are correct for mixed-parity beliefs. The earlier
two-probe invariant proves infeasibility for n>=4. Rotating the already
classified path/two-row/three-row cases covers n=1,2,3 separately.

**Conclusion.** The complete four-row formula and its explicit strategies
have matching independently audited ordinary upper and lower proofs.
The proof does not require a general corner-ideal exchange theorem.

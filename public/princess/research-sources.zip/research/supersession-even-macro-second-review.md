# Second independent audit of the even-width interface graph

13 September2026. Euler independently reviewed
`supersession-even-macro-states.md`, especially Sections4–6, against its
canonical-checkpoint interface. **Verdict: PASS as an ordinary theorem.**
This separate record preserves provenance alongside the root's review.
No closed formula, implemented table generator, logarithmic powering,
or Lean proof is asserted here.

The endpoint-difference localization is exact. Removing inspections
enlarges the final support. Any new avoiding walk must finish in
D=N^r(P0)\P1, and every earlier vertex lies within longitudinal distance
r of D. Every inspection that could hit it was retained, a contradiction.
This proves equality with P1, not just containment. Applying the deletion
to both initial cohorts respects the shared quota because their physical
colors are disjoint at each time.

The bound |D|≤(m+b)r combines arbitrary-support matching with pyramid
growth≤b, valid even at physical ends. Same-orientation cutoffs confine
D to one bounded band. With opposite orientations, either every target
fiber is nonempty and the containing downward baseline must be full,
or an empty target fiber bounds its size by w². Both give the stated
bounded end band; empty/full endpoints are included.

The owner/mate interface is sound. The length threshold implies h>mL,
so a full cohort cannot become empty inside one edge. A mate full at both
ends has D empty and can be left uninspected by localization. Any owner,
orientation, or full/empty change therefore forces the enumerated bounded
sizes or deficits. Interior edges have one common translation parameter
and bounded displacement; no monotonicity of successive translations is
assumed.

The cone radii are correct. Inspections lie in the r-enlarged difference
band; only endpoints in its 2r-enlargement can be affected. Every r-step
walk to such an endpoint lies in the 3r-enlargement. Restricting the initial
support to that larger slab and checking final membership only on the
middle slab is therefore exact. Outside it, the uninspected baseline
equals P1 and no retained inspection can affect a path. The preliminary
check P1⊆N^r(P0) is explicitly required. Inclusive endpoint layers do
not require an extra radius.

When both physical ends occur, their slabs are separated by more than
2L; the finite simulation uses their disjoint union but still enforces
one shared daily quota. No r-step path crosses between them. Far-end
color depends only on n mod2. Interior translation by two columns
preserves colors and adjacency, and empty/full tails are supplied by the
cutoff descriptions rather than a false finite-path translation symmetry.

Finally, the clean-checkpoint proof supplies an actual optimal schedule
with canonical blocks of duration at most E+1. Every stored edge is an
actual block, so the shortest-path equation has both physical directions.
Positive edge lengths and bounded displacement give O(n) edges for fixed
width and budget, and O(n log n) arithmetic operations after potentially
enormous preprocessing.

I also checked virtual heights−2 and−1 at empty fibers, the clipped
neighborhood-cutoff rule, and the equal transverse parity counts used in
the even-width growth bound. No correction was requested.

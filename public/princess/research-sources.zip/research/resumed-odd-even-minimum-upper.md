# Minimum-budget upper bound on every odd-width even-length rectangle

13 September 2026. New research, ordinary proof draft; no Lean claim. The
unrestricted lower bound is **not** established here.

## Proposed unbounded result

Let w=2b+1>=3, let n>=w be even, and m=b+1. Let L_b be the already proved
width-only clock from `paper/sections/odd-minimum-budget.tex`, and put

    C_w = 8b^2 - 4b - 4L_b + 4.

Then an explicitly prescribed physical search gives

    T_m(w,n) <= 2wn - C_w.

Thus the same numerical expression proved exact on odd lengths is an
attained upper bound on even lengths. This does not prove its optimality
on even lengths, nor evaluate L_b in the now-required absolute O(1) form.

## 1. The oriented prefix profiles

Number rooms by (x,y), with x the longitudinal coordinate 0<=x<n and
0<=y<w. On each color order by (x+y,x), ascending. Write I_p(k) for its
k-room prefix, and g_p(k)=|N(I_p(k))|. These particular prefixes are nested
under neighborhoods; they are not claimed to minimize neighborhoods among
all physical supports.

Put h=wn/2, R(z)=ceil(sqrt(z)), rho(z)=min{q>=0:z<=q(q+1)}, and
Q(z)=min{q>=1:z<=q(q-1)} for z>0, with Q(0)=0. Then, for k>0,

    g_0(k) = k + min(R(k), b, rho(h-k)),
    g_1(k) = k + min(Q(k), b+1, R(h-k)),

and g_0(0)=g_1(0)=0. This is asymmetric in the fixed spatial orientation:
reflection along the even-length coordinate exchanges the physical colors
and supplies the opposite preferred orientation.

A direct count proves these identities and neighborhood nesting. If L(d)
is the length of diagonal x+y=d, set A(0)=0 and A(d+1)=L(d)-A(d).
For a prefix ending after j cells of diagonal d its surplus is

    A(d)+1 - [d>=2b] - [max(0,d-2b)+j-1=n-1].

The last expression includes the far-right boundary correction. Its
opposite-color neighborhood is itself an initial segment in the same
order, by following the two forward neighbors of the last diagonal's
consecutive interval. The diagonal lengths increase from 1 to 2b+1,
remain there through d=n-1, then decrease to 1. Hence

    A(d)=ceil(d/2)                    for 0<=d<=2b,
    A(d)=b+(d mod 2)                 for 2b<=d<=n-1,
    A(n+s)=b-floor(s/2)              for 0<=s<=2b.

Substitution, including a partially filled terminal diagonal, gives the
two root displays. This is the width-uniform version of the five-row
prefix count already used in the manuscript.

Let i_p(z)=max{k:g_p(k)<=z}. The same formulas give

    i_0(z)=z-min(rho(z),b,R(h-z)),
    i_1(z)=z-min(R(z),b+1,Q(h-z)).

Equivalently i_p(z)=h-g_p(h-z). Rotation by 180 degrees exchanges the
colors and reverses these orders; complement-neighborhood duality also
proves this identity.

## 2. From a full cohort to a common interior count

Run the greedy prefix search: on each day inspect the last min(m,k)
rooms of the current prefix. Its next count is g_p((k-m)_+), and its
current color flips. Until capture, writing d=h-k converts this through
self-duality to the alternating inverse maps i_p(d+m).

Set B=b(b+1), C=b(b-1), and

    a_* = h-B-1.

The two inverse maps agree with the infinite lower-corner clock whenever
z<=h-b^2: R(h-z)>=b and Q(h-z)>=b+1 remove the competing far-corner
terms. Every input on the way to the tie (a_*,a_*) is at most

    a_*+m = h-b^2.

The earlier minimum-budget clock theorem gives ties (a,a) at time
L_b+2(a-C) for every a>=C+1; the transition between consecutive ties is
(a,a)->(a+1,a)->(a+1,a+1). Here a_*>=C+1 because
h>=(2b+1)(b+1). Consequently both initial phases, after

    t_* = L_b+2(a_*-C) = L_b+2h-4b^2-2

greedy steps, have count K=B+1. They have opposite current colors.
There was no earlier capture because these counts are still larger than m.

## 3. The terminal corner and the palindrome

All subsequent counts are at most K, since each prefix surplus is at
most m. On 0<=k<=K, the far corner is inactive: h-K>=b^2+2b, so
rho(h-k)>=b and R(h-k)>=b+1. Thus the remaining greedy process uses
exactly the two infinite lower-corner profiles.

A current prefix of size K is catchable in s+1 days precisely when the
appropriate fresh inverse clock at time s reaches K-m=b^2. The first
of the two clock entries reaches b^2 at

    L_b+2(b^2-C)-1 = L_b+2b-1.

Therefore the shorter of the two remaining solo searches takes L_b+2b
days. Since the two full-start runs reach the common count K with opposite
current colors, choose the initial phase attaining this shorter tail.
Its total duration is

    tau=t_*+L_b+2b=wn-4b^2+2b+2L_b-2.

The same physical inspection list followed by its reversal catches both
initial colors in 2tau days. The first half catches its designated initial
color. If a walk of the other initial color survived the second half,
reversing that length-tau subwalk would contradict the first half's solo
guarantee. This uses undirected adjacency and the even total length 2tau;
it assumes no untouched-cohort prefix normal form. It proves the displayed
upper bound.

## Computational attack and a misleading apparent gap

`src/resumed_odd_even_minimum_upper.py` independently replays all rooms,
inspections, moves, and the first capture day. Its receipt
`research/resumed-odd-even-minimum-upper.json` contains 36 cases:
b=1,...,12 and n=2b+2,2b+4,4b+4. Every case gives exactly 2wn-C_w,
with no budget or containment failures. A separate 24-case check compared
both oriented profile arrays with actual grid neighborhoods.

A joint optimizer constrained to ONE forward prefix family returned 69
for 7x8,m=4 and 97 for 9x10,m=5. This was not a physical obstruction:
the shortest solo lengths are 34 and 48, and their reversed palindromes
give 68 and 96. The reversed half need not remain in the original forward
prefix family. This is a useful warning against mistaking a restricted
joint optimum for the best strategy supplied by that family's solo runs.

## Still open

The lower bound 2wn-C_w against arbitrary full-board strategies remains
unproved for general odd width and even length. The current three-mode
necessary-condition relaxation loses orientation history in the corner;
it gives only 56 on 7x8,m=4. No full classification follows from this upper.

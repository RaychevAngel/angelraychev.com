# Independent review of the three-threshold corner frontier

13 September2026. Read-only review of
`research/bridge-corner-frontier-proof.md` by the lower-frontier lane.

The fixed-target survivor interval, explicit F+s inverses, G reduction,
G inverses, target monotonicity, and source reconstruction arguments check
algebraically, including the i=2 positive-survivor lower endpoint. The
source reconstruction identity(H_c)-(c-i)=h-2+i correctly accounts for
coupled corner deletion and avoids a false arbitrary-source implication.

One concrete issue was sent to root: the stated refined critical exception
list omits(i,j)=(2,0) for an even width w=2r with n=w+1=2r+1. The accepted
critical theorem permits that additional near-square spanning channel.
It must be included in the cap definition or the theorem scope restricted.
This review does not assume the manuscript or source was already corrected.

An independently written arithmetic check reconstructed G from its original
finite maximum over F, and compared it to the displayed closed branches
for all i,j in{0,1,2} and surplus0..39. It then compared the displayed G
inverse with direct least-surplus evaluation for deficits0..249. All2,610
comparisons passed. No root frontier implementation was imported for this
check. This is a finite transcription audit supporting, not replacing,
the ordinary algebraic review.

No further mathematical defect was found in the current argument.

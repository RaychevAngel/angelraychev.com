# Full path formalization: durable progress

Active work, 12 September 2026 UTC. This is a proof-boundary record, not a claim
that the complete original path classification already compiles.

## Landed and kernel checked

- **PathGeometry.lean:** physical Fin n path adjacency; no dead ends for n≥2;
  parity change; full parity splitting/evolution; exact parity-prefix neighborhood
  identity; prefix cardinality ceil(r/2); top-b inspection budget; exact surviving
  frontier r−2b+1 and terminal emptiness; reflection of adjacency, transitions,
  and cardinality.
- **PathSweep.lean:** an actual legal top-m strategy clearing a prefix within L
  rounds whenever R≤L(2m−1)+1; smaller first allocation followed by full batches;
  q nonterminal first-cohort rounds while the other cohort remains its complete
  alternating parity; a finite-run composition theorem; and the shared joining
  day that finishes the first cohort and begins the second.

These statements construct actual region-valued probe sets and use the same
unrestricted belief semantics and finite cardinality as the completed ladder
proof. They are not assertions about an unconnected abstract counter game.
Both modules compile without admitted proofs or new axioms.

## Currently assembling

The final two-cohort upper construction, with reflection chosen to expose the
better endpoint on even paths, and its identification with the existing
PathUpperArithmetic.sweepCount formula. A convenient simplification is that
after q first-cohort rounds in n=q(2m−1)+r+2 coordinates, the untouched cohort's
current parity is r modulo two. This removes the need to carry the entire
chronological direction rule through the final arithmetic.

## Still required

The arbitrary-subset lower geometry, high/low sequence accounting, exceptional
residue obstruction, small-range lower bounds, and complete all-parameter
assembly. None of these obligations is hidden behind an axiom or a supplied
certificate assumption. The original proof and independent ordinary audits
remain the reference mathematical arguments.

## Major update: complete physical upper and almost complete physical lower

The earlier list above is superseded by this checkpoint. All of the following
compile in Lean 4.33.1 using Std only, with no admissions or additional axioms.

- PathUpper.actual_path_upper proves the explicit historical upper bound for
  every positive n,m, including one probe, the two-room path, all-rooms inspection,
  and the isolated one-room path. The conclusion concerns every actual avoiding
  walk, with a globally bounded physical probe schedule.
- PathLowerGeometry proves even-path neighborhood noncontraction and its equality
  geometry by perfect matchings. A zero-growth proper neighborhood has no endpoint;
  every nonempty endpointless support grows strictly on the next movement.
- PathCohorts splits an arbitrary physical schedule into initial parity cohorts,
  retaining exact daily shared-budget accounting.
- PathEvenRank.path_even_lower proves the complete historical lower bound for
  every positive even n and every positive m. It uses the proved physical geometry
  to dominate PathRankLower's ammunition-potential counter.
- PathOddGeometry proves arbitrary-support odd-path neighborhood bounds by a
  matching with one exposed even-indexed room. Every nonempty support in the
  smaller color class grows strictly.
- PathOddRank proves full alternating-cap physical rank domination on odd paths,
  as well as the constant-cap relaxation used in all but one residue case.

The sole remaining mathematical formalization obligation is the odd-path,
 even-budget correction when the positive residue r=m−1. The companion agent
owns PathOddRankLower's pure counter proof for this equality obstruction. Final
all-parameter theorem assembly remains after that proof. The geometry is fully
proved; no geometric assumptions are being substituted for the path game.

## Complete checkpoint

The remaining odd exceptional interval obstruction has now been proved in
PathOddRankLower.lean and connected to arbitrary physical schedules in
PathOddBridge.lean. PathClassification.lean assembles the complete result for
every positive n,m. Its can_capture_iff theorem states that capture by any positive
number of days is possible exactly when that number is at least the historical
formula. Its exact_minimum theorem supplies the witness and universal lower
bound together. No path proof obligation remains.

Fresh independent dependency compilation: 18 modules, all pass, 17.014 seconds,
source-specific hashes in research/path-full-lean-verification.json. A readable
short proof is in research/path-matching-rank-proof.md. The root and the companion
formalization agent are conducting independent semantic reviews of the final
statement and bridges before public claims are updated.

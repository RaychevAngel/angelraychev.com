# A closed family containing both punctured-quadrant extremizers

13 September 2026. Frozen at the user's wrap-up request.

**Current status:** the broad hybrid class below is NOT a relative dynamic
normal form: the final sections give a verified 29-room, two-inspection
counterexample. Its elementary neighborhood/truncation identities remain
valid. A smaller four-parameter class passes bounded tests, but its closure
derivations have not received independent audit and its relative or dynamic
optimality is OPEN. Neither partial-start diagnostic asserts a full-board
capture time. The earlier localization result has since been independently
accepted in `research/maturation-cheap-step-rigidity.md`.

## Definition

In the infinite nonnegative quadrant, compress each occupied diagonal
toward small first coordinate. A support is specified by the counts on
its consecutive same-color diagonals h,h+2,..., with h>=0. Consider the
following family:

* F>=0 initial full diagonals, of counts h+1,h+3,...,h+2F-1;
* M>=0 subsequent proper ramp diagonals of counts u,u+1,...,u+M-1;
* optionally one final diagonal of count v, where 1<=v<=u+M.

If M>0 require 1<=u<=h+2F, so that every ramp diagonal is proper.
If M=0 there is no tail. A partial first layer after a full block is
represented by M=1 and its count as u. Tail equality v=u+M may instead
be normalized into one further ramp layer. The empty support is included.

This contains every complete and interpolated full-block or proper-ramp
attainer in the punctured-quadrant capacity theorem. Only a bounded number
of integer parameters is required, independent of support cardinality.

## Exact neighborhood closure

For any diagonal count a_i, its upward contribution has count a_i+1 if
nonempty. The next selected diagonal contributes downward count
a_(i+1)-1_[that diagonal is full]. Both are prefixes from the same end,
so their union has their maximum count. The initial downward contribution
is a_0-1_[a_0 is full], on diagonal h-1 if h>0. This is zero at h=0.

These identities give the following exact updates, taking v'=0 when
there is no tail and otherwise v'=v+1.

1. If F>0 and h>0:

       h'=h-1, F'=F+1, M'=M, u'=u+1 (when M>0).

   If F>0 and h=0, replace these first two updates by h'=1,F'=F.
   The other updates remain the same.

2. If F=0, M>0 and u<h:

       h'=h-1, F'=0, M'=M+1, u'=u.

3. If F=0, M>0 and u=h:

       h'=h-1, F'=1, M'=M, u'=u+1.

The empty support stays empty. There is no nonempty proper-ramp case
with h=0 and F=0.

For case 1, neighboring full layers have equal upward/downward output
lengths, giving the full output annulus. The downward contribution of
the first proper ramp fits into the preceding full output layer, since
u<=h+2F. Each proper ramp output thereafter has count u+i+1, and an
optional terminal partial layer contributes v+1 without changing the
preceding output. If h=0 the nonexistent negative diagonal is simply
discarded. For case 2 the initial lower contribution u is still proper,
and the successive upper contributions continue the same ramp. In
case 3 that initial lower contribution fills its entire diagonal; this
is precisely why a hybrid full block followed by a proper ramp is needed.
The displayed parameter bounds remain valid after every update.

Thus this family is closed under ACTUAL open neighborhoods in the whole
quadrant, not merely under a cardinality relaxation.

## Exact truncation to every survivor cardinality

Order selected cells by increasing diagonal and then by the chosen prefix
coordinate. Its first k cells, for any k between zero and the support
size, again have the displayed form. Truncating a full block leaves full
layers followed by one proper layer. Truncating inside the ramp leaves a
shorter ramp followed by at most one partial layer. Truncating the tail
only changes its count. An empty first remainder or an exact last-layer
fill is normalized in the evident way.

Consequently, from any member, any prescribed number of useful inspections
can leave a member by inspecting the last cells in this order. Repeating
this truncation and the exact neighborhood map gives a valid parametric
strategy for every quota word. The number of parameters does not grow
with the word length.

## Necessary scope qualifications

This does not show that the selected truncation minimizes the next
neighborhood inside its parent support, or that the family wins every
quota word that an arbitrary survivor strategy wins. Those are separate
relative or dynamic questions. In particular, the existence of two static
extremal families was not by itself a temporal compatibility theorem.

The result is for the quadrant. A finite strip agrees only while neither
the support nor its neighborhood is clipped by the other transverse
boundary. At that boundary new full-layer effects occur, and the displayed
update may not be used unchanged. The opposite-corner reflection gives
another family; mixing the two is also a separate question.

The pure annulus and pure ramp subclasses alone are not closed. For
example the ramp on diagonals 1,3 with counts 1,2 has neighborhood counts
1,2,3 on diagonals 0,2,4. Its first layer is full and the other two are
proper. It is a hybrid, rather than a full annulus or a pure proper ramp.

## Bounded exact checks and the first failed greedy rule

`src/maturation_even_boundary_family.py` checks 1,566 parameter choices
against actual quadrant neighborhoods, together with 7,745 truncated
supports. All passed in 0.075 CPU seconds; the largest support had 56
rooms. This is finite evidence for the separately proved identities.

The proved diagonal-prefix compression fixes a hybrid parent and is
monotone. Thus every subset of that parent can be compressed to a
diagonal-prefix subset still inside it, without increasing its
neighborhood. Relative one-step minima can consequently be checked
exactly by enumerating diagonal counts, rather than all room subsets.
`src/maturation_even_relative_family.py` checked 3,324 such count vectors
in nine targeted hybrid parents. Every cardinality had a hybrid minimizer;
this is evidence only, not an unbounded relative theorem.

Always retaining the first cells in diagonal order is nevertheless
false as an optimal rule. In the four-room parent

    A={(0,2),(1,1),(0,4),(1,3)},

keeping three cells in that order gives diagonal counts (2,1) and seven
neighbors. Keeping counts (1,2), namely {(0,2),(0,4),(1,3)}, gives six
neighbors. Both supports are hybrids. The family may remain useful, but
its parameters must be optimized rather than fixed by greedy truncation.

## The complete two-bit abstraction still fails dynamically

New ordinary argument submitted to root for independent attack. Work in
the width-14 half-strip, with nine probes per day. Define the bit e by
presence of the current favorable bottom corner. Applying the accepted
four conditional neighborhood profiles backwards gives the following
universal cardinality upper bounds for sets clearable within t days:

    t:       1     2     3     4     5     6     7     8     9
    e=0:     9    15    20    24    29    32    36    39    41
    e=1:     9    15    20    25    29    33    36    39    42.

These are computed by C_(t,e)=9+max_f max{k:g_(e,f)(k)<=C_(t-1,f)},
where g is the conditional neighborhood size, with the empty survivor
handled separately. They are bounds, not assumed realizable states.

In fact no 42-room e=1 support can clear in nine days. Reflect if needed
so the initial color is even and its favorable corner is (0,0). The
first three maximizing choices in the displayed recurrence are forced:

    42,e1 -- keep33, surplus6 --> 39,e0;
    39,e0 -- keep30, surplus6 --> 36,e1;
    36,e1 -- keep27, surplus6 --> 33,e1.

For clarity, the first outgoing e1 choice would require at least40
rooms against the eight-day bound39. The second outgoing e0 choice
requires at least37 against the seven-day bound36. The third outgoing
e0 choice requires at least33 against the six-day e0 bound32. Keeping
more than the indicated survivor sizes also violates these bounds.

Now the 30-room survivor in the second line has odd color, surplus6,
and omits its favorable corner (13,0). Since 6<7, a matched row without
boundary vertices splits it into two independent quadrant parts. The
unfavorable left part has ordinary odd-quadrant capacity C_1(6-r),
and the favorable right part, which omits its origin, has C_2(r).
For r=0,...,6 their possible total capacities are

    30,20,13,9,10,15,24.

Equality30 therefore forces the entire set into the left odd quadrant.
Equality in C_1(6)=30 is rigid: the ramp branch has capacity only15;
equality in the full-block proof forces exactly the full diagonals
1,3,5,7,9. Compression preserves their individual cardinalities, so
full compressed layers imply that the ORIGINAL set is precisely this
odd triangle. Its neighborhood is the even triangle of36 rooms on
diagonals0,2,4,6,8,10. Every room has first coordinate at most10.
No subset of that belief can have a neighbor at (13,0). This contradicts
the forced e1 output in the third line. Thus the 42 entry is unattainable
even by arbitrary nonhybrid intermediate supports.

The actual maximum is41 for BOTH bits, if the initial support is allowed
to be an arbitrary finite set. Let S be the right-corner odd-quadrant
prefix of32 rooms. Its neighborhood is the right-corner even prefix
of39 rooms. Add the nine rooms (0,0),(0,2),...,(0,16) to S. They are
disjoint from S and include the current favorable left corner, giving
a 41-room e1 support. Inspect those nine rooms first, then use the
right-corner prefix sweep. The successive belief sizes are

    41,39,36,33,29,25,20,15,9,0.

Each round uses nine inspections. All later supports and neighborhoods
fit the width, so the quadrant formulas are physical. For e0, start
instead from the right-corner odd prefix of41 rooms and use its first
nine inspections to leave the same S. The bound41 for e0 was already
in the table. This settles the precise small capacity diagnostic, not
the full-board search time on any finite rectangle.

The failure identifies missing distance-to-the-other-corner information.
It is stronger than a failure of one chosen prefix realization: equality
in the intervening static capacity makes that particular triangle
geometrically unavoidable. A compatible-family theorem must retain more
than the two availability bits.

## General rigidity beyond the punctured-corner capacity

New ordinary derivation submitted to root. In an even-width half-strip
of width2b, let S omit its current favorable corner, have surplus s<b,
and satisfy |S|>C_2(s). Then S is connected under the relation of sharing
a neighbor, its neighborhood touches the opposite bottom corner, and,
in quadrant coordinates measured from that opposite corner,

    x_local+y <= 2s-3 for every room of S.

Consequently the omitted current corner cannot belong to N^j(S) for
any j<2(b-s)+2. The same exclusion holds after arbitrary subsequent
inspections, since they only shrink the freely reachable support.

To prove this, decompose S into components in the sharing-neighbor graph.
Their neighborhoods are disjoint, so their cardinalities and surpluses
add. Every nonempty component has surplus at least2, by the current-
corner-omitted profile. At most one component has the opposite corner
in its neighborhood. Every other component has capacity C_2 at its own
surplus by the joint omission theorem. The possible distinguished
component has the ordinary pronic capacity C_1(r)=r(r-1).

If no component is distinguished, superadditivity of C_2 bounds the
total size by C_2(s). If the distinguished component has any companion,
both its surplus r and the other total surplus s-r are at least2.
Convexity makes the maximum of C_1(r)+C_2(s-r) on 2<=r<=s-2 occur at
an endpoint. Both endpoint values are at most C_2(s):

    2+C_2(s-2) <= C_2(s),
    (s-2)(s-3)+1 <= C_2(s),      s>=4.

This again contradicts |S|>C_2(s). Thus S is a single distinguished
component.

A boundary-free matched row exists because s<b. Its two empty physical
rows separate the neighborhoods of the two sides. Sharing-neighbor
connectivity forces S wholly onto the side containing the opposite
corner. The complete neighborhood is unchanged when viewed in that odd
quadrant: the empty matched row supplies its far neighbor layer.

The opposite origin lies in N(S), so the first occupied monochromatic
diagonal is1. A sharing-neighbor edge changes the coordinate sum by
0 or2. Therefore occupied diagonals have no gaps. If there are L of
them, the exact compressed layer inequalities give surplus at least
L+1: one unit on the initial output at the origin, and one for each
occupied diagonal. Diagonal compression preserves which layers are
occupied and cannot increase surplus. Hence L<=s-1, and the largest
occupied diagonal is 1+2(L-1)<=2s-3. This is a bound on the original
rooms because compression preserved each layer's count.

The opposite and current bottom corners are 2b-1 apart. Every room
in the displayed triangle has graph distance at least
(2b-1)-(2s-3)=2(b-s)+2 from the current corner. A walk shorter than this
cannot reach it. This proves the propagation delay and its exact
inspection-independent interpretation.

## Negative evidence: the broad class is not a dynamic normal form

The following diagnostics use a fixed quadrant corner and the fixed
small-first-coordinate convention. They do not exclude a larger family
with other origins or arbitrary changes of orientation.

First, the broad class is not intersection-closed. On diagonals beginning
at h=0, the members with counts (1,2,3,4,5) and (1,3,5,1,2) intersect in
(1,2,3,1,2), which has two separated proper ramp pieces and is not a
member. A cardinality-preserving monotone map fixing all class members
would fix their intersections, so such a retraction is impossible.

Likewise, for B with h=0 and counts (1,3,5,1,2), its exact maximal
quadrant erosion has h=1 and counts (2,4,0,1). This seven-room set has
neighborhood exactly B. It is contained in the broad parent with h=1
and counts (2,4,6,1). Six useful inspections can therefore reach B,
but the unique surviving set realizing that exact endpoint is not broad.
This is an endpoint counterexample alone, not a winning-time separation.

There is also a genuine two-inspection quota-word separation. Take h=2
and the 29-room broad parent

    A counts = (3,5,1,2,3,4,5,6).

With five first-day inspections leave

    R counts = (1,2,1,2,3,4,5,6).

It has 24 rooms and exactly 33 neighbors, so quotas (5,33) clear A.
Every broad survivor of at least 24 rooms in A instead has at least 34
neighbors. Thus the same quota word fails when every survivor must remain
in the broad class. This is an exact partial-start physical statement;
the configuration and its neighborhood fit an 8 by 18 rectangle without
any clipping of their quadrant neighborhoods.

Here is a direct lower argument for the restriction. Starting on the
third or a later occupied diagonal retains at most 21 rooms. Starting
on the second diagonal requires keeping its full five rooms; otherwise
the next source layer of capacity one stops the proper ramp. Retaining
24 then needs all six later layers, and the resulting surplus is at
least 11. Starting on the first diagonal requires both initial full
layers: a proper first layer allows at most six rooms before the forced
drop, and a full first layer followed by a proper second allows at most
eight. Once both full layers are kept, retaining 24 requires all six
later layers, necessarily counts (1,2,3,4,5,v). Their total is 23+v
and their surplus is 10, so the neighborhood has at least 34 rooms.
The unrestricted displayed R has initial lower contribution one and
one surplus unit per occupied diagonal, hence surplus nine.

The direct-coordinate verifier in `src/maturation_even_narrow_family.py`
checks every one of the 1,059 diagonal-prefix survivors of A with size
at least 24. Its raw optimum is 33 and its broad optimum is 34. The
receipt is `research/maturation-narrow-family-check.json`. The proof of
diagonal-prefix compression supplies the unrestricted reduction; the
explicit R already supplies the physical upper witness.

## Draft narrower class: a four-parameter candidate

**Frozen, not independently audited.** This is a proposed replacement
family and elementary closure derivation, not an optimality theorem.

Choose start diagonal h>=0, core length L>=0, intercept c>=1, and an
optional final partial layer v. The core counts are

    a_i = min(h+2i+1,c+i),     0<=i<L.

If present, the tail satisfies 0<v<=min(h+2L+1,c+L). Include the empty
set. A tail equal to the next core value can be normalized into the core.
This is a full initial annulus followed by a slope-one proper ramp that
joins one room above the last full layer, with at most one partial tail.
It contains both punctured-quadrant extremal families and their proposed
neighborhood-generated balanced hybrids. It excludes the large downward
jump followed by a long ramp in the 29-room counterexample.

The exact neighborhood formulas earlier in this note preserve this
smaller family: in the full-to-proper case the first proper value is
exactly h+2F, and the displayed updates preserve that equality.
Intersections also preserve it. On the common diagonal interval the
full-layer bound is shared, while the minimum of the two slope-one
affine bounds is another slope-one affine bound; only the last common
diagonal can be an exceptional partial tail.

For any diagonal-prefix target B, let b_d denote its count on diagonal d
(zero for a missing diagonal). The exact maximal erosion has, on source
diagonal d>=1, count

    e_d = min(max(b_(d+1)-1,0), b_(d-1)+1_[b_(d-1)=d]).

On the origin diagonal d=0 it has count max(b_1-1,0), because there is
no lower-neighbor condition. Upper neighbors require a prefix shortened
by one; lower neighbors require the same prefix count, with the extra
last source room allowed precisely when the lower target layer is full.
Intersecting these two prefix requirements proves the formula for every
diagonal-prefix target, independently of narrowness.

The proposed narrow erosion closure follows by comparing consecutive
core layers. Two full layers give a full layer; two proper ramp layers
give the same slope-one ramp; the full-to-proper join gives a proper
layer exactly one room above the preceding full layer. A final partial
target gives at most one final partial erosion layer. The special origin
is added only when the first target diagonal is one and is full. Initial
or terminal zero counts are discarded. These boundary observations have
been checked computationally but not independently audited as a proof.

If these closure arguments are accepted, two narrow endpoints A,B have
a narrow maximal legal survivor A intersect E(B). The exact useful-shot
cost for reaching a subset of B is therefore |A|-|A intersect E(B)|;
reaching B itself requires the additional equality N(A intersect E(B))=B.
This endpoint fact still does not prove that a winning strategy can
choose all its endpoints from the narrow class.

A common monotone cardinality-preserving retraction is already excluded
even here: fixed sets of such a map are union-closed too, whereas the
narrow members (1,3,5) and (1,2,3,4,5) at h=0 have nonnarrow union
(1,3,5,4,5). Thus a possible normal-form result must be relative,
set-valued, or an exchange theorem about particular strategies.

## Frozen finite evidence for the narrow candidate

`src/maturation_even_narrow_family.py` verifies actual neighborhoods and
actual maximal erosions on 565 narrow supports and 2,181 physical
intersections. It checks all 80,640 diagonal-count subchoices in eight
targeted narrow parents: every survivor cardinality has a narrow
one-step minimizer in these cases. Total CPU time was 0.232 seconds,
including the broad counterexample check.

`src/maturation_even_narrow_words.py` checks all three-day at-most quota
words in five small narrow parents by exact diagonal-count enumeration.
Its 796 first/second quota pairs, 141 distinct second-parent profiles,
and 13,694 second-survivor vectors show no mismatch. Runtime was 0.029
CPU seconds. The receipt is `research/maturation-narrow-word-check.json`.

Neither finite test proves unbounded relative one-step optimality or
multi-day sufficiency. These are the precise restart questions. No new
research or computation was run after the user's wrap-up instruction.

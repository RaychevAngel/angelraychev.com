# Uniform boundary complexity on even-width rectangles

13 September 2026. Ordinary structural lemmas independently accepted by
root; see `supersession-even-states-independent-review.md`.
This note does not assert the unresolved exact pyramid strategy
normal form. No manuscript, website, or Lean source is changed.

The goal is to replace isolated small-width arguments by geometric
statements uniform in width, length, and neighborhood surplus. The
main lemma below applies to EVERY physical monochromatic support, not
only to an already canonical or optimal state.

The constructive implementation `src/supersession_even_stability_check.py`
also checks actual coordinate neighborhoods, all good-block repairs, and
the exact defect transition. Its deterministic random attack passed 908
slab checks, 3,424 row inequalities, and 107 physical pyramid/transition
checks (79 with positive excess), in 0.75 CPU seconds. The receipt is
`supersession-even-stability-check.json`. This supports the ordinary proof;
it is neither a finite optimum computation nor its substitute.

## 1. Exact directed model

Let `G=P_(2b) □ P_n`, with `b≥1`, `n≥2`. Identify either physical
color class with the array `{0,...,b−1} × {0,...,n−1}` by matching
consecutive transverse rows. The induced directed graph D has loops,
bidirectional horizontal row edges, and vertical rungs all pointing one
way in even columns and the other way in odd columns. The opposite
physical color transposes the rungs.

For the image R of a support, write

    B=N⁺_D(R)\R,   s=|B|,
    R_i={j:(i,j)∈R}, B_i={j:(i,j)∈B}, r_i=|B_i|.

Thus s is exactly the physical open-neighborhood surplus, and `sum r_i=s`.

## 2. Neighboring row sets differ by a controlled amount

**Lemma 1.** For adjacent rows i and j,

    |R_i Δ R_j| ≤ 2(r_i+r_j)+1_[n odd]
                 ≤ 3(r_i+r_j),                         (1)

where the second inequality holds also when `r_i+r_j=0`.

**Proof.** Let P be the column parity whose rungs point i→j and let
Q be its complement. Put `A=R_i`, `C=R_j`, and `X=A\C`. Directed
closure gives `X∩P⊆B_j∩P`.

Fix a matching of the horizontal path that covers Q except possibly
one vertex; the exception occurs only when n is odd and Q is its
majority parity. If `z∈X∩Q` is not in B_j and is matched to z'∈P,
then z' belongs to X or B_i. Indeed, since z∈A, horizontal closure
puts z' in A∪B_i. If z' were in A∩C, closure from C would put z in
C∪B_j, contrary to its selection. The matching is injective, hence

    |X∩Q|≤|X∩P|+|B_i∩P|+|B_j∩Q|+eps_Q.

Therefore

    |A\C|≤2|B_j∩P|+|B_i∩P|+|B_j∩Q|+eps_Q.

Apply the same argument to C\A, using the reversed rung parity:

    |C\A|≤2|B_i∩Q|+|B_j∩Q|+|B_i∩P|+eps_P.

The exceptions sum to zero for even n and one for odd n, proving the
first inequality. If r_i+r_j≥1, it implies the second. If both are
zero, A and C are horizontally closed and hence each empty or full.
Since n≥2 provides a rung in both directions, one cannot be full and
the other empty without creating a boundary point. They are equal,
which completes that case. ∎

In particular, for any two rows i,j, the triangle inequality along
their interval and `sum r_i=s` give

    |R_i Δ R_j|≤6s.                                     (2)

For even n, the stronger constant 4s is available by using the first
bound in (1). This argument does not depend on either row being an
interval or on the location of the boundary points.

## 3. A bounded number of macroscopic cuts and explicit defects

For J⊆{0,...,n−1}, call `(j,j+1)` an internal cut when exactly one
endpoint belongs to J. A slab support is the set P consisting, in the
matched array, of the same row J in every transverse position.
Equivalently, its physical support is every room of the chosen color
in a union of longitudinal intervals.

**Theorem 2 (boundary complexity normal form).** Every support R of
surplus s has a slab support P such that

    number of internal cuts of P ≤ floor(s/b),
    |R Δ P| ≤ (6b+1)s.                                 (3)

For even n the second bound improves to `(4b+1)s`. The intervals defining
P may be chosen so that every missing interval between two selected
intervals has length at least two. Consequently P itself has surplus
exactly b times its number of internal cuts, which is at most s.

**Proof.** Choose an anchor row a with `r_a≤floor(s/b)`. Starting from
R_a, fill every missing singleton that lies between two selected
positions. Each filled point is in B_a by horizontal closure, so at
most r_a points are added. Call the resulting set J.

Every remaining unselected interval inside the selected span has length
at least two. Its two adjacent selected/unselected cuts are therefore
charged to two different points of B_a, namely its first and last
positions. An unselected initial or final interval has only one such
cut, charged to its one selected-adjacent boundary point. These charges
are distinct; all were already boundary points for R_a because filling
an isolated missing point removes its two incident cuts and creates no
new cut elsewhere. Thus J has at most r_a internal cuts.

Replicate J in every row to obtain P. Equations (2) and the filling
bound give

    |R Δ P|≤sum_i |R_i Δ R_a| + b|J\R_a|
             ≤6bs+b r_a ≤(6b+1)s.

For even n substitute 4s. Finally, every vertical rung stays inside the
same selected/unselected column of P. Its outside boundary comes only
from horizontal neighbors of J. The stipulated missing-gap lengths
make the outside point for each internal cut distinct, so there are
exactly b outside boundary points per cut. ∎

This is an approximation theorem with an EXACT finite defect set; it
does not change the original support in a strategy or assume equal
cardinalities. Representing R means recording P and the added and
removed rooms in `R Δ P`. Their positions can be arbitrarily far from
the principal front.

### Consequences for one and several fronts

Put `D_b(s)=(6b+1)s`. If

    s<2b,  D_b(s)<|R|<bn−D_b(s),                        (4)

then P cannot be empty or full, and has at most one cut. It is therefore
one full-width prefix or suffix. Thus every sufficiently interior
support with surplus below 2b is a single macroscopic front with at
most D_b(s) added/deleted defects. The exact-surplus-b theorem already
proved in the manuscript is stronger at s=b: it gives an exact
pyramid, with no defects, under its own sharper middle-size condition.

More generally, surplus s permits at most floor(s/b) macroscopic cuts,
plus the explicitly bounded point defects. The statement accounts for
two-end fronts once s reaches 2b, rather than trying to force them into
one orientation. It is uniform in n and contains no finite-board
enumeration or claim that the cuts evolve monotonically.

## 4. Why the defect must be two-sided

The suggested stronger form `R⊆P`, `|P\R|=O_b(s−b)` for one pyramid
P is false. Fix b≥2 and let n be even and large. In physical color one,
take all rooms with longitudinal coordinate y<c, where c is near n/2,
and add the far corner `(0,n−1)`, keeping at least two empty columns
between its neighborhood and the main front.

The main prefix has b c rooms and surplus b. The added corner has two
neighbors, disjoint from the first neighborhood, so the new support has

    |R|=b c+1,       surplus=b+1.

Yet any downward pyramid containing the far corner has a height at least
n−1−x in transverse row x, and hence occupies almost the full cylinder,
up to O(b²) rooms. The missing area relative to R grows linearly with n.
An upward pyramid containing the original left prefix has the same
problem, because that prefix contains a room on the bottom physical row.
There is no containing one-front pyramid with a length-independent
missing-room bound. In contrast, the symmetric difference from the
original prefix is exactly one room.

At surplus 2b a second obstruction is macroscopic: take two long end
prefixes separated by a long missing middle interval. Their combined
surplus is 2b, but their distance from every single prefix or suffix
grows with n. The floor(s/b) cut parameter in Theorem 2 is therefore
structurally necessary.

## 5. Scope of the next step

The theorem is an exact geometric representation for any support once
its boundary surplus is known. It is not yet an optimal-strategy
normal form: arbitrary daily inspections can create a large surplus,
and the surplus/defect representation has not been shown to close under
all time-optimal transitions with a small parameter bound.

Section 7 proves an excess-sensitive sharpening around the exact
surplus-b family: for `s=b+e<2b`, an actual pyramid has O(b e)
symmetric-difference defects. This still has a conservative bulk collar
and does not alone give an exact dynamic compression.

The existing clean-day/slack argument also gives a conservative proved
fallback: optimal states are pyramids with a bounded number of missing
rooms, by starting from the most recent clean state and retaining the
at-most E nonclean days of defects. This yields a large-exponent exact
recurrence, but does not resolve a new scope beyond the existing
effective eventual theorem. It is not being presented as the requested
full finite-rectangle solution.

## 6. Literature check

The monotone-hunting notion in Dissaux, Fioravantes, Gahlawat and Nisse,
*Further results on the Hunters and Rabbit game through monotonicity*,
https://arxiv.org/abs/2309.16533, concerns recontamination after inspections
and is not the pyramid/defect notion above. Its abstract explicitly
exhibits graphs where imposing that monotonicity increases the budget.
No theorem about that different notion is invoked here, and it does not
justify assuming monotone front evolution on rectangles.

## 7. Excess-sensitive stability around a single pyramid

**Theorem 3 (critical-frontier stability).** Let `s=b+e<2b`, with
`0≤e<b`, and suppose

    40bs < |R| < bn−40bs.                               (5)

Then there is a downward or upward physical pyramid P of the SAME
physical color such that

    |R Δ P|≤50 b e.                                    (6)

For e=0 this means exact equality, and the earlier exact-surplus
frontier theorem gives the result under its sharper collar 4b².
The large constants in (5) and (6) are explicit sufficient values,
not claimed optimal.

**Proof.** Reflect the longitudinal coordinate if necessary in the
argument below; this can change the physical color but preserves all
statements, and reflection back restores the specified original color.

### Boundary-free and one-boundary rows

By (2), every row has cardinality within 6s of every other row. Its
cardinality is therefore within 6s of their mean. Equation (5) implies

    34s<|R_i|<n−34s                                    (7)

for EVERY row. A row with r_i=0 is horizontally closed, hence empty or
full, contradicting (7). Thus r_i≥1 and

    sum_i(r_i−1)=e.

Call a row good if r_i=1 and bad otherwise. There are at most e bad
rows and, because e<b, at least one good row.

If a good row's unique boundary position is c_i, horizontal closure
implies that its selected set is empty, a prefix ending just before
c_i, a suffix starting just after c_i, or the entire row except c_i.
The first and last alternatives violate (7). Thus every good row is
a proper prefix or suffix. Opposite orientations are impossible:
a prefix and suffix whose sizes and complementary sizes all exceed
34s have symmetric difference greater than 68s, whereas (2) bounds
that difference by 6s. All good rows have the same orientation. Assume
it is a prefix, and write `R_i={0,...,c_i−1}` on good rows.

### Good blocks already have the exact pyramid geometry

For consecutive good rows the unique boundary points are exactly
c_i,c_(i+1). Every column strictly between these cuts has one selected
rung endpoint and the other endpoint outside both R and B, so its
rung must point inward. Alternation allows at most one such column,
with its required parity. Equivalently, the physical last occupied
heights in their four transverse rows differ by one across every
adjacent pair. This is precisely the local condition from the accepted
exact-surplus theorem, and needs no other rows to be good.

More explicitly, for a matched row with cut c, its two physical
heights are c−1 and c−2, in the order required by their checkerboard
parities. Thus each maximal consecutive block of good matched rows
already supplies a valid physical ±1 height walk. Its heights lie
between 34s−2 and n−34s−1 by (7).

### Join the good blocks by small even translations

Consider a gap of l≥1 bad matched rows between good rows i and j,
so j−i=l+1. Put

    e_gap=sum_(i<t<j)(r_t−1).

Then e_gap≥l. Summing the coarse second bound in (1) along this gap,
using r_i=r_j=1, gives

    |c_i−c_j| ≤ 6+6l+6e_gap.                            (8)

The last physical height in matched row i and the first physical
height in matched row j differ by at most `|c_i−c_j|+1`. Their physical
transverse distance is `2l+1`. Their height difference is odd, so
translating the latter good block by an even integer can put those
heights within distance 2l+1. The smallest needed absolute translation
is at most

    max(0, |c_i−c_j|+1−(2l+1))
       ≤6+4l+6e_gap ≤16e_gap.                           (9)

Start with the first good block unshifted. Inductively translate each
next good block relative to the preceding block by the amount in (9).
Each translation is even, preserving all physical parities and internal
±1 steps. The total absolute accumulated shift of any block is at most

    16 sum_gaps e_gap ≤16e.                             (10)

The endpoints on opposite sides of a gap now have compatible parity
and difference at most their transverse distance. Fill the missing
physical rows by any ±1 walk of exactly that distance. Such a walk
exists by the elementary parity condition. Fill leading or trailing
bad rows by extending the nearest good height walk. Throughout a gap,
the new heights differ from the adjacent shifted good endpoint by at
most 2b. Leading and trailing extensions obey the same bound.

The resulting height vector differs from the nearest original good
block's heights by at most 16e+2b. Since s≥b and (7) provides distance
at least 34s−2 from the physical ends, all these heights lie strictly
between the virtual empty bound and the top board bound. Thus no
clipping or impossible row is introduced. The vector defines an actual
downward physical pyramid P of the required color.

### Count the defects

On each good matched row, the cut changes by its even block translation,
so at most 16e positions change. All good rows together contribute at
most 16be defects.

For a bad matched row t, choose an adjacent good block's endpoint row a
(for an end gap choose the nearest good row). Equation (2) gives
`|R_t Δ R_a|≤6s`. The new cut of P_t is within `16e+2b+3` of c_a:
this accounts for (10), the physical gap walk, and conversion from
the two physical heights back to their matched-row cut. Hence

    |R_t Δ P_t|≤6s+16e+2b+3≤32b,

using s=b+e≤2b−1 and e≤b−1. There are at most e bad rows. The total
defect is at most `16be+32be=48be≤50be`, proving (6). ∎

**Same-cardinality variant.** The pyramid can instead be required to
have exactly |R| rooms, at the cost of replacing 50be by 100be in (6).
Indeed, downward pyramids are ideals of a finite poset. Remove maximal
elements or add available minimal elements until P has the desired
cardinality. This changes exactly `||P|−|R||≤|P Δ R|` rooms, so the
triangle inequality proves the bound. For that pyramid the added and
removed defect sets have equal size, each at most 50be.

Consequently a successful prescribed-quota continuation from either
one of these two equal-size supports can be transferred to the other
by increasing ONLY its first quota by at most 50be: inspect the rooms
in the new starting support outside the old one on the first day,
in addition to the old first inspection, and reuse the rest of the
old schedule. This is a quantified approximate comparison; it is not
an exact quota-preserving compression.

## 8. Exact local transitions on a pyramid with defects

The stability theorem does not license discarding its defect set. It
does give an exact local representation of neighborhoods. Write

    R=(P\D_minus) ∪ D_plus,
    D_minus⊆P, D_plus∩P=∅.

Define

    H={v∈N(P): N(v)∩P⊆D_minus}.

Then, with no geometric assumption beyond the displayed representation,

    N(R)=(N(P)\H) ∪ N(D_plus).                          (11)

Thus relative to the next pyramid N(P), its new positive and negative
defects are exactly

    D'_plus=N(D_plus)\N(P),
    D'_minus=H\N(D_plus).

Because rectangle degree is at most four, H⊆N(D_minus) and

    |N(R) Δ N(P)|≤4(|D_minus|+|D_plus|).                 (12)

The predicate defining H can be checked only at neighbors of D_minus;
it needs the local pyramid membership, not a scan of the entire board.
The ordinary pyramid neighborhood formula handles the background.
Actual inspections first update D_minus and D_plus in the evident set
operations, after which (11) is the exact next-state rule. Replacing the
result by a nearby background pyramid, when justified by Theorem 3,
must keep the exact new defect coordinates.

One immediate budget consequence is valid without any optimality
assumption. If a cohort's pre-inspection size decreases across a day
using at most m useful inspections, its survivor surplus satisfies
s≤m−1. Theorem 2 therefore bounds every such survivor by at most
floor((m−1)/b) slab cuts and `(6b+1)(m−1)` defects. If m<2b and the
bulk guard (5) holds, Theorem 3 applies with e≤m−b−1 whenever s≥b.
At the minimum feasible budget m=b+1, every strictly interior productive
survivor is an exact pyramid. Nonproductive moves and endpoint regions
remain necessary parts of the unfinished global optimum argument.

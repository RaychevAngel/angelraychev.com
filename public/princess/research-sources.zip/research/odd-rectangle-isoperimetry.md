# Odd rectangles: exact open-neighborhood profiles and nesting

12 September 2026 UTC. Independently derived ordinary proof, reviewed by
root; see odd-rectangle-independent-review.md. The finite checks are separate from the proof.
No claim is made here about Lean verification or literature priority.

Let G=P_(2a+1) square P_(2b+1), a>=b>=1, with coordinates (x,y), where x
is the long coordinate. Let E=(|G|+1)/2 and M=E-1 be the two parity sizes.
For a parity-p set of k vertices, let g_p(k) be the minimum number of open
neighbors. Write

    R(k)=ceil(sqrt(k)),
    Q(k)=least integer r>=1 such that k<=r(r-1).

Both profiles have g_p(0)=0. For nonempty sets the exact formulas are

    g_0(k)=k+min(R(k), b, R(E-k)-1),               1<=k<=E,
    g_1(k)=k+min(Q(k), b+1, Q(M-k)),               1<=k<=M. (1)

Moreover, order each parity by increasing (x+y,x). Every prefix attains
its corresponding minimum, and its neighborhood is a prefix in the other
parity's same order. Consequently the globally cardinality-based prefix
compression N-subcommutes. The two-counter game recurrence using these
profiles is exact for arbitrary daily budgets, full beliefs or prefix
partial beliefs. This is stronger than a feasibility classification.

**Tie direction matters.** With x long, use increasing x, not increasing y,
within a diagonal. The latter already fails for a size-five even set on
7-by-5: {00,02,11,20,40} has eight neighbors, whereas
{00,02,04,11,13} has seven.

## 1. Reduction to two Ferrers diagrams

On each odd coordinate, compress the spacing-two parity fibers toward zero.
The odd-path operator and its product lift are proved in
`odd-cylinder-exact-recurrence.md`. Their uniformly stabilized composition
preserves cardinality and does not increase the neighborhood size. Thus
we may assume membership is closed under decreasing either coordinate by
two. Each coordinate-parity pattern is an ordinary lower Ferrers diagram.

In rows y=2i and y=2i+1, let e_i and o_i denote the counts of the selected
path-parity prefixes. Both sequences are nonincreasing separately. For
source parity 0 these count even-x and odd-x vertices respectively; for
source parity 1 they count odd-x and even-x vertices respectively.

## 2. Two quadrant inequalities, with rowwise strengthening

First regard such a finite set S as lying in the nonnegative infinite
quadrant. Put k=|S| and delta=|N(S)|-|S|. All counts eventually vanish.
For parity 0 the exact row-neighborhood formula gives

    delta = (o_0-e_0)_+
          + sum_i [max(e_i-o_i, 1_(o_i>0)) + (o_i-e_(i+1))_+]. (2)

For parity 1 it gives

    delta = max(1_(e_0>0), o_0-e_0)
          + sum_i [(e_i-o_i)_+
                   + max(o_i-e_(i+1), 1_(e_(i+1)>0))].        (3)

To see the formulas, a nonempty odd-x prefix of length t has t+1 even-x
neighbors, while an even-x prefix has t odd-x neighbors in the quadrant.
Neighboring row contributions are prefixes too, and their union has the
maximum of the two lengths. Subtracting the original row lengths gives
(2)-(3), with the first term treating row zero.

Every displayed summand is nonnegative. In (2), if e_i>0, each of the i
preceding paired summands is at least one: either the relevant odd count
is positive, or its even count contributes at least one. The tail from i
onward is at least

    sum_(j>=i) [(e_j-o_j)+(o_j-e_(j+1))] = e_i.

If o_i>0, the first i pairs each contribute at least one, the first term
inside pair i contributes at least one, and the remaining tail is at least
o_i. Therefore

    e_i>0 => e_i+i<=delta,
    o_i>0 => o_i+i+1<=delta.                              (4)

Summing these row bounds proves

    |S|<=delta^2                       for parity 0.      (5)

For (3), if e_i>0 then the initial term is at least one, the first i
pairs each contribute at least one, and the remaining tail is at least
e_i. If o_i>0 the initial term is again at least one; every preceding
pair contributes at least one, because either e_(j+1)>0 or the positive
o_j appears in the second term. The tail after the first term of pair i
is at least o_i. Hence

    e_i>0 => e_i+i+1<=delta,
    o_i>0 => o_i+i+1<=delta,                              (6)

and summing gives

    |S|<=delta(delta-1)                 for parity 1.      (7)

For nonempty quadrant sets, (4) implies delta>=1 in parity 0, and (6)
implies delta>=2 in parity 1. Empty sets have zero surplus.

## 3. A corner, strip, or complement dichotomy

Return to the finite odd rectangle. Let F be the number of selected
vertices on its far edge x=2a, and Z the number on its far edge y=2b.
As finite subsets of the quadrant, the sets have exactly F+Z additional
neighbors: one beyond the rectangle for each selected far-edge vertex.
These extra neighbors are distinct. Consequently

    delta_quadrant = delta_rectangle + F + Z.             (8)

If F=0 and Z>0, the last even row has e_b=Z. Inequality (4) or (6),
together with (8), gives

    delta_rectangle >= b       for parity 0,
    delta_rectangle >= b+1     for parity 1.               (9)

If F>0 and Z=0, swap the axes to obtain the stronger respective bounds
a and a+1. This use of (4)/(6) does not require that the horizontal extent
be at least the vertical extent in the quadrant lemma.

It follows that below b (parity 0), or below b+1 (parity 1), only two
possibilities remain:

1. F=Z=0: S has no far-edge clipping, so (5) or (7) applies directly.
2. F,Z>0: the neighborhood N(S) covers both near edges x=0 and y=0 in
   the opposite checkerboard color. Thus the opposite-parity set
   `T=V_(1-p) minus N(S)`, reflected in both coordinate midlines, has no
   far-edge clipping and satisfies the quadrant bounds.

For the near-edge assertion in case 2, parity 0 has all even-x vertices
in row y=0 and all even-y vertices in column x=0: the Ferrers property
propagates the two far-edge occupancies back toward zero. These vertices
cover both opposite-color near edges. For parity 1, far-x occupancy gives
a full even-x row y=1, covering the even-x near edge y=0. Far-y occupancy
forces vertices (1,2i) for every i, covering the even-y near edge x=0.

The reflected T is again a union of lower Ferrers diagrams. Indeed N(S)
is fixed by each odd-coordinate prefix operator, so its complement is
upper closed in each coordinate-parity pattern; reflection turns these
into lower ideals. Both reflections preserve global parity.

## 4. Lower bounds for both exact profiles

Let first S have parity 0, size k and surplus delta<b. If F=Z=0, (5)
gives k<=delta^2. If F,Z>0, the reflected T has size

    t=M-k-delta,

and N(T) is contained in the complement of S, so its quadrant surplus
is at most delta+1. By (7),

    t<=delta(delta+1),
    k>=E-(delta+1)^2.                                    (10)

For delta=-1 this argument means T must be empty, because a nonempty
quadrant minority set has surplus at least two; hence k=E. For delta=0
it also forces T empty, hence k=M. More negative delta is impossible:
the elementary matching of the minority into all but one majority vertex
gives |N(S)|>=k-1. One can construct this matching by pairing along each
row and pairing the remaining last-column vertices vertically.

Thus either delta>=b, or delta>=R(k), or delta>=R(E-k)-1. Equivalently,

    delta>=min(R(k),b,R(E-k)-1).                           (11)

For parity 1 the same argument gives: below b+1, either

    k<=delta(delta-1),

or T has size E-k-delta and quadrant majority surplus at most delta-1,
so

    E-k-delta<=(delta-1)^2,
    k>=M-delta(delta-1).                                  (12)

If delta=0, neither nonempty-quadrant case nor the complement case is
possible; in the latter T would be nonempty because k<=M<E, yet have
negative quadrant surplus. The row/column matching ensures delta>=0.
Thus delta>=1 for nonempty minority sets, and

    delta>=min(Q(k),b+1,Q(M-k)).                           (13)

Root also observed an independent exact duality check:

    g_1(y)=E-max{x: g_0(x)<=M-y}.                          (14)

Both sides describe the largest majority set with no edge to a y-element
minority set. This derives the second profile from the first without
repeating the finite-rectangle minority geometry.

## 5. Prefix attainment and compatible neighborhoods

Order vertices in each parity by increasing (x+y,x). On each diagonal
x+y=d, the x coordinates form an interval

    max(0,d-2b) <= x <= min(2a,d).

A prefix occupies all earlier same-parity diagonals and an initial
interval of the final diagonal. Its neighbors on the next diagonal are
again an initial interval: each selected x contributes x or x+1 when the
corresponding step lies in the rectangle. Earlier opposite-parity
diagonals are full. In the very first minority diagonal d=1, its lower
neighbor is the corner (0,0); this is again the first opposite prefix.
Therefore every prefix neighborhood is a prefix in the other parity.

For completeness the layer counts give the following surplus table:

| Source parity | Size range | Prefix surplus |
|---|---|---|
| 0 | 1<=k<=b^2 | R(k) |
| 0 | b^2<k<E-b^2 | b |
| 0 | E-b^2<=k<=E | R(E-k)-1 |
| 1 | 1<=k<=b(b+1) | Q(k) |
| 1 | b(b+1)<k<M-b(b+1) | b+1 |
| 1 | M-b(b+1)<=k<=M | Q(M-k) |

The shared minority endpoint k=b(b+1)=M-b(b+1) when a=b gives b+1 in
both descriptions. Empty size ranges are simply absent.

Here is an exact layer calculation, including square and endpoint cases.
Let

    L(d)=min(2a,d)-max(0,d-2b)+1,       0<=d<=2a+2b.

If the prefix ends after j vertices on diagonal d, where 1<=j<=L(d), then

    k=sum_(s<d, s congruent d mod 2) L(s)+j.

All earlier opposite-parity diagonals are full. On the next diagonal,
each selected x contributes x or x+1. Its interval length is exactly

    f(d,j)=j+1-1_(d>=2b)
                 -1_(max(0,d-2b)+j-1=2a).

The first subtraction records that the initial vertex has reached the
short-direction boundary; the second records that the final vertex has
reached the long-direction boundary. At the far corner both occur and
f=0. Therefore

    |N(I_p(k))|=sum_(s<d, s not congruent d mod 2) L(s)+f(d,j).

Let Delta(d) be the first alternating sum minus the same-parity sum
before d. Its value, obtained from Delta(0)=0 and
Delta(d+1)=L(d)-Delta(d), is

    Delta(d)=ceil(d/2)                         if d<=2b,
             b+(d mod 2)                     if 2b<=d<=2a,
             a+b-floor(d/2)+(d mod 2)         if d>=2a.

The formulas agree at shared endpoints. The exact prefix surplus is
Delta(d)+1 minus the two displayed indicators. Complete even diagonals
through sum 2r-2 contain r^2 vertices; complete odd diagonals through
sum 2r-1 contain r(r+1). Substituting these counts and the middle constant
length L(d)=2b+1 into the size formula gives the table. The indicator at
the last selected x=2a handles the one-vertex surplus drops at the ends
of contracting diagonals, including the full-parity endpoint. This
calculation does not assume that neighboring source and target diagonals
all have the same length, which would be false even in an odd square.

The table equals the minima in (11) and (13). This proves (1), attainment
and neighborhood nesting simultaneously.

## 6. Consequences for optimal searching

Let I_p(k) be the prefix of size k and set C(S)=I_0(|S cap V_0|) union
I_1(|S cap V_1|). Cardinality and monotonicity are immediate. By the exact
profile and nesting,

    N(C(S)) cap V_(1-p) = I_(1-p)(g_p(|S cap V_p|))
                       subset I_(1-p)(|N(S cap V_p)|).

Thus C N-subcommutes and is idempotent. The general strategy-compression
theorem applies. From a mixed prefix belief (u,v), choose survivor counts
(i,j) with i<=u, j<=v, and u+v-i-j<=m. The exact next state is

    (g_1(j),g_0(i)).

Shortest paths to (0,0) give the unrestricted minimum capture time and an
optimal strategy on every odd-by-odd rectangle. This result supplies a
proved exact two-counter algorithm; a simpler closed time formula requires
an additional scheduling argument and is not asserted in this note.

## 7. Independent finite evidence

`src/odd_rectangle_profile_attack.py` enumerates pairs of Ferrers diagrams,
not all physical subsets. By Section 1 this still finds the true minimum
for every cardinality. Its separate physical adjacency calculation checks
both the proposed prefix and its neighborhood nesting on 7-by-5, 9-by-5,
7-by-7, 9-by-7, 11-by-7 and 9-by-9. All pass. The largest case has 17,640
and 15,876 compressed supports in its two parities; all six cases together
took about 0.01 seconds. Receipt: `odd-rectangle-profile-attack.json`.

The proof above was developed after observing these profiles. The finite
agreement does not replace any general step of the argument.

Root independently audited Sections 2-5, including both quadrant identities,
positive-tail bounds, F+Z clipping at the double corner, both near-edge
coverage patterns, reflected-complement closure, negative/zero surplus
cases, and the corrected layer formula. No gap was found. A complete
self-contained manuscript version is in `paper/sections/odd-rectangles.tex`.
The exact layer identities were additionally checked against 3,684 physical
prefix neighborhoods on all odd rectangles with sides from 3 through 17;
receipt `odd-rectangle-layer-identities.json`. Direct physical-set checks
of every geometric case on 3-by-3, 5-by-3, 7-by-5 and 7-by-7 passed in
0.13 seconds; receipt `odd-rectangle-geometry-checks.json`.

# Sharp critical-surplus geometry for odd-short, even-long rectangles

12 September 2026. Complete ordinary proof independently accepted by Euler;
see `uniform-odd-short-critical-independent-review.md`. This note concerns arbitrary physical supports.
It does not assert a full dynamic normal form or an exact capture-time
formula. The static profile proof is in
`uniform-even-rectangle-isoperimetry.md`.

Let the rectangle have dimensions `(2b+1) × 2L`, where `b≥1` and
`2L≥2b+1`, and put `h=(2b+1)L`. Its two physical color classes each
have size h. A support is **strictly middle** when

    b² < |R| < h−b(b+1).                                  (1)

This interval may be empty; no assertion requires otherwise.

## 1. Exact contraction and theorem

Use coordinates `(x,y)`, `0≤x≤2b`, `0≤y<2L`, and physical color
`p=(x+y) mod 2`. Match the physical cells `(x,2j)` and `(x,2j+1)`.
Identify a color-p support with cells `(x,j)`, `0≤j<L`, by

    y=2j+((p−x) mod 2).

Under the analogous identification of the opposite color, ordinary
open neighborhood becomes outgoing closed neighborhood in a directed
array D_p. It has loops, bidirectional edges `(x,j)↔(x+1,j)`, and
longitudinal edges in the following directions:

* for p=0, even-x fibers point toward j=0 and odd-x fibers toward j=L−1;
* for p=1, both directions reverse.

Write `U={0,2,...,2b}`, `V={1,3,...,2b−1}`. For a support R define its
outside directed boundary `B=N⁺(R)\R`. Then

    |N(S)|−|S|=|B|,

where S is the corresponding physical support. The directed graphs for
the two phases are transposes.

**Theorem.** Suppose R satisfies (1) and has surplus exactly b. Its
boundary has exactly one point on each V fiber and none on U. In phase
0 there are integers `l_x` such that

    R_x={0,...,l_x−1},
    1≤l_u≤L−1                     (u∈U),
    l_v≤l_u≤l_v+1                 (uv a short-axis edge).

Each V fiber is also a prefix, possibly empty; its sole boundary point
is `(v,l_v)`. Phase 1 gives the longitudinally reflected suffix
description. Consequently if R and R' are strictly middle supports in
successive phases, both with surplus b, then

    R' ⊄ N⁺(R).                                           (2)

Thus two successive actual survivor supports cannot both have surplus
b while both satisfy (1), regardless of the numbers or locations of
inspections between them.

## 2. The common-core alternative at the equality case |B|=b

Mark a short-axis column x when it contains a boundary point. There are
at most b marked columns. Suppose two consecutive columns are unmarked.
Their opposite longitudinal directions, together with the horizontal
bidirectional edges, form a strongly connected full ladder. Every
horizontal row j avoiding B is a bidirectional path meeting this ladder,
so all B-free horizontal rows belong to one strongly connected component
C. At least one B-free row exists because `L≥b+1`.

As R is outgoing-closed in D_p−B, it contains C or avoids C. We claim
the same sharp area bound as in the static-profile proof still holds:
if a set A is disjoint from B, outgoing-closed outside B, and avoids
every B-free horizontal row, then

    |A|≤b².                                               (3)

Here is the only new issue compared with the s<b proof. Choose an empty
B-free anchor row r. Above it, let P be the short-axis parity whose
longitudinal edges point toward increasing j, and set

    alpha_i=|A_i∩P|, beta_i=|A_i\P|,
    t_i=|B_i∩P|,   w_i=|B_i|.

Directed closure gives `alpha_i≤sum_(i<j<r)t_j`. Horizontal neighbors
give `beta_i≤alpha_i+t_i`, unless the selected beta vertices are the
entire majority parity U of the odd path. In that exception P=V, and
every one of the b odd columns has a point in A or B at row i, since
it neighbors a selected even column. Following its forward directed
chain to the empty anchor row forces a boundary point in that SAME
column between i and r−1. Thus all b odd columns are marked. Since
there are only b boundary points, the unmarked columns are precisely
the even ones, contradicting the assumed adjacent unmarked pair.
This excludes the exception without the unavailable inequality b>b.

The weighted summation from the static proof now applies literally.
For every occupied row i above r,

    |A_i|≤w_i+2 sum_(i<j<r)w_j.

If W is the number of boundary points above r and a the number of
occupied rows, each occupied row contains a boundary point. Reserve
one such point in each occupied row. Their coefficients in the sum
are 1,3,...,2a−1; all W−a remaining coefficients are at most 2a.
The upper-half area is at most

    a²+2a(W−a)≤W².

Below r, reverse row order and use the parity pointing toward decreasing
j. The identical exception argument still applies. If W' is the boundary
count below r, the lower area is at most (W')². Since W+W'=b, this proves
(3). This proof uses only that B contains the boundary of A, not that
it equals that boundary.

If R avoids C, (3) gives `|R|≤b²`. If R contains C, apply (3) in the
transposed directed graph to `A=all\(R∪B)`, using the SAME barrier B.
Indeed an edge from A into R in the transpose would be an edge from R
outside R∪B in the original graph. We get

    h−|R|=|A|+b≤b²+b.

Both alternatives contradict (1). Therefore no two consecutive
short-axis columns are unmarked.

## 3. The unique boundary pattern and sharp full/empty exceptions

A path with 2b+1 positions and at most b marked positions can have no
two consecutive unmarked positions only when its marked positions are
exactly `1,3,...,2b−1`. To see uniqueness, the b+1 unmarked positions
form a maximum independent set in that odd path; the only such set is
`0,2,...,2b`. Thus B has exactly one point `(v,c_v)` on every V fiber
and no point on any U fiber.

Consider phase 0. Each U fiber is a prefix because it has no boundary
point and its edges point toward 0. For every adjacent u∈U and v∈V,
horizontal closure gives

    R_v⊆R_u,              R_u\R_v⊆{c_v}.                 (4)

In particular neighboring U prefix lengths differ by at most one.
If the U fiber indexed 2j is empty, then

    |R_(2i)|≤|i−j|,
    |R_(2i+1)|≤min(|i−j|,|i+1−j|).

Summing gives the sharper exact bound

    |R|≤j²+(b−j)²≤b².                                   (5)

This argument requires neither that the V fibers are prefixes nor that
B is their exact boundary. Thus (1) implies every U fiber is nonempty.

If any U fiber were full, the transposed complement
`A=all\(R∪B)` would have that U fiber empty, the same boundary-free U
fibers, and the same one-point V barriers. Apply (5) to A, reversing
longitudinal direction if needed, to obtain

    h−|R|=|A|+b≤b²+b.

Hence every U fiber is also nonfull. Notice the two DIFFERENT exceptions:
an empty U fiber forces |R|≤b², whereas a full U fiber forces
h−|R|≤b(b+1). They must not be replaced by one symmetric b² collar.

## 4. V-prefix shape and the no-consecutive consequence

Each V fiber is contained in a neighboring nonfull U prefix. It
therefore misses position L−1. Its only possible missing point inside
that U prefix is c_v, by (4). If it contained any position above c_v,
following its increasing-j edges would reach L−1 without another
barrier. That is impossible. Thus it is a prefix, of length l_v, and
(4) gives `l_v≤l_u≤l_v+1` on every edge.

The boundary point is exactly c_v=l_v. If l_v>0, its last occupied
point points to l_v. If l_v=0, a neighboring U prefix is nonempty, and
(4) forces that neighboring prefix to have length one and c_v=0.
This also proves that no extraneous barrier point was introduced.

The next belief `N⁺(R)=R∪B` leaves every U prefix unchanged. Therefore
it omits position L−1 on every U fiber. A strictly middle phase-1
critical support is a suffix, nonempty on every U fiber, so it contains
position L−1 on those fibers. It cannot be contained in N⁺(R). The
other phase transition follows by longitudinal reflection.

Only the U fibers need to omit the far endpoint. A V fiber of N⁺(R)
can be full at a boundary value; claiming that all next-belief fibers
are nonfull would be an unnecessary and potentially false strengthening.

## 5. Intended use and remaining dynamic issue

The exact static profile implies every support satisfying (1) has
surplus at least b. The theorem explains why its two successive minima
cannot both equal b: a strict-middle critical frontier has an orientation
forced by the physical phase, which reverses on the next day.

A history bit can record whether the preceding survivor was critical
and strictly middle. This can support a rank of the form `2k+e` and
an interior decrease bound `2p−(2b+1)`, but the exact corner values and
clipped ranks needed for a closed high-budget capture time still require
a separate proof. They are not asserted here.

### A conditional corner bound after a critical frontier

There is a useful additional consequence of the physical identification.
After a phase-0 strict-middle critical survivor, the next phase-1 belief
omits the entire physical row y=2L−1: precisely its U cells have that
physical color, and their paired indices L−1 are absent. Thus every next
survivor lies in the odd-by-odd subrectangle `(2b+1) × (2L−1)`, in its
minority color. In the other phase, the omitted row is y=0; translating
the remaining subrectangle's origin again makes the survivor minority.

By the independently proved odd-rectangle profile theorem, if such a
next survivor has size `0<q≤b²`, then its neighborhood in the original
rectangle has size at least

    q+min(Q(q),b+1),
    Q(q)=min{t≥1 : q≤t(t−1)}.

Indeed the neighborhood within the smaller odd rectangle already has
that size, and adding the removed physical row can only increase it.
The smaller rectangle's minority class has at least `2b(b+1)` vertices,
so its opposite-corner term cannot improve this bound for `q≤b²`.
This is a conditional bound: arbitrary supports of the same size need
only the smaller static `q+ceil(sqrt(q))` bound. At q=0 both bounds
are zero. No claim about the persistence of this label through several
successive small-corner moves is made.

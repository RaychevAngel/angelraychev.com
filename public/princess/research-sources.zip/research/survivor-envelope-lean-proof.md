# Survivor envelopes: full semantic core in Lean

12 September 2026. Status: kernel checked from a fresh six-module dependency
closure; the surrounding transfer-matrix and eventual-formula results are
ordinary proofs, not covered by this formalization.

The module `lean/SurvivorEnvelope.lean` formalizes the local-certificate lemma
in `research/fixed-horizon-transfer-theorem.md`, Section 1. Its main theorem
is stronger than a constant-budget assertion: each day may have a different
arbitrary downward-closed predicate of admissible inspection sets.

## Exact statement and interpretation

For an initial region I and envelopes R_t, define the nominal pre-inspection
regions B_0=I and B_(t+1)=N(R_t), and inspect S_t=B_t minus R_t. No condition
R_t subset B_t is imposed. Actual beliefs U_t satisfy U_t subset B_t, by
induction: U_t minus S_t is contained in R_t. If R_last is empty, the final
inspection covers every actual trajectory surviving to that day.

Conversely, given an actual successful schedule, take R_t to be its actual
survivors. The nominal beliefs then equal the actual beliefs, and the
constructed inspection set is contained in the original inspection set.
Downward closure preserves the daily legality requirement. Thus the
existential equivalence is exact, not merely a sufficient certificate.

`actual_capture_iff_certificate` states this equivalence for arbitrary graph
relations and initial sets. `budget_capture_iff_certificate` specializes to
ordinary finite cardinalities. The index `last` is zero based: it denotes
`last+1` inspection rounds. The final envelope is empty immediately after
inspection, rather than only after a compulsory move.

The target semantics are the existing `Reachable` / `GuaranteesAt` definitions:
finite legal walks avoiding all previous inspections. On the application
Q square P_n with n>=2, every vertex has a legal next move. Consequently
there is no dead-end disappearance issue when interpreting capture of the
moving target. The formal equivalence itself does not infer capture from an
empty post-move belief and therefore requires no no-dead-ends hypothesis.

## Cartesian-product local costs

The product graph is defined explicitly: one coordinate moves along its
factor edge while the other stays fixed. `move_fiber` proves the exact
neighborhood decomposition in a fiber. `productCard` enumerates all pairs
from the two complete `Fin` lists, once each, and `productCard_fibers` proves
that its cardinality is the sum of the fiber cardinalities.

For a full initial board, `local_cost_exact` proves that the generated probe
cardinality equals the sum over fibers j of

- round 0: the number of vertices outside R_0 in that fiber;
- round t+1: the cardinality of
  (N_left(R_t,j) union all R_t,k with right-edge k->j) minus R_(t+1),j.

`product_actual_capture_iff_local_costs` therefore proves the physical
capture equivalence directly from these local sums. For the path as the
second factor, its incident fibers are precisely the adjacent columns,
with absent boundary columns contributing empty sets. The first-round
complement count equals the factor size minus the envelope fiber size.

## Verification and limits

Fresh receipt: `research/survivor-envelope-lean-verification.json`.
All six modules rebuilt with one Lean worker in 4.73 seconds; the receipt
records the source hashes, compiler version, individual outputs and times.
All three exported equivalences depend only on the standard axioms
`propext`, `Classical.choice`, and `Quot.sound`. No admissions or extra axioms.

This proves the unrestricted local survivor-envelope characterization.
It does not formalize the finite transfer matrix, semilinear reachability,
Presburger elimination, or the eventual affine budget formula. It also
does not instantiate the separate geometric compression theorem for a
particular box.

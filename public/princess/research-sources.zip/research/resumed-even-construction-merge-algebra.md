# Proposed merger algebra for the corner-count relaxation

13 September 2026. This is research derivation, sent to `split_manuscripts`
for independent proof. The geometric necessary profile is in
`resumed-even-corner-profile.md`. No manuscript or Lean source is changed.

Let h=wn/2 and w=2r<=n. A feature is `(a,c)`, where a is the number of
possible rooms in one physical color and c∈{0,1,2} is its number of
physical board corners. Cardinality requires `c<=a<=h-2+c`.

An abstract edge `(a,c)->(t,j)` of cost p exists if a survivor `(q,i)` has
`q=a-p`, `max(0,c-p)<=i<=c`, and its neighborhood feature `(t,j)` satisfies
the unconditional static profile plus the new corner-capacity necessary
condition. This is a relaxation; it need not describe an attainable edge.

For two features, propose

    M((a,c),(b,d)) = (a+b-h, max(0,c+d-2)).

This adds their deficits and caps the number of missing corners at two.
The conjectured local lemma assumes `a+b-h>k`. For two allowed edges of
costs p,q with p+q<=k and nonnegative merged target, their merged exact
target is reachable from M(source) with cost at most p+q.

All1,975,422 relevant pairs in the8x8,k5 formula graph pass this exact
target test. Without the source guard the statement is false: `(3,0)`
and full `(32,2)` can go to `(3,1)` and `(31,2)` at costs2 and3, but
merged `(3,0)` cannot go to `(2,1)` at budget5. This does not obstruct
the intended induction: before the relaxed solo capture day, the merged
source should still exceed k.

## Closed form for the dual capacity

The geometric profile uses the small-side capacity F_ij(s) and

    D_ij(s)=max_(0<=d<=2-i) F_(2-j),d(s-2+i+d).

Direct algebra gives:

- `D_i0(s)=1+(s+i-3)^2`, for `s>=4-i`;
- `D_i1(s)=(s+i-2)^2`, for `s>=3-i`;
- `D_i2(s)=(s+i-2)(s+i-1)`, for i=0,1 and `s>=2-i`;
- `D_22(s)=C2(s)=max(s(s-1)/2,s(s-2))`, for s>=0.

Each expression is minus infinity below its stated threshold. For j<2,
the d=0 summand dominates every other admissible summand. Writing
`z=s+i+j-3`, its excess over d=1 is z-1, and its excess over d=2 is
3z-5; both are nonnegative at the respective feasibility thresholds.
For j=2 and i<2 the d=1 term dominates when admissible. At the only
earlier admitted argument, the d=0 term is zero and agrees with the
displayed pronic expression. This was checked against the original
three-term maximum at all2,700 combinations i,j∈{0,1,2},0<=s<100.
The calculation itself is elementary and unbounded; the finite check is
an independent arithmetic audit, not its proof.

## Reduction of the local lemma

Let the original survivor features be `(q1,i1),(q2,i2)`, outgoing corner
counts j1,j2, and surpluses s1,s2. Choose merged survivor size
`Q=q1+q2-h` and corner count `I=max(0,i1+i2-2)`; choose outgoing count
`J=max(0,j1+j2-2)`. The guard implies Q>0. Its proposed surplus is
s1+s2. Corner-removal counts obey the total probe bound automatically.

If s1+s2>=r, the unconditional profile is satisfied and the refined
subcritical inequality is unnecessary. If s1+s2<r, both original edges
are subcritical. They cannot both use their small-side bounds, because
`F_ij(s)<=s^2` and then `q1+q2<r^2<=h`, contradicting Q>0.

When both use the dual bound, it is enough to prove

    D_i1,j1(s1)+D_i2,j2(s2) <= D_I,J(s1+s2).

This holds in all5,184 tested index/surplus pairs with s1,s2<=9 and
nonnegative original dual capacities. The finite case split of the
closed expressions above is the remaining algebraic proof obligation.

In the mixed case suppose `(q1,i1,j1)` uses F and `(q2,i2,j2)` uses D.
Its missing-room count satisfies

    h-q2 >= max(s2+2-j2, 2-i2).

The first term counts its outgoing-complement corners; the second its
omitted source corners. Thus a sufficient inequality is

    F_i1,j1(s1)-max(s2+2-j2,2-i2) <= F_I,J(s1+s2).

It passes all3,435 tested admissible cases with s1,s2<=9 and positive
left side. Its uniform indexed polynomial proof is also pending.

This aims only at full-start total-deficit domination through the
pre-capture clock. It does not assert arbitrary-state optimal seriality
or physical attainment of the relaxed clock.

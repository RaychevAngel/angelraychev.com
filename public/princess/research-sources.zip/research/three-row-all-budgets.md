# Three-row rectangles with arbitrary daily budgets: a phase-rank reduction

Research log, 11 September 2026. This is new work in the present investigation, building on the independently reviewed surplus-one classification in `three-row-investigation.md`. It assumes no result from the unavailable summer 2020 notes and makes no literature-priority claim. **The ordinary proof below now gives the exact closed formula and an explicit optimal strategy for every three-row length and every budget. It uses a new even-length phase-rank reduction and simplifies the previously proved odd-length nesting theorem. A fresh independent review found no substantive gap; see `research/three-row-rank-independent-review.md`. This is not Lean verified.**

## 1. What failed, and what repaired it

The single fixed diagonal-prefix algorithm is not optimal even when the budget exceeds two. On the `3×6` board with five probes, it takes five days whereas unrestricted full-belief BFS proves four days. Coordinates below are `(column,row)` with columns `0,...,5` and rows `0,1,2`. One optimum schedule is:

1. `(0,1),(1,0),(1,2),(2,1),(3,0)`;
2. `(2,2),(3,1),(4,0),(4,2),(5,1)`;
3. `(2,0),(3,1),(4,0),(4,2),(5,1)`;
4. `(0,1),(1,0),(1,2),(2,1),(3,2)`.

The reason is simple: the two initial-parity cohorts can choose their diagonal orientations independently. They need not be prefixes facing the same corner. A full cohort can change its selected orientation freely because its actual support remains the whole parity class. Proper cohorts retain their chosen orientation until they become full again or disappear.

The recurrence with two counts and two phase labels obtained from this observation agrees with every unrestricted finite optimum computed so far, and the lower proof below explains why this is more than pattern matching.

## 2. Definitions and the exact rank recurrence

Let `n=2q≥2`, let `G=P_3 □ P_n`, and put `h=3n/2`. Each parity class has `h` rooms.

A canonical cohort has a count `b` and a phase `z∈{0,1}`. The two phases have respective prefix-neighborhood profiles

\[
 g_0(k)=\min(h,k+1),\qquad
 g_1(k)=\min(h,k+2)\quad(k>0),
\]

and `g_0(0)=g_1(0)=0`. Full sets always have full neighborhoods, consistent with these formulas. Movement swaps the two phases. A full cohort can choose phase zero without altering its support; an empty one needs no phase.

These are actual compatible prefix profiles. In `(column,row)` coordinates, order each parity by increasing coordinate sum and, on a tie, increasing column. Their explicit orders are

\[
 E:(0,0),\quad ((2i-2,2),(2i-1,1),(2i,0))_{i=1}^{q-1},\quad (2q-2,2),(2q-1,1);
\]
\[
 O:(0,1),(1,0),\quad ((2i-1,2),(2i,1),(2i+1,0))_{i=1}^{q-1},\quad (2q-1,2).
\]

Listing the neighbors as each vertex is added gives `N(E_k)=O_{min(h,k+1)}` for `k>0` and `N(O_k)=E_{min(h,k+2)}` for `k>0`; empty prefixes have empty neighborhoods. Every new nonterminal prefix vertex supplies the next opposite-order vertex, until the last diagonal saturates the other parity. These identities include `q=1` by omitting the repeated triples. Thus the corner parity has `g_0`, the other has `g_1`, and every prefix neighborhood is the corresponding opposite prefix. Horizontal reflection exchanges physical parities and allows either initial cohort to start in phase zero. Each cohort's orientation is independent.

Encode the count and phase by the integer

\[
 u=2b+z.
\]

Use rank `0` for an empty cohort and rank `2h` for a full cohort. If `p` rooms of this cohort are inspected, define

\[
 F_h(u,p)=
 \begin{cases}
 0,&\lfloor u/2\rfloor\le p,\\
 \min(2h,u-2p+3),&\lfloor u/2\rfloor>p.
 \end{cases} \tag{1}
\]

The formula is exact for the canonical prefix families: the rank increases by three for movement and decreases by two per useful probe, until full-set saturation or capture. Thus a two-cohort state `(u,v)` has transitions

\[
 (u,v)\longmapsto(F_h(u,p),F_h(v,m-p)),\quad 0\le p\le m. \tag{2}
\]

The initial state is `(2h,2h)`. A state is capturable on the next inspection day exactly when

\[
 \lfloor u/2\rfloor+\lfloor v/2\rfloor\le m. \tag{3}
\]

Breadth-first search of this explicit finite recurrence gives a candidate exact time and constructs actual optimal probes. It has at most `(2h+1)^2` states and `m+1` outgoing transitions per state. It is polynomial in the number of rooms.

The function `F_h` is nondecreasing in `u` and nonincreasing in `p`: the nonzero branch is increasing affine until saturation, while the transition from the zero branch has a nonnegative jump. This fact will be used to compare the recurrence with arbitrary physical supports; no interval assumption is made for the latter.

## 3. Geometric obstruction to consecutive efficient expansions

Call the surplus of a survivor set `R` the quantity `s(R)=|N(R)|-|R|`. The independently reviewed even-length proof establishes:

- every proper nonempty one-parity survivor set has surplus at least one;
- every surplus-one set with size at most `h−2` consists of full matching triples from its boundary, followed by zero, one or two outer vertices of the next triple;
- the analogous sets on the opposite parity start at the opposite boundary;
- every nonempty such set includes at least one outer corner at that boundary; every such set of size at least two includes both.

Inspecting those classified sets yields this slightly strengthened compatibility statement.

**Lemma.** Suppose `R` has surplus one and `1≤|R|≤h−2`. Let `R'⊆N(R)` be nonempty with surplus one and `|R'|≤h−2`. Then necessarily

\[
 |R|=h-2,\qquad |R'|=1.
\]

**Proof.** Unless the first set reaches the last matching triple, its neighborhood contains no outer corner at the opposite boundary, so it cannot contain `R'`. Reaching that triple under the bound `|R|≤h−2` allows exactly one of its two outer vertices. This forces `|R|=h−2` and places exactly one opposite-boundary outer corner in `N(R)`. A surplus-one `R'` of size at least two would require both corners; hence it is a singleton. ∎

In the exceptional transition the current support `N(R)` has `h−1` vertices and reducing it to `R'` requires `h−2` useful probes. Therefore **this transition cannot occur when `m<h−2`**.

## 4. Lower bound for arbitrary supports when m<h−2

Track each initial-parity cohort separately. Attach to its physical support `A` a historical label `z` as follows:

- `z=1` if the preceding nonempty survivor set had surplus one and size at most `h−2`;
- `z=0` otherwise, including initially and when the support is full or empty.

Give a nonempty support the rank `ρ(A)=2|A|+z`, and give the empty support rank zero. Labels are a device for the proof, not an assumption that arbitrary supports have a canonical shape.

Suppose `p` useful probes leave survivors `R⊆A`, of size `r`. We claim that

\[
 \rho(N(R))\ge F_h(\rho(A),p). \tag{4}
\]

If `r=0`, both sides are zero. If `r=h` or `r=h−1`, the neighborhood is full, so the left side is `2h`, at least the capped right side. The `r=h−1` assertion follows because every vertex on the other parity has degree at least two, and at most one vertex was removed from a whole parity class.

It remains that `1≤r≤h−2`.

- If the surplus is one, the next label is one. The current label cannot be one, by the compatibility lemma and `m<h−2`. Thus
  `ρ(N(R))=2(r+1)+1=ρ(A)−2p+3`.
- If the surplus is at least two, the next label is zero and
  `ρ(N(R))≥2r+4≥ρ(A)−2p+3`, because the previous label was at most one.

This proves (4).

Now take any actual successful schedule, including arbitrary disconnected supports, holes, reversals and useless inspections. At each day use its two useful-probe counts in the recurrence; unused budget may be assigned arbitrarily because `F_h` is nonincreasing in probes. Initially both ranks equal `2h`. Monotonicity of `F_h` and (4) imply inductively that the recurrence's ranks never exceed the actual ranks. On the actual final day the two actual support sizes total at most `m`, so the recurrence is also terminal by (3).

Consequently the recurrence clears no later than any physical strategy. Conversely every recurrence transition is realized by the independently oriented canonical prefix families in Section 2. Hence:

**Theorem.** For every even `n≥2` and every `1≤m<h−2`, the shortest-path recurrence (1)–(3) gives the exact minimum guaranteed capture time on `P_3 □ P_n`, or infinity if no terminal state is reachable, together with an explicit optimal strategy.

For `n≥4`, the known feasibility theorem gives infinity for `m=1`; the recurrence itself also has no progress at that budget. For `n=2`, this theorem has an empty positive-budget range (`h−2=1`), so it makes no claim about that small case. The already proved two-row theorem covers `3×2`.

## 5. The high-budget boundary is elementary

The corner exception to the rank lower bound requires `m≥h−2`. Root independently established the following direct treatment, closing the remaining domain.

The even-length board has a perfect matching, so `|N(B)|≥|B|` for every set of rooms `B`, including mixed parity sets. Hence, if `m<h`, after the first inspection and movement at least `2h−m>m` possible rooms remain. Capture in two days is impossible. If `h≤m<2h`, inspect one whole parity on the first day and the other remaining cohort on the second; exactly two days are optimal. If `m≥2h`, one day is necessary and sufficient.

For `m=h−1` and `h≥6`, a three-day construction is as follows. On day one inspect `m` vertices in one full cohort using a phase-zero prefix, leaving its next support of size `h−m+1`. On day two clear this support and use all remaining probes on the other full cohort, independently oriented in phase zero. Its next support has size

\[
 2h-2m+2.
\]

Day three clears it whenever `2h−2m+2≤m`. This holds at `m=h−1` for `h≥6`, and at `m=h−2` for `h≥9`. The two-day lower bound above proves optimality.

The only remaining case is `h=6,m=4`, namely `3×4` with four probes. At least nine possible rooms remain after the first movement: if no useful probes are made this is obvious; otherwise any nonempty proper survivor cohort gains at least one neighbor, while all other surviving cohorts have nonnegative surplus, and neither cohort can be eliminated with four probes from an initial size of six. After the second movement the perfect-matching bound leaves at least `9−4=5` possible rooms, too many to capture on day three. Two sequential two-day cohort sweeps (four probes, then three) give four days, proving optimality.

Finally `h=3` means `3×2`, already a two-row grid up to rotation. Its exact values are infinity for one probe, four days for two probes, two days for three through five probes, and one day for six or more probes. These also follow directly from the previously proved ladder theorem.

Thus the exact rank recurrence in Section 2 is valid as a full-board capture-time algorithm for **all** even lengths and all budgets: it is realized geometrically as an upper bound everywhere, its arbitrary-support lower simulation applies below `h−2`, and its remaining values agree with the direct proofs just given.

## 6. Closed formula and its proof

For even `n≥2` and `h=3n/2`, the answer is infinity at `m=1`, one day at `m≥2h`, and two days at `h≤m<2h`. In the remaining range `2≤m<h`, put

\[
 W=2h-4=3n-4,\qquad D=2m-3,
 \qquad W=qD+r,\quad 0\le r<D.
\]

Here `q≥1`. The exact answer is

\[
 \boxed{T_m(P_3\square P_n)=
 \begin{cases}
 2q,&r=0,\\
 2q+1,&r>0\text{ and }m\ge r+4-(q\bmod2),\\
 2q+2,&\text{otherwise}.
 \end{cases}} \tag{5}
\]

The middle condition is equivalently

\[
 r+2\lfloor(r+4)/2\rfloor\le D, \tag{6}
\]

because `W` is even and `D` odd, so `r` and `q` have the same parity. At `m=2`, `D=1`, giving `6n−8`; at `m=3` the expression simplifies to `2n−2`.

We prove (5) for the rank recurrence first. Its validity for the physical game below `h−2` follows from Section 4. The high-budget values in Section 5 agree with (5) by substitution, including `h=6,m=4` and `h=3,m=2`.

### Upper constructions

A solo cohort starting at rank `2h` and receiving all `m` probes every day clears in exactly `s=ceil(W/D)` days. Its nonterminal rank decreases by `D` per day, and a final inspection can clear rank at most `2m+1=D+4`. This also follows by telescoping (1).

If `r=0`, two sequential solo sweeps take `2q` days. If `r>0`, sequential solo sweeps take `2q+2` days. To save one day when (6) holds:

1. Give all `m` probes to the first cohort for `q` days. Its rank becomes `r+4`.
2. On the next day clear it using `p=floor((r+4)/2)` probes, and spend `m−p` probes on the still-full second cohort.
3. Give all `m` probes to the second cohort for the following `q` days.

After the shared day, the second cohort's rank minus four is

\[
 W-D+2p=(q-1)D+r+2p\le qD.
\]

Therefore `q` further days suffice. The condition ensures `m−p≥2`, so the second cohort actually begins a proper sweep on the shared day. This gives `2q+1` days.

### Why extra interleaving cannot evade the residue correction

Consider any successful rank schedule. For each cohort separately, discard all probes preceding its last occurrence of the full rank `2h` before it is cleared. This cannot harm the other cohort, and leaves the selected cohort full throughout the discarded prefix. Thus its final active interval begins at full rank and never saturates back to full before capture.

If this active interval has `ℓ` inspection days and uses a total of `P` probes, the `ℓ−1` nonterminal movements add exactly three to the rank, with no saturation. The final capture condition therefore gives

\[
 2P\ge 2h+3(\ell-1)-1,
 \qquad
 P\ge h+\left\lfloor\frac{3(\ell-1)}2\right\rfloor. \tag{7}
\]

The per-day limit `m` implies `ℓD≥W`, so each active interval has at least `s=ceil(W/D)` days. This argument permits arbitrary overlap, idle days after a cohort becomes proper, and changes in probe allocation.

Equation (7) is equivalently `P≥ceil((W+3ℓ)/2)`. If `r=0`, then `ℓ≥q`, so each cohort needs at least `qm` probes; at least `2q` days are necessary. If `r>0`, each cohort has `ℓ≥q+1`, so it needs at least `qm+ceil((r+3)/2)` probes. This already excludes a `2q`-day schedule.

Suppose now `r>0` and a total schedule of `2q+1` days exists. The same bound (7) forces total probe usage at least

\[
 2h+2\left\lfloor\frac{3q}2\right\rfloor.
\]

The available number of probes is at most `(2q+1)m`. Substituting `2h=q(2m−3)+r+4` gives the necessary condition

\[
 m\ge r+4-(q\bmod2).
\]

Thus, when the middle case of (5) fails, even arbitrary interleaving requires at least `2q+2` days. Together with the constructions this proves the closed formula.

**Earlier failed simplification.** The naive overlap test `2r+3≤D` omits the parity correction. For example `n=16,m=5` requires 14 days rather than 13. The active-interval count (7) explains the correction without a long list of cases.

## 7. Computational boundary

`src/three_row_budget_recurrence.py` contains the bounded unrestricted BFS, canonical upper recurrence, and independent geometric lower relaxation. `research/three-row-all-budget-experiments.json` records exact versus incomplete BFS outcomes honestly. In particular the larger-budget `3×8` full searches were interrupted at their individual ten-second bounds; they are not optimality certificates.

The geometric lower relaxation retains both possible surplus types and the high-budget singleton exception. It and the canonical upper recurrence agree for all tested even `n≤30` and budgets `2≤m≤20`. A separate receipt `research/three-row-rank-recurrence-checks.json` compares 324 cases through even length 30 and budget 24, with actual room-by-room witness replay for every finite case, as part of the fresh combined verification in about 5.38 seconds. These comparisons motivated and attack the theorem but are not its proof. Full game Lean formalization is not yet attempted for this extension.

## 8. Odd lengths also admit a closed formula

This section uses the already proved full isoperimetric nesting for odd three-row rectangles (`odd-rectangle-investigation.md`). That theorem supplies the exact arbitrary-support count reduction; it is not a new assumption that arbitrary supports are prefixes.

Let `n≥3` be odd, write `3n=2h+1`, and again put `W=3n−4` and `D=2m−3`. The rank of a canonical prefix of size `b` is `2b` on the majority parity and `2b+1` on the minority parity. The two full ranks are respectively `W+5` and `W+4`. A nonterminal move before full-set saturation still obeys

\[
 u\longmapsto u-2p+3.
\]

The saturation cap is the full rank of the *next* physical parity, so it alternates between `W+4` and `W+5`. The precise odd-board prefix profiles already prove that these are exact, realizable transitions. Clearing is still equivalent to `floor(u/2)≤p`.

For `2≤m<h`, write `W=qD+r` with `0≤r<D`; again `q≥1`. Then

\[
 \boxed{T_m(P_3\square P_n)=
 \begin{cases}
 2q,&r=0,\\
 2q+1,&r>0\text{ and }m\ge r+4,\\
 2q+2,&\text{otherwise}.
 \end{cases}} \tag{8}
\]

The remaining cases are infinity for `m=1`, two days for `h≤m<3n`, and one day for `m≥3n`.

### Upper bound

Begin with the minority cohort, whose full rank is `W+4`. Its solo sweep length is `s=ceil(W/D)`. If `r=0`, then `q` is odd because both `W` and `D` are odd. After its `q` days the untouched cohort is also in the minority parity. Two equal solo sweeps give `2q` days.

If `r>0`, a solo sweep of either possible full rank takes at most `q+1` days, since `W+1≤(q+1)D`. Thus sequential sweeps give `2q+2` days.

For a shared-day construction, give `q` full-budget days to the initially minority cohort. It has rank `r+4`; clear it next with `p=floor((r+4)/2)` probes and begin the other cohort with the remaining `m−p`. At that shared day the other cohort's full rank is `W+4+ε`, where `ε=1−(q mod2)` records whether it is majority. After the shared day its rank minus four is

\[
 (q-1)D+r+\varepsilon+2p.
\]

It clears in `q` additional days provided `r+ε+2p≤D`. Since `W` is odd, `r` has parity `ε`, and this condition is exactly `m≥r+4`. Under that condition the shared-day allocation to the second cohort is large enough to leave it proper, so no hidden saturation is used. This proves the upper part of (8).

### Active-interval lower bound

As in Section 6, discard all probes on each cohort before its last departure from full. Its retained active interval never saturates. If it has `ℓ` days, total probe use `P`, and begins on physical parity label `e` (`e=0` minority, `e=1` majority), telescoping gives

\[
 P\ge \left\lceil\frac{W+e+3\ell}{2}\right\rceil,
 \qquad \ell D\ge W+e. \tag{9}
\]

In particular `ℓ≥ceil(W/D)`.

Suppose first `r>0`. Both active intervals have at least `q+1` days, so the combined probes are at least

\[
 2qm+2\left\lceil\frac{r+3}{2}\right\rceil.
\]

This exceeds the capacity of `2q` days, proving `T≥2q+1`. A `(2q+1)`-day schedule requires

\[
 m\ge2\left\lceil\frac{r+3}{2}\right\rceil.
\]

For even `r` this is already `m≥r+4`. For odd `r` it leaves one possible exception: `m=r+3`.

We exclude that exception by equality and timing. Here `q` is even, `m` is even, and `q+1` is odd. The combined lower bound equals the entire `(2q+1)m` budget. Equality therefore forces both active intervals to have exactly `q+1` days and to start in minority parity; a majority start on an odd-length interval would require one additional probe by (9). It also forces every day's budget to lie within these retained intervals, so some interval starts on day one. The other cohort can start in minority parity only on an even day. To fit its `q+1` days before day `2q+1`, its start is at most `q+1`; since `q` is even its even start is at most `q`. Therefore both cohorts have finished by day `2q`, leaving the final day outside both retained active intervals, contradicting equality of the total probe budget. Thus the exception is impossible and `m≥r+4` is necessary.

If `r=0`, both active intervals have at least `q` days. Equation (9) gives

\[
 P\ge\left\lceil\frac{qD+3q+e}{2}\right\rceil
 =qm+\lceil e/2\rceil\ge qm
\]

for each cohort. Thus the combined probes are at least `2qm`, proving `T≥2q` for every `m≥2`. No appeal to the separate two-probe theorem is needed.

These arguments prove (8), including arbitrary interleaving of the two cohort intervals.

### High budgets and feasibility

The board has a matching covering all but one vertex, obtained from a Hamilton path by matching successive pairs. Hence `|N(B)|≥|B|−1` for every room set `B`. If `m<h`, after the first movement there are at least `2h−m>m` possible rooms, ruling out two-day capture. If `m≥h`, inspect the entire minority parity on each of two consecutive days. Every trajectory is inspected on one of these two days. One day requires inspecting all `3n` rooms.

One probe is impossible because the board contains a four-cycle: the target may remain on that cycle, and each nonempty initial-parity cohort there has two possible vertices after movement, so one probe can never eliminate it. Two probes suffice by the existing construction, proving the feasibility threshold.

## 9. Complete three-row statement

For the degenerate length `n=1`, this is the three-vertex path: the answer is two days for budgets one and two, and one day for budget at least three. For every `n≥2`, the feasibility threshold is two, and one-day and two-day thresholds are respectively `3n` and `floor(3n/2)`.

For the remaining range `2≤m<floor(3n/2)`, put

\[
 3n-4=q(2m-3)+r,\qquad 0\le r<2m-3.
\]

Then the complete exact formula is

\[
 T_m(P_3\square P_n)=
 \begin{cases}
 2q,&r=0,\\
 2q+1,&r>0\text{ and }m\ge r+4-\mathbf1_{\{n\text{ even},\ q\text{ odd}\}},\\
 2q+2,&\text{otherwise}.
 \end{cases}
\]

The upper proofs describe explicit optimal inspection schedules. The even-length rank lower proof controls arbitrary supports; the odd-length lower proof uses the already established exact nesting reduction and then controls arbitrary allocations and interleavings.

The independent receipt `research/three-row-closed-form-checks.json` compares this formula with the even rank recurrence and odd exact nested-profile solver for **1,392** pairs (`2≤n≤30`, every `1≤m≤3n`), all agreeing in the fresh combined verification (about **5.38 seconds**, including the 324 physical-witness checks). This is an attack on the proof, not its logical basis. Both the root investigator and a fresh independent reviewer have now checked the odd-length algebraic extension and found no substantive gap. Their suggested sharpening of the `r=0` lower bound was incorporated; the closed formula no longer depends on the earlier two-probe specialization.

The direct constructor `formula_strategy(n,m)` in `src/three_row_budget_recurrence.py` now generates the optimum schedule without any search. The receipt `research/three-row-direct-strategy-checks.json` records **3,825** parameter pairs (`1≤n≤50`, all budgets through `3n`), with every finite schedule replayed through actual grid adjacency, in approximately **0.94 seconds**.

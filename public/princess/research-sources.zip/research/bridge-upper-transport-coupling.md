# Reducing the linear-budget couplings to one scalar comparison

13 September 2026. Exact root identity and conditional reduction proved.
Both requested couplings are now proved under the sufficient budget
condition below, in particular for every `k>=ceil(8r/3)`. The complete range
`k>=2r` remains open.
The root lane independently reviewed and accepted the root invariant,
the clipped low-region exit, alternating high-region charges, both seed
comparisons and the modulo-three corollary.

Write `w=2r`, `h=rn`, `n>=2r`, and `2r<=k<h`. Let R(q) be the least
integer u with `q<=u²`, and rho(q) the least nonnegative integer u with
`q<=u(u+1)`. Use the fixed anchored order `(x+y,-x)`, where x is
transverse. Let E_p(T) be the number of opposite-color vertices whose
entire neighborhoods lie in the phase-p prefix of size T.

## Exact physical erosion in three roots

For `0<=T<h`,

    E_p(T) = T - min(L_p(T), r, H_p(h-T)),

where

    L_0(T)=R(T),             L_1(T)=rho(T),
    H_p(d)=R(d)             if p = n mod2,
    H_p(d)=1+rho(d)         otherwise.

At the full prefix, `E_p(h)=h`; this endpoint must be treated separately.

Here is a direct derivation from the existing diagonal-prefix calculus.
Before the transverse boundary matters, inverting the corner-triangle
neighborhood profiles `q+R(q)` and `q+1+rho(q)` gives the two costs
rho(T) and R(T), respectively. Their portions strictly below r end at
`T=r(r-1)` for phase1 and `T=(r-1)²` for phase0. Between the two corner
regions the diagonal interval spans the width, giving erosion cost r.

At the opposite corner, complement and 180-degree reflection turn the
omitted suffix into a prefix of color `p+(n mod2)`. Thus

    E_p(T)=h-|N(I_(p+n mod2)(h-T))|.

The corner-neighborhood profiles give H_p above. Its portion strictly
below r starts when the deficit is at most `(r-1)²` in the R case,
or `(r-1)(r-2)` in the `1+rho` case. The low and high regions are
disjoint because `h>=2r²`. Their endpoint values agree with the
intervening constant r; the empty omitted suffix gives the separate
full-prefix endpoint. This proves the displayed minimum formula.

The independent arithmetic check compares this formula with the earlier
prefix-diagonal evaluator at448006 phase/rank/board combinations. That
check supports the derivation; it is not the justification for extending
the identity to arbitrary width.

## A scalar relaxation dominates the three corner thresholds

The unconditional isoperimetric profile is

    g(q)=q+min(R(q),r,rho(h-q)).

Its exact inverse is

    E(T)=max(0,T-min(r,rho(T),R(h-T))).

For the low branch, write the surplus u and solve `T<=u(u+1)`;
for the high branch solve `h-T<=u²`; the width branch subtracts r.
Taking the largest admitted survivor gives E. Thus a scalar backward
orbit from a terminal allowance a follows

    S_0=a,       S_(t+1)=min(h,k+E(S_t)).

Every three-corner backward threshold is bounded by this scalar orbit
when its initial threshold is at most a. Dropping corner information
and the critical filter is a relaxation, so it can only enlarge a
capturable threshold.

For the physical prefixes, let

    X_0(0)=X_0(1)=min(h,a+r),
    X_(t+1)(p)=min(h,k+E_(1-p)(X_t(1-p))).

The following SINGLE comparison would imply both inequalities in
`bridge-linear-budget-coupling.md`:

    S_t <= max_p X_t(p)       for every t, when k>=2r.       (OPEN)

Only the two initial values `a=0` and `a=floor(k/2)` are needed for
the original application. The more general statement for arbitrary a
also passes the current finite checks, but is not required.

Indeed, write `m=floor(k/2)>=r`. For a=0 the physical seed r is
bounded by m, so monotonicity gives `B_t(2)<=max Q_t(p)`. For a=m,
the physical seed m+r is bounded by k. A capture-prefix orbit after
its first step has seed k in both phases, so monotonicity gives
`R_t(2)<=max P_(t+1)(p)`. The scalar relaxation makes these implications
stronger than an induction using the three corner thresholds themselves.

## A local comparison and its limitation

For every `0<=T<h` and either phase,

    E_p(T+1) >= E(T).

Each of the three terms attaining the scalar minimum supplies the
corresponding physical bound. In the low-root case use
`R(T+1)<=rho(T)+1`; in the high-root case use
`1+rho(h-T-1)<=R(h-T)+1`; the width term is immediate. This says one
extra target room repairs a single scalar-to-physical step.

It does NOT prove the orbit statement: the one-room credit can be spent
again at later steps, and a maximum over the two physical phases cannot
be freely reselected inside an actual phase trajectory. The required
argument must account for the accumulated losses in both corner regions.
The middle region has exactly the same translation increment `k-r` in
all three recurrences and creates no new loss. The condition `k>=2r`
makes each such increment at least r, which limits residence time in
the two corner regions, but a complete invariant is still missing.

## Bounded evidence and a genuine failed extension

`src/bridge_upper_transport_coupling.py` checks the stronger orbit
statement for5346 cases: r2 through100, lengths2r,2r+1,4r, budgets
2r,2r+1,3r, and six initial-rank choices spread through the board.
All373078 checked deadlines pass. The receipt records the exact counts,
source hashes and the one-room local checks.

The same buffer-r statement is FALSE without the quota restriction:
at r4,n8,k5,a0,t16 the scalar threshold is27 while both physical
thresholds seeded at4 are26. This is a counterexample to that broader
claim, not to either requested linear-budget inequality.

## A proved budget region below the quadratic threshold

Put `D=k-r`, `m=floor(k/2)`. Suppose

    k>=2r,       m-r >= ceil((r-1)²/(2D)).                 (C)

Then BOTH original couplings hold. In fact, the scalar orbit seeded at
a is bounded by BOTH physical phase orbits seeded at `min(h,a+b)`,
provided

    r <= b <= k-r,       b-r >= ceil((r-1)²/(2D)).

This applies to `b=m` and `b=k-m`, respectively. The following proof
works for arbitrary a, although only a=0 and a=m are needed.

### Low corner

While the scalar deficit cost is `u=rho(S)<r`, its update is
`S'=min(h,S+k-u)`. Maintain

    min_p X(p) >= min(h,S+b-u).

The initial condition supplies this invariant. If a physical lower
bound has already reached h, there is nothing left to prove. Otherwise
write `x=S+b-u`. If the next scalar state remains in the low region,
write `u'=rho(S')<r`. Since `k-b>=r>=u'` and
`S'<=u'(u'+1)`,

    x = S'-(k-b) <= u'².

The cost of either physical erosion is at most R(x), hence at most u'.
Monotonicity therefore gives

    X'(p) >= min(h,k+x-u') = min(h,S'+b-u').

If the scalar instead leaves the low region, the universal physical
cost bound r gives `X'(p)>=min(h,S'+b-r)`. This also covers a jump
directly into the high region or capture. If the starting scalar state
is already outside the low region, its initial buffer b directly
supplies the weaker buffer `b-r`.

The low region is unambiguous: when `rho(S)<r`, its size is at most
`r(r-1)`, while the high-root argument is large enough to give cost at
least r. Thus the scalar minimum is indeed u throughout this part.

### Middle

Between the low and high regions the scalar cost is r. The physical
costs are always at most r, so the buffer `c=b-r` is preserved. The
number of middle steps, and hence the board length, has no effect.

### High corner

At entry to the high region, `d=h-S<=(r-1)²` and the scalar cost is
`v=R(d)<r`. As long as a physical threshold X is at least S, the phase
with high cost R has physical cost at most v, while the other phase has
physical cost at most `v+1`, since

    rho(h-X) <= R(h-X) <= R(h-S).

Every physical phase trajectory alternates these two costs. Thus in j
high-region steps each trajectory loses at most `ceil(j/2)` units from
its entry buffer. This comparison remains valid inductively while that
buffer is nonnegative; clipping at h only helps. The scalar advances by
at least D on every nonterminal step. Consequently at most

    N=ceil((r-1)²/D)

high-region steps remain before scalar capture. The required buffer is
at most

    ceil(N/2)=ceil((r-1)²/(2D)),

which is available by hypothesis. Both physical phase thresholds
therefore dominate the scalar at every deadline, including capture.
This proves the buffered comparison under (C), and hence both original
couplings by the seed argument above.

### Consequences and precise remaining scope

In particular, condition (C) holds for all `k>=ceil(8r/3)`, or
`k>=ceil(4w/3)` in terms of the width. It suffices to check the least
such k, because increasing k improves both sides. Write `r=3q+s`:

| s | k | available buffer `floor(k/2)-r` | `2(k-r)` |
|---|---|---|---|
| 0 | 8q | q | 10q |
| 1 | 8q+3 | q | 10q+4 |
| 2 | 8q+6 | q+1 | 10q+8 |

In each row, `(r-1)²` is at most the product of the last two columns,
including the q=0 case of the last row. This proves the required
ceiling inequality. The simpler bound `k>=3r` follows as well.
The sharper integer condition asymptotically begins at

    k/r >= (3+sqrt(5))/2 = 2.618... .

The two couplings give the uniform one-day bracket relative to the
accepted critical three-corner lower bound, exactly by the two terminal
cases in `bridge-linear-budget-coupling.md`. This is a theorem on the
specified budget region, not an exact formula or a complete treatment
of every `k>=2r`. No physical optimality of arbitrary partial states is
used. The principal remaining interval is `2r<=k` below (C).

The accompanying verifier additionally checks the stronger MIN-phase
comparison at the first budget satisfying (C), its successor and3r,
for r2 through100 and the same three length choices, with four seed
and buffer choices. These checks test the newly proved invariant's
boundaries; they do not replace the argument above.

## Two failed shortcuts for the remaining interval

The crude low invariant spends all initial buffer at k=2r, but its zero
remainder cannot simply be discarded. With r10,n20,k20, a scalar orbit
started at100 and two physical phase orbits also started at100 have,
after6 updates, values167 and(166,165), respectively. So an independent
high-corner theorem with zero entry buffer is false.

Replacing both physical phase costs by their pointwise WORST cost also
fails, even with an initial r-room head start at k=2r: for r9,n36,k18,
scalar seed0 and worst-cost physical seed9 give thresholds323 and322
at day32. Thus the alternating phase information is essential to any
extension proved by this route.

At the actual half-budget seed the finite orbits retain substantially
more low-corner credit than the proved bound `b-r`; the high penalty also
occurs only on the lower half of each pronic-to-square root band. These
are plausible sources of a stronger invariant. Neither observation is
currently a bound on all widths, and the requested k>=2r theorem remains
open below condition(C).

# Resumed odd-board compatibility: a deadline-only credit barrier

13 September 2026. Research resumed by the parent task after artifact
separation. This bounded branch addresses only the full-board middle-day
choice on odd rectangles. It does not change the fixed-size numerical
completion criterion, develop arbitrary partial-state optimality, or edit
paper, website, Lean, or checkpoint files.

## The narrow obligation

Write w=2b+1, n>=w odd, m in the intermediate feasible range, E=M+1,
L=tau-1, and A=max(D_0(L),D_1(L)), B=min(D_0(L),D_1(L)), delta=A-B.
The accepted exact central criterion minimizes

    (E-x-u)_+ + (M-y-v)_+

over two attainable deficit histories at L. The solo histories give the
upper strategy. The outstanding necessity asks only whether another pair
can reduce the required central inspection count to at most m.

Accepted retention already handles every pair containing a low-total
history. Accepted fastest ancestry says that all retained exceptional
histories have the same primary initial cohort. Consequently they have the
same ancestry-secondary physical color q at this final time. No assertion
that the primary is the numerically larger actual coordinate is needed.

## A conditional screening lemma

This deduction is derived here and is awaiting independent review. Its
hypotheses are explicit; the two new universal hypotheses below are NOT
proved.

Let C_q be the size of the secondary physical color, and define

    c = ceil((C_q-m)/2).

Assume m<M and delta>0; a solo tie has no exceptional states. Let F be any
integer potential for which F(s)-s is nondecreasing. Suppose all attainable
exceptional histories, with primary deficit a and secondary deficit s,
satisfy

    F(s) <= A-a+epsilon,                         (credit condition)

for a fixed nonnegative integer epsilon. If

    F(c)-c >= delta+epsilon,                    (numerical guard)

then no pair of exceptional histories wins the central day.

Proof. Exceptionality gives a+s>B=A-delta, so the integer primary lag
ell=A-a satisfies ell<=s+delta-1. The credit condition therefore implies
F(s)-s<=delta+epsilon-1. If s>=c, monotonicity of F(s)-s contradicts the
numerical guard. Hence every secondary deficit is at most c-1. Two such
histories leave at least C_q-2c+2 >= m+1 unexcluded rooms in that color
alone. Their central intersection is too large. The accepted retention
argument handles all other pairs, so the scalar central test is necessary
as well as sufficient under these hypotheses. This is a full-board
winning-decision argument, not an equality of complete attainable frontiers.

For the previously proved bottom-corner ammunition F=mu_q and the
observed rounding allowance epsilon=1, the sufficient guard is

    mu_q(c)-c >= delta+1.

Thus the currently relevant research questions can be stated as two
precise candidate lemmas:

1. At the actual precentral time, every retained exceptional history has
   mu_q(s)<=ell+1.
2. At that same actual solo layer, mu_q(c)-c>=delta+1.

The existing earlier-time 21x21,m=12 witness has mu_q(s)-ell=1. Therefore
replacing the first statement by zero credit at all times is false.
This branch deliberately permits the known credit. Applying a bottom
ammunition function to an actual finite-board secondary history is not
being assumed valid for free: that transfer is part of the first candidate
lemma and must account for possible reflected branches.

## Focused exact evidence

`src/resumed_odd_compatibility_barrier.py` uses the already established exact
retained recurrence, not a serial approximation. Its 78 selected precentral
frontiers cover widths 7,9,11,15,21,31,41; square, next odd and triple-width
lengths; and minimum-plus-one, twice-half-width, middle and upper
intermediate budgets. All completed in 0.141 CPU seconds.

- No scalar central decision failed.
- No proposed numerical guard failed.
- No final exceptional history had positive ammunition credit in this sample.
  This does not remove the epsilon=1 allowance or prove a final zero-credit
  statement. Some selected histories have no exceptional final states.

The exact rows, deficits, critical sizes, margins, credits and witnesses are
in `research/resumed-odd-compatibility-barrier.json`.

`src/resumed_odd_compatibility_solo_guard.py` performs scalar evaluations only:
it does not search joint strategies. It tested 249 non-tie selected cases
with widths up to 401 and lengths up to 101 times the width, in 0.240217 CPU
seconds. Every guard passed, with smallest margin

    mu_q(c)-c-delta = 2.

The coarse proved gap bound delta<=m-1 certifies the numerical guard in
151 of those cases, but not in 98. Thus substituting m-1 everywhere would
leave a substantial gap even in this small sample. The actual solo layer
contains information needed by the sharper candidate inequality.
Receipt: `research/resumed-odd-compatibility-solo-guard.json`.

## What this does and does not add

This gives a weaker, deadline-specific barrier than the earlier proposed
secondary<=b^2-m restriction. It separates the needed history statement
from a pure solo numerical inequality, preserves the real one-unit credit,
and avoids proving serial optimality or exact reachable-state equality.
It is a conditional route, not a completed odd-rectangle theorem.

The potentially difficult part is the credit condition through the primary
lower-root bands. The accepted suffix exchange already covers episodes
whose primary inverse inputs remain above b^2+1. A root-rounding gain can
occur below that boundary. Monotonicity, total concentration, or minimum
single-cohort ammunition alone does not bound that gain: the recorded
synthetic-capacity failures and shared-last-day obstruction remain valid.
The numerical guard is a separate candidate, and scalar computations do
not prove it uniformly.

Even proving both candidate lemmas would only remove the joint optimization
from the middle-day decision. The parameter-dependent solo clock and
ammunition evaluation would still need reduction to a fixed-size numerical
expression under the ratified completion criterion. No new mathematical
searches outside this bounded branch were performed.

## Follow-up: a proved scalar guard in a uniform budget interval

This is an ordinary deduction from the already proved ammunition recurrence
and collar gap bound. It establishes the SECOND candidate hypothesis only
in the interval below. It does not prove the credit condition or the scalar
midpoint criterion there. Independent review by the parent is requested.

**Proposition.** For b>=2, every odd n>=2b+1, every budget
b+2<=m<=2b, and either secondary color q, put

    c=ceil((C_q-m)/2).

At the actual precentral layer, whenever the solo gap delta is positive,

    mu_q(c)-c >= m >= delta+1.

**Proof.** Since C_q>=M>=2b(b+1), one has c>=b^2. Write
sigma_p(k)=L_p(k)-k for positive k and H_p(k)=mu_p(k)-k. The accepted
ammunition recurrence is equivalently

    H_p(k)=sigma_p(k)+H_(1-p)((k+sigma_p(k)-m)_+).

For k>=b^2, both sigma_p(k)>=b. Hence the first predecessor is at
least b^2+b-m>=b(b-1)>0. At every k>=b(b-1), both phase surpluses
are still at least b: R(k)>=b because b(b-1)>(b-1)^2, and
Q(k)>=b because k>(b-1)(b-2). Thus the first two positive recursion
terms contribute at least 2b. Consequently H_q(c)>=2b>=m. The accepted
precapture collar bound gives delta<=m-1. This proves the assertion.
The b=2 endpoint m=4 is included. The b=1 interval is empty. QED.

The proof actually needs no information about the precise solo orbit
beyond its already proved gap bound. In this whole budget interval the
remaining barrier task is the first, history-dependent credit condition.

### A fixed-size sufficient certificate for the scalar guard

The same recurrence yields a uniform arithmetic lower bound, avoiding an
evaluation of mu. For any integer 1<=r<=b with z=(r-1)^2+1<=c, let

    B_r(c)=r*(1+floor((c-z)/(m-r))).

Then H_p(c)>=B_r(c) in both phases. Indeed, as long as a recursion state
is at least z, its surplus is at least r, and its predecessor is at least
the current state minus m-r. The first 1+floor((c-z)/(m-r)) states
therefore stay at least z, each contributing at least r. Here m-r>0
because m>=b+1. This proves the lower bound without assuming a favorable
phase or an affine recursion branch.

Consequently B_r(c)>=m is a sufficient numerical guard for every actual
solo layer. A bounded-operation choice, with no optimization over r, is

    r=min(b,ceil(sqrt(c/3))).

This r is positive and satisfies z<=c. Choosing r=b instead is also
admissible when c>(b-1)^2 and is useful near the minimum budget. These are
certificates for the proposed guard, not a bounded formula for capture
time. The 249 earlier scalar rows were checked against the first fixed
choice: the lower bound was never larger than the exact ammunition
excess and certified 141 rows. The exact ammunition with the coarse gap
had certified 151 rows. Neither check proves the remaining cases.

### What the direct solo attack did not establish

The proper lower-corner inverses are 1-Lipschitz, so the phase gap can
increase by at most one per step there. A paired affine step preserves
it. This does not extend through the reflected end: those inverse maps
are expansive, and dropping their additional growth would be an invalid
proof. No bound using only the number of early corner steps has been
proved here. A phase coupling through this final reflected portion remains
the missing ingredient for the unproved all-budget scalar margin.

A small scalar-only diagnostic, with no joint frontiers, inspected 15,525
instances: b=3,...,25, every intermediate budget, and lengths w,w+2,3w.
It took 4.709 CPU seconds. Two tempting replacements for the proved
m-1 gap bound fail on actual solo trajectories:

- delta<=b fails at w=n=11,m=7: L=24 and delta=6>b=5.
- delta<=4b^2/(2m-w) fails at w=49,n=51,m=265: delta=5,
  while 4b^2/(2m-w)=2304/481<5.

No delta>b+1 occurred in that diagnostic, but delta<=b+1 remains an
unproved conjecture and is not used. Even that inequality by itself would
not settle the scalar guard near quadratic budgets, where a single
ammunition surplus can be smaller than b+1. Thus merely guessing a
uniform width bound would not finish this route.

## Independent review of the root-saturation construction

As a separate, read-only assignment, the parent asked for an attack of
`research/resumed-root-saturation-proof.md`. I found no mathematical gap
in either parity case. The review checked ideal extension after adding
all bottom roots, clipped erosion and its exact loss, the q>=1 endpoints,
the sizes of all enlarged envelopes, phase parity of the odd-width rank,
and reversal of the two preparation halves. It did not rerun the parent's
2,915 physical cases or produce Lean verification.

Two endpoint calculations make the construction easier to audit. For odd
width, s<=2k-2r-2 implies J(s)<=k: an even positive residue has terminal
size at most k-r-1 and surplus at most r+1; an odd residue has terminal
size at most k-r-1 and surplus at most r. Every intermediate rank is at
most 2h-2k, so its terminal survivor size plus k is at most h. For even
width, J(s)<=s+r<=k-1 when s>0. These checks support the construction's
claimed upper bounds; no optimality conclusion is supplied by this review.

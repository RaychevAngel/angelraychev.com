# Uniform rectangle optimal-time investigation

12 September 2026. This lane studies a possible general serial-cohort
normal form and exact corner inequalities. The uniform one-day determination in §4 is proved and independently reviewed. A complete all-rectangle optimal-time classification has not yet been proved. The existing complete odd-rectangle
profiles and full-budget results remain the antecedents.

## 1. Why a local serial-exchange theorem is false

A serial strategy gives the entire budget to one initial cohort until it
can be finished, uses spare inspections on that finishing day on the other,
and then spends the entire budget there. Optimize the initial first cohort.
Prior work found no discrepancy between this rule and the full initial-state
optimum on a broad finite catalogue of odd rectangles. This remains evidence,
not a general theorem.

Two new exact counterexamples delimit any attempted induction.

* On the genuine 7 × 7 grid at budget four, canonical current-color counts
  (7,7) have exact remaining time 20, while both serial orders require at
  least 22. Its first quota pairs are (3,1), (0,4), (4,0), after which one
  cohort has disappeared. This state is not reachable from the full board;
  one count is not even a neighborhood-profile image.
* On the same grid at budget six, canonical counts (8,8) have exact remaining
  time five, while either serial order needs six. This state **is** in both
  profile-image domains and is reachable from the full board. Its shortest
  arrival is 18 days, while the entire full-board optimum is 16. Thus a
  reachability restriction alone does not repair the proposed local theorem;
  a global optimality or slack condition is needed.

The exact profiles, shortest arrival and continuation witnesses are in
`uniform-rectangle-partial-counterexample.json` and
`uniform-rectangle-reachable-counterexample.json`. The algorithms enumerate
only the proved exact two-count recurrence, not arbitrary physical subsets.

An additional abstract-profile attack exhausts all generated symmetric,
unimodal minority-surplus profiles with separated unit rises and dual
majority increments at most two for minority sizes 6 through 30. There are
2,727 profile pairs and 58,940 tested feasible budget pairs, with no
full-initial-state serial counterexample. This says nothing about arbitrary
physical graphs; these are abstract dual profiles. See
`uniform-rectangle-serial-abstract.json` and
`src/uniform_rectangle_serial_attack.py`.

## 2. A uniform inverse-profile concentration lemma

The following ordinary lemma has been independently audited by root and Euler.
It proves the endpoint-allocation inequality proposed independently by
Euler's deficit-dynamics investigation, with a stronger explicit exception.
It does **not** by itself prove serial optimality.

Let the rectangle have odd sides 2a+1 ≥ 2b+1 ≥ 3, with color sizes E and
M=E−1. Write g_0,g_1 for its proved majority/minority neighborhood profiles,
and

    I_p(z) = max{k : g_p(k) ≤ z}.

Thus I_0 has domain [0,M] and I_1 has domain [0,E]. Put
R(z)=ceil(sqrt(z)) and q(z)=Q(z)−1, where Q(z) is the least integer r≥1
with z≤r(r−1). The complement-inverse identity gives

    I_0(z)=z−A(z),
    A(z)=min(q(z), b, q(M−z)),                   0≤z<M,
    I_0(M)=E,

and

    I_1(z)=z−B(z),
    B(z)=min(R(z), b+1, 1+R(E−z)),             0≤z≤E.

In particular I_0(0)=I_1(0)=I_1(1)=0. All inverses are nondecreasing.

**Lemma.** If x,y≥0 and S=x+y≤M, then

    I_0(x)+I_1(y) ≤ I_0(S).                    (1)

If additionally x≥2, then

    I_1(x)+I_0(y) ≤ I_1(S).                    (2)

When x=0 or 1, the first summand in (2) is zero instead.

**Proof of (1).** First A is subadditive below M. The function q is
subadditive: if u≤r(r+1) and v≤s(s+1), then
u+v≤(r+s)(r+s+1). If a minimizing branch of A(x) or A(y) is the cap b,
then A(S)≤that term. If it is the reflected branch q(M−x), then
A(S)≤q(M−S)≤q(M−x), and similarly for y. Otherwise both minimum branches
are the lower q branches, and q-subadditivity applies. Moreover B(y)≥A(y):
its three candidates dominate respectively q(y), b, and q(M−y).
Thus A(x)+B(y)≥A(S), proving (1) for S<M. If S=M and x<M, both terms
I_0(x)≤x and I_1(y)≤y, so their sum is at most M<E=I_0(M); the endpoint
x=M,y=0 is equality.

**Proof of (2).** Since x≥2 and S≤M, y<M. If the cap b+1 or reflected
branch 1+R(E−x) minimizes B(x), monotonicity of that reflected branch
or the cap gives B(S)≤B(x), and the desired cost inequality follows.
It remains to take B(x)=R(x), which is at least two.

If A(y)=q(y), put r=R(x)≥1 and s=q(y). Then x≤r², y≤s(s+1), and

    x+y ≤ r²+s(s+1) ≤ (r+s)².

(The final inequality is s≤2rs.) Therefore
B(S)≤R(S)≤R(x)+q(y).
If A(y)=b, then R(x)+b≥b+1≥B(S).
Finally take A(y)=q(M−y)=Q(z)−1, with z=M−y≥x. Since
z+1−x≤z and R(z)≤Q(z),

    B(S) ≤ 1+R(E−S)
         = 1+R(z+1−x)
         ≤ 1+Q(z)
         ≤ R(x)+Q(z)−1.

This proves all branches. For x=0,1 the separate assertion is immediate
from I_1(x)=0. ∎

**Corollary (endpoint allocations from one full cohort).** Let d≥0,
m≥0, d+m≤M, and 0≤r≤m. Then

    I_p(d+r)+I_(1−p)(m−r)
       ≤ max(I_p(d+m), I_(1−p)(m)),           p=0,1.

For p=0, (1) even bounds the left side by the first term alone. For p=1,
apply (2) when d+r≥2. Otherwise I_1(d+r)=0, and monotonicity bounds
I_0(m−r) by I_0(m). No feasibility or lower-budget assumption is needed.

This rigorously says that, before the total deficit plus the daily budget
reaches the smaller color capacity, the largest **total next deficit**
from a state with one full cohort is attained by an endpoint allocation:
continue the prepared cohort or give all inspections to the other. It is
not a statement about the minimum remaining capture time, and replacing
that objective by total deficit would be an unjustified step.

## 3. Failed shortcuts and the current proof gap

The full max-convolution of I_0 and I_1 is maximized by endpoint deficits in
all bounded tests tried, but using that maximum as a one-counter recurrence
is far too optimistic: it changes the best physical parity on every day.
For example it predicts six days on 3 × 3 at budget two, whereas the true
answer is ten. Any valid recurrence must retain this temporal information.

The stronger inequality I_0(x)+I_1(y)≤I_1(x+y−1), even when both terms are
positive, is false: on 5 × 5 take x=2,y=4. The left side is three while
the right side is two. Hence a one-unit rounding slack does not automatically
absorb arbitrary parity switches.

Euler is independently deriving exact solo and serial times from two finite
corner transit tables plus the affine middle. The missing global theorem is
that one of those serial strategies is optimal from the full rectangle,
or a replacement recurrence that retains the necessary joint corner state.
Root is independently investigating separable potential/charge certificates.

## 4. A uniform one-day determination of the full optimum

**Ordinary theorem, independently audited and accepted by root and Euler.** On every odd rectangle,
let τ be the least full-budget capture time for either one initial parity
cohort. If τ is finite, then

    2τ−1 ≤ T_m ≤ 2τ.                           (3)

This statement holds for every budget, without a width-dependent high-budget
threshold. It does not assert serial optimality. The two possibilities can
be distinguished by the existing exact two-count algorithm, but a uniform
closed criterion for the remaining bit is not proved here.

### Solo capacity definitions

Write C_0=E and C_1=M. Let D_p(t) be the maximum number of missing rooms in
current physical color p after t inspection-and-movement steps, when all
m inspections on every day have been directed at the initial cohort that
occupies color p at time t. The other cohort stays full. These are exactly

    D_0(0)=D_1(0)=0,
    D_0(t+1)=I_0(min(M,D_1(t)+m)),
    D_1(t+1)=I_1(min(E,D_0(t)+m)).              (4)

The compatible minimizing profiles attain these values physically, and
monotonicity proves their individual optimality. Thus τ is the first t
with D_0(t)=E or D_1(t)=M.

For any arbitrary physical strategy, let d_p(t) be its deficit in physical
color p after the same t inspection-and-movement steps, starting from the
full board. Always d_p(t)≤D_p(t): allocating the whole budget to that
cohort minimizes its survivor belief, independently of the other cohort.

### Exact concentration before the first possible cohort capture

For every t<τ,

    d_0(t)+d_1(t) ≤ max(D_0(t),D_1(t)).        (5)

The right side is attained by a full-budget solo strategy, so this is an
exact prescribed-day minimum-total-belief theorem in that time range.

Induct on t. Put D_p=D_p(t) and C'_p=D_p(t+1), and assume t+1<τ. Since
I_0(M)=E, C'_0<E implies D_1+m<M. Also I_1(z)<M for z<E, while I_1(E)=M;
C'_1<M implies D_0+m<E, hence D_0+m≤M. Consequently

    max(D_0,D_1)+m ≤ M.                       (6)

Let the actual current deficits be x=d_0(t), y=d_1(t), and let current
color-zero/one useful allocations be p,q, with p+q≤m. Define X=x+p,
Y=y+q. The arbitrary-support profile lower bounds and complement duality
bound the new deficits by

    d'_0 ≤ I_0(Y),   d'_1 ≤ I_1(X).

There is no saturation ambiguity because X+Y≤max(D_0,D_1)+m≤M.

If D_1≥D_0, inequality (1) gives

    d'_0+d'_1 ≤ I_0(X+Y) ≤ I_0(D_1+m)=C'_0.

If D_0>D_1 and X≥2, inequality (2) gives instead

    d'_0+d'_1 ≤ I_1(X+Y) ≤ I_1(D_0+m)=C'_1.

If X=0 or 1, then I_1(X)=0, and the individual bound y≤D_1 gives
I_0(Y)≤I_0(D_1+m)=C'_0. These cases prove (5). Notice that no permanent
ordering of D_0 and D_1 is assumed: their order can cross in both corners.

### Lower bound by time reversal

The case τ=1 is immediate. Suppose τ≥2, set L=τ−1, and assume for a
contradiction that a full search finishes within 2L days. Pad the end by
empty inspection sets if necessary, giving a winning 2L-day schedule.

Process its first L inspection sets forward, including the move after
its Lth inspection. This gives a possible-position set B on day L+1.
By (5), its deficit is at most max D_p(L)≤M, so |B|≥E.

Now process the last L inspection sets backward in time, using the
undirected edges. Perform only L−1 complete inspection-and-movement
steps, then the Lth inspection without its final move. The resulting
survivor set R is also located on day L+1. Before that last reverse
inspection its total deficit is at most max D_p(L−1), by (5). Removing
at most m more vertices gives deficit at most max D_p(L−1)+m≤M by (6),
applied to the noncapturing solo time L. Therefore |R|≥E.

Since |V|=2E−1, the sets B and R intersect. A vertex in their intersection
has a forward avoiding walk through the first L inspections and a backward
avoiding walk through the final L inspections. Concatenating them gives a
walk avoiding the whole schedule, a contradiction. Thus T_m≥2τ−1.

### Upper bound by reflecting the solo schedule in time

Take a winning τ-day solo schedule A_1,…,A_τ for one initial parity p.
Use the 2τ-day full schedule

    A_1,…,A_τ, A_τ,…,A_1.

The first half captures every walk starting in parity p. A walk starting
in the opposite parity that avoids the first half has, at the start of
the second half, parity p+τ−1 modulo two. Reversing its final τ vertices
therefore gives a walk of initial parity p avoiding A_1,…,A_τ, impossible.
Each day's budget remains at most m. This proves the upper bound in (3).

This upper construction uses time reversal, not an unproved claim that a
second greedy sweep always has the same length or phase.

## 5. The remaining central-day criterion

Experiments suggest the complete formula is

    T_m = 2τ−1  if m ≥ E+M−D_0(τ−1)−D_1(τ−1),
          2τ    otherwise.                    (7), CONJECTURAL NECESSITY.

The short strategy in the first branch is explicit: prepare one physical
color optimally for τ−1 steps on the left, and the other physical color
optimally for τ−1 reversed steps on the right. At the central day their
intersection consists of exactly the two solo residual sets and has the
size displayed in (7). The complementary colors keep those residuals
separate. Thus the displayed inequality is sufficient.

It matches the serial answer on 2,772 freshly checked odd-rectangle/budget
pairs, but necessity does not follow from (5). The gap between the two
solo deficits can be substantial. On 41 × 39 with m=24, τ=97 and the
precentral capacities are (793,774): the basic cardinal lower requirement
is 13 inspections, while the residual-sum condition needs 32. This is a
19-cell gap, not a universal one- or two-cell rounding issue.

Nor is the claimed intersection lower bound valid without a budget
qualification. On 3 × 3 with m=3, τ=2 and precentral capacities (2,1),
two reflected halves preparing the same color can have central
intersection size five, below the residual sum six. Both still exceed
the budget three. The missing assertion is therefore a conditional one:
if two attainable precentral beliefs have intersection at most m, then
opposite-color solo preparations also attain an intersection at most m.

### An exact midpoint optimization, without a serial assumption

The remaining bit has the following rigorous finite reduction. It was
independently recovered and audited by Euler; unlike (7), it makes no
unproved claim about the shape of an optimal strategy.

Let F_L be the set of attainable **canonical deficit pairs** after
L=τ−1 inspection-and-movement steps, starting from the full board. It is
computed by the exact two-count recurrence, or equivalently by retaining
the componentwise maximal deficit pairs at every layer. Define

    C_L = min_{d,e in F_L}
          [max(0,E−d_0−e_0)+max(0,M−d_1−e_1)].             (8)

Then

    T_m=2τ−1  if and only if C_L≤m;
    T_m=2τ    otherwise.                                 (9)

**Necessity.** Cut any winning (2L+1)-day schedule before its central
inspection. Its first L inspections and moves leave a forward belief F.
Reading its final L inspections backward, also with L complete moves,
leaves a reverse belief R on that same central day. All vertices of
F∩R must be inspected centrally: otherwise concatenate an avoiding walk
from each half. In each physical color p, elementary inclusion-exclusion
gives

    |F_p∩R_p| ≥ max(0,C_p−d_p−e_p).

For arbitrary physical half-schedules their useful daily color quotas
are dominated, with no later capture time, by the proved compatible-prefix
recurrence. Its canonical deficits d',e' dominate d,e componentwise.
Consequently C_L≤the displayed sum≤|F∩R|≤m.

**Sufficiency.** Realize the canonical forward half for d by prefixes in
the fixed diagonal order. Realize the reverse half for e by reflecting
its canonical construction through both coordinates. On an odd rectangle
this reflection preserves each physical color and reverses its order.
Thus its survivor beliefs are suffixes, and the forward-prefix/reverse-
suffix intersection in color p has exactly max(0,C_p−d_p−e_p) vertices.
Inspect this intersection on day L+1. Any avoiding full walk would have
to visit it on that day, which is impossible. Reversing the chosen reverse
half turns it into the actual final L inspections, with every quota still
at most m. This constructs the required (2L+1)-day schedule.

Taking the two solo deficit pairs (D_0(L),0) and (0,D_1(L)) in (8)
recovers the sufficient criterion (7). Formula (8) is an exact midpoint
tradeoff optimization; evaluating it only from the two solo capacities
is the separate unresolved conjecture. It does not establish that all
optimal half-schedules concentrate their inspections on one cohort.

The executable implementation is `src/uniform_rectangle_midpoint.py`.
It keeps the exact Pareto frontier only through time τ−1, then evaluates
(8) in O(K log K), where K is the last frontier size. To see this bound,
sort the surviving belief pairs (a_j,b_j) by increasing a_j, hence strictly
decreasing b_j. For fixed (a_i,b_i), the indices where both positive-part
terms in (8) are positive form an interval. Within it, only the minimum of
a_j+b_j is needed; outside it, monotonicity leaves its two adjacent boundary
indices. Binary search plus a range-minimum tree gives the stated bound.
Stored predecessors reconstruct both physical half-schedules. If the cut
is too expensive, the implementation emits the solo/time-reversal upper.

The receipt `uniform-rectangle-midpoint-witnesses.json` records 16 selected
cases including infeasibility, the one-day endpoint, both nontrivial time
branches, and the previously difficult 41×39,m=24 example. Every finite
witness was replayed on the actual coordinate graph. The range-minimum
routine was also compared with the literal pair minimum on 204 selected
frontiers. These are implementation checks, not a replacement for the
ordinary theorem above.


## 6. Independent audit and the current central-pair target

Root and Euler independently accepted the inverse inequalities and the
uniform half-time theorem. Euler's durable review is
`research/uniform-odd-solo-bound-independent-review.md`; its independent
checks cover 1,254 inverse inequalities and 144 exact full-time cases.
The present lane's receipt `uniform-rectangle-half-time.json` records
102,832 inverse pairs and 2,772 solo/serial capacity comparisons.

A potentially sufficient strengthening at t=τ−1 is the following **unproved**
two-copy deficit inequality. For any two independently attainable deficit
states (x,y),(u,v) at that time, conjecture

    min(E,x+u)+min(M,y+v) ≤ max(E,D_0(t)+D_1(t)).

This allows the harmless same-color intersection improvement on 3 × 3.
When m<M, a successful central cut needs union deficit at least N−m>E,
so the conjectured inequality would force the residual-sum criterion.
A targeted exact check passed 340 parameter pairs and 2,758,382 state pairs,
with no counterexample; see `uniform-rectangle-central-pair-attack.json`.
This is evidence only, and no further broad catalogue is needed.

A triangular time-dependent invariant is too strong. At 17 × 17,m=12,
a solo-capacity pair (53,51) occurs at time nine; the next pair is (55,56).
The attainable state (53,0), followed by allocations (10,2), gives (1,55),
which lies outside the triangle joining (55,0) to (0,56), even though its
total 56 obeys the proved concentration bound. Nor do the two bottom-corner
phase maps have a fixed commutation order: at b=3,m=4,x=2, writing
F=I_0(·+m),G=I_1(·+m), one has F(G(x))=4<5=G(F(x)). These failures explain
why the accepted proof splits cases dynamically instead of assuming one
permanently faster parity.

## 7. Additional exact restrictions on a high-total mixed interval

The following deductions from the accepted inverse inequalities isolate
where the remaining joint-history issue lies. They are ordinary lemmas;
they do not by themselves prove the capped two-copy conjecture.

**Persistence below the smaller solo deficit.** Suppose t+1<τ and an
attainable state has total deficit at most min(D_0(t),D_1(t)). After any
legal step, if the new minority deficit is positive, the new total deficit
is at most min(D_0(t+1),D_1(t+1)). Indeed, in the notation of §4, positivity
of I_1(X) implies X≥2. Both inverse concentration inequalities apply, with
common argument X+Y≤min D_p(t)+m. Their two bounds are respectively at most
I_0(D_1(t)+m) and I_1(D_0(t)+m). Thus a mixed state cannot first rise above
the smaller solo deficit from a state below it. A new high-total episode
must pass through a pure-majority deficit state.

**Interlacing and the phase change.** For 0≤k≤M the explicit root profiles
give

    g_0(k) ≤ g_1(k) ≤ g_0(k)+2.

For the upper inequality compare the three profile branches: Q(k)≤R(k)+1,
b+1≤b+2, and Q(M−k)≤R(E−k)+1. The lower inequality follows from the
opposite branch comparisons R(k)≤Q(k), b≤b+1, and
R(E−k)−1≤Q(M−k). Consequently

    I_1(z)≤I_0(z),                    0≤z≤M,
    I_0(z)≤I_1(z+2),                 0≤z≤M−1.

The exceptional full endpoint I_0(M)=E is deliberately excluded from
the second inequality. Before τ its argument is always proper.

If D_1(t)≥D_0(t), then D_0(t+1)≥D_1(t+1). If instead
D_0(t)−D_1(t)≥2, then D_1(t+1)≥D_0(t+1). Thus the fastest initial
cohort cannot change except at a tie or a majority advantage of one.
More precisely, when D_0(t)=D_1(t)+1 and z=D_1(t)+m, complement duality
gives

    D_0(t+1)−D_1(t+1)
      =1−[g_1(M−z)−g_0(M−z)] ∈ {−1,0,1}.

If D_0(t)>D_1(t) but D_0(t+1)>D_1(t+1), every new mixed state is below
the smaller next solo deficit: inequality (2) bounds its total by
I_1(D_0(t)+m)=D_1(t+1). Hence a change in the fastest initial cohort
erases the exceptional high-total mixed states; a new episode again has
to start from a pure-majority state.

An attempted local induction for the capped two-copy bound retains the
individual solo bounds, total concentration, and the old capped bound for
the input pair, both self-pairs, and their pairs with the two solo endpoints.
The complete relaxed input/quota checks near τ passed the focused cases
5×5,m=3; 7×7,m=4,5; and 9×9,m=5. This is only guidance for an algebraic
closure lemma. Such a lemma has not been proved, and the remaining bit is
still open in this note.

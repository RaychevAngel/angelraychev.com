# Independent review of the assembled cylinder manuscript

12 September 2026. Reviewer: the frontier/geometry research lane.

**Pass. No mathematical gap found in the assembled source.**

Reviewed `paper/sections/even-cylinder-eventual-time.tex`, all 777 lines,
with SHA-256

    699feb7c75eefc111517fc035f510eca6fbe5fd44cf9563fcefe6118c4f7c5d8

I checked the assembled statements and interfaces rather than treating
the earlier acceptance of the separate research notes as sufficient.
I also read the referenced SCC expansion/potential argument in
`paper/sections/hamiltonian-cylinder-time.tex` and checked the exact path
formula and the earlier odd-cylinder threshold used in the final union
of parity cases. This review is an ordinary mathematical review, not a
Lean verification or an independent typesetting review.

## Arbitrary-support geometry and efficiency

The even-order proof correctly passes from a spanning Hamiltonian
rectangle to Q: the rectangle boundary is at least b in the strict
middle, and the total boundary is exactly b, so the two boundaries agree.
The giant SCC argument then forces one deleted point per matched row.
The two-interval difference bound is valid for all row possibilities,
including empty and full-except-one rows. Its propagation excludes the
degenerate rows and mixed prefix/suffix orientations. Alternating rung
directions give the cut-distance bound and its endpoint condition.
Additional Q edges can only filter these forms.

The clipped potential equality truly forces all m useful inspections
onto one owner and its residual into the strict middle. Neither clipping
endpoint introduces an unclassified equality case. The untouched mate
has constant potential, and strong connectivity of the matching
contraction gives strict growth of every proper nonempty support.
The at-most-two-owner-block argument and the collar transients therefore
justify the stated polynomial bound on nonclean days. This does not
assume a frontier normal form for arbitrary strategies or initial sets.

For odd order and even length, I checked the different matching
convention. The paired graph has bidirectional Q edges and opposite
one-way longitudinal flows. A boundary of at most b either yields the
giant SCC or consists of exactly one point on each minority fiber.
The middle-size condition forces both occupied and empty positions in
every fiber. This prevents the apparent internal-hole alternative and
gives the minimum frontier. The next opposite-phase minimum frontier
would contain the missing far endpoint, ruling out consecutive b costs.
The b+1 containment bridge exhausts the boundary on the other color and
again excludes all hidden holes. Both arguments are for actual supports.

The history bit has the correct before-inspection and after-survivor
timings. Its raw loss, clipped loss, equality cases, and the survivor
rank 2r-e are consistent. Proper untouched supports still have strictly
increasing rank if the old bit drops. The full/empty mate condition is
therefore obtained with the stated cleanup bound. The actual physical
height sum differs from 2r-e by a constant, as required at the interface
to the common height lemma.

## Physical protection and the direct replacement

The marking step includes both the cut positions at the start of every
nonclean block and every actual inspection column within that block.
This is essential: cardinality information alone would not prevent
remote holes. The enlarged radius dominates the block length, front
width, and one-step shift between a preceding survivor and the next
belief. Local empty preservation uses finite propagation; local full
preservation uses the correct matching, transverse in the even-order
case and inside a column pair in the odd-order case.

The gap count includes the extra trimming margin on both ends. A clean
block whose endpoint statuses agree cannot enter the retained interval:
the monotone mean and bounded width keep any rowwise wiggle in the
discarded margin. A block cannot change empty to full across that band.
Together with the unchanged status through nonclean blocks, this gives
one complete crossing per initial cohort, in disjoint owner blocks with
a globally empty/full mate.

The conversion to physical cutoff heights accounts for all Q edges.
The descent proof is valid at every step, uses exactly mt flips, and
keeps each intermediate height configuration edge-compatible. Uniform
movements commute with the flip tests. The completed-day mean and the
partial-day extra unit bound all physical operations inside the stated
interval. Thus the lemma supplies actual distinct top-room inspections,
not merely a count recurrence.

The new duration allowance U contains K0+ell0. Its corresponding mean
travel contains at least Delta in physical coordinates (or delta in
paired coordinates), since the travel of ell0 days is exactly that
displacement. This checks the explicit W claim that the endpoint fronts
lie on opposite sides of a central deletion interval, in addition to
the longer-path and outer-margin requirements. The added width v covers
the conversion between matched cuts and actual physical heights.

Deleting Delta columns maps a left crossing's endpoints to a-Delta and
b. Their phases and sum difference match t-ell0 days exactly. The
direct endpoint lemma produces that path, and its mean/range bound keeps
it inside the shorter cylinder. Insertion has the reverse endpoint
shift. Reflected coordinates give the suffix case because the shorter
reflection origin changes by the same even Delta. These are translations
of cuts with filled/empty tails, not translations asserted to be graph
automorphisms of a finite path.

Every retained nonclean state is uniform near the join, and all other
retained clean frontiers are on one side of it. Their neighborhoods
therefore commute with the natural column map. The mate's full/empty
state survives the even temporal shift. Survivor edges count the
following inspection, so the total time change is exactly twice ell0,
with no omitted or double-counted inspection day.

## Threshold, parity union, and proof boundary

The explicit thresholds ensure the strict clipping guard, enough raw
gap length, and the corresponding properties after contracting by the
chosen displacement. Replacing the old finite-state bound by
K0+ell0+4 is justified by the direct endpoint construction. The displayed
O((A+m+1)^9) estimate follows from the actual parameter formulas; it is
a conservative polynomial sufficient bound, not a sharp onset claim.
The earlier odd-length box theorem has polynomial parameters after
Z<=A^2, so taking the maximum of parity thresholds retains this bound.

The singleton reduction agrees with the exact path formula: for m>=2,
adding 2(2m-1) preserves its exceptional congruence and parity correction
and increases the ceiling by four. The below-threshold impossibility
claim is the already established spanning-rectangle result. Both parity
branches give the same valid even period and increment.

The final scope statements are accurate. Q and m are fixed while the
longitudinal side grows; finite exception values, least periods, and a
simple all-finite-box formula are not supplied. The extension to general
odd-order Hamiltonian Q only covers even longitudinal lengths. The text
explicitly identifies these results as independently reviewed ordinary
proofs, with no complete Lean formalization claim.

One optional exposition improvement is to begin the odd-order physical
height paragraph with “For a left frontier, reflecting the cylinder for
the opposite orientation, ...”. The earlier reflected-coordinate
convention already supplies this meaning, so it is not a proof gap.

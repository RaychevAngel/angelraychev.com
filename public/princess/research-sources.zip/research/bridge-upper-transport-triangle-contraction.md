# Three inspections that contract a square corner triangle

13 September 2026. New ordinary uniform upper construction. Root proposed
checking the tiny transition appearing in the25x26 necessary path. Independent
literal replay found it physically feasible; the lower lane independently
gave another feasible arrangement of the same diagonal cuts. The formula
below is the direct rule extracted from this lane's rightmost legal-flip
witness. Independent proof review is pending.

Let `Q_r` be the full even-color corner triangle on diagonals
`0,2,...,2r-2`, of size `r²`. Work in a rectangle whose two side lengths
are at least `2r`, so all neighborhoods below fit without using its far
boundaries. Suppose

    r>=3,       k>=ceil((4r-1)/3).

Put `K=min(k,2r-2)`, `D=2r-2`, and `m=2K-2r`. Then
`r<=K<=2r-2` and `3K>=4r-1`. Starting from `Q_r`, use the following three
inspection sets, moving after each miss:

1. On diagonal `x+y=D`, inspect `0<=x<K`.
2. On diagonal `x+y=D+1`, inspect `K<=x<=D+1`; on diagonal `x+y=D-1`,
   inspect `0<=x<m`.
3. On diagonal `x+y=D`, inspect `m<=x<=D`.

Their sizes are respectively

    K,       (2r-K)+(2K-2r)=K,       4r-1-2K<=K.

After the third inspection, the survivor is exactly `Q_(r-1)`; after its
movement, the belief is exactly `N(Q_(r-1))`. In particular, the three-day
inspection-and-move transition is

    r² -> r(r+1)-K -> r²+2r-2K -> r(r-1).

The three inspections use exactly `4r-1` rooms in total.

## Proof

After the first inspection, the inner `Q_(r-1)` remains full, together with
the outer even-diagonal suffix `x>=K`. This suffix is nonempty because
`K<=2r-2`. Its neighborhood is the full odd triangle through diagonal
`D-1`, together with the odd-diagonal suffix `x+y=D+1, x>=K`. The latter
has `2r-K` rooms.

The second inspection removes that entire outer suffix and the first `m`
rooms on diagonal `D-1`. Its survivor is the full odd triangle through
`D-3`, together with the remaining suffix on diagonal `D-1`. This suffix
is still nonempty: `m<=2r-4`. Its neighborhood is exactly `Q_(r-1)` plus
the even-diagonal suffix `x+y=D, x>=m`. The third inspection removes
precisely that suffix. All inspected rooms are physically possible rooms
on their indicated day, and the stated quota inequalities complete the
proof. Reflections give the same construction at every board corner.

For `r=10,k=13` on25x26, the belief sizes are

    100 -> 97 -> 94 -> 90,

with survivors87,84,81 and exactly13 inspections on each day. Thus this
particular three-day segment in the lower model is physically attainable;
it is not a missing lower obstruction.

## Why this goes beyond the descending transport word

The same25x26 endpoints have descending-word virtual count47 and guaranteed
bottom-root credit3, so its exact fixed-word criterion would charge44
inspections against the available39. The alternate rightmost legal order
executes eight virtual flips while they are outside the physical board,
and uses only39 actual inspections. The directly specified diagonal cuts
above remove the virtual representation entirely.

This does not contradict the fixed-word no-improvement theorem: the
accepted obstruction there concerns the descending word, not every legal
order. The present construction is uniform in its radius, budget and
rectangle sizes, but proves only this local transition. A full-board
attainment theorem still requires compatible arrival and exit histories.

## Evidence and reproducer

`src/bridge_upper_transport_triangle.py` constructs the three room sets and
independently computes their literal board neighborhoods. It audits every
quota in the stated nontrivial interval through radius32, plus larger
budgets and non-square boards. The receipt is
`research/bridge-upper-transport-triangle-contraction.json` and includes
the exact25x26 inspection sets. The earlier generic priority experiment
is retained as `research/bridge-upper-transport-triangle10-to9-priorities.json`.

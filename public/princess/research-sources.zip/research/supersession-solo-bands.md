# Uniform arithmetic evaluation of a solo rectangle search

13 September 2026. Ordinary proof proposed by root; independent review required.
This evaluates the exact already-proved solo dynamics. It does not assert the
unproved two-cohort midpoint necessity. No manuscript theorem is changed yet.

Let an odd rectangle have w=2b+1<=n odd, b>=1, E=(wn+1)/2, M=E-1,
C_0=E,C_1=M and feasible budget m>=b+1. Use the proved exact g_p and I_p.
Put f_p(k)=g_p((k-m)_+). A cohort currently in color p moves to color 1-p
with this count. Thus the two-day map on its original color is

    P_p(k)=f_(1-p)(f_p(k)).

## 1. O(b) explicit translation intervals

On positive counts g_p(k)=k+s_p(k). All changes of s_p are contained in
these sets of left endpoints (discard endpoints outside [1,C_p]):

    B_0={r²+1:0<=r<b} union {E-r²:0<=r<=b},
    B_1={r(r-1)+1:1<=r<=b} union {M-r(r-1):1<=r<=b}.

Include 1 explicitly. Indeed, the first sets contain every change of the
capped increasing square/pronic root; the second contain every change of
the capped decreasing reflected root. Their minimum cannot change elsewhere.
There are at most 2b+1 endpoints for p=0 and 2b for p=1.

Extend I_p(z) to C_p when z>=C_(1-p). Define

    c_p=min(C_p,m+I_p(m)).

Precisely the starting counts k<=c_p disappear in at most two days:
f_p(k)<=m iff g_p((k-m)_+)<=m. For k>c_p all counts in the next pair of
steps are positive. The possible left endpoints of a translation change are

    m+s                                  (s in B_p),
    m+I_p(m+s-1)+1                       (s in B_(1-p)).

The second formula is the first k for which g_p(k-m)-m>=s, using monotonicity
and the attained inverse. Add c_p+1 and C_p+1; clip to that closed interval
and sort. Between successive endpoints l and u+1,

    P_p(k)=k-d,          l<=k<=u,
    d=2m-s_p(k-m)-s_(1-p)(g_p(k-m)-m).

Both surpluses are constant there. Since their sum is at most 2b+1,

    d>=2m-2b-1>=1.

Thus there are at most 4b+2 positive translation intervals. There is no
monotone-in-time shape assumption beyond the accepted compatible prefixes.
The same calculation evaluates the scalar lower relaxation on a canonical
partial starting prefix, where the solo problem itself is exactly attained.

## 2. A fixed-length composition of division operations

Process those intervals from highest to lowest. Start at any k<=C_p and T=0.
At interval [l,u] with decrement d, current k is at most u. If k<l do nothing;
otherwise the exact number of successive two-day steps whose source remains
in this interval is

    q=1+floor((k-l)/d).

Replace (k,T) by (k-qd,T+2q). The last source remains at least l and every
previous source does too; the next state is below l. It is still positive
because P_p is positive throughout this interval. Therefore this substitution
is exactly iteration, not a relaxation. After all intervals k<=c_p. Add zero
days if k=0, one if 0<k<=m, and two otherwise.

This is a composition of at most 4b+2 explicitly generated arithmetic maps,
each using one floor division. Its length depends only on the shorter width,
not on n, m, or the number of search days. The budget and length appear only
as integer inputs to the maps. All roots are integer square roots. The current
implementation sorts endpoints in O(b log b) comparisons; the two individually
ordered endpoint lists can also be merged. Integer bit costs are separate.

The same segments evaluate the exact count at any prescribed day: truncate
the number of pairs taken in the segment, and apply f_p once if the requested
time is odd. For the full-board half-time theorem, compute the two solo
lengths, take their minimum tau, and evaluate each at tau-1. This obtains the
proved two consecutive possibilities and the sufficient short-time test in
O(b) band stages, independent of the number of rooms along the long axis.

## 3. What it adds and what it does not

This is an exact arithmetic evaluation of the SOLO recurrence at every budget,
including multiple square/pronic corner layers below b²+1. It preserves
constructive prefix searches and arbitrary canonical solo starting counts.
It makes the existing uniform one-day theorem usable without constructing
all profiles or traversing every day. It is not a closed full-game time formula:
the two-copy midpoint necessity remains unproved, and no unknown scalar test
has been silently substituted for the exact midpoint optimization.

The executable src/supersession_solo_bands.py implements these explicit bands.
Initial checks compared 3,672 rectangle/budget pairs with independently
array-built profiles and day-by-day solo capacities, plus all 27,610 partial
solo starts in the selected small-width cases. They passed; the largest
observed positive paired partition had 47 bands. A separate review is pending.

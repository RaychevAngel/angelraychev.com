# A height-function strategy for arbitrary bipartite cylinders

12 September 2026 UTC. Derived during the all-in research block and
independently attacked by the frontier agent. No literature-priority claim.

## General feasibility bound

Let H be a finite bipartite graph with A>=1 vertices, and let n>=2.
Then

    h(H square P_n) <= floor(A/2)+1.

The strategy is explicit and applies to every starting room. It does not
assert optimal capture time. Connectedness of H is not necessary for the
cyclic version below.

Give H a bipartition c(v) in {0,1}. A single initial-parity cohort on the
cylinder has possible rooms (v,z), 0<=z<n, with c(v)+z=p+t modulo2 on day t.
Represent an upper bound on its belief by integer cutoffs a_v:

    (v,z) is possible only if z<=a_v,
    a_v = p+t-c(v) modulo2,
    |a_u-a_v|=1 whenever uv is an edge of H.

The initial full cohort has cutoff n-1 or n-2 in each fiber according to
parity. It therefore satisfies these conditions. Negative cutoffs mean
empty fibers; cutoffs above n-1 are harmless upper bounds. They are integers,
not restricted to the board.

### One virtual flip

At a local maximum v, replace a_v by a_v-2. Every neighbor previously had
cutoff a_v-1, so all adjacent differences remain exactly one. Record the
room (v,a_v) removed by this flip if it is inside the board. Repeated flips
in one fiber record distinct heights. A sequence of m virtual flips is
therefore implemented by at most m simultaneous actual inspections.

Let a' be the cutoffs after these flips. Every actual surviving room is
below a'. After the compulsory move, the new belief is bounded by

    b_v = a'_v+1.

A horizontal-in-the-cylinder move changes z by one. A move along uv in H
has z<=a'_u<=a'_v+1. Both kinds of movement therefore obey the bound, with
the correct opposite parity. Adding one everywhere also preserves the
edge-difference condition.

Thus each full day decreases the sum of cutoff heights by

    delta = 2m-A.

When delta>0, this suggests capture. The following choice of flips makes
the termination argument uniform even if H is disconnected.

### A fixed cyclic flip order

Initially one color class of H has the higher cutoff. List all vertices
of that class, then all vertices of the other class, with arbitrary order
inside each class. Repeat this A-letter word indefinitely, taking the next
m letters each inspection day.

Every flip is legal: while the higher color class is being flipped, its
unflipped vertices are above all their neighbors; after the whole class
has been flipped, the other class is higher. One complete word lowers
every cutoff by two. The uniform increase by one after each day changes
none of these comparisons. This remains true for empty color classes and
isolated vertices of H.

After t days, every vertex has been flipped at least floor(mt/A) times.
Consequently

    max_v a_v(t) <= n-1+t-2 floor(mt/A)
                  < n+1-t(2m-A)/A.

If m>A/2, the right side eventually becomes negative. For example

    L = ceil(A(n+2)/(2m-A))

days suffice to clear one initial cohort. All actual beliefs are empty
once every cutoff is negative. Since the cylinder has no isolated vertices,
this certifies capture during the inspections, not disappearance at a dead end.

Clear the two initial cohorts sequentially, initializing the second phase
to a full bound on its then-current physical parity. This gives a full-board
strategy of at most 2L days. Earlier termination can be detected by replaying
the finite cutoff recurrence; the displayed bound is intentionally coarse.

An alternative strategy always flips any local maximum. When H is connected,
the edge condition gives range at most diam(H). Negative total drift then
proves termination with a different explicit potential bound. The cyclic
word version is simpler and requires no diameter computation.

## Complete feasibility on 3 by 3 by n

For n>=3, the graph contains the 3-by-3-by-3 cube as a subgraph, so its
hunter number is at least five by the separately proved seven-room trap.
Taking H=P_3 square P_3 gives A=9, and the height strategy uses five probes.
Therefore

    h(P_3 square P_3 square P_n) = 5,   n>=3.

The remaining positive lengths are h=2 at n=1, by the square-grid theorem,
and h=4 at n=2, by the already proved length-two prism theorem. Thus this
entire cylindrical family has a complete feasibility classification.

The n=3 lower and upper result is fully verified in Lean. The general
height construction and unbounded-cylinder consequence currently have
ordinary proofs and independent review, not full Lean verification.

## Computational evidence and limits

The unrestricted one-cohort solver also confirms feasibility at five probes
on 3 by 3 by 4, with exact single-cohort times eighteen and eighteen. Those
numbers do not establish the optimal full-board time. They motivated the
extension, but the unbounded height proof does not depend on that search.

The direct cylinder strategy is replayed independently on physical adjacency
by src/cylinder_height_strategy.py. Its verification receipt records the
tested dimensions and budgets. Finite replay is an implementation check;
the cutoff invariant above proves validity for arbitrary n.

For any rectangular box, choosing its longest axis as P_n yields the general
upper bound floor(product of the other side lengths/2)+1. This can be loose
for short cylinders, including hypercubes. The stronger existing theorem
for a side of length two should still be used where applicable. No general
box feasibility equality or minimum-time formula follows from this upper
bound alone.

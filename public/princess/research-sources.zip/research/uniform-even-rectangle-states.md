# Uniform even-rectangle states: a promising pyramid normal form, not yet proved

12 September 2026. This is a research note, not an addition to the accepted
classification. No manuscript, website, or Lean source has been changed.

## 1. Target and boundary

Let G=P_w □ P_n, with coordinates 0≤x<w, 0≤y<n. The most promising
current conjecture is:

> If w is even and w≤n, every strategy from a downward-pyramidal support
> can be replaced, with no increase in any prescribed daily quota, by a
> strategy whose survivors are downward pyramids facing y=0.

The two initial parity cohorts would then be normalized independently,
which preserves the shared daily budget. This would give a uniform exact
recurrence with O(n²4^w) pairs of states, rather than 2^(wn) subsets.
It would still require evaluation of the recurrence to obtain a simple
closed time formula. The conjecture is NOT a theorem at present.

Both hypotheses matter for the stronger arbitrary-initial-state claim:
there are immediate counterexamples when w is odd, or w>n; see Section 5.
The case of an odd shorter side and an even longer side is not covered by
this particular conjecture.

The published square-grid diagonal-shift argument is in Abramovskaya,
Fomin, Golovach, and Pilipczuk, *How to hunt an invisible rabbit on a graph*,
European Journal of Combinatorics 52 (2016), 12–26,
https://doi.org/10.1016/j.ejc.2015.08.002. Our already proved square strategy
compression strengthens the scalar shift inequality to operator inclusion.
That square result does not automatically apply to a rectangular window:
edges attaching the window to the rest of the rectangle must be accounted
for. No literature-priority claim is made for the present conjecture.

## 2. Proved representation of the restricted family

A parity-p support S is a downward pyramid if

    (x,y)∈S, y>0  ⇒  (x−1,y−1),(x+1,y−1)∈S

whenever those predecessors are inside the board. Assume w≥2.
Two successive predecessor moves imply that every fixed-x fiber is a
spacing-two prefix. Put s_x=(p−x) mod 2, let k_x be its number of occupied
rooms, and define the virtual last occupied height

    a_x = s_x−2+2k_x.

The value s_x−2 represents an empty fiber. The predecessor condition is
exactly

    −2≤a_x≤n−1,   a_x≡p−x (mod 2),   |a_(x+1)−a_x|=1.       (1)

Indeed, when the higher endpoint is nonempty and positive, its predecessor
forces the lower cutoff to be at least one less. The empty and y=0 cases
obey the same inequality using the virtual heights −2 and −1. Conversely,
(1) directly supplies every required predecessor.

Thus pyramids are walks of length w−1 in the path on heights
−2,−1,...,n−1, with fixed starting parity. In particular there are at most
(n+2)2^(w−1) states in each color. Their exact count is the sum of the
appropriate entries of the (w−1)-st power of that path's adjacency matrix.
Examples per color are 20 on 4×5, 24 on 4×6, and 116 on 6×8.

### Neighborhood closure

The open neighborhood of a pyramid is a pyramid. Here is a direct proof
that includes the end boundaries. Suppose u=(x,y)∈N(S), y>0, and
u'=(x+epsilon,y−1) is a valid predecessor, epsilon=±1. Choose a neighbor
v∈S of u.

* If v=(x,y−1) or v=(x+epsilon,y), then u' is already adjacent to v.
* If v=(x−epsilon,y), its valid predecessor (x,y−1) belongs to S and
  is adjacent to u'.
* If v=(x,y+1), its valid predecessor (x+epsilon,y) belongs to S and
  is adjacent to u'.

Thus u'∈N(S). This proves closure without a conjectural compression.

For exact computation, set e'_x=(1−s_x)−2 and let t'_x be the largest
integer below n of parity 1−s_x. The contribution from the same x fiber is

    h_x = e'_x                         if k_x=0,
          min(a_x+1,t'_x)              if k_x>0.

The new height is

    eta(a)_x = max(h_x, {a_z : |z−x|=1, 0≤z<w}).            (2)

This formula includes empty fibers and the top boundary. In particular,
blindly writing eta(a)=a+1 is wrong in a bottom collar: an empty odd fiber
of height −1 need not generate the even room at height 0.

### Exact game restricted to this family

Use current physical-color heights (a,b), not permanent cohort labels.
A legal pair of survivors (c,d) satisfies c≤a, d≤b componentwise and (1)
in the appropriate colors. Its inspection cost is

    (sum_x(a_x−c_x)+sum_x(b_x−d_x))/2.

The next physical-color pair is (eta(d),eta(c)), because movement swaps
colors. A terminal state has at most m rooms. Ordinary shortest-path
search on this finite transition graph gives the exact restricted optimum
and a physical strategy. It is an upper bound on the unrestricted optimum
until the conjecture is proved. The same definition handles a varying
quota word. No scalar neighborhood relaxation has been substituted.

## 3. Complete finite evidence, and a stronger operator certificate

The exact winning-family closure tests use arbitrary physical subsets in
the unrestricted branch. They compare every possible finite quota word,
not just a selection of deadlines or constant budgets.

* 4×5: all 20 pyramids per color pass every finite quota word, 314 distinct
  pairs of winning families explored.
* 4×6: all 24 pyramids per color pass every finite quota word, 636 distinct
  family pairs explored.
* 2×8: all 9 pyramids per color pass every finite quota word.

The receipts are `uniform-even-rectangle-pyramid-4x5.json`,
`uniform-even-rectangle-pyramid-4x6.json`, and the analogous 2×8 receipt.
The generic engine is `src/even_bridge_budget_words.py`; the family
predicate is the displayed predecessor test. These are fixed-instance
statements, not an induction in width or length.

A separate C++ two-day audit on 6×8 checks, for every pyramidal starting
set A and every two-day quota pair, all arbitrary survivors R⊆A. Both
colors pass: 116 pyramids and 79,991,343 tested subsets per color. Source:
`src/uniform_even_rectangle_two_day.cpp`. This test has a precise small
purpose: it attacks the relative isoperimetric assertion that deleting a
prescribed number from a pyramid never forces a nonpyramidal minimizer of
the next neighborhood. It does not establish the multi-day theorem.

### A genuine operator exists on 4×6

`src/uniform_even_rectangle_compression_csp.py` constructs domains of
pyramidal images C(A), one for each of the 4096 subsets in each color.
It imposes cardinality preservation; C(I)=I for every pyramid I;
monotonicity on every one-element inclusion; and

    N(C(A)) ⊆ C(N(A)).                                     (3)

The initial domains also include every consequence of monotonicity with
a fixed pyramid above or below A. Arc consistency reduces the domains to
1008 singletons and 7184 pairs. Crucially, the output is not merely an
arc-consistent constraint problem: choosing the smaller integer mask in
every final domain satisfies EVERY original constraint. That direct final
check supplies a concrete idempotent, monotone, cardinality-preserving,
neighborhood-subcommuting map on this rectangle. The maps of the two
colors combine to a map on all subsets by union.

`uniform-even-rectangle-compression-map.json` stores all images and the
physical coordinate order; `uniform-even-rectangle-compression-csp.json`
stores the validation summary. The abstract strategy comparison theorem
therefore proves this particular rectangle's complete pyramid normal form.
There is no general rule for this operator yet, and no independent audit
has been requested for promoting this redundant fixed-instance fact.

The forced choices are informative. Odd corners 05 and 30 both map to
30; their even neighbors 04,15,20,31 map to 20. Most other even singletons
map to 00. Thus a simple weighted row sum or nearest-pyramid projection
is not the apparent rule: opposite end-corner balls influence the image.
Choosing a closest pyramid by Hamming distance already violates (3).
Standard diagonal shifts toward y=0 also fail: the top corner can be
sent to a noncorner of larger degree.

## 4. A broader interval idea fails even sooner

Allow one arbitrary spacing-two interval per row, with independent
endpoints. This contains the previously known two-full-row 6×6 survivor
that defeats the smaller corner-prefix family. Nevertheless, an
arbitrary-initial-state interval normal form is false.

On 4×6 take the even support

    A={00,11,13,15,35}

and the two-day quotas (1,8). Inspecting 13 leaves a neighborhood of size
8, so capture on day 2 is possible. The exact neighborhood sizes after
deleting each candidate are

    deleted room: 00  11  13  15  35
    next size:    10   9   8   9   9.

Deleting 13 is the only winning first move and splits row 1 into two
pieces. Every interval-preserving first survivor therefore fails.
The computation is reproduced in
`src/uniform_even_rectangle_intervals.py` and its 4×6 receipt.

For clarity, full-board 4×6 still passes the interval-survivor restriction
for EVERY finite quota word (650 winning-family pairs). The counterexample
is a partial-start obstruction, not a full-board obstruction. Row-interval
survivors are not neighborhood-closed, which the verifier explicitly
allows rather than silently assuming.

## 5. Parameter restrictions and failed extensions

* On 3×4, the odd support {01,03,10,12,21} is a downward pyramid, but
  quotas (4,2) force keeping the corner 03. A one-point downward pyramid
  in that color is the noncorner 10 and has three neighbors. The top
  corner has two. Thus the stronger theorem fails for odd transverse
  width.
* On 4×3, the even support {00,02,11,20} is a downward pyramid; quotas
  (2,3) require a better two-point residual than the pyramid restriction
  permits. Similar two-day failures occur on 6×3 and 6×4. These reject
  dropping the assumption w≤n.
* The 6×6 full-board varying-quota counterexample in
  `even-bridge-full-prefix-failure.md` does NOT reject pyramids: its key
  two-full-row survivor is pyramidal in a suitable square orientation.
* The earlier arbitrary-start corner-prefix and interval counterexamples
  do not become proofs about the full-board constant-budget problem.

## 6. What is missing

A fixed operator is permitted to couple both transverse coordinates and
parities; the even-PATH rigidity theorem does not rule one out. The
4×6 finite map demonstrates that this route is not vacuous. What is
missing is a formula or sequence of legitimate rectangle operators that
proves (3) uniformly for all even w≤n.

A set-valued simulation by a lattice of possible height fronts could also
suffice. It must preserve arbitrary future boundary access, not merely
one-step neighborhood size. The exact restricted recurrence in Section 2
is already available, but its equality with the unrestricted game is the
central unresolved assertion. Even proving that equality would not by
itself evaluate the optimal time as a closed expression in w,n,m.

The existing eventual-period theorem can additionally bound the number
of nonclean days and hence encode optimal states by a frontier plus a
bounded recent shot history. That would give another effective exact
algorithm for fixed width and budget. It would not solve a new scope:
the accepted effective eventual theorem already reduces all lengths to
finitely many bounded lengths. It is not a substitute for the missing
uniform normal form or time evaluation above.

## 7. Frozen checkpoint: successful route and remaining gap

The attempted uniform compression theorem remains unproved. A different
geometric route produced the following independently reviewed results
during this run:

* `uniform-even-rectangle-isoperimetry.md`: exact common static profile
  for EVERY even-area rectangle, with `b=floor(shorter_side/2)` and
  `h=area/2`: `g(k)=k+min(ceil(sqrt(k)),b,rho(h−k))`.
* `uniform-even-rectangle-high-budget-upper.md` and
  `uniform-even-rectangle-high-budget-lower.md`: complete exact capture
  time for every EVEN shorter side `2b`, all longer lengths, and
  `m≥b²+1`. The lower uses superadditivity of the inverse static profile
  and a midpoint avoiding-walk argument; the upper separately constructs
  physical backward pyramid envelopes. This avoids needing the missing
  all-budget compression theorem.
* `uniform-odd-short-critical-frontiers.md`: when the shorter side is
  `2b+1` and the longer side is even, a support of size
  `b²<k<h−b(b+1)` with surplus exactly b has its orientation forced by
  the current phase. Two such critical survivors cannot occur in
  succession. The next survivor also inherits a stronger minority-corner
  bound when small. Empty minority fibers are explicitly allowed.
* `uniform-odd-short-high-budget-upper.md`: uniform physical upper for
  the odd-short/even-long case at `m≥b(b+1)+1`, with the phase-sensitive
  remainder function J and the middle-day condition `2J≤m`. This is
  still an UPPER BOUND ONLY; the full sharp lower has not been proved.

In particular, neither all finite rectangles nor all budgets are solved
by this checkpoint. Low-budget even-short dynamics and the complete
odd-short/even-long dynamic lower remain open in this lane. The precise
next lower-bound issue is controlling the phase/history label through
arbitrary small-corner moves, rather than assuming the common static
profile can be followed at every step. All claims above are ordinary
proofs with independent review; no new physical Lean verification is
claimed for them.

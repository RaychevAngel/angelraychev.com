# Bottom roots do not force a solo reset

13 September 2026. A rejected shortcut, followed by the remaining
orientation question. The counterexamples below are actual full-start
histories; they are not synthetic capacity choices.

The bottom inverses are nondecreasing and1-Lipschitz, and satisfy
0<=I_0(z)-I_1(z)<=1. Those facts do NOT preserve the solo gap in{0,1}.
On11x11 at budget7 the first capacities are

    (0,0) -> (4,4) -> (8,7) -> (10,11) -> (14,12).

All inputs here are below the reflected-root collar. In particular
I_0(14)=10 while I_1(15)=11; the stronger one-step interlacing that the
proposed invariant would require is false. A one-unit input difference
and the phase advantage can add, allowing later gaps of size2 and more.
Thus an argument that starts every mixed ancestry at the upper collar
cannot be justified by the claimed bottom purity.

There are also actual mixed exceptions before that collar. The accepted
21x21,budget12 witness uses physical old-color-zero quotas

    0,12,0,12,0,12,0,12,0,10.

At time9 it is the pure deficit(53,0); at time10 it is(1,55), while the
solo capacities are(55,56). Its total56 exceeds the slower capacity55.
Every inverse input is in the bottom region H=101. This is the previously
recorded one-unit ammunition-credit witness, independently replayed here.

Neither counterexample disproves numerical orientation of actual retained
exceptions. The proposed condition is

    (D_0-D_1)*(x-y)>=0

for each retained mixed exception(x,y). The faster initial-cohort ancestry
would then always be the numerically larger coordinate. Ten focused
probes, including small surplus and above-width budgets, found no violation
among10,335 actual retained mixed states and1,078,811 quota transitions in
0.0032 CPU seconds. The inputs and scope are in
`bridge-odd-clock-orientation-probe.json`; the instrumented verifier is
`src/bridge_odd_clock_orientation_probe.cpp`.

This remains a conjecture. The existing synthetic failure on15x75,m12
uses hypothetical solo capacities(1,3), which cannot be a genuine solo
layer. A proof must use actual root-clock ancestry, or produce a correctly
oriented dominating frontier; arbitrary synthetic capacities and generic
Lipschitz estimates are insufficient.

# Uniform odd-rectangle dynamics: arbitrary width and budget

12 September 2026. Active research log. Scope: odd rectangles of width
2b+1 and odd length n>=2b+1, with arbitrary feasible budget m>=b+1.
The exact neighborhood profiles and the unrestricted two-count reduction
are already proved. The target is a uniform evaluation of their optimal
time, removing the current closed-form restriction m>=b²+1.
No new manuscript or Lean claim is made in this log.

## 1. Why the previous threshold matters

Above b², every nonplateau neighborhood in an unbounded corner fits into
one full inspection day. The inverse-capacity recurrence then queries only
the affine plateau, and each proper equality step drops one quotient.
Below the threshold, multiple square/pronic bands can be traversed over
several days. Neither a one-unit corner discount nor the same rigid active
interval lengths can be assumed. The remaining issue is optimal allocation
between the two cohorts; odd-rectangle isoperimetry itself is available.

## 2. Deficit coordinates and a failed merge claim

Let C0=H, C1=H−1, and let I_p(z)=max{k:g_p(k)<=z}. A cohort currently
in color p, with deficit d and r useful inspections, has next deficit

    d' = I_(1−p)(d+r).

This follows exactly from the complementary inverse identity for the two
profiles. It makes progress-concentration and postponed inspections natural
candidate abstractions.

The naive cross-superadditivity inequality

    I_p(x)+I_(1−p)(y) <= I_p(x+y)

is false even before capture. On the genuine5×5 rectangle take p=1,
x=1,y=10: I1(1)=0, I0(10)=9, but I1(11)=8. Thus any proposed exchange
must account for the color of the better cohort, rather than arbitrarily
preserving an earlier choice. This is a failed approach, not an abstract
profile counterexample.

A weaker endpoint-allocation statement survived3,796,799 exact checks on
odd widths3 through15 and three lengths per width. If one cohort is still
full and the other has deficit d, assume

    0<=d<C_(1−p), b+1<=m<=C_p−1, d+m<=C_(1−p).

Then, for0<=r<=m, the tested inequality is

    I_p(d+r)+I_(1−p)(m−r)
       <= max(I_p(d+m), I_(1−p)(m)).

This endpoint statement is now proved by the stronger inverse concentration
lemmas in `uniform-rectangle-time.md` Section 2, independently audited in
`uniform-odd-solo-bound-independent-review.md`. It concerns only a
one-full-cohort source and does not by itself justify serial optimality,
let alone arbitrary-state compression. The subsequent global concentration
argument is recorded in Section 10 below.

## 3. Parallel boundary and serial work

The global serial lane has genuine partial-state counterexamples: on7×7
at budget6, the reachable state(8,8) has optimum5 but either serial order
takes6. Its known arrival is too late to improve the full-board optimum.
Therefore neither arbitrary-state nor merely reachable-state seriality may
be used. A correct full-board theorem must exploit its boundary condition
or the accumulated time/slack of reaching an exceptional state.

The present lane will develop corner transfer/capacity statements that
remain valid independently of serial optimality. Each single cohort has
an exact monotone greedy evolution, and on the common middle plateau two
full-budget days reduce its count by D=2m−2b−1>0. Its root-shaped corner
transits are consequently bounded in length by a function of b,m alone.
The desired reusable object is a finite table of corner entry/exit data
coupled to affine middle transitions. A resulting serial formula will be
labelled an upper bound unless the separate global scheduling theorem is
proved. The broader exact two-cohort transfer must retain sufficient
joint boundary state, rather than silently replace it by serial play.

## 4. Exact transfer through an arbitrarily long joint middle

**Ordinary lemma; parent independently reviewed the interval argument.**
Put w=2b+1, K=b²+1, and choose the common safe current-count band

    L=K+m, U=H−K.

If L>U this band is empty; the entire board has H<2K+m, so the existing
exact two-count algorithm handles a size bounded solely by b,m. If a
current count lies in [L,U], every allocation0<=r<=m leaves a survivor
in [K,H−K]. Both exact profiles are on their plateau there:
g0(s)=s+b, g1(s)=s+b+1. The upper condition for g0 follows from
H−s>=b²+1, and for g1 from H−1−s>=b²>b(b−1).

Track the two initial cohorts, with the first currently in color z.
Let beta_j=b+(z+j mod2), gamma_j=w−beta_j, and

    B_z(t)=b t+floor((t+z)/2),  c=w−m.

Starting from (a,d) in the band, a length-t trajectory that remains in
the band throughout reaches (a',d') if and only if

    a',d' are in [L,U],
    a'+d'=a+d+c t,
    0<=a+B_z(t)−a'<=m t.                         (M)

Necessity follows by summing the allocations. The sufficiency is the
important part: intermediate corner constraints add nothing to (M).

**Proof.** Write S_j=a+d+cj. If S_j stays in [2L,2U], the exact reachable
first-cohort counts at time j form the interval

    A_j=max(L,S_j−U,a+B_z(j)−mj),
    Z_j=min(U,S_j−L,a+B_z(j)).                    (I)

The one-step recurrence for this interval is

    A_(j+1)=max(L,S_(j+1)−U,A_j+beta_j−m),
    Z_(j+1)=min(U,S_(j+1)−L,Z_j+beta_j).

Substitute (I). In the lower recurrence, L+beta_j−m<=L, while
S_j−U+beta_j−m<=S_(j+1)−U because gamma_j>=0. In the upper recurrence,
U+beta_j>=U, while S_j−L+beta_j>=S_(j+1)−L because m>=gamma_j.
The remaining terms give precisely (I) at j+1.

These intervals really are nonempty: compare each of the three lower
terms with each upper term. The only nonautomatic comparisons are
S_j>=2L and S_j<=2U; the other comparisons use a,d in [L,U],
0<=beta_j,gamma_j<=m. Since S_j is affine, valid initial and final
sums ensure these two inequalities at every intermediate time. The
interval induction is therefore valid throughout, proving sufficiency.

**Constructive witness.** Given a target a_(j+1), choose

    a_j=max(A_j,a_(j+1)−beta_j).

The recurrence guarantees a_j<=min(Z_j,a_(j+1)−beta_j+m). Thus the
integer allocation r_j=a_j+beta_j−a_(j+1) lies in [0,m]. Backtracking
recovers every allocation in O(t) output time. The second allocation is
m−r_j. The implementation in `src/uniform_odd_middle_transfer.py`
independently matched36,608 complete reachable sets and reconstructed
34,780 extreme endpoint witnesses in0.175 CPU seconds. These checks
attack the lemma; the proof above establishes all parameters.

## 5. Constant-size formula for a middle block's shortest duration

Index endpoints now by their current physical colors: source(a,d),
target(u,v). If c=w−m is nonzero, duration is forced:

    t=(u+v−a−d)/c.

It must be a nonnegative integer. The tracked first cohort's endpoint
is u for even t and v for odd t. Substitute that count into (M).
This decides existence and gives the shortest middle-only duration.

If m=w, sums must agree. For endpoint parity e in {0,1}, put y_e=u
when e=0 and y_e=v otherwise. The shortest duration with that parity is

    t_e=2 max(0,
      ceil((y_e−a−e b)/w),
      ceil((a−y_e−e(b+1))/w))+e.

The distance is min(t_0,t_1). This is just (M) with t=2q+e and
B_0(t)=qw+eb. Both formulas are implemented constructively in the same
module. They explicitly preserve the physical-color swap at odd times.

## 6. An unconditional boundary-game normal form

Let M be the square [L,U]² in the full two-count state rectangle.
Retain every state outside M. Also retain every state inside M with
one coordinate within R=m+1 of a band endpoint; call these the ports.
This margin contains every entry into or exit from M: in a single
physical cohort update, the count changes by at most m+1, since the
profile surplus lies between−1 and b+1. Coordinate swapping preserves
this symmetric port condition.

Keep every ordinary one-day edge between retained states. Between every
pair of ports, add a weighted edge whenever the exact middle transfer
exists, with its shortest duration from Section5. The resulting graph
has exactly the same optimal full-board capture time as the original
game. Indeed, compress maximal omitted-interior path segments into their
port-to-port transfers; conversely expand every transfer using the
constructive witness. The initial full state and the empty state are
retained. Positive-duration behavior is preserved, and zero-length
self-edges are harmless and can be omitted.

There are O((b²+m)H) retained states: at least one coordinate belongs
to a boundary set of O(b²+m) possible counts. This is an exact joint-state
reduction, valid at every feasible budget, and not a serial scheduling
assumption. It removes the quadratic number of deep-interior states.
Materializing all port-to-port edges would still be wasteful; the next
section describes their additional structure.

## 7. Prospective efficient implementation; not yet a finished algorithm

Fix a source port and a target port type, meaning that one target count
is fixed at a specified boundary-layer value and the other count y
varies. If c!=0, the duration is affine in y. Fixing its parity imposes
one congruence modulo2|c|. The two endpoint inequalities in (M) become
linear inequalities in y. Thus admissible endpoints form one arithmetic-
progression interval, and the transfer weight is affine in y.

For m=w, fixing a target port type and the conserved sum determines y
uniquely, so only O(m) possible target types need consideration.

This suggests a range-edge shortest-path implementation with a segment
tree for each target type and residue. Edge weights can remain
nonnegative: orient each progression in increasing transfer weight,
give a tree edge the difference between the minimum endpoint costs
of its child and parent, and give a source-to-range-node edge the
minimum transfer cost on that node. The costs telescope to the exact
macroedge weight. Total tree size is O(mH), and each source/type pair
requires O(log H) range edges. The resulting near-linear-in-H bound
is a proposed implementation consequence, not yet independently audited.

**Current proof boundary.** Sections4--6 give an unconditional all-budget
structural reduction. They do not yet evaluate the reduced boundary graph
by a closed formula in b,n,m. The possible general serial theorem and
the exact uniform corner optimization remain separate unresolved work.

## 8. Stronger normal form: one cohort remains close to full

**New ordinary theorem, awaiting independent review.** Define

    D=2m−2b−1, B=8b²+6D+2, L0=b²+m+1,
    E=B+4L0(B+1), R=mE.

The previously proved uniform-potential argument bounds the number of
nonclean days in an optimal prefix strategy by E. A day is clean when all
m inspections go to one cohort and the other is actually empty or its
entire current color class. The argument applies whenever its potential cap
C=2H−4b²−2m−5 is positive; it does **not** need the much larger
protected-band threshold used later in the eventual-periodicity theorem.
Indeed C>0 already implies H>2b²+m+2, hence H−1>m. The two odd-length
solo phases give dT−2C≤B by integer rounding. Every positive zero-potential
count is at most b²+m, while every full-potential count is within b²+2
of its current full class. Strict growth under N² therefore bounds each
flat-potential transient by 2L0 days, at every such H. At most B bad days
and two focused blocks per efficient run then give E=B+4L0(B+1).
None of these steps chooses a protected interval or contracts the board.
This scope check was redone independently of the later surgery argument.

**Theorem.** Every optimal prefix strategy has all its count states in

    a=0, or d=0, or H−a<=R, or H−1−d<=R.            (NF)

Until one cohort is captured, at least one therefore remains within R
rooms of its full class. This permits partial work on both cohorts and
does not assert serial optimality.

**Proof.** After first capture an axis condition holds permanently.
Before first capture, take a time t when both cohorts are proper. Let j
be the last preceding time when one cohort was full; j exists initially.
Every day from j through t−1 is nonclean. All subsequent source states
are both proper. The first day cannot be clean either: a clean day
leaves a full inactive cohort full, while activating a full cohort and
leaving a proper nonempty cohort inactive is not clean.

Follow the cohort that was full at time j. At a noncapture update its
deficit grows by at most its useful inspections: g0(s)>=s−1 and
g1(s)>=s+1 exactly offset the alternating class capacities. Its current
deficit is therefore at most m(t−j)<=mE. If C<=0, then
H<=2b²+m+2. But B>=8b²+8 and m>=2 imply
R>=m(8b²+8)>2b²+m+2, so the restriction is vacuous. This proves all sizes.

Restricting the exact two-count graph to (NF), with original edges,
preserves the full-board minimum and an attaining prefix strategy. It
has O(RH) states. No accelerated edge or serial scheduling hypothesis is
needed: only two high-boundary strips and the capture axes remain.

## 9. Proposed exact finite-matrix formula at every budget

The graph decomposition below still awaits independent review. It does
not assert an elementary closed expression. Take

    J=m+1, W=R+2m+2b²+10.

For H<2W+2J−1, the complete count graph has size bounded polynomially
in b,m and can be solved directly. At larger H, a bulk active count
k in [W,H−W] has one of these uniquely described state types:

* active current color p and passive deficit d in {0,...,R};
* active current color p and the other cohort already empty.

There are A=2(R+1)+2 types. An allocation r to the active cohort changes
its count by b+p−r and reverses its color. In the first kind, the passive
deficit becomes I_p^infinity(d+m−r), the inverse of the unbounded bottom
profile L_p; retain the edge precisely when this is at most R. In the
second kind the passive cohort stays empty. These rules are independent
of H. All jumps in active count have absolute value at most J.

The safe margins justify the unbounded inverse: its input is at most
R+m, each queried count is at most R+m+1, and the opposite corner is
farther away than b². Active residuals lie on the plateau. Capture cannot
occur in the bulk. All remaining edges depend only on bounded low counts
or bounded deficits from H.

Write H−2W+1=qJ+rho, where 0<=rho<J and q>=2. Keep q homogeneous blocks
of J consecutive active counts starting at W, each with s=AJ vertices.
All other states, including the full/full junction, form an end network
of size polynomial in b,m. This network includes possible low-to-high
edges: capturing the small active cohort leaves its companion close to
full. Those edges must not be discarded or assumed local in active count.

Include the first and last homogeneous blocks as interfaces to the end
network. Label high counts by their deficits. The network then depends
only on b,m,rho, not q. Generate it at the representative majority size
H_rho=2W−1+2J+rho, removing the homogeneous edges between its two
interface blocks. Let C_rho be its exact directed distance matrix on
both interfaces and the full initial and empty terminal vertices.

Let D be the distance matrix of two adjacent homogeneous blocks, including
within-block edges and edges in both directions. Define D1 star D2 by
identifying their adjacent interfaces, taking shortest-path closure on
the three interfaces, and retaining the outside two. Each matrix has
2s boundary vertices. The operation is associative because both
parenthesizations give distances in the same glued graph. In particular,
it accounts for arbitrary backtracking, not just forward passages.

The q-block channel distance matrix is D^(star(q−1)). Embed it on the
interfaces of C_rho, take entrywise minimum and shortest-path closure.
The initial-to-terminal entry is exactly T_m(P_(2b+1) × P_n): first
expand/collapse channel subpaths, then use the exact normal form (NF).

This is a proposed explicit finite-matrix formula for every parameter.
All precomputation sizes are polynomial in the numerical parameters b,m;
associative powering takes O(log H) products after precomputation. Retain
path witnesses to obtain a compressed optimal strategy, expanding it in
the necessary output time. The finite matrices retain joint corner state.

**Scope comparison.** The existing eventual theorem and finite base DP
already provide uniform computability for odd rectangles. The new content
is the near-full-cohort normal form and explicit joint corner/channel
representation. This is not a new decidability claim or an elementary
closed form for T. Its decomposition and quantitative assertions must
pass independent review before promotion.

## 10. A sharper uniform reduction from the parallel concentration proof

The global serial lane has now proved, and this lane independently audited,
that for **every** feasible budget on an odd rectangle,

    T belongs to {2τ−1,2τ},

where τ is the fastest solo-cohort time. The key invariant is exact maximum
total deficit before τ, not a claim of serial optimality. The full proof
and its endpoint inverse inequalities are in `uniform-rectangle-time.md`,
with independent review and coordinate evidence in
`uniform-odd-solo-bound-independent-review.md` and its receipt.

This is a more direct reduction of the remaining closed-time problem than
the finite-matrix representation of Section 9. The single unresolved bit
is whether the central inspection can join two half-strategies.

Here is an exact formulation of that bit. Set L=τ−1 and let F_L contain
all deficit pairs achievable after L inspections and L moves in the
physical prefix game, using at most m shots per day. Then the smallest
possible central inspection requirement is

    min_{d,e in F_L}
       [max(0,H−d_0−e_0)+max(0,H−1−d_1−e_1)].          (C)

Thus T=2τ−1 precisely when (C) is at most m.

For necessity, split a hypothetical odd-length winning schedule at its
central day. A prefix compression of each half gives coordinatewise no
larger possible sets than that half's actual beliefs. For any two color-p
sets of sizes H−p−d_p and H−p−e_p, their intersection has size at least
max(0,H−p−d_p−e_p). The center must inspect the intersection, so the
minimum in (C) cannot exceed its budget.

For sufficiency, realize one selected half by canonical prefixes and the
other by their 180-degree spatial reflections, then reverse the latter
in time. Both side lengths are odd, so this reflection preserves physical
color. It reverses the weight-and-tie order, making each reflected prefix
an opposite terminal segment. Their intersections have exactly the two
sizes in (C), simultaneously in the two colors. Inspect those intersections
at the center. Avoiding walks cannot cross that central layer, giving the
claimed full search.

This is an exact half-horizon method, not an elementary criterion. The
conjectural simplification replaces (C), only when deciding if it is at
most m, by H+(H−1)−D_0(L)−D_1(L). Its sufficiency is proved; necessity
remains open. Plain total-deficit and individual-deficit bounds alone do
not imply it when the two solo capacities differ. The attainable joint
boundary, or a new inequality for two copies of it, remains essential.

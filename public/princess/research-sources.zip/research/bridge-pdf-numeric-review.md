# Numerical-section PDF visual review

Date: 2026-09-13. Reviewer: numeric bridge lane.

## Reviewed artifact and scope

- PDF: `output/pdf/princess-searches.pdf`, 164 pages, US Letter.
- Reviewed build SHA-256: `3fe7c7c4582ca2c9e48f546f7379018b6a51f1b4b9f687b3f1e5178323282639`.
- This is the 09:49 local-time build. Its page images in
  `output/pdf/qa/main/` were generated at 09:49 and opened individually
  with the image-viewing tool.
- Visually inspected pages: **1, 2, and every page from 147 through 160**.
  Page 160 was included because the numerical fixed-block proof continues
  beyond the originally requested page 159.
- Checked the rendered statements against `paper/main.tex` (abstract),
  `paper/sections/bridge-odd-evaluation.tex`, and
  `paper/sections/bridge-boundary-numeric.tex`, and against the previously
  accepted research conclusions. This is publication QA, not a new proof
  audit or a rerun of the computational certificates.

## Results

**No visual or source/PDF claim defect was found on the inspected pages.**
Equations, integer roots, ceilings, floors, indicator subscripts, matrices,
finite tables, and set differences are legible. No clipping, overlapping
text, missing glyphs, unresolved references, or displaced theorem endings
was observed. Long source and receipt paths wrap within the page margins.

| Pages | Reviewed content and outcome |
| --- | --- |
| 1–2 | Title, attribution, abstract, and contents are clear. The abstract explicitly leaves the absolute-operation research goal open and distinguishes ordinary proofs, finite certificates, and Lean results. |
| 147 | The preceding linear-budget comparison corollary and the transition into Section 29 render cleanly; the one-day bracket is not presented as an exact formula. |
| 148–150 | Fixed odd solo evaluation uses 49 paired blocks per evaluation at fixed K=16, or 196 blocks and four divisions for the scalar calculation. Scalar necessity remains a separate hypothesis. Seven-row residue lists, finite complement counts, and the unbounded period argument render correctly. |
| 151–153 | Coordinate bound, improved onset, all odd boards with b+1 <= m <= 2b, and the cubic region 27m^3 <= b^4 agree with the accepted statements. The complete finite complement has 19,852 triples in 3,171 intervals. The final paragraph preserves the general O(b) clock-evaluation limitation. |
| 154–155 | Width 24 remains the one-day bracket 24n-370 <= T13(24,n) <= 24n-369 for even n >= 24. Fixed entrance/exit tables and their ordinary plateau transfer are clearly separated from finite verification receipts. |
| 156–158 | Width 25 states the exact value T13(25,n)=50n-925 for every even n >= 26. The persistent size-157, c=0 terminal exclusion is explicitly a finite certificate; its containing hull is not asserted to be an interval of flagged states. The even-cut lower proof and attaining upper construction agree with the accepted result. |
| 158–159 | The quadratic-edge theorem covers every r >= 3 and n >= 2r at k=r(r-1). The formerly exceptional r=8 residue has the explicit 127 -> 79 -> 28 shape transition and no open exception remains in the theorem. |
| 159–160 | The even fixed-block theorem includes the extra (2,0) critical cap at n=2r+1 and explains why the common affine interval is empty there. The total is 168 blocks and four divisions for K=16. Equality of lower and physical upper bounds yields an exact subfamily; strict gaps remain brackets. |

The root-produced `research/pdf-layout-verification.json` additionally
reports no text spans outside its safe-margin check for either PDF. That
automatic check supplements the individual-page visual inspection above.

## Final-build binding

The PDF was rebuilt during this review: a subsequent 09:52 build had
SHA-256 `3e042114c8ec07a9e5e129e84366913ba0a4a42ecd9c1ab0efd58e14192956ac`,
while the inspected PNGs were still from 09:49. Root confirmed that the
intervening changes were minor scope wording and spacing, with a final
build still running, and instructed this lane to keep the review bound to
the original hash. **This note therefore does not claim visual review of
the later builds.** Root will render the final build and compare page
hashes, refreshing any changed pages before final acceptance.

Only this review note was created by this QA task. No manuscript source,
PDF, shared receipt, or research result was changed.

## Final rendering refresh — accepted

The final 164-page PDF has SHA-256
`02b7276fa71ddfe2f363d74300bcf31c5831b6d22b89e0eaf713329a7132e579`.
Its refreshed PNGs were generated at 09:57 local time. The reviewer opened
pages **1, 2, and every page 147–160 individually again**. Every inspected
PNG was also compared pixel-for-pixel with a fresh in-memory rendering of
the corresponding page in this exact PDF, using the publishing Python
environment and the same 1.4 rendering scale; all 16 comparisons passed.
The PDF hash was unchanged at the end of the refreshed review.

The contents now correctly identifies Section 29 as the geometric-memory
and intermediate-budget results, Section 30 as the odd numerical results,
and Section 31 as the even-area numerical results. Section 31 begins on
page 154, as listed. The revised headings fit cleanly, and the updated
theorem and cross-reference numbers render without unresolved references.
The exact width-25 result is Corollary 31.3, the complete quadratic-edge
formula is Theorem 31.4, and the even fixed-block comparison theorem is
Theorem 31.5. Their mathematical claims and numerical bounds retain the
previously reviewed scope.

**Final acceptance: no rendering or source/PDF claim defect was found in
this lane's reviewed pages of the final hash above.** This acceptance
supersedes the pending final-build binding in the preceding section. No
files other than this review note were edited during the refresh.

# Frontier and compression research: final handoff

12 September 2026 UTC. This index maps the accepted results from this
subtask to their proofs and receipts. Root owns the full manuscript,
website, and consolidated research log.

## Structural theorems

* `paper/sections/compression.tex`: whole-strategy comparison; fixed-state
  normal forms; product lift; odd-path and square-pair compressions;
  exact odd-cylinder vector recurrence; even-path compression rigidity.
* `paper/sections/odd-rectangles.tex`: exact arbitrary-support profiles
  and compatible orders for every odd rectangle, with the complete
  quadrant/Ferrers argument and profile attainment calculation.
* `paper/sections/odd-boxes.tex`: all-odd-box nesting in every dimension,
  proved by codimension-one compression and terminal-coordinate exchange;
  exact polynomial two-count game; hunter number from the cited
  Bolkema–Groothuis criterion and proved profile duality.
* `paper/sections/odd-eventual-time.tex`: stable finite corner tables for
  every fixed all-odd cross-section; eventual feasibility; uniform time
  bounds; eventual affine time periods for every fixed feasible budget,
  with the full bounded-deficit and protected-band surgery proof.

The general structural theorems are ordinary proofs, independently attacked
by root and another agent. They are not represented here as complete
physical Lean theorems. The formalization chapter records the actual
kernel-checked boundary.

## Exact time formulas from finite rational certificates

* `paper/sections/odd-minimum-budget.tex`: for widths3,5,7,9,11,13,15,
  every odd n>=w has T_((w+1)/2)=2wn-C_w, with
  C_w=8,20,44,84,136,208,288. General interval-insertion proof plus
  exact finite certificates; no global serial-optimality assumption.
* `src/odd_minimum_budget_all_lengths.py` and
  `research/odd-minimum-budget-all-lengths.json`:32 finite lengths,
  exact rational inequalities, affine collars, and physical strategy
  premises. Independent actual-room review is recorded separately.
* `src/three_by_three_cylinder_time.py` and
  `research/three-by-three-cylinder-time.json`: independently audited exact
  T5(3×3×n)=18n-36 for every odd n>=3. The proof is in
  `research/three-by-three-cylinder-time.md`, with manuscript theorem in
  `paper/sections/odd-eventual-time.tex`. The separate audit is
  `research/three-by-three-cylinder-independent-review.md`: 4,350 exact
  inequalities and seven actual-room schedule checks passed, including
  two larger lengths. The insertion proof establishes all odd lengths.

The exploratory numerical LP scripts were used only to discover rational
charges. The final certificate checkers use integers and exact fractions,
and do not require SciPy.

## Important corrected or unresolved claims

* Full-board corner-ideal normal form is now proved for all-odd boxes,
  because the proved optimal prefixes are checkerboard corner ideals.
  It is not established for every prescribed partial starting set or
  for arbitrary boxes with even side lengths.
* Generic serial optimality for arbitrary budgets remains unproved;
  several abstract profile counterexamples show that weak surplus
  conditions cannot establish it. None of the accepted theorems needs it.
* Every fixed feasible odd-cylinder budget now has a proved eventual
  affine period. This is stronger than a leading-slope estimate but does
  not prove that the period begins at the shortest possible cylinder.
* More compact closed expressions for eventual offsets, mixed/even-side
  normal forms, and complete physical Lean formalization of the new
  structural arguments remain separate work.

Independent reviews and detailed failed approaches are indexed by the
corresponding `*-independent-review.md` and research-proof filenames.

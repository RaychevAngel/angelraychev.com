# Corner ideals and exact partial-state recurrences

12 September 2026 UTC. Independent research during the renewed Princess
investigation. This note contains proved elementary lemmas, an explicit
counterexample, and a clearly marked normal-form conjecture. It makes no
priority claim. It does not claim a general grid classification.

## 1. The useful distinction: a family of states versus a signature

A vector counting possible rooms of each parity in each row is insufficient
unless an orientation or other geometry accompanies it. For example, on a
3-by-4 board with two probes, the states

    A = {(0,0),(0,1),(1,0)},
    B = {(0,1),(0,2),(1,0)}

have the same row/parity counts. Their exact remaining times are respectively
two and three. A can leave its corner (0,0) after the first inspection; its
two neighbors are captured next. Every possible singleton survivor of B has
at least three neighbors, so two rounds are impossible. Three suffice by
leaving (0,1), then leaving its corner neighbor (0,0), then capturing that
corner's two neighbors.

This does not refute row-frontier profiles: a cutoff and direction determine
an actual shape. It refutes using the cutoff's *size* without the direction.

## 2. Row intervals do not provide a universal normal form for partial states

Here interval means that, in each row and each checkerboard parity, the
possible column indices form an interval of the parity lattice. The following
counterexample is a complete elementary argument, independently of the
computer calculation that found it.

On a 3-by-5 board, with four probes, start from the interval state

    A = {(0,1),(0,3),(0,4),(1,2),(2,0),(2,1)}.

**Claim.** Its unrestricted optimal remaining time is two, but requiring every
before-inspection belief to remain a row interval raises that time to three.

It is not capturable in one round because it has six vertices. For a two-round
strategy, at least two vertices must survive the first inspection, and their
combined neighborhood must have at most four vertices. The only pair with
that property is the two corners (0,4),(2,0). To check this without a search,
their degrees are two, the other four vertices have degrees 3,3,4,3; mixed-
parity pairs have disjoint neighborhoods and total degree at least five.
Among pairs of the four odd vertices, the union sizes are 5,5,5,5,6,5.

The two corners have neighborhood

    {(0,3),(1,0),(1,4),(2,1)}.

Inspecting it on round two wins. However, its middle row contains columns
0 and 4 and omits the intervening same-parity column 2, so it is not a row
interval. Any survivor set with at least two vertices and neighborhood size
at most four must contain this pair and no additional vertex (every other
pair already has at least five neighbors). Thus every two-round strategy
must pass through this hole.

Three interval rounds do suffice: first retain (0,1),(0,3), giving belief
{(0,0),(0,2),(0,4),(1,1),(1,3)}. Then retain only (0,0), and finally inspect
its two neighbors. Every displayed belief is a parity interval in each row.

The counterexample still holds when temporary post-inspection survivor sets
are allowed arbitrary holes. It is the next day's physical belief that must
have a hole. A smaller-budget computational example has four initial rooms
{(0,1),(0,3),(0,4),(2,0)} and budget two: unrestricted six rounds versus nine
under the interval restriction. The hand-checkable four-probe example is
preferable for exposition.

This rejects the statement “every row-interval partial state admits an
optimal interval strategy.” It does **not** reject the weaker possibility
that the full board admits an optimal strategy in a smaller, special family.

## 3. A smaller family survives all bounded tests

Fix a corner of a Cartesian box, reflect coordinates so that it is the
origin, and restrict coordinatewise order to one checkerboard parity. A
**corner ideal** is a down-set in this parity poset: if x belongs, then every
y of the same parity with y_i <= x_i for every i belongs.

Define the canonical family C to consist of unions of two such ideals, one
for each current parity. Each ideal may face a different corner, and the
corner may change between steps. Empty supports are allowed.

The bounded experiment requires both every before-inspection belief and
every post-inspection survivor set to lie in C. Thus any produced strategy
is certainly a legal physical strategy; the restriction only makes the
optimization harder.

| Board | Canonical states | All states | Budgets exhaustively tested | Canonical states with a worse restricted optimum |
|---|---:|---:|---|---:|
| 3-by-4 | 1,296 | 4,096 | 2,3,4 | 0 |
| 3-by-5 | 3,220 | 32,768 | 1 through 7 | 0 |
| 4-by-4 | 5,184 | 65,536 | 1 through 8 | 0 |

The comparison is stronger than checking the full board: the unrestricted
and restricted remaining times agree for **every canonical starting state**.
Infinite remaining times were also compared. Budgets at least the smaller
parity size automatically give equality for all canonical states: inspect
the entire smaller parity support, then its opposite support's neighborhood;
both inspections fit. The closure lemma below makes this a canonical
strategy. States already of size at most the budget take one round.

The full-board times include 3-by-4 with two probes = 16, whereas the
previously rejected single diagonal order gave 17. On 4-by-4, budgets
3,4,5,6,7,8 give 12,6,4,4,3,2 respectively.

**Additional three-dimensional attack by root.** On the 3-by-3-by-3 box,
root compared unrestricted and corner-ideal play for a *single initial
parity cohort*, considering 1,174 canonical supports of the majority color
and 1,062 of the minority color, at all budgets 1 through 13. No mismatch
was found, including infeasible states. The direct subset computation took
about 1.5 seconds. This is evidence in a dimension not covered by the
two-dimensional table, but does **not** compute or compare the simultaneous
two-cohort full-board optimum. See `parity-corner-three-cube-check.json` and
`src/parity_corner_check.py`.

**Conjecture (canonical-state optimality).** For every Cartesian box, every
budget, and every starting belief in C, some optimal strategy keeps beliefs
and survivors in C. In particular this would hold from the full board.

This is **not proved**. The small-board evidence does not justify assuming it
on larger boards, or extrapolating through dimension. A weaker theorem only
for full-board starts could survive even if the displayed conjecture fails.

## 4. Proved: neighborhoods preserve corner ideals in every dimension

**Lemma.** In any finite Cartesian product of paths, the open neighborhood
of a parity corner ideal is a corner ideal in the opposite parity, facing
the same corner.

**Proof.** Reflect to put the chosen corner at the origin. Let x be adjacent
to v in the ideal, and let z <= x coordinatewise have the same parity as x.
We show that z has a neighbor w <= v, which must lie in the ideal.

If x=v-e_i, take w=z+e_i. It is within the box because w <= v. If
x=v+e_i and z_i>0, take w=z-e_i. If x=v+e_i, z_i=0, and z has some
other positive coordinate z_j, take w=z-e_j; this also satisfies w<=v.
The only remaining case is z=0. Then x is even and v is odd, so v has
some positive coordinate v_j. Take w=e_j<=v. All cases give a neighbor
of z in the ideal. Thus z belongs to the neighborhood. QED.

This is a closure lemma, not an isoperimetric or optimality theorem. It says
that a recurrence on these states is a genuine restricted physical game.
It does not say that an arbitrary survivor set can be compressed without
losing future performance.

## 5. Exact frontier equations for the restricted game

For a fixed horizontal direction, write a one-parity row frontier as
a=(a_0,...,a_(h-1)), where a_r is the last occupied column in row r, or -1
if the row is empty. Occupied columns in a nonempty row are all columns of
the appropriate parity from its first available column through a_r.

For width w define

    H(-1)=-1;
    H(c)=c+1 if 0<=c<w-1;
    H(w-1)=w-2.

Out-of-range rows have cutoff -1. The opposite-parity neighborhood cutoff is
exactly

    Phi(a)_r = max(a_(r-1), H(a_r), a_(r+1)).

The formula includes width one: H(0)=-1 means there is no horizontal
neighbor. Vertical contributions are unchanged column cutoffs. All terms
that are not -1 have the correct output parity. This is an exact local
max recurrence; it follows by taking the union of the horizontal and the
two vertical neighbor prefixes. Reflect to handle the right-facing version.

For a corner ideal, these cutoffs additionally satisfy the down-set
conditions. A minimal set of predecessor conditions uses coordinate moves
(-2,0), (0,-2), and (-1,-1); these generate all coordinatewise comparisons
within one parity. The horizontal move (0,-2) is automatic from the
row-prefix convention; the other two constrain neighboring row cutoffs. The profile therefore
records the whole geometry with h integer parameters and a corner label.

Let tau_m(A) denote optimal time in the canonical game. The exact Bellman
recurrence is

    tau_m(empty)=0,
    tau_m(A)=1+min { tau_m(N(R)) : R subset A, R in C, |A|-|R|<=m }.

The minimum is infinity if no finite route to the empty state exists.
Neighborhood closure eliminates the need to test N(R) in C separately.
Allowing different corners for R is important; inclusion must refer to
actual supports, not just their cardinalities. The equivalent horizon/budget
recurrence is

    b_0(empty)=0, b_0(A nonempty)=infinity,
    b_t(A)=min_(R subset A, R in C)
                 max(|A|-|R|, b_(t-1)(N(R))).

Here b_t(A) is the least daily budget allowing capture within t rounds.
These are min-plus/min-max optimization recurrences, not scalar linear
recurrences. Characteristic-root methods do not apply automatically.
For a fixed height, there are at most 16*(w+1)^(2h) two-cohort corner
profiles, a polynomial in width with degree depending on height. This
bound does not imply a polynomial algorithm in the number of dimensions.

The outstanding theorem is an exchange or simulation statement proving
that these restricted recurrences equal unrestricted optimal play. Once
that is known, formula extraction can be investigated without carrying all
2^(h*w) physical beliefs.

## 6. Exact finite solver and checks

`src/frontier_state_experiments.py` uses an independent all-belief horizon
iteration. If W_t is the family clearable in at most t rounds, then

    A in W_(t+1) iff exists R subset A:
                      |A|-|R|<=m and N(R) in W_t.

For each R with N(R) in W_t, assign score |R|, assigning -infinity to the
other R. The subset maximum transform computes the maximum score over all
R subset A in O(v*2^v) time. A is newly winning precisely when that maximum
is at least |A|-m. Each horizon uses the previous completed horizon only;
the iteration stops at a fixed point. Witness survivor sets decrease the
computed remaining-time label strictly and are replayed on the graph.

Restrictions are imposed by deleting allowed beliefs and/or survivor sets,
never by identifying states that might have different future behavior.
The unrestricted full-board answers agree with the previously independent
BFS results. Every run is bounded to at most 16 rooms. The main four-by-four
experiment took about six seconds, and the three-by-five one about three;
no unbounded search was run.

Evidence files:

- `frontier-state-3x4.json`
- `frontier-state-3x5.json`, `frontier-state-3x5-extra.json`
- `frontier-state-4x4.json`, `frontier-state-4x4-extra.json`
- `frontier-state-interval-beliefs-only.json`
- `frontier-state-independent-checks.json` records separate direct forward
  BFS confirmation of both interval counterexamples, including all useful
  probe counts, and neighborhood closure on all 9,700 canonical states in
  the three boards above. These checks took about 1.7 seconds.

## 7. Next attacks

1. Falsify canonical-state optimality beyond these small boards using an
   independently solved structured starting state; do not silently assume
   it to enlarge the search.
2. Attempt a local exchange theorem *inside a corner ideal*, allowing the
   replacement survivor to change corner. Ordinary one-step isoperimetry is
   insufficient because future shape compatibility matters.
3. Separate phase changes from within-phase max recurrence. A bounded phase
   system for fixed width could admit eventual periodicity or min-plus
   algebra; no such theorem has yet been established here.

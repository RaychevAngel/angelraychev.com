# Independent review of the prism theorem and implementation

11 September 2026, by the path/lower-bound research agent, after the root agent wrote the implementation. This review found no substantive mathematical or phase-convention gap. It is an ordinary independent review, not a Lean certificate or a novelty assessment.

Reviewed `boxes-with-a-two-side.md`, `src/box_prism_time.py`, and the imported solver in `src/nested_grid_time.py`.

* **Source scope:** Otachi–Suda Theorem 2.5 explicitly covers arbitrary products of paths with sorted side lengths. Their definition of an isoperimetric order includes both minimizing external boundary and closed-neighborhood prefix closure. Thus the application does not repeat the earlier confusion between closed neighborhoods of whole-grid subsets and open neighborhoods of parity subsets.
* **Coordinate order:** `prism_data` sorts the stored base side lengths descending, then reverses coordinates in the negative lexicographic tie key. This compares shorter axes first and larger coordinates first on ties, precisely as the cited simplicial order requires. Permuting axes with equal extents is harmless by grid symmetry.
* **Parity lift:** the added coordinate `(parity-sum(v)) mod 2` gives the desired current parity. Every base vertex lifts exactly once to each parity. Open prism neighborhoods equal opposite-parity lifts of closed base neighborhoods, including empty and full sets.
* **Phase convention:** the imported solver uses current graph parity labels and therefore swaps the profile outputs after a miss and move. Its predecessor records and probe reconstruction use those same labels. The mathematical presentation permits tracking initial cohorts, which removes the swap; these conventions are equivalent, and the implementation is internally consistent.
* **Final day:** the solver stops at `a+b<=m` and appends the complete current belief as the last inspection. It counts this inspection day and does not charge or exploit a move after capture. Reconstructed schedules are replayed on the actual graph.
* **Clipping and capacity:** full budget splits `p+(m-p)=m` suffice. Deletion clips to available prefix size. The actual bitmask shot contains no more than the assigned capacity, and the two current parities are disjoint.
* **Optimality:** the size-domination argument can replay unrestricted numeric allocations on canonical prefixes. Monotonicity of the profile is needed and holds because prefixes and their neighborhoods are nested. The argument does not assume the unrestricted strategy itself has nested shapes.
* **Feasibility barrier:** if `c(k)-k>=m`, the size threshold `k+m` lies within the initial cohort size because `c(k)<=N`. A cohort never crosses that threshold under any strategy. Conversely, `m>max(c(k)-k)` strictly decreases a targeted canonical cohort. The one-vertex base has zero external boundary and gives the correct threshold one on a single edge.

Additional independent finite set-level check: `src/prism_projection_checks.py` constructs Manhattan adjacency independently and verifies the **entire neighborhood set equality**, for both parities and all selected base subsets on seven small bases, including the one-vertex base, paths, rectangles and a cube. All **1,724** cases passed in about **0.011 seconds**; receipt `research/prism-projection-checks.json`.

The root separately compared the reduced solver with 32 prior unrestricted BFS results and three new unrestricted `2 by 3 by 3` cases, and replayed returned strategies on larger examples. This review read that implementation and did not duplicate those BFS runs.

No additional correctness test is currently indicated absent a code or theorem change. Before publication, integrate the overlapping proof notes, complete the broader novelty search, and distinguish this classical-theorem-dependent exact algorithm from the not-yet-completed Lean formalization.

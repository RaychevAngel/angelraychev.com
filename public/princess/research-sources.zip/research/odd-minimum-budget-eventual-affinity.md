# Eventual affine capture time at every odd width

12 September 2026 UTC. Ordinary proof, independently reviewed by root and
the formalization agent with no gap; see
`odd-minimum-budget-eventual-independent-review.md`. Depends on the proved compatible profiles and the independently
reviewed uniform potential bound. No finite extrapolation or serial-optimality
assumption is used. Not yet Lean verified.

## 1. Statement and an explicit threshold

Fix any odd width w=2b+1>=3 and the minimum budget m=b+1. Define

    D=b+2,  A=b(b+1),  B=8b²+6,  L=b²+b+2,
    E=B+4L(B+1),
    H*=w+2A+4D+2+2E(w+2D+1).                           (1)

For an odd length n>=w, write H=(wn+1)/2. The proposed theorem is

    H>=H*  =>  T_m(w,n+2)=T_m(w,n)+4w.                 (2)

Consequently, if n0 is the least odd n>=w with (wn+1)/2>=H*, then

    T_m(w,n)=2wn-C(w) for every odd n>=n0,
    C(w)=2wn0-T_m(w,n0).                               (3)

The existing exact two-count recurrence computes C(w) on the one finite
board w×n0. Since H*=O(w^5), this costs O(w^11) arithmetic operations by
the previously proved state/edge bound. This is a deliberately loose
finite threshold, not a claim that the period begins only there. The
seven earlier certificates prove n0=w suffices for widths3 through15.

The uniform bounds also give

    2w+2 <= C(w) <= 2w²-2w+10.                         (4)

## 2. A bounded number of inefficient days

Use the uniform potential from `odd-minimum-budget-uniform-bounds.md`:

    K=2b²+2b+2,
    C=2H-4b²-2b-6>0,
    F_p(k)=min(C,max(0,2k+p-K)).                        (5)

At the large sizes considered in (1), C is positive. Each full class has
potential C. For one cohort, a quota below m cannot decrease its potential;
quota m decreases it by at most one. An optimal full-board search can be
taken in prefix normal form with the entire quota used on every nonfinal
day, and the final inspection quotas padded to sum to m.

Let Phi_t be the sum of the two current-color potentials before day t,
and let Phi_(T+1)=0 after final capture. Define the nonnegative integer

    eta_t=1-(Phi_t-Phi_(t+1)).                          (6)

The proved uniform upper bound is U=2wn-2w-2. Therefore an optimal search
has

    sum_t eta_t=T-2C <= U-2C = 8b²+6=B.                (7)

Call a day **efficient** when eta_t=0, and **bad** otherwise. There are
at most B bad days.

An efficient day must give all m inspections to one cohort: splitting the
quota into two numbers below m cannot decrease either potential. The
active cohort's potential drops by exactly one, and the inactive cohort's
potential remains exactly constant. No increase of the inactive potential
can be compensated, because the active drop is at most one.

## 3. Efficient runs have at most two focused blocks

We first show that zero inspections strictly increase an intermediate
potential:

    0<F_p(k)<C  => F_(1-p)(g_p(k))>F_p(k).             (8)

For a nonfull majority prefix, g0(k)>=k; its unclipped expression therefore
increases by at least one after the parity reversal. A full majority
prefix has potential C and is excluded from (8). Every nonempty minority
prefix has g1(k)>=k+1, again increasing the unclipped expression by at
least one. Monotone clipping cannot remove this strict increase while
the old value is strictly between0 and C.

Consider a maximal consecutive run of efficient days. After an active
cohort loses one unit, its potential is less than C. If it remains positive,
(8) forces it to stay active on the next efficient day: making it inactive
would increase its potential. Thus the active cohort can change only after
its potential reaches zero. A zero-potential cohort cannot subsequently
become active on an efficient day, because it cannot lose one more unit.
It also cannot increase while inactive in this run, as exact constancy is
required. Hence every efficient run consists of at most two focused blocks.
There are at most B+1 runs and at most2(B+1) such blocks.

This argument rules out an inactive0-to-C jump without an extra condition
on C: any positive jump would make the day bad by Section2.

## 4. Only finitely many days fail to have an empty or full inactive cohort

Call a day **clean** if all m inspections target one cohort while the
other cohort is either empty or exactly its full current color class.
It need not be efficient. We bound the number of days that are not clean
by counting all bad days and the initial transients of efficient blocks.

For a nonempty proper support in one color of a connected bipartite graph
without isolated vertices, N²(S) strictly contains S. Inclusion holds by
backtracking along an edge. Equality would make S closed under every
two-edge path; connectivity makes the two-step graph connected within
each color, forcing S to be the entire color class. Therefore an inactive
nonempty proper prefix grows by at least one after every two days with
no inspections, until it is full.

During an efficient focused block, the inactive potential is constant
and, by (8), is either0 or C.

* If it is0, its count is at most b²+b+1=L-1. If the actual count is
  positive, strict two-day growth prevents it staying in this range for
  more than2L days. If the actual count is zero, the day is already clean.
* If it is C, its count is at least H-b²-2, so its deficit from its full
  current color class is at most b²+2<=L. Within at most2L days it
  becomes full and remains full under further zero-inspection moves.

Thus each efficient block contributes at most2L nonclean days. Combining
with the bad-day bound, every optimal search has at most

    E=B+4L(B+1)                                        (9)

nonclean days. This bound depends only on w, not on n or the search path.

## 5. Finding one common interior band

For each of the at most E nonclean days, record the two cohort counts
before that day. A single such count k forbids integer cuts c satisfying

    k in [c-D,c+w+D],

an interval of exactly w+2D+1 possible cuts. There are at most2E recorded
counts. Restrict candidate cuts to

    A+2D <= c <= H-w-A-2D-2.                           (10)

The number of candidates is H-w-2A-4D-1. By (1) it is greater than the
number2E(w+2D+1) of cuts that can be forbidden. Hence a cut c exists such
that no nonclean day starts with either cohort count in
[c-D,c+w+D].

Every one-day cohort transition changes its count by at most D. This is
the previously proved displacement bound: profile surplus lies in
[-1,b+1], and the quota is at most m. It follows that no nonclean
transition can enter, leave, or pass across the band [c,c+w]. In
particular, every day whose source count lies in that band is clean.

Both full initial counts are above c+w, and both final counts are below c.
On a clean day the active count never increases, because every surplus
is at most m. Its inactive count is either0 or a full class size, both
outside the band. Thus whenever a cohort is in the band, it is active,
receives all m inspections, and has an inactive companion that is full
or empty. No cohort can cross the band upwards: a nonclean transition
cannot touch it, an active clean transition cannot increase, and an
inactive clean cohort is outside it.

The profile plateaus cover the entire band and all relevant survivors by
(10). Consequently a clean active majority step decreases its count by
one, and a minority step preserves it. Each cohort therefore visits
c+w, then traverses the band exactly once, reaching c after exactly2w
days with its current parity restored. If the count c is reached one day
earlier under one starting parity, the remaining minority day stays at c;
that day is still clean because its source is in the protected band.

Throughout these2w-day blocks the inactive companion remains full or
empty, respectively: it receives zero inspections. The two crossing
blocks cannot overlap, since each requires the other count outside the
band. They are separated by at least the protected boundary days, so
removing one does not remove any part of the other.

## 6. Contracting a band removes4w days

Take the optimal search just analyzed on majority size H. Delete the
2w-day crossing block of each cohort. At every remaining state, map a
cohort count by

    f(k)=k                  for k<=c,
         k-w                for k>=c+w.                (11)

All intermediate counts c<k<c+w belong to a deleted crossing block,
so (11) is defined on the remaining states. At the two ends of a deleted
block, the active counts c+w and c both map to c. The inactive count is
empty or full, so it also matches at the two ends after replacing its
full class by the smaller full class. The deleted block has even length,
so the current-color labels match. Thus the two state paths glue.

For every retained transition, the profile equations conjugate correctly.
If a cohort source lies at or below c, its survivor lies at or below c;
the profiles at H and H-w agree there by the far-margin condition in
(10). Its successor cannot cross into the removed band, by the preceding
clean/nonclean analysis. If the source lies at or above c+w, subtract w
from it and from its successor. The survivor after this subtraction is
at least c-m, above the low-corner threshold by (10). The high translation
identity for the profiles therefore applies, giving exactly the profile
at H-w. The boundary values of (11) agree with the glued states. Quotas
are unchanged and may be padded when a smaller support is inspected.

This is a physical prefix search on the rectangle of length n-2, lasting
T_m(w,n)-4w days. Therefore

    T_m(w,n-2) <= T_m(w,n)-4w                           (12)

whenever H>=H*. The cut margins ensure n-2 is still at least w.

## 7. Expanding the same band adds4w days

Starting instead with an optimal search on any H>=H*, choose its protected
band as above. Enlarge the majority size to H+w. Keep every lower count
at or below c unchanged and increase every upper count at or above c+w
by w. Replace each clean crossing from c+w to c in2w days by a clean
crossing from c+2w to c in4w days. The inactive companion remains empty
or the enlarged full class throughout. The inserted2w extra days per
cohort are even, so all current-color phases still match.

Outside the crossings, the same low and high profile identities used in
Section6 verify every transition. Inside them, the affine plateau formulas
give the explicit full-budget trajectory. This yields

    T_m(w,n+2) <= T_m(w,n)+4w.                          (13)

Apply (12) to H+w for the reverse inequality, and combine with (13).
This proves (2) for every H>=H*. Iteration proves (3), and (4) follows
from the independently proved uniform upper and lower bounds.

## 8. Proof boundary and remaining questions

The intended theorem is eventual affine behavior for every fixed odd
width, with a concrete though very loose threshold. It does not prove
that the affine law begins at the square for every width. The polynomial
finite procedure for C(w) uses a large two-count graph; deriving a much
smaller corner-state recurrence or a closed expression remains open.
The minimal-time problem at larger budgets and for boxes with even side
lengths is not settled by this argument.

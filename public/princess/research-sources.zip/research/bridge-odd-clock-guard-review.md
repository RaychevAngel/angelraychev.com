# Independent review of the deadline screening and scalar guard deductions

13 September 2026. Independent mathematical review by the odd-clock branch
of `research/resumed-odd-compatibility-barrier.md`. This review checks the
displayed arguments directly; it does not rely on the finite scalar scans.

## Conditional screening lemma: accepted with its stated hypotheses

Let A>B be the two actual solo capacities at the precentral deadline,
delta=A-B, and let every exceptional history have primary a and ancestry-
secondary s in the same physical color q. Put c=ceil((C_q-m)/2). Assume
F(s)<=A-a+epsilon for these histories and F(s)-s nondecreasing.

Exceptionality gives A-a<=s+delta-1. Thus

    F(s)-s<=delta+epsilon-1.

If F(c)-c>=delta+epsilon, no exceptional history can have s>=c. Two
exceptional histories consequently leave at least C_q-2c+2 rooms in
color q. This is m+2 when C_q-m is even and m+1 when it is odd. They
cannot clear centrally. A pair containing a nonexceptional history has
total deficit at most A+B, so its clipped central cost cannot be smaller
than the scalar residual sum. The two pure histories provide the converse.
The conditional deduction is valid, including its integer endpoints.

The necessary physical-to-bottom ammunition transfer is explicitly part
of the credit hypothesis. It is not supplied by this arithmetic argument.
Neither the all-width credit hypothesis nor the unrestricted scalar guard
is proved by this review.

## Uniform budget interval b+2<=m<=2b: scalar guard accepted

For b>=2 and odd n>=2b+1, C_q>=M>=2b(b+1) gives c>=b^2. Write
H_p(k)=mu_p(k)-k and sigma_p(k)=L_p(k)-k for k>0. The accepted ammunition
recurrence yields exactly

    H_p(k)=sigma_p(k)+H_(1-p)((k+sigma_p(k)-m)_+).

At k>=b^2 both surpluses are at least b. The next state is at least
b^2+b-m>=b(b-1)>0. At every state at least b(b-1), both surpluses are
again at least b: (b-1)^2<b(b-1) for the square root, and the pronic
threshold is no larger. Hence the first two positive terms contribute
at least 2b. Therefore

    mu_q(c)-c >= 2b >= m >= delta+1.

The last step uses the already accepted actual precapture gap bound
delta<=m-1. The endpoint b=2,m=4 is valid. This proves the numerical
half of the barrier on the entire stated interval, not the history half.

## Fixed-size sufficient certificate: accepted

For 1<=r<=b put z=(r-1)^2+1 and suppose z<=c. Whenever a positive
recursion state is at least z, both surpluses are at least r, and its
successor is at least the old state minus m-r. Since m-r>0, the first

    1+floor((c-z)/(m-r))

states stay at least z. Their contributions give

    H_p(c)>=r*(1+floor((c-z)/(m-r)))

for either phase. The clipping at zero does not spoil the induction:
every counted state is explicitly at least z>=1. The fixed choice
r=min(b,ceil(sqrt(c/3))) is admissible whenever c>=1; indeed
(r-1)^2<c/3<=c, and integer rounding gives z<=c. Taking r=b is another
admissible fixed choice when c>(b-1)^2. Any such expression reaching m
certifies the scalar guard through delta<=m-1, in bounded operations.

No exhaustive success rate or tested maximum is part of these proofs.
The remaining main obstacle is still the history-dependent credit condition
through the primary lower-root collar. These accepted conditional tools do
not on their own settle any new arbitrary-width midpoint family.

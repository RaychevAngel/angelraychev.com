# Consolidated theorem frontier — 13 September 2026

Research stopped at the user's explicit wrap-up request. This document
records genuine strengthening, not an artificial recounting of independent
results. The full arbitrary-budget explicit 2D classification remains open.
The previous catalogue's count should not be reduced merely because several
statements now share a heading.

## 1. Every odd width at the minimum budget

For w=2b+1>=3 and every odd n>=w,

    T_(b+1)(P_w square P_n)=2wn-(8b^2-4b-4L_b+4).

L_b is the first arrival at B=b(b-1) in the explicit bottom corner clock.
The equivalent solo calculation evaluates it in O(b) arithmetic stages.
No elementary polynomial formula for L_b is asserted.

This replaces the old seven-width certificate list as the general theorem.
The stronger higher-dimensional insertion statements and physical narrow-
width cases are retained. The proof uses the original cohort of a mixed
history; it never identifies ancestry with the larger numerical coordinate.

Manuscript: odd-minimum-budget.tex, thm:odd-minimum-budget.
Independent audits: maturation-minimum-budget-independent-review.md,
maturation-minimum-budget-second-review.md,
maturation-odd-manuscript-independent-review.md.

## 2. Scalar optimality eventually, exact bounded evaluation everywhere odd

Every odd rectangle and feasible m still has T in {2tau-1,2tau}. Put

    H=b^2+1, G=m-1,
    K=H-1+2m(floor(G/(2b+1))+1), W=G+K+1,
    J=2K+G+2m+H+2, M*=2J+G+m(W+3).

When M=(wn-1)/2>=M*, the two pure solo residuals decide the choice exactly.
For shorter boards the bounded joint evaluator remains exact. Its constants
are sharper than the previous checkpoint. Any counterexample to the scalar
rule must have intermediate budget b+2<=m<=b^2 and length n=O(b^4).
This is a bound on the remaining question, not its solution.

A common cyclic growth-control theorem computes minimum total ammunition
and the exact prescribed-horizon feasibility of one bottom process. A
conditional suffix exchange proves two-block domination when the primary
inverse inputs remain above the lower root bands. Separate optimal
ammunition schedules may still compete for the same days.

Manuscript: bounded-odd-frontier.tex, thm:eventual-odd-scalar,
prop:corner-ammunition, lem:expansive-primary-exchange.
Independent audits: maturation-eventual-scalar-independent-review.md,
maturation-cyclic-ammunition-independent-review.md,
maturation-suffix-exchange-independent-review.md.

## 3. A sharper common even-width construction and exact formula

For width2b and n>=2b, the explicit quotient-and-remainder time formula
now holds at

    m>=max(b+1,b(b-1)+1).

For m<bn put bn-b=q(m-b)+r and J(r)=r+min(ceil(sqrt(r)),b).
The time is2q if r=0, otherwise2q+1 if2J(r)<=m and2q+2 if not.
The ordinary two-day/one-day regimes apply at larger budgets.
The equality threshold is included in the lower proof.

This strictly absorbs the previously separate four-row budgets3 and4.
The common connected-bipartite erosion loses exactly the occupied bottom
roots; its floor-distance threshold is sharp. The older all-fiber distance
threshold is still a distinct sharp geometric fact. The analogous attempted
threshold reduction for odd width/even length is not proved.

Manuscript: pyramid-envelope-lemma.tex, even-rectangle-time.tex, four-rows.tex.
Audits and counterexamples: maturation-boundary-connections.md,
maturation-even-transitions.md Section5.

## 4. Explicit interior connections in the finite physical boundary graph

For any connected bipartite cross-section, virtual height connections have
an exact componentwise and total-flip criterion. A balanced descent realizes
constant-budget connections with a physical margin independent of duration.
For Hamiltonian cross-sections, plateau guards supply the lower bound
against arbitrary physical intermediate shapes.

For even-order cylinders the existing checkpoint reduction therefore
becomes a finite boundary graph with explicit interior edge weights. After
parameter-dependent preprocessing, a bounded number of integer arithmetic
stages suffices in the length. Bit complexity and printing an entire
strategy still depend on the length. The general boundary tables have not
been compiled symbolically or implemented as a practical evaluator.

This strengthens the old interior connection and graph-powering argument.
The broader higher-dimensional eventual-period and fixed-deadline theorems
are not subsumed and are retained.

Manuscript: symbolic-height-transitions.tex, bounded-cylinder-interfaces.tex.
Independent review: maturation-interior-independent-review.md.

## 5. One corner capacity and explicit temporal consequences

In a quadrant whose first allowed monochromatic diagonal is h,

    C_h(s)=max(s(s-1)/2,s(s-h))

is the exact maximum size at surplus<=s, with every intermediate size
attainable. This unifies square, pronic and omitted-origin bounds.
The maximum-of-convex-capacities argument also yields a general attained
two-candidate minimum for sums of their inverse costs.

On width2b half-strips the complete conditional corner profiles include
the critical surplus b+1 and the width-two exception. At surplus s<b,
size>s(s-1) forces the entire source into the favorable corner triangle
of radius2s-2. If that corner is absent and size>C_2(s), the entire source
lies in the opposite odd triangle of radius2s-3. These force opposite-
corner delays2(b-s)+1 and2(b-s)+2 movements under every later inspection
schedule. Finite-board uses must retain the far-boundary hypothesis.

These geometric consequences supersede the isolated one-step corner-bit
inequality. They do not establish that the separate extrema compose.
Indeed a width14,budget9 partial-start example disproves the exactness of
the two-bit relaxation; a29-room example disproves a broader proposed
annulus/ramp strategy family. The narrower family remains research-only.

Manuscript: quadrant-boundary-profiles.tex, corner-memory.tex.
Audits: maturation-punctured-quadrant-independent-review.md,
maturation-joint-corner-independent-review.md,
maturation-cheap-step-rigidity.md,
maturation-corner-manuscript-independent-review.md.

## Formal and publication boundary

There are83 Lean modules. The3 new modules prove clipped physical erosion,
ancestry under explicit inverse-system and secondary-bound hypotheses, and
the general convex-capacity theorem with concrete C_h instances. Complete
physical classifications remain paths, two-row grids,3x3x3 and4x4x4.
The complete new rectangle and corner geometry is ordinarily proved,
not fully formalized. Fresh build/deployment receipts identify the final
published bytes; CURRENT_CHECKPOINT.md is the authoritative release index.

## The remaining decisive obstacles

- Odd rectangles: remove the lower-root restriction from the suffix exchange
  or otherwise exclude a useful shared-budget gain on the shorter,
  intermediate-budget boards. Rounded-root credit and suffix collisions
  are real; elementary total-ammunition inequalities omit them.
- Even-area rectangles: evaluate the finite boundary choices uniformly in
  width and budget. Interior propagation is explicit. Boundary supports
  need more information than size or the two corner-availability bits.
  The rejected broad shape family shows that multiple ramp pieces can
  matter, while the narrower closure calculations have no optimality proof.
- Publication: maintain the distinction between new derivation and verified
  literature priority. No Princess arXiv submission is made in this phase.

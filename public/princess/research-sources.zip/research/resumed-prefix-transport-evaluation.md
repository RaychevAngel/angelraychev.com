# Fixed-size evaluation of a prescribed prefix-front transport

13 September 2026. Proposed numerical consequence of the independently
reviewed virtual containment construction. This is an intermediate tool,
not a classification of optimal full-board inspections. The entrance and
exit fronts are prescribed; optimizing their selection is still open.

## The accepted constructive criterion

For two downward pyramid height walks a,b of width w, and a duration t
with the required parity, put

    F(t) = (1/2) sum_x max(a_x - b_x + t, 0).

If F(t)<=kt, there is a directly specified sequence of at most k actual
inspections per day taking a physical belief contained in a to one
contained in b after t moves. No margins at the board ends are required.

Indeed c_x=min(a_x,b_x-t) is a height walk with the same vertex parities
as a. Repeatedly lower a current local maximum above c by two, using the
standard greatest-height-above-target choice. This reaches c in exactly
F(t) lowerings. Divide that word into t blocks of at most k lowerings,
insert uniform height additions after each block, and inspect only the
rooms whose removed virtual heights are physically on the board. The
actual belief is always below the virtual bound, including when that bound
extends past an end of the board. Its final bound c+t is at most b.

This is also the minimum number of virtual lowerings for containment at
that prescribed t: coordinate x requires at least
max(a_x-b_x+t,0)/2 lowerings. It need not be the minimum number of physical
inspections, since invisible lowerings at the ends cost no actual probe.
Root independently checked this argument proposed by the construction
agent. The geometric construction remains separate from the next proposed
fixed-size evaluation statement.

## Why prescribed two-prefix fronts are special

Take a union of at most two weightlex prefixes anchored at the two bottom
corners. On each parity class of transverse indices, its virtual heights
are piecewise affine in the index, with slopes in {-2,0,2} and an absolute
bounded number of pieces. A single prefix consists of complete diagonals,
a partial final diagonal, and the clipped top and empty-bottom portions.
Those are a fixed number of linear pieces. Taking the maximum of two such
height functions adds at most one crossing on each common affine piece.
This does not require enumerating the transverse positions.

For prescribed source and target unions of this kind, let t=e+2q have the
required parity. On each common affine piece of a fixed transverse parity,
the summands F(t) have the form

    max(A + d*j + q, 0),   0<=j<L,   d in {-2,-1,0,1,2}.

There are only an absolute bounded number of such pieces. For d>0 set

    j0 = min(L,max(0,floor(-(A+q)/d)+1)),   M=L-j0.

The piece contributes exactly

    M*(A+q) + d*(L-1+j0)*M/2.

For d=0 it contributes L*max(A+q,0). For d<0 reverse the progression and
use the positive-d formula. Thus evaluation of the prescribed-front
criterion F(t)<=kt is an absolute O(1) calculation with ordinary arithmetic,
floors and fixed case distinctions. It contains no disguised variable sum.

## Potential elimination of the duration search

Assume k>w/2, the feasible nontrivial budget range. Increasing t by two
increases F(t) by at most w, so F(t)-kt decreases strictly along its
permitted parity. In particular feasibility of the virtual containment
criterion is upward closed in the permitted durations.

Split q into its two residue classes. This removes the only possible
nontrivial floor residue in the progression formula, since |d|<=2.
For each piece, the clamp j0 has three regimes: zero, interior, or L.
Their endpoints are fixed linear expressions in A,L and d. A common
refinement therefore has an absolute bounded number of intervals. On
each interval F(e+2q)-k(e+2q) is a rational quadratic in the residue-class
variable. The least feasible integer in that interval can be determined
from the linear or quadratic roots, endpoint checks and ceilings, with
care at equality. Comparing the fixed number of candidates then gives
the least permitted virtual duration in O(1) standard operations.

This last reduction needs an explicit endpoint/residue implementation and
independent proof audit before being promoted to the manuscript. In
particular, negative q must be excluded, phase conventions at t=0 must be
kept, and only roots lying in their active clamp interval are relevant.
The claim concerns prescribed fronts and this sufficient virtual rule;
it does not optimize entrance/exit fronts or prove physical optimality.

## What this would close

It would replace a width-length sum or duration search in the constructive
connection of two prescribed prefix unions by a fixed-size numerical rule.
The main missing task would remain: prove that some explicitly selected
entrance and exit fronts attain the unrestricted rectangle lower bound.
That selection cannot be hidden inside the prescribed-front operation.

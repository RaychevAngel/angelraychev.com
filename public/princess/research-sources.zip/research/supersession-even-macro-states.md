# Exact bounded-interface states for Hamiltonian cylinders of even area

12 September 2026. **Accepted ordinary theorem after independent reviews
by the root research agent and the separate formalization/audit agent.**
The final review is `supersession-cylinder-macro-third-review.md`; the
earlier local audit is `supersession-even-macro-independent-review.md`.
The manuscript uses the common larger constants specified in that final
review, at `paper/sections/bounded-cylinder-interfaces.tex`.
This note strengthens the earlier finite-exception/eventual-period algorithm
by describing an exact graph with one free longitudinal coordinate. It does
not assert that every daily survivor can be made pyramidal. The intermediate
states of an edge are arbitrary physical supports in a bounded local gadget.
No manuscript, website, or Lean source has been changed.

## 1. Statement and constants

Let Q be a fixed finite bipartite graph with a Hamiltonian path and
w=2b≥2 vertices. Fix an integer m>b and put d=m−b. Consider the ordinary
moving-princess game on Q □ P_n, with at most m inspections each day and
mandatory movement after an unsuccessful inspection. Index Q by a chosen
Hamiltonian order 0≤x<w, so its bipartition is x mod 2; physical cylinder
coordinates are (x,y), 0≤y<n. Additional edges of Q are retained throughout.
We use current checkerboard color, while tracking the two initial-color
cohorts separately when discussing an edge.

Define constants, independent of n,

    K = 4b²,
    B = 4K+4m+2b−2,
    L₁ = K+m+1,
    E = B+2L₁(B+1),
    L = E+1,
    q = (m+b)L,
    R = 100(q+w²+L+w+1),
    n₀ = max(w, floor((2K+m+d)/b)+1, 10R).

The last two constants are deliberately excessive. Their role is to
separate two end gadgets and all propagation cones of length at most L.

**Theorem (bounded physical edges, one free coordinate).** There is an
effectively constructible finite table, depending only on Q and m, with
the following properties.

For every n≥n₀, the exact optimum T_m(Q □ P_n) is a shortest-path value
in a graph of O_b(n) states and O_(Q,m)(n) edges. An edge has a positive
integer duration at most L and is accompanied by an actual physical
inspection schedule of that duration. A state has at most one nonempty,
nonfull cohort. That cohort is a downward or upward pyramid; its mate is
globally full or empty. The only unbounded state parameter is a common
longitudinal translation of the pyramid.

Away from the two ends, transitions are translates of a finite table of
bounded-displacement edges. All other transitions join a finite family of
end states. Their table depends on n only through n mod 2. Arbitrary
nonpyramidal supports may occur *inside* an edge, and are accounted for
exactly there.

The finitely many lengths 1≤n<n₀ can be evaluated directly and included
in the same algorithm. Thus this gives an exact, uniform algorithm for
every fixed even-order bipartite Hamiltonian cylinder at m>b. Taking
Q=P_(2b) covers every rectangle whose shorter side is even and every
feasible budget. For fixed Q,m, direct shortest-path evaluation takes O(n log n) arithmetic
operations after preprocessing; the recovered path supplies an optimal
physical strategy. Section 8 supplies a further logarithmic-length
evaluation after finite preprocessing; it is separately marked for audit.

Budgets m≤b are impossible when n≥w: the spanning Hamiltonian rectangle
already has hunter number b+1. One-day cases can of course be returned immediately.

## 2. The geometric family and facts valid at the physical ends

A one-color set P is a downward pyramid when every valid predecessor
(z,y−1), z adjacent to x in Q, of a room (x,y)∈P with y>0 also belongs to P. Upward pyramids are
obtained by reflecting y. Empty and full color classes count as pyramids
in both orientations.

For color p put s_x=(p−x) mod 2. Every fiber is a spacing-two prefix, with
k_x rooms and virtual last height

    a_x = s_x−2+2k_x.

The predecessor condition is equivalent to

    −2≤a_x≤n−1,  a_x≡p−x (mod 2),
    |a_z−a_x|=1 for every edge xz of Q.                    (1)

Indeed, the higher nonempty fiber requires its predecessor in its
neighbor. Empty fibers have virtual heights −2 or −1, and the y=0 cases
obey the same inequality. Conversely these inequalities supply every
valid predecessor. Two predecessor moves give the spacing-two closure.
Along the Hamiltonian path their height vectors are ±1 walks, so there
are at most (n+2)2^(w−1) downward pyramids in each color. Additional edges
of Q only filter these walks by further instances of (1). The same bound
holds upward, and every height vector has range at most w−1.

The neighborhood of a pyramid is a pyramid, including at either end.
To check downward closure, let u=(x,y)∈N(P), y>0, and let
u'=(z,y−1) be a valid predecessor, xz∈E(Q). Choose a neighbor v∈P of u.
If v=(x,y−1), it is adjacent to u'. If v=(x,y+1), its predecessor
(z,y) lies in P and is adjacent to u'. If v=(t,y) for a transverse
neighbor t of x, its predecessor (x,y−1) lies in P and is adjacent to
u'. This argument uses no assumption that Q is itself a path.

For clarity, the exact cutoff rule is not always a↦a+1. With
e'_x=(1−s_x)−2 and t'_x the largest integer below n of parity 1−s_x,
define

    h_x = e'_x                    if k_x=0,
          min(a_x+1,t'_x)         otherwise.

The new cutoff is max(h_x,{a_z:xz∈E(Q)}).
In particular it is at most a_x+1. Because w is even,
Σ_x s_x=Σ_x(1−s_x), and therefore

    0 ≤ |N(P)|−|P| ≤ b.                                  (2)

The lower bound follows from the fixed perfect matching between
transverse rows (0,1),(2,3),…; it holds for every support, not just P.
By iteration,

    P^(r)=N^r(P) is a pyramid of the same orientation,
    |P| ≤ |P^(r)| ≤ |P|+br.                              (3)

Two further elementary bounds will be used. A pyramid of size at most u
is confined to the first 2u+w+2 columns from its filled end. This follows
fiber by fiber, since each fiber has at most u rooms. A pyramid with
deficit at most u is full outside the last 2u+w+2 columns: its complement
in its color class is a pyramid of the opposite orientation. Finally, a
pyramid with an empty physical fiber has at most w² rooms, because the
height range is at most w−1. This bound is intentionally weaker than the
sharp b² bound.

## 3. Optimal schedules have bounded gaps between canonical states

Here we invoke the ordinary clean-day argument already proved in
`paper/sections/even-cylinder-eventual-time.tex`, from
`eq:even-period-potential` through `eq:even-period-exception-count`.
We restate its complete interface and explain why it supplies *exact*
physical checkpoints rather than a scalar relaxation.

For n≥n₀, h=bn and C=h−2K−m>d. Give a cohort of count k the potential

    ψ(k)=min(C,max(0,k−K−m)).

On a day using p useful inspections on that cohort, its potential loss
is at most max(0,p−b). The total loss of both cohorts is consequently at
most d. The height construction gives T≤2ceil(b(n+2)/d); hence the total
integer slack of an optimal schedule is at most B. There are at most B
days whose total potential loss is less than d.

On any remaining efficient day all m useful inspections go to a single
owner. Its survivor has strict middle size and surplus exactly b. The
proved exact-surplus theorem makes that survivor a downward or upward
pyramid, and its next belief is its actual pyramidal neighborhood.
For general Q, the matched-row cutoffs convert to physical fiber heights
as in `eq:physical-height-edge` of that same paper section: equality of
the boundary on the spanning rectangle and on Q forces (1) on every
additional transverse edge. Thus the clean states lie in the Q-pyramid
family defined here, not merely in its larger path subfamily.
The mate has constant potential. A run of efficient days has at most
two owner blocks: after losing positive potential, an owner cannot
become an unchanged mate except at zero, and cannot own again there.
There are at most 2(B+1) owner blocks.

An untouched proper nonempty cohort grows by at least one each day,
because the matching-contracted cylinder contains the strongly connected
matching-contracted Hamiltonian rectangle.
Discarding the first L₁ days of an owner block ensures that its untouched
mate is literally full or empty, not merely in a flat potential collar.
Mark these initial days and all inefficient days nonclean. At most E
days are marked. On each remaining clean day its source belief has one
pyramidal owner and a globally full/empty mate. Its actual successor
belief has the same property. These are canonical states as in Section 1.

Partition the optimal schedule at the sources of all clean days, also
including the initial full/full state and the final empty/empty state.
If capture occurs at the last inspection, append that day's empty
movement step; it adds no inspection day and leaves the state empty.
The duration between two successive checkpoints is at most E+1=L:
apart from its possible first clean day, every intervening day is marked.
The first and last intervals satisfy the same bound. If there are no
clean days, the whole schedule has duration at most E.

Thus an actual optimum is a concatenation of bounded-duration physical
blocks between canonical states. Conversely every such concatenation is
an actual physical strategy. This already proves equality with the graph
having *all* canonical endpoints and *all* physical edges of duration
at most L. The remaining task is to show that its edge tests are local
and that its size is linear in n.

## 4. A physical block can be localized without changing its endpoint

**Lemma (endpoint-difference localization).** Suppose an r-day physical
block, r≤L, takes a one-cohort pyramid P₀ to a one-cohort pyramid P₁;
their orientations need not agree. Set

    P₂=N^r(P₀),  D=P₂\P₁.

Then P₁⊆P₂ and |D|≤(m+b)r. The block can be replaced by one of the same
duration and no larger daily quotas such that every retained inspection
of this cohort has longitudinal distance at most r from D. The final
support is exactly P₁.

**Proof.** If p_t is the number of useful inspections of this cohort on
day t, the matching gives |A_(t+1)|≥|A_t|−p_t for arbitrary supports.
Thus |P₁|≥|P₀|−mr. Equation (3) gives the claimed difference bound.

Delete all inspections farther than r in the longitudinal coordinate
from D. Removing inspections enlarges the final avoiding support, so
P₁ remains present. Any new surviving r-step walk must finish outside
P₁ but inside the no-inspection support P₂, hence in D. Every earlier
vertex of that walk is within longitudinal distance r of D. All original
inspections that could hit it were retained, contradicting that it was
not an original surviving walk. This proves equality. ∎

This argument uses actual time-indexed avoiding walks. It does not assume
that arbitrary intermediate supports are canonical, monotone, or exact
survivor envelopes. Apply it separately to both initial-color cohorts;
their current physical colors are disjoint on every day, so removing
inspections in the two applications cannot increase the shared quota.

**Lemma (the difference lies in a bounded band).** In the preceding
lemma, D is contained in one interval of at most

    2(m+b)r+2w²+4w+4                                     (4)

longitudinal columns.

**Proof.** If P₁ and P₂ have the same orientation, compare their height
vectors. Inclusion means coordinatewise comparison. Each fiber's height
difference is twice its contribution to |D|, at most 2|D|, while each
height vector has range at most w−1. All differences are therefore
between the smallest cutoff of P₁ and the largest cutoff of P₂, a band
of width at most 2|D|+2w+2. The upward case is reflected.

Suppose P₂ is downward and P₁ upward. If every fiber of P₁ is nonempty,
P₁ contains the topmost room of its color in every fiber. A downward
pyramid containing it is full, so P₂ is full. Now D is the downward
complement of P₁ and has at most (m+b)r rooms, hence lies near y=0.
If some fiber of P₁ is empty, |P₁|≤w², and therefore
|P₂|≤w²+(m+b)r. The downward P₂, and thus D, lies within the corresponding
bounded initial band. These estimates imply (4). Reflection gives the
other case. Empty/full sets can be assigned either orientation. ∎

After localization, inspections lie within r of this band. At every
intermediate time the support agrees with its uninspected pyramid
N^t(P₀) outside the further r-neighborhood: information travels at most
one longitudinal column per movement. Thus the complete nonpyramidal
part of the block fits in a slab of width bounded solely by b,m.

## 5. Interior edges have one counter; changes of owner are end events

Here a proper cohort means nonempty and not its entire color class.
Any canonical state has at most one such cohort.

First suppose a cohort is proper at both ends of a block, and has the
same pyramid orientation. The count difference lies between −mr and br.
Each height vector has range at most w−1; subtracting their means shows
that their cut positions differ by a bounded amount, for example

    2(m+b)r+4w+4.                                       (5)

This coarse bound follows also from P₁⊆N^r(P₀), the difference-band
proof, and the at-most-r displacement of the uninspected cutoff.
If both cuts are far from the board ends, the local physical block
depends only on the two relative height shapes, their bounded displacement,
the current color, and r. Translating the whole gadget by two columns
preserves every color and adjacency. Its existence and daily resource
requirements are independent of n and of its absolute position.

There cannot be another proper cohort at either endpoint. A mate that
starts empty remains empty. A mate that starts and ends full can be left
uninspected by the localization lemma (its D is empty), and is full
throughout. A full mate cannot become empty in r days on the lengths
considered, since h>mL. Hence an interior-to-interior edge has the same
owner, mate status, and orientation.

All possible failures of these conclusions force an end collar:

* A proper cohort that becomes empty has initial size at most mr.
* A proper cohort that becomes full has initial deficit at most br,
  since its no-inspection support can gain at most br rooms.
* A full cohort that becomes proper has final deficit at most mr.
  An empty cohort cannot become proper.
* If one proper cohort changes from downward to upward, use the two
  cases in the proof of (4). When P₂ is full, P₀ has deficit at most br
  and P₁ has deficit at most (m+b)r. Otherwise both endpoint sizes are
  at most w²+(m+b)r. Thus both endpoints have bounded size or bounded
  deficit, and their cuts lie in bounded end collars.

Consequently, when ownership or orientation changes, every proper
endpoint is an end state. Equation (5) also shows that an edge with one
endpoint near an end cannot reach an arbitrarily distant interior
endpoint. The collar radius R in Section 1 is larger than every size,
cutoff, displacement, and propagation bound used here.

There is a minor choice of terminology at the interface. One may retain
all bounded-displacement edges in the translation-invariant table and
use that table whenever the entire local gadget misses the physical
ends; the remaining edges form the boundary table. This avoids declaring
an artificial collar line a physical boundary. Only finitely many
counter values lie in the exceptional boundary table.

## 6. Effective finite tables and the exact recurrence

Encode an interior downward pyramid of physical color p by its shape

    ε_x=a_x−a_0,  ε_0=0,  ε_(x+1)−ε_x∈{−1,1},

and the integer counter z=(a_0−p)/2. Include the orientation, the mate's
full/empty status, and the current physical color in the finite control. Retain only shapes
satisfying (1) on every extra Q edge. For an upward pyramid, encode its downward complement in the current
color class by the same physical cutoff vector. Thus both orientations
use the same physical longitudinal counter; shifting z by one translates
either boundary by two columns. This yields at most a constant times
(n+2)2^(w−1)
canonical states. Add the constant-sized all-full/empty states. The
proper/nonproper distinction avoids duplicate ownership labels.

For each finite control pair, each r∈{1,…,L}, and each bounded counter
displacement, test existence of an r-day physical block. By Section 4
we need consider inspections only in its bounded difference band and
its r-neighborhood. Only endpoints within the band's 2r-neighborhood
can be changed by those inspections. Every r-step walk to any such
endpoint stays within the band's 3r-neighborhood. Thus a finite
exhaustive test using actual grid adjacency decides the edge and can
store a witness. This
is a parameter-dependent finite computation; no efficient preprocessing
bound is asserted.

More explicitly, it is enough to enumerate the possible time-indexed
inspection subsets in the r-enlarged bands with at most m total rooms
on each day. Start the finite simulation with the restriction of P₀
to the 3r-enlarged bands, and compare its final membership with P₁ on
the 2r-enlarged bands only. All paths to these checked endpoints lie
inside the simulation domain, so this comparison is exact. Outside
the checked bands no inspection can affect the endpoint, and the
uninspected baseline already equals P₁. First reject a candidate
endpoint unless P₁⊆N^r(P₀), an exact comparison of pyramid cutoffs.
The initial and desired memberships are supplied by these cutoffs.

For boundary edges the same test uses a slab incident to the actual
left or right end. If both ends occur, the two slabs are disjoint and
separated by more than 2L because n≥10R. They can be tested together,
retaining their shared daily quota. The intervening uniform region
cannot communicate between them during r days. The only dependence on
n is the color at the far end, hence n mod 2. All boundary endpoint
shapes and deficits lie in fixed collars, so there are only finitely
many such tests. Exact equality of endpoints can alternatively be
checked by the ordinary finite-horizon survivor-envelope recurrence,
but no compression theorem is needed for this finite gadget.

Let C_n be the resulting canonical graph. For s∈C_n define

    F_n(empty,empty)=0,
    F_n(s)=min { r+F_n(t) : a stored duration-r edge s→t exists }.  (6)

The minimum is interpreted as the nonnegative shortest-path value; every
edge has positive duration. We include all edges of duration at most L,
not just those that happen to be efficient. The clean-checkpoint proof
gives an optimal physical path in C_n. Each stored edge is a physical
block, so every graph path is a physical strategy. Thus

    T_m(Q □ P_n)=F_n(full,full).                        (7)

The number of interior edge types is finite, each has bounded counter
displacement, and the boundary graph is finite. Hence |C_n|=O_b(n) and
|E(C_n)|=O_(Q,m)(n). Dijkstra's algorithm gives the stated O(n log n)
bound for fixed Q,m. One can generate neighbors from the table rather
than store the entire graph. At every recovered edge, translate its
stored local inspection schedule to obtain an optimal physical strategy.

## 7. Scope and remaining evaluation problem

The theorem gives a geometric normal form at boundedly separated
checkpoints. It neither removes the arbitrary supports *inside* a local
edge nor contradicts the known partial-state and varying-quota failures
of smaller daily prefix/interval families. The constants arise from
optimality at a constant budget and the proved height upper bound;
there is no assertion for arbitrary prescribed quota words or arbitrary
starting supports.

This is stronger than merely saying that all sufficiently large lengths
obey an eventual period: it exhibits the exact finite interface and
bounded physical transition gadget throughout every sufficiently long
cylinder, with a linearly sized graph and finitely many explicitly
bounded short exceptions. Its geometry is uniform in b,m. Preprocessing
may nevertheless be extremely large, and (6) is not a simple closed
formula in all three parameters.

The finite min-plus summary in the next section evaluates the graph
without imposing any monotone motion of the cut. Its proof retains
arbitrarily many excursions through a segment's boundary.

## 8. Exact evaluation by associative boundary summaries

**Theorem (logarithmic dependence on longitudinal length).** After an
effective finite preprocessing depending only on Q,m, the exact value
T_m(Q □ P_n) can be computed using O_(Q,m)(log(n+1)) integer
arithmetic operations. The computation also produces a finite compressed
description of an optimal physical strategy. Expanding that description
into its actual inspections takes additional time proportional to the
output size. This is an exact finite-interface recurrence, not a claimed
elementary closed expression in Q,m,n.

### A general finite-graph composition lemma

Consider a directed weighted graph made of a sequence of blocks, with
at most a fixed q₀ vertices in each block. All edge weights are
nonnegative. Edges join vertices in the same or adjacent blocks only.
For a nonempty interval of blocks I, define its summary S(I) as the
all-pairs shortest-path distances among the vertices in its first and
last blocks, with all paths constrained to stay in I. Retain *every*
ordered pair, including pairs lying on the same end. Use ∞ for an
unreachable pair and zero on the diagonal.

For a one-block interval its left and right ports are two labeled copies
of the same vertices. Set their pairwise distances equal to the actual
within-block distances. In particular corresponding copies are joined
at zero cost; this avoids a variable-sized summary.

If consecutive intervals I and J are joined by their actual cross edges,
form an auxiliary graph on their four ports. Put in the distances S(I)
and S(J) as weighted directed edges, and add every actual edge between
the last block of I and the first block of J, in both permitted
directions. Take finite shortest-path closure on this auxiliary graph,
and retain its distances among the outer two ports. The result is
exactly S(I∪J).

Indeed, an actual path in I∪J splits at each cross edge into subpaths
wholly inside I or J. Replacing each such subpath by its summary distance
can only shorten it and gives an auxiliary walk. Conversely, every
finite auxiliary walk can be expanded into actual within-interval
shortest paths and actual cross edges. The infima therefore agree.
Nonnegative weights ensure that all finite shortest distances are
attained; repeated crossings are fully permitted. In particular the
composition is associative whenever the cross-edge pattern is fixed:
both parenthesizations summarize the same concatenated physical graph.

Equivalently, this is an operation on 2q₀-by-2q₀ matrices over
`(N∪{∞}, min, +)`, implemented by shortest-path closure on at most 4q₀
vertices. It needs a fixed number of arithmetic operations. It is not
ordinary entrywise matrix multiplication, and no assertion that a path
crosses each interface only once is being made.

### Apply the lemma to the canonical graph

Use the physical counter encoding of Section 6. Every height shape is
available, and every local edge is translation invariant, when the
entire gadget is away from the two ends. One may, for example, use the
common counter interval

    R ≤ z ≤ floor((n−2−2R)/2).                            (8)

Its length is J_n=floor(n/2)−2R. Every control has valid physical heights
there, since their ranges are at most w−1 and R dominates all local
propagation bounds. All canonical states outside (8), together with the
full/empty states, form a bounded end family; their number depends only
on b,m. Use the homogeneous edge table whenever both endpoints lie in
(8). The whole edge gadget then misses the physical ends.

Let H=R. The conservative bound (5), including the color correction in
z=(a_0−p)/2, is smaller than H for r≤L. Group H consecutive counter
levels into one block. An interior edge can then join only the same
or adjacent blocks. Every full block has the same finite graph on
q₀=H times the number of finite controls. Its cross-edge pattern is
also fixed. Invalid or unused controls can harmlessly be retained as
isolated vertices, so the dimension is fixed.

Write J_n=kH+t, 0≤t<H. Absorb the final t levels into the right end
family. For n≥n₀ there is at least one full block (in fact n≥10R gives
J_n≥3R). A boundary state can be adjacent to interior states only in
the first or last full block: ordinary displacements are bounded by H,
and every owner/orientation-changing edge already has both endpoints
in bounded end collars. Edges directly connecting the left and right
end families, including global full/empty transitions, are allowed;
their existence belongs to the finite boundary table of Section 6.

The resulting graph consists of k identical blocks plus a bounded
collection of end vertices and exceptional end-to-end edges. The latter
table depends only on n mod 2 and t, a finite number of cases. Its
counter locations are interpreted relative to the appropriate physical
end. Long end-to-end edges are *not* included in the homogeneous strip;
they are inserted in the final closure below.

Let S₁ be the one-block summary and let `⊙` be the associative composition
just proved, using the fixed cross-edge pattern. Compute

    S_k = S₁ ⊙ S₁ ⊙ ... ⊙ S₁   (k factors)                (9)

by binary powering in O(log k) compositions. An identity element is
unnecessary: use a first nonempty factor as the accumulator. Attach all
end vertices, their internal and end-to-end edges, and their edges to
the first/last block ports. One final finite shortest-path closure gives
the distance from full/full to empty/empty. By Section 6 that distance
is exactly T_m.

This final closure also permits entering the homogeneous strip, returning
to the same end, changing owner, entering again, or using a remote-end
edge in any order. All such possibilities are represented by the full
ordered-pair summaries; none is excluded by a serial or sweep assumption.

### Preprocessing, arithmetic size, and witnesses

Construct the finite local physical edge tables and finite boundary
cases by the exhaustive local tests in Section 6. Store the finitely
many short-length optima separately. The preprocessing size may be very
large as a function of Q,m; the result isolates the dependence on n,
rather than hiding the parameter cost in a claimed small constant.

Every finite distance used in a summary is bounded by the number of
vertices times the largest edge duration L: with nonnegative weights,
a shortest path can be chosen without a positive cycle. Thus its binary
length is O_(Q,m)(log(n+1)). The asserted logarithmic operation count
is an arithmetic bound; ordinary bit complexity also includes the cost
of those integer additions and comparisons.

Store shortest-path choices in each closure and retain the binary
composition tree. Expanding a summary edge recursively recovers the
sequence of canonical macroedges, and each macroedge carries a verified
physical inspection block. This supplies a compressed optimal strategy
with O_(Q,m)(log(n+1)) stored construction data. Printing every individual
inspection necessarily costs at least its output length. The existence
of the compressed witness does not assert constant-size explicit room
lists for arbitrarily long boards.

## 9. Odd-order Hamiltonian cross-sections at even lengths

The same finite-interface theorem also covers the parity case where
there is no transverse perfect matching. This extension uses the already
proved history-bit clean-day theorem, but the resulting exact state
graph needs no extra history coordinate.

Let Q be bipartite with a Hamiltonian path and odd order A=2b+1≥3.
Fix m≥b+1, put α=b+1 and D=2m−A>0, and restrict the longitudinal length
n to even integers. Set

    K = A²,
    B = 8K+8m+2A,
    L₁ = K+m+1,
    E = B+2L₁(B+1),
    L = E+1,
    q = (m+α)L,
    R = 100(q+A²+L+A+1),
    n₀ = max(A, floor((4K+2m+1+D)/A)+1, 10R).             (10)

**Theorem (odd order, even length).** After a finite preprocessing
depending only on Q,m, the exact value T_m(Q □ P_n), for every even n≥2,
is obtained in O_(Q,m)(log(n+1)) arithmetic operations. It has the same
bounded physical macro-state graph and compressed optimal strategy
description as in Sections 1–8. The finitely many even n<n₀ are direct
exceptions. The family of canonical states is the physical Q-pyramid
family of Section 2, with at most one proper cohort and a full/empty mate.

Here are all changes needed in the proof.

### Matching, shape closure, and free expansion

Match consecutive longitudinal columns, (0,1),(2,3),…, within each Q
fiber. Since n is even, this is a perfect matching of the whole cylinder
between its two equal checkerboard classes, each of size h=An/2. Thus
|N(S)|≥|S| for every support S, and an r-day block cannot reduce a
cohort's size by more than mr.

The predecessor definition, ±1 height conditions on every Q edge, exact
neighborhood closure, and empty-fiber bound of Section 2 do not require
even A. They hold verbatim with w=A. The only cardinality change is that
the sums of the two fiber parity vectors differ by one. Consequently,
using the same exact cutoff rule and η(a)_v≤a_v+1,

    |N(P)|−|P|
       = (Σ_v(η(a)_v−a_v)+Σ_v s_v−Σ_v(1−s_v))/2
       ≤ (A+1)/2 = α.                                   (11)

The lower bound is the longitudinal matching. In particular N^r(P)
is a same-oriented pyramid with size between |P| and |P|+αr. All
localization and collar proofs therefore hold with b replaced by α
in these free-growth estimates. In the height/count comparison across
an r-day block, the parity-sum correction has absolute value at most
one. Increasing the already conservative displacement estimate by two
covers it; the R in (10) is still strictly larger than every displacement
and every local propagation margin.

### Actual canonical checkpoints on every clean phase

We use `lem:paired-minimum-frontier`, `lem:paired-frontier-bridge`,
`eq:paired-efficient-cases`, and `eq:paired-nonclean-count` in
`paper/sections/even-cylinder-eventual-time.tex`. They apply to the
physical cylinder and arbitrary strategies, not to an assumed prefix
relaxation. We spell out the bridge needed here.

The two bipartition sizes of Q are b+1 and b. Matching the longitudinal
column pairs identifies each current-color cohort with an A-by-(n/2)
array. On a strict-middle survivor, the least surplus is b. Such a
survivor is a prefix in one physical phase and a suffix in the other;
its paired-fiber lengths differ by at most one across Q edges, in the
specified direction. Two consecutive strict-middle survivors cannot
both have surplus b.

For each cohort let e_t indicate that its preceding survivor was strict
middle with surplus b. Use the rank 2k_t+e_t and clipped potential

    ψ_t=min(C,max(0,2k_t+e_t−2(K+m)−1)),
    C=2h−4K−2m−1>D.

The proved potential inequality bounds a cohort's daily loss by
max(0,2p−A) when it receives p useful inspections. The two-cohort daily
bound is D. The height upper bound gives at most B integer slack, so
at most B days are inefficient. Efficient days allocate all m useful
inspections to one owner and have exactly the two possibilities

    (surplus, old bit, new bit) = (b,0,1) or (b+1,1,0).    (12)

In the first case the survivor is a physical pyramid by the minimum-
surplus lemma. In the second case, its preceding survivor was a
strict-middle surplus-b pyramid, and actual containment in that
survivor's neighborhood is precisely the hypothesis of the proved
intervening-frontier lemma. That lemma makes the new survivor a
same-oriented physical pyramid as well. In physical coordinates,
paired length l_v and required parity σ_v give a_v=2(l_v−1)+σ_v;
the stated length relations give |a_u−a_v|=1 on every Q edge in both
phases. Thus *both* efficient phases, not only every other day, have
the Q-pyramid shape required here.

The matching-contracted graph is strongly connected when n/2≥2.
An untouched proper nonempty cohort gains at least one room per day,
while its history bit can drop by at most one. Its raw rank gains at
least one. The already proved owner-block argument then gives at most
2(B+1) blocks and, after marking their first L₁ days together with the
inefficient days, at most E nonclean days. On every clean day the mate
is literally full or empty and the source is the neighborhood of a
preceding efficient pyramid. It is therefore canonical. Our n₀ ensures
both C>D and n/2≥2.

Partition at the sources of these clean days exactly as in Section 3.
The gap is at most E+1=L. No doubling of the gap is needed, because the
intervening surplus-b+1 phase has just been included. The initial and
final states are canonical as before.

The history bit is used only to prove that these checkpoints exist in
an optimum. It need not be stored in a macro state: every graph edge
is defined and verified by an actual finite inspection block between
physical supports. Concatenating two such blocks is valid regardless
of the historical rank at the join. Conversely the original optimum
supplies an actual path through the graph. Discarding the bit therefore
loses neither direction of the shortest-path equality; it does not
replace a physical condition by an incompatible scalar transition.

### Local gadgets and powering

For each canonical-to-canonical r-day block, put D_bad=N^r(P₀)\P₁.
Equation (11) and the longitudinal matching give

    |D_bad|≤(m+α)r.

The avoiding-walk localization is independent of every parity assumption,
and keeps exactly the same endpoint. The same-orientation band bound,
the opposite-orientation empty-fiber/full-fiber alternative, and the
size/deficit end-collar bounds apply with these constants. Owner changes
are again confined to the end families. The two opposite end gadgets
cannot communicate within r≤L days when n≥10R, but their shared daily
quota is kept in the same finite test. The precise r/2r/3r simulation
cone remains valid in the physical longitudinal coordinate; there is
no need to contract the local game into paired columns.

Every current-color Q-pyramid is encoded by its Hamiltonian height walk,
filtered by extra Q edges, and its physical counter z. Translation by
two columns preserves parity. The common counter interval (8), now
with the R from (10), consists of J_n=n/2−2R homogeneous levels.
Group R levels at a time and use exactly the summary composition and
final end closure of Section 8. The only boundary-table case is the
bounded remainder modulo R, since n is already even. This proves the
theorem, including exact physical witness recovery.

### Combined uniform consequence

For any fixed bipartite Hamiltonian Q of order A≥2 and integer m>A/2,
the preceding constructions give an exact finite-interface/min-plus
algorithm with logarithmic dependence on n whenever An is even.
For A even both longitudinal parities are covered; for A odd the even
lengths are covered. Its preprocessing depends only on Q,m, and every
short exception has an explicitly bounded length.

In particular, taking Q to be the shorter path gives one uniform
algorithm for every even-area rectangle with both sides at least two,
at every feasible budget. Together with the already solved one-row path
case, this covers **every even-area rectangle at every feasible budget**.
This subsumes the separate even-short and odd-short/even-long dynamic
state reductions at the algorithmic level. Closed formulas for special
budget regimes remain useful evaluations of this general recurrence;
the theorem does not turn them into a single elementary expression.
Odd-area rectangles remain governed by their separately proved odd-box
profile theorem and the companion odd-rectangle evaluation work.

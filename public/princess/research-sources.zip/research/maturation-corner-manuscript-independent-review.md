# Independent assembly review of the corner-memory section

13 September 2026. Socrates. **PASS, ordinary mathematical audit.**

Reviewed `paper/sections/corner-memory.tex` against the accepted conditional
profiles, the punctured-quadrant capacity theorem, and the independently
reviewed localization proof. This is a read-only assembly review, not a new
finite check or a Lean certificate.

The four marginal restrictions retain their exact conditions and all-size
attainment. In particular, outgoing-corner absence has capacity b²−1 at
surplus b, so its transition to surplus b+1 occurs at k=b². In the
boundary-free-row branch the excluded equality would be the full even
triangle reaching transverse coordinate 2b−2, which cannot lie before the
empty matched row. In the no-free-row branch the last prefix is empty and
the stated odd-rung sum is b²−1.

The joint restriction retains every critical b+1 case: origin addition,
one-sided/two-sided free-row decompositions, an exceptional internal row,
and both exceptional endpoint intervals. The weighted bound does not
silently assume that the exceptional internal row is an interval. The
attaining constructions retain the forced-room guards needed before
deleting either two or three rooms; the width-two coincidence is handled
separately. Intermediate cardinalities are explicitly supplied.

The localization corollary preserves the strict propagation offsets and
counts movements from the survivor. It uses connectivity of the raw
support and occupancy of raw diagonals, rather than assuming a compressed
support. The final finite-board qualification correctly requires each
profile source to avoid the far longitudinal row. The text explicitly
declines a dynamic sufficiency theorem for availability bits and does not
promote the width-fourteen partial-state diagnostic into a full-board
capture time.

No mathematical correction is requested.

# Manuscript consolidation

12 September2026. Retain every accepted result while replacing redundant
proofs with consequences of stronger theorems and ordering by dependencies.

The first pass compiles to95 pages, down from99 with the same formatting.
The general odd-rectangle high-budget theorem now precedes its narrow-grid
applications. Its b=2,m=5 boundary case uses C>=5q+3 (q=n-2,r=4),
which excludes2q+1 days; the generic sweeps attain2q+2. An independent
agent reviewed this argument and its hypotheses. It removes the former
dependency on the five-row theorem. Three-row odd-length proofs and
five-row odd-length proofs for m>=5 are now specializations, with
explicit J/delta substitutions. Their formulas and physical strategies
are retained. Historical proofs remain in version history/research notes.

The older odd eventual-period proof remains a genuine dependency of the
both-parity theorem, so it cannot be dropped by relabeling it a corollary.
Future consolidation must establish a common efficient-day/height-passage
lemma before deleting these separate arguments. General mechanisms, their
2D applications, and higher-dimensional applications should be grouped.
Formal coverage and provenance must remain precise.

# The critical corner dichotomy on even-width rectangles

13 September 2026. Ordinary proof independently reviewed and accepted by root.
The review covered the half-strip reduction, near-square fibers, all square
cover patterns, the central symmetric-difference/rung argument, and the
b=2 complementary endpoint without circularity.
This is a necessary profile theorem for arbitrary physical supports. It does
not claim that every allowed profile, or every path of profiles, is attainable.
The subcritical theorem, capacities F and G, and whole-half-strip corner
bounds used below already have separate ordinary proofs and review.

## Statement and its relation to the odd-width theorem

Let the board be 2b by n, with b>=1 and n>=2b, and put h=bn. For a support
S of one physical color let a=|S|, s=|N(S)|-|S|, i be the number of its two
own-colored board corners present, and j the number of opposite-colored
board corners in N(S). All neighborhoods are in the entire finite board.
Use F and G from `resumed-even-corner-profile.md`.

**Theorem.** At s=b one has

    a <= F_(i,j)(b)  OR  h-a-b <= G_(i,j)(b)

unless (i,j)=(1,1), or n=2b+1 and (i,j)=(2,0).

Combined with the independently proved odd-width theorem, the exceptions
have a symmetric description. On an even-area rectangle, put
b=floor(min(w,n)/2). At surplus b the F/G alternative holds, apart from
(1,1) when the board has a side 2b, and (2,0) when it has a side 2b+1.
These alternatives are permitted exceptions, not an assertion that every
size in them is physically realizable. No new exception is allowed for
longer even-width rectangles or for even squares.

The new issue is the square endpoint. A minimum vertex cover of P_(2b)
need not be alternating; the proof below treats all b+1 such covers.
The near-square 2b by (2b+1) really needs the additional (2,0) channel.
Rotated physical pyramids give examples on 4x5, 6x7, and 8x9; a check
using only the other pyramid orientation would miss them.

## 1. An empty pair of columns reduces to whole half-strips

Match adjacent rooms across the 2b side. The contraction has b rows and
n columns, horizontal bidirectional edges, and alternating downward and
upward vertical rungs. Reflect the physical board if necessary to make
even columns downward. Write R for the contracted support and B for its
outside boundary. Then |B|=b, R is disjoint from B, and R is outgoing
closed in D minus B.

If two adjacent columns avoid B, those two columns form a strongly
connected ladder, even if every matched row is marked. R contains all
of this ladder or none of it. In the latter case the two physical columns
contain neither S nor its neighborhood; cutting there splits S into two
pieces whose neighborhoods are disjoint and unchanged in the whole
half-strips of width 2b based at the two longitudinal ends. The pieces'
sizes, surpluses, and corner counts add.

If both pieces are nonempty, each has positive surplus less than b.
Each therefore has an empty matched row and splits into its two true
quadrants. The same four-piece convex capacity argument as in the
subcritical theorem gives a<=F_(i,j)(b).

If only one piece is nonempty, its surplus is b. The exact whole-half-strip
bounds in `paper/sections/corner-memory.tex` give the following capacities
according to its single current and single outgoing corner bits:

    (0,0): C2(b);   (0,1): b(b-1);   (1,0): b^2-1;
    (1,1): no finite critical capacity asserted.

The first three fit F_(i,j)(b); the last gives (i,j)=(1,1). The statement
for (0,0), including b=1, follows from the joint-omission profile.

If R contains the ladder, instead use U=V_other minus N(S). Its contracted
support in the transpose avoids the ladder. Write t=|N(U)|-|U|<=b and
d=its outgoing corner count, so its current corner count is 2-j. If t<b,
its two half-strip pieces have the usual first-branch quadrant capacity.
If t=b, the preceding argument gives that capacity or its exception (1,1).
The slack identity

    |(V_current minus S) minus N(U)|=b-t

charges 2-i-d missing corners, giving t<=b-2+i+d and hence the G branch.
If U uses the critical exception, t=b forces zero slack and d=2-i;
therefore original i=j=1 as well.

This proves F/G or (1,1) whenever an adjacent pair is unmarked. It already
settles n>=2b+2, since b marked columns cannot cover all edges of P_n.

## 2. The near-square without an unmarked adjacent pair

Let n=2b+1. A vertex cover of P_(2b+1) using b columns consists exactly of
the odd columns, each carrying one boundary vertex. Every even clean
column is a downward prefix of length t_q, q=0,...,b, in {0,...,b}.
If v is the marked column between clean neighbors q,q+1, horizontal
closure gives

    R_v subset R_q and R_(q+1),
    R_q minus R_v subset {boundary_v},
    R_(q+1) minus R_v subset {boundary_v}.

Thus |t_(q+1)-t_q|<=1, and

    |R_v|<=min(t_q,t_(q+1)),
    b-|R_v|<=min(b-t_q,b-t_(q+1))+1.             (2.1)

The two current corners correspond to nonempty endpoint clean fibers;
the outgoing corners correspond to full endpoint clean fibers. The
bounds from the odd-width alternating-fiber proof still hold with
matched height b:

* i=0,j=0: a<=b(b-1)/2<=F00(b).
* i=1,j=0: a<=b^2=F10(b).
* i=2,j=0: allow the (2,0) exception.
* i=2,j=1: h-a<=b(b+1), so h-a-b<=b^2=G21(b).
* i=2,j=2: h-a<=b(b+1)/2, so h-a-b<=C2(b)=G22(b).

Here the only additional possibility, compared with matched height>b,
is a full endpoint at one end and an empty endpoint at the other. It has
i=j=1, which is precisely the other exception. There are no other corner
pairs: i=0 excludes j>0, and j=2 forces i=2. This proves the near-square.

## 3. Classifying the square's possible column patterns

Now n=2b, and assume again no adjacent columns avoid B. There must be
exactly b marked columns, one boundary vertex in each. Their complement
is a maximum independent set of P_(2b). Such a set is exactly

    0,2,...,2ell-2;  2ell+1,2ell+3,...,2b-1      (3.1)

for some ell in {0,...,b}. Indeed b increasing nonadjacent positions
need span at least 2b-2, leaving only one unit of slack, which may be
at either end or in one interior gap. This proves the b+1-pattern
classification; it does not assume that every cover is alternating.

Clean even fibers are prefixes and clean odd fibers are suffixes.
Across a single marked column, consecutive clean lengths of the same
orientation differ by at most one, and the size/deficiency bounds (2.1)
hold. The two pure patterns ell=0,b are reflections of one another.
We treat ell=b explicitly, then 1<=ell<=b-1.

## 4. Pure alternating square pattern

The b clean even columns have prefix lengths t_0,...,t_(b-1). Between
each pair lies a marked odd column. There is also a final marked odd
column v_last. Its fiber is contained in the last prefix and differs
from that prefix by at most its one boundary vertex.

The last clean prefix is nonempty. Otherwise its marked neighbor would
be empty and have no neighbor in R at all, contradicting that its mark
is an actual outside-boundary vertex. Consequently the outgoing corner
at the lower right is always present: either the last marked fiber
contains its bottom vertex, or that vertex is its unique boundary mark.
The current corner at the lower left is present exactly when t_0>0;
the outgoing corner at the upper left exactly when t_0=b. The current
corner at the upper right can be present only if t_(b-1)=b. The latter
forces t_0>=1 by the unit slope bound.

If i=0, then t_0=0 and j=1. The bounds t_q<=q, the internal marked-size
bounds, and |R_v_last|<=t_(b-1) sum to

    a <= b(b-1)/2 + (b-1)(b-2)/2 + (b-1)
      = b(b-1)=F01(b).

The pair i=j=1 is allowed. Every remaining possibility has a full clean
endpoint. If the left endpoint is full, put d_q=b-t_q<=q. The clean
fiber deficiencies sum to at most b(b-1)/2; internal marked deficiencies
to at most b(b-1)/2; the final marked deficiency to at most b. Thus
h-a<=b^2. If the right endpoint is full the analogous bound is sharper,
h-a<=b(b-1)+1. In particular the pairs (i,j)=(1,2) and (2,1) have

    h-a-b <= b(b-1),

which is G12(b) and is at most G21(b), respectively.

Finally i=j=2 makes both clean endpoints full. Then

d_q<=min(q,b-1-q), and the elementary sum is

    sum_q d_q + sum_(q=0)^(b-2) min(d_q,d_(q+1))
       <= (b-1)(b-2)/2.

The one allowed missing vertex in each of the b marked fibers gives
h-a<=b+(b-1)(b-2)/2. Therefore
h-a-b<=(b-1)(b-2)/2<=C2(b)=G22(b).
This covers every possibility, including b=1. Reflection covers the
other pure pattern without changing corner counts.

## 5. A mixed square pattern: the two central fibers

Let 1<=ell<=b-1 and d=b-ell. There are ell clean prefixes on the left
and d clean suffixes on the right. Let P=[0,L-1] be the central clean
prefix and Q=[b-R,b-1] the central clean suffix. Between them are two
adjacent marked columns: an upward column A with boundary mark alpha,
and a downward column Z with boundary mark beta. Horizontal closure gives

    A subset P, P minus A subset {alpha};
    Z subset Q, Q minus Z subset {beta};
    A minus Z subset {beta}, Z minus A subset {alpha}.

Thus P symmetric-difference Q is contained in {alpha,beta}. For a prefix
and suffix in b rows its size is min(L+R,2b-L-R), so

    L+R<=2  OR  L+R>=2b-2.                       (5.1)

The clean fibers' unit slopes and the marked-size bounds imply

    a <= 2ell*L+2d*R+(ell-1)^2+(d-1)^2.          (5.2)

For clarity, on the left the clean fibers sum to at most
ell*L+ell(ell-1)/2, the ell-1 internal marked fibers to at most
(ell-1)*L+(ell-1)(ell-2)/2, and central A to at most L. The right
side is identical with ell,L replaced by d,R. No marked fiber has been
assumed to be a prefix or suffix.

### 5a. Small central total

Suppose L+R<=2. Bound (5.2) is at most b^2: allocate the at most two
units to the longer side; writing ell>=d gives
b^2-2(d-1)(ell+1)<=b^2.

If an outgoing corner is present, its endpoint clean fiber is full.
On the left this requires b<=L+ell-1, or d+1<=L. The central total
then forces d=1,L=2,R=0; the right endpoint is empty. Thus i=j=1.
The same conclusion holds by reflection for an outgoing corner at the
other end. It remains to consider j=0.

If i=0, both outer clean fibers are empty. Bounding each half from that
outer empty endpoint instead of its center gives

    a<=ell(ell-1)+d(d-1)<=(b-1)(b-2)<=C2(b)=F00(b).

If i=1, the generic bound a<=b^2 gives F10(b). If i=2, we need
F20(b)=(b-1)^2+1. There are only three central possibilities to check.

* If L+R<=1, (5.2) is at most
  2max(ell,d)+(ell-1)^2+(d-1)^2 <= (b-1)^2+1.
* If (L,R)=(2,0), the right outer endpoint must still be nonempty,
  so d>=2. Then (5.2) is at most
  b^2-2(d-1)(ell+1) <= b^2-2b+2.
  The inequality reduces to ell(d-2)>=0. Reflect for (0,2).
* If L=R=1 and b>=3, both central marked fibers are empty.
  Indeed P={0}, Q={b-1}. The horizontal relations permit either both
  fibers empty or both singleton fibers. One empty and one singleton
  would require the two distinct values 0,b-1 to be the same boundary
  mark. If both are singletons, alpha=b-1 and beta=0. The upward rung
  out of A={0} forces 1=alpha, hence b=2, a contradiction.
  Removing the two central upper estimates from (5.2) gives
  a<=ell^2+d^2<=(b-1)^2+1.

The sole small endpoint b=2,ell=d=1,L=R=1 is explicit: both central
fibers empty gives a=2=F20(2). If both are singleton, a=4 and
h-a-b=8-4-2=2=G20(2). Thus it also satisfies the stated dichotomy.

### 5b. Large central total and the complement

Handle the small-total case first; suppose now L+R>2 and L+R>=2b-2.
Use U=V_other minus N(S), whose true surplus t is at most b. On a clean
column U is exactly the complement of R. After reversing vertical
orientation, its two central lengths are b-L and b-R, totaling at most
two. It is closed in the transposed graph outside the same marked set B,
although its actual boundary may be a subset of B. Consequently the
purely horizontal/slope estimate (5.2) applies and gives |U|<=b^2.

If t<b, apply the accepted subcritical dichotomy to U. Its high branch
is impossible, since

    h-|U|-t >= b^2-b+1 > (b-1)^2 >= G_(any pair)(t).

Therefore U has its low F branch. The usual missing-corner slack
t<=b-2+i+d then gives the G branch for S.

If t=b, the actual boundary of U equals B. The small-central proof just
given applies verbatim to U in the transpose. A low F branch gives the
G branch for S by zero slack. Its (1,1) exception becomes (1,1) for S,
again by zero slack. The small b=2 configuration that used its own high
branch cannot occur here: it requires complement central total two,
whereas L+R>2 and b=2 make that total strictly less than two.
Thus there is no circular appeal to a yet-unproved square theorem.
This completes the mixed pattern and the theorem.

## Status, checks, and remaining boundary

This proof is entirely about physical supports and static necessary
capacities. It needs no compression theorem and no enumeration of
partial strategies. It adds no claim about the sharpness of the corner
model, a closed numerical capture clock, or an explicit optimal strategy.
The separate merger theorem can incorporate this critical filter now that
the proof has passed independent review, because it retains every F/G
profile; the algebraic closure argument is recorded separately.

Finite literal-support and simple algebra checks are recorded in
`resumed-even-corner-critical-check.json`. They are a falsification check,
not a replacement for the argument above.

Independent finite checking passed all 5,354 critical supports among
1,223,480 literal subsets on 11 boards, including both physical colors;
the split inequalities passed all 19,900 positive splits through b=200.
CPU time was 0.21 seconds. Manuscript-ready source is
`paper/sections/resumed-even-critical-extension.tex`, not yet wired here.

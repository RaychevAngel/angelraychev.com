# Exact capture time on every 25 by even-length rectangle

13 September 2026. New ordinary uniform transfer proof using an independently
checked finite terminal exclusion. Independently reviewed and accepted by
the lower-geometry lane and by root, including the frozen-radius weakening,
terminal hull, full guarded merger, and even-length cut. This replaces the
earlier two-day bracket for this family; the older unflagged calculation is
retained as a proved dependency. No flagged interval-closure assertion is used.

## Statement

For every even n>=26,

    T_13(25,n)=50n-925.

Write h=25n/2>=325. The lower uses the accepted joint day-28 theorem,
the persistent two-radius corner-reach restriction, and the exact ordinary
nine-frontier recurrence after discarding that memory. The upper is an
explicit physical prefix search and reflected central construction.

## 1. A finite terminal exclusion which transfers to every length

The old, unflagged capture frontier has B_70(c,e)=157 in all nine feature
classes, uniformly for h>=325, as proved in `bridge-boundary-numeric-25.md`.
Moreover every successful path of at most70 days from any starting state
remains at sizes at most157: its state at time j belongs to the old
backward set with horizon70-j, contained in B_70 by monotonicity.

Within this size range the necessary transition graph is independent of
h>=325. Indeed, every target has at least h-157>=168 holes. All high
capacities below closed surplus13 are at most144; all high-side pronic
bands and near-square flags have at most144 holes. They are inactive.
All feature upper-size caps are inactive as well. The remaining low
quadratics, exact triangle triggers, and subcritical square triggers
depend only on the fixed width25 and budget13.

Freeze the persistent radius feature thresholds at n0=26, and replace
all radii at least25+26-2=49 by infinity. This is a valid weakening for
every larger even n: increasing n can only reduce the number of distant
corners or their neighbors lying within any given radius. Propagation
by swapping coordinates and adding one, and tightening by local triangle
events, continue to be valid. No anchor identification is introduced.
This frozen model, restricted to sizes<=157, is the same finite model
at every allowed length.

The independently implemented grouped-radius search, without comparison
between distinct radius pairs, verifies that each state

    (157,c=0,e), e=0,1,2,

starting with both radius bounds infinite, needs71 days to capture.
The receipt is `bridge-upper-transport-terminal-feature-verified.json`.
It examines every admitted successor and excludes a capture by day70.
Initial finite radii only remove paths, so the exclusion also applies to
every incoming persistent history. Larger sizes cannot clear in70 days
even in the old unflagged model, by B_70=157.

Therefore every state capturable within70 days in the persistent model
is contained in the following ordinary coordinatewise interval hull:

    D_70(c,e)=156 if c=0, and157 if c=1 or2.

This is a NECESSARY UPPER ENVELOPE of the capturable set. We neither claim
that every state in the hull is capturable nor that flagged reachable
sets are intervals. Only the three excluded size157 states were needed
for the stronger envelope; checks of the other features are corroboration.

## 2. One old update and the exact unbounded plateau

Discard the persistent information when taking predecessors of this
hull. The ordinary nine-frontier theorem gives an exact interval
predecessor in the weaker model and thus a valid upper envelope for the
stronger model. One fixed substitution gives

    D_70 -> E(157),

where E(a) denotes the all-a vector. This substitution is independent
of h>=325: its target sizes are156 and157, so the same high-branch and
state-cap inactivity argument applies. For a direct proof, the maximum
low target capacities at closed surpluses11 and12 are132 and156.
Thus every target156 or157 requires closed surplus at least12; a
target157 requires at least13, since the sole critical surplus12
exception has target corner class j=0, whose hull threshold is156.
Original surplus is closed surplus plus delta>=0. Every predecessor
contribution is therefore at most13+156-12=157 or13+157-13=157.
Equality for every source feature uses target(j,v)=(1,0) of size157,
survivor i=u=0, and unrestricted closed surplus13. Its deletion charge
is at most4<=13 and survivor maximality holds. This proves the update
without treating a computer substitution as the unbounded argument.

The old capture calculation had E(157) at day70. The new necessary
envelope only reaches it at day71. The previous ordinary plateau proof
applies without modification:

    E(a) -> C(a) -> E(a+1), 157<=a<=h-134,

where C(a) has a in own-corner classes0,1 and a+1 in class2. After
h-290 pairs, the necessary envelope is E(h-133) at time

    71+2(h-290)=2h-509.

The fixed high-side exit table is also unchanged. Eighteen updates from
the all133 deficit vector yield deficits

    (113,113,113,112,112,112,112,112,112),

in feature order(0,0),(0,1),(0,2),(1,0),...,(2,2). Thus at the total
model deadline

    N=2h-491

the necessary envelope has maximum size h-112. No persistent-model
state of size at least h-111 can therefore be captured within N days,
regardless of its feature class or incoming radii. This conclusion
uses one fixed terminal exclusion and one exact plateau invariant;
it does not extrapolate the finite n26,n28,n30 diagnostics.

## 3. The joint lower bound, with the guard made explicit

Put L=N+28=2h-463, and write a_t for physical joint belief size minus h.
The accepted guarded merger applies while a_t>13, including the next
transition at its first crossing to at most13. An early crossing by
time28 would yield a model capture from full size h by time29, impossible
even in the old unflagged model: B_29<=B_70=157<h.

At time28 the jointly proved boundary theorem gives a_28>=h-111. A
first crossing to at most13 at any time t<=L-1 would give a model
capture from that feature within t-28+1<=L-28=N days. This contradicts
the new necessary envelope. Consequently a_(L-1)>13, and after the
next inspection-and-move one still has a_L>0; the merger's positive
survivor and the perfect matching prevent disappearance at that step.

Suppose a full-board strategy succeeded in2L days. Its first L
inspections and moves leave more than h possible rooms. Reverse its
last L inspections: after L-1 inspection-and-move steps the belief
has more than h+13 rooms, and the final inspection still leaves more
than h. Both beliefs lie on the same cut, so they intersect in this
2h-room undirected graph. Their avoiding walks concatenate, a contradiction.
Hence

    T>=2L+1=4h-925=50n-925.

The argument uses the genuinely joint time28 restriction. It does not
sum two separately proved solo restrictions or assume an automatic
time-filtered midpoint theorem.

## 4. A uniformly matching physical construction

Use the proved oriented-prefix construction in
`resumed-odd-even-minimum-upper.md`, equivalently Proposition
`prop:odd-even-minimum-upper` and its proof. At b=12 its width-only
constant is L_12=46. Both full-start prefixes reach the common count

    K=b(b+1)+1=157

after exactly t*=L_12+2h-4b^2-2=25n-532 steps, with opposite current
physical colors. The subsequent profiles are the infinite corner
profiles, independently of n, since all remaining counts are at most157
and h-157>=168 removes both reflected root terms.

Starting this fixed terminal search in phase zero takes70 days and its
last preinspection count is2. Starting it in phase one takes71 days.
This is a fixed70/71-step calculation of the two proved root formulas,
retained in `bridge-boundary-numeric-25-exact-check.json`. Choose the
full-start phase that arrives in phase zero. Its solo duration is

    t*+70=25n-462.

Reflect along the even longitudinal side to supply the corresponding
search for the opposite cohort. Its forward and reversed preparations
each leave a two-room residual on the central day. Inspect their union,
which has at most4 rooms, within budget13. This gives a full strategy
of length2(25n-462)-1=50n-925, matching the joint lower.

## Verification boundaries

The persistent localization and merger are ordinary independently reviewed
proof dependencies. The new finite terminal exclusion is independently
verified without radius dominance. The numerical transfer after its hull
uses the existing exact nine-frontier theorem and the already proved
uniform plateau/exit. `src/bridge_boundary_numeric_25_exact.py` verifies
the fixed new substitution, records the terminal receipt hashes, and
evaluates both physical terminal tails separately from the lower model.

This is an all-length proof, with a fixed finite certificate as one lemma.
It makes no assertion that arbitrary persistent-model paths are physically
attainable, and no new physical-game Lean theorem or manuscript build is
claimed here.

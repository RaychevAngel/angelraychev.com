# A uniform odd-width buffered coupling

13 September 2026. Ordinary proof, independently reviewed and accepted
by the root lane, including the explicit positive-delta domain.

Let `w=2b+1`, `b>=2`, let `n>=w` be even, and put `h=wn/2`.
The critical three-corner model is essential here: its critical b-surplus
steps cannot be repeated arbitrarily through the long middle. Write

    delta=k-b-1,      m=floor(k/2).

For `b+2<=k<h` (so delta>0), suppose

    m-b-1 >= ceil(b²/(2delta)).                            (OC)

With the stated positive-delta hypothesis this condition implies
`k>=2b+1`. Then both couplings in
the linear-budget question hold on these odd-width/even-length boards:

    B_t(2) <= max_p Q_t(p),
    R_t(2) <= max_p P_(t+1)(p).

In particular the accepted critical-three-corner lower bound and an
actual prefix-palindrome upper differ by at most one day. The clean
sufficient budget condition

    k >= ceil(8b/3)+2

implies(OC). This is a uniform linear-budget region below the quadratic
threshold, not a complete result for every `k>=w`.

## The model and physical updates

Let R(q) be the least u with `q<=u²`, and rho(q) the least nonnegative
u with `q<=u(u+1)`. The proved odd-width prefix profiles give physical
backward maps

    F0(x)=min(h,k+x-min(rho(x),b,R(h-x))),
    F1(x)=min(h,k+x-min(R(x),b+1,1+rho(h-x))).

Set `F0(h)=F1(h)=h`; the latter is a separate full-prefix endpoint.
The phase update is `X'0=F0(X1)`, `X'1=F1(X0)`. This follows either
by inverting the prefixes or by the longitudinal-complement identity
in the existing odd-width construction. It does not replace physical
phase alternation by an independently selected phase on each day.

The unconditional isoperimetric inverse has cost

    f(a)=min(rho(a),b,R(h-a)),

so the largest model coordinate satisfies

    a'=B'2 <= min(h,k+a-f(a)),       a=max(0,B2).

After the first update the reachable model vectors satisfy
`B0<=B1<=B2`, `B1<=B0+1`, `B2<=B1+1`. The corner-deletion proof
of adjacent spread applies to the odd critical exception too: losing
the required survivor corner raises surplus from b to b+1, which is
unrestricted. Choosing survivor corner0, a largest target coordinate,
and unrestricted surplus b+1 gives the uniform progress bounds

    B'2 >= min(h,a+delta),
    B'0 >= min(h-2,a+delta).

For small target a, the available capture action of cost at most k
supplies the same inequalities. The initial capture frontier
`(0,-1,-1)` is handled with a=0; its first largest coordinate is k.

We prove a stronger comparison. Start the model either from capture or
a valid all-equal terminal allowance `2<=a0<=h-2`. Start both physical phase thresholds
at `min(h,a0+z)`, where

    k-z>=b+1,      z-b-1>=ceil(b²/(2delta)).                (*)

Then their maximum dominates B2 at every deadline. The required
two choices are `(a0,z)=(0,m)` and `(m,k-m)`. Condition(OC) guarantees
both instances of(*).

## Low entrance: keep the root credit until the common middle

Put

    A=b(b+1)+1,       U=h-b²-1.

For `a<A`, the far-root argument is at least `(b+1)²`, because
`h>=(2b+1)(b+1)`. Hence `f(a)=rho(a)<=b`.
Maintain

    min_p Xp >= H(a),
    H(a)=min(h,a+z-min(b+1,rho(a))).

H is nondecreasing. It holds initially. Let `s=a+k-rho(a)` be the
unclipped scalar successor and set `x=a+z-rho(a)`. If x or the existing
physical lower bound is h, capture is immediate. Otherwise, if s<h and
`v=rho(s)<=b`, then

    x=s-(k-z) <= v(v+1)-(k-z) <= v².

Both physical costs are at most R(x), so their successors are at least
`min(h,s+z-v)=H(s)`. If instead `rho(s)>=b+1`, use the universal
physical cost bound b+1 to obtain `H(s)` directly. The same cost bound
handles `s>=h`: assumption(*) makes the clipped physical successor h.
Since `a'<=min(h,s)` and H is nondecreasing, the invariant follows for
the actual model successor as well.

At the first state with `a>=A`, this gives both physical phases a buffer
of at least

    c=z-b-1.

If this state already lies above U, go directly to the high portion
below with these stronger common-phase bounds.

## Long middle: align two physical phases with two corner coordinates

Whenever `A<=B0<=B2<=U`, all finite low and high branches at surplus
at most b are excluded: their survivor capacities and hole capacities
are at most b². Only the unrestricted cap b+1 and the odd critical
exception `(i,j)=(2,0)` remain. Therefore the exact model update is

    B'0=min(h-2,a+delta),
    B'1=min(h-1,a+delta),
    B'2=min(h,max(a,B0+1)+delta).

Before capture this update produces `B'2-B'0<=1`, including cases
where the source-state upper caps become active. The first middle step
starts with the stronger two-phase entry bounds `Xp>=min(h,a+c)` and
produces the aligned invariant

    X0>=min(h,B2+c),       X1>=min(h,B0+c).

There is no extra credit cost if the entry state has B0<A. Adjacent
spread still gives `B0>=a-2>=A-2`. For survivor corner count i=0, all
low target capacities at surplus at most b are at most b². Therefore
target sizes at least `A-2=b²+b-1>b²` exclude them. The high branches
are excluded by the U condition, and the critical exception requires
i=2. Consequently `B'0=min(h-2,a+delta)` already in this entry case.
For every survivor corner count, target capacities at surplus at most
b-1 are at most `b(b-1)<A-2`, so also
`B'2<=min(h,a+delta+1)`. These bounds suffice to establish the aligned
invariant on that first step, and the progress bound puts B'0>=A.

Indeed physical F0 adds at least delta+1, and F1 adds at least delta.
The same inequalities preserve the alignment on all later middle steps:
`B0+1>=B2` ensures that the first physical phase covers the model's
possible one-room critical bonus, while the second covers B'0.

Thus no credit is spent as the board length increases. If the model
captures in this portion, X0=h by the aligned invariant. A physical
threshold h propagates between the two phases on every later update,
so their maximum remains h thereafter.

## High exit: only alternating steps spend credit

At the first noncaptured state above U, its deficit is at most b².
The aligned middle invariant gives `X0>=min(h,a+c)` and
`X1>=min(h,a+c-1)`. If the middle was skipped, both phase bounds are
at least the stronger first quantity. Follow the physical trajectory
which is in phase0 at this entry; it starts with all c credits.

Above A, f(a)=min(b,R(h-a)) is nonincreasing. On inputs X>=a, the
physical F0 cost is at most f(a), and F1 costs at most f(a)+1.
The chosen trajectory first uses the possibly costly F1 map, then F0,
and continues alternating. It spends at most `ceil(j/2)` credits in
j further steps. The other physical phase need not satisfy the same
lower bound; no switch between physical trajectories is made.
The model progresses by at least delta, so at most
`N=ceil(b²/delta)` steps remain. The needed credit is bounded by

    ceil(N/2)=ceil(b²/(2delta)),

which(*) supplies. Nonnegative credit preserves the chosen X>=a
inductively, including the final clipped capture step. This completes
the buffered comparison with the maximum of the two physical phases.

## Couplings, full-board bracket and a simple budget corollary

For capture seed0 choose z=m, giving the first coupling. For half-budget
seed m choose z=k-m; the physical seed is then k, exactly the capture
prefix frontier after one day. This gives the second coupling.

Let tau be the critical model capture clock. If its half-budget test at
tau-1 fails, the accepted lower is2tau, while the first coupling gives
a physical upper2tau+1 with the final half-budget shots sharing a day.
If that test succeeds, the accepted lower is2tau-1 and the second
coupling gives physical upper2tau. Longitudinal reflection switches
colors, so the same physical palindrome construction applies.

For the clean sufficient budget, write `b=3q+s` and set
`k=ceil(8b/3)+2`. The available final credit and twice the progress are

| s | k | `floor(k/2)-b-1` | `2delta` |
|---|---|---|---|
| 0 | 8q+2 | q | 10q+2 |
| 1 | 8q+5 | q | 10q+6 |
| 2 | 8q+8 | q+1 | 10q+10 |

In each row b² is at most the product of the last two columns. In the
middle row q>=1 because b>=2; the last row includes q=0. Thus(OC)
holds at this budget and remains true as k increases. Equivalently,
`k>=ceil(4w/3)+1` is a slightly looser single expression in the width.
Together with the even-width proof this gives one uniform one-day
bracket for all even-area rectangles of width at least4 at that common
sufficient budget.

## Bounded audit and proof boundary

`src/bridge_upper_transport_odd_coupling.py` compares the maximum physical
threshold against the original critical-three-corner recurrence for
1590 cases, including the first budget satisfying(OC), its successor,
and the clean corollary. It checks231871 capture/half-budget deadlines
and142602 exact middle updates, for b2 through100 and three even lengths
per width. Runtime was3.691 CPU seconds. The receipt records source
hashes and the tested least budgets.

The proof uses only reachable three-frontier spread and the exact middle
update. It does not classify arbitrary partial physical states. The
couplings at every budget `k>=w` remain open below(OC).

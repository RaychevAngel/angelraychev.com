# Bounded attempts to escape theP4^5 prefix trap

12 September2026. Unsuccessful witness search, with precise solver boundaries.
These runs supply no unrestricted89-probe strategy and no general
impossibility theorem. No solver process remains running.

## An exact two-day reduction

For an initial supportA and a desired same-parity final targetB, put

    E(B)={v:N({v})⊆B}.

After a first survivor choiceR⊆A, a two-day bridge intoB is possible with
first quotap and second quotaq if and only if

    |A\R|≤p,    |N(R)\E(B)|≤q.

Indeed every second survivor must lie inE(B); shooting precisely the
bad neighborsN(R)\E(B) suffices. This is a direct physical equivalence,
not a heuristic envelope approximation.

The mixed-integer model uses first-survivor variables and a binary flag
for each possible bad neighbor, with one implication per incident edge.
It minimizes the second quota subject to the first quota89.

Both the source and target prefixes are fixed by the already proved
equal-coordinate compressions. The general strategy-compression theorem
therefore permits all intermediate survivors to be their common fixed
sets. These are the pyramidal ideals. Adding their predecessor
implications is sound and substantially helps the finite solver.
The target erosion is also fixed: ifN(E)⊆B, thenN(C(E))⊆C(N(E))⊆B;
thusC(E)⊆E, and cardinality preservation makes this equality.

## Results

|Source and target|Pyramidal constraints|Solver outcome|Actual CPU time|
|---|---|---|---:|
|I0(331) toI0(330), two days|No|Timeout, best second quota91, bound83|2.01s|
|I1(329) toI1(328), two days|No|Timeout, best second quota90, bound79|2.01s|
|I0(331) toI0(330), two days|Yes|Reported optimum second quota90|1.01s|
|I1(329) toI1(328), two days|Yes|Reported optimum second quota90|1.27s|
|I0(331) toI0(330), four days at89 each|Yes|Timeout without a feasible incumbent|13.62s|

All runs requested a single HiGHS thread and a two-second solver limit.
The four-day model had2798 variables and24061 constraints; its preprocessing
and solve exceeded that limit in actual CPU time. The search was therefore
stopped after that run instead of starting larger six-day models.

The two completed optimum reports are numerical mixed-integer-solver
evidence. No exact rational or Lean infeasibility certificate was extracted,
so they are not promoted here to independently verified impossibility
theorems. They do show that the simplest same-corner two-day bridge was
not a promising witness route in these runs.

## Sources and receipts

* `src/even_bridge_two_day_milp.py` and
  `research/even-bridge-two-day-milp-p*-*.json`.
* `src/even_bridge_envelope_milp.py` and
  `research/even-bridge-envelope-4days-p0-331-330.json`.

The latter uses the general survivor-envelope equivalence, actual physical
adjacency, and the same proved pyramidal normalization. Every proposed
winning incumbent would be checked by independent tuple/set neighborhood
replay before being reported as a witness. None of these runs produced one.

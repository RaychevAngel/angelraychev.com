# A merger theorem for the necessary even-board corner model

13 September 2026. Ordinary algebraic proof independently reviewed by root.
A final endpoint audit also passed, as recorded below.
The corner-profile theorem it uses has already received independent review.
The local merger proof below was developed independently in parallel with
root's closed-dual and high/high derivations, and the rectangle agent's
finite falsification tests. The main proof first concerns the BASE necessary model. The separate
closure arguments appended below extend it to critical filters retaining
all F/G profiles and, on odd-width rectangles, the proved pronic-triangle
memory restriction. These extensions are proved explicitly rather than
assumed from the base theorem. None proves that the model paths are
physically attainable or gives an exact physical capture-time formula.

## The exact model and the proposed statement

Fix integers r>=1 and h>=2r^2. On a nondegenerate even-area rectangle these
are r=floor(min(w,n)/2) and h=wn/2. A one-color feature is (a,c), with

    c in {0,1,2},         c<=a<=h-2+c.

The feature records belief size and the number of that physical color's
two board corners present. From (a,c), a cost p action chooses a survivor
(q,i), where q=a-p and 0<=p<=k, with

    max(0,c-p)<=i<=c,

and (q,i) itself is a valid feature. It then chooses a target (t,j), with
t>=q, allowed by the existing size profile and the following rule. Put
s=t-q. If q=0, only (t,j)=(0,0) is allowed. If q>0, require

    s>=min(ceil(sqrt(q)),r,rho(h-q)).

For s<r also require

    q<=F_(i,j)(s)  OR  h-q-s<=G_(i,j)(s),           (P)

using the accepted capacities in `resumed-even-corner-profile.md`. For
s>=r there is no additional corner-profile restriction. This model
contains every physical transition. Its allowed transitions may include
ones that are geometrically impossible; no sufficiency is assumed.

A joint transition acts on two such features with costs p1,p2 whose sum
is at most k. Define the merger of the two beliefs by

    M((a1,c1),(a2,c2))
       =(a1+a2-h, max(0,c1+c2-2)).

**Local merger theorem.** Suppose 1<=k<h and a1+a2-h>k. Every joint
model transition with total cost p=p1+p2<=k admits a one-color model
transition from the merged source to the EXACT merged target, using
cost p. In particular the existence of a cheaper edge is not required.

The source-size condition is intentional. Without it an actual model
counterexample exists at h=32,r=4,k=5:

    (3,0),(32,2) -> (3,1),(31,2), costs 2,3.

Its merged source is (3,0), merged target (2,1), and no cost-at-most-five
model transition joins them. This example was found by the rectangle
agent. It lies after the proposed single-cohort clearing threshold and
does not contradict the theorem.

## A closed expression for the dual capacity

The finite maximum defining G simplifies as follows:

    G_(i,0)(s)=1+(s+i-3)^2,            s>=4-i;
    G_(i,1)(s)=(s+i-2)^2,              s>=3-i;
    G_(i,2)(s)=(s+i-2)(s+i-1),         i<2, s>=2-i;
    G_(2,2)(s)=C_2(s),                s>=0.

Outside the displayed domains its value is -infinity. For j<2, the d=0
candidate dominates every feasible higher-d candidate. With
v=s+i+j-3, its differences from d=1 and d=2 are respectively v-1 and
3v-5; feasibility of a higher candidate gives v>=d+1. For j=2,i<2,
the d=1 candidate dominates when available; at the first permissible
argument only d=0 is needed and both displayed values are zero.
This checks all endpoints, not just the eventual polynomial pieces.

Equivalently, put A=2-i, B=2-j. A finite G requires s>=A+B. With
z=s-A-B>=0, its value is

    z^2+2z+B,        B>0;
    z^2+z,          B=0<A;
    C_2(z),         A=B=0.                         (G)

In particular every finite G_(i,j)(s) is at most s^2, and a high-branch
profile missing A current corners and B outgoing corners requires
surplus at least A+B.

## High/high merger

For two high-branch inputs let A_l=2-i_l, B_l=2-j_l and
z_l=s_l-A_l-B_l. Under the merger of corner counts, the missing counts are

    A=min(2,A1+A2),     B=min(2,B1+B2).

Put delta=(A1+A2-A)+(B1+B2-B)>=0. The merged surplus variable in (G)
is z=z1+z2+delta. We claim

    G_(i1,j1)(s1)+G_(i2,j2)(s2)
      <=G_((i1+i2-2)_+,(j1+j2-2)_+)(s1+s2).       (H)

If B>0, every source term is at most z_l^2+2z_l+B_l. Subtracting
this sum from the merged expression gives

    2z1z2+2delta(z1+z2)+delta^2+2delta-(B1+B2-B),

which is nonnegative because delta>=B1+B2-B. If B=0<A, both B_l=0;
each source term is at most z_l^2+z_l, and the merged z^2+z is at
least their sum. Finally A=B=0 forces all A_l,B_l to vanish, and (H)
is the superadditivity of the convex capacity C_2 with C_2(0)=0.
This proves (H), including zero capacities.

## Low/high merger

The following two elementary changes of F suffice. For a feasible F:

    F_((i-1)_+,j)(s+1) >= F_(i,j)(s)-1;            (C)
    F_(i,(j-1)_+)(s+1) >= F_(i,j)(s).              (O)

When the index being decreased is already zero, monotonicity suffices.
For (C), positive j makes the quadratic increase. For j=0,i=2 it
reduces to (s+1)^2>=1+(s-1)^2. The only possible loss occurs for
j=0,i=1: C_2(s+1)>=(s+1)(s-1)=s^2-1. For (O), j=2 gives a larger
pronic quadratic; j=1,i>0 gives a larger square quadratic; j=1,i=0
uses C_2(s+1)>=s^2-1>=s(s-1), since feasibility gives s>=2.
Each change also preserves feasibility of its capacity argument.

Let the low profile have corner counts i,j and surplus s. Let the high
profile omit A current corners and B outgoing corners, have surplus t,
and leave complement size d=h-t_high>=0. Its finite high capacity requires
t>=A+B by (G). Apply (C) A times and (O) B times, then monotonicity:

    F_((i-A)_+,(j-B)_+)(s+t) >= F_(i,j)(s)-A.      (L)

The merged survivor size is

    Q=q_low-(t+d).

Since t+d>=A, the low bound q_low<=F_(i,j)(s) and (L) give
Q<=F_merged(s+t). Thus a low/high pair has a low-branch merged profile.
No equality of actual profiles or arbitrary-state strategy theorem is used.

## Completing the transition proof, including corner validity

Let the two chosen survivors be (q1,i1),(q2,i2), and the targets be
(t1,j1),(t2,j2). Write p=p1+p2, and put

    m=a1+a2-h,       Q=q1+q2-h=m-p>0,
    T=t1+t2-h,       s=(t1-q1)+(t2-q2),
    c=(c1+c2-2)_+,   I=(i1+i2-2)_+,
    J=(j1+j2-2)_+.

The merged source is a valid feature: m>k>=1 gives m>=2>=c; its upper
feature bound follows by adding the two source upper bounds. The raw
merged survivor may fail its LOWER feature bound in exactly one case:
Q=1,I=2. Choose

    I*=min(Q,I).

This preserves inspection bookkeeping. Indeed I<=c, I>=c-p and
Q=m-p>=c-p. Its upper feature bound also holds; in the sole clipping
case it follows from Q=1<=h-1. Thus a cost-p action from (m,c) may
choose (Q,I*).

The merged target (T,J) is valid. Its upper feature bound follows by
adding t_l<=h-2+j_l. Since T=Q+s>0, its lower bound could fail only
if T=1,J=2. That would give Q=1,s=0. Both original survivors are
nonempty, and zero surplus under the size profile forces q1=q2=h.
Then Q=h>=2, a contradiction. Thus J<=T.

If s>=r, the size profile is automatic and the merged transition is
allowed. Suppose s<r. Both component profiles obey (P). They cannot
both use the low branch, because then

    q1+q2<=s1^2+s2^2<=s^2<r^2<h,

contrary to Q>0. If both are high, their complement deficits add, and
(H) gives the high merged branch. Moreover

    Q=h-s-(d1+d2)>=h-s-s^2>=r^2+r>=2,

so I*=I and no corner clipping occurs. If one profile is low and the
other high, (L) gives the low merged branch. If I*=I there is nothing
more to check. If Q=1,I=2, the elementary fixed-surplus inequality

    F_(1,J)(s)>=F_(2,J)(s)

preserves that low bound. For J=0 it is s^2>=1+(s-1)^2; for J>0,
decreasing the mandatory corner count increases the displayed pronic
capacity. Thus the clipped survivor also has an allowed profile.

Finally the merged small branch implies Q<=s^2; the merged high branch
implies h-Q-s<=s^2. Either implies the old size-only profile, since
rho(h-Q)<=s in the second case. Hence no unconditional requirement has
been lost. All model constraints are satisfied, proving the exact-target
local merger theorem. QED.

## Full-start consequence and its precise limit

Let tau be the minimum solo capture time IN THIS NECESSARY MODEL, starting
from (h,2); capture means reaching size at most k before the final
inspection. Every joint model trajectory of t<tau inspections and moves
can be merged into a solo model trajectory of exactly t inspections and
moves, with the stated size and corner count at every layer.

Proof by induction: at a layer before t, if the merged size were at most
k, the solo path already constructed could clear on the next day, before
tau. Therefore the local theorem's strict source-size condition holds
at every required step. Apply it. The full joint start merges to (h,2).

In particular, if f_t is the least solo model belief size after t moves,
then for every t<tau the least joint model total size is exactly

    h+f_t.

The lower bound is the merger theorem; equality is attained in the model
by following a minimizing solo path in one cohort and keeping the other
full with zero inspections. This is concentration for the necessary
model before first solo capture, not a normal form for arbitrary physical
partial states. Physical strategies inherit its lower bound because all
physical edges are admitted by the model.

The usual reversed-walk cut therefore gives a physical-game lower bound
T>=2tau-1, and T>=2tau if 2f_(tau-1)>k. The cut uses no assumption that
model solo paths are physically realizable. It does NOT provide an upper
strategy or imply that a closed-form evaluation of tau exists. Those
remain separate obligations under the fixed-size numerical goal.

## Checks and credit

The rectangle agent's preliminary 8x8,k=5 test checked 1,975,422 abstract
pair transitions satisfying the source guard and found no violation.
Its receipt is `research/resumed-even-construction-merge-guard.json`.
The test included exact merged targets, not merely target size domination.
It is finite evidence only; the proposed universal proof is the argument
above. The same agent supplied the counterexample without the guard and
flagged the invalid raw survivor corner count, which the clipping argument
explicitly repairs. Root independently derived the closed form for G,
the high/high inequality, and the same clipping endpoint check.

A separate transcription check compared the finite-max and closed G on
all 225 index/surplus entries with s=0,...,24, and checked both one-corner
deletion inequalities and the clipping monotonicity on all 198 feasible F
entries in that range. All passed. Receipt:
`research/resumed-even-merge-algebra-check.json`. These bounded checks do
not replace the displayed algebraic proof.


## Final independent endpoint audit and manuscript handoff

After root's mathematical review, the explicit chosen-survivor construction
was checked on 14 endpoint parameter cases: r=1,h=2,...,5 with every
1<=k<h, and r=2,h=8 with k=1,2,3,7. All 30,161 pairs of chosen actions
passed, including 1,041 cases where the raw survivor count needed clipping.
This checks the constructed exact-cost transition, not merely whether a
cheaper model edge exists. CPU time was 0.028 seconds. The r=1 model has
no proper subcritical profile besides surplus zero; there the size profile
forces a nonempty source to be full, exactly as the target-validity proof
uses.

A separate refined clipping witness was checked at r=4,h=32,k=5:
(7,2),(31,2) choose survivors (2,2),(31,2) and targets (4,0),(32,2).
The merged action is (6,2)->(4,0) at cost five, using survivor (1,1),
not the invalid raw pair (1,2). Its total surplus is three, so the
subcritical clipping argument is exercised.

Source and receipt: `research/resumed-even-merge-endpoints.py` and
`research/resumed-even-merge-endpoints.json`. Manuscript-ready source is
`paper/sections/resumed-even-corner-merge.tex`; it is kept separate and
has not been wired into an entrypoint by this subagent. Existing source
files remain unchanged.


## Extension 1: retaining F/G at the critical surplus

Root proposed this extension, and this subagent independently checked the
survivor clipping and r=1 endpoints. Let the model impose ANY additional
restriction at s=r that retains every valid feature profile satisfying the
F/G alternative. At s>r retain the original unrestricted rule. Then the
same exact-target, exact-cost local merger theorem holds.

Only total surplus s=r needs checking. If both component surpluses are
less than r, the very same F/G algebra applies. Both-low is impossible
because q1+q2<=r^2<h, whereas q1+q2>h. For high/high, the sole clipping
possibility remains excluded: when r>=2,

    Q>=h-r-r^2>=r^2-r>=2.

When r=1, two nonnegative component surpluses each less than r cannot
sum to r, so this subcase does not occur. Mixed-branch clipping preserves
F exactly as before. Thus the merged critical profile is retained by the
assumed filter.

If one component surplus equals r, the other is zero. Both survivors are
nonempty because q1+q2>h. The size profile forces the zero-surplus survivor
to be full, its original source to be full, its cost to be zero, and its
target to be full. Merging with this full-to-full action is the identity
on the critical action, including its corner counts. That action already
satisfies the filter. This covers all cases.

In particular the independently proved odd-width critical filter
(F/G OR (2,0)) inherits concentration. The proposed even-width filter
(F/G OR (1,1), and additionally (2,0) only at n=2r+1) also inherits it; its separate geometric proof has now been reviewed
and accepted by root. This closure statement
alone does not certify a proposed filter as physically necessary.

## Extension 2: the odd-width pronic-triangle one-step memory

Physical scope: w=2r+1, n even and n>=w, r>=2. Do not transfer this
physical memory rule to even widths; the distances to the other colored
corners differ. The geometric rigidity proof is
`paper/sections/resumed-odd-critical-extension.tex`,
`cor:odd-critical-pronic-rigidity`, independently reviewed by root.

Its consequence is that a transition whose actual survivor has size
C=r(r-1), zero current corners, and surplus r has target size r^2 and
one corner. Its target may therefore carry a memory flag: on the following
transition the new target must have zero corners, even after arbitrary
intervening inspections. This follows because the original survivor is
an entire odd triangle and its two-step neighborhood omits both corners
of the original physical color.

In the abstract model, set the new flag to one precisely when the chosen
survivor/target triple is

    Q=r(r-1), I=0, surplus=r; target=(r^2,1).

Otherwise reset it to zero. A source with flag one permits only target
corner count zero. Start with flag zero at the full feature. The use of
chosen survivor I is material: the source belief may have corners removed
by the current inspections.

The precapture merger extends to this memory model. Define the merged
history's flag from its OWN preceding merged action, not as the OR of the
two current component flags. Maintain the invariant:

    if the merged flag is one, one component flag is one
    and the other component feature is full.

To prove formation of this invariant, consider a newly triggering merged
action. Its total surplus is r. If both component surpluses were below r,
both-low would already be impossible. In low/high,

    Q <= q_low <= (r-1)^2 < r(r-1),

contradicting the trigger. In high/high the merged F/G algebra gives

    h-r^2 <= G_(0,1)(r) <= (r-2)^2,

but h>=2r^2 makes its left side at least r^2. This is also impossible.
For r=2 the displayed G value is actually -infinity; the inequality used
is still valid and its impossibility is stronger. Therefore one component
has surplus r and the other surplus zero. As above the latter must be a
zero-cost full-to-full action. The merger is the identity on the former,
so that very component has the trigger and receives its own flag one.
The invariant is established.

When a merged source has flag one, its flagged component's next target
has corner count zero. The merged target then has corner count
max(0,0+j_other-2)=0, as required. If its own new action does not trigger,
the merged flag resets to zero irrespective of component flags; this
avoids the incorrect stronger invariant obtained by taking their OR.
Induction from the full start proves the memory-model merger until the
first solo clearing day. The same reversed-cut physical lower bounds
hold with its possibly stronger solo clock.

This proof gives no physical realization of optimal paths in the memory
relaxation and no fixed-size evaluation of its clock. The strict trigger
argument proves only this specific finite-memory closure.


A further finite counterattack on these two extensions passed 19,833
exact constructed pairs under the strongest F/G-only critical filter on
14 endpoint cases, and all 54 triggering pairs across 27 (r,h) cases
with 2<=r<=10 were identity mergers with a full component. Receipt:
`resumed-even-merge-extensions-check.json`; CPU time0.15 seconds.

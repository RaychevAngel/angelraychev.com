# Independent review: fixed odd cross-sections and eventual periods

12 September 2026 UTC. Reviewer: the independent proof/formalization agent.

**Verdict: passed, after one empty-prefix display correction.** This reviews
`odd-cylinder-eventual-periodicity.md` as an ordinary mathematical proof.
It adds no Lean formalization and does not turn the whole geometric theorem
into a kernel-checked result.

The result is for a fixed nontrivial all-odd Cartesian cross-section Q,
with volume W, S the sum of coordinate maxima, and Z=W(S+1). For sufficiently
long odd cylinders the exact feasible budget is (W+1)/2. For each fixed
m at least this threshold, set d=2m-W and g=gcd(W,d). The proved eventual
identity is

    T_m(Q × P_(n+2d/g)) = T_m(Q × P_n) + 4W/g.

The explicit threshold in the reviewed note is sufficient. It is deliberately
large and is not a claim that the period begins at the first possible length.

## 1. Independent geometric derivation

Place the long coordinate last after sorting transverse side lengths.
For n>=S+3 this is legitimate: every transverse side is at most S+1.
At a bottom vertex (v,0), the full-dimensional cost minus one is a_Q(v),
including the origin. At an interior vertex it is zero, and at a top vertex
it is minus one. Thus the profile surplus is its odd nonempty-prefix
indicator, plus the selected bottom cost, minus the selected top count.

The rank of a bottom vertex stabilizes as soon as n>=S+1. Every vertex
preceding it has total weight at most S and long coordinate at most S.
There are at most Z vertices in that finite slab, giving the stated bound
on all bottom ranks. This is a bound on actual positions, not an assumption
that geometric height and prefix cardinality are interchangeable.

Coordinate complement preserves checkerboard parity because every maximum
is even. It reverses both total weight and the decreasing-lexicographic tie
order. Consequently the selected top count is exactly

    |Q_p| - B_p(H-p-k).

This verifies, for k>0,

    g_p^H(k)=k+p+U_p(k)-|Q_p|+B_p(H-p-k).

The two functions U and B are fixed finite tables independent of the long
length. Their saturation gives both the plateau and, more significantly,
the exact low-end invariance and high-end translation used in surgery.
The plateau by itself would not have proved those identities.

The original low-end display omitted its k>0 guard. For odd color and
k=0 its displayed right side would have been one. The author corrected
that display and explicitly handles k=0 by g_p(0)=0. No argument depended
on the erroneous value.

## 2. Expansion and feasibility

The transverse full-class identity gives total bottom cost (W-1)/2 in
each parity. The top contribution is nonpositive, so the maximum possible
surplus is at most (W-1)/2+p. If H>=2Z+3, the majority prefix k=Z+1
has both ends beyond the finite tables and attains this bound.

Together with the already established all-odd-box nesting theorem and
the cited hunter-number criterion, this proves the exact eventual threshold.
The size hypothesis also implies n>4(S+1)>S+3, so the coordinate-order
assumption has not been used circularly.

The Hamiltonian-path lower expansion bounds were checked separately.
Removing an unselected majority path vertex permits an injective matching
from any proper majority set into minority neighbors. A nonempty minority
set decomposes into consecutive blocks along its parity path; each block
has one more neighbor than its size, and distinct blocks have disjoint
neighbor intervals. Hence

    g0(k)>=k for k<H;  g1(k)>=k+1 for k>0;  g0(H)=H-1.

These hold for arbitrary supports, so they certainly hold for prefixes.
They imply the lower surplus bound minus one and the needed strict growth
of intermediate uninspected potentials.

This threshold must remain explicitly eventual. For example, the short
cylinder Q=P5×P5, n=5 has hunter number12, below (W+1)/2=13. Nothing in
the reviewed theorem classifies that short cylinder by the limiting threshold.
The one-point cross-section is explicitly assigned to the separate path theorem.

## 3. Constants and potential guards

For K=2Z+2m+1 and C=2H-4Z-2m-5, use the common clipped potential

    F_p(k)=min(C,max(0,2k+p-K)).

If the survivor q is at most Z, its source raw potential is at most zero
since k<=q+m. If q>=H-Z-1, the successor is at least q-1; its raw
potential is at least C. For the remaining integer q, both parity-specific
table arguments are strictly greater than Z, so the exact plateau applies.
The raw potential loss is then 2r-W. Common clipping bounds its loss by
max(0,2r-W).

For a total quota at most m, the two losses sum to at most d=2m-W.
Equality requires all m quota on one cohort. The minority-first greedy
phase takes at most 2 ceil((H-1-m)/d)+1 rounds: each uncleared pair reduces
the count by at least d, and the last round clears a count at most m.
Padding to this odd duration puts the other full cohort in the minority
phase again. Thus the two-phase bound is 4 ceil((H-1-m)/d)+2.
The integer rounding gives exactly

    dT-2C <= 8Z+6d+2 = B.

The zero flat collar has count at most Z+m=L-1. The cap flat collar is
within Z+2<=L of its full class. Connectedness makes N² strictly enlarge
every nonempty proper parity support. The previously reviewed argument
therefore gives at most E=B+4L(B+1) nonclean days. It does not incorrectly
identify a flat potential with actual empty or full support.

## 4. The count-band surgery retains its hypotheses

The one-round count displacement is at most J=m+1, using surplus in
[-1,(W+1)/2] and m>=(W+1)/2. With A=Z+1 and band width
R=Delta+2J, the candidate-cut count at the stated H* is
2E(R+2J+1)+1, exceeding the maximum number excluded by nonclean days.

The inherited surgery chooses separate endpoints for the two initial
cohorts. This matters when d>1: it does not require them to hit the same
cardinality or residue. Every block has the even duration 2Delta/d,
decreases its own cohort by Delta, and has an actually empty or full
inactive companion. The two blocks are disjoint.

For a retained low state k<=ell, contraction leaves its successor profile
unchanged: the new remaining tail is at least H-u-1>Z. For a retained
high state k>=u, the contracted survivor is at least ell-m>c-m>Z, so
the exact upper translation applies. Empty low states use the separately
stated zero-profile rule. The larger protected band prevents retained
transitions from crossing a deleted interval. Block endpoints and current
parity match because the duration is even.

The important dimensional guard also checks algebraically:

    H*-Delta >= 2Z+6J+4.

The contracted longitudinal length therefore exceeds 4(S+1), keeping it
strictly longest and keeping both finite rank tables valid. Delta is a
multiple of W, so the contracted and expanded lengths remain odd integers.
Since Delta=lcm(W,d), the period and time increment simplify respectively
to 2d/g and 4W/g. Applying contraction at H+Delta supplies the reverse
inequality to expansion at H, proving equality rather than only an upper bound.

## 5. Supplementary independent computation

`src/odd_cylinder_independent_review.py` constructs actual coordinate
neighborhood unions, without importing the profile code under review.
It checks seven cross-sections in dimensions one through three, two long
lengths each, including unequal sides. All 9,084 profile entries and
4,786 low/high translation identities passed. The receipt is
`odd-cylinder-independent-review.json`.

These small checks supplement the ordinary all-parameter proof. They are
not used to infer an eventual law from finite data. No new claim about
even or mixed side lengths, the earliest period onset, or globally serial
optimality is made.

# Independent review of the 4×6 corner-ideal obstruction

12 September 2026. **Passed.** Reviewed Section1 of
`even-bridge-corner-obstructions.md` independently of the discovery automaton.

The initial eight-room set is indeed a checkerboard coordinate ideal facing
(0,5). Direct coordinate-neighborhood computation verifies the unrestricted
five-day witness with quotas(2,0,3,0,11). Its first residual is not a corner
ideal in any of the four orientations.

I independently enumerated all37 deletions of at most two initial rooms
and tested the literal coordinatewise ideal definition for every orientation.
Exactly the eight deletion sets listed in the note survive this test. Their
two-step neighborhoods are the entire even class E, except for deletion
{11,22}, which gives E without31.

The subsequent impossibility is a direct geometric argument. Two-step
reachability is symmetric, so a room v is omitted from N²(B minus Q) exactly
when B intersect N²({v}) is contained in Q. Every such intersection has at
least four rooms for either B=E or B=E without31. The only even vertices
with four-room two-step balls are00 and35, and neither ball contains31;
all other balls have at least five rooms. Thus three inspections cannot
omit any room from the next two-step neighborhood. The final belief has
twelve rooms, exceeding the last budget eleven. I also exhaustively checked
all later deletion sets of size at most three as an independent finite attack.

The result already follows by requiring only the first residual to be a
corner ideal. It allows arbitrary later residuals, so it is stronger than
a failed search restricted at every day. Its scope remains an arbitrary
corner-ideal initial support with a prescribed budget word. It does not
refute a full-board, constant-budget corner normal form.

Receipt: `even-resume-corner-obstruction-review.json`. No gap or correction
was needed; no new Lean claim is made.

# Independent review of the uniform odd minimum-budget law

13 September 2026. Root review of `maturation-odd-midpoint.md` Section 4,
using the previously reviewed Sections 1--3 of
`uniform-odd-minimum-budget.md`. **PASS as ordinary mathematics.**

The needed distinction is initial-cohort ancestry versus present
physical color. Calling the numerically larger coordinate primary would
not prove the result. The proof instead gives each retained mixed state
the initial-cohort label of its most recent pure ancestor.

Before the first solo capture, total concentration bounds every mixed
total by the larger solo deficit. The established persistence lemma
discards totals at most the smaller solo deficit without altering the
central decision. At a tie there are consequently no exceptions.
A slower pure endpoint cannot create an exception: apply the two
inverse concentration inequalities to its total and use monotonicity.

For a strict change of fastest INITIAL cohort, the same physical color
must be strictly faster on both adjacent days. Physical minority cannot
do that, since I_0>=I_1 and both are monotone. If physical majority does
it, every predecessor has total S<=D_0(t). For a mixed successor the
second concentration inequality gives total at most I_1(S+m), hence at
most I_1(D_0(t)+m)=D_1(t+1), the new SMALLER solo deficit. All old mixed
histories are therefore erased at that change. The concentration
inequality's proper-input guard follows from t+1<tau; positivity of
the new minority coordinate supplies its nonzero-input guard.

Induction now shows that every retained exceptional state has the
currently faster initial cohort as its primary ancestry. Pure rebirths
have that same label; domination by a solo endpoint is a replacement
by an attainable state. No estimate of the numerical coordinate gap
or arbitrary-partial-state seriality has entered this argument.

At m=b+1, the reviewed width-only corner clock supplies a last pure tie
and exactly L_b days from that tie to the precentral layer. Every
secondary coordinate is bounded by a fresh solo deficit over at most
L_b days, and is therefore at most C=b(b-1). Two exceptional midpoint
states share a primary ancestry and put their secondary deficits in
the same physical color. That color alone has at least
M-2C >= 4b > b+1 rooms left. It cannot be covered centrally. If either
state is nonexceptional, their raw total is at most the sum of the two
solo deficits, so they cannot outperform the opposite solo endpoints.

The reviewed solo formula gives consecutive durations tau and tau+1.
At time tau-1 the slower solo's residual exceeds m, since otherwise
one more inspection would finish it within tau days. Thus the scalar
central condition fails, and the full answer is 2tau:

    T_(b+1)((2b+1) x n)=2(2b+1)n-K_b,
    K_b=8b^2-4b-4L_b+4,

for every b>=1 and odd n>=2b+1. L_b is exactly the first arrival of
the width-only bottom inverse recurrence at B=b(b-1), as defined in
the source note. Its termination is proved, but it is not asserted to
have an elementary closed expression in b.

This settles the older minimum-budget note's remaining final-day bit.
Its proposed lower-root translation invariant was bypassed, not proved.
The theorem does not settle arbitrary budgets, even widths, or arbitrary
partial starts, and is not claimed as a full Lean classification.

The separate exact retained-frontier solver matched the formula in 18
deliberately selected cases: b=1,2,3,9,20,40 and n=w,w+2,3w. It also
verified the predicted solo half-time and failure of the short central
cut in each case. Runtime was 1.238 CPU seconds. Receipt:
`maturation-minimum-formula-check.json`. The solver does not assume the
new formula; these checks support the preceding unbounded proof.

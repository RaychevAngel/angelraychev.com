# Near-square localization cannot repeat in the next closed transition

13 September2026. New ordinary theorem and merger extension. Root
independently reviewed the original slack proof and both merger arguments;
the stronger whole-triangle argument below was proposed by root and
independently checked by this lane. The upper-construction lane then
independently accepted the whole-triangle count, physical forbidden
successor, and both merger identity arguments.
This is a physical restriction with one history bit. It does not assert
a matching capture-time formula. The weaker inner-triangle inequality is
preserved below as derivation history, not an additional required input.

## Strongest result: a forbidden successor, with no radius table

Use the strict-near-square flag defined below. On an odd-width/even-length
rectangle, a flagged state cannot have a next target with(j,v)=(1,2)
whose closed surplus s satisfies

    2<=s<=b,       s(s-1)<h-t_new<=s².                         (FORBID)

This holds for every pair of old and new radii. No numerical radius
compatibility catalogue or extra core-shape feature is required.

**Whole-triangle proof.** Let successive holes U,V be localized inside
their r²- and s²-room corner triangles, with exact surpluses r,s. Their
own-colored corner anchors have opposite physical colors. The adjacent
possibility is along the even longitudinal side of length n. Reflect
coordinates so the anchors are(0,0) and(0,n-1), with x along the short
side and y along the long side. Then

    N(V) subset { (x,y): y-x>=n-2s=2z },   z=n/2-s>=1.

On diagonal x+y=2j of T_r(0,0), the number of rooms outside this
half-plane is min(2j+1,j+z). Summing gives

    C(r,z)=r(r-1)/2+r*z-z(z-1)/2,       0<=z<=r,
    C(r,z)=r²,                         z>=r.

The other possible anchor is diagonally opposite. Its distance is
w+n-2>=4b+1, whereas the relevant radii sum to at most
(2r-2)+(2s-1)<=4b-3. Thus the supports are disjoint and the lower bound
below is stronger. There is no adjacent opposite-colored anchor across
the odd short side.

U has more than r(r-1) rooms, hence defect at most r-1 from T_r.
Consequently, in either orientation,

    |U minus N(V)| >= C(r,1)-(r-1)
                    =r(r-1)/2+1 >=2.                         (GEOM)

But the flagged source has(c,e)=(1,2), and the candidate target has
(j,v)=(1,2). Maximal survivor retention forces i=1. Its original surplus
ell and closed surplus s differ by v-i=1. The complement inclusion
N(V) subset U union I gives |U minus N(V)|<=ell-s=1, contradicting(GEOM).
This proves(FORBID). The separate identity arguments below transfer it
to synthetic merged histories.

## Derivation history: the weaker inner-triangle slack inequality

Let w=2b+1>=5 and n>=w be even. Let U and V be successive same-cohort
hole sets, so U and V have opposite physical colors. Suppose U and V
have already been localized inside the full square corner triangles
T_r(o_U), T_s(o_V) of respective sizes r² and s², with2<=r,s<=b.
Assume |N(V)|-|V|=s. Write p for the useful inspections in the intervening
move and ell=|U|+p-|V| for that move's original survivor surplus. Then

    ell-s >= max(0,q²-(r²-|U|)),
    q=min(r,max(0,n/2-s)).                                      (NS)

**Proof.** The two corner anchors have opposite colors, so their Manhattan
distance is at least n-1. Every point of T_q(o_U) has distance at most
2q-2 from o_U, hence at least n-2q+1>=2s+1 from o_V. Therefore the
q²-room triangle T_q(o_U) is disjoint from N(V), which lies inside the
radius2s-1 ball about o_V. At most r²-|U| rooms are missing from T_r(o_U),
so

    |U minus N(V)| >= max(0,q²-(r²-|U|)).

On the other hand N(V) is contained in U union I, where I is the useful
inspection set and is disjoint from U. Thus

    |U minus N(V)| <= |U|+p-|N(V)| = ell-s.

Combining proves(NS). No assumption about attaining a static capacity,
prefix orientation, compression of U, or a particular inspection choice
is used beyond the stated localization and exact surplus.

## Detectable strict localization event

For a move with survivor(q_A,i,u), target(t,j,v), and original surplus r,
call it strict-near-square when

    i=2, (j,v)=(1,2), 2<=r<=b,
    r(r-1)<h-t<=r².

Closure has delta=v-i=0. The hole set U=complement target has surplus at
most r. The static profile forces surplus>=r, so equality holds. Its
large branch is impossible since h-r²>r²; the accepted near-square
localization theorem puts U in T_r of one of its own corners. It can
therefore receive a one-step flag, with r recoverable as ceil(sqrt(h-t)).

From such a flagged state, consider a move whose target has(j,v)=(1,2)
and whose closed surplus s=ell+i-2 satisfies

    2<=s<=b,    s(s-1)<h-t_new<=s².

The new holes V have surplus<=s and hence exactly s, so near-square
localization applies again. The strongest model now forbids the successor
by(FORBID). The earlier weaker version enforced(NS), using the old hole
size and radius recoverable from its flagged source. On every
non-triggering new action the flag clears. A newly strict-near-square
action sets it according to its own target, independently of old flags.

## The concrete25x26 shortcut it rejects

The reconstructed186-day relaxed path has at day19

    target(232,1,2), holes93, original surplus10, survivor corners2.

This is a strict event with r=10, so its holes U lie in a100-room
triangle. The next move is

    (232,1,2) --[13 inspections; survivor(219,1,0)]--> (230,1,2).

The new holes have size95. Original surplus ell=11 and closed surplus
s=10, giving the putative slack ell-s=1. But q=26/2-10=3 and the first
triangle misses only100-93=7 rooms, so(NS) requires slack at least
9-7=2. This consecutive pair is physically impossible.

The whole-triangle count strengthens this example to C(10,3)-7=65 rooms
outside N(V), still against available slack1, and supplies the uniform
forbidden successor without depending on those particular parameters.
The earlier weaker flagged model nevertheless retained a186-day solo
path, with penultimate residual9: removing the displayed witness alone
was insufficient. The stronger variant is tested separately; the old
receipt is not relabeled as a test of(FORBID).

## Merger-safe formation of the flag

In a merged strict event, merged survivor I=2 and target V=2 force
i1=i2=v1=v2=2, so both component closures have delta0. Target J=1 forces
j1+j2=3, hence both outgoing counts are positive. Its component hole sizes
sum to D in(r(r-1),r²], and component surpluses sum to r.

Each component must use its high branch. A small branch with positive
outgoing count would make its target at most s_l²<=r² and its holes at
least h-r²>r²>=D. The critical exception has outgoing count0 and cannot
occur. The high branches give d_l<=F_(2-j_l,0)(s_l)<=s_l². If both
surpluses were positive, their hole sum would be at most

    (r-1)²+1 <= r(r-1),

contradiction. Thus one component is a zero-surplus original-full-to-full
action. The merger is the identity on the strict component. Define the
merged flag from its own trigger; it therefore has one flagged component
and the other component full, as in the earlier pronic-flag merger proof.

## Merger inheritance of the next-step inequality

At a flagged merged source, the flagged component has c=1,e=2 and the
other component is full. A new merged target with J=1,V=2 forces both
component erosion counts to equal2. Maximal survivor retention then forces
i_flagged=1 and i_full=2. Consequently their closure deltas are1 and0,
and the merged closed surplus s is the sum of their closed surpluses.

Suppose the new merged holes D' satisfy s(s-1)<D'<=s², 2<=s<=b. The same
small-branch exclusion forces both components high, now with

    d_l<=F_(2-j_l,0)(sigma_l)<=sigma_l².

Two positive closed surpluses would give hole sum at most(s-1)²+1<=s(s-1).
One closed surplus is therefore zero. It cannot belong to the flagged
component: its high capacity at zero would force its target full and
q_flagged=h-1, whereas the flagged source has at least r(r-1)+1>=3 holes
and thus size at most h-3. Therefore the full component's closed surplus
is zero. Its delta is zero too, so it is again an original-full-to-full
action. The new merged edge is the identity on the flagged component,
and its physical/model(FORBID) rule transfers exactly. The same argument
also justified the earlier weaker(NS) implementation.

This proves closure for the new flag and its restricted next-step rule
within the stated weakened maximal/closed erosion model. It does not
interpret arbitrary synthetic merged supports as physical sets. The
guarded precapture merger and separate central-residual obligation remain
in force. Integration with the earlier flags is possible because their
trigger targets have erosion0, whereas this flag's targets have erosion2.

## Reproducible implementations and scope

`src/bridge_lower_frontier_flagged.py` caches the exact-cost base graph
under `.build/bridge-lower-frontier-weighted-*.pickle`, then constructs
either the `inner-slack` historical model or the `forbid-pair` model from
the same weighted relations. Strict flag formation is recognizable from
source c=2 and target v=2, since maximality forces i=2. From a flagged
c=1,e=2 source to target v=2, it forces i=1. Thus no survivor information
is lost by the weighted-graph transformation in these two special cases.

The exact nine-threshold theorem in `bridge-lower-frontier-nine-proof.md`
continues to concern ONLY the unflagged model. No interval closure is
assumed here. Finite flagged clocks and residuals come from explicit
bitset-graph reachability and are labeled separately.

# Odd rectangles: positive width-three theorem and a failed compression route

Research checkpoint, 11 September 2026. General odd-by-odd nonsquare open-neighborhood nesting is not proved here. The all-parameter positive result below covers width three; odd squares are handled independently in `grid-nesting-source-audit.md`.

## 1. Why the square compression proof cannot simply be reused

In the 2016 square-grid proof, a down-right diagonal shift preserves each diagonal cardinality and moves its selected vertices toward the smallest second coordinate. The proof says this cannot enlarge the neighborhood. The direct rectangular version is false.

Take coordinates `1<=x<=3`, `1<=y<=5`, and the even singleton `Q={(1,5)}`. Its diagonal is `x+y=6`, containing `(3,3),(2,4),(1,5)`. The stated shift sends it to `Q'={(3,3)}`. But `Q` is a corner and has two neighbors, whereas `Q'` is a noncorner boundary vertex and has three. Therefore `|N(Q')|>|N(Q)|`.

This refutes that local compression lemma on nonsquares, not the conjecture of global odd-rectangle nesting. A different proof would be needed. The square source is [Abramovskaya et al., *How to hunt an invisible rabbit on a graph*, 2016](https://fedorvf.github.io/articles/2016/2016g.pdf), Section 3.1. Its Theorem 1 is specifically about squares and two candidate orders.

## 2. Full nesting for every odd three-row rectangle

Let `n=2q+1>=3`, and let the board be `P3 square Pn` with coordinates `(r,j)`, `0<=r<=2`, `0<=j<=n-1`. Write `E` for even coordinate sum, `O` for odd sum, and `h=(3n-1)/2=3q+1`. Thus `|E|=h+1`, `|O|=h`.

The strong Hall lemmas proved in `three-row-investigation.md` give the following **minimum** open-neighborhood profiles:

\[
 g_E(0)=0,\quad g_E(k)=k+1\ (1\le k\le h-1),\quad
 g_E(h)=g_E(h+1)=h;
\]
\[
 g_O(0)=0,\quad g_O(k)=k+2\ (1\le k\le h-1),\quad
 g_O(h)=h+1.
\]

For clarity, the cited strong Hall argument supplies the lower bounds, including the near-full endpoints. It uses a Hamilton cycle after deletion of any majority vertex; those cycles are explicitly constructed and independently reviewed in the three-row proof.

To attain all bounds compatibly, order both parity classes by increasing coordinate sum and, within a diagonal, increasing column `j` (equivalently decreasing row `r`). The majority order is

\[
 (0,0),\quad
 \bigl((2,2i-2),(1,2i-1),(0,2i)\bigr)_{i=1}^{q},\quad
 (2,2q).
\]

The minority order is

\[
 (1,0),(0,1),\quad
 \bigl((2,2i-1),(1,2i),(0,2i+1)\bigr)_{i=1}^{q-1},\quad
 (2,2q-1),(1,2q).
\]

Direct inspection of these triples gives

\[
 N(I^E_k)=I^O_{k+1}\quad(1\le k\le h-1),
 \qquad N(I^E_h)=N(I^E_{h+1})=O,
\]

and

\[
 N(I^O_k)=I^E_{k+2}\quad(1\le k\le h-1),
 \qquad N(I^O_h)=E.
\]

One can check the formulas by advancing through each displayed triple: every newly included vertex supplies the next one as-yet-uncovered vertex in the opposite order. Initially the majority corner has two neighbors and the first minority vertex has three. At the final majority additions all minority vertices are already covered; at the final minority addition all majority vertices are already covered. Empty prefixes have empty neighborhoods. These are identities of sets and prove the required compatibility, not only cardinality attainment.

Thus every odd `3 by n` rectangle has full isoperimetric nesting. Combined with the exact count-state dynamic program in `grid-nesting-source-audit.md`, this gives exact feasibility, minimum time and an explicit optimal strategy for **every probe budget** on odd three-row rectangles. The separate theorem `T(3 by n,2)=6n-8` gives a simpler closed expression at budget two, and also covers even `n`, where full nesting fails.

## 3. Remaining boundary

General odd-by-odd nonsquare rectangles with both sides at least five remain open in this investigation. Small all-subset evidence recorded elsewhere is encouraging but does not replace a proof. The independently useful, fully sourced higher-dimensional route is instead `H square K2`: the ordinary closed-neighborhood isoperimetric theorem for arbitrary Cartesian products of paths yields exact algorithms for every box with a side two. See `boxes-with-a-two-side.md`.

No theorem in this note is yet Lean verified, and no novelty claim is made.

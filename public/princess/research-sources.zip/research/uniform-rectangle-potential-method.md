# A separable potential route to general rectangle times

12 September2026, root independent research lane. This is computational
evidence and a proof program, not an all-width theorem.

For the proved exact odd-rectangle profiles g_z, optimize potentials
F_z(k)>=0 with F_z(0)=0 and nonnegative allocation charges c_z(p), subject to

    F_z(k) <= c_z(p) + F_(1-z)(g_z(max(k-p,0))),
    c_0(p)+c_1(m-p) <= 1.

Summing the two inequalities each day gives a rigorous lower bound on
the exact two-count game's capture time. Exact-profile normal form transfers
it to unrestricted physical strategies; arbitrary potential monotonicity
is not required for that route. Both terminal potentials are zero.
An alleged physical strategy with smaller useful allocations can be
normalized and padded to the constant budget, preserving earlier capture.

The numerical optimizer proposes coefficients, which are reconstructed
as rational numbers and every inequality rechecked exactly before being
called a finite certificate. In the initial51 parameter cases (odd widths
3 through11; three lengths each; feasible selected budgets at the threshold,
one higher, w-1 and w), every rational certificate passed. The rounded
bound equals the exact count time except11x11,m7 (49 versus50) and
11x17,m7 (93 versus94). An equality/phase obstruction may supply that
last day; this is not established uniformly.

The useful general target is an explicit width/budget-dependent family of
charges and corner potentials, with affine continuations through the
interior. A solution could bypass serial optimality, which fails on
partial states. Records: uniform-rectangle-potential-attack.json and
src/uniform_rectangle_potential_attack.py.

A plain fractional temporal-cut relaxation is insufficient: assigning
every room a fractional inspection1/t on each of t days covers every
length-t walk fractionally and uses N/t per day, even below the true
feasibility threshold. Geometry-sensitive constraints/potentials are
essential; raw linear-program duality alone cannot solve the game.

## Exact limitation of stationary separable potentials

The extended76-case test found a two-day gap, not merely a final equality
correction. Exact primal AND dual rational certificates now establish the
optimum of the displayed linear system in the following cases:

| Rectangle | Budget | Best initial potential | Exact time |
|---|---:|---:|---:|
|11x11|7|49|50|
|17x17|10|96|98|
|19x19|10|224|226|
|19x23|10|376|378|

The dual proof is elementary: assign nonnegative rational multipliers to
the local and shared-budget inequalities. Their sum has each free-variable
coefficient at least its objective coefficient; empty-state potentials
are fixed at zero. The summed right side equals the attained primal
value. This proves the value is optimal for ALL nonnegative stationary
count/color potentials with nonnegative allocation charges of this form,
not merely that one optimizer found a weak certificate. It does not
exclude historical, joint-state, or explicitly time-dependent potentials.
All coefficients and exact checks are retained in
`uniform-rectangle-potential-dual-certificates.json`. The dual certificate
for17x17 has53 nonzero multipliers. This is a limitation of this proposed
proof simplification, not a lower bound on the complexity of the problem.

Reproduction: the exploratory optimizer uses SciPy1.18.1 with one HiGHS
worker. The final primal and dual comparisons use exact Python fractions.
SciPy is not a dependency of the Lean proof archive or the mathematical
validity of the retained rational certificates.

# Eventual affine periodicity for even Hamiltonian cylinders

12 September2026. Complete ordinary proof, independently accepted by
root and by a fresh Euler audit after the explicit gap-margin and
survivor-edge timing clarifications. The second review is recorded in
`even-bridge-eventual-independent-review.md`. It uses the independently
reviewed uniform-slope and exact-surplus frontier lemmas. Euler owns the
subsequent manuscript integration; this file remains the research proof.

## Statement and conventions

LetQ be a fixed finite bipartite graph with a Hamiltonian path and2b
vertices, whereb≥1. Fix an integer inspection budgetm>b. Putd=m−b.
Then there are effectively specified positive integersΔ andN, withΔ
even, such that

    T_m(Q×P_(n+Δ))=T_m(Q×P_n)+2bΔ/d       for everyn≥N.

The increment is an integer. In particular each residue class has an
eventually affine exact capture-time function, with the already proved
slope2b/d=2|Q|/(2m−|Q|). This statement makes no claim that the period
or threshold below is small or optimal.

Fix a Hamiltonian order onQ and match consecutive vertices. A current
cohort identifies with ab×n array under this matching. The directed
neighborhood contraction contains the alternating-rung rectangle from
`even-bridge-exact-surplus-frontiers.md`. It is strongly connected for
n≥2. Thus every proper nonempty cohort support has surplus at least1;
every support in the middle range has surplus at leastb; and middle
supports of exact surplusb have the finite frontiers proved there.

Throughout, positions are measured in actual longitudinal columns.
Deleting an even number of consecutive columns preserves all physical
checkerboard phases and the column parity in the contracted graph.

## 1. Only boundedly many inefficient days occur in an optimal strategy

SetK=4b² andh=bn. For sufficiently largen, define

    C=h−2K−m> d,
    ψ(k)=min(C,max(0,k−K−m)).

The reviewed potential lemma gives, for a cohort receivingp inspections,

    ψ(k_before)−ψ(k_after)≤max(0,p−b).

For the two cohorts together, the potential loss in a day is at mostd.
Their initial total is2C. The already proved cylinder-height upper bound is

    T_m(Q×P_n)≤2ceil(b(n+2)/d).

Consequently an optimal strategy satisfies

    dT−2C ≤ B := 4K+4m+2b−2.

Indeed dT≤2b(n+2)+2d−2 by the integer ceiling bound, whereas
2C=2bn−4K−2m. All constants can therefore be bounded usingb andm alone.

Call a day efficient if its total potential loss is exactlyd. Every
other day contributes at least1 to the nonnegative integer slack, so
there are at mostB inefficient days. An increase of potential causes
more slack and does not invalidate this count.

Equality forces allm actual inspections to be assigned to one cohort:
if the quota is split, the sum of the two positive-part bounds is
strictly belowd. Call that cohort the owner of the efficient day.
Its potential decreases byd and its mate's potential is unchanged.

### Equality gives an exact-surplus bulk survivor

The owner's source potential is positive, so its survivor cardinality
r satisfiesr>K. Its successor potential is less thanC, so its successor
count, and hencer, is less thanh−K. The middle neighborhood bound gives
surplus at leastb. Combining this with equality in the potential loss
forces all of the following equalities:

    actual inspections=m,
    successor count=source count−d,
    survivor surplus=b.

To see that clipping does not hide an exception, the raw count loss is
at mostm−b=d. Clipping can only decrease that loss. Equality of the
clipped loss withd therefore forces equality of the raw loss, with
source and successor on the linear segment or its endpoints. The
survivor itself remains strictly insideK<r<h−K.

The exact-surplus lemma now applies to every efficient owner survivor:
it is a common left or right frontier, with adjacent cut differences
at most2 and a finite offset/parity label.

## 2. Cleaning up owner changes and endpoint transients

An untouched cohort whose potential is strictly between0 andC cannot
have constant potential: its count is in the middle range and its next
neighborhood grows by at leastb. Thus the mate of an efficient owner
has potential0 orC.

An efficient run has at most two consecutive owner blocks. Once a
cohort has owned a day its potential is belowC. If ownership switches,
the previous owner can have unchanged potential only at0. It cannot
subsequently own a day in the same run, because it cannot lose anotherd
from0. Hence each cohort owns at most one block in an efficient run.
There are at most2(B+1) such blocks over the whole strategy.

PutL=K+m+1. If an untouched mate of potential0 is nonempty, its count
grows by at least1 each day and leaves the collar of at mostK+m rooms
withinL days; therefore that owner block has length at mostL. If an
untouched mate of potentialC is not full, its deficit is at mostK and
it becomes full withinK days. The growth statement follows from strong
connectivity of the directed contraction, and applies each day.

Mark as nonclean every inefficient day and the firstL days of every
owner block. There are at most

    E := B+2L(B+1)

nonclean days. On every remaining clean day the mate is globally empty
or full. A maximal clean block has one owner and one fixed orientation.
Its current owner belief is already the neighborhood of the preceding
efficient frontier survivor, since at least one initial owner day was
marked. Thus both the before-inspection belief and the after-inspection
survivor have bounded-width frontier descriptions throughout the block.

An orientation change between consecutive bulk survivor frontiers is
impossible by the earlier lemma. The exact full-quota transition of a
left survivor with cuts(c_i) to the next survivor with cuts(e_i) is

    e_i≤c_i+1,        Σ_i(c_i+1−e_i)=m.

HenceΣe_i=Σc_i−d. For a right frontier the sum increases byd. Its average
cut therefore moves at the constant nonzero speed d/b toward clearance,
although individual cuts may wiggle by a bounded amount.

## 3. A common physical band that no nonclean event can alter

Consider maximal consecutive blocks of nonclean days. Each has length
at mostE. At the start of one, either this is the initial full board,
or the preceding clean state consists of a bounded-width owner frontier
and a globally empty/full mate. Mark every cut column of that frontier.
Also mark the column of every actual inspection on every nonclean day.
There are at mostb(E+1)+mE such marked columns. Include the two ends of
the board and enlarge every marked column by a radius

    ρ=E+2b+m+2.

Outside these finitely many intervals, each cohort is locally full or
empty throughout every nonclean block. Here “full” means that all the
vertices of its current checkerboard phase in those columns are possible.
At the beginning of a block this follows because its frontier cuts lie
outside the enlarged interval. During the block no inspection occurs
within the protected neighborhood, and movement propagates information
by at most one longitudinal column per day. Empty regions therefore
stay empty in the interior; full regions stay full using the fixed
matching inside each column. The radiusρ exceeds the block length and
the frontier width, so the statement holds for all its intermediate
states, not merely the endpoints.

Putv=2(b−1). For any chosen constantW, sufficiently largen therefore
has an interior unmarked intervalJ_raw of length at leastW+2v+4.
For example, with
F=(b+m)(E+1)+2, the inequality

    n>F(2ρ+1)+(F+1)(W+2v+4)

suffices by counting the at mostF+1 gaps. Trimv+2 columns from each end
and call the retained intervalJ; it has length at leastW. This choice
is independent of the particular optimal strategy.

OnJ, a nonclean block preserves each cohort's locally full/empty status.
Every clean block has a single owner with a monotone average frontier,
and its mate is globally full or empty. Its endpoint frontier positions
are outsideJ: the preceding nonclean block ends uniformly onJ, and the
following nonclean block's initial frontier positions were marked.
Thus a clean block can change its owner's status onJ only from full to
empty, through one passage of the frontier; it cannot change empty to
full. Each initial cohort starts full onJ and ends empty there.

It follows that each cohort crossesJ in exactly one clean block. The
two crossings occur at disjoint times and, during either crossing, the
other cohort is globally empty or full. ChoosingW large gives an
arbitrarily long central crossing segment on which the entire frontier
is well insideJ, since its width is bounded and its average speed isd/b.

This is a statement about complete passages through the retained band, not
pointwise monotonicity of every room. Individual cuts may wiggle. Since
their range is at mostv, the trimming ofJ_raw eliminates any partial
excursion by a block whose initial and final
statuses are the same. A clean block cannot end full after starting
empty: its strictly monotone average would have to traverse the whole
long band in the wrong direction. Thus the trimmed band's status cannot
revert from empty to full between complete passages.

This is the step that cardinality alone would not justify. Nonclean
shots can create holes far behind a front; marking their actual columns
and bounded propagation neighborhoods is what makes physical surgery
valid.

## 4. A finite additive graph for a clean crossing

Write each frontier cut asc_i=t+a_i, witha_0=0 and adjacent offset
differences at most2. A state consists of its offset sequence, left/right
orientation, current cohort phase, andt modulo2. There are at most

    M=8·5^(b−1)

states. Extra transverse edges inQ only remove invalid states or edges.
They are tested in a bounded band around the cuts, so validity is
translation-invariant by an even number of columns.

Here translating a frontier means translating its cuts and filling the
corresponding full/empty tails up to the new board ends. It is not a
claim that longitudinal translation is an automorphism of a finite path.
The identityN(R)=R∪B under matching and the local cut conditions justify
these translations; all additionalQ edges stay within a column, and
the filled tails contribute no new outside boundary.

The exact full-quota formulas give the edges. In a left crossing, every
edge lowers the sum of cuts byd; in a right crossing it raises that sum
byd. Consequently a closed walk of lengthl translates its frontier by
exactlydl/b columns toward clearance. A closed walk returns both its
cohort phase and its translation parity, so its length and its spatial
translation are even. There are no zero-displacement closed walks.

The vertices of a crossing path are after-inspection survivor states.
An edge consists of the ensuing movement and the following inspection.
Thus deletingl edges removes exactlyl inspection days, with the initial
survivor state retained. This convention also fixes the endpoints of
every crossing segment used below.

Let

    l0=2b·lcm(1,2,...,M),       Δ=dl0/b.

Thenl0 andΔ are positive even integers. Any sufficiently long walk in
the finite graph contains disjoint closed subwalks with total length
exactlyl0. A concrete bound isM²l0 edges: partition intoM-edge chunks;
each chunk has a repeated state and hence a closed subwalk of length
between1 andM. At leastl0 chunks supply some common lengthl by the
pigeonhole principle. Since l dividesl0, delete l0/l of these disjoint
subwalks. Their total spatial translation isΔ.

Conversely, anyM-edge walk contains a closed subwalk of lengthl≤M.
Repeat that subwalk an additionall0/l times. This insertsl0 edges and
an additional translationΔ. Every repeated copy is legal because its
offsets, phase, and translation parity agree at the endpoints.

An explicit conservative protected length is obtained by putting
v=2(b−1), H=M²l0+M and choosing

    W=2(Δ+v+m+3)+ceil((d/b)(H+4))+2v+2m+10.

Take the central crossing segment after the average cut has entered
the interval with marginsΔ+v+m+3, and before it leaves the opposite end.
The average changes by exactlyd/b per edge, at mostm, so entry and exit
overshoots lose at most2m of spatial length. The remaining middle length
is at leastceil((d/b)(H+4))+2v+10, supplying more thanH edges. Every
individual cut lies withinv of the average. Hence the entire frontier
stays away from the ends ofJ by more thanΔ throughout the segment,
including its entry/exit edges. SinceH≥M²l0, its traversal length also
exceeds the centralΔ-column interval by ample margins. Its initial and
final entire frontiers therefore lie on opposite sides of that interval.

For example an effective overall threshold larger than

    2+ceil((2K+m+d+1)/b)+F(2ρ+1)+(F+1)(W+2v+4)+Δ

ensures the positive-cap condition, the protected gap, and both long-board
conditions used below. No attempt is made to optimize this threshold.

## 5. Deleting a band from an arbitrary long optimal strategy

Start with an optimal strategy onQ×P_n for sufficiently largen, and
choose the protected intervalJ above. Remove an arbitraryΔ consecutive
columns at the center of that interval, obtainingQ×P_(n−Δ). Choose each
central crossing segment with its initial and final entire frontiers
on opposite sides of this deleted band, as ensured by the margins in
Section4. Outside the two
central crossing segments, map all rooms and inspections by the natural
column deletion. No nonclean inspection is lost, and every nonclean
state is uniformly full/empty near the join. Thus neighborhood formation
commutes with this map there. A clean frontier outside a crossing lies
entirely on one side of the join; it is either translated as a whole or
left fixed, and its transition remains valid with the same quota.

Within each cohort's central crossing, delete the disjoint closed
subwalks totalingl0 edges from Section4. The resulting frontier walk is
legal on the shorter cylinder and matches the naturally mapped states
at its two ends. To check the geometry explicitly, for a left frontier
start by shifting its original cuts left byΔ. After deleting a cycle
with displacementδ, reduce that translation shift byδ. At the end all
deleted displacements totalΔ, so the final frontier is unshifted. Every
kept edge is merely an even translate of an original edge. For a right
frontier, begin unshifted and subtract the accumulated deleted
displacements, ending shifted left byΔ. The central margins ensure
all intermediate cuts remain inside the new board.

The other cohort is globally full or empty during a crossing. Removing
an even number of days and an even number of columns preserves its
phase and state. The two crossing edits occur at disjoint times, so
they do not interfere. All other inspections retain their original
budgets. The shorter board is therefore captured inT_m(Q×P_n)−2l0 days:

    T_m(Q×P_(n−Δ))≤T_m(Q×P_n)−2l0.

This construction does not assume the rest of the optimal strategy is
a sweep or even globally close to a frontier. The protected-band argument
is what permits arbitrary nonclean behavior elsewhere.

## 6. Inserting a band gives the reverse inequality

Apply the same preparation to an optimal strategy on the sufficiently
long boardQ×P_(n−Δ). InsertΔ columns in the protected central interval.
Outside its two crossings, extend the uniformly full/empty regions and
translate rooms on the far side of the join. Their transitions commute
with insertion for the same local reason.

During each central crossing, repeat one short closed subwalk an
additionall0/l times. A left frontier starts shifted right byΔ and
spends the added displacement on those repetitions, ending unshifted;
a right frontier follows the reflected construction. The added days
totall0 per cohort. All intermediate frontiers remain in the enlarged
protected region, and the empty/full mate returns to the same phase.
This gives

    T_m(Q×P_n)≤T_m(Q×P_(n−Δ))+2l0.

Combining the two inequalities yields equality for all sufficiently
largen. Increasing the threshold once ensures both boards are in the
regime used by the proof. SinceΔ=dl0/b, its increment2l0 is exactly
2bΔ/d, as asserted.

## Audit targets and proof boundaries

The main points requiring independent attack are the physical-band
argument, the classification of clean owner blocks, and endpoint matching
of the two separately edited crossings. The finite graph uses the
already reviewed exact-surplus lemma, not a conjectured optimal prefix
normal form. The proof gives eventual exact affine periodicity; the
enormous period construction is intentionally conservative. No full
Lean formalization or efficient computation of the exception table is
claimed here.

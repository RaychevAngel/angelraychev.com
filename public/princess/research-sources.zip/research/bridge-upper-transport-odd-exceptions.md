# Seven fixed budget lines remove the additive threshold correction

13 September 2026. Ordinary periodic-insertion proof plus a small finite
certificate; independently reviewed and accepted by the root lane.

Combining this note with the accepted even-width coupling and the
odd-width buffer proof gives BOTH requested couplings, hence the uniform
one-day bracket, whenever

    width w>=4,       k>=ceil(4w/3),       k<wn/2,

on an even-area rectangle with length n>=w. The smaller widths and the
elementary k>=wn/2 region retain their existing separate treatments.
The remaining general target `k>=w` is not settled by this result.

## Why only seven lines remain

For odd width `w=2b+1`, put `k0=ceil(4w/3)`. The proved sufficient
condition is

    floor(k/2)-b-1 >= ceil(b²/(2(k-b-1))),       k>b+1.

Writing `b=3q+s`, this holds at k0 for all s=0; for s=1 it is
equivalent to `q²-2q-1>=0`; for s=2 it is equivalent to
`q²-4q-4>=0`. Therefore the only missing budget lines are

    (b,k)=(2,7),(4,12),(5,15),(7,20),(8,23),(11,31),(14,39).

At k0+1 the sufficient condition holds on each line, and its two sides
improve monotonically with k. Thus only these seven FIXED pairs need
an additional proof, with n still arbitrary and even.

## One translation law handles every larger length

Fix one of the seven pairs. Use the combined state `(B0,B1,B2,X0,X1)`
from the odd coupling proof. Its two initial states correspond to capture
seed0 with physical half-budget seed m, and model seed m with physical
seed k. Put

    A=b(b+1)+1,       D=2k-2b-1,       w=2b+1.

Each initial state reaches a fixed entry state, independent of all
sufficiently large h, with

    B0>=A, B0=B1, B2-B0 in {0,1}, min(X0,X1)>=b²+1.

The receipt records both entry times and all five coordinates. In this
range the model's low-root branches are inactive. The physical low-root
costs are at least their caps b and b+1, respectively. Whenever the
high-root branches and state caps are also inactive, TWO updates add
exactly D to each of the five coordinates. For the model this is its
alternation between `(a,a,a)` and `(a,a,a+1)`; for the physical phases
the successive increments are k-b and k-b-1.

A conservative stable-length threshold is obtained as follows. Record
the largest coordinate M occurring in either initial prefix through its
entry state AND the first update after that entry. Require

    h >= M+max(b²+1,k+2).

This excludes every high branch at surplus at most b, makes the physical
high terms no smaller than their caps, and leaves every next model state
cap inactive. Therefore all these initial updates and the first two
middle updates are independent of h. The first stable even length n0
in the receipt is chosen to meet this requirement for both initial
states.

Now replace any even n>=n0 by `n+2D`. The half-area increases by

    Delta=wD.

Its initial sequence through the fixed entry is identical. At that
entry, insert w pairs of middle updates, taking2w extra days and adding
Delta to every coordinate. These inserted steps remain in the common
middle: relative to the larger half-area, their deficits are at least
those of the original entry and first middle update. Thus the chosen
stable-length margin covers every inserted pair.

After insertion, follow the entire original remaining trajectory with
Delta added to every coordinate. All low-root branches remain inactive,
because all five coordinates are nondecreasing and were already past
their low thresholds at entry. All high-root arguments `h-coordinate`
are unchanged by simultaneous translation. The model state caps and
physical full-prefix cap translate by Delta as well. Hence EVERY later
update, including capture, is exactly the translated original update.

The comparison `B2<=max(X0,X1)` is translation invariant. Every inserted
pair has exactly the comparison values of the original first middle
pair. Therefore if both couplings hold at every deadline on n, they hold
at every deadline on n+2D. No new phase choice is inserted:2w is even
and returns both physical trajectories to their original phase alignment.

## Finite bases and independent checks

It remains to check all even lengths from w+1 through `n0+2D-2`. This
includes every shorter board and exactly one representative for every
even-length residue modulo2D above n0. The seven finite ranges are:

| Width | Budget | First stable length n0 | Length period2D |
|---|---|---|---|
| 5 | 7 | 10 | 18 |
| 9 | 12 | 14 | 30 |
| 11 | 15 | 16 | 38 |
| 15 | 20 | 20 | 50 |
| 17 | 23 | 20 | 58 |
| 23 | 31 | 30 | 78 |
| 29 | 39 | 34 | 98 |

`src/bridge_upper_transport_odd_exceptions.py` checks all199 required
lengths, both initial states, and all12393 deadlines through model
capture. Every coupling holds. It additionally verifies107 translated
tail states in explicit n0-to-n0+2D comparisons, including both capture
times, and records source hashes and all entry data. Runtime was0.196
CPU seconds. The receipt is `bridge-upper-transport-odd-exceptions.json`.

This is a finite residue certificate backed by a uniform insertion
proof. It is not extrapolation from an observed affine trend, and it
uses no new classification of partial physical supports.

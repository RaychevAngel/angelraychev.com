# Independent review of the ladder classification

11 September 2026, Pacific time. Reviewer: the path-lower-bound audit agent, independent of the coordinating and small-grid agents who derived the ladder argument. Reviewed `research/ladder-investigation.md` in full and read the counter-model implementation. This is an internal mathematical review, not external peer review or Lean verification.

**Conclusion:** I found no substantive gap in the claimed complete capture-time formula for `P_n □ P_2`. The lazy-path projection, cardinality domination, equality obstruction, and explicit upper construction form a complete argument under the stated mandatory-move game. The residue correction is supported by the proof, rather than merely fitted to finite examples. This review establishes no literature novelty.

## Checks of the reduction

At each time and fixed initial checkerboard color, each column contains exactly one possible room of that cohort. A vertical move becomes a column stay; a horizontal move changes the column by one. Every allowed lazy column move corresponds to the unique required room of the next checkerboard color. Thus projected belief evolution is exactly the closed-neighborhood operator on the column path, not just a relaxation.

For `F(b,p)=0` when `p≥b` and `F(b,p)=min(n,b−p+1)` otherwise:

- It is nondecreasing in `b`, including the jump from `b=p` to `b=p+1`.
- A nonempty proper survivor set has at least one new neighbor because the column path is connected.
- Empty and full survivor sets are handled explicitly by the formula.
- A suffix attains the bound after deleting its leftmost vertices.
- Using the same cohort allocations in a suffix strategy as in an arbitrary strategy preserves domination even if the suffix cohort dies earlier. Subsequent allocated probes may be unused, which is allowed by the at-most-`m` model.
- The two cohorts' rooms are disjoint, so both suffix constructions can be implemented simultaneously even when their column projections overlap.

The reduction does not assume that arbitrary optimal strategies are monotone. Its use of monotonicity is only the elementary monotonicity of the scalar transition function.

## Checks of the lower bound and equality case

Writing a day's decrease as `u−g`, with `u` useful probes and `g` closed-neighborhood expansion, is exact. If no cohort is eliminated and a useful probe is made, that probed cohort has a nonempty proper survivor set and pays at least one expansion. If one cohort is eliminated, the decrease is at most `m`; if both are eliminated, the bound `M+e` has a strict unit of slack. Summing `Δ≤M+e` is therefore valid for arbitrary intermediate shapes, including regrowth and wasted probes.

When `Mt=2(n−1)`, every day's bound must be tight. A first elimination day must have zero expansion in the surviving cohort, hence that cohort must be full and untouched. Earlier equality days have exactly one unit of expansion, all `m` probes useful, one proper survivor set, and the other full. The currently swept proper cohort cannot be abandoned or exchanged with the full cohort without paying a second expansion or violating the elimination-day equality. This proves that `n−1` must be divisible by `M`.

If `M` divides `2(n−1)` but not `n−1`, elementary integer arithmetic gives precisely the stated half-residue exception. No other residue is excluded by this equality argument, and the construction covers all of them.

A useful optional simplification: the inequality `2n≤(m−1)t+2` remains valid at `m=1`. It then directly rules out a finite strategy for `n≥2`, so the separate minimum-degree argument is correct but not necessary.

## Boundary and schedule checks

- If `m≥2n`, all rooms are captured in one round; this case must precede the formula.
- For `n≤m<2n`, the formula gives two rounds, including `m=2n−1`, where the half-residue term prevents an erroneous one-round answer.
- In the `s=0` branch, `n≥2` implies `q≥1`; there is no zero-length phase or negative number of ordinary sweep days.
- In the `s>0` branch, each of the first `q` sweep days is nonterminal because the next-to-last suffix size exceeds `m`.
- On the shared transition day, the spare probes are `M−s≥1`. They cannot clear the second cohort under `m<2n`: when `q≥1`, its size exceeds `M`; when `q=0`, the inequality `M≤2s` gives `M−s≤s<n`.
- Therefore the resulting suffix size `b=(q−1)M+2s+2` lies in `[2,n]`, even at `q=0`. The subsequent formula `ceil((b−1)/M)` is consequently valid; it is not inadvertently being applied to an empty or singleton suffix.
- The arithmetic difference between `ceil((2s+1)/M)` and `ceil(2s/M)` occurs exactly when `2s=M`, because `0<2s<2M`.
- Capture is checked before another move. No extra terminal movement or extra capture day is counted.
- The `n=1` single-edge case is correctly separated: two rounds with one probe, one with two or more.

## Independent computational attacks

I wrote `src/ladder_independent_checks.py` without importing the counter solver.

1. It checked every column-belief subset and every useful action on each closed path of lengths 1 through 12: **797,160 subset/action cases**. The cardinality lower bound held in every case. It separately checked monotonicity of `F` and exact attainment by suffixes, including zero and excessive probe allowances.
2. It generated the explicit quotient/remainder construction directly from the written proof for all finite cases with `1≤n≤200` and `1≤m≤2n+2`: **40,401 schedules**. Every length agrees with the claimed formula and every counter trace terminates.
3. For **961 of those cases**, with `n≤30`, it built actual room probes and propagated room sets through actual vertical/horizontal moves. Each schedule captured on exactly its last listed round.

All checks passed in approximately 0.25 seconds in one process. Full output is in `research/ladder-independent-checks.json`. These tests attack edge cases and indexing; they do not replace the mathematical proof or establish novelty.

## Editorial boundaries

The paper should explain clearly that a column stay is a legal vertical move, not permission for the princess to remain in her room. This is the conceptual point most likely to be misunderstood.

The user has said the summer 2020 two-row notes are unavailable and should supply no assumed results to this investigation. The current derivation can be described as new work in this project, while any claim that it is new to the literature must await the separate literature audit.

No mathematical repair to the ladder proof was required by this review. Lean verification and external review remain outstanding.

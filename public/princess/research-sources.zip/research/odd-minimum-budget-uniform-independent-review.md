# Independent review of the uniform odd-rectangle bounds

12 September 2026. The proof in `odd-minimum-budget-uniform-bounds.md` passes
independent review. For every odd `3≤w≤n`, with budget `(w+1)/2`, it establishes

\[
\max(0,2wn-2w^2+2w-10)\le T\le2wn-2w-2.
\]

The argument is uniform in both side lengths and does not depend on finite
charge tables. The exact profile theorem remains an ordinary geometric
antecedent. The new module `lean/UniformOddRank.lean` proves the universal
scalar lower inequality and the two-current-color summation, with explicit
geometric hypotheses; it is not a physical odd-rectangle Lean theorem.

## Lower bound and endpoint audit

Write `w=2b+1`, `m=b+1`, `H=(wn+1)/2`, and let p be zero for majority and one
for minority. The potential is

    K=2b²+2b+2,
    C=max(0,2H−4b²−2b−6),
    F_p(k)=min(C,max(0,2k+p−K)).

For quota `r≤m`, put `q=max(k−r,0)` and let j be the next support size. The
following two bounds are enough:

1. `q≤j+1` everywhere;
2. `q+b+p≤j` when `b²<q<H−b²−1`.

The exact odd-rectangle profiles supply both for arbitrary supports: the first
uses the minimum possible surplus −1; the second is their central plateau.
The profile's minority far-corner argument is `H−1−q`, not `H−q`. In the
central range it is at least `b²+1`, which is safely past the threshold for
`Q` to reach b+1. The majority far distance is at least `b²+2`, enough for
its square-root term minus one to reach b. Both low-corner terms also reach
their caps because q exceeds b².

If `q≤b²`, then `k≤b²+r`, including q=0. With r<m the current unclipped
value is at most −1; with r=m it is at most one. This directly gives the
claimed loss bound from nonnegativity of the target potential.

If `q≥H−b²−1` and C is positive, then `j≥q−1≥H−b²−2`. The target affine
value is at least C even in the worst case `1−p=0`. Thus it clips to C and
cannot be below the current potential. If C is zero, both potentials vanish
and no separate geometric argument is required.

In the middle, q is positive, so `k=q+r`. The target is at least q+b+p.
Consequently the raw affine values obey

    current − target ≤ 2r−2b−1,

which is at most −1 for r<m and at most one for r=m. Clipping to `[0,C]` is
monotone and cannot increase a positive difference. The central equality
claimed in the ordinary proof is therefore stronger than needed.

The ranges cover all q. Possible overlap of the low/high descriptions on
small parameter values causes no problem: either valid argument suffices.
The two full-class potentials both equal C, and the zero-class potentials
vanish. At most one current color can receive the entire quota m on a day,
so their sum decreases by at most one. The initial value `2C` is exactly the
displayed lower bound after substituting H and w.

## Upper construction

The maximum majority surplus is b=m−1 and the maximum minority surplus is m.
Starting from a minority prefix, a pair of full-budget rounds reduces its
size by at least one unless it is already empty. Put `M=H−1`. The assumptions
`n≥w≥3` ensure M≥m, so

    L=2(M−m)+1

is a positive odd integer. After the first L−1 rounds the target cohort has
at most m positions, and the last round inspects all of them. If it cleared
earlier, use no useful probes for the rest of this fixed phase. This padding
is a legitimate predetermined strategy, not a claim about optimal play.

The untouched cohort remains the full alternating parity. Since L is odd,
the initially majority cohort is now exactly the full minority class. Repeat
the same L-round phase. The two-phase length is `2L=2wn−2w−2`. There is no
hidden parity-alignment day, and no use of serial optimality.

The theorem does not include `w=1`; ordinary path results cover that case
separately. It determines the coefficient of n uniformly, but does not prove
that the bounded correction stabilizes to one constant for each width.

## Lean statement and receipt

`Princess.UniformOddRank.Step` contains exactly the two geometric lower bounds
listed above, with natural subtraction for q. The theorem `potential_step`
proves the universal one-cohort inequality. `two_cohort_step` adds the two
inequalities under a shared budget and explicitly exchanges their successor
colors. The initial and zero values and potential monotonicity are also proved.

The scalar proof is valid for all natural parameters satisfying its stated
inequalities, which is slightly broader than the physical rectangle domain.
Its only assumptions are displayed arithmetic/geometric predicates; no profile
theorem or physical search assertion has been hidden in an axiom.

The fresh one-module receipt is `uniform-odd-rank-lean-verification.json`.
It records the source hash, compiler version and axiom output. No admissions
or added axioms occur. A full formal physical theorem would still need the
ordinary profile bounds connected to actual grid neighborhoods.

# Consolidation of the three-row and five-row proofs

12 September 2026. Euler. Executed with the root's explicit ownership
assignment for `paper/sections/three-rows.tex` and
`paper/sections/five-rows.tex`. No other manuscript or Lean source was
changed by this consolidation.

## What is subsumed and what remains

The new odd-short/even-long high-budget theorem applies to three rows
at every m≥3 and to five rows at every m≥7. The earlier special boundary
case arguments in those ranges are therefore replaced by explicit
specializations. The three-row m=2 proof and five-row m=3,4,5,6 proofs
remain. The odd-length five-row section was not edited.

The exact three-row historical two-counter realization is stronger
than its full-board time formula and remains intact. Its last-full
active-interval inequality and label `eq:three-interval` remain too.
For five rows, every endpoint-compatibility lemma and the actual
historical lower relation are retained. The common-cap potential is
still proved throughout 5≤m≤h−8, not just at the residual budgets five
and six. Thus these subordinate structural results were not silently
removed with the redundant full-board case analysis.

All existing equation and theorem labels in these two sources were
retained. The independent finite checks in
`FiveRowHighBudgetArithmetic.lean` remain cited, as do the deficit,
four-probe inequality, and four-probe equality certificates. No Lean
files were removed or changed, and no new physical Lean claim was made.

## Short critical-budget three-row proof

For even n≥4, h=3n/2, the existing rank transition is

    F_h(u,p)=0 if floor(u/2)≤p,
             min(2h,u−2p+3) otherwise.

Set V(u)=max(0,u−4). For p=0,1 the potential cannot decrease. For
p=2 it decreases by at most one, including the terminal case u≤5.
The physical rank lower bound and monotonicity transfer this to actual
supports. The shared budget two permits at most one such decrease per
day. The initial total is 2(2h−4)=6n−8 and the final total is zero.
The retained physical prefix realization attains the bound by two solo
sweeps of 2h−4 days. The n=2 board is the existing two-row case.

For m≥3, the general theorem at b=1 has J(r)=floor(r/2)+2. Since its
numerator 3n−4 is even and denominator 2m−3 is odd, r and q have the
same parity; 2J(r)=r+4−(q mod 2), exactly the old closed formula.
This also covers the previously separate near-full-budget exceptions.

## The five-row ammunition function is already the general function

The shared interior lemma assumes m≥b²+1. At b=2 its exact hypothesis
is m≥5, so both remaining budgets are included. The root conventions
used here are R(k)=ceil(sqrt(k)) and Q(k)=min{a≥1:k≤a(a−1)}.

For D=2m−5 and positive residue s∈{1,...,D}, the b=2 corner function
satisfies

    floor((s+6)/2)−J(s) = 1 if s is 1,2,4; 0 otherwise,
    J(D)=m.

If j=floor(max(0,u−7)/D)≥1 and s=(u−7 mod D)+1, then
u=6+jD+s. Therefore the general potential jm+J(s) is exactly

    floor((u+5j)/2)−1_{s∈{1,2,4}}.

When j=0, u≤2m+1, so both definitions equal floor(u/2). This proves
the identity for every natural u and every m≥5, including both quotient
boundary conventions. The published interior inequality has target
rank at most u−2p+5 because L_0(s)≤s+2 and L_1(s)≤s+3. Monotonicity
thus proves the older affine-step inequality without repeating its
discount analysis.

The additional bound F(u+2)−F(u)≤3 follows from the same residue list.
Inside a positive period the two-step increments of J are at most two;
at the wrap they are at most three by J(D)=m, J(1)=2 and J(2)=3.
At the first cardinality-to-period transition the two possible increases
are two and three. The source retains the full physical verification
of small survivors, co-small survivors, and the cap; a scalar inequality
alone was not used as a replacement for those geometric conditions.

For m=5 the physical h is a multiple of five, giving q=n−2, r=4 and
C=5q+4. For m=6 the cap values C−6q, in residue order 0,...,6, are
0,2,2,4,4,5,6. These give exactly the stated times. The physical upper
sweeps share a day only at m=6,r=1,2, when starting allocations two and
three decrease the fresh rank by one and two respectively. All other
remaining residues use separate sweeps.

## Validation and proof boundary

The two-section standalone document compiled twice successfully into
13 pages, with no overfull boxes. The changed pages 3,10,11,12 and
their adjacent page 4 were rendered and visually inspected. External
references are intentionally unresolved in this isolated wrapper; the
root is responsible for the integrated manuscript reference check.

As a redundant arithmetic attack, the two independently written
potential definitions and the two-unit increment bound agreed at
46,046 pairs (m,u), with 5≤m≤50 and 0≤u≤1000. The cap evaluations
agreed at 196 physical cases, even 6≤n≤200 and m∈{5,6}. An initial
test used the wrong R/Q conventions, failed immediately, and was
corrected against the manuscript definitions; no mathematical claim
rests on that discarded test. The general residue proof above, rather
than this finite sample, establishes the unbounded assertion.

The root was notified that the sources were frozen for the full build.
No full manuscript build, global formal receipt, website change, or
additional research direction was launched by this consolidation.

Dirac (`three_row_all_budgets`) subsequently independently read both
consolidated sections and returned PASS: the three-row capture and cap
endpoints, the exact b=2 potential identity, both phase target bounds,
the m=5,6 cap evaluations, and the physical shared starts all checked.
He found no substantive mismatch and confirmed that the independent
Lean certificate provenance remains present.

## Root follow-up: finite even-cylinder theorem

The former detailed proof of the single 3×3×4,m5 value is a strict
specialization of the independently proved all-length18n−36 theorem.
The manuscript now proves its retained proposition label as that corollary,
and records the independent eight-count exhaustive verification and physical
witness in one paragraph. Its algorithm, receipt, and original history stay
in the research archive; no complete Lean guarantee is removed. The full
higher-dimensional compression results that justify the finite verifier
remain in their general sections.

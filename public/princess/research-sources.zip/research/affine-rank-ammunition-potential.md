# A probe-count potential for affine phase ranks

Research note, 12 September 2026. Developed during the path formalization, after the three- and four-row ordinary proofs. The path specialization and the odd-path equality correction are kernel checked in `lean/PathRankLower.lean` and `lean/PathOddRankLower.lean`. The general statement below currently has an ordinary proof. This is a new proof organization for the author's original path result, not a claim that the path result itself is new.

## The abstract process

Fix a daily budget `m` and a movement cost `c` with `0≤c<2m`. Let `D=2m−c>0`. One cohort has a rank `u≤C`. Allocating `p≤m` probes updates its rank by

\[
F_C(u,p)=\begin{cases}
0,&\lfloor u/2\rfloor\le p,\\
\min\{C,u-2p+c\},&\text{otherwise}.
\end{cases}
\]

The cap may be constant or may alternate; the single-step statement below requires the old rank not to exceed the *new* cap when `2p≤c`. Thus a constant cap suffices; alternating-cap applications require a separate comparison or explicit parity analysis.

Define

\[
J(u)=\left\lfloor\frac{\max\{u-c-2,0\}}{D}\right\rfloor,
\qquad
\Phi(u)=\left\lfloor\frac{u+cJ(u)}2\right\rfloor.
\]

Then every allocation satisfies

\[
\Phi(u)\le p+\Phi(F_C(u,p)). \tag{1}
\]

This avoids the need to identify productive intervals for the main lower bound.

## Proof of the potential inequality

Both `J` and `Φ` are nondecreasing. If the cohort is captured, `u≤2p+1≤2m+1`, so `J(u)=0` and `Φ(u)=floor(u/2)≤p`.

Suppose capture does not occur. If `2p≤c`, the next rank is at least the old rank, so monotonicity proves (1). If `2p>c`, write `v=u−2p+c`; this is positive, at most `u≤C`, and hence no clipping occurs. Because `p≤m`,

\[
\max\{u-c-2,0\}\le\max\{v-c-2,0\}+D,
\]

so `J(u)≤J(v)+1`. Therefore

\[
u+cJ(u)\le v+2p-c+cJ(v)+c=v+2p+cJ(v).
\]

Taking half and rounding down gives (1).

For two independently tracked cohorts sharing the daily budget, telescoping (1) gives

\[
\Phi(u_0)+\Phi(v_0)\le Tm
\]

whenever both ranks are zero after `T` rounds. This permits arbitrary interleaving, nonproductive probes, and returns to the full state.

## Path specialization and the parity correction

For paths, `c=1`; the physical lower rank is `u=2b+z`, where the historical bit `z` prevents an unjustified second zero-surplus expansion. With even path length `n`, both initial ranks equal `n`. Positive remainder coordinates

\[
n=q(2m-1)+r+2,\qquad 1\le r\le2m-1
\]

give

\[
\Phi(n)=qm+\lfloor(r+2)/2\rfloor.
\]

The shared probe bound supplies the exact even-path lower bound. The same constant-cap bound also applies to odd paths by domination, but it is one day weak when `m` is even, `r=m−1`, and `q` is even. In that case

\[
n=q(2m-1)+m+1,\quad T=2q+1,
\quad A=qm+m/2,\quad 2A=Tm.
\]

Use the actual alternating capacities `n+1,n`. For each captured cohort, take the interval from its last full state before its first capture. If its length is `L`, its starting cap is `C`, and its probe count is `P`, all intermediate transitions are unsaturated and affine. Telescoping yields

\[
C+L\le2P+2. \tag{2}
\]

Since `P≤Lm` and `C≥n`, one gets `L≥q+1`; (2) then gives `P≥A`. Equality forces `L=q+1` and `C=n`, so both cohorts' last active intervals start on their minority parity.

If both cohorts were captured in `T=2q+1` rounds, their two interval probe counts would both equal `A`. Their initial phases are opposite. Thus the first interval has odd start `a`, the second has even start `b`, with `a,b≤q`. Since `q` is even, `1≤a≤q−1`. If `b=0`, both intervals fit inside rounds `[0,2q)`; if `b≥1`, they both fit inside `[1,2q+1)`. Either way their combined probes are at most `2qm`, contradicting `2A=(2q+1)m`.

No assumption that the active intervals are disjoint is used. Both may overlap extensively. The argument only uses their separate probe counts and a common shorter containing interval.

## Three-row specialization

For even-length three-row grids the established physical rank has `c=3`, initial cap `u=3n`, and `D=2m−3`. In positive remainder coordinates

\[
3n-4=qD+r,\qquad1\le r\le D,
\]

one gets `Φ(3n)=qm+floor((r+4)/2)`. For even `n`, the parity identity `r≡q (mod 2)` gives precisely the residue threshold `m≥r+4−(q mod 2)` for the possible odd total `2q+1`. The high-budget geometric corner exceptions still need their separate physical bridge; this potential does not remove any such hypothesis.

For odd lengths, the alternating caps need their own equality analysis, already supplied in the three-row proof. This note suggests a shorter organization of that proof; the existing independently reviewed proof remains intact.

## Formal proof boundary

- `PathRankLower.ammunition_step`: exact path (`c=1`) inequality (1).
- `PathRankLower.captured_ammunition`: arbitrary shared-budget schedules.
- `PathRankLower.captured_even_formula`: prepared exact even-path formula as a lower bound for the counter process.
- `PathOddRankLower.active_exists`: last-full intervals extracted from actual finite counter traces.
- `PathOddRankLower.active_probe_lower`: equation (2).
- `PathOddRankLower.odd_exception_impossible`: parity obstruction at the equality time.

All named theorems compile under Lean 4.33.1 with only the usual `propext`, `Classical.choice`, and `Quot.sound` dependencies, with no `sorryAx`. Physical graph geometry and domination are separate modules owned by the path formalization task. The general `c` formula above is not yet a Lean theorem.

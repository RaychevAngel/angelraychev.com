# Resumed even-box investigation: complete 4×4×4 calculation

12 September 2026. Ordinary finite computer-assisted result; no new Lean
classification or literature-priority claim is made here.

## Exact result

The previously proved square-pair compression leaves292 supports in each
checkerboard parity, hence85,264 joint states. Exhaustive shortest-path
search and direct physical witness replay give:

| Daily budget m | Exact minimum days |
|---|---:|
|0–7|impossible|
|8|40|
|9|20|
|10|16|
|11|12|
|12|10|
|13–14|8|
|15|7|
|16–17|6|
|18|5|
|19–25|4|
|26–31|3|
|32–63|2|
|64 and above|1|

The native implementation enumerates every ideal residual obtained with
exactly the allocated useful quota. Equal successors for a fixed source
and quota are merged; no dominance or heuristic pruning is used. Full
useful quotas suffice until the final day by inclusion monotonicity and
the ability to remove maximal elements from an ideal. Earliest state visits
suffice because the current-physical-parity state is Markovian. Terminal
states of size at most m take one final inspection.

Source: `src/even_resume_cube_solver.cpp`, preparation and physical replay
in `src/even_resume_cube.py`; complete receipt and room schedules in
`even-resume-four-cube-exact.json`. All budgets7–32 together took about
0.4 seconds in the compiled search. The general endpoint ranges follow
without search: the board's perfect matching makes two days impossible
below32 probes, two full parity sweeps work at32 or more, and one day
requires all64 initial rooms.

## A compact independent lower certificate at eight probes

For every canonical one-parity support A, assign the stored nonnegative
integer potential F(A). Its charge for deleting p<=8 rooms is

    c(p)=(0,0,0,0,1,2,2,2,2)[p].

The source `src/even_resume_four_cube_certificate.py` verifies all29,686
legal one-cohort deletion/move inequalities

    F(A)<=c(p)+F(N(R)),    R subset A, |A|-|R|=p<=8.

The empty potential is zero; each full parity has potential40. Two quota
shares whose sum is at most eight have total charge at most two. Thus
every successful full search takes at least(40+40)/2=40 days. The stored
potential was found by shortest charged paths, but its validity is checked
directly and does not require trusting that optimization routine.

The matching upper needs only a fixed weightlex prefix sweep. Each cohort
starts in its favorable phase, using a reflection in one even-length axis
for the second cohort. Both follow this compact cardinality trajectory:

    32,29,27,25,24,23,22,22,21,21,19,19,18,18,17,16,15,13,11,8,0.

There are20 moves per cohort. The actual room schedule is stored and
independently replayed in `even-resume-four-cube-critical-certificate.json`.
This charged certificate proves the critical lower bound without relying
on the joint breadth-first search, while retaining the ordinary geometric
compression theorem as its foundation.

## What the counts alone miss

The exact one-parity minimum-neighborhood profile is the same in both
colors:

    0,3,6,7,9,11,12,13,15,16,17,18,19,19,21,22,23,
    24,25,25,26,27,28,28,29,29,30,31,31,31,32,32,32.

Its maximum surplus is seven. In particular any same-parity support of
size at least21 retains that size after at most seven deletions and one
move: at least14 survivors have at least21 neighbors. This supplies a
simple impossibility trap below the feasible budget eight.

At budget eight, however, the two-cardinality relaxation clears in32 days,
whereas the actual optimum is40. The state count cannot be reduced to
cardinalities alone while preserving optimal time. For every budget at
least nine, that same cardinality lower bound matches the actual optimum.
The obstruction is therefore concentrated at the minimum feasible budget.

The charged potential is cardinality-dependent except at a small set of
sizes. Its scaled values can differ by two between canonical supports
of sizes18,19,20,21,22,23,24,27. Cardinality and the size of the immediate
neighborhood together still do not determine that potential. This supports
the user's suggestion that a small amount of shape or history information
can be essential even after an exact isoperimetric profile is known.

## Open next questions

The finite potential table could potentially be replaced by a short
geometric flag or local obstruction. No such formula has been proved yet.
The result also does not refute sufficiency of a family of reflected and
permuted weightlex prefixes from the full board: the critical40-day upper
already belongs to that family. What fails is the stronger cardinal-only
description, which freely changes among incompatible minimum-neighborhood
shapes.

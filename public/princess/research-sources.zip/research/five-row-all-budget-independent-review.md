# Independent review of the even five-row all-budget theorem

12 September 2026 UTC. Independent proof/formalization-agent review.

**Verdict: passed.** Sections1–8 of `five-row-all-budgets.md` supply the
complete ordinary classification for every even n>=6 and every daily budget.
The old unresolved labels in the discovery sections should be replaced or
explicitly marked historical before publication. No complete physical Lean
formalization of this theorem is claimed: the geometric certificate and its
interpretation remain ordinary mathematics, with selected scalar parts checked
in Lean.

## 1. Arbitrary-support geometry and history

The earlier independently reviewed symbolic automaton gives the universal
surplus-one size list, the bulk surplus-two row-prefix theorem, and the
empty-row size bound. The new deficit identities correctly require all five
rows to be nonempty. For a bulk source of size at least six that condition
follows from the empty-row theorem. Source sizes three through five are
handled by the explicit finite row-vector list instead; every such source's
neighborhood has row lengths at most two and cannot reach the opposite end
when the matched length is at least three.

For an opposite-orientation bulk successor, each occupied right-prefix row
requires a full row in the predecessor's left-prefix neighborhood. One
neighborhood row is not full, so the successor has an empty row and size at
most five. The listed size-three diagrams force a full endpoint row;
size-four diagrams force three full consecutive end rows or the stronger
alternating condition; size-five diagrams force the alternating condition.
The three deficit inequalities then leave exactly the possible size pairs

    (h-6,3), (h-5,3), (h-5,4).

Likewise an opposite outward singleton requires a full endpoint row and
therefore predecessor size at least h-6. These are necessary conditions;
using them as permitted transitions is safely a relaxation.

The historical bit records actual preceding surplus two and preceding size
in [3,h-5]. Thus a marked current support has size b in [5,h-3] and its
preceding survivor size is b-2. The transition relation applies the pair
restriction to exactly (b-2,b-p), and the singleton condition becomes
b>=h-4. The relation includes *every* output size for surplus at least
three, avoiding the earlier invalid assumption that minimum size dominates
all histories. Useful probes from the two initial cohorts are disjoint and
their sum is bounded by the daily budget. This establishes the intended
arbitrary-support lower-bound semantics.

## 2. The discounted potential for 5<=m<=h-8

Let D=2m-5. For u>=7, write u=6+jD+s with 1<=s<=D. At j>=1 the potential is

    F_m(u)=jm+floor((s+6)/2)-1_[s in {1,2,4}].

This row gives monotonicity, the at-most-three increase over two rank units,
and F_m(u)=floor(u/2) when floor(u/2)<=m, including the first quotient wrap.

For the affine transition v=u-2p+5, p<=m, the only nontrivial case has p>=3.
Then u-v<=D, so the quotient falls by zero or one. With no fall the
undiscounted inequality has slack two or three. With a one-quotient fall
it is an equality; a discounted target has positive remainder
s(v)=s(u)+2(m-p) in {1,2,4}, which forces a discounted source. This proves
the inequality without a finite bound on the quotient or the budget.

For physical transitions, an unmarked bulk surplus-two move changes the
rank exactly by -2p+5. A marked bulk surplus-two move requires at least
h-7 probes by the three compatible pairs, and is excluded here. A
surplus-at-least-three move has output rank at least the affine target.
The singleton surplus-one move cannot be marked in this budget range.
The listed four small-source values at m+1 and m+2 check directly.

For the near-full cases, the only decreasing proper unmarked transition
not already handled is (h-1)->(h-2) with three probes, paid by the two-rank
increment bound. Full-state improvements to h-1 with two probes and h-2
with four probes are exactly the two additional cap terms. Other such
moves are monotone or use no fewer probes. Common clipping preserves each
potential inequality, including capture and the empty target.

## 3. Independent evaluation of the endpoint cap

Write 2h-6=qD+r as in the formula. Direct substitution first gives

    F_m(2h)=qm+J(r).

The other cap terms shift the remainder by two and four. For m>=6 their
minimum is smaller only at r=2: the two-probe term then replaces J(2)=3
by two. At the smallest budget m=5, the extra possible savings occur at
residues one and three; physical h divisible by five always has r=4.
Thus throughout the stated physical range,

    C=qm+J(r)-1_[r=2].

For r>0, J(r) lies between two and m, so rounding 2C/m gives either
2q+1 or 2q+2. At r=2 the discount changes neither rounded answer nor the
sharing criterion because m>=6. At r=0 it gives 2q exactly. This confirms
the claimed formula, not merely the numerical lower recurrence.

## 4. Uniform upper strategy

The diagonal-prefix neighborhood identities give actual physical moves;
independent long-axis reflections allow each initial cohort its selected
phase. In the bulk a full allocation decreases rank u=2b+phase by D.
Before the q-th full allocation the last survivor size is r/2 in phase one
when r is even, and (r+1)/2 in phase zero when r is odd. The special small
surpluses give precisely J(r), including r=0,1,2,4. Every earlier survivor
lies in the bulk, so this is an all-parameter calculation.

A proper prefix of rank at most qD+6 clears within q full allocations.
For the shared round, the best partial initial rank drops are zero at p=0,1;
one at p=2; two at p=3; four at p=4; and 2p-5 in the relevant larger range.
At p=J(r) these drops are at least r, so the remaining q full allocations
clear the fresh second cohort. Sharing is therefore possible exactly as
needed for the upper bound when 2J(r)<=m.

The original statement of the larger-p initial drop omitted its upper
range: near p=h-2,h-1 the small-survivor cases can improve it. The author
restricted it to 5<=p<h/2. The shared construction actually uses
p<=m/2<h/2, so the correction changes no strategy or result.

For four probes the separate phase-zero pair decreases b by three;
the three explicit terminal tails give ceil((2h-8)/3) rounds per cohort.
This independently confirms the unbounded upper formula.

## 5. High budgets and feasibility endpoints

For h>=25 and h-7<=m<h the seven remainder evaluations give three rounds.
Two are impossible: the perfect matching leaves at least 2h-m>m positions
after the first inspection and movement. For h=15,20 the three finite
cardinality checks use a genuinely monotone lower neighborhood profile;
coordinatewise dominance and sorting are valid. Their budget-monotone
consequences cover exactly the remaining listed high-budget cases.

For completeness, impossibility below three probes also follows directly
from this profile: a cohort of size at least five remains of size at least
five after at most two probes and one move. The near-full profile exceptions
still exceed five. Full initial cohorts lie in this trap. Budgets at least
h give the two full-cohort sweeps, and one day is possible exactly when the
budget covers all 2h initial positions.

## 6. Four probes: universal inequality and the missing day

The periodic core H(b,z) has exactly the three residue expressions encoded
in `FiveRowFourProbeArithmetic.lean`. Its endpoint minima evaluate to the
stated A1 and C4 table. The formal Transition is a valid simplification
of the physical history relation for p<=4 and h>=15: marked singleton
surplus one and the three marked bulk compatibility exceptions would all
require more than four probes. The formal relation retains every larger
surplus-at-least-three output. The endpoint substitutions and the theorem
`potential_step` therefore have the intended ordinary physical interpretation.

If h=3t, then L=2t-2 and C4=8t-10=4L-2. At a full state, p=0 is tight,
and the only positive tight allocation is p=2, yielding size h-1 with
potential 8t-12. In particular p=4 only decreases potential by at most
three. At size h-1, allocations 0,1,2,3 have respective maximum decreases
-2,0,0,1; only p=4 can decrease by four. The two frozen equality lemmas
state these same facts for all allowed targets, not just minimum-size ones.

A hypothetical 2L-1-round search has total initial potential 8L-4, exactly
its total four-probe capacity. All individual transition inequalities and
all daily budget inequalities must be equalities. The first round is forced
to split 2+2. The second would require four probes for each of the two
penultimate states, which is impossible. This proves the missing day.
For the other h residues, C4=4L and the ordinary ammunition bound already
gives 2L. No finite upper bound on h is used.

## 7. Supplementary independent evidence and proof boundary

The independent script `src/five_row_all_budget_independent_review.py`
uses actual coordinate neighborhoods. It checked all 65,536 single-parity
supports on the 6×5 board, 12,600 low-boundary compatibility comparisons,
the exact small row-vector list, and the outward-corner restriction. It
also checked 24,059 physical parameter pairs for the cap evaluation and
rounded formula. All passed; the receipt is
`five-row-all-budget-independent-review.json`.

The unbounded claims follow from the ordinary arguments above and the
universal symbolic geometry. These supplementary finite tests are not their
substitute. The Lean files verify the deficit consequences, the four-probe
scalar inequality and equality rigidity, and the three high-budget scalar
checks. They do not yet supply a complete Lean proof of the physical
all-budget five-row classification, and the general discounted potential
argument is ordinary mathematics.

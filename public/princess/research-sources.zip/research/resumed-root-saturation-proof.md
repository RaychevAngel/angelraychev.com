# All-feasible-budget explicit upper bounds on even-area rectangles

13 September 2026. Ordinary proof; the root-selection lemma has received an
independent mathematical review and the construction has been independently
replayed on 2,915 finite boards/budgets. The full theorem is not in Lean.
This is an upper bound below the existing equality thresholds.

## The root-selection lemma

Let Q be a connected bipartite graph, with at least two vertices, and consider
Q times the path with coordinates 0,...,n-1, n>=1. In physical color p, let R
be a downward pyramid: an ideal for the predecessors (v,y) -> (u,y-1) with
uv an edge and y>0. Let Z_p={(v,0):chi(v)=p} be the bottom roots. If

    |R union Z_p| <= M <= |V_p|,

there is a downward pyramid A containing R union Z_p with |A|=M. Its clipped
erosion E in the other color is a downward pyramid with

    |E|=M-|Z_p|,        N(E) subset A.

In particular the premise holds for M=|R|+k whenever k>=|Z_p| and M fits.

**Proof.** Every member of Z_p has no predecessor, so R union Z_p is an
ideal. A finite ideal can be enlarged to any prescribed cardinality up to
the full poset: repeatedly add a minimal element of its complement. To make
the rule deterministic, fix any linear extension once and always select its
first missing element. This requires no optimization over future strategies.

For fiber phase s_v=(p-chi(v)) mod2, let a_v be A's virtual top height, using
-2 or -1 for an empty fiber. Put

    e_v=max(a_v-1, (1-s_v)-2).

These cutoffs define a physical opposite-color pyramid E; this is the
existing clipped-erosion construction. Its exact loss is the number of
occupied s_v=0 fibers. All such fibers are occupied because Z_p subset A.
The loss is therefore |Z_p|. Every physical neighbor of a room of E lies in
A, including at the finite top and bottom boundaries, by the existing
clipped-erosion proof. This proves all assertions. The lemma does not use
a graph-distance or quadratic envelope-size threshold. QED.

## Even width

Let w=2r>=2, n>=w, h=rn, and r+1<=k<h. Write

    h-r=q(k-r)+s,   0<=s<k-r.

Set J(0)=0 and J(s)=s+min(ceil(sqrt(s)),r) for s>0. Then

    T_k(w,n) <= 2q                          if s=0;
    T_k(w,n) <= 2q+1                        if s>0 and 2J(s)<=k;
    T_k(w,n) <= 2q+2                        otherwise.

The right side is a fixed-size standard numerical expression. The associated
inspections are prescribed by the following construction, without a search
over schedules. Equality still requires a separate lower bound.

**Proof.** Choose a phase-zero terminal pyramid R of size s with at most J(s)
neighbors. Such a set is provided by the existing small-corner/plateau
construction; a weightlex prefix ordered by (x+y,-x) is one deterministic
choice. If s=0 use the empty set. In the small-corner case the source fits
coordinates through 2ceil(sqrt(s))-2 and its neighborhood fits one more;
otherwise the pyramid plateau bound suffices. Reflection in the even short
side supplies either physical color if needed.

Enlarge R by k to a pyramid containing all phase roots, using the lemma,
then replace it by its clipped erosion. This increases its cardinality by
k-r and changes phase. Repeat q-1 times. Each enlarged cardinality fits h:
the largest is s+(q-2)(k-r)+k=h-(k-r), when q>=2. Every root set has r
vertices and k>=r+1, so all root selections are permitted. The resulting
first survivor has size s+(q-1)(k-r)=h-k. Its enlargement by k is the full
phase class.

Read backwards to obtain q legal inspection days. At each step the actual
belief lies in its designated envelope A, so inspecting A minus the desired
survivor uses exactly k rooms and preserves the next inclusion. After the
qth move the belief is contained in X=N(R), of size at most J(s)<k when s>0.
If s=0 this is a q-day solo capture. Otherwise one further day clears it.

Joining the preparation to a reflected reversed preparation gives a common
central day: the two possible-position envelopes there have opposite colors
and total size at most 2J(s). When this fits k, inspect their union. Otherwise
concatenate two solo searches. Time reversal of avoiding walks verifies the
second half even though the envelopes need only contain actual beliefs.
These give the stated three bounds. QED.

## Odd width and even length

Let w=2r+1>=3, n>=w even, h=wn/2, and r+1<=k<h. Set

    D=2k-w,       wn-w-1=qD+s,       0<=s<D.

For positive x put

    L_0(x)=x+min(ceil(sqrt(x)),r),
    L_1(x)=x+min(ceil((1+sqrt(1+4x))/2),r+1),

and L_0(0)=L_1(0)=0. Define J(0)=0, and

    J(s)=L_1(s/2) for positive even s,
    J(s)=L_0((s+1)/2) for odd s.

Exactly the same three-case right side above, using these q,s,J, is an upper
bound on T_k(w,n) for every feasible k. It is the existing high-budget upper
expression with its budget restriction removed.

**Proof.** Choose the existing corner terminal pyramid with (|R|,p)=(s/2,1)
for even s, or ((s+1)/2,0) for odd s. For s=0 take the empty phase-one set.
It has rank 2|R|+p=s+1 and at most J(s)<=k neighbors. Under a root-selected
backward enlargement by k and erosion, the phase-p root count is r+1-p.
The new rank is

    2(|R|+k-(r+1-p))+(1-p)=(2|R|+p)+D.

Every step is admitted since k>=r+1 bounds both root counts. After q-1 steps
the rank is s+1+(q-1)D=2h-2k. This is even, so the first survivor is in phase
zero with size h-k. Ranks increase by positive D, ensuring each requested
enlargement fits h. One final enlargement is the full phase class. The same
forward inspection and reversed-half proof applies, now using reflection in
the even longitudinal side to exchange colors. QED.

## Comparison, evidence, and remaining gap

The universal bound 2ceil(w(n+2)/(2k-w)) is strictly improved in many regimes.
The new even-width bound is at most 2ceil((h-r)/(k-r)); the odd-width bound is
at most 2ceil((wn-w-1)/(2k-w)). Their drifts agree with the known optimal
leading term, and they retain a directly constructed central-day saving.

Examples in the residual domain: the bounds are 30 on 6x6,k=4; 15 on 6x6,k=5;
56 on 8x8,k=5; and 96 on 7x8,k=4. These are not asserted optimal. The recorded
8x8,k=5 exact computation gives 40 and demonstrates substantial remaining
corner savings. Deliberately occupying all roots makes the proof uniform,
but can waste boundary opportunities when the budget is small.

`src/resumed_root_saturated_upper.py` constructs actual cell sets, verifies
ideal membership and exact erosion counts, and replays every inspection
against the full physical belief. Its 2,915 cases cover every feasible
non-endpoint budget for widths 2 through 16 and lengths w through w+4 of
even area. Receipt: `research/resumed-root-saturated-upper.json`. The tests
support implementation correctness; the unbounded proof is the argument
above. One initially erroneous integer implementation of the pronic root
was caught by the physical replay and corrected before the passing receipt.

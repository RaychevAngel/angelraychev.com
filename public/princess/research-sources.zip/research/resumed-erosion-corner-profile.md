# Retaining eroded corners in the necessary rectangle model

13 September 2026. Root derivation, independently checked in the odd-width
lane; a second algebraic review is in progress. This is a
uniform necessary transition rule, not a sufficiency or capture-time
classification. It is intended to replace isolated history exceptions by
geometric information that can be propagated at every step.

Let a nondegenerate even-area rectangle have both sides at least four.
Write h for the size of a color class and b=floor(w/2). For a one-color
set A define c(A) as the number of its own-colored board corners in A,
and e(A) as the number of opposite-colored corners whose TWO neighbors
both belong to A. Equivalently e(A) counts board corners in E(A), where
E denotes graph erosion into the opposite color.

The inspected state is (|A|,c(A),e(A)). The two relevant neighbor pairs
are disjoint, and are also disjoint from the two own-colored corners,
under the stated side assumption. Consequently

    c+2e <= |A| <= h-4+c+e.

If p rooms are removed, leaving S with size q and features (i,u), then

    i<=c,   u<=e,   (c-i)+(e-u)<=p.

The last bound is stronger than separately charging at most p losses of
each kind: destroying an eroded corner and removing a current corner
require different inspected rooms. It is a lower bound only; no
attainability of every feature change is assumed.

Put B=N(S), t=|B|, j=c(B), v=e(B), and s=t-q. Necessarily u<=j and
i<=v. Indeed two surviving neighbors imply the corresponding outgoing
corner is reached, and a surviving current corner ensures both its
neighbors are in B.

## The low-side capacity

Use H from `resumed-odd-even-one-neighbor-capacity.md`: H(0)=0, and
H(s)=max(s(s-1)/2,s(s-3)+1) for s>=1. Root independently checked the
layer proof, preservation of the forbidden origin neighbor, the equality
constructions, and the zero endpoint of that lemma.

When the matching separator proof places S in four genuine corner
quadrants, the i required even-origin pieces consume surplus one and
area one each. Of the j touched odd origins, u have both origin
neighbors and j-u have exactly one. They each consume surplus two,
with initial areas two and one respectively. Thus put

    z=s-i-2j.

For z<0 the capacity is minus infinity. Otherwise the necessary maximum
is the following fixed-size expression P(i,u,j;s):

    i+j+u+z^2+3z                    if u>0;
    i+j+z^2+2z                      if u=0<i;
    j-1+H(z+2)                      if i=u=0<j;
    C_2(s)                          if i=j=u=0.

Here 0<=u<=j<=2 and 0<=i<=2. No array or variable-length sum is used.

Proof: all quadrant capacities are discretely convex and nondecreasing
above their mandatory surplus. Concentrate the excess z in one piece.
A required two-neighbor odd piece gains z^2+3z. A required even piece
gains z^2+2z. A required one-neighbor odd piece gains

    H(z+2)-1 = max(z(z+3)/2, z^2+z-2).

This gain is at most z^2+2z and at least C_2(z). An optional piece gains
at most C_2(z), with the omitted odd-neighbor pair bounded by C_3(z).
The displayed priority of receiving pieces therefore maximizes the sum,
giving P. In particular P<=F from the earlier corner-count theorem.

## The high-side capacity with an observed target erosion

Let U=V_opposite\B be the holes after movement. Its own corner count
is 2-j. Unlike the old dual bound, its neighborhood corner count is now
KNOWN rather than maximized away:

    c(N(U))=2-v.

This follows directly from E(B)=V_current\N(U). Write sigma for the
surplus of U. The slack (V_current\S)\N(U) has size s-sigma and
contains exactly v-i missing current corners. Therefore

    sigma <= s+i-v.

When U is the side avoiding the common matching component, the old
four-quadrant F bound (no new erosion information on U is required) gives

    h-q-s <= F_(2-j,2-v)(s+i-v).

Thus, at subcritical surplus 0<=s<b, every physical transition obeys

    q <= P(i,u,j;s)
    OR h-q-s <= F_(2-j,2-v)(s+i-v).             (* )

The proof uses the same common matching component and physical separators
as the already reviewed corner theorem. This strengthening keeps the
previously maximized dual index as part of the observed next state.
The unconditional size profile remains in force at every surplus.

## Critical odd widths

For w=2b+1 and even n>=w, the strengthened dichotomy (*) also holds at
surplus s=b, except for (i,j)=(2,0), which then has u=0 and v=2.
This is not a mechanical substitution in the earlier theorem. Its
alternating-column proof has only five cases. If i=j=0, then u=0 and
P=F00. If i=1,j=0, again u=0 and P=F10. If i=2,j=1 or2, then v=2,
and the fixed dual F_(2-j,0)(b) is exactly the old G_(2,j)(b); thus
the previous deficiency bound still applies. The remaining case is
the stated exception. The odd-width agent independently checked these
absorptions and the separator/complement proof at equality.

## Corner closure strengthens the same inequality

Adjoin to S every one of its own-colored board corners lying in E(B).
There are v-i such new rooms. Their neighborhoods were already contained
in B, so B does not change. Because the corner rooms are disjoint from
the opposite-corner neighbor pairs, u is unchanged. The new size is
q+v-i, its current corner count is v, and its surplus is s-v+i>=0.
Apply (*) to this augmented support whenever that surplus is in the
proved range, with the same critical exception if needed. The low branch
becomes

    q+v-i <= P(v,u,j;s-v+i),

and the high branch remains F_(2-j,2-v)(s+i-v). This is a static geometric
closure argument; the added corner rooms need not lie in the preceding
belief A, since they are used only to prove a necessary bound.
The construction agent in the odd-width lane proposed this strengthening;
root independently checked its neighborhood and disjointness claims.

## Retaining all admissible survivor rooms

For an actual inspection transition A -> B, replacing the survivor by
A intersect E(B) preserves its neighborhood B and uses no more
inspections. Indeed the original survivor is contained in this set,
whose neighborhood is contained in B. Therefore every physical belief
trajectory has a realization using these maximal survivors. In such a
realization the surviving current corners are exactly the intersection
of the c corners of A and the v corners in E(B), so

    max(0,c+v-2) <= i <= min(c,v).

This is a harmless retention normalization preserving every next belief,
not a compression into a proposed geometric family. The useful budget
can decrease, so the model must continue to allow all costs p<=k.
The other survivor features are those of the enlarged actual survivor;
they must be enumerated consistently rather than copied from the old one.

## A single pronic rigidity lemma and its dual use

At q=b(b-1), s=b, i=0 on the odd-width/even-length board, the uniform
rigidity lemma forces a full odd triangle at one opposite-colored corner.
Its next belief has size b^2 and corner count one. On the following move
its original-colored corner count is zero, whatever inspections occur.
This is the established uniform one-step memory rule.

The same lemma has a direct dual consequence requiring no new variable.
If q=h-b^2, s=b, and j=2, then necessarily

    i=1,   u=2,   v=1.

For U=V_opposite\B, one has |U|=b(b-1), c(U)=0, and surplus at most b.
The unconditional size profile forces surplus at least b, hence exactly
b. Equality of cardinalities gives N(U)=V_current\S. Rigidity makes U
the full odd triangle, so N(U) contains exactly one current-colored
corner and N^2(U) misses both opposite-colored corners. Consequently
S contains one current corner and both neighbor pairs of the opposite
corners: i=1,u=2. Also E(B)=V_current\N(U)=S, giving v=i=1.
The odd-width agent derived this rule and root independently checked the
complement, size-profile endpoint, and the two erosion identities.

Concentration of the original corner model does not automatically extend
to these enriched features. Until a new merger is proved, a direct joint
lower computation is the justified method for the enriched model.

## Intended test and unresolved work

The enriched model with closure, maximal retention, and the direct and
dual pronic consequences recovers 68 at 7x8,k=4 without the special
initial four-day history flag. Its independent integer-potential audit
is being prepared by the odd-width agent. This is genuine consolidation:
one uniform rigidity lemma replaces the numerical history exceptions.
It does not prove uniform physical attainment or an absolute O(1)
expression for T_k(a,b). The next issues are merger for this enriched
model and whether its bounds agree with physical constructions uniformly.

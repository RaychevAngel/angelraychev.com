# Checkpoint source review: corner geometry and finite applications

Date: 2026-09-13. Reviewer: split_manuscripts, independently of the root's geometry and artifact agent's localization/model development.

## Result

The reviewed manuscript statements agree with the proved ordinary geometry and the declared necessary-model interface. No new mathematical search or new Lean verification was performed in this checkpoint review. The six finite equalities in the new certificate subsection have both a physical upper witness and a finite necessary-model lower calculation; 24 x 24 remains separately bounded until a further full-board transfer is verified.

## Specific checks

- The erosion geometry has a subcritical theorem on all even-area rectangles and a refined critical theorem only for odd width and even length. The enriched merger is correspondingly scoped; it is not substituted for the all-even-area base merger.
- Corner closure is applied by reduced surplus sigma, including transitions with original surplus above b. The zero-reduced-surplus identity used in the critical branch concerns the full closed support and full target, and does not falsely assert a full original source.
- In contrast, pronic and band trigger formation has bounded original total surplus. Its zero-original-surplus component has a full survivor, full original source and full target at cost zero. Identity therefore passes all chosen-survivor features and the trigger itself.
- The positive cardinality lower bounds c+2e <= a and i+2u <= q are explicitly discarded only in the enriched merger relaxation. Upper bounds, nonnegative sizes, exact empty endpoints, coupled removal charge, maximal retention, and all smaller budgets remain. The eleven-row finite certificates use this same weakening, rather than silently applying a theorem to the stronger physical-feature graph.
- The primal pronic theorem retains the even-width critical boundary correction kappa = 1 or 2. The enriched odd-width corollary correctly uses kappa = 0. The general physical theorem is not narrowed to the odd-board case.
- Corollary cor:dual-near-pronic applies to target corner count 2 and a strict lower hole-band endpoint D < h-t <= C, with original surplus <= b. Zero complement slack gives original surplus b, source corners 1, eroded source corners 2 and eroded target corners 1. The support radius prevents the second neighborhood from reaching either required opposite corner on odd-width/even-length boards.
- The band merger uses target J=2 to force both component outgoing counts 2; this excludes critical exception (2,0). A low component would have too many holes. Two positive original surpluses cannot supply holes above D. The resulting original full-to-full identity passes the entire static triple (1,2,1). No new band-memory bit is assumed.
- The 7 x 8 and 9 x 10 lower claims cite direct independently audited joint potentials, so they do not depend on a merger theorem. The eleven-row calculations explicitly have penultimate residual 4 and budget 6, giving the even lower bound 2*tau rather than only 2*tau-1.
- All theorem references and all 18 code/receipt paths in the finite-application subsection were checked to exist at this review. PDF layout and final compilation remain the parent's publication checks.

## Preserved limitations

These lower relaxations are not asserted to characterize attainable physical strategies. Separate upper witnesses establish the six individual equalities. The applications do not establish a parameter-uniform fixed-size numerical expression, and no new result here is claimed Lean-formalized. The early proof-pending wording remains in frozen receipts as historical provenance; the manuscript identifies the now-proved geometric premises.

## Reviewed source hashes

- `paper/sections/resumed-erosion-corner-profile.tex`: `96df4850055ab2ea8b904d95bfa14c5c2c4008f7fb2c8c262c1e786b883dd814`
- `paper/sections/resumed-even-pronic-rigidity.tex`: `4c94d73c022ebd2d77ee746a0e95ae47e3129262385912253f92d061b03a2cc0`
- `paper/sections/resumed-near-pronic-history.tex`: `5fa666b3d6efa9d0f3d5e70e313f492f4f5b19b8589575ad8bf143817d83eb96`
- `paper/sections/resumed-erosion-corner-merge.tex`: `e0e868c5448625da6b03de96c15fa9e24505b1a626442730334faf1bb11b38c3`
- `paper/sections/resumed-even-area-certificates.tex`: `80be3a8179f8076effacb7dfac7c7e618a4f47cc602fd12d7f1b7b3fba1dea96`
- `research/resumed-erosion-merger-band-dual-solo-check.json`: `27110539d594d7abf3187d68e97d21fdfd1deac82805047cca5d4ee6cb206240`
- `research/resumed-odd-even-erosion-corners-full-closure-audited.json`: `105a007c48628d9c6ba65223996a712046d1690764ecc41d3aa772b88ccd7f83`
- `research/resumed-odd-even-minimum-upper.json`: `a966e307d59a8885fca34981f0579eccf78ddfda8abfefba0b959fcc84f22554`

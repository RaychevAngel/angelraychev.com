# Independent audit of the even-short-side high-budget upper

12 September 2026. **PASS** for the complete physical construction in
`uniform-even-rectangle-high-budget-upper.md`. The matching lower proof
is `uniform-even-rectangle-high-budget-lower.md`; this audit does not
substitute an abstract profile trajectory for a physical strategy.

The empty-fiber estimate is valid for either parity: from a_x≤a_i+|x−i|
and an empty fiber i, each k_x≤ceil(|x−i|/2). Convexity of the partial
sums of ceil(j/2) bounds the total by b². Consequently every pyramid of
more than b² vertices can have every cutoff lowered by one. Its per-row
cardinality loss is 1−s_x, giving exactly b in total. The new opposite-
color set remains inside the board, remains pyramidal, and its neighbors
lie in the original pyramid, including both end collars.

Every pyramid is an ideal of the predecessor poset and can be extended
to any intermediate cardinality. The favorable small-corner prefix is
also a pyramid when its final diagonal is ordered toward y=0; reflection
of the even short axis preserves this direction and swaps colors. Hence
the final r-set with at most J(r) neighbors is available in either color.

Backward enlargements have size at most h, and each erosion adds exactly
m−b vertices to the previous survivor. After q−1 such steps the last
backward enlargement is exactly the full class. Reading the envelope
containments forward gives q legitimate inspections of at most m rooms,
with the final next belief contained in the selected J(r)-room envelope.
All inclusions have the correct direction even if the actual belief is
strictly smaller than the envelope.

At a central inspection, the two half-strategies' last neighborhood
envelopes are selected in opposite current colors, so their union costs
at most 2J(r). Reversing the second half is a genuine avoiding-walk
argument. If the union does not fit, either color has a (q+1)-day solo
capture by short-axis reflection; these may be concatenated. For r=0
both q-day captures suffice. No dynamic isoperimetric nesting is assumed.

The independent script `src/uniform_even_high_budget_audit.py` reconstructs
all sets from physical coordinate differences, extends pyramid ideals,
performs each erosion, constructs the joined schedules, and replays them
from the full board. All 635 parameter cases with b=1,…,6 and
2b≤n≤2b+4, b²+1≤m<bn pass, with first capture at the stated day.
The run used 0.072 CPU seconds; receipt:
`uniform-even-high-budget-independent-check.json`.

# Independent review: eventual affine time at every odd width

12 September 2026. The minimum-budget proof in
`odd-minimum-budget-eventual-affinity.md` passes independent mathematical
review. In particular, its explicit threshold proves, for every fixed odd
width `w≥3`,

    T_((w+1)/2)(w,n+2)=T_((w+1)/2)(w,n)+4w

at all sufficiently large odd lengths, with the threshold stated in that
note. The argument is an ordinary uniform proof, not extrapolation from the
seven earlier finite-width certificates. It does not claim that the affine
law starts at the square or that optimal strategies are always serial.

## Bad-day and focused-block counts

The integer potential loses at most one per day. Its initial value is 2C and
its terminal value zero, so the total nonnegative integer slack is T−2C.
The uniform upper bound makes this at most `B=8b²+6`, independently of length.
Every inefficient day contributes at least one, giving at most B such days.

On an efficient day all m inspections must go to one cohort. The active
potential loses exactly one, and the inactive potential stays exactly
constant. An inactive potential strictly between zero and C increases after
zero inspections: nonfull majority prefixes have neighborhood size at least
their size, and nonempty minority prefixes gain at least one vertex. The
parity change gives a strict increase in the affine expression in either
case, and clipping cannot remove it when the old potential is interior.

Therefore, after the active potential drops below C, it cannot become
inactive in the same efficient run until it reaches zero. It then cannot
become active again, since an efficient active day would have to lower it
below zero. This proves at most two focused blocks per efficient run, and
at most `2(B+1)` blocks overall. The proof also excludes an unobserved jump
of the inactive potential from zero to C: exact constancy is required every
efficient day.

## The flat-potential issue is explicitly resolved

Being at potential zero or C does not by itself make a cohort empty or full.
This is the main issue the proof needed to resolve before any surgery.

For a nonempty proper subset of one color in a connected bipartite graph,
`N²(S)` contains S strictly. Backtracking proves containment. Equality would
make S closed under all two-edge walks, and the same-color two-step graph is
connected. Thus zero inspections increase a proper same-parity set after
every pair of rounds.

The zero-potential collar has at most `L−1=b²+b+1` vertices in either color.
A positive inactive set cannot stay in that collar for more than 2L rounds.
The upper flat collar starts at count `H−b²−2`, at deficit at most
`b²+2≤L` from full; after at most 2L inactive rounds it is full. Once empty
or full, it remains so under zero inspections, up to the alternating full
parity label.

Thus each focused efficient block has at most 2L nonclean days. Combining
with the at most B inefficient days gives exactly the asserted
`E=B+4L(B+1)` bound. This handles both collar transients, not only the upper
one.

## Counting and protecting a common band

Each nonclean day records two source counts. A source count forbids exactly
`w+2D+1` possible integer cuts through the enlarged interval
`[c−D,c+w+D]`. The allowed cut interval has

    H−w−2A−4D−1

integer elements. At the stated threshold this is at least
`2E(w+2D+1)+1`, strictly exceeding the total possible forbidden cuts.

The source-only recording is sufficient. A transition changes either count
by at most D, including the empty-survivor and full-class endpoint cases.
A nonclean source outside the expanded interval cannot enter, leave or jump
across `[c,c+w]` in one round. Every transition involving a count in that band
is therefore clean.

On a clean day an inactive count is zero or full, so it is outside the band.
An active count receives the full budget and never increases. In the band
its profiles are on the central plateaus, so it decreases by one on a
majority round and stays constant on a minority round. Starting full and
ending empty, each cohort must cross the band exactly once and cannot return
upwards. It visits every integer level, including both endpoints.

Starting at level c+w in either current parity, exactly 2w full-budget rounds
end at level c in the same parity. If level c is first reached one round
earlier, the last minority round stays at c and is still protected/clean.
The inactive companion stays empty or full throughout. The two crossings
cannot overlap, since a crossing requires its companion outside the band.

## Contracting and expanding actual prefix trajectories

After deleting both crossings, every retained count is either at most c or
at least c+w. Lower counts remain unchanged and upper counts lose w. At the
two ends of a deleted block the active counts both map to c; the companion's
empty/full states also agree after the full class size loses w. The even
block duration preserves both current-parity labels.

The profile identities on retained edges are exact:

- For a source at most c, its survivor count is also at most c. The far
  corner is inactive in both the original and smaller boxes by the stated
  right margin, so the profile values agree.
- For a source at least c+w, its smaller-board survivor is at least c−m,
  which is past both low-corner caps by the left margin. Subtracting w from
  the source, survivor and target preserves the far-corner arguments and
  yields the smaller-board profile exactly.

The successor cannot lie in the deleted interior on a retained edge, by the
crossing analysis. The source c+w at the start and c at the end of a removed
block are glued states, not an unverified retained transition across the
whole band. Quotas and their shared budget remain unchanged; final padding
is harmless under truncated subtraction.

This produces a physical prefix strategy on length n−2 with 4w fewer days.
For expansion, replace each clean 2w-round traversal with the explicit
4w-round traversal of the doubled band. The same margins cover its entire
plateau, the companion is empty/full, and the extra duration is even. All
other low and translated-high transitions obey the same profile identities.
This gives 4w additional days on length n+2. Applying contraction to that
larger box supplies the reverse inequality and proves equality.

## Threshold, computation and scope

The threshold also makes C positive and leaves the contracted rectangle at
length at least w; these are not additional unstated size restrictions. Since
`E=O(w⁴)` and the protected-band width is O(w), its majority-size threshold is
`H*=O(w⁵)`. The first allowed odd length has O(w⁵) rooms. Applying the existing
exact two-count algorithm there takes O(w¹¹) arithmetic operations using its
stated O(mV²) bound. This is intentionally loose but is a finite uniform
procedure for the eventual constant.

No finite enumeration is required for this eventual-affinity proof. Its
geometric dependencies and uniform potential were reviewed separately; the
new work is the finite-slack structure and exact count-band surgery. The
generalization to larger fixed budgets requires a different crossing-endpoint
argument because active counts may jump by more than one; this review does
not silently extend the present exact-boundary argument to that setting.

# Independent review of the odd-short historical corner bound

13 September 2026. Root independently reviewed Euler's proposed Sections1–3
of research/supersession-odd-short-potential.md. Ordinary proof audit: PASS
for the potential inequality, F(2h)-1<=C<=F(2h), and C=F(2h) at remainder0.
This does NOT certify the candidate time formula in the remaining equality
case; the current one-bit relaxation is known to permit an unattainable
shorter schedule on the already-classified5×16,m11 example.

Checked details:

- At s<=b², both unbounded corner images are <=b²+b+1<=m. Thus the change
  between physical target bit0 and alternating target bit1 does not change F.
- For s>=h-b(b+1), h>=2b²+3b+1 ensures the lower-root branch is saturated;
  the exact static neighborhood is h-x+rho(x). Target history resets to0.
- The linear envelope branch is preserved by the matching estimate j>=k-p.
  Its F branch is preserved by the interior lemma or C's defining minimum.
  Capture uses F(2k+z)=k when k<=m. Both full initial potentials equal C.
- Put a=rho(x), t=x-a. Then t<=a²<=b² and 2t<D. A changed rank crosses at
  most one period. Its count is at least h-b²>=b²+3b+1>b+1, so the periodic
  expression when entering F's cardinality branch has nonnegative quotient0
  and is <=the true count: L_1(k-b-1)<=k or L_0(k-b)<=k respectively.
- The even/odd remainder crossing costs were independently derived as
  b-a+c-rho_0(ell) and b-a+1+c-rho_1(ell), with
  ell=m-b+k-x+a>=b²-a²+k+1. The two quadratic differences stated by Euler
  expand exactly to lower bounds 2d(a-c+2)+c and 2d(a-c)+3d+c.
- Clipping does not invalidate either bound: d+c-1<=b in the even case,
  and d+c<=b in the odd case. For r=0 crossing, x>0 implies a>=1 and
  d<=b-1, so the lower root exceeds d even after clipping at b.
- Noncrossing even remainder with a zero target remainder loses at most1;
  all other noncrossing cases lose at most0. x=0 gives C<=F(2h) exactly.

The unresolved time case is r>0, J(r)=floor(m/2)+1, C=F(2h)-1. It requires
stronger geometric compatibility or a different construction. No manuscript
claim of a complete classification is licensed by this audit.
## Additional audit: co-small departure followed by a critical frontier

13 September 2026. The new Section 5 of `supersession-odd-short-potential.md`
also passes independent review. If `|R|=h-x`, its surplus is `a<=b`, and
the following survivor is strictly middle and critical, its required full
physical endpoint row is disjoint from `A=V\N(R)`. Thus A is a minority
support in the odd rectangle obtained by deleting that row. The new minority
class has size `M'=h-b-1>=2b(b+1)=2B`. Since `|A|=x-a<=B-a`, its reflected
corner term is at least `b+1`. Meanwhile `N(A)` lies in the complement of R,
so its surplus is at most a. The odd profile forces `|A|<=a(a-1)`, hence
`x<=a^2`.

In the associated arithmetic estimate, `t=x-a<=a(a-1)` eliminates the
zero-target-remainder loss. At a period crossing, write `d=b-a`. The two
new lower bounds after subtracting the relevant squared/pronic capacity
are respectively `2d(a-c+1)+a-c+3` and `2d(a-c)+d+a-c+2`. They are positive
in their stated ranges `c<=a`; the desired roots do not exceed their caps
because `d+c<=b`. Therefore `x+F(2(h-x+a))>=F(2h)` is proved in this range.
The conclusion forbids a discounted co-small departure immediately before
a strict-middle critical move. It does not cover a direct jump into the
small corner; the full ammunition bound remains open.

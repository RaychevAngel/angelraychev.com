# Independent audit: finite-horizon ammunition and cyclic growth controls

13 September 2026. Euler review of `maturation-odd-midpoint.md`, Sections
5 and 11, and Dirac's explicit phase convention. **PASS**, with the scope
and weakest useful hypotheses clarified below. No manuscript edits made.

## A precise general formulation

Let the phase set be a nonempty cycle `Z/dZ`, let `m≥1`, and let each map
`h_p:Nat→Nat` be nondecreasing and surjective. These two assumptions already
imply `h_p(0)=0` and integer increments in `{0,1}`: a positive initial
value or a jump of at least two would omit an integer from the image.
Equivalently one may explicitly require zero preservation, monotonicity,
unit Lipschitzness, and unboundedness, as in the proposed application.

Let `L_p(k)` be the least input with `h_p(L_p(k))≥k`, and put

    G_p(k)=max(L_p(k)−m,0).

A growth step ending in phase `p` applies `h_p` to the previous value plus
a quota in `[0,m]`. The starting value is zero. For a fixed target phase
`p` and target `k`, the exact controllability condition is that the reverse
threshold orbit

    (p,k) → (p−1,G_p(k)) → …

reaches value zero in finitely many steps. The per-phase inequality
`L_p(k)≤k+m` is not necessary if this termination condition is stated
directly. Nonincrease at every reverse step together with strict decrease
over every complete phase cycle is a convenient sufficient certificate,
which the bottom root maps satisfy.

## Why termination is exactly feasibility

If a finite quota schedule reaches at least `k`, propagate its threshold
backward. A last quota `q≤m` and predecessor value `v` must satisfy
`v+q≥L_p(k)`, hence `v≥G_p(k)`. Inducting backward along the actual
schedule bounds the propagated threshold by its initial value zero.
Thus the reverse orbit terminates within the schedule's length.

Conversely, at every positive reverse target use the least predecessor
`G_p(k)` and quota `min(m,L_p(k))`. Their sum is exactly `L_p(k)`, whose
image is exactly `k`. Reading a terminating orbit backward therefore
constructs an exact-target schedule. This also proves feasibility of all
smaller targets in the same ending phase by deleting probes.

## Minimum total probes and shortest duration

For every feasible target define `mu_p(k)` as the least total quota in a
finite schedule ending at least at `k` in phase `p`, with starting phase
free. The deletion argument in Section 5 is correct: deleting a single
probe cannot increase the final output and decreases it by at most one.
Consequently exact targets can be attained at optimum cost and
`mu_p(k)−k` is nondecreasing on feasible targets.

The last-step argument then gives

    mu_p(k)=min(m,L_p(k))+mu_(p−1)(G_p(k)).

It covers predecessors both below and above `L_p(k)`; no omitted
zero-quota alternative can improve it. Termination of the reverse orbit
permits recursive use even if an intermediate target is larger than the
previous one.

Every nonterminal positive call contributes exactly `m`; the terminal
positive call contributes an integer in `[1,m]`. Thus the optimal growth
schedule has one possibly partial **first** quota, followed by full
quotas, and exactly

    ceil(mu_p(k)/m)

steps. For `k=0`, both cost and minimal number of steps are zero.
Any `t`-step schedule has total quota at most `mt`, giving necessity of
`mu_p(k)≤mt`. When this condition holds, prepend enough zero quotas to
the optimal schedule. Every map fixes zero, so the padding changes no
values or ammunition cost. Hence the least ammunition at that prescribed
horizon remains exactly `mu_p(k)`.

The bottom capacity identity follows:

    D_p^bottom(t)=max{k:mu_p(k)≤mt}.

The maximum exists because `h_p(z)≤z`, so reaching `k` requires at least
`k` probes; the candidate set is contained in `[0,mt]` and contains zero.

## Phase conditions are indispensable

With free starting phase and prescribed final phase `p`, an optimal block
of length `q` starts in phase `p−q`. For horizon `t≥q`, choose the overall
initial phase `p−t`; the `t−q` zero steps end in exactly `p−q`.

With a fixed initial phase `a`, the same theorem applies **only when**
`a+t=p (mod d)`. Under that compatibility condition the same beginning
padding works, so no stronger restriction is needed. Without it the
prescribed final physical phase is impossible, regardless of ammunition.
The bottom-search statement chooses the initial cohort `p−t`, which is
available from the full board; it does not freely change a given cohort's
initial color. Padding at the end of a positive growth block is not used
and in general would change its output.

## Attacks on unnecessary or missing hypotheses

1. **Per-step reverse nonincrease is unnecessary.** With two phases,
   `m=2`, `h_0(z)=max(z−3,0)` and `h_1(z)=z`, every map satisfies the
   monotone-surjection assumptions. Target `(p,k)=(0,1)` has reverse
   values `1→2→0`; `L_0(1)=4>1+m`. Nevertheless two quotas `[2,2]`
   attain it at minimum cost four. Reverse-orbit termination, rather than
   a per-step comparison of target sizes, is the essential condition.
2. **Controllability cannot be omitted.** In one phase,
   `h(z)=max(z−2,0)` with budget two has `L(k)=k+m` for positive `k`,
   yet every legal schedule stays at zero. The reverse orbit is constant
   at every positive target. Surjectivity and the nonincrease inequality
   alone do not imply finite positive-target costs.
3. **Nonexpansiveness matters if surjectivity is relaxed.** The map
   `h(z)=2z`, budget one, reaches target three in two steps using quotas
   `[1,0]`, at total cost one. It cannot do so in one step. Thus the
   identity “minimum days equals ceiling of cost/budget” fails without
   the assumptions that make probe deletion nonexpansive. This example
   intentionally drops surjectivity/unit Lipschitzness; it is not a
   counterexample to the accepted theorem.

## Concrete bottom clock consequence

The accepted exact arrival property for the bottom clock gives

    L_b=ceil(mu_1(b(b−1))/(b+1)).

Indeed the left side is the first time the minority bottom capacity
reaches that target, and the capacity identity gives the same threshold.
The minority prefix of size `b²+1` needs a first full quota `b+1`, leaving
the target `b(b−1)` in the inverse duality. Its greedy clearing time is
therefore `L_b+1`. On the square, this whole decreasing prefix trajectory
stays outside the reflected profile branches, so the existing scalar
band calculation applies. This is a genuine way to evaluate the width
clock without iterating its long day-by-day recurrence.

## Independent finite checks and remaining scope

`src/maturation_cyclic_ammunition_check.py` compared the candidate costs
with exact finite-horizon controls for **265 abstract cyclic map models**:
**74,316** phase/target/horizon checks with free starting phase, and
**2,442** checks with fixed initial phase and the required congruence.
The maps include flat steps in different phases, positive targets that
are infeasible, and the reverse-increasing example above. All finite
checks passed in approximately 0.27 CPU second. Receipt:
`maturation-cyclic-ammunition-independent-check.json`.

The theorem concerns one scalar growth process. Two separately optimal
ammunition schedules may compete for the same days, so neither the cost
sum nor the separate horizon conditions prove joint shared-budget
feasibility. No such scheduling or arbitrary-partial-state seriality
claim is included in this acceptance.

# Three-row grids with two probes: independently audited proof

11 September 2026, Pacific time. This is a current-project derivation. It assumes no result from the unavailable summer 2020 notes and makes no literature-priority claim. The graph is `G_n=P_3 □ P_n`, with vertices `(r,c)`, `r∈{0,1,2}`, `0≤c<n`. Moves are along exactly one graph edge after an unsuccessful inspection round. Two arbitrary vertices may be inspected per round.

**Claim.** For every `n≥2`, the minimum guaranteed capture time is

\[
 T(G_n,2)=6n-8.
\]

The lower and upper arguments are written below. A separate agent freshly reconstructed and attacked the complete proof and found no substantive gap; see `research/three-row-independent-review.md`. This is not yet Lean verified or externally peer reviewed. Small full-belief BFS values `4,10,16,22,28` for `n=2,...,6` motivated the investigation but are not used as proof of the general claim.

## 1. Common notation and counting device

Split possible trajectories into the two cohorts given by their initial checkerboard color. At any round each cohort lies in one current parity, and the two supports are disjoint. If a cohort has support `A`, receives useful probes `C⊆A`, and has survivors `R=A\C`, its next support is `N(R)` and its decrement is

\[
 \delta=|A|-|N(R)|=|C|-(|N(R)|-|R|).
\]

A cohort, once empty, remains empty. Every vertex of `G_n`, `n≥2`, has degree at least two. Therefore every nonempty cohort support after any move has size at least two; the initial supports also have size at least two. Eliminating a cohort requires exactly two probes on a two-vertex support. Both cohorts cannot be eliminated on the same round. There are exactly two elimination rounds in a successful schedule, the second being the final round.

Let `Δ_t` be the total decrement and let `k` be the first guaranteed-capture round. Then `ΣΔ_t=3n`. Call a round positive when `Δ_t≥1`, and nonpositive otherwise; let their counts be `x,y`, so `x+y=k`. Negative decrements are allowed throughout.

For a word of positive/nonpositive rounds, the number of positive symbols equals its number of positive runs plus its number of adjacent positive-positive pairs. There are at most `y+1` positive runs. This elementary identity will replace a lengthy list of run cases.

## 2. Even n: classify the efficient survivor sets

Write `n=2q` and `h=3q`. Each parity contains `h` vertices.

### A perfect matching and its directed contraction

In parity zero, label the vertices

\[
 a_i=(0,2i),\quad b_i=(2,2i),\quad c_i=(1,2i+1),\qquad 0≤i<q.
\]

Match them respectively to opposite-parity vertices

\[
 \mu(a_i)=(0,2i+1),\quad
 \mu(b_i)=(2,2i+1),\quad
 \mu(c_i)=(1,2i).
\]

On the first parity define a directed graph `D` by `u→v` whenever `u` is adjacent in the original grid to `μ(v)`. Besides loops, its arcs are exactly

\[
 a_i\leftrightarrow c_i\leftrightarrow b_i,
 \quad a_i\to a_{i-1},\quad b_i\to b_{i-1},
 \quad c_i\to c_{i+1},
\]

with out-of-range subscripts omitted. For every subset `R` of this parity,

\[
 |N(R)|-|R|=|N_D^+(R)\setminus R|. \tag{1}
\]

Here `N_D^+` includes the loops. Thus neighborhood surplus in the grid is exactly directed outer-boundary size. The graph `D` is strongly connected: each triple is strongly connected, the middle arcs move right, and the outer arcs move left. Consequently every nonempty proper `R` has surplus at least one; surplus zero occurs only for empty or full parity sets.

### Surplus-one sets below size h−1

**Lemma 1.** If `R` is nonempty, `|R|≤h−2`, and `|N(R)|=|R|+1`, then

\[
 R=\{a_i,b_i,c_i:0≤i<j\}\ \cup\ U,
 \qquad U\subseteq\{a_j,b_j\}
 \tag{2}
\]

for some `0≤j<q`. For the opposite parity, reflect this description horizontally, so the analogous sets start at the right boundary.

**Proof.** By (1), the directed boundary consists of a single vertex `v`. Hence `R` is a nonempty set closed under outgoing arcs in `D−v`.

Deleting an outer vertex `a_j` or `b_j` leaves a strongly connected graph: the other outer chain still gives leftward movement, the middle chain gives rightward movement, and every remaining outer vertex connects to its middle vertex. Thus an outgoing-closed nonempty set must be all `h−1` remaining vertices, excluded by the size hypothesis.

Deleting `c_j` leaves the following strongly connected pieces: the prefix triples `i<j`, the singletons `a_j,b_j`, and the suffix triples `i>j`, omitting empty pieces. Arcs run from the suffix to each singleton and from each singleton to the prefix. Therefore an outgoing-closed nonempty proper subset of `D−c_j` is precisely the whole prefix together with a subset of the two singletons. This is (2). Horizontal reflection swaps grid parities because `n` is even. ∎

### Two efficient ordinary steps cannot be consecutive

**Lemma 2.** Suppose a cohort has at most `h` vertices. In each of two consecutive rounds it receives two useful probes, survives, and decreases by one. This is impossible.

**Proof.** Let `R` be its first survivors, of size `r≤h−2`. The first decrement one says `|N(R)|=r+1`. The second survivors `R'` have size `r−1`, are nonempty, satisfy `R'⊆N(R)`, and have surplus one.

By Lemma 1, `R` starts at one boundary and `R'` at the opposite boundary. Every nonempty set of form (2) contains at least one of its boundary's two outer corners; if it has at least two vertices, it contains both.

The set `N(R)` contains no outer corner at the opposite boundary unless `j=q−1` in (2). In that case `r≤h−2` allows at most one of `a_j,b_j`, so it contains only one such corner. If it contains one, necessarily `r=h−2` and `|R'|=h−3`. For `q≥2`, this is at least three, and `R'` requires both opposite corners, a contradiction. For `q=1`, `r≤1` makes `R'` empty, also a contradiction. ∎

### Lower bound for even n

In a non-elimination round, a positive decrement is at most one. If both cohorts are nonempty, positivity forces all two useful probes onto one cohort with surplus one, while the other cohort is full and untouched. Indeed, every surviving proper cohort pays at least one unit of expansion; two such cohorts would use up all two probes without a positive decrease. A touched surviving cohort cannot be full after deletion.

After this positive ordinary round the touched cohort is proper: its survivors have at most `h−2` vertices and its next support has at most `h−1`. A second positive ordinary round must therefore target the same cohort, which Lemma 2 excludes. If only one cohort remains, the same lemma excludes two consecutive positive ordinary rounds directly. Thus every adjacent positive-positive pair touches an elimination round.

The first elimination round can touch at most two such pairs; the final round at most one. Therefore there are at most three adjacent positive-positive pairs, and

\[
 x≤y+4. \tag{3}
\]

An elimination round has decrement at most two, because it uses both probes and the untouched surviving cohort has nonnegative expansion. All other positive rounds have decrement at most one. Consequently

\[
 3n=\sum_t\Delta_t≤x+2.
\]

Combining with (3),

\[
 6n≤2x+4=k+(x-y)+4≤k+8,
\]

so `k≥6n−8`.

## 3. Odd n: a stronger Hall inequality

Now `n≥3` is odd. Let `L` be the majority parity, containing all four outer corners, and `S` the minority parity. Write `|L|=h+1`, `|S|=h`, where `h=(3n−1)/2≥4`.

### Hamilton cycles after deleting a majority vertex

**Lemma 3.** For every `v∈L`, the graph `G_n−v` contains a Hamilton cycle.

**Construction.** First, every even-width three-row rectangle has a Hamilton cycle containing both vertical edges at each boundary column. Start with its perimeter cycle. For each consecutive pair of interior columns `(1,2),(3,4),...`, replace the bottom-row edge joining those columns with the three-edge detour through their two middle-row vertices. This includes every vertex and preserves the boundary vertical edges.

Two cycles in adjacent strips can be spliced by removing a matching pair of vertical boundary edges and adding the two horizontal edges between their endpoints. The resulting single cycle covers both strips.

A majority vertex in an outer row has an even column index. Reflect vertically if necessary to put it in the top row. The columns strictly to its left and right have even widths. Form the cycle on a nonempty neighboring even strip and insert the two surviving vertices of the deleted vertex's column by replacing an adjacent middle-bottom boundary edge with a three-edge detour. If a strip remains on the other side, splice its cycle to this new middle-bottom edge. At least one neighboring strip is nonempty because `n≥3`.

A majority vertex in the middle row has an odd column index. The three columns centered at it form a `3×3` square whose center is deleted; its perimeter is an eight-vertex cycle. The strips on either side have even widths. Splice their cycles to the square's boundary vertical edges, omitting empty strips. These constructions cover every majority vertex. ∎

**Lemma 4 (neighborhood inequalities).**

1. Every nonempty proper `R⊊S` satisfies `|N(R)|≥|R|+2`.
2. Every nonempty `R⊆L` with `|R|≤h−1` satisfies `|N(R)|≥|R|+1`.
3. If `R⊆L` has size `h` or `h+1`, then `N(R)=S`.

**Proof.** For (1), choose any neighbor `v∈L` of `R` and apply Lemma 3. On the Hamilton cycle of `G_n−v`, a nonempty proper subset of either bipartition has at least one more neighbor than its own cardinality: decompose it into maximal cyclic blocks of alternate vertices. Reinsert the neighbor `v` to gain one more, giving the claimed surplus two.

For (2), suppose instead that `|N(R)|≤|R|=r`. The set `U=S\N(R)` is nonempty and proper, since `R` is nonempty and has neighbors. Its neighbors lie in `L\R`, of size `h+1−r`. But (1) gives

\[
 |N(U)|≥|U|+2≥h-r+2>h+1-r,
\]

a contradiction.

For (3), every minority vertex has degree at least three, so deleting at most one majority vertex cannot remove all of its neighbors. ∎

### Cohort size and elimination restrictions

A nonempty majority-parity support has at least three vertices: initially it has `h+1`, and thereafter it is the neighborhood of a nonempty minority set, every vertex of which has degree at least three. A nonempty minority support has at least two vertices. Thus a cohort can be eliminated only when it lies in the minority parity and has exactly two vertices.

Let `σ` be the first elimination round. It is not round one, since the initial minority set has size `h≥4`.

**Lemma 5.** Both the round preceding `σ` and the round following `σ` have nonpositive total decrement.

**Proof.** The two-vertex minority support eliminated at `σ` must have arisen as the neighborhood of a single majority corner on the preceding round. Indeed, Lemma 4 makes the neighborhood of every majority set with at least two vertices have at least three vertices. Its preceding majority support had at least three vertices, so leaving that singleton with at most two probes forces precisely three vertices and two probes. This cohort's preceding decrement was one. The other, still nonempty cohort was then in the minority parity and received no probes; it expanded by at least one. The preceding total decrement was therefore at most zero.

On round `σ` both probes are used on the eliminated cohort. The other majority support has at least three vertices and is untouched. By Lemma 4 its new minority support has at least four vertices: sets of size at most `h−1` gain at least one, and larger sets produce all `h≥4` minority vertices. On the next round two probes cannot eliminate it. If any useful probes are made, its nonempty minority survivors are proper and expand by at least two, giving decrement at most zero. If none are made, the minority support expands by at least one, again giving a nonpositive decrement. ∎

### Ordinary positive rounds are isolated

Before the first elimination, consider a round in which both cohorts survive. The minority survivors either fill the whole minority parity and have surplus one, or are proper and have surplus at least two. The majority survivors have surplus `−1` only when full and untouched; surplus zero only when their size is `h`; and otherwise surplus at least one.

Enumerating these three possibilities with the two-probe budget shows that a positive total decrement is possible only when the majority cohort is full and untouched, both probes go to the minority cohort, and its proper survivors have surplus exactly two. The total decrement is then one. After movement, the previously touched cohort is a proper majority set, so this configuration cannot repeat on the next ordinary round.

For completeness, the budget check is as follows. If majority survivors have size `h`, their surplus is zero, but proper minority survivors cost at least two; a full minority survivor costs one and leaves at most one useful probe available in the majority if its survivors have size `h`. If majority survivors are smaller, both expansion costs total at least two. Thus neither case gives a positive total. The only remaining case is untouched full majority survivors of surplus `−1`; to obtain positivity against a proper minority survivor of surplus at least two requires both probes there and gives decrement one.

After the first elimination, only one cohort remains. A surviving minority cohort has nonpositive decrement with two probes, by Lemma 4. A surviving majority cohort has decrement at most one, and is followed by a minority cohort. Thus consecutive ordinary positive rounds are impossible here as well.

By Lemma 5 the first elimination is isolated among positive rounds. The only possible adjacent positive-positive pair is the pair ending at the final elimination. Hence

\[
 x≤y+2. \tag{4}
\]

Every ordinary positive decrement is at most one. The first elimination has decrement at most three (two probes plus at most one unit of majority shrinkage), and the final elimination has decrement exactly two. Therefore

\[
 3n=\sum_t\Delta_t≤x+3.
\]

Together with (4), this gives

\[
 6n≤2x+6=k+(x-y)+6≤k+8,
\]

and again `k≥6n−8`.

## 4. Explicit strategy in 6n−8 rounds

We describe a phase of length `3n−4` which clears the cohort initially occupying parity one. Its probes alternate current parity, so the other cohort receives no probes and remains full in its current parity throughout the phase.

For `n≥4`, begin with these five pairs of probes:

1. `(0,1), (1,0)`;
2. `(0,2), (1,1)`;
3. `(1,0), (2,1)`;
4. `(0,2), (1,1)`;
5. `(1,2), (2,1)`.

For `j≥2`, define the suffix-frontier state

\[
 F_j=\{(0,j+2a),(2,j+2a):a≥0,\ j+2a<n\}
 \cup\{(1,j+1+2a):a≥0,\ j+1+2a<n\}.
\]

A direct neighborhood calculation after the five startup rounds gives `F_2`. More explicitly, the least occupied column in each row after these rounds is successively

\[
 (2,1,0),\ (3,0,1),\ (2,1,2),\ (3,2,1),\ (2,3,2),
\]

with every subsequent column of the same row parity occupied. This is valid for every `n≥4`, interpreting a row with no in-range columns as empty.

From `F_j`, the following three rounds produce `F_{j+1}`:

1. `(0,j), (2,j)`;
2. `(0,j+1), (1,j)`;
3. `(1,j+1), (2,j)`.

The row-wise least columns become `(j+1,j,j+1)`, then `(j+2,j+1,j)`, then `(j+1,j+2,j+1)`. This proves the transition for `2≤j≤n−3`.

After these repeated transitions the belief is `F_{n−2}`, consisting of exactly

\[
 (0,n-2),\quad(2,n-2),\quad(1,n-1).
\]

Finish in three rounds:

1. probe `(0,n−2), (1,n−1)`, leaving the singleton `(2,n−2)` before movement;
2. probe `(1,n−2), (2,n−3)`, leaving the corner `(2,n−1)` before movement;
3. probe its two neighbors `(1,n−1), (2,n−2)` and capture.

The phase length is

\[
 5+3(n-4)+3=3n-4.
\]

For `n=3`, use the five-round phase

\[
 \{(0,1),(1,0)\},\quad
 \{(0,2),(1,1)\},\quad
 \{(1,0),(1,2)\},\quad
 \{(1,1),(2,0)\},\quad
 \{(1,2),(2,1)\}.
\]

For `n=2`, use the two-round phase

\[
 \{(0,1),(1,0)\},\quad\{(1,1),(2,0)\}.
\]

For `n=3`, the successive nonempty supports after movement are

```
{(0,2),(1,1),(2,0),(2,2)},
{(1,0),(1,2),(2,1)},
{(1,1),(2,0),(2,2)},
{(1,2),(2,1)}.
```

The fifth pair clears the last support. For `n=2`, the first round leaves the support `{(1,1),(2,0)}`, and the second clears it. Both phases therefore have length `3n−4`.

If `n` is odd, this phase has odd length, so the untouched cohort now occupies parity one. Repeat the identical phase. If `n` is even, the phase length is even, so the remaining cohort occupies parity zero. Reflect every probe of the phase horizontally by `(r,c)↦(r,n−1−c)`, which exchanges parities, and run that reflected phase. In both cases capture is guaranteed after exactly `2(3n−4)=6n−8` rounds.

Capture is checked before the target's next movement; no extra terminal move is counted.

## 5. Failed scalar-cardinality compression: explicit certificate

It is tempting to replace each cohort by only its size and apply the pointwise smallest possible neighborhood function at every round. That is not valid for these finite rectangular grids, because minimizing shapes for consecutive parities need not be compatible.

In the `3×6` grid each parity has nine vertices. Every nonempty proper parity set has at least one more neighbor, by the even-case matching argument. A corner singleton, for example `R={(0,0)}`, attains the minimum two neighbors:

\[
 N(R)=\{(1,0),(0,1)\}.
\]

But its neighborhood has four neighbors:

\[
 N(N(R))=\{(0,0),(2,0),(1,1),(0,2)\}.
\]

In the opposite parity, the two-set `U={(0,5),(2,5)}` has only three neighbors:

\[
 N(U)=\{(0,4),(1,5),(2,4)\}.
\]

Thus the pointwise minimum for a two-set is three, but the two-set produced by an optimal singleton has four neighbors. Every minimum-neighborhood singleton is a corner, and every corner's two-neighbor set has four neighbors. Therefore no choice of simultaneously minimizing initial segments can make neighborhoods of initial segments again minimizing initial segments at these sizes. This is a counterexample to the needed nesting hypothesis, not merely a bad choice of one tie-breaking order.

Likewise, for a single cohort with two probes the scalar minima would suggest repeated size decreases `9→8→7→...`; Lemma 2 proves that the efficient intermediate shapes cannot be chained in that manner. This failed approach is retained to prevent a cardinality-only algorithm from being mislabeled exact on general grids.

## 6. Targeted finite attacks

The independent script `src/three_row_checks.py` does not run an unbounded grid search.

- For `n=2,...,6`, it enumerates all one-parity subsets, checking the even surplus and critical-set classification, every possible deletion of two vertices after a small critical survivor, and the odd strong Hall inequalities. There are 1,600 examined parity subsets in total.
- It constructs the explicit phase and complete room-by-room strategy for every `2≤n≤100`, propagating actual room sets through graph moves and checking capture exactly on round `6n−8`.
- It explicitly checks the startup frontier and the parity of every probe pair.
- A separate explicit cycle constructor, `src/three_row_hamilton_cycles.py`, implements Lemma 3 and verifies connected degree-two spanning cycles after each of 1,025 majority-vertex deletions for odd widths 3 through 51; see `research/three-row-hamilton-checks.json` (about 0.09 seconds).

All checks passed, in approximately 1.61 seconds in one process. Output: `research/three-row-checks.json`.

A separate unrestricted `frozenset`/Manhattan-adjacency BFS independently confirms the exact formula for every `2≤n≤10`, through 52 turns on the `3×10` grid, in about 2.5 seconds; see `research/three-row-independent-computation.json`. The separate mathematical review found no substantive gap in the all-parameter argument.

The proof does not rely on extrapolating these values. Remaining tasks are literature comparison, polished exposition/figures, external peer review, and Lean verification. In particular, complete feasibility/capture-time classification for arbitrary probe counts or wider rectangles is not established by this note.

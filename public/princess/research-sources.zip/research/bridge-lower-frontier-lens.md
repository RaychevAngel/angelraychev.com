# A fixed-operation size bound from the two corner radii

13 September 2026. Ordinary geometric and merger proof. The parent
independently checked the geometric maximum-overlap and merger arguments.
This adds no state coordinate to the paired-radius model.

Let w be odd, n>=w even, and h=wn/2. Suppose a one-colored belief A has
radius certificates R0 and R1 about corners of its own and opposite color,
respectively. The two anchors need not be identified. Then

    |A| <= M(w,n,R0,R1),

where M is the number of color-zero rooms in the rectangle satisfying

    x+y<=R0,       x+n-1-y<=R1.

Thus M is the intersection count for the aligned anchors (0,0) and
(0,n-1). This alignment maximizes intersection among opposite-colored
anchors: after reflecting the first anchor to (0,0), the second is either
aligned or diagonally opposite. In each row the first ball is a left
prefix. The aligned second ball is also a left prefix; the diagonal
second ball is its reflection to a right prefix with the same row-color
cardinality, since w-1 is even. Intersection with a left prefix is
maximized by the left-aligned second prefix. Summing over rows proves
the assertion. Infinity may be represented by w+n-2, giving a full ball.

## Fixed-operation formula

Write `Tri(z)=z_+(z_++1)/2`, where `z_+=max(z,0)`. For p in{0,1}, put

    r=max(0,floor((L-p)/2)+1),    t=floor((D-p)/2),
    F_p(r,t)=Tri(r-1-t)-Tri(-1-t)-Tri(-p-1-t)+Tri(-p-r-1-t),
    Q(p,L,D)=r(r+p)-F_p(r,t).

Then Q counts exactly the nonnegative integer rooms of color p with
`x+y<=L` and `x-y<=D`. On diagonal `x+y=2u+p`, write
`x=u+v+p,y=u-v`; the allowed v interval is `-u-p<=v<=u`, and the latter
inequality is `v<=t`. The number omitted is
`(u-t)_+-(-u-p-t-1)_+`. Summing for u=0,...,r-1 gives F_p by two
telescoping triangular sums. This formula also handles negative L and D.

Set D=R1-n+1. Ordinary inclusion-exclusion for x>=w and y>=n gives

    M(w,n,R0,R1)
      = Q(0,R0,D)
        -Q(w mod2,R0-w,D-w)
        -Q(n mod2,R0-n,D+n)
        +Q((w+n) mod2,R0-w-n,D-w+n).

The count therefore uses a fixed number of integer arithmetic operations,
floors and maxima, independent of the board size or radii. It is monotone
in both radii because its counting definition is monotone.

## A simpler radius-sum consequence

For finite parity-compatible certificates, R0 is even and R1 is odd.
Put `m=(R0+R1-n+1)/2`. Every room of the aligned lens maps, by
`z=y+R1-n+1`, into the wedge

    0<=x<=z,       x+z<=2m,       x+z even.

There are exactly `(m+1)(m+2)/2` such rooms when m>=0, and none when
m<0. Indeed diagonal `x+z=2u` has u+1 choices. Board boundary constraints
can only decrease the count. Therefore every nonempty jointly certified
support satisfies

    R0+R1 >= n-3+2 ceil((sqrt(8|A|+1)-1)/2).              (SUM)

For arbitrary numeric radius bounds, first replace R0 by its largest
even value and R1 by its largest odd value; this does not change either
ball on the current color. The inequality is a simpler necessary
consequence of the exact lens constraint, not an equivalent count.
It expresses a lower bound on the combined ages of opposite-orientation
certificates using only the current cardinality.

## Guarded merger inheritance

Retain the reviewed per-coordinate invariant

    Rmerged[d]>=min(Rcomponent1[d],Rcomponent2[d]).

For each finite merged coordinate, choose a component supplying an equal
or smaller radius. If the same component supplies both coordinates,
its own lens constraint and monotonicity bound its size by the merged
lens count; the merged size is no larger than that component's size.

If different components supply the two coordinates, their individual
ball bounds give

    aMerged=a1+a2-h <= B0(Rmerged[0])+B1(Rmerged[1])-h.

For any admissible pair of balls in a color class of size h, inclusion-
exclusion bounds that right side by the size of their intersection.
The latter is at most M by the geometric maximum-overlap result. Hence
the merged lens bound holds in this case as well. Infinite certificates
are interpreted as full balls, so the same argument includes them.
Trigger formation and radius propagation are unchanged.

## Targeted evidence and scope

`src/bridge_lower_frontier_interval.py` implements both the fixed formula
and an optional lens-constrained persistent terminal search. A separate
literal quadrant/row count checks 6,446 formula instances, including every
radius pair on 5x6,7x8,13x14 and23x24. Receipt:
`bridge-lower-frontier-lens-count-check.json`.

At b11, boundary K133 and source feature(c1,e0), the exact-triangle radius
model takes62 days. Adding only the lens constraint raises it to63,
matching the physical prefix, even without either interval reset. This
is an independent way to exclude the same terminal shortcut using the
existing two numbers. Receipt:
`bridge-lower-frontier-b11-exact-lens-witness.json`.

This is a uniform necessary geometry and merger theorem plus one finite
terminal check. It is not a proof of the variable-width terminal-clock
conjecture. The near-square first-orientation-change delay derived from
the same lens is recorded in `bridge-lower-frontier-terminal-family.md`.

# Four-row grids: contraction, critical sets, and the three-probe theorem

Independent ordinary proof audit: `research/four-row-independent-review.md`. The root researcher and an independent reviewer found no gap in the complete all-budget argument. This is not a Lean verification claim.

Research log, 12 September 2026 (UTC; 11 September Pacific). This is a new derivation in the present investigation; prior rectangle feasibility is credited elsewhere and no novelty priority is asserted. The complete all-budget ordinary proof has passed independent review by the root investigator and a separate reviewer. No Lean formalization yet.

## 1. Target and first result

For `n≥4`, let `G=P_4 □ P_n`, with four rows and `n` columns. Put `h=2n`, the size of each checkerboard parity class. The first theorem is

\[
 T_3(G)=4n-4=2h-4.
\]

This gives all lengths for the four-row/three-probe slice after the smaller cases are supplied by the already proved path, two-row, and three-row families. Sections 8–9 extend this to every budget.

## 2. Match vertical row pairs

Match row zero to row one in each column, and row two to row three. Identify each parity class with two layers `A,B` and columns `0,...,n−1`, according to which matched row pair contains its vertex. For a fixed parity, contract a grid edge followed by the inverse matching map. The resulting directed graph `D` has:

- a loop at every vertex;
- bidirectional horizontal edges within each of its two layers;
- one directed vertical rung per column, with direction alternating from column to column.

The other physical parity reverses every rung. Horizontal edges remain bidirectional. For every one-parity set `R`,

\[
 |N_G(R)|-|R|=|N_D^+(R)\setminus R|. \tag{1}
\]

Both directed rung orientations occur when `n≥2`, so `D` is strongly connected. Every nonempty proper survivor set therefore has surplus at least one.

## 3. Classify all surplus-one cardinalities

**Lemma.** If `n≥4` and a nonempty proper parity set `R` has `|N(R)|=|R|+1`, then

\[
 |R|\in\{1,h-2,h-1\}. \tag{2}
\]

**Proof.** Its directed outside neighborhood in `D` is a single vertex `v`. Therefore `R` is nonempty and closed under outgoing edges in `D−v`.

Deleting `v` splits one horizontal layer into a left segment and a right segment; the other layer remains connected bidirectionally. Every remaining segment of length at least two contains both rung directions and is strongly connected to the intact layer. Thus the intact layer and all segments of length at least two form one strongly connected core.

A segment of length one can only be an endpoint singleton. For `n≥4`, there is at most one such singleton unless the other segment has length zero, in which case the remaining segment has length at least three; in particular there cannot be two singleton segments. If no singleton remains, `D−v` is strongly connected, and its only nonempty outgoing-closed set is all `h−1` vertices.

If a singleton remains, it attaches to the core by its one directed rung. It is either a sink singleton or a source singleton. In the sink case, the only nonempty outgoing-closed sets are the singleton and all of `D−v`. In the source case, they are the core and all of `D−v`. The core has `h−2` vertices. These possibilities prove (2). ∎

Consequently

\[
 |N(R)|\ge |R|+2\quad\text{when }2\le |R|\le h-3. \tag{3}
\]

The excluded cardinalities really can have surplus one: a corner singleton; the complement of the two neighbors of an opposite-parity corner; and a whole parity class minus one vertex. Thus (3) is sharp across its full domain. This proof avoids classifying the more numerous surplus-two sets.

## 4. Sharp lower bound with three probes

Track the two initial-parity cohorts and give a cohort of size `b` the weight

\[
 w(b)=\max(b-3,0).
\]

Every surviving cohort after movement has at least two possible rooms, because the grid has minimum degree two. Initially each has `h` rooms. A successful strategy therefore has exactly two distinct elimination rounds: three probes cannot eliminate two nonempty cohorts of at least two rooms each in the same round.

The neighborhood bounds imply:

1. With zero or one useful probe, a cohort's weight cannot decrease. At sizes `h` and `h−1`, this uses the near-full surplus-one bound; at intermediate sizes it uses (3); the smallest sizes already have zero weight.
2. With two useful probes, the weight can decrease by at most one. The only positive possibility is a full cohort becoming size `h−1`; all other non-elimination cases are nondecreasing in weight.
3. With three useful probes, the weight can decrease by at most one. For survivor size at least two, use (3) unless near full, where the same bound follows directly. If the survivor is a singleton, the current size is four and has weight one, while the next cohort has at least two rooms and nonnegative weight.
4. An eliminated cohort had size at most three and hence already had weight zero. The other cohort receives at most one useful probe and its weight cannot decrease. Thus an elimination round has nonpositive total weight decrease.

Every other round has total weight decrease at most one, since the two allocations sum to at most three. Initially the total weight is `2(h−3)` and finally it is zero. The two elimination rounds contribute no positive decrease, so a schedule of `T` days satisfies

\[
 2(h-3)\le T-2,
 \qquad T\ge2h-4=4n-4.
\]

This compares with arbitrary physical probes, including disconnected supports and temporary increases in uncertainty.

## 5. Matching explicit construction

Use the usual diagonal prefix families, separately oriented for the two initial-parity cohorts. Each prefix neighborhood is an opposite-parity prefix. For prefix sizes `2,...,h−3`, both phases have neighborhood size `k+2`. The corner-starting phase has a singleton neighborhood of size two; the other phase has a singleton neighborhood of size three. Reflections across the horizontal midline exchange physical parities and allow either full cohort to start in the corner phase.

For one cohort, give all three probes to the tail of its prefix on every round. For the first `h−4` rounds its size decreases from `h` to four, one per round: the survivor sizes lie in `2,...,h−3`, where the prefix neighborhood adds two. Since `h−4` is even, this four-room state is in the corner phase. On the next day leave its corner singleton, whose neighborhood has two rooms. Inspect those two rooms on the final day. This clears one cohort in

\[
 (h-4)+2=h-2
\]

days. Repeat for the other cohort, independently choosing the appropriate reflected corner prefix. The total is `2h−4`, meeting the lower bound.

## 6. Consequence for feasibility

For completeness, the same geometry gives a short impossibility proof with two probes. A cohort of size at least `h−1` leaves at least `h−3` survivors after two probes, and their neighborhood has at least `h−1` rooms by (3) and the near-full bounds. Thus each cohort's size stays at least `h−1`, starting from `h`; neither can be eliminated. Three probes succeed by Section 5.

This agrees with the established rectangular hunter-number theorem. It is a new short proof within this project, not a new feasibility threshold.

## 7. Failed and open directions

A single fixed diagonal orientation is not generally isoperimetric, even though its bulk neighborhood profile is sharp. The two phases differ near the singleton and near-full endpoints, depending on the parity of `n`; scalar minimum profiles alone therefore do not imply an exact arbitrary-budget algorithm.

The next target is to determine whether arbitrary budgets can be handled using only endpoint phase labels plus the bulk affine motion `b→b−p+2`. The width-four contraction makes the bulk sharp lower bound simple, but optimal transition compatibility at surplus-two sets may require more information. No universal normal-form claim is made here.

## 8. All budgets: a stronger relaxation removes the phase difficulty

The four-row problem now has a complete ordinary proof. The new device is to make the scalar lower-bound game still easier: allow the searcher to **hold a cohort's size unchanged for free**. A lower bound for this game is valid for the actual graph. This avoids having to prove that independently minimizing shapes can be chained after every arbitrary allocation.

For `0≤k≤h`, put

\[
 g_h(k)=\begin{cases}
 0,&k=0,\\
 2,&k=1,\\
 h-1,&k=h-2,\\
 \min(h,k+2),&\text{otherwise}.
 \end{cases}
\]

The critical-set lemma proves `|N(R)|≥g_h(|R|)` for every parity set `R`; all these bounds are attained, although compatible attainment is not asserted. This profile is nondecreasing. Define the relaxed transition

\[
 H_h(b,p)=\min\{b,g_h(\max(b-p,0))\}. \tag{4}
\]

It is nondecreasing in `b` and nonincreasing in `p`. Comparing the same useful-probe allocations with arbitrary physical supports therefore gives a smaller or equal relaxed count after each day. The terminal condition is that the two counts total at most `m`. Every actual successful strategy supplies a successful relaxed strategy no longer than itself.

An inspection that does not decrease a relaxed count can be replaced by zero probes on that cohort. Thus we need count only its **productive inspections**, which need not be consecutive or disjoint from the other cohort's productive inspections. Each successful cohort starts at `h` and decreases strictly on its `k` productive inspections, the last of which clears it.

### The two possible one-unit bonuses

Every nonterminal productive inspection pays neighborhood surplus two except for at most these two events:

- **A:** the first productive inspection uses exactly two probes, sending `h` to `h−1` with surplus one;
- **B:** the penultimate productive inspection leaves a singleton, sending its neighborhood to size two with surplus one. Its final productive inspection consequently uses exactly two useful probes.

There are no other productive surplus-one events. The case `k=h−1` survivors returns a full cohort and is not productive. The case `k=h−2` survivors has output `h−1`, so is productive only from the initial size `h`. A singleton survivor has output two, and the next productive inspection must clear it. Counts of size three are never produced by `g_h`.

Write `A,B∈{0,1}` for whether these events occur. Telescoping cardinality across the productive inspections shows that their useful probe total `P` satisfies

\[
 P\ge h+2(k-1)-A-B. \tag{5}
\]

If at least one bonus occurs, a productive inspection uses exactly two useful probes, so

\[
 P\le(k-1)m+2. \tag{6}
\]

If both occur, the first and last productive inspections are distinct and each uses two probes, so

\[
 P\le(k-2)m+4. \tag{7}
\]

These upper bounds on useful probes, combined with the lower bound (5), will exclude bonuses when the available number of productive inspections is too small.

### Minimum number of productive inspections for one cohort

Let `D=m−2`, with `m≥3`. Inspecting all `m` possible rooms is always best for a single relaxed cohort, by monotonicity. The largest initial count clearable in `j≥1` inspections is

\[
 K_j=\min(h,jD+2).
\]

For `j=1` this is the direct capture threshold `m=D+2`. For the induction, whenever `b≥m+2`, the survivor size `b−m` lies between two and `h−3`, so its next count is `b−D`. The exceptional case `b=m+1` produces two rooms, but it is already within the next threshold because `K_j≥m≥3`. This proves the displayed capacity formula.

Consequently, putting `W=h−2`, every successful cohort needs at least

\[
 k\ge \left\lceil W/D\right\rceil \tag{8}
\]

productive inspections, regardless of how they interleave with the other cohort's inspections.

## 9. Closed formula for every budget on four-row boards

For `n≥4`, set `h=2n`. The answer is infinity for `m≤2`, one day for `m≥2h=4n`, and two days for `h≤m<2h`. For the remaining range `3≤m<h`, write

\[
 W=h-2=2n-2=qD+r,\qquad D=m-2,\qquad0\le r<D.
\]

Then the exact formula is

\[
 \boxed{T_m(P_4\square P_n)=
 \begin{cases}
 2q,&r=0,\\
 2q+1,&r=1\text{ or }(r\ge2\text{ and }m\ge2r+4),\\
 2q+2,&\text{otherwise}.
 \end{cases}} \tag{9}
\]

### Lower bound from productive-inspection budgets

The case `m=3` is already proved in Sections 2–5 and agrees with (9), because `D=1`, `r=0` and `q=h−2`. Assume henceforth `m≥4`.

**Case r=0.** Every cohort has `k≥q`. If `k≥q+1`, (5) immediately gives `P≥qm`, even allowing both bonuses. If `k=q`, a single bonus would force both `P≥qm−1` from (5) and `P≤qm−m+2<qm−1` from (6). Two bonuses would force `P≥qm−2` and `P≤qm−2m+4<qm−2`. Thus neither is possible, and again `P≥qm`. Both cohorts together require at least `2qm` probes, hence at least `2q` days.

**Case r=1.** Here `D≥2`, so `m≥4`. Every cohort has `k≥q+1`. If `k≥q+2`, (5) gives `P≥qm+3`. If `k=q+1`, two bonuses would force `P≥qm+1` from (5) but `P≤qm+4−m≤qm` from (7), impossible. At most one bonus occurs, so `P≥qm+2`. The two cohorts therefore need at least `2qm+4` probes, ruling out `2q` days and giving `T≥2q+1`.

**Case r≥2.** Again `k≥q+1`. If `k≥q+2`, (5) gives `P≥qm+r+2`. If `k=q+1`, exactly one bonus would force `P≥qm+r+1≥qm+3`, contradicting (6), which gives at most `qm+2`. Two bonuses would force `P≥qm+r≥qm+2`, contradicting (7), which gives at most `qm+4−m≤qm+1`. Hence there are no bonuses, and `P≥qm+r+2` in every case.

The combined probe total is therefore at least `2qm+2r+4`. A `(2q+1)`-day schedule is possible only if `m≥2r+4`; otherwise at least `2q+2` days are necessary. This proves all lower bounds in (9), even in the easier free-holding game, and hence for the physical board.

### Explicit upper constructions

The diagonal-prefix families have bulk transition `b→b−p+2` when at least two and at most `h−3` vertices survive. The two phases differ only at the near-full and singleton endpoints relevant here. An arbitrary full cohort can be independently reflected vertically to put its desired final singleton in a corner phase.

A solo cohort clears in `ceil(W/D)` days with all `m` probes each day. Near the endpoint, a singleton survivor has at most three neighbors, all inspectable the next day because `m≥3`. Thus two sequential solo sweeps give `2q` days when `r=0` and `2q+2` otherwise.

If `r=1`, give `q` full-budget days to the first cohort, choosing its initial diagonal orientation so that the singleton survivor on day `q` is a corner. Its next support then has two rooms. On day `q+1`, clear it with two probes and give the remaining `m−2=D` probes to the second, still-full cohort. The case `D=2` cannot occur because `W=h−2` is even and would then have even remainder; hence `D≥3`. The second cohort's new size is

\[
 h-D+2=(q-1)D+5\le qD+2.
\]

It therefore clears in the following `q` full-budget days. The total is `2q+1`.

If `r≥2` and `m≥2r+4`, after `q` full-budget days the first cohort has `r+2` rooms. Clear it on the shared day with `r+2` probes, and give `m-r-2=D-r` probes to the second full cohort. This is at least `r+2≥4`, so the second transition is in the bulk. Its new size is

\[
 h-(D-r)+2=(q-1)D+2r+4\le qD+2.
\]

It clears in `q` additional full-budget days, again giving `2q+1` total. No simultaneous realization of incompatible minimum profiles is used.

### Direct extreme-budget regimes

The perfect matching gives `|N(B)|≥|B|` for arbitrary mixed-parity room sets. If `m<h`, the first movement leaves at least `2h−m>m` rooms, so two-day capture is impossible. If `m≥h`, inspect one whole parity on each of two consecutive days. One day requires all `2h` rooms. The feasibility boundary `m≤2` was proved in Section 6.

The lengths `n=1,2,3` are supplied by the already proved path, two-row, and three-row classifications after rotating the board. In particular the three-probe times at lengths one, two, and three are respectively two, four, and six days, before the formula `4n−4` begins at length four.

## 10. Verification and current boundary

The complete all-budget proof above has passed fresh independent mathematical attack by both the root investigator and a separate reviewer. The finite recurrence comparison in `research/four-row-recurrence-checks.json` checks all `4≤n≤30` and `3≤m≤16`; its minimum-profile lower and independently oriented prefix upper times all agree. It separately checks 43,520 parity subsets on lengths four through seven, confirming the exact surplus-one cardinalities and sharp minimum profiles. Runtime was about 4.94 seconds in one worker.

No Lean or novelty claim is made. The free-holding reduction and the productive-inspection/bonus count are the substantive new abstraction. They may be useful for wider grids whose minimum neighborhood profiles have a constant bulk surplus and finitely many endpoint discounts.

The direct constructor `direct_strategy(n,m)` in `src/four_row_recurrence.py` gives optimal physical inspections without search. `research/four-row-direct-strategy-checks.json` records 5,076 parameter pairs (`4≤n≤50`, all budgets through `4n`), with every finite strategy physically replayed and 378 pairs additionally compared against both independent recurrences, in about 6.48 seconds.

# Independent review of the odd five-row formulas

12 September 2026. Reviewer: root research agent, separate from the agent
that derived `recurrence-bridge-odd-five.md`. Status: ordinary proof accepted.
This is not a claim that the full geometric classification is in Lean.

## Scope and result

I reviewed the four-probe and five-probe translations, the larger-budget
ammunition potential, the tight-equality obstruction, and the explicit
attaining schedules. Together with the established three-probe result,
the formulas classify every budget on every odd `5 x n`, `n >= 5`.
Combining them with the earlier even-length theorem completes five rows.

The geometric input is the already proved exact compatible parity-prefix
theorem for odd rectangles. It applies to arbitrary physical schedules by
domination; it does not assume that an arbitrary strategy was a prefix
strategy in the first place. In the equality argument it is legitimate to
replace a hypothetical optimum by a prefix optimum before analyzing exact
profile transitions. This distinction is essential because a clipped
potential alone does not determine an arbitrary support's neighborhood.

## Four and five probes

The finite bases are supplemented by genuine unbounded translations, not
an extrapolation from the tested lengths. For four probes, reducing both
`h,b` by three subtracts eight from the bulk and corrected potentials and
preserves the relevant profile branches once `h >= 24, b >= 13`; lower
source sizes permit reducing only `h`. The remaining bases have
`12 <= h <= 23`. For five probes the corresponding shift is five, with
bases `h=12,17` in the physical residue class. The potentially troublesome
endpoint `K(5,1)+10=K(10,1)` satisfies the required identity. The short
attaining tails and their starting parity agree with the claimed durations.

## All larger budgets

For `5 <= m < h`, the quotient is at least one. The four exceptional
values immediately above the capture range are
`F(2m+2),...,F(2m+5) = m+2,m+3,m+4,m+4`.
They agree directly with the definition, including `m=5`.
The first positive quotient and the remainder wrap preserve monotonicity,
the one-rank increment bound two, and the two-rank increment bound three.

I checked the complete high-end transition list against the displayed
profiles. In particular, a target corrected majority size `h` has minority
survivor size `h-2` or `h-3`; there are no missing survivor sizes. The
inequalities needed for source ranks `2h-3, 2h-1, 2h+1` follow from the
three terms in the corrected cap and the two increment bounds. A proper
majority source with survivor `h-3` has only the listed decreasing case.
Full-majority allocations zero through four account for all remaining
nonbulk improvements. Clipping a target at `C` is harmless because every
source potential is at most `C`.

The identity `C = q m + J(r)` has the stated physical exception exclusion
at `m=5`: `h=2 mod 5` forces `r=4`, so the problematic nonphysical residue
three never occurs. Since `0 < J(r) <= m` for `r>0`, the baseline lower
bound is exactly the displayed two-branch ceiling.

The extra day requires equality in the summed ammunition bound. After a
positive tight move, the potential is strictly below the cap. A later
target at the cap cannot be tight. For bulk moves with unchanged quotient,
the uncorrected slack is at least two and the discount changes by at most
one; equality is impossible. A quotient cannot decrease by more than one
because `2p-5 <= 2m-5`. Noncapture low-end moves with source size at most
`m` have strict cardinality slack; the only larger low-end sources have
quotient one and go to quotient zero. The exceptional high-end moves in
the note exhaust the remaining corrected cases.

Thus each active interval has exactly `q+1` consecutive days. Equality in
the total daily budget forces the two intervals to cover all `2q+1` days,
so they overlap once and start at days zero and `q`. For generic critical
residues, `q` is even and both starts must be in minority parity, which is
incompatible with the opposite initial colors. In the small critical
budgets six and eight, `q` is odd; the second minority start and the first
cohort's final allocation exceed the shared daily budget. These arguments
exclude arbitrary interleaving, not just serial schedules.

Finally, the low-corner capacity recurrence is exact because every target
capacity is at least `m >= 5`, beyond the small inverse-profile exceptions.
Its solution gives the advertised shared-day threshold `2J(r)+delta(r)`.
At the largest residues, `J+delta <= m`, so the two separate solo sweeps
also cover the fallback branch. The near-full first-step exceptions are
excluded by the explicit allocation bounds in the note. The residue-zero
case has odd `q`, ensuring that both serial starts have minority parity.

## Evidence boundary

The construction replay and exact-count comparisons in the author's
receipts support the result but are not used as an unbounded proof.
The two new Lean files certify the finite arithmetic bases for the small
budgets. The translations and the all-budget equality argument above are
ordinary proofs; a full physical Lean theorem for five rows remains work
to do. The broader even-box constant-budget normal-form question remains
open and is not needed here.

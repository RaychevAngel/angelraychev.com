# Minimum-budget ancestry and maturation

Research resumed 13 September 2026. This note starts from the independently
reviewed Sections 1–3 of `uniform-odd-minimum-budget.md`. The uniform solo
formula and the one-day ambiguity were proved there. The full minimum-budget
law is now proved below and independently accepted by root. Its new abstract
ancestry step is also kernel checked in Lean; the separate arbitrary-budget
problem remains open.

## Target

For odd width `w=2b+1`, odd `n≥w`, and budget `m=b+1`, exclude the short
midpoint alternative. The last pure tie, at deficit `d*=M−b²−1`, leaves
only `L_b` upper-tail steps before the midpoint. A secondary ancestry
starts at zero; each of its deficits is bounded by `C=b(b−1)`.

The key question is whether an exceptional mixed history can pay to
produce a secondary deficit while moving its primary backward into the
lower inverse-root collar. Coordinate bounds alone do not decide this.

## Exact local identity under investigation

Write `z` for the primary's remaining belief size in physical color `p`,
and `k` for the opposite secondary deficit. Allocate `u` probes to the
primary and `v=m−u` to the secondary. The exact transition is

    z' = g_p(max(z−u,0)),   k' = I_p(k+v).

In the appropriate nonempty lower-profile branches, if `s_p` denotes the
primary boundary surplus and `a_p` the secondary inverse loss, then

    z'−k' = z−k−m + s_p(z−u) + a_p(k+v).

The two root arguments differ by the quota-independent quantity
`z−k−m`. This identity is exact where the stated branches apply, but an
invariant based on it has not yet been established.

## First focused attack

`src/maturation_minimum_probe.py` reconstructs the exact upper-tail
frontier with primary ancestry tags. It discards only states covered by
the proved low-total persistence theorem, or dominated states of the
same ancestry. It also tracks changes in the fastest initial solo cohort:
the established phase-switch lemma erases exceptional mixed episodes.
The experiment asks whether those episode lengths or accumulated losses
give a stronger invariant than current coordinates.

Finite diagnostic output will be treated as evidence only. In particular,
the phase-root inequalities in the script are candidates, never pruning
rules or asserted results.

## Accepted resolution: ancestry, rather than a lower-root barrier

Dirac observed that the already established phase-reset mechanism forces
all exceptional states at a given time to favor the same initial cohort.
The following direct proof, developed while formalizing that observation,
does not even require a separate classification of phase changes.

Let `D0,D1` denote the two solo deficits at time `t<τ`. Call a state high
if its total deficit exceeds `min(D0,D1)`. Tag its original primary cohort
at the last pure tie. Its secondary deficit is always at most `C`, while
`C<d*≤min(D0,D1)` throughout the tail.

We prove by induction that a high state's primary occupies the physical
color with the strictly larger solo deficit.

* For a pure high state, the nonzero coordinate cannot be the secondary,
  because that coordinate is at most `C`. Individual solo bounds then
  force the primary's color to be the larger one. This handles both the
  initial state and every later pure rebirth.
* A high mixed successor cannot arise from a low-total predecessor, by
  low-total persistence. The predecessor is therefore high and satisfies
  the induction hypothesis. If its primary occupies color zero, total
  concentration gives source total `S≤D0`. With useful allocations `p,q`,
  the second inverse-concentration inequality gives successor total
  `I0(y+q)+I1(x+p)≤I1(S+p+q)≤I1(D0+m)=D1(next)`.
  Positivity of the successor's color-one coordinate supplies `x+p≥2`.
  Being high forces `D1(next)>D0(next)`, precisely the physical color of
  the same primary after movement. If the primary occupies color one,
  the first inverse-concentration inequality gives the symmetric result.

Thus all high states at the precentral time have the same primary ancestry.
Two independent high half-searches leave at least `M−2C≥4b>m` rooms in
their common secondary color, so they cannot share a successful central
inspection. If one half-state is low, the two totals sum to at most
`D0+D1`; their central intersection is at least the scalar solo residual
sum `E+M−D0−D1`. This is the exact distinction needed by the midpoint
theorem, without asserting serial optimality from arbitrary partial states.

The two solo durations are `τ` and `τ+1`. At time `τ−1`, the slower solo
therefore still has more than `m` possible rooms; otherwise one final
inspection would capture it in `τ` days. Hence the scalar residual sum is
strictly greater than `m`, excluding the shorter full horizon `2τ−1`.
The general reflected solo construction attains `2τ`.

Consequently, for every integer `b≥1` and every odd `n≥2b+1`,

    T_(b+1)((2b+1)×n) = 2(2b+1)n − K_b,
    K_b = 8b²−4b−4L_b+4.

Here `L_b` is the terminating width-only recurrence clock already defined
in the earlier note. In particular `T(w,n+2)=T(w,n)+4w` holds from the
square onward. No elementary expression for `L_b` is claimed. The former
lower-root exclusion conjecture was bypassed, not established.

Root's independent ordinary review is
`maturation-minimum-budget-independent-review.md`; Dirac's version of the
ancestry proof is in `maturation-odd-midpoint.md`, Section 4. The diagnostic
root-sum tests above are now historical failed-route exploration, not a
dependency of the theorem.

## Formal scope

`lean/FastestAncestry.lean` proves the shared-budget inverse recurrence's
individual and total bounds, low-total persistence, the complete primary
ancestry induction (including pure rebirth), and the two-copy numerical
midpoint obstruction. Its explicit hypotheses are the two monotone inverse
maps and concentration inequalities, a proper-input domain, a pure reset,
and a bounded fresh secondary. The odd-rectangle root identities, geometric
profiles, reset clock, and interpretation as physical avoiding walks are
ordinary theorems used externally; this module does not claim a full Lean
formalization of the new all-width game formula.

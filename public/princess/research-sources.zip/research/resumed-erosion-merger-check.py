"""Finite counterattack on an erosion-corner merger; no closure assumed."""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from resumed_odd_even_erosion_corners import build

def merge(a,b,h):return(a[0]+b[0]-h,max(0,a[1]+b[1]-2),max(0,a[2]+b[2]-2))
def audit(b,n,k,**settings):
 h=(2*b+1)*n//2;states,edges=build(b,n,k,triangle=False,**settings)
 ids={s:i for i,s in enumerate(states)};rows=[{}for s in states]
 for a,d,p in edges:rows[a][d]=min(p,rows[a].get(d,k+1))
 invalidsource=None;invalidtarget=None;checked=0
 for aa,a in enumerate(states):
  for bb in range(aa,len(states)):
   bstate=states[bb];m=merge(a,bstate,h)
   if m[0]<=k:continue
   if m not in ids:
    if invalidsource is None:invalidsource=dict(source=[a,bstate],merged=m)
    continue
   mergedrow=rows[ids[m]]
   for dd,p in rows[aa].items():
    for ee,q in rows[bb].items():
     if p+q>k:continue
     target=merge(states[dd],states[ee],h)
     if target not in ids:
      if invalidtarget is None:invalidtarget=dict(source=[a,bstate],target=[states[dd],states[ee]],costs=[p,q],merged_source=m,merged_target=target)
      continue
     checked+=1
     if mergedrow.get(ids[target],k+1)>p+q:
      return dict(status='COUNTEREXAMPLE',width=2*b+1,n=n,k=k,settings=settings,states=len(states),edges=len(edges),checked=checked,first_invalid_source=invalidsource,first_invalid_target=invalidtarget,counterexample=dict(source=[a,bstate],target=[states[dd],states[ee]],costs=[p,q],merged_source=m,merged_target=target,merged_min_cost=mergedrow.get(ids[target])))
 return dict(status='PASS_VALID_FEATURES_ONLY',width=2*b+1,n=n,k=k,settings=settings,states=len(states),edges=len(edges),checked=checked,first_invalid_source=invalidsource,first_invalid_target=invalidtarget)
if __name__=='__main__':
 start=time.process_time();rows=[]
 for b,n,k in[(2,6,3),(3,8,4)]:
  for settings in[dict(closed=False,maximal=False,dual=False),dict(closed=True,maximal=True,dual=True)]:
   r=audit(b,n,k,**settings);rows.append(r);print(json.dumps(r),flush=True)
 result=dict(scope='Necessary model only; triangle-memory flag disabled. Invalid merged features separately recorded; they are not counted as mathematical closure successes.',rows=rows,CPU_seconds=time.process_time()-start,model_source_sha256=hashlib.sha256((Path(__file__).resolve().parents[1]/'src/resumed_odd_even_erosion_corners.py').read_bytes()).hexdigest())
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')

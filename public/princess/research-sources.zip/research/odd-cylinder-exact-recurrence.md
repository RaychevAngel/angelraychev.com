# Exact partial-state recurrence for every odd cylinder

12 September 2026 UTC. Ordinary proof, independently checked; no claim that the
entire theorem is already in Lean. Root proposed the odd-path compression.
This note proves its operator properties and derives the exact recurrence.

## 1. The path operator

Let n=2q+1, q>=1, and number the vertices of P_n from 0 to 2q. Its even
vertices are 0,2,...,2q, and its odd vertices are 1,3,...,2q-1. Define C by
replacing each parity's selected vertices by a prefix in this displayed order,
retaining the number selected in each parity.

The map C is monotone, cardinality preserving, parity preserving, and
idempotent. It also satisfies

    N(C(S)) subset C(N(S)).                              (1)

Indeed, an even-parity k-set has at least min(k,q) odd neighbors. For k<=q,
this follows either from consecutive-block counting or by matching all even
vertices except one unselected vertex to distinct adjacent odd vertices; for
k=q+1 the neighborhood consists of all q odd vertices. A nonempty odd-parity
k-set has at least k+1 even neighbors: each consecutive block contributes
its size plus one, and distinct blocks have disjoint neighbor intervals.
The appropriate prefixes attain these lower bounds, and their neighborhoods
are prefixes of the opposite parity. Thus each part of N(C(S)) is contained
in the same-cardinality prefix of the corresponding part of N(S), proving
(1), including mixed-parity S and empty parity parts.

The matching detail for the even lower bound is elementary: omit an
unselected even vertex 2j, match even 2i to odd 2i+1 for i<j, and to odd
2i-1 for i>j. These q matches are distinct.

For n=1 the path neighborhood is empty and C is the identity; the product
recurrence below remains valid with q=0. A completely edgeless product is
handled by the game's separate isolated-room convention rather than by
using movement to erase an uncaught target.

## 2. Why this preserves entire strategies

Apply C independently on every path fiber of G=H square P_n. The general
fiber-lifting lemma in `corner-ideal-exchange.md`, Section 5, proves (1) for
the lifted operator, even when H is not a box. It is still monotone,
cardinality preserving and idempotent.

The strategy-compression theorem in that note, Sections 2 and 5, then
proves that a fixed starting belief has an optimal strategy with every
belief and survivor fixed. Explicitly, if an original belief A leaves
survivors R, a simulated current belief B subset C(A) can inspect
`B minus C(R)`, using at most |A|-|R| shots. Its new belief is contained
in C(N(R)). Fixed sets are closed under intersection and neighborhood,
so starting from a fixed belief makes the simulation remain fixed.
The full board is fixed. No assumption about monotone play, contiguous
cleared regions, or a sequential treatment of parity cohorts was made.
This comparison respects any predetermined sequence of daily budgets.

If H is bipartite, one global checkerboard parity has only one path-parity
prefix in each H fiber. Both current parities therefore need two integer
vectors with |V(H)| entries each.

## 3. Exact physical neighborhood in vector notation

Fix a bipartite coloring chi:V(H)->{0,1}. Let A=|V(H)|. For current global
parity p, write

    epsilon_p(v) = (p - chi(v)) mod 2,
    c_0=q+1,  c_1=q.

A vector a=(a_v) with 0<=a_v<=c_(epsilon_p(v)) represents precisely the
vertices `(v, epsilon_p(v)+2j)` for 0<=j<a_v. Let b<=a be a survivor vector.
The exact next vector is Phi_p(b), defined by

    phi_0(k)=min(k,q),
    phi_1(k)=0 if k=0, and k+1 otherwise,
    [Phi_p(b)]_v = max(phi_(epsilon_p(v))(b_v),
                       max_{u adjacent v in H} b_u).          (2)

The maximum over no H neighbors is zero. The first term is the path
neighborhood of a prefix; every H-neighbor fiber contributes its unchanged
prefix. All these contributions occupy the same output path parity and
start at the same endpoint, so their union is a prefix whose length is
exactly the maximum. In particular (2) is an equality for the actual
physical belief, not a scalar relaxation. The capacity restrictions are
preserved because adjacent H vertices have opposite colors.

Represent a full mixed belief by (a^0,a^1), indexed by its current global
parities, rather than by the target's original parity. If survivors are
(b^0,b^1), the next mixed state is

    F(b^0,b^1) = (Phi_1(b^1), Phi_0(b^0)).                    (3)

The two vectors exchange their parity roles after the move. No extra day
or phase bit is needed with this convention. The number of inspected
possible rooms is exactly

    d(a,b) = sum_v (a^0_v-b^0_v + a^1_v-b^1_v).              (4)

To implement a transition, inspect precisely the suffix removed from each
of the two spacing-two prefixes in each path fiber. Thus every transition
also gives an explicit physical inspection set.

## 4. Exact optimum and feasibility

For a constant budget m, form a directed graph on all mixed prefix states.
Put an edge a -> F(b) whenever 0<=b^p<=a^p and d(a,b)<=m. The empty state
has distance zero. Then

    T_m(a)=1+min_{b<=a, d(a,b)<=m} T_m(F(b)),   a nonempty,  (5)

means the shortest directed-path distance to empty; infinity means there
is no such path. This shortest-path interpretation resolves any cycles.
The normal-form theorem proves equality with the unrestricted game's
minimum time. Following minimizing edges gives an optimal strategy.

A single recurrence can find every budget at once. Let W_t(a) be the least
constant daily budget that clears a within t days. Set W_0(empty)=0 and
W_0(a)=infinity for nonempty a. Then

    W_(t+1)(a) = min_{b<=a} max(d(a,b), W_t(F(b))).          (6)

Again W_t(empty)=0. This is a finite min-max recurrence with completely
explicit integer bounds and maps (2)-(4). Backpointers recover probes.
For a varying budget sequence, replace (6) by the corresponding Boolean
backward recurrence and require d(a,b) to fit that day's budget.

For each H vertex there are q+2 choices for its even-prefix count and q+1
choices for its odd-prefix count. Thus the exact number of mixed states is

    K = ((q+1)(q+2))^A <= (n+1)^(2A).

Each state has at most K survivor-vector choices. Explicitly constructing
all transitions takes O((A+|E(H)|) K^2) elementary operations, with a
possible factor for integer bit arithmetic. For fixed H this is polynomial
in the odd longitudinal length n. A fixed-budget breadth-first search of
the reverse graph then decides feasibility and minimum time. Since every
successful path can have cycles removed, time at most K-1 suffices; the
all-budget recurrence stabilizes by that bound.

This is an exact algorithm for every odd cylinder with fixed transverse
bipartite graph. It is not a dimension-independent efficient algorithm,
not a closed formula for all box side lengths, and not a fixed transition
matrix as n varies: the state bounds and the clipping in (2) change with n.

## 5. What the canonical states are

If multiple coordinates have odd length, their path compressions may be
combined, using the coordinate sum as a strictly decreasing potential.
The common fixed sets satisfy `v -> v-2e_i` whenever that predecessor exists.
They are coordinatewise ideals separately in each coordinate-parity pattern.
This is weaker than the usual checkerboard corner-ideal condition, which
also compares points whose several coordinates change parity. For example,
{(1,1)} in a 3-by-3 square is fixed by these path operators but does not
contain its coordinatewise-smaller even-parity vertex (0,0).

Equal-length coordinate pairs may additionally use the proved diagonal
operators. All operators share a decreasing weighted-coordinate potential,
so their stabilized composition still preserves optimum strategies.

## 6. Bounded independent checks

`src/square_strategy_compression.py` now exposes `odd_path_operator` and
`include_odd_paths=True`. `research/odd-path-compression-checks.json` checks
all parity subsets on P3, P5, P7, 3-by-4, 3-by-5, 5-by-5 and 3-by-3-by-3:
cardinality, every one-vertex monotonicity relation, neighborhood inclusion,
composed idempotence and fixed-family neighborhood closure. The run took
about 0.37 seconds. Combined path/equal-pair fixed counts are 30 and 24 for
3-by-5, 20 and 18 for 5-by-5, and 22 and 20 for 3-by-3-by-3.

## 7. The transverse graph need not be bipartite

For arbitrary H, index the two vectors by parity of the path coordinate
instead of global checkerboard color. The exact next state is

    next_even(v)=max(phi_1(b_odd(v)), max_(u~v) b_even(u)),
    next_odd(v)=max(phi_0(b_even(v)), max_(u~v) b_odd(u)).

The same compression proof, inspection cost, state count and complexity
apply. Thus the exact fixed-H polynomial recurrence is valid for every
finite transverse graph H when n>=3. The bipartite version in Sections
3-4 remains useful for comparisons indexed by global parity. The complete
manuscript states the more general form in `paper/sections/compression.tex`.

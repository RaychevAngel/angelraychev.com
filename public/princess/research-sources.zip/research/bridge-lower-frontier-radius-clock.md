# A radius-aware clock with a local Bellman inequality

13 September 2026. Ordinary derivation building on the reviewed paired
localization and lens lemmas. This supplies a uniform lower potential;
it does not establish that its value equals the physical prefix clock
at the unrestricted boundary K for every width.

## An anchored surplus profile

Write w=2b+1, n even with n>=2b+2, k=b+1, K=b²+b+1, and
D=w+n-2. Restrict to the low sector of supports of size at most K.
For positive q put

    alpha0(q)=min(ceil(sqrt(q)),b),
    alpha1(q)=min(min{r:q<=r(r-1)},b+1).

Both are zero at q=0. The accepted square and corner-free pronic
profiles give these respective neighborhood-surplus lower bounds.
Their high branches cannot improve either bound in this sector:
h-q>=b²+2b at the smallest permitted board.

Suppose a support is contained in a radius-R ball about an anchor o.
The anchor has relative color p, where p=0 means the current support's
color and p=1 the opposite color. On p=0 days retain alpha0.
On p=1 days define the following stronger necessary profile g1(q,R).

* If R<n-1, no own-colored corner can occur, so use alpha1(q).
* Otherwise start with alpha0(q). If R<D and q>b², use b+1.
  For each 1<=r<=b with
  r(r-1)<q<=r², replace the value r by r+1 whenever

      q > L_r(R),
      L_r(R)=r²-F_r(floor((R-n+1)/2)),
      F_r(t)=Tri(r-1-t)-2Tri(-1-t)+Tri(-r-1-t),
      Tri(z)=max(z,0)(max(z,0)+1)/2.

Set g0(q,R)=alpha0(q), and g0(0,R)=g1(0,R)=0. The definition at
R>=D is the uninformative-anchor case; then every L_r(R)=r².
The radius R itself is an integer upper bound; no parity adjustment is
needed beyond the floor in the formula.

First take r<b. To prove the replacement, suppose a q-room survivor in
the indicated strict square band had surplus exactly r. The low corner capacities
force survivor corner count one and outgoing corner count zero:
the i=0 or outgoing-positive capacities are at most r(r-1), while
i=2 has capacity 1+(r-1)²<=r(r-1). The high branch is excluded by
h-q-r>r², and r<b excludes the critical exception. The reviewed
near-square theorem therefore places the survivor inside Q_r about
an own-colored corner. For r=1 this is simply the fact that a vertex
of degree two is a board corner. The old anchor has the opposite
color. The maximum possible intersection of its radius-R ball with
Q_r is exactly L_r(R), by the aligned-corner lens count. This
contradicts q>L_r(R). The original surplus must consequently be at
least r+1. No new orientation variable has been introduced.

At r=b, the condition q>L_b(R) itself implies R<D, since the
radius-D ball contains the whole board. The old opposite-anchor ball
then excludes one own-colored board corner, so i2 is impossible.
The remaining critical i1 case localizes in Q_b even without equality:
in the nonseparator proof the actual even prefixes have lengths at
most b-q at column2q, and each intervening odd fiber is contained
in the following shorter even prefix. Both lie in x+y<=2b-2.
The separator case uses the same quadrant near-square argument.
This critical interval extension is detailed in the terminal-family
note and was independently reviewed by the parent and upper lanes.

When q>b² and R<D, the critical surplus b is also impossible: every
low critical capacity is at most b², the high branch is excluded for
q<=K, and i2 is excluded by the radius. Hence the added value b+1 is
necessary. When R=D, all additions are vacuous.

For fixed R, each g_p(q,R) is nondecreasing in q. Inside a square band,
the only extra jump is the condition q>L_r(R); at the next root value
the base profile catches up with the previous value. The q>b² clause
preserves monotonicity past the critical band when R<D; at R=D the
profile is alpha0 throughout. The functions are also nonincreasing in R.

## The clock and its one-step proof

Define H_p(a,R) as the capture time of the deterministic recurrence

    a=0: stop;
    q=max(0,a-k);
    q=0: stop after this inspection;
    otherwise a <- q+g_p(q,R), p <- 1-p, R <- min(D,R+1).

The clock is finite: its step sizes are no larger than those in the
physical anchored prefix recurrence. Monotone coupling shows that H
is nondecreasing in a and nonincreasing in R.

Initially state the next inequality for a physical step whose source A
and target A' both have size at most K. The survivor has
q_actual>=max(0,a-k), and remains in
the old radius-R ball. Hence monotonicity of q+g_p(q,R) gives

    |A'| >= max(0,a-k)+g_p(max(0,a-k),R)

whenever the survivor is positive. The next support inherits the same
anchor with relative color 1-p and radius min(D,R+1). Therefore

    H_p(|A|,R) <= 1+H_(1-p)(|A'|,min(D,R+1)).       (BELL)

The clearing case has H_p(|A|,R)<=1. A later localization may replace
an anchor by another of the same relative color and tighten the radius.
Since H is nonincreasing in R, this only increases the right side.
Thus the certificate does not assume that one named corner remains the
effective orientation throughout the remaining history.

With the two persistent coordinates, the combined potential is

    Psi(a,rho0,rho1)=max(H_0(a,rho0),H_1(a,rho1)).

Propagation swaps the two coordinates, and the same argument proves
Psi(source)<=1+Psi(target). Each reset can only strengthen this
inequality. This is a uniform, scalar-valued potential built from two
anchored clocks; it charges every possible orientation change through
the same local geometric surplus test, rather than allocating one
global unit of correction to the first change.

This profile also respects the guarded merger. A merged transition in
a strict square band with surplus r<=b and incoming corner count one is an identity merger
by the reviewed interval-reset proof. The zero-cost full partner has
opposite-anchor radius D, as is already forced by its corner count two.
Consequently any informative merged opposite radius R<D is witnessed
by the non-full component, whose source, survivor and target sizes are
identical to the merged transition. Its physical lens inequality
therefore applies. For R>=D the added profile condition is vacuous.
The no-own-corner restriction and the exclusion of critical i2 are
already covered by the componentwise corner merger inequality. The
q>b² clause then uses the accepted critical corner dichotomy directly.

## Clipping extends the potential beyond the low sector

Define Hbar_p(a,R)=H_p(min(a,K),R), and use Hbar in Psi. This satisfies
the same one-step inequality for every physical source and target, even
if a history leaves the low sector. Indeed put

    q0=max(0,min(|A|,K)-k).

There is a q0-room subset W of the actual survivor. It inherits the
old radius certificate, q0<=K, and N(W) is contained in the actual
target. The low-sector surplus profile therefore gives

    |A'| >= q0+g_p(q0,R).

The right side is at most K. Consequently the same inequality holds
with min(|A'|,K) on the left, and the monotone H comparison proves
BELL for Hbar. When q0=0 the source clock is at most one and the
claim is immediate. This argument uses an actual subset only to prove
the physical inequality; it adds no state to the evaluator.

The clipped inequality also inherits the guarded count merger without
postulating a geometric merged subset. Let q be its actual merged
survivor count. If q>=K, its target count is at least q by nonnegative
surplus, so the target's clipped size is K and the clock comparison
is immediate. If q<K, the already established low-sector merged
profile applies, with q>=q0. Monotonicity gives the required size
floor. This includes the strict-band lens step through the identity
argument above. Thus a separate prohibition on excursions is not
needed for the clipped potential.

The unresolved issue is the value of Psi at the unrestricted K boundary:
both radius coordinates may initially be D, and this clock may then
reduce to the weaker scalar profile before any reset forms. The Bellman
inequality alone does not prove the conjectured terminal hull or a
uniform matching full-board formula.

## An exact anchored region that follows immediately

Let tau_p(a) be the physical fixed-corner prefix clock. If a support
has an anchor certificate (p,R) and

    R+tau_p(a)-1 < n-1,

then no opposite-anchor-color belief can contain an own-colored corner
during a hypothetically faster capture. On such days the pronic bound
applies, and on the other days the square bound applies. Induction
against the fixed-corner size recurrence excludes capture before
tau_p(a). For a<=K this also follows from the clipped potential, even
if the attempted history leaves that sector. Equivalently, H equals tau_p(a)
throughout this sufficient region. This is a uniform terminal locking
criterion; it does not assert that every history enters the region
without first gaining time.

## A precise remaining charge inequality

Call a transition sharp when its survivor lies in a strict subcritical
square band r(r-1)<q<=r² and its surplus equals r. It creates the
reviewed own-corner triangle certificate; its target has relative
phase one and radius 2r-1. Between consecutive sharp events, if all
survivors remain at most b(b-1), every strict-square-band step pays
at least r+1. Neutral-band steps already pay at least r. Hence that
entire intervening segment obeys the single pronic map

    P(a)=max(0,a-k)+alpha1(max(0,a-k)).

This statement permits less than k inspections and larger surplus:
both only increase the next size. It is not a claim that physical
survivors automatically stay in this subcritical sector.

Start just after a sharp event with

    r0²<a<=r0(r0+1), R0=2r0-1, relative phase one.

Suppose the next sharp event is t steps later, with survivor q in
the r-square band. Its new anchor has opposite color to the old one
exactly when t is odd. For such an orientation change the necessary
scalar and lens inequalities are

    q >= max(0,P^(t-1)(a)-k),
    r(r-1)<q<=r²,
    q <= L_r(2r0+t-2).

The following is a precise sufficient numerical lemma still to prove:

    these inequalities imply t+tau1(q+r)>=tau1(a).       (CHARGE)

Even t already follows from the anchored comparison: every earlier
step paid at least its anchored profile, and the final square step
has the original anchor color. If CHARGE holds for odd t, induction
over consecutive sharp events would handle repeated orientation
changes within the subcritical sector. Critical-band excursions and
the entrance from unrestricted K still need separate treatment.
Neither CHARGE nor this proposed reduction to a complete terminal
theorem is asserted proved here.

There is an exact way to measure the rounding credit in this proposal.
Write S=F0, P=F1, J(a)=tau0(a)+tau1(a), and
Delta(a)=tau1(a)-tau0(a). For positive states before capture, the two
clock recurrences give

    J(P(a))=J(a)-2+C(a),
    C(a)=tau1(P(a))-tau1(S(a))>=0,

and

    J(S(a))=J(a)-2-D(a),
    D(a)=tau0(P(a))-tau0(S(a))>=0.

Let x=P^(t-1)(a), with all intervening P states positive. For the
smallest unconstrained survivor q=x-k, the charge inequality is
equivalent to

    sum_(j=0)^(t-2) C(P^j(a))
        >= D(x)+Delta(a)-Delta(S(x)).

If a candidate band's lower endpoint or the actual history raises q,
its final target is at least S(x), so the displayed inequality remains
sufficient, although no longer necessary. If a P iterate has already
reached zero, then its capture clock bounds tau1(a) from above and
CHARGE is immediate. These identities account for the discrete phase
rounding exactly. The remaining task is to derive the required credit
from the lens condition or a sharper last-event bound; one cannot
replace C by a count of surplus rooms without justification.

At the requested wrap, the parent had independently checked CHARGE
on19263 admissible small-parameter tuples (b2 through20), and24766
selected proportional-regime tuples at b31,64,127,256,511,1000.
These checks passed; they do not prove CHARGE. The receipts are
`bridge-sharp-event-charge-check.json` and
`bridge-sharp-event-stress-check.json`, with their checkers named in
the parent lane. No further search was launched after the wrap request.

The upper lane supplied one additional sufficient reduction. For the
capped low prefix maps, the two backward phase thresholds differ by
at most one at every deadline, so tau0(z)<=tau1(z+1) and conversely.
Compare a P-only intervening segment with the alternating old-anchor
prefix. Its size lag never decreases before capture. Every even
pre-event step whose P survivor lies in a strict square band adds at
least one room of lag. Two such visits therefore leave at least one
room of lag after paying the final wrong-phase square discount;
the one-room phase comparison proves CHARGE in this case. What remains
is to exclude or analyze lens-admissible segments with zero or one such
visit. This is a sufficient reduction, not a proof that the lens forces
two visits. The threshold Lipschitz argument concerns the capped low
maps only and is not asserted for the full-board high branch.

The global clipped clock and the critical square interval extension
were accepted independently by the parent and upper lanes. Their
ordinary proofs are now also in
`paper/sections/bridge-local-geometry.tex`. A static audit found no
missing references, duplicate labels in that section, or unmatched
environments. No paper build or Lean formalization was performed by
this lane during the wrap.

Sources: `bridge-lower-frontier-terminal-family.md` (paired resets and
SWITCH), `bridge-lower-frontier-lens.md` (closed lens and merger),
and `bridge-lower-frontier-corner-reach.md` (persistent coordinates).

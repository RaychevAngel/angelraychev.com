# Independent semantic audit of the 40-day four-cube theorem

12 September 2026. Reviewer: the independent recurrence/formula lane.

**Pass.** The new lower and upper Lean statements prove that the exact
capture time on the actual 4 by 4 by 4 grid, with eight inspections each
day, is forty days. No additional restriction on the original strategy or
target paths is hidden in the final statements. This follows the separate
normalizer review in `four-cube-normalform-independent-review.md`.

Reviewed: `FourCubeIdeals.checker_sound`,
`FourCubePotentialSemantics.encoded_transition`,
`FourCubePotentialState.state_step`,
`FourCubeCriticalLower.actual_lower_40`,
`FourCubeUpper.actual_upper_40`, and their generic forced-predecessor
checker and physical normal-form dependencies.

The generic `FiniteIdealCertificates.check_sound` does not assume a supplied
list of 292 states is exhaustive. Its target mask is arbitrary; coverage of
all selected coordinates, the supplied down-mask closure, and self-membership
let it follow the appropriate forced/include/exclude branch of the checker.
At a leaf the constructed mask equals the arbitrary target mask. The cube
bridge proves that every normalizer-fixed set is closed under the supplied
down masks by a strictly decreasing physical energy route. This rules out
an unverified enumeration assumption in the lower proof.

The mask records are data. Separate exhaustive facts checks identify their
cardinalities and actual open neighborhoods. `encoded_transition` uses the
checker once for an arbitrary closed source and again for every closed
residual subset. Both the subset condition and the useful-probe cost
card(A)-card(R)<=8 are interpreted back as physical subsets. No condition
requires the residual to be a special chosen prefix inside that source.

The charge is zero for at most three probes, one for four probes, and two
for at least five. The checked shared-budget inequality is
charge(p)+charge(q)<=2 whenever p+q<=8. The state bridge proves that the
two useful parity allocations sum to at most the cardinality of the actual
inspection set; arbitrary wasted probes are harmless. Parity flips under
every actual grid edge, so the two next-cohort potentials are exactly the
two parity parts of the next physical belief. Initial potential is eighty,
terminal potential is zero, and each day reduces it by at most two.

The normal-form equivalence applies to arbitrary actual inspection schedules
from the full board. It supplies both closed pre-inspection beliefs and
closed post-inspection survivors, precisely the hypotheses needed by
`state_step`. Its use in `actual_lower_40` therefore removes those normal-
form restrictions from the resulting lower theorem. The statement's
`last+1` counts days consistently with the zero-based final round.

The upper theorem independently replays forty explicit inspection masks
against the actual cube adjacency, checks each has at most eight rooms,
and proves the resulting belief is empty. The existing no-dead-ends bridge
then translates this post-movement recurrence into guaranteed capture by
round 39, namely day forty. It does not rely on the lower certificate.

Fresh single-worker compilations of the final lower and upper modules both
passed using existing dependencies; both axiom reports contain only
`propext`, `Classical.choice`, and `Quot.sound`. This is not a fresh full
dependency rebuild. A separate Python replay rebuilt the adjacency directly
from coordinate differences, read the forty inspection masks, and confirmed
their budget and first empty survivor set on day forty. The receipt is
`four-cube-final-semantic-replay.json`.

No source correction was necessary. This review is specific to budget eight;
the all-budget classification and any independent feasibility theorem are
separate claims.

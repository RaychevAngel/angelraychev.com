# Period-size audit and the universal-loop improvement

12 September 2026. These numbers describe sufficient constants in our
proofs, not lower bounds on the true periods or the actual computation
needed for any particular cylinder.

The first accepted even-order and odd-order/even-length proofs used
respectively

    M_even = 8·5^(A/2-1),
    M_odd  = 8·2^(A-1)

as universal frontier-state bounds, then chose a multiple of every
integer from 1 through M to make scattered-cycle deletion automatic.
At the smallest feasible budget, both selected the physical period

    2·lcm(1,...,M).

This is effective but impractical even for very small cross-sections:

| Transverse order A | Old state bound M | Decimal digits in chosen old period |
|---:|---:|---:|
| 2 | 8 | 4 |
| 3 | 32 | 15 |
| 4 | 40 | 17 |
| 5 | 128 | 56 |
| 6 | 200 | 90 |
| 8 | 1000 | 434 |
| 9 | 2048 | 887 |

The table was computed by summing logarithms of the largest powers of
each prime at most M. No enormous integer was formed. Reproduction:
`src/even_bridge_period_sizes.py`; receipt:
`research/even-bridge-period-sizes.json`.

The reason for this blowup was the choice to remove subwalks already
present in the original strategy, with lengths summing to one universal
large number. It was not evidence that the frontier dynamics had long
fundamental periods.

Root's subsequent universal height-loop argument removes this obstacle.
The full proof is `even-bridge-height-loop-period.md`, independently
reconstructed by the frontier lane and subsequently accepted by Euler's
separate audit of all eight sections. It gives, for D=2m-A and g=gcd(A,D),

    physical period Delta = 2D/g,
    total time increment = 4A/g.

At minimum budget Delta=2 for every A>=2. The proof replaces a crossing
segment with a different legal same-endpoint path rather than only
deleting cycles from the original walk. Every state has a common short
loop, and all closed walks have lengths divisible by its length.
No global strong-connectivity assumption is needed.

The intermediate loop argument has normalized shape bound 2^A for one
fixed orientation and a singly exponential sufficient onset bound.
The subsequently accepted direct endpoint construction in
`even-bridge-height-descent-onset.md` eliminates this enumeration too:
its sufficient onset bound is polynomial in A and m, conservatively
O((A+m+1)^9). These are upper bounds from the proof; they do not compute
the offsets or solve all finite boxes. The old enormous constants are
retained here as the history of superseded proof methods.

# Independent consistency review of the new odd-rectangle manuscript

13 September 2026. Euler review of the first theorem/proof in
`paper/sections/odd-minimum-budget.tex`, and the new fastest-ancestry lemma,
eventual scalar theorem, and corner-ammunition proposition in
`paper/sections/bounded-odd-frontier.tex`. **PASS.** No source edits requested.

The minimum-budget statement preserves all guards: odd `n≥w=2b+1≥3`,
budget `b+1`, and a terminating width-only clock rather than a claimed
elementary expression for that clock. Its `b=1` clause avoids evaluating
the negative input `C−1`. The last tie, the `L_b` precentral tail, and the
consecutive solo durations are consistent with the reviewed research proof.
The central obstruction uses actual cohort ancestry and the fresh-secondary
bound, not a comparison between the two numerical coordinates. The slower
solo's residual exceeding the budget supplies the strict last-day exclusion.
The generic insertion lemmas retain their separate scope.

The fastest-ancestry lemma uses the stronger direct concentration argument
verified in the new Lean component. A high mixed successor must have a high
predecessor. If the predecessor's primary is in color zero, concentration
bounds its total by `D0`; the second inverse inequality puts the successor
total below `D1(next)`, hence its high primary in color one. The symmetric
case uses the first inequality. Positivity and proper-input guards are
explicit, and pure successor replacement is justified by the preceding
retention lemma. There is no arbitrary-partial-state seriality assumption.

For the eventual scalar theorem, the generous threshold
`M*=2J+Γ+m(W+3)` ensures the first entry with both solo capacities at least
`J` precedes capture. Its larger capacity is at most `J+Γ+m−1`, so at
least `W` safe transitions remain below `M−J`. The established age bound
then aligns each retained history's ancestry-primary with its larger
coordinate. After safe exit, a bounded secondary can grow to at most
`K+m`; an attempted role swap makes the total at most `2K+m<J`, hence
nonexceptional. Thus the final-collar alignment is maintained. The final
two-copy argument and threshold `M−2K>m` are correct. The theorem expressly
leaves shorter rectangles to the existing exact bounded calculation.

The corner-ammunition proposition concerns the unbounded bottom inverse
maps, with no reflected finite-board branches. Deleting probes preserves
the per-day quota and fixed phase, and one-unit Lipschitz output change
gives both exact-target attainability and monotone excess. The last-step
minimum covers predecessors both below and above the target input.
For `m≥b+1`, the predecessor strictly decreases in one phase and never
increases in the other, proving termination. Its inspection-before-movement
clearing identity has the correct inverse phase and first-day timing.
The text correctly distinguishes total-ammunition optimality from fixed-time
serial optimality in the full two-cohort game.

The final formalization paragraph retains explicit inverse and secondary
hypotheses and leaves the clock, geometry, and safe-interval instantiations
as ordinary mathematics. No full Lean rectangle classification is implied.

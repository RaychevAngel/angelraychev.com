# Width-parametric terminal clocks and interval radius resets

13 September 2026. Research beyond the proved uniform width25 family.
The general terminal statement below is a proposal, not a theorem.

## The candidate boundary statement

For odd width `2b+1`, minimum quota `b+1`, and even length at least
`2b+2`, set `K=b²+b+1`. Let `tau0(b),tau1(b)` be the two physical
infinite-corner prefix clocks from K; they are explicitly computed by
the already proved square/pronic root profiles. The useful proposed
terminal inequality is:

    from (K,0,e), remaining time >= tau1(b);
    from (K,c,e), c>=1, remaining time >= tau0(b).

This is not a claim of a universal one-day improvement over the old
model. In most checked widths, the unflagged corner/erosion frontier
already distinguishes those boundary features correctly.

Bounded exact-triangle-radius checks covered
`b=6,7,8,9,10,11,12,13,14,15,16,17,19,20`, initially at `e=0`.
All except b11 match the proposed clocks in the tested model. Width25
(`b=12`) needs the new persistent radius information, whereas the other
matching cases already have the relevant old corner deficiency.
The even and odd parameter receipts are
`bridge-lower-frontier-terminal-family-check.json` and
`bridge-lower-frontier-terminal-family-odd-check.json`.

The b11 exception disproves the proposed statement for the model with
only exact-triangle radius resets: at K133 it permits clocks62 for c1/2
and63 for c0, versus physical prefix clocks63 and64. No physical faster
strategy follows from that relaxation.

## A uniform interval reset, rather than a new shape statistic

Let `2<=r<b`. If a survivor U satisfies

    r(r-1)<q=|U|<=r²,   c(U)=1,
    |N(U)|-|U|=r,

then U is localized inside the r-square corner triangle. This follows
from the subcritical finite-board quadrant decomposition, exclusion of
the high branch, and the accepted near-square localization theorem.
Its target lies within radius `2r-1` of that same corner, of relative
anchor color one. Thus tighten the persistent coordinate `rho1` to
at most `2r-1`, exactly as for a full-square survivor.

The target necessarily has `(c,e)=(0,1)`. The radius excludes both
own-colored board corners, while the anchor's two neighbors are in
N(U) because the anchor belongs to U. The other opposite-colored corner
cannot have both neighbors in that radius. Its next target has erosion
zero by the radius-distance bounds.

This trigger preserves the guarded merger. If both original component
surpluses were positive, each would be at most r-1. A small component
would imply merged survivor size at most `(r-1)²<r(r-1)`, impossible.
Two high components would bound the merged target's holes by r², while
`h-|N(U)|>=h-r²-r>r²`. A critical exception is unavailable. Hence a
zero-surplus component exists; the empty alternative contradicts the
positive guarded merged survivor. The other component is therefore
merged with a full-to-full zero-cost partner and receives the identical
radius reset. The already reviewed two-coordinate invariant then
transfers all later radius restrictions.

## Why the diagnostic redirects only forced events

For source size a, exact inspection cost p and target size T, survivor
size q=a-p and original surplus r=T-q are fixed. The new diagnostic
redirects an edge only when the target counts are `(0,1)` and the above
strict interval holds. Every admitted witness then has survivor corner
count i1: i2 violates `i<=v=1`, whereas i0 would give closed surplus r-1
and closed survivor size q+1 greater than `(r-1)²`, excluding the low
branch; the high branch is also impossible. Survivor erosion is zero
because `u<=j=0`. Thus there is no untriggered alternative witness hidden
behind one of the redirected edges.

The new interval variant is isolated in
`src/bridge_lower_frontier_interval.py`. It does not change the minimal
exact-triangle model used by the proved width25 family.

## Paired square and pronic reset lemma

The same two-radius state supports a companion interval reset. For every
`2<=r<=b`, put `A_r=(r-1)(r-2)` and `C_r=r(r-1)`. A transition with

    survivor corner count i=0, target corner count j=1,
    A_r<q<=C_r, original surplus r,

localizes the survivor within radius `2r-3` of the unique target corner.
Consequently its target receives coordinate-zero bound `2r-2`.
This is precisely the already reviewed all-radius localization theorem
with the outgoing corner supplied. The lower threshold D_r is unnecessary:
multiple sharing-neighbor components have total area at most A_r, lower
surplus has area at most A_r, and the known outgoing corner excludes the
critical nonseparator branch. Its target erosion is zero by the same
corner-distance argument.

This wider pronic trigger also preserves the guarded merger. A merged
target with J1 forces both component outgoing corner counts to be
positive. If both original surpluses are positive, each is at most r-1.
Any small component then has source size at most

    Phi_(i,j)(s) <= s(s-1) <= (r-1)(r-2)=A_r   (j>=1).

The merged survivor cannot exceed the small component's survivor, so this
contradicts q>A_r. If both components are high, the already proved high
merger bound is at most r², while the merged target has size at most
`C_r+r=r²` and hence more than r² holes. Thus a zero-surplus component
exists. The positive guarded merged survivor excludes the empty case,
leaving a full-to-full zero-cost partner. Formation is again an identity
merger. Propagation of both interval reset types is therefore covered by
the same per-coordinate persistent-radius invariant.

The parent independently reviewed this wider pronic argument. Its
implementation uses target `(j,v)=(1,0)`, which forces every survivor
witness to have i0. Target T lies in `A_r+r<T<=r²`; these target-size
intervals are disjoint as r varies, and r is recovered as `ceil(sqrt(T))`.
The square interval target ranges lie in the intervening opposite-color
bands. The diagnostic keeps the original exact endpoints and adds only
the partial-triangle cases, preserving all valid alternative witnesses.

Together these are a uniform paired-reset lemma, not a theorem that the
resulting terminal clocks equal the physical prefix clocks for all b.

## Critical square intervals with one incoming corner

The square interval localization also holds at r=b when the actual
survivor corner count is one. This strengthens the earlier equality-
only critical observation. In the critical corner proof's nonseparator
case, reflect so that U_(2b) is the empty endpoint. Every even fiber
U_(2q) is an actual prefix of length at most b-q. The odd fiber
R_(2q+1) is contained in U_(2q+2), hence in the prefix of length
b-q-1. Under the physical map (x,j) to (x,2j+(x mod2)), both give

    x+y<=2b-2.

No fiber needs to attain its maximum: the entire support lies in Q_b.
In the separator case, the same near-square quadrant argument applies;
it needs the two separators, not a strict surplus bound. The range
b(b-1)<q<=b² and surplus b excludes the high branch. Thus the target
again receives opposite-anchor radius2b-1. The critical i2 exception
is deliberately excluded by the hypothesis i1.

The identity-merger proof is unchanged: two positive component
surpluses would each be at most b-1; a low component has at most
(b-1)² rooms, whereas two high components contradict the hole bound.
This critical interval proof was independently accepted by both parent
and upper lanes. It is not needed by the original width25 finite proof.

The first successor after this critical reset may have both own-colored
corners: its radius is2b=w-1. Its erosion remains zero. Any future
implementation extending the interval loop to r=b must therefore use
next-target c<=2,e=0 there, rather than the subcritical c<=1,e=0 filter.
The grouped radius evaluator itself already has the correct bound.

## The concrete b11 obstruction

The fastest old terminal path first beats the physical prefix in size
at day44, but its missing localization occurs earlier:

    day33: survivor99, surplus10 -> target109 (c0,e1);
    day34: survivor97, surplus11 -> target108 (c0,e1).

The first survivor has only one missing room from Q10 and therefore
localizes its target within radius19. The following target is contained
within radius20; it must have erosion zero, since the nearest adjacent
opposite-colored corner needs radius24 to contain both neighbors.
The recorded erosion one is impossible. Exact-equality flags missed
this reset because the survivor had99 rather than100 rooms.

Adding the uniform interval reset raises the c1,e0 terminal clock from62
to63, matching its physical prefix. The bounded searches inspect every
admitted edge after the same monotone radius dominance reduction already
independently reviewed. Receipts:
`bridge-lower-frontier-b11-exact-witness.json` and
`bridge-lower-frontier-b11-interval-witness.json`.

The broader proof task is to show that switching the active corner
orientation requires enough days without a sharp surplus to offset its
apparent time saving. The two radii and these interval resets provide
the candidate accounting state. The finite pattern does not establish
that argument uniformly in b.

## A quantitative cost for the first opposite-corner localization

Suppose the current support A lies in a full square corner triangle Q_r
of its own-colored anchor o, has `|A|=r²-d` with `0<=d<r`, and also
retains an older radius-R certificate about an opposite-colored anchor.
Then necessarily

    R >= n+2r-3-2 floor((sqrt(8d+1)-1)/2).                 (SWITCH)

This uses the same two radii, without identifying their anchors. For
opposite-colored anchors, the maximum overlap occurs when they are
aligned at opposite ends of the even n-side. To see this, reflect o
to (0,0). On each horizontal row, Q_r is a left prefix. The ball at
(0,n-1) is another left prefix, while the ball at (w-1,n-1) is the
reflected right prefix with the same row-color cardinality (w-1 is even).
The left-prefix overlap is at least the left/right overlap. Thus the
aligned case gives the weakest necessary bound.

In that case the old ball requires `x-y<=R-(n-1)`. Since its anchor has
the opposite color, a finite useful radius R is odd; write
`t=(R-(n-1))/2`. If t<0, it omits at least r(r+1)/2 rooms of Q_r, more
than the permitted defect d. Thus t>=0. For `0<=t<=r-1`, on diagonal
`x+y=2j` it omits `max(0,j-t)` rooms, so its total omitted count is

    (r-t-1)(r-t)/2.

The count is zero for t>=r-1. Requiring it to be at most d gives exactly
the bound (SWITCH). Saturated infinity certificates impose no bound.

If the old certificate was introduced A steps earlier with radius R0,
and no stronger certificate of that relative color intervened, then
`R<=R0+A`. Therefore (SWITCH) supplies the elapsed-time lower bound

    A >= n+2r-3-2 floor((sqrt(8d+1)-1)/2)-R0.

For example, a99-room support in Q10 on a length24 board requires an
opposite-anchor certificate radius at least39. Merely reaching the new
corner would have required only23. The extra requirement comes from
placing almost the entire new triangle inside the old reachable ball.
This is an ordinary necessary geometry inequality. Turning it into a
uniform terminal-clock lower bound still requires charging this delay
against the possible phase-clock gain.

For a formula with no separate radius cases, write
`Tri(x)=max(x,0)(max(x,0)+1)/2` for integer x and
`t=floor((R-n+1)/2)`. The exact number of Q_r rooms outside the aligned
old ball is

    F_r(t)=Tri(r-1-t)-2 Tri(-1-t)+Tri(-r-1-t).

Indeed each diagonal u contributes
`max(0,u-t)-max(0,-u-t-1)`, and the two finite arithmetic sums telescope
to that expression. This formula includes negative t and radii beyond
the whole triangle. It also handles an even upper radius R by the floor,
since actual distances to the opposite-colored anchor are odd.

## Reducing a clock improvement to a first orientation change

In the low terminal sector, fix the color of one reference corner and
follow a physical history while all its beliefs have size at most K.
Until a belief of the opposite color first contains a corner of its own
color, the belief sizes are bounded below by the fixed-corner physical
prefix recurrence from the starting size and phase. On the reference-
color steps the unconditional small square profile, capped at b, gives
the corresponding neighborhood lower bound. On opposite-color steps
the survivor has no own-colored corner, so its small profile is the
pronic bound, capped at b+1. The high branch is unavailable in this
terminal range. Monotonicity of the two cardinality maps proves the
comparison inductively. The reference corner itself may be inspected
away; its absence does not change which root profile is valid.

For the two physical clocks tau0(a),tau1(a) in this range, each daily
map f_p(a) is at most a, and the clocks are monotone in a. Hence

    tau_p(a)=1+tau_(1-p)(f_p(a))<=1+tau_(1-p)(a),

so their difference in absolute value is at most one. Neither phase is
always the faster one: bounded checks give differences -1,0,+1 at
different sizes. Assigning a phase solely from the current corner count
is therefore invalid; the retained radius certificate carries distinct
information about the orientation even when its origin room is absent.

The desired amortization would charge each actual orientation change
against the waiting time in (SWITCH), or the radius-sum lens inequality,
before a large support can be localized at that new corner. A proof must
handle repeated changes, not just spend one global unit of slack. That
charging argument remains open in this lane.

## A bounded stress test at budget 24

The next selected arithmetic stress case was b23, on 47x48 with quota
24 and boundary K553. The physical prefix clocks are162 and163.
The exact-triangle model from (553,0,0) still permits162. Adding only
the lens keeps that shortcut, whereas paired interval resets together
with the lens require163. This is finite evidence for one boundary
feature, not a variable-width theorem or a claim about all nine features.

The completed paired-plus-lens evaluation used no dominance between
different radii: it explored613434 augmented states and702 radius
pairs in2.750 CPU seconds. Its implementation and trigger/filter order
were independently reviewed by the upper lane. Receipts:

* `bridge-lower-frontier-b23-exact-check.json`: exact-only162,
  independent evaluator,6.253 CPU seconds.
* `bridge-lower-frontier-b23-exact-lens-check.json`: exact-plus-lens162,
 348897 augmented states,1.809 CPU seconds, including a shortest witness.
* `bridge-lower-frontier-b23-paired-lens-check.json`: paired-plus-lens163.

Two diagnostic variants deliberately stopped at their CPU caps. An
exact-only witness reconstruction stopped atdepth159 after4.830 CPU
seconds; paired resets without the lens stopped atdepth93 after3.705
CPU seconds. Neither stopped run determines its clock. The combined
five-run stress budget was19.35 CPU seconds. No further width catalogue
was run to support the conclusion.

The shortest exact-plus-lens witness first violates the paired geometry
at the following consecutive steps (all inspection costs are24):

| Day | Source (a,c,e) | Survivor size | Surplus | Target (a,c,e) |
| --- | --- | --- | --- | --- |
| 111 | (419,0,1) | 395 | 21 | (416,1,0) |
| 112 | (416,1,0) | 392 | 20 | (412,0,1) |
| 113 | (412,0,1) | 388 | 21 | (409,1,0) |
| 114 | (409,1,0) | 385 | 20 | (405,0,1) |
| 115 | (405,0,1) | 381 | 21 | (402,0,1) |
| 116 | (402,0,1) | 378 | 20 | (398,1,0) |

Day114 lies in the strict square band380<385<=400. The target therefore
has opposite-anchor radius39. On day115 its propagated own-anchor
radius40 forces erosion count zero, contradicting the proposed e1.
The older exact-only certificate had aged to radius52, explaining why
it missed this event. The new interval reset identifies recent geometry,
rather than adding another isolated exceptional shape.

The witness also shows why a one-time phase allowance is inadequate.
The first orientation change, at size402 on day115, has
tau0(402)=tau1(402)=48 and gives no immediate clock improvement.
A second change on day148 takes (208,0,1) to (199,0,1), where
tau0(199)=15 and tau1(199)=14; that change yields the one-day saving.
Before it, day147's survivor194 in Q14 would have reset the opposite
radius to27. Its physical remaining clock from size208 is16, and
27+16-1=42<47: the exact terminal-locking region in
`bridge-lower-frontier-radius-clock.md` already excludes any later
useful opposite corner. The formal charge of every such event,
including earlier neutral phase changes, remains the general target.

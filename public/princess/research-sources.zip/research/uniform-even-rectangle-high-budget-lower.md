# Uniform high-budget lower bound for rectangles with even shorter side

12 September 2026. Ordinary proof from the independently audited exact
static profile. The physical upper construction is separate in
`uniform-even-rectangle-high-budget-upper.md`; no dynamic normalization
of minimizing sets is assumed here. Independent review requested.

Let G=P_(2b)×P_n, b≥1, n≥2b, h=bn, and b²+1≤m<h. Define

    d=m−b,     h−b=qd+r,     0≤r<d,
    J(0)=0,    J(r)=r+min(ceil(sqrt(r)),b) for r>0.

Then every guaranteed full-board strategy needs at least

    2q                         if r=0;
    2q+1                       if r>0 and 2J(r)≤m;
    2q+2                       if r>0 and 2J(r)>m.       (1)

Together with the physical upper construction this determines the exact
minimum for this entire parameter range.

## 1. A symmetric inverse concentration inequality

Both colors have h rooms and the same static profile

    g(k)=k+min(R(k),b,rho(h−k)),
    R(k)=ceil(sqrt(k)), rho(z)=min{s≥0:z≤s(s+1)}.

For 0≤z≤h define the inverse I(z)=max{k:g(k)≤z}. Complementing an empty
bipartite pair, or applying the already established profile duality, gives

    I(z)=h−g(h−z)=z−A(z),
    A(z)=min(rho(z),b,R(h−z)).                         (2)

This identity also follows directly from the displayed formulas. The
endpoints are I(0)=0 and I(h)=h; I(z)<h when z<h.

The cost A is subadditive on its finite domain. Indeed, rho is
subadditive: if x≤u(u+1), y≤v(v+1), then
x+y≤(u+v)(u+v+1). If a minimizing branch of A(x) or A(y) is b, then
A(x+y) is at most that branch. If it is the reflected branch R(h−x),
then A(x+y)≤R(h−x−y)≤R(h−x), and similarly for y. Otherwise choose
lower-rho minimizing branches for both and use their subadditivity.
All costs are nonnegative. Therefore

    I(x)+I(y)≤I(x+y)      whenever x,y≥0 and x+y≤h.    (3)

No compatibility of profile minimizers enters (2) or (3).

## 2. Arbitrary physical strategies concentrate before scalar capture

Define the scalar sequence

    D_0=0,  D_(t+1)=I(min(h,D_t+m)),
    c_t=h−D_t.

Equivalently c_0=h and c_(t+1)=g(max(c_t−m,0)). Let τ be its first
zero time. These are comparison quantities; at this stage we do not
claim that their whole trajectory is physically attained.

For any actual full-board schedule, let x_t,y_t be the deficits in its
two current physical colors after t inspections and the following t
moves. Then for every t<τ,

    x_t+y_t≤D_t.                                      (4)

This is proved by induction. To reach a time t+1<τ, nonsaturation of
D_(t+1) implies D_t+m<h. If current useful allocations are p,q with
p+q≤m, the arbitrary-support profile lower bound and (2) give new
physical-color deficits at most I(y_t+q) and I(x_t+p). Their total input
is at most D_t+m<h, so (3) bounds their sum by D_(t+1). The physical
color exchange has no effect because the two profiles are identical.
The initial bound is equality.

## 3. Exact midpoint lower bounds

Here τ≥2 because m<h. First, no strategy captures the full board in
2τ−2 days. Put L=τ−1 and pad a shorter candidate by empty inspections.
After its first L inspections and L moves, the forward possible set B
at day L+1 has deficit at most D_L≤h−1 by (4), hence at least h+1 rooms.
Reverse the final L inspections: perform L−1 moves and then the last
reverse inspection without its final move. Before that last inspection
the deficit is at most D_(L−1); afterwards it is at most
D_(L−1)+m<h, by nonsaturation at time L. Thus the reverse survivor set R
also has at least h+1 rooms and lies at the same physical time as B.
The sets intersect, yielding a full avoiding walk by concatenation.
Consequently

    T≥2τ−1.                                           (5)

There is a further obstruction to a 2τ−1-day schedule. Process its first
L inspections and moves forward, and its final L inspections and moves
backward, omitting the central inspection from both. Both possible sets
lie at the central day, and each has deficit at most D_L. Their
intersection therefore has at least

    2h−2D_L = 2c_L                                   (6)

vertices. Every one must be inspected on the central day: otherwise
its forward and backward avoiding walks concatenate. Hence

    2c_(τ−1)>m  implies  T≥2τ.                        (7)

These arguments concern arbitrary sets and actual undirected walks.
They neither presuppose nested minimizers nor infer an upper strategy
from the scalar comparison.

## 4. Evaluation at every high budget

For any positive survivor s≤h−m, its far-corner distance is h−s≥m.
Since m≥b²+1>b(b−1), rho(h−s)≥b. Thus all scalar updates here use the
one-ended function

    L(s)=s+min(R(s),b), L(0)=0.

Also d=m−b≥b²−b+1>(b−1)². Therefore the first q−1 updates are on the
plateau and give exactly

    c_t=h−td,             0≤t≤q−1,
    c_(q−1)=m+r,
    c_q=J(r).                                           (8)

To check the plateau range directly, the survivor at update j≤q−1 is
(q−j)d+r≥d>(b−1)², so its surplus equals b. This includes b=1.

If r=0, scalar capture first occurs at τ=q and c_(τ−1)=m.
The condition m<h forces q≥2 in this case. Equation (7) gives T≥2q.
If r>0, then 0<J(r)≤r+b≤m−1, so τ=q+1 and c_(τ−1)=J(r).
Equations (5) and (7) give the remaining two branches of (1).

## Scope

The theorem handles every even shorter side, every allowed longitudinal
length, and every budget m≥b²+1 below h. Budgets at least h have the
immediate general answer: two days when h≤m<2h and one day when m≥2h.
The low-budget range below b²+1 is not settled by this proof. Nor does
this argument cover an odd shorter side with an even longer side.

### A slightly wider range for the lower bound alone

The scalar evaluation in Section 4 needs only
m≥b²−b+2: then d=m−b>(b−1)² and m>b(b−1), exactly the two inequalities
used there. Consequently the same three-branch expression remains an
unconditional lower bound in that wider range. The physical upper in
the companion note still uses m≥b²+1. In particular the lower already
applies to four-row rectangles at m=4; a separate physical construction
is needed to conclude equality there.

# Corner localization and a physical propagation delay

13 September 2026. Euler independent proof and audit of the root/Socrates
localization proposals. **PASS as an ordinary theorem.** No Lean claim and
no claim of a complete dynamic normal form.

Let the half-strip be `0 <= x < 2b, y >= 0`, with its actual square-grid
adjacency, and consider a finite nonempty support S of color zero
(`x+y` even). Write `c=(0,0)`, `c'=(2b-1,0)`, and
`s=|N(S)|-|S|`. The statements below assume `s<b`. Reflections give the
other physical color. Put

    C_2(s)=max(s(s-1)/2,s(s-2)).

## Unified theorem

1. If `|S|>s(s-1)`, S contains c, is connected in the graph joining two
   source rooms whenever they share a neighbor, and every room satisfies

       x+y <= 2s-2.

   Consequently `c'` is absent from `N^j(S)` whenever
   `j < 2(b-s)+1`.

2. If c is absent from S and `|S|>C_2(s)`, S is connected in the same
   graph, `c'` belongs to N(S), and every room satisfies

       (2b-1-x)+y <= 2s-3.

   Consequently c is absent from `N^j(S)` whenever
   `j < 2(b-s)+2`.

Here j counts movements after the survivor S, not inspection rounds or
beliefs before inspection. Subsequent inspections only shrink free
neighborhood iterates, so both exclusions hold for every later inspection
schedule. The same statements hold with a surplus upper bound s in place
of the actual surplus, by applying the actual-surplus result first.

## Accepted static inputs, and a correction to the first sketch

We use the independently accepted quadrant capacities from
`maturation-punctured-quadrant.md`, and the half-strip profiles in
`maturation-even-transitions.md` Sections 8--10. Below critical surplus b:
an arbitrary source has capacity `s^2`; one omitting c has capacity
`s(s-1)`; one omitting c whose neighborhood also omits c' has capacity
`C_2(s)`. Only these static inequalities are used.

It is FALSE that every component omitting c has capacity C_2(s).
For example on width six, `{(4,0),(5,1)}` has size two and surplus two,
whereas C_2(2)=1. This is a pronic corner component. The proof below uses
the valid omitted-current capacity `s(s-1)` instead.

## Components and concentration

Distinct sharing-neighbor components have disjoint neighborhoods. Thus
their sizes and surpluses add exactly. Transverse matching injects every
component into its neighborhood, so each surplus is nonnegative. Since
their sum is s<b, the accepted static bounds apply separately to each.
A nonempty component omitting c has surplus at least two; a nonempty
component containing c has surplus at least one.

For statement 1, if no component contains c, their capacities sum to at
most `sum u_i(u_i-1) <= s(s-1)`. If the component containing c has
surplus a and companions have total surplus d, then a>=1, d>=2 and

    |S| <= a^2+d(d-1) <= (a+d)(a+d-1) <= s(s-1).

The second inequality has nonnegative difference a(2d-1). Both cases
contradict the size hypothesis. Hence S is one component containing c.

For statement 2, all components omit c and each has surplus at least two.
If there are at least two, the sum of their pronic capacities is at most

    (s-2)(s-3)+2 <= s(s-2) <= C_2(s),    s>=4.

To see the first bound, merge all but one component, then maximize the
convex expression `a(a-1)+(s-a)(s-a-1)` over `2<=a<=s-2` at an endpoint.
For s<4 two components are impossible. Therefore S is connected.
If c' were absent from N(S), the joint static profile would give
`|S|<=C_2(s)`. Thus N(S) contains c'.

This also verifies Socrates's finer concentration proof: at most one
component can touch c', and every other component has C_2 capacity. Its
two endpoint inequalities are valid for s>=4. The simpler uniform
pronic estimate above avoids needing those endpoint cases.

## A separating row preserves the actual neighborhood

Match `(2i,y)` to `(2i+1,y)` and represent the unique color-zero room of
each matched pair by `(i,y)`. The matching-contracted digraph has horizontal
edges in both directions and outward rungs from i to i-1 at even y and
from i to i+1 at odd y. Its external boundary has exactly s vertices.

There are b matched rows and s<b. Some row has no boundary vertex.
Its finite source subset is then horizontally closed in a connected ray,
so it is empty. Physically, both transverse rows 2i and 2i+1 are empty.
Neighborhoods of the support to their left and right are disjoint: the
left neighborhood ends at row 2i, and the right neighborhood begins at
row 2i+1. Hence sharing-neighbor connectivity puts all of S on one side.

In statement 1 it is the side containing c. In statement 2 it is the side
whose neighborhood contains c'. On either side, the empty matched row
provides the entire missing transverse neighbor layer. Viewing that side
as the appropriate infinite quadrant therefore leaves N(S) UNCHANGED,
including its cardinality. There is no artificial-boundary discount.

## Connected raw diagonals give triangular localization

In the origin quadrant of statement 1, sharing-neighbor edges change
coordinate sum by zero or two. Since c belongs to S, the occupied even
diagonals are precisely `0,2,...,2(L-1)` for some L. Compressing separately
on each diagonal preserves which raw diagonals are occupied and does not
increase neighborhood size. The exact layer inequalities give at least
one surplus unit for every occupied diagonal, so `L<=s`. The ORIGINAL
support therefore has `x+y<=2s-2`; this does not assert that the original
rooms within a diagonal form a prefix.

In statement 2 reflect transverse coordinates about c', giving an odd
quadrant. Since its origin belongs to N(S), diagonal one is occupied.
Connectedness gives diagonals `1,3,...,2L-1` with no gaps. In the compressed
set there is additionally one output room at the origin, beyond the L
surplus units on occupied diagonals. Thus `L+1<=s`, and the original
support has local coordinate sum at most `2s-3`.

For comparison, the original two-coordinate matching argument is also
sound, but gives only separate bounds `x,y<=2s-2`. The triangular argument
is both stronger and shorter after the separating-row lemma.

## Propagation bounds and sharp offsets

The bottom corners are distance `2b-1` apart. Every room in the first
triangle has distance at least `2b-1-(2s-2)=2(b-s)+1` from c'. Every room
in the second has distance at least `2b-1-(2s-3)=2(b-s)+2` from c.
No shorter walk can reach the corresponding corner. If B_j is any actual
later belief obtained using arbitrary inspections, then `B_j subseteq
N^j(S)` by induction. This proves the claimed schedule-independent locks.
The strict `<` is intentional. Full square/pronic triangles contain an
axis extremity at exactly the stated distance, so it cannot generally be
replaced by `<=`.

## Equality rigidity of the square and pronic capacities

For an even quadrant, size s^2 and surplus at most s force precisely the
full diagonals `0,2,...,2s-2`. For an odd quadrant, size s(s-1), s>=2,
and surplus at most s force precisely the full diagonals `1,3,...,2s-3`.
In either case the no-full-layer branch of the capacity proof is strictly
smaller. In its full-layer branch, equality forces the first full layer
to be the first permitted layer, every occupied layer to be full, and
every intervening layer to be occupied. More explicitly, equality in
`|S|<=L*s<=s(s-h)` forces `L=s-h`, first-full rank one, and full-count
`f_t=t`; the individual layer bound then forces index `j_t=t-1`.
Compression preserves each layer's count, and a full layer has no choice
of support. Thus rigidity holds for the raw set, not merely a compression.

An omitted-current half-strip support of size s(s-1), surplus s<b, is
therefore the unique opposite-corner odd triangle (s>=2). A boundary-free
row splits its capacity into C_2(left)+C_1(right). For integer surplus
allocations, equality in C_1(s) forces all surplus to the right: C_2(s)
is strictly smaller, and every nontrivial split loses a positive cross
term. The quadrant equality case then applies. This independently
justifies the forced 30-room triangle used in Socrates's width-14,
nine-inspection, nine-day two-bit counterexample.

## Evidence and proof boundary

`src/maturation_cheap_step_check.py` checks arbitrary raw supports on small
half-strips, counting neighbors beyond the sampled finite top boundary.
It verifies both localization statements, the stronger connected-origin
geometric core, the rigid equality cases, and the stated component-bound
counterexample. The receipt is
`maturation-cheap-step-independent-check.json`. These finite checks are
adversarial evidence; the proofs above establish all widths and sizes.

No full-board optimal-time formula, arbitrary-belief compression, or
sufficiency of a finite collection of availability bits follows here.

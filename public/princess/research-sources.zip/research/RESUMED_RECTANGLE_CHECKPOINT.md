# Rectangle research checkpoint: stronger even-area bounds

13 September 2026. New mathematical research after the scope-separation
release. The priority was the two even-area gap families. The completion
criterion is unchanged: a fixed-size O(1) standard-operation value for every
T_k(a,b), feasibility included, and directly specified optimal inspections.
No independent extension was resumed. No new complete physical Lean theorem
is claimed in this checkpoint.

## Uniform results, rather than additional isolated hypotheses

1. **Upper constructions at every feasible even-area budget.** The root-selected
   envelope argument extends both former high-budget constructions to every
   k>=floor(w/2)+1. Their bounded remainder/root expressions are upper bounds
   throughout this range; equality retains its previous quadratic thresholds.
   The same minimum-budget expression 2wn-C_w known on odd lengths is an
   attained upper bound at every even length when w is odd. Its width-only
   clock remains a recurrence. Ordinary proofs and literal-room replays are
   preserved in the root-saturation and odd-even-minimum-upper notes.

2. **One necessary corner theorem for every even-area rectangle.** It keeps
   the size and current/outgoing corner counts of arbitrary supports. Below
   surplus floor(w/2), a fixed quadratic small-set capacity or its charged
   complement bound applies. The critical theorem has only the specified
   spanning corner patterns as additional possibilities, including squares.
   This does not assert attainment of each allowed profile.

3. **A stronger erosion-corner model and a proved merger.** Keeping corners
   whose two neighbors remain distinguishes touching a corner from retaining
   its supporting rooms. The strengthened low/dual capacities, corner closure,
   and maximal-retention normalization are ordinary physical arguments.
   Their critical refinement is proved for odd width and even length; the
   broader even-width critical refinement remains open. Dropping the positive
   feature lower-cardinality constraint gives a necessary model closed under
   a precapture merger. That explicit relaxation is essential: raw merging
   does not preserve the discarded constraint. The merger reduces joint lower
   evaluation to one cohort; it does not turn model paths into strategies.

4. **Near-extremal supports retain geometric information.** Exact pronic
   equality is rigid at every radius on every even-area board, with separate
   correct corner reach at an even-square endpoint. On odd width/even length,
   the full band C_2(b)<|U|<=b(b-1), with no own corner and surplus<=b, is
   localized within radius 2b-3 of one opposite-colored corner. Its dual gives
   the static survivor/target triple (i,u,v)=(1,2,1). Thus the proposed extra
   band-history bit is unnecessary: the existing erosion feature implies the
   forbidden consecutive transition. The direct band rule also preserves the
   merger. Near square capacity, |U|>s(s-1) confines a quadrant support to the
   full s^2-room corner triangle. These are proofs for arbitrary supports,
   not assertions that compression preserves their locations.

## Exact finite consequences and a remaining diagnostic interval

Ordinary uniform geometry plus independently checked integer certificates
and physical inspection replays establish:

- T_5(8,8)=40.
- T_7(12,12)=72.
- T_4(7,8)=68.
- T_5(9,10)=96.
- T_6(11,12)=128.
- T_6(11,14)=172.

The 11-row cases now use the static band-dual rule, with no extra band-memory
state. In the explicitly weakened merger model, solo times are 64 and 86;
the penultimate minimum is four, so 2*4>6 excludes the central-day saving.
The 7x8 and 9x10 full joint certificates remain independently checked evidence,
not prerequisites for every later use of the uniform merger theorem.

For 24x24,k=13, the proved FULL-BOARD interval is now 206<=T<=207.
The base corner model first supplied a 204 lower; a literal 207-day
inspection list supplies the upper. A new physical boundary-history barrier raises the
SOLO lower from 102 to 103, versus a 104-day solo construction. All eight
compressed near-square candidate supports were independently checked. A separate time-sensitive equality certificate proves that the only
extremal joint pair at day 28 has one cohort full. The physical barrier
therefore applies to every merged joint history. The filtered lower clock
is 103, with penultimate residual nine; 18>13 excludes a 205-day capture.
This independently checked bridge proves the 206 full-board lower.

## What this changes in the four remaining families

The complement of the accepted bounded-formula families is unchanged as a
family-level list. This does not mean all individual instances are unknown.

- Even widths 2r>=6, r+1<=k<=r(r-1): uniform lower geometry and all-budget
  constructive uppers are stronger, but uniform matching remains open.
- Odd widths 2r+1>=7 at even lengths, r+1<=k<=r(r+1): the same applies; the
  near-pronic dual restriction closes two 11-row diagnostics. A uniform
  minimum-budget lower matching 2wn-C_w is still a research target.
- Odd widths >=17 at odd lengths and minimum budget: the width-only clock
  still needs a bounded numerical expression. This pass does not resolve it.
- Remaining intermediate budgets on odd-by-odd rectangles: the joint central
  decision and the varying-width clock still need the stated improvements.

No universal claim of optimality of the current upper family is justified.
The precise remaining distinctions are physical attainability of necessary
lower paths, the shared-budget midpoint decision, uniform parameter
comparison, and finally fixed-size numerical evaluation. The explicit
inspection requirement also remains distinct from the numerical evaluator.

## Failures that guided the stronger proofs

- Static neighborhood minima do not compose; the corner model must retain
  information from the preceding belief.
- Two fixed-corner prefix unions improve some upper constructions but do not
  match every necessary clock. Their failure does not prove a physical lower.
- The raw erosion-feature merger can violate c+2e<=a. A documented necessary
  relaxation, with a new algebraic proof, fixes the lower-bound method.
- An extra one-bit near-pronic history rule worked, but the stronger static
  dual feature theorem makes the bit redundant. This is actual mathematical
  supersession, rather than editorial grouping.
- Pronic equality and its dual alone do not close the 11-row or 24-square
  discrepancies. Localization on an interval of near-extremal sizes supplies
  information that exact equality misses.
- The 24-square solo barrier did not automatically improve a full-board
  bound. Time-free inspection-ammunition costs fail to force concentration.
  A separate time-sensitive equality certificate supplies the needed bridge.

## Sources and verification

The current mathematical account is the manuscript, including the new common
corner-theory section and its applications. The chronological research log is
`resumed-rectangle-research-log.md`; the individual `resumed-*.md` notes retain
proof derivations, independent attacks, and failed proposals. JSON receipts
and their separate verifiers accompany the finite consequences. Historical
receipts are not relabeled as tests of a later graph or as Lean proofs.

No canonical Lean source changed. Full physical-game classifications in the
main project remain paths and two rows; new geometry and merger arguments
are ordinary proofs. Publication/build/deployment evidence is recorded
separately after the artifacts are built and inspected.

# Grid extension: bounded literature assessment

Date: 2026-09-11 (Pacific). Scope: planning evidence, not an exhaustive novelty search. No original manuscripts modified.

## The game being compared

Finite Cartesian products of paths; an initially invisible target; at most k arbitrary, simultaneous vertex probes each round; a surviving target must traverse exactly one edge. This is the standard **Hunters and Rabbit** game. Capture time here means the least deterministic worst-case number of rounds. It is distinct from the hunting number h(G), the smallest probe budget that eventually guarantees capture. Papers allowing staying, visible targets, random expected capture, restricted hunter movement, or total rather than per-round shot budgets need separate comparison.

## Results verified in primary sources

### All rectangular grids: feasibility is already completely known

Tatjana V. Abramovskaya, Fedor V. Fomin, Petr A. Golovach, Michał Pilipczuk, *How to hunt an invisible rabbit on a graph*, European Journal of Combinatorics 52 (2016), 12–26; DOI 10.1016/j.ejc.2015.08.002. Preprint first submitted 19 February 2015.

Primary [author-hosted published PDF](https://fedorvf.github.io/articles/2016/2016g.pdf), [arXiv record](https://arxiv.org/abs/1502.05614).

- Rules on printed pp.13–14 match exactly.
- **Theorem 2, printed p.21, proof pp.21–22:**
  \[h(P_a\square P_b)=\lfloor\min(a,b)/2\rfloor+1.\]
- Thus every genuine ladder P_n □ P_2, n≥2, needs and suffices with two probes; one-dimensional degeneracies need one.
- The proof provides winning sweeps and matching impossibility arguments; its optimization target is the number of hunters, not fastest capture at every permitted budget.
- Proposition 1, p.14, gives the finite belief-state arena and a 2^{|V|} upper bound on a winning schedule length. Lemma 1, pp.14–15, reduces eventual feasibility on bipartite graphs to one initial parity, repeating a suitable schedule. Such repetition is not automatically capture-time optimal.

### Higher dimensions: hypercubes are known; arbitrary boxes not established here

Jessalyn Bolkema and Corbin Groothuis, *Hunting Rabbits on the Hypercube*, first posted 30 January 2017. [Primary PDF](https://arxiv.org/pdf/1701.08726).

- **Theorem 49, printed p.14:**
  \[h(Q_d)=1+\sum_{i=0}^{d-2}\binom{i}{\lfloor i/2\rfloor}.\]
  Q_d is the box with every side length two. Check: Q_3 requires three hunters; Q_4 requires five.
- **Theorem 16, printed p.6:** a bipartite graph with isoperimetric nesting and parity expansion maxima differing by at most one has hunting number one plus the smaller maximum. The construction exploits nested minimizers of open-neighborhood size, a promising general proof tool.
- The paper verifies the relevant nesting for hypercubes. This does not by itself establish the hypothesis or formula for arbitrary products of longer paths.
- The separate section on a target permitted to stay uses closed neighborhoods and a different theorem; do not import it into the present problem.
- Warning: the introduction of the 2025 paper below prints a hypercube sum starting at i=1. The original theorem starts at i=0; the latter passes the Q_3 degree check. Use the original source.

### Capture time is a separate, actively studied parameter

Walid Ben-Ameur, Harmender Gahlawat, Alessandro Maddaloni, *Hunting a rabbit: complexity, approximability and some characterizations*. [arXiv 2502.15982v2, 4 December 2025](https://arxiv.org/pdf/2502.15982v2); published TCS 1075 (2026), 115946, [publisher page](https://www.sciencedirect.com/science/article/pii/S0304397526002057).

- §5, printed pp.15–24, defines h(G,l), the minimum hunters guaranteeing capture within l rounds. This is the inverse tradeoff to capture time for a fixed budget.
- **Corollary 5.7, printed p.19:** for bipartite G, h(G,2)=matching number=minimum vertex-cover size.
- **Independent immediate specialization:** a Cartesian box with N≥2 cells has a Hamiltonian snake path, hence a matching of size floor(N/2); its smaller checkerboard class is a vertex cover of that size. Consequently its two-round threshold is floor(N/2). Probe that smaller parity twice. This is a corollary of known results, not a new theorem claim.
- General-graph hardness does not imply hardness on rectangular grids. No blanket difficulty conclusion about boxes should be drawn from it.

### Monotone searches must not be assumed optimal

Thomas Dissaux, Foivos Fioravantes, Harmender Gahlawat, Nicolas Nisse, *Further results on the Hunters and Rabbit game through monotonicity*, [primary PDF](https://arxiv.org/pdf/2309.16533), first posted 28 September 2023.

**Theorem 1, printed p.12:** pw(G)≤mh(G)≤pw(G)+1. Here mh restricts the allowed strategies to their defined monotone searches; ordinary hunting permits recontamination. The paper exhibits arbitrarily large gaps between h and mh, including trees with h=2. Thus a successful monotone or frontier sweep is an upper bound; proving it fastest requires a lower bound against every legal schedule. Ordinary global monotonicity and monotonicity within an alternating initial parity are different notions.

### Existing source already in Angel's references

Nikolay Beluhov and Emil Kolev, *Search for a moving target in a graph*, [2016 ACCT conference slides](https://www.moi.math.bas.bg/moiuser/~ACCT2016/p7.pdf), later ENDM 57 (2017), 39–46, DOI 10.1016/j.endm.2017.02.008. The primary slides give the identical k-chase rules and the even-square result h(P_{2n} □ P_{2n})=n+1. These slides do not establish an arbitrary-budget capture-time formula for paths. Full proceedings/journal comparison remains necessary; an abstract's phrase “rectangular grid” is not enough to infer the exact theorem scope.

## Planning conclusions and unresolved questions

1. Do not spend a research phase rediscovering 2D feasibility. Cite and, if useful for the project, reprove/formalize the known theorem with clear attribution.
2. The natural prospective extension is the **complete budget-versus-capture-time tradeoff**, beginning with ladders. All rectangular-grid feasibility thresholds and the two-round regime are already available benchmarks.
3. I did not locate a complete capture-time formula for every rectangle and every probe budget in this bounded search. This is not evidence that none exists. A focused novelty audit must precede any novelty claim, particularly for paths and ladders.
4. I did not establish the status of feasibility on every arbitrary-dimensional box. Known exact hypercube results show that “all dimensions” already has substantial literature and is not automatically a small extension of the path theorem.
5. A useful mathematical hypothesis to test is whether neighborhood minimizers can remain nested throughout the optimal time-budget recurrence. A one-step minimum need not be compatible with tomorrow's optimal geometry; parity allocation can create additional timing effects. This is a proposed attack, not a theorem.
6. Recommended sequencing: complete and audit the path paper independently; run bounded ladder experiments and a focused time-optimization literature review in parallel; decide whether a rigorous additional family belongs in the same paper only after that evidence arrives. Do not make publication contingent on a full multidimensional classification.

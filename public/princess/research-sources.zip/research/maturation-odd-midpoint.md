# Maturing the odd-rectangle midpoint theorem

13 September 2026. Active research. No new full classification is claimed.
The antecedent exact bounded-frontier theorem already computes every odd
rectangle at every feasible budget. The target here is to remove its joint
optimization and prove the scalar endpoint criterion.

## 1. Exact target and known obstructions

Let w=2b+1<=n be odd, E=M+1, and m>=b+1. Let D_p(t) be the exact
solo deficits, tau the first solo capture, and L=tau-1. The exact answer is
2tau-1 iff

    C_L=min_(x,y),(u,v) [(E-x-u)+ +(M-y-v)+] <= m,

with both pairs independently attainable at time L. The remaining target is

    C_L<=m  iff  E+M-D_0(L)-D_1(L)<=m.

Sufficiency is known. No unqualified intersection lower bound, arbitrary
partial-state seriality, arbitrary monotone solo-capacity closure, or
current-gap-only restriction is assumed: each has a documented counterexample
in the antecedent notes. In particular the reachable 7x7,m6 partial state
(8,8) has a five-day continuation versus six serial days, but arrives too
late to contradict the full-board assertion.

## 2. Focused first attacks

`src/maturation_odd_midpoint_attack.py` uses only the exact retained
frontier, at the true precentral horizon. Six short-horizon square cases
and nine cases chosen immediately below the solo central-budget threshold
passed the scalar and stronger capped-pair tests. The latter deliberately
select a small deficit between the constructed central requirement and the
available quota, where a mixed-state improvement would be decisive.
Receipts: `maturation-odd-midpoint-short-horizon.json` and
`maturation-odd-midpoint-near-cut.json`. All these computations together
used less than0.1 CPU second. This is a falsification attempt, not a proof.

Examples with genuine mixed states are101x101,m1166,L4: deficits4514,4516,
frontier(4514,0),(1,4514),(0,4516); and101x101,m343,L16:
(4917,0),(4,4914),(3,4915),(2,4916),(1,4919),(0,4921).
The mixed states survive the high-total filter but do not improve the cut.

## 3. A sufficient ancestry barrier

The established persistence lemma says a mixed state with total greater
than min(D_0,D_1) can only descend, without an intervening reset, from a
pure endpoint of the faster initial cohort. At a change of fastest initial
cohort all exceptional mixed histories are erased. A tie admits no
exceptional mixed state at all. Hence all exceptional mixed states at a
fixed time have the same primary initial-cohort ancestry. Their secondary
coordinate is the other physical color, even if it is not numerically the
smaller coordinate. This ancestry claim is proved and independently reviewed in Section4.

For the remaining range b+1<=m<=b^2, consider the candidate barrier

    secondary <= b^2-m                         UNPROVED.

It is a statement about actual exceptional histories at the precentral
horizon, not an arbitrary two-counter box. Its interpretation is that a
secondary deficit remains below the bottom inverse's flat region even
when allotted one more full quota.

Conditional on this barrier and the ancestry statement, the scalar
criterion follows without any additional estimate on the solo residuals.
If either midpoint state is nonexceptional, its total is at most the
smaller solo deficit and the other's is at most the larger; their union
cannot beat D_0+D_1. If both are exceptional, their secondary coordinates
occupy the same physical color and total at most2(b^2-m). That color alone
requires at least

    M-2(b^2-m) >= 2b+2m > m

central probes because M>=2b(b+1). Thus such a pair cannot win at all.
Budgets m>=b^2+1 are already covered by the published high-budget theorem.

A stronger current-gap bound was previously refuted; this width/budget
barrier is different. A focused test at b=4,9,20,40, n=3w and budgets near
minimum, twice b, half b^2 and near b^2 found no violation for the smaller
coordinate (about1 CPU second). The correct ancestry-coordinate version
still needs separate checking. No conclusion follows from this finite
sample.

An earlier speculative estimate on the sum of solo residuals is not used:
the conditional proof above needs only the untouched-color lower bound.

## 4. Precise ancestry induction and a minimum-budget consequence

This ordinary theorem passed root independent mathematical review on
13 September2026; Euler independently checked the ancestry argument.
It uses the inverse concentration lemma and the phase-reset deduction in
`research/uniform-rectangle-time.md` Section7, together with the reviewed
corner-clock/solo-duality proof in `research/uniform-odd-minimum-budget.md`
Sections1–3. It is not a new counter assumption or a complete Lean theorem.
Physical color0 is the majority class E; color1 is the minority class M.
An initial-cohort label toggles physical color after each movement.

Give each retained pure endpoint the label of its initial cohort. Give a
mixed descendant the primary label of its most recent pure ancestor.
Pure successors can be replaced by the corresponding solo endpoint; low-
total mixed states can be discarded by persistence. At a strict solo tie
there are no exceptional mixed states. The following direct induction,
isolated by Euler during Lean formalization, avoids enumerating switches.
If an exceptional source has primary physical color0, its total S is at
most D_0(t). The second inverse concentration inequality bounds any mixed
successor's total by I_1(S+m)<=D_1(t+1). If that successor is exceptional,
color1 must therefore be strictly faster. If the source primary is
color1, the first concentration inequality similarly bounds the mixed
successor by D_0(t+1), which must be strictly faster. In both cases the
primary color flips, exactly as the original cohort does under movement.
The proper-input condition follows because t+1<tau; positive minority
output supplies the nonzero-argument hypothesis for second concentration.

Inductively, an exceptional mixed successor either descends from an
exceptional mixed predecessor with the same faster initial-cohort label,
or is born from a pure endpoint. A pure slower endpoint has total at most
the smaller old capacity and cannot create an exceptional mixed successor.
Thus every retained exceptional mixed state has the CURRENT faster initial
cohort as its primary ancestry. No numerical comparison of its two actual
deficit coordinates is asserted or needed.

At minimum budget, the independently reviewed note
`uniform-odd-minimum-budget.md` gives a last pure tie and an upper
precentral horizon L_b. Every secondary born after that tie is bounded by
fresh solo deficits for at most L_b days, hence by C=b(b-1). Therefore
any two exceptional final states share a primary ancestry, and their
other-color combined deficit is at most2C. That color alone leaves
M-2C>=4b>b+1 central rooms. Such a pair cannot win. If either state is
nonexceptional, total concentration gives the endpoint-only criterion.
The slower full-board solo has duration tau+1, so at time tau-1 its
remaining count exceeds m. Thus the solo central requirement exceeds m,
and the longer answer2tau is forced.

The reviewed ancestry deduction completes the minimum-budget law for
every odd width and length, using

    T_(b+1)((2b+1) x n)=2(2b+1)n-K_b,
    K_b=8b^2-4b-4L_b+4.

The old primary lower-root translation barrier is unnecessary for that
conclusion. No arbitrary-budget secondary bound has yet been proved.

## 5. Exact minimum ammunition in every bottom-corner budget

Ordinary lemma independently reviewed and accepted by root on13 September2026. Define

    L_0(k)=k+min(R(k),b),
    L_1(k)=k+min(Q(k),b+1),  k>0,
    L_p(0)=0,

and their integer inverses j_0(z)=z-min(rho(z),b),
j_1(z)=z-min(R(z),b+1). Each j_p is nondecreasing and1-Lipschitz on
nonnegative integers, with j_p(0)=0. These are unbounded bottom profiles,
not the full finite-board profiles with their reflected end branches.

Let mu_p(k) be the least TOTAL number of probes in a finite alternating
sequence v' = j_p(v+q), 0<=q<=m, which starts from zero and ends at
leastk in physical colorp. Either initial zero phase is allowed (a free
zero step exchanges them). The number of days is unrestricted. For
m>=b+1 every k is attainable.

Then mu_p(0)=0, mu_p(k)-k is nondecreasing, and the exact recurrence is

    mu_p(k)=min(m,L_p(k))
               +mu_(1-p)((L_p(k)-m)+).                  (A)

**Proof of monotone excess.** In any fixed finite schedule, removing one
probe changes the eventual output by at most one: every map j is
nondecreasing and1-Lipschitz. Starting with an optimal schedule whose
output is at leastk, remove probes one at a time until the output first
hitsl<k. It must hit every intervening integer. At leastk-l probes have
been removed, and the remaining cost is at leastmu_p(l). Thus
mu_p(k)>=mu_p(l)+(k-l). The same deletion argument gives an optimal
schedule ending at exactlyk.

**Last-step minimization.** Put z=L_p(k), the least integer with j_p(z)>=k.
For a predecessor v, the last quota must satisfy v+q>=z and q<=m.
Thus v>=(z-m)+. For v<=z, monotonicity of mu_(1-p)(v)-v gives

    mu_(1-p)(v)+z-v
       >=mu_(1-p)((z-m)+)+min(m,z).

For v>=z, the same inequality follows from the fact that increasing v
by a unit increases mu by at least a unit. Conversely attain predecessor
(z-m)+ at its optimal cost, then allocate min(m,z). Since j_p(z)=k
(the inverse's increments are at most one), equality is attained.
This proves(A), including the zero-quota alternatives.

Its predecessor is at mostk in phase1 and strictly less thank in phase0;
every two recursions strictly decrease positive k. Thus(A) terminates and
constructs an optimal growth schedule, using full quotas in reverse order
except for its final small predecessor step.

There is also an exact inspection-before-movement clearing cost for the
unbounded profiles. Let F_p(k) be its minimum total probes. Reversing a
clearing schedule after its first inspection gives a growth schedule for
the surviving k-q cells, so

    F_p(k)=min_(0<=q<=min(m,k)) [q+mu_p(k-q)]
          = k,                                 k<=m,
            m+mu_p(k-m),                        k>m.

The last equality follows from monotone excess. Equivalently,

    F_p(k)=m+F_(1-p)(L_p(k-m))                   k>m.    (B)

Hence full-budget greedy clearing minimizes total probes as well as
providing a valid finite schedule in this unbounded corner model. This
is not a claim that full-budget serial allocation is optimal for the
finite two-cohort rectangle game. It includes a sharp interior potential
at all feasible budgets, where the published high-budget lemma gave an
explicit quotient/remainder evaluation only in its own range.

`src/maturation_odd_ammunition.py` evaluates(A), skipping paired affine
steps. An independent finite Dijkstra comparison checked434 phase/count
targets in seven selected budget settings and all corresponding one-step
clearing inequalities. The finite graph includes every potentially
cheaper path: its count is at most its spent probes, and its cost cap is
the largest candidate value. All checks passed in0.009 CPU second;
receipt `maturation-odd-ammunition.json`. This supports but does not
replace the preceding ordinary proof.

For a mixed history whose primary remains in the affine or upper branch,
its lag from the same solo endpoint increases by at least the quota sent
to the secondary. Thus (A) supplies an exact minimum cumulative-loss
charge for secondary growth. The remaining all-budget obstacle is the
credit generated while the primary itself passes through its lower root
bands; that credit cannot be discarded without proof.


## 6. The last solo reset is not a short all-budget clock

A proposed shortcut was to start a fresh-secondary bound at the last solo
tie or fastest-ancestry change. This cannot give a width-only bound at
arbitrary budgets. On15x75,m12, the exact precentral horizon is117 and the
last such reset occurs at3. The fresh secondary bound after114 days is529,
whereas the candidate b^2-m is37. On15x751,m12 the last reset is still3,
and the corresponding fresh bound is5602. Both are genuine solo traces.
Thus fixed larger phase gaps can persist along an arbitrarily long bulk.
The known finite lifetime of each mixed history remains essential.

The exact ammunition potential distinguishes at least one historical
false envelope state. On15x75,m12,t59, the hypothetical state(3,276)
requires bottom growth ammunition mu_0(3)+mu_1(276)=712, exceeding
mt=708. The genuine solo states cost708 and707. All arguments here lie
below the reflected-corner threshold, so this is a valid exclusion. The
old weaker envelope admitted this unreachable state. This is a useful
new guard, but no general closure proof follows from one example.

## 7. A scalar formula after an explicit all-budget onset

**Ordinary theorem independently reviewed and accepted by root on
13 September2026.** This
does not settle every short odd rectangle at intermediate budgets. It
does remove the joint optimization for every sufficiently long odd
rectangle, with an explicit width/budget threshold.

Use the constants from the independently reviewed bounded-frontier
theorem (`supersession-odd-midpoint.md` Sections8–10):

    d=2m-(2b+1), H=b^2+1, G=m-1,
    K=H-1+2m*(floor(G/(2b+1))+1),
    W=G+K+1, J=2K+G+2m+H+2,
    M*=2J+G+m(W+3).

If M>=(M*) and n,w are odd with n>=w>=3, then exactly

    T_m(w,n)=2tau-1  if E+M-D_0(tau-1)-D_1(tau-1)<=m,
             2tau   otherwise.                              (S)

The already reviewed solo-band arithmetic computes tau and the two final
solo deficits using O(b) integer stages. Thus (S) is a finite scalar
arithmetic formula at every feasible fixed budget after the displayed
explicit onset; it is stronger than existence of an eventual period.

**Step1: there are W consecutive safe transitions.** Before the first
solo capture, the maximum solo deficit increases by at most m in one
transition: a proper inverse output is at most its argument, which comes
from the other physical color plus at most m. This is not an assertion
about each fixed physical coordinate's increment. The exceptional
I_0 endpoint jump would capture that cohort and is excluded here.
The solo gap is at most G. At the first time t_0 when both solo capacities
are at least J, their maximum is at most J+G+m-1. Such a time precedes
capture: a predecessor with smaller capacity below J has maximum at most
J+G-1, so its next maximum cannot reach M under the stated threshold.
The solo trajectory eventually captures, and hence must first cross J.

For 0<=s<=W+1 its maximum is at most
J+G+m-1+ms <= M-J. Its minimum remains at least J by monotonicity.
These layers exist before capture, since a first captured layer would
violate the same upper bound applied to its proper predecessor (its
inverse input is still below the endpoint). Thus there are W consecutive
safe transitions, with J<=D_0,D_1<=M-J throughout.

**Step2: the numerical bound becomes an ancestry bound.** The existing
bounded-frontier theorem gives min(x,y)<=K for every retained mixed
exceptional state. During the safe interval, write such a state using its
larger coordinate as primary. This primary is greater than K; the exact
normalized update preserves its role. The accepted age lemma says that
after W safe transitions every surviving mixed history has a recent pure
ancestor inside that interval. Consequently its ancestry-primary is its
numerically larger coordinate, and its ancestry-secondary is at most K.
This is the additional argument needed here: the numerical K bound by
itself would not imply the ancestry bound.

**Step3: ancestry cannot swap in the final collar.** Once the preceding
warm-up is complete, min(D_0,D_1)>=J>2K+m forever before capture.
Suppose a retained mixed history has primary greater than K and secondary
at most K. Following its initial-cohort label across movement, its next
secondary is at most K+m: the input stays below the endpoint since
K+m<M. If its next primary were
at most K, the total successor deficit would be at most2K+m<J and so
would not be exceptional. Therefore any retained exceptional successor
still has primary greater than K. The numerical minimum bound then forces
its secondary to be at most K again. A fresh mixed birth from a pure
endpoint obeys the same argument, its new secondary being at most m.
Pure successors are reset to the corresponding solo endpoint; a low-total
mixed state cannot re-enter the retained exceptional set by persistence.
This proves ancestry-secondary<=K for every final exceptional state.

**Step4: the central optimization collapses.** By Section4 every final
exceptional state has the same faster initial-cohort ancestry. For two
such states, the other physical color still contains at least
M-2K>m unexcluded rooms; that pair cannot give a winning central shot.
If at least one state is nonexceptional, its total is at most min D while
the other's is at most max D. The two states' combined deficit is at most
D_0+D_1. Their capped central cost is consequently at least
E+M-D_0-D_1. Thus if the scalar residual sum exceeds m, no pair wins.
Conversely the two opposite pure solo endpoints realize exactly that
scalar central cost. The exact midpoint theorem gives(S).

No coordinate translation through the final corner, periodicity of the
full frontier there, or unproved all-length secondary barrier is used.
The only new guard after the safe age lemma is the elementary
non-swapping argument of Step3. The finite set of odd lengths below M*
remains governed by the exact bounded-frontier theorem unless covered by
the minimum-budget or high-budget all-length formulas.

The focused reference check in
`src/maturation_odd_eventual_scalar_check.py` compared the scalar answer
with the existing exact joint-frontier solver at both onset-adjacent odd
lengths for (w,m)=(5,4),(7,5),(9,7),(15,12), plus
15x(10^12+1),m12. All nine cases passed in0.039 CPU seconds. The huge
case has tau=1,666,666,666,661 and T=3,333,333,333,322; its reference
solver needed282 ordinary frontier updates. Receipt:
`maturation-odd-eventual-scalar-check.json`. No comparison assumes scalar
necessity on the reference side.

## 8. Manuscript integration checkpoint

The accepted ancestry, eventual scalar and ammunition statements are in
`paper/sections/bounded-odd-frontier.tex`; the accepted all-width minimum
formula replaces the earlier seven-width statement in
`paper/sections/odd-minimum-budget.tex`. The old generic certificate and
affine insertion lemmas are preserved with their labels and conditional
scope because the cylinder proof uses them. Redundant finite charge
tables were removed from the paper, with their exact receipts retained.

An isolated three-pass full manuscript compile passed with no overfull
boxes or undefined references. The new theorem/proof pages were rendered
and inspected at pages24–26 and72–73 of that117-page interim build.
Ordinary proof versus explicit-hypothesis Lean scope is stated in the
manuscript. Root owns the final whole-paper assembly and publication.

## 9. Sharper universal constants and removal of the last-layer case

Independently accepted by root on13 September2026. The bounded-frontier
and eventual-scalar arguments hold with H=b^2+1 and G=m-1, as now used
in Section7 and the manuscript. Historical receipts using the larger
constants are preserved.

The gap proof is immediate from monotonicity, including the final layer.
For a proper solo step (a',c')=(I_0(c+m),I_1(a+m)), all inputs are at
leastm>=2. The I_0 deficit is at least1, and the I_1 deficit is at
least2. Since a'>=a and c'>=c, we obtain

    a'-c' <= m-1,       c'-a' <= m-2.

This replaces the old separate final-layer comparison and2-Lipschitz
argument. The smaller bulk threshold also suffices: X,Y>=b^2+1 and
X+Y<=M imply rho(Y),rho(M-Y)>=b, R(X)>=b+1, and
1+R(E-X)>=b+1. Both inverse profiles are therefore exactly affine.
All subsequent collar, age, and safe-interval arguments are unchanged.

The owned exact solver now uses these constants. The focused check
`maturation-odd-sharp-constants-check.json` repeats nine onset/huge-board
comparisons and additionally compares the accelerated and daywise
retained frontiers state-for-state at all eight finite onset-adjacent
boards; every accelerated case takes a nonzero jump. All passed in
0.051 CPU seconds. The earlier
`maturation-odd-eventual-scalar-check.json` remains the receipt for the
conservative-constant version rather than being overwritten.

## 10. Two tempting closure shortcuts still omit history

An exceptional state's ancestry-primary might always be numerically
larger on a genuine full-board trace, but this is not implied by the
usual relaxed bounds. On15x75,m12, synthetic capacities(1,3), source
(1,2), and quotas8/4 give next capacities(11,9) and state(4,6). The
source has the expected primary orientation; the mixed successor is
exceptional but has its faster physical-color0 primary numerically
smaller. Those capacities are not an actual solo layer. A focused check
of58,301 candidate transitions on five genuine solo traces found no
such reversal, but does not prove an invariant.

A still sharper width-only solo gap also needs genuine history. Selected
actual traces had |D_0-D_1|<=b, but the claim is not inductive even after
imposing coordinatewise monotonicity. On7x7,m5, the synthetic pair(16,18)
has gap2<=b3 and maps to(22,18), a monotone successor of gap4. The
proved asymmetric bound(m-1,m-2) remains the current theorem.

## 11. Fixed-horizon ammunition and the remaining scheduling distinction

**Independently accepted by Euler on13 September2026.** The exact phase
and controllability audit is
`maturation-cyclic-ammunition-independent-review.md`, supported by265
abstract models and76,758 horizon checks in its separate receipt.
In recurrence(A),
all positive calls contribute m except its final call, which contributes
an integer in1..m. The attaining growth schedule therefore has exactly
ceil(mu_p(k)/m) days: one possibly partial first quota, then full quotas.
Any t-day schedule has at most mt total probes. Hence the bottom solo
capacity is exactly

    D_p^bottom(t)=max{k:mu_p(k)<=mt}.

At prescribed horizon t the minimum ammunition is mu_p(k) if this
condition holds, and the target is infeasible otherwise. Free zero steps
at the beginning supply any needed padding; the initial zero phase is
chosen so that the final physical color remains p. This is not a claim
about simultaneous packing of two independently optimal schedules.

The proof is root-independent. For a nonempty finite cyclic family of
surjective nondecreasing maps h_p and m>=1, define least-input inverses
L_p. Surjectivity and monotonicity imply zero preservation and integer
unit Lipschitzness. A target is feasible exactly when the reverse orbit
(p,k)->(p-1,(L_p(k)-m)+) reaches zero; it may increase at individual
steps. Propagating required predecessors through any actual schedule
proves necessity; the least predecessors and quotas min(m,L_p(k))
prove sufficiency. The same cost and horizon result follows for feasible
targets. The concrete bottom profiles provide an instance with descent
over each two-step cycle. With fixed initial phase a, the horizon claim
requires a+t=p cyclically. No free change of a prescribed cohort's phase
is asserted.

In particular L_b=ceil(mu_1(b(b-1))/(b+1)). Equivalently the minority
prefix of size b^2+1 on the width-w square has solo time L_b+1, so the
existing O(b) solo-band arithmetic evaluates the minimum-budget constant.
These consequences and the general cyclic remark are now integrated in
the two owned manuscript sections.

There is an immediate joint scheduling obstruction. For b3,m5,t2,
genuine bottom solo capacities are(4,5). The hypothetical pair(3,2)
has separate minimum ammunition5+4=9<=10. Both optimal one-day blocks
need the last day, so they cannot be packed together at quota5. Indeed
every attainable pair obeys the exact one-step necessary condition

    L_0(x)+L_1(y)<=max(D_0(t-1),D_1(t-1))+m.

The candidate violates it:9>3+5. Thus even exact finite-horizon
single-cohort ammunition is not a sufficient joint feasibility test.

Nor does universal two-block seriality hold in the unbounded bottom
model. At b4,m7,t4, physical-color0 quotas(7,0,1,5) attain(5,6).
No two pure blocks with one shared transition day dominate that pair.
The solo capacities are(14,12), so the counterexample is low-total and
harmless to the full-board midpoint problem. A focused105-case test of
the narrower exceptional-output seriality found no counterexample;
that claim remains unproved. These examples preserve the distinction
between exact scalar costs and actual shared daily scheduling.

## 12. Restricted exceptional-output seriality

**Conjecture, not a theorem.** For every actual full-board precapture
time t, each attainable mixed pair with total greater than
min(D_0(t),D_1(t)) is componentwise dominated by a legal quota word

    A^i, one shared quota, B^j,       i+j+1=t,

where A and B are the two different initial cohorts and every pure
letter assigns the full budget. The zero-length endpoint blocks are
allowed. This assertion concerns finite odd-rectangle profiles, including
both reflected end branches, and is narrower than the false general
seriality in Section11.

`src/maturation_odd_exceptional_seriality.py` checks the conjecture with
a two-mode dynamic calculation: for each initial first cohort, retain
its pure trajectory and all already-switched states; the latter receive
the full opposite quota forever, while each current pure state births
all shared quotas. Monotone Pareto pruning is exact separately within
each mode. This includes every switch day and shared quota without
enumerating exponentially many words. Its reference is the exact full
retained recurrence, not a scalar approximation.

All48 selected finite rectangles/budgets passed, covering3,931 actual
precapture layers in0.85 CPU seconds. Widths were5,7,9,15,21, lengths
were the square, next odd length, and3w, and budgets sampled the minimum,
next budget,2b, and half b^2 where feasible. Receipt:
`maturation-odd-exceptional-seriality.json`. No unbounded conclusion is
drawn from the sample.

The needed exchange lemma is precise: append an arbitrary quota to a
two-block word. If its output remains exceptional, show it is dominated
by another two-block word of the new length. This would prove the
conjecture inductively, using persistence to discard low predecessors.
In the bottom model moving probes later helps their own cohort, but
necessarily moves the other cohort's probes earlier; monotonicity alone
does not justify that exchange. The square/pronic loss bands have
increasing widths, suggesting an integer majorization argument, but the
rounded roots are not discretely concave. The low-total counterexample
of Section11 demonstrates that ignoring this rounding is invalid.

A preliminary abstract test found the same exceptional seriality for28
small non-root monotone1-Lipschitz map pairs satisfying both inverse
concentration inequalities. This is only a hint that a general control
lemma may exist, not evidence that concentration alone implies it.

## 13. A proved exchange above the primary lower-root collar

**Ordinary lemma; root and Euler have independently checked the
argument.** This proves a precise subcase of Section12 rather
than asserting the whole exceptional-output seriality conjecture.
The separate audit is `maturation-suffix-exchange-independent-review.md`.

Consider a legal full-board quota history up to a time t<tau. Suppose
that at time i it is a pure solo endpoint for one initial cohort A,
and write r=t-i. Label A the primary and the other cohort B the
secondary throughout these r steps, following their alternating physical
colors. Assume that every primary inverse input in these r steps is at
least H=b^2+1. Then the final pair is componentwise dominated by a
legal two-block history: full quota on A, one possibly shared day,
then full quota on B. The same horizon t is retained. No assumption
that intermediate output pairs are exceptional is needed for this
conditional lemma. Pure-block degenerations with no shared day are
allowed; t=0 gives the empty word, and r=0 requires no exchange.

**Expansion of the primary map.** On proper inputs z>=H, both lower
root terms in I_p have reached their caps. Thus I_p(z)-z is the
negative of a minimum of a constant and a nonincreasing reflected-root
term. It is nondecreasing. Consequently, whenever v>=u>=H are proper,

    I_p(v)-I_p(u)>=v-u.                                   (X)

This holds across every reflected-root jump, not just within a band.

**The secondary is a bottom process.** Before every step ending before
tau, total deficit plus the daily quota is at most M. Therefore the
secondary inverse input is at most M-H when the primary input is at
least H. In this range the finite inverse equals the bottom inverse
j_p. Indeed, for I_0 the reflected rho(M-z) is at least b; for I_1
the reflected 1+R(E-z) is at least b+1. Write k for the final
secondary deficit, p for its final physical color, and Q for its
total old quota. Section11 gives mu_p(k)<=Q and an exact-target,
minimum-ammunition schedule fitting within r days.

The case k=0 is immediate by assigning every quota to A. Otherwise
put the mu-optimal secondary schedule as late as possible: zero quotas,
one partial positive quota, and then full quotas m. This has the
correct final phase p; padding is at the beginning, and the actual
initial color of B is unchanged. With mu=mu_p(k), its cumulative
secondary quota through the first s episode steps is exactly

    Q_new(s)=max(0,mu-m(r-s)).

The old cumulative quota satisfies

    Q_old(s)>=max(0,Q-m(r-s))>=Q_new(s).

Assign the complementary quota to A in each step. Its cumulative new
quota is therefore at least its cumulative old quota at every prefix.

**Prefix comparison for A.** Let a_s and a'_s be the old and new
primary deficits after s episode steps, and let Delta_s be cumulative
new primary quota minus cumulative old primary quota. We prove

    a'_s-a_s>=Delta_s>=0.                                (Y)

Both states agree at s=0. If the individual new-minus-old quota at
the next step is e, the new input minus the old input is at least
Delta_s+e=Delta_(s+1)>=0. The old input is at least H. Applying(X)
gives(Y) for the next step.

There is no hidden endpoint assumption in this induction. The new quota
word is legal from the full board. Each of its coordinates is bounded
by the corresponding pure full-budget solo coordinate, solely by
monotonicity of the exact inverse maps. Since every new time is at most
t<tau, neither cohort can reach a full deficit, and each relevant
inverse input is proper. Thus(X) is applicable throughout; no earlier
capture or saturated-input branch has been discarded.

**The new B history also remains a bottom process.** Starting with its
first partial quota, the minimum-ammunition schedule uses only full
quotas. Since m>=b+1, each bottom full-quota map sends a count k to
at least k. Its successive inputs are nondecreasing, including the
first partial input. Its largest input is exactly the final least input
L_p(k). The old final secondary transition attained k in the bottom
model, so L_p(k) is at most that old input, which was at most M-H.
Thus every input of the new B schedule stays in the bottom range;
the new finite-board secondary deficit is exactly k. This justifies
using the bottom ammunition schedule despite the finite reflected ends.

The new A output is at least its old output by(Y), and B's final
output is unchanged. Before the packed B block, A receives the entire
budget, so the old pure solo endpoint at time i extends to a longer
pure A block. The first positive B quota supplies the one shared day,
and every later day is pure B. This proves the stated exchange.

The remaining all-length seriality problem is now localized: an
exceptional episode whose primary inverse input enters the lower-root
collar cannot use(X). The negative root jumps there may destroy quota
prefix majorization. They must be controlled using genuine ancestry,
the output's exceptional-total guard, or a sharper corner charge. The
low-total counterexample in Section11 shows that no unconditional
extension of this exchange can hold.

## 14. Frozen checkpoint: a lower-corner credit is real

Research stopped at the user's wrap-up request on13 September2026.
Sections4,5,7,9,11 and13 have the independent ordinary audits identified
above; the all-length scalar criterion and Section12 remain unproved.
The conditional suffix exchange is integrated as
`lem:expansive-primary-exchange` in the existing bounded-frontier section.

The stronger hypothetical charge

    mu_(secondary color)(secondary) <= primary solo deficit-primary

is false on an actual exceptional history. On21x21 at m12, physical
color-zero quotas

    (0,12,0,12,0,12,0,12,0,10)

give at time10 solo capacities(55,56) and actual deficits(1,55).
The faster initial cohort is now physicalcolor1. Its primary lag is1,
whereas the new physicalcolor0 secondary has mu_0(1)=2. The total56
is greater than the slower solo capacity55, so low-total persistence
does not discard this witness. The first nine days are pure primary;
the last day gives two probes to the secondary. One unit of primary
root-rounding credit is therefore real, even in a two-block history.

A bounded check of16,970 actual exceptional states found no credit
greater than one. A separate6,546-transition check of the relaxed
credit-at-most-one condition along selected actual solo traces also
passed. Neither finite check proves that condition or the missing
serial exchange. Synthetic solo capacities can invalidate it, so any
proof still needs actual solo-phase history. No new calculation is
planned during consolidation.

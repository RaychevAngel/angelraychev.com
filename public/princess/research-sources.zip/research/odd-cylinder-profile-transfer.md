# Exact neighborhood transfer along a cylinder

12 September 2026 UTC. An ordinary lemma and an exact computational
check; this does not assert a complete minimum-time formula for even cylinders.

Let Q be a finite bipartite graph with compatible minimizing orders on its
two color classes: the first k vertices minimize the open neighborhood, and
their neighborhood is a prefix of the opposite order. Write g_p(k) for
these minimum sizes and W=|Q|. Every all-odd box supplies such a Q by the
separately proved odd-box nesting theorem.

For Q × P_n, fix a checkerboard color p and let k_j be the number of
selected vertices in column j, where j starts at zero. Then the exact
minimum possible neighborhood size among supports with these column counts is

    Σ_j max(g_{p+j mod 2}(k_j), k_{j-1}, k_{j+1}),

with outside counts k_{-1}=k_n=0. Indeed, the neighborhood in column j
contains the transverse neighborhood and the two adjacent-column supports,
so its size is at least their maximum. Compress every column to the
corresponding prefix. All three sets are now prefixes in the SAME color
class of Q, so their union has exactly that maximum size. Compression
preserves every column count and attains the lower bound simultaneously.

Consequently the global cardinality profile is obtained by minimizing the
displayed sum over Σk_j=k. There is a finite transfer recurrence with state
(previous count, current count, total count). Initially state (0,b,b) has
cost zero. Appending c adds max(g(current),previous,c), and changes the
state to (current,c,total+c). At the end append an outside zero and take
the minimum at each total. This proves the recurrence for EVERY n,
including even n. Direct implementation uses O(n²W⁴) arithmetic operations
and O(nW³) memory; the input profiles of Q are assumed already available.

The script `src/cylinder_profile_transfer.py` implements this recurrence.
For Q=3×3, it compares n=3,…,30 with the known odd-length profiles and
independently exhausts all 524,288 single-color supports on 3×3×4.
All comparisons pass in `research/odd-cylinder-profile-transfer.json`.

## Why this does not solve capture time by two counts

The minimizing column vector can depend on k without forming a nested
family. The lemma supplies exact minimum neighborhood sizes, but does not
prove compatible global minimizing orders. A two-count search using only
these profiles is therefore a lower bound on the true game unless an
attaining geometric comparison or physical schedule is proved separately.

For the checked even lengths, Q=3×3 and m=5 give profile-only lower bounds
9n−12 and physical serial upper bounds 18n−36. For example, n=4 gives
24≤T_5≤36. These observations are finite computational bounds, not a
claimed formula for all even lengths. One of the two usual prefix orders
fails to minimize the neighborhood, precisely the compatibility issue
that the transfer recurrence must not conceal.

# Independent review of the completed path Lean bridge

Review by the affine-rank subtask, 12 September 2026. This is an independent review of the physical geometry, bridge, and final semantic statements written by the path formalization subtask. I authored the imported pure rank and odd active-interval arguments; those are not independently reviewed by this note.

## Findings

No substantive gap or statement mismatch was found in `PathClassification.exact_minimum`, `PathClassification.can_capture_iff`, `PathOddBridge`, `PathOddRank`, `PathOddGeometry`, `PathEvenRank`, or the cohort partition used by the two lower bridges.

The graph is the actual open path on `Fin n`: adjacency is exactly a difference of one. `GuaranteesAt` quantifies over actual finite compulsory-movement walks avoiding all previous inspections. Both final theorems quantify over arbitrary room sets with the global budget on every day. They do not assume parity-restricted probes, monotonicity, intervals, a sweep strategy, or a bound on geometric complexity of beliefs. Splitting a global probe set into its two current physical parities preserves its cardinality exactly.

The timing convention is consistent: the first inspection has index zero, `days` inspections end at index `days−1`, and the lower bridge takes an empty belief after `k+1` updates. The one-room graph is handled separately and is never incorrectly declared captured merely because it has no outgoing edge. Paths of size at least two have the proved no-dead-end property needed for the empty-next-belief equivalence.

The odd matching construction leaves a chosen zero-based even vertex exposed and pairs every other vertex along an edge. Its use is valid precisely when that vertex is missing from the survivor set. If none is missing, the neighborhood contains the entire smaller parity. This proves the arbitrary-support bound without a prefix assumption. The smaller-parity strict-expansion proof excludes equality by a descending closure argument. The odd rank labels are consistent: physical one-based parity 1 is initially larger and corresponds to abstract phase 0; physical parity 0 is initially smaller and corresponds to phase 1. Empty supports have rank zero.

The even historical mark records a proper zero-surplus neighborhood and supplies the endpointless invariant. A marked surviving set therefore expands strictly on the next round. Unmarked states above the cap are handled by clipping, so the physical lemma needs no implicit cardinality hypothesis beyond the proved rank comparison. The constant abstract counter is initialized below the physical rank and remains below it by monotonicity.

The exceptional odd bridge derives the correct positive remainder `r=m−1`, the even block count, and the shape `n=q(2m−1)+m+1` before invoking the phase theorem. It first derives the weaker time `2q+1`, then excludes equality. The final prepared formula includes all positive path sizes and budgets, including `n≤m`, the single edge with one probe, and longer paths with one probe.

## Limit of this review

The ordinary theorem statement is a deterministic capture-by-deadline result. As usual for this game, adapting to previous failures follows the single all-failure branch; that explanatory reduction is not an explicit separate strategy datatype in the final theorem. The theorem does not address a target allowed to stay still, probabilistic expected capture time, costs other than daily probe cardinality, zero budget, or zero rooms.

The formalization subtask is producing the clean dependency rebuild and axiom receipt. This note records a semantic and mathematical audit, not a second dependency rebuild.

# A recent-reset criterion for the exact odd-board midpoint

13 September 2026. Ordinary deadline-only ancestry argument, independently
reviewed and accepted by root, including retention domination, pure ancestry,
and the time-homogeneous inverse bound. It proves a sufficient condition for scalar necessity,
not universal credit control or equality of all partial-state frontiers.

Let w=2b+1, n>=w odd, b>=2, b+1<=m<M, E=M+1. Use the exact solo deficit
capacities D_p(t), the first solo capture time tau, and L=tau-1.
Write Delta_t=D_0(t)-D_1(t).

## A scalar reset erases every exceptional mixed history

Call time i a reset if i=0, or if

    Delta_i * Delta_(i-1) >= 0.

At every reset there is no attainable exceptional mixed state. If
Delta_i=0, exceptionality is already impossible by total concentration.
If Delta_(i-1)=0, every source total is at most the previous smaller solo
capacity, and the accepted mixed-successor persistence lemma excludes
exceptionality at the next layer. If both gaps are nonzero with the same
sign, the same physical color is faster at both layers. But the accepted
fastest-ancestry proof says that every exceptional mixed successor from
the faster cohort requires the faster physical color to flip. The slower
pure source and all low-total sources cannot produce exceptional mixed
successors. Thus this case has none either.

Equivalently, an exceptional episode can only pass through successive
strict gaps whose signs alternate. This condition refers to actual solo
layers, so it does not assume the false synthetic-capacity invariants.

## A terminal secondary bound from the most recent reset

Suppose the final solo capacities are unequal; let q be the physical
color of their ancestry-secondary, and put

    c=ceil((C_q-m)/2).

For any reset i<=L, every relevant retained exceptional state at L has
ancestry-secondary deficit at most

    D_q(L-i).

To justify this rigorously, use the accepted exact retention construction.
Every pure state is replaced by its dominating solo endpoint. A mixed
exceptional state is retained only when its source is exceptional or is
such a pure endpoint. Since no exceptional mixed state exists at i, any
retained final exception has a pure ancestor at some time j>=i. Replace
its earlier history by the pure solo preparation of that ancestor. In
this realization its secondary is zero at i and at j. Giving this cohort
the entire quota on every one of the remaining L-i days bounds its final
deficit by D_q(L-i), by monotonicity of the exact inverse profiles.
Their time-homogeneous physical-color recurrence applies from either
zero phase; the final physical color is q. No arbitrary partial-state
normal form is being asserted.

Therefore the following scalar-only condition proves scalar necessity:

    there is a reset i<=L with D_q(L-i)<c.                 (Reset guard)

Indeed two retained exceptional histories have the same secondary color
by fastest ancestry, and each has deficit at most c-1 there. Their
central intersection in that color alone has at least

    C_q-2c+2 >= m+1

rooms. They cannot improve the middle-day winning decision. Pairs with a
nonexceptional history are already handled by the accepted concentration
and retention theorem. The pure endpoints supply sufficiency. Thus under
the reset guard,

    T=2tau-1 if E+M-D_0(L)-D_1(L)<=m, and2tau otherwise.

At a final solo tie the same conclusion holds directly. A prior solo tie
is a reset, and the following layer is also a reset; failure of strict
winner alternation supplies further resets even without a tie.

## A fixed-size certificate, preserving the absolute numerical endpoint

Fix K=16 and J=16, independently of all inputs, and restrict to

    16(2m-w)>=b^2.

Test candidate reset ages j=0,...,16 only, omitting negative times L-j.
The short capacities D_p(j) use16 ordinary inverse-pair updates. The
capacities at times L,L-1,...,L-17 are each obtained from the accepted
49-block solo evaluator. Two additional solo duration evaluations give
tau. Thus at most38 calls to that fixed evaluator and16 ordinary inverse
updates suffice to test the reset guard and evaluate the resulting exact
physical time. This is an absolute bounded numerical certificate region,
without any joint frontier, variable table, sum, or optimization.

More generally any fixed K,J can be chosen once. Changing them with the
input to force success would not establish the claimed absolute bound.
If none of the fixed tests succeeds, this criterion makes no necessity
claim; the one-day interval and sufficient short construction remain valid.

## Verification and remaining obstruction

`src/bridge_odd_clock_reset.py` implements the fixed K=J=16 certificate
and compares every issued time with the separately proved exact retained
solver on selected short and longer boards. Its receipt is
`research/bridge-odd-clock-reset-check.json`. The proof is the ancestry
argument above, not the finite agreement.

This bypasses the ammunition credit conjecture after sufficiently recent
resets. Histories whose fastest initial cohort remains unchanged across
a long final epoch are still open. In particular the square11x11,m7
has its latest reset at time2 and precentral time24; its unrestricted
secondary growth bound45 is too large for the required cutoff27.
This failure is a failure of the sufficient guard, not of scalar necessity.
It isolates the remaining task to a single persistent ancestry epoch and
does not mistake synthetic partial-state obstructions for physical ones.

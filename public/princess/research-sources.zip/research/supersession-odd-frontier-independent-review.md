# Independent audit: bounded exceptional frontier on odd rectangles

13 September 2026. Root reviewed Section 8 of
`supersession-odd-midpoint.md`. **PASS as an ordinary theorem.**

The gap estimate excludes the full jump of the majority inverse and uses
the proper two-Lipschitz estimates at a common smaller argument; it also
handles a minority input equal to M. This gives G=2m+2 before capture.

For a mixed exceptional successor, both nonzero inverse outputs allow the
two concentration inequalities. A predecessor with total at most the
smaller solo capacity therefore cannot produce that successor. This is
the required persistence fact, including histories of arbitrary physical
strategies after their canonical domination.

With both deficits at least H=(b+1)^2, the input sum at most M keeps both
reflected root arguments above the opposite input. All four corner terms
are saturated, so the two surpluses are exactly b and b+1. Over two bulk
steps the mixed total gains 2(m-w), while each solo capacity gains at least
2m-w. Thus its lag grows by at least w. The exceptional lag lies in [0,G),
which gives the stated conservative run bound. Entering that run changes
the smaller deficit by at most m, yielding

    K = H-1+2m(floor(G/w)+1).

The retained states are attainable, not hypothetical envelope points.
Monotonicity preserves domination through a quota split. Every omitted
low-total state, paired with any state, has uncapped combined total at
most the sum of the two solo capacities; the opposite solo endpoints
already attain that value without clipping. Hence omitting those states
preserves the exact central two-copy optimization.

There are at most G allowed exceptional total values and at most
2(K+1) endpoint positions at each total. The bound 2+2G(K+1) is therefore
independent of board length. This proves the bounded-state recurrence;
it does not establish the proposed scalar midpoint test or, by itself,
license jumping across many transition layers.

## Independent audit of the finite-history jump

Root subsequently reviewed Section 10 and the complete manuscript section
`bounded-odd-frontier.tex`. **PASS as an ordinary theorem**, with the stated
safe-collar constants. In normalized coordinates the primary inverse is
affine, the secondary inverse sees only its initial corner, and each
nonzero mixed continuation increases loss minus secondary deficit by at
least one. Exceptionality bounds that quantity above by G, and its initial
value is at least -K. Thus all inherited mixed histories disappear within
G+K safe transitions. New histories start at solo endpoints; their rules
and filters are periodic with period two. This proves the exact jump,
rather than inferring periodicity from a finite numerical sample.

The entry and exit collars follow from the minimum two-step solo gain
2m-w. The central-cut identity retains both color capacities and their
separate clipping. It uses actual attainable prefixes and their reflected
reverse schedules, so a low scalar objective is physically realizable.

An independent implementation built the forward profiles from actual grid
neighbors, computed the full joint frontier to capture, and compared 81
small cases with the accelerated solver. Four larger cases compared
accelerated and daywise retained frontiers. All passed in 1.367 seconds;
receipt: `supersession-odd-acceleration-independent-check.json`. These
checks support the independently read unbounded proof; they do not replace it.

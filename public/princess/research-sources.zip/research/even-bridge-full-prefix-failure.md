# Full-board varying budgets defeat the all-corner prefix family

12 September2026. Ordinary finite counterexample, independently checked
below by two different state representations. Final external audit pending.

## Statement and precise scope

On the full6×6 board there is a winning five-day strategy with daily
inspection budgets

    (6,8,5,6,18),

but no winning strategy in which the survivor set in each current color
is always a weightlex prefix, even after allowing every corner reflection
and every axis permutation independently on every day and in each color.

This refutes the prescribed-budget version of the full-board prefix
normal form. It does not refute its constant-budget version. Separate
checks at every constant budget on6×6 find the same optimum with and
without the prefix restriction.

## An actual winning strategy

Use coordinates0≤x,y≤5 and abbreviate(x,y) byxy. Initially focus on the
even-color cohort. Inspect

1. {02,04,13,15,24,35};
2. {01,10,12,21,23,30,32,34};
3. {31,33,40,42,51};
4. {25,34,43,45,52,54};
5. all18 odd-color rooms.

The focused cohort's successive pre-inspection sizes are18,14,9,6;
day4 captures it. Its successive survivors have sizes12,6,4,0. The
day2 survivors are the odd rooms in rows x=4,5:

    {41,43,45,50,52,54}.

This six-room strip is not a corner weightlex prefix for any axis order.
The other cohort is never inspected during the first four days: its
current color is always opposite the focused one. It therefore remains
full and has returned to its original odd color for day5. The final
18 inspections capture it.

The verifier replays the listed sets on all36 physical rooms, without
assuming a cohort decomposition or any neighborhood profile.

## Complete exclusion of prefix strategies

There are120 distinct prefixes in each color after all four reflections
and two axis orders are included; both the empty and full classes are
included. Their physical neighborhoods belong to the opposite prefix
family. Represent a current state by the two actual prefix masks(a,b).
For every day with budget m, enumerate every pair of prefix survivors
r⊆a,s⊆b satisfying

    |a\r|+|b\s|≤m,

and replace the state by(N(s),N(r)). These are exact physical transitions,
including all reallocations of the daily quota between the two cohorts.
There is no greedy allocation, pruning, or assumption of one active cohort.

Starting at both full classes, complete propagation gives:

| Inspections already made | Daily quota just used | Distinct states | Minimum remaining rooms |
|---|---:|---:|---:|
|1|6|105|32|
|2|8|945|27|
|3|5|1409|25|
|4|6|2597|20|

Every possible prefix strategy therefore has at least20 possible rooms
on day5. Eighteen final inspections cannot capture them all. This proves
the claimed failure.

Source: `src/even_bridge_full_prefix_failure.py`.
Receipt: `research/even-bridge-full-board-prefix-failure-6x6.json`.
The source uses global36-bit room masks and direct physical adjacency.
A prior independent local-color implementation obtained the same four
layer counts and minima.

## The maximum-cardinality distinction

The discovery began with the one-cohort word(0,8,5,6). The unrestricted
maximum winning initial size is12. A12-room initial PREFIX can win if
later survivors may be arbitrary. However, the maximum initial prefix
with an entire prefix-survivor strategy has size11.

Consequently these are different proposed inductive statements:

* a maximum-cardinality winning support can be chosen as a prefix;
* a maximum-cardinality winning support has a strategy that stays in
  prefixes at every future round.

The first statement does not imply the second. The example defeats the
second; it does not defeat the first. The full36-room extension above
also prevents quota reallocation between cohorts from repairing the
second statement in the varying-budget setting.

## Constant budgets remain a separate conjecture

Exact pyramidal-state optimization and the prefix-restricted game agree
on the full6×6 board at all constant budgets: infeasible at m≤3;
T4=22,T5=14,T6=10,T7=8,T8=T9=6,T10=5;
T11=T12=T13=4;T14=...=T17=3;T18=...=T35=2;T36=1.
The finite nontrivial comparisons and physical replays are recorded in
`research/even-bridge-full-constant-prefix-6x6.json`. Budgets below three
inherit infeasibility, budgets above18 inherit the two-day construction,
and the one-day threshold is the room count.

### Constant budgets already fail from a partial prefix

The restriction to a full initial board is essential even with a
constant daily budget. On6×6, start from the10-room corner prefix

    A={00,02,04,11,13,15,22,24,33,35}.

Four probes per day can capture it in five days, using

1. {15,24,33,35};
2. {05,14,23,32};
3. {04,13,22,31};
4. {03,12,21,30};
5. {00,02,11,20}.

The physical pre-inspection counts are10,9,8,6,4. However, every
reflected/permuted-prefix survivor strategy needs at least six days.
A complete breadth-first search of the physical prefix family has
minimum possible counts10,9,8,7,5 at depths0,1,2,3,4, so four final
shots on day5 do not suffice. A terminal state is first reached for
day6. Only56 distinct prefix states are encountered.

The direct checker `src/even_bridge_constant_partial_prefix.py` replays
the five-day witness and independently enumerates the restricted game.
Receipt:`research/even-bridge-constant-partial-prefix-check.json`.
No claim that five is the unrestricted minimum is required to prove
the normal-form failure. A separate exact compression computation also
found unrestricted minimum five, but the displayed witness is enough.

Thus a Bellman induction claiming prefix sufficiency from every partial
prefix at constant budget is false. The full-board constant-budget
version is still a separate open statement.

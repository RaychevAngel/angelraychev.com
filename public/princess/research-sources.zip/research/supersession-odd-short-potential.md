# Uniform historical potential for odd-short, even-long rectangles

**13 September completion.** The stated high-budget formula is now
proved for every parameter in this note, with no remaining short-board
exception. The root agent's uniform two-day total-deficit argument closes
q=2, and the q=1/q=3 reductions close the other small quotients; Euler's
complete independent review is
`supersession-odd-short-two-day-independent-review.md`. Sections4 and6
below preserve the intermediate open questions and failed routes as a
research log; they no longer describe a gap in this capture-time theorem.
The stronger full-cohort ammunition and small-support overlap conjectures
remain unproved and were not needed.

12 September 2026. Active research, owned by the potential/audit lane.
The physical upper and critical-front geometry were independently accepted
in the preceding run. Sections 1–3 now have an independent ordinary-proof
review from the root agent: see
`supersession-odd-short-corner-independent-review.md`. They prove the lower
bound and its stated agreement with the upper, leaving the equality family
(5) open. Later sections are explicitly marked research. No paper, website,
or Lean source has been changed.

Let w=2b+1≥3, n≥w even, h=wn/2, B=b(b+1), and B+1≤m<h.
Put D=2m−w and 2h−w−1=qD+r, 0≤r<D. Use the accepted unbounded
corner profiles L_0,L_1, remainder cost J, and rank potential F from
`high-budget-odd-rectangles.tex`. The proposed upper is
2q if r=0; 2q+1 if r>0 and 2J(r)≤m; otherwise 2q+2.

## 1. The physical/history potential bridge

For each initial cohort, give its current before-inspection belief a bit z.
Set z=1 exactly when its preceding after-inspection survivor had surplus b
and strict-middle size b²<s<h−B; otherwise set z=0. Initial bits are zero.
Use the rank 2k+z, where k is the current cardinality.

Consider p useful inspections, survivor s=k−p, and next belief size j.
For k>m and 0<s<h−B:

* If s>b² and surplus is b, critical-front incompatibility forces z=0
  and the target bit is one. Its rank is exactly 2(s+b)+1.
* If s>b² and surplus exceeds b, the target bit is zero and its rank
  is at least 2(s+b+1). This dominates the appropriate alternating
  unbounded-profile rank for either source bit.
* If 0<s≤b² and z=0, the exact static profile gives j≥L_0(s): the
  reflected term is saturated because h−s>B. If z=1, the accepted
  conditional minority-corner lemma gives j≥L_1(s). The target bit
  is zero in either case. Both L_0(s),L_1(s) are at most b²+b+1≤m,
  so F(2L_z(s))=F(2L_z(s)+1)=L_z(s). Hence the bit differs from the
  old alternating convention only where it has no effect on F.

Monotonicity and the accepted interior inequality therefore yield
F(2k+z)≤p+F(2j+z') in all these cases. For k≤m, F(2k+z)=k and
matching gives j≥k−p, so the same inequality is immediate.

For a co-small survivor let x=h−s≤B. Its target bit is zero. The
exact static minimum is g(s)=h−x+rho(x), where
rho(x)=min{a≥0:x≤a(a+1)}. Define

    C=min_{0≤x≤B}[x+F(2(h−x+rho(x)))],
    Phi_z(k)=min(F(2k+z), max(0,C−h+k)),   Phi_z(0)=0.

Matching implies that noncapture deficits increase by at most the useful
inspections. This verifies the inequality against the target's linear
branch. In the interior the preceding argument verifies its F branch;
at the far corner C's definition verifies that branch instead. Capture
costs at least k=F(2k+z). Consequently every actual transition satisfies

    Phi_z(k)≤p+Phi_(z')(j).

Both full initial supports have potential C and the final empty supports
have zero. Summing against the shared budget proves

    T_m≥ceil(2C/m).                                      (1)

The only geometric inputs are the accepted static profile, sharp critical
front theorem and its conditional small-corner consequence. No global
shape-normalization or serial optimality is assumed.

## 2. Universal one-unit bound for the corner constant

**Lemma (independently reviewed).** For every parameter in the stated range,

    F(2h)−1≤C≤F(2h).                                    (2)

Moreover C=F(2h) when r=0.

Here is a direct proof. Write rho(x)=a, so 0≤a≤b and x≤a(a+1).
For x>0, a≥1. Set t=x−a≥0. The rank decrease is 2t≤2b²<D,
so it crosses at most one period boundary. Put d=b−a≥0.
The actual cardinality branch of F is at least its periodic expression
when a crossing enters the final period; thus using that periodic
expression gives an upper bound on the possible loss below F(2h).

### No period crossing

For even r=2k, k≥t, the loss is

    L_1(k)−L_1(k−t)−x
       = rho_1(k)−rho_1(k−t)−a,

where rho_z(s)=L_z(s)−s and rho_z(0)=0. If k−t>0, put
c=rho_1(k−t). A clipped c=b+1 is immediate; otherwise c=Q(k−t)≥2.
Since t≤a²,

    k≤c(c−1)+a²≤(c+a)(c+a−1),

so the loss is at most zero. If k−t=0, Q(k)≤a+1 gives loss at most
one. This identifies the only possible no-crossing discount: the target
remainder is zero, and the source's pronic-root cost is one greater
than a. In particular r=0 has no such discount.

For odd r=2k+1 the target lower-corner argument k+1−t is positive.
The analogous estimate R(s+t)≤R(s)+a, using s≤R(s)² and t≤a²,
gives loss at most zero, including clipping.

### A period crossing, even source remainder

Now r=2k and t>k. Put c=rho_1(k), and

    ell=m−b+k−x+a≥b²−a²+k+1.

The loss from the periodic expressions is

    d+c−rho_0(ell).                                     (3)

If k=0, then c=0 and ell≥d(b+a)+1>d², so (3) is negative. This
also proves C=F(2h) for r=0.

If k>0, 2≤c≤a+1 and k≥(c−1)(c−2)+1. Therefore

    ell−(d+c−2)² ≥ 2d(a−c+2)+c >0.

Since d+c−1≤b, the clipped root rho_0(ell) is at least d+c−1.
Expression (3) is at most one.

### A period crossing, odd source remainder

Write r=2k+1, t>k, c=rho_0(k+1). Then 1≤c≤a and
k≥(c−1)². The same ell as above gives loss

    d+1+c−rho_1(ell).                                   (4)

The lower estimate yields

    ell−(d+c−1)(d+c−2) ≥ 2d(a−c)+3d+c >0.

Since d+c≤b, rho_1(ell)≥d+c, and (4) is at most one.
This finishes (2), while x=0 supplies C≤F(2h).

## 3. What is already determined, and the sole remaining equality case

Since F(2h)=qm+J(r), (1)–(2) match the physical upper in every case
except possibly

    r>0,  J(r)=floor(m/2)+1,  C=F(2h)−1.                (5)

Indeed r=0 has C=qm; if 2J≤m, the positive remainder J≥2 ensures the
rounded lower is at least 2q+1. If 2J≥m+3, even losing one potential
unit per cohort still gives 2q+2. The only gap is 2J=m+1 for odd m or
2J=m+2 for even m, which is exactly (5).

The earlier finite check's seven one-day gaps all satisfy (5). They are
not counterexamples to the physical upper, and are not proofs that it is
optimal. Eliminating the remaining gap requires a strictness argument:
a putative 2q+1-day schedule has potential slack at most one when m is
odd and zero when m is even. First-day corner discounts can sometimes
occur in both cohorts (e.g. b=2,m=11 with quotas 5 and 6), so a blanket
claim of first-day strictness is false. The next transition or a more
global equality invariant must be used.

## 4. Research log and remaining work

* Accepted: geometric/history interpretation of the proposed potential,
  conditional on the previously proved F interior lemma.
* Independently accepted ordinary proof: the universal one-unit corner
  bound in Section 2 and the physical potential bridge in Section 1.
* Exact except for (5): all other
  high-budget parameter tuples already match the physical upper.
* Open: rule out a (2q+1)-day schedule in (5), or find a physical
  counterexample to the candidate upper's optimality.
* Failed shortcut: both first departures need not be strict. Preserve
  the 5×16,m=11 two-discount example when attacking equality.

## 5. A uniform co-small-to-critical incompatibility lemma

**Ordinary lemma, independently accepted by root.** Let a survivor R
have cardinality h−x and surplus a≤b, and let A be the complement of N(R).
Then |A|=x−a and N(A) is contained in the x-cell complement of R.
If the next survivor S is strictly middle and critical, its phase-forced
orientation contains the complete favored physical endpoint row. Since
A and S are disjoint, A omits that row. It is consequently in the minority
class of the odd-by-odd rectangle obtained by removing the row.

For x≤B, |A|≤B−a≤B. The smaller rectangle's minority capacity is
M'=h−b−1≥2B, so M'−|A|≥B+a; its opposite-corner term cannot reduce
the neighborhood surplus below b+1. Thus its
accepted odd profile, together with |N(A)|−|A|≤a≤b, gives

    |A|≤a(a−1), and hence x≤a².                         (6)

Equivalently a co-small survivor with x>a² cannot precede a strict-middle
critical survivor. This is a cardinality-and-history consequence for
arbitrary physical supports; it assumes no normalization.

There is a matching arithmetic strengthening. For any 0≤a≤b and
0≤x≤a², write t=x−a (negative t only makes the conclusion immediate).
Repeating Section 2 with t≤a(a−1) proves

    x+F(2(h−x+a))≥F(2h).                               (7)

For the no-crossing even case, a zero target remainder now gives
Q(t)≤a, so the old one-unit discount disappears. All other no-crossing
cases already had no discount. At an even crossing, c≤a and

    ell−(d+c−1)²≥2d(a−c+1)+a−c+3>0,

so rho_0(ell)≥d+c. At an odd crossing, c≤a and

    ell−(d+c)(d+c−1)≥2d(a−c)+d+a−c+2>0,

so rho_1(ell)≥d+c+1. Both discounts are now nonpositive.
Thus every departure responsible for the loss in C is incompatible with
a critical move on the following day.

## 6. Why that new lemma does not yet finish the equality family

The original historical relaxation admits winning 2q+1-day traces in all
four odd-budget examples, including the already proved actual value ten
on 5×16 with m=11. The corresponding nine-day trace is therefore a
counterexample to the sufficiency of that relaxation, not a physical
counterexample. See `supersession-odd-short-slack-check.json`.

A stronger marker records either a strict-middle critical survivor or a
co-small survivor with x>a². The latter marker forbids a critical next
move by (6). A direct arithmetic test of the common-cap rank F(2k+z)
then passes the 3×12, 5×16, 29×64, 31×68 and 37×80 examples. However,
it still fails on small-corner jumps for 9×10,m=21 and 15×18,m=59.
See `src/supersession_odd_short_marked_corner.py`. These failures are
again failures of a deliberately relaxed relation.

For example, in 9×10,m=21 a marked 30-cell belief may delete21 and
leave a hypothetical nine-cell survivor of minimum surplus three. Its
excluded set A has15 cells and surplus at most four. Whether these two
efficient small supports can be disjoint is an additional geometric
question not encoded by the marker.

The tentative two-corner inequality is

    |A|+|S|≤a²+c²−max(0,a+c−b−1)²,

for disjoint same-color small supports with surpluses at most a,c≤b.
It has not been proved. A cruder claim that a+c>b+1 itself forces
intersection is FALSE: on width five two disjoint opposite-corner
three-cell supports each have surplus two. Preserve that counterexample.

An alternative possible target is that a full cohort always needs at
least F(2h) useful inspections in total under the daily cap m, regardless
of the number of days. Restricted up/down-pyramid Dijkstra searches give
27=F(36) on 3×12,m4 and50=F(80) on5×16,m11. These are only restricted
family minima and physical attaining schedules; they prove no lower
bound for arbitrary supports. The full ammunition assertion is open.

## 7. Uniform closure when the co-small and small collars cannot meet

**Complete ordinary theorem, independently accepted by root.** Under
the original parameter assumptions, additionally suppose

    h>m+2b²+b.                                          (8)

Then the physical upper stated at the start of this note is the EXACT
capture time. In particular this covers every q≥4, uniformly in b,m,n.
This is not a claim that the formula is optimal for the excluded short
boards.

### 7.1 A parity-corrected corner inequality

For 0≤a≤b and 0≤x≤a(a+1), put t=x−a. For U=N or N−1, where N=2h,

    x+F(U−2t+1)≥F(U).                                  (9)

If t≤0 or the source is in the cardinality branch, monotonicity and
F(v)≥floor(v/2) prove this immediately. Otherwise write the source
remainder as r, and use the periodic expression for the target; if it
enters the final cardinality branch, that expression is only smaller
than the actual F. There is at most one period crossing since 2t<D.
Write d=b−a and rho_p(v)=L_p(v)−v, with rho_p(0)=0.

Without a crossing, for r=2k put v=k−t+1>0. The possible discount is

    rho_1(k)−a−1−rho_0(v).

When neither clipping makes the inequality immediate, v≤R(v)² and
k=v+t−1≤R(v)²+a²−1 imply Q(k)≤R(v)+a+1, proving (9).
For r=2k+1, put v=k−t+1>0. The discount is

    rho_0(k+1)−a−rho_1(v).

Since k+1=v+t≤Q(v)(Q(v)−1)+a²≤(Q(v)+a)², it is nonpositive.

At a crossing put ell=m−b+k−x+a≥b²−a²+k+1.
For r=2k, the discount is d+rho_1(k)−rho_1(ell).
If k=0, ell>d(d−1) suffices. Otherwise put c=rho_1(k)≤a+1;
k≥(c−1)(c−2)+1 and

    ell−(d+c−1)(d+c−2)≥2d(a−c)+3d+2>0.

Thus rho_1(ell)≥d+c; clipping is safe because d+c≤b+1.
For r=2k+1 put c=rho_0(k+1)≤a. The discount is
d+c−rho_0(ell+1), and

    ell+1−(d+c−1)²≥2d(a−c+1)+2>0.

Therefore rho_0(ell+1)≥d+c, with d+c≤b. When the corrected target
is exactly on a period boundary, use J(D)=m, equal to the next period's
zero remainder. This completes all endpoint cases in (9).

Applying (9) with U=N−1 and a=rho(x) gives the useful strengthening

    C≥F(N−1).                                          (10)

Consequently, in the only unresolved case (5), one necessarily has
F(N)≥F(N−1)+1.

### 7.2 Stronger marker and common cap

It suffices to handle (5), since Sections 1–3 already settle every
other case. Mark a current belief by z=1 if its preceding survivor
was either (i) strict-middle critical, or (ii) co-small, of deficiency
x and surplus a≤b satisfying x>a². Otherwise mark it zero.
Initial marks are zero. Use

    Psi(k,z)=min(F(N),F(2k+z)), with Psi(0,z)=0.          (11)

Two successive strict-middle critical survivors remain impossible.
Moreover a source marked by case (ii) cannot have a strict-middle
critical next survivor by Section 5. Thus every strict-middle critical
move has source mark zero and target mark one; higher surplus again
dominates the ordinary alternating rank step.

For a co-small survivor let its deficiency be x≤B and surplus a.
If a>b, its rank increase is already large enough for the interior
inequality. If a≤b, matching the transposed complement and the static
profile give x≤a(a+1). If x≤a², (7) gives
x+F(2(h−x+a))≥F(N); if x>a², (9) gives the same inequality with
the target mark one. Thus in both cases

    x+F(target rank)≥F(N).                             (12)

Let the source deficiency be d=h−k, so p=x−d useful probes were used.
The accepted elementary inequality F(u+2)≥F(u)+1 gives

    d+F(N−2d)≤F(N).

For a marked source d≥1, (10) and the fact that we are in (5) likewise
give d+F(N−2d+1)≤F(N−1)+1≤F(N). Combining either inequality with
(12) yields Psi(source)≤p+F(target rank). The same inequality against
the common cap F(N) is immediate, proving the step for every co-small
target. No information about the source shape was suppressed here.

For a small survivor s≤b², an unmarked source uses L_0(s), and a
case-(i) marked source uses the accepted conditional L_1(s) bound.
These neighborhoods are already in the cardinality branch, so target
mark zero causes no loss. A case-(ii) marked source has cardinality
k=h−x+a≥h−B; by (8), k−m>b². It therefore cannot make a small-corner
move at all. Capture or a source k≤m is handled directly by cardinality
and matching.

We have proved every actual step lowers (11) by at most its useful
probe allocation. Both initial values are F(N), hence

    T≥ceil(2F(N)/m).

In case (5) this is exactly 2q+2, closing the sole gap. This proves the
asserted exact formula under (8).

Finally, q≥4 implies h≥4m−3b−1, and therefore

    h−m−2b²−b≥3m−2b²−4b−1≥b²−b+2>0,

which verifies the promised uniform q≥4 corollary.

The redundant exact-integer check
`supersession-odd-short-marked-corner-check.json` covers112,566 instances
of (9) and complete relaxed transition checks for five genuine gap
tuples satisfying (8), in0.55 CPU seconds. A useful failed stronger
claim is that (11) works for every source remainder: on9×36,m21 the
relaxed step (161,marked)→(153,marked) using11 probes drops the common
cap by12. That tuple is not in (5), and F(N)=F(N−1); it is already
handled by the original envelope. This confirms that the explicit
reduction to (5) in Section7.2 is necessary.

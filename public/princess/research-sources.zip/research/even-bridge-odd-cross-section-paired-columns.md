# A minimum-surplus frontier lemma for an odd cross-section and even length

12 September 2026. Ordinary lemmas independently accepted by root and
Euler. Their completed eventual-periodicity application is recorded in
`even-bridge-odd-cylinder-eventual-periodicity.md`; this note supplies
the geometric prerequisites. No new solver or large enumeration was used.

## The paired-column contraction

LetQ be a connected bipartite graph withA=2b+1 vertices and bipartition
(U,V), where|U|=b+1,|V|=b, andb≥1. An odd Hamiltonian transverse graph
has precisely these color sizes. OnQ×P_(2L), match columns2j and2j+1.
For either current physical cohort, identify its matched pairs with
(v,j), v∈V(Q),0≤j<L.

The resulting directed graphD_p has loops, bidirectionalQ-edges within
every layerj, and one-way longitudinal fibers. For phasep=0, choose
the convention thatU fibers flow left andV fibers flow right; phase1
reverses both directions. There is no dependence on the pair indexj.
The directed outside boundary of a supportR has cardinality equal to
its ordinary one-step neighborhood surplus before contraction.

Puth=AL andK=A². The statements below concernK<|R|<h−K.

## A giant-SCC observation

Suppose a boundary setB has sizes≤b. If someU fiber and someV fiber
both avoidB entirely, all completely undeletedQ-layers belong to one
strongly connected component. Each such layer is strongly connected
because itsQ-edges are bidirectional; the untouched opposite-flow
fibers provide connections in both longitudinal directions between
any two such layers.

At mosts layers contain a point ofB. Thus this SCC contains all but
at mostAs vertices of the full array, counting the deleted vertices
among the exceptions. IfR is outgoing-closed inD_p−B, it must contain
that whole SCC or avoid it, giving|R|≤As orh−|R|≤As. Either is
incompatible with the middle-size assumption becauseAs<A².

In particular a middle support has surplus at leastb: ifs<b, an
untouched fiber exists in each color. If its surplus is exactlyb,
there is still an untouchedU fiber. Consequently everyV fiber must
meetB. The total boundary size then forces exactly one boundary point
(v,c_v) on eachV fiber and no boundary points on anyU fiber.

There is at least one completely undeleted layer in the middle regime:
h>2A² impliesL>2A>b. Thus the SCC argument never relies on an empty
collection of layers.

## Exact-surplusb forces a common frontier

Consider phase0, in which the boundary-freeU fibers flow left. Each
row setR_u foru∈U is a left prefix, possibly empty or full initially.
For everyQ edgeuv withu∈U,v∈V, outgoing closure of the bidirectional
edge gives

    R_v⊆R_u,           R_u\R_v⊆{c_v}.

Thus adjacent fiber cardinalities differ by at most1. Connectivity
ofQ gives a global cardinality range at mostA−1. The middle-size
assumptions imply that every fiber has at least2 occupied and at least2
unoccupied positions: the average occupied count is greater thanA,
and the average unoccupied count is also greater thanA, while the
range is at mostA−1.

Fix an edgeuv and writeR_u={0,...,k−1}, with2≤k≤L−2. The displayed
inclusions say thatR_v is either that prefix or that prefix with its
single pointc_v removed. TheV fiber flows right. If a removed point
c_v were strictly belowk−1, thenk−1 would remain occupied and its
out-neighbork would be an additional boundary point, a contradiction.
If no point belowk is removed, the right endpointk itself is the
boundary. Therefore

    R_v={0,...,c_v−1},       k∈{c_v,c_v+1}.

Every fiber is thus a left prefix. Across each edge, theU-prefix length
equals theV-prefix length or exceeds it by1. The phase1 statement is
the longitudinal reflection: all fibers are right suffixes, with the
same cardinality relation. The common orientation is forced by the
phase, rather than freely selectable.

The lengths vary by at most the diameter ofQ. Relative to a fixed
fiber's length they have finitely many possibilities: along a spanning
tree there are at most2^(A−1) choices of the0/1 edge differences, and
additional edges impose consistency conditions. Translation by one
paired column preserves the directed graph, so this is a finite
translated frontier family with two phase labels.

## Two consecutive middle survivors cannot both have surplusb

Let a phase0 middle survivorR have surplusb. Its matched next belief is
R∪B. TheU-prefix lengths remain unchanged; eachV-prefix length increases
by1. Since every fiber ofR had at least2 unoccupied positions, this
next belief still omits the last positionL−1 in every fiber.

A phase1 middle survivor of surplusb would, by the lemma just proved,
be a nonempty right suffix in every fiber. It would contain positionL−1
everywhere, and hence cannot be a subset of the preceding belief.
The reflected argument applies from phase1 to phase0.

Thus if two successive survivor sets are both in the middle range,
their two surpluses have sum at least2b+1=A. Each is at leastb, and
equalityb in both is impossible. This conclusion permits arbitrary
intermediate inspection quotas and arbitrary survivor shapes; it does
not assume a prefix strategy.

## A surplusb+1 bridge after the minimum frontier

There is a further rigidity statement under the containment that occurs
in an actual strategy. LetR be a phase0 middle survivor of surplusb,
and letS⊆N(R) be a phase1 middle survivor with surplusb+1. ThenS is
also a left frontier with adjacent lengths differing by0/1; it cannot
have remote holes behind the front.

For any support with boundaryB in this contraction and anyQ edgeuv,

    S_u\S_v⊆B_v.

Following a simple path inQ shows that any two fiber cardinalities
differ by at most|B|. Thus at surplusb+1, an empty fiber would imply
|S|≤A(b+1)<A², contrary to the middle assumption. Every fiber is nonempty.

As proved above,N(R) omits the far endpoint in every fiber. In phase1,
theU fibers flow right. If anyU fiber avoided the boundary ofS, its
nonempty row set would be right-closed and would contain that endpoint,
contradictingS⊆N(R). EveryU fiber therefore meets the boundary. There
areb+1 of them and the entire boundary has sizeb+1, so it consists of
exactly one point perU fiber and no points onV fibers.

TheV fibers flow left and have no boundary points, so their row sets
are left prefixes. The same bidirectional-edge and one-way-fiber
argument as before, now withU andV exchanged, makes eachU row a left
prefix as well. Across each edge the boundary-freeV length equals the
boundary-bearingU length or exceeds it by1. The reflected statement
holds when the precedingb-surplus frontier points right.

Consequently every bulk run whose surpluses alternateb,b+1 has a finite
translated frontier on both phases after its firstb-surplus survivor.
The two phase families differ only in whichQ color's length is allowed
to exceed its neighbor by1. Within a fixed left orientation, ordinary
neighborhood formation increases the lengths on the right-flow fibers
by1 and leaves the other lengths unchanged. At full quotam, two
consecutive frontier transitions decrease the sum of all fiber lengths
by exactly2m−A. This is the additive motion expected for the remaining
even-longitudinal-length case.

## What this does and does not establish

The lemma identifies every middle support of the smallest surplusb
and explains geometrically why its orientation cannot be repeated on
the next phase. It is consistent with the known asymptotic time slope,
whose effective two-day boundary cost isA rather than2b.

The intervening surplusb+1 support is classified under the actual
containment condition by the preceding bridge lemma. The subsequent
history-bit argument has now supplied the needed accounting and a full
eventual-periodicity proof in
`even-bridge-odd-cylinder-eventual-periodicity.md`. Root has accepted that
theorem, with a fresh second audit still in progress. The new argument
tracks the alternation explicitly; it does not merely apply the
even-cross-section potential unchanged.

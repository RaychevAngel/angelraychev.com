# Independent review of the physical four-cube normal form

12 September 2026. Reviewer: the parallel recurrence/formula research lane.
This review is independent of the author of the cube compression modules.

**Result:** no substantive gap found in the physical compression and normal-
form statement. This is not a review of the later 292-ideal time certificate.

The reviewed source chain includes `SquareCompressionFourData.lean`,
`SquareCompressionFour.lean`, `SquareCompressionFourEnergyData.lean`,
`SquareCompressionFourEnergy.lean`, `ProductCompression.lean`,
`ProductCompressionNormalization.lean`, `FourCubeCompression.lean`,
`FourCubeNormalForm.lean`, and the final strategy bridge in
`StrategyCompression.lean`.

The 64 rooms are exactly triples in {0,1,2,3}^3, encoded 16x+4y+z. The
adjacency definition changes exactly one coordinate by one; it has no stay
edges or diagonal moves. Each of the three pairings is explicitly inverse
to its coordinate unpacking, and `pair_edges` checks the Cartesian-product
adjacency against this actual cube adjacency. The enumeration permutation
also verifies that lifting does not duplicate or omit physical rooms.

The two square operators compress along x+y and x+3-y level sets, with
rank increasing in y. Their masks are interpreted by independently stated
coordinate equalities, including rank and adjacency checks. Each diagonal
preserves checkerboard color. The monochromatic finite checks are extended
to arbitrary mixed-color regions by `cmap_slice`, additivity of cardinality,
and monotonicity of the compression. The neighborhood inclusion has the
needed direction N(C(A)) subset C(N(A)), rather than its converse.

Cartesian-product lifting uses that inclusion for moves inside the square
and monotonicity for moves in the remaining coordinate. No hidden hypothesis
that a whole fiber is monochromatic appears in this lift. The global energy
is x+2y+3z. The three induced pair weights and the remaining-coordinate term
sum exactly to it under the pairings. Preserving fiber cardinality keeps
the remaining-coordinate contribution unchanged. Equality of the global
energy forces every changed fiber to have equal local energy, hence to
have been fixed. Thus each nontrivial compression strictly lowers an
integer energy bounded by 64*18=1152.

The normalization is deliberately a uniform 1152 full cycles for every
input. This matters: an input-dependent stopping time alone would not
establish monotonicity of the resulting operator. Composition and fixed-
length iteration preserve monotonicity, size, and neighborhood inclusion.
`iterate_reaches_fixed` proves convergence in the uniform bound, including
energy-zero and already-fixed cases. `cycle_fixed_iff` proves a fixed full
cycle is fixed by all six individual operators: a cancellation between
different operations is impossible because their energy changes all have
the same sign. Idempotence of the resulting normalizer follows.

Finally `actual_capture_iff_normal_form` retains the full physical meaning:
arbitrary daily inspection subsets of the 64 rooms, cardinality budget m
on every day before t+1, and `GuaranteesAt` for actual target walks with
zero-based last round t. `no_dead_ends` justifies the conversion from the
post-movement recurrence to actual capture. The normal-form side requires
fixed beliefs and fixed post-inspection survivor sets, not merely a small
initial support. `optimal_fixed_normal_form` constructs those survivor
sets by intersection with a compressed survivor, preserving the probe
bound. This suffices for a subsequent exact enumeration of the common
fixed sets, but that enumeration and its time potential are separate work.

No change to the reviewed sources was necessary.

A fresh single-worker compilation of `FourCubeNormalForm.lean`, using the
existing compiled dependencies, passed. The two displayed final theorem
axiom reports contain only `propext`, `Classical.choice`, and `Quot.sound`.
This rechecks the final module; it is not a fresh full dependency rebuild.

# Independent review: odd-order transverse graphs and even cylinders

12 September 2026. Reviewer: the separate physical-proof/formalization lane.

**Pass after two explicit notation clarifications, now incorporated.**
I independently checked the full draft
`even-bridge-odd-cylinder-eventual-periodicity.md` and its prerequisite
`even-bridge-odd-cross-section-paired-columns.md`. This is an ordinary
proof audit, with no finite computation or Lean formalization claimed.

For a bipartite Hamiltonian Q of odd order A=2b+1>=3 and fixed m>=b+1,
put D=2m-A. The reviewed result gives an effective even period Delta and
threshold N with

    T_m(Q × P_(n+Delta)) = T_m(Q × P_n) + 2A Delta/D

for every even n>=N. Together with the previously proved results, this
covers every fixed transverse Cartesian box and both longitudinal
parities. It does not yet cover arbitrary odd-order Hamiltonian Q at odd
longitudinal lengths, nor give the smallest period or finite exception
values.

## The physical paired-column geometry

Matching columns 2j and 2j+1 identifies one cohort with Q×{0,...,L-1}.
I reconstructed the induced directed edges: Q edges are bidirectional
inside a pair, the matching supplies loops, and the two Q colors have
opposite one-way longitudinal flows. These directions reverse when the
cohort phase flips, but do not depend on the pair index j. Thus a shift
by one paired column preserves the entire directed model and equals an
even physical displacement.

For a boundary of size at most b, an untouched fiber in each Q color
connects all undeleted Q layers into one SCC. At most A*b vertices lie
outside that component when deleted layers are included. With K=A²,
the middle-size condition rules this out. A boundary of size exactly b
therefore consists of one point on each of the b minority fibers, none
on the majority fibers. The majority's boundary-free one-way fibers
are prefixes or suffixes according to phase. Bidirectional Q edges give
adjacent fiber-size differences at most one. Connectivity and the two
middle-size inequalities ensure at least two occupied and two empty
positions in every fiber. The one-way minority edge then rules out an
internal hole: it would create a second boundary point at the other end.
This proves the stated common frontier and its 0/1 edge differences.

Its next neighborhood omits the far endpoint in every fiber, whereas a
minimum-surplus frontier in the opposite phase contains that endpoint.
Consequently consecutive middle survivors cannot both have surplus b.

The b+1 bridge also holds under the actual containment hypothesis.
For arbitrary S with boundary B, a directed Q edge gives S_u\S_v subset
B_v. Following a simple Q path bounds each difference of fiber sizes by
|B|; the destination fibers in that path are distinct, so their boundary
counts sum to at most |B|. At |B|=b+1 a middle S therefore has no empty
fiber. Since S is contained in the preceding minimum frontier's
neighborhood, it omits the far endpoint everywhere. Each of the b+1
right-flowing majority fibers must meet the boundary. They exhaust B,
leaving boundary-free prefix fibers on the other color, and the same
edge argument forces all remaining fibers to be prefixes too. Reflection
handles the other orientation. No assumption of an optimal prefix
strategy enters this lemma.

## The history-bit charge and equality conditions

Let e_t indicate that the previous survivor was middle and had surplus b;
e_0=0. If p is the useful inspection count and the current survivor has
size r=k-p and surplus s, then the before-inspection rank loss is

    (2k+e_t) - (2(r+s)+e_(t+1))
       = 2p - 2s + e_t - e_(t+1).

For middle s=b, the no-consecutive-minimum lemma forces (e_t,e_(t+1))
=(0,1), giving 2p-A. For middle s>=b+1, the new bit is zero and the
old bit is at most one, again giving at most 2p-A. Equality in the latter
case requires s=b+1 and old bit one.

The two clip thresholds are correct and handle equality endpoints:
L0=2(K+m)+1 and upper threshold 2h-2K. A survivor r<=K has source rank
at most L0. A survivor r>=h-K has next rank at least 2h-2K by the actual
matching. Thus the clipped loss is always at most max(0,2p-A).
Daily useful shares sum to at most m; their positive-part charges sum
to at most D, with equality only when one cohort receives all m useful
inspections. The draft now explicitly defines p as useful inspections,
so the displayed raw equalities use the exact relation r=k-p.

Efficient-day clipping cannot hide an endpoint exception. Positive source
potential implies k>K+m and hence r>K; target potential below the cap
implies k'<h-K and hence r<h-K. The raw equality therefore applies and
forces precisely the alternating states (b,0->1) and (b+1,1->0). The
second state has the required actual containment after a preceding
minimum-surplus survivor, so both efficient phases have geometric
frontiers.

The integer slack calculation gives exactly B=8K+8m+2A using the height
upper bound. Proper nonempty untouched supports grow each day in the
strongly connected paired contraction; a history-bit change can subtract
at most one from twice that growth. The raw rank therefore increases by
at least one. The ownership-block argument and bounded low/high collars
are consequently valid, with E=B+2(K+m+1)(B+1). On every clean day the
mate is genuinely full or empty, with history bit zero.

## Survivor timing and finite additive motion

At an after-inspection survivor vertex, the bit must be the NEW bit,
indicating whether that survivor has middle surplus b. I requested that
this distinction be explicit, and the draft now states it. With this
meaning the appropriate survivor rank is 2r-e, not 2r+e and not the
before-day bit substituted into 2r-e.

For consecutive survivors, r'=r+s-m. If (s,e,e')=(b,1,0), the survivor
rank loss is 2m-2b-1=D. If (s,e,e')=(b+1,0,1), it is also D. Hence the
corrected average (2r-e)/(2A) decreases by D/(2A) on every edge. The
ordinary mean occupied length is nonincreasing and may be stationary on
one phase at the minimum budget. Its distance from the corrected mean
is at most 1/(2A). The margin v=A covers this correction plus the fiber
range A-1.

A closed label walk returns the phase and history bit. It has even length
l and changes cardinality by Dl/2. Returning its relative fiber lengths
therefore gives an integer paired-column translation Dl/(2A). The stated
choice l0=2A*lcm(1,...,M), M=8*2^(A-1), makes delta=Dl0/(2A) integral
and Delta=2delta even. The cycle extraction and repetition arguments need
no strong connectivity or aperiodicity of this finite label graph.

## The paired-band surgery is valid

I rechecked every changed parameter in the previously audited band proof.
One physical move crosses at most one paired-column boundary, so radius
E+2A+m+2 shields the marked inspection columns and initial front cuts
through all nonclean blocks. Local full preservation uses the actual
longitudinal matching inside each pair; it does not assume a perfect
matching in the odd-order Q. Empty neighborhoods remain empty by the
same finite-speed argument.

The raw gap W+2v+4 and subsequent trimming retain exactly the required
W-based margin. The corrected mean has constant nonzero drift, and
frontier width plus its bit correction is below v. Thus there is one
complete clean crossing per cohort; partial excursions cannot invalidate
the trimmed band. The two crossings are disjoint and have full or empty
mates. The displayed W supplies enough edges after the entry/exit
overshoots and leaves delta of spatial clearance for every translated
intermediate frontier. The threshold ensures the same conditions on the
contracted paired length as well as on the original board.

Deleting delta pairs preserves physical phase. Removing the selected
closed subwalks deletes l0 even inspection days per crossing, and their
cut displacements give the natural mapped endpoints. Insertion reverses
this by repeating a short closed subwalk. Outside the crossings, the
locally uniform protected region makes neighborhood formation commute
with the column map, including arbitrary nonclean behavior elsewhere.
The mate and the second crossing are unaffected. The total time change
is 2*l0=2A*Delta/D. This proves the two optimal-strategy inequalities and
therefore the claimed eventual equality.

The final common-period assertion for transverse boxes is also valid.
Odd volume means every transverse side is odd, so the prior odd-length
theorem applies; the new theorem treats even lengths. Both periods are
even. Taking their least common multiple and the larger threshold yields
one recurrence valid for both parity subsequences. The one-vertex
cross-section is separately covered by the exact path theorem.

# Independent audit: the odd-rectangle solo-time sandwich

12 September 2026. Independent audit of §§2 and 4 of
`uniform-rectangle-time.md`. **Verdict: PASS as an ordinary theorem.**
This is not a Lean verification, and the remaining central-day criterion
in §5 is not proved by this audit.

For every odd rectangle with both sides at least three and every feasible
budget, let τ be the shortest capture time from either complete initial
parity cohort. The proved conclusion is

    2τ − 1 ≤ T ≤ 2τ.

The separate path theorem handles a side of length one. A finite exact
algorithm can distinguish the two possibilities, but a universal elementary
criterion for that last bit remains open.

## Inverse concentration

I checked the inverse formulas against the established physical profile
formulas, including the special endpoint I_0(M)=E. Below M, the majority
inverse cost is min(q(z),b,q(M−z)); the minority cost is
min(R(z),b+1,1+R(E−z)). Every term in the latter minimum dominates the
corresponding former term, since q(z)≤R(z). The subadditivity proof for the
majority cost correctly separates a minimizing cap/reflected branch from
the case of two lower-root branches.

For the second concentration inequality, x≥2 ensures R(x)≥2. In its
reflected branch the estimate

    1+R(M−y+1−x) ≤ 1+Q(M−y) ≤ R(x)+Q(M−y)−1

has the correct direction and valid nonnegative arguments. The domain
x+y≤M prevents the exceptional I_0(M) endpoint from occurring in that
second summand. The omitted x=0,1 cases really have I_1(x)=0 and are
handled separately later. Thus no unproved superadditivity or permanent
ordering between the two phase profiles has been introduced.

## Prescribed-time concentration

The solo deficits D_p(t) refer to *current physical colors*, so their
recurrences correctly exchange the previous colors. Individual domination
of arbitrary strategies follows by allocating at most m shots to each
cohort and using profile monotonicity; physical nested prefixes attain
the solo bounds.

When t+1<τ, the two nonsaturation conditions imply
D_1(t)+m<M and D_0(t)+m≤M. Consequently the total inverse input lies in
the exact domain of the two concentration inequalities. The induction
correctly chooses its bound according to the current ordering of D_0,D_1,
and the x+p≤1 exception uses the individual D_1 bound. Hence every
physical strategy has total deficit at time t<τ at most max(D_0(t),D_1(t)).
The bound is attained by a solo strategy, but it does not claim that the
same solo phase attains it at all times.

## Midpoint timing and the lower bound

With L=τ−1, the forward half performs L inspections and L moves. It ends
just before inspection L+1, at a set B of at least E vertices. The reversed
half begins with inspection 2L and performs L−1 moves, ending immediately
after inspection L+1. Its set R lies at exactly the same physical time.
Before its final inspection, the concentration theorem applies at time
L−1; its subsequent m deletions still leave at least E vertices by the
nonsaturation condition for solo time L. Thus B and R intersect in a
(2E−1)-vertex board. Their avoiding walks concatenate with no missing or
extra inspection. This contradicts capture within 2L days. Padding a
shorter schedule by empty inspections is legitimate on these graphs,
which have no isolated vertices.

## Upper bound and its parity

The palindrome A_1,…,A_τ,A_τ,…,A_1 uses 2τ inspections. The first half
captures the solo initial parity p. At the start of the second half an
opposite-initial-parity walk has parity p+τ−1 modulo two. Reversing its
final τ vertices therefore produces a walk starting in parity p and
avoiding A_1,…,A_τ. This is impossible. The duplicated central inspection
is intentional; deleting it would require a separate argument and is
precisely where the remaining one-day question lies.

## Independent finite supplement

`src/uniform_odd_solo_bound_audit.py` rebuilds all neighborhoods directly
from coordinate differences on six rectangles from 3×3 through 7×7. It
checks prefix-neighborhood identities, both inverse formulas, 1,254
inverse concentration inequalities, and the sandwich against independent
full two-count BFS for 144 board/budget pairs. All pass in 0.009 CPU seconds.
The receipt is `uniform-odd-solo-bound-independent-check.json`. These checks
supplement the all-parameter argument above; they do not replace it.

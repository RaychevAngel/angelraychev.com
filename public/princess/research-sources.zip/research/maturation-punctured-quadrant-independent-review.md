# Independent audit: punctured-quadrant capacity

13 September 2026. Euler review of
`research/maturation-punctured-quadrant.md`. **PASS as ordinary mathematics**,
with two exposition clarifications recorded below. This review does not
assume the new capacity formula as a known profile theorem.

## Exact scope

All parameters are integers: parity `p∈{0,1}`, `r≥0`, `h=2r+p`, and
surplus budget `s≥0`. The forbidden initial diagonals constrain the support;
they are not removed from the quadrant graph. The accepted capacity is

    C_h(s)=max(s(s−1)/2, s(s−h)).

The theorem gives exact finite-support static neighborhood profiles.
It makes no compatibility assertion for successive search states.

## Lower bound audit

Choose the enclosing square strictly larger than the maximum occupied
coordinate sum plus one. Then both the original set and its diagonal
compression, including all neighbors, avoid the square's far boundary.
The previously proved square compression therefore gives the quadrant
inequality while preserving every diagonal count and the forbidden prefix.

On an occupied diagonal, the upward neighborhood is exactly a prefix of
length `a_j+1`. The next input diagonal contributes downward prefix length
`a_(j+1)−epsilon_(j+1)`: its one-cell reduction occurs precisely when that
input diagonal is full. These prefixes use the same end, so the displayed
maximum formula for `n_j` is exact. The artificial initial output also
checks in both parities: for parity zero `a_0∈{0,1}` and
`a_0−epsilon_0=0`; for parity one the output is the actual origin.

Summing the inequalities
`delta_j≥a_(j+1)−a_j−epsilon_(j+1)` through the output immediately below
occupied layer `j_t` telescopes to `a_(j_t)−f_t`, including any empty
gaps. The output at and above that layer contributes at least `L−t+1`.
This gives the crucial inequality

    a_(j_t)≤delta−L+t−1+f_t.

If there is no full layer, the first occupied layer has at least one cell,
forcing `L≤delta−1`; summing gives the triangular capacity. If the first
full layer has occupied rank `u`, then its index is at least `r+u−1`,
so its length is at least `h+2u−1`. Combining with the same inequality
gives `L≤delta−h−u+1≤delta−h`. The weaker estimate `f_t≤t` sums to
`|S|≤L delta`, hence the full-block capacity. In this branch `L>0`
also forces `delta≥h+1`, so multiplication and the later monotonicity
step are applied in a nonnegative range. Empty support is separate and
has size and surplus zero.

No term in this argument requires a layer to be adjacent to the preceding
occupied layer; empty intervening layers are already included in the
telescoping surplus. The capacity bound therefore covers arbitrary finite
supports, not just ramps or contiguous full blocks.

## Every-size attainment audit

For `h≥1`, a complete proper ramp with counts `1,2,…,q` has size
`q(q+1)/2` and surplus `q+1`. Appending `v∈[1,q+1]` cells to the next
layer leaves the old last output unchanged and introduces one new unit
of surplus. This realizes every integer size through the triangular
capacity, including the first singleton (`q=0`, surplus two).

A block of `L≥1` full layers has size `L(h+L)` and surplus `h+L`.
The downward contribution of a newly appended layer of size
`v≤h+2L+1` is at most `h+2L`, even when it is full. It therefore fits
inside the preceding full layer's upward neighborhood. The new last
output contributes one further unit of surplus, independent of `v`.

The **first** full block requires a distinct sentence: from empty,
`1≤v<h+1` cells of the first permitted layer have surplus `v+1≤h+1`,
while its full size `h+1` has surplus `h+1`. This is sufficient for all
initial interpolation. It is false to say this first addition always
increases surplus by exactly one when `h≥1`.

The full-block capacity overtakes the triangular one at `s≥2h−1` for
positive `s`. For `h≥2`, every relevant positive full-block level satisfies
`s≥h+1`; at its switching level, interpolation from the preceding full
block already begins no later than the preceding maximum capacity.
For `h=1`, the first positive level is `s=2` and the preceding paragraph
handles sizes one and two. For `h=0`, full blocks give squares `s²`,
starting with the actual origin at `s=1`. Thus every size through the
maximum is attained in all edge cases. Taking the least such integer
surplus gives the exact neighborhood profile.

## Independent computational attack

The checker `src/maturation_quadrant_check.py` uses explicit coordinate
neighbors, never the compressed-layer cost formula, to check the theorem.

* It tested **107,712 arbitrary subsets** of small finite triangles, for
  `h=0,…,6`, against the proposed surplus-capacity bound.
* It independently constructed and replayed **14,969 witnesses**, checking
  every cardinality up to `C_h(s)` for `0≤h,s≤16`.
* It separately records every partial size in the first full layer, which
  confirms the interpolation clarification above.

All checks passed in approximately 0.34 CPU second. The receipt is
`research/maturation-punctured-quadrant-independent-check.json`. These
finite tests support the unbounded proof audit; they are not its basis.

## Requested presentation clarifications

1. Explicitly call `s` a nonnegative **integer** surplus budget.
2. Restrict the phrase “appending a partial layer raises surplus by exactly
   one” to a nonempty preexisting full block, then give the first-layer
   bound above.

No change to the theorem or its stated static scope is requested.

## Subsequent audit: general two-candidate capacity convolution

The appended generic convolution corollary also **passes**. Let `A,B` be
nondecreasing unbounded discretely convex integer capacities with zero
at zero. Their inverse costs exist even with flat stretches and integer
jumps. For any feasible point of cost `t`, convexity of
`A(z)+B(t−z)` puts a value at least the total demand at one of the two
endpoints of the permitted cost interval. This yields the two proposed
count candidates.

The clipped cases require one additional line of reasoning. If
`y1=u<A(alpha(l))`, the convex endpoint inequality by itself is not enough
to bound the second count. Instead use
`beta(S−u)≤t−alpha(l)` and monotonicity of `B`. If
`y2=l>S−B(beta(S−u))`, use the symmetric bound
`alpha(l)≤t−beta(S−u)`. Thus both clipped candidates have cost at most
the original point's cost, and both remain inside the original interval.

Every `C_h` is an admissible capacity: the maximum of its two convex real
quadratics is convex on the integers; its dominating nonnegative branch
is nondecreasing, and it is unbounded. The older Lean opposed-root result
is an instance of the **generic** theorem with capacities `s(s+1)` and
`s²`. Its pronic inverse is not the punctured `h=1` profile, which instead
has capacity `s(s−1)`. Root noticed and corrected that attribution; no
negative puncture parameter is needed or claimed.

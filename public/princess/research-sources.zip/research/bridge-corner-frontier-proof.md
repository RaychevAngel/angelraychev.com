# Exact three-threshold frontier of the necessary corner model

13 September 2026. Ordinary proof under independent review. This is an
exact acceleration of the accepted necessary model, not an assertion that
its paths are physically realizable. It introduces no new physical bound.

Let w<=n, wn even, w>=2, h=wn/2 and r=floor(w/2). Take k>=r+1.
The corner model has states (a,c), c<=a<=h-2+c, c in {0,1,2}.
A day deletes p<=min(k,a) rooms, leaving q=a-p and i corners, where
max(0,c-p)<=i<=c. Empty survivors reach (0,0). Positive survivors may
reach (t,j), with surplus s=t-q>=0, through the previously proved small
or large component inequalities, or the permitted unrestricted surplus.
Use either the original model or its critical spanning refinement.

For fixed survivor and target corner counts define

    F_ij(s)=c+(s-c)(s-c-1), c=i+2j-2, s>=i+2j, if j>0;
            c+(s-c)^2, c=i-1, s>=i, if j=0<i;
            max(s(s-1)/2,s(s-2)), if i=j=0.

An expression outside its indicated domain is unavailable. Let A=2-i,
B=2-j, z=s-A-B. The exact complementary capacity is

    G_ij(s)=z^2+2z+B, if B>0 and z>=0;
            z^2+z, if B=0<A and z>=0;
            max(s(s-1)/2,s(s-2)), if A=B=0.

These are the accepted model capacities, with G written without its
maximum over the three complementary corner possibilities. They give
q<=F_ij(s) or h-t<=G_ij(s). Above r the refined model is unrestricted;
at r it is unrestricted only for (i,j)=(1,1) when a side equals 2r,
or (i,j)=(2,0) when a side equals 2r+1. In particular the second
exception includes the near-square 2r by (2r+1) rectangle, in addition
to odd-width/even-length boards. The original model is
unrestricted already at r for every (i,j).

## Closed inverses and one target

Write R(x)=ceil(sqrt(x)) and rho(x)=ceil((sqrt(1+4x)-1)/2), x>=0.
The smallest s with t<=s+F_ij(s) is

    S_ij(t)=c+max(2,R(max(0,t-2c))), c=i+2j-2, if j>0;
            c+max(1,rho(max(0,t-2c))), c=i-1, if j=0<i;
            min(rho(2t),rho(t)+1), if i=j=0 and t>0;
            0, if i=j=t=0.

The smallest s with d<=G_ij(s), d>=0, is

    H_ij(d)=A+B+max(0,R(max(0,d-B+1))-1), if B>0;
            A+rho(d), if B=0<A;
            min(rho(2d)+1,1+R(d+1)), if A=B=0 and d>0;
            0, if A=B=d=0.

These identities follow by substituting the displayed shifted variables
into their quadratics and imposing their domains. In particular the
mandatory corner domains must not be dropped when taking roots.

Let cap_ij be r in the original model. In the refined model it is r for
one of the spanning exceptions above, and r+1 otherwise. For a valid
positive target size t in class j, set

    sigma_ij(t)=min(S_ij(t),H_ij(h-t),cap_ij),
    qstar=min(h-2+i,t-sigma_ij(t)).

Define Q_ij(t)=qstar if qstar>=max(1,i), and zero otherwise. Define it as
zero when t<max(1,j). All evaluations use the valid target bound h-2+j.

**Fixed-target assertion.** The positive permitted survivor sizes are
exactly the integer interval [max(1,i),Q_ij(t)], or empty when Q=0.
Indeed, increasing s weakens both quadratic inequalities throughout
their domains. The union of their surplus ranges and the unrestricted
range is therefore the single interval s>=sigma. The ordinary static
profile is redundant here: F and G are each at most s^2 on their domains,
and the unrestricted range has s>=r. The state upper bound gives the
additional cap h-2+i. All other requirements are exactly those displayed.

**Target monotonicity.** Q_ij(t) is nondecreasing on its valid target
interval. S_ij(t) increases by at most one when t increases by one,
because s+F_ij(s) increases by at least one on consecutive domain points.
H_ij(h-t) is nonincreasing. Thus each of t-S, t-H and t-cap is
nondecreasing; their maximum is too. Capping it at h-2+i and replacing
values below max(1,i) by zero preserves monotonicity.

## Backward recurrence

Let B_t(c) be the largest size in corner class c capturable by the model
in at most t days; use -1 when that class has no state. Initialize

    B_0=(0,-1,-1).

Then the entire backward reachable set consists of a<=B_t(c), and

    B_(t+1)(c)=min(h-2+c,
                   k+max_{0<=i<=c, 0<=j<=2} Q_ij(B_t(j))).       (*)

A maximum over no positive survivor is zero. The formula also covers
classes where the upper state bound is already at most k.

Proof is by induction. A source of size at most k clears immediately.
For a larger source, any successful first day leaves a positive survivor
q reaching some class j at a target size at most B_t(j). By target
monotonicity q<=Q_ij(B_t(j)); since p<=k, (*) is necessary.

Conversely, choose i,j attaining a positive maximum Q. The corner loss
ell=c-i is at most 2<=k. For any valid source a in (k,B_(t+1)(c)], put

    q=min(Q,a-ell),    p=a-q.

Then q>=a-k>=1, q>=i (because Q>=i and a-ell>=i), and
ell<=p<=k. Also q<=Q, so the fixed-target assertion supplies a transition
to the target B_t(j). The upper bound h-2+i is already in Q; corner loss
is consistent with all source sizes because (h-2+c)-ell=h-2+i.
Induction supplies the remaining t days. This proves sufficiency for the
MODEL, and proves the entire interval assertion without any claim about
physical shapes realizing those features.

The model solo clock is the first t with B_t(2)=h. A variant initialized
with all valid states of size at most floor(k/2) tests whether a solo
residual that small can be reached before the putative central day.
Together with the existing merger theorem this supplies physical lower
bounds. A matching construction remains a separate obligation.

## Evidence and limits

The independent graph implementation predates this recurrence. The audit
in src/bridge_corner_frontier.py compares every state/deadline membership,
not just full-board clock values. Its receipt records 232 parameter/model
cases and 622731 equivalent memberships (w=2,...,12, selected lengths
and feasible budgets), all passing. This is computational evidence for
the derivation above, not a substitute for it.

One recurrence update uses a fixed number of standard numerical operations
and three state values, independent of w,n,k. The number of updates remains
the capture clock. Thus this is a substantial reduction of an optimization
problem to an arithmetic recurrence, but is NOT the required absolute O(1)
expression for T_k(a,b), and is not a new complete physical classification.

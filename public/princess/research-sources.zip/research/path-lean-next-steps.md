# Shortest concrete route to the complete path Lean theorem

Prepared 11 September 2026 after reading the current Lean modules and both reconstructed path proofs. This is a dependency map, not a claim that the remaining declarations already compile. No compilation or large search was started for this note.

## 1. The exact boundary now

Already kernel checked, using the existing Lean 4.33.1/Std setup:

* `BeliefSemantics.lean`: `possible_iff_reachable`, `guarantees_iff_belief_covered`, and `guarantees_iff_next_empty` connect the recurrence to actual finite avoiding walks, with the no-dead-end hypothesis made explicit. `possible_union` already supports splitting the initial parity cohorts; `possible_mono_initial` and `possible_mono_probes` support restrictions and extra probes.
* `PathUpperArithmetic.lean`: `canonical_parameters` supplies `d=2m-1`, `q=(n-3)/d`, `r=(n-3)%d+1`; `canonical_sweepCount_eq_correctedCeiling` identifies the sweep case count with the claimed formula for `n>m>=2`. `single_probe_sweepCount` handles the corresponding arithmetic for one probe. Transition-ceiling and exceptional-residue calculations are also present.
* `PathOEIS.lean`: the two- and three-probe specializations match the earlier OEIS expressions **arithmetically**. This module supplies no additional game or lower-bound geometry.
* The ladder classification is now complete in `LadderGame.lean`, including the room-level strategy, arbitrary-schedule lower bound, and single-edge case. Its finite-cardinality and semantics machinery can be reused, but its closed-path counter transition is **not** the transition for a one-row path.

Still absent: a path adjacency/schedule module, the parity-prefix sweep invariant, arbitrary-subset neighborhood/equality lemmas, high-decrement sequence lemmas, the lower-bound residue obstruction, and final all-parameter assembly. These are genuine proof obligations, not merely missing build commands.

## 2. Freeze one public interface first

Use `Fin n` rooms with physical adjacency

`pathAdj x y := x.val+1=y.val or y.val+1=x.val`.

This is zero-based internally; translate the ordinary proof's room number by `x.val+1` consistently. Use the existing `Region` and `possible` definitions. Reuse `Princess.LadderCardinality.card`, whose argument is already just `Fin n -> Prop`; despite the namespace, it does not depend on a ladder room type. Avoid introducing a second finite-set or cardinality representation.

Proposed new definitions, not currently existing declarations:

* `pathTurns n m`: one day when `n<=m`; two when `n=2,m=1`; `2*n-4` for the remaining one-probe cases; otherwise `PathUpperArithmetic.correctedCeiling n m`.
* `Budget n m probes := forall t, card (probes t)<=m`.
* `fullPath : Region (Fin n) := fun _ => True`.

The public target should mirror `actual_ladder_classification`: for `n>=2,m>=1`, exhibit a budget-respecting probe sequence whose possible set is empty after `pathTurns n m` rounds, and prove that emptiness after any `t` rounds of any budget-respecting sequence implies `pathTurns n m<=t`.

Finish with the guarantee-of-capture formulation using `guarantees_iff_next_empty`. Handle `n=1` directly with `guarantees_iff_belief_covered`: an isolated uninspected vertex must not disappear for free. The public theorem should quantify over actual probe sequences, not over an unconnected abstract certificate or only the supplied generator.

## 3. Shared geometry: prove this once for both bounds

Suggested file: `PathGeometry.lean`.

1. Every path vertex has a neighbor when `n>=2`; adjacent vertices have opposite parity; full parity moves onto full opposite parity. Use `possible_union` to obtain two initial-parity cohort evolutions under an arbitrary schedule. Useful probes are the intersection of the current belief and the day's probes; discarding other probes leaves the transition unchanged.
2. Reuse `cardOn_split`, `cardOn_map`, `cardOn_mono`, `card_mono`, `card_pos`, `card_full_iff`, and `probes_remove_at_most` from `LadderCardinality`. Prove the cardinal split for the two actual path parities, with their differing sizes when `n` is odd. The ladder's `budget_split` proof is a pattern, but its equally sized fibers cannot be applied unchanged.
3. Prove the exact parity-prefix neighborhood identity used by the upper construction. In the ordinary one-based coordinates, `A(r)={r,r-2,...} intersect {1,...,n}` has cardinal `(r+1)/2`, and `N(A(r))=A(r+1)` when `1<=r<n`. Removing its `b` largest vertices leaves `A(r-2b)` if nonempty, and moves to `A(r-2b+1)` when `b>=1`. Empty survivors stay empty. Add reflection `v -> n+1-v`, translated to `Fin n`, with adjacency and cardinality preservation.
4. For arbitrary one-parity subsets, prove the component/endpoints identity from the lower proof. A Lean-friendly implementation avoids a library of maximal intervals: define the count of adjacent occupied positions in the parity-indexed Boolean list and prove

   `card N(R) = 2*card R - endpointCount(R) - adjacentPairCount(R)`

   in **integer** arithmetic, then define `componentCount(R)=card R-adjacentPairCount(R)`. Each neighborhood overlap occurs exactly between two consecutive occupied parity positions, and each endpoint removes one exterior neighbor. This yields `card N(R)-card R=componentCount(R)-endpointCount(R)` by a local list induction. Maximal-interval language can be recovered only for the equality cases actually needed.
5. Prove those equality cases explicitly: on an even path, zero surplus means empty or one interval anchored at the available endpoint; the neighborhood of a proper anchored interval avoids the opposite endpoint. On an odd path, every nonempty small-parity set has positive surplus; every proper large-parity set has nonnegative surplus; surplus minus one occurs only for the entire large parity.

Items 4–5 are the first substantial lower-bound proof effort. The existing ladder `path_boundary` and cardinality lemmas help with witness extraction and strict inclusions, but they do not already prove this open-neighborhood identity or its equality cases.

## 4. Finish the upper bound without formalizing twelve historical cases

Suggested file: `PathSweep.lean`.

Define the indexed probes in `path-upper-bound-reconstruction.md`, or an equivalent finite-run constructor. Prove a generic descending-sweep invariant once: after `t` nonterminal full batches, the frontier is `R-t*(2m-1)`; the last batch clears when its parity-prefix cardinal is at most `m`. Prove the reflected version by transporting the same theorem rather than duplicating it.

Instantiate that lemma for the first cohort, then the second cohort. The only mixed-budget day is the first cohort's elimination day, with `c` probes finishing it and `ell=m-c` starting the other. Their parities are disjoint, so their budget sums exactly. Prove the direction rule for the second sweep separately: on an even path its chosen reflected starting frontier is always `n-1`; on an odd path it is `n` or `n-1` according to the current parity. This is the point that fixes the otherwise false same-direction construction.

The proof need only produce capture **by** the stated number of days; it need not separately prove that this particular schedule cannot finish early. Global minimality will follow from the lower bound. Once the geometric run has the ordinary sweep case count, invoke `canonical_sweepCount_eq_correctedCeiling`. Do not redo quotient/remainder arithmetic already checked in `PathUpperArithmetic`.

The last interface of this module should be an existential budget-respecting actual path schedule, not just an equation about its computed length. The direct cases `n<=m`, `n=2,m=1`, and the one-probe sweep should be joined here.

## 5. Lower bound: separate local geometry from finite sequence accounting

Suggested files: `PathLocalLower.lean`, `PathSequenceLower.lean`.

For a transition use signed integers

`Delta_t = (card B_t : Int) - card B_(t+1)`.

Natural-number subtraction is wrong here: valid strategies can increase their uncertainty. Derive the per-cohort and total decrement bounds from §3, retaining the actual useful probe counts and only assuming their sum is at most `m`.

Under `n>4m`, formalize exactly the two local sequence statements already reviewed in `path-lower-bound-audit.md`:

* Even `n`: two consecutive maximal decreases beginning from a partial cohort eliminate it; probing a full cohort on the first round prevents a second equality unless it can be eliminated. These facts give at most one internal long high run, of length at most three, and a terminal high run of length at most two.
* Odd `n`: a consecutive high pair is terminal and both decrements are `m`; a decrement `m+1` is isolated, noninitial, nonterminal, and occurs at most once.

The finite-word counting can be compressed further without changing the mathematics. For a nonempty high/low word, let `HH` and `LL` count adjacent pairs, and let `s,e` be the indicators that its first and last letters are high. The exact identity

`#H - #L = #HH - #LL + s + e - 1`

has a short list-induction proof. The reviewed even geometry bounds `#HH<=3`, yielding `#H-#L<=4`; the odd geometry bounds `#HH<=1`, yielding `#H-#L<=2`. This avoids a separate general maximal-run decomposition library. Then signed cardinality telescoping gives `2*n <= (2*m-1)*t+4`.

For the exceptional residue, keep the low-round slack `D` as an explicit nonnegative integer. This forces the equality conditions rather than assuming all ordinary rounds have their maximum decrement. Prove the two remaining obstructions:

* Even `n`: equality excludes an internal triple by the two short modular contradictions. With no triple, the word-count identity forces two double highs, no double lows and high endpoints. At the internal elimination pair, telescope the two cohort sizes to obtain `(u-v)*(2*m-1)=p-q`; the bound `abs(p-q)<=m<2*m-1` forces `p=q`, hence `m` even.
* Odd `n`: equality forces one `m+1` decrement. Prefix/suffix high-low counts have only the two possibilities in the ordinary proof; telescoping across that event forces `(2*m-1)` to divide `m`, impossible for `m>=2`.

The generic word identity is easy infrastructure; proving the **correct geometric hypotheses and equality-event interpretation for arbitrary evolving supports** is the main remaining proof effort. In particular, a partial cohort may become full again. Do not replace the telescoping argument by the false assertion that an untouched-looking full cohort was never previously probed.

## 6. Small ranges and final assembly

Use induced-prefix restriction of legal walks to prove path monotonicity in `n` (for nontrivial paths), rather than repeating the lower proof at every small size. Formalize the direct lower bounds at `2m+2`, `3m+1`, and the special `3m` with odd `m`; these are exactly the boundary arguments in §5 of `path-lower-bound-audit.md`. Add one-day capacity, `m=1,n<=4`, and the direct one-room case.

For `m>=2,n<=4m`, the short piecewise lower table equals `correctedCeiling` by arithmetic. That small-range equivalence and the lower-bound signed telescoping/divisibility arithmetic still need Lean lemmas; the existing upper arithmetic file does not silently establish them. Use `omega` after exposing the relevant quotient/remainder and multiplication equalities, as the checked arithmetic modules already do.

Suggested final interfaces:

* `path_upper`: existence of an actual budget-respecting schedule capturing by `pathTurns n m`.
* `path_lower`: for every actual budget-respecting schedule, capture after `t` rounds implies `pathTurns n m<=t`.
* `actual_path_classification`: the conjunction of these, with positive-size/budget hypotheses and the isolated vertex handled explicitly.

The completed ladder `RoomClears`/`PhysicalClears` recursors and their equivalence to arbitrary probe sequences are reusable proof patterns. A small graph-generic finite-run wrapper may save repetition, but a broad framework refactor is unnecessary to finish this theorem. Do not import the ladder's two-counter optimality as a substitute for the path lower bound: most even paths have no compatible parity-minimizing orders.

## 7. Validation and parallel boundaries

The shared geometry/interface work is the dependency to finish first. After it lands, upper-sweep formalization and lower sequence/accounting can proceed independently. Check each completed module using the existing sequential single-worker setup. At final assembly, print dependencies of the public theorem and retain source hashes and compiler output; inspect the statement separately for room adjacency, budget, unrestricted probe quantifiers and final-day semantics.

Existing finite replay checks remain useful implementation evidence but are not inputs from which Lean should infer the unbounded theorem. The finish line is kernel acceptance of the actual-room classification plus an independent semantic review, as was done for the ladder.

# Five-row exploratory directed cuts

**Current status, 12 September 2026:** the exact three-probe time is now proved
for all lengths `n≥5`: `T₃(P₅□Pₙ)=10n−20`. The even-length argument has passed
an independent review in `five-row-independent-review.md`; the odd-length
argument has independently passed review in `five-row-odd-independent-review.md`. The even geometry uses a finite symbolic certificate; the odd geometry
uses the independently reviewed odd-rectangle isoperimetric theorem. Both
arithmetic potentials are kernel checked, but no complete five-row Lean
formalization is claimed. The earlier entries below preserve discovery history.

Initial research log, 12 September 2026: paused while helping finish the
original path formalization. At that checkpoint no new five-row theorem was claimed.

For even length `n=2q`, match columns in adjacent pairs. One parity contracts to the directed grid `P_5 □ P_q` with bidirectional vertical edges and horizontal edges pointing left on even rows, right on odd rows; all vertices have loops. The other parity reverses horizontal directions. Neighborhood surplus becomes directed outside-boundary size.

`src/five_row_cut_states.py` enumerates outgoing-closed unions of strongly connected components after each one- or two-vertex deletion. It thereby obtains every parity set of surplus at most two without enumerating the entire exponential power set. Every tested deletion leaves at most five SCCs. The receipt is `research/five-row-cut-states.json`.

For every tested even length `6≤n≤20`, with `h=5n/2`:

- surplus-one sets have sizes only `1,h−2,h−1`;
- surplus-two sets occur at every size `1,...,h−2`;
- if `R` and `R'⊆N(R)` both have surplus two and `|R'|=|R|−1` (the transition from three useful probes), compatibility occurs only when `|R|∈{2,3,h−4,h−3,h−2}`;
- thus **no consecutive efficient three-probe transitions occur in the bulk size range `4≤|R|≤h−5`**, in these finite checks.

This suggests an analogue of the three-row efficiency-phase rank, now with affine movement cost five and finitely many exceptional endpoint states. A uniform SCC classification of two-vertex cuts would be needed to prove the bulk incompatibility for all lengths.

The standard single-orientation prefix strategy takes `10n−20` days with three probes on odd lengths and `10n−19` on even lengths. Independent cohort orientations may remove the extra even-length day, as happened for width three; this has not yet been verified here. Neither statement establishes optimality, and the odd-rectangle isoperimetric hypotheses require their own proof.

## Finite weighted automaton route (next structural attack)

A promising replacement for a long hand classification of two-vertex cuts is a column automaton. A column is a 5-bit survivor mask. With adjacent masks `A,B,C`, the outside-neighborhood mask in the middle column is

`(~B) & (vertical_neighbors(B) | (A & odd_rows) | (C & even_rows))`.

Its population count is the local surplus contribution. Sum these local weights, with zero sentinel columns outside the physical grid. Thus every arbitrary survivor set with surplus at most two is accepted by a finite weighted automaton on pairs of masks; there is no compression assumption. The low-weight language should decompose into finitely many transient words and arbitrary repetitions of all-empty or all-full columns. If the only recurrent zero-weight components are those two loops, an unbounded classification follows by exhaustive finite transition inspection plus a pumping argument. That recurrent-component assertion and the resulting symbolic families still need to be proved/certified.

For the tested widths, every surplus-two set of size `4≤k≤h−5` has each row a prefix of the matched-column direction. Its five row lengths have only 18 normalized patterns (some confined to the ends). Interior translation patterns are substantially fewer. This is discovery evidence, not a normal-form theorem for arbitrary beliefs.

I paused this structural attack for the bounded exact-time upper formalization of the 3×3×3 cube, at the path formalization task's request, after finishing the full original path lower proof.

## Complete theorem for three probes on even lengths

**New result, independently reviewed:** for every even `n≥6`, three probes per day have exact capture time

\[
T_3(P_5\square P_n)=10n-20.
\]

The lower argument is for arbitrary supports. Its geometric part uses an exhaustive *finite symbolic automaton*, not extrapolation from a list of grid lengths. The arithmetic potential is also separately being checked in Lean; this does not constitute a complete five-row Lean formalization.

### Exact symbolic boundary certificate

Write `n=2q`, `q≥3`, and `h=5q`. The matching-contracted graph is described above. For consecutive 5-bit columns `A,B,C`, the outside boundary contributed in the middle column is exactly

\[
\overline B\cap\bigl(V(B)\cup(A\cap\{1,3\})\cup(C\cap\{0,2,4\})\bigr),
\]

where `V(B)` is vertical adjacency within a column. Zero sentinel columns implement the physical ends.

`src/five_row_boundary_automaton.py` builds all reachable states `(A,B,c)` with accumulated boundary `c≤2`, retaining every possible next column. A state can be terminal when appending the right zero sentinel brings the boundary to the requested value. The only cycles are the zero-cost self-loops at `(0,0,c)` and `(31,31,c)`; deleting these leaves a DAG, checked exhaustively on 1,124 states and 3,874 remaining transitions. There are 1,057 terminal paths for boundary exactly two, each with at most eight columns after deleting loops. The receipt lists their exact words and legal pumping positions.

Consequently **every** boundary-two support at **every** length comes from one of these finitely many templates by repeating the designated empty/full columns an arbitrary nonnegative number of times. Conversely every such repetition preserves the local boundary. This is a complete finite symbolic language, not a bounded-length search. The analogous boundary-one language has 59 reduced paths.

The additional certificate `research/five-row-symbolic-geometry-certificate.json` checks the following implications on every template, with arbitrary pump exponents handled by the affine identities: a full-column pump adds five present cells, an empty-column pump adds five absent cells. Repeating a column preserves the row-prefix property. All statements concern `q≥3`.

1. A boundary-one support has size `1,h−2`, or `h−1`.
2. A boundary-two support of size `3≤k≤h−5` has every row a left prefix.
3. A boundary-two support whose rows are prefixes and with at least one empty row has size at most five.
4. A boundary-two prefix support of size four, five, or six has no neighbor in the last column.

The finite checks use the pump parameters, rather than sampling their values. The proof boundary is ordinary finite-certificate verification in Python; these automaton checks are not yet Lean theorems.

### Incompatible successive efficient expansions

Suppose `R` has boundary two, `4≤k=|R|≤h−5`, and `R'⊆N(R)` is a support for the opposite physical parity, also of boundary two. Suppose further

\[
k-1\le |R'|\le k+2,\qquad |R'|\le h-5.
\]

Both support sizes are at least three. The first support has left-prefix rows by statement 2. The other physical parity reverses the contracted horizontal arrows, so the rows of `R'` are right prefixes. The neighborhood of a left-prefix support also has left-prefix rows. Since `|N(R)|=k+2≤h−3`, some row of that neighborhood misses its last cell. The corresponding right-prefix row of `R'` must be empty. Statement 3 therefore gives `|R'|≤5`, whence `k≤6`. Statement 4 now says that `N(R)` misses the entire last column, forcing every right-prefix row of `R'` to be empty, a contradiction.

This includes the three-probe case `|R'|=k−1`, and the two-probe case `|R'|=k`.

### Historical potential

For one initial-parity cohort, let `b` be its current size. Mark it with `z=1` precisely when its immediately previous survivor support had boundary two and size in `[4,h−5]`; otherwise set `z=0`. A marked support thus has `6≤b≤h−3`. Every nonempty reachable support has size at least two, because every physical vertex has at least two neighbors.

Set

\[
V_h(b,z)=\begin{cases}
0,&b=0,\\
1,&1\le b\le2,\\
b-2,&3\le b\le5,\\
\min\{2b+z-8,b+h-10\},&b\ge6.
\end{cases}
\]

Every allocation of zero or one probe leaves this potential nondecreasing. An allocation of two or three probes decreases it by at most one. The verification is a short piecewise integer inequality using these exhaustive geometric alternatives for the survivor size `r=b−p`:

- no survivors: the next state is zero;
- full survivor support: the next support is full;
- boundary one: `r∈{1,h−2,h−1}`;
- boundary two: the next size is `r+2`, with the next historical mark determined by `4≤r≤h−5`; if the old mark is one and `3≤r≤h−5`, the preceding incompatibility lemma forbids this case for `p≤3`;
- boundary at least three: the next size is at least `r+3`.

The contracted graph is strongly connected, so a nonempty proper support cannot have boundary zero. Useless probes may be discarded from the numerical allocation: use the number of probes actually inside the cohort, which is still within the shared daily budget. This makes `r=b−p` exact. The two cohorts occupy disjoint physical parities every day, so their useful allocations sum to at most three.

At most one cohort receives at least two probes on a day. Thus the sum of their two potentials decreases by at most one per day. Initially it equals

\[
2V_h(h,0)=4h-20=10n-20;
\]

at capture it is zero. This proves the lower bound against every strategy.

### Explicit attaining strategy

Use the ordinary ascending diagonal prefix orders on the physical `n×5` grid, giving each initial cohort an independently chosen reflected orientation. Sweep the first cohort to completion with all three daily probes, then the other. Reflection in the long coordinate swaps physical parity because `n` is even, allowing each cohort to start in the favorable prefix phase.

The two prefix neighborhood surplus tables are:

- phase 0: surplus one at sizes `1,h−2,h−1`, surplus two at all other proper nonempty sizes;
- phase 1: surplus two at sizes `1,2,h−4,h−3,h−2`, surplus three at sizes `3,...,h−5`, surplus one at `h−1`.

These tables follow by counting the rows in the diagonal prefixes; the neighborhoods are the opposite-phase prefixes. Empty/full neighborhoods are empty/full. Starting in phase 0, the first three probes rounds give sizes `h,h−1,h−2,h−3`. Each subsequent pair of rounds reduces the size by one, until size five. The last three rounds give `5→4→2→0`. Thus one cohort takes

\[
3+2(h-8)+3=2h-10
\]

rounds, and two cohorts take `4h−20`. The actual room schedules are directly replayed by the accompanying strategy script, but the formula follows from the displayed symbolic tables.

At this stage the odd-length formula remained to be assembled separately; it
is now proved in the following section.

## Exact three-probe time on odd lengths, including the square

**Theorem.** For every odd `n≥5`,

\[
T_3(P_5\square P_n)=10n-20.
\]

Together with the independently reviewed even-length result, this establishes
the formula for every `n≥5`. The new ingredients here are a phase-sensitive
potential and the order of the two attaining sweeps. The geometric foundation
is the separately proved odd-rectangle isoperimetric/nesting theorem in
`odd-rectangle-isoperimetry.md`; that antecedent must be credited when this
argument is reused.

### Specialized exact neighborhood profiles

Put `h=(5n−1)/2≥12`. Write `z=0` for the physical parity containing `h+1`
vertices, and `z=1` for the one containing `h`. Let `g_z(k)` denote its minimum
open-neighborhood size among sets of cardinality `k`. Both profiles vanish
at zero. Substituting short-side parameter two in the general odd-rectangle
theorem gives

\[
g_0(k)=\begin{cases}
h,&h\le k\le h+1,\\
k+1,&k=1\text{ or }h-3\le k\le h-1,\\
k+2,&2\le k\le h-4,
\end{cases}
\]

and

\[
g_1(k)=\begin{cases}
h+1,&k=h,\\
k+2,&1\le k\le2\text{ or }h-2\le k\le h-1,\\
k+3,&3\le k\le h-3.
\end{cases}
\]

Indeed the majority corner term `ceil(sqrt(k))` is one precisely at `k=1`,
and the complementary corner term is at most one precisely when `h+1−k≤4`.
For the minority profile, `Q(k)≤2` precisely when `k≤2`, and the analogous
complement condition is `h−k≤2`; the value `Q(0)=1` handles the full set.

These are universal bounds for arbitrary supports. The increasing
`(x+y,x)` orders, with `x` along the long side, attain every displayed entry,
and their neighborhoods are opposite-parity prefixes. This last fact gives
actual strategies, not merely a numerical relaxation.

### Phase-sensitive lower potential

For a current cohort of size `b` in physical parity `z`, define

\[
W_h(b,z)=\begin{cases}
0,&b=0,\\
1,&1\le b\le2,\\
b-2,&3\le b\le5,\\
\min\{2b+z-8,\ b+h+z-10\},&b\ge6.
\end{cases}
\]

This differs from the even-length historical potential in the term `+z`
inside the second branch of the minimum. Here `z` is simply physical parity;
there is no historical mark.

Every reachable nonempty majority support has at least three vertices, and
every reachable nonempty minority support at least two. This holds initially;
after a nonempty survivor set it follows from the minimum degrees in the
opposite parity (three and two, respectively). Thus the permitted domain is

\[
b=0\quad\text{or}\quad 3-z\le b\le h+1-z.
\]

For `h≥12`, `z∈{0,1}`, every permitted `b`, and `0≤p≤3`, direct substitution
in the displayed piecewise formulas gives

\[
W_h(b,z)\le
W_h\bigl(g_z((b-p)_+),1-z\bigr)+\mathbf1_{p\ge2}.\tag{5-odd-step}
\]

Also `W_h(b,z)` is nondecreasing in `b` for each fixed `h,z`. These are
piecewise linear integer inequalities: splitting at `b=0,2,5`, the profile
breaks `k=0,1,2,h−4,h−3,h−2,h−1,h`, and the two affine branches of the
minimum proves them. The universal checks, including all endpoint and
truncated-subtraction cases, are kernel-checked in
`lean/FiveRowOddRankArithmetic.lean` as `potential_step` and `value_monotone`.
The file contains no admissions and uses only standard Lean axioms. It does
not formalize the antecedent geometric theorem.

Now consider arbitrary physical supports and take `p` to be the number of
useful probes actually in the cohort. Its survivors number `b−p`, and its
next support has at least `g_z(b−p)` elements. Monotonicity and (5-odd-step)
therefore bound the actual potential decrease by `1[p≥2]`. The two cohorts
occupy disjoint physical parities each day. With a shared budget of three,
at most one receives two or more useful probes. Their total potential thus
decreases by at most one per round.

Initially the two values are equal:

\[
W_h(h+1,0)=W_h(h,1)=2h-9.
\]

At capture both are zero, so every strategy requires at least
`4h−18=10n−20` rounds. This proof permits arbitrary supports and every possible
division of the daily budget between the cohorts.

### Explicit optimal sweep and the parity of its duration

Begin with the initially minority cohort and allocate all three probes to
its current prefix until it clears. Delete the final three vertices of the
prefix, or all of it if fewer remain. The exact nesting property makes its
next support precisely the opposite-parity prefix in the profiles above.
The initial two rounds give

\[
(h,1)\longrightarrow(h,0)\longrightarrow(h-2,1).
\]

For each minority size `6≤b≤h−2`, two rounds give

\[
(b,1)\longrightarrow(b,0)\longrightarrow(b-1,1).
\]

There are `h−7` such pairs before reaching `(5,1)`, followed by the three
rounds

\[
(5,1)\longrightarrow(4,0)\longrightarrow(2,1)\longrightarrow0.
\]

The first cohort therefore clears in

\[
2+2(h-7)+3=2h-9=5n-10
\]

rounds. This number is odd. The untouched cohort has stayed equal to the
full alternating physical parity, since the neighborhood of a full parity
is the full opposite parity. Its initially majority parity is consequently
minority when its own sweep begins. Repeat exactly the same strategy. The
total is `4h−18=10n−20`, matching the universal lower bound.

The smallest case `n=5` has `h=12`: each sweep takes fifteen rounds, so the
exact total is thirty. No extra endpoint exception is needed.

### Computation and proof boundaries

`src/five_row_three_probe_strategy.py` now supplies explicit room schedules
for every `n≥5`. The fresh odd-length receipt
`five-row-odd-three-probe-verification.json` contains direct physical replays
for the 49 odd lengths `5,...,101`, checks the specialized prefix tables at
each length, and attacks the potential on 39,872 numerical cases. These
finite tests supplement, and do not replace, the uniform proof above.

The exact mathematical boundary is: independently reviewed ordinary odd
rectangle geometry, a universal Lean-checked scalar potential inequality,
and an explicit ordinary attaining construction. A complete five-row
physical Lean theorem remains future work.

# Independent review: odd-square nesting

11 September 2026 Pacific. Coordinating-agent review of Section 4 in
`grid-nesting-source-audit.md`. Outcome: **no substantive gap found**.
This is ordinary mathematical verification, not Lean verification.

1. Checked the original source rather than relying on the later blanket
   remark: Abramovskaya et al. (2016), Theorem 1 and the order definitions
   immediately preceding it, printed page 20. The first order lists
   increasing x+y, then increasing y. The second lists decreasing x−y,
   then increasing y. Reflection x↦s+1−x takes the first order to the
   second, including its tie convention. When s is odd, it preserves the
   corner-containing parity. The two candidate neighborhood sizes are
   therefore equal, so Theorem 1 really does give one family of minimizing
   prefixes for every cardinality. Transposition justifies replacing the
   increasing-y tie convention with increasing x.
2. Checked the prefix-neighborhood assertion at the first diagonal, at
   the change from growing to shrinking diagonals, and at the far boundary.
   On diagonal x+y=t, the selected interval [L,k] has upper neighbors
   [max(1,t+1−s), min(s,k+1)] whenever nonempty. Earlier complete selected
   diagonals supply the complete earlier opposite-parity diagonals. Thus
   no internal hole is introduced, including when one upper edge is
   truncated by the square boundary.
3. Checked the complement argument for an arbitrary odd-parity set S,
   including S empty and S full. Put T=E\N(S), and replace T with the
   minimizing even prefix I of the same size. Its neighborhood has size
   at most |O|−|S| and is a prefix, so the odd tail J of size |S| avoids
   N(I). Symmetry of adjacency gives N(J)⊆E\I and hence
   |N(J)|≤|N(S)|. Central rotation preserves both colors and reverses the
   orders for odd s; it sends J to the odd prefix. This supplies the
   missing optimality direction without assuming the conclusion.
4. Independent exhaustive subset checks on 3×3 and 5×5 agree with both
   profiles. These are corroboration only; the all-parameter conclusion
   rests on the cited theorem and the preceding argument.

Consequently the conditional exact capture-time algorithm in
`nested-capture-time.md` applies to all odd squares of side at least three,
as well as to hypercubes and ladders. It gives an optimal strategy and the
exact capture time algorithmically for every budget, not a closed formula.

This review does **not** establish full nesting for nonsquare odd
rectangles. Larger finite checks on 7×5 and 11×3 also passed, but extrapolation
would be a separate unsupported step.

Source: [author-hosted 2016 published paper](https://fedorvf.github.io/articles/2016/2016g.pdf).

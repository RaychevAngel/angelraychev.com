# Independent attack of the three-row phase-rank and closed-form theorems

12 September 2026 UTC. Review by the frontier-state subagent, separate from
the author of `three-row-all-budgets.md` and the root's high-budget proof.
This is an ordinary mathematical audit, not Lean verification or external
peer review. No substantive gap was found in the complete all-length,
all-budget classification or its closed formula. The odd-length extension
received a separate final review, recorded at the end of this note.

## Scope actually reviewed

I first read Sections 2–4 while the high-budget and closed-form sections
were still marked incomplete. I then freshly reviewed the completed
Sections 5–6, including the direct boundary argument and the active-interval
counting that excludes arbitrary interleaving.

The initial audit below applies to `n` even, `n>=2`, `h=3n/2`, and every
positive budget. A later section records the final audit of the odd-length
closed formula and unified theorem. Its established geometric nesting
ingredient is used with its stated hypotheses; this review does not repeat
the earlier independent proof of that ingredient.

## Specific attempted failure points

1. **Actual prefix profiles.** With `(row,column)` coordinates, order each
   parity by `(row+column,column)`. The even parity has profile
   `min(h,k+1)`, the odd parity `min(h,k+2)`, with zero treated separately.
   Neighborhoods are the *actual* opposite prefixes, not just sets with
   the correct size. The phase changes on every movement. I verified the
   initial diagonals and endpoints by hand and all prefix identities for
   even lengths 2,4,6,8,10 by independent direct adjacency.

2. **Independent cohort orientations.** Since even-length rectangles have
   corners in both parities, each initially full cohort can choose a
   reflection putting it in phase zero. Their current physical parities
   remain disjoint on every day, so the combined probe budget is valid.
   A full cohort can reset its phase by changing its selected orientation
   without changing any possible room. A proper cohort retains its chosen
   orientation. Thus the rank cap at `2h` is physically meaningful.

3. **Rank arithmetic.** Phase zero at size b moves to phase one at size
   `b-p+1`; phase one moves to phase zero at size `b-p+2`, until capture
   or saturation. In both cases the rank update is `u-2p+3`. When full,
   resetting the phase gives cap `2h`; when captured, rank zero. The
   floor in the capture condition is essential and is used consistently.

4. **The lower label is historical.** It is not enough to say that a
   support has a certain size. Here `z=1` means the support is the
   neighborhood of an actual previous surplus-one survivor set of size
   at most `h-2`. This is exactly the hypothesis required by the strengthened
   opposite-corner lemma. Consequently a second such expansion would need
   `h-2` useful probes, excluded in the low-budget range. There is no
   hidden interval assumption on the arbitrary strategy.

5. **Large survivor sets and saturation.** A survivor set of size `h-1`
   has full opposite neighborhood because every opposite vertex has
   degree at least two. This covers the boundary case excluded from the
   small surplus-one classification. A survivor set of size h is also
   full. Both cases dominate the capped rank update.

6. **Simulation direction and unused probes.** The model rank is at most
   the arbitrary support's historical rank. The map F is nondecreasing in
   rank and nonincreasing in probe allocation. Using the actual useful
   probes in each color, then assigning unused budget arbitrarily, therefore
   preserves the correct domination direction. At final capture, the floor
   of each rank divided by two is its support size. This transfers the
   arbitrary strategy's terminal condition to the smaller rank process.

7. **The high-budget exception is real and isolated.** Independent subset
   tests find exactly the stated pattern: a current support of size `h-1`,
   with label one, can be reduced to a corner singleton using `h-2` probes.
   The next physical rank is five whereas blindly continuing the low-budget
   inequality predicts six. Thus it was necessary to separate the boundary;
   the proof has not silently ignored a counterexample.

8. **Direct high-budget lower bounds.** A perfect matching supplies an
   injective map from every mixed-parity belief B into N(B), so
   `|N(B)|>=|B|` is valid for the whole belief, not just each cohort.
   This forbids two-day capture below m=h. For h=6,m=4, the first move
   leaves at least nine possible rooms, and the second at least five,
   excluding a three-day strategy. The explicit three-day constructions
   for m=h-1 (h>=6) and m=h-2 (h>=9) fit their daily budgets. The h=3
   case is the already proved rotated two-row grid.

9. **Baseline lower time from the active intervals.** The final source
   uses the same active-interval demand for both the baseline and residue
   correction. If r=0, W is even and D odd, hence q is even; an interval
   of length at least q requires
   `h+floor(3*(q-1)/2)=qm` probes. Two intervals therefore require at
   least 2qm, proving T>=2q. If r>0, each interval has at least q+1
   days and the summed demand is `2qm+r+4-(q mod2)>2qm`, proving
   T>=2q+1. No separate weight estimate or small-budget exception is
   needed for this baseline.

10. **Last-full normalization.** Replace all probes before a cohort's
    last full pre-inspection rank by zero. It then stays full throughout
    that discarded prefix and has exactly the same rank at the selected
    departure. The other cohort is unchanged and the budget only decreases.
    In the final active interval no nonterminal move saturates, so exact
    telescoping gives

        P >= h + floor(3*(ell-1)/2).

    The two active intervals need not be disjoint or have the same length.
    Each nevertheless has at least `ceil((2h-4)/(2m-3))` days, and their
    total probe demand is at most the global number of days times m.
    Thus the argument really excludes arbitrary overlap and idle days;
    it does not assume a sequential strategy in the lower bound.

11. **Residue algebra and matching upper bound.** For W=qD+r with r>0,
    a putative total of `2q+1` days forces demand at least

        2h + 2*floor(3*q/2) = 2*q*m + r+4-(q mod 2).

    Therefore `m>=r+4-(q mod2)` is necessary. Because W is even and D
    odd, r and q have the same parity; this is precisely the upper
    construction's condition `r+2*floor((r+4)/2)<=D`. It guarantees at
    least two probes remain for starting the second cohort on the shared
    day. Its resulting rank has weight at most qD, so q more full-budget
    days suffice. There is no omitted phase parity at the final step.

## Independent computational evidence

`src/three_row_rank_independent_check.py` builds the graph directly, using
one bit per vertex of a *single parity*, and imports none of the candidate
recurrence implementation. It checks every relevant subset through n=10
(at most 15 bits per parity), including:

- 100 exact prefix-neighborhood identities;
- the strengthened compatibility assertion for every pair satisfying its
  antecedents on these boards;
- 117,460 low-budget transitions from every possible historical-label-one
  support;
- explicit failures at exactly the high-budget corner transition, with
  actual next rank five versus the naive prediction six.

The run took about 0.05 seconds. Full results are in
`three-row-rank-independent-checks.json`. These finite checks attack the
local proof claims; they are not a replacement for the general arguments.

Separately, the frontier-state experiment had already computed unrestricted
remaining times for every belief on 3-by-4, for budgets 2,3,4.
Its full-board values agree with the newly derived formula. That
experiment uses a subset maximum transform, independent of the phase-rank
recurrence.

## Presentation suggestions, not proof gaps

- Retain the explicit warning that the low-budget rank inequality itself
  fails at the high boundary. The completed full-board theorem is obtained
  by joining that inequality to separate short-horizon arguments.
- Clarify that the all-budget statement is about the full-board optimum;
  it does not claim rank alone gives the exact value of every arbitrary
  partial support. The historical label is a lower-bound certificate.
- Define the final active interval from a pre-inspection full rank, and
  state that its inspection count includes the capture day. This prevents
  a reader from shifting the telescoping identity by one round.

## Final review: odd lengths and the unified classification

After Sections 8–9 were written, I independently attacked the odd-length
algebra and the remaining parity obstruction. No new computation was
needed. The following checks are independent of the earlier finite-value
comparisons.

For odd n>=3, write `3n=2h+1`, `W=3n-4`, `D=2m-3`. The majority and
minority full ranks are W+5 and W+4. The actual parity is determined by
the cohort and day; unlike the even case, one cannot reset this phase by
choosing a reflection. The proof correctly retains this restriction.

1. **Alternating caps are necessary.** The precise odd nesting profiles
   give affine nonterminal update `u-2p+3` until the next parity's full
   cap. For example one probe from a full majority support can still leave
   a full minority support. Thus the even-case global weight-decrease lemma
   cannot simply be copied. The odd proof avoids doing so.

2. **Last-full normalization still works.** Removing probes before a
   cohort's last full pre-inspection state leaves it full in the same
   physical parity on every discarded day. At the retained start its
   rank is therefore unchanged, although the full rank alternates with
   time. The retained nonterminal steps never reach a full state again,
   so their affine rank changes telescope without a cap correction.

3. **Exact active-interval demand.** If a retained interval has ell days
   and begins in minority parity (e=0) or majority parity (e=1), its
   starting rank is W+4+e. The terminal floor condition gives

       P >= floor((W+4+e+3*(ell-1))/2)
         = ceil((W+e+3*ell)/2).

   Thus `ell*D>=W+e`, and every interval has at least `ceil(W/D)` days.
   Both the rounding and the count including the capture day are correct.

4. **The exceptional apparent residue saving is impossible.** Write
   `W=qD+r`, with r>0. For a schedule of 2q+1 days, summing the minimum
   demands of two intervals of length at least q+1 gives

       m >= 2*ceil((r+3)/2).

   This yields the desired `m>=r+4` unless r is odd and m=r+3. In that
   apparent exception q and m are even, q>=2, and all probe-demand
   inequalities must be equalities. Both intervals consequently have
   length exactly q+1 and start in minority parity: a majority start
   would add one required probe. Equality also requires every global day
   to be covered by at least one retained active interval. Some interval
   starts on day one. The other cohort reaches minority parity on even
   days, and its start must be an even day at most q+1, hence at most q.
   Both intervals therefore end by day 2q, leaving the supposed last
   day uncovered. This contradicts equality. The argument does not assume
   intervals are disjoint or meet at a prescribed day.

5. **The shared-day upper bound has the same condition.** After q days
   on the initially minority cohort, its rank is r+4. The other cohort's
   shared-day full rank is W+4+epsilon, where
   `epsilon=1-(q mod2)` equals the parity of r. Clearing the first cohort
   costs `floor((r+4)/2)` probes. The second cohort can then finish in
   q additional days exactly under the sufficient inequality

       r+epsilon+2*floor((r+4)/2) <= D,

   equivalent to `m>=r+4`. This inequality leaves at least three probes
   for the second cohort, enough to make it proper even if it starts
   in majority parity. Thus the claimed affine update does not silently
   hit a full-set cap on the shared day.

6. **The zero-remainder case is even simpler than initially written.**
   If r=0, every interval has ell>=q and the exact demand formula gives

       P >= ceil((qD+3q+e)/2) >= qm.

   Summing gives `T>=2q` for every m directly, including m=2. Since W
   and D are odd, q is odd; starting in minority parity, the first q-day
   solo sweep leaves the untouched cohort in minority parity as well.
   Two equal sweeps attain the bound. This removes an unnecessary special
   appeal to the previously proved two-probe theorem; the original weaker
   argument was valid but less economical.

The high-budget claims were checked separately: a matching covering all
but one room gives `|N(B)|>=|B|-1` for every mixed-parity B, ruling out
two-day capture below m=h. Inspecting the whole minority parity on each
of two consecutive days attains two days for m>=h, until m>=3n permits
one day. A target confined to an embedded four-cycle rules out one probe
for n>=2. For n=1 the three-vertex path takes two days at budgets one
and two, and one day thereafter.

Consequently the unified middle-range formula, with

    3n-4 = q(2m-3)+r,

has residue-saving threshold

    m >= r+4 - 1_{n even and q odd}

when r>0. The even and odd proofs supply matching upper and lower bounds
with the same terminal conventions. The final theorem is about the
full-board game for all n>=1 and all positive m; it does not say that a
single rank pair is an exact signature for every arbitrary partial belief.

# A uniform superlinear budget region on every odd rectangle

13 September 2026. Ordinary theorem independently reviewed and accepted
by root, including all constants and the absence of a separate width
cutoff. This uses the accepted complete low-linear theorem and the
general minimum-coordinate/onset argument. No new finite scan is needed.

Let w=2b+1>=3, n>=w odd, and b+1<=m. The exact scalar midpoint formula
and its attaining prefix strategy hold whenever

    m<=2b  or  27m^3<=b^4.                            (1)

Explicitly, with the solo clocks and endpoint conventions in
`bridge-odd-clock-linear-budget-all.md`,

    T=2tau-1  if E+M-D_0(tau-1)-D_1(tau-1)<=m,
      2tau    otherwise.

The second region has budget scale b^(4/3). The theorem concerns exact
values and optimal strategies through the scalar clocks; a general
absolute bounded evaluation of those clocks is a separate question.

## Reduction to widths beyond216

The complete low-linear theorem handles m<=2b. Suppose instead m>2b
and 27m^3<=b^4. Then 216b^3<b^4, so b>216. In particular

    b^(1/6)>=12/5,  sqrt(b)>=14,
    m<=b^(4/3)/3 <= (5/36)*b^(3/2).                  (2)

The first inequality follows from (12/5)^6<216. Set

    q=ceil(sqrt(b)),
    r=ceil((q*(b+1)+m-1)/(2q)),
    K=(q-1)m+r(r-1).

Since m-1<=q(b-1), one has r<=b. The definition of r gives
q(2r-b-1)>=m-1. Therefore the accepted short-window theorem makes K
a valid minimum-coordinate bound for every actual exceptional state.
It also has K>=m, since q>=2.

## The explicit onset lies below the smallest board

Because q-1<sqrt(b), equation(2) bounds the first term of K by
5b^2/36. Ceiling at most once in the expression for r gives

    r <= b/2+3/2+m/(2q)
      <= 41b/72+3/2
      <= 3b/5.

The last inequality already holds for b>=540/11, hence throughout the
present range. Consequently

    K <= (5/36+9/25)b^2 = (449/900)b^2 < b^2/2.      (3)

Equation(2) and sqrt(b)>=14 also imply

    m <= (5/504)b^2 < b^2/100.                       (4)

Use the generalized orientation onset

    G=m-1, H=b^2+1,
    J=max(2K+m+1,K+H),
    W=2ceil(sqrt(G)),
    M_onset=J+G+m(W+1).

The root cap is inactive because G<b^2. Equations(3)--(4) give
J<=3b^2/2+1. Also W<=2sqrt(m)+2 and the cubic hypothesis gives

    2m^(3/2)<=2b^2/sqrt(27)<2b^2/5.

It follows that

    G+m(W+1) <= 2m^(3/2)+4m-1
               < (2/5+1/25)b^2-1 = (11/25)b^2-1,
    M_onset < (3/2+11/25)b^2 = (97/50)b^2 <2b^2.

Every admissible odd rectangle has M>=2b(b+1)>2b^2. Thus the ordinary
orientation theorem applies on every board, proving(1). All window
lengths here are proof parameters; computing the sufficient region uses
only the displayed arithmetic and roots, with no input-sized optimization.

The broader explicit adaptive-K onset remains available outside(1).
Neither statement assumes numerical orientation for arbitrary mixed
states. Controlling that orientation directly remains a possible route
to further budget ranges.

# Boxes with a side of length two: exact feasibility and minimum-time algorithm

Research derivation, 11 September 2026. This is an ordinary mathematical proof using a classical isoperimetric theorem. It is not yet Lean verified; novelty of the capture-time application has not been established.

## 1. Precisely verified source theorem

Let `H=P_n1 square ... square P_nd`, with `2<=n1<=...<=nd`. Put the vertices in increasing order of their coordinate sum; within a tie, compare the first coordinate at which they differ, putting the **larger** coordinate first. Thus shorter side lengths come earlier in the coordinate list.

Theorem 2.5 in Yota Otachi and Ryohei Suda, *Bandwidth and pathwidth of three-dimensional grids*, arXiv:1101.0964, states that this simplicial order is isoperimetric for arbitrary such grids. Their definition immediately before Theorem 2.3 includes both required properties: every prefix minimizes the external vertex boundary at its cardinality, and the prefix together with its boundary is another prefix. In particular, this is a **closed-neighborhood** theorem, and it explicitly covers unequal side lengths and arbitrary dimension. [Primary research manuscript, PDF pp.2–3](https://arxiv.org/pdf/1101.0964)

The theorem is attributed there to H. S. Moghadam's 1983 UC Riverside thesis and *Bandwidth of the product of n paths*, Congressus Numerantium 173 (2005), 3–15; and to B. Bollobás and I. Leader, *Compressions and isoperimetric inequalities*, JCTA 56 (1991), 47–62, and *Isoperimetric inequalities and fractional set systems*, JCTA 56 (1991), 63–74. The 2011 journal version is Discrete Mathematics 311, 881–887, DOI 10.1016/j.disc.2011.02.019. This audit has read the explicit theorem and definition in the Otachi–Suda primary research manuscript; it has not independently reconstructed all proofs in the original 1983/1991 sources.

Write `I_k` for a prefix, `N=|H|`, and

\[
 c(k)=|I_k\cup N_H(I_k)|,\qquad 0\le k\le N.
\]

Then `c(0)=0`; `c` is nondecreasing; every `k`-set has closed neighborhood at least `c(k)`; and the closed neighborhood of `I_k` is exactly `I_c(k)`. Factors of length one can simply be deleted. For the empty product, use the one-vertex graph, with `c(0)=0,c(1)=1`.

## 2. The parity projection lemma

More generally, let `H` be any finite bipartite graph, and let `chi:V(H)->{0,1}` be a bipartition. Set `G=H square K2`.

The parity of `(v,z)` is `chi(v)+z mod 2`. For each parity `s` and each vertex `v` of `H`, there is exactly one vertex of `G` of parity `s` projecting to `v`: namely `(v,s-chi(v) mod 2)`. Consequently each parity class of `G` is naturally a copy of `V(H)`.

Let a one-parity possible-position set project to `R subset V(H)`. Moving in the `K2` direction keeps the projected vertex at `v`; moving along an `H` edge moves it to an `H` neighbor. These are all moves in the Cartesian product. Therefore the projection of the open neighborhood in `G` is **exactly** the closed neighborhood `R union N_H(R)`.

This is an equality of actual sets, not merely a size bound. It remains valid at a boundary and for an empty set. Probes of `p` possible vertices in that cohort remove precisely their `p` distinct projections. The two cohorts occupy opposite parity classes at any time, so probes allocated to them never conflict.

It follows that any closed-neighborhood isoperimetric order on `H` induces compatible open-neighborhood minimizing orders on both parities of `G`.

## 3. Exact minimum-time algorithm and strategy

Assume `H` has the closed nesting property above, and let `m>=1` be the daily probe budget. Track the two **initial-parity cohorts** rather than their current parity names. Both start as the full projected set, so the initial state is `(N,N)`.

A canonical state `(a,b)` means that the projected cohort sets are `I_a,I_b`. For each allocation `p=0,...,m`, allocate `p` probes to the first cohort and `m-p` to the second. Remove their prefix tails, using no more probes than actual vertices available. The state following a miss and a move is exactly

\[
 (a,b)\longmapsto
 \bigl(c(\max(a-p,0)),\ c(\max(b-m+p,0))\bigr).
\]

If instead the two coordinates always name the current graph parities, the two outputs must be swapped; tracking initial cohorts avoids that cosmetic swap.

The current state can be captured **on this inspection day** exactly when `a+b<=m`. Thus compute shortest-path distance from `(N,N)` to the target states `a+b<=m`, and add one for the final inspection. If no target is reachable, capture is impossible. Every directed edge corresponds to one failed inspection followed by one legal rabbit move. There is no extra move after the final capture.

Why is this exact against unrestricted strategies? Suppose arbitrary projected belief sets have sizes at least `(a,b)`. After an unrestricted allocation of `p,q` probes, their surviving sizes are at least `max(a-p,0),max(b-q,0)`. Minimum closed-neighborhood bounds and monotonicity of `c` show that their next sizes dominate the canonical transition. Replay the same numeric allocations in the canonical process, clipping wasted capacity; by induction its sizes never exceed those of the unrestricted process. Whenever the unrestricted process becomes capturable, so does the canonical process. Conversely, prefix-tail probing realizes every canonical transition exactly. The two optima are equal.

There are `(N+1)^2` states and at most `m+1` outgoing allocations per state. Full budget allocation loses nothing: any unused capacity can be assigned arbitrarily and then clipped, and additional probes cannot enlarge a belief. After computing the profile, a shortest-path algorithm therefore takes `O((m+1)(N+1)^2)` elementary state transitions and returns a concrete optimal schedule. This is polynomial in the number of rooms; it is not a closed formula for all side lengths.

## 4. Exact feasibility threshold

Define

\[
 B=\max_{0\le k\le N}\bigl(c(k)-k\bigr).
\]

Then the minimum number of simultaneous probes needed for certainty on `G` is

\[
 \boxed{h(H\square K_2)=B+1.}
\]

For necessity, suppose `m<=B`, and choose `k` with `c(k)-k>=m`. Since `c(k)<=N`, we have `k+m<=N`. Any cohort whose possible set has size at least `k+m` has at least `k` survivors after a day with at most `m` probes, and its next possible set has size at least `c(k)>=k+m`. The initial size is `N`, so this barrier holds forever for each cohort. Also `k>=1` because `c(0)=0`, hence such a cohort is never capturable by `m` probes. No winning strategy exists.

For sufficiency, let `m>=B+1`. Give all probes to one canonical cohort until it is cleared. If its current size `b` exceeds `m`, the survivors have size `r=b-m>0`, and its next size is at most `r+B<=b-1`. It strictly decreases until the current set can be probed completely. The untouched cohort stays full in projection, because the closed neighborhood of all of `H` is itself. Clear it by the same argument. This is a legal finite strategy.

For grids, `B` is the classical vertex boundary width of `H`, which the cited theorem identifies with its bandwidth and pathwidth. This proof derives the capture threshold directly; it does not require importing a graph-search equivalence with different movement rules.

## 5. Consequences and limits

For every finite Cartesian box having **at least one side of length two**, in any dimension, the classical grid theorem and the preceding lemmas provide all three requested outputs: an exact feasibility criterion, the exact minimum number of inspection days via a finite polynomial-size dynamic program, and an explicit optimal strategy returned by its predecessor path.

For a three-dimensional box `a by b by 2`, the exact feasibility threshold is `min(a,b)+1`, since the vertex boundary width of a rectangular `a by b` grid is `min(a,b)`. The degenerate `a=b=1` case is a single edge and has threshold one; if exactly one of `a,b` is one and the other exceeds one, the threshold is two. The displayed `min(a,b)+1` assertion therefore presumes `a,b>=2`.

The same result covers all hypercubes by taking the remaining sides to be two. It does **not** establish full nesting for arbitrary boxes with all side lengths at least three, and it does not repair the false blanket claim about open-neighborhood parity nesting on arbitrary rectangles. Closed neighborhoods on `H` and parity-restricted open neighborhoods on `G` must remain distinct.

The projection and algorithm are newly reconstructed here, but novelty is unverified. The closed isoperimetric theorem is classical and must be credited. No full Lean formalization of these results has yet been produced.

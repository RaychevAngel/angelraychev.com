# Odd-quadrant capacity with one origin neighbor forbidden

13 September 2026. New ordinary proof for independent review. This supplies
one capacity needed by the proposed erosion-corner state; it does not yet
prove a transition rule for that enriched state or a capture-time formula.

In the whole nonnegative quadrant, take odd-colored finite supports and
forbid one of the two neighbors of the origin, say (1,0). The largest
support with neighborhood surplus at most s is

    H(s)=s(s-1)/2                   for 0<=s<=4,
    H(s)=s(s-3)+1                  for s>=5.

Equivalently H(0)=0 and, for s>=1,
H(s)=max{s(s-1)/2, s(s-3)+1}. The explicit s=0 convention is essential:
the second quadratic would incorrectly give one there. This is sharper
than the tentative max{ramp,(s-1)^2} expression. The result is the maximum
capacity; no every-intermediate-cardinality claim is needed here.

## Proof

Use diagonal compression toward x=0, preserving the forbidden room:
the first odd diagonal has count a_0<=1; every later diagonal remains
unrestricted. Compression preserves cardinality and does not increase
the whole-quadrant neighborhood. Apply the layer notation from the
punctured-quadrant proof: delta is the compressed surplus, L is the number
of occupied diagonals, j_t their indices, and f_t the number of full
diagonals among the first t occupied ones. Its inequality is

    a_(j_t) <= delta-L+t-1+f_t.

If a_0=0, the known C_3(delta) bound applies and is at most H(delta).
If a_0=1 and no diagonal is full, the old no-full bound gives
delta(delta-1)/2.

Otherwise let u be the occupied rank of the first full diagonal.
The initial diagonal is proper, so u>=2, and j_u>=u-1. Its full length
is at least2u, whereas the layer inequality with f_u=1 bounds it by
delta-L+u. Therefore L<=delta-u<=delta-2.
For every t>=2, f_t<=t-1. Keeping the sharper first count a_0=1 and
summing the remaining layer bounds yields

    |S| <= 1 + sum_(t=2)^L (delta-L+2t-2)
         = 1 + delta(L-1)
         <= 1 + delta(delta-3).

The function H is nondecreasing on the nonnegative integers, so replacing
delta<=s by s proves the upper bound for every original support.

For attainment of the ramp branch, use proper diagonal counts
1,2,...,s-1 starting on the first odd diagonal and compressed toward x=0.
Its first output contributes one surplus unit, as does each occupied
diagonal, giving surplus s and size s(s-1)/2. The empty low endpoints
are separate. For the quadratic branch s>=5, take the full initial odd
triangle of surplus s-1 and delete its forbidden origin neighbor (1,0).
Every former neighbor of that deleted room remains covered, so the
neighborhood is unchanged. The resulting size is

    (s-1)(s-2)-1=s(s-3)+1,

and its surplus is s. This also works at s=4, where the ramp is larger.
The quadratic becomes the larger branch precisely at s>=5. QED.

## Intended use and boundary

If an odd-corner piece contains exactly one origin neighbor, its mandatory
surplus is two and its capacity is H rather than C_1(s)=s(s-1). If both
origin neighbors are present, retain C_1. If neither is present, use C_3.
This distinguishes an outgoing corner touched by one survivor room from
one whose two neighbors survive. It can therefore encode corner counts
of an erosion, but propagation of that extra information into the next
belief still needs a proved transition rule. This note does not assume one.

# Independent review of eventual affine periodicity on even cylinders

12 September 2026. Reviewer: the separate physical-proof/formalization lane.

**Pass after two bookkeeping clarifications, now incorporated.** I reviewed
`even-bridge-eventual-periodicity.md`, reconstructed its exact-surplus
frontier prerequisite, and checked the underlying clipped-potential and
height-strategy bounds. No finite enumeration or prefix-optimality
assumption is used in this argument. This is an ordinary mathematical
proof review, not a Lean verification or a literature-priority claim.

The statement reviewed is: for a fixed bipartite Hamiltonian transverse
graph Q with 2b vertices and an integer budget m>b, there are effective
positive integers N and even Delta such that

    T_m(Q × P_(n+Delta)) = T_m(Q × P_n) + 2b Delta/(m-b),  n >= N.

The period and threshold are deliberately very large. This does not give
the exact finite exception table or the smallest period.

## Potential equality really forces the geometric states

Write d=m-b, K=4b², h=bn, C=h-2K-m, and
psi(k)=min(C,max(0,k-K-m)). The height construction bounds the optimal
strategy's total integer slack by B=4K+4m+2b-2. A day with loss exactly d
must spend all m useful inspections on one cohort. Splitting the budget
or wasting an inspection makes the sum of positive-part loss bounds
strictly less than d.

For that owner, positive source potential forces the survivor count r>K.
Target potential below C gives the actual next count below h-K, and the
matching implies r is no larger than that next count. The middle-surplus
bound therefore applies. The raw count loss is at most d, while clipping
cannot increase a positive loss. Equality in the clipped loss forces
exactly m useful inspections and survivor surplus exactly b. Thus the
finite-frontier lemma applies to actual supports, rather than only to a
cardinality relaxation or a proposed optimal strategy.

I also checked the frontier lemma's substantial steps. If a boundary of
size b misses a contracted row, the undeleted-row SCC covers all but
4b² vertices. Otherwise there is exactly one boundary point per row.
The four row types and alternating rung directions bound each adjacent
row difference by four; the middle-size conditions exclude empty and
nearly full rows and then exclude differing end orientations. The sharper
cut displacement bound is two. Additional Q edges can only invalidate
some of these patterns; exact total surplus b forces the spanning-path
surplus to be exactly b as well.

## The cleanup bound is independent of the strategy length

An untouched cohort with interior potential gains count and cannot have
constant potential. The mate of an efficient owner consequently has
potential zero or C. Within an efficient run ownership changes at most
once: a previous owner already has potential below C, so when it becomes
the untouched mate it must be at zero and cannot later lose another d.

At zero potential a nonempty untouched mate leaves its bounded collar
within K+m+1 days. At full potential a proper untouched mate becomes full
within K days. These use the actual matching-contracted graph's strong
connectivity at n>=2, which gives at least one new room from every proper
nonempty set. Removing the first K+m+1 days of each owner block therefore
leaves a globally full or empty mate. The stated number E of nonclean
days is valid even if potential increases on some of those days.

## Why arbitrary nonclean moves cannot spoil the common band

At the beginning of each nonclean block, mark the preceding owner-front
cuts; also mark every physical shot column in every nonclean block. There
are only a bounded number of marked columns, regardless of their mutual
distances. A neighborhood step propagates influence by at most one
longitudinal column. The enlarged marks therefore shield an unmarked
interval from every such block, including intermediate times. A locally
full cohort remains full there through the matching inside each column;
a locally empty cohort receives no arriving room within the protected
interior. This argument covers arbitrary holes and remote shots elsewhere.

Each clean block has fixed owner and orientation, bounded frontier width,
and strictly monotone average cut. Individual cut positions need not be
monotone. Using a narrower retained interval removes partial excursions:
a block whose endpoint statuses agree cannot cross that entire interval
and later undo the crossing. Nonclean blocks preserve its status. Since
each cohort starts full and finishes empty, it has exactly one complete
clean crossing. During each crossing the other cohort is globally full
or empty, so the two edits occur at disjoint times and cannot interact.

The proof now explicitly chooses a raw gap of length W+2v+4, trims v+2
columns at each end, and names the retained interval J. I requested this
change so the subsequent W-based length bounds keep their full stated
margin. The overall threshold was increased accordingly.

## The finite additive graph and both surgery directions

A frontier label records orientation, offsets, current cohort phase, and
base-cut parity; at most M=8*5^(b-1) labels suffice. An edge has exact
sum-of-cuts drift d and physical displacement bounded by m. A closed walk
of length l has spatial drift d*l/b, an integer. Returning both phase
and base-cut parity makes both its time length and spatial drift even.
Extra Q edges are local to a column, so an even translation preserves all
validity conditions after the full and empty tails are filled correctly.
No automorphism of the finite longitudinal path is assumed.

The elementary cycle count is valid. M²*l0 edges give at least M*l0
chunks of length M. Every chunk contains a closed subwalk of length at
most M, and at least l0 chunks share one such length. Taking l0/l of them
produces disjoint cycles of total length l0, where
l0=2b*lcm(1,...,M). Their displacements sum to Delta=d*l0/b. Conversely a
single short closed walk can be repeated enough additional times to add
exactly l0 edges. No irreducibility or aperiodicity of the label graph is
needed.

For deletion, the initial/final frontier states lie on opposite sides of
the common physical deleted band. On a left crossing, translate the
initial cuts by -Delta and decrease that shift in magnitude after each
removed cycle; the shift ends at zero. On a right crossing, start with
zero shift and end with -Delta. Every retained edge is an even translate
of an original edge. The protected central margins keep all intermediate
cuts interior. The outside states map by ordinary column deletion, and
neighborhood formation commutes near the join because they are locally
uniform there. Insertion follows the inverse construction by repeating
one short cycle. The mate remains full or empty and returns to its phase
because the inserted/deleted time is even.

I requested that path vertices be explicitly declared after-inspection
survivor states. This is now stated: one path edge is the intervening
move plus the next inspection. Hence deleting l0 edges removes precisely
l0 inspection days per cohort, including the endpoint bookkeeping.
The two edits change the capture time by 2*l0, which equals
2b*Delta/(m-b). Both optimal-strategy comparisons follow, giving equality.

I checked the displayed W bound against the mean drift d/b, entry/exit
overshoots at most m, frontier width v, and the extra Delta margin. With
the raw-gap correction it supplies the asserted long central path and
matching endpoints. Increasing N once to cover the contracted board
handles all large n, with either longitudinal parity.

## Manuscript transfer

The complete proof was transferred to
`paper/sections/even-cylinder-eventual-time.tex` (theorem label
`thm:even-cylinder-eventual-time`). Its source SHA-256 at the reviewed
checkpoint is `cbf0ef39b3d7e4891f28eccdcbfa0035964feb1631233199f5ec6425e0362dd3`.
A standalone build with the preceding Hamiltonian-cylinder section
completed without warnings or overfull boxes. The new section occupies
five pages; all five were visually inspected, including the explicit
constants and the surgery endpoints. Main-manuscript integration remains
with the coordinating lane.

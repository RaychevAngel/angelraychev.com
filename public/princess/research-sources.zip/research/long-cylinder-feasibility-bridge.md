# A parity-independent exact threshold for every sufficiently long box

12 September 2026. Ordinary proof, independently reviewed by the frontier
agent. This is a direct corollary of a credited rectangle theorem and our
previously reviewed height construction; no claim of independent novelty.

Let Q be a finite bipartite graph with A>=2 vertices and a Hamiltonian path.
Then for every n>=2 floor(A/2),

    h(Q square P_n) = floor(A/2)+1.

The spanning path of Q gives a (not necessarily induced) subgraph
P_A square P_n. A rabbit can restrict itself to this subgraph, so the
known rectangular-grid theorem of Abramovskaya, Fomin, Golovach and
Pilipczuk gives

    h(Q square P_n) >= floor(min(A,n)/2)+1.

For even A the hypothesis is n>=A; for odd A it is n>=A-1. In either
case this lower bound is floor(A/2)+1. The height-function construction
in research/cylinder-height-strategy.md gives the reverse inequality for
every bipartite Q whenever n>=2. All hypotheses are therefore satisfied.

Every Cartesian product of finite paths has a Hamiltonian snake path.
Inductively, traverse the previous product forward in one layer and
backward in the next; the endpoints connect by a longitudinal edge.
Thus the result applies to any box whose selected longitudinal length n
is at least twice the integer part of half its transverse volume A.
There is no restriction on the parity of any side. The one-room
cross-section A=1 is simply a path and has threshold one by the earlier
path classification.

Examples:4×4×n needs exactly9 probes for n>=16;3×4×n needs exactly7 for
n>=12;4×6×n needs exactly13 for n>=24. These thresholds in n are sufficient,
not asserted to be the earliest possible. For3×3×n the specialized proof
already gives threshold5 for all n>=3, better than the general n>=8 bound.

Primary lower-bound source: *How to Hunt an Invisible Rabbit on a Graph*,
European Journal of Combinatorics52 (2016),12-26, Theorem2, pp.21-22:
https://fedorvf.github.io/articles/2016/2016g.pdf.

This settles eventual feasibility for every transverse box, including all
even cross-sections. It does not prove a corresponding exact capture-time
formula. The physical upper strategy is already executable in
src/cylinder_height_strategy.py; no new unproved construction is required.

# Exact weighted graph rows from monotone target thresholds

13 September 2026. An implementation consequence of the independently
reviewed unflagged nine-threshold theorem. No interval claim is added
for any flagged model.

For fixed survivor counts `(i,u)` and target counts `(j,v)`, let `S(T)`
be the maximum admitted positive survivor size at target size T, exactly
as in `bridge-lower-frontier-nine-proof.md`, with the stronger observed
erosion band. That proof shows `S(T)` is nondecreasing. Therefore, for
fixed positive survivor size q, all admitted targets of those counts
are precisely the suffix `T>=min{T:S(T)>=q}` within the target upper
bound. Precompute each such suffix as a bitset.

For source `(a,c,e)` and exact inspection count p, set `q=a-p` and OR
the suffix bitsets over every `(i,u,j,v)` satisfying the same coupled
deletion, upper cardinality, corner retention, and maximality conditions.
The empty survivor goes directly to the empty target. This computes
exact budget-indexed rows of the unflagged model from fixed-size inverse
capacity formulas, rather than enumerating every possible target and
surplus in the innermost loop.

The earlier pronic history rules are then handled literally. At fixed
`i=0`, `q=r(r-1)` and target size `r²`, remove the candidate unless its
counts are `(j,v)=(1,0)`, and redirect the surviving edge to the exact
pronic flag. A flagged source copies its ordinary source row restricted
to targets with own-corner count zero. The later near-square and
persistent-radius layers are separate transformations of these exact
weighted rows.

Implementation: `src/bridge_lower_frontier_fast.py`. On 25x26, quota13,
every one of its 40,866 weighted source/cost rows is identical to the
independently enumerated cached graph. Runtime was 0.128 CPU seconds
instead of approximately47 seconds. The comparison includes all prior
exact-pronic flags, not just full-start shortest distance. Receipt:
`bridge-lower-frontier-fast-check.json`.

The same implementation creates the 25x28 and25x30 base caches in
0.129 and0.143 CPU seconds. These times and graph sizes are execution
evidence, not additional exact capture-time claims. Original independent
reference caches are never overwritten by the faster builder.

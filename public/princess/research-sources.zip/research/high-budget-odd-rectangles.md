# High-budget odd rectangles: endpoint potentials and explicit scheduling

12 September 2026. New work in the present investigation. The antecedent is
the independently reviewed exact odd-rectangle neighborhood-profile and nesting
theorem in `odd-rectangle-isoperimetry.md`. No literature-priority claim or
complete physical Lean verification is made here.

**Status.** Sections 1--4 establish an ordinary universal ammunition lower
bound with a finite corner correction for m>=b^2+1. Sections 6--8 prove the
closed time formula in the uniform range m>=2b^2+1. The root agent completed
an independent mathematical audit of Sections 2,3,6,8,9 and accepted them
on 12 September 2026, after the explicit positivity correction (14a).
The root agent subsequently independently audited and accepted Sections11,
12, and14: the exact J/delta formula now holds for m>=b^2+b, and the
within-one-day bound holds for every m>=b^2+1. The root agent then
independently audited and accepted Sections15 and16: the exact time formula
now holds for every m>=b^2+1, and C has a separate four-evaluation formula.
Earlier unresolved statements below are retained as historical research entries.

## 1. Exact profiles and the unbounded corner profiles

Let w=2b+1, let n>=w be odd, and write wn=2h+1=N. The majority and minority
parities are z=0 and z=1, with capacities K_z=h+1-z. Assume m>=b^2+1. Set

    D=2m-w>0,  R(k)=ceil(sqrt(k)),
    Q(k)=least integer r>=1 with k<=r(r-1).

The exact profiles, zero at zero, are

    g_0(k)=k+min(R(k),b,R(h+1-k)-1),
    g_1(k)=k+min(Q(k),b+1,Q(h-k)).

The corresponding profiles before the far corner clips a neighborhood are

    L_0(k)=k+min(R(k),b),
    L_1(k)=k+min(Q(k),b+1),                         (1)

also zero at zero. Each L_z is increasing, and L_z(k)-k is nondecreasing.
For k>0, the elementary interlacing relations give

    0<=L_0(k+1)-L_1(k)<=1,
    0<=L_1(k)-L_0(k)<=1.                          (2)

Define J(0)=0, and for r>0

    J(r)=L_1(r/2)                 if r is even,
         L_0((r+1)/2)            if r is odd;
    delta(r)=L_0(r/2+1)-L_1(r/2) if r is even,
             L_1((r+1)/2)-L_0((r+1)/2) otherwise. (3)

Thus delta is zero or one. Also J(r+1)-J(r) is zero or one for r>=1,
J(r+2)-J(r)>=1, and J(D)=m. The exceptional jump J(1)=2 from J(0)=0 is
intentional. It is precisely the small-corner endpoint, rather than an error
in a cyclic convention.

## 2. Interior ammunition potential

For a nonempty parity-z count k assign rank u=2k+z, and put F(0)=F(1)=0.
For all ranks define

    F(u)=floor(u/2),                     if floor(u/2)<=m;
         q*m+J(r),                      otherwise,
         where u-(w+1)=qD+r, 0<=r<D.                 (4)

In the second branch q>=1. This function is nondecreasing. The following
interior inequality holds for 0<=p<=m and all k>=0:

    F(2k+z) <= p+F(2L_z((k-p)_+)+1-z).             (5)

Here and below an empty support has potential zero irrespective of its phase.

Proof. Capture and sources k<=m follow from F(2k+z)=k and L_z(s)>=s.
For larger sources write s=k-p>0. Use the positive-remainder quotient

    j(u)=floor(max(u-w-2,0)/D).

At j>=1 write u=w+1+jD+r with 1<=r<=D. Then F(u)=jm+J(r), equivalently

    F(u)=floor((u+jw)/2)-epsilon(r),
    0<=epsilon(r)=floor((r+w+1)/2)-J(r)<=b-1.       (5a)

At j=0, F(u)=floor(u/2), with no epsilon correction. These formulas also
show F(u)>=floor(u/2), F(u+2)>=F(u)+1, and monotonicity at every period
boundary.

If s lies on the plateau of (1), its next rank is v=u-2p+w. If p<=b,
then v>=u+1: p>0 gives strict slack by monotonicity, while p=0 gives
strict slack from F(u+2)>=F(u)+1. For p>b the quotient cannot increase
and falls by at most one. If it stays unchanged, the change of the floor
term in (5a), after including p, is at least b; the correction can save
at most b-1, so there is strict slack. If it falls by one, the positive
remainders obey t=r+2(m-p). Thus J(t)-J(r)>=m-p, proving (5). When the
target quotient is zero its actual cardinality is at least J(t), so this
argument still applies.

For nonplateau s, we have s<=b(b-1) in phase one or s<=(b-1)^2 in phase
zero, and L_z(s)<=b^2<=m. Also m>b^2 ensures that the noncapturable source
has quotient exactly one. Put a=k-m>0 and e=m-p, so s=a+e. Substitution
in (3)--(4) gives F(u)=m+L_z(a). Since L_z(a+e)-L_z(a)>=e, inequality
(5) follows. This proof also establishes the useful rigidity statement:
every noncapture equality in (5) lowers j by exactly one, and capture
starts at j=0. A noncapture source k<=m has strict slack because every
nonempty L_z(s)>s.

## 3. A finite correction for every far-corner transition

For a current count k in phase z write its deficit as d=K_z-k. For any
noncapture step, with p useful probes and nonempty survivor s=k-p, the new
deficit d'=K_(1-z)-g_z(s) satisfies

    d'<=d+p.                                      (6)

For z=0 this follows from g_0(s)>=s-1. For z=1 it follows from the strict
Hall surplus g_1(s)>=s+1, valid for every nonempty minority support. The
change in parity capacity is essential. **Do not apply (6) at capture:**
emptying a minority cohort can give d'=h+1>d+p=h.

Set B=b^2. If g_z(s) differs from L_z(s), then the survivor deficit
x=K_z-s=d+p is at most B. (For z=0 the clipping condition is R(x)-1<b;
for z=1 it is Q(x)<b+1, which gives the smaller bound b(b-1).)

Define the explicitly finite corner constant

    C = min { x+F(2g_z(K_z-x)+1-z) :
              z in {0,1}, 0<=x<=B }.              (7)

Because n>=w, all supports K_z-x in (7) are nonempty. Taking x=0 in
the two phases shows C<=F(N),F(N+1). Define

    Phi_z(k)=min(F(2k+z), max(C-(K_z-k),0)),
    Phi_z(0)=0.                                  (8)

This is nondecreasing in k. For every exact-profile step, including capture,

    Phi_z(k)<=p+Phi_(1-z)(g_z((k-p)_+)).            (9)

For a noncapture step, (6) gives the inequality against the target's second
branch max(C-d',0). For its first branch, if g_z(s)=L_z(s), use (5). If
the finite corner clips, x=d+p<=B, and (7) gives

    C-d <= p+F(2g_z(s)+1-z).

Thus the source is at most p plus each target branch, proving (9). At
capture k<=p<=m, and Phi_z(k)<=F(2k+z)=k<=p. This handles precisely the
case where (6) is unavailable.

Both full cohorts initially have potential C, and at capture they have zero.
Summing (9), with shared daily budget m, proves the rigorous lower bound

    T_m(P_w square P_n) >= ceil(2C/m).             (10)

This is a lower bound for arbitrary actual supports, since the proved
isoperimetric profiles and monotonicity of Phi imply the same inequality
when the actual neighborhood is larger. It does not assume prefix,
interval, monotone, or serial optimality.

## 4. Exact single-cohort capacity recurrence

Let A_z(t) be the largest count in starting phase z that can be eliminated
in t consecutive full-budget shots using the unbounded profiles L. Then

    A_z(1)=m,
    A_z(t+1)=m+A_(1-z)(t)-(b+z),
    A_z(t)=floor((tD+w+1-z)/2).                   (11)

Indeed all queried target counts are >=m>=b^2+1, above the last nonplateau
output, so the inverse of L_z at those counts is exactly subtraction by
b+z. Solving the two coupled affine recurrences gives (11). Consequently
any actual finite-board prefix with rank <=tD+w+1 clears in t full shots:
finite corner clipping only makes its neighborhoods smaller.

This is a proved finite-phase recurrence with a closed solution. It already
gives explicit partial-state strategies independently of the still-open
equality analysis for two simultaneous cohorts.

## 5. Proposed all-width high-budget formula and its exact boundary

For m<h write

    N-w-1=qD+r, 0<=r<D.

The candidate is

    T=2q,                         if r=0;
      2q+1,                       if r>0 and m>=2J(r)+delta(r);
      2q+2,                       otherwise.                 (12)

For h<=m<N the answer is two, and for m>=N it is one. The lower bound
for two days follows from the initial room count; two days are attainable
by clearing the majority in one shot and then the minority when m>=h+1,
or clearing the minority first when m=h.

`high-budget-odd-rectangles-checks.json` contains 959 exact two-count tests
for widths 7,9,11,13, sixteen odd lengths per width, and fifteen budgets
starting at b^2+1. Every exact time agrees with (12). This is evidence only.
In 39 cases the exact one-cohort ammunition is F(N)-1 rather than F(N),
so naively using 2F(N) as an unconditional lower bound is false. Among
these, two examples also leave a time gap even after rounding the actual
ammunition bound: (w,n,m)=(7,15,10) and (9,19,17). They are retained as
specific tests against overgeneralized equality arguments.

The next goals are to evaluate the finite constant (7), identify a useful
uniform range where C=F(N), and derive the phase obstruction in equality
cases. Sections6--9 first complete these goals for m>=2b^2+1, and
Sections12--14 subsequently improve the exact threshold to m>=b^2+b.

## 6. A uniform range with no corner discount

**Lemma.** If m>=2b^2+1 and m<h, the constant in (7) is C=F(N).

The x=0 cases cost F(N) and F(N+1), respectively. For x>0 the target
ranks of the two full-cohort departures are

    N-d_E(x),  d_E(x)=2(x-R(x)),
    N-d_O(x),  d_O(x)=2(x-Q(x))+1,                (13)

where x<=B=b^2; Q(x)<=b+1 and R(x)<=b. At the full board's high end,
the low-end term cannot beat the displayed far-corner term, because n>=w.
For x=1 the minority gain is -1, so its cost is immediately >=F(N).
All other gains are nonnegative and at most 2B-2b. Since

    D>=4B-2b+1 > 2B-2b,

subtracting one such gain crosses at most one quotient boundary.

First consider no crossing. Write r for the remainder of N. It suffices
to show J(r)-J(r-d)<=x. For d_E=2t, with t=x-R(x), the two endpoints
have the same phase. Root subadditivity gives an increment at most
t+Q(t)<=t+R(x)=x: indeed t<=R(x)(R(x)-1). For d_O=2t+1, put a=Q(x),
so t=x-a and t+1<=(a-1)^2. The two possible phase changes give

    L_0(k+t+1)-L_1(k)<=t+a,
    L_1(k+t+1)-L_0(k+1)<=t+a.

For the first inequality use R(k+t+1)<=Q(k)+a-1, with k=0 treated
using t+1<=(a-1)^2. For the second use
Q(k+t+1)<=R(k+1)+a. These follow by substituting the defining square
and consecutive-product bounds; clipping either surplus at b or b+1
preserves each bound. Thus the cost is again at least F(N).

If a quotient boundary is crossed, write 0<=r<d for the source remainder.
The target remainder r+D-d is on the plateau, since

    D-d >= 2m-2B-1 >= 2B+1.

Hence its J value is floor((r+D-d+w+1)/2). For d_E=2t the potential
drop is

    t+J(r)-ceil(r/2) <= t+R(x)=x.

For even r use Q(r/2)<=R(x), and for odd r use R((r+1)/2)<=R(x),
both consequences of r<2t and t=x-R(x). For d_O=2t+1 the drop is

    t+J(r)-floor(r/2) <= t+Q(x)=x.

For even r use Q(r/2)<=Q(x); for odd r use
1+R((r+1)/2)<=Q(x), since (r+1)/2<=t=x-Q(x)<(Q(x)-1)^2.
The cases r=0 simply use J(0)=0. If the target has reached the cardinality
branch of F, its value is at least the quotient-zero expression just used,
which only strengthens the inequality. This proves C>=F(N), and the
x=0 majority departure gives equality.

The simple threshold 2b^2+1 is sufficient rather than optimal. Section12
proves that b^2+b removes all discounts; Section13 shows that this improved
threshold is sharp in general.

## 7. Explicit schedules for the proposed formula

The upper bound (12) holds already for every m>=b^2+1. It uses one shared
day between two sweeps, with no asserted normal form for arbitrary optima.

Start with the minority cohort. In every noncapture full-budget step its
rank decreases by at least D, because g_z(s)<=L_z(s)<=s+b+z. If r=0,
its initial rank is qD+w+1, so (11) clears it in q days. Here q is odd
because N-w-1 is odd. The other untouched cohort is therefore minority
when its sweep starts, and it too clears in q days.

Let r>0. After q-1 full shots, the first cohort's rank is at most
2m+r+1. Its qth full shot thus leaves at most J(r) rooms: for even r
the last survivor is a minority set of at most r/2 rooms, while for odd r
it is a majority set of at most (r+1)/2 rooms. Clear those rooms on day q+1.

On that day the untouched other cohort is minority if r is even and
majority if r is odd. Put t=ceil(r/2). To make its next rank at most
qD+w+1 it suffices to create a deficit of t+1 when r is even, or t when
r is odd. The necessary inspection costs are respectively

    L_0(r/2+1)=J(r)+delta(r),
    L_1((r+1)/2)=J(r)+delta(r).

One direct geometric explanation is to choose that many opposite-parity
rooms as a terminal corner prefix and inspect all their neighbors. Their
neighborhood is a terminal prefix of size at most the stated L value.
The next belief avoids these chosen rooms and is itself an initial prefix.
The nesting theorem makes this a compatible continuation of the sweep.
The remaining q full shots suffice by (11). Thus one shared round is
possible whenever m>=2J(r)+delta(r), giving 2q+1 days.

If that inequality fails, the rank bound (11) clears either full phase in
q+1 days, because r+1<=D. Two consecutive such sweeps give 2q+2 days.
This proves every upper bound in (12), including q=1 and first-sweep
early-capture cases.

## 8. Complete uniform high-budget theorem

**Theorem (ordinary proof; independently reviewed).** For every odd
w=2b+1>=3, every odd n>=w, and every m>=2b^2+1, the minimum capture
time is exactly (12), together with the one- and two-day cases stated
above. Consequently this is an explicit all-length, all-width theorem
in a uniform quadratic budget range.

Sections 3 and 6 give T>=ceil(2F(N)/m). For r=0 this is 2q. For r>0
it agrees with (12) unless 2J(r)=m and delta(r)=1. In this latter case,
m is even. Since m>=2b^2+2, the root thresholds in (3) show that the
only possibility is

    r=m-w,  J(r)=m/2,  q even.                    (14)

For clarity, if r is odd, J=L_0((r+1)/2)=m/2 forces its plateau and
gives r=m-w; the minority surplus there is b+1, so delta=1. If r is
even, L_1(r/2)=m/2 forces r/2>=b(b-1)+1, and both relevant surplus
terms are on their plateau, so delta=0. The parity q even follows
from qD+r=N-w-1 odd. Since m<h, q>=1 and therefore q>=2.

Suppose capture were possible in 2q+1 days. Total available probes are
(2q+1)m=2F(N). Exact profile compression permits us to study the exact
two-count game. Every transition must be tight in (9), and every day
must use all m useful probes. Set C=qm+m/2 and d_0=m/2-b.
Here N=qD+m+1, so h=(qD+m)/2 and

    C-h=qw/2>=w>1.                              (14a)

Consequently C-d and C-d' are strictly positive for every nonempty
physical source and target. The clipping at zero in (8) cannot create
a spurious equality in any of the strict linear-branch comparisons below.

We record explicitly the required tight-transition facts.

**(a) Every positive tight departure from a full cohort starts in the
minority phase and spends p>=m/2.** The linear branch of (8) is strictly
inefficient for a positive departure: both full phases have d'<p for
p>0. It therefore suffices to check p+F(target) against C.

For p<=B the target ranks are (13), and r>d_E(p),d_O(p). In a majority
departure, put a=R(p). Its total cost minus qm is

    p+L_0(m/2-b-p+a) >= m/2+1.                  (15)

Indeed m/2-b>=B-b+1, p<=a^2, and

    B-b+1-a^2+a >= (b-a)^2+1

because their difference is (2a-1)(b-a)>=0. Thus the residual surplus
is at least b-a+1. For a minority departure, put a=Q(p). Its cost is

    qm + m/2-b-1+a+min(Q(m/2-b-1-p+a),b+1).

This exceeds C. If a=b+1 this follows from the nonempty residual's
positive surplus; if a<=b, the defining bound p<=a(a-1) gives a residual
strictly larger than (b+1-a)(b-a), forcing surplus at least b+2-a.

For p>B the survivors are on the plateau: q>=2 and m>=2B+2 leave a
full cohort far above the low endpoint after at most m probes. Substituting
r=m-w into the affine rank update shows that every majority departure
has cost at least C+1. More explicitly, p<=m/2 leaves positive odd
remainder m+1-2p, giving strict slack; p>m/2 leaves even remainder
D+m+1-2p, whose minority surplus is b+1, giving cost C+1. A minority
departure is strict at p<m/2 and has cost C at p>=m/2. This proves (a).
Every positive tight departure lowers j from q to q-1.

**(b) Every subsequent noncapture tight transition lowers j by exactly
one, and capture starts at j=0.** After the first positive departure
the potential is at most C-m/2=qm. It cannot return to a full cohort.
For any proper nonempty source and noncapture transition, the deficit
inequality (6) is strict: majority survivors have surplus at least zero,
and proper minority survivors have surplus at least two. Thus a target
linear branch in (8) always gives strict slack. Inductively every tight
target uses F, beginning with the departure in (a).

The bound F<=qm implies d>=d_0 in either phase, by monotonicity and
the ranks at d_0-1. Since d_0>B-b, a minority survivor cannot use the
far-corner term. A clipped majority step must have d=d_0+s and
0<=s+p<=B-d_0<=b-1. Its source rank and potential are

    u=qD+w+1-2s,   F(u)=qm-s.

Here R(d+p)=b, so its clipped surplus is b-1. The target remainder
above qD+w+1 is 2b-1-2(s+p)>0, and its cost is at least

    p+qm+L_0(b-s-p) >= qm-s+b+1 > F(u).

Thus every tight step avoids clipping. For all remaining steps, the
rigidity statement proved with (5) applies: a noncapture equality lowers
j exactly once, and a tight capture has source j=0. Zero allocations
cannot be tight after departure.

It follows from (a)--(b) that each cohort is active for exactly q+1
consecutive days, beginning at its first positive allocation. The two
active intervals use all probes and cover the 2q+1-day horizon, so their
starts are day 0 and day q and they overlap in one day. Because q is
even, these two start days have the same parity. The two initial cohorts
have opposite colors and cannot both be minority on their respective
start days. This contradicts (a), rules out 2q+1 days, and proves the
last case of (12).

## 9. Removing the root functions from the final high-budget answer

The theorem's formula has an even simpler equivalent form. Let

    R_m=m-w-1+1_[m=2b^2+1].

For m<h, divide N-w-1=q(2m-w)+r, 0<=r<2m-w. Then

    T=2q                      if r=0;
      2q+1                    if 1<=r<=R_m;
      2q+2                    otherwise.                    (16)

This contains only integer division and one endpoint indicator. To verify
the simplification, H(r)=2J(r)+delta(r) is strictly increasing for r>=1:
its successive increments alternate between positive increments of L_0
and L_1. Thus it suffices to find where H crosses m. If m=2b^2+1,
put k=b(b-1). The last allowed remainder is 2k=m-w, since

    H(2k)=L_1(k)+L_0(k+1)=2b^2+1=m,
    H(2k+1)=L_0(k+1)+L_1(k+1)=2b^2+3>m.

For b=1 this last allowed remainder is zero, and H(1)=5>m=3
gives the same result. If m>2b^2+1, substitution at r=m-w-1 and
r+1=m-w puts the relevant arguments on the plateaus, except for the
single endpoint m=2b^2+2, where L_1(b(b-1))=b^2. In that endpoint
H(m-w-1)=m-1 and H(m-w)=m+1; otherwise H(m-w-1)=m and
H(m-w)>m. This proves (16). The case b=1,m=4 has cutoff zero and
is again immediate from H(1)=5.

## 10. Fresh checks and remaining issues

`high-budget-odd-rectangles-uniform-checks.json` records 1,854 independent
exact two-count time calculations, 141 complete physical room-by-room
schedule replays, and 285,888 scalar envelope-transition checks. All pass.
The widths range from 3 through 17. These checks took 4.2 seconds on one
worker and are supporting evidence, separate from the unbounded proof.

Further finite arithmetic checks covered 43,404 full-corner constants and
critical equality endpoints, with no failures. Testing a proposed omission
of the indicator in (16) found the actual counterexample family
m=2b^2+1, r=m-w; retaining that indicator corrects the formula. For example
w=7,m=19,r=12 permits a shared round even though r exceeds m-w-1.

The interval b^2+1<=m<b^2+b still has real corner ammunition discounts
and exceptional equality patterns in larger widths. Formula (12) survives
the current exact tests there, but remains unproved in general. Sections12
and14 settle the larger budgets left open at the preceding checkpoint.
No claim is made that every optimal schedule has one shared round; this
is an explicit attaining class, and the lower proof covers all strategies.

## 11. At most one unit of corner discount throughout the larger range

**Lemma (ordinary proof; independently reviewed).** For every
m>=b^2+1 with m<h,

    F(N)-1 <= C <= F(N).                          (17)

The no-wrap arguments of Section 6 already apply at this smaller budget.
Also D>=2B-2b+1 remains larger than every nonnegative gain in (13), so at
most one quotient boundary is crossed. Only the wrap cases need attention.
Let r be the source remainder, and let Delta denote F(N) minus the cost
of the boundary departure. The actual target F is at least its periodic
endpoint expression, so it suffices to bound that latter expression.

For an E departure put a=R(x), and for an O departure put a=Q(x); put
d=b-a in both cases. If r=2k or r=2k+1, respectively, the four possible
wrap expressions are as follows. Here rho_0(t)=min(R(t),b) and
rho_1(t)=min(Q(t),b+1) for t>0, with rho_z(0)=0.

| Departure / r | Target argument ell | c | Delta |
| --- | --- | --- | --- |
| E / even | m-b-x+a+k | rho_1(k) | d+c-rho_0(ell) |
| E / odd | m-b-x+a+k | rho_0(k+1) | d+1+c-rho_1(ell) |
| O / even | m-b-x+a+k-1 | rho_1(k) | d+1+c-rho_1(ell) |
| O / odd | m-b-x+a+k | rho_0(k+1) | d+1+c-rho_0(ell) |

All target arguments are positive. Suppose Delta>=2. Its upper bound on
the target surplus is strictly below the corresponding plateau, so that
the unclipped square or consecutive-product root bound applies. Substitute
x<=a^2 for E or x<=a(a-1) for O. For a nonzero c, use
k>=(c-1)(c-2)+1 in an even-source row and k>=(c-1)^2 in an odd-source
row. Direct rearrangement gives the following upper bounds on m-B:

| Row | Upper bound on m-B |
| --- | --- |
| E / even | 2d(c-a)-3d-c+1 |
| E / odd | 2d(c-a)-2d-c+1 |
| O / even | 2d(c-a)-d-b-b*1_[a=b+1] |
| O / odd | 2d(c-a)-b-b*1_[a=b+1] |

For E, 0<=d and c<=a; c>=2 in the even row and c>=1 in the odd row.
Both bounds are nonpositive. For O with a<=b, the same conclusion follows
from d>=0 and c<=a (indeed c<=a-1 in the odd row). If a=b+1, the stronger
bound x<=B improves x<=a(a-1) by exactly b, giving the displayed indicator.
Then d=-1 and the two bounds reduce to 3-2c and 2-2c, respectively, again
nonpositive. This contradicts m>=B+1.

The only remaining case is c=0, possible only in an even-source row with
k=0. The assumption Delta>=2 forces d>=3. In the E row it gives

    m-B <= -2ad-3d+4 <=0;

in the O row it gives

    m-B <= -2ad-d-b+3 <=0.

Thus a discount of two is impossible. Taking x=0 and the E departure
still gives C<=F(N), proving (17).

**Consequence.** Throughout m>=b^2+1 the explicit upper time U in (12)
is at most one day greater than the true optimum:

    U-1 <= T <= U.                                (18)

For r>0, J(r)>=2, so (17) gives C>=qm+1 and T>=2q+1, whereas U<=2q+2.
For r=0, (17) gives T>=ceil((2qm-2)/m)>=2q-1, whereas U=2q. The
one- and two-day endpoint cases are exact separately. This deduction does
not assume that a corner discount is incompatible with a phase-critical
residue; the two remainder cases cover both possibilities directly.

The subsequent Sections12--14 settle the one-day alternative for
m>=b^2+b. It remains to decide that alternative throughout
b^2+1<=m<b^2+b. The finite corner expression (7) and its equality histories
isolate the issue without a growing physical-state search.

## 12. The no-discount threshold improves to b^2+b

**Lemma (ordinary proof; independently reviewed).** For every
m>=b^2+b with m<h, C=F(N).

Use the notation and four rows of Section 11, now assuming Delta>=1.
Increasing the allowed target root by one gives the following upper
bounds on m-B when c is nonzero:

| Row | Upper bound on m-B |
| --- | --- |
| E / even | 2d(c-a)-d+c-2 |
| E / odd | 2d(c-a)+c-1 |
| O / even | 2d(c-a)+d+2c-b-2-b*1_[a=b+1] |
| O / odd | 2d(c-a+1)+2c-b-1-b*1_[a=b+1] |

The E bounds are at most b-2 and b-1, respectively, because d>=0 and
c<=a<=b. For the O rows with a<=b, maximizing in c gives bounds at most
b-2 and b-3, respectively; in the last row c<=a-1. If a=b+1, both
O bounds reduce to -1 after the improved endpoint x<=B is applied.
If c=0, only even-source rows occur. A positive discount forces d>=2,
and the respective bounds are

    m-B <= -2ad-d+1,
    m-B <= -2ad+d-b+1,

which are also below b. Thus any positive discount implies m<B+b,
contradicting the hypothesis. Together with the x=0 departure this proves
C=F(N).

**Exactness away from a single phase boundary.** In this improved range,
the lower ceil(2F(N)/m) and the explicit upper in (12) agree unless

    m is even, 2J(r)=m, and delta(r)=1.            (19)

For fixed b,m there is at most one such positive remainder: H(r)=
2J(r)+delta(r) is strictly increasing, and (19) means H(r)=m+1.
Thus all odd lengths outside one residue class modulo 2m-w are now
classified exactly. On the exceptional residue class, the optimum is
one of 2q+1 and 2q+2. Section8 resolves it for m>=2b^2+1; Section14
below completes the separate equality argument for the improved range.

## 13. The improved no-discount threshold is sharp in general

The threshold in Section12 cannot be uniformly decreased by one. Let
b>=3 with b not congruent to 2 modulo5, set

    m=b^2+b-1,  D=2b^2-3,
    r=2(b-1)^2+1,

and choose an odd n>=w with wn-w-1=qD+r and q>=2. Such odd n exist
arbitrarily large: gcd(2b+1,2b^2-3)=gcd(2b+1,5)=1, so the congruence
has a solution, and adding 2D preserves it and odd parity.

Take the full-majority corner departure x=B=b^2. Its target rank is
N-2B+2b. The source and target ammunition values are

    F(N)=qm+B-b+2,
    F(N-2B+2b)=(q-1)m+B.

Indeed the source endpoint has argument (b-1)^2+1 in L_0, and the
target endpoint has argument b(b-1) in L_1. Adding the B probes gives

    B+F(N-2B+2b)=F(N)-1.

By Section11 this is exactly C=F(N)-1. These are actual physical odd
rectangles, not just arbitrary residues of an abstract counter. If
b=2 modulo5 the particular congruence is impossible: its right side
is 9 modulo the common factor5. This explains why the sharp generic
example does not contradict the previously solved width-five family.

## 14. Completing the equality case at the improved threshold

**Theorem (ordinary proof; independently reviewed).** Formula (12)
is exact for every odd w=2b+1>=3, odd n>=w, and m>=b^2+b. The simple
root-free expression (16) remains available in its stated smaller range
m>=2b^2+1; below that, the explicit J/delta formula is used.

By Section12 only the case 2J(r)=m, delta(r)=1 remains. Assume first
b>=2. Then m>=B+b>B, r>=2, and r<D. Let C=qm+m/2. The initial majority
rank has F(N+1)=C+1, because J(r+1)=J(r)+delta(r). Also

    C-h=((q-1)w+m-r)/2 >=2,                      (20)

since m-r>=4 for even r and m-r>=3 for odd r. Thus all linear branches
of the envelope are positive on nonempty supports.

### 14.1 A strict root inequality for a departure that does not wrap

For x>0, put a=R(x) for a majority departure, or a=Q(x) for a minority
departure. Whenever all displayed arguments are positive, the following
strict inequalities hold (with x<=B):

    x+L_1(k-x+a)   > L_1(k)       [E departure, r=2k],
    x+L_0(k-x+a)   > L_0(k)       [E departure, r=2k-1],
    x+L_0(k-x+a)   > L_1(k)       [O departure, r=2k],
    x+L_1(k-x+a-1) > L_0(k)       [O departure, r=2k-1]. (21)

These inequalities concern a full-cohort corner departure whose positive
quotient does not decrease. Its output endpoint is exactly the left side
minus x, so (21) says that such a positive departure cannot be tight.

Here is a direct root proof, including clipping. Write c for the source
surplus. In the first row the cost difference is a+rho_1(target)-c;
if a>=c-1 it is positive since rho_1(target)>=2. Otherwise c>=a+2,
and the bound k>=(c-1)(c-2)+1, together with x<=a^2, puts the target
strictly above (c-a)(c-a-1). The difference between these bounds is
2c(a-1)-2a^2+3>0. Thus its surplus is at least c-a+1.

In the second row the difference is a+rho_0(target)-c. Only a<c needs
checking. Using k>=(c-1)^2+1 and x<=a^2 puts the target strictly above
(c-a)^2: the difference is 2c(a-1)-2a^2+a+2>0. This forces surplus
at least c-a+1.

In the third row the same cost difference uses the source minority
surplus c. If a<c, use k>=(c-1)(c-2)+1 and x<=a(a-1). The target
exceeds (c-a)^2 by at least
(2a-3)c-2a^2+2a+3>0, forcing surplus c-a+1. Here a>=2.

In the last row the cost difference is a-1+rho_1(target)-c. If a<c,
use k>=(c-1)^2+1 and x<=a(a-1). The target exceeds
(c-a+1)(c-a) by at least
(2a-3)c-2a^2+3a+1>0, forcing surplus c-a+2. For a>=c the minimum
minority surplus two already gives strictness. All requested target
surpluses are at most their plateau caps, so clipping preserves these lower
bounds. This proves (21).

### 14.2 Tight histories have exactly q+1 active days

Suppose a 2q+1-day strategy succeeded. As before, equality in the total
ammunition bound forces every day to use all m useful probes and every
step to be tight in (9). Positive full departures have d'<p, and proper
nonempty transitions have d'<d+p. With (20), this makes any target
linear branch strictly inefficient. Hence each tight target after departure
uses F, and the potential never returns to C or a full cohort.

A positive full departure has quotient drop exactly one. If p<=B, the
gain in (13) is less than D; (21) rules out a zero drop. If p>B there
is no far-corner clipping: a majority departure is strict by
F(N+1)=C+1, and any tight minority departure has a single quotient drop
by the interior rigidity lemma (5).

For a proper clipped source put d=K_z-k and x=d+p<=B. Its output is
the same as the output of a full-cohort departure with x probes. Its
source quotient is either q or q-1, since d<=B, D>=2B-1, and r>=2.
If the source and target quotients both equal q, (21) gives

    p+F(target)>C-d>=Phi(source),

so the step is strict. If the source quotient is q-1, it has

    F(source)<C-d.                                (22)

To check (22), for even r=2s put alpha=rho_1(s), so m/2=s+alpha;
for odd r=2s-1 put alpha=rho_0(s), so m/2=s+alpha. In the four cases,
substitution into (4) gives the following lower bounds on
C-d-F(source):

    E / even r: alpha-1 >=1;
    O / even r: alpha   >=2;
    E / odd r:  alpha   >=1;
    O / odd r:  alpha   >=1.

These follow simply by bounding the new endpoint surplus by b or b+1.
When q=1 and the source quotient is zero, only even r occurs; direct
use of the cardinality branch gives exactly alpha-1 and alpha, respectively.
Thus no endpoint exception is omitted. The no-discount bound for the full
x-probe departure says x+F(target)>=C. Combining it with (22) again
makes the proper transition strict.

The only possible tight clipped transition therefore goes from quotient
q to q-1. All unclipped tight transitions have the same one-unit drop
by (5). A tight capture begins at quotient zero. It follows that each
cohort's active interval consists of exactly q+1 consecutive days: one
positive departure, the successive quotient drops, and its final capture.

### 14.3 The shared day's missing probe

Two such intervals covering the 2q+1-day horizon must start on days 0
and q and overlap in precisely one day. The first day spends all m on
the first cohort. It must be minority, because a full-majority m-probe
departure is unclipped and has cost at least F(N+1)=C+1.

The first cohort therefore uses q full m-probe days before its capture
day, leaving exactly C-qm=m/2 probes for that final allocation. On the
shared day the other full cohort is minority when r is even, and majority
when r is odd. A tight departure must lower its quotient, so its next
rank must be at most qD+w+1.

For even r=2s this requires omitting at least s+1 majority rooms from
the next belief. All neighbors of these omitted rooms must be inspected,
so the departure costs at least g_0(s+1)=L_0(s+1)=J(r)+delta(r)=m/2+1.
For odd r=2s-1 it similarly requires omitting at least s minority rooms
and costs at least g_1(s)=L_1(s)=m/2+1. These g values equal the L
values: the complementary deficits of the omitted sets are at least m>B,
as follows from q>=1 with the parity of q; in the odd-r case q is even
and at least two. This is an isoperimetric lower bound on the inspected
neighborhood, not an assumed choice of a prefix strategy.

The shared day would therefore require at least m/2+(m/2+1)>m probes,
a contradiction. This closes (19) and proves the theorem. Finally b=1
is already covered by Section8 for m>=3; the added case m=2 has D=1,
r=0 and follows immediately from C=F(N) and the q-day solo construction.

An additional independent finite check of Section14 tested 390,898 strict
root inequalities and 2,288 exact time values in the improved budget range,
with no failures. It is saved in
`high-budget-odd-rectangles-improved-checks.json` and took 7.9 seconds on
one worker. The polished seven-page manuscript section is
`paper/sections/high-budget-odd-rectangles.tex`; it includes the complete
proof and both corollaries, and passed a standalone LaTeX compilation
without overfull boxes. No complete physical Lean theorem is claimed for
this general high-budget result.

## 15. A constant-number formula for the corner correction

**Status: ordinary proof independently reviewed and accepted by the root
agent on 12 September 2026.** This section evaluates C explicitly throughout m>=B+1, m<h. It does not by
itself settle the possible one-day difference in the capture time.

Write N-w-1=qD+r, 0<=r<D, and put k=floor(r/2). Define

    c=rho_1(k) if r is even, and c=rho_0(k+1) if r is odd.

For an integer interval [l,u] and a function f, write E(f;l,u) for the
maximum of f(l),f(u) if l<=u, and for minus infinity if the interval is
empty. Only at most four evaluations will be needed. Define Theta_b(r)
by the following two rows of formulas.

For an even remainder r=2k, use

    f_E(a)=(b-a+c-1)^2+b+a^2-a-k,
    f_O(a)=(b-a+c)(b-a+c-1)+b+a^2-2a-k+1,

    Theta_b(2k)=max(
      E(f_E; Q(k+1), min(b,b+c-2)),
      E(f_O; 1+R(k+1), min(b,b+c-2))).            (27)

For an odd remainder r=2k+1, use

    f_E(a)=(b-a+c)(b-a+c-1)+b+a^2-a-k,
    f_O(a)=(b-a+c)^2+b+a^2-2a-k,

    Theta_b(2k+1)=max(
      E(f_E; Q(k+1), min(b,b+c-2)),
      E(f_O; 1+R(k+2), b)).                      (28)

If both intervals are empty, Theta=-infinity. Then the explicit result is

    C=F(N)-1_[m<=Theta_b(r)].                    (29)

Thus computing the sharp corner-corrected ammunition lower bound no
longer requires minimizing over B=b^2 possible deficits. Formula (29)
uses at most four evaluations of integer square roots and quadratics,
independently of the width and length.

**Proof.** At an E departure, the root a=R(x) is constant on each square
band, and at an O departure a=Q(x) is constant on each consecutive-product
band. Within either band increasing x by one decreases the target rank
by two. Since F(u+2)>=F(u)+1, the cost x+F(target rank) is nonincreasing
as x increases. It suffices to check the largest x in each band:

    E: x=a^2, 1<=a<=b;
    O: x=a(a-1), 2<=a<=b, and x=B with a=b+1.

The endpoint x=0 never gives a discount. Neither does the last O endpoint
x=B,a=b+1: in the even-remainder row its discount is
rho_1(k)-rho_1(m-B+k)<=0; in the odd-remainder row it is
rho_0(k+1)-rho_0(m-B+k+1)<=0. These conclusions also hold if the
cardinality branch of F improves the target value.

A no-wrap departure has no discount by Sections6 and11. For the remaining
band endpoints, substituting x=a^2 or x=a(a-1) into the wrap conditions
gives exactly the lower bounds on a in (27)--(28):

| Source and remainder | Wrap condition | Least a |
| --- | --- | --- |
| E, either parity | a(a-1)>=k+1 | Q(k+1) |
| O, r even | a(a-2)>=k | 1+R(k+1) |
| O, r odd | a(a-2)>=k+1 | 1+R(k+2) |

The target argument ell in Section11 is always positive. The condition
Delta>=1 therefore bounds its root respectively by

    b-a+c-1, b-a+c, b-a+c, b-a+c

in the E/even, E/odd, O/even, O/odd rows. The first and last bounds are
square-root bounds and must be at least one; the middle bounds are
consecutive-product-root bounds and must be at least two. These are
precisely the upper interval endpoints displayed in (27)--(28).

The root caps can be removed in these inequalities. The wrap condition
implies c<=a in the first three rows and c<=a-1 in the last, so every
required target root lies strictly below its plateau. Consequently
Delta>=1 is equivalent to ell being at most the square or consecutive
product of the stated root bound. Substitution of ell from the table in
Section11 now gives, in the four rows, exactly m<=f_E(a) or m<=f_O(a).
Each f is a quadratic in a with positive leading coefficient two.
Its maximum on an integer interval is attained at an endpoint, proving
that the periodic endpoint expression has a positive discount if and
only if m<=Theta_b(r).

For completeness, this periodic-expression test cannot spuriously detect
a discount in the initial cardinality branch of F. The upper bounds in
Section12 apply to the same four root conditions, and show that any
positive discount forces m<B+b. The minimum square size gives

    N-w-1 >= (2b+1)^2-(2b+1)-1 = 4B+2b-1,
    D <= 2B-3.

Thus q>=2 whenever the test is positive. After the unique wrap the
target quotient is at least one, where its value agrees with the periodic
expression (including remainder zero). Conversely the cardinality branch
can only increase F and therefore cannot introduce an extra discount.
Finally Section11 limits every discount to one, giving (29). QED.

**Evidence.** `high-budget-odd-rectangles-discount-checks.json` records
44,616 comparisons of (29) with the root-band minimum, covering b=1..16,
m=B+1..B+b+3, every remainder and parity-compatible sufficiently large h.
The full original B-term minimum was additionally evaluated for b<=7.
All comparisons pass in 1.1 seconds on one worker. This evidence is
separate from the unbounded derivation above.

## 16. Resolving the remaining one-day alternative

**Status: complete ordinary proof independently audited and accepted by
the root agent on 12 September 2026.**
The conclusion is that formula (12) is exact already for every m>=B+1.
The four-evaluation expression in Section15 remains a useful separate
ammunition formula, but its detailed evaluation is not needed here.

The cases b=1 and b=2 are already included in the exact three-row and
five-row theorems. We treat b>=3. The only newly added range is

    B+1 <= m < B+b.                              (30)

The endpoints m>=h are exact separately. Thus write N-w-1=qD+r as usual.
The minimum square size and D<=2B-3 imply q>=2. At r=0 the corner
constant has no discount: in (27) c=0, and each nonempty interval has
quadratic maximum at most B. Equivalently the c=0 positive-discount
bounds in Section12 are nonpositive. Hence C=qm, which gives T>=2q
and matches the upper. We henceforth take r>0.

### 16.1 A corner discount forces delta=0

Let eta=F(N)-C, so eta is zero or one. Suppose delta(r)=1 and a positive
corner discount exists. In the even row of Section12, c=rho_1(k) equals
rho_0(k+1), and therefore k>=(c-1)^2. This improves the lower bound
used there by c-2. In the odd row, rho_1(k+1)=c+1, so k>=c(c-1), an
improvement by c-1. With v=2d(c-a), the four upper bounds on m-B
therefore become

    E/even: v-d;
    E/odd:  v;
    O/even: v+c-a;
    O/odd:  v+2d+c-b.                             (31)

The first three are nonpositive using d=b-a>=0 and c<=a. In the last,
c<=a-1, and the expression is increasing in c, so it is at most -d-1.
The final O band a=b+1 was already shown to have no discount; it can
also be handled by its improved x<=B bound from Section12. Thus m<=B,
a contradiction. We have proved

    eta=1  implies  delta(r)=0.                  (32)

If the upper in (12) is 2q+1, the universal lower from Section11 already
matches it. If that upper is 2q+2, the only cases not settled directly by
ceil(2C/m) are now

    A: eta=0, 2J=m,   delta=1;
    B: eta=1, 2J=m+1, delta=0;
    C: eta=1, 2J=m+2, delta=0.                    (33)

### 16.2 Exact-profile reduction and proper tight transitions

We may work with the exact two-count recurrence, by the independently
proved profile and nesting theorem. Indeed, from any alleged physical
strategy retain its useful daily allocations to the two parity cohorts
and evolve the two minimum-profile counters with those same allocations,
capped if a smaller support has already been reached. Monotonicity keeps
the counters below the physical cardinalities, and a compatible prefix
strategy attains them. It also captures by the alleged deadline and has
the same or smaller budget each day. Pad its schedule with zero probes
if it captures early. This reduction is made before the equality argument:
all state updates below are exact g_z updates, not assumed equalities for
arbitrary physical neighborhoods.

For a hypothetical horizon T=2q+1, define the slack of a cohort step as

    p+Phi(next)-Phi(current) >=0,

and the unused budget of a day as m minus its two allocations. Their
sum over the horizon is Tm-2C. In cases A,B,C this is respectively 0,1,0.
Throughout these cases

    C-h=((q-1)w+m+(2J-m)-2eta-r)/2 >1.           (34)

For A, m-r is at least three; for B it is at least three as well; q>=2
and w>=7 suffice. Thus the linear branch C-d is positive on every
nonempty support, and is strictly greater than that support's size.

We claim that in A and B every tight noncapture step from a proper,
nonempty support is positive, remains proper, and lowers its positive
quotient j by exactly one. First, d'<d+p for every such step, so a
linear target branch would be strictly inefficient. A tight target
therefore uses F. An unclipped step is governed by the interior rigidity
lemma, and lowers j by one. A return to a full support is impossible
since its potential C exceeds the proper source's potential.

For a positive clipped step, d+p<=B and hence d<=B-1. Its source quotient
is q or q-1. To check this carefully with the positive-remainder convention,
it is enough that D+r>2B-2. For b>=4, in case A the even and odd remainder
bounds respectively give

    D+r >= 3B-4b,       D+r >= 3B-4b+1,

both strictly greater than 2B-2. Case B improves these by one. For b=3,
the only case-A residue is m=10,r=5; the only possible case-B residue
consistent with (32) is m=11,r=6. They give D+r=18 and21, respectively,
again larger than 2B-2=16. The rank offsets for the two phases can only
improve this lower bound. The target quotient is also q or q-1 because
the gain of a full x-probe departure, x=d+p<=B, is less than D.

If source and target both have quotient q, the full x-probe departure
has cost strictly greater than F(N) in A, by (21), or at least F(N)>C
in B, by the no-wrap inequality. Subtracting d shows that the proper
step is not tight. If the source has quotient q-1, direct substitution
in F gives the following lower bounds for C-d-F(source): write r=2s
and alpha=rho_1(s), or r=2s-1 and alpha=rho_0(s), respectively.

| Phase and remainder | Lower bound |
| --- | --- |
| E/even | alpha-eta-1 |
| O/even | alpha-eta |
| E/odd | alpha-eta |
| O/odd | alpha-eta |

These bounds are positive. In A, even alpha>=2 and odd alpha>=1. In B,
J=(m+1)/2>=6; even alpha>=3, since alpha=2 would force s<=2 and J<=4;
odd alpha>=2, since alpha=1 would force J<=2. There is no initial-period
exception because q>=2. As the full x-probe departure has cost at least C,
this strict gap again rules out a tight proper step. Only q to q-1 remains.

Finally, a zero-probe proper step is always strict, without any quotient
estimate. In phase O its neighborhood adds at least two rooms, so F
increases strictly; in phase E it adds at least one room except at deficit
one, where it returns to the full O class. In the former case F again
increases strictly; in the latter its potential rises to C. The linear
branch also increases strictly because d'<d. This proves the claim.
A tight capture starts at j=0: its allocation is at least the support
size, whereas Phi equals that size only in the cardinality branch, by
(34). Consequently every proper tight tail is consecutive and its length,
including capture, is exactly its current quotient plus one.

### 16.3 Case A uses the existing phase obstruction

Every step and day must be tight. A positive full departure lowers j by
one. For p<=B this follows from (21) and the gain bound <D; for p>B,
a full E departure is strict since F(N+1)=C+1, whereas the interior
rigidity lemma applies to a full O departure. The proper-tail claim then
gives exactly q+1 consecutive active days for each cohort.

The two intervals must overlap once. The first cohort is O, its final
allocation is J=m/2, and the other cohort's fresh departure on that day
needs J+delta=m/2+1 by the same omitted-set argument as Section14.3.
The relevant small-set neighborhoods are uncut: for an even remainder
their complementary deficit is (qD+w)/2 with q odd and at least three;
for an odd remainder it is at least (qD+w-1)/2 with q even and at least
two. Both exceed B. This contradicts the budget and disposes of A.

### 16.4 Discounted cases: the first day consumes slack

Any tight positive full departure in B or C must use the F target branch,
have p<=B, and wrap a quotient boundary. The linear target is strict by
d'<p; p>B is uncut and has cost at least F(N)>C. The wrap conditions
give the following useful minimum allocations:

| Remainder | E departure | O departure |
| --- | --- | --- |
| even | p>=J+1 | p>=J |
| odd | p>=J | p>=J+1 |

For example, with even r=2s an E wrap has p-R(p)>=s+1 and R(p)>=Q(s),
whereas an O wrap has p-Q(p)>=s and Q(p)>=Q(s). The odd case uses
r=2s-1, R(s)<=R(p) for E and R(s)<=Q(p)-1 for O. These arguments use
p<=B so the displayed source surplus bounds include their caps correctly.

The first day has total slack at least one. If any of its budget is unused,
this is immediate. If all m probes are spent on one cohort, its departure
has slack at least one because m>B and C<F(N). If they are divided between
two positive departures and both are tight, their minimum allocations
sum to at least 2J+1>m, impossible. This rules out case C, whose total
available slack is zero.

In case B the first day therefore consumes exactly the one available unit
of slack. Every later day uses all m probes, and every later cohort step
is tight. If both outputs of day one are proper, both cohorts must remain
active consecutively until capture. Their quotients are at most q (a proper output of a full
departure has rank at most N), so both capture
by day q+2. Since q>=2, this is earlier than 2q+1, leaving an entirely
unused subsequent day, a contradiction.

Suppose instead exactly one first-day output is proper. The other remains
full. Its probes, together with unused budget, contribute their entire
amount to slack, and so total at most one. The allocation p to the proper
output is therefore at least m-1>=B. Here its gain means N minus the target rank (the initial E rank is N+1).
Its exact-profile gain is between D-3 and D: when p=B the E gain is 2B-2b; when p>B
it is 2p-2b-2; the O gain is 2p-2b-1 throughout. The near-corner
profile is on its plateau because n>=w and p<=m<B+b. In case B,
r<=m-3<D-3 and r>=2, so its
quotient is exactly q-1. Both outputs cannot be full since then the
first-day slack would be m>1.

The proper cohort now has exactly q consecutive tight days left; a fresh
tight departure of the other cohort begins a tail of q+1 consecutive
days. All later days must use all their budget, so these intervals cover
the remaining 2q-day horizon and overlap exactly once. Before that overlap
only the first cohort is active. Its potential just after day one is
C-m+1; after another q-1 full allocations it consequently requires

    C-qm+1=J

probes for capture on the shared day. The fresh tight departure requires
at least J probes by the preceding table. Since 2J=m+1, the budget is
again exceeded. This rules out B and completes the proof that (12) is
exact throughout m>=B+1. QED.

**Section16 audit evidence.** `high-budget-odd-rectangles-critical-audit.json`
records 6,921 critical arithmetic cases, 130,990 clipped proper transitions,
1,102 first-day budget splits, and 18 independent exact two-count times
on physical odd rectangles. All pass in 1.7 seconds. A separate bounded
check also tested 97,396 instances of the strict no-wrap root inequalities
(21), with no failures. These finite checks support, but do not replace,
the unbounded ordinary proof above.

**Final integration.** The accepted theorem and complete staged proof are
in `paper/sections/high-budget-odd-rectangles.tex`. The headline threshold
is m>=b^2+1; the former one-day corollary is subsumed by exactness.
`high-budget-odd-rectangles-full-threshold-checks.json` adds 1,254 exact
two-count comparisons for widths7..23, every newly added budget, and odd
lengths w..3w+10; all pass in 24.5 seconds on one worker.

# Bounded numerical evaluation in a quadratic-surplus region

13 September 2026. New ordinary proof by the odd-clock branch; independently
reviewed and accepted by root on this date. Root checked the universal
paired decrease, both affine inputs, the upper/tail bounds, and fixed-K
unrolling against the implementation. This addresses the numerical lane.
It does not prove the unresolved short-board midpoint necessity.

## Statement

Fix an integer K >= 1 ONCE, independently of every rectangle and budget.
Let w=2b+1, b>=2, n>=w odd, m>=b+1, and put

    E=(wn+1)/2, M=E-1, D=2m-w.

On the region K*D>=b^2, both exact solo times and the two precentral solo
residuals have expressions using a fixed number of arithmetic operations,
integer square roots, floors, comparisons, and finite cases. One evaluation
uses at most 3K+1 paired-map blocks plus one bulk floor division. This bound
is independent of b,n,m, the initial canonical prefix size, and the requested
day at which a residual is evaluated.

For example FIXING K=16 gives a single 49-block expression valid whenever

    16(2m-w)>=b^2.

This is a genuine absolute O(1) numerical subfamily. Choosing K afresh as
ceil(b^2/D) would NOT prove the required uniform O(1) endpoint, and is not
part of the conclusion. No varying number of bands or matrix order is hidden.
The existing high-budget threshold was roughly m>=b^2; this numerical
subfamily extends into the intermediate-budget region down to roughly
b^2/32+b. The midpoint decision remains a separate obligation on short boards.

## Exact paired dynamics and one common affine interval

Use the proved odd-rectangle profiles g_p and set

    f_p(x)=g_p((x-m)_+), P_p(x)=f_(1-p)(f_p(x)).

Here p is the current physical color, C_0=E, C_1=M. Set H=b^2+1.
Whenever H<=z<=M-H, the three terms in the exact profile minimum show

    g_p(z)=z+b+p.

Indeed the increasing square/pronic root and the decreasing reflected root
have both reached the relevant cap b+p throughout that interval. This uses
only the existing exact profiles; it assumes no new physical normal form.

Define

    ell_p=2m+H-(b+p), u=m+M-H.

If ell_p<=x<=u, then both survivor inputs x-m and x-2m+b+p lie in
[H,M-H]. Therefore

    P_p(x)=x-D.

The interval is allowed to be empty. The comparisons between its endpoints
used m>=b+1>=b+p; they apply to both phases. The profile domain is also
respected because [H,M-H] lies in both physical color classes.

For every source, not merely a source in that interval,

    P_p(x) <= max(0,x-D).

If an intermediate count vanishes this is immediate. Otherwise the two
surpluses sum to at most b+(b+1)=w, so every positive paired output is at
most x-2m+w=x-D. If x<D, a positive output would contradict that inequality.
Thus both corner portions have uniform progress without classifying their
individual square/pronic bands.

## At most K pairs above the interval

The largest initial source is C_p, and

    C_p-u = H+1-p-m <= b^2

because m>=b+1 and b>=2. Apply P_p only while the source exceeds u,
using a block which also records whether capture happened in its first or
second constituent day. At most K such blocks suffice to reach x<=u or
capture, since each positive paired output decreases by at least D and
K*D>=b^2. The algorithm can simply write K conditional blocks; it need
not discover the stopping time with an unbounded loop.

If ell_p<=x<=u, take exactly

    q=1+floor((x-ell_p)/D)

successive paired steps in one operation. Their sources all stay in the
affine interval, their exact output is x-qD, and the final source exits
below ell_p. Every output in this part is positive because its two survivor
inputs were at least H. If the interval is empty, or the source is already
below it, this block does nothing.

## At most 2K+1 remaining pairs

After this step, unless captured,

    x <= ell_p-1 = D+b^2+b+1-p <= D+2b^2 <= (2K+1)D.

The middle inequality holds for b>=2. The universal paired decrease
therefore clears the remainder in at most 2K+1 paired blocks. Add the exact
number of one-day maps actually needed in the final block. The total is at
most K+(2K+1)=3K+1 conditional paired blocks, together with the one bulk
division. For fixed K this is a fixed composition of elementary numerical
maps, which may be written out as a fixed-size expression.

For an arbitrary prescribed day t, cap the bulk q by the available number
of complete pairs and stop a paired block after its first day when necessary.
If the day limit was exhausted inside the upper or bulk region, the remaining
blocks do nothing. Otherwise the preceding tail bound still applies. This
gives the exact remaining count in the same operation bound; the integer
bit size of n or t is not being claimed constant.

Finally compute both solo durations, tau as their minimum, and the two
physical-color residuals at tau-1 with the established phase adjustment.
The known exact one-day interval and sufficient scalar central test are
therefore bounded-operation quantities in this entire region. On any part
where existing theorems already establish scalar necessity, this also
evaluates the physical capture time in bounded operations. It does not
establish scalar necessity elsewhere.

## Implementation counterattack

`src/bridge_odd_clock_quadratic.py` implements this fixed-block prescription.
The first receipt `research/bridge-odd-clock-quadratic-check.json` compares
it with the already accepted O(width) root-band evaluator, including its
independent breakpoint/sorting logic. The two evaluators share the accepted
profile formulas, so this check tests the new acceleration and stopping/phase
rules rather than proving those previously established geometric formulas.

The 272 selected board/budget/K cases use K=1,4,16, b=2,3,4,7,10,20,40,80,
budgets at the new threshold, its neighbor, and b^2, and lengths w,w+2,5w,
and 10^12+1. Both full solo clocks and 11,619 prescribed-day counts from
several partial canonical starts agree. Runtime: 1.304491 CPU seconds.
No physical midpoint conclusion follows from this finite check. The
unbounded argument above is the proposed proof.

## Concurrent midpoint lane: a useful failed reduction

The proposed deadline credit mu_q(s)<=A-a+1 remains unproved. Exact separate
ammunition and the exact latest-step total-input inequality do not by
themselves prove it, even on genuine bottom solo layers.

At b=5,m=7,t=4, actual bottom solo capacities are (14,12), following (10,11).
The hypothetical pair (a,s)=(1,12), with physical color zero primary, has
total 13>12 and separate ammunition 25<=28. Its latest-step requirement is
L_0(1)+L_1(12)=2+16=18=max(10,11)+7. Yet mu_1(12)=23 while primary lag
is 14-1=13, so credit<=1 fails badly. This pair is NOT claimed attainable;
it shows why these two necessary numerical tests still omit ancestry.
The earlier b=3,m=5,t=2 pair (3,2) already defeats ammunition alone, but is
excluded by the latest-step test.

This new counterexample is about a proposed relaxation, not the actual
full-board conjecture. It reinforces the need to retain the history's
primary ancestry, or prove a stronger closed envelope from it. A tiny
additional check imposing primary>=secondary found no further failure
in six selected bottom traces, but that inequality is itself unproved
uniformly and is not being used as a theorem here.

A further proposed induction, assuming credit<=1 at the source, also
fails on synthetic solo capacities even when the capacities are componentwise
nondecreasing and primary>=secondary holds before and after the transition.
At b=4,m=6, take old physical capacities (5,7), so the primary is phase one,
and source (primary,secondary)=(6,1). Its credit is mu_0(1)-(7-6)=1.
Allocating all six probes to the secondary gives actual feature (4,4),
while the putative new solo capacities are (9,7). The mixed output remains
exceptional (total 8>7), but mu_1(4)-(9-4)=8-5=3. These capacities are
not a genuine shared solo layer: D_0=5 would require 10<=6t<12, impossible
for integer t. Thus the common exact time/ammunition thresholds can be an
essential hypothesis; gap bounds and primary orientation alone are not enough.

The conditional screening deduction and the scalar guard for b+2<=m<=2b
have now been independently checked in `bridge-odd-clock-guard-review.md`.
The universal history hypothesis remains open.

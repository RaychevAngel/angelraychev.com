# Four-cube formalization checkpoint

12 September 2026. The complete classification of P_4 square P_4 square P_4
for every natural daily probe budget is now proved in Lean against the
actual 64-room target-walk semantics, with only the standard axioms. The
final declarations are `FourCubeClassification.can_capture_iff` and
`FourCubeClassification.exact_minimum`, in namespace
`Princess.FourCubeCompression`. The critical result is T_8=40.

| Daily budget | Minimum inspections |
|---|---:|
| 0–7 | Impossible |
| 8 | 40 |
| 9 | 20 |
| 10 | 16 |
| 11 | 12 |
| 12 | 10 |
| 13–14 | 8 |
| 15 | 7 |
| 16–17 | 6 |
| 18 | 5 |
| 19–25 | 4 |
| 26–31 | 3 |
| 32–63 | 2 |
| 64 and above | 1 |

## Completed proof chain

- `ProductCompression.lean`: monotone, neighborhood-compatible operator
  composition and Cartesian-product lifting, with exact fiber cardinality.
- `ProductCompressionNormalization.lean`: a uniform fixed-length iteration
  of finitely many energy-decreasing maps reaches a common fixed point;
  the resulting map remains monotone and neighborhood-compatible and is
  idempotent. The iteration length does not depend on the input region.
- `ProductCompressionEnergy.lean` and `ProductCompressionRelabel.lean`:
  exact weighted-energy lifting and graph-isomorphism transport.
- `SquareCompressionFourData.lean`, `SquareCompressionFour.lean`,
  `SquareCompressionFourEnergyData.lean`, `SquareCompressionFourEnergy.lean`:
  the two physical diagonal maps on the4×4 square, proved for arbitrary
  regions containing either or both checkerboard colors. Each finite
  certificate ranges over all256 subsets in each color; the mixed-color
  extension is a proved slice argument. Monotonicity, cardinality,
  neighborhood inclusion, idempotence, and three weighted energies are
  verified, rather than assumed as an operator interface.
- `FourCubeCompression.lean`: the three coordinate-pair isomorphisms and
  six lifted maps on physical rooms `Fin64`, with a common energy.
- `FourCubeNormalForm.lean`:1152 cycles suffice uniformly; full-board
  actual capture is equivalent to capture in the common diagonal family.
- `FourCubeIdealData.lean`, `FourCubeIdeals.lean`: every normal-form region
  is closed under the actual predecessor masks, by a verified decreasing
  route. All relevant one-color regions are covered by the generic
  forced-predecessor enumeration in `FiniteIdealCertificates.lean`.
- `FourCubePotentialData.lean`, `FourCubePotentialCertificate.lean`:
  actual cardinality and neighborhoods of every ideal, and all source /
  residual inequalities for the integer potential. Data are untrusted
  until these checks pass. There are292 states per color and29,686 relevant
  transitions with at most8 useful probes; the checker also examines all
  other ideal pairs before rejecting their antecedents.
- `FourCubePotentialSemantics.lean`, `FourCubePotentialState.lean`:
  the certificate applies to arbitrary physical normal-form regions.
  The two current-color potentials start at80 and drop by at most2 per
  round under the shared8-probe budget.
- `FourCubeCriticalLower.actual_lower_40`: every actual8-probe strategy
  requires at least40 inspections.
- `FourCubeUpper.actual_upper_40`: a literal40-round schedule is replayed
  on all64 physical rooms and guarantees capture at zero-based day39.
- `FourCubeTimeCounterData.lean`: the exact one-color neighborhood profile
  is checked against all closed regions using the complete ideal checker.
  Ten integer counter tables cover the lower endpoints of the remaining
  finite budget intervals. `FourCubeTimeCounter0.lean` through
  `FourCubeTimeCounter9.lean` verify their monotonicity and every relevant
  allocation inequality; `FourCubeTimeCounter.lean` proves the generic
  comparison with actual successor counts and partially unused budgets.
- `FourCubeProfileGeometry.lean` interprets the profile as a statement
  about arbitrary physical regions in the normal form.
- `FourCubeAllLower.lean` proves the physical lower endpoints, the
  invariant obstruction for seven or fewer probes, and the two-day lower
  bound below64 probes.
- `FourCubeAllUpper.lean` replays twelve literal physical schedules for
  the upper interval endpoints, and proves the one-day construction when
  all64 rooms may be inspected.
- `FourCubeClassification.lean` assembles every natural budget, with
  actual walks, a shared daily budget, and matching time bounds. Zero in
  its `turns` function is an infeasibility sentinel, not a zero-day claim.

## Independent checks

The normalization was independently audited in
`research/four-cube-normalform-independent-review.md`. The complete lower
assembly, final actual-walk interpretation, and independent coordinate
replay were subsequently audited in
`research/four-cube-final-semantic-review.md` and
`research/four-cube-final-semantic-replay.json`.

A fresh43-module dependency-closure check passed in195.724 seconds in a
new empty output directory, with one compiler worker and unchanged source
hashes. Its source-specific receipt is
`research/even-resume-four-cube-lean-verification.json`; the reproducible
driver is `src/even_resume_four_cube_check_lean.py`. The all-budget theorem
has already compiled with standard-axiom reports. Its independent all-budget semantic
audit has passed in `research/four-cube-all-budget-semantic-review.md`,
with all twelve physical endpoint schedules independently replayed in
`research/four-cube-all-budget-semantic-replay.json`.

## Resource experiments and remaining scope

The first arithmetic table used a large conditional lookup and one universal
reduction. It checked successfully but consumed excessive transient memory.
The current source uses packed integer tables, balanced numeric lookup,
and at most12 source states per certificate lemma. The semantic checker
reassembles every branch; these partitions do not prune any cases.

The final theorem is a complete physical finite-board classification, not
only an arithmetic assertion under geometric assumptions. General even
boxes remain outside its formal scope. The ordinary/computational table
was independently verified in `research/even-resume-four-cube-exact.json`.

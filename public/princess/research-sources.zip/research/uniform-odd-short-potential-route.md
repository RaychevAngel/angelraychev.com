# A prospective common potential for odd-short, even-long rectangles

12 September2026, root final analytic lead. **Not independently reviewed;
not a manuscript theorem.** It builds on the now-reviewed strict-middle
critical-frontier lemma and its conditional minority-corner corollary.

Let w=2b+1, N=wn=2h, n even≥w, B=b(b+1), and m≥B+1 with m<h.
Use the same rank potential F(u) as the accepted odd-area high-budget
proof, with D=2m−w and the same J. Define a history bit z to be one
exactly when the preceding survivor had surplus b and strictly-middle
cardinality b²<q<h−B; otherwise zero. Assign current support size k
rank2k+z. Full initial supports have z0.

## Why repeated small-corner history may not be needed

For a noncapturable source k>m, consider the survivor q=k−p below h−B.
If q>b², the no-consecutive-critical theorem gives the usual alternating
rank lower step: surplus b forces source bit0,target bit1; larger surplus
gives target rank at least2q+2b+2. This is the interior inequality from
the old F proof with L_z(q).

If 0<q≤b², the new conditional corollary gives neighborhood at least
L1(q) when source z1, and the static theorem gives L0(q) when z0.
Both are at most b²+b+1≤m. Consequently F(2L_z(q)+1−z)=L_z(q):
the target is already in the cardinality branch of the potential.
Even an actual neighborhood larger than this lower bound only strengthens
that comparison. Therefore no label must persist through multiple small
corner moves to justify this particular one-step potential inequality.
For k≤m, F(2k+z)=k and plain matching handles the step directly.
This is a promising proof outline; it still requires a full case audit.

## Prospective boundary envelope

For co-small survivor deficit0≤x≤B, the exact static profile gives

    g(h−x)=h−x+min(R(h−x),b,rho(x)).

Such a survivor has target history bit0 by definition. Thus propose

    C=min_(0≤x≤B) [x+F(2g(h−x))],
    Phi_z(k)=min(F(2k+z), max(0,C−h+k)).

The deficit branch obeys d'≤d+p by matching. The interior argument above
and the defining boundary minimum would prove every potential inequality
and hence T≥ceil(2C/m). Full states have potential C since the x0 term
is F(2h); empty states are assigned0 explicitly.

The next tasks are an independent check of this whole geometric/history
bridge and a UNIVERSAL evaluation of the finite corner minimum C. The
existing odd high-budget corner inequalities may generalize, but this
has not been established. Equality cases can still need a strictness
argument, just as in the earlier odd-area theorem.

## Finite attack, not a universal proof

A direct rational/integer calculation over4,538 parameter triples, b1..25,
three lengths per b, m from B+1 through a short range above it, compares
ceil(2C/m) with the independently proved upper formula. It matches in
4,531 cases and is one day weak in seven; none has a larger gap.
Examples of weak cases are3×12,m4;5×16,m11;9×10,m21;15×18,m59;
29×64,m218;31×68,m247;37×80,m344. Full data are in
uniform-odd-short-envelope-check.json. These are potential gaps, not
counterexamples to the upper formula or certified new lower bounds.

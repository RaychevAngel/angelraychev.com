# Uniform minimum-budget time bounds on every odd rectangle

12 September 2026 UTC. Ordinary proof, independently reviewed with no gap;
see `odd-minimum-budget-uniform-independent-review.md`. The scalar potential
step also has a Lean proof in `lean/UniformOddRank.lean`, under explicit
neighborhood assumptions; that is not a full physical theorem formalization.
This does not rely on any finite charge certificate or a conjecture about
optimal serial play. It uses only the proved odd-rectangle profiles.

Let w=2b+1>=3 and n>=w be odd, V=wn, H=(V+1)/2, M=H-1, and m=b+1.
Then

    max(0, 2wn-2w²+2w-10) <= T_m(P_w square P_n)
                           <= 2wn-2w-2.                (1)

In particular, for every fixed odd width, the exact minimum-budget capture
time is 2wn+O(w²), uniformly for n>=w. This determines its leading linear
coefficient without proving an eventually constant correction C(w).

## 1. Lower bound: a truncated affine potential

Put

    K=2b²+2b+2,
    C=max(0, 2H-4b²-2b-6),
    F_p(k)=min(C,max(0,2k+p-K)).                         (2)

We prove that one cohort's potential cannot decrease after fewer than m
inspections, and decreases by at most one after m inspections. Thus the
charges are simply c_p(r)=1_(r=m). Since m>=2, at most one of the two
cohorts can receive m inspections on one day, giving a total decrease at
most one. Empty states have potential zero. The exact prefix-normal-form
theorem makes this a lower bound for unrestricted searches.

If C=0 there is nothing to prove. Assume C>0. For a current color p,
count k and inspection quota0<=r<=m, write

    q=max(k-r,0),               j=g_p(q).

Split into three regions.

**Low region: q<=b².** Here k<=b²+r (also true when q=0). If r<m,
k<=b²+b and

    2k+p-K <= 2b²+2b+1-K=-1.

The current potential is zero. If r=m, the same bound is at most one,
so the current potential is at most one. Nonnegativity of the successor
potential gives the desired inequality in either case.

**High region: q>=H-b²-1.** Every profile has surplus at least -1,
so j>=q-1>=H-b²-2. Therefore

    2j+(1-p)-K >= 2H-2b²-4-K=C.

The successor potential equals C, while the current potential is at most C;
there is no decrease.

**Middle region: b²<q<H-b²-1.** Both profiles are on their affine
plateaus. Indeed the low-corner terms have reached b in color0 and b+1
in color1, while H-q>=b²+2 and M-q>=b²+1 ensure that both far-corner
terms have also reached these caps. Thus

    j=q+b+p=k-r+b+p.

The difference between the two unclamped affine expressions is

    (2k+p-K) - (2j+(1-p)-K) = 2r-2b-1.

This is at most -1 when r<m and equals1 when r=m. The common clipping
function x↦min(C,max(0,x)) is monotone and1-Lipschitz. Clipping therefore
preserves the claimed upper bound0 or1 on the decrease.

These regions cover all q, including possible overlap of the low and high
regions for small boards. Each argument in an overlap remains valid.
We have proved the asserted one-cohort inequality for every parameter.

At both full color classes, the potential equals C: their unclamped values
are2H-p-K, larger than C by2b²+4-p. Hence T_m>=2C. Since V=2H-1 and
w=2b+1, this is exactly the lower bound in (1):

    2C=max(0,2V-8b²-4b-10)
      =max(0,2wn-2w²+2w-10).

## 2. Upper bound: two fixed odd-length phases

Start with the initial minority cohort of size M. The maximum majority
surplus is b and the maximum minority surplus is b+1=m. Therefore a
full-budget majority step decreases the size by at least one, while a
minority step does not increase it, unless the cohort is already captured.
Starting in the minority color, every pair of days decreases the count by
at least one. Consequently the cohort can be cleared in

    L=2(M-m)+1

days: after2(M-m)days its support has size at most m, and the last day
inspects that support. If capture occurs earlier, keep directing the phase
to the already-cleared cohort (equivalently make no useful inspections)
until this predetermined odd length L has elapsed. This preserves a
fixed phase length and is a valid upper-bound construction.

The other initial cohort has remained its full current color class.
It started in the majority color and L is odd, so it now occupies the
minority color and has exactly M possible positions. Repeat the same
L-day phase. Total time is at most

    2L=4M-4m+2=2wn-2w-2,

which proves the upper bound. Padding is used only to prove this bound;
no optimality of the padded or serial schedule is asserted.

## 3. Scope

The proof is uniform in both dimensions and has no finite enumeration
dependency. The exact all-length formulas for seven widths provide sharper
constants there. What remains open in general is whether the bounded
correction 2wn-T_m eventually stabilizes, and how to compute a uniform
closed or smaller corner-state recurrence for that correction.

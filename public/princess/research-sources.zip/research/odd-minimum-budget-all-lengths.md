# Minimum-budget odd rectangles: seven all-length formulas

12 September 2026 UTC. Ordinary proof using exact rational finite
certificates. Root and the formalization agent independently reviewed the
insertion argument and found no gap; see
`odd-minimum-budget-independent-review.md` for the second audit.
This is not a Lean result. The geometric premise is the independently
proved compatible odd-rectangle profile theorem.

## 1. Result and scope

For w in {3,5,7,9,11,13,15}, every odd n>=w satisfies

    T_((w+1)/2)(P_w square P_n) = 2wn-C(w),

where the constants in increasing width order are

    8,20,44,84,136,208,288.

The cases w=3 and w=5 agree with the separately derived smaller-width
theorems. This argument extends the minimum-budget result through width15.
It does not establish the formula for every width, or serial optimality
for other budgets. It constructs a matching serial strategy for the cases
proved here rather than assumes serial strategies are always optimal.

The exact certificate checker is `src/odd_minimum_budget_all_lengths.py`.
It uses Python integers and `Fraction` only, runs in0.047 seconds, and
writes `research/odd-minimum-budget-all-lengths.json`. That receipt stores
all base potential arrays, charges and the finite premises listed below.
No floating-point optimization is needed to reproduce or verify it.

## 2. One-cohort potentials give unrestricted lower bounds

Put w=2b+1, m=b+1 and D=m+1. At majority class size H the profiles are

    g0(0)=g1(0)=0,
    g0(k)=k+min(ceil_sqrt(k),b,ceil_sqrt(H-k)-1),
    g1(k)=k+min(Q(k),b+1,Q(H-1-k)),

where Q(k) is the least integer r>=1 with k<=r(r-1). These are the
proved physical profiles whenever H=(wn+1)/2 with odd n>=w.

Choose nonnegative rational charges c_p(r), 0<=r<=m, satisfying

    c0(r)+c1(m-r)<=1.                                  (1)

Suppose nonnegative potentials F_p(k), with F_p(0)=0, satisfy every
one-cohort inequality

    F_p(k)-F_(1-p)(g_p(max(k-r,0))) <= c_p(r).           (2)

Then the sum of the two current-color potentials decreases by at most
one per full-budget day. Every optimal prefix strategy can use the entire
budget while its total support exceeds m: additional inspections cannot
hurt, and a choice of extra suffix deletions keeps both residuals prefixes.
On its last day, pad the two inspection quotas to sum to m; the max(...,0)
convention is exactly the resulting empty support. Thus (1)-(2) imply

    T_m >= ceil(F0(H)+F1(H-1)).                         (3)

The use of current colors, rather than fixed initial colors, is essential:
the two colors reverse each night. The compatible-prefix theorem already
shows that restricted prefix strategies attain the unrestricted optimum,
so (3) bounds every original strategy, including interleaved cohorts.

For fixed charges we produce F as the shortest total charge of a
one-cohort path to zero in the finite state graph (p,k). It is computed
with integer-weight Dijkstra after multiplying by the common denominator.
The checker then verifies (1)-(2) directly using exact fractions; correctness
of the certificate does not rely on trusting the optimization routine.

## 3. The affine insertion lemma

Let A=b(b+1). Suppose a base majority size H, integer cut c and potentials
as in Section2 satisfy

    c>=A+2D,                 H-c>=A+2D+2,               (4)
    F_p(k)=2k+alpha_p for c-2D<=k<=c+2D, p=0,1.        (5)

For every integer Delta>=0 enlarge the majority size to H+Delta. Define
new potentials by inserting a slope-two interval at c:

               F_p(k)                       if k<=c,
    F'_p(k) =  F_p(c)+2(k-c)                 if c<=k<=c+Delta,
               F_p(k-Delta)+2Delta           if k>=c+Delta.     (6)

The formulas agree at their endpoints. We claim that the enlarged profiles
and F' satisfy the same charge inequalities (2). This is a statement for
every Delta, not an extrapolation from several computed lengths.

First note the uniform displacement bound. If
j=g_p(max(k-r,0)), 0<=r<=m, then

    |j-k|<=D.                                         (7)

Indeed each nonempty survivor has surplus between -1 and b+1, and r<=m;
if the survivor is empty, k<=m and j=0. The same bound holds in the enlarged
profile formulas.

Split an enlarged source count k into three cases.

**Low case, k<c-D.** The enlarged and base profiles agree at the survivor
q=max(k-r,0): the far-corner terms in both are above their plateau caps,
by (4). Thus j is exactly its base successor, and (7) gives j<c.
Both potentials in (2) are unchanged, so the base inequality applies.

**High case, k>c+Delta+D.** Write k0=k-Delta and q0=k0-r.
Here q0>c+D-m=c+1, so the low-corner terms have reached their plateau
caps. The profile formulas give the translation identity

    g'_p(q0+Delta)=g_p(q0)+Delta.

Consequently j=j0+Delta, where j0 is the base successor of k0. By (7),
j0>c. Both potentials gain2Delta, which cancels in their difference.
Again the base inequality applies.

**Middle case, c-D<=k<=c+Delta+D.** The survivor q=k-r is positive and
lies in the affine part of both profiles. The lower bound follows from

    q>=c-D-m>=A+1,

and the upper far-distance bound follows from

    H+Delta-q>=H-c-D>=A+D+2.

Thus j=k-r+delta_p, where delta0=b and delta1=b+1. By (7), both k and j
lie in [c-2D,c+Delta+2D], throughout which (5)-(6) give

    F'_p(k)=2k+alpha_p,
    F'_(1-p)(j)=2j+alpha_(1-p).

Their difference is therefore

    2r-2delta_p+alpha_p-alpha_(1-p).                   (8)

This is exactly the base potential difference at source k=c with the same
parity and quota r: its survivor and successor lie in the same affine
profile and potential collar by (4)-(5). Inequality (2) for that base
source bounds (8) by c_p(r). This proves all enlarged inequalities.

At each full color class, (6) increases its potential by2Delta. Hence the
sum in (3), and its ceiling, increase by exactly4Delta.

## 4. Pumping the explicit upper strategy

The base certificate supplies a serial strategy: spend all m inspections
on the first cohort until it can be eliminated, use any leftover quota
on the second that same day, then spend all m on the second. It records
which initial cohort goes first and verifies that **each active cohort
visits count c before an inspection**.
Every full-budget active-cohort step is nonincreasing in size, since all
surpluses are at most m. Thus each certified cut visit is reached from
above, and the lower trajectory thereafter stays at or below c.

Above c, a cohort's trajectory in the enlarged box is the translation by
Delta of the base trajectory. This follows directly from the high profile
translation identity; it remains valid as the trajectory approaches c
because c is well inside the plateau. The uninspected cohort remains its
full current color class. When the first active cohort reaches c+Delta,
insert2Delta extra full-budget days directed at that cohort. In the
plateau a majority step changes its count by -1 and a minority step by0:

    g0(k-m)=k-1,             g1(k-m)=k.

Every pair of days therefore reduces the count by one and restores its
current parity. The inserted block changes c+Delta to c while preserving
the phase of the original schedule. The second cohort remains full, with
the enlarged class size.

Now follow the base first-cohort trajectory below c without a shift. Its
last-day unused quota is the same as in the base strategy, so the starting
state of the second cohort is its base state translated by Delta. This
state is still above c, since it is within m+1 of a full class and (4)
puts c well away from that edge. Follow the translated second trajectory
until c+Delta, insert another2Delta full-budget days, and complete its
unchanged lower trajectory. Both inserted blocks have even length, so
neither changes the phase needed by later inspections.

This produces a physical prefix strategy in exactly base_time+4Delta
days. It proves the matching upper bound whenever the base certificate's
integer lower bound is its displayed serial time.

For actual rectangles, Delta=w(n-n_base)/2. Therefore the paired upper
and lower constructions prove

    T_m(w,n)=T_m(w,n_base)+2w(n-n_base)

for every odd n>=n_base. All smaller odd lengths from w to n_base are
checked explicitly in the certificate.

## 5. The seven certificates

In the table, alpha1=alpha0+1 in every row. The proof needs the literal
finite equality (5), not an inference from two endpoint values.

| w | m | base n | H | c | alpha0 | C(w) |
|---|---|---|---|---|---|---|
|3|2|13|20|10|-4|8|
|5|3|13|33|16|-8|20|
|7|4|15|53|26|-15|44|
|9|5|15|68|34|-26|84|
|11|6|17|94|47|-241/6|136|
|13|7|19|124|62|-59|208|
|15|8|21|158|79|-80|288|

The charges, ordered by quotas r=0,...,m, are:

    w3:  c0=c1=(0,0,1)
    w5:  c0=c1=(0,0,1,1)
    w7:  c0=(0,0,0,1,1), c1=(0,0,1,1,1)
    w9:  c0=c1=(0,0,1/3,2/3,1,1)
    w11: c0=c1=(0,0,1/6,1/2,5/6,1,1)
    w13: c0=(0,0,1/4,1/2,3/4,3/4,1,1),
         c1=(0,0,1/4,1/4,1/2,3/4,1,1)
    w15: c0=c1=(0,0,1/7,2/7,1/2,5/7,6/7,1,1).

At width11 the potential lower bound is2wn-410/3; rounding upward gives
2wn-136. All other displayed widths give the integer time directly.

The checker verifies32 finite lengths, all charge and potential
inequalities, every entry of each affine collar, both serial cut visits,
and the asserted matching times. In addition, for each width it directly
attacks (6) at Delta=1,w,2w+1, including values not corresponding to physical
rectangles. These21 redundant checks are supplementary; the proof in
Section3 is what establishes every larger length.

## 6. Discovery, failed reductions, and unresolved issues

The initial simple charge assigned zero below m/2, one above m/2, and
one-half at m/2. It exactly matched widths3,5,7,9, but missed widths11,
13,15,17 by2,4,2,4 days. Optimizing a small charge table found the rational
certificates above. The exploratory numerical script
`src/odd_minimum_budget_potential.py` records exact post-checks of its
rounded outputs. The final certificate uses the displayed rational
constants directly and does not depend on SciPy or numerical correctness.

The cubic interpolation of the first four C-values is

    8+12(b-1)+12 binom(b-1,2)+4 binom(b-1,3),

where w=2b+1. It predicts C(11)=144 rather than136 and C(13)=228 rather
than208, so that simple guess fails. No uniform formula for C(w) is proved.

The affine-insertion lemma is general and could be instantiated at more
fixed widths or used in a symbolic corner recurrence. What remains open
is a proof that suitable charges and a matching serial construction exist
for every width, or an exact richer invariant where these separable
potentials fail. The full all-odd-box two-count recurrence remains valid
independently of this narrower simplification.

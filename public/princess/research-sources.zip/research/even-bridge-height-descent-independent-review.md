# Independent review: direct height descent and polynomial onset

12 September 2026. Reviewer: the separate physical-proof/formalization lane.

**Pass.** All six sections of `even-bridge-height-descent-onset.md` were
independently reconstructed. This strengthens the already reviewed small
period without a finite-state graph or cycle argument. It is an ordinary
proof, not a Lean formalization.

For height vectors a,c with the same vertexwise parity, edge differences
of absolute value one, and c<=a, the descent rule is valid. At a vertex v
of greatest current height among those above target, a higher neighbor w
would also have to be above target: otherwise c_w=x_w=x_v+1 while
c_v<=x_v-2, violating the target edge condition. Thus v is a local maximum
and can be lowered by two without undershooting c. The sum of gaps falls
by two and the process terminates after exactly half the initial gap sum.

For compatible endpoints a,b and a duration t, set c=b-t. The height-sum
identity gives the mean difference c-a equal to -2mt/A. Along Q this
difference has range at most twice the diameter R. Consequently
c_v-a_v<=-2mt/A+2R<=0 whenever t>=ceil(AR/m). The descent gives exactly
mt flips. Uniform additions commute with the local-maximum comparisons,
so grouping the flips into m-flip blocks preceded by movement reaches b
in exactly t days. A day's repeated flips in one fiber remove different
top rooms. This is an integer-height statement first; the physical-room
claim uses the interior margin established next.

At completed days the mean decreases by D/A, D=2m-A. Every height vector
has range at most R. Hence all cutoffs remain between the two endpoint
means plus/minus R. During a movement and partial flips the maximum can
increase only by one, and the minimum is bounded by the day's final
minimum. This proves the stated physical interval bound and ensures all
flips are useful actual inspections in a sufficiently interior crossing.

For ell=2A/g and Delta=2D/g, g=gcd(A,D), both shifts are even and
A*Delta=D*ell. If a crossing has t>=ceil(AR/m)+ell edges, the modified
endpoints a-Delta,b have the correct phase and sum difference for t-ell
edges. Applying the endpoint lemma gives exactly the shorter replacement.
The insertion endpoints a+Delta,b give t+ell. Reflection handles right
frontiers. No residue-selected intermediate state is needed. The old
protected-band, full/empty-mate, and filled-tail surgery proofs therefore
apply without change to the rest of an arbitrary optimal strategy.

I checked the onset substitutions quantitatively. Replace the old long
walk requirement by H=ceil(AR/m)+ell+4 and take margin v=A+2. Since
R<=A-1 and m>A/2, H<=4A+2. The original W formulas, using physical
Delta in the even-order proof and paired Delta/2 in the odd-order proof,
therefore provide the required duration and physical margins. With
X=A+m+1, their explicit definitions give K,B,L=O(X²), E=O(X⁴),
F=O(X⁵), rho=O(X⁴), and W=O(X). The dominating threshold product is
F*rho=O(X⁹). All implied constants can be uniform over Q because only
A and the bound R<=A-1 were used.

For an odd-volume transverse box, the earlier odd-longitudinal proof also
has polynomial onset: S=sum(side-1)<=A-1, by repeated use of
(x-1)+(y-1)<=xy-1 for positive integer side lengths. Thus Z=A(S+1)<=A².
Its displayed collar and period-band parameters are polynomial in A,m
(in fact the resulting bound is dominated by the O(X⁹) bound above).
Taking the larger parity threshold retains a polynomial all-box onset.
The singleton cross-section follows from the exact path formula.

The period is valid rather than necessarily least, and neither the
exception values nor eventual offsets are evaluated by this argument.
The theorem fixes Q and m as the longitudinal length varies. No general
closed formula for all finite boxes or simultaneous cube scaling is
claimed. The manuscript can replace its longer cycle proof by this lemma
while retaining the two separately proved geometric reductions.

The final manuscript uses this direct endpoint proof. Its typesetting
receipt is `research/even-cylinder-manuscript-check.json`; that records
the exact source hash and the completed visual inspection. The earlier
finite-state height-loop proof remains valid evidence for the period but
is superseded in the manuscript by this shorter polynomial-onset route.

# Exact five-inspection time for every odd 3×3×n cylinder

12 September 2026 UTC. Ordinary proof with exact finite certificates,
independently audited by another agent; no mathematical correction was
required. See `research/three-by-three-cylinder-independent-review.md`.
No general physical Lean claim is made.

**Theorem.** For every odd n>=3,

    T_5(P_3 square P_3 square P_n)=18n-36.              (1)

Five is the minimum feasible budget throughout this family. This upgrades
the previously proved feasibility statement to an exact unbounded 3D time
formula. At n=3 it agrees with the separately complete Lean cube theorem.

## 1. Explicit stable corner tables

Let H=(9n+1)/2. For Q=3×3, the bottom-slice parity ranks and transverse
local costs are

    parity0 ranks:   1,2,3,5,8
            costs:  2,1,1,0,0
    parity1 ranks:   1,2,4,6
            costs:  2,1,1,0.

These ranks are stable for every n>=3, not merely for n>=7. To see this
directly, every predecessor of the last majority bottom point (2,2,0)
has weight0 or2 and longitudinal coordinate at most2; that point is the
first in weight layer4. For the minority bottom points, the last is
(1,2,0), sixth in its parity order. Its predecessors are the three unit
vectors and the two earlier weight-three points(2,1,0),(2,0,1), all with
longitudinal coordinate at most1. Thus enlarging the longitudinal path
beyond length3 changes none of these bottom ranks.

Define U_p(k) as the cumulative sum of listed costs through rank k and
B_p(k) as the number of listed ranks at most k. The general cylinder cost
and complement argument gives the exact profiles

    g0(0)=g1(0)=0,
    g0(k)=k+U0(k)-5+B0(H-k),              k>0,
    g1(k)=k+1+U1(k)-4+B1(H-1-k),          k>0.          (2)

Both tables have stabilized by rank8. Hence whenever k>8 and its
opposite tail distance is greater than8, the profiles are

    g0(k)=k+4,             g1(k)=k+5.                 (3)

They have stable low profiles and translated high profiles as in the
general cylinder theorem. Radius8 is sufficient; the conservative
general-purpose radius45 need not be used for this cross-section.

The maximum majority surplus is4. It is at most4 by the local-cost cap
and attains4 at k=3: U0(3)=4 and B0(H-3)=5 for every H>=14. The all-odd
feasibility criterion therefore gives hunter number5 for all odd n>=3.

## 2. Rational lower certificate and physical upper strategy

Use the two identical quota-charge sequences

    c0=c1=(0,0,1/3,2/3,1,1),                          (4)

indexed by the number of inspections r=0,...,5. They satisfy
c0(r)+c1(5-r)<=1. Let F_p(k) be the exact shortest total charge to clear
a single cohort under profiles(2). The certificate generator computes
these distances using integer-weight Dijkstra and then checks every
one-day inequality directly with exact fractions:

    F_p(k)-F_(1-p)(g_p(max(k-r,0)))<=c_p(r).

The sum of the two current-color potentials decreases by at most one
per day, so its initial value bounds the full unrestricted capture time.
For the five finite lengths n=3,5,7,9,11, the checker obtains

| n | H | initial potential sum | minority-first serial time |
|---|---|---|---|
|3|14|18|18|
|5|23|54|54|
|7|32|90|90|
|9|41|126|126|
|11|50|162|162|

The checker constructs physical rooms, unions their actual neighbors,
verifies that every profile equals(2), and replays the complete serial
inspection sequence against the actual room sets. Thus the upper values
are actual strategies, not just abstract count trajectories.

## 3. Extending the n=11 certificate to every larger odd n

At base n=11, H=50, choose cut c=25 and displacement bound D=m+1=6.
The exact potential arrays satisfy

    F_p(k)=2k-14+p for every13<=k<=37.                 (5)

These are the complete collars[c-2D,c+2D]. With corner radius8,

    c>=8+2D,             H-c>=8+2D+2.

The minority-first serial strategy reaches count25 while processing
each of its two cohorts. Thus both the potential-insertion and the
physical serial-insertion arguments apply.
Since25>5, the first cut visit occurs before the first cohort's finishing
day, so the second cohort has not yet been inspected and is exactly full.
At the second cut visit the first cohort is already empty. Thus the
companion-state premise is satisfied at both insertions.

More explicitly, increase H by any Delta>=0, keep the lower potential
through c, insert a slope-two interval of length Delta, and translate the
upper potential by2Delta. Every transition changes count by at most D.
Below the collar, profile(2) is unchanged. Above it, profile(2) translates
by Delta. Within it, (3) and (5) make the potential difference independent
of the count and of Delta. Hence every exact charge inequality persists.
The full potential sum increases by4Delta.

For the upper bound, insert2Delta full-budget days at each cohort's
cut visit. In each plateau pair, the majority day decreases its size by one
and the minority day preserves it. Each inserted block reduces
the shifted count c+Delta to c and has even length, preserving the phase.
The other cohort stays full or empty. Total time increases by4Delta.

For an actual odd n>=11, take Delta=9(n-11)/2. Both lower and upper
therefore become162+4Delta=18n-36. The five finite certificates supply
all smaller odd n>=3, proving(1).

## 4. Reproducibility and proof boundary

Source: `src/three_by_three_cylinder_time.py`.
Receipt: `research/three-by-three-cylinder-time.json`.
The certificate checks1950 exact one-cohort inequalities across five
physical boards, the full25-entry collar in each color, both cut visits,
and four redundant inserted potentials (Delta1,9,19,90). It runs in
0.01 seconds and stores the base arrays. The proof of interval insertion,
not those four extra tests, establishes every larger length.

This is an ordinary theorem with exact rational finite verification. The
n=3 case already has a separate complete Lean proof. The full n-variable
formula has not been represented as a physical Lean theorem here.

The independent checker verified 4,350 one-cohort inequalities and actual
room schedules on seven boards, including n=13 and n=31. It independently
checked both complete affine collars and the actual full/empty companion
states at both cut visits. The theorem and proof are incorporated in
`paper/sections/odd-eventual-time.tex`, Theorem
`thm:three-by-three-cylinder-time`.

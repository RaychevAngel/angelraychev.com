# Independent audit of the odd-short/even-long physical upper bound

12 September 2026. Audit of
`uniform-odd-short-high-budget-upper.md`. **Verdict: PASS as a uniform
physical upper bound only.** Matching lower bounds remain open. No new
computation or Lean formalization was used for this final bounded audit.

The hypotheses are w=2b+1, n=2L≥w, b≥1, h=wn/2, and
b(b+1)+1≤m<h. With D=2m−w and

    2h−w−1=qD+r, 0≤r<D,

the claimed three-branch upper expression follows from the actual
backward-envelope construction, with the stated phase-dependent J(r).

## Nonempty fibers and the erosion rank

The empty-fiber inequality k_x≤ceil(|x−i|/2) follows directly from the
adjacent cutoff differences and the two virtual empty heights. Summing
and moving one interval of the nondecreasing sequence ceil(j/2) to the
right gives the bound f(2b)=b(b+1). Thus the strict budget condition
makes every enlarged pyramid eligible for lowering all cutoffs by one.
No cutoff crosses below its permitted opposite-parity virtual height.

In relative phase p, exactly b+1−p fibers lose a vertex. The opposite-
phase eroded pyramid E therefore has size |R|+m−(b+1−p), and N(E) lies
inside the enlargement A, by the same coordinatewise cutoff argument
as before. Its rank 2|E|+(1−p) exceeds 2|R|+p by exactly
2m−2b−1=D. This verifies both the sign and the timing of the phase bit.

## Terminal corner and backward stopping point

For phase zero, a favorable corner prefix has surplus ceil(sqrt(k));
for phase one it has surplus Q(k). Ordering the final diagonal toward
the longitudinal origin makes it a downward pyramid. When the corner
bound beats the relevant plateau, it fits in the stated board. Otherwise
an arbitrary pyramid has surplus at most b or b+1 respectively, by the
odd transverse parity correction. The empty case has no neighborhood.

The numerator 2h−w−1 is even and D is odd, hence q and r have the same
parity. A terminal rank r+1 has exactly the stated size and phase.
After q−1 backward steps its rank is

    r+1+(q−1)D=2h−2m,

so its phase is zero and its size is h−m. Its final enlargement is the
full color class. All earlier ranks are smaller, so every enlargement
fits within h. For r=0, the empty phase-one terminal survivor is valid
bookkeeping, and the parity identity makes the initial phase zero just
as in the nonempty case.

For positive even r, r/2≤m−b−1 and J(r)≤m. For odd r,
(r+1)/2≤m−b−1 and J(r)≤m−1. Thus the additional solo inspection claimed
in the note always fits. The q-day envelope sequence itself consists
of actual physical inspection sets, with inclusions in the correct
forward direction even if actual beliefs are smaller than envelopes.

## Independent initial phases and central joining

Reflecting the even longitudinal coordinate swaps physical colors and
turns downward pyramids into upward pyramids. Relative to the reflected
endpoint, the construction still starts in relative phase zero. This
supplies either physical initial cohort without falsely asserting a
single compatible orientation for both.

At the shared central day, the two chosen half-constructions give opposite-
color neighborhood envelopes of size at most J(r). Their union fits
when 2J(r)≤m. Reading the second half backward is justified by reversing
an avoiding walk, exactly as in the previously audited even-short proof.
Otherwise the two completed solo searches may be concatenated; reflection
supplies the required physical initial phase of the second one. The
r=0 case similarly joins two q-day captures.

## Proof boundary

The note establishes the displayed bound for every parameter in its
stated range, with actual physical schedules. It does not establish
optimality. In particular, the symmetric static profile cannot supply
the needed temporal lower bound: odd transverse widths have a critical-
surplus orientation change between phases. The accepted sharp critical
geometry and its corner corollary are relevant inputs to that unresolved
lower argument, not a replacement for it.

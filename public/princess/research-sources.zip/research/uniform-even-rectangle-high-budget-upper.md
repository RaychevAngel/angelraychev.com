# Uniform high-budget upper construction on even-width rectangles

12 September 2026. Ordinary construction independently reviewed. The
matching complete lower bound is now in
`uniform-even-rectangle-high-budget-lower.md`, independently reviewed in
`uniform-even-high-budget-lower-independent-review.md`.
No dynamic nesting of isoperimetric minimizers is assumed.

Let G=P_(2b) □ P_n, n≥2b, h=bn, and b²+1≤m<h. Put D=m−b>0,
and divide

    h−b=qD+r,  0≤r<D.

Then q≥1. Put J(0)=0 and J(r)=r+min(ceil sqrt(r),b) for r>0.
We construct strategies showing

    T_m≤2q                         if r=0;
    T_m≤2q+1                       if r>0 and 2J(r)≤m;
    T_m≤2q+2                       otherwise.             (1)

These are the exact values after combining this construction with that
independent lower bound. This note itself proves the upper bounds only.

## 1. Large pyramids have no empty transverse fiber

Use the height encoding from `uniform-even-rectangle-states.md`:

    a_x=s_x−2+2k_x, s_x=(p−x) mod 2, |a_(x+1)−a_x|=1.

If row i is empty, a_i=s_i−2. For any x, the height inequality gives

    k_x≤ceil(|x−i|/2).

Writing f(L)=sum_(j=1)^L ceil(j/2), the total is at most

    f(i)+f(2b−1−i)≤f(2b−1)=b².

The middle inequality follows because the increments ceil(j/2) of f
are nondecreasing: shifting one summand's summation interval to the
right can only increase its sum. Thus every pyramid of size >b² has
all transverse fibers nonempty.

For such a pyramid A, lower every height by one. The resulting heights
are valid for the opposite physical parity and still differ by one on
adjacent rows. Call the new pyramid E. The total cardinality decreases by b, since rows with s_x=0 lose
one vertex and rows with s_x=1 lose none. Thus

    |E|=|A|−b,   N(E)⊆A.                                 (2)

More explicitly, the rowwise difference is
(1+s'_x−s_x)/2=1−s_x in the cardinality formula; b rows have each parity. The inclusion follows because each new
cutoff is a_x−1: its horizontal neighbors reach at most a_x, and the
neighboring-row cutoffs reach at most a_x as well. End clipping can only
shrink the neighborhood. No empty row is lowered below its allowed
virtual height, by the preceding lemma.

Every pyramid can be enlarged to any larger prescribed cardinality up
to h while remaining a pyramid, by extending its ideal in the finite
predecessor poset.

## 2. A one-cohort half-strategy with a controlled final support

There is a downward pyramid R of r vertices with

    |N(R)|≤J(r).                                         (3)

For ceil sqrt(r)<b, take the favorable corner prefix with the last
diagonal ordered toward y=0. For the other sizes, any pyramid has
surplus at most b. The empty case is immediate. Reflecting the even
short coordinate preserves the pyramid direction and swaps colors, so
(3) is available in either physical parity.

Construct an envelope strategy backwards from this final survivor R.
Enlarge R to a pyramid A with exactly m additional vertices. Its size
is at least m>b², so (2) gives an earlier survivor E of size

    |E|=|R|+m−b=|R|+D,
    N(E)⊆A.

Use A\R as that day's inspection set. Repeat backwards. After q−1
such erosion steps the earlier survivor has size r+(q−1)D. Enlarge it
by m one last time. Its size is

    r+(q−1)D+m=r+qD+b=h,

so this first pre-inspection envelope is the full parity class.
All intermediate requested sizes are at most h, so the enlargements
exist.

Reading forwards gives q inspection days, each with m designated shots.
The actual belief can be smaller than its envelope A; that is harmless:
inspect A\R, leaving an actual survivor contained in R, and use
N(R)⊆the next envelope to continue. The final actual survivor is contained
in the prescribed R, so its next belief has at most J(r) vertices.
This is an actual physical strategy, not a scalar transition assumption.

If r=0 this is already a q-day capture. If r>0, J(r)≤r+b<m, so one
additional inspection day captures the cohort.

## 3. Joining two halves through time reversal

We record the elementary time-reversal fact explicitly. Suppose shots
Q_1,...,Q_q starting from a full color class leave all possible rooms
after the following move in a set X. Then the reversed sequence

    X, Q_q, Q_(q−1),...,Q_1

captures a cohort starting from the full color occupied at the first
inspection of X. Indeed, a surviving walk in this reversed sequence,
read backwards, would be a walk avoiding Q_1,...,Q_q and ending after
one additional move outside X, contradicting its definition. The same
argument works when X is only an upper envelope of the possible rooms.

Take two q-day half-strategies from Section 2, choosing their parity by
short-axis reflection. Run the first one forward on one cohort during
the first q days. Run the second one in reverse on the other cohort
during the last q days. On the middle day inspect both of their final
neighborhood envelopes X and Y. They belong to opposite current colors,
so their union has size at most 2J(r). When that is at most m, this gives
a (2q+1)-day full-board strategy.

If the middle budget does not suffice, run the two (q+1)-day solo capture
strategies consecutively instead. For r=0 run the two q-day captures.
This proves all three cases of (1), with no assumption that the two
cohorts ever share a particular corner orientation.

## 4. Separate lower-bound dependency

The matching lower bound against arbitrary shared daily allocations and
arbitrary physical supports has now been proved in the separate note
linked above. Its inverse-profile deficit argument and midpoint
intersection combine with this actual physical upper, rather than
asserting automatically compatible scalar trajectories. The 6×6, m=5
example still warns against that inference outside this high-budget range.

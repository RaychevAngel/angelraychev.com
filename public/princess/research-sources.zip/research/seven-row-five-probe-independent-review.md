# Independent audit: seven rows with five daily inspections

12 September 2026. Reviewer: the frontier/geometry lane.

**Pass.** I independently reviewed `seven-row-five-probe-time.md` and
its exact rational certificate. The resulting ordinary theorem is

    T5(P7 × Pn)=2 ceil((7n-16)/3), for every odd n>=7.

This is not a Lean theorem. No broader low-budget rectangle formula is
inferred. Root also independently reviewed the candidate before this
audit was completed.

## Independent finite checks

I rebuilt the actual 7 × n room graph, its parity-prefix order, and every
prefix neighborhood directly from coordinates for n=7,9,...,23. Every
neighborhood was the required opposite prefix. I then constructed the
one-cohort reverse graph independently, using the displayed charges
scaled by four to integer weights, and ran exact shortest paths.
All recorded base potential values and complete tables agree.

All 5,778 resulting Bellman inequalities and monotonicity checks pass.
I independently replayed both priority orders of the serial strategy
on the actual room graph, checking every inspected set and every next
belief against its prefix representation. The better times are
22,32,42,50,60,70,78,88,98, exactly the formula. The stated base cut
visits, their physical colors, and their full/empty companions match.
Receipt: `seven-row-five-probe-independent-check.json`.

The computation is a finite certificate check, not the justification
for extrapolating to larger lengths. That justification is audited next.

## Unbounded potential extension

The three bases n0=19,21,23 cover all odd residues modulo six. Increasing
n by 6j adds delta=21j to each color capacity. Delta is divisible by
three, so the potential's three-residue collar repeats with value gain
2delta/3 on each cohort.

The stated base period identity is checked on c-10 through c+10, hence
supplies values through c+13. This is sufficient for the gluing proof.
For a middle source c-4<=k<=c+delta+4, the residual is at least c-9
and the output at most c+delta+8. The explicit profiles are affine with
surplus 3+p throughout this enlarged interval: the old corner margins
are much wider, and moving the upper corner by delta preserves them.
Reducing k modulo three to c,c+1,c+2 moves the output by the same amount;
the corresponding base output lies between c-2 and c+6. Both ranks
therefore change by the same multiple of two, leaving exactly a checked
base inequality. Sources farther below the cut use unchanged profiles;
sources farther above use the exact translated profiles. The joins
preserve monotonicity and zero at the empty state.

The exceptional n=5 modulo six class has integer initial rank one below
the claimed time. The only potentially tight first allocation is (3,2),
and the displayed second-step loss bounds are all strictly below one.
Actual larger neighborhoods cannot avoid this: first-step tightness
forces the same total potential as the minimal-count successor, and
monotonicity bounds every next potential from below. All quantities in
this two-step test lie in the translated upper region, so its strict
loss obstruction persists for every j. The two other residues require
only integer rounding. The initial rank and predicted time both increase
by 28j. Thus the finite bases prove the lower bound at every odd length.

## Actual upper strategy at every longer length

The recorded middle visits are above five rooms, so no leftover quota
is assigned to the other cohort there. During the first visit the other
cohort is actually full, and during the second it is empty. On the
middle plateau, full-budget moves lower the count by two in physical
color zero and by one in color one. Any two successive moves therefore
lower it by three and restore phase.

Starting a translated cut at k+delta, insert 2delta/3=14j such days.
This ends exactly at the old k in its original physical phase. Every
intermediate residual is still in the plateau: the lowest is at most
four below k and the upper end remains far from the translated upper
corner. These are actual nested-prefix transitions, so deleting the
five tail rooms supplies a valid physical inspection set each day.

Before its visit, the active cohort's counts and profiles translate by
delta; after the inserted block they agree with the old low trajectory.
Strict decrease under five probes keeps the old segments on their
required sides. The small overshoot between c and the recorded visit
causes no exception: the exact profile translation remains valid on
the surrounding collar. The untouched full cohort changes to the full
opposite parity as usual. Fourteen j days is even, so its phase, and
the later last-day spare allocation, are unchanged. Inserting separately
at the two visits therefore preserves the complete schedule and adds
28j days in total.

This supplies an attaining physical strategy for all n=n0+6j. The six
smaller bases complete every odd n>=7. No gap was found in either the
unbounded collar argument or its physical upper construction.

# A single indexed two-sweep construction for paths

**Status (11 September 2026, deadline research checkpoint):** the upper bound has a complete ordinary mathematical proof below, including all positive parameters and the delicate even-even residue. This is a reconstruction and compression of Angel Raychev's 2019–2020 parity-sweep constructions, not a new capture-time theorem. The underlying two-phase strategy and exceptional even-even construction are already in the historical papers. The explicit direction rule, uniform indexing, and compact count below were supplied in the present reconstruction. The arithmetic layer is kernel-checked as described in §7; no complete Lean proof of strategy correctness is claimed. The lower bound is a separate task.

The executable indexed generator is [`../src/path_strategy.py`](../src/path_strategy.py). It does not perform a search or inspect a simulated belief state when choosing probes. A separately structured ordinary-set verifier replayed its output for every `1 <= m <= n <= 400`: **80,200 pairs, all capturing in the claimed number of turns**, in approximately 7.6 seconds. The saved receipt and sample schedules are [`path-upper-bound-checks.json`](path-upper-bound-checks.json). These checks test the construction implementation; they are not a substitute for the proof below or evidence for a lower bound.

## 1. The model and the two trajectory classes

Vertices are `1,...,n`. At each turn we inspect at most `m` vertices, then the princess, if not captured, moves exactly one edge. On the all-miss branch let `B_t` denote the possible positions immediately before turn `t`. If `S_t` is that turn's inspection set, then capture is guaranteed on that turn if `B_t` is contained in `S_t`; otherwise

\[
 B_{t+1}=N(B_t\setminus S_t).
\]

Partition trajectories by their initial parity. The two classes occupy opposite parities at every turn. Their belief sets evolve independently under this same neighborhood operation; once one is empty, it stays empty. For `n>=2`, the neighborhood of an entire parity class is the entire opposite parity class. Consequently a trajectory class that has not yet been inspected is still the full appropriate parity class.

The cases `n<=m` need one inspection of the whole path. For `n=2,m=1`, inspect vertex 1 twice. Henceforth assume `n>m>=1` and `n>=3`.

## 2. The elementary sweep invariant

For `1<=r<=n`, define the parity prefix

\[
 A(r)=\{r,r-2,r-4,\ldots\}\cap\{1,\ldots,n\}.
\]

It has `ceil(r/2)` vertices. If `1<=r<n`, then

\[
 N(A(r))=A(r+1).
\]

Suppose a class currently has belief `A(r)` and we inspect its `b` largest vertices. If `b>=ceil(r/2)`, that class is eliminated immediately. Otherwise the survivors are `A(r-2b)`. If `b>=1`, then `r-2b<n`, so after the move its next belief is exactly

\[
 A(r-2b+1).                                      \tag{1}
\]

The identical assertion holds after reflecting coordinates by `v -> n+1-v`.

In particular, a full batch of `m` probes shifts the frontier by

\[
 d=2m-1.
\]

Starting from `A(R)` with `R>=2`, repeated full batches eliminate that class in exactly

\[
 L(R)=\left\lceil\frac{R-1}{d}\right\rceil       \tag{2}
\]

turns: before the final turn its frontier exceeds `2m`, and on the final turn it is at most `2m`, so all remaining positions fit in one batch. Formula (1) is used only while survivors remain; one must not move an already eliminated class or invent a final surviving vertex.

## 3. Uniform strategy and explicit inspected sets

Set

\[
 e=\left\lceil\frac{n-2}{d}\right\rceil,
 \qquad \rho=n-2-(e-1)d\quad(1\le\rho\le d),
\]

\[
 c=\left\lfloor\frac{\rho}{2}\right\rfloor+1,
 \qquad \ell=m-c.
\]

Here `e` is the first sweep's elimination turn, `c` is the number of positions left in that class on turn `e`, and `ell` is the spare inspection capacity on that turn.

**First sweep.** Start with the trajectory class whose initial vertices have the parity of `n-1`, and sweep it from right to left. Its initial belief is `A(n-1)`. On turn `1<=t<=e`, its frontier is

\[
 r_t=n-1-(t-1)d,
\]

and inspect

\[
 F_t=\{r_t-2j:0\le j<\min(m,\lceil r_t/2\rceil)\}.
                                                               \tag{3}
\]

For `t<e`, this uses all `m` probes. On turn `e`, the frontier is `rho+1` and exactly `c` probes eliminate this class. Thus `ell` probes remain available on that turn.

**Second sweep.** Its first inspection turn is

\[
 s=\begin{cases}e,&\ell>0,\\e+1,&\ell=0.\end{cases}
\]

Use the following direction:

- If `n` is odd, sweep the second class from right to left.
- If `n` is even and `s` is even, sweep it from right to left.
- If `n` is even and `s` is odd, sweep it from left to right.

For even `n`, this direction means that the initially inspected end does **not** itself belong to the second class: the first probes there start one vertex inside the path. This endpoint choice is the missing detail that a naive same-direction sweep gets wrong in cases such as `(n,m)=(8,2)`.

To specify every second-sweep probe by an index, let

\[
 \phi(v)=\begin{cases}v,&\text{right-to-left},\\n+1-v,&\text{left-to-right}.
 \end{cases}
\]

Work in the reflected coordinate `u=phi(v)`, so this is always a descending sweep. Let `R_0` be the largest coordinate of the second parity class on turn `s`. The chosen direction gives

\[
 R_0=\begin{cases}
 n-1,&n\text{ even},\\
 n,&n\text{ odd and }s\text{ odd},\\
 n-1,&n\text{ odd and }s\text{ even}.
 \end{cases}                                                   \tag{4}
\]

The first batch size is `b=ell` if `ell>0`, and `b=m` otherwise. On turn `s`, inspect

\[
 G_s=\{\phi^{-1}(R_0-2j):0\le j<\min(b,\lceil R_0/2\rceil)\}.
                                                               \tag{5}
\]

If the class survives this batch, then for each subsequent turn `t>s` until elimination its frontier is

\[
 R_t=R_0-2b+1-(t-s-1)d,
\]

and inspect

\[
 G_t=\{\phi^{-1}(R_t-2j):0\le j<\min(m,\lceil R_t/2\rceil)\}.
                                                               \tag{6}
\]

The complete inspection set is `S_t=F_t union G_t`, omitting terms outside their specified turns. Only turn `e` can contain both types, and then the two sets lie on opposite parities and have total cardinality `c+ell=m`. All other turns use at most `m` probes. Equations (1)–(6) prove that the first class is eliminated on turn `e`, that the second class is then swept without recontamination, and that the resulting schedule guarantees capture.

## 4. Exact length of the construction

We show that its length is

\[
 T=\begin{cases}
 2e-1,&\rho\le m-2,\\
 2e-1,&\rho=m-1\text{ and }n,m\text{ both even},\\
 2e,&\text{otherwise}.
 \end{cases}                                                   \tag{7}
\]

This also applies to `m=1`: only the last branch occurs, giving `T=2n-4`.

### No spare probes: ell=0

Here `c=m`, so `rho` is `d-1` or `d` (discard `rho=0` when `m=1`). The second sweep starts on turn `e+1`.

For even `n`, its initial frontier is `n-1`, exactly as in the first sweep, so it takes another `e` turns. Thus `T=2e`.

For odd `n`, the identity `n-2=(e-1)d+rho` implies `rho` and `e` have the same parity. If `rho=d-1`, then `e` is even and the second initial frontier is `n`; formula (2) gives `ceil((n-1)/d)=e`, since `n-1=ed`. If `rho=d`, then `e` is odd, the second frontier is `n-1`, and formula (2) again gives `e`. Hence `T=2e` in both cases, as required by (7).

### Positive spare probes, even n

Now the second sweep begins on turn `e`, with frontier `n-1`. After its `ell` probes and the move, its frontier is `n-2ell`. The second class cannot already have been eliminated on turn `e`: if `e=1`, the two classes initially contain `n>m` positions in total, while if `e>=2`, the untouched second class has more than `m` positions. Therefore (2) gives

\[
 T=e+\left\lceil\frac{n-2\ell-1}{d}\right\rceil
   =2e-2+\left\lceil\frac{\rho+2c}{d}\right\rceil.              \tag{8}
\]

Since `ell>0`, we have `rho<=d-2`; the last ceiling is either 1 or 2. If `rho` is even, then `rho+2c=2rho+2`, whereas if `rho` is odd, then `rho+2c=2rho+1`. Thus the ceiling is 1 exactly when

\[
 \rho\le m-2\quad\text{or}\quad(\rho=m-1\text{ and }m\text{ even}),
\]

which is (7) for even `n`.

### Positive spare probes, odd n

Again `s=e`, and `rho` has the parity of `e`. If `e` is odd, the second initial frontier is `n`; after its spare batch it is `n-2ell+1`. If `e` is even, those frontiers are `n-1` and `n-2ell`. Consequently

\[
 T=\begin{cases}
 e+\left\lceil(n-2\ell)/d\right\rceil,&e\text{ odd},\\
 e+\left\lceil(n-2\ell-1)/d\right\rceil,&e\text{ even}.
 \end{cases}
\]

Substitute `2ell=d+1-2c`. For odd `e`, `rho` is odd and `2c=rho+1`; for even `e`, `rho` is even and `2c=rho+2`. Both cases simplify to

\[
 T=2e-2+\left\lceil\frac{2\rho+2}{d}\right\rceil.              \tag{9}
\]

Again the last ceiling is either 1 or 2. It is 1 exactly when `rho<=m-2`, proving (7) for odd `n`.

### Comparison with the historical claimed formula

For `m>=2`,

\[
 \left\lceil\frac{2n-4}{d}\right\rceil
 =2e-2+\left\lceil\frac{2\rho}{d}\right\rceil
 =\begin{cases}2e-1,&\rho\le m-1,\\2e,&\rho\ge m.\end{cases}
\]

Also `rho=m-1` is equivalent to `n congruent m+1 (mod d)`. Comparing with (7), the construction has exactly

\[
 \boxed{T=\left\lceil\frac{2n-4}{2m-1}\right\rceil
 +\mathbf1_{\{n\equiv m+1\pmod{2m-1},\ \text{at least one of }n,m\text{ odd}\}}.}
\]

This proves the desired **upper bound** for every `n>m>=2`, alongside `2n-4` for `m=1,n>=3` and the elementary cases above. Calling this value optimal still requires the separate lower-bound proof.

## 5. Small examples and the direction issue

For `n=8,m=2`, the schedule is

\[
 \{5,7\},\quad\{2,4\},\quad\{2,4\},\quad\{5,7\}.
\]

The first sweep eliminates the initially odd class on turn 2. With no spare probes, the second class starts on turn 3, now on even vertices, and must sweep left to right to attain four turns. Always restarting from the same end instead takes five turns.

For the exceptional even-even case `n=12,m=4`, the schedule is

\[
 \{5,7,9,11\},\quad\{2,4,9,11\},\quad\{2,4,6,8\}.
\]

Turn 2 uses two probes to finish the first class and two to begin the second. It attains three turns, with no exceptional extra turn.

For `n=9,m=2`, the construction takes six turns. This provides the exceptional upper bound; it does not itself rule out five turns.

## 6. Independent attacks and remaining work

- A first attempted simplification swept both classes from the same fixed end. It failed, for example at `(8,2)` and `(16,4)`, by one turn. This was a failure of that proposed construction, not a counterexample to the historical result. The direction rule in §3 repairs precisely the endpoint loss.
- A preliminary four-candidate sweep checked both first parities and both second directions through `n<200`; all lengths matched the intended formula. That finite experiment led to the deterministic rule above. The final generator uses only explicit indices and arithmetic, not the experiment's minimization.
- The final indexed generator was independently replayed through `n=400`. Its verifier checks capture before movement, all probe counts and coordinates, and absence of redundant trailing turns. This avoids an isolated-vertex disappearance being mistaken for capture.
- The unbounded argument relies only on a parity-prefix neighborhood identity and elementary quotient/remainder algebra. It does not require the original twelve diagrams, a finite-state search, or a conjectured compression theorem for arbitrary strategies.
- A second reader should audit the exact time count and the distinction between a final inspection and a subsequent move. Lean formalization would naturally begin with the parity-prefix identity, then the indexed sweep invariant. The lower-bound proof remains separate and has not been verified by this note.

## 7. Kernel-checked arithmetic supplement

`../lean/PathUpperArithmetic.lean` now proves the even and odd transition-ceiling simplifications, canonical positive quotient/remainder coordinates, equivalence of the exceptional residue to the stated congruence, and the equality of the sweep's case count with the corrected ceiling formula for every `n>m>=2`. It also proves that the one-probe case count is `2n-4` for `n>=3`. Lean 4.33.1 accepted the file using only `Std`; printed theorem dependencies are only the standard `propext`, `Classical.choice`, and `Quot.sound`, with no `sorryAx`. The receipt is `path-upper-arithmetic-lean-check.json`.

This formalizes the arithmetic layer only. It does **not** assert that the indexed probes catch every walk; the parity-prefix graph invariant and its connection to the schedule still require Lean proofs. The ordinary mathematical proof above covers that layer, independently reviewed by the root agent without finding a substantive gap.

## 8. Direction and formalization audit, 12 September 2026

The complete path classification is now kernel checked in `PathClassification.lean`, including arbitrary actual walks and globally bounded probe schedules. The earlier status statements above describe the historical checkpoints of this note, not the final project status.

A fresh paper review found a reversed parity word in the new manuscript's second-sweep summary: on an even path the second sweep is reflected on an **odd** starting day, and is unreflected on an even starting day. Section 3 of this research note and the indexed generator already had the correct direction; they were rechecked against Lean's `PathSweep.full_oriented`. The manuscript was corrected. The explicit example `(n,m)=(8,2)` also diagnoses the direction: the second cohort starts on odd-numbered day three, occupies the even rooms, and must use the reflected odd frontier `A(n−1)`.

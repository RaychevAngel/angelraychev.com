# Odd-order Hamiltonian cross-sections with even longitudinal length

12 September 2026. Complete ordinary theorem accepted independently by
root and Euler. Euler's second audit is recorded in
`even-bridge-odd-cylinder-independent-review.md`. The geometric lemmas are in
`even-bridge-odd-cross-section-paired-columns.md`. The physical surgery
is the already independently reviewed one from
`even-bridge-eventual-periodicity.md`, with all changed parameters and
matching conventions verified below. No manuscript/site edit.

## Theorem

LetQ be a fixed bipartite graph with a Hamiltonian path andA=2b+1≥3
vertices. Fixm≥b+1 and putD=2m−A>0. There are effectively specified
positive integersN and an evenΔ such that

    T_m(Q×P_(n+Δ))=T_m(Q×P_n)+2AΔ/D

for every evenn≥N. The increment is integral. This theorem asserts an
eventual exact recurrence, not a small formula for its offsets or a
complete explicit classification of all finite boxes.

Write the even longitudinal length asn=2L and match columns2j and2j+1.
A cohort becomes anA×L array indexed byv∈V(Q) and paired-columnj.
Each cohort hash=AL rooms. Its directed contraction has bidirectional
Q-edges within a paired column and opposite one-way longitudinal flows
on the twoQ colors. It is strongly connected forL≥2.

## 1. A history bit gives the correct one-day charge

PutK=A². For each cohort definee_t∈{0,1} to be1 exactly when its previous
day's survivor was in the strict middle rangeK<r<h−K and had surplusb.
Sete_0=0. If the current before-inspection possible count isk_t, define
the raw rank

    R_t=2k_t+e_t.

The middle-surplus lemma gives surplus at leastb. It also proves that
two successive middle survivors cannot both have surplusb.

Herep always counts useful inspections of this cohort, namely inspected
rooms in its current possible set. Inspections elsewhere may be discarded
without changing the survivor set. Thusr=k−p exactly, and the two useful
daily shares still sum to at mostm.

If the current survivor is middle and has surplusb, thene_t=0 and
e_(t+1)=1. Withp actual inspections the raw rank loss is therefore

    2p−2b−1=2p−A.

If its surplus iss≥b+1, thene_(t+1)=0 ande_t≤1, so the raw loss is
at most2p−2(b+1)+1=2p−A. These statements concern actual arbitrary
survivor supports, with no normal-form assumption.

Let

    L0=2(K+m)+1,
    C=2h−2K−L0=2h−4K−2m−1,
    ψ_t=min(C,max(0,R_t−L0)),

and takeL large enough thatC>D. A survivor of size at mostK gives a
source rank at mostL0 and hence source potential0. A survivor of size
at leasth−K gives a next rank at least2h−2K and hence next potentialC,
using the longitudinal matching. Thus the two collars handle precisely
the cases excluded by the middle lemma, and in all cases

    ψ_t−ψ_(t+1)≤max(0,2p−A).

For daily sharesp+q≤m, the sum of these two positive-part bounds is at
mostD=2m−A. Equality requires allm inspections on one cohort: a genuine
split loses at leastA in the two positive terms or at least2 by reducing
the only positive share.

## 2. Bounded inefficient days and finite frontiers

Both full initial cohorts have potentialC. The proved cylinder-height
upper bound gives

    T≤2ceil(A(n+2)/D).

Usingn=2L and the integer ceiling inequality, an optimal strategy has

    DT−2C ≤ B := 8K+8m+2A.

Indeed DT≤2A(n+2)+2D−2, while2C=2An−8K−4m−2. Every day whose total
potential loss is less thanD consumes at least one unit of this integer
slack, so there are at mostB such days.

On an efficient day allm inspections belong to one owner. Its source
potential is positive and its successor potential is belowC. These
inequalities force its survivor strictly insideK<r<h−K. Equality of
the clipped loss withD then forces equality of the raw bound. The only
possibilities are

    surplusb,    e_before=0, e_after=1;
    surplusb+1,  e_before=1, e_after=0.

Every efficient owner survivor is therefore a bounded-width frontier.
For surplusb this is the minimum-surplus lemma. For surplusb+1, the
history bit says that the preceding survivor was a middleb-surplus
frontier; the current survivor is contained in its neighborhood, so the
separately proved bridge lemma applies. Its orientation is the same.

An untouched proper nonempty cohort grows by at least one room each
day, by strong connectivity of the contraction. Its history bit can
drop by at most1, so its raw rank increases by at least1. Consequently
an untouched cohort cannot have constant potential strictly between
the two clipping endpoints.

Exactly as in the even-order proof, an efficient run has at most two
owner blocks: after a cohort owns a day its potential is belowC, so it
can cease ownership during the run only at0 and cannot return active.
The low potential collar has at mostK+m possible rooms. A nonempty
untouched cohort leaves it withinL1=K+m+1 days. The high collar has
deficit at mostK and becomes full withinK days. A full or empty cohort
has history bit0.

Mark the inefficient days and the firstL1 days of every owner block
as nonclean. Their number is at most

    E=B+2L1(B+1).

Every remaining clean block has a single owner, a globally empty/full
mate, and an actual frontier before and after each inspection. The
history bit alternates, and the owner surpluses alternateb,b+1.

## 3. Exact frontier dynamics in paired-column coordinates

For a fixed orientation, write the occupied lengths of theA fibers as
l_v. Across aQ edge, the boundary-free color's length equals the other
length or exceeds it by1. There are at most2^(A−1) relative-length
patterns, as seen along a spanning tree. Their range is at mostA−1.

Neighborhood formation increases by1 the lengths on the color whose
longitudinal flow points toward the empty tail, leaving the other
lengths unchanged. At full quotam, for consecutive after-inspection
survivors of cardinalitiesr,r' and source surpluss,

    r'=r+s−m.

There is an important timing distinction: the constant-drift rank at
these survivor vertices is2r−e, rather than the before-inspection
rank2k+e. At a survivor vertex,e means the newly set bite_(t+1), which
records whether that very survivor has middle surplusb; it is not the
source day's bite_t. In both alternating cases,

    (2r−e)−(2r'−e')=D.

The ordinary average occupied length is nonincreasing and can stall
for one round whenm=b+1. The corrected average(2r−e)/(2A) decreases
by exactlyD/(2A) per edge and differs from the ordinary average by at
most1/(2A). Thus a marginv=A accommodates both the frontier width and
this correction. The reflected coordinates handle a right frontier.

A finite state consists of the relative-length pattern, orientation,
current cohort phase, and history bit. There are at most

    M=8·2^(A−1)

states. Paired-column translations need no additional parity bit:
one paired-column translation is two physical columns and preserves
the entire directed contraction. Extra transverseQ edges are local
within the pair and merely filter the finite patterns and transitions.

For a closed frontier walk of lengthl, the history and phase return.
The cardinality drop isDl/2, so its translation toward clearance is
Dl/(2A) paired columns. This is an integer for every actual closed walk,
andl is even. Choose

    l0=2A·lcm(1,...,M),
    δ=Dl0/(2A),          Δ=2δ=Dl0/A.

Thusδ is an integer number of pairs andΔ is an even number of physical
columns. The same disjoint-cycle argument as before shows that every
M²l0-edge clean walk permits deletion ofl0 edges and translationδ,
and anyM-edge walk permits insertion ofl0 edges and translationδ.

## 4. Protected paired bands and complete physical surgery

The protected-band construction of the accepted even-order proof applies
in paired-column coordinates with the following verified substitutions:

* array lengthL=n/2, transverse fiber countA;
* nonclean-day boundE as above;
* frontier width marginv=A;
* per-edge corrected average speedD/(2A);
* deleted widthδ paired columns and inserted/deleted timel0 per cohort.

For completeness, mark every initial frontier cut of each nonclean
block and every paired-column index of its actual inspections. There
are at mostF=(A+m)(E+1)+2 marked positions, including board ends. Enlarge
them by radiusρ=E+2A+m+2. Each nonclean block has length at mostE and
begins from a frontier plus an empty/full mate, or from the full initial
state. Movement reaches at most one paired column farther per day.
The longitudinal matching inside each pair preserves a locally full
cohort there, even thoughQ itself has odd order. Hence an unmarked
band remains locally full or empty throughout every nonclean block.

Choose an original unmarked gap of lengthW+2v+4 and trimv+2 at each
end, obtaining a retained bandJ of lengthW. Clean frontiers have the
strictly moving corrected average just described. Their rowwise wiggles
cannot enter the trimmed central band in a block whose endpoint status
is unchanged. A nonclean block cannot revert its status by finite-speed
propagation, and each active clean passage can only change full to empty.
Each cohort therefore crossesJ exactly once in one clean block. The
two owner crossings are temporally disjoint and their mates are globally
empty or full.

One explicit sufficient choice, writingH=M²l0+M, is

    W=2(δ+v+m+3)+ceil((D/(2A))(H+4))+2v+2m+10.

The corrected average advances byD/(2A) per edge, at mostm. Entry and
exit overshoots lose at most2m spatial units, and the marginv absorbs
both row offsets and the history correction. Thus each central crossing
contains at leastH edges, with its entire initial and final frontiers
on opposite sides of a centralδ-pair band and all intermediate fronts
more thanδ from the outer edges. A sufficient paired-length threshold
exceeds

    2+ceil((4K+2m+1+D)/(2A))
      +F(2ρ+1)+(F+1)(W+2v+4)+δ.

Now delete the centralδ pairs. Outside the two central crossings,
natural column deletion commutes with every transition: the protected
neighborhood is uniformly full/empty during nonclean days, no nonclean
inspection lies there, and clean frontiers elsewhere translate as whole
cut patterns with their filled tails. Inside each crossing, remove
disjoint closed subwalks of total lengthl0. For a left front its initial
translation shift is−δ and is reduced by the removed cycle displacements
until it becomes0. For a right front use the reflected cumulative shift.
The margins keep all translated patterns inside the shorter board.
These are translations of cuts and uniform tails, not claimed finite-path
automorphisms.

Every closed walk has even temporal length, and a paired-column shift
preserves physical phase. The empty/full mate is therefore unchanged
when its owner's crossing is shortened. The two edits do not interfere.
Endpoints are after-inspection survivor states, so deletingl0 edges
deletes exactlyl0 following inspection days. This gives

    T_m(Q×P_(n−Δ))≤T_m(Q×P_n)−2l0.

Conversely, start from an optimal strategy on the shorter sufficiently
long board. Insertδ pairs in its protected band and repeat a short
closed frontier subwalk to addl0 days to each crossing. The same
endpoint shifts, filled tails, phase preservation, and mate independence
give the reverse inequality. Thus equality holds. Its increment is
2l0=2AΔ/D, proving the theorem.

## 5. Consequence for transverse boxes

For a fixed transverse Cartesian boxQ, even|Q| is covered at all
longitudinal parities by the accepted even-order theorem. If|Q| is odd,
all its side lengths are odd: the previously proved odd-box cylinder
theorem covers odd longitudinal lengths, and the present theorem covers
even lengths. Take the least common multiple of their two even periods
and the larger threshold. This yields one eventual affine recurrence
valid on both parities. The singleton cross-section follows from the
already established exact path result.

Therefore every fixed transverse box and every fixed budget above half
its order have an eventual exact affine-periodic time function in the
remaining length, with slope2|Q|/(2m−|Q|). Lower fixed budgets are
eventually impossible by the already proved spanning-rectangle
feasibility theorem. This does not resolve the finite exception values,
the smallest period, or a simple closed minimum-time formula for every
arbitrary finite box.

# Independent semantic review of clipped pyramid erosion

13 September 2026. Socrates independently read the frozen
`lean/ClippedPyramidErosion.lean`; no source edits or repeated kernel build.

**Verdict: PASS for the stated physical inclusion and cardinality scope.**

The height convention `s-2+2k` and the count operation (subtract one only
from a nonempty parity-zero fiber) represent the ordinary clipped erosion.
`height_clipped` is the exact maximum with the opposite empty-fiber height.
`actual_below_original` correctly discards that negative virtual branch
for an actual nonnegative room. This is the key step preventing an empty
fiber from being mistaken for an admissible room.

`neighbor_in_original` quantifies over actual pairs `(v,y)` and all valid
longitudinal or transverse cylinder edges, including the finite top and
bottom boundaries. The bit condition forces the target color; the height
condition forces actual membership in the original support. Its one-sided
edge hypothesis suffices in the direction used. Symmetry or connectedness
need not be imposed for this local inclusion theorem.

`eroded_edge` separately supplies preserved adjacent height differences.
`eroded_fits` preserves the finite top cutoff. The room-list theorems prove
membership equivalence with actual cells under the fitting-cutoff guard,
unique enumeration for a list of distinct transverse vertices, and exact
cardinality loss. To interpret this as a whole finite graph, that list is
taken to enumerate its vertices; no unsupported set-cardinality shortcut
is being used.

`exact_loss` counts only occupied parity-zero roots. `root_loss` and
`room_cardinality_loss` explicitly assume every such root is occupied;
they permit empty fibers of the other parity. The graph-distance bound
which ensures that assumption, prescribed-size ideal enlargement, and
the subsequent complete search strategy are not asserted by this module.
The file's opening scope statement correctly distinguishes these ordinary
parts. The maximal erosion's extra top-cap room from the newer proposition
is also not part of this clipped-erosion module.

This is a semantic audit, not an independent compilation receipt. The
author's separate source-specific kernel receipt supplies compilation and
axiom checking.

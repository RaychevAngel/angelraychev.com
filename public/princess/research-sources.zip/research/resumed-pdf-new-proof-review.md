# Final PDF review of the new rectangle proofs

Date: 2026-09-13. Reviewer: split_manuscripts.

## Artifact and scope

- Reviewed PDF: `paper/main.pdf`.
- SHA-256: `aaaf9fdefab96e5dff620d989ac16fff0969e6d612d340bae59662ee57f01b4f`.
- PDF metadata: 134 pages, letter paper, PDF 1.7, produced by pdfTeX-1.40.28 at 07:03:17 PDT.
- Complete pages visually inspected: **45–67, 74–75, 102–103** (27 pages total; printed page numbers agree with PDF page indices).
- Rendering: fresh Poppler `pdftoppm` PNG output at **135 dpi**, 1148 × 1485 pixels per full page. Every listed page was viewed individually at readable resolution; no contact-sheet-only review.
- Fresh review images: `tmp/pdfs/resumed-new-proof-qa/main-NNN.png`. Older review images were not used.
- This was read-only PDF review, not PDF authoring. No manuscript or PDF was edited by the reviewer.

## Visual result

No clipped or overlapping text, missing mathematical glyphs, broken equation layouts, cropped diagrams, or unreadable paths were found on the inspected pages. Long file paths on page 66 wrap within the text margins. The numbered capacity formulas, critical-case displays, merger inequalities and proof-end boxes are complete and readable.

Specific content checks:

- Pages 45–52: finite corner capacities and both critical parities are legible; the erosion profile preserves the stated odd-width-only critical scope.
- Pages 53–55: the pronic theorem visibly retains all three values of the critical corner allowance; the near-pronic dual rule includes the strict lower hole-band endpoint and the complete `(1,2,1)` feature conclusion.
- Page 56: Figure 4's two 11 × 12 boards, orange and blue supports, gray neighborhood, circled obstruction, titles and captions are clear. Its separate float page is complete, and the caption distinguishes the arbitrary-support theorem from the illustrated prefixes.
- Pages 57–58: the new near-square obstruction and its full-board transfer are readable. Corollary 11.19 explicitly states **206 ≤ T_13(24,24) ≤ 207** and explains the extra joint equality argument rather than merely doubling a solo lower bound.
- Pages 59–65: base and enriched merger statements, the discarded positive feature lower bounds, reduced-surplus closure, flag inheritance and static near-pronic rule are visible and accurately scoped. The ordinary-proof versus physical-attainment distinction remains explicit.
- Pages 65–67: all six finite exact values are correctly typeset, the 11-row residual test reads `2 · 4 > 6`, the large-square interval is **206–207**, and the certificate subsection explicitly disclaims new Lean formalization and a uniform fixed-size numerical formula.
- Pages 74–75: transport conditions, virtual-height proof and boundary-credit formulas fit their text blocks; the construction is presented as a sufficient physical strategy.
- Pages 102–103: the even-length minimum-budget expression is labeled an upper bound, and the open fixed-size evaluation of the width constant remains explicit. The displayed oriented prefix profiles and inverse-clock calculation render correctly.

## One editorial issue reported to the parent

On page 103, the opening of Section 22.1 says “including the three-dimensional cylinder below.” The source is `paper/sections/odd-affine-insertion.tex:8`. If this application is in the parked companion, “below” is stale after scope separation. The parent was notified with a suggested companion reference. The reviewer did not change it.

## Limits

This check covers the listed new-proof pages, not the remaining pages, cover, table of contents, all hyperlinks, source-package reproducibility, or companion PDF. The parent owns those checks. It is visual/source-boundary QA, not an additional formal verification or a fresh proof of every mathematical claim. Any rebuilt PDF has a new hash and requires at least a focused recheck of changed pages.

## Editorial correction and final rebuild

The parent corrected the stale page-103 reference to “independent applications are retained in the companion.” The rebuilt `paper/main.pdf` has SHA-256 **`a070378c49ec580378751b05c49782dd3f6e0abe884cc3baf2a027407a03f5c0`** and still has 134 pages.

The previous exact reviewed PDF was recovered from the release staging directory and matched the original `aaaf9f...` hash before comparison. All 134 pages were compared using both layout-preserving extracted text and decoded page content streams. **Only page 103 changed**; the other 133 pages have identical layout text and identical decoded content streams. No cross-page reflow occurred.

Page 103 was freshly re-rendered at 135 dpi and visually inspected. The replacement sentence occupies the same paragraph, the following definitions and numbered equations remain intact, and there are no clipping, overlap or glyph defects. The editorial issue is resolved. The comparison record is `tmp/pdfs/resumed-new-proof-qa/rebuilt/page-comparison.json`.

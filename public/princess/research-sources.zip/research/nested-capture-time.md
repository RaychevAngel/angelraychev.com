# Capture time on bipartite graphs with isoperimetric nesting

Research derivation, 11 September 2026 Pacific. The abstract reduction below
has received an independent mathematical attack without a gap being found.
It is not yet a Lean theorem and its novelty has not been established.
The initial attempt to apply it to every rectangular grid **failed**.

## Model and hypothesis

Let G be a finite bipartite graph with parts E and O and no isolated
vertices. The invisible target starts at any vertex. Each round, at most m
vertices are inspected simultaneously; after a miss the target must move
along exactly one edge. A strategy must guarantee capture within a fixed
finite number of rounds. Since every observation before capture is the same
miss, a deterministic strategy is a fixed inspection sequence until capture.

For 0≤k≤|E|, define

    g_E(k) = min {|N(S)| : S⊆E, |S|=k},

and analogously g_O. Both functions are nondecreasing: any set of k+1
vertices contains a k-set, whose neighborhood is no larger. Also g_E(0)
and g_O(0) are zero.

Assume there are nested families I_E(k) and I_O(k), of their indicated
cardinalities, such that for every k

    N(I_E(k)) = I_O(g_E(k)),
    N(I_O(k)) = I_E(g_O(k)).

These are exactly the two conditions of isoperimetric nesting in
Bolkema–Groothuis, Definition 14. Merely having nested neighborhoods of
prefixes is insufficient: the prefixes must also minimize neighborhood size
among **all** sets of the same size.

## Exact time reduction

Consider states (a,b) with 0≤a≤|E| and 0≤b≤|O|, starting at (|E|,|O|).
A state is terminal before inspection when a+b≤m: inspect all remaining
possible vertices that round. Otherwise choose nonnegative p,q with
p+q=m and make the transition

    (a,b) → (g_O(max(b−q,0)), g_E(max(a−p,0))).

An allocation may exceed the number of remaining vertices of its color;
only the useful part is inspected. Thus the actual shot budget is at most m.

**Theorem.** The optimal guaranteed capture time is one plus the shortest
number of transitions from the initial state to a terminal state. If no
terminal state is reachable, no finite guaranteed capture strategy exists.

**Lower-bound direction.** Take any arbitrary successful inspection
sequence. Let A_t⊆E and B_t⊆O be its beliefs before round t. Suppose a
compressed state satisfies a_t≤|A_t| and b_t≤|B_t|. Allocate to the
compressed process the same number of inspections in each color as the
arbitrary sequence does; unused budget can be assigned to either color.
The arbitrary survivors in E have at least max(a_t−p,0) vertices, and
those in O at least max(b_t−q,0). The minimum-neighborhood inequality and
monotonicity of g give

    |A_(t+1)| ≥ g_O(max(b_t−q,0)),
    |B_(t+1)| ≥ g_E(max(a_t−p,0)).

Coordinatewise domination therefore persists from the initial equality.
If the arbitrary strategy captures on round T, its preceding belief has
size at most m, so the compressed state is terminal by round T. This
argument imposes no monotonicity, sweep geometry, or no-regrowth condition
on the arbitrary strategy.

**Upper-bound direction.** Realize (a,b) as the actual belief
I_E(a)∪I_O(b). Inspect the last min(p,a) vertices in the E prefix and the
last min(q,b) in the O prefix. The survivors are the smaller prefixes.
The two nesting identities make their neighborhoods exactly the next
state's two prefixes. The color classes are disjoint, so these inspections
can be made simultaneously with the stated budget. Induction realizes
every counter path as a legal room strategy, including the terminal
inspection. This proves both directions.

There are (|E|+1)(|O|+1) states and m+1 allocation choices at each state.
With the two profiles available, breadth-first search uses
O((m+1)(|E|+1)(|O|+1)) time and O((|E|+1)(|O|+1)) state storage. This is
a polynomial bound in the number of graph vertices. For a d-dimensional
hypercube, the number of vertices itself is 2^d; this is **not** a
polynomial-time bound in d.

## Application that survives: hypercubes

[Bolkema–Groothuis, *Hunting Rabbits on the Hypercube*](https://arxiv.org/pdf/1701.08726),
Theorem 35, establishes both nesting conditions for every Q_d using
weightlex order separately on the two parities. Within a weight, the set
containing the first differing coordinate comes first (Definitions 19–21).
The cardinality profiles can be obtained from those explicit prefixes.

Therefore the theorem above supplies an exact algorithm and an explicit
optimal strategy for **every hypercube dimension and every probe budget**,
conditional only on this cited, established nesting theorem. It is an
algorithmic classification, not a closed-form capture-time formula.
Its novelty relative to prior work remains to be checked.

The implementation checks every subset in each parity through Q_5,
confirming minimum-neighborhood profiles independently of the cited proof.
It also checks prefix compatibility through Q_6 and replays every computed
schedule on the actual graph. At the known minimum feasible budgets, it
gives:

| Graph | Minimum feasible probes | Optimal rounds from the exact reduction |
|---|---:|---:|
| Q_2 | 2 | 2 |
| Q_3 | 3 | 4 |
| Q_4 | 5 | 8 |
| Q_5 | 8 | 12 |
| Q_6 | 14 | 20 |

The general hunting-number formula is already due to Bolkema–Groothuis;
these computations do not claim it as new. The Q_3 result also agrees with
unrestricted belief-state search. Larger computed optimal times rely on
the proved reduction rather than an exponential unrestricted search.

## A second application: odd squares

Every square P_s□P_s with odd s≥3 also has genuine diagonal nesting.
This follows from the precise two-order square-grid theorem of
Abramovskaya et al. (2016): for odd s, a reflection preserves the majority
parity and interchanges the two candidate orders, so their neighborhood
profiles agree and one order minimizes at every size. Its prefix
neighborhoods are prefixes. Complement duality and central rotation then
transfer minimum-neighborhood optimality to the other parity.

The full derivation is in `grid-nesting-source-audit.md`, Section 4; a fresh
independent check is in `odd-square-independent-review.md`. Both have
checked the primary theorem's precise order conventions. Thus the exact
time algorithm also applies to **every odd square and every probe budget**.
No full Lean verification or novelty claim is made here. Odd nonsquare
rectangles remain outside this proved application despite passing several
small exhaustive tests.

## Failed application: all rectangular grids

The cited paper's discussion following Definition 14 attributes nesting to
the earlier grid argument. A literal application of this blanket statement
is unsafe. The original 2016 grid paper proves a minimum over **two**
geometric orders in its square-grid isoperimetric theorem, and gives an
example where which order is better changes with cardinality. See the
separate primary-source audit for the exact scope and quotations.

Independent checks give a smaller explicit failure. On coordinates
0≤x<4, 0≤y<3, order each parity by increasing (x+y,x). Its neighborhoods
are indeed prefixes. However, the first odd vertex is (0,1), with three
neighbors, whereas the odd corner (3,0) has only two. The first odd prefix
therefore fails isoperimetry. The resulting ordered-strategy time for two
probes is 17, whereas unrestricted search and an independently replayed
witness attain 16. The analogous discrepancy for 3×6 is 29 versus 28.

Thus the ordered-prefix algorithm on general rectangles currently gives
upper bounds only. Replacing its profiles by the true one-step minima
without compatible minimizing sets also fails: shapes favorable on one
day need not lead to favorable shapes the next day. A cardinality-only
lower bound must not be presented as an attainable strategy.

## Reproducibility and unresolved issues

- `src/nested_grid_time.py` constructs neighborhoods directly, computes
  profiles, tests all parity subsets on bounded small graphs, and replays
  all prefix schedules. The word `minimum_turns` in its internal solver
  refers to the chosen prefix process; on grids lacking isoperimetry it
  is only an upper bound for the unrestricted game.
- `research/nested-grid-time-checks.json` records 190 rectangle nesting
  checks, the explicitly failed isoperimetry checks, 45 comparisons to
  prior unrestricted BFS cases, and the hypercube computations.
- The first hypercube test used ascending binary tuples, which is the wrong
  convention for the paper's weightlex order. That test failed and the
  convention was corrected from the primary definition. This was an
  implementation error, not a counterexample to the hypercube theorem.
- An independent proof review accepted the abstract domination argument,
  including clipped allocations and the capture-before-movement terminal
  condition. No full Lean graph theorem is claimed.
- Investigate which other grid subclasses have genuine nesting, or which
  additional state descriptors suffice when nesting fails. Do not infer a
  full rectangular-grid classification from this conditional theorem.

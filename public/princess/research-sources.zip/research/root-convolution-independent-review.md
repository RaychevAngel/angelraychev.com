# Independent review of RootConvolution.lean

12 September 2026. Reviewer: three_row_all_budgets, independently of the
root agent who formalized the theorem.

Read the complete file `lean/RootConvolution.lean`. The semantic audit
passes. `q` is the least pronic-capacity root and `R` the least square
root, via internally defined total recursive functions and the exact
capacity iff theorems. The recursion handles zero without an external
oracle or finiteness assumption. `extreme_capacity` treats both relative
root cases and preserves the allowed minimum allocations.

The left candidate is min(u,q(l)(q(l)+1)); the right candidate is
max(l,S−R(S−u)^2), with natural subtraction. Membership is proved under
0≤l≤u≤S, and natural clipping is the intended integer interval behavior.
`two_candidate_lower` has the correct inequality direction for every
interval point. `exact_minimum` supplies an actual interval minimizer
at a candidate, rather than merely comparing two upper bounds.

The formal theorem agrees with the independently derived ordinary proof
in `supersession-odd-midpoint.md` §5. Applying it to the proper and
reflected inverse-profile branch convolutions remains an ordinary proof.
Neither the Lean file nor this review establishes scalar midpoint
necessity or a new geometric compression assertion. Root supplied the
fresh successful compilation receipt; this review did not repeat it.

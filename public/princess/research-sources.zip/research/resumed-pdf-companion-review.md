# Parked companion PDF review — 13 September 2026

**Result: PASS.** This is a read-only layout and source-preservation review of
`paper/extensions.pdf`, not a new mathematical audit or Lean compilation.

- Reviewed PDF SHA-256:
  `496773b970819c84c95d1e783d74bdc502a4127ce011ea171ad3a430aa253893`.
- PDF size: 480,110 bytes; 30 US-letter pages; PDF 1.7.
- All 30 pages were freshly rendered with Poppler `pdftoppm` at 90 dpi and
  visually inspected in 15 adjacent-page pairs. Pages 22 and 30 were also
  rendered at 144 dpi and inspected individually, to check the dense inspection
  schedule, formalization boundary, acknowledgments, and wrapped references.
- Rendered evidence:
  `tmp/pdfs/resumed-companion-qa-496773b9/`; complete text extraction:
  `tmp/pdfs/resumed-companion-qa-496773b9/text.txt`.
- The PDF hash was checked again after the review and was unchanged. No PDF or
  manuscript source was edited during this review.

## Visual findings

The title page, contents, all proof pages, both figures, finite classification
tables, explicit inspection schedules, and references render without clipping,
overlapping text, missing mathematical glyphs, or illegible labels. Both figure
captions fit normally. The compact schedule on page 22 is readable at the
expanded inspection size. Long URLs on page 30 wrap within the text block.
Ordinary theorem and proof continuations across pages remain readable.

No layout changes are requested. The separate contents page has deliberate
whitespace; it is not a missing-content page.

## Preservation and compilation checks

`publication/manuscript-scope.json` lists 16 companion source files. All 16
match its current source hashes, and all 16 appear in the final compiler log.
The entrypoint and all 14 included section files are byte-for-byte unchanged
from the preserved split-source hashes. The sole changed file is the shared
`paper/preamble.tex`, which contains the formatting changes used by both PDFs.
In particular, `paper/extensions.tex` is unchanged, so no section inclusion was
removed. Every companion label declared by the scope manifest is present in
the compiled auxiliary file.

The 30-page output therefore preserves the canonical companion content; the
change from the earlier 31-page output is pagination, not removed results or
proofs. This conclusion uses the unchanged source inclusion tree and hashes,
the final compiler log, and inspection of the rendered pages, rather than page
count alone.

The final `paper/extensions.log` contains no warning, overfull/underfull box,
undefined-reference, or multiply-defined-reference reports. Extracted text
contains no `??` references or replacement characters. The square characters
in extraction are the normal proof-end symbols and Cartesian-product notation,
which were checked visually. As an additional geometry check, every extracted
text line stays within conservative page bounds of 54–558 horizontal points
and 45–775 vertical points. The PDF contains 33 external-link annotations.

The formalization and attribution boundaries remain explicit on pages 29–30:
the companion is parked; the existing Lean receipt is preserved; general
ordinary proofs are not described as complete physical-game Lean proofs; and
the author's original work, Rusev's contribution, Dimitrov's mentorship, and
subsequent Astra 6 assistance remain acknowledged.

## Final rebuild comparison

The final publication rebuild regenerated the companion PDF after a main-only
wording correction. Its final SHA-256 is
`b80b8dfad0b9cd65c5cc06e0fb1af21bb8f3287e66069a988a1f780fd2466879`;
it remains 480,110 bytes and 30 pages.

All 30 final pages were freshly rendered using the identical Poppler command
and 90 dpi setting. Each final page was compared pixel-for-pixel against the
corresponding previously inspected page, checking image mode, dimensions, and
the complete pixel difference. **All 30 pages are identical; no page differs.**
The visual review above therefore applies unchanged to the final PDF. No
companion source changes were made for this rebuild.

The final render and per-page comparison receipt are stored at
`tmp/pdfs/resumed-companion-qa-b80b8dfa/`, with
`comparison.json` recording both PDF hashes and all 30 image comparisons.

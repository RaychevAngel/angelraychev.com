# Exact spatial transfer and eventual formulas at a fixed capture horizon

Derived 12 September 2026. Status: ordinary theorem with a complete proof,
independent review, and 56 exact small-case comparisons. The generic
survivor-envelope equivalence and local product costs are checked in Lean.
The semilinearity and eventual-affine deductions remain ordinary proofs.
This is a different parameter regime from fixed-budget eventual capture time.
No novelty claim is made before a focused literature comparison.

Let Q be any nonempty finite simple graph with A vertices. For n>=2 and
T>=1, let b_T(n) be the least daily inspection budget that guarantees capture
within T days on Q square P_n. The target must move one edge after every
unsuccessful inspection. No bipartiteness hypothesis on Q is needed here.

**Theorem.** For fixed Q and T:

1. There is an explicit finite transfer matrix, independent of n, whose
   multivariate weights encode exactly which daily budget vectors permit
   capture in T days.
2. The function b_T(n) is effectively Presburger-definable. An algorithm
   computes a finite exceptional table and an eventual formula
   b_T(n) = A n/T + c_(n mod p), with rational constants c_r and a positive
   period p divisible by T/gcd(A,T).
3. In particular b_T(n+p)=b_T(n)+A p/T for all sufficiently large n.

The matrix may have 2^(2A(T-1)) states. These assertions do not imply a small
matrix when T or the transverse size varies, nor a complete fixed-budget
capture-time formula for arbitrary boxes.

## 1. Local survivor columns

For T>=2 define an alphabet W=(2^V(Q))^(T-1). A letter b is a vector
(b_1,...,b_(T-1)) of subsets of Q. Write b_T=empty, and write 0 for the
letter with every entry empty. A word b^1...b^n specifies a proposed
survivor envelope for each column and each day. Use boundary letters
b^0=b^(n+1)=0.

For a triple (a,b,c) of letters, define its T-dimensional cost vector:

    w_1(a,b,c) = A - |b_1|,
    w_t(a,b,c) = |(N_Q(b_(t-1)) union a_(t-1) union c_(t-1)) minus b_t|,
                 2 <= t <= T.

All costs are nonnegative integers at most A. The word's day-t cost is
the sum over columns j of w_t(b^(j-1),b^j,b^(j+1)).

**Lemma.** A T-day inspection sequence with capacities (m_1,...,m_T) exists
if and only if some word has each day-t cost at most m_t.

**Soundness.** For each t, let R_t be the union of the proposed survivors
in all columns, and put R_T=empty. Define B_1=V(Q square P_n) and
B_t=N(R_(t-1)) for t>=2. Inspect S_t=B_t minus R_t. Its size is exactly
the stated local cost sum: the neighborhood in column j is the union of
the Q-neighborhood in that column and the survivor sets in the adjacent
columns. The actual belief U_1 equals B_1. If U_t is contained in B_t,
then the actual survivors U_t minus S_t are contained in R_t. Their next
neighborhood is therefore contained in B_(t+1). Induction proves this
inclusion on every day. On day T, S_T=B_T captures all actual possibilities.

It is intentional that R_t need not be contained in B_t. Extra envelope
vertices are harmless: they may enlarge later costs, but they cannot
invalidate the inclusion argument. This avoids an unnecessary local
consistency constraint.

**Completeness.** From an actual successful sequence, discard inspections
outside the current belief. Its actual survivor sets R_t satisfy R_T=empty
(extend an earlier capture with empty sets and empty shots). Taking their
column sections gives a word whose costs are precisely the useful daily
inspection counts. They do not exceed the capacities. QED.

For T=1 the result is immediate: b_1(n)=An. Equivalently use a one-state
matrix with edge weight x_1^A.

## 2. A genuine matrix independent of the box length

Use ordered pairs (a,b) in W^2 as states. For every c in W, put a directed
edge (a,b)->(b,c) of monomial weight

    x_1^w_1(a,b,c) ... x_T^w_T(a,b,c).

Let M(x) be this matrix. Initial states are (0,b), with weight one;
terminal states are (b,0), also with weight one. If their indicator
vectors are u and v, then

    F_n(x) = u^transpose M(x)^n v.

Every length-n walk between these boundary states corresponds to exactly
one n-column word, with b^0=b^(n+1)=0. Conversely each word gives that walk.
Thus F_n has a positive coefficient at x^c precisely when a certificate
with exact cost vector c exists. Capturability under m_t is equivalent
to a positive coefficient at some c with 0<=c_t<=m_t for every t.

The generating function over longitudinal length is the formal rational
series u^transpose (I-zM(x))^(-1) v. Possible coefficient multiplicities
count different envelopes and have no effect on the existential criterion.
All coefficients are nonnegative, so cancellation cannot create a false
capture certificate.

For given n and m, another implementation tracks the accumulated T-vector,
discarding a state once a coordinate exceeds m. For fixed Q,T this costs
O(n |W|^3 (m+1)^T) elementary transitions before sparse reductions. Since
an optimum never needs m>An, this is polynomial in n for fixed Q,T.
The exponent and constant depend strongly on T and A.

## 3. Semilinearity and exact budget optimization

Add a length coordinate one to each transition weight. The set L of all
attainable (n,c_1,...,c_T) is effectively semilinear. One elementary route
is to eliminate the finite automaton's states to obtain a regular
expression, and take its additive image. Finite sets, union and Minkowski
sum preserve semilinearity. Additive closure does too: if

    S = union_i (b_i + monoid(P_i)),

then S* is the union, over subsets I of component indices, of

    sum_(i in I) b_i + monoid({b_i : i in I} union union_(i in I) P_i).

The empty subset supplies zero. For a nonempty I, the initial b_i supplies
one occurrence of each used component; additional base terms account for
additional occurrences, and all period terms can be placed in one of
those occurrences. This proves both containments and makes the conversion
effective. Therefore no general context-free-language theorem is needed
for this regular-language step.

By the classical effective equivalence of semilinear and Presburger sets,
the relation

    E(n,m) iff n>=2 and exists c: (n,c) in L and c_t<=m for every t

is effectively Presburger-definable. The graph of its least feasible
budget is

    E(n,m) and (m=0 or not E(n,m-1)).

There is always some feasible m, because An inspections capture immediately.
Converting this graph back to a finite union of linear sets is effective.
The Boolean closure, projection and effective equivalence used here are
Theorems 1.1 and 1.3 of Ginsburg and Spanier (1966), pp.287-288:
https://msp.org/pjm/1966/16-2/pjm-v16-n2-p09-s.pdf

## 4. Why a semilinear function is eventually affine on residue classes

Consider a linear component of the graph of b_T:

    (n_0,m_0) + monoid((a_1,d_1),...,(a_s,d_s)).

A nonzero generator cannot have a_i=0, because that would give two values
of the function at the same n. If a_i,a_j>0, applying the i-th generator
a_j times and the j-th generator a_i times produces the same n; hence
a_j d_i=a_i d_j. All generators in that component have a common rational
slope. The whole component therefore lies on a rational affine line.

The projection of an infinite component is n_0 plus a finitely generated
additive monoid of positive integers. It eventually contains exactly the
integers in its gcd residue class. This elementary numerical-semigroup
fact is effective, for instance by shortest paths over residues modulo
one generator. Finite components contribute only finitely many exceptions.
Taking a common multiple of the finitely many gcd periods and a maximum
of the thresholds proves eventual affinity in every residue class.

The following bounds identify every slope, rather than leave an unknown
collection of different rational slopes.

## 5. The slope is exactly A/T

**Lower bound.** Along the longitudinal direction choose the disjoint
matching edges joining columns (1,2),(3,4), and so on, in each Q-fiber.
There are A floor(n/2) edges. On each edge there are two trajectories that
alternate forever, one from either endpoint. At each day all these
2A floor(n/2) trajectories occupy distinct rooms. A set of m inspections
can intercept at most m of them on that day. A T-day winning schedule
must intercept every trajectory, so

    T b_T(n) >= 2A floor(n/2) >= A(n-1).

**Upper bound.** Put q=ceil(n/T). Suppose the possible rooms before a day
lie in a suffix of columns beginning at L. Inspect the first q+1 columns
of that suffix, clipped to the actual board. Survivors begin at L+q+1,
and a move can retreat by at most one column, so the following belief
begins at least at L+q. After T-1 such days, at most
n-(T-1)q<=q columns remain. Inspect all of them on day T. Thus

    b_T(n) <= A(ceil(n/T)+1) < An/T+2A.

If capture happens earlier, extend the schedule with empty inspections.
Internal Q edges never change the column index, so this proof does not
require bipartiteness or any special geometry of Q.

Together the bounds give b_T(n)=An/T+O_Q,T(1). Every infinite affine
component found above must have slope A/T. Consequently the eventual
formula has precisely the stated form. Enlarge its period, if necessary,
by T/gcd(A,T), making the integer increment Ap/T explicit. QED.

## 6. What this adds, and what remains open

The transfer matrix is genuinely fixed as length varies. It records a
whole T-day column history rather than assuming a geometric sweep. It
therefore covers even and odd side lengths without a nesting hypothesis,
and permits unrestricted nonmonotone strategies.

This gives complete effective finite-plus-periodic expressions for the
inverse tradeoff at every fixed Q,T, with a universal leading coefficient.
The elementary algorithm can also recover physical inspection schedules.
It does not yet provide small periods, compact offsets, or a uniform
closed form in T and all side lengths. A fixed-budget problem lets T
grow with n; this construction's alphabet then grows too. Those are real
remaining research issues, not supplied by the semilinearity argument.

Further useful reference: Kevin Woods, *Presburger arithmetic, rational
generating functions, and quasi-polynomials*, Journal of Symbolic Logic80
(2015),433-449, https://www2.oberlin.edu/faculty/kwoods/research/Presburger_full.pdf.
The proof above only needs the older effective semilinearity equivalence;
it does not require a parametric Presburger theorem with growing coefficients.

# Independent review: the asymptotic time slope for every Hamiltonian cylinder

12 September2026. Root proposed the argument; this is an independent
reconstruction and attack. **Pass: no mathematical correction required.**
The conclusion concerns a fixed transverse graph and a fixed feasible
daily budget as the longitudinal length grows. It does not assert exact
offsets, a short recurrence, or eventual periodicity for mixed boxes.

## Directed contraction of an even-width rectangle

OnP_(2b)×P_n, match short-axis rows2i and2i+1. For either checkerboard
color, identify each room and its matched neighbor with(i,j),
0≤i<b,0≤j<n. A grid edge followed by inverse matching induces a directed
graphD containing loops, bidirectional horizontal edges, and vertical
rungs all directed upward in one column parity and downward in the
other. The direction reverses when the starting color reverses; the
argument below is unchanged.

For a supportR in this contracted color, its matched ordinary open
neighborhood is preciselyR together with its directed outside boundary.
The loops supplied by the matching ensure this identity, so the
neighborhood surplus is exactly the number of outside boundary vertices.

## The SCC dichotomy

Suppose the outside boundaryB has sizes<b. ThenR is outgoing-closed in
D−B. Since onlys vertices were deleted, some row has no deletions at all;
its horizontal bidirectional path belongs to one strongly connected
componentC. Every pair of adjacent entirely undeleted columns is itself
strongly connected: its vertical directions are opposite, and horizontal
edges permit switching columns before moving in either vertical direction.
That whole pair therefore belongs toC, since it intersects the intact row.

There are at mosts columns containing a deletion. An entirely undeleted
column not belonging to an adjacent undeleted pair is isolated among
the clean columns. At mosts+1 such columns occur, including the two path
ends. Thus all vertices outsideC, even if deleted vertices are included
in the count, lie in at most2s+1 columns. Their number is at most

    b(2s+1) ≤ b(2b−1) < 2b².

This argument also handlesn=1: its one clean column may be isolated,
and the bound is merely vacuous for middle-sized supports.

BecauseR is outgoing-closed inD−B, either it contains every vertex of
the strongly connected componentC or none of them. WithK=2b², this gives

    |R|≤K  or  bn−|R|≤K.

Counting the deleted vertices in the exceptional set is essential to
the second inequality; the preceding column bound explicitly did so.
Contrapositively, every support withK<|R|<bn−K has surplus at leastb.

## A potential for arbitrary inspections

Puth=bn and fixm>b. Define

    C=max(0,h−2K−m),
    ψ(k)=min(C,max(0,k−K−m)).

Suppose a cohort hask possible rooms, at mostp≤m are inspected, r remain,
andk' is the following possible count. The matching always givesk'≥r.

* Ifr≤K, thenk≤K+p≤K+m, soψ(k)=0.
* Ifr≥h−K, thenk'≥h−K, soψ(k')=C.
* IfK<r<h−K, the dichotomy givesk'≥r+b≥k−p+b. Monotonicity and the
  unit Lipschitz bound ofψ implyψ(k)−ψ(k')≤max(0,p−b).

The first two cases also satisfy the same bound. They include the two
threshold equalities, so no endpoint surplus claim is needed. IfC=0
all statements are automatic.

For the two cohorts with daily sharesp+q≤m,

    max(0,p−b)+max(0,q−b)≤m−b.

Their initial total potential is2C and their final total potential is0.
The last inspection can be followed by the neighborhood of the empty
set, so it obeys the same accounting. Therefore

    T_m(P_(2b)×P_n) ≥ 2 max(0,bn−4b²−m)/(m−b).

This is a lower bound for arbitrary physical supports and strategies;
it assumes no corner, prefix, interval, or monotone normal form.

## Transfer to general transverse graphs

LetQ be a fixed finite bipartite graph with a Hamiltonian path andA
vertices. Its spanning path givesP_A×P_n as a spanning subgraph of
Q×P_n. An evader may restrict itself to those edges, so every strategy
onQ×P_n must satisfy the rectangle lower bound.

IfA=2b, the bound just proved has leading term

    2An/(2m−A).

The existing cylinder-height strategy has the same upper leading term.
For completeness, letD be the diameter ofQ andd=2m−A>0. Initial virtual
heights sum to at mostA(n−1); their range stays at mostD. Each day lowers
their sum byd. Once the sum is below−AD, all heights are negative and
that cohort is clear. Thus two successive cohort sweeps use at most

    2(floor(A(n−1+D)/d)+1)

days, a valid upper bound with the same leading coefficient.

IfA is odd, apply the already proved all-odd rectangle lower bound to
P_A×P_n whenn is odd and toP_A×P_(n−1) whenn is even. Changing length by
one affects the leading expression by a fixed constant. The same height
upper is available for either longitudinal parity. The singletonA=1
case follows from the already established path result.

Hence, for every fixed suchQ and integer budgetm>A/2,

    T_m(Q×P_n)=2An/(2m−A)+O_(Q,m)(1),   n→∞,

with no parity restriction onn or on the side lengths of a transverse
boxQ. A transverse Cartesian box is bipartite and has a serpentine
Hamiltonian path, so every box cylinder is covered.

For fixedm≤A/2, the spanning-rectangle feasibility threshold instead
shows eventual impossibility. Thus the denominator condition is the
correct eventual-feasibility regime, not an arbitrary restriction.

The review required no expensive computation. The only previous theorem
needed for the oddA lower bound is the already independently reviewed
odd-width rectangle asymptotic result; the evenA lower is supplied in
full above.

# Independent audit: simultaneous current and outgoing corner omissions

13 September 2026. Euler review of `maturation-even-transitions.md`,
Section 10. **PASS as ordinary static mathematics.** The theorem is not a
normal form for arbitrary intermediate beliefs and does not by itself
prove that its extremizers compose in a search strategy.

## Physical interpretation and statement

In width `2b`, physical source color zero, the omitted source cells are

    (0,0), (2b−2,0), (2b−1,1).

The last two are exactly the neighbors of the opposite bottom corner
`(2b−1,0)`. Thus the restriction is precisely current favorable corner
absent and next favorable corner absent. For `b≥2`, the accepted capacity
at integer surplus `s` is

    C₂(s),                                      0≤s≤b,
    max(b(b+1)/2,b²−2),                         s=b+1,
    unbounded,                                  s≥b+2.

The source graph remains the entire half-strip. Width two is correctly
separate: translated width-two pyramids already give unbounded capacity
at surplus two. In that width the first two listed forbidden source cells
coincide, so the three-cell deletion proof must not be applied literally.

## Boundary-free row and critical capacity

Collapse each matched transverse pair to a row. In phase zero the even
column rungs point downward and odd column rungs upward. The source
omissions become row-zero column zero absent and last-row columns zero
and one absent. A boundary-free row is empty and splits the support and
its neighborhood into disjoint components. The upper component is an
even quadrant missing its origin (`C₂`); after transverse reflection the
lower is an odd quadrant missing its first diagonal (`C₃`). The direction
of diagonal compression can be chosen to preserve the transverse width.

For total surplus at most `b`, convexity and `C₃≤C₂` give capacity `C₂(s)`.
Without a boundary-free row, surplus `b` means exactly one boundary cell
per row. Every occupied row is then a prefix, and both endpoint rows are
empty. The rung inequalities give the displayed two-sided prefix lengths,
whose sum is `b(b−1)/2−1≤C₂(b)`. The proposed ramp and full-block quadrant
attainers fit the strip and avoid all three source cells.

I independently rederived the auxiliary outgoing-absent capacity `b²−1`
at surplus `b`. With a free row, its two components have capacities
`C₀(a)` and `C₃(c)`, so their sum is at most `b²`. Equality can occur only
when all surplus is in the unrestricted even quadrant and the compressed
support is the full square extremizer. That extremizer reaches transverse
coordinate `2b−2`, whereas a component before an empty matched row reaches
at most `2b−3`; equality is impossible. Without a free row, all rows are
prefixes, the last is empty, and the one-sided rung bounds sum to `b²−1`.
This supplies an independent alternative to the note's weighted-area citation.

At surplus `b+1`, when both origin neighbors are already present, adding
the origin costs no neighborhood and preserves the other omission for
`b≥2`. Applying the auxiliary bound gives `|S|≤b²−2`. In the remaining
free-row cases, a nonempty reflected component consumes at least two units
of surplus and gives the same bound. The only possible larger all-left
case would attain `C₂(b+1)=b²−1`; equality forces every diagonal
`2,…,2b−2` full, again violating the available transverse width.

## The exceptional boundary row

With no boundary-free row and surplus `b+1`, exactly one row has two
boundary cells. The remaining occupied rows are prefixes. If both endpoint
rows are empty, rung inclusion gives the independent inequalities

    alpha_i≤Σ_(j<i) t_j,   beta_i≤Σ_(j>i) u_j.

Their weighted sum bounds the area by `b²−b+1≤b²−2` for `b≥3`.
Reserving one boundary cell on each internal row justifies the subtraction
of `b−2`; no prefix assumption on the exceptional internal row is needed.

If the first row is occupied, it must be the exceptional row. Its support
is a single interval avoiding zero: two components away from zero require
at least three horizontal boundary cells. A start at one would already
put both origin neighbors in the neighborhood, so the remaining case
starts at least at two. A nonempty next-row prefix would add column zero
as a third boundary cell in the first row, hence that next row is empty.
Its unique boundary admits at most one odd interval cell, giving interval
length at most three and the stated bound on all remaining prefixes.

If the last row is occupied, it likewise has one interval starting at
least at two. For a preceding nonempty prefix of length `c`, its unique
boundary at `c` forces every even interval coordinate to be at most `c`;
the interval length is therefore at most `c`. If the preceding row is
empty, its boundary admits at most one even interval cell, again limiting
the interval to three. The separate `b=2` bounds are valid. These cases
exhaust the possible exceptional endpoints.

## Sharpness and every intermediate size

For `b≥3`, fill even diagonals `2,…,2b−2` and remove `(2b−2,0)`.
Both the support and its neighborhood lose one cell, giving size `b²−2`
and surplus `b+1`. Every smaller size at this budget is realized by a
quadrant prefix of size `k+1`, filled toward small transverse coordinate,
followed by deletion of the origin. At sizes at most `b²−1` before that
deletion, the forbidden far source cells have not yet entered the prefix.
The stated three-room ramp handles `b=2`.

For every larger `k`, take any downward pyramid of size `k+3` and delete
the three forbidden cells. Absence of `(1,1)` bounds a pyramid by
`b(b−1)+1`, and absence of `(2b−2,2)` bounds it by `b²+1`; these follow
directly by summing the maximum heights propagated from the missing cell.
The selected size exceeds both bounds. The forced cells and their
predecessors cover every neighbor of the deleted cells except the omitted
opposite bottom corner. All three deleted source cells are present.
Thus the neighborhood loses exactly one cell and the support loses three,
giving surplus `b+2`. The large pyramid has all fibers nonempty, so its
starting surplus is exactly `b`. This proves every-size attainment,
not only an unbounded subsequence.

## Independent finite attack

`src/maturation_joint_corner_check.py` used actual half-strip coordinate
neighbors, without the row inequalities or compressed cost formula.
It checked **172,032 arbitrary admissible subsets** in three selected
windows and **2,466 every-size constructions** for `b=2,…,13`.
Every construction had exactly the predicted minimum surplus and left
the outgoing corner absent. All checks passed in approximately 0.24 CPU
second. Receipt: `maturation-joint-corner-independent-check.json`.

No mathematical correction to the candidate is requested. Its static
scope should remain explicit when it is integrated into the manuscript.

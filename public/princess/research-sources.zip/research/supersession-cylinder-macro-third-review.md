# Independent review of the unified cylinder interface and its evaluation

12 September 2026. Reviewer: Euler (`trap_recurrence_formal`).

**Verdict: PASS as an ordinary mathematical theorem.** This is a fresh
review of the extension to bipartite Hamiltonian transverse graphs, the
odd-order/even-length case, and the logarithmic-length evaluation. It is
not a Lean verification, an implemented running-time benchmark, or a
claim of a small preprocessing constant.

Reviewed source: `research/supersession-even-macro-states.md`, through
Section 9, SHA-256
`15216ab775bf5a2b674bf60cccfb374ec30783d860a4f7976e0e32763fb43c80`.
The earlier independent review of the physical local-edge construction
is preserved separately in `supersession-even-macro-second-review.md`;
the root's review has its own `supersession-even-macro-independent-review.md`.

## 1. Extra transverse edges do not invalidate the geometry

The Hamiltonian order fixes the bipartition, but every additional edge
of Q is retained. A physical pyramid is a longitudinal spacing-two
prefix in each fiber with virtual cutoff heights differing by one on
every Q edge. The Hamiltonian path gives a finite list of relative
height walks; the additional edges filter that list. They are not
discarded when testing neighborhoods or inspection blocks.

The predecessor proof that neighborhoods remain pyramids is valid on
an arbitrary Q. A transverse neighbor of a room in N(P) has the
required predecessor because its intermediate predecessor lies in P;
the longitudinal-neighbor cases follow from the spacing-two closure.
The virtual heights −2 and −1 handle empty fibers without an extra
nonempty-fiber assumption. The height range is bounded by A−1 along
the chosen Hamiltonian path.

For even A, the transverse Hamiltonian matching gives both the
cardinality lower bound and the equal parity sums in the free-growth
upper bound. Efficient survivors supplied by the physical cylinder
theorem satisfy the height constraints on all Q edges, not merely on
the spanning rectangle. Thus the finite control family and exact
local-edge tests genuinely refer to Q times the path.

## 2. Odd A and even n: checkpoint history is sufficient but not a state

For odd A=2b+1, the matching is instead longitudinal: consecutive
columns are paired in every fiber. This gives equal global color
classes and |N(S)|≥|S| for every support S. The parity sums of Q differ
by one, so a pyramid's neighborhood grows by at most alpha=b+1.
The resulting one-unit cardinality correction is included in the
stated displacement margin.

I checked the use of the earlier physical lemmas
`lem:paired-minimum-frontier` and `lem:paired-frontier-bridge` in
`paper/sections/even-cylinder-eventual-time.tex`. Both efficient cases
are needed. Surplus b with old bit zero produces a physical pyramid.
Surplus b+1 with old bit one is not justified by its cardinality alone:
the actual containment in the preceding critical pyramid's neighborhood
is the hypothesis that forces the intervening survivor to be a
same-oriented pyramid. The manuscript invokes exactly that hypothesis.
Consequently both alternating phases supply canonical checkpoints.

An untouched proper cohort grows by at least one room under the
matching-contracted strongly connected graph. Its bit may drop by one,
but the rank 2k+e still increases by at least one. The existing clipped
potential argument therefore supplies the stated bounded number of
nonclean days. After the marked initial portion of an owner block, the
mate is literally full or empty, and a clean-day source is the
neighborhood of a preceding efficient pyramid. The checkpoint gap is
E+1; there is no missing factor of two.

Omitting the historical bit from a macro state is sound. Each edge is
an actual finite inspection schedule between specified physical
supports, so two edges concatenate without any history precondition.
The bit is only used in the converse direction, to extract checkpoints
from an optimum. No incompatible scalar transition has been promoted
to a physical edge.

## 3. Physical localization survives the extension

For an r-day canonical block, its danger set is
N^r(P_start) minus P_end. Matching and free pyramid growth bound its
size by (m+alpha)r. An avoiding walk ending in that set can only meet
inspections within longitudinal distance r of it. Removing more remote
inspections therefore preserves the endpoint exactly, rather than just
producing a smaller or larger admissible endpoint.

The same-orientation height bound, the opposite-orientation full/empty
fiber alternative, and the end-collar count bounds use only the
matching, finite height range, and free-growth estimate. They remain
valid with alpha in place of A/2. Owner/orientation changes remain end
events. The local check uses the physical longitudinal coordinate and
the same r/2r/3r propagation cones; it does not incorrectly replace the
game by a contracted paired-column game. When both end gadgets are
present their daily inspections retain the single shared budget.

Translation by two physical columns preserves all checkerboard phases.
Interior transitions therefore have a finite homogeneous table, while
end states have bounded relative positions. The actual finite path is
never treated as possessing a translation automorphism.

## 4. The summary composition includes arbitrary revisits

For an interval of blocks, the summary retains all ordered shortest
distances among both end blocks, including same-end pairs. Composition
adds the actual cross edges and takes shortest-path closure on the
four boundary ports. Any physical path decomposes at its crossings;
conversely every auxiliary path expands into physical interval paths
and cross edges. This proves both directions of equality and
associativity without a monotone-crossing assumption.

Two labeled copies of a single block, with zero distances between
corresponding copies, correctly preserve a fixed summary dimension.
Nonnegative weights ensure finite shortest paths exist; the copied
zero edges do not create a negative-cycle or attainability issue.

Grouping R consecutive counter levels makes every homogeneous edge
stay within one block or join adjacent blocks. The incomplete final
block is absorbed into the finite right boundary family. The bounded
exceptional end-to-end edges are added only in the final closure,
along with all boundary vertices and both interior ports. Hence the
evaluation allows repeated strip visits, returns to the same end,
owner changes, and use of a remote-end edge in any order.

Binary powering needs only the associative nonempty-interval operation;
no unproved identity summary is required. The result uses
O_(Q,m)(log(n+1)) arithmetic operations after finite preprocessing.
Distances have O_(Q,m)(log(n+1)) bits, so this is not the same as a
unit-cost bit-complexity claim. Stored shortest-path choices form a
shared binary construction DAG of logarithmic size. Expanding its
actual inspection output takes additional output-dependent time.

## 5. Conservative common constants for the manuscript

Socrates proposed the following single set of constants after the
reviewed source was frozen:

    K=A^2, B=8A^2+8m+2A,
    E=B+2(K+m+1)(B+1), L=E+1,
    alpha=ceil(A/2), q=(m+alpha)L,
    R=100(q+A^2+L+A+1), n0=10R.

This simplification is safe. For even A it enlarges every earlier
nonclean-day and propagation bound; for odd A it agrees with the
larger bounds already used. The lower bound n≥10R implies the
clipping-constant guards, n/2≥2 where needed, h>mL, separation of the
two end cones, and validity of the common interior counter interval.
Increasing E, L, and R does not affect either exactness direction:
shorter genuine blocks are still admitted, and every admitted block
is still checked physically. No claimed minimality of these constants
is involved.

## 6. Accepted scope

For fixed bipartite Hamiltonian Q of order A≥2 and integer m>A/2,
the theorem gives an effective exact algorithm, with the stated
logarithmic arithmetic dependence on n, whenever An is even. It also
gives a compressed optimal physical strategy. The bounded short
exceptions are included in preprocessing. One-row rectangles are
supplied separately by the path theorem, not by pretending A≥2
includes A=1.

This is a uniform algorithmic solution for even-area rectangles at
every feasible budget. It does not provide one elementary expression
in all width, length, and budget parameters, nor an efficient
implementation as those fixed parameters themselves grow. No
constant-budget prefix-optimality assumption is used.

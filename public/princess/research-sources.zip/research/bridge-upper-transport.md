# Physical-window transport and a no-improvement theorem

13 September 2026. New ordinary proof from the bridge-upper-transport lane.
Independent review is pending. The argument concerns one prescribed virtual
flip word, not optimal physical strategies or arbitrary partial-state values.

## Exact scheduling theorem for the descending-height word

Use the accepted transport setup: canonical initial and final pyramid heights
`a,b`, physical height interval `0,...,n-1`, horizon `t>=1`, and quota `k>=0`.
Put `c_x=min(a_x,b_x-t)`. The word obtained by repeatedly lowering a maximum
current height above `c` consists exactly of the letters `(x,H)` with
`H=a_x,a_x-2,...,c_x+2`, sorted by decreasing `H` and then by a fixed vertex
order. The accepted local-maximum argument proves legality. In particular
the word's unshifted heights are nonincreasing.

Write

    A_i = number of letters with H >= n-i,
    B_j = number of letters with H >= -j.

There is a schedule of this fixed word over days `0,...,t-1`, using at most
`k` physically visible letters on each day, if and only if

    B_j-A_i <= k(j-i+1)                         (W)

for some integers `0<=i<=j<t`. A letter on day `d` is visible precisely when
`0<=H+d<n`. An empty word is included. With `k=0`, (W) says that the middle
band is empty, so the construction below never divides a nonempty band by
zero.

**Sufficiency and direct construction.** Leave the word untouched until day
`i`. Its first `A_i` letters all satisfy `H+i>=n`, so execute them for free.
The following `B_j-A_i` letters have heights in `[-j,n-i-1]`; divide them
into `j-i+1` consecutive groups of at most `k` letters and execute them on
those days. Charge every middle letter whether visible or not. The final
letters all satisfy `H+j<0`, so execute them for free on day `j`. Empty
middle bands and empty groups cause no problem. The ordering is preserved.
The original envelope proof gives containment in `b` after all `t` days,
including any unused days at either end.

**Necessity.** Greedily execute each day's longest prefix of the remaining
word with at most `k` visible letters. It consumes all free letters preceding
the next unaffordable visible letter, including the entire suffix if that
suffix is below the board. Greedy dominates every other fixed-word schedule
at every day boundary: if its current position is farther, the part of any
competing next group beyond that position is a suffix of the competing group
and therefore costs no more on that same day. This argument does not assume
visibility is time independent.

Before greedy completes, all heights between its top-free prefix and its
bottom-free suffix are visible. If `q_j` is the position before day `j`, it
therefore completes on that day exactly when

    max(q_j,A_j)+k >= B_j.

Otherwise `q_(j+1)=max(q_j,A_j)+k`. Since `q_0=0` and `A_0>=0`, induction
before the first completion gives

    max(q_j,A_j)+k = k(j+1)+max_(0<=i<=j)(A_i-ki).

The completion condition is exactly (W). It also handles a day with no
paid letters and an already empty word.

## No extra credit at feasible budgets on even-width rectangles

Let the width be `w=2r`, and suppose `k>=r`. Each integer height `H` can
occur in at most `r` word letters, since its physical parity fixes one of
the two column parities. Canonical initial heights are below `n`, so

    A_i <= ri <= ki.

Also `B_(j+1)-B_j<=r<=k`, hence `B_j-k(j+1)` is nonincreasing in `j`.
Consequently the best window in (W) is always `i=0,j=t-1`. The exact
fixed-word criterion is therefore

    B_(t-1) <= kt.

Let `F` be the total word length. Then `F-B_(t-1)` counts letters with
`H<=-t`. This is exactly the previously proved root credit `z(B)`:

- If a target fiber is empty and its bottom room has target physical color,
  its canonical height is `b_x=-2`. The target `c_x` includes `-t-2`, and
  the last old height is `-t`. The initial canonical height is at least
  `-t` for `t>=1`, including the parity-forced case `t=1`, so this letter
  occurs exactly once.
- An empty nonroot target fiber has `b_x=-1`; its last old height is
  `1-t`, and no old height is at most `-t`.
- A nonempty target fiber has `b_x>=0`; its last old height is at least
  `2-t`, again giving no such letter. If `c_x=a_x`, that fiber contributes
  no word letters at all.

Thus, for canonical endpoint pyramids and `k>=r`,

    physical feasibility of this descending word
       iff F <= kt+z(B).                       (E)

The existing boundary-credit criterion is **exact for its prescribed word**
throughout the feasible even-width budget range. Day-dependent visibility
cannot strengthen it there. This does not make it a necessary physical
transport condition: another legal flip order, recanonicalization during
the bridge, or different endpoint states can still help.

The same argument uses the maximum transverse color-class size on a more
general bipartite product; the even-width rectangle is the application
needed here. No general-graph canonical root formula is asserted.

## Bounded checks and current consequences

`src/bridge_upper_transport.py` independently compares (W) with a dynamic
program over all day partitions of each sampled fixed word. It also checks
local-maximum legality and literally replays every accepted physical bridge.
The 500-case receipt is `research/bridge-upper-transport-audit.json`.
Its strict improvements over the old root criterion all occur below `r`,
as (E) requires; no feasible-budget upper improvement is claimed.

The same implementation checks all 5,253 deterministic left-prefix /
descending-word / right-prefix-tail splices for the 103-day solo target on
24x24 with budget 13. None succeeds. The best has entrance day 34, bridge
length 18, target size 149, and budget slack -1. This extends the old failed
102-day diagnostic to the corrected 103-day target **within this specified
family only**. It leaves unrestricted solo time at 103--104 and full time
at 206--207.

The general window criterion can be optimized in a fixed number of standard
operations for supplied endpoint families having a fixed number of affine
pieces: cumulative height counts are piecewise quadratic after parity is
fixed, and (W) is a separable quadratic maximization on finitely many lattice
rectangles cut by `i<=j`. Details of that extension are not needed for (E)
and are not yet claimed here. The accepted fixed-size evaluation of `F` for
two-prefix envelopes already gives the exact fixed-word test in the relevant
budget range. The entrance/exit clocks and selection of splice indices remain
recurrences and parameter-dependent optimization, respectively.

## A uniform constant-surplus interval for anchored prefixes

For `w=2r`, `r>=2`, `n>=2r`, either phase `p`, and the exact prefix
neighborhood count `g_p`,

    g_p(q)=q+r
       whenever (r-1)^2+1 <= q <= r(n-r)+r-1.       (P)

Here is a direct proof from the accepted prefix `(d,c)` formulas. At the
lower endpoint, the last occupied diagonal is at least `w-3`. At the upper
endpoint it is at most `n`; these statements follow by substituting the
quadratic and middle counts for the full diagonals.

- On diagonal `d=w-3` or `d=w-2`, the difference between the two earlier
  full-diagonal counts is `r-1`. The last neighborhood diagonal has one
  more occupied room than the last source diagonal. The surplus is `r`.
- For `w-1<=d<=n-2`, the earlier-count difference is `r`, and the two
  partial diagonals have equal length.
- At `d=n-1`, the upper size bound forces `c>=1`; at `d=n` it forces
  `c>=r+1>=2`. These are exactly the conditions under which the new top
  truncation does not shorten the partial neighborhood diagonal. The
  earlier-count difference remains `r` and the partial lengths agree.

Overlapping boundary cases when `n=w` use the applicable last-diagonal
case; the same displayed counts apply. This proves (P). The 19,080-value
independent arithmetic audit is finite corroboration, not the proof.

## An always-defined corner change at minimum budget

**Theorem.** Let `w=2r`, `r>=5`, `n>=2r`, and `k=r+1`. Define

    Q_A = r(n-r)+2r-2,
    Q_B = r(n-r)+3,
    t   = 2r-5,
    p_A = (n+1) mod 2,
    p_B = n mod 2.

Choose either initial physical color `p0`. Follow the deterministic left
anchored prefix strategy until the first belief in phase `p_A` with size
at most `Q_A`. Call its time `e` and its size `q_A`. Then

    q_A in {Q_A,Q_A-1}.

There is a directly prescribed `t`-day bridge from that belief into the
right anchored phase-`p_B` prefix of size `Q_B`. Finish with the deterministic
right-prefix tail. Thus this construction needs no optimization over splice
indices and is defined for every width and length in its stated range.
Trying the two initial corner phases means a fixed comparison of two clocks.

**Entrance proof.** Prefix neighborhoods are nested as their sizes grow.
At source sizes `Q_A+2,Q_A+1,Q_A`, subtraction of `k` leaves a size in (P).
Thus these states advance to sizes `Q_A+1,Q_A,Q_A-1`, respectively. No larger
prefix can jump below `Q_A+1`, by monotonicity. The feasible deterministic
prefix clock eventually crosses this level, so it visits the three sizes
in order. One of the last two visits has the desired physical phase.

**Endpoint geometry.** First set `n=2r`. The phase-1 prefix of size
`r^2+2r-3=Q_A-1` fills every diagonal through `2r-1`, then at least the
first two cells of diagonal `2r+1`, since `r-3>=2`. Its every fiber has
height at least 2. The larger prefix of size `Q_A` has the same bound.

The right phase-0 target is a reflection of the left phase-1 prefix of
size `r^2+3`. Its last diagonal is `2r-1` and contains `r+3` cells, starting
at column `r-3`. Earlier diagonals have height at most `2r-3`, and the
partial diagonal has height at most `r+2<=2r-3`. All target fibers are
nonempty: its partial diagonal fills the only two fibers missing from the
preceding full diagonals. Therefore its maximum height is `2r-3` and
minimum height is at least zero.

For general `n`, add `n-2r` to every cutoff of these two profiles. They
remain the stated prefixes, since their bottom truncations were inactive;
their sizes increase by `r(n-2r)` and their phases change by `n-2r`.
Consequently

    min_x a_x >= n-2r+2,
    max_x b_x <= n-3,
    max_x(b_x-a_x) <= 2r-5=t.

The positive-part penalty vanishes. Since

    q_A-Q_B <= Q_A-Q_B = 2r-5 = t,

the transport cost is

    F_t = q_A-Q_B+rt <= (r+1)t = kt.

Use the accepted descending local-maximum word and its original grouping.
No boundary credit is needed, and containment in the target is enough for
the tail. This is a uniform construction proof, not a lifting assertion for
arbitrary paths of a lower relaxation.

### What the theorem does and does not calculate

The endpoint sizes and bridge length use a fixed number of standard
operations, with no search over entrances, exits or bridge lengths. The
entrance stopping rule and deterministic tail still iterate prefix clocks.
Their exact capture times have not been reduced to O(1) in width.

The construction is not claimed optimal, nor better than every other upper
construction at every input. For example its bound on 10x10 is worse than
the known optimum. Taking its minimum with an existing valid upper is safe.
It gives minimum-budget upper bounds only; it does not resolve the larger
budget range by ignoring unused quota.

## Two-row length extension of this construction

For fixed `r,p0`, let `L_(r,p0)(n)` be the solo length just prescribed. Then

    L_(r,p0)(n+2) = L_(r,p0)(n)+2r.             (L)

The final solo inspection count is unchanged. Thus its full palindrome,
including the optional reflected central-day merger, increases by `4r`.
After minimizing over the two initial phases, this gives a bound of the form

    U_r(n)=2rn-C_(r,n mod 2),

where the two width constants come from the two base lengths `2r,2r+1`.
These constants are still specified by width-dependent prefix clocks.

**Entrance.** Its survivors before the stopping time have every fiber
nonempty. Indeed, the smallest such survivor has size at least `Q_A-k`,
which is at least the size of a prefix containing the bottom room in every
fiber, in either phase; substitution in the prefix formula gives this
for `r>=5`. Adding two to all cutoffs therefore commutes with each exact
inspection-and-neighborhood entrance step, while adding `2r` rooms to every
belief. The stopping inequality and phase are unchanged, so `e` is unchanged.

**Bridge.** Both endpoint vectors increase by two, preserving their
differences and the prescribed `t`-day cost. This is the same bridge theorem.

**Tail.** The new target has size `Q_B+2r`. During its first `2r` tail steps,
the pre-move survivor sizes range from `Q_B+2r-k` down to `Q_B+1-k`.
They all lie in (P) on the `(n+2)`-long board, so each step decreases the
belief size by exactly one. After `2r` steps the phase is unchanged and the
belief is precisely the original size-`Q_B` target.

The remainder of the original tail is unaffected by the taller board.
The original target has maximum height at most `n-3`. All later sizes
decrease, since any pyramid's canonical `+1` envelope contains its
neighborhood and has at most `r` additional rooms, so
`g_p(q-k)<=q-1`. In the target phase, every later prefix is contained in
the original target. In the opposite phase it is contained in the target's
neighborhood: that neighborhood is a prefix and has at least `Q_B` rooms
by the rectangle's perfect matching. Thus every later belief has height
at most `n-2`; its neighborhood cannot leave the original board at the top.
The taller board changes neither inspections nor neighborhoods. This
proves (L) and preservation of the final inspection count.

## New physical construction receipts

`src/bridge_upper_transport.py --balanced-audit` checks 608 endpoint pairs
through width160 and 19,080 plateau values, then constructs and literally
replays both initial-phase strategies on 17 boards. The summary is
`research/bridge-upper-transport-uniform-audit.json`; each named board has
its own receipt with both the solo and actual full-board inspections.

The direct rule attains the independent critical-corner lower on 12x12,
12x14, 14x14, 14x15, 16x16, 16x18, and32x32. In particular its new finite
upper certificates are 112 on16x16, 144 on16x18, and308 on32x32. The parent
lane owns independent lower verification and promotion to exact results.
The physical24x24 interval remains206--207. The uniform rule gives207
there, not206; it is not universally optimal.

The preliminary alternative-order and per-day clipping probes tried a
capped250 endpoint pairs with four/five priorities on16x16 and24x24. They
found no witness at their attempted targets. Those early16x16 probes used
only initialphase0, so they did not expose the successful phase1 bridge;
they establish no unrestricted or two-phase family lower bound.

`research/bridge-upper-transport-length-audit.json` independently compares
both initial phases at twelve base lengths with length increased by four,
including literal full-board replay. All entrance times, tail increments,
solo/full increments and final inspection counts satisfy (L). This is
corroboration of the uniform proof, not an extrapolation from finite data.

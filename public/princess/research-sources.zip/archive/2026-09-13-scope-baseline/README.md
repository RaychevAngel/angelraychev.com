# Fixed-scope baseline

Unchanged assessment sources from commit d38c1b0, where the absolute O(1) rectangular capture-time criterion and scope separation were first reconciled. These are historical records, not current coverage claims. See research/BOX_RECONCILIATION.md for the comparison with the later bridge investigation.

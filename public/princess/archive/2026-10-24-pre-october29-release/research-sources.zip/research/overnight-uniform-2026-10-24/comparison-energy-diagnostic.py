"""Targeted falsification of common-tied-origin phase energy conjectures."""
from math import isqrt
from pathlib import Path
import json,time

def root(z):
 s=isqrt(z);return s+(s*s<z)
def rho(z):
 s=(isqrt(4*z+1)-1)//2;return s+(s*(s+1)<z)
def step(k,p):
 x,y=p;return y+k-rho(y+k),x+k-root(x+k)
def run():
 t0=time.process_time();worst=(-10**9,None);fails=[];n=0
 for k in range(33,1501):
  R=(3*k+4)//5+4 if k<100 else 3*k//5
  L=R*R;Z=L+k-rho(L+k)
  for seed in sorted({L+1,(L+Z)//2,Z}):
   p=(seed,seed)
   for t in range(100000):
    if max(p)>=(k-6)**2:break
    d=p[0]-p[1];v=k-root(max(p)+k)
    error=d*d-v
    n+=1
    if error>worst[0]:worst=(error,dict(k=k,t=t,p=p,v=v,seed=seed,d=d))
    if error>1 and len(fails)<20:fails.append(dict(k=k,t=t,p=p,v=v,seed=seed,d=d,error=error))
    p=step(k,p)
 return dict(status='DIAGNOSTIC_ONLY',checks=n,worst=worst,failures_energy_le_v_plus1=fails,cpu=time.process_time()-t0)
if __name__=='__main__':
 r=run();Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

# An exact admissibility test for a stronger scalar cutoff

24 October 2026. Parametric extension of the independently accepted
comparison-half-cutoff.md. This note only changes the cutoff used in the
necessary early and late hybrid clocks; it does not claim exact capture.

Let k>=100 and choose an integer R with

    floor(k/2)<=R<=floor(3k/5).

Put r0=R+1 and D=k-R-1. Suppose

    4(ceil((r0²-12r0-112)/(2k))-1)>=D.            (1)

Equivalently, because the quantities other than the quotient are integers,

    r0²-12r0-112 > 2k ceil(D/4).                 (2)

The inequality in (2) is strict. It must not be weakened to >= at an exact
integer quotient. This criterion permits a deterministic choice of the
smallest admissible R, if desired; this is a clock strengthening, not a
claim about the final bounded-formula goal.

Both old slow-region proofs are valid at this cutoff. Indeed D<=r0, so
the capped four-room early argument applies for every target root r>=r0.
The weaker of the two matching charges is the LATE one,

    Delta>=ceil((r²-12r-112)/(2k)).

Its quadratic increases for r>=r0>=51. Thus (1), checked only at r0,
pays every old rewind, early or late. The early charge has numerator
r²-11r-108, which is larger by r+4. All concentration and quadrant-fit
conditions in the half-cutoff proof remain true: r>=51 and k<2r.
The smaller fast caps retain the earlier all-target physical +1 bound.

## Near-pronic extension without a new width enumeration

For b>=200,k=b+d,1<=d<=19, the previously accepted near-pronic proof
can use ANY R satisfying (1). In its late interface C=d+5 and
D<=k/2 give

    B_star<=(7C+D)/4<=b/8+15d/8+35/4.

The sufficient uniform polynomial is now

    3b²-16bd-166b-15d²-78d-108>=0.               (3)

It decreases in d on1..19 and, at d=19, increases in b>=200. Its value
at (200,19) is18995. Thus (3) pays every mixed old/near switch. The early
near-interface proof retains C=d+6 and does not depend on D, except for
old switches already covered by (1). The other guards remain satisfied.

For example k=225,R=116 gives r0=117,D=108. The late charge numerator
is12173 while 2k ceil(D/4)=12150, proving (2). The fixed half cutoff was
R=119, so the integer charge legitimately removes three more root bins
from the scalar relaxation. No earlier proof source or numerical receipt
has been modified.

The nonempty admissible set is already certified by R=ceil(k/2)+6 from
the half-cutoff theorem. The smallest admissible cutoff therefore gives a
well-defined stronger necessary evaluator throughout the displayed scope.
It need not improve every individual clock or remove the largest gap.

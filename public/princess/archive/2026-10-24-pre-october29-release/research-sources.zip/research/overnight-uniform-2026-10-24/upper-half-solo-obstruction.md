# Hall noncontraction does not imply a half-time solo reduction

24 October 2026. Bounded counterexample, not a rectangle theorem.

The proposed generic inequality joint_time >= 2*optimal_solo_time-1 is false even for a connected, symmetric, Hall-noncontracting relation. The ten-vertex tree has edges

    01,12,14,23,36,39,45,67,89.

Its displayed perfect matching is01,23,45,67,89, which proves Hall noncontraction for every subset. At budget2, exhaustive one-copy subset search gives solo time6. A literal nested two-copy schedule captures in10 updates; its daily survivors and resulting states are saved in `upper-half-solo-counter.json`. Thus10<2*6-1. No property of an unknown compression map is used for this upper witness: every displayed smaller survivor is contained in the larger one.

This is stronger than the earlier failure of exact seriality, but still does not refute the folded-rectangle setting. This tree has no loop. Adding one loop at each of its ten possible vertices was checked separately: those ten modifications all have joint time at least11. That bounded negative check is not evidence for a general looped theorem, and no such theorem is claimed.

Lesson: symmetry, a perfect matching, and nested cohort polarization do not suffice to reduce a full game to twice the best solo clock. An exact rectangle reduction needs additional geometry or a stronger property of the looped folded grid.

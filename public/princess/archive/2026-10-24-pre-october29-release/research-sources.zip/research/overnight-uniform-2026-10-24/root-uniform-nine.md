# Uniform nine-day bracket: assembled ordinary theorem

24 October 2026. Assembly submitted for independent review. The component
early, late, middle, and finite-base proofs have independent reviews.
This is a bound-tightening result, not exact optimality or new Lean coverage.

For every rectangle w<=n and every feasible k>=floor(w/2)+1, retained
computable lower and physical constructive upper bounds can be chosen with

    L_k(w,n) <= T_k(w,n) <= U_k(w,n),
    U_k(w,n)-L_k(w,n) <=9.                       (1)

Every older exact or stronger bound is retained by maxima/minima. For
even-area rectangles one may in particular add the lower bound

    T_k(w,n)>=2P_k(w,n)-9,                       (2)

whenever not already covered more sharply, where P is the smaller of the
two complete solo anchored-prefix clocks. Two sequential solo prefix
constructions give U<=2P. The proved all-input ceiling at the frozen start
was25 (23 at even width); the purpose of this note is to remove the last
low-budget, unbounded-width exceptions to the nine-day guarantee.

## 1. The remaining analytic range

Let wn be even, b=floor(w/2)>=200, d=k-b in1..19, h=wn/2. Set

    H=b(b-1), H'=H-d+1.

Retain the actual early and late crossing endpoints. The exact scalar
crossing inequalities give

    H-d+1<=Q<=H,       H-d+2<=Y<=H+2.             (3)

For early crossing, G(H'-1)=H because H'-1+k=b^2. For late crossing,
rho(H')=b-1, so H'+k-rho(H')=H+2. These are integer endpoint bounds,
including the minimum-budget case d=1. They do not replace endpoints
by unrelated choices of phase.

The same early hybrid E and late hybrid C from the frozen checkpoint now
give necessary clocks e(Q),ell(Y) at(3), by
`root-pronic-early-extension.md` and `lower-pronic-late-extension.md`.
Let tau9(h-Q;Y) be the accepted necessary nine-feature middle clock
initialized at equal threshold Y. The standard physical passage split
therefore gives, for every actual first merged-gate time g,

    g >= J = min_(Q,Y) [e(Q)+tau9(h-Q;Y)+ell(Y)].   (4)

There is no overlapping transition between the three passages. The cuts
are separated even on the shortest board: Q+Y<=2H+2<2b^2<=h.
The existing reversed-walk cut gives T>=2J+1.

## 2. The actual boundary pairs satisfy the middle hypotheses

Take A=E_e(Q), C=C_ell(Y). Both hybrid sequences are coordinatewise
nondecreasing. Their common scalar caps are inactive throughout the
boundary range(3); for example every coordinate is at least its endpoint
minus k, which exceeds R^2+2k for b>=200,d<=19,R=floor(3k/5).
This last elementary inequality has ample positive margin already at
(200,19), and its left-minus-right increases with b and decreases with d.
Thus the ordinary forward and backward pair operators preserve progress.
The finite-board backward operator is at least its quadrant operator, so
Phi(C)>=C, while Hf(A)>=A.

Time interlacing gives M<=G(x) when x is the smaller pair coordinate and
M the larger; use the forward G(x)=x+k-rho(x+k) for A, and the backward
G(x)=x+k-rho(x) for C. For A, x+k>=M>=Q> (b-2)(b-1), hence
rho(x+k)>=b-1. For C, x>=M-k>=Y-k>(b-2)(b-1), since b>2d.
Consequently both spans are at most k-(b-1)=d+1. This is a bound on the
actual hybrid pair, not a free choice of a favorable phase.

The independently reviewed shifted-pronic middle theorem applies:

    max_p [Phi^(tau9+2)(C)_p + A_(p xor chi)] >= h,
    chi=(w+n-2) mod2.                            (5)

Its odd-width d>=4 and all even-width cases are analytic. The remaining
odd d1..3 cases have an exact reduction to44 residue cells, checking
22,368 progressive endpoint pairs. The proof includes the two initial
transients and the final pronic-wall overshoot. See
`comparison-shifted-pronic-middle.md` and its independent review.

## 3. Meeting the physical prefixes

The same-phase fast-region domination from the earlier two-front proof
propagates unchanged to the new cuts: a physical forward pair at e+1
dominates E_e, and a physical backward gate pair at ell+1 dominates C_ell.
The relevant quadrant inequalities remain valid up to H; clipping to H
when desired only weakens the meeting. Beyond the low quadrant the exact
finite-board physical maps are no slower than these quadrant maps.

Apply monotonicity to(5), then the accepted antipodal two-front meeting
criterion. The complete solo prefix clock satisfies

    P <= (e+1)+(tau9+2)+(ell+1)+1
      = e+tau9+ell+5.

The final1 is the capture inspection. Minimize over(3) in(4):

    P<=J+5<=g+5,   T>=2J+1>=2P-9.

This preserves the carried phases and unused progress throughout all
three regions. It supplies a uniform bound; it does not claim the
necessary hybrid or middle histories themselves are physical strategies.

## 4. Complete coverage, including the finite base

The following overlapping pieces cover every feasible input:

* Odd-by-odd rectangles retain exact joint evaluation.
* Widths at most64 retain the complete all-length/all-budget gap<=3 theorem.
* Even-area widths65..399 and excess d1..19 have a complete finite
  certificate with gap<=8. There are9,538 width/budget/parity lines and
  105,621 finite length representatives, with the accepted onset/affine
  insertion theorem covering all later lengths. Every tail insertion is
  checked through its complete state trace. This is not a sample of n.
  Its named upper U is at least2P-1: the half-budget initial seed k/2 is
  dominated by the full-seed first layer k, so it saves at most one solo
  layer and yields at most the one-day odd-start improvement. Therefore
  the finite gap8 also gives L>=U-8>=2P-9.
* At b>=200 and d1..19 the preceding analytic proof gives gap<=9.
* The frozen nine-day theorem covers d>=18 at even width and d>=20 at
  odd width whenever k<3b. Its overlap with the new ranges is harmless.
* Even-area k>=3b retains the stronger gap<=1 theorem.

The finite base is `root-finite-base-lines.jsonl`, generated by the
reviewed exact-integer port `root-finite-base.cpp` of the accepted
`comparison_periodic.py`. Its root calculations are integer-corrected.
The source review verifies all inverse branches, the short n=2b+1 corner
exception, phase conventions, both initial seeds, and insertion checks.
Separate Python replays test complete lines, including every maximal-gap
line, against the original implementation. The full certificate has no
missing or duplicate parameter keys. It does not replace sharper older
results inside its range.

## 5. What is not proved

The user's goal is gap zero, and it remains open. The middle comparison
cannot be improved from two moves to one under only independent progress
and span hypotheses: a literal counterexample is recorded separately.
Further squeezing must retain more real boundary history or strengthen
the necessary middle model. Fixed-anchor prefixes are also not generally
optimal: an existing literal12x12 transport strategy beats them. These
are limitations of the current proof/construction, not evidence that the
true problem has a nine-day ambiguity.

No fixed-operation expression work is authorized by this partial result;
the required all-input zero gap has not been reached. No public or Lean
coverage is silently enlarged by this research note.

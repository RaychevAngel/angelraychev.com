"""Ordinary-MAX fast continuation inside an accepted late hybrid.

Checks the extra causal condition. Inherited slow/history parameter guards
and the allowed starting ceiling must separately be supplied by the caller.
"""
from bisect import bisect_left
from math import isqrt


def root(x):
    return isqrt(x-1)+1 if x else 0


def rho(x):
    s=(isqrt(4*x+1)-1)//2
    return s+(s*(s+1)<x)


class OrdinaryMaxLate:
    def __init__(self,k,R,gate=None):
        self.k=k; self.R=R; self.A=R*R+k
        self.gate=k if gate is None else gate
        assert 0<=self.gate<=k
        self.ordinary=[(self.gate,self.gate)]
        self.states=[(self.gate,self.gate)]; self.maxima=[self.gate]

    def G(self,x):
        return self.k+x-rho(x)

    def F(self,x):
        return self.k+x-root(x)

    def step(self):
        p=self.ordinary[-1]; pn=(self.G(p[1]),self.F(p[0]))
        cap=min(self.A,max(pn)); e=self.states[-1]
        en=(max(cap,self.G(e[1])),max(cap,self.F(e[0])))
        assert all(pn[i]>=p[i] and en[i]>=e[i] for i in (0,1))
        self.ordinary.append(pn); self.states.append(en); self.maxima.append(max(en))
        if en==e and pn==p:raise ValueError('Requested target exceeds fixed point')

    def grow(self,target):
        while self.maxima[-1]<target:self.step()

    def clock(self,target):
        if target<=self.gate:return 0
        self.grow(target)
        return bisect_left(self.maxima,target)

    def causal_guard(self,w,n):
        assert w<=n and w*n%2==0
        b=w//2; rh=root(self.A-1)
        while min(self.ordinary[-1])<self.A:self.step()
        J=bisect_left([min(p)for p in self.ordinary],self.A)
        return dict(valid=(self.A>self.k and rh<=b-1 and J+2*rh<=w+2),
                    w=w,n=n,k=self.k,R=self.R,gate=self.gate,A=self.A,Rhat=rh,J=J)


def hybrid_gate_curve(k,ceiling,R,gate=None,keep_phases=False):
    model=OrdinaryMaxLate(k,R,gate);model.grow(ceiling)
    out=dict(maxima=model.maxima)
    if keep_phases:out['phases']=model.states
    return out

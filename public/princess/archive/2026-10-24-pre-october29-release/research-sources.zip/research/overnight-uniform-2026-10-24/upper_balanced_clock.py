"""Arithmetic evaluation of the ALREADY PROVED uniform balanced transport upper.
No new strategy family or exact-optimality claim; avoids constructing huge shot lists.
The physical constructor is src/bridge_upper_transport.py::balanced.
"""
from pathlib import Path
import importlib.util,json,hashlib
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('prefix_clock',P.parent/'uniform-history-2026-10-23'/'root-prefix-clock.py')
prefix=importlib.util.module_from_spec(s);s.loader.exec_module(prefix)

def evaluate(w,n):
 assert w>=10 and w%2==0 and n>=w
 b=w//2;k=b+1;h=b*n
 qa=b*(n-b)+2*b-2;qb=b*(n-b)+3;bridge=2*b-5
 z=qb;phase=(n%2)^1;tail=0
 while z>k:
  z=prefix.neighborhood_size(w,n,phase,z-k);phase^=1;tail+=1
 tail+=1
 choices=[]
 for initial in(0,1):
  q=h;phase=initial;entry=0
  while q>qa or phase!=(n+1)%2:
   q=prefix.neighborhood_size(w,n,phase,q-k);phase^=1;entry+=1
  assert q in(qa,qa-1)
  solo=entry+bridge+tail;full=2*solo-int(2*z<=k)
  choices.append(dict(initial_prefix_phase=initial,entry_steps=entry,entry_size=q,
                      bridge_steps=bridge,target_size=qb,tail_steps=tail,solo_days=solo,
                      final_inspections=z,full_days=full))
 return dict(w=w,n=n,k=k,choices=choices,selected=min(choices,key=lambda r:(r['full_days'],r['solo_days'])),
             source='src/bridge_upper_transport.py::balanced',
             status='Existing uniform physical upper evaluated arithmetically; not an optimum')

def audit():
 root=P.parents[1];checked=[]
 for f in sorted((root/'research').glob('bridge-upper-transport-uniform-*x*.json')):
  old=json.loads(f.read_text());w,n=old['shape'];new=evaluate(w,n)
  for a,b in zip(old['choices'],new['choices']):
   for key in b:assert a[key]==b[key],(f,key,a[key],b[key])
  checked.append([w,n])
 result={'status':'PASS','existing_literal_strategy_receipts_matched':checked,'new_target':evaluate(448,448),
         'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'physical_constructor_sha256':hashlib.sha256((root/'src/bridge_upper_transport.py').read_bytes()).hexdigest()}
 P.joinpath('upper-balanced-clock-audit.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'receipts_matched':len(checked),'target':result['new_target']},indent=2))
if __name__=='__main__':audit()

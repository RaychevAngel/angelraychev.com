# Exact physical subtraction and the remaining packing defect

24 October 2026. Ordinary strategy simulation proposed for independent review.
This isolates a geometric obstruction; it does not claim that the obstruction
is always small on a rectangle.

Let G be a finite bipartite graph with equally sized color classes of size h,
and let gamma be any color-exchanging graph automorphism. Consider any actual
two-cohort inspection history from full uncertainty. At time t write its
current beliefs as X_t and Y_t in the two current colors, and put
D_t=V_(color X_t)\X_t. The colors alternate after every move. Define

    Z_t=Y_t\gamma(D_t).

There is an actual SINGLE-cohort strategy from its full color class, using at
most the same combined daily inspection budget, whose belief at each time t
is contained in Z_t. No nesting or cardinality comparison is required.

## Proof with the daily inspections kept explicit

Suppose the actual useful inspections on day t are I_X subset X_t and
I_Y subset Y_t. The two survivor sets are X_t\I_X and Y_t\I_Y. The former's
hole set is D_t union I_X. In the solo strategy inspect all currently possible
rooms in I_Y union gamma(I_X), costing at most |I_X|+|I_Y|.

If its old belief is contained in Z_t, its survivors are contained in

    (Y_t\I_Y) \ gamma(D_t union I_X).

For a set A of one color write E(A) for the vertices of the other color whose
entire neighborhoods lie in A. Symmetry of graph adjacency gives

    N(B\A) subset N(B)\E(A).                         (1)

Since gamma commutes with N and E, the next solo belief is contained in

    N(Y_t\I_Y) \ gamma(E(D_t union I_X))
      = Y_(t+1) \ gamma(D_(t+1)) = Z_(t+1).

Initially D_0 is empty and Y_0 is full, so Z_0 is full. This proves the
simulation for every day, including arbitrary retreats and corner changes.

## Exact cardinality identity

The signed merged mass q_t=|Y_t|-|D_t| satisfies

    |Z_t|=q_t+|gamma(D_t)\Y_t|.                      (2)

Thus numerical subtraction is physically realizable up to the nonnegative
packing defect on the right. At a signed gate q_t<=0, the number of possible
solo rooms is at most

    |Y_t\gamma(D_t)|.

If this is zero for some gamma, the same elapsed history already eliminates
the solo cohort. If it is at most k, one additional inspection day suffices.
These implications hold for every constant budget k and, with the corresponding
last-day quota, for varying budgets as well.

For a fixed history one may choose the best gamma retrospectively: the
construction then uses that same gamma for the complete solo history. This
does not allow changing gamma at arbitrary intermediate times for free.

## Folded version and scope of the missing theorem

For the polarization involution sigma, represent both cohorts on the folded
graph K. Then Y subset X and D=V\X is disjoint from Y. Any fixed automorphism
tau of K gives exactly the same simulation Z=Y\tau(D). On a square, the
unfolded statement also permits color-exchanging rotations whose folded
representations alternate between two intertwining permutations; no constant
K-automorphism is assumed in that case.

The remaining prospective theorem is a HISTORY-CONDITIONED packing assertion:
near an early-enough half-mass gate, either some allowed gamma makes the defect
zero (or within one inspection), or the preceding physical history has already
spent enough extra time to pay for that defect. Cardinality alone gives no such
packing. Neither does nesting alone; it makes the untransformed D and Y disjoint.

The adaptive moving-corner upper constructions remain compatible with this
simulation. A proposed lower packing theorem must allow their corner motion and
cannot simply impose a fixed-corner prefix normal form already refuted on12x12.

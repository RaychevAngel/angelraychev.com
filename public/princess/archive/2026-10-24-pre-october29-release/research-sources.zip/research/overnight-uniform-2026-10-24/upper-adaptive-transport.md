# A uniform transport bridge preserving the entrance deficit

24 October 2026. New ordinary constructive lemma, submitted for independent
review. It strengthens the endpoint of the existing balanced transport; it
does not assert optimality of any strategy family.

Let `w=2b>=10`, `n>=w`, and use daily budget `k=b+1`. Define

    QA=b(n-b)+2b-2,  QB=b(n-b)+3,  t=2b-5.

For every integer `0<=delta<=b-3`, there is an explicit t-move physical
bridge from the bottom-left prefix of size `QA-delta`, in phase
`p=(n+1) mod2`, to a subset of the bottom-right prefix of size `QB-delta`,
in phase `1-p`.

In particular the existing balanced construction enters at QA or QA-1.
The old endpoint QB may be replaced by QB or QB-1 respectively. No extra
move or quota is needed. A deterministic prefix tail from the smaller
endpoint gives an upper bound at least as strong as the old one.

## Exact endpoint geometry

With columns `x=0,...,2b-1`, the two physical height walks are

    a_x=n-1-x+2·1{x>=b+2+delta},
    z_x=n-2b-2+x+2·1{x<=b+2-delta}.

These are precisely the indicated prefixes: the left prefix has last
diagonal n+1 and final-diagonal threshold b+2+delta; reflection of the
right prefix has last diagonal n-1 and threshold b-3+delta. Their area
difference is `QA-QB=t`. Both walks have successive differences ±1,
the required checkerboard parities, and physical heights in [0,n-1].
In fact `min a>=n-2b+1`, `min z>=n-2b`, and `max z<=n-3`.

We claim `z_x-a_x<=t` in every column. Their difference is

    2x-2b-1 + 2·1{x<=b+2-delta} - 2·1{x>=b+2+delta}.

When delta=0, its maximum is at most max(3,2b-5)=t. When delta>=1,
split the columns at `b+2-delta` and `b+2+delta`. In the left part the
maximum is at most `5-2delta<=3`; in the middle it is at most
`1+2delta<=2b-5`; in the right part it is at most `2b-5`. Empty parts
do not affect the bounds. Thus `z-t<=a` coordinatewise.

## Explicit legal word and daily schedule

Apply the accepted virtual-height transport theorem to a and z. The
required terminal virtual walk is `c=z-t`; no coordinatewise minimum
loses area because `c<=a`. The number of local downward flips is exactly

    F=sum_x(a_x-c_x)/2
     =(QA-delta)-(QB-delta)+bt
     =(b+1)t=kt.

Take the legal descending-height flip word from a to c, with a fixed
left-to-right tie order, and divide it into t consecutive groups of k
flips. On physical day j inspect exactly the word's cells `(x,H+j)` which
lie in the board. Each group uses at most k rooms. The existing transport
proof shows that the actual final belief is contained in z. It remains
valid when some virtual flips become invisible at a boundary; those only
reduce actual inspection cost.

This gives directly specified inspections, not a search for a bridge.
The accepted source is `src/resumed_even_construction_transport.py` and
the later physical-window implementation `src/bridge_upper_transport.py`.

## Scope

The lemma holds for every allowed b,n,delta. It is an upper construction
at minimum budget, independent of a lower-model realization claim. The
resulting entrance/tail clocks remain computable recurrences, as authorized
for the current bound-tightening objective. No fixed-operation formula,
new Lean proof, or public artifact is claimed here.

"""Attack middle+2 over the complete tied-reset interval for one parameter.
Not a width-family proof, and reset seeds need not be the actual scalar orbit.
"""
from pathlib import Path
import importlib.util,json,time,argparse
HERE=Path(__file__).resolve().parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('tied_middle_original',HERE.parent/'joint-history-2026-10-24/root-common-orbit-attack.py')

def H(k,p):return p[1]+k-m.rho(p[1]+k),p[0]+k-m.root(p[0]+k)
def run(b,d,odd=True,extra=0,seeds=None):
 start=time.process_time();w=2*b+int(odd);n=w+int(odd)+extra;k=b+d;h=w*n//2;chi=(w+n-2)%2;cut=(b-6)**2
 R=(3*k+4)//5+4 if k<100 else 3*k//5
 L=R*R;Z=L+k-m.rho(L+k)
 qmax=cut-1+k-m.rho(cut-1+k);ymax=cut+k-m.rho(cut)
 times={}
 for Y in range(cut+1,ymax+1):
  B={f:Y for f in m.nine.FEATURES};day=0;qs=list(range(qmax,cut-1,-1))
  while qs:
   while qs and max(B.values())>=h-qs[0]:times[Y,qs.pop(0)]=day
   if qs:B=m.nine.step(w,n,k,B);day+=1
 checked=0;worst=10**9;failures=[];best_witness=None
 for seed in (range(L+1,Z+1) if seeds is None else seeds):
  for delta in(0,1):
   E=(seed,seed);D=(seed,seed-delta);t=0
   while max(D)+k<cut+1:E=H(k,E);D=H(k,D);t+=1
   for late_extra in(0,1):
    if late_extra:E=H(k,E);D=H(k,D);t+=1
    C=tuple(z+k for z in D);Y=min(ymax,max(C))
    EE=E;j=0
    while max(EE)<cut:EE=H(k,EE);j+=1
    endpoints=[]
    for early_extra in(0,1):
     if early_extra:EE=H(k,EE)
     Q=min(qmax,max(EE));tau=times[Y,Q]
     endpoints.append((EE,Q,tau,j+early_extra))
    X=C;day=0
    for EE,Q,tau,jj in sorted(endpoints,key=lambda z:z[2]):
     while day<tau+2:X=m.physical(w,n,k,X);day+=1
     margins=tuple(X[p]+EE[p^chi]-h for p in(0,1));margin=max(margins);checked+=1
     if margin<worst:
      worst=margin;best_witness=dict(seed=seed,delta=delta,t_late=t,C=C,E_late=E,E_early=EE,Q=Q,Y=Y,tau=tau,margins=margins,X=X,early_offset=jj)
     if margin<0:failures.append(best_witness)
 return dict(status='DIAGNOSTIC',b=b,d=d,w=w,n=n,reset_range=[L+1,Z],checked=checked,worst_margin=worst,worst_witness=best_witness,failures=failures,cpu=time.process_time()-start)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('b',type=int);p.add_argument('d',type=int);p.add_argument('--even',action='store_true');p.add_argument('--extra',type=int,default=0);a=p.parse_args();r=run(a.b,a.d,not a.even,a.extra);out=HERE/f'comparison-tied-middle-b{a.b}-d{a.d}-{int(not a.even)}.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

# A common real map behind the square and pronic phase maps

24 October 2026. Exact algebraic normalization; no new capture-time bound
is asserted.

Write

\[
 r(q)=\lceil\sqrt q\rceil,\qquad
 \rho(q)=\min\{s\in\mathbb Z_{\ge0}:q\le s(s+1)\}.
\]

The forward hole maps are

\[
 F(x)=x+k-r(x+k),\qquad G(x)=x+k-\rho(x+k),
 \qquad H(x,y)=(G(y),F(x)).
\]

For a lattice \(\Lambda=\mathbb Z+\alpha\), let
\(\lfloor z\rfloor_\Lambda\) and \(\lceil z\rceil_\Lambda\) mean
rounding downward and upward to that lattice. Define

\[
 Q(z)=(\sqrt{z+k}-\tfrac12)^2
     =z+k+\tfrac14-\sqrt{z+k}.
\]

With staggered coordinates \(u=x,v=y+1/4\), the update is exactly

\[
 u'=\lfloor Q(v)\rfloor_{\mathbb Z},\qquad
 v'=\lfloor Q(u)\rfloor_{\mathbb Z+1/4}.                 \tag{1}
\]

Indeed \(\rho(m)=\lceil\sqrt{m+1/4}-1/2\rceil\). Therefore
\(\lfloor Q(y+1/4)\rfloor=G(y)\), while
\(\lfloor Q(x)-1/4\rfloor+1/4=F(x)+1/4\).
These identities include square and pronic equality endpoints.

For \(z+k>1/4\), the real map is increasing and contractive:

\[
 0<Q'(z)=1-\frac1{2\sqrt{z+k}}<1,\qquad
 Q''(z)=\frac1{4(z+k)^{3/2}}>0.
\]

Thus the two phases differ only in which of two staggered lattices
receives the rounded iterate of one increasing convex map. This does
not by itself bound the accumulated rounding discrepancy: the two
rounding errors are correlated with the entire orbit.

## The high-deficit inverse

The inverse real map, on the increasing branch, is

\[
 R(z)=(\sqrt z+\tfrac12)^2-k=z+\sqrt z+\tfrac14-k.
\]

The high-deficit physical update is

\[
 (x',y')=(y+r(y)-k,\;x+1+\rho(x)-k).
\]

In the different staggered coordinates \(u=x+1/4,v=y\), it becomes

\[
 u'=\lceil R(v)\rceil_{\mathbb Z+1/4},\qquad
 v'=\lceil R(u)\rceil_{\mathbb Z}.                    \tag{2}
\]

For the first equality, subtracting1/4 before taking the ceiling gives
\(y+\lceil\sqrt y\rceil-k\). For the second,
\(\lceil x+1/2+\sqrt{x+1/4}\rceil=x+1+\rho(x)\).

The low and high staggerings are exchanged. An attempted low/high
cancellation must retain this exchange; treating both clamped numerical
models as inverse iterates of the same rounded map would be incorrect.

## Current research use and limitation

A common tied origin is the pair \((u,v)=(s,s+1/4)\). The accepted
inverse-interval criterion records exactly which staggered pairs can
come from such an origin. Equations(1)-(2) suggest an order or rounding
invariant that could propagate that admissibility through many root
bins without independent phase resets. Such an invariant, or any
resulting uniform capture-time comparison, remains to be established.

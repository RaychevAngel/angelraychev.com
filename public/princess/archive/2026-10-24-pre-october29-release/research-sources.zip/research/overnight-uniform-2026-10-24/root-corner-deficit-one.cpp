// Constant-budget saturation falsifier. The pruning is valid for this
// monotone predicate because each coordinate is individually <= its
// full-quota ordinary coordinate, so dominance preserves equality there.
#define main original_allocation_main
#include "root-corner-allocation.cpp"
#undef main
int main(int argc,char**argv){
 int top=argc>1?atoi(argv[1]):100;long long transitions=0;int days=0;
 for(int k=2;k<=top;++k){
  vector<pair<int,int>> states={{0,0}};int a=0,b=0,H=(k-1)*(k-2);
  for(int day=1;day<100*k;++day){
   int na=G(b+k),nb=F(a+k);a=na;b=nb;
   vector<int> best(a+1,-1);
   for(auto [x,y]:states)for(int u=0;u<=k;++u){
    int nx=G(y+u),ny=F(x+k-u);++transitions;
    if((a>=2&&nx==a-1&&ny>2)||(b>=2&&ny==b-1&&nx>2)){
     cout<<"{\"status\":\"DEFICIT1 COUNTEREXAMPLE\",\"k\":"<<k
         <<",\"day\":"<<day<<",\"source\":["<<x<<","<<y
         <<"],\"allocation\":"<<u<<",\"next\":["<<nx<<","<<ny
         <<"],\"ordinary\":["<<a<<","<<b<<"]}\n";return 0;
    }
    best[nx]=max(best[nx],ny);
   }
   states.clear();int seen=-1;
   for(int x=(int)best.size()-1;x>=0;--x)if(best[x]>seen){
    states.push_back({x,best[x]});seen=best[x];
   }
   ++days;if(max(a,b)>=H)break;
  }
 }
 cout<<"{\"status\":\"NO COUNTEREXAMPLE IN FINITE MODEL\",\"maximum_k\":"
     <<top<<",\"days\":"<<days<<",\"transitions\":"<<transitions<<"}\n";
}

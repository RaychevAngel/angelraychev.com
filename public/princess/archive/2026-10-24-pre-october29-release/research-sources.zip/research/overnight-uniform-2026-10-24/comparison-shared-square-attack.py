"""Challenge a shared physical orbit interface through the last square.
This is a local overapproximation, not a zero-origin or full-game theorem.
"""
from pathlib import Path
import importlib.util,json,time
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('rootclock',P/'root-shifted-clock.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
def psi(b,d,X):return X[1]+d,X[0]+d-(X[0]>b*b)
def orbit(b,d,X,t):
 S=b*b;out=[0,0]
 for i,x in enumerate(X):
  assert x>b*(b-1)
  j=max(1,(S-x)//d+2)
  if j%2!=(i+1)%2:j+=1
  out[i^(t%2)]=x+d*t-max(0,1+(t-j)//2)
 return tuple(out)
def run(b,d):
 H=b*(b-1);h0=(2*b+1)*(b+1);k=b+d;checks=0;bad=[]
 for i in range(1,d+3):
  for j in range(1,d+3):
   B=(H+i,H+j)
   if any(x<y for x,y in zip(psi(b,d,B),B)):continue
   Z=B;u=0
   while max(Z)-k<=H:
    A=tuple(z-k for z in Z)
    if min(A)>=0 and max(A)>=H-d+1:
     Q=max(A);Y=min(H+d+1,max(B))
     for extra in range(2*d-1):
      h=h0+extra;tau=r.faster_middle(b,d,h,Q,Y,True);X=orbit(b,d,B,tau+1)
      margin=max(X[p]+A[p^1]-h for p in(0,1));checks+=1
      if margin<0:bad.append(dict(b=b,d=d,B=[x-H for x in B],A=[x-H for x in A],j=u,Q=Q-H,Y=Y-H,extra=extra,tau=tau,margin=margin))
    Z=psi(b,d,Z);u+=1
 return checks,bad
if __name__=='__main__':
 t=time.process_time();checks=0;bad=[]
 for d in range(1,11):
  for b in range(200,200+2*d):
   c,z=run(b,d);checks+=c;bad+=z
  print(d,checks,len(bad),flush=True)
 out=dict(status='LOCAL_INTERFACE_FALSIFICATION_ONLY',checks=checks,bad=bad,cpu=time.process_time()-t);Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out['cpu'],bad[:4])

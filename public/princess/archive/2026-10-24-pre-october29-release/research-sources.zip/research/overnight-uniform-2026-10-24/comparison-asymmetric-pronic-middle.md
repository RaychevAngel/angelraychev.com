# Asymmetric pronic cuts: one-day transport with at most one missing room

24 October 2026. Conditional theorem, independently reviewed.
The two physical boundary cuts are intentionally different:

    H=b(b-1), early cutoff H-d+1, late cutoff H.

Assume b>=200,1<=d<=b-1,k=b+d,w<=n,wn even. Retained endpoint ranges are

    H-d+1<=Q<=H,          H+1<=Y<=H+d+1.

The explicit guards are Y<=H+d+1<=b^2, Q>=H-d+1>(b-1)^2,
and E-L>=2b+1>d in the odd case. Also Q+Y<h automatically from the
minimal board area, so the middle passage is nonempty.

Let tau be the ordinary necessary middle clock from equal Y to maximum h-Q,
or the larger nine-feature clock. Let C be any physical backward pair with
max C>=Y and Phi(C)>=C, and let A be any early pair with max A>=Q.
No spread or common-origin condition is required for the first two conclusions:

* If w is even, the phase-compatible meeting holds by tau+1.
* If w is odd, by tau+1 the minimum physical backward coordinate is at least
  h-Q-1. Hence the largest phase-compatible sum with A is at least h-1.

For odd width, if the progress and spread assumptions of the accepted shifted
middle theorem also hold, a full meeting holds by tau+2. Thus the asymmetric
cut retains the previous two-day fallback while giving a sharper signed
one-room interface.

## Aligning the input costs one day

All physical scalar maps are at least the identity in this feasible budget
range (with terminal clipping). Since Phi(C)>=C, one update has minimum at
least max C. Indeed, the output descended from the larger input is no smaller
than that input, and the other output is no smaller than the same larger
coordinate by the progress assumption. Consequently

    Phi(C)>=(Y,Y).

This elementary alignment includes arbitrarily unequal progressive inputs.

## Even width

For every pretarget input q>H and q<h-Q, both low/high relaxed costs are
at least b, and a width-cap edge costs exactly b. The target deficit remains
at least H-d+1>(b-1)^2. In particular when the deficit D lies between
Q and H, gamma=R(D)=b and delta=rho(D)=b-1. The minimum high-column
costs are gamma+1-(gamma-delta), gamma, and delta+1, all exactly b;
there is no bare rho(D) branch. Thus the faster equal-seed ordinary comparator stays
equal and advances by d each step. Both physical phases have exactly that
same drift throughout the passage, or can only be accelerated by the ignored
branches. Starting after the alignment day proves that both coordinates
reach h-Q by the ordinary first-hit time plus one. Pairing with whichever
early coordinate is >=Q gives a meeting for either diagonal parity.

## Odd width

Y>H eliminates the low-pronic one-room reset. The accepted unshifted central
comparison applies: the equal relaxed maximum is the maximum of the physical
constant-pair recurrence, and its pair spread is at most one. The sole possible
central improvement is excluded by E-L>=2b+1>d.

The target can lie above U=h-H by at most d-1. As in the accepted shifted-cut
proof, once the relaxed maximum first reaches x>=U, either it has reached
the target or the next constant update already reaches it because
x+d-1>=U+d-1>=h-Q. Therefore the new high-pronic edges cannot advance the
first-hit clock. At that clock the lower physical equal-seed minimum is at
least h-Q-1. Alignment and monotonicity prove the stated one-room interface.

For d>=2 a further physical update increases every coordinate of that lower
bound by at least d-1>=1, so a full meeting holds at tau+2. For d=1, the
small finite residue argument from the accepted shifted-cut proof applies
unchanged: its Y-range H+1..H+2 is exactly the present range. Alternatively
`comparison-asymmetric-pronic-small.py/.json` repeats d1 andd2 explicitly,
with2,208 checks in14 cells and minimum margin zero. Its parameter reduction
is the same proved b mod2d and target mod(2d-1) reduction. No new width sampling
is used to justify the theorem.

Progress of C makes its physical orbit coordinatewise nondecreasing, allowing
transfer from the faster relaxed clock to the actual ordinary or nine clock.

## The remaining signed-credit question

With accepted one-day shifts at both physical boundaries, the even-width
conclusion gives a conditional total P<=J_asymmetric+4 immediately, including
the final inspection. For odd width it leaves exactly one room, rather than
an unspecified extra phase day. That missing room is eliminated if, for example,
the shifted physical early pair has maximum at least Q+1, or if a stronger
matched phase relation at the two endpoints supplies the same credit.

These are conditional consequences of the boundary-clock theorems. This note
does not assert their extension to the new cuts or any full-game uniform gap
until the separate physical-history assembly is accepted.

"""Exact tiny folded-grid diagnostic for full-start early-hole dominance.
No extrapolation beyond checked boards. Uses the accepted polarization normal form.
"""
from pathlib import Path
import importlib.util,json,time
P=Path(__file__).resolve().parent
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
M=load('counter',P/'upper_nested_counter.py')
G=load('prefix',P.parent/'uniform-history-2026-10-23'/'root-prefix-clock.py')
def run(w,n,k):
 b=w//2;h=b*n;V=(1<<h)-1;adj=[]
 for x in range(b):
  for y in range(n):
   adj.append(sum(1<<(i*n+j)for i,j in ((x-1,y),(x+1,y),(x,y-1),(x,y+1))if 0<=i<b and 0<=j<n)|(1<<(x*n+y)if x==b-1 else 0))
 N=M.hood_table(adj);pc=[x.bit_count()for x in range(1<<h)];layer={(V,V)};parent={};prefix=[h,h];rows=[]
 for t in range(1,2*h+1):
  nxt=set()
  for a,b in layer:
   for r in M.subs(a):
    cost=pc[a]-pc[r]
    if cost>k:continue
    for s in M.subs(b&r):
     if cost+pc[b]-pc[s]>k:continue
     q=(N[r],N[s])
     if q not in nxt:parent[t,q]=((a,b),(r,s));nxt.add(q)
  layer=nxt
  prefix=[G.neighborhood_size(w,n,(p+t-1)%2,max(0,prefix[p]-k))for p in range(2)]
  Qp=h-min(prefix)
  below=[(2*h-pc[a]-pc[b],(a,b))for a,b in layer if 2*h-pc[a]-pc[b]<h]
  Q,state=max(below,default=(-1,None));row={'day':t,'states':len(layer),'best_holes_below_h':Q,'best_prefix_holes':Qp};rows.append(row)
  if Q>Qp:
   path=[];cur=state
   for j in range(t,0,-1):
    old,sur=parent[j,cur];path.append({'before':old,'survivor':sur,'after':cur});cur=old
   path.reverse();return {'w':w,'n':n,'k':k,'status':'counterexample','rows':rows,'path':path,'adj':adj}
  if Qp>=h:return {'w':w,'n':n,'k':k,'status':'no early counterexample','rows':rows}
 raise AssertionError('clock guard')
if __name__=='__main__':
 start=time.process_time();out=[]
 for args in [(4,3,3),(4,4,3),(4,4,4)]:
  # Prefix API assumes sorted side lengths; swap only its geometry for 3x4 below.
  if args[0]>args[1]:continue
  row=run(*args);out.append(row);print({k:v for k,v in row.items()if k not in('rows','path','adj')},flush=True)
 P.joinpath('upper-early-holes-check.json').write_text(json.dumps({'rows':out,'CPU_seconds':time.process_time()-start},indent=2)+'\n')

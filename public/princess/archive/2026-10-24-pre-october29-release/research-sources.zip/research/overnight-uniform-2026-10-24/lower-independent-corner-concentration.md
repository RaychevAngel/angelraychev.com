# Exact concentration of independent quadrant-corner processes

24 October 2026. Algebraic theorem proposed for independent review.
This does not yet represent every physical rectangle history: the missing
step is a valid fixed-corner decomposition through geometric relocation.

For nonnegative integers z define

    F(z)=z-ceil(sqrt(z)),    G(z)=z-rho(z),

with both root functions zero at zero. These are nondecreasing and F<=G.
They are the two quadrant erosion inverses, alternating with the physical
checkerboard phase. Consider any finite prescribed daily quota word k_t.
Start any finite collection of independent corner processes at zero. Each
has one of the two fixed phase conventions, receives a nonnegative daily
quota, and updates by F or G accordingly. The sums of its quotas on day t
are at most k_t. Then at every terminal time T its total output is at most
the larger of the two single-corner outputs obtained by giving the entire
word k_t to one alternating process starting at zero.

## Root inequalities

Both F and G are superadditive. For F this follows from
ceil(sqrt(x+y))<=ceil(sqrt(x))+ceil(sqrt(y)). For G, if rho(x)=a and
rho(y)=b, then x+y<=a(a+1)+b(b+1)<=(a+b)(a+b+1).

More strongly, whenever x>0 and y>=0,

    F(x)+G(y)<=F(x+y).                               (1)

Indeed put s=ceil(sqrt(x))>=1 and t=rho(y). Then
x+y<=s²+t(t+1)<=(s+t)², since t<=2st. Thus the total root cost on the
left is at least ceil(sqrt(x+y)). By symmetry the same assertion applies
whenever the input to the F-updated component is positive.

## Reduction to two opposite phase conventions

Merge the components with the same phase convention by superadditivity,
using the sum of their assigned quotas. This can only increase their total
output. There remain two independent processes with opposite phases.

Fix the terminal time T. In either process, let z be its last zero state
at or before T. Replace all its assigned quotas before that state by zero.
The modified process remains zero until z and agrees exactly thereafter.
If it is zero at T, remove all its quotas. This does not change the terminal
output or increase any daily quota.

Consequently each retained process has one permanent activation: it is zero
before activation and positive at every later state through T. Before the
second activation only one process matters. Follow the alternating single-
corner process with the phase of that first active process, giving it the
entire quota word. Monotonicity makes its state at least the active state.

At the second activation both update INPUTS are positive: the old process
already has positive state, and the new process must receive enough quota
to obtain positive output. The same holds at every subsequent update.
Equation (1) therefore bounds their next total by F(old total+k_t).
Whichever phase the chosen single-corner process currently uses, its map
is at least F, so it continues to dominate the two-process total by induction.

The phase may depend on T and on the allocation, which is why the theorem
uses the maximum of the TWO fixed single-corner trajectories at T. No phase
is changed during the dominating trajectory. The argument works for every
quota word, not only constant budgets.

## The precise missing physical implication

Same-color hole components in a subcritical rectangle have valid quadrant
cardinality profiles, but their corner labels can change across days, and
neighborhoods at distinct corners can interact. Therefore assigning their
sizes afresh to the independent processes on each day would be invalid.
The theorem applies only after proving a causal, budget-preserving fixed-
corner decomposition, or proving that any failure of such a decomposition
has already incurred enough loss to restore the numerical domination.

The known12x12 transport counterexample to full fixed-anchor dominance occurs
after total holes exceed b(b-1). It is not a counterexample to a decomposition
restricted to the early boundary, but neither is it evidence that such a
decomposition always exists there.

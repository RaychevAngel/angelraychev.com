# Credit from bad moves near the critical width

24 October 2026. An arithmetic lemma for the proposed sharper boundary
comparison. Independently accepted in `upper-paired-bad-credit-review.md`,
including the sharper interval count below. This does NOT yet extend
the accepted early/late physical clock: the geometric joining, phase
changes, and boundary interfaces are separate obligations.

Write R(z)=ceil(sqrt(z)), rho(z)=min{r>=0:z<=r(r+1)}, and

    G(x)=x+k-rho(x+k), F(x)=x+k-R(x+k).

Their exact lower inverse thresholds at a positive integer z are

    G(x)>=z iff x>=z+R(z)-k,
    F(x)>=z iff x>=z+1+rho(z)-k.                 (1)

Let X_t follow alternating F,G. Let q_t be an integer target history,
and let C,v>=1. Stop if X_t-q_t>=C. Assume throughout the still-running
comparison:

* X_0>=q_0 and X_(t+1)>=X_t+v;
* r_t=R(q_t)>=C for every positive-time target;
* every transition satisfies q_(t-1)+k>=q_t+r_t+1;
* a specified finite set B of at most m root values contains every
  transition not satisfying the stronger inequality
  q_(t-1)+k>=q_t+r_t+2.

Then a block of

    2(C+m ceil(C/(2v)))                          (2)

transitions cannot finish with X_t-q_t<C. This is a statement about
whole compatible numerical histories, including nonmonotone q_t.

## Proof

At a comparison step put c=X_(t-1)-q_(t-1), so 0<=c<C. For
z=q_t+c, we have R(z)<=r_t+1 and rho(z)<=r_t, because
q_t<=r_t^2 and c<=C-1<=r_t-1. The two inverse thresholds in(1)
are therefore at most z+r_t+1-k. The assumed input inequality proves
X_t>=q_t+c in either phase. Hence the true room credit never decreases
before it reaches C.

For a G step, one extra room is obtained if

    q_t+c+1<=r_t^2.                             (3)

Indeed its inverse cost is then z+R(z)-k with z=q_t+c+1 and
R(z)<=r_t. This is at most q_(t-1)+c. Outside B, the stronger
input inequality instead proves one extra room in EITHER phase:
for z=q_t+c+1 both inverse costs are at most z+r_t+1-k.

Thus a G step which does not increase the credit must have r_t in B
and q_t+c+1>r_t^2. Since c<=C-1, its target has

    r_t^2-C+1<=q_t<=r_t^2.

If that step does not increase credit, preservation and integrality imply
that its new credit is exactly c. Hence its reference output is q_t+c.
Failure of(3) and c<C therefore place that output in

    [r_t^2, r_t^2+C-1].                        (4)

For a fixed root, the reference advances by at least2v between two
G steps. The interval(4) has length C-1, so it can contain at most
floor((C-1)/(2v))+1=ceil(C/(2v)) such steps. This remains true if the
physical target repeatedly leaves and returns to that root bin: the
reference itself is strictly increasing.

There are therefore at most m ceil(C/(2v)) G steps failing to gain one
room. Among the number(2) of alternating steps there are exactly
C+m ceil(C/(2v)) G steps. At least C gain one room, contradiction.
This proves(2) without assuming monotonicity of the target history.

## Proposed nearcritical application, not yet an assembled theorem

For excess d=k-b in1..19, one tentative choice is

    C=d+5, v=d, B={b-5,...,b-1}.

The duration in(2) is at most58 throughout this finite excess set;
it is42 at d1. The earlier weaker interval count gave72. All reference
values must remain within the valid quadrant
or verified finite-board regime; v=d is a hypothesis to be checked.

Old bad events with surplus at least r+4 supply the stronger input
inequality. The new zero-slack convention calls only surplus r good
near the width, so its bad events supply the weaker inequality in
the last five root bins. The separately derived geometric switching
charges are long enough at large b to pay the58-step bound.

Missing interfaces include a local rewind of cost at most C, changes
between the old and new good-event definitions, excursions back into
the old region, and the time-reversed late argument. These are not
consequences of the arithmetic lemma alone.

# A parameterized family of stronger necessary boundary clocks

24 October 2026. Ordinary proof candidate submitted for independent review.
This extends the accepted slack-four boundary argument; no frozen source is
changed and no full capture-time gap is asserted by this note alone.

Let the board have even area, w<=n, b=floor(w/2), k=b+d, d>=1. Choose
integers s>=2 and R>=0, and put

    r0=R+1, D=k-r0, H=b(b-1), A=(b-1)^2,
    E_s(r)=r²-(2s+3)r-5s²-7s,
    L_s(r)=r²-(2s+4)r-5s²-8s,
    C_E=d+s+2, C_L=d+s+1,
    g_E=s if D<=r0, and s-1 otherwise,
    B_E=4s+6 if d=1, and 2(d+s+2) if d>=2,
    B_L=2C_L-1+ceil((D-C_L+1)/s).

The following explicit arithmetic conditions suffice:

1. k>=100, R<=floor(3k/5), b>=2d+3s+3,
   C_E<=r0<=b-s-1, C_L<=D<=2r0+1;
2. r0>=s+2, 2((r0-1)²+1)>(r0+s)²,
   2r0>(s+2)²+2, and (b-s-1)²+D<=H;
3. g_E(ceil(E_s(r0)/(2k))-1)>=D and
   s(ceil(L_s(r0)/(2k))-1)>=D;
4. ceil(E_s(b-s-1)/(2k))-1>=B_E and
   ceil(L_s(b-s-1)/(2k))-1>=B_L.

No hidden optimization is called a numerical operation here: these are
ordinary finite arithmetic sufficient tests for an intermediate evaluator.
One can retain every admissible (s,R), taking the strongest necessary clock.
An empty admissible family simply leaves the earlier accepted bounds intact.

Under these conditions the SAME early and late hybrid clocks, with scalar
cutoff R², are necessary through the accepted asymmetric pronic cuts:

* early total holes first crossing H-d+1 end at Q in[H-d+1,H];
* the late clock from any ceiling k<Y<=H+d+1 is necessary for first
  reaching signed residual at most k.

The early injection cap is G(R²), and the late cap is R²+k, exactly as in
the old evaluator. No new independent phase reset is permitted. The
previous all-target physical +1 domination remains valid, because the
new scalar injection caps are no larger than those at floor(3k/5).

## Dominant components with variable slack

Call an old event good when r<=b-s-1 and its actual surplus sigma<=r+s.
Call a near event good when b-s<=r<=b-1 and sigma<=r. All other
subcritical events are bad. Early targets above A and at most H are
neutral, with surplus at least b, as in the accepted pronic extension.

At an old good event sigma<=b-1. The small-side and concentration
conditions follow from q>=(r-1)²+1 and condition2. Their quadratic
differences increase for r>=r0. If nondominant surplus were at least
s+2, the decreasing small-root branch would give

    q<=(sigma-s-2)²+(s+2)²
      <=(r-2)²+(s+2)²<(r-1)²+1,

a contradiction. Hence nondominant surplus is at most s+1, and at most
(s+1)² cells lie outside a unique physical dominant corner/component.
The exact phase profile of total mass is preserved: its capacities are
sigma² or sigma(sigma-1), with no remainder error. Near good events have
the accepted stronger zero-slack conclusion and at most one outlier.

The physical fixed-matching change-of-corner charges therefore give

    early: Delta*k>=E_s(r)/2,
    late:  Delta*k>=L_s(r)/2.

Here the early root is the new root and the late root the old root.
These identities follow by inserting two outlier allowances (s+1)²
into the accepted half-ball intersection formulas. For late cohort
changes the stronger charge is at least
2b²-(s+1)(s+2)-(b-1)²; this exceeds L_s(r)/2 throughout the admitted
range. Indeed b>=3s+5 and r<=b-1 suffice. Early cohort changes also have
the previously accepted stronger charge. No artificial merged support is
assigned a geometric corner.

## Old bad blocks pay their phase changes

At an early old bad transition, sigma>=r+s+1. Cap reference room lead
at D. For z=q+c', 0<=c'<=D, condition D<=2r0+1 gives z<=(r+1)², so
both inverse phase costs are at most r+2. A step therefore earns s-1
rooms capped at D. If D<=r0, z<=r²+r and both costs are at most r+1,
giving the stronger gain s. All virtual targets fit genuine quadrants
by condition2.

At a late old bad transition, the unshifted physical survivor is at most
the actual survivor q, so either reference expansion cost is at most
r+1. The lead gains at least s rooms, without the early inverse shift.

The quadratics E_s and L_s increase for r>=r0. Condition3 therefore
pays the full rewind cost D on every all-old intervening bad block.
The rewind and fast-entry arguments are exactly those of the accepted
hybrid proofs; only the number of rooms earned and the scalar cutoff
have changed.

## A sharper early near-interface bound

Fix the root r of the later good event, with b-s-1<=r<=b-1. Its target
is at most r². Let

    C_r=k-r+1, v_r=k-r-1,
    m_r=max(0,r-(b-s)+1).

Track the same reference only until either its lead reaches C_r or its
value exceeds r². The latter condition already settles this later good
event: freeze its index, and use that index or the next one to obtain
either phase by the new actual day. The crossing occurred during an
interior transition, so that possible advance is paid by the later good
day itself. There is no added forward reference day.

Until this stopping condition, a bad target with root greater than r,
or an early neutral target, forces reference value >r² by ordinary
zero-credit domination and settles the case immediately. Thus only the
m_r near roots b-s,...,r can produce failed G-step credit. In particular
there is NO extra neutral-wall interval in this target-root argument.

The paired bad-credit lemma applies with C_r and v_r. We have C_r<=r0;
virtual targets remain below r²+C_r<=H; and while the reference input is
at most r² its input plus k is at most(r+1)², because k<=2r follows
from condition1. Every move gains at least v_r. Consequently a block of

    2(C_r+m_r ceil(C_r/(2v_r)))

bad transitions either settles the target by overshoot or earns C_r
rooms. This number is at most B_E: for d>=2, v_r>=2 and the ceiling is
one, giving exactly2(d+s+2); for d=1 only r=b-1 has v_r=1, giving
4s+6 there, and all other roots give2(s+3).

At the final good transition an initially wrong phase loses at most one
room of this lead. The remaining k-r rooms pay its target rewind, since

    rho(Q-1+k)>=r,  k-rho(Q-1+k)<=k-r.

The first inequality follows from Q>(r-1)² and k>=r. Condition4 and the
early matching charge supply all B_E interior transitions.

If the later good root is at most b-s-2, either an earlier/intermediate
near target already put the monotone reference above its target, or the
whole intervening block is old. These are precisely the two accepted
retreat cases, now with b-s in place of b-4. Arbitrary physical retreats
therefore introduce neither a new reset nor a new phase allowance.

## The late near-interface count

Every bad late transition preserves lead, and every second one earns at
least one room. An old bad transition earns s rooms. At a near source
or target a rewind costs at most C_L: its actual survivor exceeds
(b-s-1)², and after subtracting k its root is at least b-s-1.
Condition b>=2d+3s+3 supplies both this local bound and the retreat gap

    (b-s-1)²+1-((b-s-2)²+k)
      =b-d-2s-2>=C_L.

Thus a transition from an old low good event into the near range can
pay at that source. Otherwise the earlier good root is at least b-s-1,
and the late geometric charge in condition4 supplies at least B_L bad
transitions. If a near bad transition has index j>=2C_L, paired credit
already pays C_L there. If not, the final old segment gives at least

    C_L-1+s(B_L-2C_L+1)>=D,

paying the global rewind. This is the accepted mixed-block argument,
including excursions, with its exact gain s retained.

The last-crossing and terminal scalar continuation proofs are unchanged.
No source/corner identity is switched freely, and no contribution is
counted twice.

## A nonvacuous example and evidence boundary

For b=224,d=1,k=225,s=9,R=100, all displayed tests hold. The old early
charge is8*(17-1)=128>=D=124; the late charge is9*(17-1)=144>=124.
At the old/near interface r=214, the available counts are90 early and90
late, whereas B_E=42 and B_L=34. This validates a substantially smaller
scalar cap if the proof passes independent review. The theorem is the
parameterized test above, not an extrapolation from this example.

This note establishes neither a new physical strategy nor equality of
the necessary and sufficient capture bounds. Its purpose is a sound
uniform family of stronger intermediate lower evaluators.

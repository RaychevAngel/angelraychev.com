# A stronger early necessary clock using the actual ordinary envelope

24 October 2026. Proposed for independent review. This replaces the early
all-G scalar injection by the MAXIMUM of the two ordinary zero-origin
quadrant phases. It retains one free phase choice; it does not prove that
either fixed physical phase dominates every early history.

Let w<=n be even-area, b=floor(w/2), k>=b+1. Let an already accepted early
history theorem use cutoff R, L=R² and Z=G_k(L), where

    G_k(x)=x+k-rho(x+k),   F_k(x)=x+k-ceil(sqrt(x+k)).

The ordinary pair is P_0=(0,0),

    P_(t+1)=(G_k(P_t[1]),F_k(P_t[0])).

Assume the following additional, explicit arithmetic guards:

    Z+k<=b²,
    W=G_k(Z-1),  Rhat=ceil(sqrt(W))<=b-1,
    J=min{t:min(P_t)>=Z},  J+2Rhat<=w+2.             (1)

No bound on J is needed beyond this exact arithmetic test. In particular,
parameter-dependent computation here is allowed as an intermediate result.

## The all-time clipped envelope

For EVERY actual two-cohort full-origin history, with total holes Q_t,

    min(Q_t,Z)<=min(max(P_t),Z)                       (2)

at every elapsed inspection-and-move time t.

Suppose t is the first failure. Then max(P_t)<Z and Q_t>max(P_t).
By monotonicity max(P_(t-1))<Z, and the preceding clipped inequality
therefore gives Q_(t-1)<=max(P_(t-1))<Z. In particular

    Q_t<=Q_(t-1)+k<=Z-1+k<b²+1.

The accepted small-side total-hole profile gives original surplus at least
ceil(sqrt(Q_t)): if the surplus is >=b this is automatic; otherwise the
small/co-small separation excludes the co-small alternative since Q_t<=b²
and h>=2b². Thus Q_t<=G_k(Q_(t-1))<=W.

This is now a first ordinary-envelope violation at a target at most W,
with the previous total no larger than the ordinary maximum. The accepted
causal-boundary classification says that it must be a zero-slack,
own-corner event: its holes form one actual component in one cohort,
of radius at most2r-2, r=ceil(sqrt(Q_t))<=Rhat<b.

Since max(P_t)<Z, we have t<J. Hence

    t+2r-2<=J-1+2Rhat-2<=w-1.

Its complete backwards cone is a genuine quadrant. The matching ordinary
phase bounds Q_t, contradicting the supposed violation. This proves(2).
Notice that the clipped first-failure argument explicitly handles earlier
excursions: before the first failure, an excursion above Z is impossible
while the ordinary maximum is below Z.

## The strengthened hybrid

Define E_0=(0,0) and

    M_t=min(Z,max(P_t)),
    E_(t+1)[0]=max(M_(t+1),G_k(E_t[1])),
    E_(t+1)[1]=max(M_(t+1),F_k(E_t[0])).             (3)

Both coordinates are nondecreasing in time, and ordinary moves after any
injection are retained. This is no larger than the old all-G hybrid,
because max(P_t)<=S_t for S_0=0,S_(t+1)=G_k(S_t).

In every parameter/endpoint range of the already accepted early history
theorem, its necessary clock remains valid with(3). If the terminal cut
lies below L, the actual first-crossing target is <=Z and(2) immediately
injects it into BOTH coordinates at its actual elapsed time. Otherwise
take the entry after the last actual state Q<=L. Its target A is <=Z.
Equation(2) injects A into both coordinates at that SAME entry time,
so either alignment with the next good event is available. The accepted
good/bad and paid-rewind proof then applies unchanged, beginning with
that actual index. Its used index never exceeds actual elapsed time.

This argument does not replace a zero-origin ordinary pair by two separate
physical constructions. E is a necessary relaxation; its equal injection
is deliberately allowed. The strengthening removes excess fast scalar
capacity without claiming to remove the remaining phase reset.

The optional endpoint feature-or-credit consequence is preserved: the
accepted tracked reference is still embedded in E, and increasing its
coordinate preserves that alternative.

## Dependencies and open issue

The physical cone and first-sensitive-event facts are independently accepted
in lower-causal-quadrant-boundary.md / upper-causal-quadrant-review.json.
The slow tracking is the already accepted early hybrid theorem and whichever
cutoff extension supplies R. Equation(1) is an ADDITIONAL guard; this note
does not automatically extend every cutoff to every rectangle.

The evaluator still permits a common two-phase injection. Removing it
requires either a matching-phase full-total causal bound or a rigorous
credit transfer through the first corner convention choice. That exact
boundary-history problem and uniform zero gap remain unresolved.

from math import isqrt

def R(x):return isqrt(x-1)+1 if x else 0
def rho(x):
 r=(isqrt(4*x+1)-1)//2;return r+(r*(r+1)<x)
def F(x):return x-R(x)
def G(x):return x-rho(x)
for k in range(2,61):
 a=b=0
 for t in range(1,101):
  aa,bb=G(b+k),F(a+k)
  # only generic own-cap and both2wedge hypotheses, no attainable-state assumptions
  for x in range(a+1):
   ymax=b
   if a>=2:ymax=min(ymax,2*(a-x))
   for y in range(ymax+1):
    if b>=2 and x>2*(b-y):continue
    if x+y>max(a,b):continue
    # strongest allocation check endpoints across u
    for u in range(k+1):
     xx,yy=G(y+k-u),F(x+u)
     if (aa>=2 and yy>2*(aa-xx)) or (bb>=2 and xx>2*(bb-yy)):
      print('FAIL',k,t,(a,b),(x,y),u,(aa,bb),(xx,yy),flush=True);raise SystemExit
  a,b=aa,bb
  if a>180:break
 print('ok',k,flush=True)

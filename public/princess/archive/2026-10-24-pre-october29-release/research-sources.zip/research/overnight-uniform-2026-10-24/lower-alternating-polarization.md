# Exact alternating polarization and a nested-layer folded game

24 October 2026. Ordinary theorem, submitted for independent review.
No literature-priority, complete classification, or Lean claim is made.

## 1. Graph hypothesis and the alternating operator

Let G be a finite bipartite graph with classes V0,V1, and suppose sigma
is an involutive graph automorphism which exchanges the two classes.
Write N for open neighborhood. For p in {0,1}, write a set S as
A union B, with A subset Vp and B subset V(1-p). Define

    C_p(S) = (A union sigma(B)) union (B intersect sigma(A)).     (1)

The first displayed part belongs to Vp and the second to V(1-p).
Thus each sigma-pair containing exactly one vertex is filled on its
Vp side; empty and doubly filled pairs remain unchanged.

Each C_p is monotone, cardinality preserving, and idempotent. Its fixed
sets satisfy sigma(B) subset A. The essential neighborhood relation is
TIME ALTERNATING:

    N(C_p(S)) subset C_(1-p)(N(S)).                            (2)

Indeed the V(1-p) part of the left side is
N(A union sigma B)=N(A) union sigma N(B), exactly the favored part on
the right. Its Vp part is
N(B intersect sigma A) subset N(B) intersect sigma N(A), the other
part on the right. This proof uses only neighborhood monotonicity,
preservation of unions, and commutation with sigma.

It is generally false to keep the same p after movement. The current
favored physical color alternates, so the favored INITIAL-parity cohort
is the same throughout the actual game.

## 2. Compression of a complete physical strategy

Let p_t=p_0+t mod2, counting t unsuccessful moves already made. Assume
the initial belief A_0 is fixed by C_(p_0). For any inspection strategy
with predetermined daily budgets k_t, there is a strategy from A_0 with
no larger useful inspections on any day, whose beliefs and survivors
are fixed by the corresponding C_(p_t). In particular its capture time
is no greater. The full initial board is fixed, so its unrestricted
optimum is attained inside this nested-cohort family.

To prove this, let A_t be the original pre-inspection belief and R_t its
survivors, so A_(t+1)=N(R_t). Maintain a new actual belief B_t, fixed by
C_(p_t), and contained in C_(p_t)(A_t). Inspect

    B_t \ C_(p_t)(R_t).

Monotonicity and cardinality preservation give useful probe count at most
|A_t|-|R_t|, hence within the same daily quota. The new survivors are
B_t intersect C_(p_t)(R_t), a fixed set: intersections of two fixed
sets are fixed by monotonicity and cardinality preservation. Their
neighborhood is fixed by C_(p_(t+1)), since (2) gives containment in
its own equal-cardinality compressed image. Moreover (2) ensures the
new neighborhood is contained in C_(p_(t+1))(A_(t+1)), closing induction.
On the original terminal day R_t is empty, so the new strategy captures
as well. Conversely every normalized strategy is actual physical play.

This theorem allows varying quotas and both initial-parity cohorts
simultaneously. It neither restricts each cohort to a prefix nor asserts
that one cohort stays full until the other disappears.

## 3. Exact two-layer quotient

The sigma-orbits have size two. Choose V0 as their representatives and
let K be the symmetric relation on V0 defined by

    u K v iff u is adjacent in G to sigma(v).                  (3)

It is symmetric because sigma is an involutive automorphism. It may
have loops: u K u exactly when the two vertices of the pair are adjacent.
For subsets use K(X) for their relational neighborhood, including any
such loops.

Normalize coordinates after each move by sigma when needed, so the
current favored class is represented on V0. A fixed belief is exactly
a pair X,Y subset V0 with Y subset X: X is the favored-cohort support,
and Y is the reflected other-cohort support. A fixed survivor pair is
R,S with R subset X, S subset Y, and S subset R. The transition is

    (X,Y) -> (K(R),K(S)),
    cost = |X\R|+|Y\S|.                                    (4)

The two layers use THE SAME operator K. This follows either by direct
lifting in (3), or from commutation of N with sigma and the alternating
coordinate normalization. Since S subset R, the output remains nested.
Capture occurs exactly when both survivors are empty.

Thus the original full-board capture problem equals this nested-layer
game, starting at (V0,V0), for every daily quota word. A state is a
function with values 0,1,2 on V0: its multiplicity is one on X\Y and
two on Y. Movement is levelwise K, not multiplication of a numerical
mass matrix; overlaps in a neighborhood count only once per layer.

This gives an exact state bound 3^h instead of 4^h on an even-area board
of area2h. More importantly, it preserves a pointwise order between the
two cohorts and turns their movement into the same folded operator.
This does not by itself give an efficient exact evaluator or prove
that the known prefix upper strategies attain the unrestricted optimum.

## 4. Every even-area rectangle has an explicit folded grid

Reflect any even side2b of a rectangular board2b by n. Reflection
exchanges checkerboard parity and is an involutive automorphism, so
Sections1--3 apply. Its vertex orbits can be indexed by the b by n
half-rectangle. Under this geometric indexing, K has:

* all ordinary horizontal and vertical grid edges in the half-rectangle;
* a loop at every vertex along the fold boundary x=b-1;
* no other edges or loops.

Away from the fold each physical grid edge is paired with its reflected
copy and gives the corresponding quotient grid edge. The physical edge
between (b-1,y) and (b,y) joins the two members of one orbit and yields
the stated loop. Conversely every original edge has one of these forms.

For a two-row board, every quotient vertex is on the fold boundary:
K is the closed neighborhood of a path, agreeing with the earlier
prism reduction. At larger width, loops occur only on one boundary,
which is exactly the new geometric complication.

The shorter side need not be the even one. On an odd-by-even board,
reflect the even longer side and use the corresponding half-rectangle.
Thus this exact normal form covers ALL even-area rectangles, not just
even widths. Odd-by-odd rectangles already have their separate exact
prefix reduction.

## 5. Combining several color-swapping involutions

If sigma_1,...,sigma_m are such involutions, their C_p operators can be
composed. Monotonicity lets (2) pass through a composition, with the
same order at phase1-p. Every changing C_p strictly increases the
number of occupied vertices in the favored color. Hence h+1 complete
cycles through the list suffice to reach a common fixed set uniformly
over all initial subsets. Use this fixed number of cycles, not a
set-dependent stopping time. The resulting two alternating operators
are monotone, cardinality preserving, idempotent, and satisfy (2).

The strategy proof therefore supplies the stronger common normal form.
For a rectangle with both sides even one can include reflection in
each axis. This is an optional strengthening; no claimed state-count
or exact capture-time simplification from the two-reflection version
is needed for the single-fold theorem above.

## 6. Next exactness question

The missing step is now an exchange or compression theorem for the
nested multiplicity layers under a grid neighborhood with one looped
boundary. Any proposed simplification must preserve the cost in (4),
not merely minimize |K(R)| and |K(S)| independently. The prior partial-
prefix and varying-budget counterexamples remain valid warnings against
that weaker inference. The present normal form is exact without such
an additional claim.

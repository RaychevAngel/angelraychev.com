# A two-day middle comparison at the shifted pronic cut

24 October 2026. Candidate uniform conditional theorem, submitted for independent
review. The physical boundary necessity at this cut is a separate obligation.
This theorem does not identify the prefix construction with the game optimum.

Write b=floor(w/2), k=b+d, h=wn/2, and H=b(b-1). Assume w<=n,
wn even, b>=200 and 1<=d<=19. Set the shifted boundary cut H'=H-d+1.
Take boundary endpoints

    H-d+1 <= Q <= H,       H-d+2 <= Y <= H+2.

Let tau be the first layer at which the ordinary three-corner necessary
backward frontier, initialized equally at Y, reaches maximum h-Q. Replacing
this clock by the larger accepted nine-feature clock is permitted.

Let C be the labeled physical backward-prefix pair and A the labeled forward
hole pair. Assume

    max C>=Y, max A>=Q, spread(C),spread(A)<=d+1,
    Phi(C)>=C, and Hf(A)>=A coordinatewise.

Here Phi is the accepted finite-board physical backward operator. Hf is the
ordinary quadrant forward operator

    Hf(x,y)=(y+k-rho(y+k), x+k-R(x+k)).

R is ceiling square root and rho(u) is the least r with u<=r(r+1).
The input progress assumptions hold for the actual hybrid boundary sequences
after their scalar caps have become inactive. They are explicit assumptions,
not consequences of an arbitrary spread estimate.

Then, with chi=(w+n-2) mod 2,

    max_p [Phi^(tau+2)(C)_p + A_(p xor chi)] >= h.       (T)

All quantifiers on b,n are unbounded. The finite certificate below concerns
residue classes of an exact affine reduction, not a sample of board widths.

## 1. Odd width: the faster equal-seed comparator

Let w=2b+1, so n is even and chi=1. Put L=b(b+1), E=h-b^2,
and U=h-H. The accepted unshifted three-corner relaxation discards source
caps and decreases ordinary inverse costs; it can only reach the target earlier.

For equal Y>H, the relaxed frontier remains equal and advances by d through
its first crossing of b^2. For Y<=H, the two initial relaxed updates are

    (Y,Y,Y) -> (Y+d,Y+d+1,Y+d+1)
            -> (Y+2d+1,Y+2d+1,Y+2d+1).               (1)

Every input after the first update exceeds H, and every input in (1) is below
b^2: d<=19 and b>=200 suffice. The formulas follow by substituting
R(q)=b and rho(q)=b-1 for the first input in the unshifted cost matrix.
The high branches cannot improve these low updates.

For the physical equal pair the same two updates end instead at

    (Y+2d,Y+2d+1).                                   (2)

After equal entry above b^2, the accepted central calculation in
`comparison-pronic-middle.md` applies. In particular E-L>=2b+1>d
excludes the sole exceptional central improvement. The relaxed maximum is
therefore exactly the maximum of the constant pair map

    (x,y) -> (y+d,x+d-1),                            (3)

starting from the equal low exit. Its pair spread is at most one.

There is a new terminal detail because Q may be below H. The target satisfies
M=h-Q<=U+d-1. Before the relaxed maximum reaches U, the previous central
calculation is exact. Let x be its first maximum >=U. If x<M, every projected
coordinate is at least x-1. The next constant-map maximum is at least
x+d-1>=U+d-1>=M. The extra high-pronic inverse edges available at q>=U can
therefore affect only a step which the constant comparator already uses to
reach M. They cannot reduce the first-hit clock. This includes d=1, where
M<=U and the additional case is empty.

Consequently the following entirely scalar recipe gives a valid faster clock
tau0<=tau: when Y<=H make the two-step replacement Y->Y+2d+1; advance an
equal pair by d through b^2; thereafter use (3) until its maximum reaches M.

## 2. Odd excess d>=4

Use the lower physical operator

    hatPhi(x,y)=(y+k-min(rho(y),b), x+k-min(R(x),b+1)).

It is coordinatewise no greater than Phi, has monotone 1-Lipschitz scalar
maps, and agrees with Phi before high-boundary acceleration. In the Y<=H
case, (2) loses only one room in one coordinate relative to the relaxed reset
(1). Monotonicity and 1-Lipschitzness preserve a sup-norm loss at most one.
Hence at time tau0 its equal-seed minimum is at least M-2. The Y>H case
has the stronger M-1 bound.

C has one ancestor at least Y, the other at least Y-(d+1). A has one
coordinate at least Q, the other at least Q-(d+1). Descendant pairing loses
at most one spread: either the two good coordinates match, or both mixed
matches lose at most d+1. Thus at tau0 the largest matched sum is at least
h-(d+3). Two physical updates preserve phase labels and increase each
coordinate by at least 2d-1, until clipping at h (which already wins).
For d>=4 the matched sum is at least h+d-4>=h.

Because Phi(C)>=C, physical iterates are coordinatewise nondecreasing. This
proves (T) also at tau+2 and at every larger necessary middle clock.

## 3. Clipping and finite input reduction for d=1,2,3

First clip each C coordinate at H+2 and each A coordinate at H. This only
weakens the desired meeting. Progress is preserved: a monotone separable
coordinate-swapping map preserves coordinatewise minima of two vectors, and
the two constant cap vectors themselves are progressive. The finite-board
Phi agrees with hatPhi throughout the clipped C box. Hf is the required
forward map on the clipped A box. Spreads cannot increase under clipping.

Now strengthen Y to max C and Q to max A. They remain in their displayed
endpoint ranges. Enlarging either seed or complementary target can only
shorten the necessary clock. Progress of C permits transfer back to the
original clock. It therefore suffices to examine exactly

    max C-H in [-d+2,2],      max A-H in [-d+1,0],
    both spreads in [0,d+1],  and both progress predicates.

These are finite boxes of integer offsets independent of b. The root formulas
in both progress predicates depend only on these offsets and d when b>=200.

## 4. Exact removal of the unbounded parameters

After two updates every C coordinate is strictly above H: its initial minimum
is at least H-2d+1, and both maps there advance by at least d. The model also
has all coordinates above H after at most two updates. Before b^2 all maps
then swap coordinates and add d. Two updates add 2d with no phase change.

Choose the unique b0 in [200,200+2d-1] with b0 congruent to b modulo 2d.
If b=b0+2dj, insert 2j low-region updates after the common initial two-step
transient. Relative to H, this advances every coordinate by b-b0. Since
b^2-H=b, this exactly compensates the increase in the distance to the square
wall. Those inserted updates stay strictly below the new square wall: after
insertion the remaining distance is the old distance, at least b0-4d-4>=184 for d<=3.
Consequently model and physical normalized square-wall states agree exactly,
with a common even time offset, after translating coordinates by b^2-b0^2.
The initial transients and all phase labels are preserved.

Beyond the square, two updates of (3), and of hatPhi once both inputs have
crossed the square, add s=2d-1 to each coordinate. Thus only the target residue
modulo s matters. The minimal allowed h at b0 is

    h0=2b0^2+3b0+1.

After the preceding width reduction, the transformed board area is at least
h0+4(b-b0), so it is >=h0. Choose the unique t in [0,s-1] matching its
residue modulo s. Removing an even number of central updates reduces it to
h0+t. Both model and physical streams are already in the constant central
region long before the representative target: its distance above b0^2 is
at least 4b0+1. For an explicit transient bound, after the first physical
maximum exceeds b0^2, its spread is at most d+2 and its minimum is at least
b0^2-d-1. Within at most 2(d+2) further updates both coordinates exceed
b0^2; throughout this transient the maximum is at most
b0^2+2d^2+5d<=b0^2+33. The relaxed model enters its constant phase sooner.
Since 4b0+1>=801, the removal does not touch either transient. The terminal-wall argument
in section 1 remains valid and does not require literal high accelerations
in hatPhi.

This proves exhaustive reduction to

    d in {1,2,3}, b0 in [200,200+2d-1], t in [0,2d-2],

and the finite input-offset boxes from section 3. The checker
`comparison-shifted-pronic-small.py` evaluates these integer rules exactly.
It checks 22,368 admissible pairs in 44 parameter cells. Every matched margin
at tau0+2 is nonnegative; the minimum is zero. Its JSON receipt records every
cell and a worst witness, making the finite arithmetic independently replayable.

## 5. Even width

For w=2b and either parity of n, every physical scalar map advances by at
least d, and the ordinary relaxed maximum advances by at most d once its
input exceeds H and before target h-Q. Indeed throughout this passage both
unshifted low/high root costs and width caps are at least b, while the
(source,target)=(1,1) cap of cost b is available. The terminal deficit is
at least H-d+1>(b-1)^2 under b>=200,d<=19, so no high branch falls below b.

If Y>H, equal physical and relaxed frontiers agree up to the target. Pairing
arbitrary boundary inputs loses at most d+1, while two physical updates add
2d. If Y<=H, the initial low transient can give the relaxed maximum at most
one additional room, by the same unshifted matrices as in (1); afterwards
all branches cost at least b and the physical scalar maps remain1-Lipschitz
until the target. The paired loss is at most d+2. Here d>=2, because the
allowed Y for d=1 is strictly greater than H, so 2d>=d+2. This proves (T)
for either diagonal parity without a residue certificate.

## Scope

This is a uniform middle comparison for all lengths and the specified finite
excess range, conditional on physical boundary endpoints and progress/spread
contracts. It is not a new full-game lower bound by itself. Existing larger-
excess middle comparisons cover complementary budget ranges. No new Lean
verification is claimed. The finite residue checker is an ordinary independent
arithmetic certificate whose parameter reduction must be reviewed together
with its code; passing a collection of representative widths alone would not
establish the theorem.

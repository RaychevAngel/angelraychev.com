# The ordinary layered-cut relaxation cannot preserve daily quotas

24 October 2026. A failure shield for a proposed flow-based exact approach.

Fix any nonempty board with N rooms and a horizon T. Its time-expanded
walk graph has one vertex for each room and day; a successful inspection
schedule cuts every directed length-T room trajectory. A usual fractional
vertex-cut formulation assigns nonnegative weights x(t,v), requires every
such path to have total weight at least one, and minimizes the maximum
daily load `max_t sum_v x(t,v)`.

The assignment

    x(t,v)=1/T

is feasible and has daily load N/T. It is also literally the average of
the T integral valid cuts which inspect the entire board on exactly one
of the T days. Thus it belongs even to the convex hull of valid cuts,
not merely to an accidentally weak path-inequality relaxation.

The actual integral daily budget does not tend to zero with T. It is at
least one on every nonempty board, and for the rectangular capture game
its established feasibility threshold is `floor(w/2)+1`. Therefore the
integrality ratio is unbounded as T grows, already on one fixed board.
Adding the layer-load constraints destroys the relevant integrality of
the ordinary cut problem. Spatial planarity cannot rescue this particular
relaxation; the same counterexample works on a path.

This does not rule out a more structured discrete surface or flow method.
It says that weighted minimum cuts, a Lagrangian combination of daily
loads, or the convex hull of unrestricted successful cuts cannot by
themselves enforce the per-day quota. Such a method must retain an
additional discrete compatibility condition before taking a convex hull.

No new bound on the princess game is claimed by this observation.

# Physical visibility does not improve the descending word at feasible budgets

24 October 2026. Uniform scheduling lemma, independently reviewed by the
lower-bound lane after correcting the endpoint-letter argument below.
This is a restatement and fresh review of the existing no-extra-credit
theorem in `research/bridge-upper-transport.md`, not a new mathematical
achievement. That source already records the general cross-section version.
This rules out one proposed construction improvement; it does not rule out
other legal flip orders or other shapes.

Let a and z be phased physical height walks of width w, with their usual
phase-dependent empty heights in{-2,-1} and occupied heights at most n-1.
For a t-move transport put c_x=min(a_x,z_x-t), and use the accepted
descending-height flip word consisting of (x,H) for

    H=a_x,a_x-2,...,c_x+2.

Suppose k>=ceil(w/2). Then the physical-visibility window criterion is
equivalent to the earlier final-root-credit criterion. In particular it
cannot remove a failing short-rectangle transport condition by collecting
additional early or late invisible flips.

## Proof

All letters at a fixed height H occupy columns of a single parity, so
there are at most ceil(w/2)<=k letters at each height. Let

    U_i = number of letters with H>=n-i,
    V_j = number of letters with H>=-j.

The accepted exact window theorem says the fixed word is schedulable iff
some0<=i<=j<t satisfies

    U_i-ki+k(j+1)-V_j >=0.

Increasing i by one increases U_i by at most k. Thus U_i-ki is
nonincreasing. All initial heights are at most n-1, so U_0=0, and i=0
maximizes this term. Increasing j by one increases V_j by at most k,
so k(j+1)-V_j is nondecreasing. Therefore j=t-1 is optimal. The maximum
window slack is exactly

    kt - number of letters with H>=1-t.

Every letter with H<1-t is invisible even on the last move. A column
containing a letter has a_x>c_x and therefore c_x=z_x-t exactly. Its
letters satisfy H>=c_x+2=z_x-t+2>=-t. Thus an invisible letter has H=-t
and z_x=-2. Conversely the word contains that final letter whenever an
endpoint-empty column with z_x=-2 is active (a_x>c_x). Thus the uncharged
letters are precisely the final root-credit letters already counted by
the old construction. Equivalently, one may define that credit directly
as the number of actual word letters with H<=-t, which also covers t=0
separately by initial containment.

Consequently the exact window test is F-credit<=kt, where F is the
virtual word length. For even width2b the credit is at most b. The
argument covers arbitrary phased endpoint height walks, not only prefixes.

## Scope

Every feasible rectangle budget k>=floor(w/2)+1 satisfies the hypothesis.
The known examples where visibility windows strictly improve a transport
word use smaller local budgets. This lemma does not authorize reordering
free flips past paid flips: another legal order may have different
visibility opportunities, and must be analyzed independently.

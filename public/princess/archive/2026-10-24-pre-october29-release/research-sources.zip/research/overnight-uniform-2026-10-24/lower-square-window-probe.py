#!/usr/bin/env python3
"""Small exact attack on a proposed composite rectangular compression.

Individual square-window shifts need not subcommute with the rectangle
neighborhood. Test the stabilized composition, never infer its validity
from that of the isolated square.
"""
from pathlib import Path
import sys, json, itertools
sys.path.insert(0, str(Path(__file__).resolve().parents[2]/'src'))
from parity_trap_solver import setup

def operators(shape, colors):
    w,n=shape
    result={}
    for y0 in range(n-w+1):
        for sign in (1,-1):
            maps=[]
            for pts in colors:
                groups={}
                for i,(x,y) in enumerate(pts):
                    if y0<=y<y0+w:
                        groups.setdefault(x+sign*(y-y0),[]).append(i)
                fibers=[]; whole=0
                for ids in groups.values():
                    ids.sort(key=lambda i: pts[i][1])
                    prefixes=[0]
                    for i in ids:prefixes.append(prefixes[-1]|(1<<i))
                    fibers.append((prefixes[-1],prefixes));whole|=prefixes[-1]
                maps.append([(a&~whole)|sum(pr[(a&f).bit_count()]for f,pr in fibers)
                             for a in range(1<<len(pts))])
            result[y0,sign]=maps
    return result

def test(shape, order):
    colors,ns=setup(shape);ops=operators(shape,colors)
    maps=[]
    for p in (0,1):
        mp=[]
        for a in range(1<<len(colors[p])):
            z=a
            while True:
                old=z
                for key in order:z=ops[key][p][z]
                if z==old:break
            mp.append(z)
        maps.append(mp)
    for p in (0,1):
        for a,ca in enumerate(maps[p]):
            if ns[p][ca]&~maps[1-p][ns[p][a]]:
                unpack=lambda m,phase:[colors[phase][i]for i in range(len(colors[phase]))if m>>i&1]
                return {'passes':False,'phase':p,'source':unpack(a,p),
                        'compressed':unpack(ca,p),'N_compressed':unpack(ns[p][ca],1-p),
                        'compressed_N':unpack(maps[1-p][ns[p][a]],1-p)}
    return {'passes':True,'checks':sum(map(len,maps))}

def main():
    out=[]
    for shape in ((4,5),(4,6)):
        w,n=shape
        for direction in (1,-1):
            ys=list(range(n-w+1))[::direction]
            for signs in ((1,-1),(-1,1)):
                for grouping in ('window','sign'):
                    order=([(y,s)for y in ys for s in signs]if grouping=='window'
                           else[(y,s)for s in signs for y in ys])
                    out.append({'shape':shape,'order':order,**test(shape,order)})
    dest=Path(__file__).with_suffix('.json');dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

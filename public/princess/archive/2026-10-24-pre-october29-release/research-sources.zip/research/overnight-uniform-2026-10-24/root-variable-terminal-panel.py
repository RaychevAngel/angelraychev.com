"""Combine reviewed variable-slack necessity and terminal-quota refinement.

Reuses physical upper records; no new physical optimization or width theorem.
"""
from pathlib import Path
import importlib.util,json,time
P=Path(__file__).resolve().parent
def load(name,file):
    s=importlib.util.spec_from_file_location(name,P/file)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('variable_terminal','root-terminal-gate-panel.py')
v=load('variable_terminal_guard','comparison_variable_slack_general.py')
start=time.process_time();rows=[];hist={};maximum=-1;worst=[];improved=0
choices={}
for old in json.loads((P/'comparison-variable-slack-panel.json').read_text())['results']:
    w,n,k=old['w'],old['n'],old['k'];b=w//2;d=k-b
    key=(b,d)
    if key not in choices:choices[key]=v.strongest_cutoff(b,d)
    certificate=choices[key];R=certificate['R']
    assert certificate['admissible'] and R==old['cutoff']
    m.cut.cutoff=lambda budget,R=R:R
    m.base.m.old.early_api.cutoff=lambda budget,R=R:R
    J=m.joint(w,n,k,k);Jhalf=m.joint(w,n,k,k//2)
    assert J==old['J'] and J<=Jhalf<=J+1,(w,n,k,J,Jhalf,old['J'])
    lower=max(2*J+1,2*Jhalf);improved+=lower>old['lower']
    r={**old,'J_half':Jhalf,'lower':lower,'gap':old['upper']-lower}
    assert r['gap']>=0,r
    hist[str((w%2,r['gap']))]=hist.get(str((w%2,r['gap'])),0)+1
    if r['gap']>maximum:maximum=r['gap'];worst=[r]
    elif r['gap']==maximum:worst.append(r)
    rows.append(r)
out=dict(status='DIAGNOSTIC; uniform ceiling remains the proved eight-day theorem',
         cases=len(rows),improved_by_terminal_quota=improved,maximum_gap=maximum,
         histogram=hist,worst=worst,results=rows,CPU_seconds=time.process_time()-start)
(P/'root-variable-terminal-panel.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ('results','worst')})
print('worst',worst[:8])

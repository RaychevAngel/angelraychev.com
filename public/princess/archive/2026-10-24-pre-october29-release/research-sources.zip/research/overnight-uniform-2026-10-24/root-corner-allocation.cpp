// Falsification of a two-corner allocation model, not a physical lower proof.
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>
using namespace std;
int root(int x){int r=sqrt((double)x);while(r*r<x)++r;while(r&&(r-1)*(r-1)>=x)--r;return r;}
int rho(int x){int r=(sqrt(4.0*x+1)-1)/2;while(r*(r+1)<x)++r;while(r&&(r-1)*r>=x)--r;return r;}
int G(int x){return x-rho(x);}int F(int x){return x-root(x);}
int main(int argc,char**argv){int top=argc>1?atoi(argv[1]):100;long long transitions=0;int days=0,maxfront=0;
 for(int k=2;k<=top;++k){vector<pair<int,int>> states={{0,0}};int a=0,b=0,H=(k-1)*(k-2);
  for(int day=1;day<100*k;++day){int na=G(b+k),nb=F(a+k);a=na;b=nb;int bound=max(a,b);
   vector<int> best(bound+k+1,-1);
   for(auto [x,y]:states)for(int u=0;u<=k;++u){int nx=G(y+u),ny=F(x+k-u);++transitions;
    if(nx+ny>bound){cout<<"{\"status\":\"COUNTEREXAMPLE\",\"k\":"<<k<<",\"day\":"<<day<<",\"source\":["<<x<<","<<y<<"],\"allocation\":"<<u<<",\"next\":["<<nx<<","<<ny<<"],\"single\":["<<a<<","<<b<<"],\"H\":"<<H<<"}\n";return 0;}
    best[nx]=max(best[nx],ny);
   }
   states.clear();int seen=-1;for(int x=(int)best.size()-1;x>=0;--x)if(best[x]>seen){states.push_back({x,best[x]});seen=best[x];}
   ++days;maxfront=max(maxfront,(int)states.size());if(bound>=H)break;
  }
 }
 cout<<"{\"status\":\"NO COUNTEREXAMPLE IN FINITE MODEL\",\"maximum_k\":"<<top<<",\"days\":"<<days<<",\"transitions\":"<<transitions<<",\"maximum_frontier\":"<<maxfront<<"}\n";
}

# The accepted large-excess middle comparison allows any tied terminal seed

24 October 2026. Algebraic interface audit; this does not itself prove the
physical necessity of the new terminal gate.

Retain b>=32, b+1<=k<3b, d=k-b, H=(b-6)^2 and all endpoint ranges in
`../joint-history-2026-10-24/lower-large-excess-middle-two.md`.
Replace the initial late hybrid pair (k,k) and its scalar seed k by
(c,c) and c, for any integer 0<=c<=k. Keep the same maps and injection cap.
Then the large-excess middle theorem and its parity refinement are unchanged:
the two-extra-move conclusion holds for d>=18 at even width and d>=20 at
odd width.

Write G(x)=k+x-rho(x), F(x)=k+x-ceil(sqrt(x)). All states before the
relevant first crossing lie in the range where F,G are nondecreasing and
progressive. A tied start c is coordinatewise nondecreasing under the first
update. Induction proves time monotonicity, including the common scalar
injection. The injection at time t is at most BOTH current coordinates.
Therefore, just as for seed k,

    C_t[0]<=G(C_t[1]), C_t[1]<=F(C_t[0]).

At a first maximum crossing of Y, the previous maximum is <Y. The common
injection obeys the same one-step scalar bound as the ordinary first
coordinate: if its cap was already attained the previous pair dominates
that cap, while otherwise its preceding scalar value is dominated by the
previous maximum. Hence max C_t<=G(Y-1)<=Y+k. Since

    Y<=H+k-rho(H)=H+k-b+6,
    H+2k-b+6<b(b-1),

the progress domain used in the interlacing argument is valid. These
inequalities use only b>=32 and k<3b, not the initial seed.

Put x=min C_t and z=max C_t. Interlacing gives z<=G(x), while z>=Y>H.
At x0=(b-8)(b-7),

    G(x0)=H+k-4b+28<H.

Thus rho(x)>=b-7 and z-x<=k-rho(x)<=d+7. This is precisely the sole
boundary-origin hypothesis used in the accepted low/central/high room-credit
comparison. Its six low injections, central branch exclusions, paired
finite-board gains, and five high clamps never use c=k. The same proof
therefore applies verbatim after this span lemma.

No stronger common-origin or phase-spread property is inferred. In
particular this audit only transfers a middle comparison; the separate
late-history theorem must authorize the hybrid with gate c before it can
be used as a capture lower bound.

# The first sensitive corner event needs no initial phase allowance

24 October 2026. Proposed ordinary-proof lemma; independent review requested.
This is an initialization statement, not a complete early boundary theorem.

Let w<=n have even area, b=floor(w/2), k>=b+1, and H=b(b-1).
For an actual full-origin history let Q_t be total holes after t unsuccessful
inspection-and-move updates, with Q_0=0. Assume Q_s<=H for 0<=s<=t.
Write sigma_s for the ORIGINAL total survivor surplus at step s. Thus

    Q_(s-1)+k >= Q_s+sigma_s.

Use maps G(x)=x+k-rho(x+k), F(x)=x+k-ceil(sqrt(x+k)), and ordinary pair

    P_0=(0,0),  P_(s+1)=(G(P_s[1]),F(P_s[0])).

Call an event sensitive when Q_s>0, r=ceil(sqrt(Q_s))<b,

    r(r-1)<Q_s<=r²,  sigma_s=r.

Suppose t is the FIRST sensitive event. Then

    Q_t <= P_t[0].                                      (1)

In fact, before t both ordinary coordinates dominate all total holes:

    Q_s <= f_s <= min(P_s),  f_0=0, f_(s+1)=F(f_s),       (2)

for 0<=s<t.

## Proof

The accepted small-side capacity and complementary-side exclusion on
Q<=H imply sigma>=ceil(sqrt(Q)). If an event with Q>0 is not sensitive,
then sigma>=1+rho(Q): below its pronic wall the latter is exactly the
square-root lower bound; above that wall non-sensitivity forces one extra
integer surplus. At r=b the entire permitted range is below the pronic
wall. Therefore the exact inverse identity gives Q_s<=F(Q_(s-1)). The
case Q_s=0 also obeys this inequality since F is nonnegative on the
nonnegative integers. Induction proves Q_s<=f_s.

Since G>=F and both maps are monotone, both coordinates of P_s dominate
f_s by induction. This proves (2). At the sensitive event the square-root
profile instead gives Q_t<=G(Q_(t-1)); monotonicity and (2) yield

    Q_t <= G(f_(t-1)) <= G(P_(t-1)[1]) = P_t[0].

The actual sensitive component has its actual corner's own color by the
accepted rigidity lemma. Thus coordinate0 is the correct relative phase.
No fixed choice of physical corner in earlier days is presumed.

## What remains

After a sensitive event, F-only propagation need not stay below BOTH
ordinary coordinates at the same elapsed index. A later sensitive event
whose actual corner convention differs can demand the other reference
phase. Equation(1) does not pay that change. It only eliminates the need
for a causal cone or free two-phase injection before the FIRST sensitive
event in a history staying below H.

For first-crossing arguments, the hypothesis is applied before or at a
crossing whose final endpoint is <=H. It must not be applied across an
earlier excursion above H without a separate clipped-history argument.
Dependencies: lower-causal-quadrant-boundary.md, Section2, and its accepted
small-side/component localization sources; no computational or Lean claim.

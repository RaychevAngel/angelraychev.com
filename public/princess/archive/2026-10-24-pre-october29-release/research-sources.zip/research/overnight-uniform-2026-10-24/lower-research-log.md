# Lower lane research log — 24 October 2026 overnight

Goal: improve necessary physical capture-time bounds uniformly in both
side lengths and the feasible constant budget, ultimately to exact
optimality. Preserve every earlier accepted source. No public or Lean
claims are changed by this research pass.

## 08:17–08:43 UTC: exact two-cohort normalization

Proved and independently audited `lower-alternating-polarization.md`:
on any bipartite graph with a color-swapping involutive automorphism,
alternating polarization preserves useful inspection quotas and produces
an exact full-board strategy normal form with nested reflected cohorts.
For an even-area rectangle, folding an even axis gives a half-grid with
loops exactly on its fold boundary, and two nested support layers.

The complete small-subset audit and independent reviewer both passed.
This is a genuine uniform exact compression, not prefix optimality or a
seriality theorem. Generic seriality is false even on a looped star;
Hall alone is insufficient (the upper lane supplied a separate example).
We therefore did not spend the pass trying to prove an invalid generic
seriality consequence.

The normalization does yield a useful physical restriction: a uniquely
dominant near-capacity hole component must lie in the same permanent
smaller-support cohort throughout the normalized full-board history.

## 08:43–08:50 UTC: last-subcritical-root geometry

`lower-nearcritical-good-events.md` proves that actual two-cohort holes
with root r<b and total surplus at most r have surplus exactly r and at
most one outlying hole. The exception occurs only at (r-1)^2+1. It gives
an actual unique corner and an inspection charge for changing corners.
Independent review accepted the note; no clock extension was inferred.

`lower-nearcritical-late-events.md` proves a stronger signed-survivor
fact: a zero-slack good late event has an EXACTLY FULL partner cohort.
At most one singleton may accompany the dominant small component, again
only at the lowest point of the root bin. Independent review accepted.

These results suggest replacing the old five-root exclusion by a
zero-slack good/bad comparison. The difficulty is analytic: bad steps
need not earn one room in both phases. Early root-wall failures must be
counted; late bad steps earn one room every other phase automatically.

## 08:50 UTC onward: a proposed uniform late boundary extension

`lower-pronic-late-extension.md` proves the same necessary late hybrid
clock up to Y=b(b-1)+d+1 for b>=160 and 1<=d<=19, subject to independent
review. It uses old slack-four good states below root b-5 and zero-slack
states above, with one persistent physical reference trajectory.

The important joining issue is handled rather than hidden: if an old
low-root good state is followed by a near-critical excursion, the rise
in actual residual gives enough immediate reference credit to rewind.
Otherwise the preceding root is large, so a geometric matching charge
forces a long bad interval. Near bad steps earn one room every second
phase, old bad steps earn four, and the last-near-index argument pays a
single rewind despite arbitrary repeated excursions.

The sufficient arithmetic condition is a polynomial over the infinite
parameter range, not selected-width evidence. No early extension,
middle comparison, nine-day theorem, or exact-optimality theorem is
claimed by this note.

## Outstanding work

* Independent audit of the late extension and its exact hybrid interface.
* Parent's corresponding early extension: count failed cheap-phase steps
  near square walls while retaining one reference origin and phase.
* Comparison lane's pronic middle inequality, including odd-width phases.
* Determine whether exact nesting/fixed active-cohort identities can
  further strengthen the necessary model rather than merely improve a
  constant-gap proof. No theorem yet reduces nested supports to prefixes.

## 09:18--09:48 UTC: permanent mixing, a genuine barrier, and physical subtraction

* `lower-last-full-mixed-penalty.md`: independently accepted by upper in
  `upper-last-full-review.json`. Delete all larger-cohort inspections before
  its last full belief. Thereafter the larger survivor is permanently proper.
  Mixed small signed mass obeys sigma>=min(b,1+ceil(sqrt(q+1))), including
  roots1--3 and the extra unit at perfect squares.
* `lower-mixed-boundary-domination.md`: independently accepted by upper.
  Both physical corner phases compare with ZERO allowance throughout a mixed
  late suffix from Z<=min(h,(b-1)^2+k), including arbitrary retreats. Early
  mixed holes similarly pay the worse quadrant profile while Q<=(b-1)^2.
* `lower-mixed-central-barrier.md`: independently accepted by upper. At
  positive mixed survivor q in [(b-1)^2,h-b(b-1)-2), total surplus is at least
  b+1. The clipped potential Psi loses at most d-1 per move for k=b+d. At
  minimum budget it cannot decrease at all: useful larger-cohort work cannot
  start before the smaller belief has <=b²-b+1 rooms. This is a uniform
  all-length structural theorem, not a width certification or prefix claim.
* `lower-subtraction-simulation.md`: exact one-cohort simulation inside
  Y\gamma(D), for any fixed color-flipping graph automorphism gamma and larger
  cohort holes D. Its defect |Y\gamma(D)| at a signed gate is the precise
  geometric obstacle to converting that gate into solo capture. History-
  conditioned packing remains unproved.
* `lower-independent-corner-concentration.md`: exact algebra for independent
  fixed-corner quadrant processes, for arbitrary daily quota words. The key
  inequality F(x)+G(y)<=F(x+y) for x>0, plus last-zero pruning, proves that
  the total never beats the better of two single-corner zero-origin orbits.
  A direct allocation diagnostic k2..30 through k(k-1) found no violation,
  but the proof is uniform. Causal physical corner decomposition remains open.
* Fixed-anchor dominance is actually FALSE globally: upper replayed the retained
  12x12,k7 moving-front transport and found day26 holes42 versus anchored41,
  then day35 holes65 versus62. All these violations lie above the early pronic
  cutoff H30. The narrower early-boundary dominance conjecture survives this
  witness; no claim of proof.
* `lower-square-window-probe.py/.json` falsifies naive iteration of square
  compressions in overlapping windows: even the best ordering fails exact
  neighborhood subcommutation on4x6. Preserve as a failure shield.
* Independently reviewed and accepted upper's `upper-adaptive-transport.md`,
  `upper-free-central-phase.md`, and `upper-general-phase-transport.md`.
  These preserve entrance deficit and give actual free central phase changes;
  they are constructive families, not unrestricted optimality assertions.

Current lower target: causal geometry connecting exact independent-corner
concentration to real full-origin early holes, or a history-conditioned packing
bound for Y against gamma(D). A fixed-anchor full-history proof is disallowed
by the literal counterexample. Parent reports uniform9 accepted independently;
none of the new structural lemmas here asserts gap zero.

## 09:50--10:20 UTC: exact causal boundary and stronger cutoff

* `lower-causal-quadrant-boundary.md` is independently accepted in
  `upper-causal-quadrant-review.json`. Any localized target whose complete
  backward cone stays inside one actual quadrant has the matching zero-origin
  phase bound at the same elapsed time. The only first envelope violations
  below the pronic cutoff are zero-slack own-corner events; the fast cone
  guard controls every such fast event, not just selected histories.
* Independently accepted the parent quantitative integral guard and comparison
  half-budget / exact integer cutoff refinements. The latter strengthen both
  necessary hybrids uniformly while preserving paid phase changes.
* Do NOT replace the fast hybrid injection with the ordinary pair yet: the
  accepted fast cone theorem controls sensitive zero-slack events, whereas
  old tracking labels all C4-good events, some with outliers. A matched bound
  for one component does not automatically bound the entire state in either
  desired phase. This interface is still open.
* Reviewed the new pronic cut transport and five-day constructive bracket;
  the actual head entrance and full inspection count are correct.
* Review hashes and exact scope are in `lower-independent-reviews-1015.json`.

## 10:20--10:52 UTC: terminal gates and causal fast injection

* `lower-arbitrary-late-gate.md` is independently accepted in
  `upper-arbitrary-late-gate-review.json`. All accepted late necessary clocks
  extend to any nonnegative terminal signed gate c<=k by replacing seed(k,k)
  with(c,c). The reference-in(c,k] final move is counted; no negative gate is
  covered. Parent combines this with the final-quota cut to improve the
  uniform ceiling from9 to8. The exact zero-gap objective remains open.
* Independently accepted `upper-four-day-transport-families.md`: accepted
  central phase transport plus the arbitrary gate gives four-day brackets
  on its stated infinite even-width families. The argument uses the dichotomy
  J(floor(k/2)) in{J(k),J(k)+1}, not sample extrapolation.
* `lower-outlier-equality-rigidity.md` is independently accepted in
  `upper-outlier-rigidity-review.json`. A dominant corner component with
  outliers can attain the exact anchored profile only as a full triangle plus
  one corner singleton, at the explicitly stated square/pronic+1 endpoints.
  Every other mixture pays at least one additional unit of surplus. A stronger
  constant-budget dominant-phase allocation theorem remains unproved; its
  arbitrary-quota analogue is FALSE for word[6,0,9].
* Do not infer a phase-spread invariant from small samples: the conjecture
  delta²<=k is false at k783,t326 with pair(162040,162006). Also, a numerical
  relaxation merely forbidding consecutive cheap G moves still beats the
  physical ordinary maximum (e.g. k13,day28). Such abstract examples are not
  physical game counterexamples.
* New `lower-ordinary-max-injection.md/.py` is submitted for independent
  review. An explicit backwards-cone guard proves the ALL-TIME clipped
  inequality min(actual Q,Z)<=min(max ordinary P,Z), including arbitrary
  earlier excursions. This replaces the early all-G injection by the actual
  ordinary maximum, while deliberately retaining one free phase choice.
  Its recurrence was checked for58,716 steps and satisfies P<=new<=old.
  The causal guard and inherited slow-history range are both required.
* Reviewed upper's visibility-window collapse: its endpoint optimization is
  sound; the reversed c inequality was corrected by restricting to active
  columns. Reviewed comparison's exact one-square descendant formula; this
  removes long affine iteration but does not itself prove a capture bound.

## 10:52--11:00 UTC: both causal fast-capacity replacements accepted

* `lower-ordinary-max-injection.md` is independently accepted in
  `upper-ordinary-max-injection-review.json`.
* `lower-causal-late-capacity.md` is independently accepted in
  `upper-causal-late-capacity-review.json`. A first backward fast-capacity
  violation forces an exactly full partner and one actual corner survivor.
  Following that same cohort through its causal cone compares the entire
  remaining signed-mass history with one quadrant prefix, even if the other
  cohort later becomes proper. Thus the late injection can also use ordinary
  MAX capacities from arbitrary nonnegative gate c. Its companion API and
  recurrence receipt are saved; inherited slow guards still apply.

## 18:05--18:15 UTC: bounded resumed proof attack

* Parent reports the original overnight deadline has passed; this pass is
  bounded proof work and a durable checkpoint, with no further width sweeps.
* Parent's strict-saturation and deficit1 allocation falsifiers found no
  counterexample in their finite constant-budget models. This remains
  evidence, not a uniform theorem. A bare one-step2-wedge invariant is not
  closed: at genuine ordinary pair(10,11), the hypothetical state(9,2)
  satisfies its own caps/MAX/wedges but transitions to a saturation failure.
  That hypothetical state is not an actual reachable-history counterexample.
* A stronger convex-hull guess is actually false: k12,day10 has ordinary
  pair(55,56) and reachable allocation(1,55), so bx+ay<=ab fails.
* New activation-order lemma `lower-activation-order-deficit.md` and parent's
  `root-activation-delay.md` avoid that global invariant. After last-zero
  pruning, either the distinguished convention activates first and already
  dominates the total, or its output is at most the same-current-phase
  ordinary capacity at time t-1. An ordinary daily increment at least the
  terminal outlier mass therefore gives the matching-phase TOTAL bound.
* The elementary ordinary spread bound sharpens to delta_t<=ceil(t/2), by
  an oriented own-leading/opposite-leading induction. Hence the explicit
  daily increment lower bound is k-Rhat-ceil((t-1)/2). The rigid triangle+
  singleton exception has outlier mass1; when its complete two cones are
  disjoint, this gives a genuine conditional physical matching-phase result.
  Both notes are independently accepted in `upper-activation-delay-review.json`.
  This does not remove the slow interface
  or prove global strict saturation, and uniform gap zero is still open.
* Independently accepted comparison's first-sensitive initialization and
  upper's connected looped Hall blow-up obstruction. The latter rules out
  generic half-solo arguments even under connectedness/nonbipartiteness;
  it is not a rectangle counterexample.

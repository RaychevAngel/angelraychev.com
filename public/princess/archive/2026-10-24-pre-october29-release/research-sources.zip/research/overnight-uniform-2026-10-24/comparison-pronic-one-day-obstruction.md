# A uniform obstruction to an independent-endpoint one-day middle bound

24 October 2026. This concerns the relaxed endpoint interface, not an actual
zero-start physical history. It does not refute a stronger coupled-history bound.

For every even b>=8 take w=2b+1, n=2b+2, k=b+1, h=2b^2+3b+1,
H=b(b-1), U=h-H, Y=H+1, Q=H. Choose

    C=(H+1,H-1),     A=(H,H-1).

Both pairs satisfy their progress predicates. In particular
Phi(C)=(H+1,H+2)>=C, and Hf(A)=(H,H)>=A. Their spreads are 2 and 1,
within d+1=2, and their maxima equal Y,Q. Thus they are admissible in the
independent-endpoint theorem.

The ordinary and nine-feature necessary equal-seed clocks both reach U at

    tau=9b-1.

For the ordinary clock: there are b low updates to the equal vector b^2+1,
followed by 8b-1 central updates. For the nine clock, direct substitution
in the accepted central operator yields the same maximum; its last profile
is B(c,e)=U-1 for c=0,1 and B(2,e)=U. The low square crossing has no
extra erosion restriction in this large-deficit region.

Because b is even, the physical pair from C after the b low updates is
(b^2+1,b^2). One more update ties it at b^2+1, rather than advancing its
maximum as the equal-seed comparator does. The subsequent central updates
have pair translation 1 every two steps. Hence

    Phi^tau(C)=(U-1,U-1),
    Phi^(tau+1)(C)=(U,U-1).

For odd width/even length the correct matching has chi=1. Both sums at
tau+1 are exactly h-1:

    U+(H-1)=h-1,     (U-1)+H=h-1.

So the independent-endpoint middle+1 conclusion is false uniformly, including
with the accepted nine-feature necessary model. At the next update the high
pronic acceleration is active and the meeting succeeds.

A literal source-level replay at b=200 is saved in
`comparison-pronic-one-day-counterexample.json`. It uses the authoritative
nine-feature step and the literal finite-board physical update, obtaining
ordinary=nine=1799 and both one-day margins -1.

The remaining opportunity is to prove that these adverse C,A combinations
cannot coexist at the retained endpoint times of the actual common hybrid
histories, or to use stronger physical cohort information in the necessary
middle model. This example is not claimed to have that common origin.

# A phase-changing bridge entirely inside the pronic passage

24 October 2026. Proposed constructive theorem for independent review.

Let w=2b with b>=4, n>=w, h=bn, k=b+1, H=b(b-1), M=h-H,
and t=2b-3. For EITHER phase p, the left prefix of size M can be
carried to a subset of the right prefix of size M-t in t moves of
budget k. The two endpoint relative phases are equal, and the actual
global phases differ, exactly as required because t is odd.

## Explicit endpoint walks

If p=(n+1) mod2, the source and reflected-target diagonal parameters
are (n-1,0) and (n-1,2b-3). Thus

    a_x=n-1-x,
    z_x=n-2b-2+x+2 I{x<=2}.

Their difference is 2x-2b-1+2 I{x<=2}, at most2b-3=t.

If p=n mod2, those parameters are (n,b) and (n-2,b-3). Thus

    a_x=n-2-x+2 I{x>=b},
    z_x=n-2b-3+x+2 I{x<=b+2}.

The difference is 2x-2b-1+2 I{x<=b+2}-2 I{x>=b}.
On x<b it is at most-1; on b<=x<=b+2 it is at most5;
on x>b+2 it is at most2b-5. Since b>=4, each is at most t.

These parameter identities follow directly from the accepted prefix
diagonal counts. At n=2b a target empty height may be-1, which is the
correct phase-dependent empty fiber. All other endpoint heights are
physical. Consequently z-t<=a in both cases. The area drop is t,
so the legal descending transport word contains (b+1)t=kt flips.
The accepted transport construction proves the claim.

## Complete phase freedom between the actual cuts

Fix any Y<=H+2. Then

    M-Y>=h-2H-2>=2b-2>t.

Starting from size M, either continue at the left corner or use the
bridge. Continue greedily afterward for exactly M-Y-t further moves.
Every ordinary prefix move at budget b+1 decreases its size by at least
one, because finite-board prefix surplus is at most b. Therefore both
routes end with size at most Y after M-Y moves. Their relative corner
phases are opposite. Thus either prescribed anchored tail phase can
follow, at the same elapsed time and with no larger starting size.

The first ordinary full-start entrance to M is exact: the finite-board
prefix move at M+1 has surplus b and reaches M, and the transition is
monotone. Hence the two choices can be attached to any ordinary full-start
head which has reached size at most M by a specified day; use its earlier
first-M entrance.

## Conditional numerical consequence at minimum budget

Let a be an upper bound on the ordinary head time to M, and let v be
an upper bound on the better-phase ordinary gate clock from Y (the gate
means at most k rooms remain). The explicit full-start solo strategy above
captures within

    a+(M-Y)+v+1

inspections. The last1 is the final capture inspection. Neither the head
phase nor the tail phase needs to be compatible in advance.

In the accepted asymmetric necessary-clock framework, d=1 gives Q=H,
Y in[H+1,H+2], and the even ordinary middle clock is exactly tau=M-Y.
The independently accepted boundary comparisons give a<=e+1 and
v<=ell+1. Thus this physical construction gives

    P_construct <= e+tau+ell+3.

For every parameter range where that necessary framework is proved,
minimizing over its actual admissible endpoints gives P_construct<=J+3.
The reverse-walk lower T>=2J+1 and physical upper T<=2P_construct then
give a bracket of width at most5. Currently the cited pronic boundary
framework applies to b>=200,d=1; no extrapolation to smaller widths is
made by this note.

## Arbitrary-budget extension on sufficiently long even rectangles

For b>=200,2<=d<=19 and n>=2b+2d-2, use the general reflection bridge
with t=2b-1. The actual asymmetric endpoints obey

    H-d+1<=Q<=H, H+1<=Y<=H+d+1, M=h-Q.

The faster ordinary middle clock is tau=ceil((M-Y)/d). Its minimum
possible numerator is h-2H-d-1. The length condition implies

    h-2H-d-1 > d(t-1),

so tau>=t. The first physical prefix entrance q<=M satisfies
q>=M-d+1: at M+1 both finite-board phase profiles have surplus b,
and monotonicity prevents a larger downward jump. In particular q>=dt,
since M-Y>d(t-1) and Y>=H+1>=2d-2.

Apply the general bridge to q, or stay with the original corner.
After t moves and then tau-t ordinary moves the belief has size at most
q-d tau<=M-d tau<=Y. Every ordinary prefix move decreases size by at
least d. The two routes again supply opposite relative phases at the
same day. The same a<=e+1, v<=ell+1, final-inspection count proves

    P_construct<=J_asymmetric+3,

and therefore a computable five-day bracket throughout this uniform
parameterized family. The general bridge itself permits other budgets
and lengths; the present five-day application uses only independently
established pronic boundary ranges.

This is a scope-explicit upper/lower comparison, not exact capture time,
a new fixed-size numerical formula, or a Lean verification claim.

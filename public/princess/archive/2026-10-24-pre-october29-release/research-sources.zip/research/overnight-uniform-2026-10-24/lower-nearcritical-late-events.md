# Zero-slack late events have an exactly full partner

24 October 2026. Ordinary physical lemma submitted for independent review.
This strengthens the geometric part of the proposed nearcritical clock
extension; it does not itself prove that extension.

Let w<=n, wn even, b=floor(w/2), h=wn/2. Take the two actual survivor
sets S0,S1 after one inspection and define

    q=|S0|+|S1|-h>0,
    sigma=sum_i (|N(Si)|-|Si|), r=ceil(sqrt(q)).

Suppose 4<=r<=b-1 and sigma<=r. Then:

* sigma=r;
* one survivor cohort is exactly full;
* the other consists of a unique dominant actual corner component,
  possibly together with one singleton component;
* the singleton exception is possible only at q=(r-1)^2+1;
* the dominant component's actual phase supplies the exact square/pronic
  bound q<=r^2 or q<=r(r-1), respectively.

## Proof

Use the accepted subcritical separator alternative and canonical component
bounds in `../uniform-history-2026-10-23/physical-dominant-corner.md` and
the signed survivor argument of `physical-late-slow-block.md` there.
Since sigma<b, both survivors are small or co-small. They cannot both
be small: then their total size is at most sigma^2<h, contrary to q>0.
They cannot both be co-small: then

    q >= h-sigma(sigma+1)
      >= 2b^2-b(b-1) > b^2 >= q.

Thus exactly one is small. Denote it P; write D for the number of holes
in the other, co-small survivor. In particular q=|P|-D<=|P|.

Let a be the largest canonical component surplus in P, and put
z=sigma-a. This z includes the surplus of all remaining components of P
and the entire surplus of the other survivor cohort. Since

    (r-1)^2 < q <= |P| <= sigma^2 <= r^2,

we have sigma=r. Also q>r^2/2, so the accepted dominant-component argument
gives a>r/2 and

    q <= |P| <= (r-z)^2+z^2,       0<=z<r/2.

The same integer calculation as in `lower-nearcritical-good-events.md`
forces z<=1. If z=0, the other survivor has zero surplus, hence its
co-small hole bound D<=0(0+1) forces it to be full. All of P is the
dominant component.

If z=1, then

    (r-1)^2+1 <= q <= |P| <= (r-1)^2+1.

Every inequality is therefore equality. In particular D=0, so the
other survivor is again full and has surplus zero. The remaining unit
of surplus lies in components of P outside its dominant component.
Their total size is one and their total surplus one. Hence they form
exactly one singleton component, while the dominant component has size
(r-1)^2 and surplus r-1. (This describes a necessary configuration;
no existence for every rectangle is asserted.)

The dominant component has more than half its surplus-squared capacity.
The accepted localization theorem places it at a unique actual corner
in radius at most 2a-2<=2r-2. The square/pronic phase bounds survive a
singleton remainder exactly as before:

    a(a-1)+z^2 <= (a+z)(a+z-1),
    a^2+z^2 <= (a+z)^2.

This proves all claims.

## Consequence of exact alternating polarization

For a full-board strategy normalized by
`lower-alternating-polarization.md`, the permanently favored larger
reflected survivor cohort contains the other. At every event above,
that larger cohort is the full partner; the small active survivor
cohort is consequently the same permanent initial cohort at every
zero-slack good event. Its corner can change, but its cohort cannot.

The analogous early-hole good events also have their dominant component
in this permanent smaller-support cohort. Thus the early and late
nearcritical physical labels are not independently selectable cohort
identities. This is a normal-form statement for full initial uncertainty,
not a theorem about arbitrary partial initial states.

## Phase changes and the remaining clock obligation

For two consecutive good late events with different corners, the fixed
matching transport argument now has at most one outlier at each end.
Using the old root r and the same half-intersection estimate gives

    Delta*k >= q_old-r^2/2-2
             >= r^2/2-2r-1.

Using the sharper color-specific corner intersection, if established
with the transported parity, may improve this to the early charge.
The displayed weaker bound is sufficient as a geometric starting point
and does not assume that sharpening.

Intervening transitions can retreat. To infer that they are bad with
sigma>=ceil(sqrt(q))+1, their positive survivor roots must stay in the
stated interval. A successful clock extension still needs an analytic
credit comparison for those bad transitions, retreat/entry bookkeeping,
and the final critical transition. No stronger capture-time bound follows
from this note alone.

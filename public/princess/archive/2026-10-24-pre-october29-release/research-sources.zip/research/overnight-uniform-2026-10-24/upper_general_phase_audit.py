from pathlib import Path
import sys,json,hashlib,random,time
p=Path('/Users/angel/code/math/princess/research/overnight-uniform-2026-10-24');sys.path.insert(0,str(p.parents[1]/'src'))
from bridge_upper_transport import prefix_height
from resumed_even_construction_transport import construct
start=time.process_time();geometry=0;literal=0;random.seed(6811)
for b in range(1,31):
 for n in(2*b,2*b+1,3*b,4*b+3):
  h=b*n
  for d in(1,2,3,b,b+1):
   for t in range(1,2*b+2,2):
    if t+2*(d*t//(2*b))<2*b+1 or d*t>h:continue
    for q in sorted({d*t,h,(h+d*t)//2}):
     for phase in(0,1):
      a=prefix_height(2*b,n,phase,q);z=prefix_height(2*b,n,1-phase,q-d*t,True)
      assert max(y-x for x,y in zip(a,z))<=t,(b,n,d,t,q,phase)
      assert sum(x-y+t for x,y in zip(a,z))//2==(b+d)*t
      geometry+=1
      if b<=5 and random.random()<.15:
       _,r=construct(2*b,n,phase,a,z,t,b+d);assert r['physical_containment_verified'];literal+=1
r={'status':'PASS','geometry_checks':geometry,'literal_checks':literal,'CPU_seconds':time.process_time()-start,'scope':'Supplementary checks of uniform reflection transport, not an optimality result','source_hashes':{'upper-general-phase-transport.md':hashlib.sha256((p/'upper-general-phase-transport.md').read_bytes()).hexdigest()}}
(p/'upper-general-phase-transport-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(r)

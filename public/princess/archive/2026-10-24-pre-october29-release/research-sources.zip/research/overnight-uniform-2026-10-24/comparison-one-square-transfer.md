# Exact phase transport through the final square wall

24 October 2026. Elementary ordinary lemma; not a capture-time comparison by
itself. It removes the unbounded middle iteration from a signed-credit audit.

Let b>=1,d>=1,H=b(b-1),S=b^2. On inputs greater than H, the lower physical
odd-width middle operator is

    Psi(x,y)=(y+d, x+d-1_(x>S)).

It is no greater than the full finite-board physical operator: all ignored
high-boundary branches only accelerate the latter. Choose an initial coordinate
i in{0,1}, of value x>H. Its descendant is acted on by the square branch F
at precisely the positive updates j with j congruent to i+1 modulo2.

Let j_i be the least such positive integer satisfying

    x+d*(j_i-1)>S.

Equivalently, start at max(1,floor((S-x)/d)+2) and round upward to the required
parity. Then after any t>=0 updates that descendant has exact value

    W_i(t)=x+d*t-max(0,1+floor((t-j_i)/2)),

and occupies coordinate i xor(t mod2).

Proof. Before the first slow F update every scalar update adds d, so the
condition defining j_i is exact. Its input is at least S+1; the output adds
d-1>=0 and therefore remains above S. All subsequent inputs of the same
descendant remain above S, since the intervening G step adds d. Consequently
every subsequent F update, exactly every other update, subtracts one from the
constant drift. Counting those updates proves the formula.

If an initial coordinate lies at or below H, perform the bounded initial
updates literally until both coordinates exceed H. In the shifted-pronic
endpoint box, two updates suffice. Their label permutation is retained before
applying this formula.

For even width in the same pronic middle both scalar maps simply add d after
that transient, so no square-wall correction is present.

## Why this helps the coupled-history question

Given a necessary middle clock tau, physical boundary pair C, and early pair A,
the matched margin at tau+s is therefore a maximum of two explicit integer
expressions in C,A, the phase-specific j_i, and tau+s parity. The potentially
long middle contributes no additional state. The unresolved part is the
admissible signed relation between the two actual zero-origin boundary pairs
and the hybrid endpoints used to compute tau. Arbitrary independent progress
or even arbitrary local common-orbit constraints are insufficient, as the
saved counterexamples show.

# A one-step defect wedge does not close the saturation conjecture

24 October 2026. Bounded algebraic falsification and restart note. This does
not refute the constant-quota saturation conjecture on actual trajectories.

Let F(z)=z-ceil(sqrt(z)), G(z)=z-rho(z). The ordinary constant-k pair is
(a',b')=(G(b+k),F(a+k)). An independent allocation with u to the second
output has (x',y')=(G(y+k-u),F(x+u)). Own-capacity bounds x<=a,y<=b always
hold. The proved independent-corner theorem adds x+y<=max(a,b).

A candidate stronger invariant is y<=2(a-x) when a>=2, symmetrically
x<=2(b-y) when b>=2. It would in particular imply strict saturation and
control a deficit of one. The two small-capacity exclusions are essential:
at k2,time1,ordinary(a,b)=(1,0) and actual(1,0) already invalidate an
unqualified symmetric wedge.

Even WITH those exclusions and the MAX theorem, a ONE-STEP induction fails.
At k7,time3 the genuine ordinary pair is (a,b)=(10,11). The hypothetical
state(x,y)=(9,2) satisfies both own caps, x+y<=11, y<=2(10-9), and
x<=2(11-2). Allocate all7 to the F output. The next ordinary pair is
(14,12), but the next hypothetical pair is (G(2),F(16))=(1,12).
Thus one coordinate saturates its full ordinary capacity while the other
remains positive. The hypothetical predecessor (9,2) is not actually
reachable; an exact three-day allocation calculation gives maximum other
coordinate0 when x=9. This example isolates a missing history constraint.

The local obstruction is precise: F has a plateau at the square wall,
so the main source deficit one can disappear while the uninspected other
component2 becomes G(2)=1. When the main map is G, the other map F(2)=0
instead clears the other component. Any saturation proof must retain this
phase/fiber distinction.

A bounded algebraic test checked TWO updates starting from every hypothetical
state satisfying the own caps, MAX total and both defect wedges at genuine
ordinary pairs. It found no two-step failure for k2..16, up to30 elapsed
ordinary stages or the first ordinary coordinate exceeding100. This is
finite candidate assessment only, not a theorem. The test was stopped
before completing k17 to keep the post-deadline pass bounded. No capture
bound depends on it. The exact candidate checker is retained as
upper_wedge_two_step_check.py; its wider default loop is not a claimed
completed audit range.

A promising next proof target is two-step closure of the defect wedge under
constant quotas, using the common k across both updates and paired square/
pronic root fibers. If it fails, a certified counterexample to closure would
identify the next required history invariant. Do not replace this with a
claim that actual saturation has already been proved or disproved.

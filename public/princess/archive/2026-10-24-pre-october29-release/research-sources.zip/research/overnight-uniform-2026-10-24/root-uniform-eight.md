# Uniform eight-day bracket by retaining the final inspection quota

24 October 2026. Ordinary theorem submitted for independent review.
This improves the accepted all-input gap9 to8; it does not establish zero.

For every rectangle w<=n and every feasible k>=floor(w/2)+1, retain all
earlier lower bounds and physical constructions. The strengthened bounds
satisfy

    L_k(w,n)<=T_k(w,n)<=U_k(w,n),    U_k(w,n)-L_k(w,n)<=8.

The only new ingredient in the assembly is to retain the quota on the
central inspection day, instead of converting every trajectory through the
single gate m<=k. The physical terminal cut and the arbitrary late gate
have separate independent reviews.

## 1. A family of necessary gate clocks

Use either of the accepted early/middle/late decompositions:

* b=floor(w/2)>=200,1<=d=k-b<=19: the shifted pronic cuts of
  root-uniform-nine.md;
* b>=32,k<3b, with d>=18 at even width or d>=20 at odd width:
  the older cuts H=(b-6)^2 and large-excess middle comparison.

For each integer0<=c<=k let J(c) be the same minimum over retained actual
early and late crossing endpoints, but with the late hybrid initialized at
(c,c), and its scalar branch initialized at c. The inverse maps, cap and
middle recurrence are unchanged. By lower-arbitrary-late-gate.md, J(c) is
a necessary first-passage time to signed total belief mass m<=c.

The complete endpoint intervals, and the early and middle clocks, do not
depend on c. Monotonicity gives J(k)<=J(c)<=J(0). The hybrid from zero has
first pair(k,k) and first scalar value k; its cap is at least k. Thereafter
it is exactly the seed-k hybrid. Thus every late hitting time, and therefore
the minimum over the SAME endpoint domain, obeys

    J(0)=J(k)+1.

Write J=J(k), c=floor(k/2), and Jhalf=J(c). These integer clocks satisfy

    Jhalf in {J,J+1}.                            (1)

The old reversed-walk cut and the new central-intersection cut give

    T>=max(2J+1,2Jhalf).                         (2)

All clocks here are necessary relaxations; their trajectories are not used
as inspection strategies.

## 2. The physical comparison works for every tied gate seed

Let P0 be the smaller complete anchored solo capture clock. Let Pc be the
smaller anchored solo clock to reach residual at most c, counting unsuccessful
inspection-and-movement updates. The physical backward pair for Pc starts
at(c,c). In particular Pk=P0-1, while P0 counts the final capture inspection.

The existing comparison gives P0<=J+5. Its arbitrary-gate version gives

    Pc<=J(c)+4.                                 (3)

There is no last '+1' in(3): the backward seed already denotes the desired
residual gate. The two same-phase boundary comparisons cost one update each,
and the accepted middle comparison costs two. The antipodal meeting rule
with gate seed c gives a gate trajectory after their sum, with the same
diagonal parity correction as before.

Here are the seed-dependent obligations explicitly.

For k>=100, the fast scalar hitting time from c>=0 is no longer than its
hitting time from0. The existing proof bounds this latter time by2u, where
u=k-floor(3k/5)-1. Starting both physical coordinates at c gives the same
half-frequency deficit bound ceil(t/2), and the same minimum drift u below
the fast cap. One additional physical update therefore dominates the fast
scalar target in BOTH labelled phases. Any smaller proved cap only helps.
Propagation through the ordinary hybrid branch is unchanged.

In the large-excess range the only remaining budgets are50<=k<=99. For the
accepted cap R=ceil(3k/5)+4, root-gate-fast-finite.py checks every integer
seed0<=c<=k and every scalar update through the cap. At each such update,
both physical coordinates one update later reach the smaller of the scalar
value and the cap. This is a complete finite lemma, not width sampling.
Budgets below50 cannot occur in the large-excess range b>=32,d>=18.
They need no new lemma because the finite-width base covers the residual
low-excess cases.

Time monotonicity, common scalar injection and the interlacing inequalities
C[0]<=G(C[1]), C[1]<=F(C[0]) hold for every tied initial c<=k. The first-hit
span bounds d+1 at the shifted pronic cut and d+7 at the older cut are
therefore unchanged. The middle proofs require precisely these properties,
progress and the crossing ranges; they do not require the initial seed k.
The source audits are comparison-generic-terminal-seed.md and the
independent assembly review (when accepted).

## 3. The physical upper and necessary lower now fit within eight days

Two sequential solo searches give U<=2P0. A solo gate strategy ending with
at most c=floor(k/2) rooms can be joined to its reflected time reverse:
the two residual sets need at most2c<=k inspections on the common central
day. This is the established prefix palindrome construction, and gives

    U<=min(2P0,2Pc+1).                           (4)

If Jhalf=J, equations(2)--(4) give

    U<=2(J+4)+1=2J+9,   L>=2J+1,   U-L<=8.

If Jhalf=J+1, instead use

    U<=2(J+5)=2J+10,    L>=2J+2,   U-L<=8.

No choice of phase or unused inspection credit is discarded at a junction.
The case distinction chooses between two genuine constructions and two
valid necessary bounds.

## 4. Coverage of the entire requested domain

Odd-by-odd rectangles retain exact joint evaluation. Widths at most64 retain
gap<=3. Even-area widths65..399 at excess1..19 have the already reviewed
complete all-length finite certificate with maximum gap8. At b>=200 the
new small-excess proof above covers1..19. The large-excess proof covers
d>=18 at even width and d>=20 at odd width for k<3b. Finally k>=3b retains
the stronger old gap<=1 theorem. These overlapping ranges cover every width,
length and feasible budget without a new length cutoff.

The starting all-input ceiling was25 (23 at even width); the previous
overnight improvement was9. The new ceiling is8 subject to independent
assembly acceptance. Gap zero, complete formalization of these new arguments,
and the final bounded-operation expression remain open. No new expression
work, public claim or Lean coverage is asserted here.

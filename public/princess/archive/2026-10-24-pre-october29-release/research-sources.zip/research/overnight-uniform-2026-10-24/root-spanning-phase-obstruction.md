# A spanning-cost step does not automatically align both ordinary phases

24 October2026. Failed algebraic shortcut, not a physical counterexample.

The proposed inequality was

    min A_(t+1) >= min((b-1)^2, max A_t + k-b),

for the two zero-origin ordinary quadrant orbits. It would let a geometric
step costing surplus at least b erase the reference's phase mismatch in
one move. It is false.

Take b=5,k=7. At time3 the pair is(10,11); at time4 it is(14,12), since
G(18)=14 and F(17)=12. The proposed right side is min(16,11+2)=13,
larger than the new minimum12. A scalar target13 with surplus5 would be
allowed by the combined budget inequality13+5<=11+7, but is not below
both labelled reference coordinates.

This does not construct an actual corner-changing history. It shows that
the surplus-b charge and current total size alone are insufficient to
reset phase. Any physical merger argument must retain additional history,
geometry, or the unused signed phase credit. The global maximum14 still
dominates the hypothetical target; only simultaneous alignment fails.

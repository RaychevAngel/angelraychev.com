"""Candidate smaller cutoff retaining integer matching-charge lengths.

The precise physical induction is in comparison-half-cutoff.md. This file
only evaluates its integer sufficient conditions; near-root substitution
needs independent verification before the resulting lower is promoted.
"""
from functools import lru_cache
def ceildiv(x,y):return -(-x//y)
@lru_cache(maxsize=None)
def cutoff(k):
    assert k>=100
    for R in range(k//2,(k+1)//2+7):
        r=R+1;D=k-R-1
        early=ceildiv(r*r-11*r-108,2*k)
        late=ceildiv(r*r-12*r-112,2*k)
        if D<=r and 4*(min(early,late)-1)>=D:
            return R
    raise AssertionError(k)
if __name__=='__main__':
    for k in (100,101,201,219,225,1001):print(k,cutoff(k))

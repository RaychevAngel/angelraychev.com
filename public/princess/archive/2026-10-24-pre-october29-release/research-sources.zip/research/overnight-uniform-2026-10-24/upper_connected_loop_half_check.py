from pathlib import Path
from collections import deque
import json,hashlib,time

p=Path(__file__).parent
old=json.loads((p/'upper-half-solo-counter.json').read_text());adj=old['adj'];n=len(adj);V=(1<<n)-1
N=[0]*(V+1)
for x in range(1,V+1):
 bit=x&-x;N[x]=N[x^bit]|adj[bit.bit_length()-1]
# Independent exhaustive one-copy BFS, enumerating all survivor subsets.
D={V:0};P={};q=deque([V]);zero=None
while q:
 x=q.popleft()
 if not x:zero=x;break
 r=x
 while True:
  if x.bit_count()-r.bit_count()<=2:
   y=N[r]
   if y not in D:D[y]=D[x]+1;P[y]=(x,r);q.append(y)
  if not r:break
  r=(r-1)&x
assert zero==0 and D[0]==6
solo=[];v=0
while v!=V:
 a,r=P[v];solo.append(a^r);v=a
solo.reverse()
L=3;z=L*n;wide=[0]*(z+1)
for i in range(n):
 for j in range(n):
  if adj[i]>>j&1:
   for a in range(L):
    for b in range(L):wide[L*i+a]|=1<<(L*j+b)
wide[z]|=(1<<z)|1;wide[0]|=1<<z
full=(1<<(z+1))-1
def blow(x):return sum(((1<<L)-1)<<(L*i) for i in range(n) if x>>i&1)
def hood(x):
 out=0
 while x:
  bit=x&-x;out|=wide[bit.bit_length()-1];x^=bit
 return out
cur=full;solo_receipt=[]
for shot in solo:
 shot=blow(shot)|(1<<z);assert shot.bit_count()<=8
 before=cur;cur=hood(cur&~shot);solo_receipt.append({'before':before,'shot':shot,'after':cur})
assert cur==0
cur=(full,full);joint=[]
for row in old['schedule']:
 shots=tuple(blow(a^r)|(1<<z) for a,r in zip(row['before'],row['survivor']))
 assert sum(x.bit_count() for x in shots)<=8
 survivors=tuple(a&~s for a,s in zip(cur,shots));assert survivors[1]&~survivors[0]==0
 nxt=tuple(hood(a) for a in survivors)
 joint.append({'before':cur,'shots':shots,'survivors':survivors,'after':nxt});cur=nxt
assert cur==(0,0) and len(joint)==10
matching=[]
for i,j in ((0,1),(2,3),(4,5),(6,7),(8,9)):
 for t in range(L):matching.append((L*i+t,L*j+t))
matching.append((z,z))
assert set(sum(([a,b] for a,b in matching),[]))==set(range(z+1))
assert all(wide[a]>>b&1 and wide[b]>>a&1 for a,b in matching)
seen={0};stack=[0]
for x in stack:
 for y in range(z+1):
  if wide[x]>>y&1 and y not in seen:seen.add(y);stack.append(y)
assert len(seen)==z+1 and wide[z]>>z&1
out={'status':'PASS literal connected looped Hall counterexample','n':z+1,'budget':8,'adjacency':wide,'permutation_matching':matching,'old_solo_exact':D[0],'old_solo_BFS_states':len(D),'new_solo_exact':6,'new_solo_lower':'Every eight-shot word projects to at most two fully inspected twin classes per day.','new_solo_upper_replay':solo_receipt,'new_joint_upper':10,'joint_replay':joint,'source_hashes':{f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in ['upper_connected_loop_half_check.py','upper-connected-loop-half-obstruction.md','upper-half-solo-counter.json']}}
(p/'upper-connected-loop-half-check.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ['adjacency','permutation_matching','new_solo_upper_replay','joint_replay','source_hashes']})

# Ordinary fast late capacity from a causal quadrant

24 October 2026. Proposed for independent review. This is the late analogue
of lower-ordinary-max-injection.md, now with a physical proof for arbitrary
terminal signed gates. No matching fixed-phase optimum is claimed globally.

Let w<=n be even-area, b=floor(w/2), h=wn/2, k>=b+1, and 0<=c<=k.
For signed pre-inspection mass m=|B0|+|B1|-h, consider any actual finite
history ending with m_g<=c. Define ordinary backward capacities

    V_0=(c,c),
    V_(j+1)=(k+V_j[1]-rho(V_j[1]),
             k+V_j[0]-ceil(sqrt(V_j[0]))).

Let A>k be an integer cap, and put

    Rhat=ceil(sqrt(A-1)),
    J=min{j:min(V_j)>=A}.

Assume

    Rhat<=b-1,       J+2Rhat<=w+2.                 (1)

Then, for every suffix length j<=g,

    min(max(m_(g-j),0),A)<=min(max(V_j),A).         (2)

Thus ordinary MAX capacity, rather than an all-cheap scalar capacity, is a
necessary fast late bound under the displayed arithmetic guard.

## 1. Classification of a first backward violation

The statement is immediate for j=0. Suppose j>=1 is its first failure.
Then max(V_j)<A, m=m_(g-j)>max(V_j), and at the next actual day

    m'=m_(g-j+1)<=max(V_(j-1))<A.

Indeed the preceding clipped inequality implies this untruncated bound
because max(V_(j-1))<A. Since max(V_j)>=k, we have m>k.

Let q>0 be the signed survivor mass after the first inspection and sigma
the sum of the two neighborhood surpluses. Useful shots and the actual
update give

    q>=m-k>0,        m'=q+sigma,        q<=m'<A.

If sigma>=1+rho(q), the exact inverse of u+1+rho(u) gives

    m<=k+q<=k+m'-ceil(sqrt(m'))<=max(V_j),

a contradiction. The accepted small/co-small separator alternatives also
imply sigma>=ceil(sqrt(q)) in this range. To see the only possible exception
explicitly, sigma<b and q<b² exclude two small survivors and two co-small
survivors. There is one small survivor P and one co-small survivor with D
holes; if its surplus is u, then q=|P|-D<=(sigma-u)²-D<=sigma².
If sigma>=b, the same lower bound is automatic.

Consequently the violating event has

    r=ceil(sqrt(q))<=Rhat<b,
    r(r-1)<q<=r²,       sigma=r.                   (3)

The co-small partner is exactly full: otherwise its positive surplus u>=1
would give q<=(r-1)²<r(r-1). The small survivor P has |P|=q, surplus r,
and cannot split into positive-surplus components, since the largest split
capacity is (r-1)²+1<=r(r-1) for r>=2. For r=1 it is directly a degree-two
corner singleton. Hence P is one actual own-corner component, localized
in radius D0<=2r-2 by the accepted connected quadrant theorem. Its opposite-
corner-color capacity r(r-1) would contradict(3), so its current phase is
indeed the corner's own color.

## 2. The same actual cohort stays inside a quadrant for the whole suffix

Because max(V_j)<A, j<J. By(1),

    D0+j<=2Rhat-2+J-1<=w-1.                       (4)

Immediately after the first inspection, one actual cohort is P. At every
later survivor state this SAME cohort is a subset of an iterated neighborhood
of P. Thus all of its positions and all neighborhoods used during the next j
unsuccessful updates agree with their infinite-quadrant counterparts. No
condition is imposed on the other cohort after the initial event: it may
become proper and its holes may be anywhere.

Start a corner-prefix reference of pre-inspection size x=m in the phase
whose first survivor is own-colored, spending the full budget k. Its first
survivor size is u=m-k<=q. At subsequent times, whenever x<=actual m and
x>k, the signed actual survivor mass satisfies q_actual>=x-k=u>0.
The cardinality of the localized ACTUAL cohort survivor is at least q_actual,
because the other cohort has at most h rooms. Its quadrant neighborhood
surplus is therefore at least the reference's current square/pronic surplus
c_p(u). The other cohort has nonnegative surplus. Hence

    actual m_next=q_actual+sigma_total
                 >=u+c_p(u)=reference x_next.

When x<=k, set the next reference value to0 and compare with the clipped
actual signed mass. This also handles a final negative signed value.

All reference survivor counts remain <=A-1: its first count is <=q<A,
both relevant quadrant costs are <=b<k, and its sizes subsequently decrease.
Thus the reference maps used here are genuine quadrant prefix maps. The
same corner and the same actual cohort are followed throughout; no phase
reset or spatial subtraction has been inserted.

At the actual terminal day, the reference consequently has size <=c.
The exact backward threshold interpretation of V_j says that its initial
size m is <=ONE matching coordinate of V_j. This contradicts the first
failure, proving(2).

## 3. Replacement inside an accepted late hybrid

Suppose an already accepted late-history theorem has fast cap A=R²+k,
terminal gate c, and otherwise the same allowed starting ceiling. If(1)
holds, replace its capped all-G scalar injection by

    M_j=min(A,max(V_j)),
    C_(j+1)[0]=max(M_(j+1),k+C_j[1]-rho(C_j[1])),
    C_(j+1)[1]=max(M_(j+1),k+C_j[0]-ceil(sqrt(C_j[0]))),
    C_0=(c,c).                                      (5)

Equation(2) supplies a necessary continuation clock from EVERY actual fast
state with signed mass <=A, including the actual last entrance used in the
accepted slow proof. Either phase of that abstract continuation is allowed,
exactly as before. Ordinary slow moves and all paid rewinds are unchanged.
Thus(5) is a stronger necessary late evaluator on the inherited range.

The optional free phase at the fast boundary remains. The ordinary MAX
clipped-capacity result does not say that every actual suffix is dominated
by both fixed phases or that a particular fastest phase is attainable.

## Dependencies

Use the same accepted separator and connected-localization theorems as
lower-nearcritical-late-events.md. Nonnegative neighborhood surplus follows
from a perfect matching of an even-area rectangle. Exact residual threshold
identities, including target0, are in lower-arbitrary-late-gate.md. The
retreat-safe slow tracking and terminal bookkeeping are inherited from the
accepted late hybrid; only its fast necessary continuation is strengthened.

"""Exact bounded falsifier for a proposed generic two-identical-copy seriality lemma.
Every graph relation is symmetric; loops are permitted. This is not a grid theorem.
"""
from collections import deque
import random,json,time
from pathlib import Path

def hood_table(adj):
    n=len(adj);N=[0]*(1<<n)
    for a in range(1,1<<n):
        bit=a&-a;N[a]=N[a^bit]|adj[bit.bit_length()-1]
    return N

def subs(a):
    q=a
    while True:
        yield q
        if not q:return
        q=(q-1)&a

def solve(adj,k):
    n=len(adj);V=(1<<n)-1;N=hood_table(adj);pc=[v.bit_count() for v in range(V+1)]
    solo={V:0};q=deque([V]);best=10**9
    while q:
        a=q.popleft();depth=solo[a]
        for r in subs(a):
            if pc[a]-pc[r]>k:continue
            t=N[r]
            if t not in solo:solo[t]=depth+1;q.append(t)
    tau=solo.get(0)
    # Complete direct nested game; at every move S subset R, so no unknown compression is used here.
    initial=(V,V);D={initial:0};q=deque([initial]);parent={};terminal=None
    while q:
        a,b=q.popleft();depth=D[a,b]
        if not a and not b:terminal=(a,b);break
        for r in subs(a):
            c=pc[a]-pc[r]
            if c>k:continue
            for s in subs(b&r):
                if c+pc[b]-pc[s]>k:continue
                t=(N[r],N[s])
                if t not in D:D[t]=depth+1;parent[t]=((a,b),(r,s));q.append(t)
    if terminal is None:return {'tau':tau,'joint':None}
    schedule=[];cur=terminal
    while cur!=initial:
        old,sur=parent[cur];schedule.append({'before':old,'survivor':sur});cur=old
    schedule.reverse()
    # Exact serial schedules: solo first-arrival to a state a; on final shot use all spare budget in copy2.
    # The second copy's suffix is computed by reverse solo graph.
    reverse=[[] for _ in N]
    for a in range(V+1):
        for r in subs(a):
            if pc[a]-pc[r]<=k:reverse[N[r]].append(a)
    rem={0:0};q=deque([0])
    while q:
        v=q.popleft()
        for u in reverse[v]:
            if u not in rem:rem[u]=rem[v]+1;q.append(u)
    serial=10**9
    for a,t in solo.items():
        if 0<pc[a]<=k:
            spare=k-pc[a]
            for r in subs(V):
                if n-pc[r]<=spare and N[r] in rem:serial=min(serial,t+1+rem[N[r]])
    return {'tau':tau,'joint':D[terminal],'serial':serial,'schedule':schedule,'states':len(D)}

def run(require_matching=False,require_loop=False):
    rng=random.Random(241026);checked=0;start=time.process_time()
    for n in range(3,8):
        for trial in range(100):
            adj=[0]*n
            for i in range(n):
                for j in range(i,n):
                    if rng.random()<.3:
                        adj[i]|=1<<j;adj[j]|=1<<i
            if any(not x for x in adj):continue
            if require_loop and not any(a&(1<<i) for i,a in enumerate(adj)):continue
            if require_matching and any(y.bit_count()<x.bit_count() for x,y in enumerate(hood_table(adj))):continue
            for k in range(1,n):
                out=solve(adj,k);checked+=1
                if out['joint'] is not None and out['joint']<out['serial']:
                    ans={'status':'generic seriality FALSE','adj':adj,'n':n,'k':k,**out,'checked':checked,'CPU_seconds':time.process_time()-start}
                    Path(__file__).with_name('upper_nested_loop_matching_counter.json' if require_loop else 'upper_nested_matching_counter.json' if require_matching else 'upper_nested_counter.json').write_text(json.dumps(ans,indent=2)+'\n');print(ans);return
    ans={'status':'no counterexample in bounded random audit','checked':checked,'CPU_seconds':time.process_time()-start}
    Path(__file__).with_name('upper_nested_loop_matching_counter.json' if require_loop else 'upper_nested_matching_counter.json' if require_matching else 'upper_nested_counter.json').write_text(json.dumps(ans,indent=2)+'\n');print(ans)
if __name__=='__main__':
    import sys
    run('--matching' in sys.argv,'--loop' in sys.argv)

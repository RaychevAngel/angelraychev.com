"""Exact two-cohort budget allocation inside independent fixed corner-prefix families.
This is a physical upper construction, not an unrestricted optimality theorem.
All four relative anchor-phase choices are retained. Per-horizon Pareto update
uses inverse neighborhood triangles and a sliding maximum, O(h) per phase pair.
"""
from pathlib import Path
from collections import deque
from bisect import bisect_right
import sys,importlib.util,json,time
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('prefix_clock',ROOT/'research/uniform-history-2026-10-23/root-prefix-clock.py')
P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)

def profiles(w,n):
    h=w*n//2
    g=[[P.neighborhood_size(w,n,p,a) for a in range(h+1)] for p in (0,1)]
    inv=[[bisect_right(row,a)-1 for a in range(h+1)] for row in g]
    return g,inv

def update(front,ia,ib,k):
    h=len(front)-1;v=[-1]*(h+1)
    for a,b in enumerate(front):
        if b>=0:
            u=ia[a];v[u]=max(v[u],ib[b])
    suffix=[-1]*(h+2)
    for a in range(h,-1,-1):suffix[a]=max(v[a],suffix[a+1])
    q=deque();out=[]
    for a in range(h+1):
        while q and q[0]<a-k:q.popleft()
        if v[a]>=0:
            while q and q[-1]+v[q[-1]]<=a+v[a]:q.pop()
            q.append(a)
        best=suffix[a]+k if suffix[a]>=0 else -1
        if q:best=max(best,q[0]+v[q[0]]+k-a)
        out.append(min(h,best))
    assert all(out[a]>=out[a+1] for a in range(h))
    return out

def brute_update(front,ia,ib,k):
    h=len(front)-1;out=[-1]*(h+1)
    for a,b in enumerate(front):
        if b<0:continue
        u,v=ia[a],ib[b]
        for x in range(min(h,u+k)+1):out[x]=max(out[x],min(h,v+k-max(0,x-u)))
    return out

def solve(w,n,k,history=False):
    assert w<=n and w*n%2==0 and k>=w//2+1
    start=time.process_time();g,inv=profiles(w,n);h=w*n//2
    fronts={(p,q):[0]+[-1]*h for p in (0,1) for q in (0,1)}
    saved=[fronts] if history else None;t=0;clock={}
    while len(clock)<4:
        t+=1
        fronts={(p,q):update(fronts[1-p,1-q],inv[p],inv[q],k) for p in (0,1) for q in (0,1)}
        for phase,F in fronts.items():
            if F[h]>=h and phase not in clock:clock[phase]=t
        if history:saved.append(fronts)
    ans={'w':w,'n':n,'k':k,'joint_prefix_upper':min(clock.values()),'phase_pair_clocks':{str(p):v for p,v in clock.items()},'solo_prefix_clocks':[P.clock(w,n,k,p) for p in (0,1)],'CPU_seconds':time.process_time()-start}
    if history:return ans,(g,inv,saved)
    return ans

def reconstruct(w,n,k,phase,data):
    g,inv,saved=data;h=w*n//2;p,q=phase;a=b=h;t=next(t for t,F in enumerate(saved) if F[p,q][h]>=h);out=[]
    while t:
        nextF=saved[t-1][1-p,1-q]
        selected=None
        for x,y in enumerate(nextF):
            if y<0:continue
            u,v=min(a,inv[p][x]),min(b,inv[q][y])
            if a-u+b-v<=k:selected=(u,v);break
        assert selected is not None
        u,v=selected;out.append({'phases':[p,q],'before':[a,b],'survivors':[u,v],'quota':[a-u,b-v]})
        a,b=g[p][u],g[q][v];p^=1;q^=1;t-=1
    assert a==b==0
    return out

def literal_replay(w,n,k,phase,rows):
    # Cohort0 starts in physical color0; cohort1 in color1. Choose a corner
    # of the appropriate checkerboard color so its relative phase is prescribed.
    even_axis=0 if w%2==0 else 1
    orders=[]
    for cohort,rel in enumerate(phase):
        flip=cohort^rel
        byphase=[]
        for p in (0,1):
            cells=[(x,y) for x in range(w) for y in range(n) if (x+y)%2==p]
            def key(v):
                x,y=v
                if flip:
                    if even_axis==0:x=w-1-x
                    else:y=n-1-y
                return x+y,-x
            byphase.append(sorted(cells,key=key))
        orders.append(byphase)
    V={(x,y) for x in range(w) for y in range(n)};belief=V.copy();shots=[]
    for t,row in enumerate(rows):
        shot=set()
        for c in (0,1):
            a=row['before'][c];u=row['survivors'][c]
            shot.update(orders[c][c^(t%2)][u:a])
        assert len(shot)<=k
        belief-=shot;shots.append(sorted(shot))
        if belief:belief={z for x,y in belief for z in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if z in V}
        assert bool(belief)==(t+1<len(rows))
    return shots

def audit():
    start=time.process_time();checks=0;replays=0;rows=[]
    for w,n in [(2,4),(3,4),(4,4),(4,5),(5,6)]:
        h=w*n//2;g,inv=profiles(w,n)
        for k in range(w//2+1,min(h,2*w)+1):
            ans,data=solve(w,n,k,True)
            for t in range(1,len(data[2])):
                for p in (0,1):
                    for q in (0,1):
                        assert data[2][t][p,q]==brute_update(data[2][t-1][1-p,1-q],inv[p],inv[q],k);checks+=1
            for phase,v in ans['phase_pair_clocks'].items():
                p,q=map(int,phase.strip('()').split(','));path=reconstruct(w,n,k,(p,q),data);literal_replay(w,n,k,(p,q),path);replays+=1
            rows.append(ans)
    return {'status':'PASS','triangle_updates_checked':checks,'literal_full_board_replays':replays,'rows':rows,'CPU_seconds':time.process_time()-start}

if __name__=='__main__':
    if '--audit' in sys.argv:
        out=audit();name='upper-joint-prefix-audit.json'
    else:
        w,n,k=map(int,sys.argv[1:4]);out=solve(w,n,k);name=f'upper-joint-prefix-{w}-{n}-{k}.json'
    Path(__file__).with_name(name).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))

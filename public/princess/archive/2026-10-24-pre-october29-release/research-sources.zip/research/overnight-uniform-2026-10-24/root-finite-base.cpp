// Exact integer port of the accepted comparison_periodic.py finite certificate.
// This is a finite base, not an extrapolation in width or budget.
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <iostream>
#include <numeric>
#include <vector>
using I=long long;
using Z=std::array<I,10>; // B[3], C[3], X[2], Y[2]
I R(I x){assert(x>=0); I r=std::sqrt((long double)x);while(r*r<x)++r;while(r&&(r-1)*(r-1)>=x)--r;return r;}
I rho(I x){assert(x>=0);I r=(std::sqrt((long double)(4*x+1))-1)/2;while(r*(r+1)<x)++r;while(r&&(r-1)*r>=x)--r;return r;}
I small(int i,int j,I t){
 if(j){I c=i+2*j-2;return c+std::max<I>(2,R(std::max<I>(0,t-2*c)));}
 if(i){I c=i-1;return c+std::max<I>(1,rho(std::max<I>(0,t-2*c)));}
 return t?std::min(rho(2*t),rho(t)+1):0;
}
I large(int i,int j,I d){
 int a=2-i,b=2-j;
 if(b)return a+b+std::max<I>(0,R(std::max<I>(0,d-b+1))-1);
 if(a)return a+rho(d);
 return d?std::min(rho(2*d)+1,1+R(d+1)):0;
}
Z initial(I k){I m=k/2;return {0,-1,-1,m,m,m,0,0,m,m};}
Z shift(Z z,I a){for(auto &v:z)v+=a;return z;}
Z next(int w,int n,I k,const Z& z){
 bool inf=n==0;I b=w/2,h=I(w)*n/2;Z out{};
 for(int off:{0,3})for(int c=0;c<3;++c){
  I best=0;
  for(int i=0;i<=c;++i)for(int j=0;j<3;++j){
   I t=z[off+j];if(t<std::max(1,j))continue;
   if(!inf)t=std::min(t,h-2+j);
   bool exception=(w%2==0&&i==1&&j==1)||(w%2==1&&i==2&&j==0);
   if(!inf&&n==2*b+1&&i==2&&j==0)exception=true;
   I s=std::min(small(i,j,t),b+!exception);
   if(!inf)s=std::min(s,large(i,j,h-t));
   I q=t-s;if(!inf)q=std::min(q,h-2+i);
   if(q>=std::max(1,i))best=std::max(best,q);
  }
  out[off+c]=k+best;if(!inf)out[off+c]=std::min(out[off+c],h-2+c);
 }
 for(int off:{6,8})for(int p=0;p<2;++p){
  I t=z[off+1-p];
  if(!inf&&t==h){out[off+p]=h;continue;}
  I low=(p==0?rho(t):R(t));
  I cost=std::min(low,b+(w%2&&p==1));
  if(!inf){
   I high;
   if(w%2)high=(p==0?R(h-t):1+rho(h-t));
   else high=((1-p)==n%2?R(h-t):1+rho(h-t));
   cost=std::min(cost,high);
  }
  out[off+p]=k+t-cost;if(!inf)out[off+p]=std::min(out[off+p],h);
 }
 return out;
}
bool normal(int w,const Z&z){
 for(int off:{0,3}){
  I a=z[off],b=z[off+1],c=z[off+2];
  if(w%2==0){if(a!=c-1||b!=c)return false;}
  else if(a!=b||c-a<0||c-a>1)return false;
 }
 return true;
}
struct Entry{I day,safe,period,solo,full;Z z;};
Entry entry(int w,I k){
 I b=w/2,A=b*(b+1)+1,M=0,t=0;Z z=initial(k);
 for(;;){
  M=std::max(M,*std::max_element(z.begin(),z.end()));
  if(*std::min_element(z.begin(),z.end())>=A&&normal(w,z))break;
  z=next(w,0,k,z);++t;assert(t<=4*A+20);
 }
 Z f=next(w,0,k,z);M=std::max(M,*std::max_element(f.begin(),f.end()));
 assert(next(w,0,k,f)==shift(z,2*k-w));
 I g=std::gcd<I>(w,2*k-w);
 return {t,M+std::max(b*b+1,k+2),2*(2*k-w)/g,2*w/g,4*w/g,z};
}
struct Bound{I low,up;std::vector<Z>trace;};
Bound bounds(int w,int n,I k,bool trace=false){
 I h=I(w)*n/2;if(k>=h){I t=k>=2*h?1:2;return {t,t,{}};}
 Z z=initial(k);for(int c=0;c<3;++c)z[3+c]=std::min(z[3+c],h-2+c);
 I low=-1,up=-1,t=0,prev=-1;std::vector<Z> tr;
 while(low<0||up<0){
  if(trace)tr.push_back(z);
  if(low<0&&z[2]==h)low=2*t-(prev==h);
  if(up<0){
   if(std::max(z[6],z[7])==h)up=2*t;
   if(std::max(z[8],z[9])==h)up=(up<0?2*t+1:std::min(up,2*t+1));
  }
  if(low>=0&&up>=0)break;
  prev=z[5];z=next(w,n,k,z);++t;assert(t<4*I(w)*n);
 }
 assert(low<=up);return {low,up,std::move(tr)};
}
void line(int w,I k,int parity,const Entry&e){
 int n0=std::max<I>(w,(2*e.safe+w-1)/w);n0+=(n0%2!=parity);
 int nmin=w+(w%2!=parity);I maximum=-1;std::vector<std::array<I,3>>rows;
 for(int n=nmin;n<n0+e.period;n+=2){auto b=bounds(w,n,k);maximum=std::max(maximum,b.up-b.low);rows.push_back({n,b.low,b.up});}
 auto a=bounds(w,n0,k,true),b=bounds(w,n0+e.period,k,true);
 assert(a.trace.at(e.day)==e.z&&b.trace.at(e.day)==e.z);
 assert(b.trace.size()==a.trace.size()+e.solo);
 assert(b.low==a.low+e.full&&b.up==a.up+e.full);
 for(I t=0;t<=e.day;++t)assert(a.trace[t]==b.trace[t]);
 for(I t=e.day;t<I(a.trace.size());++t)assert(b.trace[t+e.solo]==shift(a.trace[t],I(w)*e.period/2));
 std::cout<<"{\"w\":"<<w<<",\"k\":"<<k<<",\"parity\":"<<parity<<",\"first_stable_length\":"<<n0<<",\"length_period\":"<<e.period<<",\"entry_day\":"<<e.day<<",\"safe_h\":"<<e.safe<<",\"maximum_gap\":"<<maximum<<",\"rows\":[";
 for(size_t j=0;j<rows.size();++j){auto r=rows[j];if(j)std::cout<<",";std::cout<<"["<<r[0]<<","<<r[1]<<","<<r[2]<<"]";}
 std::cout<<"]}"<<std::endl;
}
int main(int argc,char**argv){
 int first=argc>1?std::stoi(argv[1]):65,last=argc>2?std::stoi(argv[2]):319;
 int maxd=argc>3?std::stoi(argv[3]):19;
 for(int w=first;w<=last;++w)for(int d=1;d<=maxd;++d){
  I k=w/2+d;auto e=entry(w,k);
  line(w,k,0,e);if(w%2==0)line(w,k,1,e);
 }
}

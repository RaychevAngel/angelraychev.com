# An exact corner-labelled boundary bound from finite propagation

24 October 2026. Ordinary geometric theorem proposed for independent review.
This is an exact early-boundary statement, not a full fixed-anchor normal form.

Let w<=n be an even-area rectangle, b=floor(w/2), h=wn/2, and k>=b+1.
Count t unsuccessful inspection-and-move updates from the full initial board,
so the two cohort hole sets start empty at t=0. Let

    P_0=(0,0),
    P_(t+1)^0=G(P_t^1+k),  P_(t+1)^1=F(P_t^0+k),

where F(z)=z-ceil(sqrt(z)) and G(z)=z-rho(z). These are the genuine infinite-
quadrant prefix hole capacities, indexed by CURRENT relative color:0 means
the color of the corner,1 the opposite color. Each coordinate is nondecreasing
in t, by monotonicity of the two maps and induction from zero.

## 1. The backwards cone needs no compression hypothesis

Suppose an actual hole set U at time t, in one cohort, lies in the ball of
Manhattan radius D around an actual rectangle corner C. If

    D+t<=w-1,                                        (1)

then |U|<=P_t^p, where p is U's current color relative to C.

Proof. Embed the rectangle at C into the infinite quadrant and put

    C_s=N_quad^(t-s)(U),   0<=s<=t.

Every C_s lies inside the physical rectangle by (1). More particularly, every
vertex of C_(s+1) has radius at most D+t-s-1<=w-2, so its complete quadrant
neighborhood lies in the rectangle and agrees with its physical neighborhood.

Let H_s be the actual holes of this cohort and I_s its actual inspections.
For v in H_(s+1) intersect C_(s+1), all its quadrant neighbors lie in

    (H_s intersect C_s) union (I_s intersect C_s).

Starting from no quadrant holes, inspect only I_s intersect C_s on day s.
Induction using erosion shows that its quadrant holes contain H_s intersect C_s
at every s, and hence contain U at time t. The daily cost is at most k.

In the quadrant, the exact own/opposite cardinality profiles bound each target
hole count q by q+ceil(sqrt(q)) or q+1+rho(q) predecessor rooms, respectively.
Their inverse maps are G and F. Induction therefore bounds this actual quadrant
process by the indicated zero-origin prefix coordinate P_t^p. This proves (1).

## 2. Which actual events need a phase label

Let Q be the total holes after an actual update, and let s be its original
total survivor surplus. Then

    Q_old+k>=Q+s.

For Q<=b(b-1), write r=ceil(sqrt(Q)). A FIRST violation of the maximum
ordinary quadrant pair can occur only when

    1<=r<b,  r(r-1)<Q<=r²,  s=r.                    (2)

Indeed max P_(t+1)>=F(max P_t+k). If s>=1+rho(Q), the exact F inverse
already forbids a first violation. If Q<=r(r-1), the latter cost is r, so
a violation would need s<=r-1. The total dual hole surplus is at most s;
the small-side capacities then give Q<=s², impossible. The co-small
alternative is excluded because Q<=b(b-1) and h>=2b². This also handles
r=b: its entire permitted interval is below its pronic wall.

In (2), all holes lie in a SINGLE actual cohort and a SINGLE two-step
connected component, of surplus r, at one actual corner C. For r>=2,
any split into two positive-surplus components has capacity at most
(r-1)²+1<=r(r-1)<Q. The component is in a genuine corner quadrant because
r<b. The accepted connected localization theorem gives radius at most2r-2.
For r=1, Q=1 and surplus1 force a degree-two board corner directly.
The target has C's own color, since the opposite-color capacity is r(r-1).

Consequently any first violation in the early pronic range must satisfy

    t+2r-2>w-1.                                     (3)

This is a geometric restriction on a possible counterexample, not evidence
that the entire pronic range is already proved.

## 3. A uniform exact fast contract for every sensitive event

Choose1<=R<=b-1. Let

    J(R²)=min{t:min(P_t^0,P_t^1)>=R²}.

Assume the entirely numerical condition

    J(R²)+2R<=w+2.                                  (4)

Then EVERY actual event satisfying (2) with r<=R, at ANY actual time t,
obeys the matching-phase bound

    Q<=P_t^0.                                       (5)

If t>=J(R²), this follows from monotonicity and Q<=R². Otherwise
t<=J(R²)-1, so t+2r-2<=w-1 by (4), and Section1 applies to the actual
localized component. The current relative phase is0, as established above.

This conclusion is stronger than a maximum-phase bound: at a fast sensitive
event, the ordinary zero-origin orbit matching its actual corner is available
at the SAME elapsed index. The chosen corner may depend on the event; (5)
does not authorize switching between ordinary reference orbits at other times
without the separate history accounting.

The condition (4) is a uniform arithmetic condition on w,k,R. A numerical
estimate for J can turn it into a simple parameter range. Small-budget cutoffs
with extra additive margins must be checked separately; they cannot be silently
included under the floor(3k/5) calculation.

## Dependencies and boundary

The component localization and small-side/co-small-side capacities are the
accepted results in `../uniform-history-2026-10-23/physical-dominant-corner.md`.
The exact quadrant inverse identities are the same ones used by the accepted
boundary clocks. No new infinite-tiling, optimization, or Lean assertion is
made. In particular this does not conflict with the retained12x12 moving-front
counterexample, whose first fixed-anchor improvement occurs beyond b(b-1).

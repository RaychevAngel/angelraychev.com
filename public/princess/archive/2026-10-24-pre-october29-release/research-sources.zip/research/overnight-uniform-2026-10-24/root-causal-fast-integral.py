"""Exact rational certificate for the ordinary-quadrant hitting-time constant."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json, hashlib
P=Path(__file__).resolve().parent
N=256;scale=10**6;step=F(9,25*N);a=F(199,200)
terms=[]
for i in range(1,N+1):
    x=i*step+F(1,200)
    # An upper rational square root, using exact integer inequalities.
    r=isqrt(x.numerator*scale**2//x.denominator)
    if r*r*x.denominator<x.numerator*scale**2:r+=1
    upper=F(r,scale)
    assert upper*upper>=x and upper<a
    terms.append(step/(a-upper))
upper_sum=sum(terms,F(0));margin=F(13,20)-upper_sum
assert margin>0
out={'status':'PASS','claim':'The scaled integral at k=200 is less than13/20.',
     'right_Riemann_intervals':N,'rational_root_scale':scale,
     'upper_sum_decimal_for_reading':float(upper_sum),
     'positive_margin_decimal_for_reading':float(margin),
     'all_comparisons_exact_rational':True,
     'certificate_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(P/'root-causal-fast-integral.json').write_text(json.dumps(out,indent=2)+'\n')
print(out)

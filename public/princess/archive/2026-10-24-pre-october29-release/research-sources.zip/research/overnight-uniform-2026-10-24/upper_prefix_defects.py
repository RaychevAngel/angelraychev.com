"""Bounded physical upper search with small area-preserving pyramid defects.
A diagnostic construction search, not a completeness/normal-form assertion.
"""
from pathlib import Path
import sys,json,time,functools
from collections import deque
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'))
from resumed_even_construction_prefix import PrefixGame

def search(w,n,k,defects=1,beam=1000):
    start=time.process_time();g=PrefixGame(w,n);h=w*n//2
    @functools.lru_cache(None)
    def family(p,q):
        ans=set()
        for order in (g.orders[p][0],g.orders[p][4]):
            mask=order[q];cells=[v for i,v in enumerate(g.colors[p]) if mask>>i&1]
            heights=tuple(max((y for x,y in cells if x==c),default=(p-c)%2-2) for c in range(w))
            visited={heights:mask};front={heights:mask}
            for d in range(defects):
                new={}
                for a,ma in front.items():
                    for x in range(w):
                        if a[x]<0 or any(a[j]!=a[x]-1 for j in (x-1,x+1) if 0<=j<w):continue
                        b=list(a);b[x]-=2;mb=ma^(1<<g.index[p][x,a[x]])
                        for z in range(w):
                            if b[z]+2>=n or any(b[j]!=b[z]+1 for j in (z-1,z+1) if 0<=j<w):continue
                            c=b.copy();c[z]+=2;c=tuple(c)
                            if c not in visited:
                                mc=mb|(1<<g.index[p][z,c[z]]);new[c]=mc;visited[c]=mc
                front=new
            ans.update(visited.values())
        return tuple(ans)
    # Phase0 initial color only; all square symmetries make the other initial choice equivalent for the upper family.
    layer={g.full};parents={};p=0;depth=0;total=1;layers=[]
    # Stronger existing valid arithmetic lower can be added later; this first diagnostic uses only exact set transitions.
    while layer:
        terminal=[a for a in layer if a.bit_count()<=k]
        layers.append({'day':depth,'states':len(layer),'minimum':min(map(int.bit_count,layer)),'family_cache':family.cache_info().currsize})
        if terminal:
            a=min(terminal,key=int.bit_count);end=a;path=[]
            for t in range(depth,0,-1):
                old,r=parents[t,a];path.append((old,r));a=old
            path.reverse();path.append((end,0));shots=[];belief=set(g.colors[0]);V={(x,y)for x in range(w)for y in range(n)}
            for t,(a,r) in enumerate(path):
                shot={v for i,v in enumerate(g.colors[t%2]) if (a^r)>>i&1};assert len(shot)<=k
                belief-=shot;belief={u for x,y in belief for u in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if u in V}
                assert bool(belief)==(t+1<len(path));shots.append(sorted(shot))
            return {'w':w,'n':n,'k':k,'defects':defects,'beam':beam,'solo_upper':depth+1,'final_shot':end.bit_count(),'palindrome_upper':2*(depth+1)-(2*end.bit_count()<=k),'physical_solo_replay':True,'layers':layers,'shots':shots,'CPU_seconds':time.process_time()-start}
        nxt={}
        for a in layer:
            q=a.bit_count()-k
            for r in family(p,q):
                if not r&~a:
                    b=g.hood(p,r)
                    if b not in nxt:nxt[b]=(a,r)
        if len(nxt)>beam:
            # Heuristic beam only: cardinality and exact next greedy prefix reachability.
            keys=sorted(nxt,key=lambda a:(a.bit_count(),a))[:beam];nxt={a:nxt[a] for a in keys}
        depth+=1;p^=1
        for a,par in nxt.items():parents[depth,a]=par
        layer=set(nxt);total+=len(layer)
        if depth%20==0:print('layer',depth,'states',len(layer),'minimum',min(map(int.bit_count,layer),default=-1),'CPU',round(time.process_time()-start,2),flush=True)
    return {'status':'no construction in restricted search','layers':layers,'CPU_seconds':time.process_time()-start}

if __name__=='__main__':
    w,n,k,d=map(int,sys.argv[1:5]);out=search(w,n,k,d);name=f'upper-prefix-defects-{w}-{n}-{k}-{d}.json';Path(__file__).with_name(name).write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ['shots','layers']})

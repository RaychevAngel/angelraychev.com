# Upper/construction lane: reconciled checkpoint

24 October 2026. Independent final audit is `upper-final-assembly-audit.json`.

The strongest accepted all-input statement is a computable lower and
constructive upper bound with gap at most **eight days**, throughout
w<=n and k>=floor(w/2)+1. The finite base contains exactly9,538 distinct
width/budget/length-parity lines for widths65..399 and excesses1..19,
with105,621 finite representatives and exact affine insertion coverage of
all later lengths. I rechecked every coverage key, every consecutive finite
length, every gap and the current source hashes; all match the prior
independently reviewed certificate. The analytic high-width and
large-excess ranges overlap this base without a missing parameter range.

A separate actual transport construction gives **four-day brackets** when
w=2b,b>=200 and either k=b+1,n>=2b, or k=b+d,2<=d<=19,
n>=2b+2d-2. The complete recurrence definitions and bounds are spelled out
in `upper-four-day-transport-families.md`; this is a uniform parameter-family
theorem, not an extrapolation from examples. It preserves the final
inspection quota and supplies genuine relative-corner phase freedom.

The latest both-ordinary-MAX diagnostic covers8,113 instances, including
6,279 exact matches, with maximum observed gap4. It is valuable pointwise
evidence and improves accepted computable lower bounds where its causal
guards pass. It is **not** a uniform four-day theorem. All-input zero gap
remains unproved.

## What most directly remains

1. The early and late necessary hybrids still allow an equal injection into
both relative phases. Replacing all-cheap scalar injection by guarded actual
ordinary MAX removes numerical excess but retains a free phase choice.
A causal fixed-phase or explicit phase-credit theorem would address this
remaining relaxation. Independent-corner concentration already holds for
arbitrary quota words only in MAX form; the stronger constant-quota
saturation question is still being investigated.

2. The even-width reflection bridge has a proved length/budget condition.
Short rectangles at larger excess may not have enough central time to move
the front across the width. The descending-word visibility test cannot
recover extra credit there: its purported improvement collapses exactly
to the existing final-root credit at feasible budgets. This fact was already
in the September source; the new note is a fresh audit, not a new result.
Other legal front families or sharper lower phase restrictions remain viable.

3. Odd-width phase exchange is not covered by even-width reflection.
Reflection across the odd short side preserves corner color. Reflection
across the even long side changes it, but rotating the old prefix introduces
height jumps outside the accepted height-walk class and may expose an
expansion cost above budget. A defect wholly inside the ordinary downward
pyramid interior cannot change its phase-dependent strip expansion. Any
successful odd-width construction must use a real boundary contact or a
more general support, or the lower bound must retain the unavoidable phase.
No odd-width impossibility theorem is claimed.

4. Generic graph shortcuts do not resolve the remaining geometry. The new
31-vertex connected looped Hall relation has exact solo time6 at budget8,
but a literal ten-day two-copy strategy, contradicting T>=2*solo-1 even
with connectedness and a loop. The proof uses a three-twin blow-up of the
retained ten-vertex counterexample and one permanently inspected connector.
This is not a folded-grid counterexample, so a rectangle-specific theorem
remains possible; symmetry, Hall noncontraction and connectedness alone
are insufficient.

The new work is ordinary mathematics with independent source reviews and
exact computational receipts. This lane made no public edits, no new Lean
coverage claim, and no fixed-operation numerical simplification.

The final bounded algebra review produced a useful conditional advance:
constant-budget last-zero activation order gives a matched-phase total bound
whenever the distinguished ordinary phase's one-day increment pays the other
terminal mass. The rigorous phase-spread estimate is at most ceil(t/2).
For the exceptional full-triangle-plus-singleton configuration this removes
the free phase under explicit disjoint-cone and positive-increment guards.
The sources are `root-activation-delay.md` and
`lower-activation-order-deficit.md`, independently reviewed in
`upper-activation-delay-review.json`. Their physical slow-history interface
is still outstanding, so no capture-gap claim is added.

The exact correlation of the two ordinary-MAX hybrids is also accepted:
at gate k, early E and late C-k differ by at most one room in each labelled
coordinate. Each hybrid is an exact maximum over single-reset trajectories,
but different coordinates can choose different reset times. That algebra
retains a real constraint without authorizing a free physical phase choice.
See `upper-ordinary-max-correlation-review.json`.

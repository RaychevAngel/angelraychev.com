# An exact fast-boundary guard without a lost inspection day

24 October2026. Quantitative lemma for the causal quadrant comparison.
The physical consequence uses the separately proved backwards-cone lemma;
it does not extend fixed-anchor optimality to the middle of a rectangle.

Let k>=200 and R=floor(3k/5). Define the slower scalar quadrant orbit

    x_0=0, x_(t+1)=x_t+k-ceil(sqrt(x_t+k)).

Let J be its first hitting time of R². Then

    J <= 13k/20+1.                                      (1)

Every coordinate of the ordinary alternating quadrant pair dominates this
scalar orbit: both physical scalar maps are at least its update, and both
are nondecreasing. Thus (1) is an upper bound on the time by which BOTH
matching physical phases have reached the fast target.

## Integral proof with an exact rational constant

Set f(x)=k-1-sqrt(x+k). It is positive and decreasing on[0,R²]. Each
scalar increment is at least f(x_t). If x_(t+1)<R², then

    integral_[x_t,x_(t+1)] du/f(u) >= (x_(t+1)-x_t)/f(x_t) >=1.

Adding the completed intervals before the crossing gives

    J-1 <= integral_0^(R²) dx/(k-1-sqrt(x+k)).

Scale x=k²v. Since R/k<=3/5 and k>=200, the integral divided by k is at
most

    I = integral_0^(9/25) dv/(199/200-sqrt(v+1/200)).

The integrand is positive and increasing. Its256-interval right Riemann
sum, using upper rational square roots with denominator10^6, is less than
0.646963 and hence less than13/20. Every inequality in this numerical
constant check is exact rational arithmetic, including the root brackets;
`root-causal-fast-integral.py/.json` is the reproducible certificate.
This proves (1). The displayed decimal is explanatory, not the certificate.

## Uniform geometric consequence

Let w<=n be even-area, b=floor(w/2), k=b+d, and additionally assume

    k<=40b/37.

Then R<b, and (1) gives

    J+2R <= (13/20+6/5)k+1 =37k/20+1 <=2b+1<=w+2.

This is the exact sufficient guard in the causal quadrant lemma. At a
phase-sensitive good event with hole count Q<=R² and root r<=R, either
the matching ordinary phase has already reached Q, or t<=J-1. In the
latter case the entire backwards dependence cone of the actual corner
component remains inside the corresponding infinite quadrant. The
quadrant isoperimetric inverse can therefore be iterated with the SAME
corner phase and the SAME actual daily quotas from zero initial holes.

Consequently these fast good events are dominated by their matching
ordinary zero-origin physical phase, with NO one-day fast-region shift.

In particular this guard includes every d in1..19 and b>=235, because
37(b+19)<=40b. Smaller widths are not silently covered by this argument.
The earlier special cutoff for k<100 is also not covered.

## Remaining assembly

The old boundary proof used a capped all-G scalar injection to cover fast
good events, costing one physical day in the final comparison. The present
lemma makes that injection unnecessary for the displayed parameter range,
provided the remaining good/bad and corner-change induction is rerun with
the ordinary reference pair. That replacement is a separate obligation:
the numerical guard by itself does not prove a smaller full-game gap.

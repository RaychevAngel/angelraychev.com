"""General inverse-cost variant of the variable-slack proof candidate."""
from __future__ import annotations
import importlib.util
from pathlib import Path
from math import isqrt

P=Path(__file__).resolve().parent
_s=importlib.util.spec_from_file_location('variable_slack_base',P/'comparison_variable_slack.py')
base=importlib.util.module_from_spec(_s)
_s.loader.exec_module(base)


def guards(b:int,d:int,s:int,R:int)->dict:
    result=base.guards(b,d,s,R)
    r,D,k=result['r0'],result['D'],result['k']
    t=1
    while D>(2*t-1)*r+t*(t-1):
        t+=1
    g=s+1-t
    E=r*r-(2*s+3)*r-5*s*s-7*s
    result['inverse_extra']=t
    result['early_gain']=g
    tests=result['tests']
    tests['rewind_range']=d+s+1<=D
    tests['positive_early_gain']=g>=1
    tests['old_early_charge']=k>0 and g*(base.ceil_div(E,2*k)-1)>=D
    result['admissible']=all(tests.values())
    return result


def least_cutoff_for_slack(b:int,d:int,s:int)->dict|None:
    if d<1 or s<2 or b<2*d+3*s+3 or b+d<100:
        return None
    k=b+d
    lo=max(s+1,d+s+1)
    hi=min(3*k//5,b-s-2,k-(d+s+1)-1)
    if lo>hi or not guards(b,d,s,hi)['admissible']:
        return None
    while lo<hi:
        mid=(lo+hi)//2
        if guards(b,d,s,mid)['admissible']:hi=mid
        else:lo=mid+1
    return guards(b,d,s,lo)


def strongest_cutoff(b:int,d:int)->dict|None:
    smax=min((b-2*d-3)//3,isqrt(2*(3*(b+d)//5+1))-2)
    choices=[v for s in range(2,smax+1)
             if (v:=least_cutoff_for_slack(b,d,s)) is not None]
    return min(choices,key=lambda v:(v['R'],v['s'])) if choices else None


if __name__=='__main__':
    import argparse,json
    p=argparse.ArgumentParser();p.add_argument('b',type=int);p.add_argument('d',type=int)
    args=p.parse_args()
    print(json.dumps(strongest_cutoff(args.b,args.d),indent=2))

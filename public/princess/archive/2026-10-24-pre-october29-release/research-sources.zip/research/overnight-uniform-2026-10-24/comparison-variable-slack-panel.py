"""Reuse existing comparison records; mathematical acceptance is separate."""
from pathlib import Path
import importlib.util,json,time,hashlib
P=Path(__file__).resolve().parent
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,P/file)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
m=load('variable_panel_clock','root-asymmetric-clock.py')
v=load('variable_panel_guard','comparison_variable_slack_general.py')
start=time.process_time();rows=[];hist={};worst=[];maximum=-100;choices={}
for old in json.loads((P/'root-shifted-panel.json').read_text())['results']:
    w,n,k=old['w'],old['n'],old['k'];b=w//2;h=w*n//2;d=k-b
    key=(b,d)
    if key not in choices:
        certificate=v.strongest_cutoff(b,d)
        if certificate is None:
            choices[key]=None
            continue
        cut=certificate['R']
        m.m.old.early_api.cutoff=lambda budget,cut=cut:cut
        m.m.old.late_api.cutoff=lambda budget,cut=cut:(cut,cut*cut+budget)
        choices[key]=(certificate,m.endpoints(b,d))
    choice=choices[key]
    if choice is None:continue
    certificate,endpoints=choice
    J=min(e+ell+m.m.faster_middle(b,d,h,q,y,w%2)for q,y,e,ell in endpoints)
    r={**old,'J':J,'P_minus_J':old['P']-J,'lower':2*J+1,
       'gap':old['upper']-2*J-1,'slack':certificate['s'],'cutoff':certificate['R']}
    assert r['gap']>=0,r
    hist[str((w%2,r['P_minus_J']))]=hist.get(str((w%2,r['P_minus_J'])),0)+1
    if r['gap']>maximum:maximum=r['gap'];worst=[r]
    elif r['gap']==maximum:worst.append(r)
    rows.append(r)
files=['comparison-variable-slack-panel.py','comparison_variable_slack.py',
       'comparison_variable_slack_general.py','comparison-variable-slack-cutoff.md',
       'comparison-variable-slack-wide-inverse.md']
out=dict(status='DIAGNOSTIC; proof acceptance is separate',cases=len(rows),
         skipped_parameter_pairs=sum(x is None for x in choices.values()),
         maximum_gap=maximum,histogram=hist,worst=worst,results=rows,
         CPU_seconds=time.process_time()-start,
         source_sha256={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in files})
(P/'comparison-variable-slack-panel.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items()if k not in('worst','results','source_sha256')})
print('worst',worst[:5])

"""Independent literal recurrence checks of the accelerated diagnostic clock."""
from pathlib import Path
import importlib.util, json, hashlib, random, time
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('shifted_check',P/'root-shifted-clock.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)

def literal_physical(w,n,k,seed):
    pair=(seed,seed);day=0;h=w*n//2
    while max(pair)<h:
        pair=m.old.meeting_api.physical(w,n,k,pair);day+=1
    return day

def check():
    start=time.process_time();rng=random.Random(20261024)
    cases={(400,400,201),(401,402,201),(407,408,204),(448,448,225),(448,1344,225)}
    for _ in range(45):
        b=rng.randrange(200,501);w=2*b+rng.randrange(2);n=w+rng.randrange(0,2*b+1)
        if w%2 and n%2:n+=1
        cases.add((w,n,b+rng.randrange(1,20)))
    physical=middle=0;largest_tau_slack=0
    for w,n,k in sorted(cases):
        for seed in(0,k//2):
            literal=literal_physical(w,n,k,seed)
            assert literal==m.physical_clock(w,n,k,seed),(w,n,k,seed,literal)
            physical+=1
        b=w//2;h=w*n//2;d=k-b
        for q,y,e,ell,A,C in m.endpoints(b,d):
            B={f:y for f in m.old.nine.FEATURES};t=0
            while max(B.values())<h-q:B=m.old.nine.step(w,n,k,B);t+=1
            fast=m.faster_middle(b,d,h,q,y,w%2)
            assert fast<=t,(w,n,k,q,y,fast,t)
            largest_tau_slack=max(largest_tau_slack,t-fast);middle+=1
    result={'status':'PASS','physical_literal_comparisons':physical,
            'middle_literal_comparisons':middle,'largest_tau_slack':largest_tau_slack,
            'cases':sorted(cases),'CPU_seconds':time.process_time()-start,
            'scope':'Numerical implementation check only; uniform proof is in the reviewed comparison notes.',
            'sha256':{f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in ('root-shifted-clock.py','root-shifted-clock-check.py')}}
    (P/'root-shifted-clock-check.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ('cases','sha256')})
if __name__=='__main__':check()

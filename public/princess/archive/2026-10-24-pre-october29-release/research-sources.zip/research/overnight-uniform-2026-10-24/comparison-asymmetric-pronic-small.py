"""Attack pronic-cut middle+2 with independent progressive boundary pairs.
Candidate finite residue certificate for the shifted cut; proof supplied separately.
"""
from pathlib import Path
from math import isqrt
import json

def R(x):r=isqrt(x);return r+(r*r<x)
def rho(x):r=(isqrt(4*x+1)-1)//2;return r+(r*(r+1)<x)
def low_step(b,d,X):
 x,y=X;return y+b+d-min(rho(y),b),x+b+d-min(R(x),b+1)
def hole_step(k,X):x,y=X;return y+k-rho(y+k),x+k-R(x+k)
def equal_clock(b,d,Y,M):
 H=b*(b-1)
 if Y<=H:
  return 2+equal_clock(b,d,Y+2*d+1,M)
 x=y=Y;t=0
 if x<=b*b:
  jump=(b*b-x)//d+1;x+=jump*d;y=x;t+=jump
 if max(x,y)>=M:return t
 jump=max(0,(M-x)//(2*d-1)-1);x+=jump*(2*d-1);y=x;t+=2*jump
 while max(x,y)<M:x,y=y+d,x+d-1;t+=1
 return t

def iterate(b,d,C,t):
 X=C
 while t and min(X)<=b*b:
  X=low_step(b,d,X);t-=1
 if t>=2:
  j=t//2;X=tuple(x+j*(2*d-1)for x in X);t-=2*j
 if t:X=low_step(b,d,X)
 return X

def run(b,d,Mextra=0):
 H=b*(b-1);k=b+d;M=b*b+4*b+1+Mextra;h=M+H
 qmax=H;ymax=H+d+1
 cs=[];es=[]
 for high in range(H+1,H+d+2):
  for spread in range(d+2):
   for C in set(((high,high-spread),(high-spread,high))):
    if all(a>=z for a,z in zip(low_step(b,d,C),C)):cs.append(C)
 for high in range(H-d+1,H+1):
  for spread in range(d+2):
   for E in set(((high,high-spread),(high-spread,high))):
    if all(a>=z for a,z in zip(hole_step(k,E),E)):es.append(E)
 worst=10**9;witness=None;checks=0
 for C in cs:
  Y=min(ymax,max(C))
  for E in es:
   Q=min(qmax,max(E));tau=equal_clock(b,d,Y,h-Q);X=iterate(b,d,C,tau+2)
   margins=tuple(X[p]+E[1-p]-h for p in(0,1));margin=max(margins);checks+=1
   if margin<worst:worst=margin;witness=dict(C=[z-H for z in C],E=[z-H for z in E],Y=Y-H,Q=Q-H,tau=tau,margins=margins,X=[z-(h-H)for z in X])
 return dict(b=b,d=d,Mextra=Mextra,checks=checks,worst_margin=worst,witness=witness)
if __name__=='__main__':
 rows=[run(b,d,t)for d in(1,2)for b in range(200,200+2*d)for t in range(2*d-1)]
 out=dict(status='ASYMMETRIC_MIDDLE_TWO_DAY_CERTIFICATE_CANDIDATE',rows=rows,checks=sum(r['checks']for r in rows),worst=min(r['worst_margin']for r in rows));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

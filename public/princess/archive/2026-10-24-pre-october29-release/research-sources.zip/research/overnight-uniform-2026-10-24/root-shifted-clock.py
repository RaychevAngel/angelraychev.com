"""Necessary shifted-boundary clock and physical prefix comparison.

The faster middle comparator is proved in comparison-shifted-pronic-middle.md.
Central jumps implement its existing exact affine recurrence only to make
bound comparisons practical; this is not work on the final O(1) goal.
"""
from pathlib import Path
from math import isqrt
from functools import lru_cache
import importlib.util, argparse, json, time
HERE=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=load('shifted_prior_clock',HERE.parent/'joint-history-2026-10-24/root-joint-hybrid-clock.py')
def R(x):return isqrt(x-1)+1 if x else 0
def rho(x):
    s=(isqrt(4*x+1)-1)//2;return s+(s*(s+1)<x)
def ceildiv(x,d):return -(-x//d)
def faster_middle(b,d,h,Q,Y,odd):
    H=b*(b-1);M=h-Q
    assert M>Y
    if not odd:return max(1,ceildiv(M-Y-(Y<=H),d))
    elapsed=0
    if Y<=H:Y+=2*d+1;elapsed+=2
    if Y<=b*b:
        steps=(b*b-Y)//d+1;Y+=steps*d;elapsed+=steps
    if Y>=M:return elapsed
    stride=2*d-1
    even=2*max(0,ceildiv(M-Y,stride))
    oddtime=1+2*max(0,ceildiv(M-Y-d,stride))
    return elapsed+min(even,oddtime)
def physical_clock(w,n,k,seed=0):
    b=w//2;h=w*n//2;X=(seed,seed);day=0
    L=b*(b+1)+1;stride=2*k-w
    while max(X)<h:
        if min(X)>=L and max(X)<h-L:
            jumps=(h-L-max(X))//stride
            if jumps:
                X=tuple(x+jumps*stride for x in X);day+=2*jumps
                continue
        X=old.meeting_api.physical(w,n,k,X);day+=1
    return day
@lru_cache(maxsize=2048)
def endpoints(b,d):
    k=b+d;H=b*(b-1);cut=H-d+1
    em=old.early_api.EarlyHybrid(k);e=em.clock(cut)
    q0=min(H,em.maxima[e]);qs=[q0]+([H] if q0<H else [])
    es={q:em.clock(q) for q in qs}
    lm=old.late_api.hybrid_gate_curve(k,H+2,keep_phases=True)
    ell=old.late_api.gate_time(lm,cut+1)
    y0=min(H+2,lm['maxima'][ell]);ys=[y0]+([H+2] if y0<H+2 else [])
    ls={y:old.late_api.gate_time(lm,y) for y in ys}
    return [(q,y,es[q],ls[y],em.states[es[q]],lm['phases'][ls[y]]) for q in qs for y in ys]
def run(w,n,k,details=False):
    assert w<=n and w*n%2==0
    b=w//2;d=k-b;h=w*n//2
    assert b>=200 and 1<=d<=19
    pairs=[]
    for q,y,e,ell,A,C in endpoints(b,d):
        tau=faster_middle(b,d,h,q,y,w%2)
        pairs.append(dict(Q=q,Y=y,e=e,ell=ell,middle=tau,J=e+tau+ell,A=A,C=C))
    J=min(p['J'] for p in pairs)
    P=physical_clock(w,n,k)
    U=min(2*P,2*physical_clock(w,n,k,k//2)+1)
    result=dict(w=w,n=n,k=k,P=P,J=J,P_minus_J=P-J,lower=2*J+1,upper=U,gap=U-2*J-1)
    assert result['gap']>=0,result
    if details:result['pairs']=pairs
    return result
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('w',type=int);ap.add_argument('n',type=int);ap.add_argument('k',type=int);ap.add_argument('--details',action='store_true');a=ap.parse_args()
    print(json.dumps(run(a.w,a.n,a.k,a.details)))

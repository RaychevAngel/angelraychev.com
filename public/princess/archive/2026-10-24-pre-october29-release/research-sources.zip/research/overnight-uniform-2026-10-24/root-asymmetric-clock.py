"""Asymmetric boundary comparison diagnostic. No new uniform gap assertion."""
from pathlib import Path
from functools import lru_cache
import importlib.util, argparse, json, time
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('asymmetric_base',P/'root-shifted-clock.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
@lru_cache(maxsize=4096)
def endpoints(b,d):
    k=b+d;H=b*(b-1);cut=H-d+1
    em=m.old.early_api.EarlyHybrid(k);e=em.clock(cut)
    q0=min(H,em.maxima[e]);qs=[q0]+([H] if q0<H else [])
    lm=m.old.late_api.hybrid_gate_curve(k,H+d+1,keep_phases=True)
    ell=m.old.late_api.gate_time(lm,H+1)
    y0=min(H+d+1,lm['maxima'][ell]);ys=[y0]+([H+d+1] if y0<H+d+1 else [])
    return [(q,y,em.clock(q),m.old.late_api.gate_time(lm,y)) for q in qs for y in ys]
def run(w,n,k,detail=False):
    b=w//2;d=k-b;h=w*n//2
    assert w<=n and w*n%2==0 and b>=200 and 1<=d<=19
    rows=[dict(Q=q,Y=y,e=e,ell=ell,tau=m.faster_middle(b,d,h,q,y,w%2)) for q,y,e,ell in endpoints(b,d)]
    for r in rows:r['J']=r['e']+r['ell']+r['tau']
    J=min(r['J'] for r in rows);clock=m.physical_clock(w,n,k)
    upper=min(2*clock,2*m.physical_clock(w,n,k,k//2)+1)
    out=dict(w=w,n=n,k=k,P=clock,J=J,P_minus_J=clock-J,lower=2*J+1,upper=upper,gap=upper-2*J-1)
    assert out['gap']>=0,out
    if detail:out['endpoints']=rows
    return out
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--max-b',type=int,default=300);a=ap.parse_args()
    start=time.process_time();cases=[];worst=[];hist={};maximum=-1
    for b in range(200,a.max_b+1):
        for d in range(1,20):
            for odd in (0,1):
                w=2*b+odd
                lengths={w+odd,w+odd+2,3*w+odd}
                if not odd:lengths.add(w+1)
                for n in lengths:
                    r=run(w,n,b+d)
                    hist[str((odd,r['P_minus_J']))]=hist.get(str((odd,r['P_minus_J'])),0)+1
                    if r['gap']>maximum:maximum=r['gap'];worst=[r]
                    elif r['gap']==maximum:worst.append(r)
                    if odd and r['P_minus_J']>=4:cases.append(run(w,n,b+d,True))
    result=dict(status='Diagnostic only',max_b=a.max_b,maximum_gap=maximum,histogram=hist,worst=worst,odd_four=cases,CPU_seconds=time.process_time()-start)
    (P/'root-asymmetric-panel.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ('worst','odd_four')})
    print('odd_four',cases[:3])

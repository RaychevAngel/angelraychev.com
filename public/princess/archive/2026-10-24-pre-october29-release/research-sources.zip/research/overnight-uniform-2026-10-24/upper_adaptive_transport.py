"""Uniform endpoint-preserving balanced transport and deterministic clock.
Proof: upper-adaptive-transport.md. No unrestricted optimality assertion.
"""
from pathlib import Path
import importlib.util,sys,json,hashlib,time
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'src'))
from bridge_upper_transport import prefix_height
from resumed_even_construction_transport import construct
s=importlib.util.spec_from_file_location('balanced_clock',P/'upper_balanced_clock.py');old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
prefix=old.prefix

def evaluate(w,n):
 result=old.evaluate(w,n);b=w//2;k=b+1;choices=[]
 qa=b*(n-b)+2*b-2;qb=b*(n-b)+3
 for row in result['choices']:
  delta=qa-row['entry_size'];assert delta in(0,1)
  z=qb-delta;phase=(n%2)^1;tail=0
  while z>k:z=prefix.neighborhood_size(w,n,phase,z-k);phase^=1;tail+=1
  tail+=1;solo=row['entry_steps']+row['bridge_steps']+tail
  choices.append({**row,'target_size':qb-delta,'entrance_deficit':delta,'tail_steps':tail,'solo_days':solo,'final_inspections':z,'full_days':2*solo-int(2*z<=k)})
 return {**result,'choices':choices,'selected':min(choices,key=lambda r:(r['full_days'],r['solo_days'])),'source':'upper-adaptive-transport.md','status':'Uniform constructive upper; not an optimum'}

def audit():
 start=time.process_time();geometry=0;literal=0
 for b in range(5,71):
  for n in(2*b,2*b+1,3*b):
   qa=b*(n-b)+2*b-2;qb=b*(n-b)+3;t=2*b-5;p=(n+1)%2
   for delta in range(b-2):
    a=[n-1-x+2*(x>=b+2+delta)for x in range(2*b)]
    z=[n-2*b-2+x+2*(x<=b+2-delta)for x in range(2*b)]
    assert a==prefix_height(2*b,n,p,qa-delta)
    assert z==prefix_height(2*b,n,1-p,qb-delta,True)
    assert max(y-x for x,y in zip(a,z))<=t
    assert sum(x-y+t for x,y in zip(a,z))//2==(b+1)*t
    geometry+=1
    if b<=9:
     _,receipt=construct(2*b,n,p,a,z,t,b+1)
     assert receipt['physical_containment_verified'];literal+=1
 examples=[{'old':old.evaluate(2*b,2*b),'new':evaluate(2*b,2*b)}for b in(6,23,54,224)]
 r={'status':'PASS','scope':'Supplementary geometry and literal bridge checks for a uniform proved construction','geometry_cases':geometry,'literal_bridges':literal,'examples':examples,'CPU_seconds':time.process_time()-start,'source_hashes':{x:hashlib.sha256((P/x).read_bytes()).hexdigest()for x in ['upper-adaptive-transport.md','upper_adaptive_transport.py']}}
 P.joinpath('upper-adaptive-transport-audit.json').write_text(json.dumps(r,indent=2)+'\n');print({k:v for k,v in r.items()if k not in('source_hashes','examples')});print([(x['new']['w'],x['old']['selected']['full_days'],x['new']['selected']['full_days'])for x in examples])
if __name__=='__main__':audit()

"""Diagnostic for the gate-parametric necessary clock and final quota cut.

Uses the accepted asymmetric faster-middle relaxation. All geometry proof
obligations live in the corresponding notes, not in this finite panel.
"""
from pathlib import Path
from functools import lru_cache
from bisect import bisect_left
import importlib.util,json,time
P=Path(__file__).resolve().parent
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
base=load('terminal_base',P/'root-asymmetric-clock.py')
cut=load('terminal_cut',P/'root-integer-charge-cutoff.py')
base.m.old.early_api.cutoff=cut.cutoff

@lru_cache(maxsize=8192)
def early_endpoints(b,d):
    k=b+d;H=b*(b-1);em=base.m.old.early_api.EarlyHybrid(k)
    e=em.clock(H-d+1);q0=min(H,em.maxima[e])
    qs=[q0]+([H] if q0<H else [])
    return tuple((q,em.clock(q)) for q in qs)

@lru_cache(maxsize=8192)
def late_endpoints(b,d,c):
    k=b+d;H=b*(b-1);top=H+d+1;R=cut.cutoff(k);cap=R*R+k
    scalar=c;pair=(c,c);maxima=[c]
    while maxima[-1]<top:
        scalar=k+scalar-base.m.rho(scalar)
        pair=(max(min(cap,scalar),k+pair[1]-base.m.rho(pair[1])),
              max(min(cap,scalar),k+pair[0]-base.m.R(pair[0])))
        assert max(pair)>maxima[-1]
        maxima.append(max(pair))
    ell=bisect_left(maxima,H+1);y0=min(top,maxima[ell])
    ys=[y0]+([top] if y0<top else [])
    return tuple((y,bisect_left(maxima,y)) for y in ys)

def joint(w,n,k,c):
    b=w//2;d=k-b;h=w*n//2
    return min(e+ell+base.m.faster_middle(b,d,h,q,y,w%2)
               for q,e in early_endpoints(b,d)
               for y,ell in late_endpoints(b,d,c))

if __name__=='__main__':
    start=time.process_time();rows=[];hist={};worst=[];maximum=-1;gains=0
    for old in json.loads((P/'root-integer-charge-panel.json').read_text())['results']:
        w,n,k=old['w'],old['n'],old['k'];J=joint(w,n,k,k)
        assert J==old['J'],(w,n,k,J,old['J'])
        Jhalf=joint(w,n,k,k//2)
        assert J<=Jhalf<=J+1,(w,n,k,J,Jhalf)
        lower=max(2*J+1,2*Jhalf)
        r={**old,'J_half':Jhalf,'old_lower':old['lower'],'lower':lower,
           'gap':old['upper']-lower}
        assert r['gap']>=0,r
        gains+=lower>old['lower']
        hist[str((w%2,r['gap']))]=hist.get(str((w%2,r['gap'])),0)+1
        if r['gap']>maximum:maximum=r['gap'];worst=[r]
        elif r['gap']==maximum:worst.append(r)
        rows.append(r)
    out=dict(status='Diagnostic; quantified proof and coverage are separate',
             cases=len(rows),improved=gains,maximum_gap=maximum,
             histogram=hist,worst=worst,results=rows,
             CPU_seconds=time.process_time()-start)
    (P/'root-terminal-gate-panel.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items() if k not in ('worst','results')})
    print('worst',worst[:5])

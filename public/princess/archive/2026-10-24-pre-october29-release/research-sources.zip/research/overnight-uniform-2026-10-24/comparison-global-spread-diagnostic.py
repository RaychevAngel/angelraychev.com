"""Challenge a coarse root-dependent phase-spread conjecture.
Parameter examples only; no universal bound is inferred.
"""
from math import isqrt
from pathlib import Path
import json,time,argparse

def root(x):return isqrt(x-1)+1 if x else 0
def rho(x):
 r=(isqrt(4*x+1)-1)//2;return r+(r*(r+1)<x)
def run(k,seed=0):
 x=y=seed;t=0;worst=None;maximum=0
 while True:
  gap=abs(x-y)
  if gap>maximum:maximum=gap;worst=dict(k=k,seed=seed,t=t,x=x,y=y,gap=gap,root=root(max(x,y)+k),drift=k-root(max(x,y)+k))
  a=y+k-rho(y+k);b=x+k-root(x+k)
  if(a,b)==(x,y):break
  assert a>=x and b>=y
  x,y=a,b;t+=1
  if t>100*k:raise AssertionError((k,seed,t,x,y))
 return dict(k=k,seed=seed,maximum=maximum,ratio=maximum*maximum/k,witness=worst,steps=t)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--max-k',type=int,default=1000);arg=a.parse_args();start=time.process_time();rows=[]
 for k in range(20,arg.max_k+1):
  rows.append(run(k))
 out=dict(status='DIAGNOSTIC_NOT_PROOF',max_k=arg.max_k,maximum_ratio=max(r['ratio']for r in rows),worst=sorted(rows,key=lambda r:r['ratio'],reverse=True)[:30],cpu=time.process_time()-start)
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out['maximum_ratio'],out['worst'][:5],out['cpu'])

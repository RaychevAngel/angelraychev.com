"""Reevaluate the diagnostic panel with the newly proved smaller hybrid cutoff."""
from pathlib import Path
import importlib.util,json,time
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('half_panel_base',P/'root-asymmetric-clock.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def latecut(k):
    r=(k+1)//2+6
    return r,r*r+k
m.m.old.early_api.cutoff=lambda k:(k+1)//2+6
m.m.old.late_api.cutoff=latecut
start=time.process_time();rows=[];hist={};worst=[];maximum=-100
for old in json.loads((P/'root-shifted-panel.json').read_text())['results']:
    w,n,k=old['w'],old['n'],old['k'];b=w//2;h=w*n//2;d=k-b
    J=min(e+ell+m.m.faster_middle(b,d,h,q,y,w%2) for q,y,e,ell in m.endpoints(b,d))
    r={**old,'J':J,'P_minus_J':old['P']-J,'lower':2*J+1,'gap':old['upper']-2*J-1}
    assert r['gap']>=0,r
    hist[str((w%2,r['P_minus_J']))]=hist.get(str((w%2,r['P_minus_J'])),0)+1
    if r['gap']>maximum:maximum=r['gap'];worst=[r]
    elif r['gap']==maximum:worst.append(r)
    rows.append(r)
out=dict(status='Diagnostic only; physical proof status is separate',cases=len(rows),maximum_gap=maximum,histogram=hist,worst=worst,results=rows,CPU_seconds=time.process_time()-start)
(P/'root-half-cutoff-panel.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ('worst','results')})
print('worst',worst[:5])

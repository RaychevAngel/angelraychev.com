# A cost-free central phase choice at minimum budget

24 October 2026. Ordinary constructive corollary of the independently
accepted adaptive transport lemma. This is not a global optimality claim.

Let w=2b>=10, n>=w, h=bn, and k=b+1. Set

    QA=h-b²+2b-2, QB=h-b²+3, B=QB-1, t=2b-5.

For initial checkerboard phase alpha, follow the ordinary bottom-left
prefix strategy from its full color class until it first reaches QA.
Call that time a_alpha. It reaches QA exactly. At time

    a_alpha+t+1

there are directly specified strategies whose surviving belief is
contained in a prefix of size B with EITHER relative corner phase.
The elapsed time is identical for the two choices.

Here relative phase means the checkerboard phase measured from the chosen
bottom corner. Reflecting the width changes it because w is even.

## Plateau identity and exact entrance

For a nonempty anchored prefix of size s, its neighborhood surplus is

    min(b, c_p(s), e_(p xor chi)(h-s)),

where chi=n mod2, c_0(s)=ceil(sqrt(s)), c_1(s)=1+rho(s),
e_0(s)=ceil(sqrt(s)), e_1(s)=rho(s). This is the existing finite-board
prefix count, obtained by substitution in the three diagonal ranges of
`src/resumed_even_construction_prefix_arithmetic.py`.

In particular both phases have surplus exactly b whenever

    (b-1)² < s < h-b(b-1).

For every pre-inspection size q in [B,QA+1], the survivor s=q-k lies
strictly in this interval: its smallest possible value is
h-b²-b+1 >= b²-b+1 > (b-1)², and its largest is
h-b²+b-2 < h-b(b-1). Therefore an ordinary move decreases q by exactly
one throughout this interval, independently of phase and corner.

The prefix transition is monotone in q. Since the transition from QA+1
is QA, an entrance from above cannot jump below QA. Feasibility makes
the entrance finite, so the first size at most QA is exactly QA.

## Two actual phase choices at the same time

Staying at the left corner for t+1 ordinary moves reaches B exactly.
For the other choice, put p=(n+1) mod2.

If the physical phase at QA is p, use the adaptive transport bridge with
delta=0, reaching the right prefix QB after t moves; then take one
ordinary move to B.

If the physical phase at QA is 1-p, take one ordinary move first. It
reaches QA-1 in phase p. Use the adaptive bridge with delta=1; after t
more moves the result is contained in the right prefix QB-1=B.

Both constructions take t+1 moves. At that common day the actual global
checkerboard phase is fixed, but the chosen corner is reflected. Thus
the relative corner phases are opposite. Containment is sufficient for
the chosen deterministic tail.

## Separated head and tail upper bound

Let ell_beta(B) be the ordinary anchored capture clock from size B and
relative phase beta, including its final inspection. Then the following
is a uniform physical solo upper bound:

    P_free = min_alpha a_alpha + t+1 + min_beta ell_beta(B).

Both minima have only two options. The head and tail phases are genuinely
independent, because the preceding construction supplies the needed
corner choice. The corresponding full-board upper bound is 2P_free by
the existing reverse-schedule construction. The retained shared final
inspection refinement may improve it further when its usual quota
condition holds.

This formula is an arithmetic recurrence evaluation, as allowed for the
current bound-tightening objective. It does not establish that arbitrary
solo strategies, or arbitrary two-cohort strategies, are no faster.

## Exact relation to the fixed-anchor clock

For each alpha the fixed-anchor strategy also passes B at a_alpha+t+1,
but only one tail phase is available. Hence P_free never exceeds the best
fixed-anchor clock. If the best fixed-anchor clock is one day larger
than the displayed separated sum, the transport construction saves that
day for every parameter tuple satisfying that clock condition. This
is a uniform implication, not an assertion that the condition always
holds or a claim based on selected boards.

The adverse 448-by-448 example with k=225 is one instance: the fixed
anchor has solo clock4433, while the separated construction has4432.
Its retained shared-final-day construction gives full-board upper8863.

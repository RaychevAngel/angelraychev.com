# Correlated-ancestry lane: overnight research log

24 October 2026, beginning08:17UTC. The target is exact structural bounds
throughout the rectangle/budget domain. Existing generic exact algorithms
do not discharge this research target. Numerical simplification is deferred.

The frozen prior checkpoint and all accepted bounds remain intact. This
lane owns only `comparison-*` files in the current folder. No public or
Lean changes are authorized by this lane's assignment.

## Starting facts

The previous inverse-interval criterion is independently accepted in
`../joint-history-2026-10-24/physical-tied-origin-review.json`. It gives an
exact test for a common tied reset of two phase-labeled hybrid fronts.
All recorded false arbitrary-seed middle examples fail this test, while
the genuine positive control passes. A uniform implication to the
two-extra-middle-day meet is not proved. That implication would close a
nine-day comparison, not the stronger overnight zero-gap target.

The accepted large-excess argument already gives the nine-day comparison
for d>=18 at even width and d>=20 at odd width. The remaining small-d
sets are finite, but the width and length remain unbounded. The old25-day
fallback covers the entire domain. Prefix optimality is not assumed.

## Initial plan

1. Determine whether exact common-origin information admits a compact
   phase/radius invariant, preferably via a contrapositive interval
   separation argument rather than a guessed spread bound.
2. Distinguish genuine physical obstructions from artifacts of the
   necessary numerical merger. Exact phase holding may require geometry
   beyond a one-room pair correction.
3. Pursue exact physical domination where sound; if a proposed exact
   comparison fails, preserve the counterexample and identify the
   missing state rather than weakening it silently.

Parent is independently exploring set compression and Pareto normal
forms. The other two lanes supply geometric lower refinements and
independent physical audits. Diagnostics here target conjectures and
symbolic mechanisms, not isolated width certificates.

## 08:28 UTC: common-map normalization and attacks on ancestry relaxations

The square and pronic forward maps are exactly one real map
Q(z)=(sqrt(z+k)-1/2)^2 rounded downward onto two quarter-offset lattices.
The high inverse is Q^{-1} rounded upward, with the lattice offsets
exchanged. `comparison-staggered-lattice.md` contains the endpoint proof;
240,024 exact integer identities passed. This is a normalization tool,
not a new capture-time inequality.

The tempting bound phase-spread^2 <= local-drift+1 is false even for
allowed tied reset seeds. In particular k41, seed852 has spread3 near
the critical end while the drift drops to5. A larger diagnostic has
spread24 at drift142. The full output is preserved in
`comparison-energy-diagnostic.json`; it disproves that invariant, not
the actual hybrid meeting conjecture. It also warns against replacing
ancestry by a single unsigned energy.

I then tested the actual proposed middle+2 inequality for EVERY seed in
the allowed tied-reset interval, retaining both possible one-room reset
errors and all four compressed endpoint choices, at the previously
problematic b100,d1 and the small energy obstruction b40,d1. Both pass
with minimum compatible meeting margin2 (320 and88 tests respectively).
The b32,d1 case also passes. These are tests of a specific ancestry
relaxation, not a width-family theorem. All previous arbitrary-pair
counterexamples remain excluded by exact ancestry.

## Shifted pronic interface secured

The conditional middle+2 theorem is independently accepted for every b>=200,
1<=d<=19 and both even-area width parities, with shifted endpoints
Q in [b(b-1)-d+1,b(b-1)] and Y in [b(b-1)-d+2,b(b-1)+2].
The odd small-excess cases use exact residue reduction, not width sampling:
44 cells and22,368 arithmetic checks. See comparison-shifted-pronic-middle.md
and upper-shifted-pronic-middle-review.json. Boundary necessity is separate.

An independent-progress middle+1 comparison is false, even with BAND9,
and the same adverse pairs can have the correct local common forward orbit.
The exact tied-reset-origin test excludes the first three such adverse states.
This leaves genuine history/ancestry as the route to a stronger comparison.
No public sources, manuscripts, or Lean coverage changed.

## 10:50 UTC: parameterized slack gives a genuinely stronger lower family

The fixed slack-four argument was unnecessarily restrictive. The accepted
new theorem permits arbitrary slack s and cutoff R satisfying explicit
arithmetic conditions, with dominant remainder at most s+1, exact matching
charges E_s(r),L_s(r), and old bad-step gains s+1-t and s. The inverse
allowance t is itself an exact root inequality. The main new interface is
target-root-local counting: before the next good target of root r, freeze
the comparator once it exceeds r²; otherwise only near walls up to r can
consume credit. This removes the old extra neutral interval and reduces
the early near count to4s+6 at d1, or2(d+s+2) at d>=2.

Both proof notes have independent source-hashed acceptance:
`upper-variable-slack-review.json` and
`upper-variable-slack-wide-review.json`. The implementation returns only
fully admissible choices, with earlier bounds retained otherwise. Examples
of admissible (k,s,R) are(225,11,94),(1001,22,290),(10001,57,1796).
These examples illustrate the theorem; they are not its evidence base.

Reusing all8113 prior comparison records, with no new strategy search,
reduced their worst retained gap from6 to5 and P-J from4 to3. The separate
parent combination with the final-inspection quota reaches gap4 on that
same diagnostic collection. Neither number is asserted uniformly from
those records. The new mathematical achievement is the admissible lower
clock family, valid for arbitrary board length under its stated guards.

The simpler contraction conjecture that every near-pronic hybrid pair is
within one room of its ordinary zero-origin pair is false even with these
stronger cutoffs. Literal witnesses are b200,d7 and b264,d3, with respective
same-phase excesses(2,1) and(0,2). They are preserved in
`comparison-coupling-counterexamples.py/.json`. This does not refute a
drift-scaled contraction bound or a correlated two-front comparison.

The accepted large-excess two-day middle comparison has also been audited
for arbitrary tied terminal seed c in[0,k]: its interlacing/span proof and
all subsequent modules are seed-independent. See
`comparison-generic-terminal-seed.md`; physical gate necessity remains a
separate reviewed ingredient owned by the lower lane.

## 18:18 UTC: resumed bounded phase-compatibility assessment

Two new algebraic/physical initialization facts are secured without claiming
an improved global gap. `comparison-first-sensitive.md` proves that the first
zero-slack own-corner event in a stay-below-pronic history is matched by the
ordinary correct phase at the SAME elapsed time. Before it, all steps obey
the worst-phase F recurrence. The lower lane independently accepted this.

`comparison-ordinary-max-correlation.md` gives an exact maximum-over-one-reset
representation of the new ordinary-MAX hybrid. After shifting the late gate-k
clock by k, both boundaries use the SAME ordinary zero-origin orbit, with
caps L and G(L); their labelled capacities differ by at most one room per
coordinate at every time. Independent source-hashed acceptance is recorded in
`upper-ordinary-max-correlation-review.json`.

An apparently attractive simplification fails: these stronger hybrids do not
always coalesce with the ordinary pair at the near-pronic cut. For b251,d1,
the hybrid is(62750,62750) while ordinary is(62750,62749). For b201,d19,
the errors occupy both coordinates. Literal witnesses are preserved in
`comparison-ordinary-max-coupling-failures.json`. Thus a better-phase choice
at each boundary cannot silently replace the reset histories.

The first-slow-good causal initialization remains open. Bounding the number
of outlier holes does not automatically partition their backwards cones:
small proper ramps may float along a side rather than lie at actual corners,
and chains of overlapping cones can prevent a budget-preserving independent
quadrant decomposition. The accepted activation-order theorem applies once
that decomposition is valid, not before. No arithmetic cone guard alone was
promoted to a theorem for those arbitrary outliers.

A preliminary weighted-triangle invariant for the independent-corner
allocation model was refuted at k12,t10: source(53,0), quota split2, target
(1,55), ordinary(55,56). It does not refute ordinary-MAX concentration, which
the lower lane has separately proved by permanent activation order. Further
allocation scans were stopped as redundant.

The remaining most concrete same-time route tracks only sensitive events,
which have no outliers. The first is now free; later changes of the actual
corner convention require geometry/credit. Weak bad steps yield one room
per pair, whereas a corner change consumes order r²/k days. Replacing the
old one-day rewind cost by the actual ordinary phase span could close this
if a usable uniform O(sqrt(k)) bound is proved. The sharper delta²<=k
conjecture is already false; no substitute bound has been established.

### Exact remaining comparison target and stopping boundary

For gate k, set W^L_t to the reset envelope in
comparison-ordinary-max-correlation.md. The lower and upper boundary
comparators satisfy C_t-k=W^L_t and W^L_t<=E_t<=W^L_t+(1,1).
For retained endpoints(Q,Y), let e,ell be their actual hybrid hitting times
and tau the accepted necessary middle passage. A one-day saving would need
a phase-compatible physical meeting using only THREE extra moves in total
across both boundaries and the middle, rather than independently charging
one+two+one. In exact notation, a sufficient statement is

    exists p: A_e[p xor chi] + Phi^(tau+3)(V_ell)[p] >= h,

where A is the ordinary forward pair, V the ordinary backward gate-k pair,
and Phi the finite-board physical prefix operator. This gives solo
P<=e+ell+tau+4 after the final inspection. It is NOT established. The
max-over-one-reset identity shows that the two extremal hybrid coordinates
can arise at different reset times, so no common phase may be selected
without proof. General terminal gates need their separate origin treatment.

There is also no blanket one-room endpoint debt bound to substitute for
this missing proof. At b289,d19,k308,R119,t1142, the ordinary-MAX early
hybrid is(83214,83220), while the ordinary pair is(83214,83218); even the
maximum differs by2. An uncapped ordinary-MAX envelope already differs
by2 at k18,t12: ordinary(111,111), envelope(113,111). These are algebraic
failure shields, not counterexamples to retained physical capture bounds.

The alternative physical route starts at the first SENSITIVE event, now
proved exactly initialized at its own-corner phase. Subsequent sensitive
events have no outliers, so their corner changes admit the accepted matching
charge. To obtain same-time ordinary domination one must pay a change of
ordinary phase using its ACTUAL span, or otherwise show incompatible
changes cannot retain the requisite mass. The existing weak bad-step
credit and crude span/velocity bound do not bridge the entire root range.
A sharper globally valid span bound or a direct spatial replacement lemma
is still missing. The floating-ramp issue belongs to the broader slack-good
route and must not be silently imported into the sensitive-only argument.

No further parameter scan or publication change was made after the parent's
checkpoint request. The uniform mathematical ceiling remains the accepted
eight-day bracket; zero gap and closed-form completion are not claimed.

"""Literal same-origin failures of a proposed one-room coupling bound."""
from pathlib import Path
from math import isqrt
import importlib.util,json,hashlib
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('coupling_guards',P/'comparison_variable_slack_general.py')
v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
def R(q):return isqrt(q-1)+1 if q else 0
def rho(q):
    r=(isqrt(4*q+1)-1)//2
    return r+(r*(r+1)<q)
def check(b,d):
    cert=v.strongest_cutoff(b,d);assert cert
    k=b+d;cut=cert['R'];target=b*(b-1)-d+1
    G=lambda x:x+k-rho(x+k)
    F=lambda x:x+k-R(x+k)
    cap=G(cut*cut)
    hybrid=ordinary=(0,0);scalar=t=0
    last_hybrid=hybrid
    while max(hybrid)<target:
        last_hybrid=hybrid
        scalar=G(scalar);inject=min(cap,scalar)
        hybrid=(max(inject,G(hybrid[1])),max(inject,F(hybrid[0])))
        ordinary=(G(ordinary[1]),F(ordinary[0]));t+=1
    assert max(last_hybrid)<target<=max(hybrid)
    debt=tuple(a-b for a,b in zip(hybrid,ordinary))
    assert max(debt)>1
    return dict(b=b,d=d,k=k,slack=cert['s'],cutoff=cut,t=t,
                target=target,hybrid=hybrid,ordinary=ordinary,excess=debt,
                admissibility=cert)
rows=[check(200,7),check(264,3)]
out=dict(status='EXACT_COUNTEREXAMPLES_TO_ONE_ROOM_COUPLING_ONLY',cases=rows,
         limitation='No refutation of a time bound, capture strategy, or physical lower theorem.',
         source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print([{k:r[k]for k in('b','d','k','cutoff','t','hybrid','ordinary','excess')}for r in rows])

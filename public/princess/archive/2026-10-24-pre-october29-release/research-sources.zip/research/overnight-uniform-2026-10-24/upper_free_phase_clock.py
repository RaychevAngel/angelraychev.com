"""Uniform physical head/tail phase separation at minimum even-width budget.

Proof: upper-free-central-phase.md. No claim of unrestricted optimality.
"""
from pathlib import Path
import sys, json, hashlib, time
P=Path(__file__).resolve().parent; ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'src'))
from resumed_even_construction_prefix_arithmetic import neighborhood_count
from bridge_upper_transport import prefix_tail,prefix_height,capture_replay
from resumed_even_construction_transport import construct

def data(w,n):
    assert w%2==0 and w>=10 and n>=w
    b=w//2;h=b*n;k=b+1;t=2*b-5
    return b,h,k,t,h-b*b+2*b-2,h-b*b+2

def evaluate(w,n):
    b,h,k,t,qa,B=data(w,n); heads=[];tails=[];rows=[]
    for alpha in (0,1):
        q=h;p=alpha;a=0
        while q>qa:q=neighborhood_count(w,n,p,q-k);p^=1;a+=1
        assert q==qa
        heads.append((a,p))
    for beta in (0,1):
        q=B;p=beta;ell=0
        while q>k:q=neighborhood_count(w,n,p,q-k);p^=1;ell+=1
        tails.append((ell+1,q))
    for alpha,(a,p) in enumerate(heads):
        at_B=p^((t+1)%2)
        for beta,(ell,last) in enumerate(tails):
            solo=a+t+1+ell
            rows.append(dict(initial_phase=alpha,tail_relative_phase=beta,
                             reflected_tail=bool(beta!=at_B),head_steps=a,
                             transport_interval=t+1,tail_days=ell,solo_days=solo,
                             final_inspections=last,full_days=2*solo-int(2*last<=k)))
    return dict(w=w,n=n,k=k,central_size=B,choices=rows,
                selected=min(rows,key=lambda r:(r['full_days'],r['solo_days'])),
                separated_solo=min(a for a,p in heads)+t+1+min(e for e,q in tails),
                scope='Uniform constructive upper, not unrestricted optimum')

def literal(w,n,row):
    b,h,k,t,qa,B=data(w,n);alpha=row['initial_phase'];a=row['head_steps']
    full_prefix=prefix_tail(w,n,k,alpha,h);head=full_prefix[:a]
    p=(alpha+a)%2
    if not row['reflected_tail']:
        middle=full_prefix[a:a+t+1]
    else:
        required=(n+1)%2
        delta=int(p!=required)
        left=prefix_height(w,n,required,qa-delta)
        right=prefix_height(w,n,1-required,B+1-delta,True)
        bridge,receipt=construct(w,n,required,left,right,t,k)
        assert receipt['physical_containment_verified']
        if delta:
            middle=full_prefix[a:a+1]+bridge
        else:
            after_phase=1-required
            tail=prefix_tail(w,n,k,after_phase,B+1,True)
            middle=bridge+tail[:1]
    pB=(alpha+a+t+1)%2
    tail=prefix_tail(w,n,k,pB,B,row['reflected_tail'])
    solo=head+middle+tail
    assert len(solo)==row['solo_days']
    reflect=lambda shot:{(w-1-x,y)for x,y in shot}
    if alpha:solo=[reflect(s)for s in solo]
    assert capture_replay(w,n,k,solo)==len(solo)
    if 2*len(solo[-1])<=k:
        full=solo[:-1]+[solo[-1]|reflect(solo[-1])]+[reflect(s)for s in solo[-2::-1]]
    else:full=solo+solo[::-1]
    assert capture_replay(w,n,k,full,full=True)==row['full_days']
    return len(full)

def audit():
    start=time.process_time();checks=0;examples=[]
    for b in range(5,13):
        for n in(2*b,2*b+1,3*b):
            result=evaluate(2*b,n)
            for row in result['choices']:literal(2*b,n,row);checks+=1
    for b,n in((6,12),(23,46),(54,108),(224,448),(224,450),(224,1344)):
        examples.append(evaluate(2*b,n))
    result={'status':'PASS','literal_head_tail_phase_choices':checks,'examples':examples,
            'CPU_seconds':time.process_time()-start,
            'source_hashes':{f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in
                             ['upper-free-central-phase.md','upper_free_phase_clock.py','upper-adaptive-transport.md']}}
    P.joinpath('upper-free-central-phase-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print({'status':'PASS','literal_choices':checks,'examples':[(x['w'],x['n'],x['separated_solo'],x['selected']['full_days'])for x in examples]})
if __name__=='__main__':audit()

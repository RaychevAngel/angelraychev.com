"""Challenge target-specific boundary minimum after the accepted one-day shift.
Pure recurrence diagnostics, not width-family certification.
"""
from pathlib import Path
from importlib.util import spec_from_file_location,module_from_spec
import json,time
D=Path(__file__).resolve().parent
def load(name,p):s=spec_from_file_location(name,p);m=module_from_spec(s);s.loader.exec_module(m);return m
J=load('j',D.parent/'joint-history-2026-10-24/root-joint-hybrid-clock.py')
def run(b,d):
 k=b+d;H=b*(b-1);qmin=H-d+1;qmax=H;ymin=H-d+2;ymax=H+2
 E=J.early_api.EarlyHybrid(k);e=E.clock(qmin);qs=sorted(set((min(qmax,E.maxima[e]),qmax)));es={q:E.clock(q)for q in qs}
 C=J.late_api.hybrid_gate_curve(k,ymax,True);ell=J.late_api.gate_time(C,ymin);ys=sorted(set((min(ymax,C['maxima'][ell]),ymax)));ells={y:J.late_api.gate_time(C,y)for y in ys}
 A=(0,0);V=(k,k);aph={};vph={}
 for t in range(max(es.values())+2):
  if t in {v+1 for v in es.values()}:aph[t]=A
  A=(A[1]+k-J.rho(A[1]+k),A[0]+k-J.root(A[0]+k))
 for t in range(max(ells.values())+2):
  if t in {v+1 for v in ells.values()}:vph[t]=V
  V=(V[1]+k-J.rho(V[1]),V[0]+k-J.root(V[0]))
 early=[dict(target=q-H,hybrid=[z-H for z in E.states[es[q]]],physical=[z-H for z in aph[es[q]+1]],margin=min(aph[es[q]+1])-q)for q in qs]
 late=[dict(target=y-H,hybrid=[z-H for z in C['phases'][ells[y]]],physical=[z-H for z in vph[ells[y]+1]],margin=min(vph[ells[y]+1])-y)for y in ys]
 return dict(b=b,d=d,early=early,late=late)
if __name__=='__main__':
 rows=[];start=time.process_time()
 for b in range(200,501):
  for d in(1,2,3):
   r=run(b,d)
   if any(z['margin']<0 for f in ('early','late')for z in r[f]):rows.append(r)
 out=dict(status='FALSIFICATION_DIAGNOSTIC',bad_cases=rows,cpu=time.process_time()-start);Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(len(rows),rows[:3],time.process_time()-start)

"""Exact integer audits of the quarter-lattice normalization, no floats."""
from math import isqrt
from pathlib import Path
import json,hashlib

def root(q):
 r=isqrt(q);return r+(r*r<q)
def rho(q):
 r=(isqrt(4*q+1)-1)//2;return r+(r*(r+1)<q)
def qfloor(j,k,dest):
 """4*round_down_Q(j/4) to integer j=dest mod4."""
 raw=j+4*k+1-root(4*(j+4*k))
 return raw-(raw-dest)%4
def rceil(j,k,dest):
 raw=j+1+root(4*j)-4*k
 return raw+((dest-raw)%4)
def run():
 checks=0
 for k in (1,2,7,33,101,1001):
  for z in range(0,10001):
   assert qfloor(4*z+1,k,0)==4*(z+k-rho(z+k))
   assert qfloor(4*z,k,1)==4*(z+k-root(z+k))+1
   assert rceil(4*z,k,1)==4*(z+root(z)-k)+1
   assert rceil(4*z+1,k,0)==4*(z+1+rho(z)-k)
   checks+=4
 return dict(status='PASS_ALGEBRA_AUDIT',integer_identity_checks=checks,
             new_capture_bound=False,
             sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(Path(__file__),Path(__file__).with_suffix('.md'))})
if __name__=='__main__':
 r=run();Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

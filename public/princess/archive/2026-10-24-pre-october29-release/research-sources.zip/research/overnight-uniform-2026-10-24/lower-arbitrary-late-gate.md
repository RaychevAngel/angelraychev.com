# The necessary late clock has an arbitrary nonnegative terminal gate

24 October 2026. Parametric consequence of the accepted late-history proofs.
Submitted for independent review. This note supplies a boundary clock only;
new full-game cut identities and their inspection indices are separate.

Work in any parameter range already covered by the accepted necessary late
hybrid proof, including the pronic extension and its accepted smaller-cutoff
substitutions. Keep its budget k, scalar cutoff A=R^2+k, and allowed starting
ceiling Y unchanged. Replace the old terminal gate k by any integer

    0<=c<=k.

Let rho(u) be the least nonnegative r with u<=r(r+1), and define

    G(u)=k+u-rho(u),   F(u)=k+u-ceil(sqrt(u)),
    S_0=c, C_0=(c,c), S_(t+1)=G(S_t),
    C_(t+1)[0]=max(min(A,S_(t+1)),G(C_t[1])),
    C_(t+1)[1]=max(min(A,S_(t+1)),F(C_t[0])).

Put ell_c(Y)=min{t:max(C_t)>=Y}. An actual two-cohort history starting
with signed residual m_s>=Y and first reaching m_g<=c satisfies

    g-s>=ell_c(Y).                                  (1)

Here m is the usual total belief size minus one color-class size. Its final
value may be negative. No physical realization of all numerical hybrid paths
is asserted.

## 1. Residual maps at and below k

Use the complete ordinary solo residual maps

    phi_p(x)=0,                                    0<=x<=k,
    phi_0(x)=x-k+ceil(sqrt(x-k)),                   x>k,
    phi_1(x)=x-k+1+rho(x-k),                        x>k,

in the genuine quadrant range of the original argument. Use the scalar
fast map phi_0. For nonnegative target u their inverse thresholds are exactly

    max{x:phi_0(x)<=u}=G(u),
    max{x:phi_1(x)<=u}=F(u).

The case u=0 is included: both thresholds equal k. For positive u these are
the same square/pronic inverse identities used by the previous hybrid clock.
Thus changing the terminal seed from k to c gives precisely the displayed
backward recurrence, with no additional move or altered phase convention.

## 2. The physical comparison is independent of the terminal seed

All slow-history work remains unchanged. The actual slow residual exceeds A,
and all entry resets, good-event comparisons, room-credit estimates and paid
rewinds use the current residual, the budget and the cutoff. None uses the
numerical terminal gate k. In particular these arguments still follow ONE
ordinary reference orbit with its original phase; they do not restart it
when its residual becomes at most k.

There is one wording change which matters. A reference in (c,k] has not yet
reached the new gate. Its next ordinary move is0, rather than being omitted
by the old proof's stopping convention. If the actual history is still slow,
this update trivially stays below its positive residual. If that next actual
move is the final one, the same conclusion holds after clipping its signed
residual at0. Subsequent reference moves, if needed, remain0.

For the final fast comparison define m^+=max(m,0). The scalar residual map
is a lower bound on the next clipped actual residual. For m<=k its value
is0 and the statement is immediate. For m>k the useful-shot inequality gives
positive survivor mass q>=m-k>0, so the already proved signed-surplus
comparison applies and the next actual residual is positive. Hence the
previous fast argument extends through the possible final nonpositive jump.
Monotonicity then keeps the reference below m^+ throughout this comparison.

Since c>=0, the actual terminal condition m_g<=c implies m_g^+<=c.
The reference therefore reaches the new gate no later than the actual one.
There is no hidden extra inspection at the old gate k.

## 3. Entry, excursions and inverse interpretation

The last-crossing entry at Y and any subsequent fast-region excursion are
handled by exactly the previously accepted omitted-time accounting. If an
entry lands at a residual at most k, one reference update to0 is already
covered by the omitted actual move; this also handles c<k. The chosen
hybrid route consists of the same ordinary reference moves followed by the
same scalar continuation, now stopped at c instead of k. Its number of
moves is at most g-s.

The displayed recurrence is the exact inverse threshold evaluator for these
routes: from residual at most A one may use the scalar-only continuation,
while above A the ordinary phase-labelled move comes first. Ordinary moves
below A remain allowed. Starting the inverse iteration from c is exactly
what it means for the final residual to be at most c. This proves(1).

## Scope and dependencies

The mathematical scope of Y, R and all geometry is inherited, not enlarged,
from `../joint-history-2026-10-24/physical-hybrid-necessary-clock.md`,
`lower-pronic-late-extension.md`, and the accepted cutoff refinements
`comparison-half-cutoff.md` / `comparison-integer-cutoff.md` when used.
Only the terminal gate is parameterized. The hypothesis c>=0 is essential
for the simple clipping argument; a negative terminal gate needs a different
physical comparison and is not covered here.

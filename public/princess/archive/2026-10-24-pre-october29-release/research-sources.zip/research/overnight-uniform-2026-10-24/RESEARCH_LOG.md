# Overnight uniform-bound research: 24 October 2026

## Authorization, target, and deadline

Started at 08:15 UTC / 01:15 PT on 24 October 2026. Deadline is 17:00 UTC /
10:00 PT the same day. The user requests continued substantive research
toward matching computable lower and constructive upper bounds for every
positive rectangle w<=n and every feasible k>=floor(w/2)+1. All existing
achievements remain retained. Only AFTER gap zero is proved throughout
this domain may work turn to fixed-operation numerical simplification.

Existing exhaustive belief search and finite-interface exact computability
are not new closure of this bound-tightening objective. We seek a tight
structural evaluator with physical strategies, or the strongest genuine
uniform squeezing possible before the deadline. Do not silently weaken
the target or interpret a finite panel as a quantified theorem.

## Frozen starting checkpoint

Source: ../joint-history-2026-10-24/root-nine-day-families.md and its
independent final assembly review. All-input maximum proved gap is25,
sharpened to23 at even width. Odd-by-odd exact joint evaluation, widths
at most64 gap<=3, and even-area k>=3floor(w/2) gap<=1 are retained.

For the remaining even-area range w>64 and k<3b, b=floor(w/2), the
nine-day theorem applies for excess d=k-b>=18 at even width or d>=20
at odd width. Residual nine-day windows are d1..17 and d1..19, respectively,
with width and length unbounded. A pointwise necessary joint clock applies
throughout that range and may strengthen these family ceilings.

No new Lean/publication claim is implied. Prior source files remain frozen.

## Work distribution

* Comparison lane: common tied ancestry, exact inverse intervals, uniform
  meeting inequality, preferably sharper than the nine-day target.
* Lower lane: stronger physical-state simulation/compression or necessary
  model capable of exact lower bounds, with full-origin restrictions.
* Upper lane: actual improved strategies, corner/shape changes and a
  uniform exact candidate family; independently review new proofs.
* Root: global full-game/solo relation, time-reversal and physical merger,
  independent attacks and integration against the frozen baseline.

## Entry 1: initial audit

The previous checkpoint is independently reviewed ordinary mathematics.
Its largest global ceiling is still25. The static minimum neighborhood
profile for even-area rectangles is exact, but is not dynamically nested.
The proposed fixed-orientation pyramid normal form has not been proved;
its stronger partial-state version fails at odd width. Static matching
features and unconstrained current phase pairs admit false fast histories.
The common tied-origin condition is essential to the current comparison.

Past attempts already reject generic successful-quota-word polymatroid
exchange, unrestricted stationary potentials, and independently minimized
temporal intervals. Any new temporal or compression approach must retain
the individual daily quota and actual compatible history.

## Entry 2: accepted structural tools, no new gap theorem yet

The alternating-polarization lemma normalizes every even-area full-start
strategy to reflected nested cohorts without increasing time or any daily
budget. It is independently reviewed. This gives an exact folded game on
two nested supports (multiplicities0,1,2), retaining geometry. It does not
by itself prove an efficient exact clock or a better uniform gap.

The zero-slack good-event lemma localizes early states with total surplus
equal to the square-root lower bound through root b-1. All but at most
one hole lies in the unique dominant corner component. The late analogue
forces the other cohort to be full. Both have independent reviews.

The paired bad-credit lemma is independently accepted, with a sharper
failure count suggested by the lower lane: a failed favorable-phase move
occupies only C possible reference values at each root wall, rather than
2C-1. Thus an arbitrarily nonmonotone target cannot discard credit by
repeatedly revisiting the same root wall. Physical joining remains separate.

Important failed shortcuts: Hall noncontraction alone does not imply an
optimal serial strategy in the folded game; fixed isoperimetric prefix
nesting is obstructed by an unlooped corner; every two bad moves need not
earn one room (square-wall counterexamples). Exact shared-budget search
inside the fixed-corner prefix family did not improve the four diagnostic
large fixtures. These failures are preserved in the lane notes.

## Entry 3: uniform nine-day theorem accepted

The assembled ordinary theorem in `root-uniform-nine.md` is independently
accepted in `upper-uniform-nine-review.json`. Retaining all older exact
results and stronger bounds, the constructive upper and necessary lower
bounds now differ by at most nine days over EVERY rectangle and feasible
budget. The starting ceiling was25 (23 at even width). This is not an
exact solution or a new Lean/publication claim.

The new analytic range is b=floor(w/2)>=200, d=k-b in1..19. Early and
late hybrid histories extend to a shifted pronic cut without discarding
phase or room credit; the middle comparison costs at most two days.
The resulting P<=J+5, T>=2J+1 gives T>=2P-9. The omitted finite widths
are covered by a complete all-length periodic certificate:9538 lines,
105621 representatives, maximum gap8. The C++ port and independent Python
samples have separate reviews. Older theorems cover all remaining budgets
and odd-by-odd boards. These are uniform proofs plus a finite complete
base, not extrapolation from selected lengths.

Failed sharper interfaces are retained: even arbitrary progressive
endpoints can require two middle days; actual tied-origin hybrid endpoints
also need two on407x408,k204. On448x448,k225 the full BAND9 clock has
P-J=4. Thus a one-day isolated middle estimate and P<=J+3 for the old
anchored benchmark are both false. Any further gain must retain physical
boundary credit, improve the construction, or strengthen the lower model.

## Entry 4: toward a smaller uniform gap

Exact alternating polarization permits a last-full normalization: useful
work on the larger reflected cohort begins once, after which it never
becomes full again. In this permanently mixed suffix, the subcritical
surplus exceeds both physical corner phase costs. This eliminates the
need to pay a phase-reset day INSIDE such a suffix; connecting its start
to the solo prefix remains open. The normalization and static penalty
have independent review; the exact mixed-boundary comparison is under
review. A generic seriality theorem remains false on nonrectangular folded
graphs and is not being assumed.

The upper lane is preserving entrance undershoot in the balanced moving
front transport. This is a uniform constructive family, not a claim that
the old anchored prefix is optimal. The current diagnostic panel of8113
large-width cases has P-J<=4 and prefix-bound gap<=6, but this panel is
only evidence for choosing the next uniform theorem, not a new ceiling.

## Entry 5: accepted structural improvements and five-day subfamilies

By10:15 UTC, the permanent mixed central barrier is independently accepted.
For every even-area rectangle, proper surviving cohorts at signed mass
(b-1)^2<=q<h-b(b-1)-2 have total neighborhood surplus at least b+1.
Its clipped potential falls by at most d-1 per mixed day. At minimum budget
d=1 this forces all central progress to remain genuinely solo: useful work
on the larger cohort cannot begin until the smaller has at most b(b-1)+1
rooms. This is an unrestricted physical statement, not fixed-prefix optimality.

The accepted adaptive transport construction preserves entrance undershoot
and frees the two corner phases through the middle. Together with asymmetric
pronic cuts it proves gap<=5 for every even width2b,b>=200 at d=1, at ALL
lengths; also for2<=d<=19 when n>=2b+2d-2. These improve substantial uniform
families but do not lower the all-input ceiling below9.

The necessary hybrid clock now admits R=ceil(k/2)+6 for k>=100, replacing
the older approximately0.6k cutoff. An exact integer charge test can lower R
further (e.g.116 instead of119 at k225). Both proofs have independent review.
These strengthen computable lower bounds without charging an extra day.

Independent corner processes concentrate exactly into one of the two
ordinary alternating quadrant trajectories, for any daily quota word.
The algebraic theorem is proved and independently reviewed. The missing
physical implication is a valid corner ancestry decomposition through merges
or an integrated loss charge for every failure of that decomposition.

A separate accepted causal-cone lemma proves exact matching-phase ordinary
domination at sufficiently early sensitive corner events. A first ordinary
envelope violation must have surplus r=ceil(sqrt(Q)) with Q>r(r-1), hence
all holes in one corner component. Its dependence cone is a true quadrant
while t+2r-2<=w-1. The quantitative root fast-cut certificate supplies a
uniform sufficient range. It does not yet control all later corner changes.

## Entry 6: diagnostic limits of the sharper-boundary route

The8113-case pure ordinary-boundary panel is CONJECTURAL, replacing the
necessary hybrid clocks by unproved exact ordinary boundary clocks. It has
P-J<=2 at even width and<=3 at odd width, so even this hoped-for boundary
theorem alone would leave a possible five-day full-game bracket at odd
width (e.g.431x432,k216). It is a diagnostic of the next proof interface,
not a new lower bound. This prevents treating a boundary theorem as automatic
gap-zero closure.

Failed shortcuts retained: a spanning merger day with surplus>=b does not
automatically align both ordinary phases; the finite counterexample is in
root-spanning-phase-obstruction.md. The attractive phase-span inequality
delta^2<=k is false on a genuine zero-origin trajectory (k783,day326,
delta34). Neither failure refutes a stronger history-dependent merger charge
or a larger-constant square-root span theorem.

## Entry 7: uniform eight-day theorem independently accepted

At10:31 UTC the new assembly root-uniform-eight.md is independently accepted
in upper-uniform-eight-review.json. The necessary late hybrid extends to
every terminal gate0<=c<=k with the same slow history and cap. The generic
terminal-intersection lemma retains the central inspection quota. If J=J(k)
and Jhalf=J(floor(k/2)), then Jhalf is either J or J+1 and
T>=max(2J+1,2Jhalf). The corresponding physical gate comparison has no final
capture-day surcharge. Choosing the prefix palindrome or two solo captures
according to these two cases reduces the GLOBAL ceiling9 to8.

The arbitrary-seed fast comparison for k50..99 uses a complete exact finite
certificate:3775 seeds and250235 scalar updates. The distinction from the
older floor(3k/5) cap matters: using the larger small-budget cap blindly
fails at k33 and37 for some seeds. Those cases are already covered by the
finite-width base and are not used in the new large-excess proof.

The improved final-quota lower bound strengthens4362 of the8113 diagnostic
panel cases by one day, with the anchored upper's panel maximum dropping
from6 to5. This panel is not the proof of the all-input eight-day bound.
The two independent component reviews, complete coverage assembly, and
existing complete finite-width certificate provide that proof.

## Entry 8: both fast boundaries strengthened before interruption

The variable-slack cutoff family and its wider inverse allowance passed
independent review. They give explicit arithmetic sufficient conditions for
smaller fast caps, while retaining the old bounds whenever a guard fails.
They are parameterized necessary evaluators, not a new unqualified gap bound.

Both lower-ordinary-max-injection.md and lower-causal-late-capacity.md now
have independent physical reviews. The opening and closing fast branches
can use the maximum of the two actual ordinary quadrant phases, rather than
an all-cheap scalar orbit, under their separate causal guards. A shared
two-phase injection remains permitted; no matching-phase optimum is inferred.

The completed root-both-ordinary-max-panel.json combines these refinements
with the variable cutoff and terminal-quota bound on the SAME8113 retained
inputs. It has6279 exact numerical matches and maximum gap4, improving1170
inputs over the preceding early-only panel. Every selected causal and
cutoff guard passes. This is finite pointwise evidence; it does not prove
a uniform four-day bound.

Separately, upper-four-day-transport-families.md proves a four-day bracket
on all even-width boards w=2b,b>=200 at d=1, all n>=w, and at2<=d<=19
when n>=2b+2d-2. Its explicit constructive upper and necessary lower retain
the final central inspection. It does not cover the short higher-excess
or odd-width cases by extrapolation.

The constant-budget independent-corner falsifiers found no strict-saturation
or deficit-one counterexample for k2..100 through the tested boundary, each
checking33833 days and9330277191 transitions. These are finite algebraic
diagnostics, not proofs of the conjectures or physical ancestry.

## Entry 9: resumed audit and activation-order progress after the deadline

The overnight agent work stopped at the account usage limit around11:00UTC,
before the17:00UTC (10:00PT) deadline. User resumed at approximately18:05UTC.
No continuous overnight work is claimed during that interruption. Pending
local computations completed and were recovered on resume.

The final independent audit rechecked the global8 coverage assembly, every
finite-base parameter key and all retained review hashes. It found9538
unique complete width/budget/parity lines and105621 finite representatives,
maximum gap8, with the reviewed insertion theorem covering all later lengths.
Read upper-final-assembly-audit.json and upper-final-checkpoint.md.

Newly accepted root-activation-delay.md / lower-activation-order-deficit.md
use constant-quota activation order. If the distinguished corner convention
activates first, the total fits its ordinary phase. If it activates later,
the distinguished process is at least one elapsed day behind that phase.
Thus an ordinary daily increment at least the outlier mass pays the latter.
The sharper spread bound delta_t<=ceil(t/2) gives an explicit increment
guard k-Rhat-ceil((t-1)/2). This supplies a matched-phase bound for the rigid
triangle-plus-singleton configuration when its actual dependency cones are
disjoint. It does not yet initialize the entire slow-history proof.

Comparison's independently accepted ordinary-MAX correlation represents
each extremal coordinate by one reset of the same ordinary orbit. The
early pair and the gate-k late pair shifted by k differ by at most one
room in each phase. Exact coalescence is false, including at b251,d1;
both boundary debts cannot simply be discarded.

A rejected extension is important: general slack-good outliers need not be
actual corner components. Small proper ramps can float near the dominant
component, and their backwards cones can connect. The rigid-singleton
disjoint-cone proof therefore does NOT justify a matching-phase replacement
for every fast state. This ancestry/credit interface remains unresolved.

## Current evidence boundary

Uniform gap<=8 is proved and independently reviewed in ordinary mathematics.
Exact gap zero remains open. The explicit four-day transport families and
stronger guarded necessary clocks above are proved separately; the retained
panel maximum4 is not a uniform theorem. No final O(1)-expression work has
started. No new Lean, manuscript, PDF, or public website claim is made.
Prior authoritative source files remain frozen. The current entry point is
CHECKPOINT.md in this folder.

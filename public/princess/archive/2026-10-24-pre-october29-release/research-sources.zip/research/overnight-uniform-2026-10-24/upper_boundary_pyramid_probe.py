"""Bounded falsification of solo anchored-hole dominance below the pronic cut.
SAT witnesses are literal physical schedules. UNSAT is only for the specified
pyramid class; no new arbitrary-state normal form is claimed here.
"""
from pathlib import Path
import sys,json,time,hashlib
from ortools.sat.python import cp_model
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'src'))
from resumed_even_construction_prefix_arithmetic import neighborhood_count
from resumed_even_construction_transport import neighborhood

def probe(w,n,k,T,target,p0=0,seconds=10):
    h=w*n//2;m=cp_model.CpModel();before=[];remain=[]
    cap=lambda p,x:(n+1-((p-x)%2))//2
    for t in range(T+1):
        p=(p0+t)%2
        A=[m.NewIntVar(0,cap(p,x),f'a{t}_{x}')for x in range(w)];before.append(A)
        if t==0:
            for x in range(w):m.Add(A[x]==cap(p,x))
        else:
            pp=1-p;R=remain[t-1]
            for x in range(w):
                values=[R[z]for z in(x-1,x+1)if 0<=z<w]
                if(pp-x)%2==0:values.append(R[x])
                else:
                    pos=m.NewBoolVar(f'pos{t}_{x}')
                    m.Add(R[x]>=1).OnlyEnforceIf(pos);m.Add(R[x]==0).OnlyEnforceIf(pos.Not())
                    addition=m.NewIntVar(0,cap(p,x),f'long{t}_{x}')
                    m.AddMinEquality(addition,[cap(p,x),R[x]+pos]);values.append(addition)
                m.AddMaxEquality(A[x],values)
        if t==T:break
        R=[m.NewIntVar(0,cap(p,x),f'r{t}_{x}')for x in range(w)];remain.append(R)
        for x in range(w):m.Add(R[x]<=A[x])
        m.Add(sum(A)-sum(R)<=k)
        for x in range(w-1):
            if(p-x)%2==0:m.Add(R[x]-R[x+1]>=0);m.Add(R[x]-R[x+1]<=1)
            else:m.Add(R[x]-R[x+1]>=-1);m.Add(R[x]-R[x+1]<=0)
    m.Add(sum(before[T])<=h-target)
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds;solver.parameters.num_search_workers=1
    status=solver.Solve(m)
    out=dict(w=w,n=n,k=k,T=T,target_holes=target,p0=p0,status=solver.StatusName(status),wall_seconds=solver.WallTime())
    if status in(cp_model.OPTIMAL,cp_model.FEASIBLE):
        A={(x,y)for x in range(w)for y in range(n)if(x+y)%2==p0};shots=[];sizes=[h]
        for t in range(T):
            p=(p0+t)%2
            R={(x,y)for x in range(w)for y in range((p-x)%2,2*solver.Value(remain[t][x])+((p-x)%2),2)}
            shot=A-R;assert R<=A and len(shot)<=k
            shots.append(sorted(shot));A=neighborhood(w,n,R);sizes.append(len(A))
        assert h-len(A)>=target
        out.update(shots=shots,sizes=sizes,physical_replay=True)
    return out

def run():
    rows=[]
    for w,n in((10,10),(12,12),(10,12)):
        b=w//2;k=b+1;h=w*n//2;H=b*(b-1);q=[h,h];curve=[0];t=0
        while curve[-1]<H:
            q=[neighborhood_count(w,n,(p+t)%2,q[p]-k)for p in(0,1)]
            t+=1;curve.append(h-min(q))
        for T in(sorted(set([t-1,max(1,t//2)]))):
            target=curve[T]+1
            if target>H:continue
            for p in(0,1):
                row=probe(w,n,k,T,target,p,10);rows.append(row)
                print({k:v for k,v in row.items()if k not in('shots','sizes')},flush=True)
                if row.get('physical_replay'):break
    out={'scope':'Bounded pyramid falsification only, not a uniform lower theorem','rows':rows,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    P.joinpath('upper-boundary-pyramid-probe.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':run()

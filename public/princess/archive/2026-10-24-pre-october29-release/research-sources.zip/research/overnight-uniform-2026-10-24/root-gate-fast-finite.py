"""Complete finite budget/seed base for the arbitrary-gate fast-one lemma."""
from math import isqrt
from pathlib import Path
import json,hashlib
def R(x):return isqrt(x-1)+1 if x else 0
def rho(x):
    r=(isqrt(4*x+1)-1)//2
    return r+(r*(r+1)<x)
tests=0;seeds=0;maximum_steps=0
for k in range(50,100):
    r=(3*k+4)//5+4;cap=r*r+k
    for c in range(k+1):
        scalar=c;pair=(c,c);t=0;seeds+=1
        while scalar<cap:
            scalar=k+scalar-rho(scalar)
            pair=(k+pair[1]-rho(pair[1]),k+pair[0]-R(pair[0]));t+=1
            after=(k+pair[1]-rho(pair[1]),k+pair[0]-R(pair[0]))
            assert min(after)>=min(cap,scalar),(k,c,t,scalar,pair,after)
            tests+=1
        maximum_steps=max(maximum_steps,t)
p=Path(__file__)
out=dict(status='complete exact finite verification',budget_range=[50,99],
         all_integer_seeds='0<=c<=k',cutoff='ceil(3k/5)+4',seeds=seeds,
         scalar_steps_checked=tests,maximum_steps=maximum_steps,
         source_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(out)

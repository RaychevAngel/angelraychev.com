"""Diagnostic: guarded ordinary-envelope early injection plus terminal quota."""
from pathlib import Path
from functools import lru_cache
from bisect import bisect_left
import importlib.util,json,time
P=Path(__file__).resolve().parent
def load(name,file):
    s=importlib.util.spec_from_file_location(name,P/file)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('ordinary_max_terminal','root-terminal-gate-panel.py')
v=load('ordinary_max_guards','comparison_variable_slack_general.py')
a=load('ordinary_max_early','lower-ordinary-max-injection.py')
late_api=load('ordinary_max_late','lower-causal-late-capacity.py')
choices={};guards={};late_guards={}
@lru_cache(maxsize=8192)
def early(b,d):
    certificate=choices[(b,d)];R=certificate['R'];k=b+d;H=b*(b-1)
    em=a.OrdinaryMaxEarly(k,R);guard=em.causal_guard(2*b,2*b)
    guards[(b,d)]=guard
    assert guard['valid'],guard
    e=em.clock(H-d+1);q0=min(H,em.maxima[e])
    return tuple((q,em.clock(q)) for q in [q0]+([H] if q0<H else []))
m.early_endpoints=early
@lru_cache(maxsize=8192)
def late(b,d,c):
    R=choices[(b,d)]['R'];k=b+d;H=b*(b-1);top=H+d+1
    em=late_api.OrdinaryMaxLate(k,R,gate=c)
    guard=em.causal_guard(2*b,2*b);late_guards[(b,d,c)]=guard
    assert guard['valid'],guard
    ell=em.clock(H+1);y0=min(top,em.maxima[ell]);ys=[y0]+([top] if y0<top else [])
    return tuple((y,em.clock(y))for y in ys)
m.late_endpoints=late
start=time.process_time();rows=[];hist={};maximum=-1;worst=[];improved=0
for old in json.loads((P/'root-ordinary-max-panel.json').read_text())['results']:
    w,n,k=old['w'],old['n'],old['k'];b=w//2;d=k-b;key=(b,d)
    if key not in choices:choices[key]=v.strongest_cutoff(b,d)
    certificate=choices[key];R=certificate['R']
    assert certificate['admissible']
    m.cut.cutoff=lambda budget,R=R:R
    J=m.joint(w,n,k,k);Jhalf=m.joint(w,n,k,k//2)
    assert J>=old['J'] and J<=Jhalf<=J+1,(w,n,k,J,Jhalf,old['J'])
    lower=max(2*J+1,2*Jhalf);improved+=lower>old['lower']
    r={**old,'J':J,'P_minus_J':old['P']-J,'J_half':Jhalf,
       'lower':lower,'gap':old['upper']-lower}
    assert r['gap']>=0,r
    hist[str((w%2,r['gap']))]=hist.get(str((w%2,r['gap'])),0)+1
    if r['gap']>maximum:maximum=r['gap'];worst=[r]
    elif r['gap']==maximum:worst.append(r)
    rows.append(r)
out=dict(status='DIAGNOSTIC; both guarded physical boundary refinements independently reviewed; global bound remains eight',
         cases=len(rows),guarded_parameter_pairs=len(guards),improved=improved,
         maximum_gap=maximum,histogram=hist,worst=worst,results=rows,
         causal_guards=list(guards.values())+list(late_guards.values()),CPU_seconds=time.process_time()-start)
(P/'root-both-ordinary-max-panel.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ('results','worst','causal_guards')})
print('worst',worst[:8])

"""Finite falsification of the abstract one-day balanced comparison.

SMT UNSAT is bounded evidence only. No unbounded theorem is inferred.
"""
import z3,json,argparse,time
from pathlib import Path

def run(k,N,T,timeout=30000):
 s=z3.Solver();s.set(timeout=timeout)
 f=z3.Array('f',z3.IntSort(),z3.IntSort());g=z3.Array('g',z3.IntSort(),z3.IntSort())
 s.add(f[0]==k,g[0]==k)
 for i in range(N+1):
  s.add(i+1<=f[i],f[i]<=g[i])
  if i:s.add(0<=f[i]-f[i-1],f[i]-f[i-1]<=1,0<=g[i]-g[i-1],g[i]-g[i-1]<=1,g[i-1]<=f[i])
 X=[(z3.Int(f'x{t}'),z3.Int(f'y{t}'))for t in range(T+2)]
 B=[(z3.Int(f'p{t}'),z3.Int(f'q{t}'))for t in range(T+1)]
 s.add(*[z==0 for z in X[0]+B[0]])
 for t in range(T+1):
  x,y=X[t];s.add(x>=0,y>=0,x<=N,y<=N)
  s.add(X[t+1][0]==g[y],X[t+1][1]==f[x])
  if t<T:
   p,q=B[t];s.add(p>=0,q>=0,p<=N,q<=N)
   a=g[q];b=f[p];s.add(B[t+1][0]==a,B[t+1][1]==z3.If(b>=a-1,b,a-1))
 s.add(z3.Or(B[T][0]>X[T+1][0],B[T][1]>X[T+1][1]))
 start=time.process_time();r=s.check();out=dict(k=k,N=N,T=T,status=str(r),cpu=time.process_time()-start)
 if r==z3.sat:
  m=s.model();out.update(f=[m.eval(f[i]).as_long()for i in range(N+1)],g=[m.eval(g[i]).as_long()for i in range(N+1)],X=[[m.eval(z).as_long()for z in p]for p in X],B=[[m.eval(z).as_long()for z in p]for p in B])
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('k',type=int);p.add_argument('N',type=int);p.add_argument('T',type=int);p.add_argument('--timeout',type=int,default=30000);a=p.parse_args();r=run(a.k,a.N,a.T,a.timeout);Path(__file__).with_name(f'comparison-abstract-balanced-k{a.k}-t{a.T}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

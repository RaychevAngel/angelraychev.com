"""Adversarial test of a stronger triangle invariant for the corner allocation model."""
from math import isqrt
import json
from pathlib import Path
def R(x):return isqrt(x-1)+1 if x else 0
def rho(x):
 r=(isqrt(4*x+1)-1)//2;return r+(r*(r+1)<x)
def G(x):return x-rho(x)
def F(x):return x-R(x)
for k in range(2,41):
 st={(0,0)};a=b=0
 for t in range(1,20*k):
  a,b=G(b+k),F(a+k);best={}
  for x,y in st:
   for u in range(k+1):
    nx,ny=G(y+u),F(x+k-u)
    if a*b and nx*b+ny*a>a*b:
     out=dict(status='COUNTEREXAMPLE to weighted triangle, not ordinary maximum',k=k,t=t,source=[x,y],u=u,target=[nx,ny],ordinary=[a,b],excess=nx*b+ny*a-a*b)
     Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out);raise SystemExit
    best[nx]=max(best.get(nx,-1),ny)
  peak=-1;st=set()
  for x in sorted(best,reverse=True):
   if best[x]>peak:st.add((x,best[x]));peak=best[x]
  if max(a,b)>=(k-1)*(k-2):break
print('passed')

"""Bounded exact falsification of 2*solo-1 on connected nonbipartite Hall relations.
Positive counterexamples are literal nested two-copy schedules; negative outputs
concern only the enumerated finite relations.
"""
from pathlib import Path
from collections import deque
from itertools import combinations
import importlib.util,json,time,argparse,random


def hood_table(adj):
 n=len(adj);out=[0]*(1<<n)
 for a in range(1,1<<n):
  bit=a&-a;out[a]=out[a^bit]|adj[bit.bit_length()-1]
 return out


def deletions(a,k):
 bits=[1<<i for i in range(a.bit_length()) if a>>i&1]
 yield 0
 for size in range(1,min(k,len(bits))+1):
  for row in combinations(bits,size):yield sum(row)


def solo(adj,k):
 N=hood_table(adj);V=len(N)-1;D={V:0};q=deque([V])
 while q:
  a=q.popleft()
  if not a:return D[a]
  for gone in deletions(a,k):
   z=N[a^gone]
   if z not in D:D[z]=D[a]+1;q.append(z)
 return None


def nested_within(adj,k,limit,retain=False):
 N=hood_table(adj);V=len(N)-1;start=(V,V);q=deque([start]);D={start:0};P={}
 # Nested larger U and smaller V. Deletions in the larger support's overlap
 # force the corresponding smaller deletions, charging each actual copy.
 while q:
  a,b=q.popleft();depth=D[a,b]
  if not a and not b:
   seq=[];cur=(a,b)
   while cur!=start:
    old,sur=P[cur];seq.append({'before':old,'survivor':sur});cur=old
   seq.reverse();return {'joint':depth,'schedule':seq,'states':len(D)}
  if depth>=limit:continue
  for da in deletions(a,k):
   forced=da&b;cost=da.bit_count()+forced.bit_count()
   if cost>k:continue
   ar=a^da;remain=b^forced
   for extra in deletions(remain,k-cost):
    br=remain^extra;z=(N[ar],N[br])
    if z not in D:D[z]=depth+1;P[z]=((a,b),(ar,br));q.append(z)
 return {'joint':None,'states':len(D)}


def odd_connected(adj):
 colors=[None]*len(adj);colors[0]=0;q=[0];odd=False
 for x in q:
  for y in range(len(adj)):
   if adj[x]>>y&1:
    if colors[y] is None:colors[y]=1-colors[x];q.append(y)
    elif colors[y]==colors[x]:odd=True
 return len(q)==len(adj) and odd


def run():
 p=Path(__file__).parent;old=json.loads((p/'upper-half-solo-counter.json').read_text());base=old['adj'];results=[];start=time.process_time()
 # Every one-edge nonbipartite augmentation retains the displayed matching.
 for i in range(len(base)):
  for j in range(i,len(base)):
   if base[i]>>j&1:continue
   a=base.copy();a[i]|=1<<j;a[j]|=1<<i
   if not odd_connected(a):continue
   tau=solo(a,2)
   if tau is None:continue
   result=nested_within(a,2,2*tau-2)
   row={'addition':[i,j],'tau':tau,**result};results.append({k:v for k,v in row.items() if k!='schedule'})
   print(i,j,tau,result['joint'],result['states'],round(time.process_time()-start,2),flush=True)
   if result['joint'] is not None:
    out={'status':'COUNTEREXAMPLE connected nonbipartite Hall','n':len(a),'k':2,'adj':a,'tau':tau,**result,'tested':results,'cpu':time.process_time()-start}
    (p/'upper-connected-half-counter.json').write_text(json.dumps(out,indent=2)+'\n');return
 out={'status':'No counterexample in all single nonbipartite edge augmentations of the retained tree','cases':results,'cpu':time.process_time()-start}
 (p/'upper-connected-half-probe.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':run()

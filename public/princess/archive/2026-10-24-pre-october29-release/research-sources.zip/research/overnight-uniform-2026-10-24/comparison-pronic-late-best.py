"""Challenge a target-specific best-phase late+middle comparison."""
from pathlib import Path
from importlib.util import spec_from_file_location,module_from_spec
import json,time
D=Path(__file__).resolve().parent
s=spec_from_file_location('r',D/'root-shifted-clock.py');R=module_from_spec(s);s.loader.exec_module(R)
def run(b,d,odd):
 w=2*b+odd;n=w+odd;k=b+d;h=w*n//2;rows=R.endpoints(b,d);V=(k,k);ph={}
 for t in range(max(z[3]for z in rows)+2):
  if t in {z[3]+1 for z in rows}:ph[t]=V
  V=(V[1]+k-R.rho(V[1]),V[0]+k-R.R(V[0]))
 out=[]
 for Q,Y,e,ell,A,C in rows:
  tau=R.faster_middle(b,d,h,Q,Y,odd);X=ph[ell+1]
  for _ in range(tau):X=R.old.meeting_api.physical(w,n,k,X)
  margin=max(X)-(h-Q)
  if margin<0:out.append(dict(b=b,d=d,odd=odd,Q=Q-b*(b-1),Y=Y-b*(b-1),margin=margin,late=ph[ell+1],hybrid=C,tau=tau))
 return out
if __name__=='__main__':
 start=time.process_time();bad=[]
 for b in range(200,301):
  for d in(1,2,3):
   for odd in(0,1):bad+=run(b,d,odd)
 out=dict(status='FALSIFICATION_ONLY',bad=bad,cpu=time.process_time()-start);Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(len(bad),bad[:4],out['cpu'])

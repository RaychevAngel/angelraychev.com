# Generic nested-layer seriality is false

24 October 2026. Exact counterexample; no rectangular-grid counterexample is claimed.

Let the folded graph have vertices c,u,v and relational neighborhoods

    K(c)={c,u,v}, K(u)=K(v)={c}.

There is a loop at c, and ordinary edges cu,cv. Start both identical
layers at the full three-element set and use daily budget two. Inspect c
in each layer on day one. Each survivor is {u,v}, so both next supports
are {c}. Inspect c in each layer again on day two. Capture is guaranteed.
One day is impossible because six possible room copies exceed the budget.
Thus the joint optimum is exactly two.

A single full layer takes exactly two days: it contains three vertices,
and deleting c and u leaves {v}, whose neighborhood is {c}. Every serial
strategy must spend at least two days before the first layer is empty.
Before that elimination day the other layer was untouched and remains
full. The final inspection in the first layer is nonempty, so at most
one of the two daily probes is available for the second full layer.
Its survivor is nonempty and K has no isolated vertices. Thus serial
capture requires at least three days, which is attainable.

The six-vertex bipartite double cover is the tree consisting of two
adjacent central vertices, each with two leaves. Swapping its two color
classes is an involutive automorphism. Hence all hypotheses of the exact
alternating-polarization theorem hold. The obstruction already obeys
the nested-layer condition (the two layers remain equal).

Consequences:

* Reflection polarization does not imply serial allocation.
* Even the putative generic bound T>=2*tau-1 is false: here tau=2,T=2.
* Any rectangular concentration theorem must use the folded grid geometry,
  not only neighborhood union/intersection identities, no isolated vertices,
  symmetry, or nesting of the layers.

The independently inspectable witness is also the first output of
`upper_nested_counter.py`, which computes the exact nested game and exact
serial optimum separately. `upper_nested_counter.json` records the masks
and transitions. The three-vertex proof above is independent of the search.

## Hall property alone does not repair seriality

A second exact obstruction has six folded vertices 0,...,5 with edges

    01, 13, 23, 24, 35, 45.

This is a four-cycle 2-3-5-4-2 with the pendant path 3-1-0. It has the
perfect matching {01,23,45}, so |K(S)|>=|S| for every subset S.
With budget two, exhaustive exact Bellman search gives solo optimum four,
joint optimum six, and serial optimum seven. The joint survivor sequence
is stored in `upper_nested_matching_counter.json` and can be replayed by
ordinary neighborhoods. Thus Hall noncontraction does not supply either
seriality or the bound T>=2*tau-1.

This second quotient is bipartite and has no loops, so its bipartite double
cover is disconnected. The folded rectangle instead has a connected
quotient with a looped boundary. No strict example was found after adding
any nonempty subset of loops to this six-vertex obstruction, nor in the
bounded connected-single-loop-tree audit through six vertices (9,336
Hall-admissible graph/budget instances). These negative diagnostics are
not a theorem. Any proposed all-rectangle exchange must retain the exact
folded geometry; none of these examples is itself a rectangle.

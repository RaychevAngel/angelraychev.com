# Four-day brackets from central transport and the final quota

24 October 2026. Independently accepted ordinary theorem. The older
five-day construction is preserved unchanged. The definitions below make
the lower and upper bounds directly reproducible without selecting an
unspecified necessary evaluator.

Work in either of these even-width families:

* w=2b, b>=200, k=b+1, n>=2b;
* w=2b, b>=200, k=b+d, 2<=d<=19, n>=2b+2d-2.

Put h=bn, H=b(b-1), R=floor(3k/5), L=R². Write
root(x)=ceil(sqrt(x)) and rho(x)=min{r>=0:x<=r(r+1)}, both zero at zero.
Define four nondecreasing integer maps

    g(x)=x+k-rho(x+k),     f(x)=x+k-root(x+k),
    G(x)=k+x-rho(x),       F(x)=k+x-root(x).

The early scalar and pair start S_0=0, E_0=(0,0), and evolve by

    S_(t+1)=g(S_t),       Z=g(L),
    E_(t+1)=(max(min(Z,S_(t+1)),g(E_t[1])),
             max(min(Z,S_(t+1)),f(E_t[0]))).

Let e(Q)=min{t:max(E_t)>=Q}. For a terminal gate0<=c<=k, the late scalar
and pair start B_0=c, C_0=(c,c), and evolve by

    B_(t+1)=G(B_t),       A=L+k,
    C_(t+1)=(max(min(A,B_(t+1)),G(C_t[1])),
             max(min(A,B_(t+1)),F(C_t[0]))).

Let ell_c(Y)=min{t:max(C_t)>=Y}. The finite endpoint domain is exactly

    H-d+1<=Q<=H,       H+1<=Y<=H+d+1,

with integer Q,Y, and the even-width middle time is

    tau(h-Q;Y)=ceil((h-Q-Y)/d).

The numerator is positive in both stated parameter families. Define

    J(c)=min over admissible Q,Y of e(Q)+tau(h-Q;Y)+ell_c(Y).

The endpoint ranges are unchanged when c changes. The accepted
arbitrary-gate late proof supplies the same necessary history clock.
All old lower bounds remain available separately.

In particular this theorem supplies the concrete computable bracket

    L_new=max(2J(k)+1,2J(floor(k/2))),
    U_new=min(2J(k)+6,2J(floor(k/2))+5).

The construction below attains a capture time at most U_new, and
U_new-L_new=4. Retaining previous lower bounds by a maximum and previous
constructions by a minimum can only improve this bracket. These recurrences
are definitions of intermediate exact bounds, not the final O(1) formula goal.

## Construction with any final residual

Let P_c be the number of complete inspection-and-movement updates in a
constructed solo history starting with one full color class and ending
with at most c possible positions. The actual cut-compatible transport
construction in `upper-cut-phase-bridge.md` gives

    P_c <= J(c)+2.                                      (1)

Indeed its ordinary head costs at most e+1 moves, the physical central
bridge supplies either desired relative corner phase within exactly tau
moves, and the better-phase ordinary tail to c costs at most ell_c+1.
There is no final capture inspection in P_c. Parameterizing the tail by
c does not alter the central bridge or its endpoint-size and timing
conditions.

The physical +1 comparison remains valid for every tied seed c in[0,k].
The scalar first hit from c is no later than the hit from0 used in the
accepted fast-one proof; the same half-frequency discrepancy and minimum
drift pay one extra update. The ordinary and capped-hybrid recurrences
then preserve this same-phase domination after the fast segment. This
comparison does not assert that every necessary hybrid path is physical.

## Two ways to finish a full-board schedule

For c=floor(k/2), take such a P_c-move solo word, reflect it in the even
axis, and use the reflected word in reverse after one central inspection.
At the central layer the two small survivor sets have opposite colors and
total size at most2c<=k. Inspect their union. The reversed-walk argument
shows this is a winning full-board schedule, so

    T <= 2P_c+1 <= 2J(c)+5.                           (2)

Alternatively, the gate-k solo word followed by its capture inspection
has at most J(k)+3 inspections. Concatenating an appropriate reversed
solo word captures both initial cohorts, giving

    T <= 2J(k)+6.                                    (3)

Both are actual inspection constructions, rather than a choice between
unrealized numerical phase labels.

## The terminal-cut lower bound matches within four days

The accepted final-quota cut and ordinary gate lower bounds give

    T >= max(2J(k)+1, 2J(c)).                         (4)

Write J=J(k). Since the late seed0 performs one first update to(k,k),
its whole later scalar and hybrid trajectory equals the seed-k trajectory
shifted by one update. Consequently J(0)=J+1. Monotonicity in the terminal
seed gives

    J <= J(c) <= J+1.

If J(c)=J, use(2) and the first term in(4): the gap is at most4.
If J(c)=J+1, use(3) and the second term in(4): again the gap is at most4.
Thus the combined computable lower and constructive upper bounds have
width at most4 throughout both displayed parameter families.

This is scope-explicit tightening. It does not cover the remaining short
higher-excess rectangles, claim an exact value, or change Lean coverage.
The whole-rectangle uniform bound remains a separate theorem.

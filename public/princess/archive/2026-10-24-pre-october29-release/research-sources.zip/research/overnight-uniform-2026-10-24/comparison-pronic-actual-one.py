"""Mechanism diagnostics for the exact zero-origin hybrid pronic interface.
No inference from sampled budgets to a uniform theorem.
"""
from pathlib import Path
from importlib.util import spec_from_file_location,module_from_spec
import json,time
D=Path(__file__).resolve().parent
def load(name,p):s=spec_from_file_location(name,p);m=module_from_spec(s);s.loader.exec_module(m);return m
S=load('small',D/'comparison-shifted-pronic-small.py');J=load('joint',D.parent/'joint-history-2026-10-24/root-joint-hybrid-clock.py')
def run(b,d):
 w=2*b+1;n=w+1;k=b+d;h=w*n//2;H=b*(b-1);qmin=H-d+1;qmax=H;ymin=H-d+2;ymax=H+2
 E=J.early_api.EarlyHybrid(k);e=E.clock(qmin);Q0=min(qmax,E.maxima[e]);qs=sorted(set((Q0,qmax)));es={q:E.clock(q)for q in qs}
 C=J.late_api.hybrid_gate_curve(k,ymax,True);ell=J.late_api.gate_time(C,ymin);Y0=min(ymax,C['maxima'][ell]);ys=sorted(set((Y0,ymax)));ells={y:J.late_api.gate_time(C,y)for y in ys}
 rows=[]
 for Y in ys:
  for Q in qs:
   cv=C['phases'][ells[Y]];av=E.states[es[Q]];tau=S.equal_clock(b,d,Y,h-Q);X=cv
   for _ in range(tau):X=J.meeting_api.physical(w,n,k,X)
   margins=[]
   for extra in range(3):
    margins.append(max(X[p]+av[p^1]-h for p in(0,1)));X=J.meeting_api.physical(w,n,k,X)
   rows.append(dict(Q=Q-H,Y=Y-H,C=[z-H for z in cv],A=[z-H for z in av],e=es[Q],ell=ells[Y],tau=tau,margins=margins))
 return dict(b=b,d=d,rows=rows,worst_one=min(r['margins'][1]for r in rows),worst_zero=min(r['margins'][0]for r in rows))
if __name__=='__main__':
 start=time.process_time();rows=[]
 for b,d in [(200,1),(201,1),(202,1),(203,1),(204,1),(500,1),(1000,1),(1458,1),(200,2),(201,2),(200,3)]:
  r=run(b,d);rows.append(r);print(b,d,r['worst_one'],flush=True)
 out=dict(status='EXACT_HYBRID_DIAGNOSTIC_NOT_UNIFORM_PROOF',rows=rows,cpu=time.process_time()-start);Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

# Connectedness and a loop do not rescue the half-solo bound

24 October 2026. Explicit ordinary counterexample, submitted for independent
review. This is a general-graph failure shield, not a rectangle counterexample.

The retained ten-vertex tree K has edges

    01,12,14,23,36,39,45,67,89,

and a perfect matching 01,23,45,67,89. At budget2 its exact one-copy capture
time is6, while two identical copies admit the literal nested10-day schedule
in upper-half-solo-counter.json. The exact one-copy lower bound is independently
recomputed by exhaustive subset BFS in the attached checker.

Construct K' by replacing each vertex v of K with three independent twins
(v,0),(v,1),(v,2). Replace every old edge uv by all nine edges between the
two twin classes. Add one new vertex z, with a loop and an edge to (0,0).
Set the daily budget to8.

K' has31 vertices. It is connected and nonbipartite, and its relation is
Hall-noncontracting: use the old matching between corresponding twins and
the loop at z as a permutation matching. Consequently the bipartite double
cover of K' is also connected. These are exactly the extra generic properties
which the previous unlooped example lacked.

## The one-copy optimum is exactly six

For any inspection word on K' of daily cost at most8, construct a word on K
as follows. On each day inspect every old vertex whose three twins have all
been inspected that day. There are at most floor(8/3)=2 such vertices.

Inductively, every vertex in the old word's current possible-position set has
ALL three twins in the K' possible-position set. It holds initially. If an
old vertex is not inspected, at least one of its twins survives; that twin
is adjacent to all three twins of every old neighbor. Hence all those neighbor
classes occur after movement. The extra vertex z only adds possible positions
and cannot invalidate the inclusion. This induction does not assume that all
K' fibers remain full: only the classes in the embedded old history must be.

A K' capture in at most five days would therefore give an impossible K
capture in at most five days. Thus its solo time is at least6. Conversely,
triple the inspections in a six-day K solo word and inspect z every day.
This costs at most7<=8 per day. The vertex z never survives an inspection,
so it cannot introduce any extra core positions. The core evolves exactly
as the old word's twin blow-up and is captured in six days. Thus tau(K',8)=6.

## Two copies are captured in ten

Triple the retained ten-day nested joint word on the two copies of K. Its
core cost is6 per day. Additionally inspect z in BOTH copies on every day,
for total cost8. The two core supports evolve exactly as the original
supports' blow-ups; the extra vertices are removed before every movement.
The last day's core survivors are empty, so no new z is generated either.
This is a literal ten-day winning word. The checker replays all62 actual
vertices and verifies the quota and nested survivor relation at every day.

Consequently

    T(K' disjoint-union K',8) <=10 < 11 = 2*tau(K',8)-1.

No optimality claim about the joint time is needed. The one-copy lower bound
and this upper witness alone refute the proposed inequality.

## General mechanism and scope

More generally, any two-copy counterexample of budget k can be preserved
while adding a permanently inspected looped connector by taking twin
multiplicity L>2 and new budget Lk+2: floor((Lk+2)/L)=k. This shows that mere
connectedness, nonbipartiteness, a loop, symmetry, and Hall noncontraction
cannot imply a half-solo theorem. Additional folded-grid geometry is needed.

The new graph is not a folded rectangle: it has complete bipartite twin
fibers and only one loop. This does not disprove a rectangle-specific
half-solo reduction or any accepted capture-time bound. No Lean claim is made.

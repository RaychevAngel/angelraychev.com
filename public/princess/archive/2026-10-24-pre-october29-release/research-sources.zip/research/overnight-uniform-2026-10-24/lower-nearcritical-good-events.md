# Zero-slack good events up to the last subcritical root

24 October 2026. Ordinary physical-history lemma submitted for independent
review. This is the geometric component of a proposed stronger boundary
comparison; the required paired bad-step credit theorem is separate.

Let w<=n, wn even, b=floor(w/2), h=wn/2. For the two actual cohort hole
sets U0,U1 at some day put

    Q=|U0|+|U1|, sigma=sum_i (|N(Ui)|-|Ui|),
    r=ceil(sqrt(Q)).

Assume 4<=r<=b-1 and sigma<=r. Call this a zero-slack good event.
The hypotheses refer to actual physical hole sets, not a synthetic merged
state. The canonical separator and dominant-component results used below
are the independently reviewed ones in
`../uniform-history-2026-10-23/physical-dominant-corner.md`.

## 1. Surplus, concentration, and exact phase

Each hole set belongs to the small separator branch. Indeed

    h-Q >= 2b^2-r^2 > r(r+1) >= sigma(sigma+1),

where the strict inequality remains valid at r=b-1. The additive quadrant
component bounds therefore give Q<=sigma^2. Since (r-1)^2<Q, this forces
sigma=r.

Moreover Q>r^2/2 for r>=4. There is a unique dominant actual component,
cohort and corner. Let m be its nondominant surplus allowance, including
unused surplus. The sharpened concentration bound is

    Q <= (r-m)^2+m^2,       0<=m<r/2.

If m>=2, the decreasing smaller-root quadratic gives
Q<=(r-2)^2+4<(r-1)^2+1<=Q, a contradiction. Hence m<=1, and at most
one hole lies outside the dominant component. Further, m=1 is possible
only when

    Q=(r-1)^2+1.                                      (1)

For every larger integer in the root bin, m=0: the complete two-cohort
hole state is one connected component in one actual cohort.

The dominant component lies in a genuine corner ball of radius at most
2r-2, with its actual corner uniquely determined. Its phase gives the
exact total square/pronic profile even when m=1:

    Q<=r^2 if the dominant component has its corner's color;
    Q<=r(r-1) if it has the opposite color.

This is the accepted remainder algebra: dominant surplus a and remainder
m give Q<=a(a-1)+m^2<=(a+m)(a+m-1) in the opposite phase.
No additional radius, phase, or cohort merger is assumed.

## 2. Changing identity costs many inspections

Take consecutive zero-slack good events separated by Delta actual days,
with different dominant actual identities. If the intervening root values
remain between4 andb-1, those intervening events have sigma>=r+1.
The geometric charge itself does not require this interval condition.
Apply the accepted fixed-matching block charge
with at most one outlying hole at each endpoint. At the new endpoint,
whose root is r,

    Delta*k >= Q-r(r-1)/2-2 >= r(r-3)/2.             (2)

Intermediate hole sets need not be localized and may retreat in size.
The same bound covers a change of actual cohort; that case has a stronger
charge. Thus a bad-run comparison which earns enough room credit over
Delta-1 steps can pay each necessary change of reference phase.

For the proposed extension from root b-5 to b-1, every new good endpoint
has r>=b-4, so the uniform sufficient charge is

    Delta*k >= (b-4)(b-7)/2.                         (3)

Neither (2) nor (3) is itself a clock comparison: it measures actual
inspections, and one must still account for the ordinary time spent
between endpoints. A two-step excess-surplus argument is needed here;
the old positive one-step credit lemma does not apply with zero slack.

## 3. Optional full-board normalization fixes the dominant cohort

By `lower-alternating-polarization.md`, for an even-area rectangle one
may assume an optimal full-board strategy has a fixed larger reflected
cohort and a fixed smaller reflected cohort at every belief and survivor.
The same containment, reversed, holds for their hole sets. The favored
larger support therefore has a hole set which, after reflection, is
contained in the other cohort's hole set.

At a zero-slack good event the dominant component has at least Q-1>Q/2
holes. It cannot belong to the smaller hole set: reflection would place
at least as many holes in the other set, exceeding total Q. Consequently
the dominant hole cohort is the SAME permanent initial cohort at every
such event in the normalized strategy. Only the actual corner can
change. Corners of the same color do not change the relative phase
convention and require no reference rewind.

This optional normalization is exact for full initial uncertainty. It
is not asserted for an arbitrary partial initial state which fails the
polarization fixed-set condition.

## 4. The last crossing and the unresolved analytic interface

At a first crossing of H=(b-1)^2, with k=b+d<3b, the exact scalar
envelope is Qmax=G(H-1)=H+d-1, since rho(H-1+k)=b. In particular
d=1 has no overshoot above H. A target Q>H has root at least b.
It is NOT covered by this good-event theorem. If such a target had
sigma<b, the small-branch bound Q<=sigma^2 would contradict Q>H;
therefore sigma>=b. The complementary-side exclusion does hold throughout
this overshoot range: h-Q>=b^2+2b-d>b(b-1) when d<2b.
That final transition must be compared by the appropriate neutral
width/phase bound, rather than silently declared a subcritical good
event.

The proposed stronger hybrid necessity thus needs: a paired bad-run
credit inequality across the few remaining root walls; enough credit
from (2) to pay changes of corner phase; and an explicit final-crossing
comparison. No stronger capture-time bound is claimed by this note.

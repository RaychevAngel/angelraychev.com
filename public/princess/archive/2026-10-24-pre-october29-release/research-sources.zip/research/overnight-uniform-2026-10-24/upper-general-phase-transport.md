# Reflection transport at the central clearing rate

24 October 2026. Proposed uniform physical construction, pending independent
review. No unrestricted normal form or optimality is assumed.

Let w=2b, n>=w, k=b+d with d>=1. Choose a positive odd integer t such that

    t + 2 floor(dt/(2b)) >= 2b+1.                    (1)

For every prefix size dt<=q<=h=bn and either initial relative phase p,
there is a directly specified t-move physical strategy carrying the
bottom-left prefix of size q to a subset of the bottom-right prefix of
size q-dt. Its daily inspection quota is k.

Both endpoint prefixes have relative phase p. Since the two bottom
corners have opposite colors and t is odd, their global phases have
exactly the relation required by t moves. Against the central prefix
drift d this is a cost-free change of the relative phase matching.

Simple choices are t=2b+1 for d=1 and t=2b-1 for d>=2. The more flexible
condition (1) is only a construction condition, not a claim of its
necessity or of minimum transport time.

## Diagonal and height bounds

Write Delta=dt, and let D,D' be the final occupied diagonals of the
source and reflected target in coordinates measured from their own
corners. They have the same parity. Every diagonal has at most2b cells.
Consequently

    D'-D <= -2 floor(Delta/(2b)).                    (2)

Indeed if the diagonal drops by only2m, the size drop between two
nonempty prefixes is at most (m+1)2b-1. This proves (2). For an empty
target, use its conventional diagonal p-2; counting all occupied
diagonals gives the same bound.

Before physical clipping, the two height walks have the form

    a_x = D-x-2+2 I{x>=c},
    z_x = D'-(2b-1-x)-2+2 I{2b-1-x>=c'}.

Thus z_x-a_x <= D'-D+2b+1 <= t by (1)-(2).
Clipping does not spoil this inequality. If a is clipped at the top,
the two phase-dependent top heights differ by at most1, so z-a<=1.
If z is clipped at the bottom, the two empty heights differ by at most1,
again giving z-a<=1. In every other case clipping only raises a or
lowers z relative to the displayed expressions. Since t>=1, in all
cases the physical walks satisfy z-t<=a.

There are b even and b odd columns, so the sum of the empty-height
constants is the same in either global phase. Therefore

    sum_x(a_x-z_x)=2Delta.

The descending legal virtual-height word from a to z-t has exactly

    F=sum_x(a_x-z_x+t)/2=Delta+bt=kt

flips. Divide that word into t successive groups of k flips and inspect
the cells of each group which lie in the physical board on that day.
The accepted transport theorem gives final containment in z. Invisible
flips at the top or bottom only reduce actual inspection cost.

## Free phase choice whenever the plateau accommodates the bridge

The two anchored phases have neighborhood surplus b throughout

    (b-1)² < survivor size < h-b(b-1).

Equivalently, for pre-inspection prefix sizes in the integer interval

    L=b²-b+d+2 <= q <= A+1=h-b²+2b+d-1,

every ordinary prefix move decreases size by exactly d.

Here set A=h-b²+2b+d-2, leaving one room of entrance margin.
If q-dt>=L and q<=A+1, ordinary continuation for t moves and the transport
bridge end at the SAME size q-dt and at the SAME elapsed day, but have
opposite corner-relative phases. Thus either deterministic anchored tail
phase is physically available without time or size loss.

For a full-start strategy, first enter size at most A by an anchored
prefix. Monotonicity and the plateau transition at A+1 show the entrance
size lies in [A-d+1,A]. Hence the sufficient uniform length condition

    h >= 2b²-3b+d+3+dt                              (3)

ensures the bridge fits for either initial phase. With a_alpha and
q_alpha the actual deterministic entrance time and size, the resulting
solo upper is

    min_alpha [a_alpha+t+min_beta ell_beta(q_alpha-dt)],

where ell is the deterministic anchored capture clock including its
last inspection. This retains the actual entrance size; no independent
minimum across unequal states is used.

This theorem applies to parameterized widths, lengths, and budgets.
Outside condition (3) the bridge itself remains valid, but it need not
beat ordinary prefix continuation, whose speed may then exceed d.

# The remaining odd one-room contact is a synchronized-clock question

24 October 2026. Research assessment; no new full-game bound.

The accepted asymmetric middle theorem leaves only one room at odd width.
The lower physical pair from an equal seed Y>H, H=b(b-1), reaches the relaxed
maximum M=h-Q at the necessary first-hit time. Its only deficient terminal
pattern is (M,M-1). It therefore fails the opposite-phase meeting only when
an early pair has its larger coordinate in the unfavorable label and no
spare room. A tied early pair, or an early maximum Q+1, resolves this.

## An exact last-wall representation

For inputs above H and before a helpful high-boundary branch, write

    Psi(x,y)=(y+d,x+d-1_(x>b^2)).

The closed descendant expression in comparison-one-square-transfer.md is an
exact implementation of this map, retaining coordinate labels. Moreover the
unbounded quadrant forward map Hf and backward map satisfy

    Hf(A)+(k,k)=Psi(A+(k,k))

in the same last-root range. Thus the physical late pair beta=A_(ell+1)+k
and early pair alpha=A_(e+1) are connected by this same last-wall orbit,
not by independent phase choices.

That observation alone is insufficient. The local counterfamily d=1 has
beta=(H+1,H+2) when b is even, with its coordinates reversed when b is odd.
After b-1 common forward steps from beta-k, alpha=(H,H-1). On a shortest
odd rectangle, the equal-seed middle clock from Y=H+2 to M=h-H is 9b-2;
at one extra middle update both matched sums are h-1. The checker confirms
this and its higher-d analogues; these are counterexamples to a RELAXED
interface, not physical capture counterexamples.

The checker comparison-shared-square-attack.py/.json tests every state in
an explicit small endpoint box for d=1,...,10, each b residue mod2d, and each
central area residue mod(2d-1). It is a diagnostic, with no claim here that
this constitutes a complete parametric certificate. Its 151272 comparisons
have110 failures, all deficit exactly one. Every failure has beta offsets
{1,d+1}, hence uses the top possible Y endpoint, and the unfavorable early
larger coordinate. This identifies a concrete equality case to analyze.

## Two tempting ancestry claims are false

The adverse physical beta can occur on the literal zero-start physical
orbit: for example b=202,d=1, beta=(H+1,H+2) at its late physical day1655.
At that time, however, the actual hybrid clock only certifies Y=H+1. For
Y=H+2 the hybrid requires a later day and the physical beta is stronger.
Thus zero ancestry by itself does not exclude the adverse orientation.

Nor does arbitrary tied fast-reset ancestry exclude every adverse beta.
The accepted inverse-interval test finds allowed tied origins, for example,
for b=201,202,203. The exact scalar first-crossing seed is extra information;
its existence somewhere in the allowed crossing interval is too weak.

The mathematical issue is synchronization: the necessary hybrid's actual
scalar-injection time and seed must be compared with the zero-start physical
orbit at precisely one shifted day. Replacing either by an independent
admissible origin discards a relevant constraint.

## A useful easy branch

If the early endpoint Q remains in the scalar-injection regime, the early
hybrid pair is tied. Accepted one-day physical domination then makes both
early physical coordinates at least Q, so the asymmetric middle maximum
already suffices; its one-room minimum deficit is irrelevant. A sufficient
numerical condition is floor(3k/5)>=b, since then Q<=H<R^2<=Z.
This is a conditional middle/boundary comparison. Extension of necessary
physical boundary clocks to those budget ranges is a separate obligation.

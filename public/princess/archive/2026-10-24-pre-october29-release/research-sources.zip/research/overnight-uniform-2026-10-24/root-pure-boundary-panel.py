"""Hypothetical ordinary boundary clocks; NOT proved necessary for the game."""
from pathlib import Path
import importlib.util,json,time
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('pure_panel_base',P/'root-asymmetric-clock.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class PureEarly(m.m.old.early_api.EarlyHybrid):
    def grow(self,target):
        while self.maxima[-1]<target:
            a,b=self.states[-1];pair=(self.G(b),self.F(a))
            assert max(pair)>self.maxima[-1]
            self.states.append(pair);self.maxima.append(max(pair))
def pure_late(k,ceiling,keep_phases=False):
    pair=(k,k);maxima=[k];phases=[pair]
    while max(pair)<ceiling:
        a,b=pair;pair=(k+b-m.m.rho(b),k+a-m.m.R(a))
        assert max(pair)>maxima[-1]
        phases.append(pair);maxima.append(max(pair))
    return dict(maxima=maxima,phases=phases)
m.m.old.early_api.EarlyHybrid=PureEarly
m.m.old.late_api.hybrid_gate_curve=pure_late
start=time.process_time();rows=[];hist={};worst=[];bad=[];maximum=-100
for old in json.loads((P/'root-shifted-panel.json').read_text())['results']:
    w,n,k=old['w'],old['n'],old['k'];b=w//2;h=w*n//2;d=k-b
    J=min(e+ell+m.m.faster_middle(b,d,h,q,y,w%2) for q,y,e,ell in m.endpoints(b,d))
    r={**old,'hypothetical_J':J,'P_minus_J':old['P']-J,'hypothetical_lower':2*J+1,'hypothetical_gap':old['upper']-2*J-1}
    hist[str((w%2,r['P_minus_J']))]=hist.get(str((w%2,r['P_minus_J'])),0)+1
    if r['hypothetical_gap']<0:bad.append(r)
    if r['hypothetical_gap']>maximum:maximum=r['hypothetical_gap'];worst=[r]
    elif r['hypothetical_gap']==maximum:worst.append(r)
    rows.append(r)
out=dict(status='CONJECTURAL DIAGNOSTIC; these are not proved lower bounds',cases=len(rows),maximum_gap=maximum,histogram=hist,worst=worst,contradictions_to_retained_upper=bad,results=rows,CPU_seconds=time.process_time()-start)
(P/'root-pure-boundary-panel.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ('worst','results','contradictions_to_retained_upper')})
print('contradictions',bad[:3]);print('worst',worst[:5])

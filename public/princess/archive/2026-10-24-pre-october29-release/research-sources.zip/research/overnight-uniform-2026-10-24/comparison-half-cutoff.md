# A half-budget fast cutoff with four-room capped credit

24 October 2026. Proof candidate for independent review. All old accepted
sources are preserved; this note strengthens the necessary boundary clocks,
not an assertion of a new capture gap by itself.

For k>=100 set

    R=ceil(k/2)+6, L=R², D=k-R-1.

Then R<=floor(3k/5), D>0, and D<=r whenever r>=R+1.
Use the SAME hybrid recurrences, replacing their fast cutoff R by this value.
The new early injection cap G(L) and late cap L+k are smaller, so these are
stronger necessary-clock candidates. The scalar all-target physical +1
comparison at the previous cutoff applies automatically to the smaller caps.

## Four-room early credit is enough after capping

At an old-bad early transition let q be the target hole total,
r=ceil(sqrt(q)), and sigma>=r+5 its actual surplus. Thus

    q+sigma<=q_previous+k.

Suppose the carried reference has lead at least c, 0<=c<=D. Set
c'=min(D,c+4). Since c'<=D<=r, the inverse target z=q+c' satisfies

    z<=r²+r,
    ceil(sqrt(z))<=r+1,
    1+rho(z)<=r+1.

Thus EITHER phase's inverse target cost beta(z) is at most r+1. Consequently

    z+beta(z)<=q+c'+r+1<=q+c+r+5<=q_previous+k+c.

The same reference phase therefore gains four rooms capped at D. It is
unnecessary to estimate profiles on the larger interval [q,q+k]. That
uncapped interval was the source of the earlier three-room bound.

All virtual targets in the old subcritical range r<=b-5 still fit: k<2r
and q+k<=r²+k<(r+1)²< b(b-1). The concentration and exact phase-profile
proofs need only r>=20 and sigma<=b-1; here r>=57 for k>=100.

## Old changes of phase can be paid at the new cutoff

Retain the established early matching charge

    Delta*k >= (r²-11r-108)/2.

There are Delta-1 intervening bad transitions. Since r>=k/2+7 and the
quadratic is increasing there, use r>=k/2+7 and D<=k/2-7
SEPARATELY to obtain

    4(Delta-1)-D
      >= 2(r²-11r-108)/k-4-D
      >= 6-272/k >0.                              (1)

This pays the same backward reference rewind, before the later good event.
The rewind criterion itself is unchanged: q>L implies
G(q-1)<=q+D-1. No new reference phase or physical day is inserted.

For the old late matching charge

    Delta*k >= r²/2-6r-56,

the established four-room bad-step gain instead gives

    4(Delta-1)-D >=5-294/k>0.                     (2)

Thus both old slow-region inductions work with the single new cutoff.

## Near-pronic extension in the already displayed parameter range

Take b>=200, k=b+d, 1<=d<=19. The early near-pronic proof uses its local
credit C=d+6, rather than D, and counts bad/neutral transitions in the same
five short wall intervals. Lowering R does not alter that count. Its near
switch separation and target-rewind bound remain unchanged. Old switches
use (1). The old/near geometry still has r>=R+1>=107 and genuine quadrant
inverse targets, so no newly small root case appears.

For the late proof put C=d+5. Its old/near retreat argument and

    B_star=2C-1+ceil((D-C+1)/4)

are unchanged, but D<=k/2-7 now gives the sufficient estimate

    B_star<=(7C+D)/4<=b/8+15d/8+7.

The established near switch charge supplies B>=B_star whenever

    3b²-16bd-152b-15d²-64d-108>=0.                (3)

For b>=200 this expression decreases with d on1..19 and increases with b
at d=19. At (b,d)=(200,19) it equals22061. Hence (3) is uniform throughout
the stated range. The other near-proof conditions D>=C, b>d+10,
b>=2d+15 remain true there.

Entry, excursions, endpoint ranges, signed merger, and final scalar
continuation are the same as the reviewed pronic boundary proofs. The only
changes are the lower scalar cutoff and the stronger capped early bad gain.
If all these substitutions pass independent review, both boundary clocks
can be strengthened uniformly without adding a phase allowance or day.

## Why the cutoff is useful beyond a numerical improvement

The causal quadrant guard has form J_slow(R²)+2R<=w+2. Reducing R from
approximately0.6k to0.5k substantially widens the parameter range where an
ordinary zero-origin matching phase can replace a scalar fast injection.
That causal consequence needs its own timing and physical induction review;
(1)--(3) alone do not assert it.

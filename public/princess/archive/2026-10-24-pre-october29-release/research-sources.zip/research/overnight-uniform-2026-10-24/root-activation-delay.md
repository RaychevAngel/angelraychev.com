# Constant-budget activation delay and a matched-phase fast bound

24 October 2026. Proposed algebraic lemma for independent review.
This concerns independent quadrant processes; its use for a physical board
still requires a valid disjoint causal decomposition. It is not a new
unrestricted rectangle capture-time theorem.

Let f(z)=z-ceil(sqrt(z)), g(z)=z-rho(z), with both roots zero at zero.
Fix a constant daily quota k. Let

    P_0=(0,0), P_(t+1)=(g(P_t[1]+k),f(P_t[0]+k)).

Coordinates denote the CURRENT own/opposite relative corner color, not
persistent process identities. Every fixed-corner process alternates its
coordinate at every update. The same pair P_t supplies both possible
initial conventions, so a process starting from zero at a later day has
terminal bound P_j in its current coordinate after j updates.

Consider finitely many independent fixed-corner processes from zero with
total assigned daily quota at most k. At time t choose one distinguished
process of size x and current phase p; let all other sizes sum to y.
Last-zero trim every process as in the accepted concentration theorem.

Either an earliest permanently active process has the distinguished phase
convention, or it does not. In the first case the proof of that theorem
follows this convention and gives x+y<=P_t[p]. In the second case the
chosen distinguished process was zero at some day a>=1: it cannot have
activated earlier than the earliest other convention, and if simultaneous,
the distinguished convention can be chosen as earliest. Thus

    x<=P_(t-a)[p]<=P_(t-1)[p].                       (1)

Consequently, if the other terminal sizes obey y<=B and

    P_t[p]-P_(t-1)[p]>=B,                          (2)

then again x+y<=P_t[p]. This proves a matched-phase total bound, rather
than just the larger of the two ordinary coordinates. A sharper strict
comparison is available when the increment exceeds B.

The argument allows arbitrary assigned quota words inside the constant
TOTAL quota k. It does not hold with the same P_t shift for a varying total
quota. Same-phase outlier processes need no separate restriction in the
first case. The second case compares the distinguished process itself,
not a newly merged process with an earlier fictitious activation.

## An elementary sufficient increment guard

Let delta_t=|P_t[0]-P_t[1]|. The maps f,g are nondecreasing and1-Lipschitz,
and0<=g(z)-f(z)<=1. Hence delta_t<=delta_(t-1)+1 and delta_t<=t.
If ceil(sqrt(max(P_(t-1))+k))<=Rhat, then both coordinates satisfy

    P_t[p]-P_(t-1)[p]>=k-Rhat-(t-1).              (3)

Indeed the update swaps the old coordinate, changes it by k minus its
root cost, and the difference from the unswapped old coordinate is at
least minus delta_(t-1). Since rho<=ceil(sqrt), the same Rhat works in
both phases. Thus k-Rhat-t+1>=B suffices for(2).

For a finite fast segment one can instead check the exact two ordinary
increments at each time; this is an arithmetic guard, not a search over
inspection strategies. It fits the current recurrence-based bound goal.

## Intended physical use and outstanding conditions

In an actual corner decomposition with dominant surplus a and total surplus
s, the accepted outlier capacity gives B=(s-a)^2. The rigid equality cases
in lower-outlier-equality-rigidity.md have B=1. If the complete dependency
cones are disjoint and contained in the corresponding quadrants, the actual
inspections partition into independent processes without duplicating quota.
The lemma then supplies the matched dominant phase whenever(2) holds.

This does NOT establish the disjointness for arbitrary histories, nor does
it authorize replacing every capped MAX injection by its two ordinary
coordinates. A slow-history comparison may need stronger initial-state
claims. Those interfaces must be checked before any new rectangle bound.

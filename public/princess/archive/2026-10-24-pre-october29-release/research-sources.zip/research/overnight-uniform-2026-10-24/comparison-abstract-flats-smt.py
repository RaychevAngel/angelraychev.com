"""Flat-position encoding of the abstract balanced-map comparison."""
import z3,json,argparse,time
from pathlib import Path

def run(k,N,T,timeout=30000):
 s=z3.Solver();s.set(timeout=timeout)
 a=[z3.Int('a'+str(i))for i in range(k-1)]
 b=[z3.Int('b'+str(i))for i in range(k-1)]
 for i in range(k-1):
  s.add(1<=a[i],a[i]<=b[i],b[i]<=N+2*k)
  if i:s.add(b[i-1]<a[i])
 def f(x):return k+x-z3.Sum([z3.If(x>=z,1,0)for z in a])
 def g(x):return k+x-z3.Sum([z3.If(x>=z,1,0)for z in b])
 X=[(z3.Int(f'x{t}'),z3.Int(f'y{t}'))for t in range(T+2)]
 B=[(z3.Int(f'p{t}'),z3.Int(f'q{t}'))for t in range(T+1)]
 s.add(*[z==0 for z in X[0]+B[0]])
 for t in range(T+1):
  x,y=X[t];s.add(x>=0,y>=0,x<=N,y<=N)
  s.add(X[t+1][0]==g(y),X[t+1][1]==f(x))
  if t<T:
   p,q=B[t];s.add(p>=0,q>=0,p<=N,q<=N)
   c=g(q);d=f(p);s.add(B[t+1][0]==c,B[t+1][1]==z3.If(d>=c-1,d,c-1))
 s.add(z3.Or(B[T][0]>X[T+1][0],B[T][1]>X[T+1][1]))
 start=time.process_time();r=s.check();out=dict(k=k,N=N,T=T,status=str(r),cpu=time.process_time()-start)
 if r==z3.sat:
  m=s.model();out.update(a=[m.eval(z).as_long()for z in a],b=[m.eval(z).as_long()for z in b],X=[[m.eval(z).as_long()for z in p]for p in X],B=[[m.eval(z).as_long()for z in p]for p in B])
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('k',type=int);p.add_argument('N',type=int);p.add_argument('T',type=int);p.add_argument('--timeout',type=int,default=30000);a=p.parse_args();r=run(a.k,a.N,a.T,a.timeout);Path(__file__).with_name(f'comparison-abstract-flats-k{a.k}-t{a.T}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

# Retaining the final inspection: two-sided necessary capacity curves

24 October 2026. General cut lemma submitted for independent review.
The cut lemma is separate from the proposed shifted-gate implementation.

Let G be any finite undirected graph with N vertices, with simultaneous
inspections of at most k vertices per day and a mandatory edge move after
each unsuccessful inspection. Let B_t be the possible positions before
inspection t, after t unsuccessful inspection-and-movement updates, with
B_0=V. An empty possible-position set remains empty. Let ell(t) be ANY
proved lower bound on |B_t|, valid for every inspection history from full
uncertainty, and replace it by its nonincreasing lower envelope if necessary.

For every successful T-day inspection word, for each0<=s<=T-1,

    ell(s)+ell(T-1-s) <= N+k.                     (1)

Proof. At the vertex layer of inspection s, let F be the forward possible
positions after avoiding the first s inspections, and let R be the positions
from which one can avoid the final T-1-s inspections. Undirectedness makes R
exactly the full-start possible-position set for the reversed suffix word.
If a vertex in F intersect R were not inspected on day s, concatenate its
forward and backward avoiding walks to get a complete surviving walk. Thus
F intersect R is contained in S_s and has size at most k. Inclusion-exclusion
gives |F|+|R|<=N+k, and both cardinality lower bounds apply. Walks may repeat
vertices; no monotonicity, solo strategy, or shape normal form is assumed.

In particular, at the central layer:

    T=2t+1 requires 2ell(t)<=N+k;
    T=2t   requires ell(t-1)+ell(t)<=N+k.          (2)

These retain the final inspection quota. They are generally stronger than
using only the first crossing of the merged gate |B|<=N/2+k.

## Applying a family of first-crossing clocks

For an even-area rectangle put h=N/2 and m_t=|B_t|-h. Suppose J(c) is a
proved lower bound on the first update index with m_t<=c, for every chosen
nonnegative integer threshold c. Then t<J(c) implies m_t>=c+1, including
histories which later retreat. Therefore the computable curve

    r(t)=max({-h} union {c+1 : t<J(c)})

is a necessary signed-mass bound. It is automatically nonincreasing in t.
Equations(2) become

    odd2t+1 requires 2r(t)<=k;
    even2t requires r(t-1)+r(t)<=k.              (3)

The fallback -h is essential: signed mass may become negative, so an empty
set of threshold constraints must not be silently replaced by zero.
Every old lower bound is retained by taking the maximum.

A particularly simple consequence, c=floor(k/2), is

    T>=2J(floor(k/2)).                          (4)

Indeed all T<=2J(c)-1 have a central split with both indices<J(c), and
2(c+1)>k. This is a consequence about a proved gate clock, not a claim that
the existing hybrid clock has already been justified for this smaller gate.

## Proposed implementation; physical proof obligation remains separate

The necessary late hybrid currently starts from C_0=(k,k), with scalar seed
k, backward maps k+x-rho(x) and k+x-ceil(sqrt(x)), and scalar injection capped
at R^2+k. To target m<=c,0<=c<=k, use C_0=(c,c) and scalar seed c, leaving
the maps and cap unchanged. Early and middle crossings remain unchanged.

The proposed extension needs independent checking of the late physical
history proof, especially final scalar continuation through residual<=k.
For positive scalar survivor u, the same root inverse is exact. A residual
at most k can be cleared in one reference inspection, yielding0<=c; negative
actual signed mass already crosses the new gate. This suggests the existing
rewind and last-crossing argument extends without a new phase-reset charge,
but the cut lemma above does not itself prove that extension.

The numerical evaluator, if accepted, is a stronger LOWER bound only. No
claim of a new exact evaluator, uniform gap zero, or O(1) expression follows.

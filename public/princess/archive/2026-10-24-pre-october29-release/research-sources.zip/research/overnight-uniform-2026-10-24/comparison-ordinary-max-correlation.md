# Exact shared-history structure of the two ordinary-MAX hybrids

24 October 2026. Algebraic lemma proposed for independent review. No new
capture-time comparison is inferred from it.

Fix integer k>=1. Let F(x)=x+k-ceil(sqrt(x+k)), G(x)=x+k-rho(x+k),
H(x,y)=(G(y),F(x)), and ordinary P_t=H^t(0,0). On nonnegative integers
F,G are monotone and1-Lipschitz, and 0<=G(x)-F(x)<=1. Let M_t=max(P_t).
For a nonnegative integer cap B define the ordinary-MAX hybrid

    W^B_0=(0,0),
    W^B_(t+1)=max_coordinatewise(H(W^B_t),(min(B,M_(t+1)),same)).

## 1. One reset is enough to describe every extremal coordinate

Because scalar monotone maps preserve maximum on a totally ordered domain,
H preserves coordinatewise maximum. Consequently

    W^B_t = max_(0<=s<=t) H^(t-s)(min(B,M_s),min(B,M_s)).       (1)

This is an exact finite maximum representation. It does NOT say that one
common s attains both coordinates, or that these reset trajectories are
physical. Each individual reset trajectory exceeds the ordinary P_t in at
most one coordinate: at injection, at least one ordinary coordinate equals
M_s and is therefore not increased; H then alternates the two independent
coordinate descendants. The maximum over distinct reset times can combine
improvements in both coordinates.

## 2. The early and late cutoffs differ by at most one room per phase

Take any cap L>=0 and Z=G(L). Then, for every t,

    W^L_t <= W^Z_t <= W^L_t+(1,1),                          (2)

provided Z>=L (the relevant positive-progress boundary range). The first
inequality is monotonicity in the cap.

For the second, use induction. The ordinary branch preserves a coordinate
error of at most1 by1-Lipschitzness. It remains to dominate the larger
injection a=min(Z,M_(t+1)) by each coordinate of W^L_(t+1)+1. Put
m=min(L,M_t). By the smaller injection W^L_t>=(m,m), so its next ordinary
branch is at least(G(m),F(m)). If M_t<=L, ordinary monotonicity gives
M_(t+1)<=G(M_t)=G(m). If M_t>L, a<=Z=G(L)=G(m). In either case

    a <= G(m) <= F(m)+1.

Thus both coordinates dominate a-1, completing the induction.

For the accepted early ordinary-MAX clock E, L=R² and Z=G(L), so
E=W^Z. For the late clock with initial gate k, subtracting k conjugates
its map exactly to H and its cap to L; its ordinary pair is also P.
Therefore

    C_t-k <= E_t <= C_t-k+(1,1).                         (3)

This assertion is unconditional algebra for any cutoff satisfying Z>=L.
The geometrical admissibility of either necessary clock remains separate.
For a terminal gate c other than k, subtracting k changes the initial
seed; equation(3) must NOT be used without adapting that origin.

## 3. Sharpness and failure shields

Exact equality in(3) is false for arbitrary cutoffs: k201,R49,t15 gives
E=(2474,2474), C-k=(2474,2473). Each discrepancy is only one room by(3).

Nor do the new hybrids necessarily coalesce with the ordinary pair by the
near-pronic endpoint. With the accepted variable-slack choices:
- b251,d1,k252,R103,t2414: E=(62750,62750), P=(62750,62749).
- b201,d19,k220,R94,t678: E=(40193,40194), P=(40191,40193).
The literal values and further cases are saved in
comparison-ordinary-max-coupling-failures.json. In particular, reset debt
can survive at minimum budget and can occupy BOTH coordinates. A proof
that simply selects the better ordinary phase at each boundary would
silently discard this history-dependent debt.

## Remaining joint question

The two boundaries are not arbitrary seeds: they are evaluations of the
same shared-reset envelope at two nearby cardinality levels, up to(3).
But(1) also reveals why an immediate one-day joint-cost conclusion is
unjustified: the early extremal coordinate and late extremal coordinate
may use different injection times and opposite descendants. A useful
stronger invariant must retain those attaining reset times, or prove that
one of their apparent advantages is incompatible with the middle/terminal
phase choice. Neither assertion is established here.

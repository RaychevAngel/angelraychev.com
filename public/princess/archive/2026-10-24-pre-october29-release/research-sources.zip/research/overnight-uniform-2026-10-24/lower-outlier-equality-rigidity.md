# The only component mixtures with no surplus penalty

24 October 2026. A geometric/algebraic refinement for the boundary-history
problem, submitted for independent review. It does not itself prove ordinary
prefix optimality from the full board.

Consider a subcritical hole configuration with total dual surplus s<b.
Suppose its canonical two-step connected components have positive additive
surpluses, and one component is dominant with surplus a>s/2 at an actual
corner C. Put m=s-a. Assume m>=1, so at least one component lies outside the
dominant component. The accepted separator capacities give

    q_rest<=m²,
    q_dom<=a²                       in C's own color,
    q_dom<=a(a-1)                   in the opposite color.

The conclusions below use s>=5. These are precisely the large-root boundary
situations for which the dominant-component theorem is used.

## Own-color dominant component

For 1<=m<s/2,

    q<= (s-m)²+m² <= (s-1)²+1.                     (1)

The second expression is strictly decreasing in m on this integer range,
so equality requires m=1. If the total surplus equals the exact own-corner
profile s=ceil(sqrt(q)), the definition of that ceiling also gives
q>(s-1)². Consequently the ONLY possibility is

    q=(s-1)²+1, m=1, q_dom=(s-1)², q_rest=1.       (2)

The dominant component is the full own-color corner triangle of surplus
s-1, by equality in the quadrant profile. The remaining component is one
actual board corner: its cardinality and surplus are both1, hence its
neighborhood has two vertices. In every other mixed-component case,

    s>=ceil(sqrt(q))+1.                            (3)

## Opposite-color dominant component

Now

    q<= (s-m)(s-m-1)+m².

For real m in[1,(s-1)/2] this is convex, so its maximum lies at an endpoint.
At m=1 it equals(s-1)(s-2)+1. At m=(s-1)/2 it equals s(s-1)/2.
Their difference is (s-2)(s-3)/2>0. Hence on the permitted integer range

    q<=(s-1)(s-2)+1,                               (4)

and equality requires m=1. If s equals the exact opposite-corner profile
1+rho(q), then q>(s-2)(s-1). The ONLY possibility is therefore

    q=(s-1)(s-2)+1, m=1,
    q_dom=(s-1)(s-2), q_rest=1.                    (5)

Again the dominant component is the full opposite-color triangle of surplus
s-1 and the remaining component is one actual corner singleton. All other
component mixtures satisfy

    s>=1+rho(q)+1.                                (6)

The exact phase inequalities themselves are the accepted dominant-component
bounds. This note identifies when their one-unit strengthening can fail.

## A causal separation observation for the exceptional configurations

In(2) the dominant triangle has corner radius2s-4; in(5) it has radius2s-5.
The singleton is a DIFFERENT actual corner. If both have existed as target
holes at elapsed time t and

    2s-4+2t < w-1,                                (7)

their full backward dependence cones are disjoint: the distance between
any distinct actual board corners is at least w-1. Each cone also stays
inside its own actual quadrant when its radius plus t is at most w-1.
Thus the actual inspections can be split between two independent quadrant
histories without duplicated daily quota. Their total is controlled by the
accepted independent-corner MAX theorem.

Condition(7) does NOT automatically give the dominant-phase bound. That
stronger algebraic assertion is currently unproved for constant quotas and
is false for arbitrary quota words. For example the quota word[6,0,9] has
ordinary pair(8,6), while an independent allocation reaches pair(1,6), whose
sum7 exceeds the coordinate6 matching the larger terminal component. The
MAX theorem is unaffected.

## Use and remaining obligation

Normally, component outliers force extra surplus, so they supply room credit
rather than a new free phase. Only the two exact endpoint configurations
above evade that penalty. Their very rigid two-corner geometry may permit a
causal or allocation argument to remove the fast-boundary phase allowance.
That assembly, the constant-quota dominant-phase conjecture, and exact full-
board capture time remain open. No new formalization coverage is claimed.

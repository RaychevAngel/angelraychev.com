# Signed boundary credit: current obstacles and exact reductions

24 October 2026, 09:26 UTC. Research status, not a uniform new theorem.

The shifted-pronic middle+2 theorem is accepted. Attempts to replace it by
+1 using successively stronger but incomplete interfaces fail:

1. Arbitrary progressive endpoints fail already at b200,d1, and the full
   accepted BAND9 clock does not remove the failure.
2. Requiring the correct local common quadrant orbit, with zero dual error,
   still allows that failure. Its exact tied fast-reset origin is impossible.
3. Actual zero-origin hybrid endpoints still fail isolated middle+1: b203,d1,
   Q=H,Y=H+2, e1867,ell1665,tau1825, C=(H+2,H+1),A=(H,H-1).
   Both physical matched sums after tau+1 equal h-1. The actual shifted
   physical boundary pairs have spare rooms and the complete prefix clock
   satisfies P-J=3, so this does not obstruct a sharper total comparison.
4. Replacing coordinatewise one-day boundary domination by domination of the
   hybrid target in both phases is false. At b208,d2 the physical early
   shifted pair is (H+1,H-1) and the late shifted pair is(H+3,H+1), missing
   their respective targets H andH+2 in one coordinate.
5. A positive scalar total spare-credit assumption is also false. At b224,d1
   both shifted physical pairs equal their hybrid pairs exactly. Their phases
   are complementary in the adverse way on even-width/even-length boards.
   Full BAND9 has P-J=4 there, including the long-board instance448x1344.

These are failure shields against proving unnecessarily strong interfaces.
The actual currently plausible target remains a total P<=J+4 inequality,
possibly improved constructively by a central phase-changing transport.

## Exact physical duality

For the zero-origin quadrant histories, not merely within one room,

    V_t=A_t+k

coordinatewise, where A_0=(0,0), V_0=(k,k), and A follows
Hf(x,y)=(G(y),F(x)). This follows by substituting V=A+k in its backward
update. The accepted hybrid pair differs from this exact conjugacy by at most
one room in one coordinate. Thus the two actual shifted physical boundary
pairs lie on the same exact orbit; independent endpoint maximization discards
real information.

## The middle has one relevant square wall

For odd width above the pronic seed, the lower physical scalar maps are
G(u)=u+d and F(u)=u+d-1_(u>b^2). A descendant starting at C_i has
constant drift d until the first F-update whose input exceeds b^2. If that
update is j_i, then at a later time t it has position

    C_i+d*t - max(0,1+floor((t-j_i)/2)).

The allowed parity of j_i is fixed by the initial coordinate. It is the
smallest such parity index with C_i+d*(j_i-1)>b^2. A two-step initial
transient handles C_i<=H. This is an exact one-wall transfer formula;
no growing root-bin search is hidden in it.

Consequently a sufficient total signed-credit condition can be expressed
using the two phase crossing indices and the early pair. The hard remaining
step is establishing which crossing-index/credit combinations can occur
simultaneously from the actual scalar-fast hybrid and zero physical origins.
The isolated middle arithmetic itself is now finite and explicit.

## A monotonicity fact for a future history invariant

Each quadrant scalar map F,G is nondecreasing and1-Lipschitz. Therefore for
any coordinatewise increasing orbit X_t=Hf^t(X_0), its increments satisfy

    deltaX_0(t+1)<=deltaX_1(t),
    deltaX_1(t+1)<=deltaX_0(t).

Thus the two checkerboard increment streams are nonincreasing and the sum
of the two increments is nonincreasing. This is stronger than an unsigned
spread estimate, but it has not yet been combined with the fast-reset gap
into a sufficient boundary credit theorem. It does not, by itself, justify
replacing the actual zero origin by arbitrary progressive local states.

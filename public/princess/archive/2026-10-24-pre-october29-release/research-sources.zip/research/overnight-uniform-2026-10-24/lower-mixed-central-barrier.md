# A permanent mixed central barrier and an exact minimum-budget consequence

24 October 2026. Ordinary physical theorem proposed for independent review.
The result concerns every even-area rectangle and every actual normalized
full-board history. It does not presume optimality of an anchored prefix.

Let w<=n, wn even, b=floor(w/2)>=2, h=wn/2, and k=b+d with d>=1.
Use the exact last-full normalized history from
`lower-last-full-mixed-penalty.md`. Its activation day a has full larger
pre-inspection cohort X_a, and every larger survivor from a onward is proper.
All pre-activation work is a genuine solo strategy on the smaller cohort.

Put

    A=(b-1)^2,   C=h-b(b-1)-2.

## 1. The strict mixed central surplus

For any actual pair of proper survivors with positive signed mass

    q=|P_0|+|P_1|-h,

if A<=q<C then their total surplus sigma satisfies

    sigma>=b+1.                                      (1)

Proof. Suppose sigma<=b. Both survivors are nonempty, since q>0 and
each color class has h rooms. Each individual surplus is a nonnegative
integer. An individual zero surplus, by the accepted subcritical separator
dichotomy, forces that survivor to be either empty or full. Both alternatives
are excluded. Thus the individual surpluses s_0,s_1 are positive and at most
b-1, so the separator dichotomy applies separately to each.

If both are small, their total size is at most
(b-1)^2+1<h, contradicting q>0. If exactly one is small, the other has at
least one hole, and hence

    q<=(b-1)^2-1=A-1.

If both are co-small, their total hole count is at most

    s_0(s_0+1)+s_1(s_1+1)<=b(b-1)+2,

where the largest sum at fixed positive s_0+s_1<=b is attained at1,b-1.
Consequently q>=h-b(b-1)-2=C. Every case contradicts A<=q<C.

This proof is valid at sigma=b although the original one-cohort separator
requires strict surplus below b: the positive proper-partner condition makes
each INDIVIDUAL surplus strictly smaller than b.

## 2. One potential handles all lengths, budgets, and retreats

Put M=A+k and define the clipped nonnegative potential

    Psi_k(m)=max(0, min(m,C)-M+1).                    (2)

For every transition in the permanently mixed suffix, with signed belief
m before inspection and m' after movement,

    Psi_k(m)-Psi_k(m') <= d-1.                       (3)

Proof. Only a positive decrease needs consideration. It forces m>=M and
m'<C. If p<=k useful rooms were inspected in total, the survivor mass
q=m-p obeys q>=m-k>=A. Nonnegative surplus gives q<=m'<C. Thus (1)
applies, and

    m'=m-p+sigma>=m-k+(b+1)=m-(d-1).

The map in (2) is nondecreasing and1-Lipschitz, which proves (3).
There is no monotonicity assumption on m or on the actual shapes.

The potential has height

    max(0,C-M+1)=max(0,h-2b^2+2b-2-d).

For d>=2, if the mixed suffix starts at mass m_a and subsequently reaches
a belief with signed mass at most k, at least

    ceil(Psi_k(m_a)/(d-1))

unsuccessful updates are required between these events. This is a uniform
history-conditioned passage bound, not a numerical certification of widths.

## 3. Minimum budget forces the entire central passage to remain solo

Let d=1, so k=b+1. Here

    C-M+1=h-2b^2+2b-3>=2b-3>0.

Equation (3) says Psi_k cannot decrease anywhere in the permanently mixed
suffix. A winning history eventually has signed belief at most k: immediately
before a final inspection its total belief has size at most k, and hence its
signed mass is at most k-h<=k. Since Psi_k is zero there, it must be zero at
activation. The positive height implies m_a<M, or exactly

    m_a<=b^2-b+1.                                   (4)

At activation X_a is full, so m_a=|Y_a|. Therefore EVERY full-board strategy
can be normalized, without changing its quota word or capture time, so that
at minimum budget it does not start useful work on the larger cohort until
the smaller cohort has at most b^2-b+1 possible rooms.

The complete passage down to this threshold is a SOLO physical strategy.
It may use the adaptive corner transport construction. This is not the
false assertion that a fixed-corner prefix is always optimal.

## 4. Exact solo-clock implication

Let tau_p be the unrestricted optimal solo capture time from the full color
class of phase p. Let A_p(z) be the minimum number of unsuccessful updates
in any solo strategy from that full class which reaches a belief of size at
most z. These definitions permit every physical shape and are not claims of
closed-form evaluation.

For the actual normalized activation day a, its smaller cohort reaches size
m_a in a updates, while the larger cohort is still full. Thus

    a>=A_(initial smaller phase)(m_a),
    T-a>=tau_(larger phase at day a).

Together with (4), this gives the necessary bound obtained by minimizing
the sum over the actual initial choice and activation parity, with
m_a<=b^2-b+1. One must retain the activation parity; replacing the two terms
by independently chosen phase minima can weaken the result but cannot make
it stronger. This is a genuine relation to UNRESTRICTED solo clocks.

For d>=2, the same activation relation and the potential cost (3) coexist.
Combining them into an exact full capture-time formula remains open.

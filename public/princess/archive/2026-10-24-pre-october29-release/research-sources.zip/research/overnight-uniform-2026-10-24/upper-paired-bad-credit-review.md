# Independent review of paired bad credit

24 October 2026. Reviewer: `uniform_upper`.

**Accepted as an arithmetic lemma.** This review does not accept the proposed
physical nearcritical application without its separately listed interfaces.
The reviewed source hash and finite audit are in
`upper-paired-bad-credit-review.json`.

The two inverse thresholds are exact for positive targets. At a running step,
the previous credit is an integer `0 <= c < C`. The estimates
`R(q+c) <= r+1` and `rho(q+c) <= r` follow from `r >= C` and
`q <= r²`. Thus the weak input inequality preserves credit in either phase.
The strong inequality increases it in either phase; a weak G step increases
it unless `q+c+1 > r²`. These statements do not require monotonicity of q.

There is a useful sharpening of the source's failure count. If a G step
fails to increase credit, preservation and integrality give **exactly**
`c' = c`. Therefore its output is `X' = q+c`, and failure implies

    r² <= X' <= r²+C-1.

Successive G outputs are separated by at least `2v`, including when the
target leaves and returns to a root bin. The C integer positions in this
interval permit at most

    floor((C-1)/(2v))+1 = ceil(C/(2v))

failures for that root. Consequently the stronger duration is

    2(C + m ceil(C/(2v))).

There are exactly `C + m ceil(C/(2v))` G steps in this even-length block,
regardless of its initial phase. All but at most the displayed failure
budget gain at least one room. Hence C units of credit have accumulated,
contradicting a still-running comparison. This also handles arbitrary
initial nonnegative credit; positive initial credit only helps.

The independent bounded audit verifies 1,491,776 local cases, including
77,792 failed G cases, with separately evaluated integer square/pronic
roots. It is supplementary evidence, not a substitute for the argument.
For the proposed `d=1..19, C=d+5, v=d, m=5` application, the sharpened
duration is at most 58 steps (42 at d=1). This finite arithmetic does not
verify the physical drift, rewind cost, root-window membership, or joining.

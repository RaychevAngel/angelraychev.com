"""Finite literal-graph audit of the uniform alternating-polarization proof.

This is a diagnostic of theorem interfaces, not its all-rectangle proof.
Only small complete subset spaces are used; no capture-time width panel.
"""
from pathlib import Path
import hashlib
import json
import time


def audit(w,n):
    assert w%2==0
    size=w*n
    cells=[(x,y) for x in range(w) for y in range(n)]
    index={z:i for i,z in enumerate(cells)}
    adj=[]
    reflect=[]
    colors=[0,0]
    for i,(x,y) in enumerate(cells):
        colors[(x+y)%2]|=1<<i
        reflect.append(index[w-1-x,y])
        adj.append(sum(1<<index[z] for z in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if z in index))
    count=1<<size
    neighborhoods=[0]*count
    reflections=[0]*count
    cardinalities=[0]*count
    for a in range(1,count):
        bit=a&-a; i=bit.bit_length()-1; old=a^bit
        neighborhoods[a]=neighborhoods[old]|adj[i]
        reflections[a]=reflections[old]|(1<<reflect[i])
        cardinalities[a]=cardinalities[old]+1
    def C(a,p):
        A=a&colors[p];B=a&colors[1-p]
        return A|reflections[B]|(B&reflections[A])
    normalized=[[],[]]
    inclusion_checks=0
    for a in range(count):
        for p in (0,1):
            ca=C(a,p)
            assert cardinalities[ca]==cardinalities[a]
            assert C(ca,p)==ca
            assert neighborhoods[ca]&~C(neighborhoods[a],1-p)==0
            if ca==a:
                normalized[p].append(a)
                assert C(neighborhoods[a],1-p)==neighborhoods[a]
            # Complete one-element inclusions imply all monotonicity.
            missing=(count-1)^a
            while missing:
                bit=missing&-missing;missing^=bit
                assert ca&~C(a|bit,p)==0
                inclusion_checks+=1

    # Quotient indexed geometrically on the half-rectangle, rather than
    # obtained by blindly folding the already computed adjacency.
    small=[(x,y) for x in range(w//2) for y in range(n)]
    si={z:i for i,z in enumerate(small)}
    kadj=[]
    for x,y in small:
        zs=[z for z in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if z in si]
        if x==w//2-1:zs.append((x,y))
        kadj.append(sum(1<<si[z] for z in zs))
    reps=[[],[]]
    for p in (0,1):
        for x,y in small:
            reps[p].append(index[(x,y) if (x+y)%2==p else (w-1-x,y)])
    def lift(mask,p):
        ans=0
        while mask:
            bit=mask&-mask;mask^=bit
            ans|=1<<reps[p][bit.bit_length()-1]
        return ans
    def K(mask):
        ans=0
        while mask:
            bit=mask&-mask;mask^=bit
            ans|=kadj[bit.bit_length()-1]
        return ans
    folded_checks=0
    h=len(small)
    for x in range(1<<h):
        for p in (0,1):
            assert neighborhoods[lift(x,p)]==lift(K(x),1-p)
            folded_checks+=1
        y=x
        while True:
            for p in (0,1):
                state=lift(x,p)|lift(y,1-p)
                assert C(state,p)==state
                assert neighborhoods[state]==lift(K(x),1-p)|lift(K(y),p)
                folded_checks+=1
            if not y:break
            y=(y-1)&x
    return dict(w=w,n=n,subsets=count,one_vertex_inclusions=inclusion_checks,
                normalized_counts=list(map(len,normalized)),
                predicted_normalized=3**h,folded_checks=folded_checks)


if __name__=='__main__':
    started=time.process_time()
    rows=[audit(*z) for z in [(2,4),(2,6),(4,3),(4,4)]]
    source=Path(__file__).with_name('lower-alternating-polarization.md')
    result=dict(status='PASS',scope=__doc__,rows=rows,
                CPU_seconds=time.process_time()-started,
                proof_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

# Last-full normalization and a permanent mixed-suffix penalty

24 October 2026. Ordinary physical lemmas proposed for independent review.
No prefix-optimality, seriality, new capture-time formula, or Lean claim.

## 1. Exact temporal normalization

Use the exact folded game of `lower-alternating-polarization.md`. Its
beliefs before day t are X_t,Y_t with Y_t subset X_t, and survivors are
R_t,S_t with S_t subset R_t. Their next beliefs are K(R_t),K(S_t).
Write V for the folded vertex set. The full-board start is (V,V), and
K(V)=V. Days are t=0,...,T-1, with both terminal survivors empty.

Let a be the LAST pre-inspection day with X_a=V. Replace all earlier
larger-cohort survivors R_t, t<a, by V, leaving every smaller-cohort
inspection and every action from day a onward unchanged. Before a the
new beliefs in the larger cohort are V. Nesting is preserved, and the
new useful inspection cost is at most the old cost. The smaller cohort
evolves exactly as before. At day a both beliefs agree with the original
ones, so the entire subsequent history agrees as well.

Consequently every full-board winning strategy can be replaced, without
increasing any daily budget or its capture time, by one with:

* X_t=R_t=V for all t<a;
* X_a=V but R_a is proper;
* X_t and R_t are proper for all t>a.

For the second assertion, if R_a=V then X_(a+1)=V, contradicting the
definition of a. If a=T-1, terminal capture instead gives R_a empty.
The third follows directly from the last-full definition.

Thus useful work on the larger cohort begins only once, and its support
never returns to full thereafter. This does NOT say that the two cohorts
are processed serially. Their active periods can overlap, and the smaller
cohort can have an arbitrary moving geometric front.

## 2. A static penalty when the larger survivor is proper

Let w<=n, wn even, b=floor(w/2), h=wn/2. Consider actual survivor sets
P_0,P_1 of the two checkerboard colors. Put

    q=|P_0|+|P_1|-h,    sigma=sum_i (|N(P_i)|-|P_i|).

Assume

    1<=q<=(b-1)^2,

and neither survivor is full. Then

    sigma >= min(b, 1+ceil(sqrt(q+1))).                 (1)

In particular, writing r=ceil(sqrt(q))<=b-1, sigma>=r+1.
When q=r^2 and r<=b-2, the stronger sigma>=r+2 holds.

Proof. If sigma>=b there is nothing to prove. Otherwise apply the accepted
subcritical separator dichotomy separately to the two survivors. Their
individual surpluses are nonnegative integers. They cannot both be small:
their total size would be at most sigma^2<h, contrary to q>0. They cannot
both be co-small, because their total hole count is at most sigma(sigma+1),
and hence

    q>=h-sigma(sigma+1)>=2b^2-b(b-1)=b^2+b>(b-1)^2.

Exactly one survivor P is small. The other has a positive hole count D,
since neither survivor is full. If its surplus is z, then z>=1: the
co-small profile gives D<=z(z+1). The small survivor has surplus
sigma-z and size at most (sigma-z)^2. Therefore

    q=|P|-D <= (sigma-1)^2-1,

which proves (1) by taking the integer square root.

The proof uses only the established ordinary small/co-small capacities;
no canonical component, corner occupation, or shape assumption is needed.
It therefore includes the roots r=1,2,3 omitted from the stronger
nearcritical localization statement.

## 3. Retaining the actual second-cohort deficit

In the same subcritical case sigma<b, if D is the actual positive number
of holes in the co-small survivor, the argument gives the sharper bound

    sigma >= ceil(sqrt(q+D)) + rho(D),                  (2)

where rho(D) is the smallest nonnegative integer z with D<=z(z+1).
The two summands are lower bounds on the small and co-small surpluses,
respectively. Equivalently, without assuming sigma<b in advance,

    sigma >= min(b, ceil(sqrt(q+D))+rho(D))

whenever D denotes the co-small deficit guaranteed in the subcritical
branch. The latter is a branch statement, not an instruction to assign
an arbitrary D to a synthetic merged state.

In the polarized game the small survivor, when q>0 and sigma<b, must
be the permanently smaller cohort; the other survivor is the permanently
larger one. In folded coordinates, write its holes as Dset=V\R and the
small survivor as S. Nesting gives S intersect Dset empty, and

    q=|S|-|Dset|.

This spatial disjointness is genuine additional information. Bounds (1)
and (2) do not yet exploit it beyond identifying the positive deficit.

## 4. Consequence along the complete normalized history

Apply Section1. For every day t>=a whose positive post-inspection signed
mass satisfies q_t<=(b-1)^2, the larger survivor R_t is proper. Nesting
forces S_t proper too. Therefore (1) applies at EVERY such day, regardless
of retreats, changing corner, or the time spent outside this mass range.

By contrast, the pre-activation segment has a completely full partner and
is a genuine solo strategy in the smaller cohort. It may be the retained
moving-front transport strategy, and need not be a fixed-corner prefix.

This yields a necessary two-mode history structure: a full-partner solo
prefix, followed by a permanently mixed suffix with the stronger signed
surplus profile. The mode changes at most once. A lower evaluator may
relax each mode and optimize over its switch time, but must not permit
the mixed mode to revert to the full-partner cheap profile.

This is a necessary restriction, not yet a quantitative bound on the
overlap duration or a proof that a selected construction is optimal.

## 5. Existing results used

The exact temporal normalization uses `lower-alternating-polarization.md`.
The small/co-small capacities and nonnegative integer surpluses are those
of `../resumed-even-corner-profile.md` and
`../uniform-history-2026-10-23/physical-dominant-corner.md`.
The stronger localization at zero slack remains in
`lower-nearcritical-late-events.md`; the simpler full-partner conclusion
here does not replace its geometric or matching-charge conclusions.

"""Attack one-day pronic middle comparison retaining common E/C origin.
Inputs are a local relaxation, not necessarily actual zero-origin hybrids.
"""
from pathlib import Path
from importlib.util import spec_from_file_location,module_from_spec
import json
P=Path(__file__).with_name('comparison-shifted-pronic-small.py');s=spec_from_file_location('small',P);S=module_from_spec(s);s.loader.exec_module(S)
def run(b,d,extra=0):
 H=b*(b-1);k=b+d;h=2*b*b+3*b+1+extra;qmin=H-d+1;qmax=H;ymin=H-d+2;ymax=H+2
 worst=10**9;witness=None;checks=0
 for high in range(ymin,ymax+d+2):
  for spread in range(d+2):
   for C in set(((high,high-spread),(high-spread,high))):
    if not all(a>=z for a,z in zip(S.low_step(b,d,C),C)):continue
    for error in ((0,0),(1,0),(0,1)):
     E=tuple(c-k+z for c,z in zip(C,error));steps=0
     if not all(a>=z for a,z in zip(S.hole_step(k,E),E)):continue
     while max(E)<qmin:E=S.hole_step(k,E);steps+=1
     for eextra in range(2):
      if eextra:E=S.hole_step(k,E)
      Y=min(ymax,max(C));Q=min(qmax,max(E));tau=S.equal_clock(b,d,Y,h-Q);X=S.iterate(b,d,C,tau+1)
      margins=[X[p]+E[1-p]-h for p in(0,1)];margin=max(margins);checks+=1
      if margin<worst:worst=margin;witness=dict(C=[z-H for z in C],error=error,E=[z-H for z in E],steps=steps+eextra,Y=Y-H,Q=Q-H,tau=tau,margins=margins)
 return dict(b=b,d=d,extra=extra,checks=checks,worst=worst,witness=witness)
if __name__=='__main__':
 rows=[run(b,d,e)for d in(1,2,3)for b in range(200,200+2*d)for e in range(2*d-1)]
 out=dict(status='LOCAL_COMMON_ORBIT_ATTACK_NOT_UNIFORM_PROOF',rows=rows,worst=min(r['worst']for r in rows),checks=sum(r['checks']for r in rows));Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items()if k!='rows'});print([r for r in rows if r['worst']<0][:3])

# Early hybrid necessity through the last pronic quadrant level

24 October 2026. Proof candidate submitted for independent review. No
capture-gap consequence is asserted until the boundary and middle contracts
are assembled. All older sources remain unchanged.

Let wn be even, w<=n, b=floor(w/2)>=160, k=b+d, 1<=d<=19, and put

    H=b(b-1), A=(b-1)^2, R=floor(3k/5), L=R^2,
    C=d+6, D=k-R-1.

Use exactly the earlier necessary early hybrid E, its scalar injection
through Z=G(L), and e(Q)=min{t:max(E_t)>=Q}, as defined in
`../joint-history-2026-10-24/lower-hybrid-necessary-clock.md`.

**Claim.** If an actual full-start hole history is stopped at time tau,
all its hole totals through tau are at most H, and its endpoint is Q_tau,
then e(Q_tau)<=tau. In particular at the first crossing of

    H'=H-d+1

the actual endpoint lies in [H',H], and the claim applies. There is no
additional phase reset or forward reference-day allowance.

The reference is a single alternating F,G orbit after its last fast
injection, with paid backward rewinds or omission of a forward reference
move. It may harmlessly be capped at H: reaching H settles the claim for
every remaining endpoint. All inverse threshold tests below are <=H,
where they are genuine physical quadrant tests in either board parity.

## 1. The piecewise event convention

As in the earlier proof, start immediately after the last actual total
Q<=L before tau. The scalar injection allows either reference phase at
this entry, at an index no larger than its actual time. If there is no
such slow interval the scalar comparison already proves the claim.

For targets Q>L with r=ceil(sqrt(Q))<=b-1, use:

* old good if r<=b-5 and actual total dual-hole surplus sigma<=r+4;
* near good if b-4<=r<=b-1 and sigma<=r.

Old good events have at most25 outlying holes; near good events at most1.
Both have a unique actual dominant cohort/corner, total surplus<b, and
the exact square/pronic capacity in that dominant phase. These are the
accepted old geometry and `lower-nearcritical-good-events.md`.

At Q>A, up to H, sigma>=b. Indeed sigma<b would exclude the co-small
branch, since h-Q>=2b^2-H=b^2+b>sigma(sigma+1), and force
Q<=sigma^2<=A. Call these upper events neutral. Both target quadrant
surpluses at every Q<=H are at most b. Thus a neutral transition preserves
reference domination in either carried phase, with no corner choice.

Choose the entry phase to fit the first good event. Before it, bad and
neutral transitions preserve domination. Later changes of good-event
phase are handled below. Changes of identity preserving the phase need
no adjustment.

## 2. Credit over mixed bad and neutral blocks

Consider a block between consecutive good events, containing no good
event internally. Until its reference reaches A+C, all neutral targets
have Q<A+C. For a carried lead c<=C, the inverse tests at Q+c are still
at most H, because A+2C<=H at the stated parameters. Their surplus is
at most b. Neutral transitions therefore preserve c.

For subcritical bad targets, r>=R+1>C. Old bad surplus is at least r+5;
near bad surplus is at least r+1. The paired-credit lemma proves that
lead is preserved, and a G move earns a room except possibly in the
last C reference values at a square wall of a near root. There are only
four such roots, b-4,...,b-1. Old bad moves supply the stronger input
inequality and do not cause these failures.

While the reference is below A+C, every reference move advances at least
d: its input plus k is at most A+C-1+k<=b^2. Thus distinct G outputs
are separated by at least2d. Each near root can cause at most
ceil(C/(2d)) failed G gains. A neutral failed G output lies in
[A+1,A+C-1], contributing at most the same count once more. This is one
interval for the entire block, irrespective of repeated excursions.

Consequently after

    B=2(C+5 ceil(C/(2d)))                         (1)

interior transitions, either the reference has reached A+C or its lead
has reached C. Once the latter occurs it is preserved by subsequent bad
and neutral transitions until A+C is reached. This argument does not
assume monotone physical hole totals. Capped credit C is justified by the
same inverse tests (r>C), not by an assumption of exact equality of leads.

## 3. Paying every change of phase

First suppose the new good event has root r>=b-5. The ordinary matching
charge, using the conservative25 outliers at each endpoint, gives

    Delta*k >= (r^2-11r-108)/2
             >= (b^2-21b-28)/2.                 (2)

For b>=160 and 1<=d<=19, (2) implies Delta-1>=B. This reduces to19
integer inequalities at b=160: the ratio on the right of(2), divided by
k=b+d, increases with b, and B depends only on d. The accompanying
arithmetic check records all19 values. No rectangle-length sample is used.

If the reference reached A+C during the intervening block, its current
value before the new good event already exceeds its target Q<=A. Keeping
the current reference index or advancing it once supplies either phase
by the new actual time. No new orbit or forward-day penalty is introduced.

Otherwise its lead before the new good transition is at least C. Even
in the wrong phase, this transition leaves at least C-1 rooms of lead:
at z=Q+C-1 both inverse target surpluses are at most r+1, whereas the
actual surplus is at least r. Thus z+beta(z)<=Q+r+C<=Q_previous+k+C.
The exact target rewind cost obeys

    D(Q)=k-rho(Q-1+k)<=d+5=C-1                  (3)

because Q>(b-6)^2. The previously accepted target-rewind lemma therefore
allows one backward reference move, switching to the required phase while
still dominating Q. Its index is at most the new actual time.

Next suppose the new good event has root r<=b-6. If the preceding good
event or any intervening target had root at least b-4, the monotone
reference already reached at least (b-5)^2+1. This exceeds the new target
Q<=(b-6)^2 before its transition. Keeping or advancing the existing index
again supplies either phase without a penalty. This includes every upper
neutral excursion.

If no such high target occurred, the entire intervening block is old
bad. The original three-rooms-per-move argument, geometric charge, global
rewind cost D, and k>=100 arithmetic apply without change. The previous
good event is also an old good event in this case. This pays the change
exactly as in the accepted early hybrid proof.

These cases cover every consecutive pair of good events. After the last
good event, bad and neutral transitions preserve domination to tau.
All reference index modifications decrease the index or omit an advance.
Every forward move is an ordinary alternating term permitted by E; the
initial injection is the original one. Coordinatewise time monotonicity
of E therefore gives max(E_tau)>=Q_tau, as claimed.

## 4. Endpoint guard and deliberate limitation

At the first crossing of H'=H-d+1, the common scalar bound gives

    Q_tau<=G(H'-1)=H,

since H'-1+k=H+b=b^2 and rho(b^2)=b. Thus the complete history lies in
the proved range. At the unshifted H cut the endpoint may exceed H by
d-1. On odd-width boards one quadrant phase can then require surplus
b+1 while the scalar argument only supplies b. This proof deliberately
uses the shifted cut; it does not silently erase that endpoint issue.

## Review obligations

Check the capped-reference interpretation, the extra neutral failure
interval, wrong-phase loss of one room, old/new interfaces under arbitrary
retreats, and the19 arithmetic inequalities. Combining this early clock
with the late extension and a shifted-cut middle comparison remains a
separate assembly obligation.

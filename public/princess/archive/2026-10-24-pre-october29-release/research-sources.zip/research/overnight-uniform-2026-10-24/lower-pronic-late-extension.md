# Extending the necessary late hybrid clock to the pronic boundary

24 October 2026. Ordinary physical theorem submitted for independent
review. No claim of an improved full capture bound is made here.

Let w<=n have even area, b=floor(w/2), h=wn/2, and

    b>=160, k=b+d, 1<=d<=19,
    R=floor(3k/5), A=R^2+k,
    Y_top=b(b-1)+d+1.

For every k<Y<=Y_top, the SAME late hybrid clock C and h_k(Y) defined in
`../joint-history-2026-10-24/physical-hybrid-necessary-clock.md` is a
necessary clock: an actual two-cohort history starting with m_s>=Y and
first reaching m_g<=k satisfies

    g-s >= h_k(Y).

The evaluator and its one fast-region relaxation are unchanged. There
is no additional independent phase reset at the old boundary.

## 1. Quantities and genuine prefix range

Use the accepted signed-survivor quantities

    q=m-p>0, p<=k, sigma=sum_i(|N(S_i)|-|S_i|),
    m_next=q+sigma, r=ceil(sqrt(q)).

After the last crossing into m<=Y, every reference residual X<=m has
survivor u=X-k<=Y_top-k=(b-1)^2. Thus both reference phases have genuine
quadrant profiles

    beta0(u)=ceil(sqrt(u)), beta1(u)=1+rho(u),
    phi_j(X)=X-k+beta_j(X-k).

They strictly decrease while X>k, because beta_j(u)<=b<k. The reference
is one fixed alternating prefix trajectory, with occasional rewinds of
its already used index. A rewind is never a new physical move.

It suffices to extend the slow-history comparison until its first entry
into m<=A. Throughout the slow portion m>A, so the reference rewind
criterion uses

    D=k-R-1: a lead m-X>=D permits one preceding reference step.

Indeed phi0(m)>=m-D, and the accepted strict-monotonicity argument applies.
If the reference has already reached the gate, the desired comparison is
complete and no further rewind is needed.

## 2. A piecewise good definition, with no change of reference orbit

For a slow actual transition call it old-good if

    r<=b-5 and sigma<=r+4,

and near-good if

    b-4<=r<=b-1 and sigma<=r.

All remaining slow transitions are bad. The established C=4 concentration
argument applies to old-good transitions: at most25 outlying cells,
an actual dominant corner/cohort, and the exact square/pronic phase
profile for total signed q. The new zero-slack result
`lower-nearcritical-late-events.md` applies to near-good transitions:
an exactly full partner, at mostone outlier, and the same exact phase
profile. Both kinds therefore preserve reference domination in their
actual convention.

If r>=b, then sigma>=b. To see this, if sigma<b both physical survivors
are in small/co-small separator branches. Both small contradict q>0;
both co-small give q>=h-b(b-1)>b^2, whereas q<=m<=Y_top<b^2. One of each
gives q<=sigma^2<=(b-1)^2, contradicting r>=b. Thus these critical
transitions belong to the bad class without requiring a false
subcritical localization claim.

## 3. Bad transitions preserve lead; old ones earn four

Let E=m-X>=0 be the current lead, u=X-k, so q>=u+E. An old-region bad
transition has r<=b-5 and sigma>=r+5. Both beta_j(u)<=r+1, hence the
new lead is at least E+4.

A near-region bad transition with r<=b-1 has sigma>=r+1. It preserves
lead in either phase; the beta0 phase earns at leastone. When r>=b,
sigma>=b while u<=(b-1)^2 gives beta0(u)<=b-1 and beta1(u)<=b. The
same conclusion holds. Consequently every bad transition preserves lead,
and every second consecutive bad transition earns at leastone. Old bad
transitions always earn four, regardless of phase.

Set C=d+5. At the source or target of any near-region bad transition,
one reference rewind costs at most C. Indeed that transition has
q>(b-5)^2, and its target is at least q. At either relevant source or
target M,

    M-k >= (b-5)^2+1-k > (b-6)^2,

because b>d+10. Hence ceil(sqrt(M-k))>=b-5 and
phi0(M)>=M-C. The same argument applies to a near-good source.

## 4. The old/near interface handles retreats explicitly

Consider consecutive good transitions with different actual conventions.
Until a paid rewind, advance the same reference through every intervening
bad transition. The following cases find a valid place to rewind BEFORE
the later good transition. Subsequent bad transitions preserve domination
in the flipped phase.

First suppose the earlier good root is at most b-6. Its source residual
is at most (b-6)^2+k, and the reference never increases. If any intervening
transition, or the later good transition, enters the near region, its
source residual is at least (b-5)^2+1. The lead there is therefore at least

    (b-5)^2+1-((b-6)^2+k)=b-d-10 >= C,

using b>=2d+15. Rewind at that source. This covers arbitrary retreats
back to larger residuals. If the interval never enters the near region,
all its bad transitions are old bad and the previously accepted C=4
matching-charge/rewind proof applies unchanged.

Otherwise the earlier good root is at least b-5. The conservative old
good bounds dominate both kinds of good event: at most25 outliers at
each endpoint, old dominant surplus at most r+4, and old q at least
(r-1)^2+1. The accepted fixed-matching corner-change charge gives

    Delta*k >= r^2/2-6r-56
             >= (b^2-22b-27)/2.                  (1)

A change of active cohort has the accepted stronger charge; polarization
can also eliminate such changes when its full-board normal form is used.
The present proof does not need that extra normalization.

There are B=Delta-1 intervening bad transitions. Put

    B_star=2C-1+ceil((D-C+1)/4).                  (2)

Here D>=C in the stated range. If a near bad transition is the j-th bad
transition and j>=2C, then by its target the lead is at leastfloor(j/2)
>=C, and the local rewind criterion applies there. If no such transition
occurs, let j<=2C-1 be the last near bad index, or j=0 if none occurs.
The final B-j transitions are old bad. Their accumulated lead is at least

    floor(j/2)+4(B-j)
      >= C-1+4(B-2C+1) >= D                     (B>=B_star),

where the middle bound is minimized at j=2C-1; if B<2C-1 the sufficient
condition B>=B_star cannot hold. Thus one can rewind at the final slow
source before the next good event. This argument counts the complete
mixed bad history and permits repeated excursions across the interface.

## 5. Uniform arithmetic sufficiency

The conditions b>d+10, b>=2d+15, D>=C and the old slow concentration
range r>=R+1>=46 all hold for b>=160 and 1<=d<=19. In particular the
old C=4 matching proof is available whenever invoked above.

To prove that (1) supplies B>=B_star, note D<2k/5 and

    B_star <= (7C+D)/4
            < b/10+37d/20+35/4.

The sufficient inequality

    (b^2-22b-27)/(2(b+d))-1
       >= b/10+37d/20+35/4

is equivalent to

    8b^2-39bd-415b-37d^2-195d-270 >=0.           (3)

For b>=160 the left side decreases in d on 1<=d<=19, and at d=19
increases in b. Its value at (b,d)=(160,19) is2508. Thus (3) holds
throughout the infinite parameter range. There is no width enumeration.

## 6. Initial, terminal, and fast-region bookkeeping

Choose the initial reference phase to match the first good transition;
if there is no good transition either phase works. Sections3--5 pay
every later convention change using a rewind of this SAME trajectory.
Its used index never exceeds actual elapsed time. Rewinds occur only
after a preceding good transition, so an earlier reference step exists.

The last-crossing entry into m<=Y, any later excursion after reaching A,
and the final scalar continuation use exactly the arguments of
`physical-hybrid-necessary-clock.md`. The crossing inequality remains
valid: any crossing target is <=Y_top<b^2, where the scalar signed-surplus
bound applies. One reset move is paid by an omitted nonempty excursion;
no reset is introduced merely for passing the old (b-5)^2 ceiling.

After the last entry into m<=A, the scalar continuation is allowed by
the SAME hybrid C. Ordinary reference moves below A remain allowed, so
an earlier reference crossing causes no problem. Hence some hybrid
initial phase reaches its gate in at most g-s moves, proving the stated
necessary late clock.

## Evidence boundary

This is a physical-history extension for the displayed parameter range.
It does not prove the proposed pronic middle comparison, extend the early
hybrid, prove a nine-day uniform gap, or establish exact optimality.

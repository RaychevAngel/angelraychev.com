# A pronic-cut middle comparison with no ancestry assumption for excess at least three

24 October 2026. Conditional middle-passage theorem. The new boundary
necessity needed to put an arbitrary physical game at this cut is a
separate obligation. No full-game gap is asserted here.

Let w=2b+1, n>=w be even, h=wn/2, k=b+d, b>=8 and
1<=d<2b+1. Put

    H=b(b-1), L=b(b+1), E=h-b^2, U=h-H.

Thus E-L>=2b+1. Let H<Y<=b^2, H<=Q and Y<h-Q<=U. Let tau
be the first time that the accepted ordinary three-corner necessary
frontier, initialized at (Y,Y,Y), has maximum at least h-Q. The
nine-feature clock is at least this ordinary clock.

Let C and A be arbitrary physical backward-prefix and forward-hole
pairs with

    max C>=Y, max A>=Q,
    spread(C)<=d+1, spread(A)<=d+1, Phi(C)>=C coordinatewise.

The current physical phase labels may be arbitrary, and chi is either
0 or1. If d>=3, then

    max_p [Phi^(tau+2)(C)[p] + A[p xor chi]] >= h.       (1)

Consequently the same conclusion holds if tau is replaced by the
nine-feature middle clock. No common tied-origin assumption is needed.
The statements use the physical update Phi from the accepted prefix
construction, and do not identify the unrestricted optimum with that
construction.

## 1. An exact faster comparator from an equal seed

Speed up the ordinary frontier by discarding its source-corner caps and
using the accepted unshifted inverse branches. Call the resulting
frontier B and its first-hit clock tau0. Its maximum is at least the
original ordinary maximum, so tau0<=tau.

For an equal input q with H<q<=b^2, every inverse cost is at least b,
and each source corner count has an available cost-b edge (target j=1,
source i=0 suffices). Both physical low costs are exactly b. Therefore
both the relaxed frontier and the physical pair advance equally by d.
This includes an update crossing b^2 and its exit overshoot. The low
large-deficit branch cannot be cheaper: h-q>=h-b^2>=b^2+3b+1.
The shifted tiny inverse exceptions are also strictly above b here;
b>=8 and q>H suffice.

After the equal entry z>b^2, and until the first target h-Q is reached,
all input targets q are below U. The exact relaxed central recurrence is

    B0'=x+d-1,
    B1'=max(x+d-1, y+d if y<=L),
    B2'=max(x+d-1, y+d, B1+d if B1>=E),

where x=B2=max B, y=B0, x-y in{0,1}, and B1 in{y,x}. This is the
accepted central recurrence in the frozen critical-passage proof.

Its exceptional last term can never improve the pair update in the
present budget range. Such an improvement requires B1=x=y+1 and B1>=E.
A difference B1>B0 can only have been created at the immediately previous
step from an input with B0<=L. Its new B1 is then at most L+d, whereas
E>=L+2b+1>L+d. If a step has input B0>L it removes that difference
permanently. Equal initialization cannot supply it. This proves exclusion
of the exception for every width and length, including an input that
jumps across a central subinterval.

Hence the projected pair follows exactly

    (x,y) -> (y+d,x+d-1).

These are the exact physical maps on b^2<q<U: G costs b and F costs
b+1. Starting at the equal seed Y, the relaxed maximum therefore equals
the physical maximum at every pre-exit step and on the exit update.
The physical pair has spread at most one throughout. In particular, if
Z=Phi^tau0(Y,Y), then

    max Z>=h-Q,  min Z>=h-Q-1.                       (2)

## 2. Unequal input pairs lose at most one spread, not two

Track the two ancestors of the physical coordinates separately; each
step swaps their labels. At least one coordinate of C is at least Y.
Its descendant at time tau0 is at least the corresponding coordinate
of Z. The other initial coordinate is at least Y-(d+1).

On every comparison interval below the corresponding equal-seed input,
Phi's scalar map is nondecreasing and1-Lipschitz: the equal-seed input
has not yet reached h-Q<=U, so the high-deficit decrease in the F cost
at U is not encountered. The low square/pronic costs, capped at b+1
or b respectively, are nondecreasing. Thus the other descendant loses
at most d+1 rooms. The positive descendant needs only monotonicity and
may pass U early without causing a problem.

Similarly A has one coordinate at least Q and the other at least
Q-(d+1). For either phase matching, either the two nondeficient
coordinates match, or the two mixed matches lose at most one spread.
Using (2), at time tau0 this gives

    max_p [Phi^tau0(C)[p]+A[p xor chi]] >= h-(d+2).   (3)

The one additional room in (3) is the equal-seed phase spread, not a
second independently charged input spread.

## 3. Two physical steps pay the remaining deficit

For odd width, globally G increases its input by at least d and F by
at least d-1, with the common terminal clipping at h. Therefore two
successive updates increase each phase coordinate by at least2d-1,
unless that coordinate has already reached h, which itself proves(1).
The phase labels return to their original order after two steps.
Combining with(3), the matched sum is at least

    h-(d+2)+(2d-1)=h+d-3>=h.

This proves(1) at tau0+2. The explicit hypothesis Phi(C)>=C and
monotonicity imply that all of its later iterates are coordinatewise
nondecreasing, so the same fixed-phase paired sum meets at tau+2.
This hypothesis holds for the actual late hybrid pair after the scalar
cutoff: the hybrid sequence is coordinatewise nondecreasing, its cap is
inactive, and the finite-board physical operator dominates the ordinary
quadrant operator there. It is included explicitly rather than inferred
from an arbitrary unsigned spread bound.

## Scope and remaining endpoint work

The ordinary relaxed comparator is an admissible necessary middle clock.
The conclusion also applies at a larger nine-feature clock because of
the progress-compatible input condition just stated. No fixed-phase
monotonicity is asserted for arbitrary unrelated input pairs.

For even width the physical minimum increment is d, and the scalar
necessary maximum increment is at most d throughout this pronic middle.
The same paired-input argument gives a two-step comparison for d>=1;
its separate proof is being assembled.

The odd d=1,2 cases remain. The affine transport now has only the
boundary residue modulo2d and central residue modulo2d-1. This is much
smaller than the earlier six-root-band module, and no unbounded ancestry
information should be discarded without testing that remaining finite
interface. The boundary feasibility of H=b(b-1) remains separate.

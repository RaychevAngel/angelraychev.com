# Constructive and independent-review lane

24 October 2026. Private research; no new public or Lean claims.

## Exact structural progress

The alternating polarization theorem was independently accepted and its
literal finite audit reproduced. Every even-area rectangle admits an
optimal strategy with reflected cohort nesting. Folding the reflection
gives two nested copies of a half-size grid with loops on the fold boundary.
This is an exact normal form, not yet a size-only or prefix normal form.
Receipt: `upper-polarization-review.json`.

The zero-slack nearcritical early and late concentration lemmas were
independently accepted. The early remainder is at most one cell; the late
opposite survivor cohort is exactly full. Polarization fixes the permanent
cohort, leaving only actual corner changes. Receipts:
`upper-nearcritical-good-review.json`, `upper-nearcritical-late-review.json`.

The paired bad-credit arithmetic lemma is accepted, with the stronger
failure count `ceil(C/(2v))` per exceptional root. Its duration becomes
`2(C+m ceil(C/(2v)))`. The proposed d=1..19 application is at most 58 steps,
but its physical interfaces remain separate. See the review and receipt.

## Failed routes and retained evidence

Generic nested-layer seriality is false. A tiny symmetric relation gives
joint two-day capture while serial capture takes three. A second relation
has a perfect matching (thus Hall noncontraction) and still gives joint six
versus serial seven. The second has a disconnected bipartite double cover,
so neither example is a rectangle counterexample. Adding loops removed
that example's advantage. The exact counterexamples and the limited
negative checks are documented in `upper-seriality-obstruction.md`.

An exact O(h)-per-day optimization over both fixed-corner prefix cohorts
and shared daily quota did not improve the retained constructive bounds.
It was independently checked against literal transition triangles and
coordinate-level strategy replays. Results include 24²/k13=207,
46²/k24=509, 108²/k55=1539, 81×82/k41=1607, and 129×130/k65=2803.
The 12²/k7 prefix value 74 is worse than the known transport value 72,
confirming that this family misses essential shape motion. See
`upper_joint_prefix.py` and its audit/diagnostic receipts.

A one-defect pyramid beam diagnostic on 46²/k24 again gave solo 255,
palindromic full-board 509. This is only a bounded search of a restricted
family, not an optimality statement. No broader defect enumeration has
been authorized by the evidence so far.

## Current constructive questions

The reflected-grid quotient may expose a stronger exact strategy normal
form, but Hall alone is insufficient and a fixed prefix order is already
incompatible with an unlooped minimum-degree corner at size one.
Two moving orders or a geometric front state are needed.

Pyramidal height walks admit local particle moves, suggesting a scheduling
or cut formulation. The missing point is an exact transformation of an
arbitrary physical strategy, including boundary clipping and quota words.
Automatic boundary removals cannot be commuted with paid inspections
without proof: a vertex redundant before other deletions need not remain
redundant afterwards.

The immediate goal remains a uniform exact strategy/value theorem.
No fixed-width result, negative sample, or newly named evaluator is being
treated as completion.

## Later checks and independent assembly

The connected-loop seriality route also fails. Appending a three-edge path
ending in a loop to the earlier Hall counterexample gives a connected,
looped, Hall-noncontracting relation with solo4, nested joint7, serial8 at
budget3. Every one of its512 Hall inequalities and its literal schedule
were checked. It is not a rectangle and still obeys joint=2solo−1.
Receipt: `upper-connected-loop-tail.json`.

The existing12×12/k7 transport construction refutes exact full-start
early dominance by a fixed anchored prefix. At day26 it creates42 holes
against the best anchored41; at day35 it creates65 against62, still below
half-area72. This was freshly replayed on physical coordinates. The
unrestricted optimal solo envelope remains a different question.
Receipt: `upper-early-anchored-prefix-counterexample.json`.

The plain time-expanded minimum-cut relaxation has an unbounded quota
integrality gap: averaging full-board cuts over T days has daily fractional
load N/T. See `upper-layered-cut-obstruction.md`.

The new pronic early/late extensions, shifted-pronic middle comparison,
complete C++ finite-base port/coverage, and assembled uniform nine-day
bracket were independently reviewed and accepted as ordinary mathematics.
The final source-hashed assembly receipt is `upper-uniform-nine-review.json`.
This is substantive all-parameter tightening, but the authorized zero-gap
goal remains open; no Lean/public coverage was changed.

## Uniform constructive phase freedom

The adaptive balanced bridge now preserves every entrance deficit delta in
[0,b-3], with an explicit legal word and exactlykt virtual flips. Its
independent review and7029 geometry/75 literal checks are saved.

This gives cost-free independent head/tail phase choice at minimum budget
for every even width>=10. The corollary is an actual strategy, verified on
96 literal full schedules. It removes the anchored phase mismatch at448²,
reducing solo4433 to4432 and giving full upper8863. The result is uniform;
that example only illustrates it. No unrestricted optimum is asserted.

The general reflection-transport lemma covers arbitraryk=b+d: an oddt
with t+2floor(dt/(2b))>=2b+1 carries any prefixq>=dt to the opposite
corner prefixq-dt. Its long-plateau corollary preserves central drift d
and makes the two relative phases freely available. Lower independently
accepted the proof;15774 geometry and158 literal checks passed.

The permanent mixed-boundary domination and mixed central barrier were
independently accepted. These are stronger necessary physical statements,
not new constructive optimality. A bounded solo-boundary falsification
check found no witness below the pronic cut: four small pyramid queries
were infeasible and eight timed out. The retained exhaustive8² pyramid
layer certificate matches anchored maxima through H=12. These finite
checks do not prove uniform anchored boundary dominance.

The cut-compatible reflection bridge is now independently accepted. It
changes either relative phase directly from M=h-b(b-1) in2b-3 moves at
minimum budget. Coupling this actual construction with the asymmetric
necessary clocks yields an ordinary five-day bracket for even width2b,
b>=200,d1 and every length. For2<=d<=19 the general bridge yields the
same five-day bracket whenever n>=2b+2d-2. These are uniform parameter
families, not selected-instance gains. The finite smaller-width portion
and short higher-excess rectangles are not included in this new theorem.
Receipt: upper-cut-phase-bridge-review.json.

The smaller half-budget hybrid cutoff was independently accepted. Its stronger capped early credit pays every required phase rewind, and the near-pronic late arithmetic remains uniform. This strengthens necessary evaluators; no standalone capture gap or exactness claim follows. Receipt: upper-half-cutoff-review.json.

A stronger generic seriality shortcut also fails: a connected ten-vertex tree with a displayed perfect matching has solo6 but nested joint10 at budget2. See upper-half-solo-obstruction.md and its exact witness. It has no loops and therefore does not refute folded rectangles; no generic Hall-based half-time reduction may be assumed.

The terminal-quota cut now improves the accepted transport families from a five-day to a four-day bracket. The separate source is upper-four-day-transport-families.md; lower independently accepted its arbitrary-gate construction and final-day arithmetic. The global eight-day theorem was also independently assembled and accepted; these new ordinary proofs do not change formalization coverage.

The exact physical-visibility optimization for descending words collapses uniformly to the old final-root credit at every feasible rectangle budget. Lower independently checked the proof and caught a reversed endpoint inequality, corrected using active columns. This rules out hidden visibility savings in this construction route, not other orders. Source: upper-window-collapse.md. The lower lane's outlier equality rigidity was independently accepted: exact phase cost with multiple components forces a full corner triangle plus a corner singleton at one exceptional integer endpoint.

Source reconciliation: visibility collapse was already proved in research/bridge-upper-transport.md, including the general cross-section case. The new note is a reviewed restatement/failure shield, not new mathematical progress.

Post-deadline bounded review: strongest global8 and explicit four-day subfamilies re-audited, all source hashes and complete finite-base coverage current. Ordinary-MAX cap-correlation algebra independently accepted. Constant-quota saturation remains open: a one-step own-cap/MAX/2-wedge closure is false at an unreachable k7 state; two-step closure remains a plausible unproved route after a bounded k2..16 algebraic check. No new capture gap claimed.

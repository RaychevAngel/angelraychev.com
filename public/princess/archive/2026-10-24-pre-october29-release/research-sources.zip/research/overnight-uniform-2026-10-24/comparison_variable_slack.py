"""Arithmetic guards for the variable-slack proof candidate.

This module does not itself authorize a physical lower bound. Check the
independent review receipt for comparison-variable-slack-cutoff.md.
No board dimensions or strategies are searched here.
"""
from __future__ import annotations

from math import isqrt


def ceil_div(a: int, b: int) -> int:
    return -(-a // b)


def guards(b: int, d: int, s: int, R: int) -> dict:
    k = b + d
    r = R + 1
    D = k - r
    H = b * (b - 1)
    ce, cl = d + s + 2, d + s + 1
    ge = s if D <= r else s - 1
    be = 4 * s + 6 if d == 1 else 2 * (d + s + 2)
    bl = 2 * cl - 1 + ceil_div(D - cl + 1, s) if s > 0 else 10**99
    E = lambda x: x*x - (2*s+3)*x - 5*s*s - 7*s
    L = lambda x: x*x - (2*s+4)*x - 5*s*s - 8*s
    tests = {
        'positive_parameters': b >= 1 and d >= 1 and s >= 2 and R >= 0,
        'budget': k >= 100,
        'old_fast_domination': R <= 3*k//5,
        'width_interface': b >= 2*d+3*s+3,
        'old_root_range': ce <= r <= b-s-1,
        'rewind_range': cl <= D <= 2*r+1,
        'concentration_monotonicity': r >= s+2,
        'concentration': 2*((r-1)**2+1) > (r+s)**2,
        'remainder': 2*r > (s+2)**2+2,
        'genuine_quadrant': (b-s-1)**2+D <= H,
        'old_early_charge': k > 0 and ge*(ceil_div(E(r),2*k)-1) >= D,
        'old_late_charge': k > 0 and s*(ceil_div(L(r),2*k)-1) >= D,
        'near_early_charge': k > 0 and ceil_div(E(b-s-1),2*k)-1 >= be,
        'near_late_charge': k > 0 and ceil_div(L(b-s-1),2*k)-1 >= bl,
    }
    return dict(admissible=all(tests.values()), b=b, d=d, k=k, s=s, R=R,
                r0=r, D=D, early_gain=ge, late_gain=s,
                near_early_steps=be, near_late_steps=bl, tests=tests)


def least_cutoff_for_slack(b: int, d: int, s: int) -> dict | None:
    """Find the least admissible R, using proved monotonicity of the guards."""
    if d < 1 or s < 2 or b < 2*d+3*s+3 or b+d < 100:
        return None
    k = b+d
    lo = max(s+1, d+s+1)
    hi = min(3*k//5, b-s-2, k-(d+s+1)-1)
    if lo > hi or not guards(b,d,s,hi)['admissible']:
        return None
    while lo < hi:
        mid=(lo+hi)//2
        if guards(b,d,s,mid)['admissible']:
            hi=mid
        else:
            lo=mid+1
    return guards(b,d,s,lo)


def strongest_cutoff(b: int, d: int) -> dict | None:
    """Return the strongest member; None means retain older proved clocks."""
    # The width interface and remainder root guard each bound the slack.
    smax=min((b-2*d-3)//3, isqrt(2*(3*(b+d)//5+1))-2)
    choices=[v for s in range(2,smax+1)
             if (v:=least_cutoff_for_slack(b,d,s)) is not None]
    return min(choices,key=lambda v:(v['R'],v['s'])) if choices else None


if __name__ == '__main__':
    import argparse,json
    p=argparse.ArgumentParser()
    p.add_argument('b',type=int)
    p.add_argument('d',type=int)
    a=p.parse_args()
    print(json.dumps(strongest_cutoff(a.b,a.d),indent=2))

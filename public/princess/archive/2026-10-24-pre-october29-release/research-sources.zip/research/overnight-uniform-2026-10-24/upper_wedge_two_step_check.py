from math import isqrt
R=lambda x:isqrt(x-1)+1 if x else 0
def rho(x):
 r=(isqrt(4*x+1)-1)//2;return r+(r*(r+1)<x)
F=lambda x:x-R(x);G=lambda x:x-rho(x)
for k in range(2,31):
 a=b=0
 for t in range(1,31):
  aa,bb=G(b+k),F(a+k);aaa,bbb=G(bb+k),F(aa+k)
  for x in range(a+1):
   ymax=min(b,max(a,b)-x)
   if a>=2:ymax=min(ymax,2*(a-x))
   for y in range(ymax+1):
    if b>=2 and x>2*(b-y):continue
    for u in range(k+1):
     xx,yy=G(y+k-u),F(x+u)
     for v in range(k+1):
      xxx,yyy=G(yy+k-v),F(xx+v)
      if (aaa>=2 and yyy>2*(aaa-xxx)) or (bbb>=2 and xxx>2*(bbb-yyy)):
       print('FAIL',k,t+1,(a,b),(x,y),(u,v),(aaa,bbb),(xxx,yyy),flush=True);raise SystemExit
  a,b=aa,bb
  if a>100:break
 print('ok',k,flush=True)

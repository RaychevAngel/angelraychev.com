# Both physical corner phases dominate a permanently mixed boundary

24 October 2026. Ordinary theorem proposed for independent review.
This concerns actual two-cohort histories after the last-full normalization.
It does not assert that a fixed-corner prefix is optimal from full origin.

Put b=floor(w/2), h=wn/2 for an even-area rectangle w<=n, and assume
k>=b+1. Let H=(b-1)^2. For positive u<=H define the two genuine corner
neighborhood surplus functions

    c_0(u)=ceil(sqrt(u)),  c_1(u)=1+rho(u),

where rho(u) is the least integer z>=0 with u<=z(z+1). Thus c_0<=c_1<=b.
These are the actual two checkerboard prefix profiles while the prefix
fits the quadrant. At u=0 set both c_p(0)=0.

## 1. Stronger static mixed survivor profile

The proof of `lower-last-full-mixed-penalty.md` actually applies throughout

    0<q<=b^2,

not just q<=H. Indeed if sigma<b, two co-small survivors would give
q>=b^2+b, still a contradiction; two small survivors give q<0. Since
both survivors are proper, their small/co-small decomposition yields

    q<=(sigma-1)^2-1.

Consequently every such actual mixed survivor pair satisfies

    sigma >= min(b,1+ceil(sqrt(q+1))).                 (1)

In particular, if 0<u<=min(q,H), then

    sigma >= c_p(u) for BOTH p=0,1.                   (2)

For sigma>=b this is immediate. Otherwise (1), monotonicity, and
rho(u)<=ceil(sqrt(u+1)) prove it. No phase or corner label is needed.

## 2. Exact late comparison, including arbitrary retreats

Consider an actual permanently mixed suffix: the larger survivor is
proper after every inspection, as in the last-full normalization. Write
m_t for the signed pre-inspection mass |X_t|+|Y_t|-h. Take any day s and
any integer

    k<Z<=min(h,H+k),    m_s>=Z.

For either initial corner phase, start a physical single-cohort prefix
with Z rooms. While its size x_t exceeds k, inspect its last k rooms;
its next size is

    x_(t+1)=u+c_p(u),  u=x_t-k,                       (3)

with p alternating each day. Stop at its first x_t<=k.

Then at every actual day up to the first actual m_t<=k,

    x_t<=m_t.                                        (4)

This holds separately for BOTH possible starting phases. There is no
extra initial-phase day, fast-boundary day, or phase-reset allowance.

Proof. Assume x_t<=m_t and x_t>k. The actual survivor mass q_t satisfies
q_t>=m_t-k>=x_t-k=u>0. Actual expansion gives

    m_(t+1)=q_t+sigma_t.

The reference update is at most x_t-1, since c_p(u)<=b<k. Therefore its
sizes remain <=Z and u remains <=H. Also

    x_(t+1)=u+c_p(u)<=H+b=b^2-b+1<=b^2.

If q_t>=x_(t+1), nonnegative surplus proves (4) immediately. Otherwise
0<q_t<x_(t+1)<=b^2, and both actual survivors are proper. Apply (2) with
the reference u<=q_t to obtain

    m_(t+1)=q_t+sigma_t>=u+c_p(u)=x_(t+1).

This argument permits m_t and q_t to make arbitrary excursions above Z
or above the subcritical mass window. In the only case where such an
excursion could endanger the comparison, q_t is itself forced back below
b^2, where the static inequality applies. QED.

Let ell_p(Z) be the number of unsuccessful prefix updates (3) before
its first size<=k. If g is the first actual day at or after s with m_g<=k,
then

    g-s >= max(ell_0(Z),ell_1(Z)).                    (5)

Each prefix needs one further inspection to capture. The clock in (5)
counts only the pre-final updates, matching the actual signed gate.

## 3. Early mixed-hole counterpart

Suppose both actual cohort hole sets are nonempty, their total size is
Q with 2<=Q<=H, and their total dual surplus is sigma. Then

    sigma >= min(b,1+ceil(sqrt(Q-1))) >= c_1(Q).       (6)

If sigma<b, each hole set is on the small separator side because
h-Q>sigma(sigma+1). Each has positive integer surplus, so their two
square capacities sum to at most (sigma-1)^2+1. This proves the first
inequality. For Q>=2, rho(Q)<=ceil(sqrt(Q-1)); also c_1(Q)<=b.

For an actual inspection-and-move step with target holes Q in this range,
the original survivor surplus is at least this dual surplus. Hence

    Q_old+k >= Q+c_p(Q) for either quadrant phase p. (7)

The exact inverse prefix relation therefore lets either physical hole
phase dominate this mixed step whenever its source hole count dominates
Q_old. This is a local statement while the target is in the displayed
window. A general early cut may still start in a solo state with a moving
front; no fixed-prefix dominance is inferred for that preceding segment.

In a last-full normalized history, both hole cohorts are nonempty at
every pre-inspection day strictly after activation. The larger support
is proper, and nesting makes the smaller support proper as well.

## 4. What this changes and what remains

The previous corner-history machinery was needed because a full partner
permits a cheap single-cohort corner profile whose phase can change.
Inside the permanently mixed portion, positive deficit in the partner
already pays for the worse of the two quadrant profiles. All corner
motion is therefore harmless for the exact comparisons above.

The unresolved full-board task is to connect the SOLO moving-front
prefix, the activation point, the middle transition, and this exact mixed
suffix. One may not assume the mixed mode starts before a chosen cut, or
replace the genuine solo prefix by an anchored prefix known to be
suboptimal on the 12-by-12 transport example.

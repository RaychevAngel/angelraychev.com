"""Independent literal audit of the exact one-square phase formula."""
from pathlib import Path
import json

def first_slow(b,d,x,i):
 j=max(1,(b*b-x)//d+2)
 return j+((i+1-j)%2)

def transfer(b,d,C,t):
 out=[None,None]
 for i,x in enumerate(C):
  j=first_slow(b,d,x,i)
  out[i^(t%2)]=x+d*t-max(0,1+(t-j)//2)
 return tuple(out)

def literal(b,d,X):return X[1]+d,X[0]+d-int(X[0]>b*b)

def audit():
 checks=0
 for b in(4,8,32,200):
  H=b*(b-1)
  for d in(1,2,3,7,19):
   for x in range(H+1,b*b+2*d+3):
    for delta in(-2,-1,0,1,2):
     if x+delta<=H:continue
     C=(x,x+delta);X=C
     for t in range(2*b+8):
      assert transfer(b,d,C,t)==X,(b,d,C,t,transfer(b,d,C,t),X)
      X=literal(b,d,X);checks+=1
 return dict(status='PASS',literal_comparisons=checks,scope='Exact one-square phase identity, not a uniform capture comparison.')
if __name__=='__main__':
 out=audit();Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

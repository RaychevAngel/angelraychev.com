# A delayed activation pays for small outliers

24 October 2026. Proposed ordinary lemma for independent review. This is
stronger than strict saturation in the fast regime, but it deliberately
does not claim a full constant-budget allocation theorem at arbitrary time.

Use F(z)=z-ceil(sqrt(z)), G(z)=z-rho(z), and the ordinary constant-quota
pair P_0=(0,0), P_(t+1)=(G(P_t[1]+k),F(P_t[0]+k)). Consider TWO independent
fixed-corner quadrant processes starting from zero and sharing daily quota k.
Their cardinality updates may be LESS than the corresponding F/G inverse;
equality is not required. Thus actual quadrant histories are included.
Choose one of them as the distinguished process; at terminal time t>=1,
write x for its output, y for the other's output, and p for the distinguished
process's CURRENT relative corner color. Then

    x+y <= max(P_t[p], P_(t-1)[p]+y).              (1)

In particular, if

    P_t[p]-P_(t-1)[p]>=y,                         (2)

then x+y<=P_t[p]. No hypothesis that x is the larger output is needed.

## Proof by permanent activation order

For this terminal time, erase each process's allocations up to and including
its last zero state. This preserves its terminal output and never increases
the daily budget. Remove a process whose terminal output is zero. Each
remaining process is now zero until one activation and positive thereafter.

If the distinguished process activates no later than the other, follow its
phase convention with the full daily quota. Before the other activation it
dominates the only relevant process. At and after the second activation,
both input masses are positive; the accepted mixed inequality

    F(a)+G(b)<=F(a+b) whenever a>0

bounds the total by the worse map F. Whichever map the distinguished ordinary
phase uses is at least F. Thus the total is bounded by P_t[p]. Simultaneous
activation is included: choose the distinguished phase from that update.

Otherwise the distinguished process activates strictly later. Since the
first activation is at least day1, it is still zero after at least one full
day. Its remaining history has at most t-1 moves. Giving it the entire
constant quota k on each of those moves bounds its output by P_(t-1)[p].
The CURRENT relative color index is unchanged: a zero start has both phase
coordinates0, and the alternating evolution of a suffix is exactly the
ordinary pair for its own duration. Coordinatewise time monotonicity allows
replacing a shorter suffix by t-1. Adding its actual terminal partner y
proves(1).

This is exactly where constant quotas are used. The arbitrary-word example
[6,0,9] does not supply a time-shifted copy of the full word and does not
contradict the lemma.

## A simple lower bound on ordinary daily increments

Let Delta_t=|P_t[0]-P_t[1]|. Then

    Delta_t<=ceil(t/2).                            (3)

Indeed the stronger oriented induction holds: an own-leading pair at time t
has span<=ceil(t/2), and an opposite-leading pair has span<=floor(t/2).
An opposite-leading input can increase the span by at most1 and produces
an own-leading output. An own-leading input either changes leader with no
span increase, or has own-leading output of span at most1. The two stated
bounds therefore propagate from the initial tie. This uses only monotonicity,
1-Lipschitzness, and0<=G-F<=1.

Consequently, with

    B_t=ceil(sqrt(max(P_(t-1))+k)),

both same-coordinate increments satisfy

    P_t[p]-P_(t-1)[p] >= k-B_t-ceil((t-1)/2).      (4)

Both scalar updates remove at most B_t and the adverse source-coordinate
change is at most Delta_(t-1). This proves(4), even when its right side is
nonpositive. It is useful precisely in a fast region, not near a stall.

## Physical consequence for the rigid triangle-plus-singleton exception

Consider one of the accepted configurations in
lower-outlier-equality-rigidity.md at elapsed time t: a full distinguished
corner triangle of surplus s-1 plus a singleton at a DIFFERENT actual
corner. Its largest target radius is D<=2s-4. Suppose

    D+2t < w-1.                                   (5)

Its two full backwards dependence cones are disjoint and each fits its
own actual quadrant. Restricting actual inspections to those cones gives
two independent quadrant histories with no duplicated daily quota, exactly
as in the accepted causal proof. They produce at least the respective actual
target sets. Restrict their final target cardinalities to the actual triangle
size and1: the numerical process definition permits a smaller output than
its F/G bound. No artificial enlargement of the partner is needed. The
activation-order proof applies to these numerical histories directly.

If the matching ordinary increment is at least1, (1) with y=1 bounds the
ENTIRE actual triangle-plus-singleton state by P_t[p]. In particular this
holds when the explicit right side of(4) is at least1.

Thus these exceptional outliers do not require a free phase in that causal
fast regime. This does not cover arbitrary outlier geometries whose cones
overlap, or remove the need to assemble the slow corner-change argument.

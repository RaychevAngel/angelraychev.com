"""Stronger early necessary clock, under explicit causal and inherited guards.

This module checks the EXTRA causal guard only. The caller remains responsible
for the accepted history theorem's width, budget, cutoff and endpoint range.
"""
from bisect import bisect_left
from math import isqrt


def root(x):
    return isqrt(x-1)+1 if x else 0


def rho(x):
    s=(isqrt(4*x+1)-1)//2
    return s+(s*(s+1)<x)


class OrdinaryMaxEarly:
    def __init__(self,k,R):
        self.k=k; self.R=R; self.L=R*R; self.Z=self.G(self.L)
        self.ordinary=[(0,0)]; self.states=[(0,0)]; self.maxima=[0]

    def G(self,x):
        return x+self.k-rho(x+self.k)

    def F(self,x):
        return x+self.k-root(x+self.k)

    def step(self):
        p=self.ordinary[-1]
        pn=(self.G(p[1]),self.F(p[0]))
        cap=min(self.Z,max(pn)); e=self.states[-1]
        en=(max(cap,self.G(e[1])),max(cap,self.F(e[0])))
        assert all(pn[i]>=p[i] and en[i]>=e[i] for i in (0,1))
        self.ordinary.append(pn); self.states.append(en)
        self.maxima.append(max(en))
        if en==e and pn==p:
            raise ValueError('Requested target exceeds fixed point')

    def grow(self,target):
        while self.maxima[-1]<target:self.step()

    def clock(self,target):
        if target<=0:return 0
        self.grow(target)
        return bisect_left(self.maxima,target)

    def causal_guard(self,w,n):
        assert w<=n and w*n%2==0
        b=w//2; W=self.G(self.Z-1); rh=root(W)
        while min(self.ordinary[-1])<self.Z:self.step()
        J=bisect_left([min(p) for p in self.ordinary],self.Z)
        return dict(valid=(self.Z+self.k<=b*b and rh<=b-1 and J+2*rh<=w+2),
                    w=w,n=n,k=self.k,R=self.R,Z=self.Z,W=W,Rhat=rh,J=J)

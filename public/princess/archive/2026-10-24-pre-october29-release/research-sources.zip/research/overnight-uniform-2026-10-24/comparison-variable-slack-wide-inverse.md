# The variable-slack clock does not require a proportional fast cutoff

24 October 2026. Algebraic extension of the proof candidate
`comparison-variable-slack-cutoff.md`; independent review is still required.

Keep every condition and construction of that note, except remove the
upper restriction D<=2r0+1. Let t>=1 be the least integer such that

    D <= (2t-1)r0+t(t-1),

and require t<=s. Replace its early gain g_E by

    g_E=s+1-t.

Use this gain in the early old-block arithmetic test. Every other test,
including D>=C_L, the genuine-quadrant target guard, the late old gain s,
and both near-interface counts, remains unchanged.

Indeed, for an old target root r>=r0 and any desired capped lead c'<=D,

    z=q+c'<=r²+D
      <=r²+(2t-1)r+t(t-1)=(r+t-1)(r+t).

Both exact inverse phase costs at z are at most r+t: ceil(sqrt(z))<=r+t
and1+rho(z)<=r+t. An actual bad surplus at least r+s+1 therefore earns
s+1-t rooms, capped at D. This is the only place the removed restriction
was used. All virtual targets still fit actual quadrants by the separate
condition (b-s-1)²+D<=H.

The former gain rule is recovered exactly: t=1 when D<=r0, and t=2
when r0<D<=3r0+2. In fact the earlier D<=2r0+1 guard was stronger than
necessary even for its second branch.

This change permits a smaller cutoff without asserting one from an
asymptotic heuristic. Only pairs(s,R) passing ALL finite arithmetic guards
are admissible. In particular no ordinary causal comparison, new uniform
capture gap, or optimality theorem follows from this inverse calculation
alone.

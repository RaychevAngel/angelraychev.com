# Correctness of the constructed whole-clock arithmetic DAG

18 September 2026. Ordinary compositional proof and independent source
audit of the implementation pilot. This is not Lean verification, and
the enormous full-clock arithmetic expression has not been evaluated
literally. The reference clock, sparse specification, helper identities,
and compiler source have been checked separately.

## Constructed artifact and statement

The fixed expression is the JSON straight-line arithmetic DAG
`clock-duration.dag.json`, produced by `build_duration.py` from the fixed
first-count artifact and `outer_spec.py`. Its sole input is b. Its output
is named `L_b`. It contains 207,601 nodes, including 204,107 arithmetic
operations. Each arithmetic node is addition, subtraction, multiplication,
floor division, or natural exponentiation. Constants and references to
earlier nodes complete the expression. There is no recurrence, search,
Hamming-weight primitive, moment primitive, or variable-length operation
inside the exported DAG.

**Statement.** For every integer b>=2, the output is the full corner clock
L_b defined in `paper/sections/odd-minimum-budget.tex`. Set L_1=0 as a
separate fixed case. The ordinary proof below connects the finite
expression to that clock. The numerical operation count is constant in
b; bit complexity and intermediate integer sizes are not constant.

The exact artifact SHA-256 recorded by the build is

    bbb6c3a146d090d2bda91fd17042ea9e52bbe7f6b722c90ae4aba8514b9f6a36

The first-count artifact used in its construction has SHA-256

    2e2d67d11dd768f1c61a6730c3d41af9647ceab0d09d2f477b01cf73b3fe31a1

These hashes identify this pilot snapshot, not any later revision.

## 1. The first arithmetic count

`clock-spec-proof.md` gives a self-contained proof of the following
properties of the implemented 23-variable,18-equation relation. Put

    C=b(b-1), m=b+1, Q=C+1, R=Q², H=2C, K=R^(H+1).

The paired clock from (0,0), frozen upon B=C, remains in [0,C]² and
arrives in at most H steps. Encode its H+1 states in base R, with digit
A+QB, and denote the unique code by X_b.

Let G(b,X) be the number of solutions of the local relation. Its index
variable permits exactly j=0,...,H-1. All other witnesses are uniquely
determined when a transition is valid. Initial coordinates are forced
to zero and 0<=X<K is imposed. Therefore

    0<=G(b,X)<=H,
    G(b,X)=H if and only if X=X_b.

For every b>=2,X>=0 all witnesses lie in the explicit cube with edge

    t_1=X+K+(Q+m+1)²+H+2.

The nonnegative squared-equation polynomial is strictly less than
2^w_1 throughout this cube, with w_1=10t_1². These are bounds on all
cube points, not merely on solutions. The first compiler implements
G using the zero-count identity proved below.

## 2. Arithmetic zero-count identity

Let E be a nonnegative integer-valued simple exponential polynomial on
the d-dimensional cube {0,...,t-1}^d, and suppose E<2^w everywhere.
Here d, the polynomial degrees and its monomial list are fixed by the
specification. Let M=2^w, B=M² and

    delta(e)=(M-1)(M-e+1).

For e=0 this is M²-1, with 2w binary ones. For 1<=e<M its upper and
lower w-bit blocks are M-e and e-1; these are binary complements
because their sum is M-1. Thus its Hamming weight is w. Each delta
lies strictly between zero and B.

Index a cube point x by i(x)=sum_j x_j t^j. Packing the values
delta(E(x)) into base-B digits involves no carries. If Z is the number
of zero values of E and P is the packed integer, then

    HW(P)=w(t^d+Z),
    Z=HW(P)/w-t^d.

The packing sum is eliminated as follows. For fixed e<=4, write

    G_e(q,t-1)=sum_(x=0)^(t-1) x^e q^x.

The zero-th expression is (q^t-1)/(q-1). The compiler obtains the next
four fixed numerator polynomials by applying q*d/dq, treating q^t as a
symbol z with derivative q*dz/dq=t*z. If P_e is the numerator over
(q-1)^(e+1), the next numerator is

    P_(e+1)=(q-1)(q*dP_e/dq+t*z*dP_e/dz)-(e+1)q*P_e.

This identity proves the implemented fixed moment formulas. Their
denominators are positive because every substituted q is at least two.
All numerators are nonnegative on their intended domain. The moments
are expanded at construction time, not evaluated by a run-time loop.

The baseline weighted cube sum is

    V=(B^(t^d)-1)/(B-1)
     =product_(j=0)^(d-1) G_0(B^(t^j),t-1).

For a monomial, only its nontrivial coordinates need modified moments.
Divide V by the corresponding baseline factors, then multiply the
modified factors. The division is exact, since its denominator is a
subproduct of the displayed product. Multiplying an exponential base
a^x into a coordinate replaces its moment base by a*B^(t^j).

If W is the weighted cube sum of E, then the packed integer is

    P=(M-1)((M+1)V-W).

The compiler splits the fixed monomial list by coefficient sign. This
computes the displayed value using nonnegative intermediate sums, with
a final nonnegative subtraction: P>0 by its base-B interpretation.
The code in `sparse_count.py` expands each squared equation locally;
its doubled off-diagonal terms are precisely the square expansion.

## 3. The Hamming-weight helper is also expanded

For a positive integer n, let A=2n and B_0=2^A. Every coefficient in
(B_0+1)^A is less than B_0. Therefore

    N=floor((B_0+1)^A/B_0^n) mod B_0 = binomial(2n,n).

The compiler uses the following positive-integer gcd expression. For
a,c>0 put q=5^(ac). Then

    gcd(a,c)=
      [floor(q^(ac+a+c)/((q^a-1)(q^c-1))) mod q]-1.

For completeness, expand the fraction as
sum_(i,j>=0) q^(ac-ai-cj). Its coefficient at exponent zero is
gcd(a,c)+1, by the elementary parametrization of ai+cj=ac. Every
nonnegative-power coefficient is below q. The negative-power tail is
less than one: its n-th coefficient is at most ac+n+1, and
sum_(n>=1)(ac+n+1)q^(-n)=(ac+1)/(q-1)+q/(q-1)²<1 for q=5^(ac).
Hence floor and remainder select the asserted coefficient. All
denominators are positive and the final subtraction is nonnegative.

Take D=gcd(N,2^N)=2^v, where v is the two-adic valuation of N, and put
J=2^(N+1)-1. Then

    D^(N+1)=(J+1)^v = 1+vJ modulo J².

Since 0<=v<=N<J-1, the remainder is exactly 1+vJ, so dividing by J
and flooring gives v. Finally v_2(binomial(2n,n))=HW(n): the identity
v_2(n!)=n-HW(n), proved by counting the powers of two in its factors,
gives this immediately. These are exactly the binomial, gcd and
valuation expressions expanded by `hamming_weight` in `arith_dag.py`.

The zero-count packing P is positive, so no undefined zero-input
valuation is used. The underlying classical arithmetic-term method
is due to Marchenkov and Mazzanti; see
[Marchenkov's primary paper](https://www.mathnet.ru/eng/da10).
This pilot instantiates that machinery for the clock.

## 4. Convert the first expression into unique natural witnesses

The actual first expression has only natural intermediate values for
b>=2,X>=0, by the moment, packing, gcd and remainder identities above.
`outer_spec.py` first replaces every non-base-two power by

    a^e = 2^((ae+a+1)e) mod (2^(ae+a+1)-a).

Indeed 2^(ae+a+1) is congruent to a modulo the positive denominator,
and 0<=a^e<2^(ae+a+1)-a; the case a=e=0 returns one. Squaring is
implemented more economically by multiplication. This conversion adds
only a fixed number of nodes per original power.

Every converted arithmetic node gets one natural output variable.
Addition, subtraction and multiplication are imposed by their defining
polynomial equality. A quotient c=floor(a/d) is represented by

    a-dc-r=0,
    d-r-s-1=0.

The natural r,s are the unique remainder and remainder slack, and these
equations require d>0. Every actual denominator in the first expression
is positive. A base-two power is represented by c-2^u=0. Induction
through the acyclic graph proves that the node values and all quotient
witnesses are unique and are exactly the first expression's values.
There is no branch choice and no free witness at a zero remainder.

The generated graph has 2,953 nodes. The final relation has 3,490
counted variables and 3,210 equations, containing 8,303 unsquared
terms and 11,863 monomials after squaring and combining. These are
fixed integers, not input-dependent sizes.

## 5. The second count returns L_b

The outer relation imposes G(b,X)=H and X+s_X+1=K. Hence X is the
unique frozen-history code X_b, and all first-expression gate witnesses
are unique. Seven further natural variables j,d,ell,eta,s_j,s_d,s_ell
satisfy

    X=ell+Q R^j(d+Q eta),
    ell+s_ell+1=Q R^j,
    j+s_j+1=H,
    d+s_d+1=C.

These assert 0<=j<H, 0<=d<C, and that d is the base-Q digit occupying
the B coordinate at time j. The lower remainder lies below Q R^j,
so the decomposition is unique. Because d<C<Q, this is equivalent to
B_j<C. For each such index every additional witness is unique. The
number of outer solutions is therefore exactly the number of active
indices, which is L_b.

## 6. Every outer witness fits the implemented cube

`monotone_bounds` evaluates a fixed majorant alongside the converted
first graph. It bounds input X by K, keeps positive constants and b,
and uses the following rules for bounds A,B on operands a,e:

    addition: A+B; subtraction: A;
    multiplication: AB; positive quotient: A;
    natural power: (A+1)^B.

These rules are valid for natural outputs, including 0^0=1 in the
power rule. Induction gives a bound U_i for every gate. Quotient
remainders and slacks are below their actual divisor and hence its
majorant. The code slack is below K. In the active query, j,s_j<H,
d,s_d<C, ell,s_ell<Q R^j<K, and eta<=X<K.

The implemented t is the sum of every U_i, K,H,C,Q,R,b,10 and all
positive external parameters. It therefore strictly exceeds every
counted witness, every parameter and every fixed graph coefficient.
The graph has no unbounded search for this bound: the majorant is
itself a fixed arithmetic DAG.

For arbitrary points of the whole cube [0,t-1]^3490, the audited
unsquared terms have coefficient magnitude at most 23<t, polynomial
total degree at most two, parameter total degree at most two, and at
most one exponential, whose base is 2 or R and exponent is below t.
Each equation has at most four terms. Thus, with D=3210 equations,

    |equation|<=4t^(t+5),
    0<=E<=16D*t^(2t+10).

For t>=2,

    log_2(E)<4+D+2t²+10t<100(D+1)t².

The implemented packing width w=100(D+1)t² consequently satisfies
E<2^w on the entire cube. It is intentionally generous. Applying the
zero-count identity to the outer relation is valid and yields L_b.

## 7. Scope, validation and limitations

The expression's meaning follows from the lemmas above and the fixed
compiler transformations. Independent review checked the first-count
moment and Hamming-weight formulas, exact baseline divisions, unique
local witnesses, base-two conversion, quotient graph, active-index
extraction and both whole-cube bounds. Thirty-six small power-conversion
cases, including 0^0, passed. Every outer variable has bound metadata;
all sparse indices, parameter names and exponential base tags were
checked. Separate direct-clock tests checked 56 genuine witnesses and
rejected 1,816 one-digit changes to their packed histories.

These are component checks and ordinary proofs. They are not a literal
evaluation of the huge full-clock term or a Lean theorem about its JSON
semantics. No practical speedup is claimed.

Combining this clock expression with the accepted odd minimum-budget
theorem gives the bounded-operation value expression

    T_(b+1)(2b+1,n)=2(2b+1)n-8b²+4b+4L_b-4

for every odd n>=2b+1 and b>=2, with b=1 handled directly. That
consequence is conditional on the accepted geometric theorem; the
compiler does not reprove its capture/minimality argument or extend
the formula to other budgets. No public or formal-source artifact was
changed during this implementation pilot.

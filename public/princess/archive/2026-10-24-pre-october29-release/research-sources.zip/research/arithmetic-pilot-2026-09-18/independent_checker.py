"""Independent semantic and guarded primitive-DAG audit.

No huge clock-count integer is evaluated. Producer modules are used only to
obtain the equation list and compile toy DAGs; neither their reference
recurrence nor their interpreter supplies expected values.
"""
from __future__ import annotations

import argparse
from collections import Counter
import importlib.util
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BIT_CAP = 1_000_000
ALLOWED = {"input", "const", "add", "sub", "mul", "div", "pow"}


class UnsafeInteger(Exception):
    pass


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def interpret(nodes, inputs, output, bit_cap=BIT_CAP):
    """Independent interpreter; stops at the requested node, before large powers."""
    values = []
    maximum_bits = 0
    negatives = 0
    for index, node in enumerate(nodes):
        op = node["op"]
        assert op in ALLOWED, (index, op)
        if op == "input":
            value = inputs[node["name"]]
        elif op == "const":
            value = node["value"]
        else:
            assert len(node["args"]) == 2
            assert all(isinstance(i, int) and 0 <= i < index for i in node["args"])
            a, b = (values[i] for i in node["args"])
            if op == "add":
                value = a + b
            elif op == "sub":
                value = a - b
            elif op == "mul":
                if a and b and abs(a).bit_length() + abs(b).bit_length() > bit_cap + 1:
                    raise UnsafeInteger((index, "multiplication exceeds safe bound"))
                value = a * b
            elif op == "div":
                assert b > 0, (index, "nonpositive denominator", b)
                value = a // b
            else:
                assert b >= 0, (index, "negative exponent", b)
                if abs(a) > 1 and abs(a).bit_length() * b > bit_cap:
                    raise UnsafeInteger((index, "power exceeds safe bound"))
                value = a ** b
        assert isinstance(value, int)
        bits = abs(value).bit_length()
        if bits > bit_cap:
            raise UnsafeInteger((index, "value exceeds safe bound"))
        maximum_bits = max(maximum_bits, bits)
        negatives += value < 0
        values.append(value)
        if index == output:
            return value, maximum_bits, negatives
    raise AssertionError("Missing output node")


def parameters(b):
    assert b >= 2
    C = b * (b - 1)
    return C, b + 1, C + 1, (C + 1) ** 2, 2 * C


def roots(A, B, m):
    # Deliberately use elementary increasing trials, not the producer's isqrt.
    u = v = 0
    while u * (u + 1) < B + m:
        u += 1
    while v * v < A + m:
        v += 1
    return u, v


def own_history(b):
    C, m, Q, R, H = parameters(b)
    pairs = [(0, 0)]
    for _ in range(H):
        A, B = pairs[-1]
        if B == C:
            nxt = A, B
        else:
            u, v = roots(A, B, m)
            nxt = B + m - u, A + m - v
        assert all(0 <= z <= C for z in nxt)
        pairs.append(nxt)
    assert pairs[-1][1] == C
    X = sum((A + Q * B) * R ** j for j, (A, B) in enumerate(pairs))
    assert X.bit_length() < 10000  # History codes only, never the packed count.
    return pairs, X


def own_witness(b, X, j):
    C, m, Q, R, H = parameters(b)
    if X < 0 or not 0 <= j < H or X >= R ** (H + 1) or X % R:
        return None
    lower_base = R ** j
    lower, tail = X % lower_base, X // lower_base
    pair, next_tail = tail % R, tail // R
    next_pair, upper = next_tail % R, next_tail // R
    A, B = pair % Q, pair // Q
    Ap, Bp = next_pair % Q, next_pair // Q
    u, v = roots(A, B, m)
    active = int(B != C)
    expected = (B + m - u, A + m - v) if active else (A, B)
    if (Ap, Bp) != expected:
        return None
    result = dict(j=j, A=A, B=B, Ap=Ap, Bp=Bp, h=active,
                  e=C-B-active, u=u, v=v,
                  su=B+m-u*(u-1)-1, tu=u*(u+1)-B-m,
                  sv=A+m-(v-1)**2-1, tv=v*v-A-m,
                  ell=lower, eta=upper,
                  dA=C-A, dB=C-B, dAp=C-Ap, dBp=C-Bp,
                  dell=lower_base-lower-1, dj=H-1-j,
                  dX=R**(H+1)-X-1, zeta=X//R)
    assert len(result) == 23 and min(result.values()) >= 0
    return result


def direct_G(b, X):
    return sum(own_witness(b, X, j) is not None for j in range(parameters(b)[4]))


def semantic_audit():
    producer = load_module("audited_clock_spec", HERE / "clock_spec.py")
    spec = producer.build_spec()
    assert len(spec["variables"]) == 23 and len(spec["equations"]) == 18
    import sympy as sp
    evaluate_equations = sp.lambdify(
        [*spec["variables"], *spec["parameters"].values(), spec["exponential_symbol"]],
        spec["equations"], modules="math", cse=False)
    examples = []
    witnesses = mutations = perturbed_witnesses = active_checks = 0
    for b in range(2, 11):
        C, m, Q, R, H = parameters(b)
        pairs, X = own_history(b)
        params = dict(b=b, X=X, C=C, m=m, Q=Q, R=R, H=H)
        cube = X + R**(H+1) + (Q+m+1)**2 + H + 2
        assert direct_G(b, X) == H
        for j in range(H):
            witness = own_witness(b, X, j)
            assert witness is not None and max(witness.values()) < cube
            arguments = [witness[str(v)] for v in spec["variables"]]
            arguments += [params[name] for name in spec["parameters"]]
            arguments += [R**j]
            assert not any(evaluate_equations(*arguments))
            witnesses += 1
            # Every witness coordinate is constrained: a +1 mutation must fail.
            if b <= 5:
                for position in range(23):
                    changed = arguments.copy()
                    changed[position] += 1
                    if position == 0:
                        changed[-1] = R ** (j + 1)  # z means R^j, not a free input.
                    assert any(evaluate_equations(*changed))
                    perturbed_witnesses += 1
            # Independent semantics of the proposed second count's digit equation.
            base = Q * R**j
            ell = X % base
            d = (X // base) % Q
            eta = X // (base * Q)
            assert X == ell + base * (d + Q * eta)
            assert d == pairs[j][1]
            assert (d <= C-1) == (j < next(i for i, p in enumerate(pairs) if p[1] == C))
            active_checks += 1
        L = next(i for i, p in enumerate(pairs) if p[1] == C)
        examples.append(dict(b=b, L=L, H=H, history_code_bits=X.bit_length()))
        assert direct_G(b, X + R**(H+1)) == 0
        assert own_witness(b, X, -1) is None and own_witness(b, X, H) is None
        if b <= 5:
            for digit_position in range(2*(H+1)):
                place = Q**digit_position
                old = X // place % Q
                for digit in range(Q):
                    if digit != old:
                        assert direct_G(b, X + (digit-old)*place) < H
                        mutations += 1
    assert own_history(2)[1] == 59004
    return dict(witnesses=witnesses, single_digit_mutations=mutations,
                perturbed_witnesses=perturbed_witnesses,
                active_digit_checks=active_checks, examples=examples)


def helper_audit():
    producer = load_module("audited_arith_dag", HERE / "arith_dag.py")
    import sympy as sp
    moment_checks = 0
    for degree in range(5):
        dag = producer.DAG()
        node = dag.moment(degree, dag.input("q"), dag.input("t"))
        for q in range(2, 5):
            for t in range(1, 7):
                got, _, _ = interpret(dag.nodes, dict(q=q, t=t), node)
                assert got == sum(x**degree * q**x for x in range(t))
                moment_checks += 1
    hw = producer.DAG()
    node = hw.hamming_weight(hw.input("n"))
    hamming = []
    for n in (1, 2):
        value, bits, neg = interpret(hw.nodes, {"n": n}, node)
        assert value == bin(n).count("1")
        hamming.append(dict(n=n, value=value, maximum_bits=bits, negative_nodes=neg))
    try:
        interpret(hw.nodes, {"n": 3}, node)
    except UnsafeInteger:
        refused = True
    else:
        raise AssertionError("Expected n=3 to exceed the declared safe cap")
    x, y, z = sp.symbols("audit_x audit_y audit_z")
    packing_checks = []
    for variables, equations, t, w in [([x], [x+1], 1, 1),
                                       ([x], [x], 1, 1),
                                       ([x], [x-1], 3, 3),
                                       ([x, y], [x-y], 2, 2)]:
        dag = producer.DAG()
        result, _ = producer.count_zero(dag, equations, variables, z, 0,
                                        dag.const(2), {}, dag.const(t), dag.const(w))
        packed, _, _ = interpret(dag.nodes, {}, dag.annotations["packed"])
        import itertools
        expected = 0
        zeros = 0
        for digits in itertools.product(range(t), repeat=len(variables)):
            substitution = dict(zip(variables, digits))
            E = sum(int(eq.subs(substitution))**2 for eq in equations)
            assert 0 <= E < 2**w
            index = sum(digit * t**i for i, digit in enumerate(digits))
            expected += (2**w-1)*(2**w-E+1)*2**(2*w*index)
            zeros += E == 0
        assert packed == expected
        assert packed.bit_count() // w - t**len(variables) == zeros
        literal = None
        try:
            literal, max_bits, _ = interpret(dag.nodes, {}, result)
            assert literal == zeros
        except UnsafeInteger:
            max_bits = None
        packing_checks.append(dict(dimension=len(variables), t=t, w=w,
                                   zeros=zeros, packed_bits=packed.bit_length(),
                                   literal_count=literal, literal_maximum_bits=max_bits))
    assert packing_checks[0]["literal_count"] == 0
    assert packing_checks[1]["literal_count"] is None
    # Variable-base powers have an explicit natural base-two reduction.
    power_checks = 0
    for a in range(9):
        for b in range(7):
            Z = 2**((a+1)*(b+1))
            value = (2**((a+1)*(b+1)**2) // (Z-a)) % Z
            assert value == a**b
            # This is the different, more economical conversion actually used
            # by outer_spec.py, not just the earlier reciprocal alternative.
            ell = a*b+a+1
            assert 2**(ell*b) % (2**ell-a) == a**b
            power_checks += 1
    return dict(moment_checks=moment_checks, hamming=hamming,
                hamming_3_safely_refused=refused, packing_checks=packing_checks,
                base_two_power_reduction_checks=power_checks,
                actual_outer_power_reduction_checks=power_checks)


def graph_structure(path):
    graph = json.loads(Path(path).read_text())
    for index, node in enumerate(graph["nodes"]):
        assert node["op"] in ALLOWED
        if node["op"] not in ("input", "const"):
            assert len(node["args"]) == 2
            assert all(0 <= i < index for i in node["args"])
    result = dict(file=Path(path).name, nodes=len(graph["nodes"]),
                  operations=dict(Counter(n["op"] for n in graph["nodes"])),
                  outputs=graph["outputs"], evaluated=False,
                  sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())
    # Only input-free toy artifacts are eligible for literal evaluation.
    if not any(n["op"] == "input" for n in graph["nodes"]):
        try:
            literal = {name: interpret(graph["nodes"], {}, node)
                       for name, node in graph["outputs"].items()}
            result.update(evaluated=True, literal=literal)
        except UnsafeInteger:
            result["safely_refused"] = True
    return result


def sparse_audit():
    """Independent sparse packing checks, with native HW ONLY at a named boundary."""
    from itertools import product
    primitive = load_module("audit_sparse_dag", HERE / "arith_dag.py")
    sparse = load_module("audit_sparse_compiler", HERE / "sparse_count.py")

    class BoundaryDAG(primitive.DAG):
        def hamming_weight(self, value):
            self.audit_packed = value
            return self.input("AUDIT_NATIVE_HW")

    # term = coefficient, variable powers, exponential factors, parameter powers
    fixtures = [
        (2, 3, 6, {"2": 2, "p": 1},
         [[(1, ((0, 1),), (), ()), (1, (), ((1, "2", 1),), ()),
           (-3, (), (), ())],
          [(1, ((1, 1),), (), ()), (-1, (), (), (("p", 1),))]]),
        (2, 2, 4, {"2": 2, "3": 3},
         [[(1, (), ((0, "2", 1),), ()), (-1, (), ((1, "3", 1),), ())]]),
        (2, 3, 6, {"p": 2},
         [[(1, ((0, 1),), (), ()), (-1, ((1, 1),), (), (("p", 1),))],
          [(1, ((1, 1),), (), ()), (-1, (), (), ())]]),
        (1, 2, 1, {"2": 2, "3": 3, "6": 6},
         [[(1, (), ((0, "2", 1), (0, "3", 1)), ()),
           (-1, (), ((0, "6", 1),), ())]]),
    ]
    report = []
    for dimension, t, w, params, equations in fixtures:
        dag = BoundaryDAG()
        output, _ = sparse.compile_sparse_count(
            dag, equations, dimension, {p: dag.const(v) for p, v in params.items()},
            dag.const(t), dag.const(w))
        packed, _, _ = interpret(dag.nodes, {}, dag.audit_packed)
        direct_pack = zeros = 0
        for point in product(range(t), repeat=dimension):
            E = 0
            for equation in equations:
                value = 0
                for coefficient, poly, expo, pars in equation:
                    term = coefficient
                    for i, e in poly:
                        term *= point[i]**e
                    for i, base, e in expo:
                        term *= params[base]**(e*point[i])
                    for p, e in pars:
                        term *= params[p]**e
                    value += term
                E += value*value
            assert E < 2**w
            index = sum(x*t**i for i, x in enumerate(point))
            direct_pack += (2**w-1)*(2**w-E+1)*2**(2*w*index)
            zeros += E == 0
        assert packed == direct_pack
        got, bits, _ = interpret(dag.nodes, {"AUDIT_NATIVE_HW": packed.bit_count()}, output)
        assert got == zeros
        report.append(dict(dimension=dimension, t=t, zeros=zeros,
                           maximum_bits=bits, native_HW_boundary=True))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", action="append", default=[])
    args = parser.parse_args()
    report = dict(semantic=semantic_audit(), helpers=helper_audit(),
                  sparse=sparse_audit(),
                  graphs=[graph_structure(p) for p in args.graph],
                  bit_cap=BIT_CAP)
    print(json.dumps(report, indent=2))

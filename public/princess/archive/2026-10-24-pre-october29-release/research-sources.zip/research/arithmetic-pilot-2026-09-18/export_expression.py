"""Render the already-built FIXED graph as an acyclic list of expressions."""
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent

def render(source,target):
    data=json.loads(Path(source).read_text())
    lines=['# Fixed arithmetic expression; only the input b varies.',
           '# Domain b >= 2. Define L_1 = 0 in a separate fixed case.',
           '# Each x_i abbreviates its earlier arithmetic expression.',
           '# No recurrence, counting, search, or parameter-length loop is an operator.']
    for i,n in enumerate(data['nodes']):
        op=n['op']
        if op=='input':rhs=n['name']
        elif op=='const':rhs=str(n['value'])
        else:
            a,b=(f'x{j}' for j in n['args'])
            if op=='div':rhs=f'floor({a} / {b})'
            else:rhs=f'{a} '+{'add':'+','sub':'-','mul':'*','pow':'^'}[op]+f' {b}'
        lines.append(f'x{i} = {rhs}')
    for name,i in data['outputs'].items():lines.append(f'{name} = x{i}')
    Path(target).write_text('\n'.join(lines)+'\n')

if __name__=='__main__':
    render(HERE/'clock-duration.dag.json',HERE/'clock-duration.expr.txt')

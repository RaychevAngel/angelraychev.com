"""Build an actual fixed primitive expression for the whole clock L_b."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import time
from arith_dag import DAG
from outer_spec import build_outer_spec
from sparse_count import monotone_bounds,compile_sparse_count

HERE=Path(__file__).resolve().parent


def build_duration():
    spec=build_outer_spec();dag=DAG();one=dag.const(1);two=dag.const(2)
    b=dag.input('b');C=dag.mul(b,dag.sub(b,one));Q=dag.add(C,one)
    R=dag.mul(Q,Q);H=dag.mul(two,C);K=dag.pow(R,dag.add(H,one))
    parameters={'b':b,'C':C,'Q':Q,'R':R,'H':H,'K':K,'2':two}
    for name,definition in spec['extra_parameter_definitions'].items():
        exponent=definition['exponent']
        parameters[name]=dag.pow(two,b if exponent=='b' else dag.const(exponent))
    upper=monotone_bounds(dag,spec['converted_dag'].nodes,{'b':b,'X':K})
    # Every gate is <=its majorant, quotient witnesses <their divisor,
    # and all active-index witnesses are <K+H+C. All positive parameters
    # and fixed graph constants are also strictly below this t.
    t=dag.sum(upper+[K,H,C,Q,R,b,dag.const(10)]+list(parameters.values()))
    w=dag.mul(dag.const(100*(len(spec['equations'])+1)),dag.mul(t,t))
    out,info=compile_sparse_count(dag,spec['equations'],spec['dimension'],parameters,t,w)
    dag.outputs={'L_b':out}
    info.update({'domain':'b>=2; define L_1=0 separately',
        'meaning':'Full accepted minimum-budget corner clock duration.',
        'allowed_operators':['input','const','add','sub','mul','div','pow'],
        'proof_status':'Ordinary compositional proof with independent component audits; not Lean verified; no literal full-clock evaluation.',
        'converted_inner_nodes':len(spec['converted_dag'].nodes),
        'inner_sha256':hashlib.sha256((HERE/'clock-transition-count.dag.json').read_bytes()).hexdigest(),
        'cube_bound_node':t,'packing_width_node':w})
    return dag,info


if __name__=='__main__':
    started=time.monotonic()
    dag,info=build_duration()
    data=dag.export(HERE/'clock-duration.dag.json',info)
    counts=data['operation_counts']
    info.update({'nodes':len(dag.nodes),
        'arithmetic_operations':sum(v for k,v in counts.items() if k not in ('input','const')),
        'operation_counts':counts,'build_seconds':time.monotonic()-started,
        'sha256':hashlib.sha256((HERE/'clock-duration.dag.json').read_bytes()).hexdigest()})
    (HERE/'duration-build-summary.json').write_text(json.dumps(info,indent=2)+'\n')
    print(json.dumps(info,indent=2))

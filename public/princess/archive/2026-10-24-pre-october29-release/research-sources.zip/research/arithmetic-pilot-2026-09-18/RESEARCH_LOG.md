# Whole-clock arithmetic pilot

18 September 2026, 10:48–11:08 UTC. The user authorized twenty minutes
trying one of the exploratory ideas. Chosen target: turn the entire
minimum-budget corner clock into an actual fixed arithmetic expression.
This is a private research artifact, not a website/manuscript/Lean release.

## Result and precise scope

`clock-duration.dag.json` is a fixed acyclic list of 207,601 nodes,
including **204,107 arithmetic operations**, one input `b`, and constant
leaves. The only arithmetic operations are addition, subtraction,
multiplication, integer floor quotient, and natural exponentiation.
`clock-duration.expr.txt` renders the same list as literal named expressions.
No recurrence, sum, counting, Hamming-weight, minimization, root oracle, or
parameter-dependent loop occurs as an operation in either delivered list.

For b>=2 its output is the whole accepted corner-clock duration L_b.
Set L_1=0 separately. The accompanying ordinary proof proceeds through
unique bounded witnesses and two completely expanded arithmetic counting
layers. Its components and implementation have independent reviews in this
directory. This is not a Lean-verified theorem, and no literal full-clock
evaluation was attempted.

The input is the half-width parameter, not the rectangle's long side.
Combining this expression with the existing theorem in
`../../paper/sections/odd-minimum-budget.tex` gives, for every r>=1 and odd
n>=2r+1,

    T_(r+1)(2r+1,n)
      = 2(2r+1)n - 8r² + 4r + 4L_r - 4.

Here L_r is supplied by the fixed expression, rather than left as a
width-dependent recurrence. Conditional only on that existing ordinary
rectangle theorem, this removes the remaining fixed-operation numerical
obligation for the entire odd-by-odd minimum-budget family. It does not
prove new geometric lower bounds, solve other budget families, solve the
remaining even-area cases, or extend the physical-game Lean coverage.
The optimal inspections for this family are the already-established ones;
the pilot changes the numerical representation of their exact duration.

## Why this meets the literal numerical criterion

The generator ran once without receiving a numerical value of b. Its
output graph has the same vertices and edges for every b. A node abbreviates
an earlier arithmetic expression; recursive substitution produces one
fixed finite expression. The operation count above allows ordinary sharing
of previously calculated values. Even expanding every shared subexpression
into a tree leaves a fixed finite expression independent of b, though a
much larger one.

This is not a fast evaluation algorithm. The integer sizes become
astronomical. The stated project criterion counts numerical operations,
not bit complexity; these are separate assertions. No new bound on
intermediate integer size or practical evaluation time is claimed.

## Construction chronology and proof obligations

1. Implement the frozen clock's 23-variable, 18-equation relation. Initial
   conditions, adjacent-digit decompositions, roots, active flags, and
   slacks have unique witnesses. The clock reaches its target within 2C
   steps, C=b(b-1).
2. Expand its squared residual into 167 signed parameter monomials and
   compile the first count G(b,X). This produces a fixed 1,949-operation
   expression. G equals the horizon H exactly for the unique valid code X.
3. Replace variable-base powers in that expression by explicit base-two
   arithmetic. The resulting 2,953-node natural graph has unique gate
   witnesses. Quotients include a remainder and strict-remainder slack.
4. Require G=H and X<R^(H+1), and add seven witnesses identifying an index
   j<H whose encoded B_j<C. The resulting fixed system has 3,490 variables,
   3,210 equations, and 11,863 squared-residual monomials. Its number of
   solutions is L_b.
5. Build an explicit monotone majorant for every converted gate. This
   produces an outer cube bound depending only on b. A padded exponential
   bound controls the squared residual throughout that entire cube,
   including invalid assignments. Compile the outer count with all helpers
   expanded, producing the delivered expression.

The finite loops in the generator traverse these fixed equation and node
lists. They are construction machinery, not operations in the delivered
numerical expression. Both the source and its fully expanded product are
provided so this distinction can be checked.

## Attacks, checks, and limitations

- The Hamming-weight helper was rederived through binomial digit extraction,
  a gcd digit count with a controlled fractional tail, and a valuation
  identity. The source's first-geometric-moment typo was corrected by an
  independent differentiation derivation.
- Every primitive denominator is positive on the stated domain. Moment
  numerators and packed-count differences are nonnegative. The converted
  graph therefore needs only natural witnesses.
- Independent semantic checks cover valid histories for b=2 through 10,
  2,416 single-digit mutations, and 1,840 perturbations of witness values.
  These checks support, but do not replace, the uniqueness argument.
- The fully expanded Hamming helper was literally evaluated only at inputs
  1 and 2. A complete zero-free count toy was evaluated with its largest
  intermediate below 405,000 bits. Positive-count toys and the full clock
  were not literally evaluated; the guard refuses such enormous powers.
- The generic sparse packing identity was independently compared with
  direct finite sums on small mixed-exponential fixtures. Graph checks
  verify the allowed operation set, acyclic dependencies, and fixed counts.
- The correctness claim is compositional mathematics plus implementation
  audits. It is not a full end-to-end numerical run, a Lean proof, or a
  newly published classification.

See `full-clock-proof.md`, `clock-spec-proof.md`, `helpers_review.md`,
`outer-bound-review.md`, and `independent_review.md` for the exact arguments
and remaining evidence boundaries. `duration-build-summary.json` contains
the actual graph counts and hash.

## Provenance and attribution

The arithmetic representation and block-counting machinery comes from
Mazzanti and Marchenkov, with later explicit presentations including
Prunescu, Sauras-Altuzarra, Istrate, and Shunia. These general methods are
not claimed as new. The clock specification, application, fixed expression
artifact, bounds, and audits are this project's work. The existing
rectangle theorem and its provenance remain those of the manuscript.

Primary references:

- Marchenkov, *Superpositions of elementary arithmetic functions*, 2006
  Russian / 2007 English: <https://www.mathnet.ru/eng/da10>.
- Mazzanti, *Plain Bases for Classes of Primitive Recursive Functions*,
  2002: <https://doi.org/10.1002/1521-3870(200201)48:1%3C93::AID-MALQ93%3E3.0.CO;2-8>.
- Istrate, Prunescu, Shunia, 2026 construction reference, with the corrected
  helper noted above: <https://arxiv.org/html/2606.09336v1>.

## Reproduce without evaluating giant integers

Use Python with the pinned SymPy version in `requirements.txt`. From this
directory, run `build_clock.py`, then `build_duration.py`, then
`export_expression.py`. The first two construct symbolic expression lists;
they do not evaluate those lists at b.

Run `verify_helpers.py` and `independent_checker.py` for the bounded
checks. The latter accepts repeated `--graph FILE` arguments for structural
audits of the exported graphs. Never disable its integer-size guard to
attempt a full clock evaluation.

## Next work, not undertaken by this bounded pilot

The next verification task is formalizing the generic arithmetic-counting
lemma and its compiler interpretation, followed by the unique-clock witness
relation. A separate presentation decision is how to integrate a long
explicit expression into the paper without confusing it with a concise
geometric formula. Applying the construction to other scalar clocks or the
full finite-state game is a separate research step; this artifact does not
silently perform either extension.

"""Fixed sparse second-layer compilation; no dense symbolic polynomial."""
from collections import defaultdict,Counter


def merge_degrees(a,b):
    out=defaultdict(int)
    for v,e in a+b:out[v]+=e
    return tuple(sorted((v,e) for v,e in out.items() if e))


def merge_exponents(a,b):
    out=defaultdict(int)
    for v,base,e in a+b:out[v,base]+=e
    return tuple(sorted((v,base,e) for (v,base),e in out.items() if e))


def sum_of_squares(equations):
    out=defaultdict(int)
    for equation in equations:
        for i,(ca,pa,ea,aa) in enumerate(equation):
            for j in range(i,len(equation)):
                cb,pb,eb,ab=equation[j]
                key=(merge_degrees(pa,pb),merge_exponents(ea,eb),merge_degrees(aa,ab))
                out[key]+=ca*cb*(1 if i==j else 2)
    return [(c,*key) for key,c in sorted(out.items()) if c]


def compile_sparse_count(dag,equations,dimension,parameters,t,w):
    terms=sum_of_squares(equations)
    one=dag.const(1);m=dag.pow(dag.const(2),w);base=dag.mul(m,m)
    total=dag.pow(t,dag.const(dimension))
    baseline=dag.div(dag.sub(dag.pow(base,total),one),dag.sub(base,one))
    powers={}
    def power(i):
        if i not in powers:powers[i]=dag.pow(base,dag.pow(t,dag.const(i)))
        return powers[i]
    positive=[];negative=[];supports=Counter();maxdegree=0
    for coefficient,poly,exponent,params in terms:
        degrees=dict(poly);bases=defaultdict(list)
        for i,name,e in exponent:bases[i].append((name,e))
        support=sorted(set(degrees)|set(bases));supports[len(support)]+=1
        maxdegree=max(maxdegree,max(degrees.values(),default=0))
        coefficient_node=dag.product([dag.const(abs(coefficient))]+[
            dag.pow(parameters[name],dag.const(e)) for name,e in params])
        old=[];new=[]
        for i in support:
            qi=power(i);old.append(dag.moment(0,qi,t))
            for name,e in bases[i]:
                qi=dag.mul(qi,dag.pow(parameters[name],dag.const(e)))
            new.append(dag.moment(degrees.get(i,0),qi,t))
        monomial=dag.mul(coefficient_node,
            dag.mul(dag.div(baseline,dag.product(old)),dag.product(new)))
        (positive if coefficient>0 else negative).append(monomial)
    bracket=dag.sub(dag.add(dag.mul(dag.add(m,one),baseline),dag.sum(negative)),dag.sum(positive))
    packed=dag.mul(dag.sub(m,one),bracket)
    out=dag.sub(dag.div(dag.hamming_weight(packed),w),total)
    return out,{'equations':len(equations),'dimension':dimension,
        'monomials':len(terms),'maximum_individual_degree':maxdegree,
        'support_histogram':dict(supports)}


def monotone_bounds(target,source_nodes,input_bounds):
    """Upper bound EVERY natural gate output; assumes positive divisors."""
    upper=[]
    for node in source_nodes:
        op=node['op']
        if op=='input':u=input_bounds[node['name']]
        elif op=='const':u=target.const(node['value'])
        else:
            a,b=(upper[i] for i in node['args'])
            if op=='add':u=target.add(a,b)
            elif op=='sub':u=a
            elif op=='mul':u=target.mul(a,b)
            elif op=='div':u=a
            elif op=='pow':
                # a+1>=1 makes the bound monotone even if a might equal0.
                u=target.pow(target.add(a,target.const(1)),b)
            else:raise ValueError(op)
        upper.append(u)
    return upper

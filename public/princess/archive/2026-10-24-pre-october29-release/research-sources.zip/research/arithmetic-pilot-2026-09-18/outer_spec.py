"""Fixed sparse graph of the whole-clock active-index count.

No huge integers are evaluated.  Construction consumes the fixed first-count
DAG and emits a fixed list of unsquared equations with unique natural
witnesses.  Every term has the agreed format

    (coefficient, poly, expo, params)

where poly=((variable_index,degree),...),
expo=((variable_index,base_name,degree),...), and
params=((parameter_name,degree),...).  The counting compiler squares these
equations locally.  Exponential bases are '2' and 'R'.
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from arith_dag import DAG


HERE = Path(__file__).resolve().parent


def convert_to_base_two(data: dict[str, Any]) -> tuple[DAG, dict[int, int]]:
    """Expand every non-base-two power, preserving only natural intermediates.

    a^e = 2^((ae+a+1)e) mod (2^(ae+a+1)-a).
    Squaring is more economically represented by a*a.
    """
    dag = DAG()
    mapping: dict[int, int] = {}
    one, two = dag.const(1), dag.const(2)
    for i, node in enumerate(data["nodes"]):
        op = node["op"]
        if op == "input":
            new = dag.input(node["name"])
        elif op == "const":
            if node["value"] < 0:
                raise ValueError("This natural graph requires nonnegative constants")
            new = dag.const(node["value"])
        else:
            a, e = (mapping[j] for j in node["args"])
            if op != "pow":
                new = dag.op(op, a, e)
            elif dag.nodes[a].get("value") == 2:
                new = dag.pow(two, e)
            elif dag.nodes[e].get("value") == 2:
                new = dag.mul(a, a)
            else:
                ell = dag.sum([dag.mul(a, e), a, one])
                modulus = dag.sub(dag.pow(two, ell), a)
                numerator = dag.pow(two, dag.mul(ell, e))
                new = dag.rem(numerator, modulus)
        mapping[i] = new
    dag.outputs = {name: mapping[i] for name, i in data["outputs"].items()}
    return dag, mapping


def _canonical(items):
    result = {}
    for key, degree in items:
        if degree:
            result[key] = result.get(key, 0) + degree
    return tuple(sorted(result.items()))


def _term(coeff=1, poly=(), expo=(), params=()):
    pd = _canonical(poly)
    ed = _canonical((((i, base), degree) for i, base, degree in expo))
    ed = tuple((i, base, degree) for (i, base), degree in ed)
    return int(coeff), pd, ed, _canonical(params)


def _add(*expressions):
    out = {}
    for expression in expressions:
        for coefficient, poly, expo, params in expression:
            key = poly, expo, params
            out[key] = out.get(key, 0) + coefficient
    return [(c, *key) for key, c in sorted(out.items()) if c]


def _neg(expression):
    return [(-c, p, e, a) for c, p, e, a in expression]


def _mul(left, right):
    terms = []
    for c, p, e, a in left:
        for cc, pp, ee, aa in right:
            terms.append(_term(c * cc, p + pp, e + ee, a + aa))
    return _add(terms)


def _const(value):
    return [] if value == 0 else [_term(value)]


def _param(name):
    return [_term(params=((name, 1),))]


def _variable(index):
    return [_term(poly=((index, 1),))]


def _exp(index, base):
    return [_term(expo=((index, base, 1),))]


def build_outer_spec(path: str | Path | None = None) -> dict[str, Any]:
    path = Path(path) if path else HERE / "clock-transition-count.dag.json"
    data = json.loads(path.read_text())
    dag, source_mapping = convert_to_base_two(data)
    variable_names: list[str] = []
    gate_variables: dict[int, int] = {}
    gate_values: dict[int, list] = {}
    auxiliary_bounds: dict[int, dict[str, Any]] = {}
    equations: list[list] = []

    def allocate(name):
        index = len(variable_names)
        variable_names.append(name)
        return index

    X_index = allocate("X")
    X = _variable(X_index)
    one = _const(1)
    for i, node in enumerate(dag.nodes):
        op = node["op"]
        if op == "const":
            gate_values[i] = _const(node["value"])
            continue
        if op == "input":
            if node["name"] == "X":
                gate_values[i] = X
                gate_variables[i] = X_index
            elif node["name"] == "b":
                gate_values[i] = _param("b")
            else:
                raise ValueError(("Unexpected first-count input", node))
            continue

        index = allocate(f"g{i}")
        gate_variables[i] = index
        c = _variable(index)
        gate_values[i] = c
        left_id, right_id = node["args"]
        a, b = gate_values[left_id], gate_values[right_id]
        if op == "add":
            equations.append(_add(c, _neg(a), _neg(b)))
        elif op == "sub":
            # All first-count intermediates are proved nonnegative on its
            # domain.  This equality therefore uses no branch/free witness.
            equations.append(_add(c, _neg(a), b))
        elif op == "mul":
            equations.append(_add(c, _neg(_mul(a, b))))
        elif op == "div":
            rem_i = allocate(f"rem{i}")
            slack_i = allocate(f"rem_slack{i}")
            rem, slack = _variable(rem_i), _variable(slack_i)
            equations.append(_add(a, _neg(_mul(b, c)), _neg(rem)))
            equations.append(_add(b, _neg(rem), _neg(slack), _neg(one)))
            for aux in (rem_i, slack_i):
                auxiliary_bounds[aux] = {"kind": "less_than_gate",
                                         "node": right_id}
        elif op == "pow":
            if dag.nodes[left_id].get("value") != 2:
                raise AssertionError("A variable-base power escaped conversion")
            if right_id in gate_variables:
                exponent = _exp(gate_variables[right_id], "2")
            elif dag.nodes[right_id]["op"] == "const":
                # A constant power is already an allowed fixed positive
                # coefficient.  Avoid materializing it by exposing its value
                # as a fixed external parameter constant.
                name = f"pow2_const_{dag.nodes[right_id]['value']}"
                exponent = _param(name)
            elif dag.nodes[right_id].get("name") == "b":
                exponent = _param("pow2_b")
            else:
                raise AssertionError(("Unrepresented exponent", right_id))
            equations.append(_add(c, _neg(exponent)))
        else:
            raise ValueError(("Unknown arithmetic operation", op))

    G_node = dag.outputs["valid_transition_count"]
    equations.append(_add(gate_values[G_node], _neg(_param("H"))))
    code_slack = allocate("code_bound_slack")
    equations.append(_add(X, _variable(code_slack), one, _neg(_param("K"))))
    auxiliary_bounds[code_slack] = {"kind": "less_than_parameter", "name": "K"}

    active = {name: allocate(f"active_{name}")
              for name in ("j", "d", "ell", "eta", "sj", "sd", "sell")}
    j, d, ell, eta, sj, sd, sell = (_variable(active[name])
                                   for name in ("j", "d", "ell", "eta", "sj", "sd", "sell"))
    Rj = _exp(active["j"], "R")
    QRj = _mul(_param("Q"), Rj)
    equations.extend([
        _add(X, _neg(ell), _neg(_mul(QRj, _add(d, _mul(_param("Q"), eta))))),
        _add(ell, sell, one, _neg(QRj)),
        _add(j, sj, one, _neg(_param("H"))),
        _add(d, sd, one, _neg(_param("C"))),
    ])
    for name, index in active.items():
        auxiliary_bounds[index] = {"kind": "less_than_parameter_sum",
                                    "names": ["K", "H", "C"]}

    parameter_names = sorted(
        {name for equation in equations for _, _, _, params in equation
         for name, _ in params}
        | {base for equation in equations for _, _, expo, _ in equation
           for _, base, _ in expo if not base.isdigit()})
    extra_parameters = {}
    for name in parameter_names:
        if name.startswith("pow2_const_"):
            extra_parameters[name] = {"op": "pow", "base": 2,
                                      "exponent": int(name[len("pow2_const_"):])}
        elif name == "pow2_b":
            extra_parameters[name] = {"op": "pow", "base": 2, "exponent": "b"}
    return {
        "dimension": len(variable_names),
        "variables": variable_names,
        "equations": equations,
        "gate_variables": gate_variables,
        "converted_dag": dag,
        "source_mapping": source_mapping,
        "X_index": X_index,
        "active_indices": active,
        "output_gate": G_node,
        "auxiliary_bounds": auxiliary_bounds,
        "parameters": parameter_names,
        "extra_parameter_definitions": extra_parameters,
        "parameter_relations": {"C": "b*(b-1)", "Q": "C+1", "R": "Q^2",
                                 "H": "2*C", "K": "R^(H+1)"},
        "domain": "b>=2; all counted variables are nonnegative integers",
        "meaning": "The total number of solutions is the full clock L_b, given a cube containing every gate and auxiliary witness.",
    }


def summary(spec):
    return {
        "dimension": spec["dimension"],
        "equations": len(spec["equations"]),
        "unsquared_terms": sum(map(len, spec["equations"])),
        "largest_equation_terms": max(map(len, spec["equations"])),
        "converted_gate_nodes": len(spec["converted_dag"].nodes),
        "converted_gate_operations": dict(Counter(n["op"] for n in spec["converted_dag"].nodes)),
        "parameters": spec["parameters"],
        "extra_parameter_definitions": spec["extra_parameter_definitions"],
    }


if __name__ == "__main__":
    print(json.dumps(summary(build_outer_spec()), indent=2))

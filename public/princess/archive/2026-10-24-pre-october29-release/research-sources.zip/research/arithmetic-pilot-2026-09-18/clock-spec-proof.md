# Whole-clock local specification: proof and validation

18 September 2026. This document describes the implemented symbolic
specification in `clock_spec.py`. The completed bounded-operation expression
for L_b is proved separately in `full-clock-proof.md`. The iterative
Python reference functions are diagnostics, not substitutes for that
expression.

## Interface and representation

`build_spec()` returns exactly 23 counted variables in the order

    j,A,B,Ap,Bp,h,e,u,v,su,tu,sv,tv,ell,eta,
    dA,dB,dAp,dBp,dell,dj,dX,zeta.

It has parameters b,X,C,m,Q,R,H, related by

    b>=2, X>=0,
    C=b(b-1), m=b+1, Q=C+1, R=Q², H=2C.

The extra symbol z represents R^j and is **not** another counted
variable. Expand the sum of squares as a polynomial in the 23 variables
and z. A monomial z^e is then interpreted as R^(e*j). Thus exponential
dependence is attached to counted coordinate zero, j, while the number
of counted variables remains 23. The largest z-degree is two and every
polynomial counted-variable degree is at most four. Input parameters
remain coefficients and can be expanded into signed sums of nonnegative
parameter monomials as needed by the arithmetic compiler.

The module also returns the parameter relations, cube bound t and
packing width w as symbolic expressions. The compiler must instantiate
the parameter relations; treating C,m,Q,R,H as independent inputs is
only an intermediate symbolic representation.

## The frozen clock and its horizon

Let q(z) be the least nonnegative u with z<=u(u+1), and let R_2(z) be
ceil(sqrt(z)). The accepted minimum-budget corner clock, before first
arrival at B=C, is

    F(B)=B+m-q(B+m),
    G(A)=A+m-R_2(A+m),
    (A,B) -> (F(B),G(A)).

Both original caps are redundant in this range. Indeed B<C implies
B+m<=b², hence q(B+m)<=b. Also A<=C implies A+m<=b²+1, hence
R_2(A+m)<=b+1=m. Therefore

    F(B)>=B+1  for 0<=B<C,
    G(A)>=A    for 0<=A<=C.

Each root function increases by at most one when its integer argument
increases by one, so F and G are nondecreasing on their ranges. At their
largest allowed inputs,

    F(C-1)=C,
    G(C)=C.

Thus an active transition stays in [0,C]². Freeze both coordinates when
B=C. Starting from (0,0), if neither of the next two transitions freezes,

    B_(t+2)=G(F(B_t))>=F(B_t)>=B_t+1.

If a freeze occurs sooner, the target has already been reached. Hence
the first arrival time L_b is at most H=2C. The frozen H+1-state history
is unique, and exactly L_b of its indices j in [0,H-1] have B_j<C.
The case b=1 has C=H=L_b=0 and is handled separately, not passed into
this specification.

## Local equations and unique witnesses

The first nine implemented equations are

    h(h-1)=0,
    (1-h)(C-B)=0,
    C-B-h-e=0,
    B+m-u(u-1)-1-su=0,
    u(u+1)-B-m-tu=0,
    A+m-(v-1)²-1-sv=0,
    v²-A-m-tv=0,
    Ap-A-h(B+m-u-A)=0,
    Bp-B-h(A+m-v-B)=0.

All counted variables are nonnegative integers. The first three force
h=1 when B<C and h=0 when B=C; e=C-B-h is then unique. They allow
no B>C. The next four equations express

    u(u-1)<B+m<=u(u+1),
    (v-1)²<A+m<=v².

The root inputs are strictly positive, so each has exactly one root
index u or v. Their four slacks are uniquely determined. The last two
equations then determine Ap,Bp and express exactly the active or frozen
transition. In particular, root witnesses are still fixed at a frozen
state; they do not become free variables.

## Packed-code equations and why G=H is decisive

A history is represented in base R by

    X = sum_(i=0)^H (A_i+Q B_i) R^i.

This is the semantic definition of the code; the final numerical term
will not use a parameter-length sum.

The remaining nine implemented equations are

    X-ell-z(A+Q B+R(Ap+Q Bp+R eta))=0,
    A+dA-Q+1=0,
    B+dB-Q+1=0,
    Ap+dAp-Q+1=0,
    Bp+dBp-Q+1=0,
    ell+dell+1-z=0,
    j+dj-H+1=0,
    X+dX+1-R^(H+1)=0,
    X-R zeta=0,

where z=R^j. Their consequences are:

1. Exactly 0<=j<H is allowed, with unique dj.
2. Exactly 0<=X<R^(H+1) is allowed, with unique dX.
3. The initial base-R digit is zero, because R divides X. Since its
   two base-Q components are nonnegative and less than Q, both initial
   coordinates are zero. zeta=X/R is unique.
4. The four digit equations make A,B,Ap,Bp elements of [0,Q-1]=[0,C].
   The remainder equation makes 0<=ell<R^j. Consequently the packed
   equation gives the unique adjacent base-R digits and unique upper
   quotient eta. All four digit slacks and dell are unique.

These statements include j=0, when ell=dell=0, and j=H-1, when eta=0.
For every b,X and j there is therefore at most one full witness tuple.
Let G(b,X) count the solutions of all 18 equations. Then G<=H. Equality
means all H indexed transitions are valid, so deterministic induction
from the forced initial zero pair proves that X is the unique true
frozen history code. Conversely that code contributes one witness for
every index, so its count is H. Codes with extra high digits or a wrong
initial pair contribute zero, not a competing full count.

## Explicit cube and exponent bounds

The supplied cube bound is

    t=X+R^(H+1)+(Q+m+1)²+H+2.

Every solution variable is strictly below t:

- j and dj are below H; all four state digits and their slacks are
  below Q.
- u,v are at most Q+m. The root slacks are below (Q+m+1)².
- h<=1 and e<=C. The lower and upper code pieces ell,eta and zeta
  are at most X.
- dell<R^H and dX<R^(H+1).

Thus counting only in [0,t-1]^23 loses no solution. This remains valid
for invalid X, since it is a statement about any tuple satisfying the
equations, and invalid codes can also have no such tuple.

Let E be the sum of squares of the equations after z=R^j. On the entire
cube, each parameter C,m,Q,R,H,X is below t. The largest unsquared
equation is the packed-code equation, whose absolute value is bounded
by 9t^(t+4). This bound also dominates each other equation. Therefore

    0<=E<=18*(9t^(t+4))²<1701*t^(2t+8)<2^(10t²).

For the last inequality use log_2(t)<=t, log_2(1701)<11, and
11+2t²+8t<=10t² for t>=2. Here t is much larger than two. Hence
`packing_width = 10*t**2` supplies a valid strict bound E<2^w even
on nonsolutions. The extra formal symbol z does not receive an
independent cube bound: its value is exactly R^j.

## What is implemented and what remains

Implemented:

- the symbolic equations and their intended parameter substitutions;
- the explicit cube and packing-width bounds;
- a unique-witness constructor for diagnostic comparison;
- reference history and count evaluators, clearly labeled iterative;
- a small self-test against every symbolic equation.

The arithmetic compiler is separate. It must expand the fixed
counting expression, including the geometric moments and Hamming
weight. The final second count selecting G=H and counting active
indices also remains separate. This specification alone is not the
fixed-operation expression for L_b and does not change public theorem
or Lean-coverage claims.

## Validation receipt

Run with SymPy 1.14 in the task-local interpreter:

    /tmp/princess-arithmetic-pilot-20260918/bin/python clock_spec.py

Result:

    23 counted variables; 18 equations;
    130 coalesced monomials in the formal-z polynomial;
    56 genuine witnesses checked against all symbolic equations;
    1,816 single-base-Q-digit mutations rejected;
    b=2: H=4,L=2; b=3: H=12,L=5; b=5: H=40,L=12.

Witness coordinates were also checked against the strict cube bound.
Wrong high-code digits were rejected. The calculation took less than
one second and constructed no hypercube-packing integers. It validates
the specification against the direct semantics; uniqueness and the
uniform bounds are supported by the ordinary proof above rather than
finite testing alone.

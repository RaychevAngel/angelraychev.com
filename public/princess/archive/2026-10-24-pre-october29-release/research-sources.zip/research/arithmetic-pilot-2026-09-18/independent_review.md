# Independent review of the arithmetic clock construction

18 September 2026. This review first audits the actual 23-variable relation and generated first-count arithmetic DAG, then audits the outer duration DAG completed during the same pilot. The final section records acceptance of the completed expression for \(L_b\) at the ordinary compositional-proof level. No huge packed clock-count integer was evaluated, and neither expression is Lean verified.

## Result and artifact identity

The reviewed first-count artifact is a fixed straight-line arithmetic program for \(G(b,X)\), for all \(b\ge2,X\ge0\). It contains 1,975 nodes, of which 1,949 are arithmetic operations. Its only operation types are addition, subtraction, multiplication, floor quotient, and natural exponentiation; leaves are constants and the two inputs. No Hamming-weight, recurrence, moment, minimization, root, or counting operation remains as a node.

The claimed interpretation is accepted at the ordinary-proof and compositional-code-review level: \(G(b,X)\) counts the valid transitions of the candidate frozen clock history, and \(G(b,X)=H\) holds for exactly one code \(X\). This is a statement about \(G\), not an already extracted numerical value of \(L_b\). There is no Lean verification in this pilot.

The reviewed JSON SHA-256 is `2e2d67d11dd768f1c61a6730c3d41af9647ceab0d09d2f477b01cf73b3fe31a1`. The corresponding reviewed source hashes are:

- `clock_spec.py`: `ed9838e2f0c3cc6099e29a755c1c5a7a0bc96a53f966ce5dcbc39dbad3db8178`;
- `arith_dag.py`: `41e0dc0ba7928597cb34bc38e62d2ed9489cb52ec1e38daa9f3cee57c713fdd0`;
- `build_clock.py`: `1fbf271332dd56b6154a7afd092f0e1f911249f6ac5265ab46d2de9fa38a0627`.

## Independent semantic proof checks

Put \(C=b(b-1),m=b+1,Q=C+1,R=Q^2,H=2C\). The frozen recurrence remains in \([0,C]^2\). Before the stopping value \(B=C\), its pronic index satisfies \(u\le b\), and its square index satisfies \(v\le b+1\). Hence

\[
A_{t+1}\ge B_t+1,\qquad B_{t+1}\ge A_t.
\]

Every two active steps therefore increase \(B\) by at least one. This independently proves arrival at \(C\) by \(H=2C\), provided the interval is invariant.

For that invariant, the pronic input is at most \(b^2\). If it exceeds \(C\), its index is exactly \(b\), so its output is at most \(b^2-b=C\); below \(C\), subtraction cannot exceed \(C\). The square input is at most \(b^2+1\). Above \(C\) and at most \(b^2\) its square index is \(b\); at \(b^2+1\) it is \(b+1\). Both cases again give output at most \(C\). Nonnegativity follows immediately from the defining root inequalities. Freezing preserves these bounds. The special value \(b=1\) remains a separate fixed case.

The 18 equations in `clock_spec.py` match the written relation. The first three force exactly one flag and slack: \(h=1,e=C-B-1\) for \(B<C\), and \(h=e=0\) for \(B=C\). They admit no value above \(C\). The pronic intervals

\[
u(u-1)+1\le B+m\le u(u+1)
\]

partition the positive integers, as do the square intervals

\[
(v-1)^2+1\le A+m\le v^2.
\]

Thus both roots and all four root slacks are unique, including at frozen steps. The next coordinates are then uniquely forced.

The packing equation, remainder bound, and four base-\(Q\) digit bounds give the unique adjacent digit pairs for each \(j\). The global equation \(X=R\zeta\) enforces the initial zero pair. The code bound removes arbitrary high digits. At \(j=0\) the lower remainder is zero; at \(j=H-1\) the upper quotient is zero. Every slack is uniquely determined. Consequently each index contributes at most one solution, and there are exactly \(H\) available indices. Equality \(G=H\) forces the unique deterministic history from the zero start.

The proposed cube bound contains every possible solution witness, including for invalid candidate codes: all digit/root/slack bounds are explicit, while remainder, quotient, and code slacks are dominated by \(X+R^{H+1}\). The coarse squared-sum bound \(E<2^{10t^2}\) is valid on the **entire** cube, not merely its zero set. This distinction is essential for the block-counting proof.

The second count's proposed extraction equation also has the right meaning:

\[
X=\ell+QR^j(d+Q\eta),\qquad 0\le\ell<QR^j
\]

extracts exactly the digit \(d=B_j\). The slack \(d+s_d=C-1\) selects precisely \(B_j<C\). On the unique frozen history the selected indices are exactly \(0,\ldots,L_b-1\). This accepts the **semantic design** of the second count; it does not assert that its graph or its final arithmetic expression has been built.

## Review of the generated first-count compiler

The code-limit parameter \(R^{H+1}\) is lifted to its own symbolic coefficient before polynomial expansion. This is necessary: treating both \(R\) and \(H\) as ordinary polynomial generators would fail on \(R^H\). `build_clock.py` performs this lifting and binds the coefficient to an actual power node, so it introduces no oracle input.

After expansion there are 167 parameter-expanded monomials in a fixed dimension of 23. Their support sizes are at most three. The compiler's sparse baseline factorization is exact:

\[
\prod_{i=0}^{22}\sum_{x=0}^{t-1}B^{t^i x}
=\frac{B^{t^{23}}-1}{B-1}.
\]

Dividing out selected baseline factors is exact because they are literally a subproduct of the baseline. Replacing each with its appropriate fixed-degree moment factors gives the weighted sum of that monomial. A power \(R^{ej}\) is incorporated by multiplying the geometric base for the index coordinate by \(R^e\). This accounts for all exponential dependence on a counted variable.

The moment routine is the fixed symbolic result of applying \(q\,d/dq\) at most four times to the finite geometric expression. This differentiation occurs during construction of a fixed graph, not during evaluation on \(b,X\). Each denominator is a positive power of \(q-1\), since every geometric base is at least two. The entire grouped numerator is nonnegative and the quotient is exact.

For \(M=2^w\), every block \((M-1)(M-E+1)\) lies in \([0,M^2-1]\), has weight \(2w\) at \(E=0\), and weight \(w\) otherwise. Blocks cannot overlap or carry. The packed value is positive. Thus the final Hamming helper is always called on its stated positive domain, and dividing its result by \(w\) is exact.

The Hamming helper has a finite expansion: it extracts \(\binom{2n}{n}\) as a base digit, uses the explicit geometric-series gcd term, and extracts the resulting power-of-two valuation by modular arithmetic. The identity \(\nu_2\binom{2n}{n}=\operatorname{HW}(n)\) supplies its interpretation. The helper proofs are separately written in `helpers_review.md`; the independent checker uses ordinary sums and integer bit counts only as finite audit oracles.

All subtractions in the current first graph are nonnegative on its stated input domain. This follows from the parameter inequalities, the grouped moment identities, ordinary remainder identities, and the nonnegative packed block sum. Merely inspecting nonnegative constants would not prove this; the compositional domain arguments are needed. All divisors are positive. Exponents are natural. Therefore a later natural-variable graph translation need not introduce signed variables for this particular first graph, provided it preserves these grouped operations.

## Independent finite checks

The independently written `independent_checker.py` does not call the producer's reference recurrence, witness constructor, count evaluator, or DAG interpreter. It constructs the reference history through increasing root trials, substitutes its witnesses into the actual symbolic equation list, and interprets primitive graph nodes itself with a one-million-bit guard.

Its completed checks are:

- 660 complete 18-equation witnesses for \(2\le b\le10\), all inside the stated witness cube;
- rejection of all 2,416 single base-\(Q\)-digit mutations for \(b=2,3,4,5\);
- rejection of 1,840 individual witness-coordinate increments on those four parameters;
- 660 independent checks of the proposed active-index digit extraction;
- 90 literal primitive-DAG moment evaluations for degrees zero through four;
- literal fully expanded Hamming evaluations at inputs one and two;
- four independent packing checks, including one- and two-dimensional cubes;
- 63 checks of the variable-base to base-two power reduction below;
- structural verification of the first-count JSON and both toy JSON graphs.

The exported zero-free toy was evaluated **end to end using only its primitive nodes**, returning zero and reaching a maximum intermediate size of 404,796 bits. Positive-count toy graphs were checked through their packed stage and against ordinary bit counts, but their literal Hamming expansion exceeded the declared safe cap and was stopped **before** constructing the large power. The entire clock-count DAG was not numerically evaluated at any \(b,X\). Its correctness claim is compositional, not a claim of completed huge-integer experimentation.

Observed clock values for \(b=2,\ldots,10\) are \(2,5,8,12,15,20,24,30,35\). The independently packed history code at \(b=2\) is 59004. These are diagnostics, not the eventual operation-count evaluator for \(L_b\).

## Outer-count checklist used during the review

1. Generate the unique-witness graph for every first-count node. For a floor quotient use \(a=dq+r\) and \(d=r+1+s\), which simultaneously enforce the correct remainder and a positive divisor. Ordinary subtraction can use its polynomial graph only because its valid outputs have been proved nonnegative.
2. Replace variable-base powers before applying a simple exponential-polynomial counter. For natural \(a,b\), let \(Z=2^{(a+1)(b+1)}\). Then

   \[
   a^b=\operatorname{Rem}\left(
      \left\lfloor\frac{2^{(a+1)(b+1)^2}}{Z-a}\right\rfloor,Z\right).
   \]

   Polynomial division gives the finite geometric sum plus remainder \(a^{b+1}/(Z-a)<1\), so the formula is valid, including \(0^0=1\). Multiplication gates can name the polynomial exponents, leaving only base-two exponentials in the graph.
3. Supply a positive common majorant for every graph witness. Raw monotonicity of \(a^b\) in both arguments fails at \(0^0\). Make every gate bound at least one, or use \((U_a+1)^{U_b+1}\), to avoid that exceptional case.
4. Generalize the counting compiler from one exponential coordinate to the finite list arising from all power gates. The same sparse factorization applies, but this extension is an actual implementation and audit obligation.
5. Generate the second fixed arithmetic DAG and review its complete expansion, magnitude bounds, uniqueness, and operation count. Only then can this pilot deliver the intended expression for \(L_b\).

These were actual construction obligations, rather than permission to hide an algorithm in a new helper. The following addendum audits their implementation.

## Completed outer-count audit

The generated `clock-duration.dag.json` has SHA-256 `bbb6c3a146d090d2bda91fd17042ea9e52bbe7f6b722c90ae4aba8514b9f6a36`. The independent structural checker finds 207,601 nodes and 204,107 arithmetic operations: 14,944 subtractions, 97,691 multiplications, 48,250 additions, 21,806 powers, and 21,416 floor quotients. Its only input is \(b\). Every edge points to an earlier node, and every operation belongs to the permitted list. Its output is labeled `L_b`. The dimension of the outer count is the fixed constant 3,490, with 3,210 equations and 11,863 squared-sum monomials. These counts do not depend on \(b\).

The implementation uses a different, more economical power conversion than the reciprocal formula above. With \(a,e\ge0\), set \(\ell=ae+a+1\). Then

\[
a^e=\operatorname{Rem}(2^{\ell e},2^\ell-a).
\]

Indeed \(2^\ell\equiv a\pmod{2^\ell-a}\), and \(a^e<2^\ell-a\). The latter is immediate at \(a=0\); for positive \(a\), use \(2^{ae}\ge a^e\) and \(2^{a+1}\ge a+2\). The case \(e=0\), including \(0^0=1\), is valid. The actual conversion was independently tested on all 63 pairs \(0\le a\le8,0\le e\le6\). All resulting power gates have base two, and the remainder expansion uses only a positive divisor and a nonnegative subtraction.

`outer_spec.py` assigns one natural output variable to each nonconstant arithmetic gate, and exactly one remainder and strict-remainder slack to each quotient. Constants and the parameter \(b\) are not free witnesses. Topological induction over the acyclic graph proves uniqueness of every gate output. The equation for the first count's output enforces \(G=H\), and an explicit code slack enforces \(X<K=R^{H+1}\). The seven active-index variables have exactly the previously checked digit semantics. Therefore there is one solution for each active index in the unique valid clock history and no additional multiplicity: the zero count is \(L_b\).

The magnitude bound in `build_duration.py` is adequate. `monotone_bounds` bounds powers by \((U_a+1)^{U_e}\), so the \(0^0\) exception cannot invalidate monotonicity. Every quotient output is bounded by its numerator; each remainder and its slack is below the positive divisor. The cube side \(t\) exceeds the sum of all these gate bounds, all positive parameter values, \(K,H,C,Q,R,b\), and a positive fixed margin. The active-index and code witnesses are strictly below the included \(K+H+C\) bound. Thus the cube contains every solution witness.

The outer squared-sum bound also holds on the entire cube. All variables and parameter values are below \(t\). Each unsquared graph equation is polynomial of bounded degree or contains one base-two exponential; the active-index equation contains the factor \(R^j\). A common crude bound is \(5t^{t+3}\) for each unsquared equation. For \(q=3210\) equations this gives

\[
E_2\le25q\,t^{2t+6}<2^{100(q+1)t^2},\qquad t\ge2.
\]

The implementation's packing width is exactly the safe exponent on the right. No parameter-dependent search for a witness bound is present.

The sparse counter merges polynomial degrees and exponential factors coordinate by coordinate, then applies the same baseline and fixed-degree moments already audited for the first count. The largest individual polynomial degree is four. I additionally checked four independently specified tiny fixtures covering two exponential coordinates, two exponential bases on one coordinate, parameter coefficients, polynomial products, and identically zero equations. Their sparse packed integers match literal cube enumeration exactly. These four tests deliberately use native Hamming weight **only at an explicitly named validation boundary**; they are not represented as full primitive evaluations. The actual exported zero-free toy remains the separate fully expanded end-to-end test.

The complete receipt is `independent-review.json`; it records both artifact hashes, all primitive counts, semantic tests, four sparse fixtures, successful zero-free literal evaluation, and safe rejection of oversized positive-count literal evaluation. No full clock-duration integer was constructed.

**Conclusion:** no gap was found in this two-count construction after the independent semantic, symbolic, structural, and bounded numerical audits. It supplies an actual fixed-operation expression for the accepted scalar clock \(L_b\), for \(b\ge2\), with the fixed case \(L_1=0\) added separately. This is an ordinary compositional proof and a concrete arithmetic DAG, not Lean verification and not practical bit-time evaluation. It does not by itself resolve any remaining geometric compatibility or strategy-construction problem for general rectangles.

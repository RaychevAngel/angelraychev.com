#!/usr/bin/env python3
"""Independent, bounded audit of fixed arithmetic helpers.

The term functions use only +, -, *, // and **. Validation uses ordinary
Python reference functions and finite loops; those are not claimed parts
of the arithmetic term. Literal Hamming-weight checks stop at n=2 because
n=3 would already require unreasonable intermediate integers.
"""

from math import comb, gcd
import json


def rem_term(x, d):
    return x - d * (x // d)


def binomial_term(a, b):
    base = 2**a
    return rem_term(((base + 1)**a) // (base**b), base)


def gcd_term(a, b):
    product = a*b
    base = 5**product
    quotient = (base**(product+a+b)) // ((base**a-1)*(base**b-1))
    return rem_term(quotient, base)-1


def valuation_from_gcd(n, g):
    modulus = 2**(n+1)-1
    return rem_term(g**(n+1), modulus**2) // modulus


def valuation_term(n):
    return valuation_from_gcd(n, gcd_term(n, 2**n))


def hamming_term(n):
    central = binomial_term(2*n, n)
    return valuation_term(central)


def moments_term(q, t):
    d = q-1
    z = q**t
    a2 = q+q**2
    a3 = q+4*q**2+q**3
    a4 = q+11*q**2+11*q**3+q**4
    numerators = (
        z-1,
        z*t*d+q-z*q,
        z*(t**2*d**2+a2)-(2*z*t*q*d+a2),
        z*(t**3*d**3+3*t*a2*d)+a3-z*(3*t**2*q*d**2+a3),
        z*(t**4*d**4+6*t**2*a2*d**2+a4)
        -(z*(4*t**3*q*d**3+4*t*a3*d)+a4),
    )
    return (
        numerators[0] // d,
        numerators[1] // d**2,
        numerators[2] // d**3,
        numerators[3] // d**4,
        numerators[4] // d**5,
    ), numerators


def main():
    counts = {}
    for a in range(1, 25):
        for b in range(a+1):
            assert binomial_term(a, b) == comb(a, b)
    counts['binomial_literal_checks'] = sum(a+1 for a in range(1, 25))

    # The requested small gcd audit is deliberately bounded at 4.
    for a in range(1, 5):
        for b in range(1, 5):
            assert gcd_term(a, b) == gcd(a, b)
    counts['gcd_literal_checks'] = 16

    # Verify the valuation extraction independently with the ordinary gcd.
    for n in range(1, 65):
        expected = (n & -n).bit_length()-1
        assert valuation_from_gcd(n, gcd(n, 2**n)) == expected
    counts['valuation_extraction_checks'] = 64

    # Complete literal composition; the largest nested gcd here is (6,64).
    for n in range(1, 7):
        assert valuation_term(n) == (n & -n).bit_length()-1
    counts['valuation_literal_checks'] = 6

    for n in (1, 2):
        assert hamming_term(n) == n.bit_count()
    counts['hamming_literal_checks'] = 2

    # Larger proof-component check, not a literal whole-term evaluation.
    for n in range(1, 129):
        c = binomial_term(2*n, n)
        assert (c & -c).bit_length()-1 == n.bit_count()
    counts['central_binomial_valuation_checks'] = 128

    for q in range(2, 18):
        for t in range(1, 19):
            values, numerators = moments_term(q, t)
            for e in range(5):
                assert numerators[e] >= 0
                assert rem_term(numerators[e], (q-1)**(e+1)) == 0
                assert values[e] == sum(j**e*q**j for j in range(t))
    counts['geometric_moment_checks'] = 16*18*5

    # Explicitly exhibit the known first-moment typo at the smallest input.
    q = 2
    inclusive_end = 0
    wrong_numerator = (inclusive_end*q**(inclusive_end+2)
                       -(inclusive_end+1)*q**(inclusive_end+1)+1)
    assert wrong_numerator == -1
    assert moments_term(2, 1)[0][1] == 0
    counts['all_passed'] = True
    print(json.dumps(counts, indent=2))


if __name__ == '__main__':
    main()

# Independent audit of the arithmetic helpers

18 September 2026. This note supplies explicit fixed arithmetic expressions for the Hamming-weight helper on positive integers and the five geometric moments needed by the clock pilot. All macros below have a fixed finite expansion using only `+`, `-`, `*`, integer floor quotient, and exponentiation. The proofs use sums and factorials as mathematical explanations; they do not introduce such operations into the expressions.

The audit is independent of the main clock DAG. No full packed clock was evaluated here. Source orientation: the displayed helpers in [Istrate, Prunescu, Shunia, Section 3](https://arxiv.org/html/2606.09336v1#S3) suggest the construction. The proofs and the grouped moment expressions below are rederived here rather than relying on that display. The published display's first-moment constant is wrong, as noted explicitly below.

## 1. Remainder as an allowed expression

For integers `x>=0`, `d>=1`, define

\[
\operatorname{Rem}(x,d)=x-d\left\lfloor x/d\right\rfloor.
\]

This macro is three allowed arithmetic operations, its result lies in `[0,d-1]`, and every use below has a positive denominator. No remainder atom is necessary in the final expression.

## 2. Binomial digit extraction

For integers `a>=1` and `0<=b<=a`, put `B=2^a` and

\[
\operatorname{Bin}(a,b)=
\operatorname{Rem}\left(
 \left\lfloor\frac{(B+1)^a}{B^b}\right\rfloor,B\right).
\]

Then `Bin(a,b)=binomial(a,b)`.

**Proof.** In the binomial expansion of `(1+B)^a`, every coefficient is a nonnegative integer strictly smaller than `B`: each is at most the sum `2^a`, and at least two coefficients are positive. Thus this expansion is its base-`B` digit expansion with no carries. Quotient by `B^b` discards lower digits, and remainder modulo `B` selects the coefficient at position `b`.

The condition `a>=1` is essential for this particular displayed term; do not extend it silently to `a=0`, where its base is 1. In the intended Hamming-weight call `a=2n>=2`, so the condition is automatic.

## 3. A positive-input gcd expression and proof

For `a,b>=1`, put `m=ab`, `B=5^m`, and

\[
\operatorname{GcdTerm}(a,b)=
\operatorname{Rem}\left(
 \left\lfloor
 \frac{B^{m+a+b}}{(B^a-1)(B^b-1)}
 \right\rfloor,B\right)-1.
\]

Then `GcdTerm(a,b)=gcd(a,b)`. Both denominator factors are positive. The final subtraction is nonnegative; indeed the selected digit is at least 2.

**Proof, including the carry and fractional-tail checks.** Since `B>1`,

\[
\frac{B^{m+a+b}}{(B^a-1)(B^b-1)}
 =\sum_{u,v\ge0}B^{m-au-bv}.
\]

The part with `au+bv<=m` is an integer polynomial in `B`. Every coefficient is at most `m+1<B`, so its base-`B` digits have no carries. For the tail with `au+bv=m+ell`, `ell>=1`, there are at most `m+ell+1` pairs. Thus the tail is at most

\[
\frac{m+1}{B-1}+\frac{B}{(B-1)^2}
 \le\frac12+\frac5{16}<1.
\]

Here `5^m>=5m`, so `B-1>=4m`; also `B>=5` and `x/(x-1)^2` decreases for `x>1`. Consequently taking the floor discards exactly the fractional tail, without adding a carry to the units digit.

The units digit counts nonnegative solutions of `au+bv=ab`. If `g=gcd(a,b)`, coprimality after division by `g` gives exactly

\[
(u,v)=((b/g)j,(a/g)(g-j)),\qquad j=0,\ldots,g.
\]

There are `g+1` solutions. Selecting that digit and subtracting 1 gives `g`.

The base 5 avoids small exceptions; replacing it by 2 without an extra branch is invalid at `a=b=1`. The proof here does not require such a replacement, since general powers are allowed.

## 4. The 2-adic valuation

For `n>=1`, put

\[
g=\operatorname{GcdTerm}(n,2^n),\qquad M=2^{n+1}-1,
\]

and define

\[
V(n)=\left\lfloor
 \frac{\operatorname{Rem}(g^{n+1},M^2)}M
\right\rfloor.
\]

Then `V(n)=nu_2(n)`.

**Proof.** Write `v=nu_2(n)`. Since `v<=n`, `g=gcd(n,2^n)=2^v`. Hence

\[
g^{n+1}=2^{v(n+1)}=(M+1)^v
 \equiv1+vM\pmod{M^2}.
\]

For `n>=1`, `v<=n<=M-2`, so `0<=1+vM<M^2`; this is the actual remainder. Division by `M` and floor gives `v`. In particular, odd inputs have remainder 1 and valuation 0. Zero is outside the domain throughout.

## 5. Fully expanded Hamming-weight recipe

For `n>=1`, the following acyclic list is an explicit standard-operation term. Each named line is substituted into later lines, rather than treated as a new primitive:

\[
\begin{aligned}
B&=2^{2n},\\
X&=\left\lfloor (B+1)^{2n}/B^n\right\rfloor,\\
C&=X-B\left\lfloor X/B\right\rfloor,\\
A&=2^C,\\
Q&=5^{CA},\\
Y&=\left\lfloor
 Q^{CA+C+A}/((Q^C-1)(Q^A-1))
 \right\rfloor,\\
g&=Y-Q\left\lfloor Y/Q\right\rfloor-1,\\
M&=2^{C+1}-1,\\
Z&=g^{C+1},\\
\operatorname{HWTerm}(n)&=
\left\lfloor
 \frac{Z-M^2\left\lfloor Z/M^2\right\rfloor}{M}
\right\rfloor.
\end{aligned}
\]

All bases, exponents, and denominators in this list are nonnegative as required, and all denominators are positive. Intermediate integers are enormous; this is an operation-count statement, not a practical bit-complexity bound.

The first three lines give `C=binomial(2n,n)>0`; the next four give `g=gcd(C,2^C)`; the final three give `nu_2(C)`. Finally,

\[
\nu_2\binom{2n}{n}=\operatorname{HW}(n).
\]

For completeness, counting the even factors of a factorial gives `nu_2(N!)=N-HW(N)`: expand `N` into its binary digits and sum the contributions of each digit to the floor counts. Therefore the central binomial valuation is `2HW(n)-HW(2n)=HW(n)`.

This proof uses no assumption about which bits of the eventual packed input are set. Thus the recipe applies to the positive packed integers used by the counting construction. If a different caller permits input 0, it must provide its own zero branch or use a separately proved extension; the present pilot states `n>=1`.

## 6. Geometric moments through degree four

The required convention is

\[
G_e(q,t-1)=\sum_{j=0}^{t-1}j^e q^j,
\qquad q\ge2,\quad t\ge1,\quad e\in\{0,1,2,3,4\},
\]

with `j^0=1` also at `j=0`. Put

\[
d=q-1,\qquad z=q^t,\qquad
A_2=q+q^2,\quad A_3=q+4q^2+q^3,\quad
A_4=q+11q^2+11q^3+q^4.
\]

The five fixed expressions are

\[
G_0=\frac{z-1}{d},
\]

\[
G_1=\frac{ztd+q-zq}{d^2},
\]

\[
G_2=\frac{z(t^2d^2+A_2)-(2ztqd+A_2)}{d^3},
\]

\[
G_3=\frac{z(t^3d^3+3tA_2d)+A_3
 -z(3t^2qd^2+A_3)}{d^4},
\]

\[
G_4=\frac{z(t^4d^4+6t^2A_2d^2+A_4)
 -(z(4t^3qd^3+4tA_3d)+A_4)}{d^5}.
\]

Each quotient is exact and may therefore be implemented by floor quotient. Each entire numerator is nonnegative. The grouping displayed above is intentional: form the whole positive part and the whole negative part first, then subtract. This avoids negative intermediates and is also valid if the implementation uses truncated subtraction. All denominator powers are positive because `q>=2`.

**Derivation.** Start with the finite geometric identity `(q^t-1)/(q-1)` and apply the operator `q*d/dq` successively, treating `t` as constant. Applying it to each summand multiplies that summand by its exponent `j`. Four differentiations give exactly the displayed expressions. This is a derivation of five fixed formulas; differentiation is not an operation in the delivered arithmetic term. Alternatively, expansion verifies the base values at `t=1` and the five identities `G_e(q,t)-G_e(q,t-1)=t^e q^t`, which prove the formulas by induction.

**Source correction.** With an inclusive end index `s`, the correct first moment is

\[
\sum_{j=0}^{s}j q^j
=\frac{s q^{s+2}-(s+1)q^{s+1}+q}{(q-1)^2}.
\]

The source display has final constant `1` instead of `q`. At `q=2,s=0` it gives `-1` instead of zero, so this is an actual formula error, not a change of convention. The displayed second-moment formula agrees with the rederived expression.

## 7. Bounded verification and limits

Run `python3 research/arithmetic-pilot-2026-09-18/verify_helpers.py` from the project root. It checks:

- binomial terms for `1<=a<=24` and all `0<=b<=a`;
- the literal gcd term for `1<=a,b<=4`;
- valuation extraction for `1<=n<=64` using an independently computed gcd;
- the fully composed valuation term for `1<=n<=6`;
- the fully composed Hamming-weight term only for `n=1,2`;
- central-binomial valuations for `1<=n<=128`, using ordinary bit valuation solely as an audit oracle;
- all five moments for `2<=q<=17`, `1<=t<=18`, including nonnegative numerators and exact divisibility.

Literal Hamming-weight evaluation at `n=3` is deliberately omitted: the central binomial coefficient is already 20, and the nested gcd calls `(20,2^20)`, producing an unreasonable integer exponent. This is not a mathematical restriction of the expression. The ordinary proofs above supply the uniform correctness argument; finite tests serve only to detect transcription and boundary mistakes.

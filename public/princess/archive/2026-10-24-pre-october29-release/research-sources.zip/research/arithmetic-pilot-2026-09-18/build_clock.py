"""Build the fixed primitive graph for G(b,X), the clock history verifier."""
from pathlib import Path
import json
import sympy as s
from arith_dag import DAG,count_zero
from clock_spec import build_spec

HERE=Path(__file__).resolve().parent


def build_clock():
    spec=build_spec();dag=DAG();p=spec['parameters']
    env={p['b']:dag.input('b'),p['X']:dag.input('X')}
    for name in ('C','m','Q','R','H'):
        sym=p[name]
        env[sym]=dag.expr(spec['parameter_relations'][sym],env)
    limit=p['R']**(p['H']+1)
    cap=s.Symbol('code_limit',integer=True,positive=True)
    env[cap]=dag.expr(limit,env)
    equations=[eq.xreplace({limit:cap}) for eq in spec['equations']]
    t=dag.expr(spec['cube_bound'].xreplace({limit:cap}),env)
    w=dag.mul(dag.const(10),dag.mul(t,t))
    out,info=count_zero(dag,equations,spec['variables'],
        spec['exponential_symbol'],spec['exponential_coordinate'],
        env[p['R']],env,t,w)
    dag.outputs={'valid_transition_count':out}
    info.update({'domain':'b>=2, X>=0','meaning':'Number of valid indices in the bounded frozen-clock code X; equals H exactly for the unique valid code.',
        'component_scope':'This graph computes G(b,X), not L_b. The separate clock-duration.dag.json compiles the outer unique-history/active-index count.',
        'constants_nonnegative':all(n.get('value',0)>=0 for n in dag.nodes),
        'allowed_operators':['input','const','add','sub','mul','div','pow']})
    return dag,info


def build_toy():
    # E(x)=x^2 on {0,1}; exactly one zero. This positive-count instance
    # intentionally exceeds the literal Hamming helper's safe bit cap.
    dag=DAG();x,z=s.symbols('x z',integer=True,nonnegative=True)
    out,info=count_zero(dag,[x],[x],z,0,dag.const(2),{},dag.const(2),dag.const(1))
    dag.outputs={'zero_count':out}
    return dag,info


def build_zero_free_toy():
    # One cube point, E=1, packing width1: packed=2. This complete primitive
    # instance fits a bounded literal evaluator, including all HW helpers.
    dag=DAG();x,z=s.symbols('x z',integer=True,nonnegative=True)
    out,info=count_zero(dag,[s.Integer(1)],[x],z,0,dag.const(2),{},dag.const(1),dag.const(1))
    dag.outputs={'zero_count':out}
    return dag,info


if __name__=='__main__':
    dag,info=build_clock()
    data=dag.export(HERE/'clock-transition-count.dag.json',info)
    arithmetic=sum(v for k,v in data['operation_counts'].items() if k not in ('input','const'))
    summary={**info,'nodes':len(dag.nodes),'arithmetic_operations':arithmetic,
             'operation_counts':data['operation_counts']}
    (HERE/'build-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    toy,meta=build_toy();toy.export(HERE/'toy-count.dag.json',meta)
    toy,meta=build_zero_free_toy();toy.export(HERE/'zero-free-toy.dag.json',meta)
    print(json.dumps(summary,indent=2))

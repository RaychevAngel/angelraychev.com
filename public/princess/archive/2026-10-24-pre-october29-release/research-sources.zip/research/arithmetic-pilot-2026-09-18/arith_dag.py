"""Compile fixed sparse exponential-polynomial counts to primitive arithmetic.

Construction loops run once on a FIXED specification. Exported graphs contain
only input/constant leaves and +, -, *, floor quotient, and natural powers.
No runtime counting, Hamming-weight, moment, or optimization node is permitted.
"""
from collections import Counter
import json
from pathlib import Path
from functools import lru_cache
import sympy as s


@lru_cache(None)
def moment_polynomial(e):
    q,t,z=s.symbols('moment_q moment_t moment_z')
    p=z-1
    for j in range(e):
        deriv=q*s.diff(p,q)+t*z*s.diff(p,z)
        p=s.expand((q-1)*deriv-(j+1)*q*p)
    return (q,t,z),p


class DAG:
    def __init__(self):
        self.nodes = []
        self.index = {}
        self.outputs = {}
        self.annotations = {}
        self.moment_cache = {}

    def intern(self, key, node):
        if key not in self.index:
            self.index[key] = len(self.nodes)
            self.nodes.append(node)
        return self.index[key]

    def const(self, value):
        value = int(value)
        return self.intern(('const', value), {'op':'const', 'value':value})

    def input(self, name):
        return self.intern(('input',name), {'op':'input','name':name})

    def op(self, op, a, b):
        ca, cb = self.nodes[a], self.nodes[b]
        if op in ('add','mul') and b<a:
            a,b=b,a; ca,cb=cb,ca
        if op=='add':
            if ca.get('value')==0:return b
            if cb.get('value')==0:return a
        if op=='mul':
            if ca.get('value')==0 or cb.get('value')==0:return self.const(0)
            if ca.get('value')==1:return b
            if cb.get('value')==1:return a
        if op=='sub':
            if a==b:return self.const(0)
            if cb.get('value')==0:return a
        if op=='pow':
            if cb.get('value')==0:return self.const(1)
            if cb.get('value')==1:return a
        if op=='div' and cb.get('value')==1:return a
        # Never constant-fold enormous powers, even during construction.
        if ca['op']==cb['op']=='const' and op!='pow':
            x,y=ca['value'],cb['value']
            if op=='add':return self.const(x+y)
            if op=='sub':return self.const(x-y)
            if op=='mul':return self.const(x*y)
            if op=='div' and y:return self.const(x//y)
        return self.intern((op,a,b),{'op':op,'args':[a,b]})

    def add(self,a,b):return self.op('add',a,b)
    def sub(self,a,b):return self.op('sub',a,b)
    def mul(self,a,b):return self.op('mul',a,b)
    def div(self,a,b):return self.op('div',a,b)
    def pow(self,a,b):return self.op('pow',a,b)
    def rem(self,a,b):return self.sub(a,self.mul(b,self.div(a,b)))
    def sum(self,ids):
        out=self.const(0)
        for x in ids:out=self.add(out,x)
        return out
    def product(self,ids):
        out=self.const(1)
        for x in ids:out=self.mul(out,x)
        return out

    def expr(self,expr,env):
        expr=s.sympify(expr)
        if expr in env:return env[expr]
        if expr.is_Integer:return self.const(int(expr))
        if expr.is_Add:
            positive=[];negative=[]
            for x in expr.args:
                (negative if x.could_extract_minus_sign() else positive).append(
                    self.expr(-x if x.could_extract_minus_sign() else x,env))
            return self.sub(self.sum(positive),self.sum(negative))
        if expr.is_Mul:return self.product(self.expr(x,env) for x in expr.args)
        if expr.is_Pow:
            a,b=expr.args
            if b.is_Integer and b<0:
                raise ValueError('Rational subexpression must be compiled as one exact quotient')
            return self.pow(self.expr(a,env),self.expr(b,env))
        raise ValueError((expr,env))

    def signed_polynomial(self,expr,variables,env):
        """Nonnegative polynomial monomials split by integer coefficient sign."""
        positive=[];negative=[]
        for exponents,coefficient in s.Poly(s.expand(expr),*variables).terms():
            coefficient=int(coefficient)
            factors=[self.const(abs(coefficient))]
            factors += [self.pow(env[v],self.const(e)) for v,e in zip(variables,exponents) if e]
            (positive if coefficient>0 else negative).append(self.product(factors))
        return self.sub(self.sum(positive),self.sum(negative))

    def moment(self,e,q,t):
        """sum_(x=0)^(t-1) x^e q^x, expanded at compile time, e fixed."""
        assert 0<=e<=4
        key=(e,q,t)
        if key in self.moment_cache:return self.moment_cache[key]
        (qsym,tsym,zsym),p=moment_polynomial(e)
        num=self.signed_polynomial(p,[qsym,tsym,zsym],
            {qsym:q,tsym:t,zsym:self.pow(q,t)})
        den=self.pow(self.sub(q,self.const(1)),self.const(e+1))
        out=self.div(num,den)
        self.moment_cache[key]=out
        return out

    def hamming_weight(self,n):
        """Expanded classical positive-integer formula. Requires n>=1."""
        one=self.const(1);two=self.const(2)
        a=self.mul(two,n)
        base=self.pow(two,a)
        choose=self.rem(self.div(self.pow(self.add(base,one),a),
                                    self.pow(base,n)),base)
        b=self.pow(two,choose)
        ab=self.mul(choose,b)
        q=self.pow(self.const(5),ab)
        numerator=self.pow(q,self.sum([ab,choose,b]))
        denominator=self.mul(self.sub(self.pow(q,choose),one),
                             self.sub(self.pow(q,b),one))
        gcd=self.sub(self.rem(self.div(numerator,denominator),q),one)
        exp=self.add(choose,one)
        modulus=self.sub(self.pow(two,exp),one)
        return self.div(self.rem(self.pow(gcd,exp),self.mul(modulus,modulus)),modulus)

    def export(self,path,metadata=None):
        data={'format':'fixed-arithmetic-dag-v1','nodes':self.nodes,
              'outputs':self.outputs,'metadata':metadata or {},
              'operation_counts':dict(Counter(n['op'] for n in self.nodes))}
        Path(path).write_text(json.dumps(data,separators=(',',':'))+'\n')
        return data


def count_zero(dag,equations,variables,z,exp_coordinate,exp_base,env,t,w):
    """Return primitive DAG node counting zeros in [0,t-1]^d.

    z represents exp_base ** variables[exp_coordinate]. Requires the squared
    sum E to satisfy 0<=E<2**w throughout the entire cube; t>=1,w>=1.
    Coefficients may involve only positive parameter symbols in env.
    """
    total=s.expand(sum(eq**2 for eq in equations))
    params=sorted(total.free_symbols-set(variables)-{z},key=str)
    poly=s.Poly(total,*(variables+[z]+params))
    d=len(variables); one=dag.const(1);two=dag.const(2)
    m=dag.pow(two,w);base=dag.mul(m,m)
    td=dag.pow(t,dag.const(d))
    baseline=dag.div(dag.sub(dag.pow(base,td),one),dag.sub(base,one))
    powers=[dag.pow(base,dag.pow(t,dag.const(i))) for i in range(d)]
    positive=[];negative=[]
    support_hist=Counter()
    for exponents,coefficient in poly.terms():
        coeff=int(coefficient)
        if not coeff:continue
        degrees=exponents[:d];ze=exponents[d]
        pdegrees=exponents[d+1:]
        support=[i for i in range(d) if degrees[i] or (i==exp_coordinate and ze)]
        support_hist[len(support)]+=1
        factor=dag.product([dag.const(abs(coeff))]+[
            dag.pow(env[p],dag.const(e)) for p,e in zip(params,pdegrees) if e])
        old=[];new=[]
        for i in support:
            old.append(dag.moment(0,powers[i],t))
            q=powers[i]
            if i==exp_coordinate and ze:
                q=dag.mul(q,dag.pow(exp_base,dag.const(ze)))
            new.append(dag.moment(degrees[i],q,t))
        block=dag.mul(factor,dag.mul(dag.div(baseline,dag.product(old)),dag.product(new)))
        (positive if coeff>0 else negative).append(block)
    # Mpacked=(m-1)*((m+1)*baseline - weighted_sum(E)).
    pos=dag.add(dag.mul(dag.add(m,one),baseline),dag.sum(negative))
    nonnegative=dag.sub(pos,dag.sum(positive))
    packed=dag.mul(dag.sub(m,one),nonnegative)
    out=dag.sub(dag.div(dag.hamming_weight(packed),w),td)
    dag.annotations['packed']=packed
    return out,{'expanded_monomials':len(poly.terms()),'dimension':d,
                'support_histogram':dict(support_hist),
                'maximum_degree':max(max(e[:d]) for e,c in poly.terms())}


def evaluate(nodes,inputs,output=None,max_bits=1000000):
    """Guarded evaluator; refuses giant powers before constructing them."""
    values=[]
    for i,node in enumerate(nodes):
        op=node['op']
        if op=='input':v=inputs[node['name']]
        elif op=='const':v=node['value']
        else:
            a,b=(values[j] for j in node['args'])
            if op=='add':v=a+b
            elif op=='sub':v=a-b
            elif op=='mul':v=a*b
            elif op=='div':
                if b<=0:raise ArithmeticError(('nonpositive denominator',i,b))
                v=a//b
            elif op=='pow':
                if b<0:raise ArithmeticError(('negative exponent',i,b))
                if a not in (0,1,-1) and b*abs(a).bit_length()>max_bits:
                    raise OverflowError(('bit limit before power',i))
                v=pow(a,b)
            else:raise ValueError(op)
        if abs(v).bit_length()>max_bits:raise OverflowError(('bit limit',i))
        values.append(v)
        if output==i:return v
    return values

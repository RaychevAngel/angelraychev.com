# Independent review: sparse counting, natural intermediates, and outer bounds

18 September 2026. Reviewed the implemented `arith_dag.py`, `sparse_count.py`, `outer_spec.py`, `build_duration.py`, and the exported `clock-duration.dag.json` during the arithmetic pilot. This review supplies ordinary proofs, bounded component checks, and a static audit of the actual final graph. The full packed integers were not literally evaluated.

## 1. The first counting graph is natural on its stated domain

The input domain is `b>=2`, `X>=0`. The parameter definitions

```
C=b(b-1), m=b+1, Q=C+1, R=Q², H=2C,
t=X+R^(H+1)+(Q+m+1)²+H+2, w=10t²
```

give natural intermediates and strictly positive `Q,R,t,w`. In particular, the only subtraction in this parameter setup is `b-1`, which is positive.

The source local-equation proof supplies, on the entire counting cube, `0<=E(x)<M=2^w`. Let `B=M²`. For cube dimension `d`, the compiler's baseline is

\[
\mathcal B=\frac{B^{t^d}-1}{B-1}
 =\prod_{i=0}^{d-1}G_0(B^{t^i},t-1).
\]

This is the ordinary mixed-radix enumeration of all cube points. Every factor is a positive integer. Consequently `baseline // product(old)` in the sparse replacement step is an **exact integer quotient**: it removes precisely the zeroth-moment factors on the support of a monomial.

For a monomial, multiplication of a coordinate's geometric base by `R^e` incorporates the factor `R^(e*x_i)`. All resulting moment bases are at least `B>=4`. Polynomial coordinate degrees are at most four. The separately audited moment expressions therefore have nonnegative numerators and positive denominators. Their signed coefficients are assembled as a whole positive sum minus a whole negative sum, avoiding a negative partial sum.

Every monomial contribution to the weighted sum of `E` is nonnegative before its coefficient sign is applied. The compiler's single signed assembly is

\[
(M+1)\mathcal B+\text{negative-coefficient contributions}
 -\text{positive-coefficient contributions}
=\sum_x(M+1-E(x))B^{v(x)}.
\]

Since `E(x)<=M-1`, this is at least `2*baseline>0`. Thus the large subtraction in the counting graph is natural even when some coefficients of the expanded sum of squares are negative.

Multiplication by `M-1` produces the packed blocks

\[
\delta(E)=(M-1)(M-E+1).
\]

Each lies strictly between zero and `B`. At `E=0`, it equals `B-1`, with `2w` set bits. At `1<=E<M`, write

\[
\delta(E)=(M-E)M+(E-1).
\]

The two `w`-bit pieces are complementary, so their total bit count is `w`. There is no carry between the `2w`-bit blocks. The packed argument of the Hamming-weight helper is therefore **strictly positive**, including when there are no zeros of `E`. Its helper domain is satisfied. The final quotient by `w` is exact and equals `t^d + number_of_zeros`; subtracting `t^d` is natural.

This proves naturalness of every first-count intermediate, not only the output. Positive divisors come from moment bases greater than 1, products of positive zeroth moments, and the independently audited Hamming-weight expression. It applies to invalid history codes as well as the unique valid code: naturalness depends on the all-cube bound for `E`, not on `G=H`.

## 2. The generalized sparse compiler preserves this proof

In `sparse_count.py`, a monomial is represented by its signed coefficient, polynomial degrees, coordinate-indexed exponential factors, and ordinary parameter degrees. Squaring each equation produces diagonal products once and cross products twice. Merging polynomial and parameter degrees adds exponents; merging exponential factors adds their exponents for the same coordinate and base.

For coordinate `i`, a factor

\[
x_i^e\prod_s a_s^{h_s x_i}
\]

changes the zeroth-moment factor at `q_i=B^(t^i)` to

\[
G_e\left(q_i\prod_s a_s^{h_s},t-1\right).
\]

This is exactly what `compile_sparse_count` constructs. It permits several exponential coordinates and several bases on the same coordinate, as the outer graph requires. The former single-`z` restriction of the first compiler is absent. The same sparse baseline quotient and signed-assembly arguments from Section 1 apply.

Required conditions remain visible: every exponential base is at least 1; each individual polynomial degree is at most four; `t,w>=1`; and the chosen `w` bounds the entire squared polynomial on the full cube. These hold for the described outer gate system, whose exponential bases are 2 and `R`.

## 3. Lowering powers to base two is valid, including zero

For natural `a,e`, with `0^0=1`, put

\[
J=ae+a+1,\qquad D=2^J-a.
\]

Then `D>=2` and

\[
a^e=\operatorname{Rem}(2^{Je},D).
\]

Indeed `2^J` is congruent to `a` modulo `D`. For `a=0`, the claim follows separately for `e=0` and `e>0`. For `a>=1`, `a<=2^a`, whence

\[
a^e+a\le2^{ae}+2^a<2^{ae+a+1}=2^J.
\]

Thus `a^e<D`, so the congruence identifies the actual remainder. Also `J>=a+1` implies `D>=2^(a+1)-a>=2`. Every modulus and floor-division witness introduced by this transformation is well-defined. Squaring may instead be replaced directly by a multiplication, as implemented.

This is why `convert_to_base_two` can represent every original power gate by a fixed collection of natural gates without a special zero case.

## 4. Unique outer gate witnesses

For each natural arithmetic gate, `outer_spec.py` introduces its output as a counted variable and equations defining it:

- addition, multiplication, and known-nonnegative subtraction have their ordinary algebraic equalities;
- quotient `c=floor(a/b)` has `a=bc+r` and `b=r+s+1`, with natural `r,s`;
- a base-two power has `c=2^e`.

For a true graph evaluation, quotient denominators are positive, and the remainder/slack equations uniquely force `0<=r<b` and `s=b-r-1`. Conversely, if a purported denominator is zero, those equations have no natural solution. Induction through the acyclic graph proves that all gate and quotient witnesses are unique for each input pair `(b,X)`. Subtraction uses no free sign or branch witness because Section 1 and the power-lowering proof establish that its true result is natural.

The additional equation `G(b,X)=H`, together with the source local-specification theorem, therefore selects the unique frozen history code `X_b`. The explicit code bound `X+code_slack+1=K`, where `K=R^(H+1)`, introduces one uniquely determined slack and restricts `X<K`.

For the active-index query, the equations imply

\[
X=\ell+QR^j(d+Q\eta),\quad 0\le\ell<QR^j,
\quad0\le j<H,\quad0\le d<C.
\]

The code uses base-`Q` components `(A_j,B_j)`. Dividing by `QR^j` and taking the next base-`Q` digit gives `d=B_j` uniquely; `eta` is the remaining quotient. Hence exactly the indices with `B_j<C` contribute, each once. All seven active-query variables and all gate witnesses are fixed by `(X_b,j)`. Their count is `L_b`, provided the outer cube contains them.

## 5. A fixed arithmetic majorant for every witness

Apply `monotone_bounds` to the **converted** graph, after power lowering. Bounding only the original graph would miss the much larger intermediate numerators and moduli introduced by conversion.

For the converted input `X`, use upper bound `K`; for input `b`, use `b`; for a constant, use its nonnegative value. If `U_a,U_b` majorize two inputs, use

\[
\begin{array}{c|c}
\text{gate}&\text{upper bound}\\
a+b&U_a+U_b\\
ab&U_aU_b\\
a-b&U_a\\
\lfloor a/b\rfloor&U_a\\
a^b&(U_a+1)^{U_b}.
\end{array}
\]

The quotient row uses the already proved positive-denominator condition. The power row is safe when `U_a=0` or `b=0`: its base is at least 1, so exponent monotonicity is legitimate. Thus induction supplies a nonnegative bound for every converted gate output.

The actual `build_duration.py` takes

\[
t=\sum_i U_i+2(H+K+C+Q+R+b)+12.
\]

This equality expands the builder's list of 2,953 converted-node bounds, its explicit padding list, and its parameter dictionary, whose actual extra-parameter list is empty. It is a **fixed finite sum over the fixed exported graph**, so it is expanded into a fixed addition tree; it is not a parameter-length sum. Every gate output is strictly below `t`. Each quotient remainder and its slack is below its denominator, hence below the corresponding denominator bound and `t`. The code slack is below `K`.

For the active query, `j,s_j<H`, `d,s_d<C`, and `ell,sell<QR^j`. Since `j<H` and `Q<R`, `QR^j<R^H<K`. The upper quotient `eta` is at most `X<K`. Thus all counted witnesses lie in `[0,t-1]`.

The externally represented constants `pow2_const_c` and parameter `pow2_b` also lie below `t`: each occurs as the value of a converted power gate, whose majorant is included in the sum. They do not require an unmentioned independent bound. Likewise `m=b+1<t` even if it is not repeated separately in the displayed sum.

## 6. The actual outer packing width bounds the entire cube

There are `M=3210` unsquared outer equations in 3,490 counted variables. Let `E_2` be their sum of squares. All counted variables range over `[0,t-1]`. Every ordinary parameter or coefficient value occurring as a gate input is below `t` by Section 5. The exponential bases are 2 and `R`, both below `t` here, so any factor `base^x` is at most `t^t` on the entire cube.

An independent syntax audit of the actual equation list gives: at most four terms per equation; absolute coefficient at most 23; total polynomial-variable degree at most two per term; total ordinary-parameter degree at most two; and at most one exponential factor, of degree one, per term. These are independent maxima, so the following coarse bound avoids any need to correlate them. Since `b>=2`, already `K>=9^5=59049`, and hence `23<t`. Therefore every unsquared equation satisfies

\[
|F_i|\le4t^{t+5}.
\]

This is a bound on the original gate equations before expansion; coalescing coefficients while expanding their squares does not change it. Therefore

\[
0\le E_2\le16M t^{2t+10}.
\]

For `M>=1,t>=2`, using `log_2(t)<=t` and `log_2(M)<=M`,

\[
\log_2(16M t^{2t+10})
\le4+M+2t^2+10t
\le(M+8)t^2
<100(M+1)t^2.
\]

Here `10t<=5t²` and `4+M<=(M+1)t²`. Consequently the exact implemented width

\[
w=100(3210+1)t^2=321100t^2
\]

satisfies the required strict all-cube bound `E_2<2^w`. This controls nonsolutions too, which is essential for the Hamming-weight packing identity.

## 7. Independent checks of components and final delivery

A separate bounded audit evaluated the generalized sparse compiler on four two-coordinate equation systems, each at cube lengths 1, 2, and 3. The systems include two exponential bases on one coordinate, different exponential bases on different coordinates, mixed polynomial/exponential monomials, and ordinary parameter factors. Results:

- 56 pointwise comparisons of the sparse sum of squares against the original equations passed;
- 12 packed integers matched direct finite enumeration exactly;
- all 12 packed bit counts returned the direct zero count;
- 20 majorant comparisons, including zero bases and `0^0`, passed.

Only the packed integers were evaluated in these sparse tests. Hamming weight there used the ordinary bit-count audit oracle; the independently proved complete Hamming-weight term is covered separately by `helpers_review.md` and its literal tiny tests. No full outer integer was constructed.

The final graph was also independently read and checked. It contains 207,601 nodes: 3,493 nonnegative integer constants, one input `b`, and 204,107 arithmetic operations. Every operation is one of `add`, `sub`, `mul`, `div`, `pow`; each has two strictly earlier argument references. The only named output is `L_b`, pointing to the final node. The serialized operation counts match the node list. The metadata's inner-graph hash matches the actual first-count graph.

The reviewed final file has SHA-256

```
bbb6c3a146d090d2bda91fd17042ea9e52bbe7f6b722c90ae4aba8514b9f6a36
```

The actual builder wires the six parameters `b,C,Q,R,H,K`, the constant exponential base 2, the 3,490-variable outer system, and the 3,210-equation width multiplier into the generalized sparse compiler. Its bound nodes are 5250 for `t` and 5253 for `w`. No unexpanded Hamming-weight, geometric-moment, iteration, minimization, or counting operator appears in the export.

**Review conclusion.** The delivered graph is accepted as a fixed allowed-operation expression for `L_b` on `b>=2`, with `L_1=0` handled separately. The ordinary proof is compositional: the local clock specification characterizes the unique history; the normalized gate graph has unique natural witnesses; the active query counts exactly its unfinished indices; the explicit cube contains every witness and the width bounds all cube points; the audited sparse packing and expanded helpers return that count. No remaining mathematical gap was identified in this composition. This is not a claim of Lean verification or of literal evaluation of the enormous full expression, and does not itself prove a new geometric capture-time theorem.

"""Fixed local relation for the whole minimum-budget corner clock.

The public interface is ``build_spec``.  Its 23 counted variables and 18
equations are fixed independently of the clock parameter b.  R**j is
represented by the additional formal symbol z; z is NOT a counted variable.

The reference functions below are ordinary iterative diagnostic code.  They
are not claimed to be the bounded-operation arithmetic expression.
"""

from __future__ import annotations

from math import isqrt
from typing import Any

import sympy as sp


VARIABLE_NAMES = (
    "j", "A", "B", "Ap", "Bp", "h", "e", "u", "v",
    "su", "tu", "sv", "tv", "ell", "eta", "dA", "dB",
    "dAp", "dBp", "dell", "dj", "dX", "zeta",
)


def build_spec() -> dict[str, Any]:
    variables = list(sp.symbols(" ".join(VARIABLE_NAMES), integer=True,
                                nonnegative=True))
    (j, A, B, Ap, Bp, h, e, u, v, su, tu, sv, tv, ell, eta,
     dA, dB, dAp, dBp, dell, dj, dX, zeta) = variables
    parameters = dict(zip(
        ("b", "X", "C", "m", "Q", "R", "H"),
        sp.symbols("b X C m Q R H", integer=True, nonnegative=True),
    ))
    b, X, C, m, Q, R, H = parameters.values()
    z = sp.Symbol("z", integer=True, nonnegative=True)
    equations = [
        h * (h - 1),
        (1 - h) * (C - B),
        C - B - h - e,
        B + m - u * (u - 1) - 1 - su,
        u * (u + 1) - B - m - tu,
        A + m - (v - 1)**2 - 1 - sv,
        v**2 - A - m - tv,
        Ap - A - h * (B + m - u - A),
        Bp - B - h * (A + m - v - B),
        X - ell - z * (A + Q * B + R * (Ap + Q * Bp + R * eta)),
        A + dA - Q + 1,
        B + dB - Q + 1,
        Ap + dAp - Q + 1,
        Bp + dBp - Q + 1,
        ell + dell + 1 - z,
        j + dj - H + 1,
        X + dX + 1 - R**(H + 1),
        X - R * zeta,
    ]
    t = X + R**(H + 1) + (Q + m + 1)**2 + H + 2
    return {
        "variables": variables,
        "parameters": parameters,
        "exponential_symbol": z,
        "exponential_coordinate": 0,
        "exponential_base": R,
        "equations": equations,
        "parameter_relations": {
            C: b * (b - 1), m: b + 1, Q: C + 1,
            R: Q**2, H: 2 * C,
        },
        "cube_bound": t,
        "packing_width": 10 * t**2,
        "domain": "b >= 2, X >= 0; all counted variables nonnegative",
    }


def parameter_values(b: int, X: int = 0) -> dict[str, int]:
    if b < 2 or X < 0:
        raise ValueError("The nontrivial clock specification requires b>=2 and X>=0")
    C = b * (b - 1)
    Q = C + 1
    return {"b": b, "X": X, "C": C, "m": b + 1,
            "Q": Q, "R": Q * Q, "H": 2 * C}


def pronic_ceiling(z: int) -> int:
    """Least nonnegative u satisfying z <= u(u+1), for positive z."""
    if z <= 0:
        raise ValueError("This local relation has strictly positive root inputs")
    u = (isqrt(4 * z + 1) - 1) // 2
    return u + (u * (u + 1) < z)


def square_ceiling(z: int) -> int:
    if z <= 0:
        raise ValueError("This local relation has strictly positive root inputs")
    v = isqrt(z)
    return v + (v * v < z)


def reference_step(b: int, A: int, B: int) -> tuple[int, int]:
    p = parameter_values(b)
    C, m = p["C"], p["m"]
    if not (0 <= A <= C and 0 <= B <= C):
        raise ValueError("Frozen clock coordinates must lie in [0,C]")
    if B == C:
        return A, B
    return B + m - pronic_ceiling(B + m), A + m - square_ceiling(A + m)


def reference_history(b: int) -> list[tuple[int, int]]:
    p = parameter_values(b)
    history = [(0, 0)]
    for _ in range(p["H"]):
        history.append(reference_step(b, *history[-1]))
    if history[-1][1] != p["C"]:
        raise AssertionError("The accepted 2C clock bound failed")
    return history


def encode_history(b: int, history: list[tuple[int, int]]) -> int:
    p = parameter_values(b)
    if len(history) != p["H"] + 1:
        raise ValueError("Expected exactly H+1 pairs")
    X = 0
    for A, B in reversed(history):
        if not (0 <= A < p["Q"] and 0 <= B < p["Q"]):
            raise ValueError("A history digit lies outside the packing base")
        X = X * p["R"] + A + p["Q"] * B
    return X


def construct_witness(b: int, X: int, j: int) -> dict[str, int] | None:
    """Return the unique local witness, or None when the queried step fails.

    This is a semantic reference evaluator, not the arithmetic count term.
    """
    p = parameter_values(b, X)
    C, m, Q, R, H = (p[k] for k in ("C", "m", "Q", "R", "H"))
    if j < 0 or j >= H or X >= R**(H + 1) or X % R:
        return None
    z = R**j
    ell = X % z
    current = (X // z) % R
    following = (X // (z * R)) % R
    A, B = current % Q, current // Q
    Ap, Bp = following % Q, following // Q
    h = int(B < C)
    u, v = pronic_ceiling(B + m), square_ceiling(A + m)
    if (Ap, Bp) != (A + h * (B + m - u - A),
                    B + h * (A + m - v - B)):
        return None
    witness = {
        "j": j, "A": A, "B": B, "Ap": Ap, "Bp": Bp,
        "h": h, "e": C - B - h, "u": u, "v": v,
        "su": B + m - u * (u - 1) - 1,
        "tu": u * (u + 1) - B - m,
        "sv": A + m - (v - 1)**2 - 1,
        "tv": v * v - A - m,
        "ell": ell, "eta": X // (z * R * R),
        "dA": Q - 1 - A, "dB": Q - 1 - B,
        "dAp": Q - 1 - Ap, "dBp": Q - 1 - Bp,
        "dell": z - ell - 1, "dj": H - 1 - j,
        "dX": R**(H + 1) - X - 1, "zeta": X // R,
    }
    if min(witness.values()) < 0:
        raise AssertionError("A purported witness has a negative coordinate")
    return witness


def reference_count(b: int, X: int) -> int:
    return sum(construct_witness(b, X, j) is not None
               for j in range(parameter_values(b)["H"]))


def _self_test() -> dict[str, Any]:
    spec = build_spec()
    variables = spec["variables"]
    parameters = spec["parameters"]
    z = spec["exponential_symbol"]
    assert len(variables) == 23 and len(spec["equations"]) == 18
    expanded = sp.Poly(sp.expand(sum(eq**2 for eq in spec["equations"])),
                       *variables, z)
    assert max(sum(powers[:-1]) for powers, _ in expanded.terms()) <= 4
    assert max(powers[-1] for powers, _ in expanded.terms()) <= 2
    evaluate = sp.lambdify([*variables, *parameters.values(), z],
                          spec["equations"], modules="math", cse=True)
    checked_witnesses = checked_mutations = 0
    examples = []
    for b in (2, 3, 5):
        history = reference_history(b)
        X = encode_history(b, history)
        p = parameter_values(b, X)
        t = X + p["R"]**(p["H"] + 1) + (p["Q"] + p["m"] + 1)**2 + p["H"] + 2
        assert reference_count(b, X) == p["H"]
        for j in range(p["H"]):
            witness = construct_witness(b, X, j)
            assert witness is not None and max(witness.values()) < t
            values = evaluate(*[witness[str(v)] for v in variables],
                              *[p[name] for name in parameters], p["R"]**j)
            assert all(value == 0 for value in values), values
            checked_witnesses += 1
        for index in range(2 * (p["H"] + 1)):
            place = p["Q"]**index
            digit = X // place % p["Q"]
            for changed in range(p["Q"]):
                if changed == digit:
                    continue
                assert reference_count(b, X + (changed - digit) * place) < p["H"]
                checked_mutations += 1
        assert reference_count(b, X + p["R"]**(p["H"] + 1)) == 0
        examples.append({"b": b, "H": p["H"],
                         "L": sum(B < p["C"] for A, B in history[:-1])})
    return {"variables": len(variables), "equations": len(spec["equations"]),
            "coalesced_monomials": len(expanded.terms()),
            "witnesses_checked": checked_witnesses,
            "single_digit_mutations_rejected": checked_mutations,
            "examples": examples}


if __name__ == "__main__":
    import json
    print(json.dumps(_self_test(), indent=2))

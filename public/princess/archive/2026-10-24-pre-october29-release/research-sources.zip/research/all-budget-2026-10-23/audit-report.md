# General-budget bound audit

23 October 2026. Read-only reuse and finite evaluation of existing bounds,
plus independent verification of the newly proposed paired-lens evaluator.
No manuscript, public page, or Lean source was changed by this audit lane.

## What is being compared

The efficient lower bound available at every even-area input is the accepted
critical three-corner necessary-model recurrence, including its half-budget
central-day test (`bridge_corner_frontier.step`). It is a physical lower
bound via the existing guarded-merger argument. Model witnesses are not
physical strategies.

The baseline upper is the best of the two anchored physical prefix clocks,
with the ordinary palindrome or its permitted shared last inspection. The
even-width and odd-width physical erosion formulas evaluate these clocks.
The upper is a construction, not an unrestricted strategy optimum.

Stronger components have different scopes. The nine-feature erosion model
is available for odd width and even length. Persistent geometric-radius
models further improve selected cases. The direct balanced corner change
works at minimum budget on every even width at least ten, but does not
always improve an anchored prefix. General reflected-prefix search and
transport/shape changes supply additional certified physical uppers.

Therefore a large gap between one pair of named algorithms is a diagnostic,
not necessarily the strongest known mathematical bracket at that input.

## Broad baseline scan

`audit_named_bounds.json` retains 3,416 cases. Widths are every integer from
4 through 40, then 48,49,64,65,80,81,100,101,128,129. Lengths include w,w+1,
w+2,w+3,2w,2w+1,4w,4w+1 when the area is even. Budgets concentrate on
the first ten feasible values, about 3w/4, w-1,w,w+1 and ceil(13w/10).
The serial run used 43.735 CPU seconds.

The counts by gap are 0:1844, 1:903, 2:410, 3:181, 4:62, 5:8, 7:8.
The seven-day named-baseline gaps occur at width31/budget16 and
width129/budget65 in this sample. The first is largely an artifact of the
weaker lower model: nine-feature erosion closes the square-adjacent case.

Every sampled input with k>=w has gap at most one. This supports the
existing conjectured larger one-day range; it does not prove that range.
Near the feasibility budget the chosen generic algorithms can differ by
more than two, and this difference persists across several sampled lengths.
Neither fact proves that the true optimum stays far from a better lower
bound, or that the gap is uniformly bounded as width grows.

## Stronger components and representative physical replay

The nine-feature scan (`audit_nine_nearsquare.json`) checks 312 inputs:
odd widths 5..41 and 49,65,81,101,129, two near-square even lengths, and
several budgets from feasibility to w. After taking the maximum of the
three-corner and nine-feature lowers, the largest sampled gap is four:

- 81x82,k41: 1603 <= T <= 1607.
- 129x130,k65: 2799 <= T <= 2803, improved from 2796 <= T.
- 31x32,k16: the nine-feature lower and physical upper both equal495.

These figures do not incorporate every more specialized radius/lens theorem.
For example the generic models leave372..375 at25x26,k13, while the
accepted all-length25-row theorem gives375 exactly.

The balanced arithmetic evaluator was checked against the original literal
construction on24x24,24x25 and28x28. It is deliberately combined with the
fixed-anchor upper by a minimum. At128x128,k65 the fixed prefix gives1905,
while the balanced corner-change upper gives1907; the former is better.
The corresponding three-corner lower is1900. This is a useful unresolved
diagnostic, not a claim that no stronger lower exists.

Seven full physical witnesses were independently replayed by room-set
updates:24x24,k13;24x25,k13;28x28,k15;28x29,k15;31x32,k16;
38x39,k21;49x50,k25. Their complete inspections are retained in the
`audit_witness_*` JSON files. Allowing arbitrary reflected-prefix switches
does not improve the anchored upper on these seven cases.

### Correction to the previous24-row odd-length status

The24x25,k13 witness captures in231 days. Combined with the already proved
uniform lower24n-370, this gives230..231 at that input, improving the
previously quoted230..232 bracket. The231-day schedule was replayed in the
physical full-board game. This audit alone does not claim the corresponding
affine upper for every odd length; that requires the uniform clock argument.

## Independent audit of the new paired-lens evaluator

`audit_lens_independent.py` separately enumerates all own/opposite corner
anchor pairs, rather than fixing one anchor at the origin. Its literal
room-set capacities match both tables in `lower_lens.py` on ten boards.
Every radius pair also passes the two numerical inclusion-exclusion
inequalities and coordinate monotonicity. These checks support, but do not
replace, the ordinary geometric proof.

A separate explicit tuple-state BFS, sharing only the accepted base reset
graph, matches all first-arrival layers and visited-state counts of the
grouped bitset implementation on seven inputs. At16x16,k15 it examines
387,221 explicit edges and returns solo15, residual3, full lower29.
The input/output source hashes and all receipts are in
`audit_lens_independent.json`.

The paired capacity argument is sound under the stated radius invariants.
When both radius witnesses come from one component, coordinate monotonicity
and the component's own paired bound suffice. When they come from different
components, the single-ball capacities and inclusion-exclusion suffice; no
physical interpretation of a synthetic merged set is required. The base
reset and guarded-merger proof obligations remain dependencies of this
review; the audit did not reprove them.

## Priority suggested by this evidence

The all-budget gap problem is concentrated below the linear-budget range,
especially at the first few feasible budgets. Isolated wide inputs with
larger model gaps are better adversarial tests than another check near the
known sufficient one-day threshold. Both model sharpening and strategy
improvement remain relevant. A finite-residue reduction over length would
turn these sampled differences into a meaningful all-length assessment for
each width/budget, while still leaving uniform growth in width to prove.

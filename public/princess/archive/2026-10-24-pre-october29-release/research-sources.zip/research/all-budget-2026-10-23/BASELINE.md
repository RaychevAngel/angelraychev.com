# Baseline for all budget rectangle bounds

Frozen 23 October 2026 PT, after the paired-capacity refinement and the
24-row odd-length correction. This is an aggregation of existing results,
not a new mathematical search. Its machine-readable companion is
`baseline.json`. Future comparisons should preserve this snapshot.

## Objective and an essential distinction

Use positive integers w<=n and k>=floor(w/2)+1. The current objective is
tight computable bounds L_k(w,n)<=T_k(w,n)<=U_k(w,n) across this entire
domain, allowing recurrences, finite-state calculations and preprocessing.
The final fixed-size-expression objective remains separate and deferred.

Under a literal unrestricted-computation interpretation, exact computability
is already established for every rectangle. The odd retained-joint theorem
is an exact evaluator; the even-area finite-interface theorem is an exact
algorithm with optimal physical strategy reconstruction and potentially
enormous parameter-dependent preprocessing. The latter is a mathematical
construction, not an implemented generic compiler. Ordinary full-belief
search also gives exact computability on any finite board.

This baseline therefore records both exact mathematical characterizations
and the implemented/proved structural bounds being tightened. It does not
silently impose a new runtime requirement or call the existing exact
characterization a remaining mathematical value gap. Statements below about
a positive gap concern the named structural bounds, without invoking full
exact preprocessing.

Sources: `paper/sections/bounded-odd-frontier.tex`,
`paper/sections/bounded-cylinder-interfaces.tex`.

## Complete parameter map for the structural bounds

The following rules cover every feasible input. Stronger special theorems,
integer sufficient tests and evaluated matches remain valid inside the
containing ranges; the thresholds are sufficient, not exact frontiers.

1. All w<=5: exact classifications at every budget. Also at any width,
   k>=wn gives one day, and floor(wn/2)<=k<wn gives two days on a nontrivial
   board. Below feasibility the time is infinite.

2. Odd w and odd n: the solo calculation gives a uniform one-day bracket
   2tau-1<=T<=2tau for every feasible k. The implemented retained-joint
   evaluator decides the endpoint exactly and reconstructs a strategy.
   Its state bound depends on w,k, not n. Thus under this phase's allowance
   of algorithmic evaluation, this entire parity class has matching values.
   Simpler scalar decisions are already proved throughout several uniform
   budget ranges and beyond explicit length onsets, but are not needed to
   establish exact algorithmic coverage.

3. Even width w=2r>=6, either parity of n: exact formulas/optimal constructions
   for k>=r(r-1), inclusive. Below that, a uniform structural gap at most one
   is proved whenever k>=C_e(w)=ceil(13w/10). Below C_e, general lower and
   physical upper evaluators still apply, but no universal one-day, two-day,
   or other absolute small-gap theorem is currently accepted. Intersect all
   ranges with feasibility and the preceding exact clauses.

4. Odd width w=2r+1>=7 and even n: exact formulas/optimal constructions for
   k>=r(r+1)+1. Below that, a uniform structural gap at most one is proved for
   k>=C_o(w)=min(ceil(4w/3),ceil(13r/5)+3). Below C_o the same qualification
   applies: bounds exist and are computable, but no accepted universal small
   constant gap covers the whole remaining range.

For both even-area classes the rule k>=w is a conjectured sufficient
one-day threshold below the accepted gates, supported by finite tests.
It is not part of the proved baseline.

The existing sharper computable one-day gate is also retained. Assume
k>=w and k<wn/2. For even w=2r use c=floor(k/2)-r, v=r-1, K=k;
for odd w=2r+1 use c=floor(k/2)-r-1, v=r, K=k-1. If c>=1,
t=2c, A=K-v>0 and

    t*A + sum(j=0,...,t-1) floor(j*A/(2v)) >= v^2,

the one-day theorem applies. Its fixed-operation sufficient replacement is
4*v*t*A+A*t*(t-1)-4*v*(t-1)>=4*v^3. These are earlier accepted tests from
`research/bridge-upper-transport-high-credit.md`; they may cover inputs
below the clean C_e,C_o thresholds. No new test was evaluated in this pass.

## What the general bounds contain

The basic even-area lower is the critical three-corner recurrence with its
half-budget midpoint test. The new paired-capacity model is a valid stronger
geometric lower evaluator for all even-area w>=4 and all feasible budgets.
The nine-feature erosion model gives additional lower bounds on odd-width,
even-length boards. Earlier radius, joint-boundary and special exact results
must be combined by a maximum; the newest model does not supersede all of them.

The basic upper is a physical prefix strategy, considering both initial
phases and the permissible shared middle day. Corner changes, other proved
shape changes and explicitly replayed schedules are combined by a minimum.
No general assertion that prefixes are optimal is made.

For every fixed feasible w,k and either admissible length parity, the
leading term is already established:

    T_k(w,n) = 2wn/(2k-w) + O_{w,k}(1), as n tends to infinity.

The constant depends on w,k. This does not give an absolute uniform gap
near square boards or at growing width. The largest current structural
gap over the infinite three-parameter domain has not been determined.

For example a completely explicit, but coarse, all-budget fallback at
even width is

    ceil(2*max(0,wn/2-w^2-k)/(k-w/2)) <= T_k(w,n)
        <= 2*ceil(w*(n+2)/(2*k-w)).

The geometric evaluators are often much tighter. This fallback and the
asymptotic statement come from `paper/sections/hamiltonian-cylinder-time.tex`.

## Retained comparison points

These combine the strongest documented applicable sources checked in this
aggregation. They are reproducible comparison fixtures, not a claim that an
exhaustive run of every possible exact algorithm was performed.

- 16x16, k=15: [29,29], gap 0.
- 20x20, k=12: [103,104], gap 1.
- 24x24, k=13: [206,207], gap 1; use the older special lower, not generic205.
- 24x25, k=13: [230,231], gap 1.
- 25x26, k=13: [375,375], gap 0; preserve the earlier exact theorem.
- 28x28, k=15: [257,259], gap 2.
- 31x32, k=16: [495,495], gap 0; use the nine-feature lower.
- 46x46, k=24: [505,509], gap 4.
- 81x82, k=41: [1603,1607], gap 4.
- 108x108, k=55: [1535,1539], gap 4.
- 129x130, k=65: [2799,2803], gap 4.

The corrected full 24-row family has

    24n-370 <= T_13(24,n) <= 24n-369, for every n>=24.

Thus the old two-day statement for odd lengths is superseded. The exact
25-row family T_13(25,n)=50n-925 for every even n>=26 is also retained.
These are useful regression families; the main assessment remains all widths.

## What the latest pass changed

The paired-capacity lower improved 29 of 213 selected even-width inputs
relative to the previous single-ball-radius model, and 7 of 54 selected
odd-width/even-length inputs relative to the simpler base model. These are
finite implementation comparisons, not percentages of the infinite domain.
Examples of named-model improvement are 255..259 to 257..259 at28x28,k15,
and1531..1539 to1535..1539 at108x108,k55.

Broader saved scans have 3416 basic-model inputs, 1808 even-width inputs,
and 312 odd-width near-square inputs with a stronger erosion lower. Their
samples overlap, and not all use the strongest combined model. They cannot
be pooled into a solved-case percentage or a claimed global maximum gap.
In particular the four-day fixtures do not prove a universal four-day bound.

The new general refinement has ordinary proofs, independent implementation
checks and physical upper replays. It has no new complete Lean theorem.
The website/manuscript/formal release still predates these private additions.

## Comparison rules for subsequent work

- Record changes to general parameter coverage: exact, uniformly one day,
  another proved gap, or no proved absolute gap.
- Compare the same named evaluator versions on the frozen numerical fixtures.
  When an older theorem is stronger, preserve it in the combined bound.
- Separate newly evaluated inputs from a new theorem applying to all inputs
  in a parameter family. Report actual runtime if operational evaluation
  is the claimed advance.
- Report unknown global gap as unknown. No percentage completion or global
  maximum should be inferred from finite scans.
- Keep exact mathematical characterization, implemented evaluation, physical
  strategy certificates, and Lean coverage as separate evidence fields.

No new mathematical claims, searches, public changes or Lean work were
undertaken while assembling this baseline.

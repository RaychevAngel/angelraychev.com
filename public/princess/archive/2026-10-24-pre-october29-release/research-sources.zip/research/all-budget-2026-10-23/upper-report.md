# All-budget upper lane: findings and failed repairs

23 October 2026. User priority is tight computable bounds for every feasible
`w<=n,k`; the fixed-operation expression remains a later objective. No
manuscript, website, formal source, or old release was changed in this lane.

## Accepted correction: all odd lengths at width 24

`upper-24-odd-correction.md` proves, by an ordinary entrance/plateau/tail
insertion argument,

    T_13(24,n) <= 24n-369,  n odd and n>=25.

Its fixed entrance is 34 days; the variable middle is `12n-254` days;
its fixed tail is 36 days. The final solo shot has two cells and can be
shared with its colour-swapping reflection. This is the old prefix
construction with the correct initial phase and shared day, not a new
geometric family. The previous checkpoint retained the weaker transport
upper `24n-368` for odd lengths.

Together with the independently accepted lower `24n-370`, every such
odd length now has a one-day bracket. The verifier checks the finite
certificates and independent physical replays; it is not a Lean proof.

## Broad even-width evidence: old bounds are not uniformly 1-2 apart

`upper-prefix-scan.json` compares the accepted critical three-corner lower
with the best of two anchored-prefix uppers and the old generic envelope
upper on 1,808 inputs. Widths are every even integer 4..160; lengths are
`w,w+1,3w/2,2w`; selected budgets include the first three feasible values,
approximately 5w/8, 3w/4, and w. Runtime: 50.64 CPU seconds.

The largest named-model gap is eight days, already at `w=108,k=55`, for
lengths 108,109,162,216. At `w=46,k=24`, the gap is seven days at all four
sampled lengths. These are gaps between two particular valid bounds;
they are not assertions that no stronger previously established theorem
applies, and are not lower bounds on the gap to the true optimum.

Breaking down this same scan:

* At the minimum budget, the largest gap is 8 (316 inputs).
* At budget `w/2+2`, the largest gap is 6 (316 inputs).
* At budget `w/2+3`, the largest gap is 4 (316 inputs).
* Among sampled budgets at least `3w/4`, the largest gap is 2 (492 inputs).
* Among sampled budgets at least w, the largest gap is 1 (320 inputs).

These are finite diagnostics only. In particular they do not prove any
universal two-day theorem at `k>=3w/4` or one-day theorem at `k>=w`.

Arithmetic-only checks at still larger minimum-budget squares exhibit
solo gaps of 4 at widths 1600,3200,6400 and 5 at width12800 between
the critical lower and plain physical prefix upper. The old direct
corner-change construction does not generally improve these: for
`w=n=3200,k=1601` it also gives an eight-day full named-model gap.
These runs use the proved scalar prefix calculus, not literal giant
room-set searches. They should be treated as diagnostic observations
until reproduced from a retained dedicated receipt if quoted publicly.

## Two attempted upper repairs that did not help

1. **Arbitrary prefix orientation changes.** The existing exact BFS over
   all reflected/permuted prefix survivors was rerun on four diagnostics.
   It gives full uppers 509 on `46x46,k24`, 555 on `46x47,k24`,
   783 on `64x64,k33`, and 1539 on `108x108,k55`. These equal the anchored
   upper in each case. Complete solo/full shots and literal replay results
   are in `upper-prefix-family-*.json`. This rules out improvements within
   that restricted prefix family only.

2. **Known triangle macro at every eligible prefix state.**
   `upper_triangle_dp.py` adds the already proved three-day square-triangle
   contraction to the exact physical prefix recurrence. It allows
   enlargement of the current prefix to the containing square triangle,
   then uses the three cuts and returns to a prefix. Its objective includes
   the final half-budget shot, so it tests the full palindrome length.
   This improved none of 138 selected cases (widths12..128, square and
   square-adjacent lengths, five low/intermediate budget choices).

There is also a short ordinary reason that this particular macro cannot
improve a prefix continuation. Start from its square prefix of size `s^2`,
and write R for ceiling square root and Q for the least u with `x<=u(u-1)`.
For the two phase neighbourhoods, `g0(x)<=x+R(x)` and `g1(x)<=x+Q(x)`.
Because `k>=s`, three greedy prefix steps have successive size bounds

    a1 <= s^2+s-k,
    a2 <= s^2+2s-2k,
    a3 <= s^2+3s-3k-1 <= s(s-1).

For the second inequality, its survivor is at most `s(s-1)` so Q<=s.
For the third, its survivor is at most `(s-1)^2`, using `3k>=4s-1`,
so R<=s-1. This is the very same phase and prefix target as the macro.
Starting from a smaller contained prefix only improves matters by
monotonicity. Thus every use of this macro can be replaced by three
ordinary prefix steps with a contained endpoint. The zero improvements
are explained, rather than merely observed. This does not say that all
possible local geometric repairs are redundant; the lemma applies only
to this already known three-cut square-triangle macro.

## Consequence for next research

The most informative current tests are near the first feasible budgets at
larger widths, not more samples around the old sufficient `1.3w` threshold.
The three-corner recurrence is substantially sharper than the scalar
isoperimetric relaxation here; comparing physical prefixes only to the
latter loses the relevant history and greatly overstates the discrepancy.

The tests do not justify assuming the upper is optimal. They do show that
routine prefix orientation switches and this specific local contraction
do not repair the larger discrepancies. Further upper gains need genuinely
different intermediate shapes or joint-cohort schedules. Further lower
gains need history constraints; the paired-radius intersection capacities
are a principled uniform candidate. I independently reviewed their
numerical guarded-merger argument and found it sound under the already
established reset/localization dependencies.

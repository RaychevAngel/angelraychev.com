# A missed shared-day upper for every odd length at width 24

23 October 2026. Ordinary construction proof, using the previously proved
prefix calculus and constant-surplus interval. This is a correction to the
old checkpoint's weaker `24n-368` upper, not a claim of a new shape family.

For every odd `n>=25`,

    T_13(24,n) <= 24n-369.

Together with the independently established lower `24n-370`, this is a
one-day bracket at every odd length. The lower is not proved in this note.

## Construction and its length

Put `h=12n`. In each physical colour order cells by `(x+y,-x)`, with
`0<=x<24` transverse. Start with colour 0. Each day inspect the final
13 cells of the current prefix, or its entire contents if smaller.
The prefix-neighbourhood closure has already been proved.

**Entrance, 34 days.** At base length 25 the successive defects `h-q`
through day 34 are

    0,9,17,25,31,37,42,48,53,58,62,66,70,74,77,81,
    84,87,90,93,95,98,100,102,104,106,108,110,111,
    113,114,116,117,119,120.

The day-34 state is phase 0 and has size `h-120`. Every survivor in
these 34 transitions has at least 168 rooms. In either phase every
transverse fibre of every such prefix is nonempty: in either phase a
prefix of size 156 already contains a bottom cell in every fibre.
Thus increasing the length by two and increasing
every cutoff height by two adds exactly 24 cells, preserves the phase,
and commutes with each inspection-and-neighbourhood transition. The
top truncation moves by the same two units; the bottom fibres were
already nonempty. Induction proves the same defect list at every odd
length `n>=25`.

**Middle, `h-254` days.** The accepted constant-surplus lemma in
`research/bridge-upper-transport.md`, specialized to `r=12`, says

    g_p(s)=s+12 whenever 122<=s<=h-133, for both phases.

Consequently every preinspection state `135<=q<=h-120` advances to
size `q-1`: its survivor has size `s=q-13` in that interval. From
`h-120` this takes exactly `h-254` days to reach 134. This number is
even, so the endpoint is still phase 0.

**Tail, 36 days.** The exact preinspection sizes, followed by capture,
are

    134,132,131,129,128,126,125,123,121,119,117,115,
    113,110,108,105,103,100,97,94,91,87,84,80,76,
    71,67,62,57,51,45,38,31,23,14,2,0.

All survivors here have at most 121 cells. The phase-0 such prefixes
have maximum height at most 20, and phase-1 such prefixes at most 21;
their neighbourhoods have height at most 22. Thus no tail transition
depends on the top boundary when `n>=25`. The list is a fixed finite
arithmetic certificate evaluated using the proved prefix formula,
not an extrapolation over lengths. Its final shot is `{(0,1),(1,0)}`.

The solo length is therefore

    L = 34 + (h-254) + 36 = h-184.

Reflect in the even transverse direction, `sigma(x,y)=(23-x,y)`.
For solo shots `S_1,...,S_L`, take

    S_1,...,S_(L-1), S_L union sigma(S_L),
    sigma(S_(L-1)),...,sigma(S_1).

The middle shot has four rooms, within budget 13. The usual
reverse-and-reflect argument captures the other initial-colour cohort:
an avoiding walk over the last L days would reverse and reflect to
one avoiding the solo schedule. The reflection switches colours and
the full sequence has an even number `2L-2` of inter-day moves.
The full time is `2L-1=24n-369`.

## Verification status

The companion verifier checks the fixed entrance and tail lists with
the exact prefix arithmetic, the nonempty-fibre and tail-height bounds,
and a small number of complete literal-grid replays. It checks the
two-row insertion identity on additional lengths as corroboration.
The uniform proof is the entrance/plateau/tail argument above.
No new Lean theorem or publication is claimed here.

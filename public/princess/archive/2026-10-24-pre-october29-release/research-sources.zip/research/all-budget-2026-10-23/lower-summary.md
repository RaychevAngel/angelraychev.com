# All-budget lower-bound lane: outcome

23 October 2026. The authorized aim was stronger algorithmic bounds for all
w<=n and every feasible budget, with fixed-size numerical extraction deferred.

## Accepted progress

`lower-lens.md` proves a stronger necessary-state rule for every even-area
rectangle with w>=4, at every budget. It retains the existing two persistent
corner-localization radii but bounds the support by the INTERSECTION of the
two corner balls, maximizing over compatible unknown anchors. Previously
the generic even-width model bounded the support against each ball
separately. The refined rule survives the guarded merger algebraically,
including the case where its two radius witnesses belong to different
component histories. It therefore provides a stronger physical lower
bound at every input where the finite evaluator is completed.

The method is uniform, not a collection of width-specific arguments.
The evaluator is an algorithm and is not claimed to meet the eventual
fixed-operation expression criterion. Parent, independent audit, and upper
lanes reviewed the new proof. Base reset/merger theorems remain dependencies.

Files: `lower_lens.py`, `lower-lens.md`, `audit-report.md`,
`audit_lens_independent.py/.json`, `lower_lens_verify.py/.json`.

## What finite checks actually establish

A selected213-case even-width comparison (w6..40, n=w,w+1,2w and budgets
r+1,r+2,w-1,w with duplicates removed) gives29 strict full-lower improvements
versus the previous single-ball radius model. `lower_lens_sweep.json` records
the improved rows. Every improved row was compared with a literally replayed
physical prefix upper in `lower_lens_upper_comparison.json`.

Examples:

- 16x16,k15: lower28 rises to29 and matches the physical upper29.
- 20x20,k12: lower102 rises to103; physical upper104.
- 28x28,k15: lower255 rises to257; physical upper259.
- 46x46,k24: critical lower502 rises to505; physical upper509.
- 108x108,k55: critical lower1531 rises to1535; physical upper1539.

The last two stress checks demonstrate why this is NOT a uniform one- or
two-day-gap theorem. The 108-square run finished in15 CPU seconds and
visited4,858,305 augmented feature states, with no physical-attainment claim.

A separate54-case odd-width/even-length check passes27,729 independent base
row comparisons and physical upper replays (`lower_lens_odd_width.json`).
The simpler corner model is weaker than the existing nine-feature erosion
model on some of those inputs; the new rule does not supersede that model.

Always take the maximum with earlier accepted lower bounds. For example,
the new generic evaluator gives205 on24x24,k13 while an earlier special
geometric theorem already gives206. Likewise preserve the exact25-row
classification. A named-model improvement is not automatically a new
strongest mathematical bound or a newly classified instance.

## Assessed refinement that did not help in this pass

`lower_labelled.py` keeps four individually labelled corner radii, branches
over possible anchors at each localization, and checks the literal
four-ball intersection. It also tests the survivor's intersection at entry
to a new localization, before movement. `lower-labelled-notes.md` gives the
proposed proof; this stronger variant is not needed for the accepted result.

A106-case scan (even w6..40, n=w,w+1, budgets r+1,r+2,w-1) improved NO full
lower over the paired rule. On46x46,k24 it again gives505, after5.2 CPU
seconds and796,422 augmented states. Thus anonymous anchor reselection
alone does not explain that surviving four-day diagnostic gap. This is
finite negative evidence, not equivalence of the models.

## Most direct remaining issue

The generic refinement now carries persistent simultaneous corner-ball
geometry, but it still forgets the detailed support inside those balls.
Remaining fast model paths can exploit that internal freedom. The next
lower-bound attack should inspect one of the larger unresolved model
witnesses (46-square or108-square) and seek a uniform necessary constraint
on that internal history or its entrance time. Merely attaching exact
corner names has now been assessed and does not fix these diagnostics.
No further search, manuscript work, publication, or Lean development was
undertaken by this lane.

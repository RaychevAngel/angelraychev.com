"""General even-area corner model with paired-radius intersection capacities.
Necessary histories only. Full-board interpretation additionally uses the
identity-reset and guarded-merger arguments documented in lower-lens.md.
"""
from pathlib import Path
import sys, json, time
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'src'))
from bridge_corner_reach import graph, bits

def capacities(w,n):
    diameter=w+n-2
    corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
    anchors=[x for x in corners if sum(x)%2]
    area=[[0]*(diameter+1)for _ in range(diameter+1)]
    corner=[[0]*(diameter+1)for _ in range(diameter+1)]
    for ax,ay in anchors:
        A=[[0]*(diameter+1)for _ in range(diameter+1)]
        C=[[0]*(diameter+1)for _ in range(diameter+1)]
        for x in range(w):
            for y in range(n):
                if (x+y)%2:continue
                d=x+y;e=abs(x-ax)+abs(y-ay)
                A[d][e]+=1;C[d][e]+=int((x,y)in corners)
        for i in range(diameter+1):
            for j in range(diameter+1):
                for Q in (A,C):
                    if i:Q[i][j]+=Q[i-1][j]
                    if j:Q[i][j]+=Q[i][j-1]
                    if i and j:Q[i][j]-=Q[i-1][j-1]
                area[i][j]=max(area[i][j],A[i][j])
                corner[i][j]=max(corner[i][j],C[i][j])
    return area,corner

def run(w,n,k,cap_seconds=40):
    assert 4<=w<=n and w*n%2==0 and k>w//2
    begin=time.process_time();h=w*n//2;D=w+n-2
    states,index,rows=graph(w,n,k,True)
    sizecap,cornercap=capacities(w,n)
    masks={}
    def allowed(r0,r1):
        if (r0,r1)not in masks:
            a,c=sizecap[r0][r1],cornercap[r0][r1]
            masks[r0,r1]=sum(1<<j for j,(q,z)in enumerate(states)if q<=a and z<=c)
        return masks[r0,r1]
    front={(D,D):1<<index[h,2]};seen=dict(front);zero=1<<index[0,0];layers=[]
    for t in range(4*w*n):
        if not front:raise AssertionError('empty frontier')
        layers.append(min(states[z][0]for mask in front.values()for z in bits(mask)))
        if any(mask&zero for mask in front.values()):break
        if time.process_time()-begin>cap_seconds:
            return dict(shape=[w,n],budget=k,complete=False,depth=t,CPU_seconds=time.process_time()-begin)
        following={}
        for (r0,r1),source in front.items():
            pair=(min(D,r1+1),min(D,r0+1));events={}
            for a in bits(source):
                for key,mask in rows[a].items():events[key]=events.get(key,0)|mask
            for (d,R),mask in events.items():
                new=list(pair)
                if d>=0:new[d]=min(new[d],R)
                new=tuple(new);mask&=allowed(*new)
                if mask:following[new]=following.get(new,0)|mask
        front={pair:mask&~seen.get(pair,0)for pair,mask in following.items()if mask&~seen.get(pair,0)}
        for pair,mask in front.items():seen[pair]=seen.get(pair,0)|mask
    residual=min(layers[:-1]);return dict(shape=[w,n],budget=k,complete=True,solo=t,residual=residual,full_lower=2*t-int(2*residual<=k),layers=layers,states=sum(x.bit_count()for x in seen.values()),radius_pairs=len(seen),CPU_seconds=time.process_time()-begin)

if __name__=='__main__':
    out=[]
    for case in sys.argv[1:] or ['24,24,13','24,25,13','32,32,17']:
        z=run(*map(int,case.split(',')));out.append(z);print(json.dumps({k:v for k,v in z.items()if k!='layers'}),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

"""Independent table and explicit-state BFS audit of lower_lens.py.

The base reset graph is shared with the reviewed construction; the radius
table and augmented-state traversal are independently implemented here.
This tests implementation, not the unlimited physical merger proof.
"""
import sys,json,time,hashlib
from pathlib import Path
from functools import lru_cache
from lower_lens import capacities,run
from bridge_corner_reach import graph,bits


def literal_tables(w,n):
    D=w+n-2;corners={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
    color=[(x,y) for x in range(w) for y in range(n) if (x+y)%2==0]
    own=[c for c in corners if sum(c)%2==0]
    other=[c for c in corners if sum(c)%2==1]
    distances={c:{v:abs(c[0]-v[0])+abs(c[1]-v[1]) for v in color} for c in corners}
    A=[[0]*(D+1) for _ in range(D+1)]
    C=[[0]*(D+1) for _ in range(D+1)]
    for R in range(D+1):
        for S in range(D+1):
            # All anchors, rather than normalize one to the origin.
            for o in own:
                for z in other:
                    rooms={v for v in color if distances[o][v]<=R and distances[z][v]<=S}
                    A[R][S]=max(A[R][S],len(rooms))
                    C[R][S]=max(C[R][S],len(rooms&corners))
    assert (A,C)==capacities(w,n)
    checks=0
    for R in range(D+1):
        for S in range(D+1):
            assert A[R][D]+A[D][S]-w*n//2<=A[R][S]
            assert max(0,C[R][D]+C[D][S]-2)<=C[R][S]
            if R:
                assert A[R-1][S]<=A[R][S] and C[R-1][S]<=C[R][S]
            if S:
                assert A[R][S-1]<=A[R][S] and C[R][S-1]<=C[R][S]
            checks+=2
    return A,C,checks


def explicit_bfs(w,n,k):
    start=time.process_time();D=w+n-2;h=w*n//2
    A,C,_=literal_tables(w,n)
    states,index,rows=graph(w,n,k,True)
    outgoing=[[(d,R,z) for (d,R),mask in row.items() for z in bits(mask)] for row in rows]
    initial=(h,2,D,D);front={initial};seen=set(front);layers=[];edges=0
    while True:
        layers.append(min(a for a,c,R,S in front))
        if layers[-1]==0:break
        nxt=set()
        for a,c,R,S in front:
            for d,reset,z in outgoing[index[a,c]]:
                q,e=states[z]
                RR,SS=min(D,S+1),min(D,R+1)
                if d==0:RR=min(RR,reset)
                elif d==1:SS=min(SS,reset)
                edges+=1
                if q<=A[RR][SS] and e<=C[RR][SS]:
                    after=(q,e,RR,SS)
                    if after not in seen:nxt.add(after)
        assert nxt
        seen.update(nxt);front=nxt
    expected=run(w,n,k)
    assert expected['complete'] and expected['layers']==layers
    assert expected['states']==len(seen),(expected['states'],len(seen))
    return dict(w=w,n=n,k=k,solo=len(layers)-1,residual=min(layers[:-1]),
                full_lower=expected['full_lower'],states=len(seen),edges=edges,
                all_first_arrival_layers_equal=True,cpu_seconds=time.process_time()-start)


def main():
    start=time.process_time();tables=[];bfs=[]
    for w,n in [(2,2),(2,3),(4,4),(4,5),(6,6),(6,7),(8,8),(8,9),(10,12),(16,16)]:
        _,_,checks=literal_tables(w,n)
        tables.append(dict(w=w,n=n,radius_pairs=checks//2,inclusion_exclusion_checks=checks))
    for case in [(6,6,4),(6,7,4),(8,8,5),(8,9,5),(8,8,7),(8,9,8),(16,16,15)]:
        row=explicit_bfs(*case);bfs.append(row);print(row,flush=True)
    out=dict(scope=__doc__,table_boards=tables,explicit_BFS=bfs,cpu_seconds=time.process_time()-start,
             source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('lower_lens.py')]})
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

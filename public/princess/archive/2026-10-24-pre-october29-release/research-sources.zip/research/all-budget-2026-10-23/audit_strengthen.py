"""Compare the baseline audit with existing stronger lower/upper components."""
import sys
from pathlib import Path
import json
import time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from audit_named_bounds import bounds
from resumed_even_construction_prefix_arithmetic import neighborhood_count
from bridge_lower_frontier_nine import step as nine_step


def balanced_arithmetic(w,n):
    assert w%2==0 and w>=10 and n>=w
    r=w//2;k=r+1
    QA=r*(n-r)+2*r-2; QB=r*(n-r)+3; duration=2*r-5
    options=[]
    for p0 in (0,1):
        q=w*n//2;p=p0;entrance=0
        while q>QA or p!=(n+1)%2:
            q=neighborhood_count(w,n,p,max(0,q-k));p^=1;entrance+=1
        assert q in (QA,QA-1)
        q=QB;p=n%2;tail=0
        while q:
            final=q
            q=neighborhood_count(w,n,p^1,max(0,q-k));p^=1;tail+=1
        solo=entrance+duration+tail
        options.append(dict(solo=solo,final_shot=final,upper=2*solo-int(2*final<=k)))
    return min(options,key=lambda x:x['upper'])


def nine_lower(w,n,k,limit=20):
    start=time.process_time();b=w//2;h=w*n//2
    B={(c,e):0 for c in range(3) for e in range(3)}
    C={(c,e):min(k//2,h-4+c+e) for c in range(3) for e in range(3)}
    t=0
    while B[2,2]<h:
        C_prev=C
        B=nine_step(b,h,k,B,strong_band=True)
        C=nine_step(b,h,k,C,strong_band=True)
        t+=1
        if time.process_time()-start>limit:
            return dict(completed=False,steps=t,cpu_seconds=time.process_time()-start)
    return dict(completed=True,solo=t,lower=2*t-int(C_prev[2,2]>=h),cpu_seconds=time.process_time()-start)


def main():
    start=time.process_time();out=[]
    cases=[(7,8,4),(9,10,5),(15,16,8),(23,24,12),(25,26,13),(31,32,16),(35,36,18),(49,50,25),(65,66,33),(129,130,65)]
    for w,n,k in cases:
        row=bounds(w,n,k); row['nine_feature']=nine_lower(w,n,k,limit=12)
        if row['nine_feature']['completed']:
            row['stronger_lower']=max(row['lower'],row['nine_feature']['lower'])
            row['stronger_gap']=row['upper']-row['stronger_lower']
            assert row['stronger_gap']>=0
        out.append(row)
        print(row,flush=True)
        Path(__file__).with_name('audit_strengthen.json').write_text(json.dumps(dict(scope=__doc__,rows=out,cpu_seconds=time.process_time()-start),indent=2)+'\n')
        if time.process_time()-start>35:
            break
    even=[]
    base=json.loads(Path(__file__).with_name('audit_named_bounds.json').read_text())
    for row in base['rows']:
        w,n,k=row['w'],row['n'],row['k']
        if w%2==0 and w>=10 and k==w//2+1:
            improved=balanced_arithmetic(w,n)
            even.append(dict(**row,balanced_upper=improved['upper'],improved_gap=min(row['upper'],improved['upper'])-row['lower']))
    Path(__file__).with_name('audit_strengthen.json').write_text(json.dumps(dict(scope=__doc__,odd_rows=out,even_rows=even,cpu_seconds=time.process_time()-start),indent=2)+'\n')
    print('Even worst after balanced:',sorted(even,key=lambda x:x['improved_gap'],reverse=True)[:12])

if __name__=='__main__':main()

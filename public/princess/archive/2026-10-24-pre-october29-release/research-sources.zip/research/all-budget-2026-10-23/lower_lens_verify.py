"""Independent literal geometry and explicit tuple-BFS audit of paired lens model.
Imports the existing transition relation, but not producer tables or search.
"""
from collections import deque
from functools import lru_cache
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'src'))
from bridge_corner_reach import graph,bits

def verify(w,n,k):
    started=time.process_time();S,I,rows=graph(w,n,k,True);D=w+n-2;h=w*n//2
    corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
    points=[(x,y)for x in range(w)for y in range(n)if (x+y)%2==0]
    @lru_cache(None)
    def cap(r,s):
        ans=[];co=[]
        for z in corners:
            if sum(z)%2==0:continue
            region=[(x,y)for x,y in points if x+y<=r and abs(x-z[0])+abs(y-z[1])<=s]
            ans.append(len(region));co.append(sum(v in corners for v in region))
        return max(ans),max(co)
    start=(I[h,2],D,D);front={start};seen={start};residual=h;edges=0;day=0
    while front:
        if any(S[a][0]==0 for a,r,s in front):
            return dict(shape=[w,n],budget=k,solo=day,residual=residual,full_lower=2*day-int(2*residual<=k),augmented_states=len(seen),edges_examined=edges,literal_radius_pairs=cap.cache_info().currsize,CPU_seconds=time.process_time()-started)
        residual=min(residual,min(S[a][0]for a,r,s in front));following=set()
        for a,r,s in front:
            for (d,R),mask in rows[a].items():
                r2,s2=min(D,s+1),min(D,r+1)
                if d==0:r2=min(r2,R)
                elif d==1:s2=min(s2,R)
                A,C=cap(r2,s2)
                for b in bits(mask):
                    edges+=1
                    if S[b][0]>A or S[b][1]>C:continue
                    state=(b,r2,s2)
                    if state not in seen:following.add(state)
        seen.update(following);front=following;day+=1
    raise AssertionError('no capture')
if __name__=='__main__':
    out=[]
    for args in [(16,16,15),(20,20,12)]:
        row=verify(*args);out.append(row);print(json.dumps(row),flush=True)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

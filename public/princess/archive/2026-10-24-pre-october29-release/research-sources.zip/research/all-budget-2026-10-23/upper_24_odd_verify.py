"""Finite certificates and independent physical replays for the all-length proof."""
import sys,json,time,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'src'))
from resumed_even_construction_prefix_arithmetic import neighborhood_count
from bridge_upper_transport import prefix_height,prefix_tail,capture_replay

entrance=[0,9,17,25,31,37,42,48,53,58,62,66,70,74,77,81,84,87,90,93,95,98,100,102,104,106,108,110,111,113,114,116,117,119,120]
tail=[134,132,131,129,128,126,125,123,121,119,117,115,113,110,108,105,103,100,97,94,91,87,84,80,76,71,67,62,57,51,45,38,31,23,14,2,0]

def run():
    start=time.monotonic()
    for p in (0,1):
        heights=prefix_height(24,25,p,156)
        assert all(a>=0 for a in heights)
    for day in range(34):
        q=300-entrance[day];p=day%2
        assert neighborhood_count(24,25,p,q-13)==300-entrance[day+1]
        a=prefix_height(24,25,p,q-13)
        assert min(a)>=0
        b=prefix_height(24,27,p,q+24-13)
        assert b==[v+2 for v in a]
    for day in range(36):
        q=tail[day];p=day%2;s=max(0,q-13)
        assert neighborhood_count(24,25,p,s)==tail[day+1]
        if s:
            assert max(prefix_height(24,25,p,s)) <= 20+p
    rows=[]
    for n in (25,27,29,35,49,101):
        h=12*n;p=0;q=h;sizes=[]
        while q:
            sizes.append(q);q=neighborhood_count(24,n,p,max(0,q-13));p=1-p
        assert len(sizes)==h-184 and sizes[-1]==2
        assert [h-q for q in sizes[:35]]==entrance
        assert sizes[-36:]==tail[:-1]
        rows.append({'n':n,'solo':len(sizes),'last_size':sizes[-1],'full_upper':2*len(sizes)-1})
    for n in (25,27,35):
        shots=prefix_tail(24,n,13,0,12*n)
        assert shots[-1]=={(0,1),(1,0)}
        reflect=lambda S:{(23-x,y)for x,y in S}
        full=shots[:-1]+[shots[-1]|reflect(shots[-1])]+[reflect(s)for s in shots[-2::-1]]
        assert capture_replay(24,n,13,shots)==12*n-184
        assert capture_replay(24,n,13,full,full=True)==24*n-369
    return {'status':'PASS','scope':__doc__,'fixed_entrance_steps':34,'fixed_tail_steps':36,
            'literal_replay_lengths':[25,27,35],'arithmetic_checks':rows,
            'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

if __name__=='__main__':
    result=run();Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

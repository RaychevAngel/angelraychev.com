# All budget rectangle bounds

23 October 2026, America/Los_Angeles. Private research checkpoint.

## Current objective

Use w<=n and a constant daily budget k. The immediate objective is tight,
algorithmically evaluable lower and constructive upper bounds for EVERY
rectangle and EVERY feasible k>=floor(w/2)+1. Recurrences and finite geometric
evaluators are acceptable in this phase. Fixed-size numerical expressions
remain the final objective, but numerical simplification is not this phase's
priority. No interval below a convenient budget threshold is excluded.

For each input report L<=T_k(w,n)<=U and the gap U-L. Lower bounds must apply
to arbitrary physical strategies; uppers must have physical inspections.
Take maxima of applicable certified lower bounds and minima of applicable
physical uppers. A gap between two named algorithms is not automatically
the strongest known gap at that input. Exact generic search does not replace
the task of deriving informative, usable general bounds.

The known odd-by-odd one-day theorem and exact retained joint evaluator
remain available. The weakest general guarantees occur on even-area boards
near the feasibility budget, which received priority here.

## Uniform strengthening obtained

`lower-lens.md` proves a paired corner-ball capacity filter for every
even-area rectangle with w>=4 and every budget. Two radius certificates
must constrain the same surviving rooms, so their intersection capacity
can be smaller than either separate capacity. The new necessary graph
therefore removes numerical histories admitted by the older graph.

The rule inherits physical propagation and the existing guarded merger.
The key algebra is monotonicity when both radii come from one component,
and inclusion-exclusion when they come from different components. No
physical interpretation of synthetic merged states is assumed. The strict
subcritical reset rules are existing theorems; no new critical reset is used.

Root reviewed this proof, and a separate upper-lane review found no gap.
The independent implementation audit enumerates all actual anchor pairs,
checks the capacity inequalities, and compares a separate tuple-state BFS
with the grouped implementation. See `audit_lens_independent.json` and
`lower_lens_verify.json`. These are ordinary proofs and checked finite
computations, not new Lean theorems.

The paired model strictly improves the old single-ball radius model in29
of213 selected even-width inputs, and improves the base model on seven of54
selected odd-width/even-length inputs. These samples support the implementation;
the general validity is supplied by the proof. They are not counts of new
classification theorems, since older specialized results can be stronger.

For example the named-model bracket at28x28,k15 improves from255..259 to
257..259, and at20x20,k12 from102..104 to103..104. At16x16,k15 the new lower
and a physically replayed upper both equal29. At46x46,k24 the new lower505
still leaves four days to the physical prefix upper509. No uniform small-gap
theorem follows from this refinement.

## Corrected old bound

The previously quoted odd-length24-row upper was unnecessarily weak.
`upper-24-odd-correction.md` proves, for EVERY odd n>=25,

    24n-370 <= T_13(24,n) <= 24n-369.

The lower is the existing joint-boundary theorem. The improved upper is an
existing physical prefix strategy with a shared middle inspection. Its new
account gives a fixed34-day entrance, a translated middle, and a fixed36-day
tail. The all-length implication is proved, with independent literal replays
at representative lengths. Thus the older claim of a two-day bracket for this
whole family is superseded. This corrects the bound record; it is not a new
strategy family or an argument that all low-budget rectangles are within one.

## Broad diagnostics and failed upper approaches

`audit-report.md` compares3416 even-area inputs using the critical three-
corner lower and physical prefix upper. Further scans include312 odd-width
near-square inputs with the stronger nine-feature lower, and1808 even-width
inputs in the upper lane. These samples overlap and must not be added as a
count of distinct inputs. Some named-model gaps exceed two days. Specialized
older theorems and the new paired filter must be included before describing
any such number as the best current bracket.

Searching all reflected/permuted prefix survivors did not improve the
tested large-gap examples. A dynamic program inserting the known three-day
square-triangle contraction improved none of138 sampled inputs. A short
ordinary comparison explains the latter failure: three ordinary prefix
steps dominate that particular macro. This is not a proof that prefixes
are optimal among all physical strategies. See `upper-report.md` and the
saved physical replays.

A stronger labelled-four-corner envelope was also tested. Its proof and
bounded outcomes are kept separately in the lower lane's notes; no broad
matching claim depends on it.

## What remains and how to measure progress

1. Combine the strongest applicable lower mechanisms instead of presenting
   the basic three-corner model as the final lower bound. History-dependent
   intersection restrictions are now an available general component.
2. Tighten the first few feasible budgets on even-area boards. A useful next
   improvement must either remove more false geometric histories or produce
   new physical shapes beyond the prefix/known-gadget family tested here.
3. Control dependence on length by proved entrance/interior/exit transfers.
   An all-length finite-residue gap audit would be stronger than sampling
   several lengths, but the general reduction was only proposed in this pass.
4. Prove a uniform small-gap theorem or match bounds throughout the remaining
   ranges. This pass does not do so. The k>=w one-day conjecture remains a
   conjecture below the earlier accepted sufficient gates.

Private research notes and evaluators were added. The manuscript, website,
downloads, arXiv material and Lean coverage were not changed. No mathematical
achievement has been removed or replaced by the change in current priority.

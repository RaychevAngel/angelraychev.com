"""Exact-corner-label strengthening of the anonymous paired radius model.
Proposed necessary model, proof review pending; no cross-radius dominance.
"""
from pathlib import Path
import sys,json,time
from functools import lru_cache
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'src'))
from bridge_corner_reach import graph,bits

def run(w,n,k,cap_seconds=20,entry_guard=True):
    assert 4<=w<=n and w*n%2==0 and k>w//2
    begin=time.process_time();D=w+n-2;h=w*n//2
    states,index,rows=graph(w,n,k,True)
    corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
    # Normalize every successor back to color0 via a fixed color-swapping reflection.
    reflect=(lambda x,y:(w-1-x,y)) if w%2==0 else (lambda x,y:(x,n-1-y))
    perm=[corners.index(reflect(*z))for z in corners]
    points=[(x,y)for x in range(w)for y in range(n)if (x+y)%2==0]
    cornerbits=sum(1<<i for i,z in enumerate(points)if z in corners)
    balls=[[sum(1<<i for i,(x,y)in enumerate(points)if abs(x-z[0])+abs(y-z[1])<=R)for R in range(D+1)]for z in corners]
    own=[[j for j,z in enumerate(corners)if sum(z)%2==d]for d in (0,1)]
    @lru_cache(None)
    def region(R):
        mask=(1<<h)-1
        for j,r in enumerate(R):mask&=balls[j][r]
        return mask
    @lru_cache(None)
    def allowed(R):
        mask=region(R)
        A=mask.bit_count();C=(mask&cornerbits).bit_count()
        return sum(1<<j for j,(a,c)in enumerate(states)if a<=A and c<=C)
    size_masks=[sum(1<<j for j,(a,c)in enumerate(states)if a<=q)for q in range(h+1)]
    seed=(D,)*4;front={seed:1<<index[h,2]};seen=dict(front);zero=1<<index[0,0];layers=[]
    for t in range(4*w*n):
        layers.append(min(states[z][0]for mask in front.values()for z in bits(mask)))
        if any(mask&zero for mask in front.values()):
            f=min(layers[:-1]);return dict(shape=[w,n],budget=k,complete=True,entry_guard=entry_guard,solo=t,residual=f,full_lower=2*t-int(2*f<=k),radius_vectors=len(seen),augmented_states=sum(x.bit_count()for x in seen.values()),CPU_seconds=time.process_time()-begin)
        if time.process_time()-begin>cap_seconds:return dict(shape=[w,n],budget=k,complete=False,depth=t,radius_vectors=len(seen),CPU_seconds=time.process_time()-begin)
        following={}
        for R,source in front.items():
            nxt=tuple(min(D,R[perm[j]]+1)for j in range(4));events={}
            for a in bits(source):
                for key,mask in rows[a].items():events[key]=events.get(key,0)|mask
            for (d,r),mask in events.items():
                choices=[(nxt,mask)]
                if d>=0:
                    choices=[]
                    for j in own[d]:
                        new=list(nxt);new[j]=min(new[j],r)
                        filt=mask
                        if entry_guard:
                            source_anchor=perm[j]
                            overlap=region(R)&balls[source_anchor][r-1]
                            surplus=(r+1)//2 if d==1 else (r+2)//2
                            filt&=size_masks[min(h,overlap.bit_count()+surplus)]
                        choices.append((tuple(new),filt))
                for new,filt in choices:
                    filtered=filt&allowed(new)
                    if filtered:following[new]=following.get(new,0)|filtered
        front={R:mask&~seen.get(R,0)for R,mask in following.items()if mask&~seen.get(R,0)}
        assert front
        for R,mask in front.items():seen[R]=seen.get(R,0)|mask
    raise AssertionError('limit')

if __name__=='__main__':
    out=[]
    for case in sys.argv[1:]or['16,16,15','24,24,13','28,28,15']:
        row=run(*map(int,case.split(',')));out.append(row);print(json.dumps(row),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

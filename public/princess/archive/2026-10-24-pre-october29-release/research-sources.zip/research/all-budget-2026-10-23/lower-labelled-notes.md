# Bounded four-corner refinement attempt

23 October 2026. This is an assessed strengthening of `lower-lens.md`,
not a new general gap theorem. Code: `lower_labelled.py`.

The state retains one radius for each actual board corner. On an informative
localization, branch over its two eligible corner anchors and tighten that
coordinate. A fixed reflection in an even side follows every move so that
the current support is always represented as color zero; the four radii are
permuted by the same reflection, then incremented and clipped at diameter.
The base corner transition relation is unchanged. Every retained state must
fit the literal intersection of its four colored corner balls, both in
room count and occupied-corner count. No two distinct radius vectors are
identified or compared by dominance.

Guarded-merger closure uses componentwise minimum radii after mapping both
cohorts to the common color. Their allowed regions intersect under this
minimum. If their cardinalities are a1,a2 and their occupied-corner counts
c1,c2, inclusion-exclusion gives

    a1+a2-h <= |K1 intersect K2|,
    max(0,c1+c2-2) <= |corners(K1) intersect corners(K2)|.

Thus a synthetic merged support is unnecessary. The existing subcritical
reset triggers are identity mergers, so any reset of the merged transition
is inherited from one component with the same chosen corner label. This
continues the radius invariant. Abstract branches that are impossible can
be retained; all physical histories have a consistent branch.

The optional `entry_guard` (default true) checks the survivor, not merely
the next belief: if a triggering edge has surplus s and target radius R
about corner o, the survivor lies in the source allowed region intersected
with the radius R-1 ball about o. Its size is target size minus s. Reject
an annotated edge when this necessary survivor capacity fails. Formation
is again identity in the merger; the zero-cost full partner has a source
allowed region containing the entire current color, so it cannot add an
unjustified survivor restriction. This is a proposed ordinary refinement;
independent review is needed before using its outputs as accepted lower
bounds. The simpler paired-lens bound has a separate proof and audit.

Initial checks retain the paired-lens full lower values at16-square,k15;
20-square,k12;24-square,k13;28-square,k15;46-square,k24. On46-square the
labelled model takes5.2 CPU seconds, visits796422 augmented states and2679
radius vectors, and gives505, the same as the anonymous paired rule.
The explicit physical upper is509, so these particular labels do not close
that four-day gap. Absence of improvement on these cases does not establish
that the labelled and anonymous models are always equivalent.

The purpose of this bounded attempt was to test whether anonymous anchor
reselection explains the remaining diagnostic gap. The current evidence
says that it is not the only missing information. No new fixed-width
classification or global uniform small-gap conclusion follows.

"""Certified-family upper evaluator: diagonal prefixes plus 3-day cuts.

Uses previously proved geometric constructions. Does not claim unrestricted
optimality. All dynamic choices concern actual physical upper constructions.
"""
from pathlib import Path
import sys, json, time
from math import isqrt
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'src'))
from resumed_even_construction_prefix_arithmetic import neighborhood_count
from bridge_budget_ratios import analyze


def root(q):
    z=isqrt(q)
    return z+(z*z<q)


def run(w,n,k):
    assert w%2==0 and w<=n and w//2<k<w*n//2
    h=w*n//2
    # Cost is twice solo days, minus one iff final shot is shareable.
    F=[[0]*(h+1) for _ in (0,1)]
    actions=[[None]*(h+1) for _ in (0,1)]
    for q in range(1,h+1):
        for p in (0,1):
            if q<=k:
                F[p][q]=2-int(2*q<=k)
                actions[p][q]=('finish',q)
                continue
            z=neighborhood_count(w,n,p,q-k)
            assert z<q
            best=2+F[1-p][z];action=('prefix',z)
            if p==0:
                s=root(q)
                K=min(k,2*s-2)
                z=s*(s-1)
                if s>=3 and 2*s<=w and s<=K and 3*K>=4*s-1 and z<q:
                    cost=6+F[1][z]
                    if cost<best:
                        best=cost;action=('triangle',s,z)
            F[p][q]=best;actions[p][q]=action
    initial=min((F[p][h],p) for p in (0,1))
    p=initial[1];q=h;trace=[]
    while q:
        action=actions[p][q]
        trace.append((p,q,action))
        if action[0]=='finish':q=0
        elif action[0]=='prefix':q=action[1];p=1-p
        else:q=action[2];p=1-p
    return {'w':w,'n':n,'k':k,'hybrid_upper':initial[0],
            'initial_phase':initial[1],'triangle_count':sum(a[2][0]=='triangle' for a in trace),
            'trace':trace}


if __name__=='__main__':
    start=time.monotonic();rows=[]
    for w in [12,16,20,24,32,40,46,48,64,80,96,106,108,128]:
        for n in (w,w+1):
            for k in sorted({w//2+1,w//2+2,w//2+3,3*w//4,w}):
                b=analyze(w,n,k);u=run(w,n,k)
                rows.append({**b,**{key:val for key,val in u.items() if key!='trace'},
                             'improvement':b['upper']-min(b['upper'],u['hybrid_upper'])})
    improved=[r for r in rows if r['improvement']>0]
    out={'scope':__doc__,'cases':len(rows),'seconds':time.monotonic()-start,
         'improved':len(improved),'rows':rows}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'cases':len(rows),'improved':len(improved),'seconds':out['seconds'],
                      'examples':improved[:10]},indent=2))

"""Read-only finite audit of existing proved necessary/constructive clocks.

This is a comparison of named bounds, not unrestricted capture-time search.
No finite audit result establishes a uniform gap theorem.
"""
import sys
from pathlib import Path
import json
import time
from collections import Counter

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from bridge_corner_frontier import step
from bridge_upper_transport_coupling import physical_erosion
from bridge_upper_transport_odd_coupling import physical_step


def bounds(w, n, k):
    h = w*n//2
    assert w <= n and w*n % 2 == 0 and k > w//2
    if k >= h:
        t = 1 if k >= w*n else 2
        return dict(w=w,n=n,k=k,lower=t,upper=t,gap=0)
    B, C = (0,-1,-1), tuple(min(k//2,h-2+c) for c in range(3))
    X, Y = (0,0), (k//2,k//2)
    low = up = None
    t = 0
    while low is None or up is None:
        if low is None and B[2] == h:
            # C_prev is the half-shot backward threshold at t-1.
            low = 2*t-int(C_prev[2] == h)
        if up is None:
            candidates = []
            if max(X) == h:
                candidates.append(2*t)
            if max(Y) == h:
                candidates.append(2*t+1)
            if candidates:
                up = min(candidates)
        if low is not None and up is not None:
            break
        C_prev = C
        B, C = step(w,n,k,B,True), step(w,n,k,C,True)
        if w % 2:
            X, Y = physical_step(w//2,h,k,X), physical_step(w//2,h,k,Y)
        else:
            X = tuple(min(h,k+physical_erosion(w//2,n,1-p,X[1-p])) for p in (0,1))
            Y = tuple(min(h,k+physical_erosion(w//2,n,1-p,Y[1-p])) for p in (0,1))
        t += 1
        assert t < 4*w*n
    # A half-shot horizon t may give 2t+1; full capture at t+1 gives 2t+2,
    # so the first of these upper events is always optimal in this family.
    assert low <= up, (w,n,k,low,up)
    return dict(w=w,n=n,k=k,lower=low,upper=up,gap=up-low)


def main():
    started = time.process_time()
    rows = []
    # Near-square, both length parities, and length/width 2 and 4.
    widths = list(range(4,41)) + [48,49,64,65,80,81,100,101,128,129]
    for w in widths:
        lengths = sorted({w,w+1,w+2,w+3,2*w,2*w+1,4*w,4*w+1})
        for n in lengths:
            if w*n % 2:
                continue
            r=w//2
            budgets = list(range(r+1,min(w+2,r+11)))
            budgets += [max(r+1,(3*w)//4),w-1,w,w+1,(13*w+9)//10]
            for k in sorted(set(budgets)):
                rows.append(bounds(w,n,k))
                if time.process_time()-started > 45:
                    break
            if time.process_time()-started > 45:
                break
        if time.process_time()-started > 45:
            break
    data = dict(scope=__doc__,
                lower='Accepted critical three-corner necessary model; halfbudget central test.',
                upper='Best fixed-anchor two-phase physical prefix palindrome; halfbudget central shot.',
                stronger_bounds_not_included='Corner-change, arbitrary prefix switching, transport/shape repairs, nine-feature/radius lower refinements.',
                cases=len(rows),cpu_seconds=time.process_time()-started,
                gap_histogram=dict(sorted(Counter(r['gap'] for r in rows).items())),
                rows=rows)
    out = Path(__file__).with_name('audit_named_bounds.json')
    out.write_text(json.dumps(data,indent=2)+'\n')
    print({k:v for k,v in data.items() if k!='rows'})
    print('worst',sorted(rows,key=lambda r:r['gap'],reverse=True)[:20])


if __name__ == '__main__':
    main()

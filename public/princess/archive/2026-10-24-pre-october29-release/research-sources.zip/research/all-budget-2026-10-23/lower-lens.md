# Paired corner-ball capacities for every even-area rectangle and every budget

23 October 2026. Ordinary argument and finite checks. This is a uniformly
applicable strengthening of the accepted necessary corner model, not a
uniform one-day theorem or a new fixed-size formula. The parent and two
independent lanes accepted the ordinary paired-capacity argument under the
existing base reset and guarded-merger dependencies.

## Model and new rule

Let 4<=w<=n, wn be even, h=wn/2, D=w+n-2 and k>=0. The accepted model in
`src/bridge_corner_reach.py` retains (a,c,rho0,rho1), where a is the size of a
single-color support, c its own-colored board-corner count, and each finite
rho_d certifies containment in a ball about SOME corner whose color differs
by d from the support. Two retained certificates need not use the same
corner; indeed their colors differ. Diameter D represents no information.

Fix the current physical color to zero and one own-color corner o=(0,0).
Every own-colored corner can be mapped to o by a color-preserving rectangle
symmetry. Let O be the two opposite-colored corners. Define

    A(R,S) = max_{z in O} |V0 intersect B_R(o) intersect B_S(z)|,
    C(R,S) = max_{z in O} |corners(V0) intersect B_R(o) intersect B_S(z)|.

The maxima can choose different z; this deliberately weakens the joint
constraint and is harmless. Impose a<=A(rho0,rho1), c<=C(rho0,rho1).
These two tables are computed by two bivariate prefix sums of literal
Manhattan-distance histograms. They are nondecreasing in each argument.
No optimization over shapes or inspection schedules is involved in their
construction. When either radius is D the rule includes the former
single-ball area and corner restrictions; thus it can only strengthen them.

## Physical validity

Choose an actual witness anchor for each retained radius. Reflect the own-
color anchor to o. The other witness becomes one of O. The support and its
occupied corners lie in the indicated intersection, so both bounds follow.

Movement propagates (rho0,rho1) to (min(D,rho1+1),min(D,rho0+1)). The existing
subcritical square and exact pronic resets use coordinatewise minima. Their
physical localization and identity-merger formation are already proved in
`research/bridge-linear-budget-coupling.md` and its cited corner theory.
This note adds no new reset or compression hypothesis.

## Guarded-merger validity: the important joint-witness point

The old merger has size a=a1+a2-h and corner count c=max(0,c1+c2-2), in its
positive-size guard. Its radius invariant says, separately for d=0,1,

    rho_merged[d] >= min(rho_component1[d],rho_component2[d]).

For each merged coordinate choose a witnessing component with radius no
larger. All following claims concern numerical model states; the components
need not be physically realizable supports.

If both coordinates are witnessed by component i, coordinate monotonicity
of A,C, its already imposed paired bounds, and a<=a_i,c<=c_i prove the
merged inequalities directly.

If the witnesses come from different components, use the numerical
single-ball capacities A(R,D),A(D,S),C(R,D),C(D,S). They dominate the
respective paired capacities. The number of rooms or same-colored corners
in a ball depends only on its radius and relative anchor color, not on
which corner is chosen. For ANY compatible anchor pair, inclusion-exclusion
therefore gives

    A(R,D)+A(D,S)-h <= A(R,S),
    max(0,C(R,D)+C(D,S)-2) <= C(R,S).

Apply these to the two component bounds, then enlarge the radii to the
merged coordinates. This proves the distinct-component case. Diameter D
is a literal full-board ball, so missing certificates cause no exception.
The two maxima A,C need not use the same optimizing anchor pair: they are
separate necessary inequalities. No simultaneous maximizing shape is
asserted.

This supplies the abstract-model merger argument directly and does not
invent a physical merged support. It extends the earlier reviewed paired
lens idea to the general even-area corner model.

The existing guarded precapture merger theorem consequently continues to
apply. If tau is the refined model's first capture day and f its minimum
size among states reachable before tau, the lower bound remains

    L=2*tau - 1 if 2*f<=k, and L=2*tau otherwise.

There is no physical attainment assertion for model paths.

## Computation and verification boundary

`lower_lens.py` imports the accepted base graph and adds ONLY these paired
capacity filters. The first-arrival search groups states with equal radius
pairs, retains all base-feature states and uses no dominance across distinct
pairs. Therefore it computes exact reachability in the stated finite model.
`lower_lens_sweep.json` records strict improvements over the old single-ball
radius model; it does not claim improvements over every previously named
special theorem. In particular 24-square,k13 has an independent stronger
206-day lower theorem; this simple paired model produces only205 there.

The independent implementation review is `audit-report.md` and
`audit_lens_independent.py/.json`: literal all-anchor capacities, numerical
inclusion-exclusion, monotonicity, and separate explicit-state BFS agree
with the grouped bitset evaluator. A second literal checker is
`lower_lens_verify.py/.json`. Its initially noticed capture-layer accounting
bug was corrected: only layers strictly before first capture enter the
residual, and first capture is tested before expanding that layer. It now
agrees with the producer and primary independent audit. No producer fix
was needed. The upper lane's independent proof review is in `upper-report.md`.
These finite checks complement the ordinary unlimited-parameter proof;
they do not replace it. No manuscript, website, Lean source or public
artifact has been changed.

## Why both even-area parity classes are covered

The base `survivor_bound` and `model_data` already accept every even-area
rectangle. Their critical exceptions distinguish even and odd short sides.
The reused `graph` function has no width-parity assumption and uses only
radius r<floor(w/2) resets, so no disputed critical localization enters.
The square reset follows from the finite-board small-branch decomposition
and near-square localization: the high branch is excluded since its hole
side is larger than r^2, while its dual capacity is at most r^2. The pronic
reset is the strictly subcritical part of the existing theorem titled
“Pronic rigidity on every even-area rectangle.” Both identity-merger
formation arguments use h>=2 floor(w/2)^2 and the strict surplus bound,
not the parity of w. Finally every such board has two corners per color;
a reflection along an even side swaps colors, and color-preserving
symmetries act transitively on the two corners of either color. These are
exactly the symmetry facts used by the intersection capacities.

The older `bridge_corner_reach.run` wrapper asserts even w, but its `graph`
function and the underlying proved geometric rules do not need it. The
new wrapper explicitly accepts all even-area boards and excludes odd-area
boards. This broadens the applicability of this paired refinement without
assuming the much stronger odd-width erosion model is subsumed.

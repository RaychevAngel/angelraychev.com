"""Independent complete arithmetic base for the late passage, not board samples."""
from math import isqrt
from pathlib import Path
import hashlib,json,time

def square_root(x):
    return isqrt(x-1)+1 if x else 0

def rho(x):
    r=isqrt(x)
    while r*(r+1)<x:r+=1
    while r and (r-1)*r>=x:r-=1
    return r

def times(k,top,phase=None):
    hit=[0]*(top+1);value=day=0
    while value<top:
        loss=rho(value) if phase is None or (day+phase)%2==0 else square_root(value)
        nxt=value+k-loss
        assert nxt>value
        day+=1
        hit[value+1:min(nxt,top)+1]=[day]*min(nxt-value,top-value)
        value=nxt
    return hit

start=time.process_time();rows=[];checks=0
for k in range(33,100):
    R=(3*k+4)//5+4;r=R+1;top=R*R+k;D0=k-R-1
    assert r>=25 and R<k-2 and 5*r>3*k
    numerator=r*r-12*r-112
    Delta=(numerator+2*k-1)//(2*k)
    margin=4*(Delta-1)-D0
    assert margin>=0
    scalar=times(k,top)
    worst=max((a-b,q,phase) for phase in (0,1)
              for q,(a,b) in enumerate(zip(times(k,top,phase),scalar)) if q)
    assert worst[0]<=1
    checks+=2*top
    rows.append(dict(k=k,R=R,top=top,maximum_fast_delay=worst[0],
                     witness_target=worst[1],witness_phase=worst[2],
                     minimum_switch_credit=margin))
here=Path(__file__).parent
sources=[Path(__file__),here/'physical-late-all-budgets.md',
         here/'physical-two-day-late-contract.md',here/'physical-fast-one.md']
result=dict(status='PASS',budget_count=len(rows),width_or_length_samples=0,
            target_phase_comparisons=checks,
            maximum_fast_delay=max(x['maximum_fast_delay'] for x in rows),
            minimum_switch_credit=min(x['minimum_switch_credit'] for x in rows),
            CPU_seconds=time.process_time()-start,
            source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k!='rows'})

# The odd-width central nine-feature operator

24 October 2026 UTC. Exact algebraic simplification of the accepted
unflagged necessary model. It does not by itself prove a passage-time
comparison or resolve a phase interface.

Let w=2b+1, n>=w be even, b>=32, h=wn/2, and b+1<=k<3b. Suppose every
input threshold B(j,v) lies in the interval

    b^2+1 <= B(j,v) <= h-(b-1)^2-1.             (1)

Write L=b(b+1), E=h-b^2, U=h-b(b-1), and

    Q_c=max_{0<=j,v<=2}(B(j,v)-max(v-c,0)).

The next threshold at source feature(c,e) is k plus the maximum of:

    Q_c-b-1;
    B(0,2)-b-max(2-c,0);
    B(0,1)-b-max(1-c,0), if B(0,1)<=L;
    B(1,2)-b-max(2-c,0), if B(1,2)>=E;
    B(2,1)-b-indicator(c=0 or e<2), if B(2,1)>=U.       (2)

No eroded-corner requirement accompanies the fourth term. Its square
root is the critical root b, where the subcritical wide-square filter
does not apply. Inserting an e>=1 condition there would incorrectly
strengthen the necessary model.

## Derivation from the nine fixed target features

Retaining i=min(c,v) minimizes the closure cost delta=v-i; retaining
u=min(e,j) is allowed. All deletion charges are at most4 and hence at
most k. The maximal-retention constraint is satisfied by these choices.
The target and survivor upper-size caps do not bind in(1), and neither
does the output source cap after adding k, since b>=32 and k<3b.

Every target admits closed surplus b+1 in the necessary model. Its
ordinary critical cap is at most b+1, and all additional band penalties
are at most b+1 original surplus in this interval. Consequently the
first term in(2) is always available. To improve it one must use closed
surplus at most b, and the following list is exhaustive:

* Target(j,v)=(0,2) always has the odd-width critical exception(v,j)=(2,0).
  Its closed surplus can equal b, giving the second term.
* Target(0,1) has closed surplus b precisely when its low capacity fits:
  T<=b(b+1). In the whole input interval, its high inverse exceeds b.
  This is the third term, including its closure cost when c=0.
* Target(1,2) has closed surplus b precisely when h-T<=b^2. Its high
  inverse is ceil(sqrt(h-T))=b. The wide-square penalty is restricted
  to roots below b, so it imposes no extra condition here. This yields
  the fourth term, including closure costs for c=0,1.
* Target(2,1) has closed surplus b when h-T<=b(b-1). The critical
  near-pronic band requires original surplus at least b+1 unless
  (i,u,v)=(1,2,1). This latter choice exists exactly when c>=1,e=2.
  Otherwise one extra unit suffices; if c=0 the closure cost already
  supplies that unit. This gives the fifth term.

For the other five targets, the low and high ordinary inverses are at
least b+1. For example target(2,2) has high cost at least b+1 since
D=h-T>=(b-1)^2+1 and 2D>b(b-1); its two ordinary high branches are
1+rho(2D) and1+ceil(sqrt(D+1)). The remaining bounds follow directly
from their shifted square/pronic roots. The low-side input T>b^2 and
the high-side input D>(b-1)^2 rule out all smaller roots. No high root
can be below b and no relevant low root can be below b in(1).

This proves(2). It applies to any input vector satisfying(1), not just
vectors encountered in a selected rectangle computation.

## Interfaces still required

Physical source-prefix features change at actual corner and neighbor-pair
ranks. Away from endpoint transients the two phases use:

    low:     (1,0), (0,1);
    middle:  (2,0), (0,2);
    high:    (2,1), (1,2).

For phase0, its second own corner enters at rank b^2+1, and its first
eroded opposite corner enters at rank h-b(b-1). For phase1, its second
eroded corner enters at rank b(b+1)+1, and its first own corner enters
at rank h-b^2. These are changes in physical features, not permission
to swap the two phase labels.

Inputs at or below b^2, the precise first two ranks above it, and jumps
across a feature-rank boundary still need to be joined to the low pair
without losing credit. The same is true at the high end. A full central
clock assertion must explicitly check these interfaces rather than
using(2) outside its interval.

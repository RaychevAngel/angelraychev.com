# Late comparison for every budget in the unbounded-width range

24 October 2026 UTC. Ordinary proof with a finite arithmetic base, submitted
for independent review. No new global gap claim is made here.

The theorem of `physical-two-day-late-contract.md` extends from k>=75 to
EVERY k>=max(33,b+1), with the same arbitrary ceiling

    k<Y<=(b-5)^2,

and the following cutoff:

    R=ceil(3k/5)+4 for 33<=k<=99;
    R=floor(3k/5)  for k>=100;
    F_cut=R^2+k, D0=k-R-1.

Either physical incoming phase has late allowance two. The allowance is
one if the whole remaining interval is fast, or if its first slow good
event is already phase aligned, or if the explicit incoming local room
credit in the earlier note pays a rewind. In particular this does NOT
grant a freely chosen phase to a carried prefix at a middle/late join.

## Why the geometric argument is unchanged

For the finite budgets, R+1>=25, R<k-2, and R+1>3k/5. A slow transition
therefore has r>=25. All concentration inequalities in the earlier proof
already hold for r>=20: good surplus is at most r+4, the unused surplus is
at most five, small outliers are at most25, and the opposite cohort's
holes are at most30. The old-root matching charge is still

    Delta*k >= (r^2-12r-112)/2.

The polynomial increases for r>=R+1. Hence it suffices, for each of the
67 budgets, to check at r=R+1 that

    4*(ceil((r^2-12r-112)/(2k))-1) >= D0.

The exact integer check has minimum margin three. It proves the needed
credit for every larger root, every board, and every physical history;
it is not a width sample. All good profiles, strict monotonicity,
interlacing, and the reference predecessor argument remain the same.

## Complete fast numerical base

For every integer target A with 1<=A<=R^2+k, compute first-hit times of
the all-G backward capacity map and both alternating backward physical
maps, where

    G(x)=k+x-rho(x), F(x)=k+x-ceil(sqrt(x)).

The accompanying checker independently computes all these thresholds.
Across the 67 budgets there are 286,352 target/phase comparisons. Every
physical threshold is reached at most one update after its scalar
threshold. These are all possible fast targets, not selected histories.

The usual final-inspection cancellation converts this to one extra gate
transition. The arbitrary-Y last-crossing reset and the later fast
last-crossing reset are paid by the actual durations they omit, exactly
as in `physical-two-day-late-contract.md`. Thus the only unpaid costs are
the optional initial slow phase adjustment and the one-day fast bound.

The fast-only ceiling corollary also extends, using this R: it is enough
that Y<=min(F_cut,b(b-1)) and the compared prefixes fit the quadrant.
This branch uses no dominant-component or phase-rewind argument.

For k>=100 the previous analytic fast theorem and switch-charge
polynomial apply directly. The finite base above completes the budget
range without any bound on width or length.

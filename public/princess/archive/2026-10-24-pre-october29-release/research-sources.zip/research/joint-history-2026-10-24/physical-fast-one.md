# One fast-exit day below the three-fifths cutoff

24 October2026 UTC. New scalar comparison for independent review. This
is a late-interface lemma, not a complete physical late theorem.

For k>=33 define R=floor(3k/5), F_cut=R^2+k and u=k-R-1. Start
Y_0=0 and iterate

    G(Y)=k+Y-rho(Y).

The two physical backward quadrant phases alternate G with
F(Y)=k+Y-ceil(sqrt(Y)), starting at zero. For every integer target
1<=A<=F_cut, BOTH physical phases first reach A at most ONE update
after the scalar orbit first reaches A.

## Uniform proof for k>=75

Let t be the scalar first hitting time of F_cut. Put a=k-1. Since
rho(Y)<=ceil(sqrt(Y))<=sqrt(Y)+1, each scalar increment is at least
f(Y)=a-sqrt(Y). This positive function decreases on [0,F_cut]. For
every complete scalar step before the final crossing,

    integral from Y_j to Y_(j+1) of dy/f(y)
      >= (Y_(j+1)-Y_j)/f(Y_j) >=1.

Consequently

    t <= 1+integral from0 to F_cut of dy/(a-sqrt(y))
      =1+2a log(a/(a-sqrt(F_cut)))-2sqrt(F_cut).      (1)

All denominators are positive. The elementary bounds

    sqrt(F_cut)<=3k/5+5/6,
    sqrt(F_cut)>=R>=3k/5-1

give

    a/(a-sqrt(F_cut))
       <=(k-1)/(2k/5-11/6)<=444/169                 (k>=75).

The rational function decreases with k; its value at75 is444/169.
Also log(444/169)<97/100: the first six nonnegative terms of the
exponential series at97/100 already exceed444/169. Their exact positive
difference is1903592147933/202800000000000.

Inserting these estimates into (1) yields

    t < (37/50)k+53/50 <=(4/5)k-2 <=2u.

The middle inequality holds for k>=51, and the final one uses R<=3k/5.
In particular t<=2u for every k>=75.

The maps F,G are nondecreasing and1-Lipschitz, and0<=G-F<=1.
Either physical phase uses F at most ceil(s/2) times in s updates,
so its deficit from the scalar orbit is at most ceil(s/2). At the
scalar first hit of any A<=F_cut, s<=t<=2u, making this deficit at
most u. Every physical update below A gains at least u because
F_cut<= (R+1)^2. One additional update therefore reaches A.

## Budgets33 through74

`physical-fast-one-check.py/.json` checks only the42 scalar budgets,
not either rectangle dimension. For each it verifies t<=2u at F_cut,
which proves the same simultaneous all-target assertion by the identical
half-frequency and drift argument. There is no strategy search.

## Physical conversion and interface boundary

If an actual interval of ell transitions stays at residual at most
min(F_cut,H), ends at residual at most k, and obeys the accepted scalar
surplus inequality, its initial residual is at most Y_(ell+1). The
comparison above gives either physical phase a gate trajectory in at
most ell+1 transitions: the final inspection in both backward clocks
cancels in the conversion to gate time.

All physically used target prefixes must still fit the rectangle;
that condition is separate. The new lower cutoff R must also satisfy
the geometric paid-rewind conditions on the preceding slow interval.
This lemma does not assume those conditions or silently replace the
accepted late3 theorem.

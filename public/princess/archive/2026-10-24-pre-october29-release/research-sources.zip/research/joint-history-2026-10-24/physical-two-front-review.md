# Independent review of the two-front reduction

24 October 2026. The exact meeting identity and the conditional reduction
are accepted as ordinary mathematics. The displayed uniform middle
inequality remains unproved; no nine-day theorem is asserted.

## Exact identity and phase conventions

The residual map phi_p uses source parity p relative to its corner, and
its output has parity1-p. Its exact inverse at a threshold in phase1-p
therefore has source phase p. The backward recurrence in
`lower-two-front-meeting.md` has precisely that orientation.

A residual prefix of phase p has antipodal complementary hole phase
q=p xor chi, chi=(w+n-2) mod2. After the move, the complementary holes
have phase1-q. Thus

    A_next[1-q]=h-phi_(q xor chi)(h-A[q]).

In the small quadrant this becomes A_next=(G(A[1]),F(A[0])), exactly
the current-hole labeling used by the early hybrid. The late inverse
has the same displayed pair recurrence but its labels are source
residual phases. Their identical algebra does not remove the xor chi
at the meeting cut.

Monotonicity of each exact finite-board phi proves the threshold
adjunction. Applying it repeatedly gives the exact V_s capacity from
s moves plus the final inspection. A_t is the actual residual complement
after t moves, indexed by current hole phase. Consequently

    P<=t+s+1 iff max_p(A_t[p xor chi]+V_s[p])>=h.

This includes early capture through the absorbing zero residual and
includes exactly one final inspection. The selected starting phase is
fixed by the current phase and the number of previous moves, so this
does not permit an independent mid-strategy phase change.

## Same-phase boundary repair and its scope

The accepted fast-one statements give coordinatewise physical domination
of the capped scalar injection with one extra move. The monotone ordinary
operator propagates domination of the ordinary hybrid branch. Taking the
maximum of the ordinary and injected branches proves the same-phase
inequalities at the boundary clocks used by the reduction.

These inequalities should be read only up to their admitted boundary
capacities, or with a physical cap at h, not as inequalities for an
unbounded quadrant recurrence at every time. This causes no gap at the
required e=e_k(Q) and ell=ell_k(Y): before either first hit its maximum
is below its target, and the next maximum is at most the corresponding
scalar update. In particular

    max E_e <= Qmax+k <= H+2k-1,
    max C_ell <= Ymax+k = H+2k-b+6.

Both are strictly below b(b-1) for b>=32 and k<3b. Thus every hybrid
capacity actually used in the two-front assertion is in the established
quadrant boundary range, even when the formal injection cap R^2+k orZ
is larger. The finite-board physical fronts may continue beyond this
range using their exact maps; no quadrant formula is extrapolated there.

## Conditional consequence

For an endpoint pair Q,Y, put e=e_k(Q), ell=ell_k(Y), and let tau be
the necessary BAND9 middle hitting time. If for some phase p

    Phi^(tau+2)(C_ell)[p] + E_e[p xor chi] >= h,

then V_(ell+1)>=C_ell, monotonicity of the exact backward operator,
and A_(e+1)>=E_e give a physical meeting at

    t=e+1, s=ell+1+tau+2.

The exact identity then yields P<=e+tau+ell+5. Applying this to a
minimizing endpoint pair proves P<=g_joint+5; combined with the accepted
joint physical lower2g_joint+1, it would imply T>=2P-9.

The remaining inequality retains both labeled hybrid seeds. It is
strictly different from the refuted assertion that an equal-seeded
necessary middle clock is repaired in two days in every physical phase.
This review does not supply that missing uniform inequality.

## Independent implementation audit

`physical-two-front-audit.py` builds the exact residual maps from the
literal diagonal-prefix neighborhood routine, obtains every inverse by
literal finite maximization, and checks all forward/backward splits in
five parity/budget fixtures. All5,445 meeting checks and the local
quadrant phase identities pass. These checks validate the convention
and implementation; the general adjunction proof above establishes the
identity, and no board sample is used as evidence for the open uniform
middle assertion.

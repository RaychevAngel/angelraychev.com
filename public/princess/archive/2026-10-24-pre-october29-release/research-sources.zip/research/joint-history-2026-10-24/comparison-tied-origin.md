# Exact admissibility of a common tied hybrid origin

24 October 2026. An algebraic characterization of the history retained by
the two hybrid fronts. This is not the pending uniform middle bound.

Fix k>=33 and the accepted cutoff R. Put L=R^2 and
Z=L+k-rho(L+k). Beyond its unique scalar crossing, the early hybrid has
the form

    E_t=H^t(x,x),
    D_t=H^t(x,x-delta),
    L<x<=Z, delta in{0,1},

where D is the late hybrid minus k and

    H(u,v)=(G(v),F(u)),
    G(z)=z+k-rho(z+k), F(z)=z+k-ceil(sqrt(z+k)).

Allowing every x in this interval and both delta choices is a relaxation
of the actual scalar crossing. Crucially, it still retains a COMMON tied
origin. An arbitrary near-boundary pair and arbitrary one-coordinate
error need not belong to this class.

## Exact interval inverses

For a positive integer target interval[a,b] in the relevant quadrant
range, the full integer preimages are

    G^{-1}([a,b]) = [a+ceil(sqrt(a))-k,
                    b+ceil(sqrt(b+1))-k],

    F^{-1}([a,b]) = [a+1+rho(a)-k,
                    b+1+rho(b+1)-k].                 (1)

If necessary these intervals are intersected with the nonnegative input
domain. All endpoints used in the critical-to-cutoff test are positive.

For example, the least integer u with u-rho(u)>=a is
a+ceil(sqrt(a)); substituting r=ceil(sqrt(a)) proves both the attained
inequality and its failure one integer earlier. Likewise the least u
with u-ceil(sqrt(u))>=a is a+1+rho(a). Because both forward maps are
nondecreasing and have integer increments zero or one, the upper inverse
endpoint for b is the least inverse endpoint for b+1 minus one. This
proves(1), including all square and pronic endpoint conventions.

The preimage under H of a Cartesian interval box I0 x I1 is exactly

    F^{-1}(I1) x G^{-1}(I0).                         (2)

This is an equality, not a bounding box approximation: the two output
coordinates depend on separate input coordinates. Iterating(2) therefore
preserves exactness for an arbitrary number of backward steps.

## The common-seed test

Given candidate current pairs E and D, start their inverse boxes as the
two singleton boxes. After t reverse steps write the boxes as
I0 x I1 and J0 x J1. A tied reset t steps earlier with initial discrepancy
delta exists if and only if

    (L,Z] intersect I0 intersect I1 intersect J0
          intersect (J1+delta)

contains an integer. The four coordinates in this intersection all refer
to the SAME seed x. This is the condition lost by independently bounding
the current spread and the error vector.

Necessity follows by applying exact preimages to an existing common
orbit. Conversely an integer in the displayed intersection supplies
initial E=(x,x),D=(x,x-delta) whose two H^t images are precisely the given
current pairs. Thus the test is both necessary and sufficient for the
relaxed tied-origin family at a specified t. Taking the union over t
gives the complete family. In the relevant positive-progress range the
inverse upper endpoints decrease until they lie below L+1, so this is a
finite evaluator. No constant-operation or width-independent running-time
claim is made.

## Falsification results and a positive control

The independent scalar audit in `comparison-tied-origin.py` checks12,492
literal interval memberships. The proof above supplies the unbounded
statement; this audit attacks its endpoint implementation.

All four saved failures of the arbitrary-common-pair middle relaxation
have NO tied origin in the entire allowed reset interval:

* k33: C=(680,674), E=C-k+(1,0).
* k101: C=(8841,8838), E=C-k+(1,0).
* k101: C=(8845,8847), E=C-k+(0,1).
* k101: C=(8842,8838), E=C-k.

For the last example, the relevant reverse boxes near the fast cutoff
are[3664,3672] x[3639,3639] and then
[3599,3599] x[3624,3632]. The tied-seed intervals remain separated by25
rooms while passing the reset interval[3601,3640]. There is no missing
choice of an earlier or later reset time.

As a positive control, the actual k1001 late pair C=(988043,988041) has
E=D=C-k. Reversing7,381 steps admits tied seeds[360164,360241] for delta0
and[360165,360241] for delta1. The exact scalar crossing is a member of
this admitted class. The reset error is already erased at this current
time, although an initial delta1 remains admissible.

## What remains open

This criterion proves precisely why the recorded relaxed-pair failures
do not refute the actual-hybrid meeting conjecture. It does not prove
that every tied-origin pair satisfies that conjecture. Nor does it turn
the history into a fixed finite list of local phase states: the inverse
intervals pass through a parameter-dependent number of root bins.

A promising next invariant would preserve enough information about the
intersection or separation of these inverse intervals through a full
root-bin transition. A spread bound alone discards that information.
Any finite wall certificate must either carry an equivalent admissibility
condition or prove that its broader input set satisfies the desired
meeting inequality. The latter has already failed for the broad sets
tested so far.

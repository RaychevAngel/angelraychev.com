# A two-day late contract from an arbitrary physical residual ceiling

24 October2026 UTC. New ordinary theorem submitted for independent review.
Accepted25-day sources remain unchanged. This is an interface lemma; no
nine-day full-game theorem is asserted.

Let w<=n have even area, b=floor(w/2), k>=max(75,b+1), and choose

    k<Y<=(b-5)^2, R=floor(3k/5), F_cut=R^2+k.

Consider any actual two-cohort history starting at merged residual
m_s>=Y and first reaching m_g<=k at time g. A physical anchored-prefix
residual trajectory starting at Y, in EITHER initial phase, reaches
residual at most k within

    g-s+2

transitions. A smaller incoming prefix residual only improves the bound.
If Y<=k the conclusion is immediate. If Y<=F_cut, the stronger allowance
is one. More generally, the allowance is one whenever the initial slow
phase is already aligned; the exact meaning of that condition is below.

## Genuine quadrant profiles and scalar crossings

Use the accepted physical survivor notation

    q=m-p=|S0|+|S1|-h>0, p<=k,
    sigma=sum_i(|N(Si)|-|Si|), m_next=q+sigma.

For q<=b^2 the already proved scalar inequality is sigma>=ceil(sqrt(q)).
The two prefix residual maps are

    phi0(x)=x-k+ceil(sqrt(x-k)),
    phi1(x)=x-k+1+rho(x-k)                       (x>k),

with gate value zero at x<=k. They are monotone and satisfy
phi1(x)<=phi0(x+1). Thus one reference step from any prefix at most x
puts it below an actual crossing from >x to <=x, for k<x<=Y. The
crossing source may be larger: its survivor q is bounded by its target
<=Y, where the scalar inequality is valid.

Every survivor used by a reference with residual at most Y fits the
quadrant. The upper ceiling is deliberately (b-5)^2; it is not replaced
by the smaller main-project cutoff (b-6)^2.

## Slow transitions: slack four, remainder five

At a slow source F_cut<m<=Y, one has q>R^2, and

    r=ceil(sqrt(q))>=R+1>=46, r<=b-5.

Call a transition good when sigma<=r+4, bad otherwise. At a good
transition sigma<=b-1<b. The same accepted small/co-small dichotomy and
canonical component argument give one small survivor cohort, with signed
q=|P|-D, and a unique dominant component of surplus a>sigma/2.
Put z=sigma-a. Then

    q<=(sigma-z)^2+z^2.

The inequality q>sigma^2/2 follows from
2((r-1)^2+1)>(r+4)^2 for r>=46. If z>=6, the displayed upper bound
is at most (r-2)^2+36, strictly smaller than (r-1)^2+1. Therefore z<=5.
There are at most25 small-cohort outlier cells and at most30 holes in
the other survivor cohort. The dominant component lies in its actual
corner ball of radius2a-2 and has a unique corner.

The remainder does not weaken the exact phase profile. In its own color
q<=sigma^2. In the opposite color,

    q<=a(a-1)+z^2<=sigma(sigma-1).

Thus good steps with the correct physical phase preserve reference
residual domination, including any existing room advantage.

## Changes of actual corner or cohort pay their rewinds

For consecutive good transitions Delta apart, the accepted matching
transport, distinct-corner half intersection, and the two25-cell outlier
budgets give, when the small cohort is unchanged but the corner changes,

    Delta*k >= (r-1)^2+1-(r+4)^2/2-50
             =r^2/2-6r-56,                         (1)

where r is the OLD root. A small-cohort change has the stronger charge
h-30-(b-1)^2. All Delta-1 intervening transitions are bad.

Let X<=m be a reference residual and D=m-X its lead. At a bad step,
q>=X-k+D, while the actual sigma>=r+5 and either reference profile
at X-k is at most r+1. Hence the lead increases by at least FOUR:

    m_next-X_next>=D+4.                             (2)

Set D0=k-R-1. At a slow source, phi0(m)>=m-D0. Therefore a reference
lead of D0 allows one previous reference step to be restored while
retaining domination; this flips the phase. As in the accepted late
proof, this is a rewind of an existing reference trajectory, not an
unproved exchange of corner labels.

The charge is uniformly sufficient. Since the quadratic in (1) increases
for r>=R+1>3k/5,

    4(Delta-1)-D0
      >=(8k^2-460k-5600)/(25k)>0                  (k>=75).

The numerator is positive at75 and increases thereafter. Thus every
later convention change earns its needed rewind credit on its own
intervening bad block. There is no accumulating time cost. An arbitrary
initial reference phase requires at most one extra forward step to align
with the first good transition. If it is already aligned, that step is
omitted; an all-bad interval needs no alignment either.

## Fast comparison and exact time bookkeeping

`physical-fast-one.md` proves that, at this R, every fast interval of
ell actual moves below F_cut has a physical gate comparison of at most
ell+1 moves, in either phase. All targets here are also below Y, so the
required prefixes fit the genuine quadrant.

Take the last crossing into residual<=Y, with t0=s if the actual history
starts at Y and never later returns from above. The crossing reset costs
one reference move only if t0>s, and is paid by the ignored actual time
t0-s>=1. If there is a slow segment, let t1 be its first exit to<=F_cut;
let t2 be the last later return to<=F_cut, or t1 if there is none. The
second crossing reset is needed only if t2>t1, and is paid by its ignored
excursion duration. These are precisely the accepted last-crossing
arguments, with arbitrary ceiling Y in place of the former fixed H.

The only costs not already paid are the initial slow phase adjustment
(at most one) and the fast comparison (one). This proves g-s+2, and
proves g-s+1 when the initial slow adjustment is unnecessary. If the
slow interval is empty the latter condition holds automatically.

## A usable conditional room-credit form

At any slow source m, define the local rewind cost

    D_local(m)=k-ceil(sqrt(m-k)).

If an incoming carried physical prefix has an existing previous step,
its current residual X satisfies X<=m-D_local(m), and that preceding
step has the genuine-quadrant profile, then its predecessor is at most m.
Indeed phi0(m)=m-D_local(m), while strict monotonicity would contradict
X<=phi0(m) if the predecessor exceeded m. Thus an initially wrong phase
can be corrected by a rewind rather than an additional forward step.
Under this explicit incoming-credit condition the late allowance is ONE.
A previous finite-board step is sufficiently local whenever its survivor
prefix and neighborhood fit; this condition must be checked at the join.

The unconditional two-day theorem does not require such incoming credit.
This note does not claim the middle comparison always supplies it.

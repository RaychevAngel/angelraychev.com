"""Finite scalar base for the three-fifths one-day fast lemma."""
from math import isqrt,factorial
from fractions import Fraction
from pathlib import Path
import hashlib,json

def rho(x):
 r=(isqrt(4*x+1)-1)//2
 return r+(r*(r+1)<x)

rows=[]
for k in range(33,75):
 R=3*k//5;cut=R*R+k;u=k-R-1;Y=t=0
 while Y<cut:
  Y+=k-rho(Y);t+=1
 assert t<=2*u
 rows.append(dict(k=k,R=R,cut=cut,u=u,scalar_hit=t,margin=2*u-t))
poly=sum(Fraction(97,100)**i/Fraction(factorial(i))for i in range(6))
assert poly-Fraction(444,169)==Fraction(1903592147933,202800000000000)>0
p=Path(__file__); note=p.with_name('physical-fast-one.md')
out=dict(status='PASS',budgets=42,width_or_length_samples=0,
 minimum_scalar_margin=min(r['margin']for r in rows),
 exponential_lower_bound_difference=str(poly-Fraction(444,169)),rows=rows,
 source_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in(p,note)})
p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items()if k!='rows'})

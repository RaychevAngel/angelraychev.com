"""Finite arithmetic base for early1 at the six-root cut."""
from math import isqrt
from pathlib import Path
import hashlib,json

def root(x):
 r=isqrt(x);return r+(r*r<x)
def rho(x):
 r=(isqrt(4*x+1)-1)//2;return r+(r*(r+1)<x)
def hits(k,top,phase=None):
 out=[0]*(top+1);x=t=0
 while x<top:
  N=x+k;y=N-(rho(N)if phase is None or(phase+t)%2==0 else root(N))
  assert y>x;t+=1
  for q in range(x+1,min(y,top)+1):out[q]=t
  x=y
 return out
rows=[];checks=0
for k in range(100,188):
 R=3*k//5;Z=R*R+k-rho(R*R+k);S=hits(k,Z);P=[hits(k,Z,p)for p in(0,1)]
 worst=max((P[p][q]-S[q],q,p)for p in(0,1)for q in range(1,Z+1))
 assert worst[0]<=1,(k,worst)
 checks+=2*Z
 r=R+1;D=k-R-1;delta=-(-(r*r-11*r-108)//(2*k))
 assert 3*(delta-1)>=D
 rows.append(dict(k=k,R=R,Z=Z,max_delay=worst[0],witness_target=worst[1],witness_phase=worst[2],switch_credit_margin=3*(delta-1)-D))
files=[Path(__file__),Path(__file__).with_name('lower-one-day-early-large-budget.md')]
out=dict(status='PASS',budget_count=len(rows),target_phase_checks=checks,width_or_length_samples=0,max_delay=max(r['max_delay']for r in rows),source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files},rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items()if k!='rows'})

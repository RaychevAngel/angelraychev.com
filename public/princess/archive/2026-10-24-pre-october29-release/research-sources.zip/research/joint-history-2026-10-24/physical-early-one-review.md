# Independent acceptance of early1 for budgets at least100

24 October2026 UTC. Accepted ordinary proof with finite scalar base:
`lower-one-day-early-large-budget.md`, under its explicit six-root cut
H=(b-6)^2 and max(100,b+1)<=k<3b. No lower-budget extension is inferred.

I checked the C4 concentration inequalities, the exact square/pronic
profile after aggregating the remainder, the matching charge
(r^2-11r-108)/2, and the three-room bad-step credit. Substituting
r>=3k/5+1/5 and D<=2k/5-1/5 gives precisely the stated polynomial
(7k^2-617k-8262)/(50k), positive at100 and thereafter.

The fast three-stage drift estimate and each rational numerator/
denominator bound are valid. The ceiling estimate259k/360+11 is at
most4k/5-4 for k>=188, so the half-frequency discrepancy fits into
one physical update. The physical prefix cutoff and the final actual
overshoot are inside the required genuine-quadrant window.

For the finite base100..187, an independent implementation checked all
1,343,660 targets and initial phases. Worst delay was one and the
minimum integer switch-credit margin was one. This took0.239 CPU seconds,
with no board dimensions enumerated.

Both reference phases can be advanced to the common entry time t0+1;
selecting the one aligned with the first good event then preserves the
accepted paid-rewind bookkeeping through the actual final overshoot.
This proves the stated pointwise early1 component, not a global gap9.

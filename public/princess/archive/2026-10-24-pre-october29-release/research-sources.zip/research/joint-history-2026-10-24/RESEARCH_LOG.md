# Joint history comparison: target nine-day uniform gap

Started24 October2026 UTC. The authorized target is P<=g+5 for every
actual first merged-gate time g, where P is the best complete solo
anchored-prefix capture clock. This implies T>=2P-9 and U<=2P.
The accepted25-day all-width bound in the preceding uniform-history
folder remains intact. No public or Lean claim is being changed here.

## Approach and ownership

- Root: a single physical history/phase/credit join, especially removing
  the artificial middle/late overlap and identifying sufficient credit.
- Lower lane: pointwise early domination, improved fast-entry arithmetic,
  and signed credit carried to the middle.
- Comparison lane: carry the original corner vector and both physical
  phases through low, central, and high transitions without equal resets.
- Physical lane: late-history credit contracts and independent attack on
  proposed joins and parameter guards.

## First findings

1. The previous early3 proof charged an avoidable entry-envelope delay.
   Comparing the actual entry target with its own scalar hitting time
   gives early2 with the same H=(b-5)^2. The lower lane has written the
   proof and finite scalar-budget base; the physical lane accepted the
   argument and is independently replaying its base arithmetic.

2. A first composition retaining signed phase errors but allowing every
   root-wall entry residue independently still permits a five-day delay
   at odd width/minimum budget. This is NOT a physical counterexample or
   a disproof of critical2. It identifies an overrelaxation: all wall
   spacings share one width parameter, and both boundaries share h.
   The next finite-state analysis must preserve these congruences or
   provide a stronger input-credit contract.

3. Changing the slow/fast cutoff can reduce the boundary costs. Candidate:
   R=floor(3k/5), good surplus<=r+4, and H=(b-6)^2. Remainder surplus
   is at most5 when r>=20. Early bad steps earn three room credits,
   while the matching switch bound is

       Delta*k >=(r^2-11r-108)/2.

   Its leading coefficient is enough to pay the local rewind cost.
   The scalar fast passage is short enough that one extra physical
   step may suffice. This is being proved with explicit finite-budget
   obligations, not inferred from an asymptotic estimate.

4. A root-only diagnostic reused the old all-residue low-wall simulator
   at6,7,9 root bins, with no board widths sampled. At6 bins it retains
   a two-day terminal comparison; at7 and9 bins the independent-residue
   relaxation permits three days at the minimum offset. This favors the
   six-bin cutoff above over a larger nine-bin cutoff. These are design
   diagnostics, not new accepted global theorems.

## Scope and evidence controls

The global requirement covers all w<=n and all feasible k. Parameter
base cases cannot be silently omitted. Earlier exact/one-day/small-width
theorems remain available, and new bounds are combined by maxima/minima.
No selected-width panel will be used to infer uniformity. Proofs, exact
finite-state arithmetic, physical interpretation, and Lean verification
remain separate obligations.

## Refined boundary and phase results

5. Early1 is now proved for every k>=33 in the unbounded-width target
   range. For33<=k<100 the cutoff is ceil(3k/5)+4; for k>=100 it is
   floor(3k/5). The finite base checks all scalar target thresholds and
   both phases. Independent review accepted the physical transfer.
   Late2 likewise covers every such budget and arbitrary admissible Y;
   its allowance is1 with compatible phase or sufficient local credit.

6. Both the ordinary and enriched nine-feature versions of a blanket
   critical MIN-phase<=2 assertion are false. Literal saved witnesses
   include w2001,n2002,k1001 with the six-root cut and admissible entry
   and exit offsets. These refute an overly strong intermediate lemma,
   not the requested full physical P<=g+5 inequality.

7. A phase-label error in interpreting the obstruction was caught:
   a hole prefix and its complementary support prefix have antipodal
   anchors. Their relative phases differ by(w+n-2) mod2. Keeping this
   conversion makes the source-feature-matched delay2 in the six-root
   witness, although the unrestricted minimum-phase delay is3.

8. The early comparison now supplies compatible corner/erosion features
   OR one room of actual unused prefix capacity. The proof uses exact
   punctured-quadrant capacities and does not assume the dominant corner
   is occupied. Root and the physical lane independently reviewed it.

9. The retained low and high nine-feature pairs satisfy balanced
   recurrences, stronger than the old one-sided projections. Root has
   independently verified the high recurrence on every deficit using
   the387-cell symbolic certificate and its finite base. The compatible
   source-face thresholds are each within one room of the overall
   threshold, exactly matching the early credit alternative. Critical
   cap interfaces, the complete elapsed-time comparison, and the late
   phase connection remain open; no global nine-day claim is made.

10. The new join uses the actual late source Y before the first crossing
    below H, so the middle and late intervals share a state but no move.
    Its exact identity is P<=g+e+c+l+1. The target thus needs a compatible
    e1,c2,l1 account, including any credits spent at the two interfaces.
    A high-budget guard check covers Y beyond the slow ceiling using the
    independently proved fast-only late contract.

11. A further target offset disproves even a standalone feature-matched
    critical2 assertion. At the same six-root witness, the extra middle
    delay occurs only at early targets where the actual zero-seed prefix
    already has zero early delay and spare rooms. The obstruction is an
    argument for retaining the endpoint capacities, not adding independent
    phase-wise worst-case delays.

12. Both boundary histories now have independently accepted necessary
    hybrid clocks. Each permits scalar relaxation only in the fast region
    and preserves the physical alternating recurrence afterwards. Their
    exact capacities, plus the existing nine-feature middle clock, define
    a joined necessary gate clock. In the critical2001x2002,k1001 witness
    it gives32727 while P=32728, hence a one-day capture bracket. This is
    one diagnostic, not a uniform comparison theorem.

13. The two hybrid boundary recurrences are conjugate: after subtracting k
    from the late capacity, their states differ by at most one room in one
    coordinate at every time. This statement has an algebraic proof and
    independent review. It replaces two unrelated boundary relaxations by
    two nearly identical copies of one numerical orbit.

14. Each boundary's crossing interval spans at most two hybrid clock
    values. Within a constant clock block, retaining the largest room
    count dominates all other choices in the joint minimization. Thus the
    full endpoint optimization reduces to at most two early and two late
    endpoint choices, without weakening its numerical lower bound. The
    remaining uniform obligation is P minus the joined clock at most5.

15. The exact physical two-front adjunction has now been proved and
    independently checked against literal prefix inverses. For early
    current-hole phase q, late source phase p, and chi=(w+n-2) mod2,
    the meeting condition is A_t[p xor chi]+V_s[p]>=h. It is equivalent
    to the complete solo clock P<=t+s+1. It permits a convenient meeting
    cut without selecting inconsistent phases. Same-phase fast-one
    domination at both hybrid boundaries reduces the nine-day target to
    a two-extra-middle-move meeting condition, still unproved uniformly.

16. Arbitrary common-orbit boundary seeds are too permissive. Saved
    counterexamples at b32,d1 and b100,d1 refute that relaxation, including
    one with no duality error. A half-drift spread bound is insufficient;
    a guessed square-spread bound is false even for actual hybrid states.
    Ten root bins of generic monotone history do not force the desired
    small spread. These failures concern intermediate numerical claims,
    not actual counterexamples to P<=g+5.

17. A bounded attack using actual hybrid boundary states checked all
    retained endpoint choices on116 short odd-by-even instances (b32..60,
    excess budgets1..4). The middle meeting condition survived, with at
    least two rooms of margin. The joined numerical lower can be nine
    days below the simple upper in this diagnostic:73x74,k37;
    81x82,k41;109x110,k55. Previous stronger bounds are still retained;
    these are NOT nine-day gaps to the actual optimum, nor a uniform
    proof from selected boards.

18. The even-width central nine-feature operator now has an exact
    algebraic expression, independently reviewed. Its two-room high-end
    guard matters: the adjacent omitted rank admits an extra branch.
    Combined with the odd-width formula, this supplies the central
    algebra for every even-area parity type. Whole-passage history and
    cap interfaces are separate obligations.

19. The current universal route splits large excess budgets from small
    ones. A room-credit comparison is being checked for excess d>=26
    (possibly slightly lower). The difficult small-excess input must
    retain common equal-reset origin. Exact inverse intervals exclude
    the saved fake boundary seeds and offer a more faithful invariant
    than phase spread alone. Neither pending route is being recorded as
    an accepted all-parameter nine-day theorem.

20. The large-excess comparison is now PROVED and independently reviewed,
    with the final thresholds d>=18 at even width and d>=20 at odd
    width/even length. Low injections share credit with their exit span;
    high clamps share credit with their terminal span; the odd top high
    root cannot clamp; the odd central exceptional edge cannot occur
    under k<3b; and exact paired physical progress absorbs the square
    entry. These are refinements of one proof, not separate theorem
    families added to the main count. Read `root-nine-day-families.md`.

21. Every width, length, and feasible budget remains covered by the
    combined bounds. The general nine-day target remains open only in
    excesses1..17 at even width and1..19 at odd width/even length, with
    widths and lengths still unbounded. The new necessary joint clock
    applies there too; the old23/25-day guarantees and stronger special
    cases are retained. The largest proved all-input ceiling is still25.

22. The exact common-origin inverse criterion has passed independent
    review. It excludes all four saved fake middle seeds and admits the
    genuine positive control. The next mathematical obligation is a
    uniform implication from that origin condition to the paired meeting
    inequality in the residual excess ranges. No such implication is
    claimed at this checkpoint. Public artifacts and Lean are unchanged.

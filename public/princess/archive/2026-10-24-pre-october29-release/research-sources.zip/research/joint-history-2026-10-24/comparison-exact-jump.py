"""Exact root-cell acceleration, for symbolic residue investigations."""
from math import isqrt
from bisect import bisect_right
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'src'))
from bridge_corner_frontier import step as ordinary_step

def R(q):
    x=isqrt(max(0,q));return x+(x*x<q)
def rho(q):
    x=(isqrt(max(0,4*q+1))-1)//2;return x+(x*(x+1)<q)

def update(b,n,k,q,odd,ordinary=False):
    h=(2*b+int(odd))*n//2
    B=q[:3];X=q[3:]
    if ordinary:
        Bn=ordinary_step(2*b+int(odd),n,k,B)
    else:
        Bn=[]
        for i in range(3):
            opts=[]
            for j,z in enumerate(B):
                a,beta,g,delta=R(z),rho(z),R(h-z),rho(h-z)
                lo=beta+int(i==0) if j==0 else a+int(j==2)
                hi=delta+3-i if j==0 else(g+2-i if j==1 else delta+2-int(i>0))
                cap=b+1
                if (not odd and i>=1 and j==1)or(odd and i==2 and j==0):cap=b
                if not odd and n==2*b+1 and i==2 and j==0:cap=b
                opts.append(z+k-min(lo,hi,cap))
            Bn.append(min(h,max(opts)))
    Xn=[]
    for p in range(2):
        z=X[1-p]
        if odd:
            cost=min(rho(z),b,R(h-z))if p==0 else min(R(z),b+1,1+rho(h-z))
        else:
            phase=1-p
            cost=min(R(z)if phase==0 else rho(z),b,R(h-z)if phase==n%2 else 1+rho(h-z))
        Xn.append(min(h,z+k-cost))
    return tuple(Bn)+tuple(Xn)

def cuts(b,h,C,ordinary=False):
    out={0,h}
    for r in range(b-C-2,b+4):
        for z in(r*r,r*(r+1)):
            for off in(range(-8,9)if ordinary else(0,1)):
                out.add(z+off);out.add(h-z+off)
    return sorted(out)

def run(b,n,d,odd=False,C=5,ordinary=False,target_offset=0,seed_offset=0):
    h=(2*b+int(odd))*n//2;k=b+d;H=(b-C)**2;M=h-H-target_offset
    cs=cuts(b,h,C,ordinary);q=(H+seed_offset,)*5;t=0;modeltime=None;iterations=0;jumps=0;strides=set();phase_times=[None,None]
    while min(q[3:])<M:
        if max(q[:3])>=M and modeltime is None:modeltime=t
        for p in range(2):
            if q[p+3]>=M and phase_times[p] is None:phase_times[p]=t
        y=update(b,n,k,q,odd,ordinary);z=update(b,n,k,y,odd,ordinary)
        ds={a-c for a,c in zip(z,q)}
        if len(ds)==1 and next(iter(ds))>0 and modeltime is None:
            D=next(iter(ds));cap=10**100
            for s in(q,y):
                for v in s:
                    c=cs[bisect_right(cs,v)]
                    cap=min(cap,(c-1-v)//D)
            cap=min(cap,(M-1-max(q[:3]))//D,(M-1-min(q[3:]))//D)
            if cap>=1:
                # Every coordinate stays within its current root cell.
                q=tuple(v+cap*D for v in q);t+=2*cap;jumps+=1;strides.add(D);continue
        q=y;t+=1;iterations+=1
        assert iterations<100000
    if modeltime is None:modeltime=t
    phase_times=[t if p is None else p for p in phase_times]
    return dict(b=b,n=n,d=d,odd=odd,C=C,ordinary=ordinary,seed_offset=seed_offset,target_offset=target_offset,modeltime=modeltime,physicaltime=t,phase_times=phase_times,best_gap=min(phase_times)-modeltime,gap=t-modeltime,iterations=iterations,jumps=jumps,strides=sorted(strides))

if __name__=='__main__':
    import json
    for odd in(False,True):
        print(json.dumps(run(1000,2000+2*int(odd),1,odd)))

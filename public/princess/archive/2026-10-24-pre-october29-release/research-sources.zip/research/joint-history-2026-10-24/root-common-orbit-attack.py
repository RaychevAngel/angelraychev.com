"""Attack the proposed meeting inequality with relaxed common-orbit inputs.

These seeds need not occur from zero. A failure refutes this relaxation,
not the physical game or the actual hybrid-front conjecture.
"""
from pathlib import Path
import importlib.util
from math import isqrt
import json,time,argparse
HERE=Path(__file__).resolve().parent
def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
nine=load('common_attack_nine',HERE.parent/'uniform-gap-2026-10-23/lower-band9.py')
def root(x):return isqrt(x-1)+1 if x else 0
def rho(x):
    q=(isqrt(4*x+1)-1)//2;return q+(q*(q+1)<x)
def physical(w,n,k,X):
    b=w//2;h=w*n//2;out=[]
    for p in(0,1):
        z=X[1-p]
        if w%2:cost=min(rho(z),b,root(h-z)) if p==0 else min(root(z),b+1,1+rho(h-z))
        else:
            phase=1-p
            cost=min(root(z) if phase==0 else rho(z),b,
                     root(h-z) if phase==n%2 else 1+rho(h-z))
        out.append(min(h,z+k-cost))
    return tuple(out)

def run(b,d,odd=True,extra_length=0,allow_error=True,span_limit=None):
    start=time.process_time();w=2*b+int(odd);n=w+int(odd)+extra_length
    assert w*n%2==0
    h=w*n//2;k=b+d;H=(b-6)**2;chi=(w+n-2)%2
    qmax=H-1+k-rho(H-1+k);ymax=H+k-rho(H)
    times={}
    for Y in range(H+1,ymax+1):
        B={f:Y for f in nine.FEATURES};day=0;qs=list(range(qmax,H-1,-1))
        while qs:
            while qs and max(B.values())>=h-qs[0]:times[Y,qs.pop(0)]=day
            if qs:B=nine.step(w,n,k,B);day+=1
    checked=0;worst=1000000000;failure=None
    for Cmax in range(H+1,H+2*(d+8)+1):
      for spread in range((d+8 if span_limit is None else span_limit)+1):
       for high in(0,1):
        C=(Cmax,Cmax-spread) if high==0 else(Cmax-spread,Cmax)
        Y=min(ymax,Cmax)
        # Both possible one-room discrepancies of the dual hybrid orbit.
        for error in(((0,0),(1,0),(0,1)) if allow_error else ((0,0),)):
            E=tuple(c-k+z for c,z in zip(C,error));j=0
            while max(E)<H:
                E=(E[1]+k-rho(E[1]+k),E[0]+k-root(E[0]+k));j+=1
            for eextra in(0,1):
                if eextra:E=(E[1]+k-rho(E[1]+k),E[0]+k-root(E[0]+k))
                Q=min(qmax,max(E));tau=times[Y,Q]
                X=C
                for _ in range(tau+2):X=physical(w,n,k,X)
                margins=tuple(X[p]+E[p^chi]-h for p in(0,1));margin=max(margins)
                worst=min(worst,margin);checked+=1
                if margin<0:
                    failure=dict(C=C,error=error,E=E,Y=Y,Q=Q,tau=tau,X=X,margins=margins,j=j+eextra)
                    return dict(b=b,d=d,w=w,n=n,checked=checked,worst_margin=worst,
                                failure=failure,cpu_seconds=time.process_time()-start)
    return dict(b=b,d=d,w=w,n=n,checked=checked,worst_margin=worst,failure=None,
                cpu_seconds=time.process_time()-start)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('b',type=int);ap.add_argument('d',type=int)
    ap.add_argument('--even',action='store_true');ap.add_argument('--extra-length',type=int,default=0)
    ap.add_argument('--no-error',action='store_true');ap.add_argument('--span-limit',type=int)
    ap.add_argument('--output');a=ap.parse_args();r=run(a.b,a.d,not a.even,a.extra_length,not a.no_error,a.span_limit)
    if a.output:Path(a.output).write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps(r))

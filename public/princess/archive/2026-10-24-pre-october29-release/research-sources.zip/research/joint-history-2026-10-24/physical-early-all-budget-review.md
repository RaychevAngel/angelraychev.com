# Independent review: early one-day comparison, all budgets

24 October 2026. ACCEPTED as an ordinary theorem with a finite arithmetic
base. This is not a global nine-day capture theorem or a Lean proof.

I independently reimplemented the integer roots and all first-hit clocks
for the 67 budgets33..99. All280,322 target/phase comparisons give delay at
most one. The early matching-block credit has minimum margin one. The
checker samples neither board widths nor lengths.

The transfer from this arithmetic base to arbitrary boards is valid:
the matching charge is increasing above the tested minimal root, and
both concentration inequalities hold already at that root. The larger
cutoff only shortens the slow interval. If a slow interval exists then
H>R^2 and the final crossing remains below the genuine quadrant ceiling;
the proof of that fact uses R>3k/5 and is therefore preserved. In a
fast-only passage the actual crossing target is below the tested Z.

I also accept `lower-early-phase-credit-contract.md` as bookkeeping of
the maintained comparison path. Starting at s(A)+e and rewinding N times
gives index tau+e-W-N exactly. The final carried phase is constrained by
the actual good-event history. Advancing once offers the opposite phase
numerically, and the stated terminal room-credit test permits a genuine
predecessor rewind. Neither operation supplies an unproved free phase
choice to a joined critical/late comparison.

The attached JSON records hashes of the reviewed sources and independent
arithmetic totals. The k>=100 theorem had already been reviewed separately.

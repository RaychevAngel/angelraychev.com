"""Uniform algebraic audit of the retained high pair; no full-game bound."""
from pathlib import Path
import importlib.util
import json
import time

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'uniform-history-2026-10-23'
spec = importlib.util.spec_from_file_location('high_cert', OLD / 'lower-high-pattern-certificate.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
m = c.m


def check_pair(p, z):
    # Indices 5=(1,2), 7=(2,1). Work with deficits, so faces take minima.
    assert min(p[:6]) == p[5]
    assert min(p[i] for i in (0, 1, 3, 4, 6, 7)) == p[7]
    assert max(p[5], p[7]) <= 1
    assert abs(p[5] - p[7]) <= 1


def run():
    before = time.process_time()
    # Use the preserved, already certified list, rather than rediscover it.
    receipt = json.loads((OLD / 'lower-high-pattern-certificate.json').read_text())
    patterns = [tuple(p) for p in receipt['patterns']]
    finite = symbolic = 0
    clamp_patterns = set()
    for p in patterns:
        check_pair(p, None)
        for d in range(4, c.R0 ** 2):
            z = m.image(d, p)
            a = d + p[5] + m.root(d + p[5])
            b = d + p[7] + m.pronic(d + p[7])
            assert (z[7], z[5]) == (a, min(b, a + 1)), (p, d, z, a, b)
            if b > a + 1:
                clamp_patterns.add(p)
                assert b == a + 2
            finite += 1
        for lo, hi in c.arrangement():
            z = [min(p[3*j+v] + c.symbolic_cost(p[3*j+v], min(cc,v), min(e,j),j,v,lo,hi)
                     for j,v in m.FEATURES) for cc,e in m.FEATURES]
            # Every expression here denotes the constant after subtracting d+r.
            a = p[5] + c.root_offset('square', p[5], lo, hi)
            b = p[7] + c.root_offset('pronic', p[7], lo, hi)
            assert (z[7], z[5]) == (a, min(b, a + 1)), (p, lo, hi, z, a, b)
            if b > a + 1:
                clamp_patterns.add(p)
                assert b == a + 2
            symbolic += 1
    assert clamp_patterns == {(1,1,1,1,1,0,1,1,0)}
    return dict(status='PASS', scope=__doc__, finite_deficits=[4,c.R0**2-1],
                finite_checks=finite, root_indices_from=c.R0, symbolic_cells=symbolic,
                phase_pair=['D(2,1)','D(1,2)'],
                recurrence=['A(y)-k','min(B(x),A(y)+1)-k'],
                face_identities=True, face_distance_from_overall_minimum_at_most=1,
                unique_clamp_pattern=list(next(iter(clamp_patterns))),
                cpu_seconds=time.process_time()-before)


if __name__ == '__main__':
    result = run()
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

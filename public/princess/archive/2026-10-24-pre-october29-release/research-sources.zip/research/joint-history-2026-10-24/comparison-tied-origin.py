"""Exact inverse-interval test for a common tied quadrant origin.

This is an admissibility evaluator, not a uniform capture-time proof.
"""
from math import isqrt
from pathlib import Path
import json
import hashlib


def root(x):
    return isqrt(x)+(isqrt(x)**2<x)


def rho(x):
    q=(isqrt(4*x+1)-1)//2
    return q+(q*(q+1)<x)


def scalar_preimage(interval,k,kind):
    a,b=interval
    assert 1<=a<=b
    if kind=='G':
        return a+root(a)-k,b+root(b+1)-k
    return a+1+rho(a)-k,b+1+rho(b+1)-k


def pair_preimage(box,k):
    return scalar_preimage(box[1],k,'F'),scalar_preimage(box[0],k,'G')


def origins(k,C,error):
    """Find every possible tied reset in the allowed fast crossing range.

    E_l=C-k+error, D_l=C-k. A reset has E_0=(x,x) and
    D_0=(x,x-delta), delta in{0,1}. The cutoff is the accepted one.
    """
    R=(3*k+4)//5+4 if k<100 else 3*k//5
    L=R*R;Z=L+k-rho(L+k)
    E=tuple((c-k+e,c-k+e)for c,e in zip(C,error))
    D=tuple((c-k,c-k)for c in C)
    found=[];trace=[]
    for t in range(1000000):
        row=[]
        for delta in(0,1):
            lo=max(L+1,E[0][0],E[1][0],D[0][0],D[1][0]+delta)
            hi=min(Z,E[0][1],E[1][1],D[0][1],D[1][1]+delta)
            if lo<=hi:
                found.append(dict(elapsed=t,delta=delta,seed_interval=[lo,hi]))
            row.append(dict(delta=delta,lo=lo,hi=hi,separation=lo-hi))
        if min(E[0][0],E[1][0],D[0][0],D[1][0])<=Z:
            trace.append(dict(elapsed=t,E=E,D=D,intersections=row))
        if max(E[0][1],E[1][1],D[0][1],D[1][1])<L+1:
            break
        E=pair_preimage(E,k);D=pair_preimage(D,k)
    else:
        raise AssertionError('inverse orbit did not reach cutoff')
    return dict(k=k,C=C,error=error,R=R,reset_range=[L+1,Z],
                compatible_origins=found,cutoff_trace=trace,
                reverse_steps=t)


def audit():
    # Independent literal scalar membership checks; inverse endpoints are
    # proved symbolically in the companion note.
    scalar_checks=0
    for k in(4,7,20,33):
        for kind in('F','G'):
            forward=(lambda z:z+k-root(z+k))if kind=='F'else(lambda z:z+k-rho(z+k))
            for a in range(k+1,k+81):
                for b in(a,a+1,a+3):
                    lo,hi=scalar_preimage((a,b),k,kind)
                    for z in range(max(0,lo-2),hi+3):
                        assert (a<=forward(z)<=b)==(lo<=z<=hi)
                        scalar_checks+=1
    cases=[(33,(680,674),(1,0)),(101,(8841,8838),(1,0)),
           (101,(8845,8847),(0,1)),(101,(8842,8838),(0,0)),
           (1001,(988043,988041),(0,0))]
    results=[origins(*row)for row in cases]
    assert all(not r['compatible_origins']for r in results[:4])
    assert results[4]['compatible_origins']
    return dict(status='PASS',scope=__doc__,scalar_membership_checks=scalar_checks,
                cases=results,uniform_middle_bound_proved=False,
                sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in (Path(__file__),Path(__file__).with_suffix('.md'))})


if __name__=='__main__':
    result=audit()
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],checks=result['scalar_membership_checks'],
                         origins=[r['compatible_origins']for r in result['cases']])))

"""Exploratory composition of the phase-labeled balanced boundary maps.

Independent wall residues form an overapproximation; central projection
and finite-board interfaces are obligations, not asserted here.
"""
from pathlib import Path
import json

def normalize(q,high=False):
    s=min(q[:2])if high else max(q[:2])
    return tuple(x-s for x in q)

def advance(q,F,G,high=False):
    x,y,p,r=q
    if high:
        z=F(y)
        return z,min(G(x),z+1),F(r),G(p)
    z=G(y)
    return z,max(F(x),z-1),G(r),F(p)

def variants(state,v,half,high=False):
    # half=True means equal maps; otherwise the second profile differs1.
    if high:
        F=lambda x:x-v;G=(lambda x:x-v)if half else(lambda x:x-v+1)
    else:
        F=lambda x:x+v;G=(lambda x:x+v)if half else(lambda x:x+v+1)
    out={state};q=normalize(advance(state,F,G,high),high);out.add(q)
    for _ in range(3):
        q=normalize(advance(q,F,G,high),high);out.add(q)
    return out

def wall(states,v,pronic,high=False):
    if high:
        if pronic:F=lambda q:q-v;G=lambda q:q-v+(q>0);half=False
        else:F=lambda q:q-v-(q<=0);G=lambda q:q-v;half=True
    else:
        if pronic:F=lambda q:q+v;G=lambda q:q+v+(q<0);half=False
        else:F=lambda q:q+v-(q>=0);G=lambda q:q+v;half=True
    out=set();maxexit=0
    for state in states:
        for s in variants(state,v,half,high):
            entries=range(1,v+3)if high else range(-v-2,0)
            for entry in entries:
                q=tuple(x+entry for x in s)
                nxt=advance(q,F,G,high)
                if (min(nxt[:2])>0 if high else max(nxt[:2])<0):continue
                steps=0
                while(max(q)>0 if high else min(q)<0):
                    q=advance(q,F,G,high);steps+=1;assert steps<200
                for _ in range(2):q=advance(q,F,G,high)
                out.add(normalize(q,high));maxexit=max(maxexit,-min(q[:2])if high else max(q[:2]))
    return out,dict(states=len(out),maxexit=maxexit)

def delays(q,F,G):
    x,y,p,r=q;times=[None,None];t=0
    while any(a is None for a in times):
        if p<=x and times[0]is None:times[0]=t
        if r<=y and times[1]is None:times[1]=t
        if all(a is not None for a in times):break
        p,r=F(r),G(p);t+=1;assert t<100
    return times

def audit(states,v,half):
    F=lambda q:q-v;G=(lambda q:q-v)if half else(lambda q:q-v+1)
    rows=[]
    for state in states:
        for q in variants(state,v,half,True):rows.append((max(delays(q,F,G)),q,delays(q,F,G)))
    return max(rows)

def run(C=6):
    rows=[]
    for d in range(1,6):
        states={(0,0,0,0)};trace=[]
        for j in range(C-1,-1,-1):
            states,m=wall(states,d+j,True);trace.append(dict(side='low',j=j,kind='pronic',**m))
            if j:states,m=wall(states,d+j,False);trace.append(dict(side='low',j=j,kind='square',**m))
        lowstates=states
        for odd in(False,True):
            states=lowstates
            if odd:
                states,m=wall(states,d,False)
            states={tuple(-x for x in q)for q in states}
            # Stable central translations have arbitrary parity/length.
            if odd:
                middle=set()
                for s in states:middle|=variants(s,d,False,True)
                states=middle
                states,m=wall(states,d,True,True)
            else:
                states|={(y,x,r,p)for x,y,p,r in states}
            hightrace=[]
            for j in range(C):
                hightrace.append(dict(j=j,kind='lower',worst=audit(states,d+j,True)))
                if j==C-1:break
                states,m=wall(states,d+j,False,True);hightrace.append(dict(j=j,kind='square',**m))
                hightrace.append(dict(j=j+1,kind='upper',worst=audit(states,d+j+1,False)))
                states,m=wall(states,d+j+1,True,True);hightrace.append(dict(j=j+1,kind='pronic',**m))
            rows.append(dict(d=d,odd=odd,states=len(states),maxdelay=max(x['worst'][0]for x in hightrace if 'worst'in x),trace=hightrace,lowtrace=trace))
    return dict(status='EXPLORATORY_ONLY',C=C,width_samples=0,rows=rows)

if __name__=='__main__':
    result=run();Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print([dict(d=r['d'],odd=r['odd'],maxdelay=r['maxdelay'],states=r['states'])for r in result['rows']])

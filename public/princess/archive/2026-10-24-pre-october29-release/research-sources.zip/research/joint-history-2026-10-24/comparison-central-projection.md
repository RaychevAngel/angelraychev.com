# The physical phase changes its corner-feature pair across the center

24 October2026 UTC. Algebraic assessment using the exact operator in
`root-central-nine-operator.md`. This does not yet prove a passage bound.

At odd width w=2b+1, let L=b(b+1), E=h-b², U=h-b(b-1).
The source prefix in physical phase0 has features(1,0) before its second
occupied corner enters at size b²+1; then(2,0), and finally(2,1) when
the first far eroded corner enters at U. Physical phase1 starts with
features(0,1), changes to(0,2) at L+1, and to(1,2) at E.

These are literal prefix ranks. For a corner z=(x,y), its occupied
threshold is its rank in increasing x+y/decreasing x order. The eroded
threshold of an opposite-color corner is the larger of the ranks of its
two neighbors. Thus no new phase may be selected at any of these changes.

In particular near full size the paired model quantities are
(B(2,1),B(1,2)), in the same order as the physical capacity pair. The
opposite-corner hole phase is XOR1 with this source phase. At even width
and even length the high pair is reversed; at even width and odd length
the same order applies. Literal small-grid counts independently checked
these parity conventions.

The central normalized patterns, in the ordering used by the root lane,
are

    0:000/000/000   1:100/000/000   2:100/100/100
    3:111/000/000   4:111/110/000   5:111/110/110
    6:111/111/000   7:222/111/000.

Far enough from the three interfaces that every input/output coordinate
uses the same displayed feature pair, substitution into the exact
central operator gives the following stable cycles:

* Between b² and L, the pair is(B20,B01), and the stable cycle is0<->3.
* Between L and E, it is(B20,B02), with stable cycle0<->6.
* Between E and U, it is(B20,B12), again0<->6.
* Beyond U, it is(B21,B12), with fixed pattern4 or cycle5<->7.

On every one of those stable cycles the projected update is exactly the
physical two-phase update. In the first three intervals the updates have
increments d and d-1, d=k-b; beyond U both increments are d until the
next root wall. The model does not accumulate a new error per day in any
of these intervals, however long the rectangle is.

The remaining central obligations are finite interface windows and
incoming nonstable patterns. For example pattern2 in the first interval
raises the physical second output by one; pattern2 entering the second
interval can pass through pattern7 before stabilizing. It is not sound
to assume all eight input patterns can arise at every interface without
paying for their earlier history. Conversely, bulk-cycle exactness alone
does not justify discarding these exceptional transitions.

An exploratory composed wall calculation with independently selected
residues still allows phase-matched delays4 at d=1 and3 at d=2,3. Those
are overapproximation paths, not physical or fixed-parameter
counterexamples. They lose the common-width relation between the low
and high wall spacings. Establishing the correct joint residue or
history-credit condition remains the substantive passage problem.

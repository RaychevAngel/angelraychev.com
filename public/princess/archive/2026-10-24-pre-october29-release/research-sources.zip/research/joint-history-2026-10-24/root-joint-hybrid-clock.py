"""Three-passage necessary clock preserving the actual endpoint sizes.

Uses physical-history boundary theorems and the accepted necessary nine-
feature merger. The uniform gap<=9 remains a separate comparison question.
"""
from pathlib import Path
from math import isqrt
import importlib.util
import argparse
import json
import time
import hashlib

HERE=Path(__file__).resolve().parent


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result


nine=module('joint_clock_nine',HERE.parent/'uniform-gap-2026-10-23/lower-band9.py')
prefix=module('joint_clock_prefix',HERE.parent/'uniform-history-2026-10-23/root-prefix-clock.py')
early_api=module('joint_clock_early',HERE/'lower-hybrid-necessary-clock.py')
late_api=module('joint_clock_late',HERE/'physical_hybrid_late.py')
meeting_api=module('joint_clock_meeting',HERE/'root-common-orbit-attack.py')


def rho(x):
    s=(isqrt(4*x+1)-1)//2
    return s+(s*(s+1)<x)


def root(x):
    s=isqrt(x)
    return s+(s*s<x)


def cutoff(k):
    return (3*k+4)//5+4 if k<100 else 3*k//5


def boundary_clocks(k,targets,early):
    targets=sorted(set(targets));R=cutoff(k)
    if early:
        G=lambda x:x+k-rho(x+k)
        F=lambda x:x+k-root(x+k)
        cap=G(R*R);scalar=0;pair=(0,0)
    else:
        G=lambda x:k+x-rho(x)
        F=lambda x:k+x-root(x)
        cap=R*R+k;scalar=k;pair=(k,k)
    day=0;out={};i=0
    while i<len(targets):
        while i<len(targets) and targets[i]<=max(pair):
            out[targets[i]]=day;i+=1
        if i==len(targets):break
        scalar=G(scalar)
        new=(max(min(cap,scalar),G(pair[1])),max(min(cap,scalar),F(pair[0])))
        assert max(new)>max(pair),(k,day,pair,new)
        pair=new;day+=1
    return out


def evaluate(w,n,k):
    before=time.process_time();w,n=sorted((w,n));b=w//2;h=w*n//2
    assert w*n%2==0 and b>=32 and b+1<=k<3*b
    H=(b-6)**2
    qs=list(range(H,H-1+k-rho(H-1+k)+1))
    ys=list(range(H+1,H+k-rho(H)+1))
    early_model=early_api.EarlyHybrid(k)
    e=early_model.clock(H)
    q0=min(qs[-1],early_model.maxima[e])
    q_candidates=[q0]+([qs[-1]] if q0<qs[-1] else [])
    early={Q:early_model.clock(Q) for Q in q_candidates}
    assert set(early.values())<={e,e+1}
    late_model=late_api.hybrid_gate_curve(k,ys[-1],keep_phases=True)
    ell=late_api.gate_time(late_model,H+1)
    y0=min(ys[-1],late_model['maxima'][ell])
    y_candidates=[y0]+([ys[-1]] if y0<ys[-1] else [])
    late={Y:late_api.gate_time(late_model,Y) for Y in y_candidates}
    assert set(late.values())<={ell,ell+1}
    best=None;witness=None;layers=0;meetings=[]
    early_physical={};A=(0,0)
    for day in range(max(early.values())+2):
        if day in {e+1 for e in early.values()}:early_physical[day]=A
        A=(A[1]+k-rho(A[1]+k),A[0]+k-root(A[0]+k))
    late_physical={};V=(k,k)
    for day in range(max(late.values())+2):
        if day in {ell+1 for ell in late.values()}:late_physical[day]=V
        V=(k+V[1]-rho(V[1]),k+V[0]-root(V[0]))
    chi=(w+n-2)%2
    for Y in y_candidates:
        B={f:Y for f in nine.FEATURES};day=0
        X=late_model['phases'][late[Y]]
        XP=late_physical[late[Y]+1]
        pending=list(reversed(q_candidates))
        while pending:
            while pending and h-pending[0]<=max(B.values()):
                Q=pending.pop(0);g=early[Q]+day+late[Y]
                XX=meeting_api.physical(w,n,k,meeting_api.physical(w,n,k,X))
                XXP=meeting_api.physical(w,n,k,meeting_api.physical(w,n,k,XP))
                EE=early_model.states[early[Q]];AA=early_physical[early[Q]+1]
                meetings.append(dict(Q=Q,Y=Y,gate_clock=g,
                                     hybrid_middle_two_margin=max(XX[p]+EE[p^chi]-h for p in(0,1)),
                                     physical_shifted_margin=max(XXP[p]+AA[p^chi]-h for p in(0,1))))
                if best is None or g<best:
                    best=g;witness=dict(Q=Q,Y=Y,early=early[Q],middle=day,late=late[Y])
            if not pending:break
            B=nine.step(w,n,k,B)
            X=meeting_api.physical(w,n,k,X);XP=meeting_api.physical(w,n,k,XP)
            day+=1;layers+=1
        assert day<4*w*n
    P=min(prefix.clock(w,n,k,p) for p in (0,1))
    low=2*best+1;up=2*P
    assert low<=up,(w,n,k,low,up,witness)
    return dict(w=w,n=n,k=k,H=H,early_endpoints=len(qs),late_endpoints=len(ys),
                retained_early_endpoints=q_candidates,retained_late_endpoints=y_candidates,
                necessary_gate_clock=best,P=P,P_minus_gate=P-best,
                history_lower=low,physical_upper=up,gap=up-low,
                minimizing_endpoints=witness,nine_layers_evaluated=layers,
                paired_meetings=meetings,
                cpu_seconds=time.process_time()-before,
                scope='Pointwise necessary history clock; uniform gap<=9 not inferred from this evaluation.')


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('w',type=int);ap.add_argument('n',type=int);ap.add_argument('k',type=int)
    ap.add_argument('--output');a=ap.parse_args();result=evaluate(a.w,a.n,a.k)
    if a.output:
        result['evaluator_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        Path(a.output).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

# At most four endpoint pairs suffice in the joint necessary clock

24 October 2026. Algebraic compression of the proposed joint evaluator,
submitted for independent review. This preserves the entire endpoint
minimum; it does not estimate that minimum by selected endpoints.

Use the rectangle and budget range of the six-root joint interface.
Let H=(b-6)^2 and

    Qmax=H-1+k-rho(H-1+k),
    Ymax=H+k-rho(H).

The actual early crossing holes Q and actual late source residual Y lie
in the integer intervals [H,Qmax] and [H+1,Ymax]. Write e(Q) for the
accepted early hybrid clock and ell(Y) for the accepted late hybrid clock.
Let m(Q,Y) be the first time that the accepted nine-feature backward
frontier, initialized with every threshold equal to Y, has maximum at
least h-Q. The joint necessary clock is

    J=min_(Q,Y) [ e(Q)+m(Q,Y)+ell(Y) ].             (1)

Only at most TWO early endpoints and TWO late endpoints need be retained.

## Early endpoints

Put e0=e(H), and let E_(e0) be the early hybrid pair. Define

    Q0=min(Qmax,max E_(e0)).

Then retain Q0 and, only if Q0<Qmax, Qmax. All original early endpoints
have clock e0 or e0+1, and these are the largest endpoints in their two
constant-clock blocks.

Indeed, for any pair (x,y), the maximum after its ordinary H update is
at least F(max(x,y)); the scalar injection only increases it. Exact
interlacing of the forward maps gives

    F(H)>=G(H-1)=Qmax.

Since max E_(e0)>=H, every early endpoint is reached by e0+1. The
endpoints through Q0 are reached at e0, and, if there are any remaining
ones, their first time is exactly e0+1.

## Late endpoints

Put ell0=ell(H+1), and let C_(ell0) be the late hybrid pair. Define

    Y0=min(Ymax,max C_(ell0)).

Retain Y0 and, only if Y0<Ymax, Ymax. These likewise represent the
constant-clock blocks ell0 and ell0+1. Here the exact root identity is

    F_back(H+1)=H+1+k-ceil(sqrt(H+1))
               =H+k-rho(H)=Ymax,

because H is a positive square. The next maximum argument is identical.

## Why keeping the largest endpoint preserves the minimum

For fixed Y, m(Q,Y) is nonincreasing in Q, since its target h-Q decreases.
For fixed Q it is nonincreasing in Y: the initial nine thresholds all
increase with Y, and every accepted backward update is monotone in the
threshold vector. This is the established capacity monotonicity of the
ordinary/banded nine evaluator, not a presumed monotonicity between the
corner or erosion feature labels.

Within any product of constant e/ell blocks, replace Q and Y by their
largest values. The two boundary clocks are unchanged and m cannot
increase. The largest values belong to the original ranges, so this
operation proves equality, not merely one inequality, between(1) and
the minimum over the retained at-most-four pairs.

The mathematical claim is conditional only on using a middle evaluator
with the stated seed monotonicity. In particular it applies to the
accepted nine-feature frontier used in `root-joint-hybrid-clock.py`.
It does not silently extend to a differently seeded or nonmonotone
feature-selection heuristic.

## Computational implication

There is no need to construct either parameter-length endpoint list.
Compute Qmax,Ymax directly, grow each boundary clock through its largest
target, and retain the two maxima above. At most two middle frontier
runs suffice, one per retained Y, stopping each run as it crosses the
one or two retained targets h-Q.

This removes endpoint-search growth from the exact joint evaluator.
The boundary recurrences and middle frontier iteration remain; this
is not the final O(1) numerical expression sought for the full problem.

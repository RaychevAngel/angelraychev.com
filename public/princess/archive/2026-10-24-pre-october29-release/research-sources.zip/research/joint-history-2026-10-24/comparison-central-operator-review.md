# Independent check of the exact central nine-feature operator

24 October2026 UTC. Comparison lane review of
`root-central-nine-operator.md` and the accepted survivor definitions.

Accepted as an algebraic simplification under its stated input interval.
This acceptance does not extend to the unresolved phase/passsage join.

I checked the nine target feature choices directly. The low (0,1)
exception has threshold T<=b(b+1); the high (1,2) exception has
D=h-T<=b²; the high (2,1) exception has D<=b(b-1). Their closure costs
and the critical pronic wrong-feature penalty give exactly the five
terms in the proposed maximum. The square filter is inactive at root b,
so adding an erosion requirement to its term would be invalid.

Every ordinary closed surplus is at most b+1, and the existing static
penalties allow original surplus delta+b+1. Thus the common baseline
term is available. For the five remaining targets, the ordinary inverse
already excludes closed surplus b. In particular, the (2,2) target uses
2D>b(b-1), which follows from D>=(b-1)²+1 for b>=32. No unsupported
subcritical capacity is being applied at the critical root.

All retained corner deletion costs are at most4<=k. The source and output
size caps are inactive: the deficit margin (b-1)²+1 exceeds k+4 throughout
b>=32,k<3b. The literal prefix corner ranks also agree with the listed
phase-feature changes for every odd-width/even-length rectangle.

The outstanding work is genuinely the interfaces and their retained
time/room credit, rather than a correction to this central operator.

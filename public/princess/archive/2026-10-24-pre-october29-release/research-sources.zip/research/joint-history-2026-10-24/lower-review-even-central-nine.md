# Independent review of the even central nine operator

24 October2026. ACCEPTED `root-even-central-nine.md` as an exact operator
identity on its stated interval. No critical-clock or global gap claim
is inferred from this review.

I checked the ordinary inverse branches directly in
`src/bridge_corner_frontier.py`, and the refined/banded caps and source
retention rules in the accepted nine evaluator. Put d=h-T. The stated
range gives T>=b^2+1 and d>=(b-1)^2+2.

For each target(j,v), the only ways its ordinary cost can be b are:

* 00: none; low rho(T)+1 and rho(2T) are at least b+1.
* 01: low rho(T), precisely T<=b(b+1).
* 02: only the critical exception n=2b+1. Its otherwise dangerous
  high branch is1+ceil(sqrt(d-1))>=b+1.
* 10: none; low ceil(sqrt(T))>=b+1.
* 11: the critical exception at every even width.
* 12: high ceil(sqrt(d)), precisely d<=b^2.
* 20: none; high2+rho(d)>=b+1.
* 21: high1+rho(d), precisely d<=b(b-1).
* 22: none; both high branches are at least b+1.

All unlisted inverse branches are larger, and the ordinary width cap
makes b+1 available universally. In particular no target costs below b.
The refined inverse is already relaxed at b, so it cannot increase this
ordinary cost. The square refinement needs ceil(sqrt(d))<b; the even
pronic refinement needs its root at most b-1. Both are excluded by the
lower bound on d. Hence neither refinement leaves an erosion condition
in this interval.

For fixed source(c,e) and target(j,v), maximal i=min(c,v) and
u=min(e,j) are admissible and minimize the closure charge. Its value is
v-i=max(v-c,0). All corner-deletion costs are at most4<=k. The survivor
and output size caps are inactive by the quadratic distance from h;
the zero option is also inactive since T-b-closure>0. The resulting
maximum is therefore independent of source e and is exactly the six
terms stated by the parent.

The two-room upper guard is necessary for the stated formula: at
T=h-(b-1)^2-1, target02 gains the omitted high cost b. That adjacent
case is deliberately outside the accepted interval, not silently
absorbed into its operator.

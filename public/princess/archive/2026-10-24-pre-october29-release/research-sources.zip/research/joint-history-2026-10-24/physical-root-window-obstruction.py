"""Exact counterexample to generic ten-bin half-drift contraction."""
from math import isqrt
from pathlib import Path
import json,hashlib
k=1001;start_root=984;end_root=994
X=(968256,968241);initial=X;t=0;crossings=[]
def rho(x):r=(isqrt(4*x+1)-1)//2;return r+(r*(r+1)<x)
def root(x):return isqrt(x-1)+1 if x else 0
assert max(X)==start_root**2 and abs(X[0]-X[1])<=k-start_root
while max(X)<end_root**2:
 old=X;X=(k+X[1]-rho(X[1]),k+X[0]-root(X[0]));t+=1
 if isqrt(max(old))!=isqrt(max(X)):crossings.append(dict(step=t,pair=X,root=isqrt(max(X)),spread=abs(X[0]-X[1])))
assert X==(988034,988041) and abs(X[0]-X[1])==7
assert abs(X[0]-X[1])>(k-end_root+1)//2
out=dict(status='EXACT_RELAXATION_COUNTEREXAMPLE',k=k,initial=initial,initial_root=start_root,initial_spread=abs(initial[0]-initial[1]),initial_drift=k-start_root,terminal=X,terminal_root=end_root,terminal_spread=abs(X[0]-X[1]),terminal_drift=k-end_root,steps=t,crossings=crossings,scope='Refutes final-ten-bin contraction from arbitrary incoming span<=local drift. Does not refute actual zero-start hybrid fronts.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

# Independent review of the even-width central operator

24 October 2026. Accepted as an algebraic identity under the stated input
interval in `root-even-central-nine.md`. This is not a clock comparison.

The permanent target(1,1) exception contributes closed surplus b at every
even width. Target(0,2) has that exception only at n=2b+1. The other three
cost-b possibilities have exactly the thresholds T<=b(b+1),
T>=h-b^2, and T>=h-b(b-1) listed in the note. In the last case the even
critical pronic band is excluded from the refined filter, so imposing an
erosion restriction would be incorrect.

The additional upper margin is necessary: at D=(b-1)^2+1 the ordinary
target(0,2) high inverse 1+ceil(sqrt(D-1)) equals b. Requiring D>=(b-1)^2+2
raises it to b+1 and excludes this extra branch. The other target formulas
are at least b+1 under T>=b^2+1 and this deficit margin. Their quadratic
branches exceed b because b>=32. All source/output finite-board caps are
inactive since the deficit margin exceeds k+4 for k<3b.

I also checked that the retained features i=min(c,v),u=min(e,j) attain the
displayed costs and that every other retention choice cannot improve
them. The resulting formula has no source-e dependence in this interval.
That conclusion does not extend across either omitted endpoint window.

The new identity therefore supplies the even-width counterpart of the
accepted odd central reduction. It does not establish a uniform delay,
permit independent phase choices, or close the joint two-front comparison.

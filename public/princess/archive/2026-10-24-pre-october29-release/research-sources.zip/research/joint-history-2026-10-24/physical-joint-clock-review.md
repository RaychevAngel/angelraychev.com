# Reviewed theorem: a joint necessary clock retaining both actual endpoints

24 October 2026. Independently reviewed ordinary physical theorem with an
exact numerical evaluator. This is not a proof of a uniform nine-day gap,
not a physical attainment claim, and not a new Lean formalization.

## Statement

Let w<=n have even area, b=floor(w/2)>=32, and b+1<=k<3b. Set

    h=wn/2, H=(b-6)^2,
    Qmax=H-1+k-rho(H-1+k),
    Ymax=H+k-rho(H)=H+k-b+6.

Let e_k(Q) be the necessary early hybrid clock, with zero-hole seed0,
and ell_k(Y) the necessary late hybrid gate clock, with seedk. Their
definitions and independently reviewed physical proofs are
`lower-hybrid-necessary-clock.md` and
`physical-hybrid-necessary-clock.md`.

For each Y, initialize the accepted BAND9 backward frontier by

    B_0(c,e)=Y  for all nine feature pairs,

and iterate its existing necessary transition operator. Define

    d_Y(M)=min{t>=0:max_(c,e) B_t(c,e)>=M}.

This admits all terminal features of size at mostY and all initial
features at sizeM. Discarding their correlation only weakens the lower
bound; no independent phase choice is asserted to be physically possible.

Define the finite, exactly computable quantity

    g_joint=min [ e_k(Q)+d_Y(h-Q)+ell_k(Y) ],       (1)

where the minimum ranges over EVERY integer

    H<=Q<=Qmax,  H+1<=Y<=Ymax.

Then the physical worst-case capture time satisfies

    T_k(w,n)>=2*g_joint+1.                       (2)

In particular combine this with all retained results as

    L_new=max(L_old,2*g_joint+1),
    U_new=min(U_old,2*P),

where P is the smaller complete physical solo-prefix capture clock.
Outside the stated range, retain the existing bounds. Thus no previously
proved achievement is lost, and the accepted global25-day ceiling remains
available. Formula(1) is an algorithmic lower evaluator, not a fixed-size
bounded-operation answer.

## Exact physical cuts and endpoint ranges

For any actual two-cohort history, let Q_t be its total number of holes
after t inspections and moves, and m_t=h-Q_t. Let g be its first time
with m_g<=k. Set

    t_E=first t with Q_t>=H,
    t_L=first t>=t_E with m_t<=H,
    s=t_L-1, Q=Q_(t_E), Y=m_s.

The elementary guards H>k, 2H+k<h and h-H-k>b^2 hold because b>=32
and k<3b. Therefore these crossings exist before the gate, and

    t_E<=s<g,  m_(t_E)>b^2>H,  Y>H.

The accepted scalar first-crossing inequality gives Q<=Qmax. The
accepted guarded merger, applied to the move fromY to at mostH, gives
Y<=H+k-rho(H)=Ymax. These are exactly the integer ranges in(1).
The middle and late intervals meet at the same actual state s; no
actual move is counted twice or omitted.

## Every late endpoint lies in a proved physical range

If k<=3b-17, then Ymax=H+k-b+6<=(b-5)^2, so the arbitrary-ceiling
late hybrid theorem applies directly.

Otherwise k>=3b-16. The cutoff is at least floor(3k/5), hence
R>=(9b-53)/5. For b>=32,

    ((9b-53)/5)^2-(b^2-12b+42)
      =(56b^2-654b+1759)/25>0.

It follows that R^2+k>Ymax (the displayed comparison is slightly
stronger than needed). Also

    Ymax<=H+2b+5=b^2-10b+41<=b(b-1).

Thus every such endpoint is wholly in the genuine-quadrant fast region.
The fast-only proof of the necessary late hybrid clock applies, with
no slow component or phase-label assumption. The larger cutoff for
budgets33..99 only strengthens these inequalities. No budget interval
is omitted at this interface.

## Addition of necessary durations

The early physical theorem gives t_E>=e_k(Q). On the middle interval,
all residuals are aboveH>k before the final state. The existing guarded
BAND9 merger therefore maps the actual cohort history to a necessary
model path from h-Q toY. Its backward maximum can only reach h-Q
earlier than or at this path's length:

    s-t_E>=d_Y(h-Q).

The independently proved late clock gives g-s>=ell_k(Y), using the
scope check above. Adding these three inequalities proves

    g>=e_k(Q)+d_Y(h-Q)+ell_k(Y)>=g_joint.          (3)

The proof uses only actual histories for the two boundary passages.
It does not add their dominant-corner labels to the numerical merger.

## Reversed-walk conversion, including the final inspection

Equation(3) is universal over all actual inspection histories. Let
G=g_joint. Before timeG every such history has Q_t<h-k. Suppose that
a winning full-board schedule used at most2G inspections, and pad it
to2G with empty inspections. Process its firstG inspections forward,
including the move following the G-th. At timeG-1 the possible-position
set has more than h+k vertices. Inspection removes at mostk, and a
perfect matching implies that moving does not decrease cardinality.
Thus its possible-position set B on dayG+1 has more thanh vertices.

Process the lastG inspections backward along the undirected grid edges:
perform G-1 reversed inspections and moves, then the last reversed
inspection without a move. The same universal gate bound leaves more
than h+k vertices before that last inspection and therefore more thanh
vertices afterward. This reverse possible-position set R is on the same
dayG+1. Since the board has2h vertices, B and R intersect. Joining the
two avoiding walks at an intersection vertex contradicts capture in2G
days. Therefore T>=2G+1, proving(2).

## Evaluator audit and evidence boundary

`root-joint-hybrid-clock.py` represents exactly the inclusive Q and Y
ranges above using the endpoint compression proved in
`lower-joint-endpoint-compression.md`. The early and late clocks each
have at most two constant blocks on their respective endpoint intervals.
The early claim follows from F_forward(H)>=G_forward(H-1)=Qmax; the
late claim follows from F_backward(H+1)=Ymax. Within each product of
constant-clock blocks, increasing Q lowers the middle target and
increasing Y raises every middle seed threshold. Fixed-feature survivor
capacity monotonicity, including the band boundaries, was proved in
`lower-nine-interval-proof.md`. Thus retaining the largest endpoint of
each block preserves the exact minimum, reducing it to at most four
pairs. The implementation uses the accepted BAND9 step and separately
seeded hybrid recurrences; no independently worst passage allowance is
substituted. Its physical upper
uses the existing literal diagonal-prefix neighborhood clock, including
the final inspection.

The accompanying review receipt records source hashes and independent
clock/endpoint audits. Any observed small gap at a supplied rectangle is
only an instance result. The desired universal estimate

    P<=g_joint+5

remains a separate mathematical obligation; it would imply gap at most9.

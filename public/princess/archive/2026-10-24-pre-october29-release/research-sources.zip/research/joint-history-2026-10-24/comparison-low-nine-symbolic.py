"""Uniform algebra for the isolated low nine-feature projection.

This is a symbolic root-cell certificate, not a rectangle clock theorem.
It preserves erosion features and proves the balanced, phase-labeled map.
"""
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from bridge_lower_frontier_nine import theta_low,quadratic,pronic
from bridge_corner_frontier import small_inverse
R0=26
FEATURES=[(c,e)for c in range(3)for e in range(3)]
PATTERNS=[(0,)*9,(1,0,0,0,0,0,0,0,0),(1,0,0,1,0,0,1,0,0),(1,1,1,0,0,0,0,0,0)]
OPTIONS={(c,e):[(i,u,j,v)for i in range(c+1)for u in range(e+1)
               for j in range(u,3)for v in range(i,3)
               if i>=max(0,c+v-2)]for c,e in FEATURES}

def linear(a,b,strict=False):
    assert a>=0 and a*R0+b>=int(strict),(a,b,strict)

def quadratic_positive(a,b,c):
    assert a>=0 and 2*a*R0+b>=0 and a*R0*R0+b*R0+c>0,(a,b,c)

def root_offset(m,shift,lo,hi):
    """Prove min z:z(z+m)>=r²+u+shift equals r+c."""
    value=R0*R0+lo[0]*R0+lo[1]+shift
    c=(pronic(value)if m==-1 else quadratic(m,value))-R0
    linear(lo[0]-(2*c+m-2),lo[1]+shift-(c-1)*(c-1+m),True)
    linear(2*c+m-hi[0],c*(c+m)-hi[1]-shift)
    return c

def theta(alpha,v,u,j,lo,hi):
    if u:return v+2*j+root_offset(4,alpha-2*v-3*j-u,lo,hi)
    if v:return v+2*j+root_offset(3,alpha-2*v-3*j,lo,hi)
    if j:
        c=root_offset(2,alpha-3*j+2,lo,hi)
        # quad(5,2T-6j)>=quad(2,T-3j+2).
        quadratic_positive(1,2*lo[0]-(2*c+3),2*lo[1]+2*alpha-6*j-(c-1)*(c+4))
        return 2*j+c
    c=root_offset(-1,alpha,lo,hi)
    quadratic_positive(1,2*lo[0]-(2*c-1),2*lo[1]+2*alpha-(c-1)*c)
    return c

def ordinary(alpha,v,j,lo,hi):
    if j:
        c=v+2*j-2
        return c+root_offset(0,alpha-2*c,lo,hi)
    if v:
        c=v-1
        return c+root_offset(1,alpha-2*c,lo,hi)
    c=root_offset(1,alpha,lo,hi)
    quadratic_positive(1,2*lo[0]-(2*c+1),2*lo[1]+2*alpha-c*(c+1))
    return c+1

def arrangement():
    cuts={(0,0),(2,1)}
    for a in range(3):
        for b in range(-11,12):
            if a*R0+b>0 and (2-a)*R0+1-b>0:cuts.add((a,b))
    cuts=sorted(cuts,key=lambda p:p[0]*R0+p[1])
    for a,b in zip(cuts,cuts[1:]):linear(b[0]-a[0],b[1]-a[1],True)
    return [(a,(b[0],b[1]-1))for a,b in zip(cuts,cuts[1:])]

def certify():
    rows=[]
    for p in PATTERNS:
        for lo,hi in arrangement():
            costs={}
            for j,v in FEATURES:
                alpha=-p[3*j+v]
                for u in range(j+1):
                    t=theta(alpha,v,u,j,lo,hi);o=ordinary(alpha,v,j,lo,hi)
                    assert t>=o,(p,lo,hi,v,u,j,t,o)
                    for i in range(v+1):costs[i,u,j,v]=v-i+t
            # Output B'=q+k-r+constant coordinatewise.
            constants=tuple(max(-p[3*j+v]-costs[i,u,j,v]
                                for i,u,j,v in OPTIONS[c,e])for c,e in FEATURES)
            maximum=max(constants);following=tuple(maximum-x for x in constants)
            assert following in PATTERNS,(p,lo,hi,following)
            x=-p[3];y=-p[1]
            G=y-root_offset(1,y,lo,hi)
            F=x-root_offset(0,x,lo,hi)
            assert constants[3]==G and constants[1]==max(F,G-1),(p,lo,hi,constants,G,F)
            for r in(R0,R0+17,1003):
                for u in{lo[0]*r+lo[1],hi[0]*r+hi[1]}:
                    q=r*r+u
                    got=tuple(max(q-p[3*j+v]-(v-i)-max(theta_low(q-p[3*j+v],v,e,j),small_inverse(v,j,q-p[3*j+v]))
                                  for i,e,j,v in OPTIONS[c,e0])for c,e0 in FEATURES)
                    assert got==tuple(q-r+x for x in constants),(r,u,p,got,constants)
            rows.append(dict(pattern=p,u_lower=lo,u_upper=hi,constants=constants,next_pattern=following))
    return dict(status='SYMBOLIC_LOW_PROJECTION_PROVED',scope=__doc__,root_floor_from=R0,
                patterns=PATTERNS,symbolic_cells=len(rows),transition_table=rows)

if __name__=='__main__':
    st=time.process_time();result=certify();result['CPU_seconds']=time.process_time()-st
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items()if k!='transition_table'})

# Two middle days for excess at least 18 at even width, 20 at odd width

24 October 2026. Direct refinement of the independently accepted
`lower-large-excess-middle-two.md`. The ingredients below have passed
independent mathematical review; this assembled version is held for
the final source-hashed review receipt.
All its notation, endpoint ranges, actual hybrid input, and exact
finite-board physical phase conventions are retained.

Its conclusion

    min Phi^(tau+2)(C_ell) >= h-Q

holds under either of the following conditions:

* w is even and d=k-floor(w/2)>=18;
* w is odd (so n is even) and d>=20.

Thus, via the accepted two-front reduction, the desired nine-day
capture-time gap holds throughout these families with arbitrary width
and length. These numerical thresholds concern the budget excess d,
not a width cutoff.

## Low injections and exit alignment share six rooms

The initial room debt is at most d+7 by the actual hybrid span lemma.
Let I be the low injection count and s the model span at its first
maximum at least b^2. The base proof bounds I<=6 and s<=1. In fact

    I+s<=6.                                      (1)

If the final root-b bin has no injection, at most five bins inject,
which proves (1). If that bin does inject, the output is tied; all
remaining inputs before exit lie in the same upper-half root-b interval,
where F=G. The pair stays tied through exit, including its overshoot,
so s=0. Large jumps which skip bins only decrease I.

Both physical coordinates are therefore at least

    z1-(d+13)                                    (2)

at the actual low exit maximum z1. Replace the conservative progress
bound for the two extra physical updates by their exact paired
width-cap bound.

## Two physical updates and the odd square endpoint

At odd width the two scalar physical backward maps have global width
caps b and b+1. Thus, in fixed labels and with clipping at h,

    Phi(X,Y) >= (min(h,Y+d), min(h,X+d-1)).

Applying this twice makes EACH coordinate at least its original value
plus 2d-1, clipped at h. At even width both scalar caps are b, so the
corresponding gain is at least 2d in EACH coordinate. This calculation
is valid even if either step crosses a root wall or a module boundary:
these are global finite-board width caps, not a local affine formula.

Consequently the room lead after the two extra updates is at least

    odd width:  (2d-1)-(d+13)=d-14;
    even width: 2d-(d+13)=d-13.                    (3)

At odd width the exact input endpoint z1=b^2 need not consume an extra
room. In this case compare the physical pair with the equal virtual
seed b^2-d-13 supplied by (2). Its first extra update gains at least d
in each coordinate, since both comparison inputs are at most b^2.
The resulting common lower bound is b^2-13, again at most b^2, so the
second extra update also gains at least d in each coordinate. The
ordinary comparator endpoint update takes b^2 to b^2+d; the matching
third physical update gains at least d-1 globally. Explicitly,

    b^2-d-13 -> >=b^2-13 -> >=b^2+d-13
               -> >=b^2+2d-14.

Relative to the comparator's b^2+d this leaves the same d-14 room
lead as (3). This uses TWO extra physical updates plus ONE ordinary
matched update. It does not spend a third extra day. For z1>b^2 the
endpoint is absent and (3) already applies. Clipping at h only helps.

## The odd central exceptional edge cannot occur here

Use the exact odd central recurrence in the base proof. Set
L=b(b+1) and E=h-b^2, so E-L>=2b+1. The only exceptional edge could
act when B1>B0 and B1>=E. But a strict difference B1>B0 can only be
created by an earlier input B0<=L, giving the new value

    B1=old B0+d<=L+d<E,

because k<3b implies d<2b. An update with input B0>L destroys that
difference. Thus the exceptional condition is impossible, not merely
limited to one occurrence, in the present budget range.

The central comparator follows the constant physical affine pair
exactly. Uniform room lead is preserved; only its final span, at most
one room, is needed to pay the equal reset. Including the preceding
square-endpoint calculation, the odd high-entry room lead is therefore
at least d-15.

At even width the central equal comparator advances exactly d while
both physical coordinates advance at least d globally, so it consumes
NO room lead. Its high-entry lead is at least d-13.

## High clamps and terminal alignment share five rooms

At even width the equal high entry is at deficit at most (b-1)^2;
the possible clamping roots down to H=(b-6)^2 are b-5,...,b-1, at
most five. At odd width the entry may lie in root b, but its equal
deficit is at most b(b-1), already in that root's LOWER half. There
A=B, so the equal pair stays equal until it leaves the root: no
root-b clamp is possible. Thus there are at most five clamps at odd
width as well.

Let J be the high clamp count and t the model span when its minimum
first reaches the terminal deficit Q>=H. Then

    J+t<=5.                                      (4)

If fewer than five clamps occur, J<=4 and t<=1. If all five occur,
the last is in root b-5. It ties the model, and A=B throughout the
remaining lower-half interval down to H. Since the target is Q>=H,
the pair remains tied through the terminal step, including overshoot,
so t=0. As in the base proof, each clamp spends at most one room of
physical advantage and t rooms pay both-coordinate terminal alignment.
Therefore FIVE rooms suffice for the entire high passage.

The available leads are d-15 at odd width and d-13 at even width.
They are at least five precisely under the sufficient thresholds
d>=20 and d>=18, respectively.

Everything else is unchanged: the faster necessary comparator uses
at most tau model steps; there are precisely two extra physical steps;
both coordinates pay every module reset; target overshoots and clipping
can only help. No local or global phase change is free.

This proof leaves the finitely many excess values d<=17 at even width
and d<=19 at odd width unresolved by this comparison, with width and
length still unbounded in each. It makes no claim that all individual
instances in those remaining families are unknown.

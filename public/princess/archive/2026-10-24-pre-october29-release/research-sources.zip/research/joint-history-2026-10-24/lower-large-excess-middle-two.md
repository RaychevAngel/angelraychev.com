# Two middle days suffice whenever the budget excess is at least 26

24 October 2026. New ordinary mathematical comparison, submitted for
independent review. No width sampling or new formalization claim is used.

Let w<=n, wn even, b=floor(w/2)>=32, b+1<=k<3b, and d=k-b>=26.
Put h=wn/2, H=(b-6)^2, and rho(x)=min{j>=0:j(j+1)>=x}. Let

    H <= Q <= Qmax=H-1+k-rho(H-1+k),
    H <  Y <= Ymax=H+k-rho(H).

Let C_ell be the actual late hybrid pair at its first maximum at least Y.
Initialize every threshold of the accepted ordinary BAND9 backward
frontier at Y, and let tau be its first maximum at least M=h-Q.
Let Phi be the exact finite-board physical backward prefix operator.
Then

    min Phi^(tau+2)(C_ell) >= M.                    (1)

Consequently this parameter range satisfies the remaining middle
assertion of `root-two-front-reduction.md`: the early hybrid has some
coordinate at least Q, whereas both physical middle coordinates reach
h-Q. With that independently reviewed reduction, this range has
P<=g_joint+5 and hence the desired physical gap at most nine days.
The excess range 1<=d<=25 remains outside this lemma.

## 1. The only boundary-origin information needed

The actual late hybrid has the time-interlacing bound proved in
`physical-boundary-span.md`:

    max C_ell-min C_ell <= d+7.

Here is the short argument, including active scalar injections. Write
G(x)=k+x-rho(x) and F(x)=k+x-ceil(sqrt(x)). Coordinatewise time
monotonicity, and the common injection being at most both new
coordinates, give C[0]<=G(C[1]) and C[1]<=F(C[0]). The current
coordinates lie below b(b-1), where both maps progress. Thus, if
x=min C_ell and z=max C_ell, then z<=G(x). At
x0=(b-8)(b-7), one has

    G(x0)=H+k-4b+28 < H < z.

Therefore rho(x)>=b-7, proving the stated span bound. In particular

    min C_ell >= Y-(d+7).                          (2)

The elementary upper bound max C_ell<=Y+k<H+2k-b+6<b(b-1)
justifies the progress range used here. This argument uses the actual
hybrid orbit; it makes no assertion about arbitrary incoming phase debt.

## 2. A faster necessary comparator and its three modules

Project BAND9 to the ordinary three-corner graph, then discard the
source corner caps and use the monotone unshifted relaxation from
`../uniform-history-2026-10-23/adversary-critical-unshifted.md`.
The projection is proved in
`../uniform-gap-2026-10-23/lower-nine-projection.md`.
At the present equal seed Y>k+2, the positive feature/cardinality
exception causes no new issue: any newly maximal source larger than Y
has survivor q>=source-k>2, so its retained corner count is already
at most q. Smaller sources are contained in the initial seed.

At each module exit replace all three necessary capacities by their
actual maximum. Monotonicity makes this a faster necessary comparator.
The sum of its elapsed module steps is therefore at most tau. These
resets are paid for below by a bound on BOTH physical coordinates;
they do not authorize free changes of physical phase.

The modules and their exact formulas are the accepted ones in
`../uniform-history-2026-10-23/adversary-critical-eleven-day-assembly.md`.
The sole change is H=(b-6)^2 instead of (b-5)^2, so a boundary can
meet six root bins instead of five. Its cap and label arguments are
unchanged. All involved inverse arguments exceed the fixed small-size
cutoffs, since H>k and b>=32.

In particular Y<=H+d+6<b^2, while M=h-Q>b^2. The low module is
therefore present. Large jumps may skip either later module or already
reach M; in those cases stop immediately and omit the unused costs.

## 3. Low module: at most d+14 rooms of debt

Start the low comparator equal at Y. With its leading coordinate first,
its exact two-state reduction is

    (x,y) -> (max(G(y),F(x)), F(x)),   x-y in {0,1}.

The physical low map omits the maximum: (G(y),F(x)). The two scalar
maps are nondecreasing and 1-Lipschitz. The comparator adds at most one
room at a step, and such an injection can occur at most once in each
upper-half root bin. Before its maximum reaches b^2, the possible bins
are b-5,...,b: at most six injections. The initial square root b-6
cannot add an injection because the seed is at least H and the state
is equal. These are the exact bin argument and map identities of
`../uniform-history-2026-10-23/adversary-critical-one-sided.md`.

Compare against a virtual physical pair started equal at Y-(d+7).
By (2) the actual pair dominates this virtual pair. The virtual pair
is coordinatewise below the comparator, so every input through the
low exit lies below b^2 and its finite-board maps really are F,G.
The initial debt d+7 and at most six unit injections imply labelled
debt at most d+13. At the actual low exit maximum z1, the comparator's
span is at most one. Thus both actual physical coordinates are at least

    z1-(d+14).                                    (3)

Now spend precisely TWO extra physical updates. Everywhere on the
finite board, a physical backward coordinate increases by at least
d-1=k-(b+1), unless it clips at h. Consequently both coordinates are
at least

    min(h,z1+L),       L=2(d-1)-(d+14)=d-16.        (4)

Restart the necessary comparator equal at z1. No more extra physical
updates will be used: the remaining modules spend this room lead.

## 4. Central module consumes at most three rooms

For odd width the central exit threshold is h-b(b-1); for even width
it is h-(b-1)^2. Stop earlier if M is reached. Use the exact central
formulas in
`../uniform-history-2026-10-23/adversary-critical-central.md`.

At odd width and strictly above the input endpoint b^2, write
x=B2=max B and y=B0; x-y<=1. Except for at most one exceptional
edge, the comparator's labelled pair follows

    (x,y) -> (y+d,x+d-1).

The physical finite-board maps dominate these affine maps globally.
Thus a uniform positive room lead is preserved through ordinary central
steps. The exceptional edge, which can occur only once, consumes at
most one room of the lead. Passing from labelled domination to both
coordinates dominating the comparator's exit maximum consumes at most
one further room because its span is at most one.

There is one additional endpoint allowance. If z1=b^2, the equal
comparator's first update is the equal value b^2+d. A physical pair
already ahead need not use exactly that update: its square-phase cost
may have risen to b+1. The global progress d-1 guarantees that this
first step loses at most ONE room of the lead. After it, the comparator
is strictly above b^2, so the preceding central argument applies.
If z1>b^2 this allowance is unused.

Hence the entire odd central module, including equalization at its
actual exit maximum z2, consumes at most THREE rooms. At even width
the equal central comparator and both physical maps advance by at
least d, so no room allowance is required. Keeping the uniform bound
of three is harmless. After the central reset, both physical capacities
are therefore at least

    min(h,z2+L-3).                                (5)

This argument includes a final update which jumps past the central
exit: the comparator's input is still in its central range. If a
physical coordinate clips at h, all claimed capped bounds remain true.

## 5. High module consumes at most seven rooms

At high entry set x=D2,y=D1, where D_c=h-B_c. Both comparator deficits
start equal. The entry ranges are x=y<=b(b-1) at odd width and
x=y<=(b-1)^2 at even width. The accepted exact high model and its
matching physical map are

    model:   (x,y) -> (min(A(y),B(x))-k, B(x)-k),
    physical:(p,q) -> (A(q)-k, B(p)-k),

where A(u)=u+ceil(sqrt(u)), B(u)=u+1+rho(u), and x<=y<=x+1.
The required cap and low-branch exclusions, including the possible
even equal endpoint, are in the eleven-day assembly cited above.
Both physical deficits obey the same uniform entry bound, so its
one-time choice of high phase labels is legitimate for either parity.

The scalar maps A,B are expansive in the ordered direction: for u<=v,
their increments between u and v are at least v-u. Hence uniform
physical deficit advantage persists through every ordinary high step.
A clamp reduces one comparator deficit by at most one, spending at
most one room of that advantage. There is at most one clamp per
decreasing lower-half root bin. Until the comparator minimum first
reaches Q>=H, at most the six bins b-5,...,b occur. (Even width uses
at most five.) Thus six rooms pay every clamp, and one further room
pays the comparator's span, ensuring that BOTH physical deficits are
at most its actual exit minimum. Clipping physical deficits at zero
only helps. This is the positive-advantage argument of
`../uniform-history-2026-10-23/adversary-critical-high-two-day.md`,
used with room credit rather than additional days.

The needed high-entry advantage is therefore SEVEN rooms. Equations
(4)-(5) supply at least L-3=d-19, which is at least seven exactly
when d>=26. Thus the high passage, and hence the complete middle,
needs no further extra physical updates beyond the two already spent.

## 6. Time, phase, and scope accounting

The faster comparator's module times total at most tau. The physical
pair performs the same steps plus the two explicit updates after the
low exit. At every reset both coordinates dominate the reset value
with the stated remaining room credit. The final physical minimum
therefore reaches M in at most tau+2 steps, proving (1). Physical
time monotonicity gives the assertion at exactly tau+2 as well.

This proves a family with arbitrary width and length and every admitted
budget excess d>=26. It does not prove the uniform nine-day theorem
at d<=25, and does not assert that a generic span restriction suffices
there. It also does not replace the accepted general gap25/even23
theorem. Its purpose is to remove all sufficiently large budget
excesses from the outstanding joint two-front comparison.

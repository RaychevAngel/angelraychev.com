# A necessary early clock retaining the fast-region advantage

24 October 2026. Ordinary consequence of the accepted early history
comparison, submitted for independent review. This is an exact evaluator
of a numerical relaxation, not a bounded-operation formula or a new
full-game gap theorem.

Let an even-area rectangle have b=floor(w/2)>=32 and b+1<=k<3b. Put
H=(b-6)^2. As in the accepted all-budget early theorem, use

    R=ceil(3k/5)+4 for33<=k<100, and R=floor(3k/5) otherwise;
    L=R^2;
    G(x)=x+k-rho(x+k), F(x)=x+k-ceil(sqrt(x+k));
    Z=G(L).

These are FORWARD HOLE maps. The zero-time seed is0; they are not the
backward inspection-capacity maps seeded at k in the late clock.

Define S_0=0, S_(t+1)=G(S_t), and E_0=(0,0),

    E_(t+1)[0]=max(min(Z,S_(t+1)),G(E_t[1])),
    E_(t+1)[1]=max(min(Z,S_(t+1)),F(E_t[0])).       (1)

Both coordinates are nondecreasing in t: the recurrence operator is
coordinatewise monotone, the injection is nondecreasing, and its first
iterate dominates the zero seed. All subsequent comparisons are stopped
at the relevant actual first-crossing target. Larger abstract iterates
are not asserted to be physical board prefixes.

Set

    e_k(Q)=min{t>=0:max(E_t)>=Q}.                  (2)

If an actual two-cohort history starts with zero holes and first reaches
Q_tau>=H at time tau, then

    e_k(Q_tau)<=tau.                             (3)

The endpoint itself, not merely H, is retained. In particular every
possible actual endpoint in [H,G(H-1)] has this necessary clock.

## Interpretation of the relaxation

The scalar injection makes both phases available through the entry
envelope Z. Above that envelope the recurrence follows the ordinary
alternating maps. Once both coordinates exceed Z, the constant injection
is irrelevant forever. Thus there is only one fast-region relaxation.
The construction does not allow an independent phase choice in every
later square/pronic bin.

For every A<=Z, let s(A)=min{t:S_t>=A}. Equation(1) gives

    E_(s(A))[0]>=A and E_(s(A))[1]>=A.             (4)

This simple statement is the precise replacement for the one-day
physical fast-entry comparison. No extra physical day is charged.

## Physical proof

If H<=L, the accepted scalar first-crossing bound gives
Q_tau<=G(H-1)<=Z and s(Q_tau)<=tau. Equation(4) proves(3).

Suppose H>L. Let t0 be the entry immediately after the last actual state
Q<=L before tau, and write A=Q_(t0). Then A<=Z. Its scalar first-hit
time satisfies s(A)<=t0: apply the scalar necessary bound only up to
the actual FIRST crossing of A, which occurs no later than t0. This
does not require the preceding physical history to stay below L.

Initialize a reference at A in whichever phase aligns with the first
subsequent good event. Equation(4) permits either phase at index s(A).
Thereafter apply exactly the accepted all-budget slow-history argument:
good events preserve domination in their dominant cohort/corner phase;
bad intervals earn three rooms per move; a convention change is paid by
a backward reference rewind using the D=k-R-1 room allowance. The
geometric charge and its finite budget base ensure enough fresh credit
for every such rewind. No forward reference-day adjustment is needed
after the chosen initial alignment.

The reference is one alternating orbit after its initialization. If N
rewinds occur, at the actual cut its used index is

    j=s(A)+(tau-t0)-N<=tau.

It dominates Q_tau in its carried phase p. Each forward reference move
is a permitted ordinary term of(1). A rewind merely decreases the index
of the same already existing orbit; it is not a new transition added to
the model. Consequently E_j[p]>=Q_tau. Coordinatewise time monotonicity
gives E_tau[p]>=Q_tau, proving(3).

The original slow guards remain intact: H>L forces the final overshoot
root at most b-5, good total surplus is below b, and every candidate
prefix used in the physical comparison is inside the genuine quadrant.
The proof uses no new spatial-label merger.

## Optional phase and source-feature information

At the tracked slow endpoint, the same carried hole phase p satisfies
the accepted early feature alternative. Either E_tau[p]>=Q_tau+1,
or p=0 and the merged source has c<=1, or p=1 and it has e<=1.
This follows first for the tracked reference; replacing it by the
larger E_tau[p] preserves the alternative.

Converting this to the physical complementary SOURCE phase requires
the existing antipodal parity correction p_source=p xor(w+n-2 mod2).
Equation(3), which uses the maximum over phases, needs no phase choice
or source-feature simplification. It is therefore safe to combine with
an independently proved phase-free necessary middle evaluator.

## A diagnostic explaining the old coarse-counterexample mismatch

At w=2001,n=2002,k=1001, H=988036 and Q=H+2=988038, use R=600,
L=360000,Z=360400. Both hybrid coordinates first reach Q at time8168:

    E_8168=(988042,988041).

The two ordinary zero-seed physical forward-hole capacities at that
SAME time are(988039,988041). Thus both physical phases already cover
this endpoint with no extra early day. Charging the coarse early1
allowance throws away a day on this specific critical counterexample.

This is a numerical comparison of necessary clocks, not a construction
of a physical history attaining the hybrid or the middle-model bound.

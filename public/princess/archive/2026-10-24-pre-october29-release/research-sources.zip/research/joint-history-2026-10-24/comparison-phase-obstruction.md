# A phase obstruction to the proposed critical two-day interface

24 October 2026 UTC. Exact adversarial witnesses; independently replayed
against the authoritative ordinary and physical-prefix APIs by the upper
review lane. These do not refute the full-game goal P<=g+5.

Let b=floor(w/2), H=(b-C)^2. The proposed interface compared the first
ordinary three-corner backward layer reaching M with the time by which
BOTH physical prefix capacities reach M, from the same equal seed.
That interface cannot have a universal two-day allowance as stated.

At the old cutoff C=5, take w=2001,n=2002,k=1001, H=990025, equal
seed H, and M=h-(H+4)=1012972. The ordinary frontier first reaches M
at layer15880. The labeled physical capacities reach M at layers15882
and15883. Thus the better phase is two days behind, but both phases
require three. The exact literal receipt is
`comparison-c5-counterexample.json`.

The new cutoff C=6 and the variable equal seed required by the proposed
nonoverlapping join have the same problem. Take

    w=1999, n=2000, k=1000, b=999,
    H=993^2=986049, Y=H+1=986050,
    M=h-(H+5)=1012946.

Starting the ordinary frontier at (Y,Y,Y) and the physical pair at(Y,Y),
the ordinary hitting time is16528, while the two physical hitting times
are16530 and16531. At time16530 the physical pair is
(1012948,1012942): one phase is already two rooms above M while the
other is four rooms below. Receipt: `comparison-c6-counterexample.json`.

Both witnesses were replayed by literal updates at every layer. The
root-cell accelerated evaluator found the candidates but is not relied
on for their verification. The independent reviewer used
`src/bridge_corner_frontier.py::step` and
`src/bridge_upper_transport_odd_coupling.py::physical_step` directly.

## Consequence for the research direction

Do not attempt to prove a minimum-phase critical<=2 inequality for this
ordinary necessary model with arbitrary equal entry. Neither preserving
common width residues nor removing intermediate resets can make a false
interface true. The stronger full-game target remains open because this
necessary model can contain transitions unavailable to the actual
history, and because the full proof may carry a geometrically determined
phase or a signed room advantage from the early history.

The revised useful interface is phase-resolved: keep the two labeled
deadlines or their signed capacity differences, and state which phase
the actual early history supplies. In the displayed witnesses those
delays are(2,3), not an undifferentiated3. A bound for the better phase
alone is also not enough unless the full physical strategy may legally
select that phase at the interface.

The lower lane's early contract currently has the following shape:
the fast entry supplies both phases, but the slow part carries one
phase determined by the actual dominant cohort/corner. A paid rewind
or a delayed fast entry can free a day and recover both choices. Thus
the uncharged zero-rewind, earliest-entry histories are the meaningful
remaining case; their actual geometric identity may constrain the
critical phase. This compatibility has not been proved here.

## What the nine-feature refinement does and does not repair

The accepted nine-feature (corner and erosion) model can be substituted
for the ordinary three-corner model without changing the physical
prefix pair. It delays the first C6 witness by one layer: the nine-feature
clock is16529, versus physical16530/16531. However it does not delay the
C5 witness, whose nine-feature clock remains15880. Neither observation
is a parameter coverage theorem.

A shifted C6 witness shows that erosion retention alone does not prove
the unrestricted minimum-phase statement either. Keep w=2001,n=2002,
k=1001, now take H=(1000-6)^2=988036, Y=H+2, and
M=h-H-1=1014964. The accepted BAND9 clock reaches M at16545, while the
physical phases reach it at16548 and16547. Both the seed and terminal
offsets are within the actual-cut sufficient envelopes. Receipts are
`comparison-c6-shift-diagnostic.json` and
`comparison-c6-feature-diagnostic.json`; the upper lane independently
replayed the result with the authoritative model and physical APIs.

The retained source face is decisive in this witness. At16545, only
features(1,2) and(2,2) reach M; the other seven features reach M at16546.
For odd width and even length, physical source phase0 near full size
has features(2,1), while physical source phase1 has features(1,2).
This is the parity inversion relative to the opposite corner containing
the holes: own-corner holes correspond to physical source phase1.
Consequently the **matched** delays are two days for both faces in the
C6 example, despite the unrestricted minimum-phase delay being three.
At C5 the analogous matched-face two-day statement also fails, so no
unqualified cutoff-independent claim is available.

One abstract winning path for the C6 source(1,2) ends at terminal
feature(0,1). It contains a same-face high transition at

    source(a,c,e)=(1005997,1,2),
    retained(i,u)=(1,1), target(T,j,v)=(1005996,1,2),
    inspection1001, surplus1000, closed surplus999=b-1.

Later it contains a same-face low transition
(991018,0,1)->(991013,0,1), with retained(0,0) and surplus996.
These change the canonical prefix phase without recording a named
corner change. The path is only an admissible necessary-model path;
it is not claimed to be realizable physically. The compressed receipt
`comparison-c6-winning-path.json` preserves every noncanonical edge,
edge multiplicities, terminal features, and endpoint data.

This localizes the remaining possible sources of compensation: the
actual history may prohibit such phase changes without paying room or
time credit; or the two endpoint face constraints may select a physical
phase that already meets the smaller deadline. The early lane has since
proved precisely a credit-or-face dichotomy. The complete critical and
late compatibility inequality is still open.

## Matching the source face is still not the full interface

The same C6 geometry refutes a further tempting simplification. Decrease
the target by one room to M=1014963=h-H-2. Now both B21 and B12 reach M
at16545, while the physical phases still reach at16548 and16547. Thus
even the correctly matched B21-to-phase0 passage costs three extra days.
The source-face lemma alone cannot prove the desired two-day critical
bound with an arbitrary independent equal terminal seed. See
`comparison-c6-face-diagnostic.json`.

This does not refute the proposed joint five-day solo comparison. The
unpaid early loss and this critical loss are incompatible in the same
diagnostic. At budget1001 the fast cutoff is600². Enumerating its400
possible last-entry values, followed by the fastest fixed-phase good
continuation, gives the following targeted conclusion. For the dangerous
opposite-hole phase1, early delay1 occurs at Q=H; the critical matched
delay3 occurs at Q=H+2,H+3,H+4. At all three latter targets the earliest
hybrid actual crossing and the physical crossing are both8168, so the
early delay is0. At that time the physical hole prefix has H+5 rooms,
retaining respectively3,2,1 rooms of credit. Receipts:
`comparison-c6-early-hybrid.json` and
`comparison-c6-early-offsets.json`.

These are exact calculations of a specified scalar-fast/fixed-phase-slow
envelope at one obstruction geometry, not a theorem identifying all
actual histories or all parameter values. Their role is to locate the
joint inequality that remains to prove. A model that separately maximizes
early and middle losses discards the target offset and fabricates the
extra day in this example.

The frozen25-day theorem and all its dependencies remain unchanged.

"""Literal local counterexample to a proposed late phase-feature invariant."""
from pathlib import Path
import json,hashlib
w=n=64;k=33
V={(x,y)for x in range(w)for y in range(n)}
colors=[{v for v in V if sum(v)%2==p}for p in(0,1)]
corners={(0,0),(0,n-1),(w-1,0),(w-1,n-1)}
def hood(S):
 return {(x+dx,y+dy)for x,y in S for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))if 0<=x+dx<w and 0<=y+dy<n}
def feat(S,p):
 C=corners&colors[p];O=corners&colors[1-p]
 return len(S&C),sum(hood({v})<=S for v in O)
def diag(p,D):return sorted((v for v in colors[p]if sum(v)==D),key=lambda v:-v[0])
def pref(p,q):return set(sorted(colors[p],key=lambda v:(sum(v),-v[0]))[:q])
P={v for v in colors[0]if 2<=sum(v)<=48}
I=set(diag(0,50)[:33]);A=P|I
Sprev={v for v in colors[1]if 3<=sum(v)<=47}|set(diag(1,49)[:32])
assert hood(Sprev)==A
B=hood(P)
X=pref(1,len(A));U=pref(1,len(A)-k);Z=hood(U)
assert len(A)==657 and feat(A,0)==(0,0)
assert len(P)==624 and len(B)==650 and len(B)-len(P)==26
assert feat(B,1)==(0,1)
assert len(Z)==650 and feat(Z,0)==(1,0)
assert hood(U)==pref(0,650)
out={'status':'LOCAL_INVARIANT_COUNTEREXAMPLE','board':[w,n],'k':k,'actual_source_size':len(A),'actual_source_features':feat(A,0),'actual_source_is_neighborhood':True,'survivor_size':len(P),'surplus':len(B)-len(P),'actual_target_size':len(B),'actual_target_features':feat(B,1),'physical_source_phase':1,'physical_target_phase':0,'physical_target_size':len(Z),'physical_target_features':feat(Z,0),'room_lead':len(B)-len(Z),'scope':'One valid physical neighborhood-to-neighborhood transition with the other cohort full. This does not claim a counterexample to the global nine-day goal or the accepted early feature lemma.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

# Lower/history lane research log

24 October2026 UTC. Objective: improve the accepted all-parameter25-day
bracket toward gap9, without a width cutoff or selected-board evidence.
All earlier accepted sources remain intact.

## 1. Early2 at the existing cut

The existing early3 proof compared the entry envelope G(R^2) with the
scalar first hit of the smaller target R^2+1. That comparison introduced
an avoidable day. Comparing each actual entry target with its own scalar
hitting time gives early2 at the SAME H=(b-5)^2. A one-integer improvement
in each residue-class ceiling proves t_G<=4u-1 for k>=75. All159,786
finite target/phase checks for33..74 pass. Independent physical review
accepted `lower-two-day-early.md`.

## 2. Early1 with a six-root cut, all budgets

A lower fast/slow cutoff R approximately3k/5 lets a one-day fast repair
suffice. Increasing good surplus slack from3 to4 retains paid phase
rewinds: dominant remainder<=5, switch charge(r^2-11r-108)/(2k), and
three rooms of bad-step credit. For k>=100 the switch inequality has
margin at least(7k^2-617k-8262)/(50k)>0.

A three-stage drift estimate proves all-target fast1 analytically from
k188 onward;1,343,660 target-phase checks cover100..187. The initial
concern was a small-budget gap. A bounded parameter-only exploration
found that R=ceil(3k/5)+4 works for ALL67 budgets33..99. Its280,322
all-target phase checks pass with maximum delay1, and its minimum
switch-credit margin is1. The smallest-root switch inequality extends
to every larger root by monotonicity, hence every width and history.
There is no selected-width certification.

Independent review accepted both `lower-one-day-early-large-budget.md`
and `lower-one-day-early-all-budgets.md`. The endpoint is the ACTUAL
crossing overshoot at H=(b-6)^2, not merely H.

## 3. Signed phase and credit output

Early1 is existential in its final carried phase after a slow segment.
It does not provide both final phases within one day. At the last entry
A at actual time t0, retain W=t0-scalar_hit(A)>=0. If N paid rewinds
occur, the reference index is exactly tau+e-W-N in the specified
bookkeeping. These nonnegative credits were discarded by the old scalar
endpoint statement. The opposite phase ordinarily costs one forward
step; if terminal lead reaches k-rho(Q-1+k), its predecessor instead
supplies that phase one step earlier. Independent review accepted the
bookkeeping in `lower-early-phase-credit-contract.md`.

A proposed simpler terminal threshold k-ceil(sqrt(Q))-1 was rejected
before use: it is too strong in part of a root bin. The exact threshold
above is valid; a safe cut-only version is d+C-1 at H=(b-C)^2.

## 4. Credit or compatible actual corner features

A dominant corner need not itself be occupied. In particular, simply
assigning the prefix feature pair from the dominant phase is unsound.
The punctured-quadrant theorem gives the correct alternative.

If own-phase dominant holes omit their origin, dominant capacity is
at most a(a-2); if opposite-phase dominant holes omit both origin
neighbors, capacity is at most a(a-3). Adding remainder m^2 yields
Q<=sigma(sigma-2) or sigma(sigma-3), respectively. The exact aligned
update can then cover Q+1 within the actual budget. A bad terminal step
already supplies at least three rooms of lead.

Therefore early output is: carried hole phasep with either one room of
lead, or p0 with merged supportc<=1, or p1 with mergede<=1. The source
prefix phase is p XOR((w+n-2) mod2). Omitting this antipodal phase
conversion would swap the crucial phases on mixed-parity boards.

The safe numerical interface uses face maxima, not unproved feature
monotonicity. With M=max B(c,e), A0=max_{c<=1,e<=2}B(c,e) and
A1=max_{c<=2,e<=1}B(c,e), a sufficient phase-specific critical comparison
is physical threshold >=max(Ap,M-1). The existing ordinary counterexample
only refutes the stronger unconditional minimum-phase threshold >=M.

The parent accepted the physical dichotomy; an independent physical-lane
review is pending at this log entry. The face simplification to B12/B21
is deliberately not assumed. The uniform critical inequality consuming
this input is also still open.

## 5. Independent reviews of the late lane

Accepted `physical-fast-one.md`: the decreasing-drift integral has the
correct direction; its finite base checks all42 scalar budgets and the
inspection-to-gate cancellation is correct.

Accepted `physical-two-day-late-contract.md`: arbitrary incoming ceiling
Y<=(b-5)^2, unconditional late2, conditional late1 if the carried phase
is already aligned or an actual predecessor credit pays a rewind. The
one-day branch is not a free phase choice at a join.

Accepted `physical-late-all-budgets.md` after independently reconstructing
inverse maps by binary search in explicit neighborhood arrays. All286,352
target-phase comparisons pass; the smallest switch margin is3. Thus no
small-budget boundary exception remains in either physical endpoint.

## Remaining mathematical obligation

The early and late boundary constants are now much smaller, but their
phases cannot be chosen independently of the critical passage. The next
useful result is a signed necessary-model middle theorem consuming the
actual early credit-or-feature input and producing a phase or credit
accepted by the late1 branch. It must retain actual endpoint/overshoot
indices. Neither the old25-day theorem nor these local improvements by
themselves prove uniformgap9, and no public artifact or Lean claim has
been changed in this research pass.

## 6. A local late feature invariant fails

The physical lane independently accepted the early credit-or-feature
proof. However, a seemingly symmetric permanent late feature invariant
is false. `lower-late-feature-obstruction.md/.py/.json` supplies a valid
64x64,k33 transition with genuine-neighborhood source: merged source657
has features00, deletion33 leaves a punctured own triangle624, and the
target650 has features01. The opposite-phase physical prefix produces
the same size650 with features10 and NO room lead. This is not a full
capture counterexample, but it prevents treating the puncture as an
automatically paid late phase change.

The new direction retains numerical history instead of inventing a
stronger local feature invariant.

## 7. Exact necessary hybrid boundary clocks

`lower-hybrid-necessary-clock.md/.py` replaces the early fast repair by
an explicit relaxed scalar prefix. The forward pair starts0 and has
injection cap Z=G(R^2), then follows ordinary alternating maps. Accepted
good/bad history tracking initializes it at scalar entry time, with no
extra physical day. Consequently its first hit of the ACTUAL early
overshoot is a necessary actual elapsed time. The physical lane has
independently accepted the proof and API.

The corresponding accepted late hybrid startsk, uses backward maps,
and permits scalar continuation below R^2+k. Its best-phase gate time
is a necessary actual late duration. I independently accepted this
standalone proposition. The stronger claim that either ordinary phase
loses at most one day to the hybrid remains an unproved numerical
inequality. Fixed positive room leads between arbitrary balanced seeds
do not suffice to prove it; targeted analytic falsification found such
cross-phase leads can disappear later.

The current critical counterexample k1001,Q=988038 illustrates why
retaining the full head helps: both hybrid phases first hit at8168,
and the ordinary physical pair at that SAME time is(988039,988041).
There is no extra early day on that endpoint, despite the coarse early1
allowance. The receipt is a clock calculation, not an actual attainment.

## 8. Uniform one-room duality and exact endpoint compression

`lower-hybrid-duality.md` proves a genuine unification. Subtracting k
from the late pair turns its backward maps into the early forward maps.
The cap is L=R^2 instead of Z=G(L). At the first scalar crossing of L,
only one coordinate can differ, by at most one room; after the next
step both injections are inactive forever. Integer1-Lipschitz maps
preserve this one-coordinate discrepancy. The physical lane accepted
the proof independently. Thus the two boundary clocks are one-room
variants of the SAME parameter recurrence.

`lower-joint-endpoint-compression.md` proves that the complete endpoint
minimum reduces exactly to at most four pairs. Early clocks throughout
[H,G(H-1)] take only e(H),e(H)+1; late clocks throughout
[H+1,H+k-rho(H)] take only ell(H+1),ell(H+1)+1. In each constant-clock
block retain its largest endpoint, by middle-frontier seed/target
monotonicity. This does not drop any minimizing case and requires no
parameter-length endpoint enumeration. The physical lane independently
accepted this exact compression and the parent joint necessary clock.

The parent is combining these clocks with the accepted nine-feature
middle. The remaining uniform target is a full-clock inequality, rather
than separately adding worst-case local phase costs. For low budgets,
the shifted late target and early target lie roughly one radial half-bin
apart in their shared boundary orbit. Their linking affine root wall
may allow a finite signed comparison, but this is a proposed route,
not an established uniform gap theorem.

## 9. A large-budget-excess two-day middle comparison

`lower-large-excess-middle-two.md` is a new all-width proof accepted
after independent review. It proves both physical prefix phases catch
the entire necessary middle in two additional days whenever
d=k-floor(w/2)>=26 in the joint interface. The argument needs only the
actual late hybrid span d+7, which I independently verified in
`physical-boundary-span.md`; it does not need a conjectured quadratic
phase-spread invariant or a finite-width panel.

The proof uses a fixed six-root-bin budget. Initial room debt is at
most d+7. Low injections cost at most six rooms and exit alignment one.
Two genuine physical updates after the low exit create room credit
d-16. Central propagation consumes at most three rooms, including a
previously easy-to-miss loss at the exact b^2 endpoint; high propagation
consumes at most six clamps and one alignment room. Thus d>=26 pays
every loss without another physical day. Equal resets are paid in both
phases, so no phase is freely reselected.

The unified refinement `lower-large-excess-parity-refinement.md` now
proves the full middle comparison for d>=18 at even width and d>=20
at odd width. The assembled source has independent, source-hashed
acceptance in `physical-large-excess-review.md/.json`. This is a strict strengthening
of the same proof, not another incomparable theorem. The savings are:
exact paired progress, shared low injection/alignment credit, an exact
square-endpoint calculation, exclusion of the central exceptional edge
under k<3b, and shared high clamp/alignment credit. No board or width
panel was computed.

Through the accepted two-front meeting reduction, these families have
capture-time gap at most nine days. The unproved part of that nine-day
target is reduced to d<=17 at even width and d<=19 at odd width,
with width and length still arbitrary. The prior uniform25/even23
theorem remains the unconditional fallback. These are ordinary proofs
with independent mathematical review, not new Lean formalizations.
No public website, manuscript, PDF, or accepted older source was edited.

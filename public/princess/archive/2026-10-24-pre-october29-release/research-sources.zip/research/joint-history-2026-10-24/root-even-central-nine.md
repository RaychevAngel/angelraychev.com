# The even-width central nine-feature operator

24 October2026 UTC. Algebraic counterpart of the odd-width central lemma.
This is an exact operator simplification, not the pending uniform clock
comparison. All initial and final cap interfaces remain explicit.

Let w=2b, n>=2b, b>=32, h=bn and b+1<=k<3b. Suppose every input
threshold B(j,v) satisfies

    b^2+1 <= B(j,v) <= h-(b-1)^2-2.                 (1)

Write L=b(b+1), E=h-b^2, U=h-b(b-1), and

    Q_c=max_{j,v}(B(j,v)-max(v-c,0)).

The next threshold at(c,e) is k plus the maximum of:

    Q_c-b-1;
    B(1,1)-b-max(1-c,0);
    B(0,2)-b-max(2-c,0), if n=2b+1;
    B(0,1)-b-max(1-c,0), if B(0,1)<=L;
    B(1,2)-b-max(2-c,0), if B(1,2)>=E;
    B(2,1)-b-max(1-c,0), if B(2,1)>=U.           (2)

The expression is independent of e. This is particular to this central
interval; it is not permission to forget erosion throughout the passage.

## Uniform nine-target derivation

As in the odd-width lemma, maximal retention i=min(c,v),u=min(e,j)
minimizes closure penalties, all corner deletion charges are affordable,
and no input or output size cap binds. The refined geometric inverse is
relaxed at reduced surplus b, so the ordinary critical inverse decides
whether a target costs b or b+1. All targets admit b+1, giving Q_c-b-1.

The ordinary critical exception(v,j)=(1,1) is available at every even
width. It gives the second term. The further exception(v,j)=(2,0)
is available exactly at n=2b+1 and gives the third term.

Otherwise the only ordinary inverse branches at most b in(1) are:

* (j,v)=(0,1), whose low root rho(T) is at most b iff T<=L;
* (j,v)=(1,2), whose high root ceil(sqrt(h-T)) is at most b iff T>=E;
* (j,v)=(2,1), whose high root 1+rho(h-T) is at most b iff T>=U.

The wide-square refinement only applies below root b. The pronic-band
refinement at even width only applies at roots at most b-1. Thus neither
imposes an additional erosion condition on these critical-root branches.
Their closure penalties are exactly those displayed in(2).

For target(0,2), absent the exceptional length, its high inverse is
1+ceil(sqrt(h-T-1)). The two-room upper guard in(1) makes this at least
b+1. At the immediately adjacent omitted input T=h-(b-1)^2-1 the root
would be b; this is why the even-width interval has a two-room rather
than a one-room guard. The other four targets have both ordinary inverse
branches at least b+1 throughout(1). Direct substitution into the nine
fixed formulas verifies this exhaustively and proves(2).

The numerical diagnostic checks every target/source cost near all three
rank changes at square, adjacent-length, and long rectangles. These checks
attack the stated algebra; they are not used as a proof over all widths.

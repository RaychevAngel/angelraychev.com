"""Independent forward dynamic-program audit of the hybrid threshold API."""
from pathlib import Path
from array import array
from math import isqrt
import hashlib,json,time
from physical_hybrid_late import hybrid_gate_curve,gate_time

def root(x):return isqrt(x-1)+1 if x else 0
def pronic(x):
    r=isqrt(x)
    while r*(r+1)<x:r+=1
    while r and (r-1)*r>=x:r-=1
    return r

start=time.process_time();rows=[]
for k in (33,75,100,201,501):
    R=(3*k+4)//5+4 if k<100 else 3*k//5
    A=R*R+k;top=(k-6)**2
    H=[array('i',[0])*(top+1)for _ in (0,1)]
    scalar=array('i',[0])*(top+1)
    for y in range(k+1,top+1):
        q=y-k;targets=(q+root(q),q+1+pronic(q))
        scalar[y]=1+scalar[targets[0]]
        for p in(0,1):
            physical=1+H[1-p][targets[p]]
            H[p][y]=min(physical,scalar[y]) if y<=A else physical
    curve=hybrid_gate_curve(k,top,True)
    for y in range(top+1):
        assert gate_time(curve,y)==min(H[0][y],H[1][y]),(k,y)
    true=[k,k]
    for t,pair in enumerate(curve['phases']):
        for phase in(0,1):
            # Independent forward DP is monotone in the initial residual.
            while true[phase]<top and H[phase][true[phase]+1]<=t:true[phase]+=1
            assert min(top,pair[phase])==true[phase],(k,t,phase)
    rows.append(dict(k=k,top=top,threshold_layers=len(curve['maxima']),
                     all_target_clock_checks=top+1))
p=Path(__file__);api=p.with_name('physical_hybrid_late.py')
out=dict(status='PASS',scope=__doc__,CPU_seconds=time.process_time()-start,
         rows=rows,source_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest()
                                 for f in(p,api)})
p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(out)

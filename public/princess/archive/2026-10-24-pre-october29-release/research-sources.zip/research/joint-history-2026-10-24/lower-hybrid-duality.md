# The early and late hybrids differ by at most one room

24 October 2026. Algebraic lemma submitted for independent review.
This compares the necessary numerical clocks; it is not a physical
attainment assertion or the missing global capture comparison.

Use the cutoff R of the accepted all-budget boundary theorems, and put
L=R^2, Z=G(L), with the forward maps

    G(x)=x+k-rho(x+k), F(x)=x+k-ceil(sqrt(x+k)).

Let E_t be the early hybrid of `lower-hybrid-necessary-clock.md` (seed0,
injection cap Z). Let C_t be the late hybrid of
`physical-hybrid-necessary-clock.md` (seedk, backward-map cap L+k), and
define D_t=C_t-(k,k). Then, for every t>=0,

    0<=E_t[p]-D_t[p]<=1 for p=0,1,              (1)
    (E_t[0]-D_t[0])+(E_t[1]-D_t[1])<=1.         (2)

In particular the two thresholds are the same or differ by ONE ROOM
in ONE coordinate. This holds for arbitrary time and budget k>=33;
there is no width bound or enumeration of boards.

## Exact conjugacy

For the backward maps G_b(y)=k+y-rho(y) and
F_b(y)=k+y-ceil(sqrt(y)),

    G_b(x+k)-k=G(x), F_b(x+k)-k=F(x).

The backward scalar seed k therefore becomes the forward scalar seed0.
After subtracting k, the late hybrid has exactly the same recurrence
as E, except its injection is min(L,S_(t+1)) rather than min(Z,S_(t+1)).
Here S_0=0 and S_(t+1)=G(S_t).

## The sole possible discrepancy

Let s be the first scalar time with S_s>L. It exists since k>R+2.
Through time s-1 both hybrid coordinates equal S_t: the scalar injection
is available in full, G is the larger map, and F<=G.

Write x=S_s. Since S_(s-1)<=L, x<=G(L)=Z. At the strict crossing,

    E_s=(x,x),
    D_s=(x,max(L,x-delta)),

where delta=G(S_(s-1))-F(S_(s-1)) is0 or1. This proves(1)--(2)
at the only possible injection event that distinguishes the models.

At the next step both coordinates of D exceed or equal Z. Indeed its
second input is at least L, so G(D_s[1])>=G(L)=Z. Its first input is
x>=L+1, and the exact interlacing F(u)>=G(u-1) gives F(x)>=Z.
The same holds for E by monotonicity.

Both constant caps are now irrelevant forever. To verify this last
point without a hidden drift assumption, the cutoff inequalities give

    Z+k<=R^2+2k-R-1<=(R+2)^2,
    ceil(sqrt(Z+k))<=R+2<k,

so F(Z)>Z and G(Z)>=F(Z). Every later iterate at or above Z stays
above Z. Both recurrences henceforth apply only

    (u,v) -> (G(v),F(u)).

Each scalar map is nondecreasing and1-Lipschitz on the integers.
A difference initially supported in only one coordinate remains
supported in at most one coordinate (its coordinate alternates), and
its value cannot increase beyond1. This proves(1)--(2) for all time.

## Clock sandwich

Let e_k(q)=min{t:max E_t>=q} and
ell_k(y)=min{t:max C_t>=y}. For every relevant q>=1,

    ell_k(k+q-1) <= e_k(q) <= ell_k(k+q).        (3)

Thus the early and late necessary boundary clocks are two one-room
variants of a single underlying parameter recurrence. Retaining their
coordinate labels is stronger still by(2). This relation may be used
in a joint comparison; it does not by itself bound either clock's gap
from an ordinary alternating physical clock.

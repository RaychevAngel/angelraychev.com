"""Local central algebra discovery; finite diagnostic, not a uniform proof."""
from pathlib import Path
import importlib.util
import json

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('central_band9', HERE.parent/'uniform-gap-2026-10-23/lower-band9.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
F = m.FEATURES


def run(b=100):
    w=2*b+1; n=w+1; h=w*n//2; k=b+1
    ranks=(b*b,b*(b+1),h-b*b,h-b*(b-1))
    points=set()
    for q in ranks:
        points.update(range(q-10,q+11))
    for l,r in zip(ranks,ranks[1:]):
        points.add((l+r)//2)
    patterns={(0,)*9,(1,0,0,0,0,0,0,0,0),(1,0,0,1,0,0,1,0,0),(1,1,1,0,0,0,0,0,0)}
    pending=list(patterns); transitions=[]
    while pending:
        p=pending.pop()
        for q in sorted(points):
            out=m.step(w,n,k,{f:q-p[z] for z,f in enumerate(F)})
            top=max(out.values()); s=tuple(top-out[f] for f in F)
            transitions.append(dict(source=p,q=q,shift=top-q-k,target=s))
            if s not in patterns:
                patterns.add(s); pending.append(s)
                assert len(patterns)<100
    return dict(status='DIAGNOSTIC_ONLY',b=b,w=w,n=n,ranks=ranks,
                patterns=sorted(patterns),transitions=transitions)


if __name__=='__main__':
    r=run(); Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items() if k!='transitions'}))

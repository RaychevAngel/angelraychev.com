"""Independent exact-prefix adjunction/index audit, not a uniform gap test."""
from pathlib import Path
import importlib.util,json,hashlib
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('literal_prefix',P.parent/'uniform-history-2026-10-23/root-prefix-clock.py')
prefix=importlib.util.module_from_spec(spec);spec.loader.exec_module(prefix)

def check(w,n,k):
 h=w*n//2;chi=(w+n-2)%2
 maps=[[prefix.neighborhood_size(w,n,p,max(0,m-k)) for m in range(h+1)] for p in (0,1)]
 assert all(a<=b for f in maps for a,b in zip(f,f[1:]))
 # Exact inverses are computed by literal maximization, independent of root formulas.
 inv=[[max(m for m in range(h+1) if maps[p][m]<=v) for v in range(h+1)] for p in (0,1)]
 expected=min(prefix.clock(w,n,k,p) for p in (0,1))
 A=[(0,0)];V=[(min(k,h),)*2]
 for t in range(expected+3):
  a=[0,0]
  for q in (0,1):a[1-q]=h-maps[q^chi][h-A[-1][q]]
  A.append(tuple(a));V.append(tuple(inv[p][V[-1][1-p]] for p in (0,1)))
 count=0
 for t in range(expected+3):
  for s in range(expected+3):
   meeting=max(A[t][p^chi]+V[s][p] for p in (0,1))>=h
   assert meeting==(expected<=t+s+1),(w,n,k,t,s,A[t],V[s],expected)
   count+=1
 # In the genuine quadrant, current hole/source residual labels use the same H.
 from math import isqrt
 def rho(x):r=(isqrt(4*x+1)-1)//2;return r+(r*(r+1)<x)
 def root(x):return isqrt(x-1)+1 if x else 0
 for x in range(min((w//2-2)**2,h-k)+1):
  g=x+k-rho(x+k);f=x+k-root(x+k)
  assert h-maps[1^chi][h-x]==g,(w,n,k,x,'G')
  assert h-maps[chi][h-x]==f,(w,n,k,x,'F')
 return dict(w=w,n=n,k=k,solo_clock=expected,cut_checks=count)

rows=[check(*args) for args in [(8,8,5),(8,9,5),(9,10,5),(10,12,7),(11,12,7)]]
files=['lower-two-front-meeting.md','root-two-front-reduction.md',Path(__file__).name]
out=dict(status='EXACT_ADJUNCTION_AND_PHASE_AUDIT_PASSED',uniform_middle_assertion='NOT PROVED',rows=rows,source_sha256={f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in files})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

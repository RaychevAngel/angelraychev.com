"""Exact forward early hybrid clock. No board-width scan or new theorem test."""
from bisect import bisect_left
from math import isqrt
from pathlib import Path
import hashlib
import json


def root(x):
    return isqrt(x - 1) + 1 if x else 0


def rho(x):
    r = (isqrt(4*x + 1) - 1) // 2
    return r + (r*(r + 1) < x)


def cutoff(k):
    assert k >= 33
    return (3*k + 4)//5 + 4 if k < 100 else 3*k//5


class EarlyHybrid:
    """Grow exact thresholds only as far as needed; query all endpoints cheaply."""

    def __init__(self, k):
        self.k = k
        self.R = cutoff(k)
        self.L = self.R*self.R
        self.Z = self.G(self.L)
        self.scalar = 0
        self.states = [(0, 0)]
        self.maxima = [0]

    def G(self, x):
        return x + self.k - rho(x + self.k)

    def F(self, x):
        return x + self.k - root(x + self.k)

    def grow(self, target):
        while self.maxima[-1] < target:
            old = self.states[-1]
            self.scalar = self.G(self.scalar)
            cap = min(self.Z, self.scalar)
            new = (max(cap, self.G(old[1])),
                   max(cap, self.F(old[0])))
            assert new[0] >= old[0] and new[1] >= old[1]
            if new == old:
                raise ValueError("Target exceeds the hybrid fixed point")
            self.states.append(new)
            self.maxima.append(max(new))

    def clock(self, target):
        if target <= 0:
            return 0
        self.grow(target)
        return bisect_left(self.maxima, target)

    def phase_clock(self, target, phase):
        self.grow(target)
        while self.states[-1][phase] < target:
            self.grow(self.maxima[-1] + 1)
        return bisect_left([s[phase] for s in self.states], target)


def diagnostic():
    k = 1001
    H = 994**2
    target = H + 2
    model = EarlyHybrid(k)
    t = model.clock(target)
    physical = (0, 0)
    before = physical
    for _ in range(t):
        before = physical
        physical = (model.G(physical[1]), model.F(physical[0]))
    assert t == 8168
    assert model.states[t] == (988042, 988041)
    assert physical == (988039, 988041)
    assert max(model.states[t-1]) < target
    assert max(before) < target
    assert min(physical) >= target
    return dict(k=k, H=H, target=target, R=model.R, L=model.L,
                Z=model.Z, hybrid_first_hit=t,
                hybrid_at_hit=model.states[t], physical_at_hit=physical,
                previous_hybrid=model.states[t-1], previous_physical=before,
                both_physical_phases_need_extra_early_days=0)


if __name__ == "__main__":
    source = Path(__file__)
    note = source.with_suffix(".md")
    row = diagnostic()
    out = dict(status="EXACT_CLOCK_DIAGNOSTIC_NOT_PHYSICAL_ATTAINMENT",
               row=row,
               source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in (source, note)})
    source.with_suffix(".json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))

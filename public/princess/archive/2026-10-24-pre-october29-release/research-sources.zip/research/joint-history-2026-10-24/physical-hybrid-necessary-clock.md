# A necessary computable late clock with one fast-region relaxation

24 October 2026. Ordinary physical consequence of the accepted late
comparison. Independently reviewed by the lower lane. The numerical
one-day comparison conjecture is not used in this proposition.

Let w<=n have even area, b=floor(w/2), k>=max(33,b+1), and

    k<Y<=(b-5)^2.

Use R=ceil(3k/5)+4 when33<=k<100 and R=floor(3k/5) otherwise.
Put A=R^2+k. Let C_t be the hybrid thresholds of
`physical-hybrid-late-reduction.md`, with C_0=(k,k), and define

    h_k(Y)=min{t>=0 : max(C_t)>=Y}.

Every actual two-cohort history starting with m_s>=Y and first attaining
the merged gate m_g<=k satisfies

    g-s >= h_k(Y).                              (1)

This is a necessary clock for a physical partial history. It does not
claim arbitrary model paths are physically realizable, does not add a
new corner label to a numerical merger, and does not require a minimum-
versus-maximum phase comparison. The recurrence is an exact evaluator
of the specified relaxation, not an O(1) formula.

## Proof

Take the same last crossing into m<=Y used in the accepted late theorem.
If it occurs after s, either initial physical reference phase can take
one move from Y to lie below the actual entry target. This move is paid
by the at least one actual move omitted. Choose the initial phase so
that the subsequent first slow good event is aligned. If no such event
exists, either phase is usable and all slow steps earn rather than spend
room credit.

Follow the accepted good/bad comparison, paying later identity changes
with backward reference rewinds. The reference values are values of ONE
ordinary alternating prefix orbit. A rewind decreases its used index;
it is not a proposed backward physical move. At any later comparison
time its current index is at most the actual elapsed time, including
the paid entry reset. Its residual is at most the actual residual.

At the final entry into the fast region, the reference residual is at
most A. A later return from above A is handled by one additional physical
reference move, paid by the omitted excursion duration. From that point
on, the actual residuals stay at most A. The scalar map

    x -> x-k+ceil(sqrt(x-k))   for x>k

is no larger than any actual residual update there, by the accepted
signed-surplus bound. Its monotonicity therefore bounds the remaining
actual gate time below by the scalar gate time from the reference's
current residual.

The hybrid is allowed to follow all the ordinary physical moves used by
the reference and then this scalar continuation. The prefix orbit may
have entered the fast region earlier; ordinary physical moves below A
remain allowed, so this causes no restriction. The total number of moves
in this chosen hybrid route is at most g-s. Some initial phase therefore
has hybrid gate time at most g-s, proving(1).

## Intended use and remaining obligation

Equation(1) is already a valid all-width computable boundary clock. It
can be used in a joint evaluator retaining the actual endpoint residual
Y. Proving the separate inequality

    min(P_(t+1))>=min((k-6)^2,max(C_t))

would turn it into an unconditional one-day late comparison in either
physical phase. Targeted arithmetic supports that stronger inequality,
but it remains open in this checkpoint.

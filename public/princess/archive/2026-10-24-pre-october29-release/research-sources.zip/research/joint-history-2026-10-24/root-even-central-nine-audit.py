"""Finite attack on the uniform even-width nine-target algebra."""
from pathlib import Path
import importlib.util
import json
import time

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('even_central_band9',HERE.parent/'uniform-gap-2026-10-23/lower-band9.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def cost(b,n,h,T,c,e,j,v):
    base=b+1+max(v-c,0)
    if(j,v)==(1,1):return b+max(1-c,0)
    if(j,v)==(0,2) and n==2*b+1:return b+max(2-c,0)
    if(j,v)==(0,1) and T<=b*(b+1):return b+max(1-c,0)
    if(j,v)==(1,2) and T>=h-b*b:return b+max(2-c,0)
    if(j,v)==(2,1) and T>=h-b*(b-1):return b+max(1-c,0)
    return base

def run():
    start=time.process_time();checks=0;records=[]
    for b in(32,100):
        for n in(2*b,2*b+1,2*b+2,100000):
            w=2*b;h=b*n;lo=b*b+1;hi=h-(b-1)**2-2
            ranks=sorted({lo,b*(b+1),h-b*b,h-b*(b-1),hi})
            targets={q for r in ranks for q in range(r-5,r+6) if lo<=q<=hi}
            targets.update(q for a,z in zip(ranks,ranks[1:]) if lo<=(q:=(a+z)//2)<=hi)
            for T in sorted(targets):
                for c,e in m.FEATURES:
                    for j,v in m.FEATURES:
                        actual=max(m.survivor(w,n,T,i,u,j,v)
                                   for i in range(min(c,v)+1)
                                   for u in range(min(e,j)+1)
                                   if i>=max(0,c+v-2))
                        expected=T-cost(b,n,h,T,c,e,j,v)
                        assert actual==expected,(b,n,T,c,e,j,v,actual,expected)
                        checks+=1
            records.append(dict(b=b,n=n,targets=len(targets)))
    return dict(status='PASS',scope=__doc__,checks=checks,records=records,
                limitation='Finite algebra diagnostic; uniform statement is proved by the nine-target case split.',
                cpu_seconds=time.process_time()-start)

if __name__=='__main__':
    r=run();Path(__file__).with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

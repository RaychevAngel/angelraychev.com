# Retaining the erosion feature gives the balanced low map

24 October2026 UTC. A uniform algebraic lemma; the finite-board critical
interfaces and whole-passage time comparison remain separate obligations.

Write B(c,e) for the nine backward thresholds. In the isolated low region,
remove the finite-width/high-deficit alternatives and source-size caps.
The update is

    B'(c,e)=k+max[T-(v-i)-theta_low(T,v,u,j)],
    T=B(j,v),

over the accepted OPTIONS(c,e). The ordinary three-corner inverse adds no
restriction in the range below, since theta_low dominates it. All corner
deletion costs are at most4; assume k>=4.

Let q=max B. For q>=26², the following four normalized patterns q-B,
written in rows(c=0,1,2) and columns(e=0,1,2), are closed:

    000/000/000,
    100/000/000,
    100/100/100,
    111/000/000.

Define x=B(1,0), y=B(0,1), and

    F(z)=z+k-ceil(sqrt(z)),
    G(z)=z+k-rho(z),  rho(z)=min{r:z<=r(r+1)}.

Then the exact projected update is

    x'=G(y),
    y'=max(F(x),G(y)-1).

In particular |x-y|<=1. The physical pair instead updates as
(G(y),F(x)). Thus the only artificial improvement is a one-room raise
of the second coordinate when the raw first coordinate leads by two.
Retaining erosion does not sort the two phases, nor freely choose a
new phase. This differs from the weaker three-corner projection
(max(G(y),F(x)),F(x)).

The symbolic certificate `comparison-low-nine-symbolic.py` writes
q=r²+u,0<=u<=2r,r>=26. It divides u into47 intervals with endpoints
affine in r. On each interval and each of the four input patterns, every
quadratic inverse equals r plus an explicitly verified constant.
The required integer-root inequalities reduce to affine inequalities
whose slopes and values at r=26 have the required signs. The competing
sqrt(2q) branches are dominated using quadratic inequalities with
nonnegative derivative and positive value at r=26. It then checks every
allowed feature transition, the ordinary-inverse domination, closure,
and the two displayed projected identities. This is188 symbolic cells,
not188 sampled widths. Original root-function evaluations at three
indices calibrate the implementation but are not the unbounded proof.

No claim is made here that the isolated operator equals the full
finite-board recurrence all the way through q=b². The width-cap
interfaces, changing physical prefix corner features, and the high
operator require their own algebra. The accepted high-pattern
certificate has the dual balanced projection, independently checked
in `root-high-balanced-certificate.py`.

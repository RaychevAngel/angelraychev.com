# Independent acceptance of the pointwise early two-day comparison

24 October2026 UTC. The physical-history lane accepts
`lower-two-day-early.md` after checking the argument and independently
reimplementing its finite scalar base.

The three k mod3 polynomial bounds strengthen t_G<=4u to t_G<=4u-1.
Thus every target at most G(L) has scalar first hit at most4u, whose
half-frequency physical discrepancy is at most2u and is repaired in two
steps. The proof compares the actual last-crossing entry A with its OWN
scalar first hit, so no unproved earlier crossing time is substituted.

Both initial physical phases can be advanced to the same reference index
t0+2 by monotonicity. One may therefore select the phase aligned with the
first subsequent good event at that common index. All later paid rewinds
preserve the existing slow-history time contract. The argument still
maintains pointwise domination through the final physical overshoot.

An independent implementation checked every target and both phases for
all42 budgets33..74:159,786 comparisons, worst loss2, in0.031 CPU seconds.
There was no width or length enumeration. This accepts early2 only; it
does not assert the still-unproved global nine-day bracket.

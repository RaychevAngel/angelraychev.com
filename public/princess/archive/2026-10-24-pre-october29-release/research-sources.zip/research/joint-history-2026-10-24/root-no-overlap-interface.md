# Joining at the actual late source, without overlapping an actual move

24 October 2026 UTC. Bookkeeping lemma, conditional on the stated physical
passage contracts. This is not a proof of the nine-day uniform gap.

Let an even-area board have b=floor(w/2)>=32, h=wn/2, and b+1<=k<3b.
Put d=k-b and H=(b-6)^2. For an actual two-cohort history, write Q_t for
total holes and m_t=h-Q_t. Let g be its first time m_g<=k. Define:

* t_E: the first time Q_t>=H;
* t_L: the first time at or after t_E with m_t<=H;
* s=t_L-1, M=m_(t_E), Y=m_s.

The scalar first-crossing bound and the ordinary necessary one-step
backward bound give

    H <= Q_(t_E) <= G_k(H-1) <= H+d+4,
    H < Y <= H+k-rho(H) = H+d+6,

where G_k(x)=x+k-rho(x+k). The first inequality uses
rho(H-1+k)>=b-5; the second uses the guarded merger on the transition
from Y to at most H. Its targets are in the genuine low-capacity region,
where the smallest relaxed profile cost is rho(H)=b-6.

The guards H>k and M>b^2>H hold throughout this range. The coarse bound
Y<=H+d+6 proves Y<=(b-5)^2 when d<=2b-17. When that
inequality fails, Y is in the fast region R^2+k for R=floor(3k/5),
and the separately proved fast-only late contract must be used.
Here is an explicit guard check. Failure gives k>=3b-16, hence
R>=9b/5-53/5. For b>=32,

    (9b/5-53/5)^2 - (b^2-12b+42) > 0,

because the difference is 56b^2/25-654b/25+1759/25,
positive at32 and increasing thereafter. Since Y<=H+k-b+6,
this gives R^2+k>Y. Also Y<=H+2b+5=b^2-10b+41<=b(b-1).
The larger small-budget cutoff only strengthens this fast-only check.
Thus every Y lies in either the proved slow ceiling or the proved
fast-only ceiling. No late-interface budget range is omitted.

## Conditional composition

Suppose the physical zero-seed prefix supplied by the early comparison
has residual at most M at some index j_E<=t_E+e. It has a particular
carried phase and a possible additional room lead; neither is reset.

Assume the middle comparison continues that very physical prefix to
residual at most Y in at most s-t_E+c additional transitions. Assume
the late comparison, in the resulting phase and with its actual retained
room lead, reaches the gate in at most g-s+l transitions. Then, adding
the final capturing inspection,

    P <= (t_E+e)+(s-t_E+c)+(g-s+l)+1
      = g+e+c+l+1.

The middle and late actual intervals meet at the identical state m_s=Y.
There is no shared actual transition. In particular, e=1,c=2,l=1 would
give the requested P<=g+5, hence T>=2P-9 and U<=2P.

This calculation needs an actual phase-compatible middle-to-late
contract. A statement for the better of two independently chosen
phases is insufficient. Likewise, an unconditional late allowance2
does not become1 merely by reusing the letter Y for the interface.

## Precise remaining obligations

1. Prove the critical physical comparison with the necessary-model
   elapsed time, for the endpoint ranges above, retaining incoming
   phase and unused time/room credit. The ordinary three-corner MIN<=2
   interface is false; literal counterexamples are saved separately.
2. Show that the actual output satisfies the conditional late1 premise,
   or that any needed phase adjustment is paid elsewhere in the same
   carried account. A fresh phase choice would leave a gap in the proof.
3. Verify the high-budget fast-only guard explicitly where Y exceeds
   (b-5)^2. The existing all-budget results continue to cover this range
   regardless of whether the improved comparison is proved.

The early theorem's credits W (delayed entry) and N (paid rewinds) can
reduce e, and a terminal room lead can allow another rewind. They may
be spent only once across this composition.

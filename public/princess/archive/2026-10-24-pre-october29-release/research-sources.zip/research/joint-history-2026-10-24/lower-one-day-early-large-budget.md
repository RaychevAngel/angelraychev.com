# One-day early comparison with a six-root cut

24 October2026 UTC. Ordinary proof candidate submitted for independent review.
No existing accepted source or global capture bound is replaced here.

Let w<=n have even area, b=floor(w/2)>=32, and

    max(100,b+1) <= k < 3b.

Put H=(b-6)^2. If an actual two-cohort history first reaches total holes
Q_tau>=H at time tau, then some zero-seed physical anchored-prefix hole
trajectory dominates the ACTUAL Q_tau by reference time tau+1.

The proof follows the physical phase-tracking construction of the accepted
five-root theorem, changing the quantitative cutoff and good-event slack.
The new cut is six roots below b. Budgets33..99 are not claimed here.

## Slow history: slack four and cutoff three fifths

Put R=floor(3k/5), L=R^2 and D=k-R-1. Consider an actual interval whose
target roots satisfy

    R < r=ceil(sqrt(Q)) <= b-5.

Call an event good when its actual total hole surplus sigma<=r+4.
The small-branch and concentration hypotheses hold: sigma<=b-1,
Q>=(r-1)^2+1>sigma^2/2, and h-Q>sigma(sigma+1), where h=wn/2.
Here r>=61, and h>=2b^2.

The dominant-component theorem yields at most five units of nondominant
surplus. If the remainder were at least six, its decreasing quadratic
bound on the smaller-root branch would give

    Q <= (sigma-6)^2+36 <= (r-2)^2+36
       < (r-1)^2+1,

since r>=20. Thus at most25 holes lie outside the unique dominant actual
cohort/corner. The exact square/pronic profile of that dominant phase
still holds for the entire Q: aggregating the other components never
requires a surplus correction.

For consecutive good events with different dominant identities, let
Delta be their time separation and r the new root. The accepted matching
charge, using at most25 outliers at either endpoint, gives

    Delta*k >= (r-1)^2+1-50-(r+4)(r+3)/2
             = (r^2-11r-108)/2.                 (1)

All Delta-1 intervening targets are bad. Their surplus is at least r+5.
Since r>3k/5>(k-1)/2, the target profile on [Q,Q+k] is at most r+2.
The exact bad-step credit lemma therefore supplies three rooms per step,
retaining at least min(D,old_lead+3).

The smaller rewind proof needs only k>R: once the reference lead at an
actual count q>L reaches D, its predecessor still dominates q, because

    rho(q-1+k)>=R+1,
    G_k(q-1)<=q+D-1.

A rewind changes reference phase and costs no actual day.

There is enough fresh credit for every identity change. Since r is an
integer greater than3k/5, it satisfies r>=3k/5+1/5. The quadratic in(1)
is increasing there. Also D<=2k/5-1/5. Thus

    3(Delta-1)-D
       >= (7k^2-617k-8262)/(50k) > 0            (2)

for k>=100: the numerator is38 at100 and increasing thereafter.
Consequently every required phase change can be paid by intervening bad
steps; identity changes preserving phase need no rewind.

All candidate prefixes fit in a genuine quadrant. Indeed k<5r/3 and
r<=b-5 imply

    Q+k <= r^2+k < (b-5)^2+5(b-5)/3 < b(b-1).

The same physical matching and reference construction as before therefore
maintains domination throughout an arbitrarily long slow interval. No
unverified merger of new spatial labels is used.

## Fast entry: an all-target one-day comparison

Use G(x)=x+k-rho(x+k), F(x)=x+k-ceil(sqrt(x+k)), and let

    Z=G(L)<=L+k-R-1,       v=k-R-2.

For any reference input x<Z,

    x+k <= L+2k-R-2 <= (R+2)^2,

because2k<=5R+6. Every alternating physical step before a target at most
Z thus gains at least v. The scalar G orbit and either alternating orbit
still satisfy discrepancy at most ceil(t/2).

For k>=188 a three-stage estimate bounds the scalar first hit of Z by
2v. Set S=floor(k/3) and V=floor(k/2). Scalar drift before exceeding S^2
is at least k-S-2, before exceeding V^2 at least k-V-1, and before
exceeding L at least k-R-1. These follow respectively from
k<=5S+6, k<=3V+2, and k<=3R+2. One more step reaches Z. Hence

    t_Z <= ceil((S^2+1)/(k-S-2))
           +ceil((V^2-S^2)/(k-V-1))
           +ceil((R^2-V^2)/(k-R-1))+1
         <= k/6+2 + 5k/18+3 + 11k/40+5 +1
          =259k/360+11
         <=4k/5-4 <=2v.                       (3)

For completeness, the three ratio bounds before adding a ceiling unit
are at most k/6+1,5k/18+2,11k/40+4. They follow by bounding the
numerators by k^2/9+1,5k^2/36+2k/3,11k^2/100+k and the denominators
below by2k/3-2,k/2-1,2k/5-1. Multiplication proves the inequalities
for k>=36. The final comparison in(3) is29k>=5400, valid at k>=188.

At the scalar first hit s(A) of any A<=Z, the alternating discrepancy
is at most ceil(s(A)/2)<=v. One additional physical step reaches A.
For100<=k<188 the accompanying exact arithmetic certificate checks every
integer target through Z and both initial phases. Its maximum excess
is one. No board widths or lengths are enumerated.

Thus, uniformly for k>=100,

    J_p(A) <= s(A)+1       (p=0,1; 1<=A<=Z).    (4)

As before, only the target prefix needs to lie in the board. The accepted
clipped inverse-neighborhood comparison handles an abstract cutoff larger
than the physical board's quadrant range.

## Actual crossing and carried phase

If H<=L, then Q_tau<=G(H-1)<=Z. The scalar first hit of that actual
target is no later than tau, so(4) proves the result directly in either
initial phase.

If H>L, take the time t0 after the last actual Q<=L before the first H
crossing. Its actual entry Q_(t0)<=Z is dominated in either reference
phase by t0+1, using its own scalar hitting time. Choose the phase of the
first good event and use the paid slow rewinds thereafter.

The final actual overshoot remains in the slow window: H>L implies
k<5(b-6)/3, and

    Q_tau<=H+k<=(b-5)^2.

Thus the same pointwise comparison reaches Q_tau by reference index
at most tau+1. The six-root cut and the stated budget threshold are part
of this theorem, not suppressed dependencies of a full capture result.

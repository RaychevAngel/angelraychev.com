# Early output: compatible corner features or one room of credit

24 October2026 UTC. New ordinary physical interface lemma submitted for
independent review. This is not an assumed feature assignment to an
arbitrary numerical state.

Use the all-budget early1 theorem and its six-root cut H=(b-6)^2,
with b>=32 and b+1<=k<3b. In the nonempty slow branch, let tau be the
first actual total-hole crossing of H. Let X_j be its maintained physical
reference hole prefix, including the paid rewinds, so X_j>=Q_tau and
j<=tau+1. Put delta=X_j-Q_tau.

For the actual current support cohorts A0,A1, write H_l for their holes.
For a one-color set S let c(S) count its occupied own-color board corners,
and e(S) count opposite-color board corners whose complete neighbor set
lies in S. The actual guarded merged source features are

    c=max(c(A0)+c(A1)-2,0),
    e=max(e(A0)+e(A1)-2,0).

Equivalently,

    c=max(2-c(H0)-c(H1),0),
    e=max(2-c(N(H0))-c(N(H1)),0).                (1)

Let p be the carried prefix hole phase, relative to the dominant actual
corner at the latest good event: p=0 for own color and p=1 for opposite
color. Then at the terminal early crossing at least one of the following
holds:

    delta>=1;                                  (credit)
    p=0 and c<=1;                              (own compatibility)
    p=1 and e<=1.                              (opposite compatibility)

The corresponding safe numerical inputs are the two finite faces

    max { B(c,e) : c<=1, e<=2 },
    max { B(c,e) : c<=2, e<=1 },

respectively. The physical complementary-support prefix feature pairs
are (1,2) and (2,1), but replacing these face maxima by B(1,2) or B(2,1)
requires a separate monotonicity proof for the particular frontier.
No such simplification or new merger rule is assumed here.

## Missing the required corner gives a punctured profile

First suppose the terminal target is good. Let its actual total dual
hole surplus be sigma and its unique dominant actual component have
surplus a. Put m=sigma-a. The good-event proof supplies m<=5, a>=20,
and total size of all other hole components at most m^2. The dominant
component lies in a genuine quadrant at its actual canonical corner.
Its finite-board neighborhood equals that quadrant neighborhood.

If p=0 and c=2, equation(1) says neither hole cohort contains ANY own
corner. In particular, the dominant component omits its quadrant origin.
The accepted punctured-quadrant capacity with forbidden-depth h=2 gives
its size at most a(a-2): the quadratic branch dominates a(a-1)/2 since
a>=20. Therefore

    Q_tau <= a(a-2)+m^2 <= sigma(sigma-2),       (2)

because the difference between the final expression and the preceding
one is m(2a-2)>=0.

If p=1 and e=2, equation(1) says neither hole neighborhood contains ANY
opposite-color corner. In particular, neither of the two neighbors of
the dominant quadrant origin belongs to that component. The accepted
punctured profile has h=3, giving size at most a(a-3). Thus

    Q_tau <= a(a-3)+m^2 <= sigma(sigma-3),       (3)

with difference m(2a-3)>=0. This argument needs neither a full initial
triangle nor an assumption that the dominant origin is occupied.

## The physical update earns one actual room

Put q=Q_tau. The exact budget inequality at this transition is

    q+sigma <= Q_(tau-1)+k.

The maintained reference has the correct target phase at this good event
and its preceding hole count dominates Q_(tau-1).

In the own case, (2) gives q+1<=(sigma-1)^2. The own-phase prefix
neighborhood profile at q+1 is therefore at most sigma-1. Consequently

    (q+1)+eta_0(q+1) <= q+sigma,

so its next prefix has at least q+1 holes. In the opposite case, (3)
gives q+1<=(sigma-1)(sigma-2), and the identical inequality holds for
the pronic profile eta_1. Thus either incompatible feature earns delta>=1
within the original daily budget, including integer root endpoints.

If the terminal step is bad, the accepted slack-four credit lemma gives
at least three rooms of lead, so the credit alternative already holds.
No phase identification is needed for that case.

The terminal step is a tracked slow transition, not merely the initialized
entry state. Indeed H>L implies H>=(R+1)^2, whereas the last-entry target
is at most Z=G(L)<(R+1)^2 because k<3R+2. Thus the actual H crossing
occurs strictly after the last fast-to-slow entry. All tested target
prefixes through q+1 fit the genuine quadrant at this cut.

## Source-prefix phase conversion

The prefix of support complementary to a corner hole prefix is anchored
at the diagonally opposite board corner. Put

    chi=(w+n-2) mod2.

A carried HOLE phase p therefore corresponds to SOURCE-prefix phase
p xor chi. It flips when exactly one side is odd and stays the same when
both sides are even. In particular, on odd-width/even-length boards,
hole-own phase corresponds to physical source phase1, not phase0.
The feature pairs in the statement refer to actual support features and
are unaffected by this notation conversion.

## Fast-only and unresolved joint use

If the whole early passage is fast, the existing all-target comparison
supplies both prefix phases by tau+1. The feature dichotomy is unnecessary
there. In a slow passage, combine this lemma with the exact early phase
credit contract: extra entry time and paid rewinds can reduce the reference
index, while this lemma provides a room of lead when the matching feature
is absent.

What remains is a signed critical-region comparison that consumes exactly
this alternative. A theorem for arbitrary independent phase and feature
choices would be stronger and is not asserted here.

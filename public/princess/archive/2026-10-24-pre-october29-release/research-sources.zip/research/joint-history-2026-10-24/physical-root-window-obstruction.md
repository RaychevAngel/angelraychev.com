# A bounded final root window does not erase arbitrary incoming phase debt

24 October 2026. Exact counterexample to a proposed proof relaxation,
not to the actual zero-start hybrid comparison.

Let G(x)=1001+x-rho(x), F(x)=1001+x-ceil(sqrt(x)), and iterate the
ordinary physical pair H(x,y)=(G(y),F(x)). Start at

    (x,y)=(968256,968241)=(984^2,984^2-15).

Its initial span15 is below the local drift1001-984=17. After1799
updates, at the first crossing of994^2, the state is

    (988034,988041).

Its span7 equals the new local drift1001-994. In particular it exceeds
half the drift, even after ten complete, correlated square/pronic bins.
The first-crossing spans at roots985,...,994 are

    15,14,13,12,12,11,10,9,8,7.

`physical-root-window-obstruction.py` checks every intervening update
with exact integer roots and saves the ten crossing states. The same
integer root variable is retained across both walls in every bin; this
failure is not caused by allowing independent wall residues.

Therefore a proof cannot replace the actual hybrid seed by an arbitrary
pair of span at most the incoming drift, then hope that a fixed number
of final bins forces a half-drift spread. Such a replacement loses the
fast reset's phase history. It remains possible that the actual equal
fast-reset trajectory satisfies a stronger global invariant, but that
requires a separate proof. Small empirical phase spans at the desired
boundary are not that proof.

The open uniform capture comparison should also preserve the positive
room slack in the already proved one-day physical boundary repairs.
Replacing those physical pairs by the hybrid pairs may itself create an
unnecessarily strong intermediate inequality. The exact physical
meeting identity permits carrying this slack without a new geometric
state or an additional phase choice.

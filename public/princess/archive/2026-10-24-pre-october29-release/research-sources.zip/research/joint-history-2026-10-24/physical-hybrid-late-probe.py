"""Targeted falsification of the single-fast-reset inequality; not a proof."""
from math import isqrt
from pathlib import Path
import json,time,sys,hashlib

def rho(x):
    r=(isqrt(4*x+1)-1)//2
    return r+(r*(r+1)<x)
def root(x):return isqrt(x-1)+1 if x else 0

def probe(k):
    R=(3*k+4)//5+4 if k<100 else 3*k//5
    cut=R*R+k;top=(k-6)**2
    G=lambda x:k+x-rho(x)
    F=lambda x:k+x-root(x)
    scalar=k;hybrid=(k,k);physical=(G(k),F(k));day=0
    worst=None;first_failure=None
    while True:
        margin=min(physical)-min(top,max(hybrid))
        if max(hybrid)>cut and (worst is None or margin<worst['margin']):
            worst=dict(day=day,margin=margin,hybrid=hybrid,physical=physical)
        if margin<0:
            first_failure=dict(day=day,margin=margin,hybrid=hybrid,physical=physical)
            break
        if max(hybrid)>=top:break
        scalar=G(scalar)
        hybrid=(max(min(cut,scalar),G(hybrid[1])),max(min(cut,scalar),F(hybrid[0])))
        physical=(G(physical[1]),F(physical[0]));day+=1
    return dict(k=k,R=R,cut=cut,top=top,days=day,worst_slow=worst,first_failure=first_failure)

if __name__=='__main__':
    values=list(map(int,sys.argv[1:])) or [1001,2001,10001,100001]
    start=time.process_time();rows=[]
    for k in values:
        row=probe(k);rows.append(row);print(row,flush=True)
        if row['first_failure']:break
    p=Path(__file__)
    out=dict(status='DIAGNOSTIC_ONLY',width_or_length_samples=0,
             CPU_seconds=time.process_time()-start,rows=rows,
             source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()})
    p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

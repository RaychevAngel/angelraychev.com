# A late phase-feature invariant fails at a punctured-root transition

24 October2026 UTC. Exact local counterexample, with a literal-grid receipt.
It is not a counterexample to the requested global gap or to the early
credit-or-feature theorem.

A tempting late invariant would allow physical phase0 when the actual
merged erosion feature is zero, and phase1 when the occupied-corner
feature is zero, requiring a room of lead otherwise. The following valid
local transition does not preserve it.

Take a64 by64 board and budget33. Let the small actual cohort's source
A contain all even-color cells on diagonals2,4,...,48, together with the
33 rightmost cells of diagonal50. The other cohort is full. Thus the
merged residual is657 and its features are(c,e)=(0,0).

This source is itself a neighborhood: take all odd-color cells on
diagonals3,5,...,47 plus32 rightmost cells of diagonal49. Their whole
neighborhood is exactly A. Thus the example does not use an arbitrary
source that cannot occur immediately after a move.

Inspect the33 cells on diagonal50. The small survivor is the full
own-color triangle of625 cells minus its origin, so it has624 cells.
Its neighborhood has650 cells and surplus26. The target is the full
opposite-color triangle, with merged features(0,1).

Compare the physical opposite-phase anchored prefix of657 cells. After
inspecting its last33 cells its survivor prefix has624 cells, and its
next neighborhood also has650 cells. The resulting physical prefix is
now own phase, with features(1,0). There is ZERO room lead, while the
actual target has erosion feature1. Thus the proposed invariant fails
on this single step.

The transition lies in the quantitative late slow regime: b=32,k=33,
R=ceil(3k/5)+4=24, source657>R^2+k=609, survivor root25, and surplus26
is good with slack four. The actual source and target are both below
(b-5)^2=729.

The example isolates a genuine one-cell phase change produced by a
punctured quadrant. It does not prove that the same worst losses occur
in an entire zero-start capture history. A sound late1 theorem must
retain enough clock/phase credit to cover this event; source features
alone cannot be treated as a permanent phase label.

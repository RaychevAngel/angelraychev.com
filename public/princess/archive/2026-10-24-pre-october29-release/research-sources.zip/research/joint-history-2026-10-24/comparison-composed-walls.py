"""Exploratory signed critical transfer; inherited root residues, no resets."""
from pathlib import Path
import importlib.util,json

BASE=Path(__file__).resolve().parents[1]/'uniform-history-2026-10-23'
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
low=load('low_wall',BASE/'adversary-critical-wall-automaton.py')
high=load('high_wall',BASE/'adversary-critical-high-wall-automaton.py')


def high_wall(states,v,square):
    # Unlike the former isolated comparison, do not add equal starts.
    if square:
        A=lambda q:q-v-(q<=0);B=lambda q:q-v;old_lower=True
    else:
        A=lambda q:q-v;B=lambda q:q-v+(q>0);old_lower=False
    out=set();maxexit=0;maxdelay=0;witness=None
    for state in states:
        for s in high.variants(state,v,old_lower):
            for entry in range(1,v+2):
                q=tuple(a+entry for a in s)
                if high.advance(q,A,B)[0]>0:continue
                steps=0
                while max(q)>0:
                    q=high.advance(q,A,B);steps+=1
                    dd=high.delay(q,A,B)
                    if dd>maxdelay:maxdelay=dd;witness=q
                    assert steps<100
                q=high.advance(q,A,B)
                dd=high.delay(q,A,B)
                if dd>maxdelay:maxdelay=dd;witness=q
                out.add(high.normalize(q));maxexit=max(maxexit,-q[0])
    return out,dict(states=len(out),maxexit=maxexit,maxdelay=maxdelay,witness=witness)


def common(states,v,lower):
    A=lambda q:q-v;B=(lambda q:q-v)if lower else(lambda q:q-v+1)
    found=[]
    for s in states:
        for q in high.variants(s,v,lower):found.append((high.delay(q,A,B),q))
    return max(found)


def run():
    rows=[]
    for d in range(1,5):
        states={(0,0,0,0)}
        for j in range(4,-1,-1):
            states,_=low.wall(states,d+j,True)
            if j:states,_=low.wall(states,d+j,False)
        low_states=states
        for odd in (False,True):
            states=low_states
            if odd:
                states,meta=low.wall(states,d,False)
            # Convert capacities to deficits, retaining physical phase order.
            states={(0,-s[1],-s[2],-s[3])for s in states}
            trace=[]
            if odd:
                trace.append(dict(kind='middle',maxdelay=common(states,d,False)[0],states=len(states)))
                states,meta=high_wall(states,d,False)
                trace.append(dict(j=0,kind='pronic',**meta))
            else:
                # Both even high phase orders are possible; keep both.
                states=states|{(x,y,q,p)for x,y,p,q in states}
                trace.append(dict(kind='middle',maxdelay=common(states,d,True)[0],states=len(states)))
            for j in range(5):
                trace.append(dict(j=j,kind='lower',maxdelay=common(states,d+j,True)[0],states=len(states)))
                if j==4:break
                states,meta=high_wall(states,d+j,True);trace.append(dict(j=j,kind='square',**meta))
                trace.append(dict(j=j+1,kind='upper',maxdelay=common(states,d+j+1,False)[0],states=len(states)))
                states,meta=high_wall(states,d+j+1,False);trace.append(dict(j=j+1,kind='pronic',**meta))
            rows.append(dict(d=d,odd=odd,maxdelay=max(x['maxdelay']for x in trace),states=len(states),trace=trace,final_states=sorted(states)))
    return dict(status='EXPLORATORY',width_samples=0,rows=rows)


if __name__=='__main__':
    result=run();Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({**result,'rows':[dict(d=r['d'],odd=r['odd'],maxdelay=r['maxdelay'],states=r['states'],worst=[t for t in r['trace']if t['maxdelay']==r['maxdelay']])for r in result['rows']]}))

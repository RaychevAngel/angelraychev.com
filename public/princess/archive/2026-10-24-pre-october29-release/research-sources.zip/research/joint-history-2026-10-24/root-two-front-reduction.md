# A two-front sufficient inequality for the uniform nine-day goal

24 October2026 UTC. This reduces the outstanding comparison to a precisely
phase-labelled numerical assertion. The last assertion is NOT yet proved.

Let b>=32, b+1<=k<3b, H=(b-6)^2, h=wn/2, and chi=(w+n-2) mod2.
Use the accepted early hybrid E_t and late hybrid C_t, retaining both
coordinates. The former is indexed by the CURRENT phase of a hole prefix;
the latter by the SOURCE phase of a residual prefix. Let A_t be the
ordinary physical zero-hole pair and V_t the ordinary physical backward
gate pair (seed(k,k)). Let Phi be the exact finite-board backward residual
prefix operator, indexed by source phase.

## Same-phase boundary domination

The accepted fast-one lemmas imply, throughout the admitted boundary
range and for each labelled coordinate,

    A_(t+1)[p] >= E_t[p],
    V_(t+1)[p] >= C_t[p].                          (1)

Here only SAME-phase inequalities are asserted. Neither inequality
implies min(A_(t+1))>=max(E_t), or its late analogue.

One may check propagation directly. Suppose a physical pair at t+1
dominates the hybrid at t. The ordinary monotone operator then dominates
the ordinary branch of the next hybrid. It also dominates the next capped
scalar injection: if its scalar target is reached by time t+1, the
accepted fast-one lemma reaches it in both physical phases by t+2.
Taking the coordinatewise maximum proves the induction. The seed case
is immediate. For the late gate clock, the first zero-seed capacity
update is exactly(k,k), so the common initial inspection cancels from
the scalar and physical fast comparison.

## Exact meeting criterion

At any split into s forward-hole moves and t backward gate moves, a
complete solo prefix succeeds by s+t+1 inspections if

    A_s[p xor chi] + V_t[p] >= h                   (2)

for some phase p. The extra1 is the final capture inspection. The
complement of an anchored prefix, rotated by180 degrees, is a prefix
of phase p xor chi: the rotation reverses both diagonal order and the
tie order within each diagonal. Equivalently,(2) follows by composing
the monotone residual maps and their exact threshold inverses. The
clock parity changes which initial phase realizes the path, but the
definition of P minimizes over both initial phases.

## The sufficient remaining assertion

Choose any of the at most four retained endpoint pairs(Q,Y). Write

    e=e_k(Q), ell=ell_k(Y),
    tau=min{j:max B_j>=h-Q}, B_0(c,e)=Y.

Thus the accepted necessary joint gate clock is the minimum of
e+tau+ell over these four choices. The following assertion would imply
the requested result:

    There is a phase p such that
    Phi^(tau+2)(C_ell)[p] + E_e[p xor chi] >= h.   (3)

Indeed(1), monotonicity, and(2) would give

    P <= (e+1)+(tau+2)+(ell+1)+1
      = e+tau+ell+5.

Taking a minimizing endpoint pair yields P<=g_joint+5<=g+5, hence
T>=2P-9. This route does NOT require the stronger, still unproved
late minimum-versus-maximum one-day statement. Nor does it require the
refuted isolated matched-phase critical2 statement. It preserves the
two boundary capacities and their antipodal phase compatibility.

The accepted hybrid duality supplies substantial input structure for(3):
C_ell-k is a point on the same alternating numerical orbit as E_e, up to
one room in one coordinate. For near-minimum budgets the two boundary
positions lie across only a single pronic wall. Treating E_e and C_ell as
unrelated arbitrary seeds would discard precisely this structure.

## Outstanding proof obligations

The exact physical maps and phase orientation in(2) must be independently
checked against the authoritative diagonal-prefix implementation. The
uniform middle assertion(3), including cap transitions and all three
parity types, remains open. A diagnostic meeting in one board is not a
proof of(3). No new public or Lean claim is made here.

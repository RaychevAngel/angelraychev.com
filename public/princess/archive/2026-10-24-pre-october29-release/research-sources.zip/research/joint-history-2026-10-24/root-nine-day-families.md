# A nine-day bracket outside a fixed low-budget window

24 October2026 UTC. Ordinary physical-game theorem with independent
mathematical review. The requested nine-day bound for ALL feasible budgets
is not yet proved. No new Lean or public-release claim is made.

Write b=floor(w/2), w<=n, k>=b+1. Let P be the smaller complete solo
anchored-prefix inspection clock over the two initial phases.

For every even-area rectangle with w>64 and k<3b, the following sufficient
conditions give

    P<=g+5 for every actual first merged-gate time g,
    2P-9 <= T_k(w,n) <= U <=2P:

* even width: k>=b+18;
* odd width, even length: k>=b+20.

There is no length threshold and no upper bound on the width. Earlier
exact and smaller-gap bounds remain combined by maxima/minima. The new
lower2P-9 needs only the existing physical prefix-clock evaluator; the
more detailed joint evaluator below can strengthen it instance by instance.

## Joint necessary clock and proof of the comparison

Put H=(b-6)^2 and h=wn/2. At the actual early and late cuts retain

    Q in[H,H-1+k-rho(H-1+k)],
    Y in[H+1,H+k-rho(H)].

Let e_k(Q) be the accepted necessary early hybrid time, ell_k(Y) the
necessary late hybrid time, and tau_9(h-Q;Y) the accepted necessary
nine-feature passage time from equal threshold Y to maximum at least h-Q.
The cuts meet at states, without sharing a move. Thus every actual gate
history satisfies

    g >= J_k(w,n)
      = min_(Q,Y) [e_k(Q)+tau_9(h-Q;Y)+ell_k(Y)].   (1)

The minimum retains at most TWO Q values and TWO Y values: each boundary
clock takes at most two consecutive values on its crossing interval, and
within a constant-clock block the largest capacity dominates every other
choice. This compression is exact. `root-joint-hybrid-clock.py` evaluates
it, with the independently reviewed boundary APIs and BAND9 recurrence.
For every parameter in the new even-area low-budget range, even outside
the new nine-day families, it supplies the valid computable lower

    T_k(w,n)>=2J_k(w,n)+1.                         (2)

The parity refinement `lower-large-excess-parity-refinement.md` proves
that for each retained(Q,Y), both labelled physical middle capacities
from the ACTUAL late hybrid state reach h-Q within tau_9+2 moves when
d=k-b>=18 at even width or d>=20 at odd width. The early hybrid has at
least Q rooms in one labelled coordinate. The exact antipodal meeting
criterion, with phase correction(w+n-2) mod2, therefore connects them.

The same-phase boundary comparisons cost one move each; the middle costs
two; the final capture inspection costs one. No phase is freely reset.
Consequently

    P <= e_k(Q)+tau_9(h-Q;Y)+ell_k(Y)+5.

Choose a minimizing pair in(1). Then P<=J+5<=g+5. The already accepted
reversed-walk cut gives(2), hence T>=2P-9. Two sequential physical solo
prefixes supply U<=2P.

The room accounting underlying the parity thresholds is short:

* actual late boundary phase spread is at most d+7;
* low injections and exit alignment together spend at most6 rooms;
* two genuine physical moves gain2d rooms at even width,2d-1 at odd width;
* the central interval spends0 rooms at even width and1 at odd width,
  with its square endpoint absorbed by the exact entry calculation;
* high clamps and terminal alignment together spend at most5 rooms.

The final remaining leads are d-13 at even width and d-15 at odd width,
so five rooms suffice at d18 and d20. The detailed proof checks all cap
interfaces, skipped intervals, overshoots, and saturation at h. These are
uniform inequalities; no panel of board sizes supplies their proof.

## Coverage of every feasible input

Odd-by-odd rectangles retain their exact joint evaluator. Widths at most64
retain the complete gap-at-most3 theorem. Even-area boards with w>64 and
k>=3b retain the earlier gap-at-most1 comparison. These statements are
unchanged and combine with the new families above.

The ONLY ranges still lacking the desired general nine-day guarantee are

    even w=2b>64:       1<=k-b<=17;
    odd  w=2b+1>64,
    even n>=w:          1<=k-b<=19.

Width and length remain unbounded in both. Every such input still has
the previous universal bound (gap<=23 even width,<=25 odd width), all
older stronger results, and the new exact joint lower(2). No instance
is dropped from coverage. The largest PROVED all-input ceiling is still
25; the universal nine-day goal remains open in these residual families.

## Evidence, limitations, and restart

Principal proof chain: the two hybrid necessity notes; the exact endpoint
compression; `physical-joint-clock-review.md`; `lower-two-front-meeting.md`;
`root-two-front-reduction.md`; the large-excess base and parity refinement;
and their independent review receipts. The current source hashes are
recorded by the final verification receipt.

The research log records several disproved stronger intermediate claims.
An isolated critical2 statement fails. Arbitrary boundary seeds, generic
phase-spread restrictions, and a guessed square-spread barrier are also
insufficient. They are not counterexamples to the physical nine-day goal.

The remaining promising constraint is common equal-reset origin of both
boundary phases. Exact inverse intervals exclude all four saved fake
boundary counterexamples. A uniform implication from this origin condition
to the paired meeting inequality has not been proved. See
`comparison-restart.md` before repeating a weaker local phase model.

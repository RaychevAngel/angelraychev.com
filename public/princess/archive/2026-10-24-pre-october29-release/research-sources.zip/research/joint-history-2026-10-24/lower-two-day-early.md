# Two-day early comparison with the actual crossing target

24 October2026 UTC. New ordinary theorem submitted for independent review.
The accepted three-day theorem and the uniform25-day assembly are preserved.

Let w<=n have even area, b=floor(w/2)>=32, and b+1<=k<3b.
Put H=(b-5)^2. If an actual two-cohort history first reaches total holes
Q_tau>=H at time tau, then some zero-seed physical anchored-prefix hole
trajectory has at least Q_tau holes by reference time tau+2.

This strengthens `../uniform-history-2026-10-23/lower-early-overshoot-domination.md`
by one day. Its physical slow-history argument, canonical corner/cohort
labels, paid rewinds and five-root cutoff are unchanged. The improvement
comes from comparing each entry target with its own scalar hitting time.

## Scalar and alternating reference maps

For rho(y)=min{r>=0:y<=r(r+1)}, write

    G(x)=x+k-rho(x+k),
    F(x)=x+k-ceil(sqrt(x+k)).

These are nondecreasing and1-Lipschitz, with F<=G<=F+1. Starting at0,
let S_t iterate G and let X_t^p alternate G,F in either initial phase p.
For every t,

    0 <= S_t-X_t^p <= ceil(t/2).                  (1)

Only F steps can add a room of discrepancy; a G step cannot increase it.
This estimates cardinalities of the actual physical reference while the
relevant prefixes and their neighborhoods fit in the rectangle. A
hitting comparison for a smaller physical target continues to hold when
an abstract update overshoots the quadrant range, by the accepted clipped
inverse-neighborhood argument.

Set R=floor(2k/3) if k>=75, or R=floor(4k/5) if33<=k<75, and put

    L=R^2,    u=k-R-1,    Z=G(L).

The accepted estimates give Z<=L+u, and every alternating step before
reaching a target at most Z gains at least u when k>=75. In detail,
for an input x<Z,

    x+k <= L+2k-R-2 <= (R+1)^2,

using2k<=3R+3. Thus the smaller map F subtracts at most R+1.

## One integer of slack in the scalar-time bound

Let t_G be the first time S_t>L. The two-stage estimate from the
three-day proof, with S=floor(R/2), is

    t_G <= ceil((S^2+1)/(k-S-3))
           +ceil((R^2-S^2)/u).                  (2)

The stronger bound t_G<=4u-1 holds for every k>=75. Write k=3m+j,
where m>=25. The second-stage ceilings and improved first-stage bounds
are as follows:

* j=0: R=2m, S=m, u=m-1. The second ceiling is3m+4 and the first
  is at most m-9, since
  (m-9)(2m-3)-(m^2+1)=m^2-21m+26>0 for m>=25.
* j=1: R=2m, S=m, u=m. The second ceiling is3m and the first is
  at most m-1, since
  (m-1)(2m-2)-(m^2+1)=m^2-4m+1>0 for m>=25.
* j=2: R=2m+1, S=m, u=m. The second ceiling is3m+5 and the first
  is at most m-6, since
  (m-6)(2m-1)-(m^2+1)=m^2-13m+5>0 for m>=25.

Each displayed polynomial is positive at25 and increasing thereafter.
The sums are exactly4u-1 in each case. Since S_(t_G)>L, monotonicity
implies S_(t_G+1)>=G(L)=Z. Therefore the scalar first hitting time
s(A) of every integer target1<=A<=Z is at most4u.

At time s(A), (1) gives X^p>=A-2u in both phases. Every further step
below A gains at least u, so

    J_p(A) <= s(A)+2       (p=0,1; 1<=A<=Z).     (3)

Unlike the old entry-envelope comparison, this uses s(A), not s(L+1).
An actual crossing close to Z cannot be charged the earlier scalar
crossing time of L+1.

For33<=k<75, the accompanying finite arithmetic certificate checks (3)
for every integer target1<=A<=G(R^2), both initial phases, and all42
budgets. Its maximum loss is2. Neither board dimension is enumerated.

## Transfer to the actual early history

The accepted scalar surplus inequality implies that the scalar G orbit
reaches any actual target before or at the actual time it is reached,
through the first H crossing. All actual targets in question are below
H+k<b(b-1), so the ordinary subcritical bound applies directly.

If H<=L, the crossing target satisfies

    Q_tau <= G(H-1) <= Z.

Apply (3) to A=Q_tau, whose scalar hitting time is at most tau. Both
reference phases dominate the actual crossing target by time tau+2.
Only that target prefix is used physically; a larger abstract cutoff L
need not fit in the board.

If H>L, let t0 be the time after the last actual state with Q<=L before
the first H crossing. Then Q_(t0)<=G(L)=Z. Apply (3) directly to
A=Q_(t0), whose scalar hitting time is at most t0. Both reference
phases dominate this actual entry size by time t0+2. Choose the phase
matching the first subsequent good event and use the already proved
paid rewinds at later changes of canonical cohort/corner. The slow
argument has no accumulating positive reference-time cost. It maintains
pointwise dominance through Q_tau, including its overshoot. Hence the
final reference index is at most tau+2.

The result is a pointwise physical comparison for the actual crossing
size. It does not yet give a nine-day global gap; the phase and room
credit passed into the critical and late regions remain separate work.

# What the early history comparison actually supplies

24 October2026 UTC. Exact bookkeeping refinement of the accepted paid-rewind
construction; proposed for independent review. No global nine-day conclusion.

The scalar endpoint bounds hide two useful quantities: real time spent
before the last entry, and reference days recovered by paid rewinds. This
note keeps both, as well as the phase of the resulting physical prefix.

## Contract at the last fast-to-slow entry

Use any proved early passage with fast cutoff L=R^2 and all-target fast
allowance e: both zero-seed alternating physical prefixes reach every
relevant entry size A by scalar hitting time s(A)+e. Examples are the
same-cut early2 theorem, or the six-root early1 theorem for k>=100.

Let t0 be the actual time after the last state with Q<=L before the final
first H crossing at tau. Put A=Q_(t0), and

    W=t0-s(A)>=0.

The nonnegative integer W is actual elapsed time not needed by the scalar
G clock to reach the specific entry target. Initialize the physical
reference at index

    j0=s(A)+e=t0+e-W.

Both initial reference phases dominate A at that common index. Choose the
initial phase to match the first good event in the following slow interval.
Advance the reference once per actual transition, applying exactly the
already proved paid backward rewinds whenever a later good event needs
opposite phase. Let N be the total number of such rewinds through tau.
Then at the final state

    X_j >= Q_tau,
    j = tau+e-W-N.                              (1)

The formula is exact for this specified reference bookkeeping; choosing
an earlier admissible initial index can only improve it. The phase of X_j
is the phase carried by the latest good dominant actual cohort/corner,
advanced through any subsequent bad events. It is not an arbitrary phase
chosen afresh at the end.

Therefore the carried phase has deadline tau+e-W-N. The opposite phase
always has deadline at most tau+e-W-N+1, by advancing the same physical
prefix once. The physical prefix cardinalities are nondecreasing in the
feasible range. When W+N>=1, this gives BOTH phases by tau+e.

In particular, the early1 proof gives both phases by tau+1 whenever
there is a paid rewind or a delayed scalar entry. The only histories in
which its one-day conclusion leaves an extra opposite-phase day have
W=N=0 and insufficient room lead to use the next lemma.

If the entire passage is fast, the all-target theorem already gives both
phases by tau+e; no slow-history phase restriction arises.

## A target-specific terminal rewind

Suppose a maintained physical prefix at index j dominates q=Q_tau with
room lead delta=X_j-q>=0, and the relevant predecessor comparison is in
the genuine quadrant. Define the exact integer

    D(q)=k-rho(q-1+k).

If delta>=D(q), then X_(j-1)>=q. Indeed, otherwise X_(j-1)<=q-1, and
monotonicity of the larger prefix update gives

    X_j <= G(q-1)=q+D(q)-1,

contradicting the lead assumption. The predecessor has the opposite phase.
Thus the opposite phase deadline improves from j+1 to j-1 whenever the
available lead reaches D(q). This spends existing room lead and recovers
a reference day; it does not claim that a new phase can be selected for free.

For q>=H=(b-C)^2 and feasible k>=b+1, the safe cut-only bound is

    D(q) <= k-b+C-1.

This follows from rho(q-1+k)>=b-C+1. At the five-root cut it is d+4,
and at the six-root cut d+5, where d=k-b. The exact D(q) can be smaller.
A statement k-ceil(sqrt(q))-1 would be unjustified in part of a root bin
and is deliberately not used.

## Why this does not settle the joint phase choice

A zero-rewind history need not have one literally fixed corner: dominant
identities can change without changing the required phase. What stays
fixed at good events is the relevant phase convention, after accounting
for elapsed time. The strict dangerous class for a joint comparison is:

* no scalar-entry time credit W;
* no paid rewind N;
* terminal room lead less than D(Q_tau);
* a critical or late continuation preferring the opposite carried phase.

It remains to show that these properties cannot simultaneously produce
the worst separate critical/late losses, or to quantify the necessary
compensation. Canonical dominant labels describe real physical history;
ordinary three-corner features alone do not yet identify that phase.
This is an unresolved compatibility condition, not a claimed merger rule.

# One-day early comparison for every budget in the new range

24 October2026 UTC. Finite-parameter extension submitted for independent
review. The accepted25-day global theorem remains unchanged.

Let w<=n have even area, b=floor(w/2)>=32, and b+1<=k<3b. Put
H=(b-6)^2. If an actual two-cohort history first reaches total holes
Q_tau>=H at time tau, then some zero-seed physical anchored-prefix hole
trajectory dominates the ACTUAL Q_tau by reference index at most tau+1.

This includes every budget in the unbounded-width low-budget range. It
uses the complete physical proof in `lower-one-day-early-large-budget.md`
for k>=100 and the following finite arithmetic extension for33<=k<100.
Neither width nor length is sampled, bounded, or preprocessed.

## A sufficient cutoff for the67 remaining budgets

Choose

    R=ceil(3k/5)+4        if33<=k<100,
    R=floor(3k/5)         if k>=100.

As before L=R^2, D=k-R-1, and Z=G_k(L). On the finite budget range,
19<=R<k-2 and R>=floor(3k/5). Every slow target root r>=R+1 is at
least20 and strictly exceeds3k/5. Consequently every geometric argument
in the large-budget note remains valid:

* good events have surplus at most r+4<b, remainder at most five,
  and at most25 outlier holes;
* a change between consecutive good identities Delta moves apart obeys
  Delta*k>=(r^2-11r-108)/2;
* bad transitions earn three rooms per move;
* a lead D pays a backward reference rewind;
* all compared target intervals are genuine quadrant prefixes;
* when H>L, the final crossing overshoot still has root at most b-5.

The only numerical conditions requiring replacement are the switch-credit
inequality at the smallest allowed root and the all-target fast comparison.
For every one of these67 budgets, the accompanying exact certificate checks

    3*(ceil(((R+1)^2-11(R+1)-108)/(2k))-1) >= D,  (1)

and, for BOTH initial alternating phases p and EVERY integer target
1<=A<=Z,

    J_p(A) <= s(A)+1.                           (2)

The quadratic in(1) increases for r>=R+1, so this one parameter check
proves the switch credit for every possible larger slow root and every
board supporting that root. Condition(2) covers every possible actual
entry or fast-only target. It does not sample selected physical histories.

## Transfer and evidence boundary

Apply(2) to the actual last-crossing entry target A, whose scalar hitting
time is no later than its actual time. Choose the phase of the first good
event, and apply(1) and the already proved paid-rewind construction at every
later phase change. If the whole passage is fast, (2) directly applies to
the actual crossing target. These are exactly the physical cases in the
large-budget theorem, with no new history or board exceptions.

The output phase remains the carried dominant-event phase when a slow
segment occurs. It is not asserted that both final phases reach the actual
crossing target by tau+1. The stronger phase/credit information is stated
in `lower-early-phase-credit-contract.md`.

This finite parameter certificate completes the early1 lemma for every
k>=33. It does not prove the desired global nine-day capture gap, which
still needs compatible critical and late contracts.

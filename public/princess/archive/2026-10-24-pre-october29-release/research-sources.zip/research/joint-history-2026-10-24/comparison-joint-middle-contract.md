# The remaining comparison is a paired meeting, not a minimum-phase clock

24 October 2026. Research contract and algebraic clarification. The
inequality in the next paragraph is a sufficient conjecture, not a proved
uniform bound.

Let E_e and C_l be the accepted early and late hybrid pairs at the
necessary boundary times. Let Q<=max(E_e), Y<=max(C_l) be retained crossing
endpoints, and let tau be the first time the necessary nine-feature model,
initialized at the equal threshold Y in all features, reaches h-Q.
Write Phi for the exact finite-board physical backward prefix update and
chi=(w+n-2) mod2. A sufficient sharper middle assertion is

    max_p [Phi^(tau+2)(C_l)[p] + E_e[p xor chi]] >= h.       (J)

It is not necessary that both physical phases dominate the model maximum.
The exact physical two-front adjunction is proved separately in
`lower-two-front-meeting.md`. The same-phase one-day fast comparisons at
the two ends would turn(J) into P<=e+l+tau+5, including the final capturing
inspection. This does not require the stronger, unresolved late
minimum-versus-maximum one-day assertion.

The exact hybrid relation is E_t=D_t+epsilon_t, where D_t=C_t-k and
epsilon_t is zero or one in just one coordinate. After their common fast
cutoff, both pairs follow the SAME alternating forward map. Consequently
E_e and C_l cannot be selected independently, even if their values and
spreads separately look plausible. The relation and its proof are in
`lower-hybrid-duality.md`.

## A direct check of the previously difficult geometry

For w=2001,n=2002,k=1001, the retained minimizing endpoint times are
e=8168,l=8014,tau=16545. The exact pairs are

    E_e=(988042,988041), C_l=(988043,988041).

At the unextended middle time tau,

    Phi^tau(C_l)=(1014960,1014954).

Here h=2003001 and chi=1, so the two meeting margins are(0,-5).
One compatible phase already meets with no middle allowance. This is an
exact check of this geometry, not a uniform proof of(J). It explains why
the earlier equal-seed minimum-phase counterexample need not obstruct a
joint comparison.

## Why a formal inversion must preserve the phase swap

After shifting low backward capacities by k, write

    G(z)=z+k-rho(z+k), F(z)=z+k-ceil(sqrt(z+k)),
    H(x,y)=(G(y),F(x)).

At the relevant positive critical thresholds (where these inverses are
nonnegative), the least integer inverse thresholds are

    G_inv(z)=z+ceil(sqrt(z))-k,
    F_inv(z)=z+1+rho(z)-k.

Thus the physical high-deficit map is J H_inv J, where J swaps the
coordinates. The low necessary closure raises its SECOND coordinate to
at least the first minus one. The high closure lowers its SECOND
coordinate to at most the first plus one. After applying the antipodal
swap, the latter acts on the FIRST low-side coordinate. The high closure
is therefore not the simple inverse of the same one-sided low closure.
Any proposed Galois or cancellation argument must retain this distinction.

## Refuted shortcuts

The relaxed common-orbit seed test in `root-common-orbit-attack.py` is
stronger than(J): it permits near-boundary seeds and error orientations
that need not originate at the zero-seeded scalar cutoff. Its recorded
failures are not physical counterexamples and do not refute(J).

The earlier word-deletion shortcut also fails even for the actual root
maps. With F(z)=8+z-ceil(sqrt(z)), G(z)=8+z-rho(z), Q=G-1 and J=F composed
with G, x=6,m=2 give

    Q J^2 Q(6)=29 > 28=J^3(6).

Accordingly, arbitrary pairs of optional phase-holding steps cannot be
deleted without a history-dependent allowance. This is an exact scalar
counterexample, not a rectangle-game counterexample.

The next mathematical obligation is a uniform proof of the paired meet,
or a weaker signed comparison that retains the actual spare room supplied
by the two physical fast comparisons. If(J) fails, its failure must be
recorded rather than repaired by silently changing the input family.

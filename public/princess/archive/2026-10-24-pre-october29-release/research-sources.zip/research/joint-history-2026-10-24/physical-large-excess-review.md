# Independent review of the whole-middle room-credit comparison

24 October 2026. The ordinary proof in
`lower-large-excess-middle-two.md` is independently accepted. It is a
uniform parameter theorem, not an extrapolation from width samples.

## Checked interfaces

The necessary nine-to-three projection is used only above the common
terminal seedY. Any newly needed source there has survivor larger than
Y-k>2, so the positive corner-count relaxation does not invalidate the
projection. Equalizing the necessary three-coordinate state at a module
exit makes its subsequent clock faster. Both physical coordinates pay
for this equalization; no new physical phase is selected.

In the low module, the virtual physical pair starts equal atY-(d+7)
and is dominated by the actual hybrid pair. Until the necessary low
maximum first reaches b^2, all virtual inputs are below that threshold.
Consequently the exact low maps apply, and one-Lipschitz propagation
bounds its deficit by the initial span allowance plus the six possible
unit injections. Adding the one-room exit span gives d+14 rooms of debt.
The final low step's overshoot is retained.

The two added physical updates are inserted once, after this low exit.
They preserve the parity of the physical pair relative to the necessary
clock. Subsequent central and high comparisons use uniform positive
room lead, not independently selected phase clocks. Short rectangles
and large jumps can omit later modules; the corresponding losses are
then simply unused.

At odd width the central cost is at most three rooms: one for an exact
b^2 entry whose ahead physical pair may already use costb+1, one for
the single exceptional central edge, and one for its final span. The
ordinary physical maps globally dominate the central affine maps, so
positive lead cannot otherwise decrease. Even width needs none of these
three room allowances.

At the high reset both physical deficits are below the equal necessary
deficit and satisfy its entry cap. Monotonic expansive root maps preserve
that ordered advantage. Each of at most six odd/five even clamps spends
one room, and the final one-room span converts labeled control to a
bound in both phases. Zero deficit clipping only helps.

These facts prove the submitted uniform d>=26 theorem and justify
exactly the final tau+2 time count. Time monotonicity from the actual
hybrid seed extends an earlier physical completion to that exact horizon.

## Direct parity sharpening

The same proof already gives better thresholds without another case
analysis. Let d=k-b. On an odd-width rectangle, one physical inverse
update in source phase0 has cost at mostb and one in phase1 at mostb+1.
Every coordinate of TWO successive updates therefore gains at least
2d-1, capped at h. At even width both source caps areb, so the gain is
at least2d. The two-step phase parity is unchanged.

After the low debt d+14, the resulting lead is at least

    d-15 at odd width,  d-14 at even width.

Odd central/high losses total at most3+7=10. Even losses total0+6=6.
Therefore the identical whole-middle conclusion holds for

    odd width: d>=25;  even width: d>=20.

This sharpening is independently accepted. It uses only inequalities
already verified at the exact finite-board interfaces. It does not claim
the proposed further odd-width threshold24, whose shared event allowance
needs separate checking.

Together with the accepted two-front reduction, these parameter ranges
satisfy P<=g_joint+5 and physical gap at most nine. Smaller excesses remain
outside this theorem; the previously accepted all-parameter bounds and
all sharper instance/family bounds must still be retained.

## Final accepted refinement:18 even,20 odd

The assembled `lower-large-excess-parity-refinement.md` is independently
accepted with its stronger final thresholds. I checked each shared
allowance against the exact ordinary comparator maps:

* Low injections plus exit span total at most six. If the final root-b
  injection occurs, it ties the pair and the remaining upper-half maps
  agree through the exit, including its overshoot. Otherwise there are
  at most five injections and at most one room of span.
* At odd equal high entry, the top root b is already in its lower half,
  where A=B. It cannot clamp before leaving that root. Both parities
  therefore have at most five high clamps. If all five occur, the last
  ties the pair and preserves that tie through targetQ>=H; otherwise
  the unused clamp allowance pays the terminal span. Their total is
  at most five rooms.
* The odd central exceptional edge is impossible under d<2b. Every
  fresh strict B1>B0 has B1<=L+d<E; a later update aboveL destroys
  the difference. Only the central exit span of one remains.
* At the exact odd endpoint z1=b^2, the virtual common lower bounds
  b^2-d-13, b^2-13, b^2+d-13, b^2+2d-14 prove that TWO extra low
  updates plus ONE matched endpoint update preserve the same d-14
  lead as the non-endpoint case. There is no third extra update.

Thus low debt is d+13. The paired physical gains leave d-14 odd or
d-13 even. Odd central alignment spends one room; even spends none.
Five rooms suffice for the high module. The final sufficient conditions
are therefore d>=20 odd and d>=18 even. All arbitrary-width, arbitrary-
length, endpoint, phase, and physical-history conditions of the base
proof are retained. No numerical sampling is used for this sharpening.

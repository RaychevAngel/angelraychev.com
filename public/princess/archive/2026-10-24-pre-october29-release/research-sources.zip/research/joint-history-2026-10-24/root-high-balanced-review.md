# Exact high-region pair and the early credit alternative

24 October 2026 UTC. Independent algebraic verification of the comparison
lane's retained-feature reduction. Physical finite-board entry conditions
and the full passage clock are still separate obligations.

Let the high-region nine deficits have one of the nine previously proved
patterns D=d+P, d>=4. Set

    x=D(2,1), y=D(1,2),
    A(z)=z+ceil(sqrt(z)), B(z)=z+1+rho(z).

For the isolated high operator, before terminal feature floors act, the
two exact output deficits are

    x'=A(y)-k,
    y'=min(B(x),A(y)+1)-k.

This retains which component is which. It is stronger than replacing
them by the overall minimum or resetting both to that minimum. The only
departure from the physical pair (A(y)-k,B(x)-k) is a one-room reduction
of its second coordinate when the raw second coordinate exceeds the
first by two. Such a reduction can occur only in pattern111/110/110.

The independent checker `root-high-balanced-certificate.py` verifies
9,180 finite deficit cases d=4,...,1023 and387 affine cells for every
root index r>=32. The latter are symbolic sign checks on whole intervals
d=r^2+u, not numerical samples of large rectangles. It uses the prior
uniform high-operator certificate for the root and static-band branches.

It also verifies, on all nine patterns,

    min_{c<=1,e<=2} D(c,e)=D(1,2),
    min_{c<=2,e<=1} D(c,e)=D(2,1),
    0<=D(1,2)-min D<=1,
    0<=D(2,1)-min D<=1.

These facts explain why the early physical dichotomy has the right form.
If the actual source is in the compatible feature face, its necessary
threshold is controlled by the corresponding labelled coordinate. If
instead the carried physical residual is one room below the actual
residual, that room pays the possible one-room difference between the
overall threshold and either face threshold. It does not pay for an
arbitrary late phase switch.

This implication is conditional on the actual critical frontier having
entered the certified pattern system and on the correctly labelled
physical pair comparison. The old isolated physical interface only
proved a conservative D<=(b-8)^2 range; it cannot silently be used at
the new six-root cut. The cap-entry proof is being developed separately.

# A uniform span bound for the actual late hybrid boundary pair

24 October 2026. Ordinary algebraic lemma, submitted for independent
review. This bounds the actual hybrid pair; it does not assert that an
arbitrary pair with this span satisfies the desired middle comparison.

Let b>=32, b+1<=k<3b, d=k-b, H=(b-6)^2. Write

    G(x)=k+x-rho(x), F(x)=k+x-ceil(sqrt(x)).

Let C_t be the accepted late hybrid pair, and let ell be the first time
its maximum reaches some Y in[H+1,H+k-rho(H)]. Then

    |C_ell[0]-C_ell[1]| <= d+7.                   (1)

The same argument gives d+6 if k<=2b-14.

## Time interlacing of the actual pair

At each relevant time the hybrid coordinates are nondecreasing. Both
ordinary terms at the current update are at most the corresponding
map applied to the OTHER current coordinate. The common capped scalar
injection is at most each current coordinate. Since F(x)>=x andG(x)>=x
through this boundary range, it follows that

    C_t[0]<=G(C_t[1]), C_t[1]<=F(C_t[0]).          (2)

This also holds when the injection is still active; it does not require
a claim that the fast cutoff has already been crossed.

For completeness all coordinates at ell are below b(b-1): the preceding
maximum is less thanY, and the next is at mostG(Y-1). Thus

    max C_ell <=Y+k<=H+2k-b+6<b(b-1).

In this range F andG have positive progress, as used in(2).

## Root lower bound and span

Put x=min C_ell and M=max C_ell. Because F<=G, equation(2) implies
M<=G(x). We know M>=Y>H. At

    x0=(b-8)(b-7), rho(x0)=b-8,

one has

    G(x0)=H+k-4b+28<H,

using k<3b andb>=32. Monotonicity therefore forces x>x0 and hence
rho(x)>=b-7. Consequently

    M-x<=G(x)-x=k-rho(x)<=d+7,

which proves(1).

If k<=2b-14, instead take x1=(b-7)(b-6). Then
G(x1)=H+k-2b+13<H, so rho(x)>=b-6 and the bound improves to d+6.

The conclusion requires the actual hybrid time interlacing. It supplies
no root-window contraction from generic incoming phase debt, which the
separate ten-bin counterexample refutes.

"""Exact one-fast-region hybrid gate clock. Physical scope is in the proof note.

This module evaluates a relaxation, not a physical strategy optimizer.
The gate clock counts moves to residual <=k, excluding the final inspection.
"""
from bisect import bisect_left
from math import isqrt

def square_root(x):
    return isqrt(x-1)+1 if x else 0

def rho(x):
    r=(isqrt(4*x+1)-1)//2
    return r+(r*(r+1)<x)

def cutoff(k):
    if k<33:raise ValueError('The proved physical reduction requires k>=33.')
    R=(3*k+4)//5+4 if k<100 else 3*k//5
    return R,R*R+k

def hybrid_gate_curve(k,ceiling,keep_phases=False):
    """Thresholds for all Y<=ceiling; gate_time(curve,Y) returns the clock.

    `maxima[t]` is the largest residual admitted in t moves in either
    initial phase. `phases[t]`, when requested, retains both labelled
    thresholds (own first). No board dimensions occur in this evaluator.
    """
    R,A=cutoff(k)
    scalar=k;pair=(k,k);maxima=[k]
    phases=[pair] if keep_phases else None
    while maxima[-1]<ceiling:
        scalar=k+scalar-rho(scalar)
        pair=(max(min(A,scalar),k+pair[1]-rho(pair[1])),
              max(min(A,scalar),k+pair[0]-square_root(pair[0])))
        maximum=max(pair)
        if maximum<=maxima[-1]:
            raise ValueError('Requested ceiling is outside the increasing hybrid range.')
        maxima.append(maximum)
        if phases is not None:phases.append(pair)
    result=dict(k=k,R=R,fast_cut=A,ceiling=ceiling,maxima=maxima)
    if phases is not None:result['phases']=phases
    return result

def gate_time(curve,Y):
    if Y>curve['maxima'][-1]:raise ValueError('Curve does not reach this residual.')
    return bisect_left(curve['maxima'],Y)

def gate_times(k,targets):
    """Convenience wrapper: compute a curve once and evaluate many ceilings."""
    targets=list(targets)
    curve=hybrid_gate_curve(k,max(targets,default=k))
    return [gate_time(curve,Y) for Y in targets]

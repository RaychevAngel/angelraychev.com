# Exact meeting of two physical prefix fronts

24 October 2026. An adjunction identity for the already proved physical
prefix strategy. Submitted for independent review. It does not assert
that either hybrid front is itself physically attainable.

Let an even-area rectangle have h rooms in each color class. Let
chi=(w+n-2) mod2. Fix the physical diagonal-prefix family, including its
established within-diagonal order. Define its exact residual maps

    phi_p(m)=|N(prefix_p(max(0,m-k)))|, 0<=m<=h,

where p is the CURRENT source phase. These are nondecreasing maps of
{0,...,h} to itself and phi_p(0)=0. A residual at most k is already
captured by the next inspection; mapping it to0 is harmless absorbing
bookkeeping if a longer comparison horizon is used.

Let P be the smaller of the two physical solo prefix inspection clocks.

## Forward and backward fronts

Define the forward physical hole pair A_0=(0,0), with coordinates indexed
by CURRENT hole phase at the antipodal corner:

    A_(t+1)[1-q]=h-phi_(q xor chi)(h-A_t[q]).      (1)

Define the backward physical gate-capacity pair V_0=(min(k,h),min(k,h)),
with coordinates indexed by CURRENT residual/source phase:

    V_(s+1)[p]=max{m in[0,h]:phi_p(m)<=V_s[1-p]}. (2)

The zero-move backward seed includes the final capturing inspection.
Thus V_s describes s movements followed by that final inspection.
Both pairs use exact finite-board maps, not quadrant formulas continued
past their valid range.

For every nonnegative t,s,

    P<=t+s+1
      iff max_(p=0,1) [A_t[p xor chi]+V_s[p]]>=h. (3)

## Proof by threshold adjunction

For every source phase p and threshold v, monotonicity of phi_p gives

    phi_p(m)<=v
      iff m<=max{u:phi_p(u)<=v}.

Induction in s proves that V_s[p] is exactly the largest prefix residual
capturable within s more movements and the final inspection, starting
in phase p. This uses the same fixed prefix strategy throughout; no
optimization over arbitrary inspection strategies is claimed.

Equation(1) is the complement size of the forward prefix residual after
t moves. Because both initial phases are allowed, h-A_t[p xor chi] is
exactly the residual reached in current phase p by the corresponding
one of the two zero-start prefix strategies. It can be finished within
the allowed s remaining movements precisely when

    h-A_t[p xor chi]<=V_s[p].

Taking the existential choice of p proves(3). Empty residuals and an
earlier capture may be padded by the absorbing value0, so the argument
also covers the "at most" interpretation without an extra day.

The antipodal phase correction is geometric, but no unproved tie-order
claim is needed for the size adjunction. For the actual standard prefix
order it also holds at set level: a180-degree rotation sends diagonal
sum d to w+n-2-d and reverses the within-diagonal coordinate, reversing
the entire ordering. The complement of a prefix is therefore the
corresponding antipodal prefix, with phase xor chi.

## Free choice of the meeting cut

For a fixed total horizon N=t+s+1, condition(3) has the same truth value
at every split t+s=N-1. The witnessing current phase changes according
to its physical parity. Choosing a convenient split is legitimate; it
does not introduce a fresh independent phase choice on either side.

In particular, if J is a proved necessary merged-gate clock, a sufficient
way to establish the desired comparison P<=J+5 is to find ANY split
t+s=J+4 and prove the physical meeting inequality in(3). Equivalently,
one may prove it at a cut selected from the actual/model history.

The existing endpoint-based necessary clock supplies information on
relaxed early and late fronts, not automatically on A and V. The missing
mathematical work is to transfer that information to this exact paired
meeting inequality while retaining phase and room credit. Adding
independent worst-case early/middle/late allowances is not part of(3).

# A single scalar reset would remove the late phase allowance

24 October 2026. New reduction and a conjectured root-map inequality.
The reduction is submitted for independent review. The numerical inequality
below is NOT proved, and no improved global capture bound is claimed.

## The exact scalar question

Write G(x)=k+x-rho(x), F(x)=k+x-ceil(sqrt(x)), and use the all-budget
late cutoff R from `physical-late-all-budgets.md`. Set A=R^2+k.
All quantities here are gate thresholds, so the zero-move seed is k.

The ordinary two physical gate thresholds satisfy

    P_0=(k,k),
    P_(t+1)=(G(P_t[1]),F(P_t[0])).

Define S_0=k, S_(t+1)=G(S_t), and the hybrid thresholds

    C_0=(k,k),
    C_(t+1)[0]=max(min(A,S_(t+1)),G(C_t[1])),
    C_(t+1)[1]=max(min(A,S_(t+1)),F(C_t[0])).        (1)

This hybrid permits ordinary alternating physical moves above A, and
the faster scalar own-color move at every step below A. It may also keep
using physical moves below A, which are never better. Equation(1) is its
exact inverse threshold recurrence: a starting residual at most A may
use the scalar-only clock, while a larger starting residual must make
the ordinary phase-labelled physical move first.

The desired inequality is

    min(P_(t+1)) >= min((k-6)^2,max(C_t))            (2)

whenever the right side exceeds k. It says that EITHER ordinary physical
initial phase finishes no more than one move after the FASTER hybrid
phase, throughout the ceiling allowed by b<=k-1 and Y<=(b-5)^2.

This is appreciably weaker than allowing scalar phase resets throughout
the whole trajectory. Once S_t has crossed A, the injection min(A,S_t)
is constant; after the two hybrid coordinates exceed A, (1) is just the
ordinary alternating physical operator. There is only one fast-region
reset, not a reset at every root boundary.

## Conditional consequence for physical histories

If(2) holds, the arbitrary-ceiling late theorem improves from two days
to ONE, in either incoming phase, for every k>=33.

Choose the first actual slow good-event phase, and start a physical
reference at Y in that phase. There is no initial alignment cost for
this existentially chosen reference. Follow the accepted slow comparison,
paying all later phase changes by backward rewinds. The maintained
reference remains one single alternating physical trajectory; if N
rewinds occur, its index is at most the elapsed actual time minus N.

At the final entry into the fast region, the reference residual is no
larger than the actual residual and is at most A. The remaining actual
history is bounded below by the all-G scalar clock. The hybrid may now
use that clock, so its best initial phase reaches the gate within the
actual interval length. If the reference entered the fast region earlier,
it may continue its ordinary physical moves until this comparison time;
those remain allowed hybrid moves. All arbitrary-Y and fast re-entry
resets are paid by the durations omitted, as in the accepted late proof.

Thus the actual history dominates a hybrid history from Y of at most
the same length. Applying(2) gives the required one extra physical move
in either initial phase. This argument retains the room advantage of
the initial phase choice rather than separately charging an initial
phase day and a terminal fast day.

## Evidence and failed shortcuts

Exact backward iteration checks the inequality for every possible target
in a budget, without a board-width sample. Targeted runs at k=1001,2001,
10001 reached the maximal target without a violation; their smallest
positive slow-region room margins were respectively3,3,5. Forward
dynamic programming independently checked all targets for k=33,75,100,
201,501,1001 with maximal clock difference one. These are diagnostics,
not a uniform proof or a complete finite parameter base.

The accepted fast lemma only proves both physical thresholds dominate
the scalar clock through A. Propagating coordinatewise domination after
that point proves the SAME-phase comparison, but does not prove the
minimum-versus-maximum comparison in(2). The latter is precisely the
remaining phase issue. Nor can one replace it with a one-room argument:
the two physical phase thresholds can differ by more than one room.

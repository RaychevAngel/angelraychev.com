# Independent review of the early credit-or-feature interface

24 October 2026 UTC. Root review of `lower-early-credit-or-feature.md`.
Accepted as an ordinary physical lemma; not a Lean theorem or a proof of
the uniform nine-day claim.

I checked the argument against the source punctured-quadrant theorem in
`paper/sections/quadrant-boundary-profiles.tex`, whose capacity is
max{s(s-1)/2,s(s-h)}. At dominant surplus a>=20 its h=2 and h=3 branches
are a(a-2) and a(a-3). Adding the nondominant capacity m^2 gives the
stated bounds by the exact difference m(2a-h)>=0. This does not require
the dominant origin or its two neighbors to be occupied.

The feature identities are exact complements: a support's lost current
corners are occupied hole corners, and its lost eroded opposite corners
are opposite corners touched by the hole neighborhood. In the two-cohort
positive-part merger this gives the two displayed identities directly.

Both integer improvements are valid. If q<=sigma(sigma-2), then
q+1<=(sigma-1)^2. If q<=sigma(sigma-3), then
q+1<=(sigma-1)(sigma-2). In each case the correctly phased physical
prefix of q+1 rooms needs at most q+sigma input capacity. The actual
transition supplies that capacity within its existing budget. Thus the
extra room is a real prefix advantage, not an extra inspection.

The terminal tracked-step guard also holds: H and L are squares, H>L
implies H>=(R+1)^2, while G(L)<(R+1)^2 follows from k<3R+2. Hence the
terminal step cannot be the freely initialized fast entry. A bad
terminal step already supplies at least three rooms of lead.

The phase conversion is essential. Complementation changes the anchor
to its antipode and changes relative phase by (w+n-2) mod2. In particular
own-hole phase maps to source-prefix phase1 when exactly one side is odd.

One interface caution remains: the physical conclusion is c<=1 OR e<=1,
in the respective carried phase. To use a necessary frontier safely,
take the maximum over the corresponding feature face. Replacing that
face maximum by its top corner B(1,2) or B(2,1) needs the frontier's
feature monotonicity proved separately. There are only nine features,
so retaining the face maximum has constant cost and no coverage loss.

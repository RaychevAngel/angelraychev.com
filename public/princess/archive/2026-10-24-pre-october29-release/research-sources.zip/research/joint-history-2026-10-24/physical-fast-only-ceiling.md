# A larger ceiling for the fast-only late branch

24 October2026 UTC. Direct corollary for independent review.

Let k>=33, R=floor(3k/5), F_cut=R^2+k. Suppose an even-area rectangle
has the accepted genuine-quadrant prefix profiles through a ceiling Y,
where

    k<Y<=min(F_cut,b(b-1)).

For any actual two-cohort history starting at m_s>=Y and first reaching
m_g<=k, either physical prefix phase starting at Y reaches the gate
within g-s+1 transitions.

Take the last crossing into residual<=Y, or use s if m_s=Y and there
is no later excursion above Y. After this time the actual sources stay
below Y. A crossing from above Y has survivor q bounded by its target
<=Y<b^2, so the accepted scalar bound and interlacing place one physical
step from Y below that crossing target. This step is needed only when
at least one actual step was omitted; the omitted duration pays it.

The remaining interval is entirely fast. `physical-fast-one.md` gives
one additional comparison move in either phase. All used target prefixes
fit by the stated ceiling. Thus the total extra cost is one. A reference
already below Y only improves the conclusion by monotonicity.

This branch does not require the smaller slow-history ceiling (b-5)^2:
no canonical component, dominant-corner, or paid-rewind argument is used.
It is useful when a critical exit lies above that smaller ceiling but
already below F_cut. The profile-fit hypothesis remains explicit.

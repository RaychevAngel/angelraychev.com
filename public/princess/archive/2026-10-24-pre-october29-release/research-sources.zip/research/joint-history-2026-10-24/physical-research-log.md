# Physical comparison lane: joint-history research log

24 October 2026. This directory is new research; the accepted previous
25-day bound and its sources have not been altered.

## Proved and independently checked

1. One-day fast late comparison for R=floor(3k/5): an integral estimate
   for k>=75 and a complete arithmetic base for33..74. This concerns all
   targets up to R^2+k, not selected board sizes.
2. Late allowance two from ANY ceiling Y<=(b-5)^2, in either incoming
   phase. The allowance is one with an aligned first slow event or the
   explicitly sufficient incoming local room credit. All later changes
   are paid by their intervening bad transitions. The finite arithmetic
   extension now covers every k>=33; lower independently reproduced it.
3. Independently accepted lower's all-budget early allowance one, the
   exact saved-time/rewind bookkeeping, and its endpoint feature-or-room-
   credit dichotomy. The latter uses the correct diagonal-antipode phase
   conversion. It does not provide an arbitrary free final phase.
4. Independently checked the comparison lane's isolated low nine-feature
   symbolic projection on all188 affine cells. This preserves phase and
   erosion. It is not a finite-board critical-passage or clock theorem.

## Failed shortcuts and why they fail

* An arbitrary critical minimum-phase two-day comparison is false even
  for BAND9. The saved independent C6 witness is w2001,n2002,k1001,
  Y988038,M1014964: model16545, physical phases16548/16547.
* Restricting only the early source face does not fix that failure.
  Lowering the same target to1014963 makes both faces hit16545 while the
  physical times remain16548/16547. Hence the correctly matched first
  phase still has delay three. The room/feature endpoint alternatives
  must be joined to more than an independent scalar target seed.
* One room of early credit cannot simply be declared a free late phase
  flip. Two backward physical phase capacities can differ by many rooms;
  k783 at step327 gives162823 and162789.
* A simple permanent late phase label based on source corner features
  fails on a genuine neighborhood source. Lower's64-square punctured-
  triangle example goes from feature00 to01 while the carried opposite
  prefix ties in size and reaches feature10. I independently checked
  its exact diagonal counts and neighborhood construction.

## Current promising reduction, still conjectural numerically

`physical-hybrid-late-reduction.md` removes the need to classify the late
endpoint features if a precise root-map inequality can be proved. The
hybrid allows ordinary alternating physical moves above the fast cutoff
and free scalar choice only below it. Its backward recurrence has one
eventual reset, after which it is the ordinary physical recurrence.

The accepted history argument compares every actual late history to SOME
phase of this hybrid within the actual elapsed time. Thus a one-day
minimum-physical versus maximum-hybrid clock bound would prove late1 in
either incoming phase. Complete-target diagnostics through large budgets
have found no failure, sometimes with only one room to spare. This is
evidence for a sharp lemma, not a proof. Same-phase domination is easy;
cross-phase domination remains unresolved.

The late cutoff may be lowered toward alpha*k with alpha>1/2 without
changing good slack four or the six-root main cut. Its matching credit
has leading condition2*alpha^2>=1-alpha. This gives more spare initial
room credit for a conservative phase comparison, but no new theorem has
been claimed from that observation. The lower lane is independently
attacking the root-map inequality while the comparison lane retains the
actual endpoint features in the critical passage.

## Evidence boundary

All new claims here are ordinary proofs, exact arithmetic certificates,
or explicitly labelled conjectures/diagnostics. None is a new Lean proof,
website publication, manuscript update, or a complete nine-day theorem.

## Joint-clock consolidation and the two-front replacement

The necessary early and late hybrid clocks are now proved directly from
actual histories. Their capped scalar injection retains the fast-region
advantage instead of replacing it by a worst-case day allowance. Their
shifted capacities differ by at most one room in one alternating
coordinate; this is a proved uniform conjugacy, not a guessed resemblance.

`physical-joint-clock-review.md` independently establishes the combined
physical lower2*g_joint+1. It retains the actual early crossingQ and late
sourceY, uses the accepted necessary BAND9 middle graph, handles the
high-budget fast-only interface, and keeps all older bounds by max/min.
The exact endpoint minimum has at most four representatives: the largest
endpoints of each of two possible constant-clock blocks on either side.
This is genuine evaluator compression, not a sample of endpoints.

The stronger late cross-phase conjecture is no longer needed by the
preferred uniform-nine-day route. The exact physical adjunction gives

    P<=t+s+1 iff max_p(A_t[p xor chi]+V_s[p])>=h.

Same-phase boundary repair is already available in one day. Therefore
it suffices to prove a phase-compatible middle meeting inequality for
the actual paired hybrid capacities; see `physical-two-front-review.md`.
The review accepts the identity and conditional reduction, while leaving
that middle inequality explicitly open. Independent exact-prefix checks
validate5,445 meeting cuts across all parity types.

A relaxed common-orbit counterexample found by the root lane uses a
six-room phase spread at local drift seven. Actual hybrid seeds from the
zero start have much smaller spread in the inspected diagnostics. A
possible next invariant relates squared phase spread to remaining drift,
but no such bound has been proved and a plain one-step inequality is not
closed. Any successful version must retain square/pronic wall position
or trajectory information, rather than impose an arbitrary seed bound.

The proposed bounded-final-window spread repair has now been explicitly
refuted for generic incoming states. The exact k1001 ten-bin witness in
`physical-root-window-obstruction.md` retains span7 at final drift7,
despite starting with span15 at drift17. This rules out a local-window
contraction proof based only on incoming span<=drift. It leaves the
actual fast-reset history and the unused slack of the one-day physical
fronts as necessary information to retain in the preferred joint route.

A useful replacement for the failed contraction is now proved and
independently accepted: the ACTUAL late hybrid boundary pair has span
at most d+7, d=k-b (and at mostd+6 ifk<=2b-14). This follows from time
interlacing and a pronic test point, not from a conjectured decay law.
See `physical-boundary-span.md`. Lower is using the saved room to retain
a proposed uniform middle comparison for all budget excessd>=26; its
full low/central/high interface proof is still under review.

## Final accepted family improvement at this checkpoint

The full middle comparison and its strongest assembled refinement have
now passed independent review. For b>=32 andb+1<=k<3b, putd=k-b.
The uniform nine-day bound holds whenever

    w even andd>=18, or w odd andd>=20.

This covers arbitrary width and length, not a list of width fixtures.
The proof spends two extra physical middle updates, preserves actual
boundary-pair information, and shares the terminal-alignment cost with
unused low/high clamps. Exact paired progress, the impossible odd central
exceptional edge, and its square-endpoint accounting give the stated
thresholds. See `physical-large-excess-review.md/.json` and the frozen
`lower-large-excess-parity-refinement.md`.

The remaining near-minimum excess values are1..17 even and1..19 odd,
with width and length still unbounded. They retain the old uniform
bounds and the new exact joint evaluator; no universal nine-day theorem
is claimed for them. The comparison lane's exact common-tied-origin
criterion also passed review, but it is an admissibility theorem, not
the missing small-excess comparison.

# Broad exploration of routes to the full rectangle goal

18 September 2026. Exploration 10:06–10:26 UTC. Requested scope: 20–30 minutes of
exploration, small discriminating checks, literature, and assessment.
No new proof campaign, accepted classification, manuscript restructuring,
website release, or Lean coverage is claimed. This folder is the research
log for this pass; main artifacts remain unchanged.

## What actually needs closing

The fixed target remains every positive a,b and constant budget k, from
full uncertainty: a fixed-size standard-operation expression for T_k(a,b)
(including infinity), directly specified optimal inspections, and proofs.
No width-dependent preprocessing or variable-length recurrence is itself
the numerical answer. See ../../CLASSIFICATION_SCOPE.md.

The current accepted range ledger is ../../RECTANGLE_GAPS.md. Three
different issues survive:

1. **Even-area physical compatibility.** Necessary one-cohort size/boundary
   transitions need not compose into a physical history. Low budgets do
   not have a uniform one-day gap: T_13(24,24) remains 206 versus 207,
   and the current 24-row odd-length formulas leave two days.
2. **Odd-area shared-budget compatibility.** Exact joint evaluation is
   known, but the remaining short-board decision between the two candidate
   horizons has not been replaced uniformly by a direct criterion.
3. **Arithmetic output.** Even where optimal strategies and bounds match,
   some exact answers retain a parameter-length clock. In particular for
   r>=8, T_(r+1)(2r+1,2r+1)=4L_r+12r-2. An expression for the whole
   game cannot simply cancel away this clock.

Full physical-game Lean verification remains separate. Existing partial
formal coverage is not the latest general rectangle theorem.

## What the previous attempts rule out

- A stationary additive score misses actual deadlines; the latest
  day-dependent quota prices do certify examples it cannot.
- Total expenditure alone loses daily quotas. Projecting a physical
  history to a smooth pyramid can remove more than k projected cells in
  one day even when the actual inspection used at most k.
- Independently optimizing different intervals loses the requirement that
  all those intervals belong to the same history.
- A single interval of positive inspections is not a valid general normal
  form, even at a previously proposed low-budget threshold.
- Generalized-polymatroid exchange fails for successful quota words.
  A theorem about two special rectangle languages would have to be proved;
  generic polymatroid intersection cannot be imported.
- Static paired counts and matching ranks permit incompatible successive
  representatives. An edge-by-edge legal relaxation need not give a legal
  whole path.
- An optimal witness can change its sweep axis. A theorem requiring one
  fixed anchor/orientation is too strong.
- Counting the missing cells inside a pyramid is not an exact state:
  control.md gives two 4-by-4 states with identical closure and deficit
  but different remaining solo times. Their holes even heal after the same
  number of free moves. Hole position matters.
- The root-band clock retains an accumulated carry history. Smooth leading
  asymptotics and an endpoint residue do not recover it exactly.

These are restrictions on proposed methods, not impossibility proofs for
the research goal.

## Lead A: arithmetic representation, rather than another clock identity

This is the most consequential new lead. Classical work of Mazzanti and
Marchenkov shows that all elementary recursive functions are fixed finite
compositions of permitted arithmetic operations. The rectangle value and
a canonical optimal inspection word have elementary bounded algorithms,
so this supplies an existence theorem for expressions of the literal
required kind. See arithmetic-representation-assessment.md for the
finite-state argument and precise qualifications.

The construction encodes information in enormous integers. The operation
count is fixed; bit complexity is enormous. Our ratified scope explicitly
distinguishes those costs. We should not silently exclude this approach,
and we should not call an unexpanded interpreter or a theorem asserting
existence the requested expression.

**A decisive, contained next test:** extract a complete fixed arithmetic
expression for L_r itself, from its already-proved clamped paired-clock
recurrence and polynomial bound. This targets a real infinite numerical
gap. It also tests whether the representation machinery can produce an
auditable artifact of a reasonable fixed size. It should include a precise
standard-operation count, not merely a new function name.

**Full-closure route:** instantiate a bounded exact finite-state evaluator
and an optimal-word selector, eliminate their loops, and supply the actual
value and inspection expressions with generic correctness/minimality
proofs. This is a different kind of explanation from a geometric formula.
It potentially satisfies the literal criterion across all parameters,
without settling a simple geometric classification of optimal histories.

**Confidence:** high in the existence implication, independently checked
by two lanes; unsettled in the practical size and verification effort of
the extracted expression. The constructive June 2026 preprint has local
formula errors, so it cannot be treated as trusted off-the-shelf machinery.
The older published basis theorem does not depend on that preprint.

## Lead B: a critical-deadline theorem for capped temporal prices

For a proposed deadline D, let Q_c(D) be the set of full successful quota
words for initial color c; each coordinate is individually at most k.
For nonnegative day prices lambda define

    W_c(lambda)=min_(q in Q_c(D)) sum_t lambda_t q_t.

A strategy using both colors requires

    W_0(lambda)+W_1(lambda) <= k sum_t lambda_t.

The previous pass proves this inequality and finds useful sharp certificates.
The missing theorem is not another optimized list of prices. It is that,
at the relevant false deadline, every full-board obstruction has a
certificate from a uniformly describable family, or from this dual at all.

**The key risk:** linear prices separate convex hulls. They might fail to
separate two integer strategy languages that have compatible fractional
averages but no compatible actual pair. Proving generalized exchange for
every partial state is unnecessary and already false in one proposed form.
The right weaker target is exactness at the full-board critical deadline.

**First decisive test:** find a small board where capped constant-price
demands fit but full capture is impossible. Solve the physical fractional
mixture problem, not merely the size relaxation. A verified feasible
mixture would rule out every additive day-price proof for that instance
and demand a genuinely joint/history interaction term. An exact separating
certificate identifies the mathematical statement worth proving. A tiny
3-by-4 smoke test was done; constant prices already settle it, so it does
not establish the required integrality property. A more useful tiny
fixture was then found: on 3-by-5, budget 4, at the false deadline 5,
the capped unweighted demands are 10+10=20, equal to capacity. Prices
(1,2,3,2,1) instead give demands 20+18=38 against capacity 36, excluding
that deadline. The accepted optimum is 6. This verifies the mechanism on
a small nontrivial example; it is not new classification coverage or a
proof that all false deadlines can be separated.

**Why promising:** this retains exactly the daily shared resource and
whole-history dependence absent from the old potentials. Reverse symmetry
already reduces the candidate prices. Equality could characterize the
resource schedule of an optimal strategy.

**What it does not do alone:** on even boards a geometric transfer is
still needed; evaluating the resulting clock remains an arithmetic task.

## Lead C: rotation-independent boundary topology and temporal charging

Represent a same-color room as a unit square after rotating coordinates
by 45 degrees. Its possible next rooms are the square's four vertices.
For the resulting finite square complex K(A), let p(A) be its exposed-edge
perimeter, chi(A) its Euler characteristic, and o(A) the number of its
vertices that correspond to rooms outside the physical rectangle. Then

    |N(A)|-|A| = p(A)/2 + chi(A) - o(A).

This identity follows from Euler's formula and incidence counting; it
handles holes and components meeting at vertices. Its value here is that
it does not select a sweep axis. The identity itself is not a sharp
capture-time bound. See geometry.md for the derivation and limitations.

**The proof target:** charge favorable boundary contact and hole creation
over a complete history to inspections that create or maintain them.
Keep the per-day cap while charging; a pooled total is insufficient.
Apply the charge to the forward and reversed histories up to their middle
meeting. This could repair exactly the missing interaction term in the
current two-sided clock argument.

The old closure deficit remains useful as a comparison, but a scalar
number of missing cells cannot be assumed to summarize everything. The
topological representation suggests tracking events and persistence of
holes/boundary contacts rather than continually appending static flags.
Any claimed telescope must be tested on actual changes of axis and on
histories that open and later heal holes.

**Why full-closure relevant:** a sharp temporal charge matched by equality
constructions could handle odd and even boards through the same physical
objects. Arithmetic extraction would still be supplied separately.

**Risk:** this may only re-express the cardinality telescope unless a
new inequality ties these events to legal inspections. That inequality,
not the Euler identity, is the genuinely missing theorem.

## Supporting and lower-priority routes

### Ordered optimal-control kernels

For one cohort, the inverse-neighborhood transition cost has the form
max(0,s-I_p(y)) with the cap retained. It has a Monge ordering property.
This offers a concrete route toward simplifying the weighted one-cohort
problems in Lead B. However, the naive cross-color exchange inequality
fails, and grouping two days does not repair it. A parity/complement
transformation or an explicit correction is required. Treat this as a
possible tool for the critical-deadline theorem, not a solved integrality
argument. Details and small counterexamples are in control.md.

### Frontier histories as tableaux or exclusion-process events

Smooth boundary flips resemble particle jumps, and literature relates
exclusion-process histories to tableaux. A rewrite preserving the number
of events with each day label could preserve the daily budget, unlike
our failed set union/intersection compression. But ordinary fixed
precedence relations cannot encode this game: with enough budget the
entire board is captured on day one, regardless of geometric chain length.
Movement and inspection must be separate event types, and changes of axis
must be allowed. This is a potentially useful normal-form language with
an unproved physical bridge, ranked below the explicit temporal/topology
routes. See geometry.md for primary sources.

### Matrix powers, tropical periodicity, and Presburger methods

The raw game is a product of movement matrices and inspection masks.
The masks do not commute with movement or preserve tensor separation;
the dimension increases with board size. Diagonalizing a fixed matrix
does not remove a changing control word.

The arithmetic lane gives a route-specific obstruction: the ceiling
orbit x_(t+1)=ceil((b+1)x_t/b), for b>=2 and positive x_0, has no eventual
constant-coefficient rational linear recurrence. Thus ordinary fixed-size
rational matrix powering cannot exactly represent that entire orbit.
This does not exclude floor/exponential arithmetic terms or a special
formula for the diagonal hitting-time problem.

Max-plus eventual periodicity can simplify fixed-width evaluators but
does not bound their width-dependent state space or transient uniformly.
Parametric Presburger counting yields eventual quasipolynomials under
its standard fixed-dimensional hypotheses, whereas L_r has r log r
growth. That is an obstruction to this particular encoding, not to the
allowed power/floor formulas. Neither is presently a standalone full-box
route.

### Standard monotone searching and planar cuts

Standard monotone hunter strategies can require more budget than the
actual game; results on monotone hunting cannot simply normalize the
low-budget strategies we need. A time-expanded two-dimensional rectangle
is three-dimensional, so ordinary planar min-cut duality is not directly
applicable either. Phase-aware spacetime surfaces remain a possible
language for Lead C, but an exact new theorem would be needed.

## Recommended next allocation, subject to Angel's next instruction

First validate and extract the whole-clock arithmetic term, with all
abbreviations expandable. In parallel, test critical-deadline fractional
compatibility and develop the rotation-independent temporal charge only
far enough to discover whether it supplies the missing interaction.

Do not resume a catalogue of individual widths, optimize another fixed
inspection word already known to be restrictive, or seek a stronger
all-partial-state theorem merely because it is easier to state. The
arithmetic representation route changes the attainability picture under
the literal goal; geometric work should be pursued for the structural
classification and usable strategies it can actually deliver.

No new accepted parameter range is announced by this exploration.

## Additional primary literature screened

- Mazzanti (2002), composition-only bases: https://doi.org/10.1002/1521-3870(200201)48:1%3C93::AID-MALQ93%3E3.0.CO;2-8
- Marchenkov (2006/2007), bounded-sum elimination: https://www.mathnet.ru/eng/da10
- Istrate, Prunescu, Shunia (2026), bounded recurrence/compiler architecture,
  with displayed errors flagged in arithmetic.md: https://arxiv.org/abs/2606.09336
- Prunescu and Sauras-Altuzarra (2024), an explicit arithmetic term for factorial:
  https://repositum.tuwien.at/handle/20.500.12708/193554
- Bogart, Goodrick, Woods (2017), parametric Presburger structure:
  https://arxiv.org/abs/1608.08520
- Hartmann and Arguelles (1999), matrix-dependent max-plus transients:
  https://doi.org/10.1287/moor.24.2.414
- *Recontamination Helps a Lot to Hunt a Rabbit* (MFCS 2023), monotone
  hunting/pathwidth relationship, not an optimal-time rectangle theorem:
  https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.MFCS.2023.42
- Dal Zovo (2026), exclusion-process histories and tableaux:
  https://arxiv.org/abs/2605.29520
- *Cellular Automata and Bootstrap Percolation* (2021/2022), a related
  language of local update rules, not the same controlled recovery problem:
  https://arxiv.org/abs/2110.00656

No result from these papers is treated as directly proving the missing
rectangle compatibility or optimality statement without the stated bridge.

# Structural geometry routes: bounded exploration, 18 September 2026

This is an exploration note, not a new classification. It preserves the current goal: every rectangle, constant daily budget, full initial uncertainty, an exact value in a fixed number of standard numerical operations, and directly specified optimal inspections. No manuscript, website, formal source, or established claim was changed in this pass.

The numerical bottleneck remains independent. On the remaining numerical
family b>=8, the already established reduction

\[
T_{b+1}(2b+1,2b+1)=4L_b+12b-2
\]

means that a full bounded-operation answer must in particular evaluate the unresolved scalar clock \(L_b\). A geometric calibration cannot make that requirement disappear through cancellation. The routes below concern the structural half of the problem unless explicitly stated otherwise.

## The obstacle that a useful new representation must preserve

For an odd deadline the exact midpoint question is whether two independently attainable half-histories have intersection of size at most \(k\). For an even deadline it is whether their post-inspection survivors are anticomplete. Each history retains its own quota on every day. Cardinalities, ordinary matching rank, balanced vertex-cover rank, and their reflected versions do not retain enough information about attainable histories.

The decisive small diagnostic is the recorded \(3\times4,k=2\) collision: separately valid one-step transitions can be concatenated after resetting shapes with identical count/rank signatures, yielding a fictitious ten-day solution when the true value is sixteen. The \(6\times6,k=5\) static profile relaxation similarly predicts thirteen instead of fourteen. Thus another sharp inequality for one isolated set will not suffice. It must either control transport between successive near-extremizers, or retain a whole-history object on which those incompatible resets are impossible.

Several large diagnostic witnesses rule out convenient assumptions. The \(25\times26,k=13\) 188-step solo witness is not nested in either of the previously tested senses. It is smooth in at least one of the two axes at each recorded step, but not in one fixed axis. Reading its existing transpose-audit file gives 97 original-axis-only steps, 78 transposed-axis-only steps, and 13 smooth in both. After deleting the ambiguous steps, the forced axis labels have nineteen runs: this particular witness requires at least eighteen switches. That does not exclude a different optimal witness with fewer switches, but it does exclude treating a single switch as an observed normal form. The sixteen-row shape-changing example must also be retained.

There is a literature obstruction to a stronger monotonicity claim. Dissaux, Fioravantes, Gahlawat and Nisse prove that the standard monotone hunting number lies between pathwidth and pathwidth plus one, in the same compulsory-motion game. Thus ordinary monotone hunting cannot explain the low hunter threshold of general grids. This does not rule out a cohort-specific, moving-coordinate, or event-based description. [MFCS 2023 paper](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.MFCS.2023.42).

## 1. Rotation-invariant contour accounting and a joint temporal calibration

This is the most directly physical new geometric route from this exploration. It removes the need to choose a sweep axis while exposing exactly which temporal information the area calculation discards.

### An exact representation

Take a set \(A\) of one checkerboard color. Map a cell \((x,y)\) to the unit square centered at

\[
u=(x+y)/2,\qquad v=(x-y)/2.
\]

The four vertices of this square correspond exactly to the four potential opposite-color neighbors of the original cell. Let \(K(A)\) be the finite square cell complex obtained by taking the union of these squares, including their edges and vertices. Vertex contacts between squares are allowed. Write:

- \(p(A)\) for the number of edges incident with exactly one square;
- \(\chi(A)=V-E+F\) for the Euler characteristic of this complex;
- \(o(A)\) for the number of its vertices corresponding to neighbors outside the original board.

Then, without a convexity, connectivity, or smoothness assumption,

\[
|N(A)|-|A|=\frac{p(A)}2+\chi(A)-o(A). \tag{1}
\]

Indeed, \(F=|A|\), \(4F=2E_{\rm interior}+p\), and hence \(E=2F+p/2\). Euler's identity gives \(V-F=p/2+\chi\). Exactly \(o\) of the vertices counted by \(V\) lie outside the physical board. This proof works equally for holes and vertex-touching components. As a tiny independent arithmetic check, all 640 single-color supports of the \(3\times4\) and \(4\times4\) boards satisfy (1). The parent independently checked the derivation.

For a post-inspection transition \(A_{t+1}=N(A_t)\setminus S_t\), with only effective inspections counted,

\[
i_t=|A_t|-|A_{t+1}|+p(A_t)/2+\chi(A_t)-o(A_t). \tag{2}
\]

This is an exact, rotation-invariant version of expansion accounting. Summing (2) alone is **not** a new lower bound: it is the mass identity in different coordinates. Replacing its right-hand geometric terms by their independent minima recreates the old failure.

### What extra quantity could make it useful?

The promising object is the **history of contours and their contacts with the board**, rather than the three numbers in (1).

An interior bounded complementary component with perimeter \(\ell\) contributes \(\ell/2-1\ge1\) through its inner boundary and Euler term. Thus internal holes have an explicit expansion cost. But a corner notch need not create a bounded hole, so hole counts alone cannot handle the sharp mixed endpoints. Contacts with each of the four board sides must be part of the bookkeeping. Corner notches should be treated as open complementary components with recorded contact intervals.

There is also an exact local inspection relation. Removing one face deletes some \(d\) vertices of \(K(A)\), of which \(d_{\rm in}\) are physical board vertices. Its change in the right side of (1) is \(1-d_{\rm in}\). A complicated perimeter/Euler change therefore cannot be assigned an arbitrary favorable cost: it arises from actual lost neighbor vertices. For a batch of shots, a neighbor vertex disappears only when every incident surviving face has been removed. This is the causal condition that a contour certificate must retain.

A useful theorem would trace those contour births, merges, holes, and board contacts through time and prove a sharp lower charge for every pair of full-start histories that reaches the midpoint terminal condition. In particular, each corner contact must retain its location and ancestry: resetting one near-minimal shape to an unrelated one should incur a real charge. The theorem can permit arbitrarily many repetitions of a fixed list of local events; it need not falsely promise an absolute bound on the number of switches.

The two histories have a concrete common geometric terminal condition. For sets of opposite physical colors, their shifted square complexes have overlapping interiors exactly when some original cells are adjacent. Consequently the two cross-color pairs at an even midpoint must have disjoint interiors. This suggests pairing their contact traces from opposite time directions, so that endpoint terms cancel or leave a forced connecting interface. The balanced terminal stability lemma already limits certain sharp endpoints to corner islands. It supplies terminal data for such a trace argument; it does not itself supply the temporal charge.

### Relation to the existing closure identity

The accepted identity \(P(NA)=N(PA)\) and

\[
i_t+\beta_t=J_t+\Delta D_t+\tau_t+\sigma_t
\]

give a second coordinate system for the same task: actual quota versus projected removals, closure deficit, boundary credits, and roughness. The new contour representation may allow the axis-dependent top/bottom credits to be combined into boundary-contact events. A valid combination must pay for changing orientation and must retain the actual daily inequalities \(i_t\le k\). It cannot simply feed the generally larger \(J_t\) into the capped canonical evaluator.

### Decisive gate

First seek one **two-sided temporal inequality** that excludes the \(3\times4\) reset chain while accepting genuine shape-changing histories. It should use a contour/contact trace or a transport charge, rather than a new scalar assigned independently to every state. Then test whether its equality conditions allow both the solo-degenerate and mixed endpoints of the \(24\times24,k=13\) diagnostic. If its entire proof collapses to (2) plus independent per-time isoperimetry, it has not advanced beyond the failed relaxation.

**Assessment:** highest priority among the geometric routes here. It starts from exact physical identities and accommodates holes, recontamination, boundary events, and changes of axis. The missing temporal rigidity is substantial. A successful uniform calibration would settle structural optimality, but the scalar clocks would still require numerical evaluation.

## 2. Whole-history growth diagrams with day-label preservation

For a smooth height front, adjacent height differences are \(\pm1\). Removing a permissible corner changes a slope pair \((+1,-1)\) to \((-1,+1)\). This is the usual exclusion-process particle hop. Boundary exits and entries are additional events. The useful insight is to encode the **entire event history**, not just its current height vector.

There are genuine primary-literature bridges between exclusion histories, tableaux, and growth diagrams. Elizalde's 2026 paper gives bijections involving cylindric tableaux, walks, and exclusion-process histories, with a cylindric growth-diagram description. Dal Zovo's 2026 preprint treats open-boundary TASEP and shifted tableaux; it also studies tableau-like objects with repeated cells. These are sources for representations and local relations, not established theorems about our game. [Elizalde](https://www.combinatorics.org/ojs/index.php/eljc/article/view/v33i3p7), [Dal Zovo](https://arxiv.org/html/2605.29520v1).

The attraction of tableau rectification is unusually specific here: local rewrites can preserve the multiset of labels. If labels encode actual inspection days, preserving that content preserves every day's inspection count. This is exactly what ordinary union/intersection uncrossing failed to do: it preserved combined ammunition but turned two quota-one histories into costs zero and two on particular days.

The required new theorem would identify a class of space-time growth diagrams containing an optimal full-start physical history for every rectangle and budget. Its local rewrite rules would preserve both legal mandatory movement and the content of each day label. Axis changes would be alternative descriptions of the same diagram or controlled local events, rather than silent resets of shape. Repeated events must be permitted, since ordinary once-per-cell nesting is already false.

There is a sharp warning against an oversimplified translation. A fixed **strict** precedence poset on inspection jobs cannot represent the full game: with \(k\ge ab\) the whole board is captured on day one, regardless of the length of a geometric chain. Allowing arbitrary weak same-day labels, on the other hand, makes ordinary order-ideal scheduling collapse to an area calculation. A useful diagram must therefore retain **two sorts of events**, inspections and mandatory propagation, together with their timing. Off-the-shelf scheduling of a fixed poset is not the answer.

Its first gate is an explicit local move on a genuinely physical two- or three-day history that preserves each day's quota, including movement between those days. It must survive the quota-one uncrossing counterexample, the \(3\times4\) reset obstruction, and the repeated-axis witness. If no nontrivial move does this, there is no reason to build a large tableau formalism.

**Assessment:** a credible representation route, but less direct than contour accounting. Its advantage is that it attacks temporal compatibility and quotas simultaneously. Its risk is that the needed physical correspondence may be as hard as the original problem. A successful representation may still give only a recurrence or a growing diagram; bounded numerical evaluation remains separate.

## 3. A dynamic inverse theorem: near equality forces compatible fronts

The alternative to normalizing every winning history is to assume that a history beats the proposed optimum by one day and show that its available geometric slack is too small to permit the necessary transitions.

This requires an inverse theorem **along time**, not merely a stability theorem for one set. A useful statement would say that if a full-start history spends almost the maximum possible budget on effective progress, then its successive supports belong to a controlled family of fronts and every change between incompatible fronts consumes a quantified amount of slack. Different parameter ranges may select different fronts; that is acceptable. What must be uniform is the finite list of transition mechanisms and their charges.

The existing corner-capacity and balanced terminal lemmas are good starting conditions at the middle of the history. One could propagate them backwards in each half until the endpoint constraints meet. This asks only about near-optimal full-board histories, not all partial states and not an unnecessarily strong exact equality between scalar relaxations.

Isoperimetric stability provides a relevant methodological precedent. Barber, Erde, Keevash and Roberts prove that nearly optimal boundaries in lattices force proximity to the appropriate large limiting shapes. Their theorem is asymptotic and concerns infinite lattice Cayley graphs; it does not supply the additive one-cell accuracy, finite-board boundary terms, or consecutive-time compatibility needed here. It motivates an inverse statement but cannot be substituted for one. [Primary paper](https://arxiv.org/html/2007.14457).

A second analogy is the rectangles process in bootstrap percolation, where complicated growth is organized into a restricted collection of growth and merge events. The princess game's exact dual is

\[
C_{t+1}=\{v:N(v)\subseteq C_t\cup S_t\},
\]

where \(C_t\) is the cleared set. This is a controlled, reversible, all-neighbor process; it is **not** ordinary persistent two-neighbor bootstrap percolation. The lesson worth borrowing is an event description, not a threshold or time formula. [Benevides and Przykucki](https://arxiv.org/abs/1310.4457).

The decisive gate is a two- or three-step transport theorem: a change between two individually sharp shapes either is an explicitly allowed front event or incurs positive cumulative excess. A result saying only that each near-extremizer is close to some corner shape will not address the reset counterexamples. Nor is a large-width asymptotic error adequate when the remaining discrepancy is one day.

**Assessment:** probably the cleanest way to convert the contour representation into a proof. It is a substantial new theorem rather than a promise that minor strengthening of a static inequality will suffice. It could give a complete structural classification; finite event types alone do not evaluate all repeated-event clocks in O(1).

## 4. A space-time separator with local budgets

The exact game is a directed space-time graph. Its vertices are \((v,t)\), its edges are legal compulsory moves, and the inspected vertices form a cut separating all starts from all surviving endpoints. The quota says that the cut contains at most \(k\) vertices in each time layer. This is a partition-matroid constraint on a separator.

This viewpoint automatically retains full-start uncertainty, recontamination, and every possible shape change. It is therefore useful as a correctness framework for any proposed contour or event representation. But it is not an immediate planar min-cut problem: a two-dimensional rectangle times time is a three-dimensional space-time complex. Ordinary planar duality does not apply to the full layered graph.

Ordinary weighted cuts also replace hard per-layer budgets by a weighted total. That is precisely the relaxation whose insufficiency we have already encountered. A successful theorem would have to prove an **integer**, quota-preserving canonical separator or an exact min-max certificate for this special rectangular layered graph. A continuous separating hyperplane or compatible mean load profile is not enough.

The matroid-cut literature makes the local-budget interpretation precise and develops nontrivial algorithms. It does not immediately solve this directed space-time instance or give the required uniform expression. In particular, generic results for undirected cuts must not silently be transferred to our directed graph. [Banik et al., ESA 2024](https://arxiv.org/abs/2406.19134).

Generic graph-search machinery is also unlikely to remove the geometry by itself: the 2026 paper *Hunting a rabbit: Complexity, approximability and some characterizations* proves hardness for deadline-constrained hunting on arbitrary graphs. This is not an impossibility result for rectangles; it is a reason to insist on an actual rectangle-specific structure theorem. [Primary publication](https://doi.org/10.1016/j.tcs.2026.115946).

**Assessment:** retain as the exact overarching model and as a source of counterexamples to proposed uncrossing. It ranks below the first three as a stand-alone research attack, unless a quota-preserving rectangular separator theorem becomes concrete. Any claimed laminarization must pass the two-vertex daily-budget counterexample.

## Separate arithmetic observation requested during this pass

The parent raised a possible arithmetic-term representation theorem. Independently of that theorem's exact hypotheses, the finite game evaluator is elementary recursive.

Let \(N=ab\) and \(Q=2^N\). There are at most \(Q\) belief states and at most \(Q\) inspection subsets. On a rectangle with an edge, an optimal winning belief path can be chosen simple, so its length is at most \(Q-1\). We may use the finite sentinel \(Q\) for infinity, enumerate all shorter schedules, and simulate each by finite Boolean adjacency updates. There are at most \(Q^Q=2^{N2^N}\) schedule codes. All bounds are fixed-height towers in the binary input length. Bounded minimization over those codes therefore defines an elementary recursive function. The lexicographically first shortest winning schedule, encoded as a base-\(Q\) integer, is elementary recursive as well. Isolated one-cell and zero-budget conventions should be handled explicitly as fixed cases.

Consequently, if the cited representation theorem truly expresses every elementary recursive function by a **fixed composition** of the permitted arithmetic, quotient/remainder, and power operations, it applies to both the numerical answer and a coded optimal strategy. That is a legitimate logical possibility, not an impossibility or an explicit term already produced here. It requires checking the exact function class and constructing or extracting the term. Its intermediate integers would be enormous. An expanded expression containing only permitted operations is materially different from introducing a new black-box “solve the game” operation, but the distinction between such arithmetization and a geometric classification must be stated openly. No new numerical closure is claimed in this note.

## Recommended sequence of structural gates

1. Use the rotation-invariant contour identity to formulate a genuinely paired **temporal** charge. Retain locations and ancestry of boundary contacts, not just perimeter and Euler characteristic.
2. Try to prove the dynamic inverse/transport theorem needed to make that charge sharp. The smallest reset counterexample is the first gate; the large shape-changing witnesses are mandatory acceptance tests.
3. In parallel, test one physical, day-content-preserving growth-diagram rewrite. Pursue the tableau apparatus only if this concrete gate succeeds.
4. Use the space-time cut as the semantic reference and a source of quota-integrality tests, rather than pretending that ordinary planar duality or an unconstrained min-cut solves the game.

This is a proposal for stronger proof mechanisms, not a new width catalogue. No route above has yet supplied the missing uniform temporal theorem. The useful progress in this exploration is a precise rotation-invariant representation, stronger tests for what a proposed normalization must preserve, and a clearer separation of geometric closure from arithmetic representation.

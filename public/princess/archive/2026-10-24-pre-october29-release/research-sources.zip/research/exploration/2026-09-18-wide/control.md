# Control, duality, and algebraic compression: bounded exploration

18 September 2026, approximately 10:07–10:24 UTC. Exploration only. This note changes no manuscript, website, formal source, or accepted classification. It assesses routes to a uniform result; the small computations below discriminate proposed mechanisms rather than add a catalogue of exact boards.

## What a closing theorem would have to do

There are two logically separate gates.

1. **Structural gate:** prove that the physical lower bound equals the construction, uniformly in both dimensions and the daily cap. On odd rectangles, the compatible-prefix model makes the whole-history quota language exact; on even-area rectangles, geometry must remain in the model. A theorem about separately optimal states is insufficient.
2. **Numerical gate:** reduce the resulting value to the user's absolute fixed-size arithmetic expression, and specify attaining inspections directly. A path algorithm, fixed-width transfer matrix, or finitely parameterized dynamic program alone does not pass this gate.

The current minimum-budget odd-square identity supplied by the root lane is

\[
 T_{b+1}(2b+1,2b+1)=4L_b+12b-2\qquad(b\ge8).
\]

Consequently a numerical formula for the full answer would recover `L_b` by subtraction and division. A whole-game calibration cannot make this particular arithmetic obstacle cancel away. A separate lane is investigating the literal expressive power of the allowed numerical operations; no conclusion from that investigation is assumed here.

The earlier failure shields remain active: the actual quota languages need not be generalized polymatroids; a weighted minimizing history need not use one consecutive positive block; optimizing different intervals independently loses information; unrestricted one-day ammunition destroys the useful dual; and a fixed-axis smooth-front normal form is contradicted by the known 25 by 26 witness.

## Route 1: a critical-deadline separation theorem, not an index heuristic

For a deadline `D`, let `Q_c(D,k)` contain the quota words of complete successful origin-`c` histories, with **each coordinate at most `k`**. For odd rectangles this can be the exact canonical count language. For even rectangles it must be the actual physical language or a geometric relaxation already proved sufficient for the desired lower bound.

The precise target is: at the day immediately below the proposed construction, the upward Minkowski sum

\[
 \operatorname{conv}Q_0+\operatorname{conv}Q_1+\mathbb R^D_{\ge0}
\]

does not contain `k*1`. Equivalently, there exist nonnegative prices `lambda_t` such that

\[
 \min_{q\in Q_0}\lambda\cdot q+
 \min_{q\in Q_1}\lambda\cdot q>k\sum_t\lambda_t.
\]

This is more focused than proving integrality of the entire resource polytope for every initial state and deadline. A strict separator at the critical full-board deadline is enough. The already proved time-reversal argument permits symmetric prices. The next useful strengthening would put the separating prices in a uniformly specified family: for example constant prices, a clipped tent, or a bounded number of tent components. Neither concavity nor a bounded number of knots has been proved. The existing observation that independent interval minima are too weak means the price components must be evaluated on the **same history**.

Why this is currently the best control route: it retains precisely the timing information missing from total ammunition, and it already yields exact certificates on the hard odd benchmarks. It also states its own failure condition sharply. If the convexified pair admits a rational feasible point below the true deadline, **every additive time-price separator fails**, even if each individual history is modeled perfectly. No more search for clever day prices would then help at that instance.

The analogy with restless-bandit control is useful for identifying the relaxation, not for importing an exact policy. Brown and Smith's *Index Policies and Performance Bounds for Dynamic Selection Problems* explicitly obtains decomposed time-price bounds and asymptotic guarantees as the number of items grows; it does not establish exact optimality for our two deterministic cohorts. [Primary manuscript, November 2018](https://optimization-online.org/wp-content/uploads/2017/10/6258.pdf).

**Decisive early test.** At a false critical deadline, solve the two exact one-cohort flow problems linked only by mean daily quota. Require either an independently checked rational mixture or an exact separating certificate. A rational feasible mixture is a counterexample to this entire proof class; an infeasible instance is evidence, not a uniform theorem.

Two tiny discriminator results:

- Exact physical histories on 3 by 4, `k=2,D=15`: the mean-flow LP is infeasible (954 variables, 293 flow-and-budget constraints). Physical exhaustive search gives 16 days. This is only a smoke test: constant-price demands are already `16+16>30`.
- A genuinely nontrivial compact fixture is 3 by 5, `k=4,D=5`, below the accepted exact time 6. Constant capped demands are `10+10=20`, equal to available quota 20. Prices `(1,2,3,2,1)` instead give `20+18=38>36`. These integer costs were recomputed from the exact profile. This was the first nontrivial instance in a short ordered test list, not a claim of global minimality.

For a difficult even-area test, first check whether constant capped physical demands fit. If they already contradict the deadline, optimized prices are unnecessary. If they fit, that board is a meaningful test of temporal separation. The 24-square physical language is too large for this exploration; a small geometric relaxation should be explicitly labeled as such.

**What success closes.** A uniform critical-deadline separator would match lower and upper bounds in the language to which it applies. It would not evaluate `L_b`, and for even rectangles it would not by itself justify discarding geometry.

## Route 2: ordered path kernels through inverse capacities

There is a concrete Monge structure before any conjecture is made. Let

\[
 I_p(y)=\max\{x:g_p(x)\le y\}.
\]

The minimum quota needed to make the next count **at most** `y`, from count `s`, is

\[
 C_p(s,y)=\max(0,s-I_p(y)),
\]

provided this is at most `k`; otherwise set it to infinity. Allowing an upper bound on the next count does not change the minimum successful weighted cost: a physical canonical trajectory stays below the chosen bounds by monotonicity, and the actual trajectory itself is an allowed bound sequence.

For `s<=s'` and `y<=y'`, this matrix is Monge:

\[
 C_p(s,y)+C_p(s',y')\le C_p(s,y')+C_p(s',y).
\]

Indeed it is the hinge function of `s-I_p(y)`, with a convex extended-real cutoff beyond `k`. This was also checked on 6,492 adjacent quadrangles across four small odd rectangles, both phases, and three budgets. Multiplication by a nonnegative price preserves the property. Min-plus composition preserves Monge structure, giving ordered optimal intermediate states for each individual cohort. This is a real foothold in the original problem, unlike assuming discrete convexity of the quota language.

The corresponding algebra is well developed: Tiskin proves closure of Monge matrices under min-plus multiplication and studies compact unit-Monge representations. [Primary paper, *Fast Distance Multiplication of Unit-Monge Matrices*](https://link.springer.com/article/10.1007/s00453-013-9830-z). The recent core-sparse formulation also separates matrix description size from state count. [Gawrychowski, Gorbachev, Kociumaka, 2024](https://arxiv.org/abs/2408.04613).

**The missing theorem is colored, not ordinary, uncrossing.** The two phases have different inverse profiles. The naive cross-color inequality already fails on 3 by 3, `k=2,s=1,y=1`:

\[
 C_0(1,1)+C_1(2,2)=3>2=C_0(1,2)+C_1(2,1).
\]

Here `I_0(1),I_0(2)=(0,1)` and `I_1(1),I_1(2)=(0,0)`. Grouping two days does not simply cure the problem: the analogous inequality for the two-day kernels fails on 5 by 5, `k=3,s=1,y=3`, again `3>2`.

A viable version must use a phase/complement transformation, or explicitly charge the cross-phase defect. The most promising target is an uncrossing operation on **whole pairs of histories** that preserves the individual cap and does not increase combined daily consumption at the critical deadline. If available, it could either prove Route 1's separation directly or reduce the price family to bounded complexity. The ordinary Monge property does not do that automatically.

**Early kill test.** Before proving a large theorem, write the precise transformed four-point inequality and test it on the two counterexamples above plus the known short-board shared-budget failures. If it needs an unbounded defect or silently changes the quota cap, abandon that form. Do not repair it by asserting general M-convexity: the actual language already violates the relevant simultaneous exchange axiom. Murota's definition makes that assumption explicit. [Primary book chapter on M-convex sets](https://epubs.siam.org/doi/10.1137/1.9780898718508.ch4).

**What success closes.** This is a plausible mechanism for a uniform matching-bounds proof and simpler strategy reconstruction. Faster Monge multiplication alone closes neither the structural theorem nor the fixed-operation numerical goal.

## Route 3: treat holes as timed budget liabilities, not a scalar reserve

The new exact projection supplies an augmented-control identity. For a physical state `A`, let `P(A)` be its downward-pyramid closure and `D(A)=|P(A)|-|A|`. Actual removal `i_t` projects to a pyramid removal `J_t` satisfying

\[
 J_t=i_t+D(A_t)-D(B_t),
\]

where `B_t` is the post-inspection survivor. The exact movement charge is

\[
 D(NB_t)-D(B_t)=\beta_t-\tau_t-\sigma_t,
\]

with all three charges nonnegative. Therefore

\[
 i_t+\beta_t=J_t+D(A_{t+1})-D(A_t)+\tau_t+\sigma_t.
\]

This resembles a storage system: a projected front can apparently spend more than the physical cap by consuming previously accumulated deficit. The bottom-boundary credit can replenish that deficit. The prior weighted transfer is useful, but it only bounds weighted expenditure; it does not impose `J_t<=k`.

The natural next object is **a spatial assignment of the outstanding liabilities to holes**, carrying the time window in which each can disappear or become a boundary credit. Then ask for an interval transport/Hall inequality that prevents projected over-quota operations from being moved through time for free. A sufficient proof would either reschedule the charged projected operations within their legal windows without increasing a chosen temporal price, or charge every unsuccessful rescheduling to a positive geometric term large enough to eliminate the false deadline. This is a concrete way to connect the exact boundary bookkeeping to Route 1 without losing its crucial daily cap.

A scalar reserve is definitively insufficient for exact state reduction. On 4 by 4, `k=3`, take the common pyramid

```
P={(0,0),(0,2),(1,1),(1,3),(2,0),(2,2),(3,1)}.
```

Both states below have the same closure `P` and deficit 1:

- `P\{(0,2)}` has exact solo capture time 4.
- `P\{(0,0)}` has exact solo capture time 5.

In both cases the deficit becomes zero after a free movement. These values were obtained by complete single-color state iteration on the 512 parity-tagged supports. Thus even `(P,D,D after movement)` misses the relevant control information: **hole location changes what can be achieved with the next inspections**. A useful liability should retain position relative to the removable front or the pyramid order, not merely count missing cells.

Queueing reflection theory gives a useful conceptual model for boundary regulators but no ready-made solution. The explicit two-sided Skorokhod map itself contains history suprema and infima. [Kruk, Lehoczky, Ramanan, Shreve, 2007](https://arxiv.org/abs/0710.2977). Calling that an explicit map would not meet the user's operation bound; moreover our charges depend on transverse geometry, not an exogenous one-dimensional driving path.

**Closing theorem to aim for.** For any putative full-board strategy one day faster than the construction, apply forward and reverse-complement projections around a midpoint. Bound their joint endpoint deficits and all unrepayable boundary liabilities by a stated expression. Retain the adjusted daily caps throughout. The resulting inequality should contradict the sum of physical day budgets. This would cover arbitrary supports rather than proving a stronger normal form from every partial state.

**Early kill tests.** The two six-cell states above must be distinguished or safely bounded; the singleton example whose closure deficit increases `56->59` must be allowed; the 25 by 26 witness must permit orientation changes. A proposed bound that charges only total deficit, total ammunition, or one fixed orientation fails before any large computation.

**What success closes.** This is the most concrete route for incorporating even-area geometry into the temporal dual. It may unify the geometric and odd-board lower bounds. It still leaves the separate evaluation of the resulting exact clock.

## Route 4: algebraic compression of the ordered kernels, with a stringent entry test

The Monge kernels offer a potential connection between structural proofs and numerical evaluation. For constant or piecewise constant prices, several consecutive stages become min-plus powers or products of a small number of alternating kernels. Unit-Monge matrices have representations via permutation-like density data; more general nonnegative integer Monge matrices can be interpreted through an extended Demazure product. [Erickson, *The Demazure product extended to biwords*, 2024](https://arxiv.org/abs/2407.13165).

The worthwhile target is **not** merely to use this representation for a faster algorithm. It is to show that the particular rectangle kernels belong to a family with a bounded symbolic description that remains bounded under the necessary powers and products, and whose required entry can be extracted by the allowed fixed-size operations. This might reveal a finite number of collective invariants that ordinary state-by-state recurrence hides.

There is a sharp warning even at the first step. For the uncapped hinge kernel, its Monge density is

\[
 C(s,y+1)+C(s+1,y)-C(s,y)-C(s+1,y+1)
 =\mathbf1\{I(y)\le s<I(y+1)\}.
\]

Thus the number of nonzero density entries generally grows with the color-class size. “Sparse” in the algorithmic literature does not mean a constant number here. The hope would have to be a **formula for a patterned core**, not a constant-size explicit list. Products may destroy even that pattern.

**Entry/kill test.** Compute only a few symbolic products at successive root thresholds, identify an actual finite parameter family, and check closure under one more product. If the description requires the entire ceiling orbit, this route has only renamed `L_b`. Require the proposed representation to recover the minimum-budget odd-square specialization before calling it a full numerical route.

General parametric counting theorems do not supply the missing uniform formula automatically. Ordinary Presburger counting gives piecewise quasipolynomials under its own fixed-formula hypotheses; allowing multiplication by multiple parameters is substantially more expressive and does not retain a general quasipolynomial conclusion. [Woods, 2012](https://arxiv.org/abs/1211.0020), [Bogart–Goodrick–Nguyen–Woods, 2018](https://arxiv.org/abs/1802.00974). Our state dimension and history length vary, and the profile contains parameter-dependent root thresholds. Those hypotheses must be addressed before importing a counting theorem.

**Assessment.** This is the most speculative of the four routes. It deserves a short structural recognition test, not a broad transfer-matrix implementation. It could address both gates only if a genuinely bounded symbolic family is found; ordinary min-plus spectral or eventual-periodicity theory supplies variable-size data and does not by itself meet the goal.

## Further outside-field analogy screened out early

Smooth pyramid fronts can be encoded by their `+1/-1` slopes. Removing an allowable top cell flips a peak to a valley, which resembles exclusion processes, order-ideal toggles, and carrier models. Integrable box-ball systems have powerful inverse-scattering descriptions. [Kuniba–Takagi–Takenouchi, 2006](https://arxiv.org/abs/math/0602481).

However, the obvious carrier identification fails a necessary commutation test. Let `F_k` be two canonical solo updates using budget `k`, so the physical phase returns to its original parity. On the 5 by 5 full larger cohort, of size 13,

\[
 F_5(F_3(13))=6\ne7=F_3(F_5(13)).
\]

The analogous commuting time evolutions are central to the integrable carrier analogy. A more elaborate lift is not ruled out, but no such lift has been identified, and introducing one solely to repair this failure is not presently a priority. Similarly, rowmotion's periodicity concerns a specified invertible toggle action, not the controlled irreversible capture game. These are sources of candidate statistics, not imported solution theorems.

## Recommendation

Use Route 1 as the explicit uniform lower-bound target; investigate Route 2 as its possible uncrossing mechanism and Route 3 as the geometry-preserving extension to even rectangles. Route 4 is a separate bounded recognition experiment directed at symbolic compression. None should be reported as a full solution or as bypassing the minimum-budget arithmetic specialization. The rational-mixture test, cross-phase counterexamples, and hole-location collision make it possible to discard unsuccessful versions quickly rather than enlarge their assumptions indefinitely.

## Exact compact certificate for the 3 by 5 pricing fixture

This is included to make the small discriminator reviewable without an optimizer. The two exact neighborhood profiles, indexed from zero, are

```
g0 = [0,2,3,4,5,6,7,7,7]   # input counts 0,...,8
g1 = [0,3,4,5,6,7,8,8]     # input counts 0,...,7
```

Let `lambda=[1,2,3,2,1]`. For each origin color, the following arrays are `F_t(s)` at times `t=0,...,5`, indexed by the possible count `s` in that day's physical color. The symbol `inf` means infinity.

```
origin 0:
t0 [0,1,2,3,4,8,10,12,20]
t1 [0,2,4,6,8,16,18,20]
t2 [0,3,6,8,10,12,15,18,21]
t3 [0,2,4,6,8,10,12,inf]
t4 [0,1,2,3,4,inf,inf,inf,inf]
t5 [0,inf,inf,inf,inf,inf,inf,inf]

origin 1:
t0 [0,1,2,3,4,10,12,18]
t1 [0,2,4,6,8,14,16,18,18]
t2 [0,3,6,8,10,12,15,18]
t3 [0,2,3,4,6,8,10,12,inf]
t4 [0,1,2,3,4,inf,inf,inf]
t5 [0,inf,inf,inf,inf,inf,inf,inf,inf]
```

For every `t<5`, every listed input count, and every `q` in `{0,1,2,3,4}`, direct substitution verifies

```
F_t(s) <= lambda[t]*q + F_(t+1)(g_(c xor(t mod2))(max(0,s-q))).
```

The terminal row is zero only at capture. Therefore any successful capped origin-0 quota word costs at least `F_0(8)=20`, and any successful origin-1 word at least `F_0(7)=18`. The words `(0,4,0,4,4)` and `(0,0,2,4,4)` attain the respective values, so these are exact minima, not only lower bounds. Their incompatible timing is the point: any common five-day physical schedule has total weighted quota at most `4*(1+2+3+2+1)=36`, below `20+18=38`. Thus five days are impossible, independently of an LP solver.

# Second arithmetic exploration: concrete extraction architecture

18 September 2026, continuation of the exploration-only pass. No compiler,
formalization, manuscript, website, or accepted-coverage change was made.
The results below are algebraic design and audit notes, not an already
constructed bounded-operation expression for the capture time.

## Assessment

There is now a concrete route from the **entire** accepted corner clock to a
fixed arithmetic expression. It avoids a universal machine and does not
depend on an unknown Josephus constant. The central object is a fixed
23-variable system with 18 equations that recognizes one transition in a
packed clock history. A first arithmetic count recognizes the unique valid
history; a second count returns its number of active steps. The remaining
work is explicit construction and verification of the arithmetic expression,
particularly the second count after all helpers are expanded.

This would address the full width-dependent clock, not merely one band or
one fixed width. Its intermediate integers would be enormous. That affects
practical computation and numerical auditing, but does not violate the
user's stated operation-count criterion.

## 1. Simplify the accepted clock before compiling anything

Assume b>=2; b=1 is the separate fixed case L_b=0. Put

    m=b+1, C=b(b-1), H=2C.

The accepted paired recurrence starts at (A,B)=(0,0), and L_b is the first
time B=C. Before that time A<=C and B<C. Consequently its caps are
redundant:

    q(B+m)<=b,
    ceil(sqrt(A+m))<=b+1.

The first inequality follows from B+m<=b² and b(b+1)>=b²; the second
follows from A+m<=b²+1<=(b+1)². Thus, before the target is reached,

    A'=B+m-u,       where (u-1)u < B+m <= u(u+1),
    B'=A+m-v,       where (v-1)² < A+m <= v².

Freeze the pair as soon as B=C. The existing clock proof gives L_b<=2C=H.
All coordinates throughout this frozen history lie in [0,C].

An initial design stored a third coordinate counting active steps. That
gave a 27-variable, 21-equation local encoding. It is unnecessary: the
second count can count the indices j with B_j<C directly. The smaller
design below stores only the pair.

## 2. A local graph with unique witnesses

For current coordinates A,B and proposed next coordinates A',B', introduce
eight nonnegative variables

    h,e,u,v,s_u,t_u,s_v,t_v.

Impose the following nine equations:

    h(h-1)=0,
    (1-h)(C-B)=0,
    C-B-h-e=0,

    B+m-u(u-1)-1-s_u=0,
    u(u+1)-B-m-t_u=0,
    A+m-(v-1)²-1-s_v=0,
    v²-A-m-t_v=0,

    A'-A-h(B+m-u-A)=0,
    B'-B-h(A+m-v-B)=0.

Each equation is polynomial of degree at most two. Their squared sum has
total degree at most four.

**Uniqueness audit.** The first three equations force h=1 when B<C and
h=0 when B=C, with e uniquely determined. They admit no solution when B>C.
The next four inequalities select exactly one pronic root u and one square
root v, with unique slacks. Their inputs are positive, since m>=3. The
last two equations then determine the next pair uniquely. At h=0 they
freeze both coordinates. There is no free witness capable of multiplying
the count.

## 3. Packed-history recognition with fixed dimension

Let Q=C+1 and R=Q². Encode the H+1 pairs by

    X = sum_(i=0)^H (A_i + Q B_i) R^i.

This sum defines the meaning of a code; it is not being proposed as an
operation in the final expression.

For a queried index j, introduce the four digits A,B,A',B', the eight
local witnesses above, a lower part ell, an upper part eta, and the
following eight slacks/witnesses:

    d_A,d_B,d_A',d_B', d_ell, d_j, d_X, zeta.

Altogether the variables are:

    j                         1
    A,B,A',B'                 4
    eight local witnesses     8
    ell,eta                   2
    four digit slacks         4
    d_ell,d_j,d_X,zeta         4
                              --
                              23.

In addition to the nine local equations, impose nine more:

    X = ell + R^j(A+Q B+R(A'+Q B'+R eta)),
    A+d_A=Q-1,
    B+d_B=Q-1,
    A'+d_A'=Q-1,
    B'+d_B'=Q-1,
    ell+d_ell+1=R^j,
    j+d_j=H-1,
    X+d_X+1=R^(H+1),
    X=R zeta.

Their squared sum is a nonnegative simple exponential polynomial E_b,X
in exactly 23 variables. The only exponential dependence on a counted
variable is R^j (and R^(2j) after squaring). All polynomial degrees are
bounded by four independently of b,H,X.

**Why the count has the intended meaning.** The code bound excludes
additional high digits. The divisibility equation forces the initial
pair to be (0,0). The lower-part bound and the four base-Q digit bounds
give the unique adjacent pairs in the base-R expansion. This remains
true at j=0, when ell=d_ell=0, and at j=H-1, when eta=0. The index slack
permits exactly 0<=j<H. All digit, remainder and index slacks are unique.
By the local uniqueness argument each j contributes at most one witness.

Therefore the number G(b,X) of solutions satisfies G(b,X)<=H. Equality
holds exactly when every transition is valid. Starting from the forced
zero pair, deterministic induction then identifies one unique history
code X_b. No arbitrary high digits or multiplicity of auxiliary witnesses
can produce a false G=H.

**A crude explicit cube bound.** All solution variables are strictly below

    t = X + R^(H+1) + (Q+m+1)² + H + 2.

For example, digits are below Q; root indices are at most Q+m; root
slacks are below (Q+m+1)²; ell and eta are at most X; d_ell<R^H;
d_X<R^(H+1); and zeta<=X. Thus this single cube contains every witness,
including on invalid input codes. All parameters Q,R,H,C,m,X are below t.

On the whole cube [0,t-1]^23, not just on solutions, every unsquared
equation has absolute value at most 9t^(t+4). There are 18 equations.
The convenient bound

    0 <= E_b,X < 2^(10t²)

follows for t>=2; using 21 instead of 18 in the estimate still works:
21(9t^(t+4))²=1701t^(2t+8), whose binary logarithm is strictly less than
11+2t²+8t<=10t². This gives a completely explicit packing width w=10t².
It is deliberately coarse, and numerical efficiency is not claimed.

## 4. The two arithmetic counts and the remaining construction

The classical block-counting construction produces an arithmetic term for
G(b,X). In brief, with M=2^w,

    delta(E)=(M-1)(M-E+1).

For 0<=E<M its binary Hamming weight is 2w at E=0 and w otherwise. Pack
these delta values into nonoverlapping 2w-bit blocks indexed by the cube.
The number of zeros is the packed integer's Hamming weight divided by w,
minus t^23. This is the mechanism in Marchenkov's published proof and the
later explicit presentations; the packing sum factors into fixed-degree
geometric moments because E has a fixed monomial list. See
[Marchenkov](https://www.mathnet.ru/eng/da10) and
[Prunescu–Sauras-Altuzarra](https://arxiv.org/html/2407.12928v1), §3.

This statement is a construction recipe, not permission to treat Hamming
weight or geometric moments as new primitives. They must be replaced by
their explicit arithmetic expressions, with corrected formulas and
positive-denominator hypotheses.

For the second count, translate the resulting fixed arithmetic DAG for
G into a unique-witness graph and impose G(b,X)=H. Then add an index j,
a digit d and five further witnesses ell,eta,s_j,s_d,s_ell satisfying

    X = ell + Q R^j(d+Q eta),
    ell+s_ell+1=Q R^j,
    j+s_j=H-1,
    d+s_d=C-1.

These seven new variables select exactly the indices j<H for which the
unique valid history has B_j<C. Hence the number of solutions is L_b.
This second count returns the desired clock directly; it does not need
to reconstruct the enormous history code as its numerical output.

**Where the real construction remains.** The graph of the first count
must be explicitly generated, including all Hamming-weight, quotient and
power helpers. Every arithmetic DAG node gets its own uniquely determined
output; a quotient uses a unique remainder and a strict-remainder slack.
Variable-base powers can be reduced to the standard base-two basis before
graph conversion. All gate outputs need an explicit common bound obtained
by a monotone majorant of the finite DAG with X<R^(H+1). This has fixed
height, but potentially enormous values. After this graph is built, the
second counting expression must itself be expanded to the allowed
operations. None of these last deliverables was produced in this pass.

More precisely, replace each input X in the fixed DAG by R^(H+1), keep
positive constant and parameter bounds, bound a truncated subtraction by
the sum of its input bounds, and bound a positive-denominator quotient by
its numerator bound. Addition, multiplication and exponentiation have
monotone bounds directly. This yields a fixed arithmetic majorant U(b)
for every valid gate value. Quotient remainders and slacks are bounded by
the sums of the relevant gate bounds; for truncated subtraction z=max(u-v,0)
one can use the unique-witness equations

    u-z-alpha=0,  z-u+v-beta=0,  z*beta=0.

All variables are nonnegative, and these force z and both slacks uniquely,
including u=v. A fixed maximum or sum of the gate/slack bounds, enlarged
by H+R^(H+1)+2, supplies an outer cube bound t_2(b). Replace all variables
by t_2 in an absolute-coefficient majorant of the second sum of squares;
that majorant plus one can itself serve as the exponent w_2, since
E_2<w_2<2^w_2 for w_2>=2. Thus neither counting layer needs an unbounded
search to discover its bounds. The actual expressions U,t_2,w_2 depend
on the still-unconstructed finite gate list and are not being claimed
as already written formulas.

The root functions are already represented by polynomial inequalities;
there is no integer-square-root oracle hidden in this construction.

## 5. Static expression size: a useful sparsity lemma

The 18 squared equations above give a conservative bound of 194 raw
monomials before combining equal terms:

    nine local equations       120
    packed digit equation       28
    four digit bounds           24
    lower-part bound            10
    index bound                  6
    code bound                   3
    initial divisibility         3
                               ---
                               194.

A completely naive expansion uses at most 194*23 generalized-moment
factors, all of degrees at most four. Thus its syntax size is already
independent of b. This is not an exact operation count: the moments and
Hamming weight still need expansion and common subexpressions matter.

The following additional identity substantially improves the architecture.
It was derived during this pass and independently checked by the parent.
Put G_e(q,t-1)=sum_(x=0)^(t-1) x^e q^x for fixed e. For B>=2,

    P = product_(i=0)^(d-1) G_0(B^(t^i),t-1)
      = (B^(t^d)-1)/(B-1).

The equality follows either by telescoping the geometric fractions or by
enumerating base-t digits. If a monomial has support S, meaning the
coordinates whose polynomial degree or exponential base is nontrivial,
its weighted cube sum equals

    [P / product_(i in S) G_0(B^(t^i),t-1)]
       * product_(i in S) G_(e_i)(a_i B^(t^i),t-1).

The first quotient is exact because its denominator is a selected
subproduct of the baseline product. The index set S is fixed by the
monomial, not by the input. In a gate-graph system each monomial involves
only a bounded number of variables. Consequently the expanded outer
count need not cost `number of variables * number of monomials` moment
factors: it can scale linearly in the gate graph size, using this common
baseline and the sparse supports.

For auditing, one can also ensure that individual variable degrees never
exceed two. Replace each squared root occurrence by a product of equal
copies and replace h(h-1)=0 by h+s_h=1 with both variables nonnegative.
Three extra variables and two extra equations suffice for the local
system. Then only G_0,G_1,G_2 occur. This is a standard
multilinearization device, also treated in Lemma 3.5 of the cited
Prunescu–Sauras-Altuzarra paper; it is not a claim of a new general method.

**Size judgment.** A static DAG in the thousands or tens of thousands of
nodes for the first count looks plausible after moment reuse. The outer
DAG could be substantially larger, but sparsity avoids a compulsory
quadratic blow-up. These are architecture estimates, not measured counts
or promises. The decisive size measurement must come from producing the
actual fixed DAG and checking its expansion. A fixed acyclic DAG meets
the operation-count requirement; a parameter-dependent loop over its
construction does not.

## 6. Independent attacks and a small diagnostic

The main failure modes were checked explicitly in the design:

- Missing initial conditions would admit many valid trajectories. The
  equation X=R*zeta forces both initial coordinates to zero.
- Missing code bounds would allow arbitrary high digits and multiple
  histories. X<R^(H+1) removes this freedom.
- Missing remainder bounds would allow spurious digit decompositions.
  The lower remainder and every base-Q digit have explicit unique bounds.
- A free slack, or an ambiguous active flag, would multiply the count.
  All slacks and both root indices are uniquely determined.
- Freezing only one coordinate would count the wrong continuation. Both
  coordinates are frozen at B=C.
- Counting any valid transition rather than all H would not recognize a
  history. Equality G=H is essential, and each j contributes at most one.
- A parameter-dependent number of equations or moments would violate
  the target. Here all dimensions, degrees, and monomial lists are fixed.

A tiny independent direct-integer check reconstructed frozen histories
for b=2,3,5 and rejected every one-digit mutation of their codes: 20,
156 and 1640 mutations respectively. Their clocks were 2,5,12. For b=2,
Q=3,R=9,H=4, and the unique code is X=59004. Eighteen small exact checks
also confirmed the baseline-product identity. These checks exercise the
semantic encoding and the algebraic identity; they do not evaluate the
fully expanded arithmetic-term counts, nor replace the proof.

## 7. Bit complexity and validation are real limits

Even the smallest nontrivial full clock produces extremely large packed
integers in the naive hypercube formula. For b=2, the displayed bound t
is already over 100000; the cube has t^23 positions. This is before
expanding the Hamming-weight expression, whose own powers can increase
the size dramatically. A literal full evaluation is not a sensible
macOS experiment. No such computation was attempted.

The right validation separates three things:

1. A finite standard-operation DAG, with no unexpanded Hamming weight,
   moment, recurrence, minimization, or variable-length product.
2. Compositional proofs of the helpers and of the history-counting
   interpretation. These establish the huge-integer expression without
   materializing its values.
3. A separate accelerated interpreter using already-proved helper
   identities, compared with direct clocks on small inputs. This is a
   useful diagnostic, but must not be advertised as constant bit-time
   evaluation of the original expanded term.

The numerical-operation criterion permits this distinction. We should
not secretly exclude large integers; equally, we should not suggest that
the resulting formula will compute examples faster than the current
recurrence.

## 8. A different economical encoding: parallel tableau checking

There is a second architecture worth considering only if the direct
clock compiler becomes unwieldy. It does not yet have a completed proof.

All L-bit candidate tableaux can be placed in consecutive wide blocks
of one integer by

    W = sum_(i=0)^(2^L-1) i B^i.

This particular sum has the fixed geometric first-moment expression.
A fixed finite-state cellular-automaton rule can verify local neighboring
cells throughout every tableau in parallel using shifts, Boolean
operations, and periodic masks. Initial and terminal conditions can be
masked separately. With guard bits, detecting whether each candidate
block contains any violation is a constant sequence of operations. For
example, if every block contains a bad-bit number v<2^L, adding its guard
2^L and subtracting one gives a high bit precisely when v>0; no borrow
crosses block boundaries. The least surviving block can then be selected
by a two-adic valuation.

**The necessary caution:** bitwise AND and two-adic valuation are not
free extra atoms. A fixed arithmetic AND term can itself be obtained by
one-layer bounded counting: bit i is set in x and y exactly when

    x=(2q+1)2^i+r,   0<=r<2^i,
    y=(2s+1)2^i+u,   0<=u<2^i.

Adding a variable z<2^i makes the count contribute 2^i. Sum implicitly
over 0<=i<=x+y; the terms above the bit lengths have no solutions.
The witness dimension is fixed and all bounds can be explicit. This
gives an elementary counting architecture for AND, not an already
expanded short AND formula. The valuation also requires expansion.

If these helper terms are small enough, a word-parallel local verifier
could avoid nested general-purpose history counting and support arbitrary
bounded computations. It would therefore retain full-game closure
potential. However, proving a universal tableau encoding, guard masks,
boundary semantics and extraction is more work than the direct paired
clock system. It should be a fallback, not an excuse to start another
large compiler project before testing the smaller construction.

Independent design review: the parent separately checked the 23-variable
system, root uniqueness, frozen-pair bounds, active-index digit extraction,
the truncated-subtraction graph, the coarse exponent bound and the sparse
baseline identity. That review found no gap in these design components.
The explicit outer DAG and complete operation expansion remain unfinished.

## The decisive pilot

The next pilot should have a finite stop condition:

1. Independently certify the 23-variable unique-history relation and its
   bound, including initial, final and frozen states.
2. Generate the first count's fixed sparse arithmetic DAG, with every
   moment and Hamming-weight helper expanded, and report its actual node
   count. This tests whether the architecture is manageable.
3. Generate the second count for the number of active indices and prove
   that its value is L_b, by composition of the checked lemmas.

Success would be an actual bounded-operation expression for the whole
minimum-budget clock and hence its whole rectangle family. Failure due
to size or audit complexity would be a concrete reason to favor the
parallel-tableau alternative. None of these implementation steps was
started in this exploration-only pass.

# Second geometry exploration: tests that separate new information from mass accounting

18 September 2026, bounded continuation of the exploration. No classification, publication claim, or formal artifact is changed. This pass deliberately attacks the Euler/contact proposal before investing in it.

## 1. The physical operation really is a dilation, but relative Euler alone is not progress

Use the square complex \(K(A)\) from `geometry.md`, whose faces are the rotated cells of a single checkerboard color. On the infinite square lattice there is an exact identity of closed sets:

\[
K(N_\infty A)=K(A)+[-1/2,1/2]^2. \tag{1}
\]

For one face, the four neighboring cells correspond to the four unit squares centered at its vertices, whose union is the original face dilated by the indicated square. Minkowski addition distributes over unions, proving (1). On a finite rectangle, one must retain the subsequent selection of valid opposite-color cells. Treating this as ordinary intersection without checking lower-dimensional boundary pieces is unnecessary and can obscure the exact cell complex.

This supplies a genuine geometric setting: alternating-grid dilations followed by deletion of at most \(k\) faces. It is not merely an analogy to a continuous flow. The finite board, however, has two alternating cell domains; suppressing their clipping would lose the boundary effects we need.

Let \(\Gamma(A)\) be the discrete subcomplex consisting of the off-board neighbor vertices of \(K(A)\). Then

\[
\chi(K(A),\Gamma(A))=\chi(K(A))-|\Gamma(A)|.
\]

Thus the first-pass identity can be written

\[
|N(A)|-|A|=p(A)/2+\chi(K(A),\Gamma(A)). \tag{2}
\]

This is an important negative discriminator: **replacing the words “Euler characteristic minus boundary regulator” by “relative Euler characteristic” adds no information.** Summing (2) along a history is still mass accounting. A useful new theorem must contain metric placement or actual temporal transport of the contacts.

## 2. Ordinary persistence does not remember the bad shape resets

Zigzag persistence is the appropriate standard language for topological features in a sequence that both grows and shrinks. It records homology across inclusions through common unions or other intermediary spaces. Carlsson and de Silva establish its mathematical framework; no result of theirs is a capture-time or quota theorem. [Primary paper](https://arxiv.org/abs/0812.0197).

There is already a decisive small warning in our data. Reinterpret the exact \(3\times4,k=2\) reset-chain masks with four columns and three rows. Every nonempty single-color complex at the recorded sources and targets is connected and has Euler characteristic one, hence has no holes. The minority supports are:

- after the first step: \(\{(0,0),(0,2),(1,1),(2,0)\}\);
- the actual next target: \(\{(0,1),(1,0),(3,0)\}\), while the reset uses \(\{(2,1),(3,0),(3,2)\}\);
- the following actual target: \(\{(1,1),(2,0)\}\), while the reset uses \(\{(0,0),(0,2)\}\);
- the following actual target: \(\{(1,0)\}\), while the reset uses \(\{(3,0)\}\).

The full-color supports are also connected and hole-free. Ordinary homology sees a single component and no holes in all of these states. The geometric incompatibility is precisely in where the corner or side contacts lie. It is therefore unjustified to expect a charge from Euler events or a basic component/hole barcode alone. This does not prove that every possible enriched persistence representation fails; it identifies the information that an enrichment has to add.

Even labeled side incidence is not enough for a general state clock. Consider a \(7\times7\) board, budget three, and a singleton post-inspection state at an interior cell \(v\). Its exact remaining capture time is

\[
1+\operatorname{dist}(v,\partial V). \tag{3}
\]

For the upper bound, after each movement inspect all but a chosen neighbor leading toward the boundary; there are at most four neighbors. Once the singleton reaches a boundary vertex, inspect its at most three neighbors. For the lower bound, any two same-color cells on this board have at least four neighbors, so immediately before a terminal budget-three movement-and-inspection step the state must be a singleton on the boundary. Every surviving vertex has an ancestral path from \(v\), so reaching that boundary takes at least its graph distance.

Consequently \((1,1)\) requires two steps and \((3,3)\) requires four, despite identical area, perimeter, Euler characteristic, empty side contacts, and ordinary relative homology. **This is a partial-state diagnostic, not a full-start counterexample:** budget three is below the full-board feasibility threshold for this board. It warns against a purported universal state potential; it does not rule out a theorem restricted to near-optimal full-start histories.

### Local-event charges also need care

One inspection need not create only one new component. Take a central face and four faces touching its four corners, with the outer faces mutually disjoint. Removing the central face creates three additional components with one shot. In original board coordinates, the five cells can be \((3,3),(1,3),(5,3),(3,1),(3,5)\) on \(7\times7\). The removed face's neighbors are still all supplied by the four outer faces: the topological change does not even reduce the next neighborhood.

Nor can the area of a bounded complementary component be charged at a fixed rate to its death. Removing one face from a thin annular wall can open an arbitrarily large cavity to the exterior. The hole's area disappears from a “bounded-hole area” statistic after one inspection. A positive hole-area state potential would therefore have an unbounded one-step drop. A valid amortization would have to remember the earlier cost of forming the wall and cavity, not merely the present hole area.

Movement can merge components and change boundary contacts without any inspection at all. Persistent features could still form part of an amortized proof, but no sharp budget inequality follows just from counting their births and deaths.

**Assessment:** ordinary or relative homology should not be promoted to the main attack. Metric contact ancestry may be valuable, but it is a new geometric transport problem, not something delivered automatically by persistence theory. No useful sharp temporal inequality emerged from Euler accounting alone in this pass.

## 3. A concrete quota-preserving compression gate

The more promising alternative is to make the desired history normalization precise enough to prove or falsify locally.

Write an actual post-inspection history as

\[
A_{t+1}=N(A_t)\setminus I_t,\qquad
i_t=|N(A_t)\setminus A_{t+1}|\le k.
\]

For each time choose a monotone, cardinality-preserving map \(C_t\) on subsets of the corresponding vertex set. Suppose

\[
N(C_t(A_t))\subseteq C_{t+1}(N(A_t)) \tag{4}
\]

holds along this actual history. Since a cardinality-preserving map fixes the full and empty sets, the initial and terminal conditions cause no problem.

**Sufficient normalization lemma.** Under these assumptions, there is a physical history winning no later than the original and respecting every original daily quota.

Define inspections

\[
J_t=C_{t+1}(N(A_t))\setminus C_{t+1}(A_{t+1}).
\]

Monotonicity and cardinality preservation give \(|J_t|=i_t\). If the transformed physical survivor \(B_t\) is contained in \(C_t(A_t)\), then

\[
N(B_t)\setminus J_t
\subseteq C_{t+1}(N(A_t))\setminus J_t
=C_{t+1}(A_{t+1}).
\]

Induction from the full initial board proves capture. The inspection sets may include already impossible cells; that only decreases the number of effective shots. No daily budget is transferred between times, and no pooled-ammunition relaxation is used.

This is a general sufficient lemma, not the missing rectangle theorem. Taking every \(C_t\) to be the identity makes it trivial. Its value is to specify exactly what a useful low-complexity family of transformations must establish.

### The exact cost of a failed interchange

There is also a quantitative version. Set

\[
E=N(C_t(A_t)),\quad F=C_{t+1}(N(A_t)),\quad
G=C_{t+1}(A_{t+1}),
\]

so \(G\subseteq F\). Define

\[
\delta_t=|E\setminus F|,\qquad
\xi_t=|(F\setminus G)\setminus E|.
\]

Then the exact number of deletions needed from the canonical envelope is

\[
|E\setminus G|=i_t+\delta_t-\xi_t. \tag{5}
\]

Here \(\delta_t\) is the new-neighborhood leakage outside the next compressed envelope, while \(\xi_t\) counts canonical deleted cells that the transformed state never produces. Therefore the more general local exchange condition is

\[
\delta_t-\xi_t\le k-i_t. \tag{6}
\]

It preserves the daily cap exactly. Unlike a shadow-cardinality comparison, (5) sees where the sets overlap. It can charge an attempted relocation of a corner front even when the before/after sizes and separate perimeters coincide.

### What would make this a full-scope route?

One would need a finite collection of explicitly parametrized transformations—possibly associated with different axes, corners, or front types—and a theorem that every full-start winning history admits a compatible sequence of them satisfying (6). Repeated switches are allowed. The transformed inspection sets, rather than every actual survivor set, can be the desired normal form. This distinction avoids demanding more than the construction requires.

A two-layer geometric exchange theorem would establish the available transitions between such transformations; a full-history compatibility theorem would show those transitions can be selected consistently. This is exactly where the old independent profile minimizers failed. The result must not silently replace the second theorem by choosing a separately best transformation on every day.

An especially useful first gate would be a nontrivial pair of front transformations satisfying (6) on the critical two-layer configurations, including a change of axis. Failure would expose the missing metric variable directly. Success would justify developing the growth-diagram or finite-event machinery from the first exploration.

There is a relevant existing framework: isoperimetric nesting is used in the actual Hunters and Rabbits game by Bolkema and Groothuis. Their theorem concerns graphs with the nesting property; it must not be assumed for our unresolved rectangle ranges. A single total order whose initial segments minimize neighborhoods and whose neighborhoods remain initial segments is much stronger than the time-dependent exchange sought here. [Hunting rabbits on the hypercube](https://www.sciencedirect.com/science/article/pii/S0012365X18303455).

The useful research question is therefore not “can all grid histories be made monotone?” It is whether they admit a quota-preserving sequence of **compatible compressions**, with the incompatibility surcharge (5) explicitly paid. Standard hunter monotonicity remains obstructed by the known pathwidth gap.

### A literal two-day surgery that preserves quotas

Fix all inspections except on consecutive days \(t,t+1\). Let the left vertices of a bipartite graph \(H\) be cells reachable just before day \(t\) under the fixed prefix, and its right vertices be cells from which some trajectory survives the fixed suffix after day \(t+1\). Join the copies when a physical move connects them. The two inspection sets \((S,T)\) preserve capture precisely when they cover every edge of \(H\). Thus this is an exact local model with the outside history retained.

Here is a concrete balanced exchange. Choose \(U\subseteq S\) and \(W\subseteq T\) with no edge of \(H\) between \(U\) and \(W\). Put

\[
P=N_H(W)\setminus S,\qquad Q=N_H(U)\setminus T.
\]

Then

\[
S'=(S\setminus U)\cup P,\qquad
T'=(T\setminus W)\cup Q
\]

is again a vertex cover. Indeed, an edge newly uncovered on its left would have its left endpoint in \(U\); its right endpoint outside the old \(T\) is added to \(Q\), while a right endpoint removed from \(T\) would lie in \(W\), contrary to the assumed anticompleteness. The other case is symmetric. Its exact side counts are

\[
|S'|=|S|-|U|+|P|,\qquad
|T'|=|T|-|W|+|Q|.
\]

The move therefore respects each daily budget if these two quantities do. In particular, \(|P|\le|U|\) and \(|Q|\le|W|\) suffice even on saturated days. This is a real quota-balanced surgery, rather than moving an arbitrary region of a space-time cut onto one time slice.

A plausible global proof architecture is to select an optimal schedule minimizing an explicit contour disorder, then show that every forbidden local pattern admits such a balanced exchange decreasing that disorder. The entirely open step is the existence of the exchange for the relevant rectangle patterns. The exchange lemma by itself does not imply connectivity of all feasible covers, a normal form, or optimality of any candidate strategy.

An additional small warning excludes replacing this two-quota relation by the lattice of ordinary minimum cuts. The outer ring of a \(3\times3\) board induces an eight-cycle. Its two minimum-cardinality vertex covers are the alternating four-sets, with side counts \((4,0)\) and \((0,4)\). Covers of side counts \((2,3)\) and \((3,2)\) also exist and obey quota three on each side. But no nonzero nonnegative linear weighting of the two side counts makes either mixed cover optimal: the cheaper alternating four-set always costs less. Thus minimum weighted covers can discard exactly the balanced alternative the surgery needs. This is a counterexample to **uncapped** weighted minimization, not to the project's capped whole-history pricing: keeping the daily caps inside the minimization excludes the two invalid alternating covers.

### A narrower and better normalization target suggested by the parent

Rather than normalizing every winning history, fix a temporal price vector \(\lambda\) and normalize only a **minimum-weight, daily-capped, full-start one-cohort history**, using a geometric tie-breaker. This is a materially weaker requirement and matches the existing weighted lower-bound framework.

For the two-day exchange above, its weighted cost change is exactly

\[
\lambda_t(|P|-|U|)+\lambda_{t+1}(|Q|-|W|). \tag{7}
\]

The move must obey both daily caps, but need not decrease the two daily counts separately. At a price plateau, only their sum enters (7). On a rising or falling slope, moving work in the cheaper direction can be permitted. This may allow the geometry to be organized according to the constant number of price regions in a clipped tent or a related price family.

The proposed theorem would select a minimum weighted history with least contour disorder and show that every forbidden geometric pattern admits a cap-feasible exchange with (7) nonpositive and a strict improvement in the tie-breaker. That would establish a canonical minimizer for the chosen price. If its form can be evaluated uniformly, it would give a genuine physical lower certificate, while avoiding an unnecessary normal form for all partial states or all histories.

Two obligations remain separate. First, prove and evaluate that canonical capped minimizer. Second, prove that the chosen prices separate every losing full-board deadline. Exact evaluation of each cohort's priced minimum alone does not eliminate a possible gap between compatible mean quota profiles and compatible physical strategies. This combination is a promising research target, not an assertion of either obligation.

## 4. A bounded-event statement needs the correct meaning of bounded

The existing 188-step \(25\times26,k=13\) solo witness was replayed from its saved inspections, without a new search. Examining each physical cell only on the days of the appropriate color, the maximum number of separate survivor-presence runs is three. Four cells attain it: \((3,25),(4,24),(23,4),(24,3)\). The complete distribution over the 650 cells is 35 with no run, 528 with one, 83 with two, and four with three. The replay ends empty.

This is a property of that witness, not a lower bound on all optimal strategies. Along with its eighteen forced changes of axis, it warns against announcing “one switch” or “two runs per cell” from visual intuition. No next constant is conjectured here.

A useful finite-event theorem could instead have a fixed list of **types** of propagation, boundary contact, and exchange events, with arbitrarily many repetitions. Such a theorem would be structural progress only if their compatibility and total cost could be evaluated uniformly. Replacing the original game by a long word in finitely many event types is not yet the fixed-operation numerical answer.

## Conclusion of this bounded pass

The Euler representation survived as an exact, axis-independent description of the physical geometry. Its most immediate topological enhancements did not yield a new sharp lower bound: relative Euler is already the mass identity, ordinary homology ignores the known corner resets, and naive feature-birth or hole-area charges fail.

The better concrete target emerging from these failures is the two-layer quota-preserving exchange inequality (6), coupled with a full-history compatibility theorem. It makes both the hoped-for normalization and its failure measurable. It still requires a genuinely new rectangle theorem, and any structural success must be combined with the separate scalar-clock arithmetic work. No new parameter range is declared complete.

# Further exploration: what survived a second round of attacks

18 September 2026. Requested additional window: 10:28–10:48 UTC.
Exploration and small discriminating checks only. This note does not change
the accepted classification, manuscript, website, or formalization claims.

## Assessment

The strongest route to the literal fixed-operation requirement remains
arithmetic-term extraction. It now has a concrete whole-clock pilot rather
than only an existence argument. For an informative geometric
classification, capped temporal prices remain the leading lower-bound
idea, but should be joined to a precise quota-preserving exchange argument.
Ordinary topological persistence, generic convexity of successful schedules,
and total inspection demand alone do not supply the missing theorem.

These conclusions come from falsifiers as well as positive evidence. No
previously unresolved parameter range was closed in this exploration.

## 1. Whole-clock arithmetic: a concrete design, not yet the expression

The first pass established the applicability of the classical elementary
function representation theorem; see `arithmetic-representation-assessment.md`.
The significant change is that the entire accepted clock L_b can now be
recognized by a fixed 23-variable, 18-equation system, with degree at most
four and a conservative 194-monomial bound. The size does not depend on b.
The system includes initial conditions, unique adjacent-digit extraction,
unique root witnesses, a frozen terminal state, and explicit bounds.

A first arithmetic solution-count recognizes the unique valid packed
history. A second counts precisely the indices before the terminal state,
returning L_b. No extra counter register is needed. The parent independently
checked the local root/freeze logic, bounds on the pair, active-index digit
extraction, uniqueness of the subtraction gate, and the sparse geometric
factor identity in `second-arithmetic.md`. The lane also tested single-digit
mutations of small valid histories; these are diagnostics, not a replacement
for the algebraic uniqueness proof.

The sparse identity is useful for syntax size. In a d-variable counting
cube, the baseline product of zeroth geometric moments telescopes to

    (B^(t^d)-1)/(B-1).

A monomial then needs changes only in its fixed small support. This avoids
blindly multiplying its cost by all variables of the outer gate graph.
It supplies a plausible route to an auditable fixed expression graph.

Remaining work is substantial but sharply specified: produce that graph,
expand Hamming weight and geometric moments into permitted operations,
instantiate every outer bound, verify all domain conditions, and prove the
composition. The helpers are not new allowed atomic operations. No final
expression or operation count has been delivered. Literal evaluation of the
intermediate integers would be impractical even for small inputs; the
relevant verification would be compositional, with independently audited
small components.

Why this pilot matters: for r>=8 the accepted odd-square reduction is

    T_(r+1)(2r+1,2r+1) = 4 L_r + 12r - 2.

An actual fixed expression for the whole clock would therefore close a
genuine infinite numerical gap. The same representation machinery can in
principle be applied to the elementary-bounded full-game evaluator and
canonical optimal-word selector, as explained in the first-pass note.
That is an inference from the representation theorem plus our finite-state
bound, not a rectangle theorem asserted by the cited authors.

The distinction remains important: a fully expanded arithmetic encoding
can satisfy the stated operation-count criterion while offering little
geometric understanding and enormous bit complexity. Neither an unexpanded
search primitive nor mere existence of an expression is the requested
deliverable. Conversely, enormous integers alone do not disqualify a route
under the criterion the user actually specified.

Primary source: Marchenkov, *Superpositions of elementary arithmetic
functions*, Russian 2006 / English 2007,
<https://www.mathnet.ru/eng/da10>. The constructive 2026 preprint
<https://arxiv.org/html/2606.09336v1> is a useful architecture reference but
contains local formula errors identified in the first pass; it is not
trusted compiler software.

## 2. Temporal prices: stronger evidence and a narrower missing theorem

The second pass tested actual physical histories on even-area rectangles.
On 4 by 4, budget 3, deadline 11, either initial color can be cleared with
minimum total 16 inspections. Thus total-demand accounting gives only

    16+16 <= 3*11.

However, with day prices (1,2,3,4,5,6,5,4,3,2,1), the minimum weighted
demand is 56 per color. The combined demand 112 exceeds the weighted
capacity 108. The parent independently reproduced both minima by exhaustive
integer dynamic programming on physical subsets, using no geometry
relaxation. See `second-independent-checks.json` and the standalone checker
in `second-control.md`.

The lane found the same discriminator on 4 by 6, budget 3, deadline 19:
unweighted demand 56 fits under 57, but tent-weighted demand 308 exceeds
300. These four-row optima were already known; the checks assess the method,
not new classification coverage. Earlier examples already disprove universal
tent prices, so this is evidence for a parameter-dependent price family,
possibly including flat and clipped shapes, not a theorem that one tent
always works.

Generic integrality is too strong and false. On the smaller initial color
of the 3 by 3 board, both quota words

    (0,0,2,2,2,2,2), (2,2,2,2,2,0,0)

guarantee capture, while their integer midpoint

    (1,1,2,2,2,1,1)

does not. The parent independently checked all three with physical-state
enumeration. Thus successful quota words are not all the integer points
of their convex hull. This does not refute the full-board constant-budget
price method.

For even-area boards there is a cleaner, weaker target. Reflection swaps
colors, so both full-origin successful permitted-quota languages are the
same upward-closed set Q inside {0,...,k}^D. The fractional mean-quota test
passes exactly when the center (k/2,...,k/2) belongs to conv(Q). Physical
capture requires q and k*1-q both to belong to Q. The missing theorem need
only imply the second fact from the first at the relevant critical
deadlines. It need not eliminate every integer hole or establish generic
polymatroid exchange.

No full-board fractional counterexample was found in this bounded pass.
That keeps temporal separation promising; it does not prove sufficiency.
For odd boards the two different languages require the corresponding
two-language statement. Even exactness of the price relaxation would not
by itself give a bounded numerical formula or explicit optimal inspections.

## 3. Geometry: replace topological optimism by a testable exchange

The rotated-cell Euler identity survives, but its immediate enhancements
are weaker than hoped. Relative Euler characteristic simply rewrites the
same neighborhood mass identity. Ordinary connected-component and hole
data cannot distinguish the known 3 by 4 corner-reset examples. Even labeled
side incidence omits distance to a boundary: interior singleton states
already distinguish that metric information. The singleton example is
below full-board feasibility and is explicitly only a partial-state
diagnostic. See `second-geometry.md` for these qualifications.

A more concrete normalization criterion emerged. If C_t are monotone,
cardinality-preserving compressions of a post-inspection history, let

    E = N(C_t(A_t)),
    F = C_(t+1)(N(A_t)),
    G = C_(t+1)(A_(t+1)),
    i = |F minus G|,
    delta = |E minus F|,
    xi = |(F minus G) minus E|.

Because G is contained in F, the exact deletion cost from the compressed
envelope is i+delta-xi. The inequality delta-xi <= k-i is therefore a
precise daily-cap gate. It retains the overlap lost by separate cardinality
minimization. Containment of actual transformed survivors is enough; they
need not coincide with the canonical envelope.

There is also an exact two-day exchange expressed as a bipartite vertex
cover between prefix-reachable and suffix-co-reachable cells. Its two
quota changes are separately controlled. This supplies a useful local
test, but a global normal-form theorem is still missing. Identity
compressions trivially pass; useful compressions must simplify the history
enough to evaluate and construct optimal schedules uniformly.

The best combined target is weaker than normalizing every winning history:
choose a minimum-weight capped full-origin cohort history for proposed
prices, then choose a geometric tie-breaker. Seek a two-day exchange that
eliminates every forbidden contour while retaining both caps and satisfying

    lambda_t * change_in_quota_t
      + lambda_(t+1) * change_in_quota_(t+1) <= 0.

Price plateaus permit balanced exchanges; slopes may select a preferred
direction. This may turn the price demand into a tractable geometric
minimum without imposing an unjustified fixed axis or one-block schedule.
It remains a proposal: local optimality must still be shown to force the
desired global form, and the resulting price bound must be sharp.

## 4. Wider literature routes screened

- **Macaulay posets / Hilbert-function compression.** These organize nested
  shadow minimizers and are relevant tools for static shapes. They do not
  supply compatibility of alternating physical neighborhoods and deletions.
  The known failure of the size relaxation already blocks naive use of one
  global order. A temporal grading or paid exchange is still needed.
  Kuzmanovski: <https://digitalcommons.unl.edu/dissunl/82/> and
  <https://link.springer.com/article/10.1007/s10801-025-01472-w>.
- **Minimal-surface cut surgery.** Deterministic exchanges used to exclude
  long thin chimneys suggest a geometric tie-breaker, but those arguments
  control a weighted total cut. Moving its cost to one slice can violate
  our hard daily cap. Only a balanced exchange, such as the two-day gate
  above, would transfer. Dembin and Garban:
  <https://arxiv.org/abs/2301.11248>.
- **Concave-growth queue scheduling / majorization.** The continuous
  preference for concentrating service is suggestive, but the discrete
  root profiles have oscillating increments. Existing failed exchange and
  majorization examples prevent direct import. Full-start exceptional
  outputs remain a possible narrower domain; no new bridge was found.
- **Synchronizing automata.** The finite-word viewpoint is useful for
  arithmetization, but generic shortest-word algorithms do not give a
  uniform expression, and deterministic reset words are not the same as
  extinction of this nondeterministic moving-target state.
- **Josephus / rational-base iteration.** Exact-looking power formulas can
  move the problem into an unknown parameter-dependent limiting constant.
  That constant cannot become a new permitted atom. The literature is
  valuable for understanding carries, but it did not provide a completed
  uniform expression in this pass. Odlyzko and Wilf, 1991:
  <https://doi.org/10.1017/S0017089500008272>.

These are method assessments, not impossibility results about those fields.

## Recommended next discriminants

1. Construct and independently verify the actual fixed expression graph
   for the whole L_r clock. Audit every helper and state the fixed node
   count. This directly tests the strongest route to the numerical goal.
2. Attack critical full-board temporal separation, rather than general
   quota-polytope integrality. A genuine fractional full-board witness would
   tell us exactly what extra interaction a joint potential must retain.
3. Couple prices to quota-preserving geometric exchanges. First prove a
   nontrivial exchange across a change of front orientation; then test
   whether a minimum-price tie-breaker forces a useful global form.

Do not spend the next pass merely increasing the catalogue of price
certificates, adding topological statistics, or assuming that a faster
recurrence evaluator meets the numerical target. Each proposed direction
has an explicit missing bridge and a test that can change its priority.

# Second exploration: the exact boundary of temporal-price arguments

18 September 2026, 10:28–10:44 UTC. Bounded exploration, not a new proof campaign. No manuscript, website, or formal source changed. This note follows `control.md` and records discriminator computations and a narrower structural target.

## Conclusion of the bounded test

No critical-deadline fractional-mixture counterexample was found. Two nontrivial **physical even-area** fixtures support continuing with temporal prices: total capped ammunition fits below the true deadline, but a simple tent of day prices excludes that deadline. This strengthens the case for temporal prices beyond the earlier odd-rectangle tests, without proving their general sufficiency.

A different simplification does fail: the quota language can omit an integer point of its own convex hull, even on the 3 by 3 board. Consequently one cannot simply identify successful quota words with all integral points in a convex resource polytope and import an integer-decomposition theorem. The full-board question requires a much narrower central compatibility statement, described below.

## 1. Exact physical even-area tests

For an origin checkerboard color, a state is the actual set of still possible rooms. An inspection removes a subset of at most `k` rooms and movement replaces the survivors by their full physical neighborhood. These tests enumerate those sets; they use neither a cardinality-profile relaxation nor a smooth-front assumption.

On **4 by 4, budget 3**, the accepted full-board answer is 12 days. At the false deadline 11:

- The minimum total paid inspections for either cohort is 16. Thus constant prices give only `16+16=32<=33` and cannot exclude the deadline.
- For prices `(1,2,3,4,5,6,5,4,3,2,1)`, the minimum physical weighted cost for either cohort is 56. Therefore `56+56=112>3*36=108` excludes 11 days.
- The exact-history flow relaxation coupled only by expected daily quotas is infeasible: 3,642 variables and 491 flow/budget constraints. The weighted integer calculation already supplies the exclusion; the LP is only an independent formulation check, not an additional mathematical conclusion.

On **4 by 6, budget 3**, the accepted answer is 20. At deadline 19:

- Constant demands are `28+28=56<=57`.
- Tent demands are `154+154=308>3*100=300`.
- The corresponding physical mean-quota flow LP is infeasible, with 44,426 variables and 3,825 constraints. This run took about 1.2 seconds, with one solver thread.

The higher-budget contrast **4 by 6, budget 5, deadline 6**, below the accepted answer 7, is already excluded by constant demands `17+17>30`; its tent demands are `36+36>60`. It therefore supplies no further discriminator for the temporal method.

These are checks of the same candidate mechanism, not new capture-time classifications. In particular, four-row formulas were already proved. No claim is made that a tent always works: previous work already has odd-board counterexamples to universal tent prices, while constant or clipped-tent prices succeed there.

### A literal attaining physical history on the 4 by 4 fixture

Coordinates are zero-based. Start with the even checkerboard color. The first five days inspect nothing. On days 6 through 11 inspect respectively

```
6:  {(0,1),(1,0)}
7:  {(0,2),(1,1),(1,3)}
8:  {(1,0),(1,2),(2,1)}
9:  {(1,3),(2,0),(2,2)}
10: {(2,1),(2,3),(3,2)}
11: {(2,0),(3,1)}.
```

After movement the successive possible-set cardinalities are `7,6,5,4,2,0`. The quota word is `(0,0,0,0,0,2,3,3,3,3,2)`, giving total 16 and tent cost 56. A color-swapping reflection supplies the other cohort's attaining history. The two individual histories cannot be combined within budget 3, precisely as the weighted inequality proves.

The minimum values were obtained by exhaustive integer dynamic programming with terminal cost zero only at the empty support. The following standalone checker reproduces the two demands on this fixture without importing a project helper or an optimization library. This is finite exhaustive evidence, not a uniform proof of a price family.

```python
from functools import lru_cache
from itertools import combinations

w = n = 4
k = 3
neighbors = []
full = 0
for x in range(w):
    for y in range(n):
        j = x*n+y
        if (x+y) % 2 == 0:
            full |= 1 << j
        neighbors.append(sum(
            1 << (u*n+v)
            for u, v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
            if 0 <= u < w and 0 <= v < n))

@lru_cache(None)
def neighborhood(a):
    if not a:
        return 0
    bit = a & -a
    return neighborhood(a ^ bit) | neighbors[bit.bit_length()-1]

@lru_cache(None)
def edges(a):
    bits = [1 << j for j in range(w*n) if a >> j & 1]
    best = {}
    for q in range(min(k, len(bits))+1):
        for removed in combinations(bits, q):
            z = neighborhood(a-sum(removed))
            best.setdefault(z, q)
    return tuple((q,z) for z,q in best.items())

def demand(prices):
    costs = {full: 0}
    for price in prices:
        next_costs = {}
        for a, cost in costs.items():
            for q, z in edges(a):
                value = cost + price*q
                next_costs[z] = min(next_costs.get(z, 10**9), value)
        costs = next_costs
    return costs[0]

assert demand([1]*11) == 16
assert demand([1,2,3,4,5,6,5,4,3,2,1]) == 56
```

Keeping only the least paid quota for a fixed successor is legitimate for these nonnegative costs and for a mean-capacity inequality. Empty supports persist at zero cost. Applying the last movement does not change capture status because the grid has no isolated vertices.

## 2. A convexity obstruction with an exact trace

Consider the exact canonical language on **3 by 3, budget 2, deadline 7**, starting from the smaller color class of size 4. Both permitted-quota words

```
u = (0,0,2,2,2,2,2)
v = (2,2,2,2,2,0,0)
```

capture. Their integer midpoint

```
z = (1,1,2,2,2,1,1)
```

does not. The exact post-movement count traces, including the initial count, are

```
u: 4,5,4,4,3,3,2,0
v: 4,4,3,3,2,0,0,0
z: 4,5,4,4,3,3,3,4.
```

The two neighborhood profiles, indexed from zero, are

```
g_even = [0,2,3,4,4,4]
g_odd  = [0,3,4,5,5].
```

Each trace follows `s_next = g_phase(max(0,s-q))`, alternating physical colors. These are exact minimum-neighborhood profiles with compatible canonical realizations. Thus the failed trace cannot be repaired by choosing a different physical arrangement: the profile recurrence is already a lower bound on every physical history for that quota word.

Writing `Q` for the successful permitted words, this proves

\[
Q\ne\operatorname{conv}(Q)\cap\mathbb Z^7.
\]

This is **not** a fractional counterexample to the full-board constant-budget deadline. It concerns one cohort, and its midpoint is not a compatible full-board pair. Its role is to reject a tempting unnecessarily strong intermediate theorem.

## 3. The sharper even-area structural target

On every even-area rectangle, reflection across an even side swaps checkerboard colors. Hence the two full-origin physical quota languages coincide: `Q_0=Q_1=Q`. Use **permitted quotas**, so `Q` is upward closed in the integer box `{0,...,k}^D`, including wasted quota after capture. This convention leaves the physical feasibility question unchanged.

Let `P=conv(Q)` and `c=(k/2,...,k/2)`. The expected-quota relaxation is feasible exactly when

\[
c\in P.
\]

Indeed, feasible means `x,y in P` with `x+y<=k*1`; their midpoint belongs to `P` and lies below `c`. Convex upward closure then puts `c` in `P`. Conversely, the pair `c,c` is itself a feasible mean pair.

The exact full-board condition is instead that some `q` satisfies

\[
q\in Q,\qquad k\mathbf1-q\in Q.
\]

Consequently the precise no-fractional-gap statement needed here is **central decomposability**:

> If the center of the quota cube belongs to the convex hull of successful full-origin words, two successful full-origin words are complementary coordinatewise.

It would suffice to prove this only at the false critical deadlines of the proposed construction. This is far weaker than generalized-polymatroid exchange, all-state integral convexity, or the absence of every integer hole. The counterexample in Section 2 does not refute it.

Equivalently, every impossible critical deadline would have a nonnegative day-price separator. Price reversal and symmetrization are already proved in the prior temporal-structure note; they are not new claims here. The remaining useful strengthening is a **uniformly parameterized family of separators**, perhaps constant prices or clipped tents with parameters determined from the rectangle and budget. No bounded-knot or tent-family sufficiency theorem has been established.

## 4. What can and cannot be imported from decomposition theory

Kleer and Schäfer's aggregation/decomposition framework explicitly separates two requirements: a fractional aggregate must have an integer representative in the capacity box, and that aggregate must decompose into individual strategies. Their hypotheses include integer decomposition and box-TDI; symmetric network and related structured games are examples. This distinction is directly useful here, but the hypotheses are not automatic for the quota projection. [Primary paper, published 11 August 2020](https://link.springer.com/article/10.1007/s10107-020-01546-6).

Our one-cohort time-expanded flow polytope is integral before projection. Adding shared daily resource rows does not preserve that conclusion automatically. Projecting to quota words additionally creates the integer hole above. A proof might retain the full history lift, but then it must establish a central two-history decomposition compatible with the added budget rows. Merely invoking network-flow integrality or a general two-commodity theorem is insufficient.

The narrower central target is the promising part of this connection: it asks only for the symmetric constant-cap full-board slice needed by this problem. It avoids spending effort on a stronger decomposition theorem that is already false in its most obvious projection.

## 5. If additive prices eventually fail

The next relaxation should be chosen from the actual rational witness, not introduced preemptively. A hierarchy of genuinely different information levels is available:

1. **Mean quotas:** additive day prices `lambda_t*q`. This is the current promising class.
2. **Whole daily quota distributions:** allow nonlinear costs `f_t(q)` for each cohort and bound their combined cost on `q+q'<=k`. Exact cohort histories remain intact. This detects an incompatibility hidden by means but visible in one-day marginals.
3. **Short blocks of successive quotas:** retain joint distributions of `(q_t,...,q_(t+h))`. This can detect incompatibility hidden by independently coupling each day's marginals.
4. **Full coupled histories:** exact, but this returns to the original optimization unless a structural reduction is proved.

For the second level, the valid inequality is immediate. If `F_c` is the minimum of `sum_t f_(c,t)(q_t)` over successful cohort histories and

\[
B_t=\max_{u+v\le k}\bigl(f_{0,t}(u)+f_{1,t}(v)\bigr),
\]

then a full strategy requires `F_0+F_1<=sum_t B_t`. Additive prices are the special case `f_(c,t)(q)=lambda_t*q`. This is the dual interpretation of the existing marginal-flow model, not a new capture theorem.

A uniform theorem at any bounded level could potentially match all bounds. An unbounded march through this hierarchy would merely reimplement exact joint search. Likewise, general Chvatal–Gomory or parity cuts are not a solution by themselves: one needs a game-specific cut family with a uniformly controlled description and a proof that it excludes every false critical deadline. No need for that escalation has yet been demonstrated by a full-board fractional witness.

## Recommended next gate

Continue the temporal-price route, retaining actual physical geometry on even boards. Aim first at a proof of critical central separation, or directly at a sufficiently broad but explicitly parameterized separator family. Use the odd-board exact language to develop the price-shape argument and the new physical 4 by 4/4 by 6 fixtures as mandatory even checks. Keep the closure/deficit budget identities as a possible transfer mechanism, remembering that projection may exceed the daily cap.

Do not divert to proving full polytope integrality or a generic multicommodity theorem. The explicit integer-hole obstruction shows why that would impose avoidable burdens. Also do not return to constant total ammunition as the presumed even-board solution: it fails on the smallest meaningful four-row fixture.

This closes no unresolved family-level value gap and does not settle the fixed-operation numerical goal. It narrows the needed structural theorem, rejects two oversimplifications, and supplies concrete evidence that time prices can detect geometric timing losses beyond a total-ammunition bound.

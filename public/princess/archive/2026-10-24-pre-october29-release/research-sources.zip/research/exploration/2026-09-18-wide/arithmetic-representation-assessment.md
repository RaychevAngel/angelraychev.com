# A different route to the literal fixed-operation target

18 September 2026. Exploratory assessment, not a submitted formula, a new
rectangle classification, or a Lean claim. The main sources, manuscript,
website, and accepted coverage are unchanged.

## What the literature actually says

Mazzanti, *Plain Bases for Classes of Primitive Recursive Functions*,
Mathematical Logic Quarterly 48 (2002), 93–104, gives substitution bases
for elementary recursive functions. Here substitution means composition,
not input-dependent iteration. Marchenkov, *Superpositions of Elementary
Arithmetic Functions*, Journal of Applied and Industrial Mathematics 1
(2007), 351–360, gives a basis consisting of addition, truncated
subtraction, integer quotient, and base-two exponentiation.

Primary records:

- https://onlinelibrary.wiley.com/doi/10.1002/1521-3870(200201)48:1%3C93::AID-MALQ93%3E3.0.CO;2-8
- https://www.mathnet.ru/eng/da10
- https://doi.org/10.1134/S1990478907030106

Consequently every elementary recursive numerical function has a fixed
finite expression in these operations. This is stronger than generic
computability. It permits enormous intermediate integers, and makes no
claim of constant bit complexity or a short/usable expression.

The basis operations fit the ratified criterion. For example,
max(x-y,0)=(x-y+sqrt((x-y)^2))/2. A quotient with a zero divisor can be
handled by a fixed case distinction, or eliminated algebraically. No
new arithmetic primitive is needed. All abbreviations must ultimately
expand to a fixed expression independent of the input parameters.

## Why the rectangle capture function is covered

This is our deduction from the representation theorem, not a theorem
about rectangles stated in the cited papers.

Let N=ab, Q=2^N, and first handle the singleton and zero-budget conventions
directly. When N>=2 every vertex has a neighbor. A state is the subset A
of cells where an uncaptured target could be before inspection. For a
legal inspection set S, the next state is N_G(A minus S). There are at
most Q states and Q inspection sets. Empty is reached on the capture day:
because there are no isolated vertices, N_G(A minus S) is empty exactly
when A minus S is empty.

Every successful inspection policy has a unique all-miss word up to
capture, so no additional decision-tree state is necessary. In a shortest
successful word no belief state repeats; a repeated segment could be
deleted because the transition rule and daily budget are time independent.
Thus finite capture time is at most Q-1.

Enumerate the finite state graph and compute distances to empty. This uses
only bounded loops, finite-set encodings, and elementary operations, with
a running-time bound of the form poly(N)*Q^c for a fixed c if a standard
explicit graph-search implementation is used. Alternatively, the simpler
but slower enumeration of all words of length at most Q-1 has an explicit
bound poly(N)*Q^(Q+2), still elementary. In binary input length this is
bounded by a tower of fixed height. Therefore the total function which
returns T on finite cases and 0 on infinite cases is elementary recursive.

The same applies to a canonical optimal strategy: among the shortest
successful words choose the lexicographically first one. Encode it in
base Q, with time included to disambiguate leading zeros. Its code is
less than Q^Q. Computing a particular day's inspection mask, or testing
membership of a specified cell, is likewise elementary recursive.

The classical basis theorem therefore implies existence of fixed
standard-operation terms for both the finite/sentinel value and a
canonical optimal inspection rule. It does NOT display those terms.
Writing a symbol for the graph search, the universal interpreter, or an
unevaluated bounded sum would NOT meet the criterion.

## What actual completion by this route would require

1. An explicit fixed expression, or a fixed acyclic expression graph with
   a specified expansion into permitted operations. Its number of nodes
   must be an absolute constant, not depend on a,b,k.
2. All bounds and encodings instantiated for this game, including the
   singleton, k=0, and infinite cases.
3. An explicit inspection-membership expression depending on a,b,k,t and
   the room, with proofs of budget, capture, and minimality.
4. Independent checking of the expression-building machinery and the
   game interpretation. The current Lean development does not supply this.

An arithmetic term can implement bounded search mathematically without
containing a search operation syntactically. Its cost moves into integer
size. This distinction must be made explicit to Angel. We should neither
advertise an unconstructed term as the requested answer nor silently add
a restriction on intermediate integer sizes to exclude the route.

## A more informative pilot than compiling the whole game

On the unresolved numerical family r>=8, the minimum-budget odd-square
reduction is

    T_(r+1)(2r+1,2r+1) = 4 L_r + 12r - 2.

Thus structural geometry alone cannot bypass L_r under the current
numerical goal. A smaller extraction target is the known corner-clock
recurrence. One relevant orbit is

    x_0=1,
    x_(t+1)=floor(((r+1)x_t+r-1)/r).

The update is already an arithmetic term. Before an explicit threshold
of order r^2, the orbit increases at least by one. A clamped orbit and
a counter that freezes when the threshold is crossed give a bounded
recurrence of fixed arity. This is a candidate for a manageable arithmetic
term extraction. It is not yet an expression for the full L_r, whose
remaining phase/tail still has to be incorporated. The arithmetic lane
identified a better final pilot: apply the same construction directly to
the accepted paired clock, clamped at C=r(r-1), and freeze a counter at
termination. The accepted clock bound L_r<=2C provides a polynomial
horizon and bounds on all registers. That would address the whole clock,
rather than only the displayed upper phase.

The explicit new preprint by Istrate, Prunescu, and Shunia,
*Undecidability, Chaos and Universality in Arithmetic Terms*, 8 June 2026,
https://arxiv.org/abs/2606.09336, proposes a recurrence-to-term construction
and a bounded-program compiler. Its recurrence theorem requires an
arithmetic-term growth bound. That condition is essential: arbitrary
tower-height recurrence growth is not covered without a new bound
operation. Our proposed bounded clocks and finite-state search do have
elementary bounds.

The arithmetic exploration found local errors in displayed formulas in
that preprint; see arithmetic.md. Accordingly it is a source of a
construction architecture, not trusted ready-to-use compiler software.
The older published basis theorem supplies the existence result
independently of those errors.

## Assessment

This is the strongest new lead for the literal full fixed-operation goal.
The question of whether such terms exist is much less open than our
previous focus on Josephus-style telescoping suggested. Producing a
readable geometric classification, practically evaluable formulas, and
illuminating inspection strategies remains a different quality question.
Those benefits should be stated explicitly, not smuggled in as extra
completion conditions or discarded as though an encoding explains the
geometry. No substantive pursuit of this route was started in this
exploration-only pass.

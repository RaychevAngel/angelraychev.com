#include <algorithm>
#include <ctime>
#include <iostream>
#include <vector>
using namespace std;

// Tiny exact full-board screen. Fixed horizontal domino matching identifies
// each color with h cells; optional restriction nests each cohort's survivors.
int solve(int w,int n,int k,bool nested,double cap,int& count) {
  const int h=w*n/2,H=1<<h,full=H-1;
  vector<vector<int>> hood(2,vector<int>(H));
  for(int p=0;p<2;p++) {
    vector<int> one(h);
    for(int rowpair=0;rowpair<w/2;rowpair++) for(int y=0;y<n;y++) {
      int x=2*rowpair+((p-y)&1),i=rowpair*n+y;
      for(auto d:vector<pair<int,int>>{{1,0},{-1,0},{0,1},{0,-1}}) {
        int xx=x+d.first,yy=y+d.second;
        if(xx>=0&&xx<w&&yy>=0&&yy<n)one[i]|=1<<((xx/2)*n+yy);
      }
    }
    for(int a=1;a<H;a++)hood[p][a]=hood[p][a&(a-1)]|one[__builtin_ctz(a)];
  }
  vector<unsigned char> seen(H*H); vector<int> layer{full*H+full};seen[layer[0]]=1;
  const auto start=clock(); count=1;
  for(int depth=0;!layer.empty();depth++) {
    vector<int> next;
    for(int state:layer) {
      int r0=state/H,r1=state%H,a0=hood[1][r1],a1=hood[0][r0];
      int total=__builtin_popcount(a0)+__builtin_popcount(a1);
      if(total<=k)return depth+1;
      // Survivor containment forces all off-old-support vertices to be shot.
      int compulsory0=nested?(a0&~r1):0,compulsory1=nested?(a1&~r0):0;
      int left=k-__builtin_popcount(compulsory0)-__builtin_popcount(compulsory1);
      if(left<0)continue;
      int base0=a0^compulsory0,base1=a1^compulsory1;
      vector<int> bits;for(int i=0;i<h;i++)if(base0>>i&1)bits.push_back(i);
      for(int i=0;i<h;i++)if(base1>>i&1)bits.push_back(h+i);
      auto generate=[&](auto&& self,int at,int need,int b0,int b1)->void {
        if(!need){int s=b0*H+b1;if(!seen[s]){seen[s]=1;next.push_back(s);count++;}return;}
        for(int j=at;j+need<=int(bits.size());j++){
          int bit=bits[j];self(self,j+1,need-1,bit<h?(b0^(1<<bit)):b0,bit<h?b1:(b1^(1<<(bit-h))));
        }
      };
      // Early extra deletion need not preserve a nesting-constrained future;
      // retain every unused-quota choice in the restricted model.
      for(int used=nested?0:left;used<=left;used++)generate(generate,0,used,base0,base1);
      if(double(clock()-start)/CLOCKS_PER_SEC>cap)return -2;
    }
    layer.swap(next);
  }
  return -1;
}
int main(){for(auto v:vector<vector<int>>{{2,4,2},{2,6,2},{4,4,3},{4,4,4}}){
  for(bool nested:{false,true}){
    int count;auto start=clock();int ans=solve(v[0],v[1],v[2],nested,1.5,count);
    cout<<v[0]<<","<<v[1]<<","<<v[2]<<","<<nested<<","<<ans<<","<<count<<","<<double(clock()-start)/CLOCKS_PER_SEC<<endl;
  }
}}

# Routes toward the complete rectangle problem

13 September 2026. Bounded exploration requested by Angel; begun at
17:06 UTC. This is an assessment of possible methods, not a new accepted
classification. The manuscript, website, Lean sources, and publication
packages are unchanged.

## The endpoint being assessed

For every positive rectangle a by b and every constant daily budget k,
determine T_k(a,b), including infinity, with an absolute fixed number of
standard numerical operations. Also give directly specified optimal
inspections and proofs of capture and minimality. A recurrence, a short
algorithm, or a parameter-dependent finite optimization is intermediate
progress, not this endpoint.

The current mathematical boundary was read from CURRENT_CHECKPOINT.md,
HANDOFF.md, research/RECTANGLE_GAPS.md, and the relevant manuscript sections.
The most important distinction is between three outstanding obligations:

1. **Physical optimality on even-area boards.** Existing exact boundary
   evaluators retain parameter-dependent optimization. Necessary size,
   corner, and radius models need not describe realizable consecutive
   states. Some known upper strategies are themselves improvable. The low
   budget range is not uniformly confined to a one-day gap: for example,
   T_13(24,24) lies between 206 and 207, while the current 24-row odd-length
   formulas give a two-day interval. The broad one-day bounds require the
   stated linear-budget thresholds, rather than feasibility alone.
2. **The last shared day on odd-area boards.** The exact answer is already
   one of 2 tau - 1 and 2 tau. The unresolved direct decision is restricted
   to shorter boards and the remaining intermediate budgets; an exact joint
   evaluator exists. Proving every partial state has a preferred orientation
   is stronger than necessary and has repeatedly led to false conjectures.
3. **Uniform numerical evaluation.** Even some families whose exact strategy
   and optimality were proved before the fixed-scope baseline still have a
   width-dependent clock. For w=2r+1 and k=r+1, on odd n>=w, the accepted
   formula contains the term +4 L_r, where L_r is an explicit recurrence.
   This is a separate barrier to the absolute-operation goal.

The detailed parameter ranges remain authoritative in RECTANGLE_GAPS.md;
this exploratory document does not replace that coverage ledger. Formal
verification is a separate delivery obligation. No new Lean coverage is
claimed here.

## What the previous attempts actually taught us

The successful work controls expansion and explicit front transport very
well in the interior. The remaining geometric difficulty is maintaining
compatibility through the boundary phases and through the final meeting
of the two initial-color cohorts.

The failures are informative:

- Minimum neighborhood sizes do not necessarily compose: the 6 by 6,
  k=5 scalar relaxation predicts 13, whereas the exact value is 14.
- A size and a current corner flag do not retain the old corner's influence
  after that corner is inspected away. Persistent radii repair part of this,
  but their initial values can be too weak for a sharp whole-game bound.
- An optimal fixed-anchor strategy cannot be assumed: the accepted
  16-row, k=56 construction changes shape and improves the anchored rules.
- Actual odd-board histories can have phase gaps and rounded credits larger
  than convenient one-unit envelopes. Examples on 11 by 11 and 21 by 21
  reject those envelopes, while not disproving the weaker central decision.
- Rescheduling the same fixed descending word has already been exhausted
  in the relevant theorem. Further searches over that same word would
  not address the missing geometry.

These suggest studying complete histories and the actual full-board terminal
condition. They do not justify extending the list of state flags indefinitely.

## Lead 1: calibrate the meeting of two histories

This is the strongest common geometric target found in this exploration.
It can address both parity cases without requiring every solo continuation
to be optimal or every intermediate belief to be canonical.

Let A_l be the possible positions before a middle inspection after l
quota-feasible preceding rounds, starting from the full board. Let B_r
be the corresponding possible positions obtained by running the last r
rounds backward, reversing the suffix inspection order and also starting
from the full board. Because adjacency is
undirected, a complete surviving walk exists through a middle room exactly
when that room lies in A_l intersection B_r and is not inspected there.
Consequently these two particular histories can be joined into a winning
strategy of l+r+1 days exactly when

    |A_l intersection B_r| <= k.

This is an exact reformulation, not a solution: the histories still range
over the true game. Its value is that it identifies the right quantity to
bound. Separate scalar efficiencies are not enough; actual middle overlap
is the obstruction.

A concrete proof target is an explicit paired potential Phi(A,B) satisfying:

- Phi(V,V) >= T_star - 1 for the proposed optimal construction;
- Phi(A,B) <= 0 whenever |A intersection B| <= k;
- a legal update of either side, A -> N(A minus S) or the corresponding
  update of B, with |S|<=k, lowers Phi by at most one.

Then at least T_star-1 updates are required before the final inspection.
It suffices to prove the inequalities on pairs attainable from the full
start. Defining Phi to be an optimal remaining time would be circular;
the desired object is a stated expression or a telescoping geometric charge.
A fixed two-day block inequality could replace one-day inequalities if
phase effects require it, with the end cases handled explicitly. Proving
a stronger one-day potential is not an additional completion obligation.

The promising difference from the current one-sided radius argument is a
relative-position term. Two individually weak entrance estimates may still
force large middle overlap. The existing exact corner-ball lens calculations
are potential ingredients. The two histories do not share ancestry, however:
any relationship between their anchors must follow from their geometry and
the meeting condition, not be imposed by assumption.

For odd area, the smallest target is the implication that if any two actual
histories can share the proposed last day, the stated pure-history strategy
can do so. There is no need to identify the exact optimum of every auxiliary
central-cost problem. For 24 by 24, k=13, one concrete test is whether a
102-round prefix and a reversed 103-round suffix can have middle overlap
at most 13; excluding that would exclude a 206-day strategy.

**Why this has full-closure potential:** it could supply a single lower-bound
principle for the remaining even and odd decisions, matched by a directly
specified family of constructions. If the initial calibration value itself
has a fixed-size formula, it could also bypass numerical clock iteration.
That last possibility requires a real new identity; the reformulation alone
does not remove the arithmetic difficulty.

**First decisive test:** proposed pair features must survive actual reachable
prefix/suffix pairs, their reflections, and updates on either side. Look for
equal-feature pairs with different middle behavior, and for a failed
one-step inequality. This tests the proposed mechanism rather than collecting
more exact board values.

Discrete calibration methods exist in the isoperimetric literature, including
[Petrache and Gomez](https://arxiv.org/abs/2012.11039). Their results concern
static edge boundaries, not this dynamic vertex-inspection game. The useful
import is the proof architecture: a sharp inequality tied to the desired
extremal object, with equality determining the construction.

## Lead 2: an accumulated arithmetic invariant, not more band acceleration

The strongest arithmetic finding is a precise Josephus connection inside the
actual optimal minimum-budget clock. It survives pairing the square and
pronic phases, so simply combining alternate days does not eliminate it.

For width 2r+1 and budget r+1, a long initial segment of the terminal clock
passes through consecutive translation bands. If e_j denotes the inherited
overshoot on entering the next band, its exact update is

    e_1 = 0,
    e_j = (e_(j-1) - r) mod j.

With zero-based standard Josephus notation
J(1,q)=0, J(j,q)=(J(j-1,q)+q) mod j, this is

    e_j = j-1-J(j,r+1).

Thus the Josephus step varies with the board width. The familiar binary
formula for fixed step two does not apply. This segment covers consecutive
moduli through N=r-1+[r odd]; the remaining lower tail still needs treatment.
The calculation was checked directly on the actual paired map for r=12
and r=64. It is exploratory algebra, not a proof of any complexity barrier.

The accumulated number of pairs in this segment is

    r(H_N-1) - floor(N/2) + e_N/N
      + sum_(j=2)^(N-1) e_j/[j(j+1)].

Here H_N=sum_(j=1)^N 1/j is the harmonic number.

This expression is useful diagnostically and DOES NOT satisfy the goal.
It shows exactly what survives a first telescoping attempt: a weighted
history of remainders. Independent band counts that reset each overshoot
give 23 instead of 20 pairs at r=12, and 241 instead of 210 at r=64.
The carries are not a harmless final parity adjustment.

A weighted work count already telescopes. Elapsed time is the unweighted
count and needs a second identity. The best target is therefore an explicit
observable whose change across a band equals its duration minus a simple
reference term, including skipped bands and the remaining lower tail.
Its total change must depend on a fixed number of elementary endpoint
expressions. Merely evaluating the same remainder recurrence faster would
not close the box.

The numerical lane also found a two-candidate expression for each uncapped
lower-corner, phase-one paired band endpoint: two bounding quadratics cross
at an explicitly known rational
point, so only its floor and ceiling are needed. This removes the optimization
inside one band; it leaves accumulation over the input-dependent number of
bands. Capped and reflected finite-board branches still need their own
treatment. This is a useful language for the desired invariant, not numerical
completion.

[Odlyzko and Wilf's 1991 paper](https://www-users.cse.umn.edu/~odlyzko/doc/arch/josephus.problem.pdf)
and [Halbeisen and Hungerbuehler's 1997 paper](https://math.ch/norbert.hungerbuehler/publications/The_Josephus_problem.pdf)
are directly relevant to the floor-iteration issue. Fixed-step formulas,
parameter-dependent limit constants, and fast recursive algorithms require
a separate uniformity check here. None reviewed supplies the required
expression for this varying-step accumulated clock.

**Why this has full-closure potential:** a uniform clock coordinate could
apply across all low-surplus boundary phases after the geometry is settled.
The minimum-budget clock is the cleanest decisive test because optimality
is already known there. Success would attack the genuinely missing numerical
ingredient rather than add another budget range.

**Honest limitation:** this is a sharp research target, not a high-confidence
claim that an elementary formula exists. No impossibility result was found
either. The special minimum-budget connection does not establish a reduction
from arbitrary Josephus instances to rectangle capture time.

There is a useful positive comparison. For the simpler recurrence
a -> a+floor(sqrt(a)), started at 1, write the entry into root band j as
j^2+e. A zero offset takes three steps through the band and sets the next
offset to j-1; a positive offset takes two steps and decreases by one.
The zero offsets consequently occur at powers of two. Entry into band j
therefore takes exactly 2(j-1)+ceil(log_2(j)) steps. This is not our clock,
but it illustrates the right kind of discovery: a global reset law can
collapse arbitrarily many root bands into a fixed expression. The Josephus
connection sharpens the search for such a law; it does not rule one out.

## Lead 3: a boundary-aware least-action description

This is the most plausible outside-field partner for the first two leads,
but it is less developed than the paired calibration target.

The existing virtual height theorem has an order-independent feature: for
admissible comparable endpoint fronts, a prescribed number of legal corner
lowerings can be arranged to reach the target. In the guarded interior, daily movement is
uniform height addition and the construction is already explicit.

[Bond and Levine's abelian-network least-action principle](https://arxiv.org/abs/1309.3445)
suggests representing the cumulative local operations by an odometer, then
characterizing its final value through local inequalities rather than the
whole order of operations. A successful physical version would have to retain
clipping at both ends and the daily capacity. Those are exactly the parts
omitted by the virtual interior simplification.

The promising synthesis is to express physical boundary visits as a regulator
or debt term, derive a least-action inequality for the full trajectory, and
make its equality case specify the inspections. A closed accumulated debt
could be the missing arithmetic observable in Lead 2; a paired version could
be the overlap calibration in Lead 1.

**Decisive gate:** operations that commute virtually must either commute
physically with the same daily costs, or their failure to commute must have
an exact, bounded-description correction. Arbitrary borrowing of tomorrow's
inspection quota is invalid. An abelian model that computes only total work
but leaves the deadline scheduling unresolved would be another intermediate
result.

Rowmotion and the octahedron recurrence offer a related, more speculative
source of telescoping statistics and predictable chain shifts on rectangular
posets: [Johnson and Liu](https://arxiv.org/abs/2204.04255). There is no direct
conjugacy established. The finite clock terminates, whereas rowmotion is
invertible and periodic; inverse deficit maps also coalesce. A lift must
retain the lost boundary information. Variable-size path formulas and
complete-orbit averages do not automatically evaluate our first passage.
This is a targeted source of identities, not a reason to begin a general
integrable-systems project.

## Attractive approaches that were downgraded during exploration

### Monotone clearance histories and domino matchings

Initially this was the leading structural idea: identify opposite-color
rooms using a fixed domino matching and seek an optimal history in which
matched survivor sets only shrink. It would replace many history flags by
clearance times, with daily obligations represented by parity intervals.

Small exact comparisons passed, as did the known optimal 6 by 6, k=5
history. The accepted 16-row, k=56 shape-change solo witnesses fail stripe
matchings but each becomes nested under one fixed nonstripe matching: an
eight-cycle change in a four-by-two patch repairs the whole history.
The test covered the complete solo histories at lengths 22 and 34, not a
common matching for both cohorts of a full merged strategy.

The accepted 25 by 26, k=13, 188-day solo witness is much less encouraging.
After deleting every matching edge that violates any-day nesting, the largest
matching has only 182 pairs rather than 325. A Hall witness has 212 vertices
and only 69 permitted neighbors. That same history also violates physical
same-color two-day nesting on 20 days.

These are counterexamples for the specified optimal witness, not proofs that
every optimum fails a nesting condition. Nevertheless, a simple monotone
normal form now requires replacing a known optimum, rather than merely
recognizing it. It should not lead the next effort without a mechanism for
that replacement. Nor would a clearance field with one variable per room
itself give a fixed-size formula.

### Balanced interval coloring and causal exchanges

Ordinary union/intersection of two survivor histories improves a sum of
costs but can violate individual daily quotas. The two-vertex example turns
two legal cost vectors (1,1) into (0,2) and (2,0).

[Balanced Interval Coloring](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.STACS.2011.531)
provides a close possible repair when independent unit packets really have
interval support. Our natural packets have linked odd/even intervals;
the abstract supports {1,3}, {1,2}, {2,3} already prevent balanced two-coloring.
No physical grid realization of that isolated obstruction is claimed.

We also defined exchanges that are provably legal by swapping connected
components of the local spacetime dependency graph. On existing witnesses,
the components were whole cohort sweeps or the entire differing history.
The safe exchange was therefore largely vacuous. Any useful finer exchange
must use actual geometry to break these dependencies, not assume independent
packets. Detailed hypotheses and receipts are in strategy.md.

### Generic min-cut, convexity, and pathwidth

The time-expanded cut formulation is exact integrally, but its ordinary
fractional relaxation is extremely weak. On 4 by 4 with k=3, assigning shot
weight 1/6 to every room for six days covers every temporal path fractionally
and fits every daily budget; the actual optimum is 12 days. On graphs with
a perfect matching, the natural relaxed minimum daily budget is simply
|V|/T. New geometric integral inequalities are required.

The [multi-budgeted cut literature](https://link.springer.com/article/10.1007/s00453-019-00609-1)
studies the exact kind of separate-resource restriction involved here, but
its general algorithms do not provide a uniform rectangle formula. General
hardness does not establish hardness for rectangles.

The actual day-one deficit domain on 11 by 11, k=7 also fails the standard
discrete-convex exchange axiom. Straightforward Monge or marginal-priority
arguments are therefore unsupported in the current coordinates.

[Monotone hunters](https://arxiv.org/abs/2309.16533) can need far more resources
than unrestricted hunters on other graph families. Standard pathwidth and
[minimum-length path decompositions](https://arxiv.org/abs/1302.2788) are useful
analogies, not equivalent solutions to the alternating rectangle game.

### Generic algebraic compression

Matrix diagonalization requires an appropriate linear recurrence of bounded
dimension. Our transitions are controlled nonlinear floor/root maps, and
the general exact transfer matrices grow with parameters. Calling them
matrices does not produce the desired fixed expression.

Beatty/Sturmian coding fails for the most natural actual carry word: at
r=64 one constant-quotient segment contains both 00 and 11, so it is not
balanced. A different coordinate is still possible.

Euclidean reciprocity, Barvinok counting, Presburger descriptions, and
generating functions become plausible tools after a bounded-dimensional
structural reduction. Bounded dimension by itself does not supply a polytope
encoding or establish Presburger definability; variable products and root
capacities still need to be handled. General polynomial or logarithmic evaluation, an
input-dependent period, and unevaluated finite sums do not meet the goal.

## Suggested order of attention if research is resumed

1. Use the exact forward/reverse middle condition as the common geometric
   target. Test a paired calibration with relative-corner and overlap terms
   against existing troublesome witnesses before building new machinery.
2. In parallel, attack the accumulated Josephus correction of the already
   solved minimum-budget family. Demand a total-duration identity, not just
   faster iteration or a formula for individual bands.
3. Use boundary-aware least action and local geometric exchanges as candidate
   mechanisms for those two obligations. Give them explicit failure gates;
   do not let general abelian-network or rowmotion theory become a new scope.

The promising path is a combination of a whole-game geometric certificate
and a genuinely uniform arithmetic identity. At this stage there is no
single established reduction that removes both obstacles, and no basis for
describing full fixed-operation closure as routine or imminent.

## Evidence and restart pointers

- geometry.md: whole-history geometry, matching and nesting diagnostics,
  and the conditions under which rearrangement literature could apply.
- strategy.md: paired calibration, the exact odd threshold target,
  causal exchange conditions, and rejected convex/flow shortcuts.
- numerical.md: paired band derivation, Josephus identity, numerical
  diagnostics, and uniformity checks on the literature.
- root-notes.md: exact spacetime cut and fractional-relaxation calculation.
- JSON receipts in this directory preserve the small diagnostic witnesses.

All diagnostics were bounded checks of representations or existing witnesses.
No parameter-family capture search, theorem-development campaign, formal
build, or public artifact update was started.

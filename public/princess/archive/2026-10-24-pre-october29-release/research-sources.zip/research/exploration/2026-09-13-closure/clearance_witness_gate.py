"""Read-only geometric screening of existing physical winning histories."""
from itertools import product, combinations
from pathlib import Path
from time import process_time
import hashlib
import json

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).parent

def geometry(w,n):
    vertices=set(product(range(w),range(n)))
    adjacent={v:{(v[0]+dx,v[1]+dy) for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))
                 if 0<=v[0]+dx<w and 0<=v[1]+dy<n} for v in vertices}
    def hood(a):
        return set().union(*(adjacent[v] for v in a)) if a else set()
    return vertices,adjacent,hood

def allowed_matching(w,n,initial_phase,shots):
    V,adj,N=geometry(w,n)
    black=sorted(v for v in V if sum(v)%2==0)
    allowed={u:set(adj[u]) for u in black}
    # Initial matched support is full, so the first survivor has no constraint.
    # Both endpoint colors must be available for that virtual predecessor.
    old=V.copy();A={v for v in V if sum(v)%2==initial_phase}
    stripe_bad={axis:[] for axis in (0,1) if (w,n)[axis]%2==0}
    pyramids=[];layers=[]
    for day,S in enumerate(shots,1):
        S=set(map(tuple,S));R=A-S
        for axis in stripe_bad:
            old_ids={(v[axis]//2,v[1-axis]) for v in old}
            bad=[v for v in R if (v[axis]//2,v[1-axis]) not in old_ids]
            if bad:stripe_bad[axis].append(dict(day=day,rooms=sorted(bad)))
        for u in black:
            allowed[u]={v for v in allowed[u]
                        if not (u in R and v not in old) and not (v in R and u not in old)}
        pyramids.append(all((xx,y-1) in R for x,y in R
                            for xx in (x-1,x+1) if 0<=xx<w and y>0))
        layers.append(dict(day=day,belief=len(A),shots=len(A&S),survivors=len(R)))
        old=R;A=N(R)
    assert not A
    # Start with all still-legal short-axis stripe dominoes, then use shortest
    # alternating augmenting paths. This makes any required repair explicit.
    mate={};leftmate={}
    for u in black:
        v=(u[0]^1,u[1])
        if v in allowed[u]:mate[v]=u;leftmate[u]=v
    stripe_initial=len(mate)
    for root in black:
        if root in leftmate:continue
        queue=[root];seen={root};pre={};end=None
        for u in queue:
            for v in sorted(allowed[u]):
                if v in pre:continue
                pre[v]=u
                if v not in mate:end=v;break
                if mate[v] not in seen:seen.add(mate[v]);queue.append(mate[v])
            if end is not None:break
        if end is not None:
            v=end
            while True:
                u=pre[v];before=leftmate.get(u);mate[v]=u;leftmate[u]=v
                if before is None:break
                v=before
    unmatched=set(black)-set(mate.values());L=set(unmatched);R=set();queue=list(L)
    for u in queue:
        for v in allowed[u]:
            if v not in R:
                R.add(v)
                if v in mate and mate[v] not in L:L.add(mate[v]);queue.append(mate[v])
    return dict(width=w,length=n,days=len(shots),all_downward_pyramids=all(pyramids),
                stripe_violations=stripe_bad,allowed_edges=sum(map(len,allowed.values())),
                matched_pairs=len(mate),required_pairs=len(black),perfect=len(mate)==len(black),
                hall_left=sorted(L),hall_neighbors=sorted(R),layers=layers,
                matching=sorted((u,v) for v,u in mate.items()),stripe_initial=stripe_initial,
                nonstripe_dominoes=sorted((u,v) for v,u in mate.items() if v!=(u[0]^1,u[1])))

def six_case():
    V,adj,N=geometry(6,6);C=[{v for v in V if sum(v)%2==p} for p in (0,1)]
    old=[{(x//2,y) for x,y in A} for A in C]
    incidence={(p,i,j):0 for p in (0,1) for i in range(3) for j in range(6)}
    clear={};shots=[];violations=[];solo=[]
    for cohort in (1,0):
        local=[]
        while C[cohort]:
            S=set(sorted(C[cohort],key=lambda v:(sum(v),-v[0]))[-5:])
            C[cohort]-=S;day=len(shots)+1;shots.append(sorted(S));local.append(sorted(S))
            for x,y in S:incidence[cohort,x//2,y]|=1<<(day-1)
            for p in (0,1):
                cur={(x//2,y) for x,y in C[p]}
                if cur-old[p]:violations.append(dict(day=day,cohort=p,reentered=sorted(cur-old[p])))
                for i,j in old[p]-cur:clear[p,i,j]=day
                old[p]=cur
            C=[N(A) for A in C]
        solo.append(local)
    tri=None;triples=0
    for ts in combinations(range(len(shots)),3):
        triples+=1;groups={}
        for col,mask in incidence.items():
            tag=sum(((mask>>t)&1)<<j for j,t in enumerate(ts));groups.setdefault(tag,col)
        if all(tag in groups for tag in (3,5,6)):
            tri=dict(days=[t+1 for t in ts],packets=[groups[tag] for tag in (3,5,6)]);break
    return dict(width=6,length=6,budget=5,days=len(shots),full_capture=not any(C),
                nested=not violations,violations=violations,shot_sizes=list(map(len,shots)),
                shots=shots,clearance=[dict(cohort=p,pair=[i,j],day=t) for (p,i,j),t in sorted(clear.items())],
                incidence=[dict(cohort=p,pair=[i,j],mask=mask) for (p,i,j),mask in sorted(incidence.items())],
                triangle_minor=tri,triples_checked=triples,
                solo_matching_gate=allowed_matching(6,6,1,solo[0]))

def main():
    start=process_time();source=ROOT/'research/bridge-quadratic-edge-exception-splice.json'
    rows=json.loads(source.read_text());six=six_case()
    sixteen=[allowed_matching(16,row['n'],1,row['solo_shots']) for row in rows[:2]]
    out=dict(scope='Structural screening only; no new optimal-time theorem or generic TU claim.',
             source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             existing_witness_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
             six_by_six=six,sixteen_rows=sixteen,cpu_seconds=process_time()-start)
    (OUT/'clearance-witness-gate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(six_days=six['days'],six_nested=six['nested'],six_triangle=six['triangle_minor'],
                         sixteen=[dict(length=r['length'],perfect=r['perfect'],matched_pairs=r['matched_pairs'],
                                       required_pairs=r['required_pairs'],hall_sizes=[len(r['hall_left']),len(r['hall_neighbors'])]) for r in sixteen],
                         cpu_seconds=out['cpu_seconds']),indent=2))

if __name__=='__main__':main()
